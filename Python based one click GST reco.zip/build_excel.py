"""Excel report writer - section 9 of the spec. Four sheets."""

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NAVY = "1F2E4A"
GOLD = "C9A84C"
CREAM = "F0EDE6"

IND_NUM = r'[>9999999]##\,##\,##\,##0.00;[>99999]##\,##\,##0.00;##,##0.00'
IND_NUM_RED = (r'[>9999999]##\,##\,##\,##0.00;[>99999]##\,##\,##0.00;'
               r'[Red]-##,##0.00')
DATE_FMT = "DD-MM-YYYY"

thin = Side(style="thin", color="D8D2C4")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)


def _write_sheet(ws, rows, columns, numeric_cols, date_cols, note=None):
    ws.freeze_panes = "A2"
    for j, col in enumerate(columns, start=1):
        c = ws.cell(row=1, column=j, value=col)
        c.font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=NAVY)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = BORDER

    for i, row in enumerate(rows, start=2):
        for j, col in enumerate(columns, start=1):
            v = row.get(col)
            c = ws.cell(row=i, column=j, value=v)
            c.font = Font(name="Arial", size=10)
            c.border = BORDER
            if col in numeric_cols:
                c.number_format = IND_NUM
                c.alignment = Alignment(horizontal="right")
            elif col in date_cols:
                c.number_format = DATE_FMT
                c.alignment = Alignment(horizontal="center")

    # column widths
    for j, col in enumerate(columns, start=1):
        width = max(11, min(28, len(str(col)) + 4))
        ws.column_dimensions[get_column_letter(j)].width = width

    # totals row driven by formulas, never hardcoded
    if rows:
        tr = len(rows) + 2
        tc = ws.cell(row=tr, column=1, value="TOTAL")
        tc.font = Font(name="Arial", bold=True, size=10)
        tc.fill = PatternFill("solid", fgColor=GOLD)
        for j, col in enumerate(columns, start=1):
            cell = ws.cell(row=tr, column=j)
            cell.fill = PatternFill("solid", fgColor=GOLD)
            cell.font = Font(name="Arial", bold=True, size=10)
            cell.border = BORDER
            if col in numeric_cols:
                letter = get_column_letter(j)
                cell.value = f"=SUM({letter}2:{letter}{len(rows) + 1})"
                cell.number_format = IND_NUM
        if note:
            n = ws.cell(row=tr + 2, column=1, value=note)
            n.font = Font(name="Arial", size=9, italic=True, color="777777")

    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{len(rows) + 1}"


def build_excel(path, reco_rows, pr_only, rb_only, summary_rows, meta):
    wb = Workbook()

    # ---- Cover -------------------------------------------------------------
    ws = wb.active
    ws.title = "Run Summary"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "GSTR-2B Reconciliation Report"
    ws["A1"].font = Font(name="Arial", bold=True, size=16, color=NAVY)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 40
    r = 3
    for k, v in meta.items():
        ws.cell(row=r, column=1, value=k).font = Font(name="Arial", bold=True, size=10)
        c = ws.cell(row=r, column=2, value=v)
        c.font = Font(name="Arial", size=10)
        c.alignment = Alignment(horizontal="left")
        r += 1
    ws.cell(row=r + 1, column=1,
            value=("Assumptions: engine defaults per Logic Specification v1.0 clause 14. "
                   "IMPG, IMPGSEZ, ISD and ECO documents are not read (clause 11.4). "
                   "Credit notes compared as recorded, no sign flip (clause 11.2)."
                   )).font = Font(name="Arial", size=9, italic=True, color="777777")

    money = ["Taxable Value", "IGST", "CGST", "SGST", "Cess",
             "2B Taxable Value", "2B IGST", "2B CGST", "2B SGST",
             "ITC Difference", "Total ITC",
             "PR Unrec Taxable", "PR Unrec ITC", "2B Unrec Taxable", "2B Unrec ITC"]
    dates = ["Invoice Date", "2B Invoice Date"]

    reco_cols = ["GSTIN of Supplier", "Invoice No", "Invoice Date", "Taxable Value",
                 "IGST", "CGST", "SGST", "Cess", "Match Status", "Match Reason",
                 "2B GSTIN", "2B Invoice No", "2B Invoice Date", "2B Taxable Value",
                 "2B IGST", "2B CGST", "2B SGST", "ITC Difference"]
    _write_sheet(wb.create_sheet("Reconciliation"), reco_rows, reco_cols, money, dates,
                 note="One row per purchase register line. Blank 2B columns mean no matching 2B document.")

    std = ["GSTIN of Supplier", "Invoice No", "Invoice Date", "Taxable Value",
           "IGST", "CGST", "SGST", "Cess", "Total ITC"]
    _write_sheet(wb.create_sheet("PR Only"), pr_only, std, money, dates,
                 note="In books, not in GSTR-2B. This is ITC at risk. Follow up with the supplier.")
    _write_sheet(wb.create_sheet("2B Only"), rb_only, std[:-1] + ["Type", "Total ITC"], money, dates,
                 note="In GSTR-2B, not in books. ITC unclaimed, or the purchase is not recorded.")

    sum_cols = ["GSTIN", "PR Unrec Lines", "PR Unrec Taxable", "PR Unrec ITC",
                "2B Unrec Lines", "2B Unrec Taxable", "2B Unrec ITC", "ITC Difference"]
    _write_sheet(wb.create_sheet("GSTIN Summary"), summary_rows, sum_cols, money, [],
                 note="Pending records only, sorted by the size of the ITC difference. Chase the top rows first.")

    wb.save(path)
    return path
