# GSTR-2B Reconciliation Tool - read me first

A small Python tool that reconciles a Purchase Register against GSTR-2B and produces
two things: a formatted Excel working paper and a self-contained HTML dashboard.

---

## 1. What is in this folder

| File | What it is | What it does |
|---|---|---|
| `run_reco.py` | The only file you run | Asks for the folder holding your data files, picks up the Purchase Register and the GSTR-2B file from it, runs a few sanity checks, calls the engine, writes both reports, then checks its own results |
| `reco_engine.py` | The brain | All the reconciliation logic: reading the two files, cleaning dates and amounts, normalising invoice numbers, the three matching passes, and assembling the output tables. No screen output, no file writing |
| `build_excel.py` | Excel writer | Turns the results into the .xlsx report using openpyxl. Handles the formatting: navy and gold theme, Indian number format (lakhs and crores), frozen header rows, filters, and formula-driven TOTAL rows |
| `build_dashboard.py` | Dashboard writer | Builds the summary numbers and chart data, then injects them into an HTML template to produce the dashboard |
| `chart.umd.js` | Chart.js library, version 4.4.1 | The charting library, embedded inside the dashboard so it opens without an internet connection. Do not rename, move or delete it. It must stay next to `run_reco.py` |
| `Mock_PR.csv` | Demo data | A fake Purchase Register, 200 lines. Deliberately messy: invoice numbers written differently from 2B, small amount differences, date differences, wrong state codes |
| `Mock_GSTR2B.json` | Demo data | A fake GSTR-2B download in the JSON format the GST portal gives you |
| `README.md` | This file | Setup and running instructions |
| `HANDOFF.md` | Technical note | For whoever maintains the code: matching logic, fixes already applied, and known issues still open |
| `__pycache__` | Auto-generated | Python's compiled cache. Ignore it. Safe to delete at any time, it rebuilds itself |

Anything named `Reco_....xlsx` or `Dashboard_....html` is output from a previous run,
not part of the tool. Safe to delete.

---

## 2. What you need installed

1. **Python 3.10 or later.** Download from python.org. On the first install screen,
   tick **"Add Python to PATH"** before clicking Install. This one tick saves a lot of pain.
2. **Two libraries.** Open Command Prompt and run:

       pip install pandas openpyxl

   That is the whole setup. Nothing else to install, no internet needed afterwards.

---

## 3. Running the demo

1. Unzip the folder anywhere, say `C:\GST Reco Demo`.
2. Open Command Prompt.
3. Move into the folder. Type `cd `, then drag the folder from Explorer into the
   Command Prompt window and press Enter. Or type it out:

       cd "C:\GST Reco Demo"

4. Run it:

       python run_reco.py

5. It asks:

       Data folder:

   For the demo, just **press Enter**. That tells it to use this same folder, where
   `Mock_PR.csv` and `Mock_GSTR2B.json` are already sitting.

6. It shows which files it has picked up:

       GSTR-2B               : Mock_GSTR2B.json
       Purchase Register     : Mock_PR.csv

   It then asks for the two details that go on the report header:

       Client name [Demo Client Pvt Ltd]:
       Client GSTIN [24AAACD1234F1ZP]:

   Press Enter at both to accept what is shown in the brackets. For the demo that is all
   you need. It then runs and finishes with:

       Matched 165 of 200 (82.5%)
       Invariants OK

   If you see `Matched 165 of 200` and `Invariants OK`, it worked correctly.

7. Two new files appear in the folder:
   - `Reco_24AAACD1234F1ZP_062025_<date>_<time>.xlsx` - open in Excel
   - `Dashboard_24AAACD1234F1ZP_062025_<date>_<time>.html` - double-click, opens in any browser

---

## 4. Running it on real data

Same command, but at the `Data folder:` prompt paste the full path of the folder where
the real Purchase Register and GSTR-2B file are kept, for example:

    D:\Clients\ABC Ltd\June 2025

Tip: in Explorer, hold Shift, right-click the folder, choose **Copy as path**, and paste.
The quotes it adds are handled automatically.

Inside that folder the script finds the files by itself:

- **GSTR-2B**: any `.json` file, or an `.xlsx`/`.xls` with "2b" in the name
- **Purchase Register**: any other `.csv`, `.xlsx`, `.xlsm` or `.xls`
- If more than one file fits either description, it lists them and asks you to pick a number
- Previous outputs (`Reco_*`, `Dashboard_*`) and Excel lock files (`~$*`) are ignored

Both reports are written into that same data folder, not into the tool folder.

### The client name and GSTIN on the report header

Asked for after the files are picked up. They appear on the Run Summary sheet, on the
dashboard, and in the two output file names. They have no effect on the matching itself.

- **GSTIN**: if the GSTR-2B file is a JSON downloaded from the portal, it already carries
  the GSTIN it was issued to. The script reads it from there and does not ask. Otherwise
  it asks and checks the shape of what you type, for example 24AAACD1234F1ZP. A value
  that fails the check can still be forced through if you are sure
- **Client name**: always asked. Press Enter to keep the value in brackets
- **Tax period**: taken from the return period inside the 2B JSON where present, otherwise
  from the commonest month among the purchase register invoice dates

The Purchase Register columns do not have to be in any fixed order or have exact names.
The tool looks at the headers and works out which column is the GSTIN, which is the
invoice number, and so on. The mapping it used is printed on the Run Summary sheet of
the Excel report, so it is always worth a glance before relying on the numbers.

---

## 5. What the two reports contain

**Excel report, five sheets:**

| Sheet | Contents |
|---|---|
| Run Summary | Client, GSTIN, period, file names, match rate, ITC at risk, tolerances used, the column mapping it worked out, and any warnings |
| Reconciliation | One row per Purchase Register line, with the 2B document it matched to alongside, the match status, the reason, and the ITC difference |
| PR Only | In your books but not in 2B. This is ITC at risk. Chase the supplier |
| 2B Only | In 2B but not in your books. Either unclaimed ITC or an unrecorded purchase |
| GSTIN Summary | Unreconciled amounts totalled supplier-wise, sorted with the biggest ITC gap on top, so you know who to call first |

**HTML dashboard:** the same story in charts and headline figures. One file, opens in any
browser, works offline, can be emailed as is.

---

## 6. How it matches, briefly

Three passes, in order. Once a Purchase Register line is matched, it is out of the running,
and each 2B document can only be claimed once.

1. **Same GSTIN, same invoice number.** Graded as Exact Match, Date Mismatch (amount agrees,
   date does not) or Amount Mismatch (date agrees, amount does not).
2. **Same GSTIN, invoice number nearly the same.** Tries progressively looser comparisons:
   ignoring punctuation, then digits only, then dropping the financial year, then dropping
   leading zeros. The amount must still agree.
3. **Same PAN, different GSTIN.** Catches the case where the branch or state code is wrong.

Tolerances used: Rs 2.00 in total across taxable value plus IGST, CGST and SGST, and
5 days on the invoice date.

---

## 7. If something goes wrong

| Message | What it means |
|---|---|
| `'python' is not recognized` | Python is not on PATH. Reinstall Python and tick "Add Python to PATH" |
| `No module named pandas` (or `openpyxl`) | Run `pip install pandas openpyxl` |
| `chart.umd.js not found next to run_reco.py` | That file was deleted or the .py files were moved without it. Put it back in the same folder |
| `No GSTR-2B file found in ...` | Wrong folder, or the 2B file is not a `.json` and has no "2b" in its name. Rename it, or pass the paths directly |
| `Not a folder: ...` | Typo in the path. It will simply ask again |
| `Permission denied` on saving | The previous Excel report is still open. Close Excel and re-run |

To skip the prompts entirely:

    python run_reco.py "D:\path\to\data folder"
    python run_reco.py "path\to\PR.xlsx" "path\to\2B.json" "path\to\output folder"

---

## 8. Before relying on the output

Two things worth checking on every real run, both on the Run Summary sheet of the Excel
report:

- **The column mapping** that the tool worked out for the purchase register. If it has
  picked the wrong column for the invoice number or a tax head, the match rate will look
  poor for no good reason
- **The warnings line**, which flags the two common causes of a bad run: too few rows
  carrying a GSTIN-shaped value, and purchase register dates that sit in a different
  month from the 2B

This is a demo tool running on mock data. Reconciliation output should be reviewed by a
professional before being relied on for any GST return or ITC claim.
