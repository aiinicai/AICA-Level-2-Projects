"""
GSTR-2B Reconciliation Engine
Implements sections 4 to 9 of the Logic Specification v1.0 (25 August 2026).

Pure engine: no UI, no I/O side effects beyond reading the input files.
"""

import json
import math
import re
from datetime import datetime, timedelta, date

import pandas as pd

# ----------------------------------------------------------------------------
# Section 14 - defaults
# ----------------------------------------------------------------------------
DEFAULT_TOL_AMT_ABS = 2.00
DEFAULT_TOL_AMT_PCT = 0.0
DEFAULT_TOL_DAYS = 5

STD_FIELDS = [
    "GSTIN of Supplier", "Invoice No", "Invoice Date",
    "Taxable Value", "IGST", "CGST", "SGST", "Cess",
]

TWOB_SHEETS = {"b2b", "b2ba", "b2b-cdnr", "b2b-cdnra", "cdnr", "cdnra", "b2b-dnr"}
IGNORE_SHEET_TOKENS = ["reject", "read me", "itc available", "itc not available",
                       "itc reversal", "itc rejected"]

GSTIN_SHAPE = re.compile(r"^\d{2}[A-Z0-9]{11,13}$")
EXCEL_EPOCH = datetime(1899, 12, 30)


# ----------------------------------------------------------------------------
# Section 5.6 - date parsing
# ----------------------------------------------------------------------------
def parse_date(value):
    """Return a datetime.date, or None. Day-first convention for ambiguous text."""
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None

    # 1. already a date/datetime object - strip the time component
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, pd.Timestamp):
        return value.to_pydatetime().date()

    # 2. Excel serial number
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value < 1:
            return None
        return (EXCEL_EPOCH + timedelta(days=int(round(value)))).date()

    text = str(value).strip()
    if not text or text.lower() in ("nan", "nat", "none"):
        return None

    # 3. yyyy-mm-dd / yyyy/mm/dd
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", text)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None

    # 4. dd-mm-yyyy / dd/mm/yy / dd.mm.yyyy  -> DAY FIRST
    m = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})", text)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, mo, d)
        except ValueError:
            return None

    # 5. generic fallback
    try:
        return pd.to_datetime(text, dayfirst=True).date()
    except Exception:
        return None


# ----------------------------------------------------------------------------
# Section 5.7 / 5.8 - cleaning
# ----------------------------------------------------------------------------
def clean_number(value):
    if value is None:
        return 0.0
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return 0.0 if (isinstance(value, float) and math.isnan(value)) else float(value)
    text = str(value).replace(",", "").replace("\u20b9", "").replace("Rs.", "").replace("Rs", "").strip()
    text = text.replace(" ", "")
    if text in ("", "-", "nan", "None"):
        return 0.0
    try:
        return float(text)
    except ValueError:
        return 0.0


def clean_gstin(value):
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    return re.sub(r"\s+", "", str(value)).upper().strip()


# ----------------------------------------------------------------------------
# Section 6 - invoice number normalisation ladder
# ----------------------------------------------------------------------------
def normalise_inv(value, mode="basic"):
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    s = str(value).strip().upper()
    if s in ("", "NAN", "NONE"):
        return ""

    if mode == "basic":
        return s
    if mode == "no_special":
        return re.sub(r"[^A-Z0-9]", "", s)
    if mode == "no_alpha":
        return re.sub(r"[^0-9]", "", s)
    if mode == "no_fy":
        s = re.sub(r"20\d{2}[-/]\d{2}", "", s)
        s = re.sub(r"\d{2}[-/]\d{2}", "", s)
        return s
    if mode == "no_leading_zero":
        return re.sub(r"^0+", "", s)
    return s


# ----------------------------------------------------------------------------
# Section 5.1 - header row detection
# ----------------------------------------------------------------------------
def detect_header_row(raw_df, scan_rows=20):
    limit = min(scan_rows, len(raw_df))
    for i in range(limit):
        cells = [str(c).lower() for c in raw_df.iloc[i].tolist() if pd.notna(c)]
        joined = " | ".join(cells)
        has_gstin = "gstin" in joined or "gstn" in joined
        has_other = any(t in joined for t in ("inv", "tax", "date", "value"))
        if has_gstin and has_other:
            return i
    return 0


def uniquify(headers):
    seen, out = {}, []
    for idx, h in enumerate(headers):
        name = str(h).strip() if (h is not None and str(h).strip() and str(h) != "nan") else f"Column {idx + 1}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 0
        out.append(name)
    return out


# ----------------------------------------------------------------------------
# Section 5.9 - PR column auto-mapping
# ----------------------------------------------------------------------------
def guess_pr_mapping(headers):
    mapping = {}
    lower = {h: str(h).lower() for h in headers}

    def take(field, header):
        if field not in mapping and header not in mapping.values():
            mapping[field] = header

    # strict pass, whole header list per rule
    for h in headers:
        l = lower[h]
        if "gstin" in l or "gstn" in l:
            take("GSTIN of Supplier", h)
    for h in headers:
        l = lower[h]
        if "inv" in l and ("no" in l or "num" in l):
            take("Invoice No", h)
    for h in headers:
        l = lower[h]
        if "inv" in l and ("date" in l or "dt" in l):
            take("Invoice Date", h)
    for h in headers:
        if "taxable" in lower[h]:
            take("Taxable Value", h)
    for h in headers:
        if "igst" in lower[h]:
            take("IGST", h)
    for h in headers:
        if "cgst" in lower[h]:
            take("CGST", h)
    for h in headers:
        l = lower[h]
        if "sgst" in l or "state" in l:
            take("SGST", h)
    for h in headers:
        if "cess" in lower[h]:
            take("Cess", h)

    # loose pass, only for still-unmapped fields
    for h in headers:
        if "date" in lower[h]:
            take("Invoice Date", h)
    for h in headers:
        l = lower[h]
        if "inv" in l or "bill" in l or "doc" in l or ("voucher" in l and ("no" in l or "num" in l)):
            take("Invoice No", h)
    for field in STD_FIELDS:
        for h in headers:
            if field.lower() in lower[h]:
                take(field, h)

    return mapping


# ----------------------------------------------------------------------------
# Purchase register reader
# ----------------------------------------------------------------------------
def read_pr(path, mapping_override=None):
    if str(path).lower().endswith(".csv"):
        raw = pd.read_csv(path, header=None, dtype=object, keep_default_na=False)
    else:
        raw = pd.read_excel(path, header=None, dtype=object, sheet_name=0)

    h = detect_header_row(raw)
    headers = uniquify(raw.iloc[h].tolist())
    df = raw.iloc[h + 1:].copy()
    df.columns = headers
    df = df.reset_index(drop=True)

    mapping = mapping_override or guess_pr_mapping(headers)

    records = []
    for _, row in df.iterrows():
        gstin = clean_gstin(row.get(mapping.get("GSTIN of Supplier"), ""))
        inv = row.get(mapping.get("Invoice No"), "")
        inv = "" if inv is None else str(inv).strip()
        if not gstin and not inv:
            continue
        records.append({
            "GSTIN of Supplier": gstin,
            "Invoice No": inv,
            "Invoice Date": parse_date(row.get(mapping.get("Invoice Date"))),
            "Taxable Value": clean_number(row.get(mapping.get("Taxable Value"))),
            "IGST": clean_number(row.get(mapping.get("IGST"))),
            "CGST": clean_number(row.get(mapping.get("CGST"))),
            "SGST": clean_number(row.get(mapping.get("SGST"))),
            "Cess": clean_number(row.get(mapping.get("Cess"))),
            "Type": "PR",
        })
    return records, mapping, headers


# ----------------------------------------------------------------------------
# Section 5.5 - GSTR-2B JSON reader
# ----------------------------------------------------------------------------
def _pick(node, keys):
    for k in keys:
        if k in node and node[k] not in (None, ""):
            return node[k]
    return None


def _tax_amounts(node):
    if isinstance(node.get("items"), list) and node["items"]:
        tot = dict(txval=0.0, igst=0.0, cgst=0.0, sgst=0.0, cess=0.0)
        for it in node["items"]:
            for k in tot:
                tot[k] += clean_number(it.get(k))
        return tot
    return dict(
        txval=clean_number(node.get("txval")), igst=clean_number(node.get("igst")),
        cgst=clean_number(node.get("cgst")), sgst=clean_number(node.get("sgst")),
        cess=clean_number(node.get("cess")),
    )


def read_2b_json(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        blob = json.load(f)

    root = blob.get("data", blob) if isinstance(blob, dict) else blob
    docdata = root.get("docdata", root) if isinstance(root, dict) else root

    records = []

    def harvest(section_key, child_key, type_fn):
        for supplier in (docdata.get(section_key) or []):
            ctin = clean_gstin(supplier.get("ctin", ""))
            for node in (supplier.get(child_key) or []):
                amt = _tax_amounts(node)
                records.append({
                    "GSTIN of Supplier": ctin,
                    "Invoice No": str(_pick(node, ["inum", "inv_no", "ntnum", "nt_num"]) or "").strip(),
                    "Invoice Date": parse_date(_pick(node, ["dt", "idt", "nt_dt", "doc_dt"])),
                    "Taxable Value": amt["txval"], "IGST": amt["igst"],
                    "CGST": amt["cgst"], "SGST": amt["sgst"], "Cess": amt["cess"],
                    "Invoice Value": clean_number(node.get("val")),
                    "Type": type_fn(node),
                })

    harvest("b2b", "inv", lambda n: "B2B")
    harvest("b2ba", "inv", lambda n: "B2BA")
    harvest("cdnr", "nt", lambda n: f"CDNR-{n.get('ntty', '')}")
    harvest("cdnra", "nt", lambda n: f"CDNRA-{n.get('ntty', '')}")
    return records


# ----------------------------------------------------------------------------
# Section 5.2 to 5.4 - GSTR-2B Excel reader
# ----------------------------------------------------------------------------
def _map_2b_header(text):
    l = str(text).lower()
    if "gstin" in l or "gstn" in l:
        return "GSTIN of Supplier"
    if "invoice n" in l or "note n" in l or "bill no" in l or "document n" in l:
        return "Invoice No"
    if "invoice date" in l or "note date" in l or "document date" in l:
        return "Invoice Date"
    if "taxable" in l:
        return "Taxable Value"
    if "integrated" in l or "igst" in l:
        return "IGST"
    if "central" in l or "cgst" in l:
        return "CGST"
    if "state" in l or "sgst" in l or "ut tax" in l:
        return "SGST"
    if "cess" in l:
        return "Cess"
    if "invoice value" in l or "note value" in l:
        return "Invoice Value"
    return None


def read_2b_excel(path):
    book = pd.read_excel(path, header=None, dtype=object, sheet_name=None)
    names = [n for n in book
             if n.strip().lower() in TWOB_SHEETS
             and not any(t in n.lower() for t in IGNORE_SHEET_TOKENS)]
    if not names:
        names = [list(book.keys())[0]]

    records = []
    for name in names:
        raw = book[name]
        h = detect_header_row(raw)
        headers = [("" if pd.isna(c) else str(c).strip()) for c in raw.iloc[h].tolist()]

        # two-row header merge
        data_start = h + 1
        if h + 1 < len(raw):
            nxt = [("" if pd.isna(c) else str(c).strip()) for c in raw.iloc[h + 1].tolist()]
            non_empty = [c for c in nxt if c]
            joined = " ".join(non_empty).lower()
            looks_data = any(re.match(r"^\d{2}[A-Z]{5}", c) for c in non_empty)
            if len(non_empty) >= 3 and re.search(r"invoice|note|date|tax|value", joined) and not looks_data:
                headers = [nxt[i] if i < len(nxt) and nxt[i] else headers[i] for i in range(len(headers))]
                data_start = h + 2

        col_map = {}
        for idx, htext in enumerate(headers):
            field = _map_2b_header(htext)
            if field and field not in col_map:
                col_map[field] = idx

        if "GSTIN of Supplier" not in col_map:
            continue

        base_type = "CDNR" if "cdnr" in name.lower() or "dnr" in name.lower() else "B2B"
        for _, row in raw.iloc[data_start:].iterrows():
            vals = row.tolist()

            def cell(field):
                i = col_map.get(field)
                return vals[i] if (i is not None and i < len(vals)) else None

            gstin = clean_gstin(cell("GSTIN of Supplier"))
            if not GSTIN_SHAPE.match(gstin):
                continue
            records.append({
                "GSTIN of Supplier": gstin,
                "Invoice No": "" if cell("Invoice No") is None else str(cell("Invoice No")).strip(),
                "Invoice Date": parse_date(cell("Invoice Date")),
                "Taxable Value": clean_number(cell("Taxable Value")),
                "IGST": clean_number(cell("IGST")), "CGST": clean_number(cell("CGST")),
                "SGST": clean_number(cell("SGST")), "Cess": clean_number(cell("Cess")),
                "Invoice Value": clean_number(cell("Invoice Value")),
                "Type": base_type,
            })
    return records


# ----------------------------------------------------------------------------
# Section 7 - tolerances
# ----------------------------------------------------------------------------
def is_amt_match(pr, rb, tol_abs=DEFAULT_TOL_AMT_ABS, tol_pct=DEFAULT_TOL_AMT_PCT):
    diff_taxable = abs(pr["Taxable Value"] - rb["Taxable Value"])
    diff_tax = (abs(pr["IGST"] - rb["IGST"]) + abs(pr["CGST"] - rb["CGST"])
                + abs(pr["SGST"] - rb["SGST"]))          # Cess deliberately excluded
    total_diff = diff_taxable + diff_tax
    if total_diff <= tol_abs:
        return True
    if tol_pct > 0:
        base = pr["Taxable Value"] + pr["IGST"] + pr["CGST"] + pr["SGST"]
        if base > 0 and (total_diff / base) * 100 <= tol_pct:
            return True
    return False


def is_date_match(pr, rb, tol_days=DEFAULT_TOL_DAYS):
    if pr["Invoice Date"] is None or rb["Invoice Date"] is None:
        return False
    return abs((pr["Invoice Date"] - rb["Invoice Date"]).days) <= tol_days


# ----------------------------------------------------------------------------
# Section 8 - the matching engine
# ----------------------------------------------------------------------------
PATTERN_ORDER = ["no_special", "no_alpha", "no_fy", "no_leading_zero"]


def reconcile(pr_records, rb_records,
              tol_amt_abs=DEFAULT_TOL_AMT_ABS,
              tol_amt_pct=DEFAULT_TOL_AMT_PCT,
              tol_days=DEFAULT_TOL_DAYS):

    pr = [dict(r, status="Pending", reason="", link=-1, _id=i) for i, r in enumerate(pr_records)]
    rb = [dict(r, status="Pending", _id=i) for i, r in enumerate(rb_records)]

    amt_ok = lambda a, b: is_amt_match(a, b, tol_amt_abs, tol_amt_pct)
    date_ok = lambda a, b: is_date_match(a, b, tol_days)

    # index 2B by GSTIN (section 11.8)
    by_gstin = {}
    for r in rb:
        by_gstin.setdefault(r["GSTIN of Supplier"], []).append(r)

    # ---- Pass 1: same GSTIN, same invoice number ---------------------------
    for p in pr:
        if p["status"] != "Pending":
            continue
        p_inv = normalise_inv(p["Invoice No"], "basic")
        if not p_inv:
            continue

        best, mtype, min_diff = None, "", float("inf")
        for c in by_gstin.get(p["GSTIN of Supplier"], []):
            if c["status"] != "Pending":
                continue
            if normalise_inv(c["Invoice No"], "basic") != p_inv:
                continue
            a_ok, d_ok = amt_ok(p, c), date_ok(p, c)
            curr_diff = abs(p["Taxable Value"] - c["Taxable Value"])

            if a_ok and d_ok:
                if mtype != "Exact Match" or curr_diff < min_diff:
                    best, mtype, min_diff = c, "Exact Match", curr_diff
            elif a_ok:
                if best is None and curr_diff < min_diff:
                    best, mtype, min_diff = c, "Date Mismatch", curr_diff
            elif d_ok:
                if best is None:
                    best, mtype = c, "Amount Mismatch"

        if best is not None:
            p["status"], p["reason"], p["link"] = "Matched", mtype, best["_id"]
            best["status"] = "Matched"

    # ---- Pass 2: fuzzy invoice number, same GSTIN --------------------------
    for mode in PATTERN_ORDER:
        for p in pr:
            if p["status"] != "Pending":
                continue
            key = normalise_inv(p["Invoice No"], mode)
            if not key:
                continue
            for c in by_gstin.get(p["GSTIN of Supplier"], []):
                if c["status"] != "Pending":
                    continue
                if normalise_inv(c["Invoice No"], mode) == key and amt_ok(p, c):
                    p["status"], p["reason"], p["link"] = "Matched", f"Pattern Match: {mode}", c["_id"]
                    c["status"] = "Matched"
                    break

    # ---- Pass 3: same PAN, different GSTIN ---------------------------------
    by_inv = {}
    for r in rb:
        by_inv.setdefault(normalise_inv(r["Invoice No"], "basic"), []).append(r)

    for p in pr:
        if p["status"] != "Pending":
            continue
        if len(p["GSTIN of Supplier"]) < 15:
            continue
        pan = p["GSTIN of Supplier"][2:12]
        p_inv = normalise_inv(p["Invoice No"], "basic")
        if not p_inv:
            continue
        for c in by_inv.get(p_inv, []):
            if c["status"] != "Pending":
                continue
            g = c["GSTIN of Supplier"]
            if len(g) != 15:
                continue
            if g[2:12] == pan and g != p["GSTIN of Supplier"] and amt_ok(p, c):
                p["status"], p["reason"], p["link"] = "Matched", "GSTIN State/Code Mismatch", c["_id"]
                c["status"] = "Matched"
                break

    return pr, rb


# ----------------------------------------------------------------------------
# Section 9 - outputs
# ----------------------------------------------------------------------------
def itc(r):
    return r["IGST"] + r["CGST"] + r["SGST"] + r["Cess"]


def build_outputs(pr, rb):
    rb_by_id = {r["_id"]: r for r in rb}

    reco_rows = []
    for p in pr:
        m = rb_by_id.get(p["link"]) if p["link"] >= 0 else None
        reco_rows.append({
            "GSTIN of Supplier": p["GSTIN of Supplier"], "Invoice No": p["Invoice No"],
            "Invoice Date": p["Invoice Date"], "Taxable Value": p["Taxable Value"],
            "IGST": p["IGST"], "CGST": p["CGST"], "SGST": p["SGST"], "Cess": p["Cess"],
            "Match Status": p["status"], "Match Reason": p["reason"],
            "2B GSTIN": m["GSTIN of Supplier"] if m else "",
            "2B Invoice No": m["Invoice No"] if m else "",
            "2B Invoice Date": m["Invoice Date"] if m else None,
            "2B Taxable Value": m["Taxable Value"] if m else None,
            "2B IGST": m["IGST"] if m else None, "2B CGST": m["CGST"] if m else None,
            "2B SGST": m["SGST"] if m else None,
            "ITC Difference": (itc(p) - itc(m)) if m else itc(p),
        })

    pr_only = [{**{k: p[k] for k in STD_FIELDS}, "Total ITC": itc(p)}
               for p in pr if p["status"] == "Pending"]
    rb_only = [{**{k: r[k] for k in STD_FIELDS}, "Type": r["Type"], "Total ITC": itc(r)}
               for r in rb if r["status"] == "Pending"]

    summary = {}
    for p in pr:
        if p["status"] == "Pending":
            s = summary.setdefault(p["GSTIN of Supplier"], dict(pl=0, pt=0.0, pi=0.0, bl=0, bt=0.0, bi=0.0))
            s["pl"] += 1; s["pt"] += p["Taxable Value"]; s["pi"] += itc(p)
    for r in rb:
        if r["status"] == "Pending":
            s = summary.setdefault(r["GSTIN of Supplier"], dict(pl=0, pt=0.0, pi=0.0, bl=0, bt=0.0, bi=0.0))
            s["bl"] += 1; s["bt"] += r["Taxable Value"]; s["bi"] += itc(r)

    summary_rows = [{
        "GSTIN": g, "PR Unrec Lines": s["pl"], "PR Unrec Taxable": s["pt"], "PR Unrec ITC": s["pi"],
        "2B Unrec Lines": s["bl"], "2B Unrec Taxable": s["bt"], "2B Unrec ITC": s["bi"],
        "ITC Difference": s["pi"] - s["bi"],
    } for g, s in summary.items()]
    summary_rows.sort(key=lambda x: abs(x["ITC Difference"]), reverse=True)

    return reco_rows, pr_only, rb_only, summary_rows
