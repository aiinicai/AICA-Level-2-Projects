"""Self-contained HTML dashboard - section 10 of the spec.
Chart.js is inlined so the file opens with no network access.
"""

import json
from collections import Counter, defaultdict
from datetime import date

CHARTJS_PATH = "package/dist/chart.umd.js"


def _d(v):
    return v.isoformat() if isinstance(v, date) else v


def _jsonable(rows):
    return [{k: _d(v) for k, v in r.items()} for r in rows]


def itc(r):
    return r["IGST"] + r["CGST"] + r["SGST"] + r["Cess"]


def build_payload(pr, rb, reco_rows, pr_only, rb_only, summary_rows, meta):
    pr_matched = [p for p in pr if p["status"] == "Matched"]
    pr_pending = [p for p in pr if p["status"] == "Pending"]
    rb_matched = [r for r in rb if r["status"] == "Matched"]
    rb_pending = [r for r in rb if r["status"] == "Pending"]

    itc_pr = sum(itc(p) for p in pr)
    itc_rb = sum(itc(r) for r in rb)
    itc_risk = sum(itc(p) for p in pr_pending)
    itc_unclaimed = sum(itc(r) for r in rb_pending)

    reasons = Counter(p["reason"] for p in pr_matched)

    heads = ["Taxable Value", "IGST", "CGST", "SGST", "Cess"]
    head_pr = [sum(p[h] for p in pr) for h in heads]
    head_rb = [sum(r[h] for r in rb) for h in heads]

    top = summary_rows[:]
    top.sort(key=lambda x: x["PR Unrec ITC"] + x["2B Unrec ITC"], reverse=True)
    top = top[:10]

    months = defaultdict(lambda: [0.0, 0.0])
    for p in pr:
        if p["Invoice Date"]:
            months[p["Invoice Date"].strftime("%Y-%m")][0] += p["Taxable Value"]
    for r in rb:
        if r["Invoice Date"]:
            months[r["Invoice Date"].strftime("%Y-%m")][1] += r["Taxable Value"]
    mkeys = sorted(months)

    return {
        "meta": meta,
        "kpi": {
            "pr_lines": len(pr), "pr_matched": len(pr_matched), "pr_pending": len(pr_pending),
            "rb_docs": len(rb), "rb_matched": len(rb_matched), "rb_pending": len(rb_pending),
            "match_rate": (len(pr_matched) / len(pr) * 100) if pr else 0,
            "itc_pr": itc_pr, "itc_rb": itc_rb, "itc_risk": itc_risk,
            "itc_unclaimed": itc_unclaimed, "itc_gap": itc_pr - itc_rb,
        },
        "charts": {
            "status": [len(pr_matched), len(pr_pending)],
            "reasons": {"labels": list(reasons.keys()), "values": list(reasons.values())},
            "heads": {"labels": heads, "pr": head_pr, "rb": head_rb},
            "top": {
                "labels": [t["GSTIN"] for t in top],
                "pr": [t["PR Unrec ITC"] for t in top],
                "rb": [t["2B Unrec ITC"] for t in top],
            },
            "itc_split": [itc_pr - itc_risk, itc_risk, itc_unclaimed],
            "monthly": {"labels": mkeys,
                        "pr": [months[m][0] for m in mkeys],
                        "rb": [months[m][1] for m in mkeys]},
        },
        "tables": {
            "reco": _jsonable(reco_rows[:1000]),
            "pr_only": _jsonable(pr_only[:1000]),
            "rb_only": _jsonable(rb_only[:1000]),
            "summary": _jsonable(summary_rows[:1000]),
        },
        "counts": {"reco": len(reco_rows), "pr_only": len(pr_only),
                   "rb_only": len(rb_only), "summary": len(summary_rows)},
    }


TEMPLATE = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GSTR-2B Reconciliation Dashboard</title>
<style>
:root{--navy:#1F2E4A;--gold:#C9A84C;--cream:#F0EDE6;--ink:#22252b;--muted:#6b7280;
--good:#177245;--warn:#B7791F;--bad:#B42318;--line:#e2ddd1;}
*{box-sizing:border-box}
body{margin:0;background:var(--cream);color:var(--ink);
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Arial,sans-serif;font-size:14px}
h1,h2,h3{font-family:Georgia,"Playfair Display",serif;font-weight:600;margin:0}
header{background:var(--navy);color:#fff;padding:22px 32px;border-bottom:4px solid var(--gold)}
header h1{font-size:23px;letter-spacing:.2px}
header .sub{color:#cbd3e0;font-size:12.5px;margin-top:6px}
.wrap{max-width:1320px;margin:0 auto;padding:24px 32px 60px}
.grid{display:grid;gap:14px}
.kpis{grid-template-columns:repeat(4,1fr);margin-bottom:22px}
.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:16px 18px;
box-shadow:0 1px 2px rgba(31,46,74,.05)}
.kpi .label{font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted)}
.kpi .val{font-size:25px;font-weight:600;margin-top:7px;font-variant-numeric:tabular-nums}
.kpi .sub{font-size:11.5px;color:var(--muted);margin-top:4px}
.kpi.hl{border-left:4px solid var(--gold)}
.red{color:var(--bad)} .green{color:var(--good)} .amber{color:var(--warn)}
.charts{grid-template-columns:1fr 1fr;margin-bottom:22px}
.card h3{font-size:14.5px;margin-bottom:12px;color:var(--navy)}
.chartbox{position:relative;height:270px}
.tabs{display:flex;gap:6px;margin:10px 0 14px;flex-wrap:wrap}
.tab{padding:8px 15px;border:1px solid var(--line);background:#fff;border-radius:999px;
cursor:pointer;font-size:12.5px;color:var(--navy)}
.tab.on{background:var(--navy);color:#fff;border-color:var(--navy)}
.tools{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
input,select{padding:8px 11px;border:1px solid var(--line);border-radius:7px;font-size:13px;
background:#fff;color:var(--ink)}
input{min-width:280px}
.tblwrap{overflow:auto;max-height:560px;border:1px solid var(--line);border-radius:8px;background:#fff}
table{border-collapse:collapse;width:100%;font-size:12.5px}
th{position:sticky;top:0;background:var(--navy);color:#fff;text-align:left;padding:9px 10px;
font-weight:600;white-space:nowrap;font-size:11.5px}
td{padding:7px 10px;border-bottom:1px solid #f0ede6;white-space:nowrap}
tr:nth-child(even) td{background:#fbfaf7}
td.num{text-align:right;font-variant-numeric:tabular-nums}
.pill{padding:2px 9px;border-radius:999px;font-size:11px;font-weight:600}
.pill.m{background:#e6f4ec;color:var(--good)} .pill.p{background:#fdecea;color:var(--bad)}
.note{font-size:11.5px;color:var(--muted);margin-top:9px}
@media(max-width:960px){.kpis{grid-template-columns:repeat(2,1fr)}.charts{grid-template-columns:1fr}
.wrap{padding:18px}}
</style></head><body>
<header>
  <h1>GSTR-2B Reconciliation Dashboard</h1>
  <div class="sub" id="hdrsub"></div>
</header>
<div class="wrap">
  <div class="grid kpis" id="kpis"></div>
  <div class="grid charts">
    <div class="card"><h3>PR line status</h3><div class="chartbox"><canvas id="c1"></canvas></div></div>
    <div class="card"><h3>Match reason breakup</h3><div class="chartbox"><canvas id="c2"></canvas></div></div>
    <div class="card"><h3>Tax head comparison, PR against 2B</h3><div class="chartbox"><canvas id="c3"></canvas></div></div>
    <div class="card"><h3>Top 10 suppliers by unreconciled ITC</h3><div class="chartbox"><canvas id="c4"></canvas></div></div>
    <div class="card"><h3>ITC matched against at risk</h3><div class="chartbox"><canvas id="c5"></canvas></div></div>
    <div class="card"><h3>Monthly taxable value</h3><div class="chartbox"><canvas id="c6"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Detail</h3>
    <div class="tabs" id="tabs"></div>
    <div class="tools">
      <input id="q" placeholder="Search GSTIN or invoice number">
      <select id="fstatus"><option value="">All statuses</option><option>Matched</option><option>Pending</option></select>
      <select id="freason"><option value="">All reasons</option></select>
    </div>
    <div class="tblwrap"><table id="tbl"><thead></thead><tbody></tbody></table></div>
    <div class="note" id="tnote"></div>
  </div>
  <div class="note" style="margin-top:18px">
    Imports (IMPG, IMPGSEZ), ISD distributions and ECO documents are not covered by this run.
    Credit notes are compared as recorded in the books, with no sign adjustment.
    Full precision figures are in the accompanying Excel report.
  </div>
</div>
<script>__CHARTJS__</script>
<script>
const D = __PAYLOAD__;

function inr(n){if(n===null||n===undefined||n==="")return"";
 const neg=n<0;n=Math.abs(Number(n));
 let s=n.toFixed(2),[i,d]=s.split(".");
 let last3=i.slice(-3),rest=i.slice(0,-3);
 if(rest)last3=rest.replace(/\B(?=(\d{2})+(?!\d))/g,",")+","+last3;
 return (neg?"-":"")+last3+"."+d;}
function short(n){const a=Math.abs(n);
 if(a>=1e7)return (n/1e7).toFixed(2)+" Cr";
 if(a>=1e5)return (n/1e5).toFixed(2)+" L";
 return inr(n);}
function dmy(s){if(!s)return"";const p=String(s).split("-");
 return p.length===3?p[2]+"-"+p[1]+"-"+p[0]:s;}

document.getElementById('hdrsub').textContent =
 D.meta['Client'] + "  |  GSTIN " + D.meta['GSTIN'] + "  |  Period " + D.meta['Tax Period'] +
 "  |  Generated " + D.meta['Generated'];

const k=D.kpi;
const rateCls = k.match_rate>90?'green':(k.match_rate>=70?'amber':'red');
const tiles=[
 ['PR lines', k.pr_lines, k.pr_matched+' matched, '+k.pr_pending+' pending',''],
 ['2B documents', k.rb_docs, k.rb_matched+' matched, '+k.rb_pending+' pending',''],
 ['Match rate', k.match_rate.toFixed(1)+'%', 'matched PR lines over total', rateCls],
 ['Net ITC gap', inr(k.itc_gap), 'ITC in PR minus ITC in 2B', k.itc_gap<0?'red':''],
 ['ITC in PR', inr(k.itc_pr), 'IGST + CGST + SGST + Cess',''],
 ['ITC in 2B', inr(k.itc_rb), 'IGST + CGST + SGST + Cess',''],
 ['ITC at risk', inr(k.itc_risk), 'PR lines with no 2B document','red'],
 ['ITC not claimed', inr(k.itc_unclaimed), '2B documents not in books','amber'],
];
document.getElementById('kpis').innerHTML = tiles.map((t,i)=>
 `<div class="card kpi ${i>=2&&i<4||i>=6?'hl':''}"><div class="label">${t[0]}</div>
  <div class="val ${t[3]}">${t[1]}</div><div class="sub">${t[2]}</div></div>`).join('');

const NAVY='#1F2E4A',GOLD='#C9A84C',RED='#B42318',GREEN='#177245',SLATE='#7d8aa3';
Chart.defaults.font.family='-apple-system,Segoe UI,Arial,sans-serif';
Chart.defaults.font.size=11.5;
const noLeg={plugins:{legend:{display:false}}};
const money={ticks:{callback:v=>short(v)}};

new Chart(c1,{type:'doughnut',data:{labels:['Matched','Pending'],
 datasets:[{data:D.charts.status,backgroundColor:[GREEN,RED]}]},
 options:{maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}});

new Chart(c2,{type:'bar',data:{labels:D.charts.reasons.labels,
 datasets:[{data:D.charts.reasons.values,backgroundColor:NAVY}]},
 options:{indexAxis:'y',maintainAspectRatio:false,...noLeg}});

new Chart(c3,{type:'bar',data:{labels:D.charts.heads.labels,datasets:[
 {label:'PR',data:D.charts.heads.pr,backgroundColor:NAVY},
 {label:'2B',data:D.charts.heads.rb,backgroundColor:GOLD}]},
 options:{maintainAspectRatio:false,scales:{y:money},plugins:{legend:{position:'bottom'}}}});

new Chart(c4,{type:'bar',data:{labels:D.charts.top.labels,datasets:[
 {label:'PR only ITC',data:D.charts.top.pr,backgroundColor:RED},
 {label:'2B only ITC',data:D.charts.top.rb,backgroundColor:GOLD}]},
 options:{indexAxis:'y',maintainAspectRatio:false,scales:{x:money},plugins:{legend:{position:'bottom'}}}});

new Chart(c5,{type:'doughnut',data:{labels:['Matched ITC','PR only, at risk','2B only, unclaimed'],
 datasets:[{data:D.charts.itc_split,backgroundColor:[GREEN,RED,GOLD]}]},
 options:{maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}});

new Chart(c6,{type:'line',data:{labels:D.charts.monthly.labels,datasets:[
 {label:'PR',data:D.charts.monthly.pr,borderColor:NAVY,tension:.3},
 {label:'2B',data:D.charts.monthly.rb,borderColor:GOLD,tension:.3}]},
 options:{maintainAspectRatio:false,scales:{y:money},plugins:{legend:{position:'bottom'}}}});

const TABS=[['reco','Reconciliation'],['pr_only','PR Only'],['rb_only','2B Only'],['summary','Supplier Summary']];
let cur='reco';
const MONEY=['Taxable Value','IGST','CGST','SGST','Cess','2B Taxable Value','2B IGST','2B CGST',
 '2B SGST','ITC Difference','Total ITC','PR Unrec Taxable','PR Unrec ITC','2B Unrec Taxable','2B Unrec ITC'];
const DATES=['Invoice Date','2B Invoice Date'];

document.getElementById('tabs').innerHTML =
 TABS.map(t=>`<div class="tab ${t[0]===cur?'on':''}" data-k="${t[0]}">${t[1]} (${D.counts[t[0]]})</div>`).join('');
document.getElementById('freason').innerHTML='<option value="">All reasons</option>'+
 D.charts.reasons.labels.map(r=>`<option>${r}</option>`).join('');

function render(){
 const rows=D.tables[cur]||[];
 const q=document.getElementById('q').value.trim().toUpperCase();
 const st=document.getElementById('fstatus').value, rs=document.getElementById('freason').value;
 const cols=rows.length?Object.keys(rows[0]):[];
 const out=rows.filter(r=>{
  if(q && !((r['GSTIN of Supplier']||r['GSTIN']||'')+' '+(r['Invoice No']||'')).toUpperCase().includes(q))return false;
  if(st && r['Match Status']!==st)return false;
  if(rs && r['Match Reason']!==rs)return false;
  return true;});
 document.querySelector('#tbl thead').innerHTML='<tr>'+cols.map(c=>`<th>${c}</th>`).join('')+'</tr>';
 document.querySelector('#tbl tbody').innerHTML=out.map(r=>'<tr>'+cols.map(c=>{
  let v=r[c];
  if(MONEY.includes(c))return `<td class="num">${v===null||v===''?'':inr(v)}</td>`;
  if(DATES.includes(c))return `<td>${dmy(v)}</td>`;
  if(c==='Match Status')return `<td><span class="pill ${v==='Matched'?'m':'p'}">${v}</span></td>`;
  return `<td>${v===null?'':v}</td>`;}).join('')+'</tr>').join('');
 document.getElementById('tnote').textContent =
  `Showing ${out.length} of ${D.counts[cur]} rows. On-screen display is capped at 1000 rows, the Excel report carries every line.`;
}
document.getElementById('tabs').addEventListener('click',e=>{
 if(!e.target.dataset.k)return;cur=e.target.dataset.k;
 document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.k===cur));render();});
['q','fstatus','freason'].forEach(id=>document.getElementById(id).addEventListener('input',render));
render();
</script></body></html>"""


def build_dashboard(path, payload, chartjs_src):
    html = TEMPLATE.replace("__CHARTJS__", chartjs_src)
    html = html.replace("__PAYLOAD__", json.dumps(payload, default=str))
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path
