# GST Reconciliation Tool - handoff note

Folder: D:\Projects\Hackathon projects\2. GST reco on Python - Semi Final\New tool

## What the tool does
Reconciles a Purchase Register (CSV or Excel) against GSTR-2B (GSTN JSON or the
downloaded Excel), and writes two outputs into the same folder:
- Reco_<GSTIN>_<MMYYYY>_<timestamp>.xlsx  - 4 sheets: Run Summary, Reconciliation, PR Only, 2B Only, GSTIN Summary
- Dashboard_<GSTIN>_<MMYYYY>_<timestamp>.html - self-contained, Chart.js inlined

## Files
| File | Role |
|---|---|
| run_reco.py | Entry point. Reads inputs, runs pre-flight checks, calls engine and writers, asserts invariants |
| reco_engine.py | Pure logic: readers, date/number cleaning, invoice normalisation ladder, 3-pass matching, output builders |
| build_excel.py | openpyxl writer, navy/gold theme, formula-driven TOTAL rows |
| build_dashboard.py | Builds JSON payload and injects it plus chart.umd.js into an HTML template |
| chart.umd.js | Chart.js 4.4.1 UMD build, inlined into the dashboard. Must sit next to run_reco.py |
| Mock_PR.csv, Mock_GSTR2B.json | Test data, 200 PR lines |

## How to run
    cd "D:\Projects\Hackathon projects\2. GST reco on Python - Semi Final\New tool"
    python run_reco.py

The script asks for the folder where the Purchase Register and the GSTR-2B file are
saved. Paste the full path (quotes are stripped, so a right-click Copy as path works).
Press Enter to use the script folder itself. The data files stay wherever they are, and
both outputs are written into that same data folder.

Within that folder the script picks the files up automatically:
- GSTR-2B: any .json, or an .xlsx/.xls whose name contains 2b
- Purchase Register: any other .csv/.xlsx/.xls
- Files named Reco_*, Dashboard_* and Excel lock files ~$* are ignored, so re-running in
  the same folder does not pick up the previous run's outputs
- If more than one file qualifies, it lists them and asks which one to use

Three other ways to run, all skipping the prompts:
    python run_reco.py "D:\path\to\data folder"
    python run_reco.py <pr_path> <2b_path>
    python run_reco.py <pr_path> <2b_path> <out_dir>

Requires: pandas, openpyxl.

Expected on the mock data: Matched 165 of 200 (82.5%), Invariants OK.

## Matching logic, in short
Pass 1: same GSTIN + same invoice number, ranked Exact Match > Date Mismatch > Amount Mismatch.
Pass 2: same GSTIN + fuzzy invoice number, ladder no_special, no_alpha, no_fy, no_leading_zero. Amount must be within tolerance.
Pass 3: same PAN, different GSTIN, same invoice number, amount within tolerance.
Tolerances: Rs 2.00 absolute on (taxable + IGST + CGST + SGST), percentage off, 5 days on invoice date.
Each 2B document can be claimed only once, asserted at the end of run_reco.py.

## Fixes applied on 25 August 2026
1. run_reco.py had chat-container paths hardcoded (/mnt/user-data/uploads/...). Now
   defaults to Mock_PR.csv and Mock_GSTR2B.json sitting next to the script, using
   os.path.join, so it runs from any working directory on Windows.
2. Output paths built with os.path.join instead of f"{OUT_DIR}/...".
3. Filenames in the report metadata use os.path.basename instead of split("/"), which
   returned the full path on Windows.
4. chart.umd.js was missing from the folder and was opened by relative path. Downloaded
   Chart.js 4.4.1 into the folder, and the path is now resolved relative to the script
   with a clear error message if it is absent.
5. Added existence checks on the two input files with readable error messages.
6. The script now prompts for the data folder and auto-detects the PR and 2B files in it,
   instead of expecting them to be copied next to the Python files. Outputs go to that
   data folder. Command line arguments still work and skip the prompts.
7. Client name and GSTIN are no longer hardcoded. The recipient GSTIN and return period
   are read from the GSTR-2B JSON (data.gstin, data.rtnprd) where present; otherwise the
   script asks, validating the GSTIN against
   ^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$ with a force-anyway option. Output file
   names use a sanitised GSTIN_TAG. When stdin is not a tty the old demo values are used,
   so piped and scheduled runs never block on a prompt.

## Open items, not yet changed
- Pass 1 ranking is order dependent. If an Amount Mismatch candidate is seen before a
  Date Mismatch candidate, the weaker one wins because the code only tests `best is None`.
  Fix: score candidates (Exact 3, Date Mismatch 2, Amount Mismatch 1) and keep the highest.
- Cess is excluded from the amount tolerance test but included in the ITC Difference
  column. A cess-only difference will show as Exact Match with a non-zero ITC difference.
- clean_number() returns 0.0 for anything unparseable, silently. A broken amount column
  reads as zero and reconciles wrongly. Consider returning None and counting failures.
- Bracketed negatives, e.g. (1,000.00), are read as 0.0. Relevant for credit notes.
- read_2b_json only reads b2b, b2ba, cdnr, cdnra. IMPG, IMPGSEZ, ISD and ECO are not read.
  Credit note key fallbacks cover ntnum/nt_num and nt_dt but not every GSTN variant.
