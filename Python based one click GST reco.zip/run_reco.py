"""One-shot runner: PR + GSTR-2B in, Excel report + HTML dashboard out."""

import json
import os
import re
import sys
from collections import Counter
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from reco_engine import (read_pr, read_2b_json, read_2b_excel, reconcile,
                         build_outputs, itc)
from build_excel import build_excel
from build_dashboard import build_payload, build_dashboard

# -----------------------------------------------------------------------------
# Input selection: command line arguments if given, otherwise ask the user
# for the folder holding the Purchase Register and the GSTR-2B file.
# -----------------------------------------------------------------------------
PR_EXTS = (".csv", ".xlsx", ".xlsm", ".xls")
TWOB_EXTS = (".json", ".xlsx", ".xlsm", ".xls")
TWOB_NAME_HINTS = ("2b", "gstr2b", "gstr-2b", "gstr_2b")
OUTPUT_PREFIXES = ("reco_", "dashboard_", "~$")


def _ask(prompt):
    try:
        return input(prompt).strip().strip('"').strip("'")
    except EOFError:
        raise SystemExit(
            "No console input available. Pass the paths as arguments instead:\n"
            "  python run_reco.py <purchase_register> <gstr2b_file> [output_folder]")


def _ask_folder():
    print("\nGSTR-2B Reconciliation")
    print("Enter the folder where the Purchase Register and the GSTR-2B file are saved.")
    print(f"Press Enter to use the folder holding these scripts:\n  {BASE_DIR}\n")
    while True:
        answer = _ask("Data folder: ")
        folder = os.path.abspath(os.path.expanduser(answer)) if answer else BASE_DIR
        if os.path.isdir(folder):
            return folder
        print(f"Not a folder: {folder}\nTry again, or paste the full path.\n")


def _candidates(folder):
    pr, twob = [], []
    for name in sorted(os.listdir(folder)):
        full = os.path.join(folder, name)
        if not os.path.isfile(full):
            continue
        low = name.lower()
        if low.startswith(OUTPUT_PREFIXES):
            continue
        is_2b = low.endswith(TWOB_EXTS) and (
            low.endswith(".json") or any(h in low for h in TWOB_NAME_HINTS))
        if is_2b:
            twob.append(full)
        elif low.endswith(PR_EXTS):
            pr.append(full)
    return pr, twob


def _pick(files, label, folder):
    if not files:
        raise SystemExit(
            f"No {label} file found in:\n  {folder}\n"
            "Check the folder, or pass the paths as arguments:\n"
            "  python run_reco.py <purchase_register> <gstr2b_file> [output_folder]")
    if len(files) == 1:
        print(f"{label:22}: {os.path.basename(files[0])}")
        return files[0]
    print(f"\nSeveral possible {label} files:")
    for i, f in enumerate(files, start=1):
        print(f"  {i}. {os.path.basename(f)}")
    while True:
        choice = _ask(f"Pick the {label} file [1-{len(files)}]: ")
        if choice.isdigit() and 1 <= int(choice) <= len(files):
            picked = files[int(choice) - 1]
            print(f"{label:22}: {os.path.basename(picked)}")
            return picked
        print(f"Enter a number between 1 and {len(files)}.")


if len(sys.argv) > 2:
    PR_PATH = os.path.abspath(sys.argv[1])
    TWOB_PATH = os.path.abspath(sys.argv[2])
    OUT_DIR = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else os.path.dirname(PR_PATH)
else:
    DATA_DIR = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else _ask_folder()
    if not os.path.isdir(DATA_DIR):
        raise SystemExit(f"Not a folder: {DATA_DIR}")
    print(f"\nReading from: {DATA_DIR}")
    _pr_files, _2b_files = _candidates(DATA_DIR)
    TWOB_PATH = _pick(_2b_files, "GSTR-2B", DATA_DIR)
    PR_PATH = _pick(_pr_files, "Purchase Register", DATA_DIR)
    OUT_DIR = DATA_DIR

for _label, _path in (("Purchase Register", PR_PATH), ("GSTR-2B", TWOB_PATH)):
    if not os.path.isfile(_path):
        raise SystemExit(f"{_label} file not found: {_path}")
os.makedirs(OUT_DIR, exist_ok=True)
print(f"Writing to  : {OUT_DIR}\n")

# -----------------------------------------------------------------------------
# Report header identity: client name and GSTIN.
# Read from the GSTR-2B file where possible, otherwise asked for.
# -----------------------------------------------------------------------------
GSTIN_RE = re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
INTERACTIVE = sys.stdin.isatty()


def _identity_from_2b(path):
    """A GSTR-2B JSON carries the recipient's own GSTIN and the return period."""
    if not path.lower().endswith(".json"):
        return "", ""
    try:
        with open(path, encoding="utf-8-sig") as fh:
            blob = json.load(fh)
    except Exception:
        return "", ""
    root = blob.get("data", blob) if isinstance(blob, dict) else None
    if not isinstance(root, dict):
        return "", ""
    gstin = str(root.get("gstin") or "").strip().upper().replace(" ", "")
    period = str(root.get("rtnprd") or "").strip()
    return (gstin if GSTIN_RE.match(gstin) else ""), period


def _ask_client(default):
    return _ask(f"Client name [{default}]: ") or default


def _ask_gstin(default):
    while True:
        answer = (_ask(f"Client GSTIN [{default}]: ") or default).upper().replace(" ", "")
        if GSTIN_RE.match(answer):
            return answer
        print(f"'{answer}' does not look like a 15 character GSTIN, e.g. 24AAACD1234F1ZP.")
        if _ask("Use it anyway? [y/N]: ").lower().startswith("y"):
            return answer


CLIENT_DEFAULT = "Demo Client Pvt Ltd"
GSTIN_DEFAULT = "24AAACD1234F1ZP"

GSTIN_FROM_2B, RETURN_PERIOD = _identity_from_2b(TWOB_PATH)

if INTERACTIVE:
    print("Report header. These appear on the report and in the output file names.")
    print("Press Enter to accept the value in brackets.")
    CLIENT = _ask_client(CLIENT_DEFAULT)
    if GSTIN_FROM_2B:
        GSTIN = GSTIN_FROM_2B
        print(f"Client GSTIN          : {GSTIN}  (read from the GSTR-2B file)")
    else:
        GSTIN = _ask_gstin(GSTIN_DEFAULT)
    print()
else:
    CLIENT = CLIENT_DEFAULT
    GSTIN = GSTIN_FROM_2B or GSTIN_DEFAULT

GSTIN_TAG = re.sub(r"[^A-Za-z0-9]", "", GSTIN) or "NOGSTIN"

pr_records, mapping, headers = read_pr(PR_PATH)
if TWOB_PATH.lower().endswith(".json"):
    rb_records = read_2b_json(TWOB_PATH)
else:
    rb_records = read_2b_excel(TWOB_PATH)

# --- clause 12.5 pre-flight checks -------------------------------------------
warnings = []
if not pr_records or not rb_records:
    raise SystemExit("PR or 2B is empty after parsing.")

gstin_ok = sum(1 for r in pr_records if re.match(r"^\d{2}[A-Z0-9]{11,13}$", r["GSTIN of Supplier"]))
if gstin_ok / len(pr_records) < 0.80:
    warnings.append("Under 80% of PR rows carry a GSTIN-shaped value. Column mapping may be stale.")
date_ok = sum(1 for r in pr_records if r["Invoice Date"])
if date_ok / len(pr_records) < 0.90:
    warnings.append("Under 90% of PR invoice dates parsed. Date format may have changed.")

months = Counter(r["Invoice Date"].strftime("%m%Y") for r in pr_records if r["Invoice Date"])
modal_month = months.most_common(1)[0][0] if months else "unknown"
b_months = Counter(r["Invoice Date"].strftime("%m%Y") for r in rb_records if r["Invoice Date"])
modal_2b = b_months.most_common(1)[0][0] if b_months else "unknown"
if modal_month != modal_2b:
    warnings.append(f"PR modal month {modal_month} differs from 2B modal month {modal_2b}. "
                    f"Mock dataset spans many months, so this is expected here.")

# --- run ---------------------------------------------------------------------
pr, rb = reconcile(pr_records, rb_records)
reco_rows, pr_only, rb_only, summary_rows = build_outputs(pr, rb)

matched = sum(1 for p in pr if p["status"] == "Matched")
rate = matched / len(pr) * 100
stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

meta = {
    "Client": CLIENT,
    "GSTIN": GSTIN,
    "Tax Period": (f"{RETURN_PERIOD[:2]}/{RETURN_PERIOD[2:]} (return period stated in the GSTR-2B file)"
                   if len(RETURN_PERIOD) == 6 and RETURN_PERIOD.isdigit()
                   else f"{modal_month[:2]}/{modal_month[2:]} (modal month of PR invoice dates)"),
    "Generated": datetime.now().strftime("%d %B %Y %H:%M IST"),
    "Purchase Register file": os.path.basename(PR_PATH),
    "GSTR-2B file": os.path.basename(TWOB_PATH),
    "PR lines": len(pr),
    "2B documents": len(rb),
    "Matched PR lines": matched,
    "Match rate": f"{rate:.1f}%",
    "ITC at risk (PR only)": round(sum(itc(p) for p in pr if p["status"] == "Pending"), 2),
    "ITC not claimed (2B only)": round(sum(itc(r) for r in rb if r["status"] == "Pending"), 2),
    "Tolerance - amount": "Rs 2.00 absolute, percentage off",
    "Tolerance - days": "5 days",
    "PR column mapping used": "; ".join(f"{k} = {v}" for k, v in mapping.items()),
    "Warnings": " | ".join(warnings) if warnings else "None",
}

xl = build_excel(os.path.join(OUT_DIR, f"Reco_{GSTIN_TAG}_{modal_month}_{stamp}.xlsx"),
                 reco_rows, pr_only, rb_only, summary_rows, meta)

chart_path = os.path.join(BASE_DIR, "chart.umd.js")
if not os.path.isfile(chart_path):
    raise SystemExit(f"chart.umd.js not found next to run_reco.py: {chart_path}")
with open(chart_path, encoding="utf-8") as f:
    chartjs = f.read()
payload = build_payload(pr, rb, reco_rows, pr_only, rb_only, summary_rows, meta)
db = build_dashboard(os.path.join(OUT_DIR, f"Dashboard_{GSTIN_TAG}_{modal_month}_{stamp}.html"), payload, chartjs)

print("Matched", matched, "of", len(pr), f"({rate:.1f}%)")
print(Counter(p["reason"] for p in pr if p["status"] == "Matched"))
print("Warnings:", warnings)
print(xl)
print(db)

# --- invariants (clause 13) ---------------------------------------------------
links = [p["link"] for p in pr if p["link"] >= 0]
assert len(links) == len(set(links)), "a 2B document was claimed twice"
assert all(rb[p["link"]]["status"] == "Matched" for p in pr if p["link"] >= 0)
print("Invariants OK")
