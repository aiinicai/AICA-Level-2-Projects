@echo off
setlocal
cd /d "%~dp0"
python build_networth_exe_with_ocr.py
if errorlevel 1 (
  echo.
  echo Build failed. Read the message above, then retry.
) else (
  echo.
  echo Your EXE is in dist_with_ocr\NetWorthCertificate.exe
)
pause
