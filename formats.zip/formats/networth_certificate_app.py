"""
Net Worth Certificate Generator  (desktop app for Chartered Accountants)
-----------------------------------------------------------------------
* Enter applicant details
* Add assets by type (Immovable property, Jewellery, Bank accounts, FDs,
  Vehicles, Shares / MF, PPF / NSC, LIC, Others) and liabilities
* Generates the "Independent Practitioner's Certificate on Net Worth"
  with the detailed computation (Annexure A / B / C)
* Save as Excel (.xlsx), PDF or MS Word (.docx)
* Save / open client data (.json) so a certificate can be revised later

Install dependencies (one line):
    pip install openpyxl python-docx reportlab pillow

Run:
    python networth_certificate_app.py
"""

import os
import sys
import json
import math
import datetime
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_TITLE = "Net Worth Certificate Generator"
HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(os.path.expanduser("~"), ".networth_certificate_settings.json")

DEFAULT_SETTINGS = {
    "firm_name": "S B H S & ASSOCIATES",
    "firm_type": "CHARTERED ACCOUNTANTS",
    "address1": "B-I/728,First Floor, Backside Aggarwal Dharamshala",
    "address2": "Barnala, Punjab -148101",
    "email": "cahimank@mail.ca.in",
    "contact": "+91-6280775968",
    "frn": "031324N",
    "partner": "HIMANK SINGLA",
    "designation": "PARTNER",
    "mno": "563959",
    "place": "BARNALA",
    "logo_path": os.path.join(HERE, "ca_logo.png"),
    "letterhead_first_page": True,
}

CURRENCIES = [
    "None",
    "AUD - Australian Dollars",
    "CAD - Canadian Dollars",
    "USD - US Dollars",
    "GBP - British Pounds",
    "NZD - New Zealand Dollars",
    "EUR - Euros",
    "SGD - Singapore Dollars",
    "AED - UAE Dirhams",
]

RELATIONS = ["Self", "Father", "Mother", "Parents", "Spouse", "Husband", "Wife",
             "Brother", "Sister", "Son", "Daughter", "Grandfather", "Grandmother",
             "Father-in-law", "Mother-in-law"]

SECTION_LABELS = {"A": "A - Non-Current", "B": "B - Current", "C": "C - Liability"}


# ======================================================================
# Number helpers
# ======================================================================
_ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
         "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
         "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two(n):
    if n < 20:
        return _ONES[n]
    return _TENS[n // 10] + (" " + _ONES[n % 10] if n % 10 else "")


def _three(n):
    h, r = divmod(n, 100)
    parts = []
    if h:
        parts.append(_ONES[h] + " Hundred")
    if r:
        parts.append(_two(r))
    return " ".join(parts)


def indian_words(n):
    """56262575 -> Five Crore Sixty Two Lakh Sixty Two Thousand Five Hundred Seventy Five"""
    n = int(n)
    if n == 0:
        return "Zero"
    crore, n = divmod(n, 10_000_000)
    lakh, n = divmod(n, 100_000)
    thousand, n = divmod(n, 1000)
    parts = []
    if crore:
        parts.append(indian_words(crore) + " Crore")
    if lakh:
        parts.append(_two(lakh) + " Lakh")
    if thousand:
        parts.append(_two(thousand) + " Thousand")
    if n:
        parts.append(_three(n))
    return " ".join(parts)


def intl_words(n):
    """837489 -> Eight Hundred Thirty Seven Thousand, Four Hundred Eighty Nine"""
    n = int(n)
    if n == 0:
        return "Zero"
    parts = []
    for value, name in ((10 ** 12, "Trillion"), (10 ** 9, "Billion"),
                        (10 ** 6, "Million"), (1000, "Thousand")):
        q, n = divmod(n, value)
        if q:
            parts.append((intl_words(q) if q >= 1000 else _three(q)) + " " + name)
    if n:
        parts.append(_three(n))
    return ", ".join(parts)


def fmt_inr(x):
    """Indian grouping: 56262575.87 -> 5,62,62,575.87"""
    neg = x < 0
    whole, dec = f"{abs(x):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups) + "," + tail
    return ("-" if neg else "") + whole + "." + dec


def fmt_acct(x):
    """Accounting style used in the tables: 39,550,000.00 / - for zero / (1,000.00)"""
    if abs(x) < 0.005:
        return "-"
    return f"{x:,.2f}" if x > 0 else f"({abs(x):,.2f})"


# Bold markers: text between these two characters prints in bold in Excel, Word and PDF
BOLD_ON, BOLD_OFF = "\x01", "\x02"


def mark(text, bold=True):
    return f"{BOLD_ON}{text}{BOLD_OFF}" if bold and text else text


def strip_marks(text):
    return (text or "").replace(BOLD_ON, "").replace(BOLD_OFF, "")


def segments(text):
    """'a \x01b\x02 c' -> [('a ', False), ('b', True), (' c', False)]"""
    out, buf, bold = [], "", False
    for ch in text or "":
        if ch in (BOLD_ON, BOLD_OFF):
            if buf:
                out.append((buf, bold))
            buf, bold = "", ch == BOLD_ON
        else:
            buf += ch
    if buf:
        out.append((buf, bold))
    return out


def parse_amount(text):
    text = (text or "").replace(",", "").replace("Rs.", "").replace("₹", "").strip()
    return float(text) if text else 0.0


# ======================================================================
# Asset / liability categories
# ======================================================================
def _v(f, k):
    value = (f.get(k) or "").strip() or "________"
    return mark(value, f.get("_bold", {}).get(k, False))


def _held(f, prefix="held in the name of"):
    holder = _v(f, "holder")
    rel = f.get("relation") or "Self"
    if rel == "Self":
        return f"{prefix} {holder} (Applicant)"
    return f"{prefix} {holder} ({_v(f, 'relation')} of Applicant)"


BANK_NOTE = "(As per signed Bank Statement by the bank's authorized signatory)"

HOLDER_FIELDS = [("holder", "Held in the name of", "text", None),
                 ("relation", "Relation with applicant", "relation", None)]

CATS = {
    # ---------------- ASSETS ----------------
    "Immovable Property": dict(
        kind="asset", section="A",
        fields=[("nature", "Nature of property", "combo",
                 ["Agriculture Land", "Residential House", "Residential Flat", "Residential Plot",
                  "Commercial Property", "Shop", "Industrial Property"])]
        + HOLDER_FIELDS +
        [("location", "Located at (full address)", "text", None),
         ("valuer", "Valuer (issued by)", "text", None),
         ("val_date", "Valuation report date", "text", None)],
        desc=lambda f: f"Immovable Property in the nature of {_v(f, 'nature')} {_held(f)}, "
                       f"located at {_v(f, 'location')}.",
        note=lambda f: "(Valuation is based on Valuation Report of the abovesaid immovable property "
                       f"produced to me by the applicant, as issued by {_v(f, 'valuer')}, "
                       f"dated {_v(f, 'val_date')})"),

    "Jewellery": dict(
        kind="asset", section="A",
        fields=[("details", "Jewellery details", "combo",
                 ["Gold Ornaments weighing ____ grams", "Gold & Diamond Ornaments weighing ____ grams",
                  "Silver Ornaments weighing ____ grams"])]
        + HOLDER_FIELDS +
        [("valuer", "Valuer (issued by)", "text", None),
         ("val_date", "Valuation report date", "text", None)],
        desc=lambda f: f"Jewellery in the nature of {_v(f, 'details')}, {_held(f)}.",
        note=lambda f: "(Valuation is based on Valuation Report of the abovesaid jewellery produced "
                       f"to me by the applicant, as issued by {_v(f, 'valuer')}, dated {_v(f, 'val_date')})"),

    "Bank Account (Savings / Current)": dict(
        kind="asset", section="B",
        fields=[("acc_type", "Account type", "combo", ["Saving", "Current"]),
                ("acno", "Account number", "text", None),
                ("as_on", "Balance as on (date)", "text", None),
                ("bank", "Bank name", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"{_v(f, 'acc_type')} Account Balance (A/c No. {_v(f, 'acno')}) as on "
                       f"{_v(f, 'as_on')} with {_v(f, 'bank')}, {_held(f)}.",
        note=lambda f: BANK_NOTE),

    "Fixed Deposit": dict(
        kind="asset", section="B",
        fields=[("acno", "FD account number", "text", None),
                ("as_on", "Balance as on (date)", "text", None),
                ("bank", "Bank name", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"Fixed Deposit Account Balance (A/c No. {_v(f, 'acno')}) as on "
                       f"{_v(f, 'as_on')} with {_v(f, 'bank')}, {_held(f)}.",
        note=lambda f: BANK_NOTE),

    "Vehicle": dict(
        kind="asset", section="B",
        fields=[("vtype", "Vehicle type", "combo", ["Car", "Motorcycle", "Scooter", "Tractor", "Truck"])]
        + HOLDER_FIELDS +
        [("vno", "Vehicle number", "text", None),
         ("reg_date", "Date of registration", "text", None),
         ("basis", "Valuation basis", "combo",
          ["Approximate Market Value (no valuation report)", "Valuation Report"]),
         ("val_date", "Value as on / report date", "text", None),
         ("valuer", "Valuer (only if valuation report)", "text", None)],
        desc=lambda f: f"Vehicle ({_v(f, 'vtype')}), {_held(f)}, Vehicle Number - {_v(f, 'vno')}, "
                       f"date of registration being {_v(f, 'reg_date')}.",
        note=lambda f: (f"(Valuation is based on Valuation Report of the abovesaid vehicle produced to me "
                        f"by the applicant, as issued by {_v(f, 'valuer')}, dated {_v(f, 'val_date')})")
        if (f.get("basis") or "").startswith("Valuation")
        else (f"(Valuation is based on Approximate Market Value as on {_v(f, 'val_date')} as provided "
              "to me by the applicant. No valuation Report has been provided to me, hence I don’t "
              "certify the correctness of the same)")),

    "Shares / Mutual Funds": dict(
        kind="asset", section="A",
        fields=[("itype", "Investment type", "combo",
                 ["Shares", "Mutual Funds", "Shares & Mutual Funds", "Bonds / Debentures"]),
                ("account", "Demat A/c / Folio No.", "text", None),
                ("dp", "Depository / AMC / Broker", "text", None),
                ("as_on", "Value as on (date)", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"Investment in {_v(f, 'itype')} held in Demat A/c / Folio No. {_v(f, 'account')} "
                       f"with {_v(f, 'dp')} as on {_v(f, 'as_on')}, {_held(f)}.",
        note=lambda f: f"(Valuation is based on market value as per Statement of Holdings issued by "
                       f"{_v(f, 'dp')} as on {_v(f, 'as_on')})"),

    "PPF / NSC / Post Office": dict(
        kind="asset", section="A",
        fields=[("scheme", "Scheme", "combo",
                 ["Public Provident Fund (PPF)", "National Savings Certificate (NSC)",
                  "Kisan Vikas Patra (KVP)", "Post Office Deposit", "Sukanya Samriddhi Account"]),
                ("acno", "Account / Certificate No.", "text", None),
                ("as_on", "Balance as on (date)", "text", None),
                ("inst", "Bank / Post Office", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"{_v(f, 'scheme')} Balance (A/c No. {_v(f, 'acno')}) as on {_v(f, 'as_on')} "
                       f"with {_v(f, 'inst')}, {_held(f)}.",
        note=lambda f: f"(As per Passbook / Statement issued by {_v(f, 'inst')})"),

    "Life Insurance (Surrender Value)": dict(
        kind="asset", section="A",
        fields=[("pno", "Policy number", "text", None),
                ("insurer", "Insurer", "text", None),
                ("as_on", "Surrender value as on", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"Surrender Value of Life Insurance Policy (Policy No. {_v(f, 'pno')}) with "
                       f"{_v(f, 'insurer')} as on {_v(f, 'as_on')}, {_held(f)}.",
        note=lambda f: f"(As per Surrender Value Certificate issued by {_v(f, 'insurer')})"),

    "Other Asset": dict(kind="asset", section="B", fields=[], desc=None, note=None),

    # ---------------- LIABILITIES ----------------
    "Bank Loan": dict(
        kind="liability", section="C",
        fields=[("ltype", "Loan type", "combo",
                 ["Home", "Car", "Education", "Personal", "Gold", "Agriculture", "Business",
                  "Kisan Credit Card (KCC)", "Loan Against Property"]),
                ("acno", "Loan account number", "text", None),
                ("as_on", "Outstanding as on (date)", "text", None),
                ("bank", "Bank / NBFC", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"{_v(f, 'ltype')} Loan (A/c No. {_v(f, 'acno')}) outstanding as on "
                       f"{_v(f, 'as_on')} with {_v(f, 'bank')}, {_held(f, 'in the name of')}.",
        note=lambda f: "(As per Loan Account Statement issued by the bank)"),

    "Credit Card": dict(
        kind="liability", section="C",
        fields=[("card", "Card number (last 4 digits)", "text", None),
                ("as_on", "Outstanding as on (date)", "text", None),
                ("bank", "Card issuer", "text", None)] + HOLDER_FIELDS,
        desc=lambda f: f"Credit Card Outstanding (Card No. XXXX-XXXX-XXXX-{_v(f, 'card')}) as on "
                       f"{_v(f, 'as_on')} with {_v(f, 'bank')}, {_held(f, 'in the name of')}.",
        note=lambda f: "(As per Credit Card Statement issued by the bank)"),

    "Other Liability": dict(kind="liability", section="C", fields=[], desc=None, note=None),
}

ASSET_CATS = [k for k, v in CATS.items() if v["kind"] == "asset"]
LIAB_CATS = [k for k, v in CATS.items() if v["kind"] == "liability"]


# ======================================================================
# Certificate content (shared by Excel / Word / PDF)
# ======================================================================
PROCEDURES = [
    ("a)", "Obtained documents viz. original deeds / valuation report to verify the value of property "
           "(residential flat/ commercial property, i.e. immoveable property) forming part of the net assets."),
    ("b)", "Obtained invoices and bank statements to verify the value of movable property."),
    ("c)", "Obtained bank statements to verify the bank balances in savings/ current accounts, fixed deposits."),
    ("d)", "Obtained demat statement of the depository, to verify the investments held in the nature of "
           "the shares / mutual funds."),
    ("e)", "Obtained valuation report of the Jewellery mentioned in the statement, to verify the value of the same."),
    ("f)", "Obtained the loan statements to verify the loan from Bank including mortgage, forming part of liabilities."),
    ("g)", "Obtained the Credit Card balance statements to verify the credit card related liability."),
    ("h)", "We have obtained confirmations from the parties mentioned in the loan given to (assets)/ "
           "loan taken from (liabilities), in the statement."),
    ("i)", "Performed necessary inquiries with the Individual and obtained necessary clarification, "
           "from the individual."),
]


def build_content(d):
    """d = {'app': {...applicant...}, 'items': [...], 'settings': {...}}"""
    a, s = d["app"], d["settings"]
    female = a["title"] in ("Ms.", "Mrs.", "Miss")
    his, him = ("her", "her") if female else ("his", "him")
    bolds = a.get("_bold", {})

    def A(k):
        return mark(a.get(k, ""), bolds.get(k, False))

    T = f"{A('title')} {A('name')}".strip()
    stmt = A("statement_date")

    parent = f", {A('relation')} {A('parent')}" if a.get("parent") else ""
    passport = f", bearing Passport No. {A('passport')}" if a.get("passport") else ""
    address = f", residing at {A('address')}" if a.get("address") else ""

    secs = {"A": [], "B": [], "C": []}
    for it in d["items"]:
        secs[it["section"]].append(it)
    tot = {k: round(sum(i["amount"] for i in v), 2) for k, v in secs.items()}
    nw = round(tot["A"] + tot["B"] - tot["C"], 2)

    neg = " (Negative)" if nw < 0 else ""
    words = [f"Net Worth of the applicant is Rs. {fmt_inr(nw)}/- (Indian Rupees "
             f"{indian_words(abs(nw))}{neg} Approximately)"]
    cur = a.get("currency", "None")
    rate = parse_amount(a.get("rate", ""))
    fx_value = None
    if cur != "None" and rate > 0:
        code, cname = cur.split(" - ", 1)
        fx_value = nw / rate
        words.append(f"Net Worth of the applicant is {code} {abs(fx_value):,.2f}/- "
                     f"({intl_words(abs(fx_value))} {cname}{neg} Approximately)")

    return dict(
        settings=s, app=a, his=his, totals=tot, nw=nw, fx_value=fx_value,
        title="INDEPENDENT PRACTITIONER’S CERTIFICATE ON NET WORTH",
        intro=[
            f"This Report is issued in accordance with the terms of our engagement letter/ agreement dated "
            f"{A('engagement_date')}",
            f'We have been requested by {T} ("Applicant"){parent}{passport}{address}, to issue Certificate '
            f"on {his} Net Worth.",
            f"The accompanying Statement of Net worth as at {stmt} (the “Statement”) of {T} (\"Applicant\"), "
            f"as prepared by {him}, and contains the details of {his} assets and liabilities, for submission "
            f"to {A('authority')} in connection with {A('purpose')}.",
            "The Statement has been initialled by us for identification purposes only.",
        ],
        summary=[("1", "Non Current Investments (Annexure - A)", tot["A"], "A"),
                 ("2", "Current Investments (Annexure - B)", tot["B"], "B"),
                 ("3", "Less : Total Liabilities (Annexure - C)", tot["C"], "C")],
        words=words,
        date_line=f"DATE : {A('cert_date')}",
        udin_line=f"UDIN: {A('udin')}",
        resp_head="INDIVIDUAL'S RESPONSIBILITY FOR THE STATEMENT",
        resp=[
            f"The preparation of the accompanying Statement is the responsibility of the applicant {T}, "
            "including the maintenance of all relevant supporting records and documents. This responsibility "
            "also includes the design, implementation and maintenance of internal control relevant to the "
            "preparation and presentation of the Statement and applying an appropriate basis of preparation; "
            "and making estimates that are reasonable in the circumstances.",
            f"The applicant is also responsible for submitting all the details including the original deeds, "
            f"documents, records of {his} assets and liabilities as at {stmt}.",
        ],
        prac_head="PRACTITIONER'S RESPONSIBILITY FOR THE STATEMENT",
        prac=[
            "Pursuant to the requirements of visa application, it is our responsibility to provide limited "
            "assurance as to whether the Statement presented to us is in agreement with the details referred "
            f"in original deeds, documents, records of {his} assets and liabilities etc.",
            "The procedures performed in a limited assurance engagement vary in nature and timing from, and "
            "are less in extent than for, a reasonable assurance engagement; and consequently, the level of "
            "assurance obtained in a limited assurance engagement is substantially lower than the assurance "
            "that would have been obtained had a reasonable assurance engagement been performed.",
            "Accordingly, we have performed the following procedures in relation to the Statement presented "
            "to us as were considered appropriate in the circumstances, including verification of relevant "
            "supporting documents and records as applicable and enumerated in the Detailed Net Worth "
            "Statement of Applicant :",
        ],
        procedures=PROCEDURES,
        relied="We have relied upon the information and supporting details furnished in substantiation of "
               "the statement.",
        standards=[
            "We have conducted our examination of the Statement in accordance with the Guidance Note on "
            "Reports or Certificates for Special Purposes (Revised 2016) issued by the Institute of Chartered "
            "Accountants of India (“ICAI”). The Guidance Note requires that we comply with the ethical "
            "requirements of the Code of Ethics issued by the ICAI.",
            "We have complied with the relevant applicable requirements of the Standard on Quality Control "
            "(SQC) 1, Quality Control for Firms that Perform Audits and Reviews of Historical Financial "
            "Information, and Other Assurance and Related Services Engagements.",
            "The Income Details referred in the Certificate (if any) have been compiled from the Income Tax "
            "Returns filed by the applicant. We categorically state that we haven't verified the financials "
            "of the client, nor have we audited or reviewed them. Our scope is just to report the figures as "
            "filed on Income Tax Portal.",
        ],
        concl_head="CONCLUSION",
        concl="Based on the procedures carried out as mentioned above, and according to the information and "
              "explanations given to us, nothing has come to our attention that causes us to believe that the "
              "particulars mentioned in the Statement, which is prepared by the applicant and initialled by us "
              "for identification purpose, is not in accordance with the documentary evidence made available "
              f"for verification as set out in original deeds, documents, records of {his} assets and "
              "liabilities etc.",
        restr_head="RESTRICTION ON USE",
        restr="This Certificate has been issued at the request of the applicant solely for the purpose of "
              "submission to immigration or embassy for visa application purposes. This Certificate should not "
              "be used for any other purpose or by any person other than the addressee of this Certificate. "
              "Accordingly, we do not accept or assume any liability or any duty of care for any other purpose "
              "or to any other person to whom this Certificate is shown or into whose hands it may come "
              "without our prior consent in writing.",
        enclosure="Enclosure: Detailed Statement of Net Worth of the applicant",
        detail_title="DETAILED COMPUTATION OF NET-WORTH OF THE APPLICANT",
        sections=[
            ("A", "", "(A) NON-CURRENT INVESTMENTS", secs["A"], "TOTAL (A) :", tot["A"]),
            ("B", "", "(B) CURRENT INVESTMENTS", secs["B"], "TOTAL (B) :", tot["B"]),
            ("C", "Less: ", "(C) LIABILITIES", secs["C"], "TOTAL (C) :", tot["C"]),
        ],
        signature=[f"FOR {s['firm_name']}", s["firm_type"], f"FRN NO. {s['frn']}"],
        signatory=[s["partner"], f"({s['designation']})", f"M. NO. {s['mno']}"],
        place=f"PLACE: {s['place']}",
    )


def logo_file(s):
    p = s.get("logo_path") or ""
    return p if p and os.path.isfile(p) else None


# ======================================================================
# Excel export (mirrors the original worksheet layout)
# ======================================================================
def export_excel(c, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side
    from openpyxl.worksheet.pagebreak import Break
    from openpyxl.worksheet.properties import PageSetupProperties
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    from openpyxl.cell.text import InlineFont

    ACCT = '_(* #,##0.00_);_(* \\(#,##0.00\\);_(* "-"??_);_(@_)'
    WIDTHS = dict(A=13.43, B=5.86, C=8.71, D=7.86, E=9.71, F=7.86, G=21.14, H=23.43, I=27.29, J=30.86)
    COLS = "ABCDEFGHIJ"
    s = c["settings"]

    wb = Workbook()
    ws = wb.active
    ws.title = "Net Worth Certificate"
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 60
    for k, w in WIDTHS.items():
        ws.column_dimensions[k].width = w

    thin, medium, double = Side(style="thin"), Side(style="medium"), Side(style="double")

    def F(size=16, bold=False, ul=False):
        return Font(name="Arial", size=size, bold=bold, underline="single" if ul else None)

    def put(row, col, text, size=16, bold=False, ul=False):
        """Write text; parts marked bold become bold via rich text."""
        cell = ws.cell(row, col)
        segs = segments(text)
        if not bold and any(b_ for _t, b_ in segs):
            cell.value = CellRichText([TextBlock(InlineFont(rFont="Arial", sz=size, b=b_,
                                                            u="single" if ul else None), t_)
                                       for t_, b_ in segs])
        else:
            cell.value = strip_marks(text)
        cell.font = F(size, bold, ul)
        return cell

    class St:
        r = 1
        used = 0.0

    PAGE_LIMIT = 1240.0  # usable row-points per printed page at fit-to-width (as in the original sheet)

    def height(h):
        ws.row_dimensions[St.r].height = h
        St.used += h

    def nxt(h=20.25):
        height(h)
        St.r += 1

    def need(h):
        if St.used + h > PAGE_LIMIT:
            page_break()

    def page_break():
        ws.row_breaks.append(Break(id=St.r - 1))
        St.used = 0
        letterhead()

    def letterhead():
        start = St.r
        rows = [(s["firm_name"], 28, True, True, 35.25), (s["firm_type"], 28, True, True, 34.5),
                (None, 0, False, False, 12), (s["address1"], 20, False, False, 25.5),
                (s["address2"], 20, False, False, 25.5), ("Email: " + s["email"], 20, True, False, 26.25),
                ("Contact: " + s["contact"], 20, True, False, 26.25)]
        for text, size, b, u, h in rows:
            if text:
                cell = ws.cell(St.r, 10, text)
                cell.font = F(size, b, u)
                cell.alignment = Alignment(horizontal="right", vertical="center")
            nxt(h)
        for col in range(1, 11):
            ws.cell(St.r - 1, col).border = Border(bottom=medium)
        lg = logo_file(s)
        if lg:
            try:
                from openpyxl.drawing.image import Image as XLImage
                img = XLImage(lg)
                ratio = 140 / img.height
                img.height, img.width = 140, int(img.width * ratio)
                img.anchor = f"A{start + 1}"
                ws.add_image(img)
            except Exception:
                pass
        nxt(20)

    def cpl(first, last, size, bold):
        width = sum(WIDTHS[COLS[i]] for i in range(COLS.index(first), COLS.index(last) + 1))
        return width * 0.70 * 16 / size * (0.92 if bold else 1)

    def est_height(text, first, last, size, bold):
        per = cpl(first, last, size, bold)
        lines = sum(max(1, math.ceil(len(seg) * 1.02 / per)) for seg in strip_marks(text).split("\n"))
        return min(409, lines * size * 1.35 + 4)

    def box(row, c1, c2, top=thin, bottom=thin, left=thin, right=thin):
        i1, i2 = COLS.index(c1) + 1, COLS.index(c2) + 1
        for col in range(i1, i2 + 1):
            ws.cell(row, col).border = Border(top=top, bottom=bottom,
                                              left=left if col == i1 else None,
                                              right=right if col == i2 else None)

    def para(text, num=None, bold=False, size=16, ul=False, first="B", last="J",
             align="justify", gap=True, keep_extra=0):
        h = est_height(text, first, last, size, bold)
        need(h + keep_extra)
        if num is not None:
            cell = ws.cell(St.r, 1, num)
            cell.font = F(16, True)
            cell.alignment = Alignment(horizontal="center", vertical="top")
        cell = put(St.r, COLS.index(first) + 1, text, size, bold, ul)
        cell.alignment = Alignment(horizontal=align, vertical="top", wrap_text=True)
        if first != last:
            ws.merge_cells(f"{first}{St.r}:{last}{St.r}")
        nxt(h)
        if gap:
            nxt(12)

    def date_udin(left, right, size=16):
        need(22)
        put(St.r, 1, left, size, True)
        put(St.r, 9, right, size, True)
        nxt()

    def signature(size=16):
        need(15 * 22)
        for t in c["signature"]:
            ws.cell(St.r, 2, t).font = F(size, True)
            nxt(21)
        for _ in range(4):
            nxt(21)
        for t in c["signatory"]:
            ws.cell(St.r, 2, t).font = F(size, True)
            nxt(21)
        nxt()
        put(St.r, 2, c["udin_line"], size, True)
        put(St.r, 9, c["date_line"], size, True)
        nxt(21)
        ws.cell(St.r, 2, c["place"]).font = F(size, True)
        nxt(21)

    # ---------------- Page 1 ----------------
    if s.get("letterhead_first_page", True):
        letterhead()
    else:
        for _ in range(9):
            nxt(21)
    para(c["title"], bold=True, size=18, ul=True, first="A", last="J", align="center")
    for n, t in enumerate(c["intro"], 1):
        para(t, num=n)
    para("NET WORTH OF THE APPLICANT", bold=True, size=20, ul=True, first="A", last="J",
         align="center", gap=False)
    for col in range(1, 11):
        ws.cell(St.r - 1, col).border = Border(top=medium, bottom=medium)

    # summary table
    r = St.r
    ws.cell(r, 1, "S. No.").font = F(16, True)
    ws.cell(r, 1).alignment = Alignment(horizontal="center")
    ws.cell(r, 2, "PARTICULARS").font = F(16, True)
    ws.merge_cells(f"B{r}:I{r}")
    ws.cell(r, 10, "AMOUNT (in Rs.)").font = F(16, True)
    ws.cell(r, 10).alignment = Alignment(horizontal="center")
    box(r, "A", "A"); box(r, "B", "I", top=medium); box(r, "J", "J")
    nxt(21)
    summary_rows = {}
    for num, label, _amt, key in c["summary"]:
        r = St.r
        ws.cell(r, 1, int(num)).font = F(16, num == "1")
        ws.cell(r, 1).alignment = Alignment(horizontal="center")
        ws.cell(r, 2, label).font = F(16)
        ws.merge_cells(f"B{r}:I{r}")
        cell = ws.cell(r, 10)
        cell.font = F(16)
        cell.number_format = ACCT
        box(r, "A", "A"); box(r, "B", "I"); box(r, "J", "J")
        summary_rows[key] = r
        nxt(24)
    r = St.r
    ws.cell(r, 2, "Net Worth of the Applicant (1+2-3)").font = F(18, True)
    ws.cell(r, 2).alignment = Alignment(horizontal="right")
    ws.merge_cells(f"B{r}:I{r}")
    cell = ws.cell(r, 10, f"=J{summary_rows['A']}+J{summary_rows['B']}-J{summary_rows['C']}")
    cell.font = F(18, True)
    cell.number_format = ACCT
    box(r, "A", "A", bottom=medium); box(r, "B", "I", bottom=medium); box(r, "J", "J", bottom=medium)
    nxt(24)
    nxt()
    for w in c["words"]:
        para(w, bold=True, first="A", last="J")
    nxt()
    date_udin(c["date_line"], c["udin_line"])

    # ---------------- Page 2 ----------------
    page_break()
    para(c["resp_head"], num=5, bold=True, ul=True, align="left")
    para(c["resp"][0])
    para(c["resp"][1], bold=True)
    para(c["prac_head"], num=6, bold=True, ul=True, align="left")
    for t in c["prac"]:
        para(t)
    for lbl, t in c["procedures"]:
        para(f"{lbl} {t}", gap=False)
    nxt(12)
    para(c["relied"])
    date_udin(c["date_line"], c["udin_line"])

    # ---------------- Page 3 ----------------
    page_break()
    for t in c["standards"]:
        para(t)
    para(c["concl_head"], num=7, bold=True, ul=True, align="left")
    para(c["concl"])
    para(c["restr_head"], num=8, bold=True, ul=True, align="left")
    para(c["restr"])
    signature()
    nxt()
    nxt()
    ws.cell(St.r, 2, c["enclosure"]).font = F(16)
    nxt()

    # ---------------- Page 4+ : detailed computation ----------------
    page_break()
    para("DETAILED COMPUTATION OF NET-WORTH OF \nTHE APPLICANT", bold=True, size=22, ul=True,
         first="A", last="J", align="center")
    r = St.r
    ws.cell(r, 1, "S.No.").font = F(16, True)
    ws.cell(r, 1).alignment = Alignment(horizontal="center")
    ws.cell(r, 2, "Particulars").font = F(16, True)
    ws.merge_cells(f"B{r}:I{r}")
    ws.cell(r, 10, "Amount (in Rs.)").font = F(16, True)
    ws.cell(r, 10).alignment = Alignment(horizontal="center")
    box(r, "A", "A"); box(r, "B", "I"); box(r, "J", "J")
    nxt(21)
    nxt()

    total_rows = {}
    for key, prefix, head, items, total_lbl, _tot in c["sections"]:
        need(70)
        if prefix:
            ws.cell(St.r, 1, prefix).font = F(16, True)
        ws.cell(St.r, 2, head).font = F(16, True, True)
        nxt()
        nxt()
        first_row = St.r
        if not items:
            ws.cell(St.r, 2, "NIL").font = F(16)
            cell = ws.cell(St.r, 10, 0)
            cell.font = F(16, True)
            cell.number_format = ACCT
            box(St.r, "J", "J")
            total_rows[key] = St.r
            nxt()
            nxt()
            continue
        for n, it in enumerate(items, 1):
            h1 = est_height(it["desc"], "B", "I", 16, False)
            h2 = est_height(it["note"], "B", "I", 17, True) if it["note"] else 0
            need(h1 + h2 + 20)
            ws.cell(St.r, 1, n).font = F(16, True)
            ws.cell(St.r, 1).alignment = Alignment(horizontal="center", vertical="top")
            cell = put(St.r, 2, it["desc"], 16)
            cell.alignment = Alignment(horizontal="justify", vertical="top", wrap_text=True)
            ws.merge_cells(f"B{St.r}:I{St.r}")
            cell = ws.cell(St.r, 10, it["amount"])
            cell.font = F(16)
            cell.number_format = ACCT
            cell.alignment = Alignment(horizontal="right", vertical="top")
            nxt(h1)
            if it["note"]:
                cell = put(St.r, 2, it["note"], 17, True, True)
                cell.alignment = Alignment(horizontal="justify", vertical="top", wrap_text=True)
                ws.merge_cells(f"B{St.r}:I{St.r}")
                nxt(h2)
            nxt()
        last_row = St.r - 1
        need(25)
        ws.cell(St.r, 9, f"{total_lbl}   (Rs.)").font = F(16, True)
        ws.cell(St.r, 9).alignment = Alignment(horizontal="right")
        cell = ws.cell(St.r, 10, f"=SUM(J{first_row}:J{last_row})")
        cell.font = F(16, True)
        cell.number_format = ACCT
        cell.alignment = Alignment(horizontal="right")
        box(St.r, "J", "J")
        total_rows[key] = St.r
        nxt(23)
        nxt()

    need(30)
    nxt()
    ws.cell(St.r, 9, "NET WORTH (A+B-C)   (Rs.)").font = F(18, True)
    ws.cell(St.r, 9).alignment = Alignment(horizontal="right")
    cell = ws.cell(St.r, 10, f"=J{total_rows['A']}+J{total_rows['B']}-J{total_rows['C']}")
    cell.font = F(19, True)
    cell.number_format = ACCT
    cell.alignment = Alignment(horizontal="right")
    ws.cell(St.r, 10).border = Border(top=thin, bottom=double, left=thin, right=thin)
    nxt(24.75)
    nxt()
    signature(size=14)

    for key, row in summary_rows.items():
        ws.cell(row, 10).value = f"=J{total_rows[key]}"

    # print setup
    ws.print_area = f"A1:J{St.r}"
    ws.page_setup.paperSize = 9
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_margins.left = ws.page_margins.right = 0.7
    ws.page_margins.top = ws.page_margins.bottom = 0.75
    wb.save(path)


# ======================================================================
# Word export
# ======================================================================
def export_word(c, path):
    from docx import Document
    from docx.shared import Pt, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    s = c["settings"]
    JUST, LEFT, RIGHT, CENTER = (WD_ALIGN_PARAGRAPH.JUSTIFY, WD_ALIGN_PARAGRAPH.LEFT,
                                 WD_ALIGN_PARAGRAPH.RIGHT, WD_ALIGN_PARAGRAPH.CENTER)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.27), Inches(11.69)
    sec.left_margin = sec.right_margin = Inches(0.8)
    sec.top_margin, sec.bottom_margin = Inches(0.6), Inches(0.7)
    sec.header_distance = Inches(0.35)
    TEXT_W = 8.27 - 1.6

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.15

    def border_el(tag, **sides):
        el = OxmlElement(tag)
        for side, val in sides.items():
            b = OxmlElement(f"w:{side}")
            b.set(qn("w:val"), val[0])
            b.set(qn("w:sz"), str(val[1]))
            b.set(qn("w:space"), "0")
            b.set(qn("w:color"), "000000")
            el.append(b)
        return el

    def cell_border(cell, **sides):
        tcPr = cell._tc.get_or_add_tcPr()
        tcPr.append(border_el("w:tcBorders", **sides))

    def para_border_bottom(p, val="single", sz=12):
        pPr = p._p.get_or_add_pPr()
        pPr.append(border_el("w:pBdr", bottom=(val, sz)))

    def run(p, text, bold=False, ul=False, size=None):
        r = None
        for seg, seg_bold in segments(text):
            r = p.add_run(seg)
            r.bold, r.underline = (bold or seg_bold), ul
            if size:
                r.font.size = Pt(size)
        return r

    def set_widths(table, widths):
        table.autofit = False
        tblPr = table._tbl.tblPr
        layout = OxmlElement("w:tblLayout")
        layout.set(qn("w:type"), "fixed")
        tblPr.append(layout)
        tblW = tblPr.find(qn("w:tblW"))
        if tblW is None:
            tblW = OxmlElement("w:tblW")
            tblPr.append(tblW)
        tblW.set(qn("w:w"), str(int(sum(widths) * 1440)))
        tblW.set(qn("w:type"), "dxa")
        for gc, w in zip(table._tbl.tblGrid.findall(qn("w:gridCol")), widths):
            gc.set(qn("w:w"), str(int(w * 1440)))
        for row in table.rows:
            for cell, w in zip(row.cells, widths):
                cell.width = Inches(w)

    # ---- letterhead in header ----
    def fill_letterhead(header):
        first = header.paragraphs[0]._p
        first.getparent().remove(first)
        tbl = header.add_table(rows=1, cols=2, width=Inches(TEXT_W))
        set_widths(tbl, [1.4, TEXT_W - 1.4])
        lc, rc = tbl.rows[0].cells
        lg = logo_file(s)
        if lg:
            lc.paragraphs[0].add_run().add_picture(lg, height=Inches(1.0))
        lines = [(s["firm_name"], 18, True, True), (s["firm_type"], 14, True, True),
                 (s["address1"], 10, False, False), (s["address2"], 10, False, False),
                 ("Email: " + s["email"], 10, True, False), ("Contact: " + s["contact"], 10, True, False)]
        for i, (t, size, b, u) in enumerate(lines):
            p = rc.paragraphs[0] if i == 0 else rc.add_paragraph()
            p.alignment = RIGHT
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            run(p, t, b, u, size)
        rule = header.add_paragraph()
        rule.paragraph_format.space_after = Pt(0)
        para_border_bottom(rule, "single", 12)

    if s.get("letterhead_first_page", True):
        fill_letterhead(sec.header)
    else:
        sec.different_first_page_header_footer = True
        fill_letterhead(sec.header)
        sp = sec.first_page_header.paragraphs[0]
        sp.paragraph_format.space_before = Inches(1.25)

    # ---- helpers ----
    brk = {"on": False}

    def page_break():
        brk["on"] = True

    def take_break(p):
        if brk["on"]:
            p.paragraph_format.page_break_before = True
            brk["on"] = False

    def P(text="", bold=False, ul=False, align=JUST, size=None, indent=0.45, after=6):
        p = doc.add_paragraph()
        take_break(p)
        p.alignment = align
        p.paragraph_format.left_indent = Inches(indent)
        p.paragraph_format.space_after = Pt(after)
        if text:
            run(p, text, bold, ul, size)
        return p

    def numbered(num, text, bold=False, ul=False, align=JUST):
        p = doc.add_paragraph()
        take_break(p)
        p.alignment = align
        pf = p.paragraph_format
        pf.left_indent, pf.first_line_indent = Inches(0.45), Inches(-0.45)
        pf.tab_stops.add_tab_stop(Inches(0.45))
        run(p, f"{num}.\t", True)
        run(p, text, bold, ul)
        return p

    def date_udin(left, right):
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(TEXT_W), WD_TAB_ALIGNMENT.RIGHT)
        p.paragraph_format.space_before = Pt(12)
        run(p, f"{left}\t{right}", True)

    def signature():
        P("", indent=0, after=0)
        for t in c["signature"]:
            P(t, bold=True, align=LEFT, indent=0, after=0)
        for _ in range(3):
            P("", indent=0, after=0)
        for t in c["signatory"]:
            P(t, bold=True, align=LEFT, indent=0, after=0)
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(TEXT_W), WD_TAB_ALIGNMENT.RIGHT)
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(0)
        run(p, f"{c['udin_line']}\t{c['date_line']}", True)
        P(c["place"], bold=True, align=LEFT, indent=0)

    # ---- Page 1 ----
    P(c["title"], bold=True, ul=True, align=CENTER, size=14, indent=0, after=12)
    for n, t in enumerate(c["intro"], 1):
        numbered(n, t)
    P("NET WORTH OF THE APPLICANT", bold=True, ul=True, align=CENTER, size=13, indent=0, after=6)

    t = doc.add_table(rows=1, cols=3)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for cell, txt, al in zip(hdr, ["S. No.", "PARTICULARS", "AMOUNT (in Rs.)"], [CENTER, LEFT, CENTER]):
        cell.paragraphs[0].alignment = al
        run(cell.paragraphs[0], txt, True)
    for num, label, amt, _k in c["summary"]:
        row = t.add_row().cells
        row[0].paragraphs[0].alignment = CENTER
        run(row[0].paragraphs[0], num)
        run(row[1].paragraphs[0], label)
        row[2].paragraphs[0].alignment = RIGHT
        run(row[2].paragraphs[0], fmt_acct(amt))
    row = t.add_row().cells
    merged = row[0].merge(row[1])
    merged.paragraphs[0].alignment = RIGHT
    run(merged.paragraphs[0], "Net Worth of the Applicant (1+2-3)", True, size=12)
    row[2].paragraphs[0].alignment = RIGHT
    run(row[2].paragraphs[0], fmt_acct(c["nw"]), True, size=12)
    set_widths(t, [0.8, 4.27, 1.6])
    for r_ in t.rows:
        for cell in r_.cells:
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(3)
                p.paragraph_format.space_before = Pt(3)

    P("", indent=0)
    for w in c["words"]:
        P(w, bold=True, indent=0, after=10)
    date_udin(c["date_line"], c["udin_line"])

    # ---- Page 2 ----
    page_break()
    numbered(5, c["resp_head"], True, True, LEFT)
    P(c["resp"][0])
    P(c["resp"][1], bold=True)
    numbered(6, c["prac_head"], True, True, LEFT)
    for t_ in c["prac"]:
        P(t_)
    for lbl, t_ in c["procedures"]:
        p = doc.add_paragraph()
        p.alignment = JUST
        pf = p.paragraph_format
        pf.left_indent, pf.first_line_indent = Inches(0.8), Inches(-0.35)
        pf.tab_stops.add_tab_stop(Inches(0.8))
        pf.space_after = Pt(2)
        run(p, f"{lbl}\t{t_}")
    P("", after=0)
    P(c["relied"])
    date_udin(c["date_line"], c["udin_line"])

    # ---- Page 3 ----
    page_break()
    for t_ in c["standards"]:
        P(t_)
    numbered(7, c["concl_head"], True, True, LEFT)
    P(c["concl"])
    numbered(8, c["restr_head"], True, True, LEFT)
    P(c["restr"])
    signature()
    P(c["enclosure"], align=LEFT, indent=0)

    # ---- Page 4: detailed computation ----
    page_break()
    P(c["detail_title"], bold=True, ul=True, align=CENTER, size=14, indent=0, after=10)
    t = doc.add_table(rows=1, cols=3)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    box = dict(top=("single", 6), bottom=("single", 6), left=("single", 6), right=("single", 6))
    for cell, txt, al in zip(t.rows[0].cells, ["S.No.", "Particulars", "Amount (in Rs.)"],
                             [CENTER, LEFT, CENTER]):
        cell.paragraphs[0].alignment = al
        run(cell.paragraphs[0], txt, True)
        cell_border(cell, **box)
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    trPr.append(th)

    def new_row(space_before=4):
        row_ = t.add_row()
        cs = OxmlElement("w:cantSplit")
        cs.set(qn("w:val"), "true")
        row_._tr.get_or_add_trPr().append(cs)
        cells = row_.cells
        for cell in cells:
            cell.paragraphs[0].paragraph_format.space_before = Pt(space_before)
        return cells

    for key, prefix, head, items, total_lbl, total in c["sections"]:
        row = new_row(10)
        if prefix:
            run(row[0].paragraphs[0], prefix.strip(), True)
        run(row[1].paragraphs[0], head, True, True)
        if not items:
            row = new_row()
            run(row[1].paragraphs[0], "NIL")
            row[2].paragraphs[0].alignment = RIGHT
            run(row[2].paragraphs[0], fmt_acct(0), True)
            cell_border(row[2], **box)
            continue
        for n, it in enumerate(items, 1):
            row = new_row(6)
            row[0].paragraphs[0].alignment = CENTER
            run(row[0].paragraphs[0], str(n), True)
            p = row[1].paragraphs[0]
            p.alignment = JUST
            run(p, it["desc"])
            if it["note"]:
                p2 = row[1].add_paragraph()
                p2.alignment = JUST
                run(p2, it["note"], True, True, 10)
            row[2].paragraphs[0].alignment = RIGHT
            run(row[2].paragraphs[0], fmt_acct(it["amount"]))
        row = new_row(6)
        row[1].paragraphs[0].alignment = RIGHT
        run(row[1].paragraphs[0], f"{total_lbl}  (Rs.)", True)
        row[2].paragraphs[0].alignment = RIGHT
        run(row[2].paragraphs[0], fmt_acct(total), True)
        cell_border(row[2], **box)

    row = new_row(14)
    row[1].paragraphs[0].alignment = RIGHT
    run(row[1].paragraphs[0], "NET WORTH (A+B-C)  (Rs.)", True, size=12)
    row[2].paragraphs[0].alignment = RIGHT
    run(row[2].paragraphs[0], fmt_acct(c["nw"]), True, size=12)
    cell_border(row[2], top=("single", 6), left=("single", 6), right=("single", 6), bottom=("double", 6))
    set_widths(t, [0.6, 4.57, 1.5])

    signature()
    doc.save(path)


# ======================================================================
# PDF export
# ======================================================================
def _pdf_fonts():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.fonts import addMapping
    win = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
    candidates = [
        [os.path.join(win, f) for f in ("arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf")],
        ["/System/Library/Fonts/Supplemental/" + f for f in
         ("Arial.ttf", "Arial Bold.ttf", "Arial Italic.ttf", "Arial Bold Italic.ttf")],
        ["/Library/Fonts/" + f for f in ("Arial.ttf", "Arial Bold.ttf", "Arial Italic.ttf", "Arial Bold Italic.ttf")],
        ["/usr/share/fonts/truetype/msttcorefonts/" + f for f in
         ("Arial.ttf", "Arial_Bold.ttf", "Arial_Italic.ttf", "Arial_Bold_Italic.ttf")],
        ["/usr/share/fonts/truetype/liberation/" + f for f in
         ("LiberationSans-Regular.ttf", "LiberationSans-Bold.ttf", "LiberationSans-Italic.ttf",
          "LiberationSans-BoldItalic.ttf")],
    ]
    for files in candidates:
        if all(os.path.isfile(f) for f in files):
            try:
                names = ["CertFont", "CertFont-Bold", "CertFont-Italic", "CertFont-BoldItalic"]
                for n, f in zip(names, files):
                    if n not in pdfmetrics.getRegisteredFontNames():
                        pdfmetrics.registerFont(TTFont(n, f))
                addMapping("CertFont", 0, 0, names[0])
                addMapping("CertFont", 1, 0, names[1])
                addMapping("CertFont", 0, 1, names[2])
                addMapping("CertFont", 1, 1, names[3])
                return names[0], names[1]
            except Exception:
                continue
    return "Helvetica", "Helvetica-Bold"


def export_pdf(c, path):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_RIGHT, TA_LEFT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                    PageBreak, KeepTogether)
    from reportlab.pdfbase.pdfmetrics import stringWidth
    from xml.sax.saxutils import escape

    s = c["settings"]
    REG, BOLD = _pdf_fonts()
    W, H = A4
    LM = RM = 0.75 * inch
    FRAME_W = W - LM - RM
    TOP = 148

    base = ParagraphStyle("base", fontName=REG, fontSize=10, leading=13.6, alignment=TA_JUSTIFY,
                          spaceAfter=6)
    st = {
        "body": base,
        "left": ParagraphStyle("left", parent=base, alignment=TA_LEFT),
        "center": ParagraphStyle("center", parent=base, alignment=TA_CENTER),
        "right": ParagraphStyle("right", parent=base, alignment=TA_RIGHT, spaceAfter=0),
        "cell": ParagraphStyle("cell", parent=base, spaceAfter=0),
        "note": ParagraphStyle("note", parent=base, fontSize=9.5, leading=13, spaceAfter=0, spaceBefore=3),
        "title": ParagraphStyle("title", parent=base, fontName=BOLD, fontSize=13, leading=17,
                                alignment=TA_CENTER, spaceAfter=12),
    }

    def e(t):
        return escape(t).replace(BOLD_ON, "<b>").replace(BOLD_OFF, "</b>")

    def b(t, ul=False):
        t = e(t)
        return f"<b><u>{t}</u></b>" if ul else f"<b>{t}</b>"

    def letterhead(cv, _doc):
        cv.saveState()
        xr = W - RM
        top = H - 30
        y = top - 18
        lines = [(s["firm_name"], BOLD, 17, True, 0), (s["firm_type"], BOLD, 13, True, 18),
                 (s["address1"], REG, 9.5, False, 17), (s["address2"], REG, 9.5, False, 12),
                 ("Email: " + s["email"], BOLD, 9.5, False, 13), ("Contact: " + s["contact"], BOLD, 9.5, False, 12)]
        for text, font, size, ul, dy in lines:
            y -= dy
            cv.setFont(font, size)
            cv.drawRightString(xr, y, text)
            if ul:
                w = stringWidth(text, font, size)
                cv.setLineWidth(0.8)
                cv.line(xr - w, y - 2, xr, y - 2)
        lg = logo_file(s)
        if lg:
            try:
                cv.drawImage(lg, LM, y - 6, width=95, height=top - y + 6,
                             preserveAspectRatio=True, anchor="w", mask="auto")
            except Exception:
                pass
        cv.setLineWidth(1.4)
        cv.line(LM, y - 12, W - RM, y - 12)
        cv.restoreState()

    def first_page(cv, d_):
        if s.get("letterhead_first_page", True):
            letterhead(cv, d_)

    story = []

    def numbered(num, markup):
        t = Table([[Paragraph(f"<b>{num}.</b>", st["cell"]), Paragraph(markup, st["cell"])]],
                  colWidths=[30, FRAME_W - 30])
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                               ("BOTTOMPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 0)]))
        story.append(t)

    def body(markup, style="body"):
        ps = ParagraphStyle("ind", parent=st[style], leftIndent=30)
        story.append(Paragraph(markup, ps))

    def two_col(left, right):
        t = Table([[Paragraph(left, st["left"]), Paragraph(right, st["right"])]],
                  colWidths=[FRAME_W / 2, FRAME_W / 2])
        t.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        return t

    def signature():
        parts = [Spacer(1, 8)]
        parts += [Paragraph(b(t), ParagraphStyle("sig", parent=st["left"], spaceAfter=1)) for t in c["signature"]]
        parts.append(Spacer(1, 40))
        parts += [Paragraph(b(t), ParagraphStyle("sig", parent=st["left"], spaceAfter=1)) for t in c["signatory"]]
        parts.append(Spacer(1, 8))
        parts.append(two_col(b(c["udin_line"]), b(c["date_line"])))
        parts.append(Paragraph(b(c["place"]), st["left"]))
        story.append(KeepTogether(parts))

    # ---- Page 1 ----
    story.append(Paragraph(f"<u>{e(c['title'])}</u>", st["title"]))
    for n, t in enumerate(c["intro"], 1):
        numbered(n, e(t))
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<u>NET WORTH OF THE APPLICANT</u>",
                           ParagraphStyle("h", parent=st["title"], fontSize=12, spaceAfter=6)))
    data = [[Paragraph(b("S. No."), st["center"]), Paragraph(b("PARTICULARS"), st["cell"]),
             Paragraph(b("AMOUNT (in Rs.)"), st["center"])]]
    for num, label, amt, _k in c["summary"]:
        data.append([Paragraph(num, st["center"]), Paragraph(e(label), st["cell"]),
                     Paragraph(fmt_acct(amt), st["right"])])
    big = ParagraphStyle("big", parent=st["right"], fontName=BOLD, fontSize=11.5)
    data.append([Paragraph("Net Worth of the Applicant (1+2-3)", big), "", Paragraph(fmt_acct(c["nw"]), big)])
    t = Table(data, colWidths=[55, FRAME_W - 55 - 125, 125])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.6, colors.black),
                           ("SPAN", (0, -1), (1, -1)), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story.append(t)
    story.append(Spacer(1, 14))
    for w in c["words"]:
        story.append(Paragraph(b(w), ParagraphStyle("w", parent=base, spaceAfter=10)))
    story.append(Spacer(1, 16))
    story.append(two_col(b(c["date_line"]), b(c["udin_line"])))

    # ---- Page 2 ----
    story.append(PageBreak())
    numbered(5, b(c["resp_head"], True))
    body(e(c["resp"][0]))
    body(b(c["resp"][1]))
    numbered(6, b(c["prac_head"], True))
    for t_ in c["prac"]:
        body(e(t_))
    proc_style = ParagraphStyle("proc", parent=base, leftIndent=56, firstLineIndent=-22, spaceAfter=2)
    for lbl, t_ in c["procedures"]:
        story.append(Paragraph(f"{lbl}&nbsp;&nbsp;{e(t_)}", proc_style))
    story.append(Spacer(1, 6))
    body(e(c["relied"]))
    story.append(Spacer(1, 10))
    story.append(two_col(b(c["date_line"]), b(c["udin_line"])))

    # ---- Page 3 ----
    story.append(PageBreak())
    for t_ in c["standards"]:
        body(e(t_))
    numbered(7, b(c["concl_head"], True))
    body(e(c["concl"]))
    numbered(8, b(c["restr_head"], True))
    body(e(c["restr"]))
    signature()
    story.append(Spacer(1, 10))
    story.append(Paragraph(e(c["enclosure"]), st["left"]))

    # ---- Page 4: detailed computation ----
    story.append(PageBreak())
    story.append(Paragraph(f"<u>{e(c['detail_title'])}</u>", st["title"]))
    data = [[Paragraph(b("S.No."), st["center"]), Paragraph(b("Particulars"), st["cell"]),
             Paragraph(b("Amount (in Rs.)"), st["center"])]]
    cmds = [("BOX", (0, 0), (0, 0), 0.6, colors.black), ("BOX", (1, 0), (1, 0), 0.6, colors.black),
            ("BOX", (2, 0), (2, 0), 0.6, colors.black), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    for key, prefix, head, items, total_lbl, total in c["sections"]:
        data.append([Paragraph(b(prefix.strip()), st["cell"]) if prefix else "",
                     Paragraph(b(head, True), st["cell"]), ""])
        cmds.append(("TOPPADDING", (0, len(data) - 1), (-1, len(data) - 1), 12))
        if not items:
            data.append(["", Paragraph("NIL", st["cell"]), Paragraph(b(fmt_acct(0)), st["right"])])
            cmds.append(("BOX", (2, len(data) - 1), (2, len(data) - 1), 0.6, colors.black))
            continue
        for n, it in enumerate(items, 1):
            cell = [Paragraph(e(it["desc"]), st["cell"])]
            if it["note"]:
                cell.append(Paragraph(b(it["note"], True), st["note"]))
            data.append([Paragraph(b(str(n)), st["center"]), cell,
                         Paragraph(fmt_acct(it["amount"]), st["right"])])
            cmds.append(("TOPPADDING", (0, len(data) - 1), (-1, len(data) - 1), 8))
        data.append(["", Paragraph(b(f"{total_lbl}  (Rs.)"), st["right"]), Paragraph(b(fmt_acct(total)), st["right"])])
        cmds += [("BOX", (2, len(data) - 1), (2, len(data) - 1), 0.6, colors.black),
                 ("TOPPADDING", (0, len(data) - 1), (-1, len(data) - 1), 8),
                 ("VALIGN", (0, len(data) - 1), (-1, len(data) - 1), "MIDDLE")]
    nwst = ParagraphStyle("nw", parent=st["right"], fontName=BOLD, fontSize=11.5)
    data.append(["", Paragraph("NET WORTH (A+B-C)  (Rs.)", nwst), Paragraph(fmt_acct(c["nw"]), nwst)])
    r = len(data) - 1
    cmds += [("BOX", (2, r), (2, r), 0.6, colors.black),
             ("LINEBELOW", (2, r), (2, r), 0.6, colors.black, None, None, None, 2, 2),
             ("TOPPADDING", (0, r), (-1, r), 16), ("VALIGN", (0, r), (-1, r), "MIDDLE")]
    t = Table(data, colWidths=[40, FRAME_W - 40 - 115, 115], repeatRows=1)
    t.setStyle(TableStyle(cmds))
    story.append(t)
    story.append(Spacer(1, 10))
    signature()

    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TOP,
                            bottomMargin=45, title="Net Worth Certificate",
                            author=s["firm_name"])
    doc.build(story, onFirstPage=first_page, onLaterPages=letterhead)


# ======================================================================
# Settings persistence
# ======================================================================
def load_settings():
    data = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data.update(json.load(f))
    except Exception:
        pass
    return data


def save_settings(data):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def open_path(p):
    try:
        if sys.platform.startswith("win"):
            os.startfile(p)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception:
        pass


# ======================================================================
# GUI: Add / edit item dialog
# ======================================================================
class ItemDialog(tk.Toplevel):
    def __init__(self, master, category, item=None, applicant=""):
        super().__init__(master)
        self.cat_name = category
        self.cat = CATS[category]
        self.applicant = applicant
        self.result = None
        self.title(("Edit - " if item else "Add - ") + category)
        self.transient(master)
        self.resizable(True, True)

        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=category, style="H2.TLabel").grid(row=0, column=0, columnspan=2, sticky="w",
                                                                  pady=(0, 10))
        if self.cat["fields"]:
            ttk.Label(outer, text="Print in bold", style="Hint.TLabel").grid(row=0, column=2, sticky="sw",
                                                                             padx=(8, 0))
        self.vars = {}
        self.bolds = {}
        row = 1
        saved = item["fields"] if item else {}
        saved_bold = item.get("bold", {}) if item else {}
        for key, label, typ, opts in self.cat["fields"]:
            ttk.Label(outer, text=label + ":").grid(row=row, column=0, sticky="w", pady=3, padx=(0, 10))
            default = saved.get(key, "")
            if not item:
                if typ == "combo":
                    default = opts[0]
                elif typ == "relation":
                    default = "Self"
                elif key == "holder":
                    default = applicant
            var = tk.StringVar(value=default)
            if typ == "combo":
                w = ttk.Combobox(outer, textvariable=var, values=opts, width=58)
            elif typ == "relation":
                w = ttk.Combobox(outer, textvariable=var, values=RELATIONS, width=58, state="readonly")
            else:
                w = ttk.Entry(outer, textvariable=var, width=61)
            w.grid(row=row, column=1, sticky="we", pady=3)
            self.vars[key] = var
            var.trace_add("write", lambda *_a, k=key: self.on_field(k))
            bvar = tk.BooleanVar(value=bool(saved_bold.get(key, False)))
            ttk.Checkbutton(outer, text="Bold", variable=bvar).grid(row=row, column=2, sticky="w", padx=(8, 0))
            self.bolds[key] = bvar
            bvar.trace_add("write", lambda *_a, k=key: self.on_field(k))
            row += 1

        if self.cat["kind"] == "asset":
            ttk.Label(outer, text="Show under:").grid(row=row, column=0, sticky="w", pady=3)
            self.section = tk.StringVar(value=SECTION_LABELS[item["section"] if item else self.cat["section"]])
            ttk.Combobox(outer, textvariable=self.section, state="readonly", width=58,
                         values=[SECTION_LABELS["A"] + " Investments (Annexure A)",
                                 SECTION_LABELS["B"] + " Investments (Annexure B)"]
                         ).grid(row=row, column=1, sticky="we", pady=3)
            if not item:
                self.section.set(SECTION_LABELS[self.cat["section"]] + " Investments (Annexure "
                                 + self.cat["section"] + ")")
            else:
                self.section.set(SECTION_LABELS[item["section"]] + " Investments (Annexure "
                                 + item["section"] + ")")
            row += 1
        else:
            self.section = None

        ttk.Label(outer, text="Amount (Rs.):", style="Bold.TLabel").grid(row=row, column=0, sticky="w", pady=6)
        self.amount = tk.StringVar(value=(f"{item['amount']:.2f}" if item else ""))
        ttk.Entry(outer, textvariable=self.amount, width=30, font=("Segoe UI", 11)).grid(
            row=row, column=1, sticky="w", pady=6)
        row += 1

        ttk.Separator(outer).grid(row=row, column=0, columnspan=3, sticky="we", pady=8)
        row += 1
        hint = ("Type the particulars as they should appear in the certificate. "
                "Select any words and press Ctrl+B to make them bold."
                if not self.cat["fields"] else
                "Text below is generated from the fields above. You can edit it, and select any words "
                "and press Ctrl+B to bold / unbold them.")
        ttk.Label(outer, text=hint, style="Hint.TLabel").grid(row=row, column=0, columnspan=3, sticky="w")
        row += 1
        ttk.Label(outer, text="Particulars:").grid(row=row, column=0, sticky="nw", pady=3)
        self.desc = tk.Text(outer, height=4, width=70, wrap="word", font=("Segoe UI", 10))
        self.desc.grid(row=row, column=1, sticky="we", pady=3)
        row += 1
        ttk.Label(outer, text="Note below it\n(bold, underlined):").grid(row=row, column=0, sticky="nw", pady=3)
        self.note = tk.Text(outer, height=3, width=70, wrap="word", font=("Segoe UI", 10))
        self.note.grid(row=row, column=1, sticky="we", pady=3)
        row += 1
        for w in (self.desc, self.note):
            w.tag_configure("b", font=("Segoe UI", 10, "bold"))
            w.bind("<Control-b>", lambda _e, w=w: self.toggle_bold(w))
            w.bind("<Control-B>", lambda _e, w=w: self.toggle_bold(w))

        btns = ttk.Frame(outer)
        btns.grid(row=row, column=0, columnspan=3, sticky="we", pady=(12, 0))
        if self.cat["fields"]:
            ttk.Button(btns, text="Regenerate text from fields", command=self.regenerate).pack(side="left")
        ttk.Button(btns, text="Bold / unbold selected text (Ctrl+B)",
                   command=self.toggle_bold_focused).pack(side="left", padx=6)
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="Save", style="Accent.TButton", command=self.ok).pack(side="right", padx=6)
        outer.columnconfigure(1, weight=1)

        self.manual = False
        if item:
            self.set_rich(self.desc, item["desc"])
            self.set_rich(self.note, item["note"])
            if self.cat["fields"]:
                gen = dict(saved, _bold=saved_bold)
                self.manual = (item["desc"] != self.cat["desc"](gen) or item["note"] != self.cat["note"](gen))
        else:
            self.regenerate()
        self.desc.bind("<Key>", lambda _e: setattr(self, "manual", True))
        self.note.bind("<Key>", lambda _e: setattr(self, "manual", True))

        self.grab_set()
        self.bind("<Escape>", lambda _e: self.destroy())
        self.wait_window(self)

    def fields(self):
        return {k: v.get() for k, v in self.vars.items()}

    def bold_flags(self):
        return {k: bool(v.get()) for k, v in self.bolds.items()}

    @staticmethod
    def set_rich(w, text):
        w.delete("1.0", "end")
        for seg, bold in segments(text):
            w.insert("end", seg, ("b",) if bold else ())

    @staticmethod
    def get_rich(w):
        out, bold = [], False
        for kind, value, _idx in w.dump("1.0", "end-1c", text=True, tag=True):
            if kind == "tagon" and value == "b":
                bold = True
            elif kind == "tagoff" and value == "b":
                bold = False
            elif kind == "text":
                out.append(mark(value, bold))
        return "".join(out).replace(BOLD_OFF + BOLD_ON, "").strip()

    def toggle_bold(self, w):
        try:
            a, b = w.index("sel.first"), w.index("sel.last")
        except tk.TclError:
            return "break"
        if "b" in w.tag_names(a):
            w.tag_remove("b", a, b)
        else:
            w.tag_add("b", a, b)
        self.manual = True
        return "break"

    def toggle_bold_focused(self):
        w = self.focus_get()
        self.toggle_bold(w if w in (self.desc, self.note) else self.desc)

    def on_field(self, key):
        if key == "relation":
            rel, holder = self.vars["relation"].get(), self.vars["holder"].get().strip()
            if rel == "Self" and not holder:
                self.vars["holder"].set(self.applicant)
            elif rel != "Self" and holder == self.applicant:
                self.vars["holder"].set("")
        if not self.manual:
            self.regenerate(keep_manual=True)

    def regenerate(self, keep_manual=False):
        if not self.cat["fields"]:
            return
        f = dict(self.fields(), _bold=self.bold_flags())
        self.set_rich(self.desc, self.cat["desc"](f))
        self.set_rich(self.note, self.cat["note"](f))
        if not keep_manual:
            self.manual = False

    def ok(self):
        try:
            amount = parse_amount(self.amount.get())
        except ValueError:
            messagebox.showerror(APP_TITLE, "Please enter a valid amount (numbers only).", parent=self)
            return
        desc = self.get_rich(self.desc)
        if not desc:
            messagebox.showerror(APP_TITLE, "Particulars cannot be empty.", parent=self)
            return
        if "________" in desc and not messagebox.askyesno(
                APP_TITLE, "Some details are still blank (shown as ________). Save anyway?", parent=self):
            return
        if amount <= 0 and not messagebox.askyesno(APP_TITLE, "Amount is zero. Save anyway?", parent=self):
            return
        if self.section is not None:
            section = self.section.get()[0]
        else:
            section = "C"
        self.result = dict(category=self.cat_name, kind=self.cat["kind"], section=section,
                           fields=self.fields(), bold=self.bold_flags(), desc=desc,
                           note=self.get_rich(self.note), amount=round(amount, 2))
        self.destroy()


# ======================================================================
# GUI: Main window
# ======================================================================
class App(tk.Tk):
    APP_FIELDS = [
        ("title", "Title", "combo", ["Mr.", "Ms.", "Mrs.", "Miss"]),
        ("name", "Applicant's full name", "text", None),
        ("relation", "Relation", "combo", ["S/o", "D/o", "W/o"]),
        ("parent", "Father's / Husband's name (with Mr.)", "text", None),
        ("passport", "Passport No.", "text", None),
        ("address", "Residential address", "text", None),
        ("purpose", "Purpose (in connection with)", "combo",
         ["Study Visa", "Visitor Visa", "Tourist Visa", "Work Visa", "Spouse Visa",
          "Dependent Visa", "PR Application", "Business Visa"]),
        ("authority", "For submission to", "text", None),
        ("engagement_date", "Engagement letter date", "text", None),
        ("statement_date", "Net worth as at (statement date)", "text", None),
        ("cert_date", "Certificate date", "text", None),
        ("udin", "UDIN", "text", None),
        ("currency", "Show net worth also in", "readonly", CURRENCIES),
        ("rate", "Exchange rate: 1 unit = Rs.", "text", None),
    ]

    SETTINGS_FIELDS = [
        ("firm_name", "Firm name"), ("firm_type", "Line below firm name"), ("address1", "Address line 1"),
        ("address2", "Address line 2"), ("email", "Email"), ("contact", "Contact"), ("frn", "FRN No."),
        ("partner", "Signing partner"), ("designation", "Designation"), ("mno", "Membership No."),
        ("place", "Place"), ("logo_path", "Logo image (PNG/JPG)"),
    ]

    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x760")
        self.minsize(1000, 640)
        self.settings = load_settings()
        self.items = []
        self.client_file = None
        self._style()

        header = ttk.Frame(self, padding=(16, 12, 16, 4))
        header.pack(fill="x")
        ttk.Label(header, text=APP_TITLE, style="H1.TLabel").pack(side="left")
        ttk.Button(header, text="New", command=self.new_client).pack(side="right", padx=3)
        ttk.Button(header, text="Save client data", command=self.save_client).pack(side="right", padx=3)
        ttk.Button(header, text="Open client data", command=self.open_client).pack(side="right", padx=3)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=12, pady=6)
        self.tab_app = ttk.Frame(nb, padding=14)
        self.tab_items = ttk.Frame(nb, padding=10)
        self.tab_settings = ttk.Frame(nb, padding=14)
        nb.add(self.tab_app, text="  1. Applicant Details  ")
        nb.add(self.tab_items, text="  2. Assets & Liabilities  ")
        nb.add(self.tab_settings, text="  Firm Settings  ")
        self._build_app_tab()
        self._build_items_tab()
        self._build_settings_tab()

        bar = ttk.Frame(self, padding=(16, 6, 16, 12))
        bar.pack(fill="x")
        self.totals_lbl = ttk.Label(bar, text="", style="Bold.TLabel")
        self.totals_lbl.pack(side="left")
        ttk.Button(bar, text="Save as MS Word", style="Accent.TButton",
                   command=lambda: self.export("docx")).pack(side="right", padx=3)
        ttk.Button(bar, text="Save as PDF", style="Accent.TButton",
                   command=lambda: self.export("pdf")).pack(side="right", padx=3)
        ttk.Button(bar, text="Save as Excel", style="Accent.TButton",
                   command=lambda: self.export("xlsx")).pack(side="right", padx=3)
        self.refresh()

    # ---------- styling ----------
    def _style(self):
        st = ttk.Style(self)
        if "clam" in st.theme_names():
            st.theme_use("clam")
        accent = "#1F4E79"
        st.configure("H1.TLabel", font=("Segoe UI", 17, "bold"), foreground=accent)
        st.configure("H2.TLabel", font=("Segoe UI", 12, "bold"), foreground=accent)
        st.configure("Bold.TLabel", font=("Segoe UI", 10, "bold"))
        st.configure("Hint.TLabel", foreground="#666666")
        st.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), foreground="white",
                     background=accent, padding=(12, 6))
        st.map("Accent.TButton", background=[("active", "#163A5C")])
        st.configure("Treeview", rowheight=26, font=("Segoe UI", 10))
        st.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        st.configure("TNotebook.Tab", padding=(10, 6), font=("Segoe UI", 10))

    # ---------- tab 1 ----------
    def _build_app_tab(self):
        self.av = {}
        today = datetime.date.today()
        defaults = dict(title="Mr.", relation="S/o", purpose="Study Visa",
                        authority="immigration or embassy authorities",
                        engagement_date=today.strftime("%d.%m.%Y"),
                        statement_date=today.strftime("%d-%m-%Y"),
                        cert_date=today.strftime("%d.%m.%Y"), currency="None")
        frm = self.tab_app
        self.ab = {}
        ttk.Label(frm, text="Print in bold", style="Hint.TLabel").grid(row=0, column=2, sticky="w", padx=(10, 0))
        for i, (key, label, typ, opts) in enumerate(self.APP_FIELDS, 1):
            ttk.Label(frm, text=label + ":").grid(row=i, column=0, sticky="w", pady=4, padx=(0, 12))
            var = tk.StringVar(value=defaults.get(key, ""))
            if typ == "combo":
                w = ttk.Combobox(frm, textvariable=var, values=opts, width=70)
            elif typ == "readonly":
                w = ttk.Combobox(frm, textvariable=var, values=opts, width=70, state="readonly")
            else:
                w = ttk.Entry(frm, textvariable=var, width=73)
            w.grid(row=i, column=1, sticky="we", pady=4)
            self.av[key] = var
            bvar = tk.BooleanVar(value=False)
            ttk.Checkbutton(frm, text="Bold", variable=bvar).grid(row=i, column=2, sticky="w", padx=(10, 0))
            self.ab[key] = bvar
            if key in ("currency", "rate"):
                var.trace_add("write", lambda *_a: self.refresh_totals())
        n = len(self.APP_FIELDS) + 1
        ttk.Label(frm, text="Tick 'Bold' to print that detail in bold wherever it appears in the certificate.\n"
                            "Dates are printed exactly as typed (e.g. 07.10.2026). "
                            "Exchange rate example: if 1 AUD = Rs. 55.25, type 55.25",
                  style="Hint.TLabel").grid(row=n, column=1, sticky="w", pady=(8, 0))
        frm.columnconfigure(1, weight=1)

    # ---------- tab 2 ----------
    def _build_items_tab(self):
        frm = self.tab_items
        left = ttk.Frame(frm)
        left.pack(side="left", fill="y", padx=(0, 10))
        box = ttk.LabelFrame(left, text=" Add Asset ", padding=8)
        box.pack(fill="x")
        for name in ASSET_CATS:
            ttk.Button(box, text="+ " + name, width=32,
                       command=lambda n=name: self.add_item(n)).pack(fill="x", pady=2)
        box = ttk.LabelFrame(left, text=" Add Liability ", padding=8)
        box.pack(fill="x", pady=(10, 0))
        for name in LIAB_CATS:
            ttk.Button(box, text="+ " + name, width=32,
                       command=lambda n=name: self.add_item(n)).pack(fill="x", pady=2)
        ttk.Label(left, text="No liabilities? Leave this empty —\n"
                             "the certificate will show NIL.", style="Hint.TLabel").pack(anchor="w", pady=8)

        right = ttk.Frame(frm)
        right.pack(side="left", fill="both", expand=True)
        cols = ("no", "sec", "type", "particulars", "amount")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for col, text, w, anchor in [("no", "#", 40, "center"), ("sec", "Annexure", 120, "w"),
                                     ("type", "Type", 170, "w"), ("particulars", "Particulars", 480, "w"),
                                     ("amount", "Amount (Rs.)", 140, "e")]:
            self.tree.heading(col, text=text)
            self.tree.column(col, width=w, anchor=anchor, stretch=(col == "particulars"))
        sb = ttk.Scrollbar(right, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="left", fill="y")
        self.tree.bind("<Double-1>", lambda _e: self.edit_item())

        acts = ttk.Frame(frm)
        acts.pack(side="left", fill="y", padx=(10, 0))
        for text, cmd in [("Edit", self.edit_item), ("Duplicate", self.duplicate_item),
                          ("Delete", self.delete_item), (None, None),
                          ("▲ Move up", lambda: self.move_item(-1)), ("▼ Move down", lambda: self.move_item(1))]:
            if text is None:
                ttk.Separator(acts).pack(fill="x", pady=8)
            else:
                ttk.Button(acts, text=text, width=14, command=cmd).pack(fill="x", pady=2)

    # ---------- tab 3 ----------
    def _build_settings_tab(self):
        frm = self.tab_settings
        self.sv = {}
        for i, (key, label) in enumerate(self.SETTINGS_FIELDS):
            ttk.Label(frm, text=label + ":").grid(row=i, column=0, sticky="w", pady=4, padx=(0, 12))
            var = tk.StringVar(value=self.settings.get(key, ""))
            ttk.Entry(frm, textvariable=var, width=80).grid(row=i, column=1, sticky="we", pady=4)
            self.sv[key] = var
        n = len(self.SETTINGS_FIELDS)
        ttk.Button(frm, text="Browse…", command=self.pick_logo).grid(row=n - 1, column=2, padx=6)
        self.lh_first = tk.BooleanVar(value=self.settings.get("letterhead_first_page", True))
        ttk.Checkbutton(frm, text="Print letterhead on the first page too "
                                  "(untick if you print page 1 on pre-printed letterhead)",
                        variable=self.lh_first).grid(row=n, column=1, sticky="w", pady=8)
        ttk.Button(frm, text="Save settings", style="Accent.TButton",
                   command=self.store_settings).grid(row=n + 1, column=1, sticky="w", pady=6)
        ttk.Label(frm, text=f"Settings are remembered on this computer ({SETTINGS_FILE}).",
                  style="Hint.TLabel").grid(row=n + 2, column=1, sticky="w")
        frm.columnconfigure(1, weight=1)

    def pick_logo(self):
        p = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg")])
        if p:
            self.sv["logo_path"].set(p)

    def current_settings(self):
        s = dict(self.settings)
        for k, v in self.sv.items():
            s[k] = v.get().strip()
        s["letterhead_first_page"] = bool(self.lh_first.get())
        return s

    def store_settings(self):
        self.settings = self.current_settings()
        try:
            save_settings(self.settings)
            messagebox.showinfo(APP_TITLE, "Firm settings saved.")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not save settings:\n{e}")

    # ---------- items ----------
    def applicant_name(self):
        return f"{self.av['title'].get()} {self.av['name'].get()}".strip()

    def selected_index(self):
        sel = self.tree.selection()
        return int(sel[0]) if sel else None

    def add_item(self, cat):
        dlg = ItemDialog(self, cat, applicant=self.applicant_name())
        if dlg.result:
            self.items.append(dlg.result)
            self.refresh(select=len(self.items) - 1)

    def edit_item(self):
        i = self.selected_index()
        if i is None:
            return
        dlg = ItemDialog(self, self.items[i]["category"], item=self.items[i], applicant=self.applicant_name())
        if dlg.result:
            self.items[i] = dlg.result
            self.refresh(select=i)

    def duplicate_item(self):
        i = self.selected_index()
        if i is None:
            return
        self.items.insert(i + 1, json.loads(json.dumps(self.items[i])))
        self.refresh(select=i + 1)

    def delete_item(self):
        i = self.selected_index()
        if i is None:
            return
        if messagebox.askyesno(APP_TITLE, "Delete the selected entry?"):
            del self.items[i]
            self.refresh()

    def move_item(self, delta):
        i = self.selected_index()
        if i is None:
            return
        j = i + delta
        if 0 <= j < len(self.items):
            self.items[i], self.items[j] = self.items[j], self.items[i]
            self.refresh(select=j)

    def refresh(self, select=None):
        self.tree.delete(*self.tree.get_children())
        counters = {"A": 0, "B": 0, "C": 0}
        for idx, it in enumerate(self.items):
            counters[it["section"]] += 1
            plain = strip_marks(it["desc"])
            short = plain if len(plain) < 110 else plain[:107] + "…"
            self.tree.insert("", "end", iid=str(idx),
                             values=(counters[it["section"]], SECTION_LABELS[it["section"]],
                                     it["category"], short, f"{it['amount']:,.2f}"))
        if select is not None and 0 <= select < len(self.items):
            self.tree.selection_set(str(select))
            self.tree.see(str(select))
        self.refresh_totals()

    def refresh_totals(self):
        tot = {k: sum(i["amount"] for i in self.items if i["section"] == k) for k in "ABC"}
        nw = tot["A"] + tot["B"] - tot["C"]
        text = (f"A: Rs. {fmt_inr(tot['A'])}    B: Rs. {fmt_inr(tot['B'])}    "
                f"C: Rs. {fmt_inr(tot['C'])}    NET WORTH: Rs. {fmt_inr(nw)}")
        cur = self.av["currency"].get() if hasattr(self, "av") else "None"
        try:
            rate = parse_amount(self.av["rate"].get()) if hasattr(self, "av") else 0
        except ValueError:
            rate = 0
        if cur != "None" and rate > 0:
            text += f"   ≈ {cur.split(' - ')[0]} {nw / rate:,.2f}"
        self.totals_lbl.config(text=text)

    # ---------- client data ----------
    def client_data(self):
        return {"applicant": {k: v.get() for k, v in self.av.items()},
                "applicant_bold": {k: bool(v.get()) for k, v in self.ab.items()},
                "items": self.items}

    def save_client(self):
        name = self.av["name"].get().strip() or "client"
        p = filedialog.asksaveasfilename(defaultextension=".json", initialfile=f"{name} - net worth.json",
                                         filetypes=[("Client data", "*.json")])
        if not p:
            return
        with open(p, "w", encoding="utf-8") as f:
            json.dump(self.client_data(), f, indent=2, ensure_ascii=False)
        self.client_file = p
        messagebox.showinfo(APP_TITLE, "Client data saved. Use 'Open client data' to revise it later.")

    def open_client(self):
        p = filedialog.askopenfilename(filetypes=[("Client data", "*.json")])
        if not p:
            return
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            for k, v in data.get("applicant", {}).items():
                if k in self.av:
                    self.av[k].set(v)
            for k, v in self.ab.items():
                v.set(bool(data.get("applicant_bold", {}).get(k, False)))
            self.items = data.get("items", [])
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not open file:\n{e}")
            return
        self.client_file = p
        self.refresh()

    def new_client(self):
        if self.items and not messagebox.askyesno(APP_TITLE, "Clear the current client and start a new one?"):
            return
        for k in ("name", "parent", "passport", "address", "udin", "rate"):
            self.av[k].set("")
        self.av["currency"].set("None")
        self.items = []
        self.client_file = None
        self.refresh()

    # ---------- export ----------
    def export(self, kind):
        a = {k: v.get().strip() for k, v in self.av.items()}
        a["_bold"] = {k: bool(v.get()) for k, v in self.ab.items()}
        if not a["name"]:
            messagebox.showwarning(APP_TITLE, "Please enter the applicant's name (tab 1).")
            return
        if not any(i["kind"] == "asset" for i in self.items):
            messagebox.showwarning(APP_TITLE, "Please add at least one asset (tab 2).")
            return
        if a["currency"] != "None":
            try:
                if parse_amount(a["rate"]) <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning(APP_TITLE, "Please enter a valid exchange rate, or set currency to None.")
                return
        content = build_content({"app": a, "items": self.items, "settings": self.current_settings()})
        ext = {"xlsx": ".xlsx", "pdf": ".pdf", "docx": ".docx"}[kind]
        ftype = {"xlsx": ("Excel workbook", "*.xlsx"), "pdf": ("PDF", "*.pdf"),
                 "docx": ("Word document", "*.docx")}[kind]
        p = filedialog.asksaveasfilename(defaultextension=ext,
                                         initialfile=f"Net Worth Certificate - {a['name']}{ext}",
                                         filetypes=[ftype])
        if not p:
            return
        try:
            self.config(cursor="watch")
            self.update()
            {"xlsx": export_excel, "pdf": export_pdf, "docx": export_word}[kind](content, p)
        except PermissionError:
            messagebox.showerror(APP_TITLE, "Could not save — the file may be open in another program.")
            return
        except ModuleNotFoundError as e:
            pkg = {"reportlab": "reportlab", "openpyxl": "openpyxl", "docx": "python-docx",
                   "PIL": "pillow"}.get(e.name, e.name)
            cmd = f'"{sys.executable}" -m pip install {pkg}'
            self.clipboard_clear()
            self.clipboard_append(cmd)
            messagebox.showerror(APP_TITLE, f"The '{pkg}' package is not installed for this Python.\n\n"
                                            f"Run this in Command Prompt (already copied to clipboard):\n\n{cmd}\n\n"
                                            "Then restart the app.")
            return
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not create the file:\n{e}")
            return
        finally:
            self.config(cursor="")
        if messagebox.askyesno(APP_TITLE, f"Saved:\n{p}\n\nOpen it now?"):
            open_path(p)


if __name__ == "__main__":
    App().mainloop()
