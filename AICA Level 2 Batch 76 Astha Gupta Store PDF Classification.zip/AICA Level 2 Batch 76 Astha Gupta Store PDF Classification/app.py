import json
from pathlib import Path
import shutil
from PIL import Image
import pymupdf
import streamlit as st
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, models, transforms

# 1. Page Configuration
st.set_page_config(
    page_title="PDF Document Classifier", page_icon="📄", layout="wide"
)

# Initialize Session State
if "undo_stack" not in st.session_state:
    st.session_state.undo_stack = []
if "pending_selections" not in st.session_state:
    st.session_state.pending_selections = {}

# Custom CSS for reduced top padding, tight grid spacing, and sticky header
st.markdown(
    """
    <style>
    /* 1. Reduce top header padding and title margins */
    .block-container {
        padding-top: 1rem !important;
        padding-bottom: 1rem !important;
    }
    h1 {
        padding-top: 0rem !important;
        padding-bottom: 0.5rem !important;
        margin-bottom: 0rem !important;
        font-size: 1.8rem !important;
    }
    header[data-testid="stHeader"] {
        background: transparent !important;
        height: 0rem !important;
    }

    /* 2. Compact container spacing & uniform image height */
    div[data-testid="stVerticalBlock"] > div {
        gap: 0.15rem !important;
    }
    div[data-testid="stImage"] {
        width: 100% !important;
    }
    div[data-testid="stImage"] img {
        width: 100% !important;
        height: 380px !important;
        object-fit: contain !important;
        background-color: #f8f9fa;
        border-radius: 4px;
        box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.12);
    }
    .stButton > button {
        padding: 2px 4px !important;
        font-size: 12px !important;
    }
    div[data-testid="stPills"] {
        width: 100% !important;
        justify-content: space-between !important;
    }

    /* 3. Sticky header bar for Tab 2 */
    div[data-testid="stVerticalBlock"] > div:has(div.sticky-bar-marker) {
        position: sticky;
        top: 0px;
        z-index: 999;
        background-color: white;
        padding: 8px 0px;
        border-bottom: 2px solid #eaeaea;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "Input"
JPEG_DIR = BASE_DIR / "JPEG"
INVOICE_DIR = BASE_DIR / "Invoice"
EWAY_DIR = BASE_DIR / "Eway"
BILTY_DIR = BASE_DIR / "BILTY"
OTHERS_DIR = BASE_DIR / "others"
TRAIN_DIR = BASE_DIR / "training_data"
MODEL_PATH = BASE_DIR / "document_classifier.pth"
CLASSES_PATH = BASE_DIR / "classes.txt"
CONFIRMED_LOG = BASE_DIR / "confirmed_images.json"
AI_PREDICTIONS_LOG = BASE_DIR / "ai_predictions.json"

CONFIDENCE_THRESHOLD = 0.80

# Ensure directories exist
for folder in [
    INPUT_DIR,
    JPEG_DIR,
    INVOICE_DIR,
    EWAY_DIR,
    BILTY_DIR,
    OTHERS_DIR,
    TRAIN_DIR / "Invoice",
    TRAIN_DIR / "Eway",
    TRAIN_DIR / "Bilty",
    TRAIN_DIR / "Others",
]:
    folder.mkdir(parents=True, exist_ok=True)

# Image preprocessing transform
transform = transforms.Compose(
    [
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
        ),
    ]
)


def load_json_log(filepath):
    if filepath.exists():
        try:
            with open(filepath, "r") as f:
                return json.load(f)
        except Exception:
            return {} if filepath == AI_PREDICTIONS_LOG else []
    return {} if filepath == AI_PREDICTIONS_LOG else []


def save_json_log(filepath, data):
    with open(filepath, "w") as f:
        json.dump(data, f)


def load_confirmed_set():
    data = load_json_log(CONFIRMED_LOG)
    return set(data) if isinstance(data, list) else set()


def save_confirmed_set(confirmed_set):
    save_json_log(CONFIRMED_LOG, list(confirmed_set))


def clear_training_data():
    """Removes all cached training images to free up storage after model training."""
    for subfolder in TRAIN_DIR.iterdir():
        if subfolder.is_dir():
            for file_path in subfolder.glob("*"):
                if file_path.is_file():
                    file_path.unlink()


def auto_train_model():
    valid_extensions = {
        ".jpg",
        ".jpeg",
        ".png",
        ".ppm",
        ".bmp",
        ".pgm",
        ".tif",
        ".tiff",
        ".webp",
    }

    # Verify if there are any valid training images at all
    has_images = any(
        f.suffix.lower() in valid_extensions for f in TRAIN_DIR.rglob("*")
    )

    if not has_images:
        st.warning(
            "⚠️ No training images found. Please reclassify some documents first."
        )
        return False

    # Safely load datasets while skipping empty subdirectories
    try:
        dataset = datasets.ImageFolder(
            root=str(TRAIN_DIR), transform=transform, allow_empty=True
        )
    except TypeError:
        dataset = datasets.ImageFolder(
            root=str(TRAIN_DIR), transform=transform
        )

    if len(dataset) == 0:
        st.warning("⚠️ Training directory contains no valid samples.")
        return False

    dataloader = DataLoader(dataset, batch_size=8, shuffle=True)
    class_names = dataset.classes

    with open(CLASSES_PATH, "w") as f:
        f.write("\n".join(class_names))

    try:
        model_train = models.mobilenet_v3_small(
            weights=models.MobileNet_V3_Small_Weights.DEFAULT
        )
    except AttributeError:
        model_train = models.mobilenet_v3_small(pretrained=True)

    num_features = model_train.classifier[3].in_features
    model_train.classifier[3] = nn.Linear(num_features, len(class_names))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_train = model_train.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model_train.parameters(), lr=0.001)

    model_train.train()
    for epoch in range(5):
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model_train(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

    torch.save(model_train.state_dict(), MODEL_PATH)

    # Cleanup cached training image files after model checkpoint is saved
    clear_training_data()

    st.cache_resource.clear()
    return True


@st.cache_resource
def load_classifier():
    if not MODEL_PATH.exists() or not CLASSES_PATH.exists():
        return None, None, "MISSING"

    with open(CLASSES_PATH, "r") as f:
        classes = [line.strip() for line in f.readlines()]

    model = models.mobilenet_v3_small(weights=None)
    num_features = model.classifier[3].in_features
    model.classifier[3] = nn.Linear(num_features, len(classes))

    try:
        model.load_state_dict(
            torch.load(MODEL_PATH, map_location=torch.device("cpu"))
        )
        model.eval()
        return model, classes, "OK"
    except RuntimeError:
        return None, None, "MISMATCH"


def save_page_as_jpeg(page, output_path):
    pix = page.get_pixmap(matrix=pymupdf.Matrix(2, 2), alpha=False)
    pix.save(str(output_path))


def classify_image(image_path, model, class_names):
    img = Image.open(image_path).convert("RGB")
    tensor_img = transform(img).unsqueeze(0)

    with torch.no_grad():
        outputs = model(tensor_img)
        probabilities = F.softmax(outputs, dim=1)
        confidence, pred_idx = torch.max(probabilities, 1)

    predicted_label = class_names[pred_idx[0].item()]
    confidence_score = confidence[0].item()

    return predicted_label, confidence_score


@st.dialog("📄 Full Page Document View", width="large")
def show_fullpage_modal(image_path):
    st.image(str(image_path), width="stretch")
    st.caption(f"Filename: `{Path(image_path).name}`")


def check_pdf_status(pdf_path, confirmed_set):
    doc = pymupdf.open(str(pdf_path))
    total_pages = len(doc)
    doc.close()

    existing_jpegs = 0
    classified_jpegs = 0
    all_target_dirs = [JPEG_DIR, INVOICE_DIR, EWAY_DIR, BILTY_DIR, OTHERS_DIR]

    for page_idx in range(1, total_pages + 1):
        jpeg_name = f"{pdf_path.stem}_page_{page_idx}.jpg"
        for folder in all_target_dirs:
            if (folder / jpeg_name).exists():
                existing_jpegs += 1
                if jpeg_name in confirmed_set:
                    classified_jpegs += 1
                break

    is_extracted = existing_jpegs == total_pages
    is_fully_classified = (
        classified_jpegs == total_pages if total_pages > 0 else False
    )

    return total_pages, is_extracted, is_fully_classified


def get_folder_images(folder_path):
    return sorted(
        list(folder_path.glob("*.jpg")) + list(folder_path.glob("*.jpeg"))
    )


# --- APP INTERFACE ---
st.title("📄 PDF Intelligent Document Classifier")

# Check Model Status
model, class_names, model_status = load_classifier()

if model_status in ["MISMATCH", "MISSING"]:
    st.info(
        "💡 Ready to update AI classes! Click below to retrain the model with current categories."
    )
    if st.button("🔄 Retrain Model", type="primary"):
        with st.spinner("Training model & cleaning temporary files..."):
            if auto_train_model():
                st.success("Model retrained and temporary files cleared!")
                st.rerun()

tab1, tab2, tab3 = st.tabs(
    [
        "🚀 File Inspection & Pipeline",
        "🔍 Sticky Review & Batch Classify",
        "📊 Folder Status",
    ]
)

# --- TAB 1: INPUT FILE INSPECTION ---
with tab1:
    st.header("Step 1: Input Folder Overview & Extraction")

    uploaded_files = st.file_uploader(
        "Upload PDFs directly to 'Input' folder",
        type=["pdf"],
        accept_multiple_files=True,
    )

    if uploaded_files:
        for uploaded_file in uploaded_files:
            save_path = INPUT_DIR / uploaded_file.name
            with open(save_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
        st.success(f"Saved {len(uploaded_files)} PDF(s) to Input folder.")

    pdf_files = sorted(list(INPUT_DIR.glob("*.pdf")))
    confirmed_set = load_confirmed_set()

    if pdf_files:
        st.subheader("📋 Files Found in 'Input' Directory")

        pdf_grid_data = []
        for pdf_file in pdf_files:
            pages, is_extracted, is_classified = check_pdf_status(
                pdf_file, confirmed_set
            )
            pdf_grid_data.append(
                {
                    "PDF Name": pdf_file.name,
                    "Total Pages": pages,
                    "JPEG Converted": "✅ Yes" if is_extracted else "❌ No",
                    "Manually Classified": (
                        "✅ Full"
                        if is_classified
                        else (
                            "⚠️ Partial/Pending"
                            if is_extracted
                            else "⏳ Unprocessed"
                        )
                    ),
                }
            )

        st.dataframe(pdf_grid_data, width="stretch")

        if st.button(
            "🚀 Run Stage 1 (Extract & Classify New PDFs)", type="primary"
        ):
            if model is None:
                st.error(
                    "Please retrain the model first using the button above."
                )
            else:
                progress_bar = st.progress(0)
                ai_predictions = load_json_log(AI_PREDICTIONS_LOG)

                for idx, pdf_file in enumerate(pdf_files):
                    pages, is_extracted, _ = check_pdf_status(
                        pdf_file, confirmed_set
                    )

                    if is_extracted:
                        st.write(
                            f"⏭️ Skipping `{pdf_file.name}` (Already converted to JPEGs)"
                        )
                        progress_bar.progress((idx + 1) / len(pdf_files))
                        continue

                    doc = pymupdf.open(str(pdf_file))
                    total_pages = len(doc)

                    for page_index in range(total_pages):
                        page = doc[page_index]
                        jpeg_name = f"{pdf_file.stem}_page_{page_index + 1}.jpg"
                        jpeg_path = JPEG_DIR / jpeg_name

                        save_page_as_jpeg(page, jpeg_path)
                        category, confidence = classify_image(
                            jpeg_path, model, class_names
                        )

                        target_dir = JPEG_DIR
                        assigned_folder_key = "JPEG"

                        if confidence >= CONFIDENCE_THRESHOLD:
                            category_lower = category.lower()

                            if "invoice" in category_lower:
                                target_dir = INVOICE_DIR
                                assigned_folder_key = "Invoice"
                            elif "eway" in category_lower:
                                target_dir = EWAY_DIR
                                assigned_folder_key = "Eway"
                            elif "bilty" in category_lower:
                                target_dir = BILTY_DIR
                                assigned_folder_key = "Bilty"
                            else:
                                target_dir = OTHERS_DIR
                                assigned_folder_key = "Others"

                            shutil.move(
                                str(jpeg_path), str(target_dir / jpeg_name)
                            )

                        ai_predictions[jpeg_name] = assigned_folder_key

                    doc.close()
                    progress_bar.progress((idx + 1) / len(pdf_files))

                save_json_log(AI_PREDICTIONS_LOG, ai_predictions)
                st.success("Processing complete!")
                st.rerun()
    else:
        st.info("No PDF files found in Input folder.")

# --- TAB 2: STICKY REVIEW & BATCH CLASSIFY ---
with tab2:
    folder_map = {
        "Invoice Folder": INVOICE_DIR,
        "Eway Folder": EWAY_DIR,
        "Bilty Folder": BILTY_DIR,
        "Others Folder": OTHERS_DIR,
        "Unclassified (JPEG Folder)": JPEG_DIR,
    }

    folder_to_pill = {
        "Invoice Folder": "Invoice",
        "Eway Folder": "Eway",
        "Bilty Folder": "Bilty",
        "Others Folder": "Others",
    }

    confirmed_set = load_confirmed_set()

    # Pre-calculate Total, Confirmed, and Unconfirmed counts for each folder
    folder_counts = {}
    for name, path in folder_map.items():
        imgs = get_folder_images(path)
        total_count = len(imgs)
        confirmed_count = sum(1 for img in imgs if img.name in confirmed_set)
        unconfirmed_count = total_count - confirmed_count

        folder_counts[name] = {
            "total": total_count,
            "confirmed": confirmed_count,
            "unconfirmed": unconfirmed_count,
        }

    # Sticky bar container
    with st.container():
        st.markdown(
            '<div class="sticky-bar-marker"></div>', unsafe_allow_html=True
        )

        col_folder, col_items_row, col_filter, col_save, col_retrain = (
            st.columns([3, 1, 1.8, 2, 1])
        )

        with col_filter:
            show_unconfirmed_only = st.checkbox(
                "Show Pending Only", value=True
            )

        with col_folder:
            selected_folder_name = st.selectbox(
                "Select Folder:",
                options=list(folder_map.keys()),
                format_func=lambda name: f"{name} (Total: {folder_counts[name]['total']} | Confirmed: {folder_counts[name]['confirmed']} | Unconfirmed: {folder_counts[name]['unconfirmed']})",
                label_visibility="collapsed",
            )

        with col_items_row:
            cols_per_row = st.selectbox(
                "Items/Row:",
                options=[2, 3, 4, 5, 6],
                index=2,
                label_visibility="collapsed",
            )

        with col_save:
            if st.button(
                "💾 Save & Apply All Changes", type="primary", width="stretch"
            ):
                moved_count = 0

                for img_name, selected_cat in list(
                    st.session_state.pending_selections.items()
                ):
                    if selected_cat == "To Be Confirmed":
                        confirmed_set.add(img_name)
                        moved_count += 1
                        continue

                    src_file = folder_map[selected_folder_name] / img_name
                    if not src_file.exists():
                        continue

                    if selected_cat == "Invoice":
                        target_out_dir = INVOICE_DIR
                        target_train_dir = TRAIN_DIR / "Invoice"
                    elif selected_cat == "Eway":
                        target_out_dir = EWAY_DIR
                        target_train_dir = TRAIN_DIR / "Eway"
                    elif selected_cat == "Bilty":
                        target_out_dir = BILTY_DIR
                        target_train_dir = TRAIN_DIR / "Bilty"
                    else:
                        target_out_dir = OTHERS_DIR
                        target_train_dir = TRAIN_DIR / "Others"

                    target_train_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_file, target_train_dir / img_name)

                    if target_out_dir != folder_map[selected_folder_name]:
                        shutil.move(
                            str(src_file), str(target_out_dir / img_name)
                        )

                    confirmed_set.add(img_name)
                    moved_count += 1

                save_confirmed_set(confirmed_set)
                st.session_state.pending_selections.clear()
                st.success(f"Saved & confirmed {moved_count} items!")
                st.rerun()

        with col_retrain:
            if st.button("🧠 Retrain Model", width="stretch"):
                with st.spinner("Training model & cleaning temporary files..."):
                    if auto_train_model():
                        st.toast(
                            "Model fine-tuned and training storage cleaned!",
                            icon="✅",
                        )

    current_dir = folder_map[selected_folder_name]
    image_files = get_folder_images(current_dir)

    if show_unconfirmed_only:
        image_files = [
            img for img in image_files if img.name not in confirmed_set
        ]

    if not image_files:
        st.info(
            f"No matching image files found in '{selected_folder_name}'."
        )
    else:
        st.write(f"Showing **{len(image_files)}** file(s):")

        for i in range(0, len(image_files), cols_per_row):
            cols = st.columns(cols_per_row)
            row_images = image_files[i : i + cols_per_row]

            for idx, img_path in enumerate(row_images):
                with cols[idx]:
                    with st.container(border=True):
                        st.image(str(img_path), width="stretch")
                        st.caption(f"`{img_path.name[:20]}...`")

                        if st.button(
                            "🔍 Fullpage",
                            key=f"modal_{img_path.name}",
                            width="stretch",
                        ):
                            show_fullpage_modal(img_path)

                        # Dynamic pill highlight rule
                        is_confirmed = img_path.name in confirmed_set
                        if is_confirmed:
                            default_pill = folder_to_pill.get(
                                selected_folder_name, "To Be Confirmed"
                            )
                        else:
                            default_pill = "To Be Confirmed"

                        selected_option = st.pills(
                            label="Assign Category",
                            options=[
                                "To Be Confirmed",
                                "Invoice",
                                "Eway",
                                "Bilty",
                                "Others",
                            ],
                            default=default_pill,
                            key=f"pills_{img_path.name}",
                            label_visibility="collapsed",
                        )

                        if selected_option and selected_option != default_pill:
                            st.session_state.pending_selections[
                                img_path.name
                            ] = selected_option

# --- TAB 3: FOLDER STATISTICS & AI TOOL SUCCESS RATIO ---
with tab3:
    st.header("Folder Statistics & Manual Confirmation Progress")

    input_pdfs = len(list(INPUT_DIR.glob("*.pdf")))

    invoice_imgs = get_folder_images(INVOICE_DIR)
    eway_imgs = get_folder_images(EWAY_DIR)
    bilty_imgs = get_folder_images(BILTY_DIR)
    others_imgs = get_folder_images(OTHERS_DIR)
    jpeg_imgs = get_folder_images(JPEG_DIR)

    all_current_images = (
        invoice_imgs + eway_imgs + bilty_imgs + others_imgs + jpeg_imgs
    )
    all_current_filenames = {img.name for img in all_current_images}

    # Automatically purge deleted/stale filenames
    confirmed_set_raw = load_confirmed_set()
    confirmed_set = confirmed_set_raw.intersection(all_current_filenames)

    if len(confirmed_set) != len(confirmed_set_raw):
        save_confirmed_set(confirmed_set)

    ai_predictions = load_json_log(AI_PREDICTIONS_LOG)

    # Per-folder current location map
    img_current_folder = {}
    for img in invoice_imgs:
        img_current_folder[img.name] = "Invoice"
    for img in eway_imgs:
        img_current_folder[img.name] = "Eway"
    for img in bilty_imgs:
        img_current_folder[img.name] = "Bilty"
    for img in others_imgs:
        img_current_folder[img.name] = "Others"
    for img in jpeg_imgs:
        img_current_folder[img.name] = "JPEG"

    # Compute AI Success Metrics on Confirmed Files
    ai_correct_count = 0
    total_evaluated_ai = 0

    for fname in confirmed_set:
        initial_ai_pred = ai_predictions.get(fname)
        current_loc = img_current_folder.get(fname)

        if initial_ai_pred and current_loc:
            total_evaluated_ai += 1
            if initial_ai_pred == current_loc:
                ai_correct_count += 1

    tool_success_ratio = (
        (ai_correct_count / total_evaluated_ai * 100)
        if total_evaluated_ai > 0
        else 100.0
    )

    # Calculate per-folder manual confirmed counts
    invoice_confirmed = sum(
        1 for img in invoice_imgs if img.name in confirmed_set
    )
    eway_confirmed = sum(1 for img in eway_imgs if img.name in confirmed_set)
    bilty_confirmed = sum(1 for img in bilty_imgs if img.name in confirmed_set)
    others_confirmed = sum(
        1 for img in others_imgs if img.name in confirmed_set
    )

    total_images = len(all_current_images)
    total_confirmed = len(confirmed_set)
    confirmation_ratio = (
        (total_confirmed / total_images * 100) if total_images > 0 else 0
    )

    # Row 1: Total Directory Breakdown
    st.subheader("📁 Directory File Breakdown")
    r1_c1, r1_c2, r1_c3, r1_c4, r1_c5, r1_c6 = st.columns(6)
    r1_c1.metric("Input PDFs", input_pdfs)
    r1_c2.metric("Invoice Folder", len(invoice_imgs))
    r1_c3.metric("E-Way Bills Folder", len(eway_imgs))
    r1_c4.metric("Bilty Folder", len(bilty_imgs))
    r1_c5.metric("Others Folder", len(others_imgs))
    r1_c6.metric("Unclassified (JPEG)", len(jpeg_imgs))

    st.divider()

    # Row 2: Per-Folder Manual Confirmation Progress
    st.subheader("✅ Manually Confirmed Items per Folder")
    r2_c1, r2_c2, r2_c3, r2_c4, r2_c5, r2_c6 = st.columns(6)
    r2_c1.metric(
        "Invoices Confirmed", f"{invoice_confirmed} / {len(invoice_imgs)}"
    )
    r2_c2.metric("E-Way Confirmed", f"{eway_confirmed} / {len(eway_imgs)}")
    r2_c3.metric("Bilty Confirmed", f"{bilty_confirmed} / {len(bilty_imgs)}")
    r2_c4.metric(
        "Others Confirmed", f"{others_confirmed} / {len(others_imgs)}"
    )
    r2_c5.metric("Total Confirmed", f"{total_confirmed} / {total_images}")
    r2_c6.metric(
        "Overall Progress",
        f"{confirmation_ratio:.1f}%",
        delta=f"{total_confirmed}/{total_images} items",
    )

    st.divider()

    # Row 3: AI Model Initial Classification Accuracy (Success Ratio)
    st.subheader("🤖 AI Classification Tool Performance")
    r3_c1, r3_c2, r3_c3, r3_c4 = st.columns(4)
    r3_c1.metric("Evaluated Verified Items", total_evaluated_ai)
    r3_c2.metric("AI Predictions Unchanged", ai_correct_count)
    r3_c3.metric(
        "User Reclassified Items", total_evaluated_ai - ai_correct_count
    )
    r3_c4.metric(
        "Tool Success Ratio",
        f"{tool_success_ratio:.1f}%",
        delta=f"{ai_correct_count}/{total_evaluated_ai} correct AI predictions",
    )