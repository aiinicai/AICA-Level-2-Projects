@echo off
title Launch Document Classifier Web Dashboard
cd /d "%~dp0"
echo Starting Web Interface...
python -m streamlit run app.py --server.port 8502
pause