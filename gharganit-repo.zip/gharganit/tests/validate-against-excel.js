/*
 * Validates the engine against values Excel itself calculated in
 * RealEstateDecisionSuite_v3_08Mar26.xlsx (sample data).
 * Run: node tests/validate-against-excel.js
 */
const E = require('../js/engine.js');
const st = E.sampleState();
const out = E.runAll(st);
const M = E.M;

let pass = 0, fail = 0;
function check(label, got, want, tol) {
  tol = tol === undefined ? 0.5 : tol;
  const ok = typeof want === 'string' ? got === want : Math.abs(got - want) <= tol;
  if (ok) pass++; else fail++;
  console.log((ok ? 'PASS ' : 'FAIL ') + label.padEnd(48) + ' got ' + got + '   excel ' + want);
}

// Simple ROE sheet
check('Simple ROE', out.simpleROE.roe, 0.5, 1e-9);
check('Annualised ROE (CAGR)', out.simpleROE.cagr, 0.084471771197698553, 1e-6);

// Tranche Payments without Loan
check('Self-funded XIRR', out.selfFunded.xirr, 0.13826461434364321, 1e-7);

// Equity + Loan
const el = out.equityLoan;
check('Total loan', el.totalLoan, 6400000);
check('Total interest (interest-only)', el.totalInterest, 1069391.3757700205, 0.01);
check('Net sale proceeds', el.netSale, 4530608.624229979, 0.01);
check('Equity XIRR', el.equityXIRR, 0.23128276467323308, 1e-7);
check('Property XIRR', el.propertyXIRR, 0.1382646143436432, 1e-7);
check('Simple equity ROE', el.equityROE, 1.8316303901437367, 1e-9);

// Rental Scenario
const r = out.rental;
check('Schedule start', M.str(r.start), '2026-02');
check('Effective loan end', M.str(r.effEnd), '2050-01');
check('Cumulative rent minus EMI', r.cumNetRentMinusEMI, 1288775.0854552835, 0.01);
check('Property value at end', r.valueEnd, 29066585.24929572, 0.01);
check('Loan balance at end', r.loanEndBal, 0, 0.001);
check('Equity at end', r.equityEnd, 29066585.24929571, 0.01);
check('RD balance', r.spare.rd, 3275884.1467470257, 0.01);
check('FD balance', r.spare.fd, 3737548.4183739205, 0.01);
check('MF balance', r.spare.mf, 4740702.15279224, 0.01);
check('Foreclosure month', M.str(r.foreclosure.k), '2046-09');
check('Foreclosure in months', r.foreclosure.months, 247, 0);
check('ROE on equity', r.roeOnEquity, 17.16661578080982, 1e-9);
check('Equity XIRR over projection', r.equityXIRR, 0.12880759835243225, 1e-7);
check('OD interest saved', r.od.interestSaved, 841773.5257389455, 0.01);
check('OD payoff months', r.od.months, 254, 0);
check('Base payoff months', r.od.baseMonths, 276, 0);
check('Months saved due to OD', r.od.monthsSaved, 22, 0);
check('OD foreclosure date', M.str(r.od.odDate), '2048-03');

check('All-in XIRR (app addition, regression)', r.allInXIRR, 0.11405952476038926, 1e-6);

// Spot-check monthly rows
const row = (s) => r.rows.find((x) => M.str(x.k) === s);
check('Jun 2030 EMI', row('2030-06').D, 49619.13, 0.01);
check('Jun 2030 interest', row('2030-06').E, 37044.15, 0.01);
check('Feb 2031 EMI (after rate cut)', row('2031-02').D, 48508.14, 0.01);
check('Oct 2032 rent', row('2032-10').C, 38587.5, 0.01);
check('Year 24 rent', r.annual[23].rent, 1048684, 1);

// Leverage Optimiser
const lv = out.leverage.rows;
check('Leverage 20% EMI', lv[1].emi, 50390.355, 0.01);
check('Leverage 15% months Rent>EMI', lv[0].monthsToEMI, 105, 0);
check('Leverage 25% months Rent>Interest', lv[2].monthsToInterest, 7, 0);

// Scenarios & Stress Test
const sc = out.scenarios;
check('Scenario EMI', sc.keys.emi, 50390.3551, 0.001);
check('Months Rent>Interest', sc.keys.monthsToInterest, 36, 0);
check('Months Rent>EMI', sc.keys.monthsToEMI, 103, 0);
check('Grid EMI -20% rent / +2% rate', sc.gridEMI[2][2], 194, 0);
check('Grid outflow -10% / +1%', sc.gridOutflow[1][1], 24406.5142, 0.001);

// Compare Plans
const cp = out.plans;
check('Plan A PV total', cp.plans[0].pvTotal, 7454974.2060525641, 0.5);
check('Plan B PV total', cp.plans[1].pvTotal, 7355977.2113632094, 0.5);
check('Plan C PV total', cp.plans[2].pvTotal, 7559347.438703482, 0.5);
check('Recommended plan', cp.best, 'Plan B');
check('Savings vs next best', cp.savings, 98996.994689354673, 0.5);

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
