# How GharGanit calculates

Every number in the app comes from `js/engine.js`. Each function mirrors one sheet of `RealEstateDecisionSuite_v3_08Mar26.xlsx`. Cell references are noted in the code beside the matching line.

All dates are normalised to the 1st of the month, as in the workbook. Internally a date is a "month key" (`year × 12 + month − 1`). Day counts, where the workbook uses them, are taken between those 1st-of-month dates.

## Shared building blocks

| Workbook function | Engine | Notes |
|---|---|---|
| `PMT` | `pmt(rate, n, pv)` | Returns the positive EMI |
| `XIRR` | `xirr(cashflows, months)` | Newton's method, bisection fallback, 365-day year as Excel |
| `YEARFRAC(a, b, 1)` | `yearFrac(a, b)` | Actual/actual, Excel's basis 1 rules |
| `DATEDIF(a, b, "m")` | `b − a` on month keys | |
| `EDATE(a, n)` | `a + n` on month keys | |

## Property Data and Equity + Loan

`tranches(state)` returns each payment with its month, amount and whether it was own money (Equity) or bank money (Loan).

`equityLoan(state)`:

| Output | Excel | Formula |
|---|---|---|
| Interest per loan tranche | F14:F28 | Σ over rate periods of amount × rate × days(max(tranche, period start), min(accrual end, period end)) ÷ 365.25 |
| Total loan | B29 | Σ loan tranches |
| Total interest | B33 | Σ F |
| Net sale proceeds | B34 | Sale price − total interest − total loan |
| Equity XIRR | C56 | Own-money tranches out, net sale proceeds in |
| Property XIRR | C57 | All tranches out, gross sale price in |
| Simple property ROE | C58 | (Sale − purchase) ÷ purchase |
| Simple equity ROE | C59 | (Net sale − own money) ÷ own money |

## Interest Rates

`rateSchedule(state)`. The first row always starts on the loan start date. Each period ends the month before the next starts (`EDATE(next, −1)`). The last period ends on the interest accrual end date: the earlier of the sale date and the loan end date (C6).

`rateAt(schedule, month)` reproduces column AM of Rental Scenario: before the first start, use the first rate; otherwise the last period that has started (`LOOKUP`).

## Rental Scenario

`rental(state)` builds the monthly schedule. One object per month, with the workbook's column letters as property names.

| Column | Meaning | Rule |
|---|---|---|
| A | Month | Schedule start (F11: earliest tranche) + i |
| B | Rate | `rateAt` |
| C | Rent | From rent start to rent end: rent × (1 + increase)^⌊months since rent start ÷ 12⌋ |
| T, U | Loan disbursed to date, this month | Σ loan tranches |
| G | Balance start | Previous H + U |
| D | EMI | 0 if no balance or past loan end. Interest-only (G × B ÷ 12) before the EMI start date. Otherwise `PMT(B/12, months left, G)`, recalculated when money is disbursed, at the EMI start, and on a rate change if "EMI is recalculated" is selected; else carried forward |
| E | Interest | G × B ÷ 12 |
| F | Principal | max(0, min(G, D − E)) |
| H | Balance end | max(0, G − F) |
| V | Spare rent | max(0, C − D) |
| W, X, Y | RD, FD, MF pots | previous × (1 + rate ÷ 12) + V |
| Z to AE | Prepayment schedule | As H, but spare rent V is paid as extra principal; AE flags the month the balance hits 0 |
| AH | Own money paid | Σ equity tranches in the month |
| AF | Equity cash flow for XIRR | −AH, plus equity at end in the final month |
| AI | Overdraft money parked | Deposits − withdrawals to date |
| AT | EMI for the overdraft schedule | As D but never recalculated on a rate change |
| AQ, AL, AJ, AR, AS | Overdraft loan | Balance start, balance net of parked money, overdraft interest, principal, balance end |
| AO | Interest saved | E − AJ |

Effective loan end (F12): with "From possession", the tenure is shifted to start at possession (possession + months between loan start and loan end). With "From loan start", it's the loan end.

Outputs:

| Output | Excel |
|---|---|
| Cumulative rent − EMI | N4 |
| Property value at end: value at possession × (1 + growth)^YEARFRAC(possession, last month) | N6 |
| Loan balance at end | N7 |
| Equity at end | N5 |
| RD, FD, MF at end | J4, J5, J6 |
| Foreclosure month and months | J7, J8 |
| ROE on equity: equity at end ÷ own money − 1 | J9 |
| Equity XIRR over the projection | J10 |
| Overdraft interest saved, payoff months, base months, months saved, dates | N8 to N13 |

Added by the app (not in the workbook, clearly labelled on screen):

- `net` per month: rent − EMI − own money paid. The "your pocket" column.
- `allInXIRR`: XIRR on every month's `net`, plus equity at the end.
- Phase per month (before the loan, pre-EMI, top-up, rent covers EMI, loan-free) and milestones, used for the plain-language story.

## Leverage Optimiser

`leverage(state)`. For own-money shares from 15% to 100% in steps of 5%: loan = value × (1 − share); interest at start = loan × rate ÷ 12; EMI = `PMT(rate/12, tenure, loan)`; months until rent beats a target = ⌈12 × ln(target ÷ rent) ÷ ln(1 + rent growth)⌉. The "sweet spot" is the first share where EMI − rent ≤ 0.

## Scenarios & Stress Test

`scenarios(state)`. Net rent = rent × (1 + rent shock) × (1 − vacancy). Rate = base rate + interest shock. EMI on the full loan and the original tenure. Months to cover interest (E15) and EMI (E16) use the scenario's rent escalation. Grids repeat the calculation for rent shocks 0, −10%, −20% and rate shocks 0, +1%, +2%.

## Compare Plans

`comparePlans(plans)`. Amount used = amount if given, else % × price. PV of a payment = amount ÷ (1 + discount rate)^YEARFRAC(base, date). PV of loan interest = amount × loan rate × YEARFRAC(date, possession) ÷ (1 + discount rate)^YEARFRAC(base, possession). Lowest PV total is recommended; savings = second lowest − lowest.

## Simple ROE and Tranche Payments without Loan

ROE = (sell − buy) ÷ buy. CAGR = (sell ÷ buy)^(1 ÷ years) − 1. Holding period defaults to months from first payment to sale ÷ 12 (5.00 years for the sample, matching the workbook's typed 5). Self-funded XIRR uses all tranches out and the sale in.

## Differences from the workbook

| # | Workbook behaviour | App behaviour | Effect on the sample |
|---|---|---|---|
| 1 | Rental Scenario equity XIRR (J10) counts only upfront own money and end equity | Shown as "Excel method". The app adds an all-in XIRR including top-ups and spare rent | 12.9% (Excel) vs 11.4% (all-in) |
| 2 | Rate periods end the month before the next starts, so one month of interest is skipped at each rate change (Equity + Loan F column) | Reproduced, so results reconcile | Interest understated by ₹55,721 |
| 3 | Annual summary column S compounds value from year 1, even before possession | Yearly value grows from possession, consistent with N6 | Year 24 value ₹2.91 Cr instead of ₹3.55 Cr |
| 4 | Scenario vacancy is fixed at 5% (B18 typed in); appreciation and selling cost aren't used | Vacancy follows the chosen scenario; appreciation and selling cost give an exit value | Same result for Base |
| 5 | Compare Plans possession dates are typed in, though labelled "auto" | Editable; blank = last payment month | Same result |
| 6 | Leverage Optimiser inputs (D5:D8) are typed in, though labelled "linked" | Linked to your property's price, rent, growth and first rate | Same result for the sample |
| 7 | Rental end month (F6) is a typed date, while C8 ("Rental End Date") is blank | One optional "Rent stops" input | Same result |

## Verifying

`node tests/validate-against-excel.js` checks 45 values against Excel's cached results and one regression value for the all-in XIRR.
