/*
 * Bundles the app into one self-contained HTML file (dist/gharganit.html)
 * that you can email, host anywhere, or open offline (charts and font
 * still load from their CDNs when online).
 * Run: node scripts/build-single-file.js
 */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

let html = read('index.html');
html = html.replace('<link rel="stylesheet" href="css/styles.css">', () => '<style>\n' + read('css/styles.css') + '\n</style>');
['js/config.js', 'js/engine.js', 'js/app.js'].forEach((f) => {
  html = html.replace(`<script src="${f}"></script>`, () => '<script>\n' + read(f).replace(/<\/script>/gi, '<\\/script>') + '\n</script>');
});
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
const out = path.join(root, 'dist', 'gharganit.html');
fs.writeFileSync(out, html);
console.log('Built ' + out + ' (' + Math.round(html.length / 1024) + ' KB)');
