/*
 * GharGanit: user interface
 * All numbers come from js/engine.js. This file only collects inputs,
 * renders results and explains them in plain language.
 */
(function () {
  'use strict';

  const E = window.REEngine;
  const M = E.M;
  const CFG = window.APP_CONFIG || {};
  const MON = CFG.monetization || {};
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const YEARS = []; for (let y = 2000; y <= 2080; y++) YEARS.push(y);
  const TODAY = M.today();

  /* ================================================================ */
  /* Formatting                                                        */
  /* ================================================================ */
  const INR = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });
  const DASH = '–';
  const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ok = (v) => v !== null && v !== undefined && isFinite(v);
  const rs = (v) => (!ok(v) ? DASH : (v < -0.5 ? '−' : '') + '₹' + INR.format(Math.round(Math.abs(v))));
  const short = (v) => {
    if (!ok(v)) return DASH;
    const a = Math.abs(v), s = v < -0.5 ? '−' : '';
    if (a >= 1e7) return s + '₹' + (a / 1e7).toFixed(2) + ' Cr';
    if (a >= 1e5) return s + '₹' + (a / 1e5).toFixed(a >= 1e6 ? 1 : 2) + ' L';
    return s + '₹' + INR.format(Math.round(a));
  };
  const pct = (v, d) => (!ok(v) ? DASH : (v * 100).toFixed(d === undefined ? 1 : d) + '%');
  const ml = (k) => (k === null || k === undefined ? DASH : M.label(k));
  const dur = (m) => {
    if (m === null || m === undefined) return DASH;
    if (typeof m === 'string') return m;
    if (m <= 0) return 'now';
    const y = Math.floor(m / 12), mo = m % 12;
    const parts = [];
    if (y) parts.push(y + (y === 1 ? ' year' : ' years'));
    if (mo) parts.push(mo + (mo === 1 ? ' month' : ' months'));
    return parts.join(' ');
  };
  const durS = (m) => {
    if (m === null || m === undefined) return 'never';
    if (m <= 0) return 'now';
    const y = Math.floor(m / 12), mo = m % 12;
    return (y ? y + 'y ' : '') + (mo ? mo + 'm' : '').trim();
  };
  const rel = (k) => {
    if (k === null || k === undefined) return '';
    const d = k - TODAY;
    if (d === 0) return 'this month';
    return d > 0 ? 'in ' + dur(d) : dur(-d) + ' ago';
  };
  const tip = (t) => `<button type="button" class="tip" title="${esc(t)}" aria-label="${esc(t)}">?</button>`;
  const css = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();

  /* ================================================================ */
  /* Storage (browser only, never leaves the device)                   */
  /* ================================================================ */
  const KEY = 'gharganit:v1';
  const uid = () => 'p' + Math.random().toString(36).slice(2, 9);

  function merge(base, extra) {
    if (Array.isArray(base)) return Array.isArray(extra) ? extra : base;
    if (base && typeof base === 'object') {
      const out = {};
      Object.keys(base).forEach((k) => { out[k] = extra && k in extra ? merge(base[k], extra[k]) : base[k]; });
      if (extra && typeof extra === 'object') Object.keys(extra).forEach((k) => { if (!(k in out)) out[k] = extra[k]; });
      return out;
    }
    return extra === undefined ? base : extra;
  }
  const withDefaults = (st) => merge(E.sampleState(), st || {});

  function loadDB() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const d = JSON.parse(raw);
        if (d && d.properties && Object.keys(d.properties).length) {
          Object.keys(d.properties).forEach((id) => { d.properties[id] = withDefaults(d.properties[id]); });
          if (!d.properties[d.active]) d.active = Object.keys(d.properties)[0];
          return d;
        }
      }
    } catch (e) { /* storage blocked or corrupt: start fresh */ }
    const id = uid();
    return { active: id, properties: { [id]: E.sampleState() }, pro: null, theme: 'auto', ui: {} };
  }
  let DB = loadDB();
  let S = DB.properties[DB.active];
  let OUT = null;
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(DB)); } catch (e) { /* ignore */ } }
  function recompute() {
    try { OUT = E.runAll(S); } catch (e) { console.error(e); OUT = null; }
  }

  /* ================================================================ */
  /* Paid tier                                                         */
  /* ================================================================ */
  const isPro = () => !MON.enabled || !!(DB.pro && DB.pro.valid);
  const needsPro = (feature) => !!(MON.enabled && feature && (MON.proFeatures || []).indexOf(feature) >= 0 && !isPro());
  const track = (ev, props) => { try { CFG.track && CFG.track(ev, props || {}); } catch (e) { /* ignore */ } };

  async function validateKey(key) {
    key = (key || '').trim();
    if (!key) return null;
    if (MON.licenseApiUrl) {
      try {
        const r = await fetch(MON.licenseApiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key }) });
        const j = await r.json();
        return j && j.valid ? { valid: true, key, plan: j.plan || 'pro', expires: j.expires || null, at: Date.now() } : null;
      } catch (e) { return null; }
    }
    return (MON.demoKeys || []).indexOf(key) >= 0 ? { valid: true, key, plan: 'pro', expires: null, at: Date.now() } : null;
  }

  /* ================================================================ */
  /* Navigation                                                        */
  /* ================================================================ */
  const NAV = [
    { group: 'Your property', items: [
      { id: 'overview', label: 'Overview' },
      { id: 'setup', label: 'Set up your property' },
      { id: 'cashflow', label: 'Monthly cash flow' },
      { id: 'explain', label: 'Explain it simply', pro: 'explainScript' }
    ] },
    { group: 'Decide', items: [
      { id: 'returns', label: 'Returns' },
      { id: 'plans', label: 'Compare payment plans', pro: 'comparePlans' },
      { id: 'leverage', label: 'Loan vs own money', pro: 'leverage' },
      { id: 'whatif', label: 'What if? Stress test', pro: 'whatIf' }
    ] },
    { group: 'Make the most of it', items: [
      { id: 'spare', label: 'Spare rent & prepaying', pro: 'spareMoney' },
      { id: 'od', label: 'Overdraft home loan', pro: 'overdraft' }
    ] },
    { group: 'Help', items: [
      { id: 'learn', label: 'Jargon buster' },
      { id: 'data', label: 'Save, export, reset' }
    ].concat(MON.enabled ? [{ id: 'upgrade', label: 'Upgrade to Pro' }] : []) }
  ];
  const ALL = NAV.reduce((a, g) => a.concat(g.items), []);
  let current = 'overview';

  function renderSide() {
    const side = document.getElementById('side');
    side.innerHTML = `
      <div class="brand"><div class="brand-mark" aria-hidden="true">₹</div>
        <div><div class="brand-name">${esc(CFG.appName || 'GharGanit')}</div><div class="brand-tag">${esc(CFG.tagline || '')}</div></div></div>
      ${NAV.map((g) => `<nav class="nav-group" aria-label="${esc(g.group)}"><div class="nav-title">${esc(g.group)}</div>
        ${g.items.map((it) => `<button class="nav-btn" data-go="${it.id}" ${it.id === current ? 'aria-current="page"' : ''}>
          <span>${esc(it.id === 'upgrade' && isPro() ? 'Your Pro licence' : it.label)}</span>${needsPro(it.pro) ? '<span class="lock">Pro</span>' : ''}</button>`).join('')}
      </nav>`).join('')}
      <div class="side-foot">Your numbers stay in this browser. Nothing is uploaded.</div>`;
  }

  function renderTop() {
    const props = Object.keys(DB.properties);
    const theme = DB.theme || 'auto';
    document.getElementById('topbar').innerHTML = `
      <button class="icon-btn menu-btn" data-action="menu" aria-label="Open menu">☰</button>
      <div class="prop-switch">
        <span class="muted small">Property</span>
        <select id="propSel" aria-label="Choose property">
          ${props.map((id) => `<option value="${id}" ${id === DB.active ? 'selected' : ''}>${esc(DB.properties[id].meta.name || 'Untitled')}</option>`).join('')}
          <option value="__new">＋ Add another property</option>
        </select>
      </div>
      <div class="top-actions">
        <button class="btn ghost small" data-action="print" title="Print or save as PDF">🖨<span class="btn-label"> Print</span></button>
        <button class="icon-btn" data-action="theme" aria-label="Switch colour theme (now ${theme})" title="Theme: ${theme}">${theme === 'dark' ? '☾' : theme === 'light' ? '☀' : '◐'}</button>
      </div>`;
  }

  function applyTheme() {
    const t = DB.theme || 'auto';
    if (t === 'auto') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', t);
  }

  function go(id) {
    if (!ALL.some((x) => x.id === id)) id = 'overview';
    current = id;
    if (location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
    render();
    const v = document.getElementById('view');
    v.focus({ preventScroll: true });
    window.scrollTo(0, 0);
    document.getElementById('side').classList.remove('open');
    const scrim = document.querySelector('.scrim'); if (scrim) scrim.remove();
    track('view', { id });
  }

  /* ================================================================ */
  /* Rendering machinery: live regions + charts                        */
  /* ================================================================ */
  let liveFns = [];
  let chartQueue = [];
  function live(id, fn) { liveFns.push({ id, fn }); return `<div id="${id}"></div>`; }
  function runLive() {
    liveFns.forEach(({ id, fn }) => {
      const el = document.getElementById(id);
      if (!el) return;
      try { el.innerHTML = fn(); } catch (e) { console.error(e); el.innerHTML = `<div class="callout bad">Something in the inputs stops this section from calculating. Check the dates and amounts in Set up.</div>`; }
    });
    mountCharts();
  }
  function chart(id, cfgFn, cls, label) {
    chartQueue.push({ id, cfgFn });
    return `<div class="chart-box ${cls || ''}"><canvas id="${id}" role="img" aria-label="${esc(label || 'Chart')}"></canvas></div>`;
  }
  function mountCharts() {
    const q = chartQueue; chartQueue = [];
    q.forEach(({ id, cfgFn }) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (!window.Chart) { el.parentElement.innerHTML = '<div class="chart-fallback">Charts load from the internet. Connect once and refresh to see them. Every number on this page still works.</div>'; return; }
      const old = window.Chart.getChart(el); if (old) old.destroy();
      try { new window.Chart(el, cfgFn()); } catch (e) { console.error(e); }
    });
  }

  let keepScroll = null;
  function render() {
    liveFns = []; chartQueue = [];
    renderSide(); renderTop();
    const view = document.getElementById('view');
    const item = ALL.find((x) => x.id === current);
    if (item && needsPro(item.pro)) { view.innerHTML = gateView(item); return; }
    const fn = VIEWS[current] || VIEWS.overview;
    view.innerHTML = fn();
    runLive();
    const w = document.querySelector('.table-wrap.tall');
    if (w) {
      if (keepScroll !== null) w.scrollTop = keepScroll;
      else { const row = w.querySelector('tr.selected') || w.querySelector('tr.is-today'); if (row) w.scrollTop = Math.max(0, row.offsetTop - w.clientHeight / 2); }
    }
    keepScroll = null;
  }

  /* ================================================================ */
  /* Input helpers                                                     */
  /* ================================================================ */
  function getPath(path) { return path.split('.').reduce((o, k) => (o === undefined || o === null ? undefined : o[k]), S); }
  function setPath(path, value) {
    const keys = path.split('.');
    let o = S;
    for (let i = 0; i < keys.length - 1; i++) o = o[keys[i]];
    o[keys[keys.length - 1]] = value;
  }
  const fid = (p) => 'f-' + p.replace(/\./g, '-');
  const hintMoney = (v) => (v === '' || v === null || v === undefined || !isFinite(v) || Number(v) === 0 ? '' : short(Number(v)));

  function field(label, control, help, hint) {
    return `<div class="field">${label ? `<label>${label}</label>` : ''}${control}${hint !== undefined ? `<div class="hint">${hint}</div>` : ''}${help ? `<div class="help">${help}</div>` : ''}</div>`;
  }
  function inMoney(path, attrs) {
    const v = getPath(path);
    return `<div class="affix"><span>₹</span><input type="number" inputmode="numeric" min="0" step="1000" data-bind="${path}" data-kind="money" value="${v === '' || v === null || v === undefined ? '' : v}" ${attrs || ''}></div>`;
  }
  function fMoney(path, label, help, attrs) {
    const v = getPath(path);
    return `<div class="field"><label for="${fid(path)}">${label}</label>${inMoney(path, `id="${fid(path)}" ${attrs || ''}`)}<div class="hint" data-hint="${path}">${hintMoney(v)}</div>${help ? `<div class="help">${help}</div>` : ''}</div>`;
  }
  function inPct(path, attrs) {
    const v = getPath(path);
    const shown = v === '' || v === null || v === undefined ? '' : +(Number(v) * 100).toFixed(4);
    return `<div class="affix"><input type="number" inputmode="decimal" step="0.05" data-bind="${path}" data-kind="pct" value="${shown}" ${attrs || ''}><span>%</span></div>`;
  }
  function fPct(path, label, help) { return `<div class="field"><label for="${fid(path)}">${label}</label>${inPct(path, `id="${fid(path)}"`)}${help ? `<div class="help">${help}</div>` : ''}</div>`; }
  function fNum(path, label, help, attrs) {
    const v = getPath(path);
    return `<div class="field"><label for="${fid(path)}">${label}</label><input id="${fid(path)}" type="number" inputmode="numeric" data-bind="${path}" data-kind="num" value="${v === '' || v === null || v === undefined ? '' : v}" ${attrs || ''}>${help ? `<div class="help">${help}</div>` : ''}</div>`;
  }
  function fText(path, label, help, attrs) {
    return `<div class="field"><label for="${fid(path)}">${label}</label><input id="${fid(path)}" type="text" data-bind="${path}" data-kind="text" value="${esc(getPath(path))}" ${attrs || ''}>${help ? `<div class="help">${help}</div>` : ''}</div>`;
  }
  function monthPick(path, optional) {
    const k = M.parse(getPath(path));
    const m = k === null ? '' : (k % 12) + 1;
    const y = k === null ? '' : Math.floor(k / 12);
    const blank = optional || k === null;
    return `<div class="mpick" data-bind-month="${path}">
      <select data-part="m" aria-label="Month">${blank ? '<option value="">Month</option>' : ''}${MONTHS.map((n, i) => `<option value="${i + 1}" ${m === i + 1 ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <select data-part="y" aria-label="Year">${blank ? '<option value="">Year</option>' : ''}${YEARS.map((yy) => `<option value="${yy}" ${yy === y ? 'selected' : ''}>${yy}</option>`).join('')}</select></div>`;
  }
  function fMonth(path, label, help, optional) { return `<div class="field"><span class="lbl">${label}</span>${monthPick(path, optional)}${help ? `<div class="help">${help}</div>` : ''}</div>`; }
  function seg(path, options, action) {
    const v = getPath(path);
    return `<div class="seg" role="group">${options.map((o) => `<button type="button" data-action="${action || 'seg'}" data-path="${path}" data-val="${esc(o.v)}" aria-pressed="${String(v) === String(o.v)}">${esc(o.l)}</button>`).join('')}</div>`;
  }
  function uiSeg(key, options, def) {
    const v = (DB.ui && DB.ui[key]) || def;
    return `<div class="seg" role="group">${options.map((o) => `<button type="button" data-action="ui" data-key="${key}" data-val="${esc(o.v)}" aria-pressed="${v === o.v}">${esc(o.l)}</button>`).join('')}</div>`;
  }
  const ui = (key, def) => (DB.ui && DB.ui[key] !== undefined ? DB.ui[key] : def);

  function onInput(e) {
    const t = e.target;
    if (t.matches('[data-bind]')) {
      const kind = t.dataset.kind;
      let v;
      if (kind === 'bool') v = t.checked;
      else if (kind === 'money' || kind === 'num') v = t.value === '' ? '' : Number(t.value);
      else if (kind === 'pct') v = t.value === '' ? '' : Number(t.value) / 100;
      else v = t.value;
      setPath(t.dataset.bind, v);
      if (kind === 'money') {
        const h = document.querySelector(`[data-hint="${t.dataset.bind}"]`);
        if (h) h.textContent = hintMoney(v);
      }
      if (t.dataset.bind === 'meta.name') renderTop();
      changed(t.dataset.rerender === '1');
      return;
    }
    const wrap = t.closest && t.closest('[data-bind-month]');
    if (wrap) {
      const m = wrap.querySelector('[data-part="m"]').value;
      const y = wrap.querySelector('[data-part="y"]').value;
      setPath(wrap.dataset.bindMonth, m && y ? y + '-' + String(m).padStart(2, '0') : '');
      changed(wrap.dataset.rerender === '1');
    }
  }
  let saveTimer = null;
  function changed(full) {
    recompute();
    if (full) render(); else runLive();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persist, 250);
  }

  /* ================================================================ */
  /* Plain-language helpers                                            */
  /* ================================================================ */
  const PHASE = {
    build: { l: 'Before the loan', c: '' },
    preemi: { l: 'Pre-EMI', c: 'brand' },
    topup: { l: 'You top up', c: 'out' },
    surplus: { l: 'Rent covers EMI', c: 'in' },
    free: { l: 'Loan-free', c: 'today' },
    idle: { l: DASH, c: '' }
  };
  const phaseTag = (p) => `<span class="tag ${PHASE[p].c}">${PHASE[p].l}</span>`;
  const isSample = () => /sample/i.test(S.meta.name || '');

  function focusRow() {
    const R = OUT && OUT.rental;
    if (!R || !R.ok) return null;
    const t = R.rows.find((r) => r.k === TODAY);
    if (t) return t;
    if (TODAY < R.start) return R.rows.find((r) => r.D > 0) || R.rows[0];
    return R.rows[R.rows.length - 1];
  }

  function explainMonth(r) {
    const out = [];
    if (r.AH > 0) out.push(`You paid <b>${rs(r.AH)}</b> from your own savings towards the purchase.`);
    if (r.U > 0) out.push(`The bank paid <b>${rs(r.U)}</b> to the builder or seller for you. The loan now stands at ${rs(r.G)}.`);
    if (r.preEmi) out.push(`The flat isn't handed over yet, so the bank charges interest only: <b class="out">${rs(r.D)}</b> on the ${rs(r.G)} lent so far (${pct(r.B, 2)} a year, divided by 12). This is pre-EMI. It doesn't reduce the loan by a rupee.`);
    else if (r.D > 0) out.push(`The EMI is <b class="out">${rs(r.D)}</b>. Of that, ${rs(r.E)} is interest (the bank's charge for lending) and ${rs(r.F)} pays back the loan itself.`);
    if (r.C > 0) out.push(`The tenant paid rent of <b class="in">${rs(r.C)}</b>.`);
    if (r.net < -0.5) out.push(`So you put in <b class="out">${rs(-r.net)}</b> from your own pocket this month.`);
    else if (r.net > 0.5) out.push(`So <b class="in">${rs(r.net)}</b> was left over for you this month.`);
    else out.push('Nothing moved in or out of your pocket this month.');
    if (r.H > 0.5) out.push(`Loan still to repay after this month: ${rs(r.H)}.`);
    else if (r.T > 0) out.push('The loan is fully repaid.');
    return out;
  }

  function ledgerFor(r, title) {
    const ins = [], outs = [];
    if (r.C > 0) ins.push(['Rent from tenant', r.C]);
    if (r.D > 0) {
      if (r.preEmi) outs.push(['Pre-EMI (interest only)', r.D]);
      else outs.push(['EMI to bank', r.D, [['interest', r.E], ['loan repaid', r.F]]]);
    }
    if (r.AH > 0) outs.push(['Own money to builder or seller', r.AH]);
    const line = (x) => `<div class="ledger-line"><span>${x[0]}</span><span class="num">${rs(x[1])}</span></div>${x[2] ? x[2].map((s) => `<div class="ledger-line"><span class="sub">of which ${s[0]}</span><span class="num sub">${rs(s[1])}</span></div>`).join('') : ''}`;
    return `<div class="ledger" aria-label="${esc(title)}">
      <div class="ledger-col in-col"><h4>Comes in</h4>${ins.length ? ins.map(line).join('') : '<div class="ledger-line"><span class="faint">Nothing this month</span><span></span></div>'}</div>
      <div class="ledger-col out-col"><h4>Goes out</h4>${outs.length ? outs.map(line).join('') : '<div class="ledger-line"><span class="faint">Nothing this month</span><span></span></div>'}</div>
      <div class="ledger-total"><span>${r.net < -0.5 ? 'From your pocket' : r.net > 0.5 ? 'Left over for you' : 'Net'}</span><span class="big num ${r.net < -0.5 ? 'out' : r.net > 0.5 ? 'in' : ''}">${rs(Math.abs(r.net))}</span></div>
    </div>`;
  }

  function headline() {
    const R = OUT.rental, EL = OUT.equityLoan;
    const r = focusRow();
    if (!R.ok || !r) return `<p>${esc(R.reason || 'Fill in Set up to see your story.')}</p>`;
    const p = [];
    const price = Number(S.purchasePrice) || EL.totalPaid;
    p.push(`<p>This property costs <b>${short(price)}</b>. <b>${short(EL.totalEquity)}</b> comes from your own savings and the bank lends <b>${short(EL.totalLoan)}</b>.</p>`);
    const when = r.k === TODAY ? `This month (${ml(r.k)})` : r.k > TODAY ? `In ${ml(r.k)}, when payments begin` : `In ${ml(r.k)}`;
    if (r.phase === 'build') p.push(`<p>${when}, nothing is due to the bank yet.${r.AH > 0 ? ` You pay <b class="out">${short(r.AH)}</b> from savings.` : ''}</p>`);
    else if (r.phase === 'preemi') p.push(`<p>${when}, the flat is under construction, so you pay the bank interest only: <b class="out">${rs(r.D)}</b> a month. This pre-EMI doesn't reduce the loan.</p>`);
    else if (r.phase === 'topup') p.push(`<p>${when}, the tenant pays <b class="in">${rs(r.C)}</b> and the EMI is <b class="out">${rs(r.D)}</b>. So you add <b class="out">${rs(r.D - r.C)}</b> from your own pocket. Of the EMI, ${rs(r.E)} is the bank's interest and ${rs(r.F)} actually cuts your loan.</p>`);
    else if (r.phase === 'surplus') p.push(`<p>${when}, rent of <b class="in">${rs(r.C)}</b> covers the EMI of <b class="out">${rs(r.D)}</b> and leaves <b class="in">${rs(r.C - r.D)}</b> spare. The flat is paying for itself.</p>`);
    else if (r.phase === 'free') p.push(`<p>${when}, the loan is repaid. The full rent of <b class="in">${rs(r.C)}</b> is yours.</p>`);
    const ms = R.milestones;
    const g = Number(S.rental.rentIncrease) || 0;
    if (ms.rentBeatsEMI !== null && ms.rentBeatsEMI > r.k) p.push(`<p>Rent goes up ${pct(g, 0)} a year. It overtakes the EMI in <b>${ml(ms.rentBeatsEMI)}</b>, ${rel(ms.rentBeatsEMI)}. After that you stop topping up.</p>`);
    else if (ms.rentBeatsEMI !== null && r.phase !== 'surplus' && r.phase !== 'free') p.push(`<p>Rent overtook the EMI in ${ml(ms.rentBeatsEMI)}.</p>`);
    else if (ms.rentBeatsEMI === null && R.totals.emi > 0 && ms.firstRent !== null) p.push(`<p>On these numbers, rent never catches up with the EMI within the ${R.years} years shown. You keep topping up until the loan ends.</p>`);
    if (R.valueEnd !== null) p.push(`<p>The loan ${R.effEnd !== null && R.effEnd <= R.end ? `ends in <b>${ml(R.effEnd)}</b>` : `runs past ${ml(R.end)}`}. By ${ml(R.end)} the property could be worth about <b class="in">${short(R.valueEnd)}</b>${R.loanEndBal > 1 ? `, with ${short(R.loanEndBal)} still owed` : ' and you own it outright'}.</p>`);
    return p.join('');
  }

  /* ================================================================ */
  /* Views                                                             */
  /* ================================================================ */
  const VIEWS = {};

  /* ---------- Overview ---------- */
  VIEWS.overview = function () {
    return `
      <div class="view-head"><div><h1>${esc(S.meta.name || 'My property')}</h1>
        <p>${S.meta.city ? esc(S.meta.city) + '. ' : ''}Everything below updates the moment you change an input.</p></div>
        <div class="no-print"><button class="btn" data-go="setup">Edit inputs</button> <button class="btn primary" data-go="cashflow">See month by month</button></div></div>
      ${isSample() ? `<div class="callout warn no-print" style="margin-bottom:16px"><p><b>You're looking at the sample data from the Excel.</b> To see your own flat, use the quick start. It takes about 2 minutes.</p>
        <p><button class="btn primary small" data-action="quickstart">Quick start for my flat</button> <button class="btn small" data-go="setup">Fill in every detail</button></p></div>` : ''}
      ${live('ov-main', () => {
        if (!OUT || !OUT.rental.ok) return `<div class="panel empty"><h2>Let's set up your property</h2><p>Add the purchase price, your payments and the loan.</p><button class="btn primary" data-action="quickstart">Quick start</button></div>`;
        const R = OUT.rental, r = focusRow();
        const cover = r && r.D > 0 ? r.C / r.D : null;
        return `
        <div class="split">
          <div class="panel"><div class="story">${headline()}</div></div>
          <div class="stack">
            <div class="panel-head"><h3>${r.k === TODAY ? 'This month' : ml(r.k)}: the money ledger</h3></div>
            ${ledgerFor(r, 'This month')}
          </div>
        </div>
        <div class="figs" style="margin-top:16px">
          <div class="fig"><div class="label">Loan left ${r.k === TODAY ? 'today' : 'at ' + ml(r.k)}</div><div class="value">${short(r.H)}</div><div class="note">of ${short(R.totalLoan)} borrowed</div></div>
          <div class="fig"><div class="label">Rent covers ${tip('Rent divided by EMI. Above 100% means the flat pays for itself.')}</div><div class="value ${cover === null ? '' : cover >= 1 ? 'in' : 'out'}">${cover === null ? DASH : pct(cover, 0)}</div><div class="note">of the EMI this month</div></div>
          <div class="fig"><div class="label">Worth by ${ml(R.end)}</div><div class="value in">${short(R.valueEnd)}</div><div class="note">at ${pct(Number(S.rental.appreciation), 1)} a year growth</div></div>
          <div class="fig"><div class="label">Your money grows at ${tip('All-in XIRR: the yearly return on every rupee you put in (down payment and monthly top-ups) and took out (spare rent), plus your share of the flat at the end. Compare it with an FD rate.')}</div><div class="value">${pct(R.allInXIRR)}</div><div class="note">a year, all-in. Excel method: ${pct(R.equityXIRR)}</div></div>
        </div>
        <div class="panel" style="margin-top:16px">
          <div class="panel-head"><div><h3>Rent vs EMI, every month</h3><p>Green bars: money left over. Red bars: money you add. The dashed line is today.</p></div></div>
          ${chart('ovChart', () => cashChart(R), '', 'Monthly rent, EMI and net cash')}
          ${phaseStrip(R)}
        </div>
        <div class="grid g2" style="margin-top:16px">
          <div class="panel"><div class="panel-head"><h3>Key dates</h3></div>${milestoneList(R)}</div>
          <div class="panel"><div class="panel-head"><h3>Totals over ${R.years} years</h3></div>
            <div class="ledger-line"><span>Rent collected</span><span class="num in">${short(R.totals.rent)}</span></div>
            <div class="ledger-line"><span>EMIs and pre-EMI paid</span><span class="num out">${short(R.totals.emi)}</span></div>
            <div class="ledger-line"><span class="sub">of which interest</span><span class="num sub">${short(R.totals.interest)}</span></div>
            <div class="ledger-line"><span class="sub">of which loan repaid</span><span class="num sub">${short(R.totals.principal)}</span></div>
            <div class="ledger-line"><span>Own money paid upfront</span><span class="num out">${short(R.totals.equity)}</span></div>
            <div class="ledger-line"><span><b>Net cash from your pocket</b> ${tip('Rent minus EMIs minus your own instalments. Negative means you funded it.')}</span><span class="num ${R.totals.net < 0 ? 'out' : 'in'}"><b>${short(R.totals.net)}</b></span></div>
            <div class="ledger-line"><span><b>Property value at the end</b></span><span class="num in"><b>${short(R.valueEnd)}</b></span></div>
          </div>
        </div>`;
      })}`;
  };

  function phaseStrip(R) {
    const segs = [];
    R.rows.forEach((r) => {
      const last = segs[segs.length - 1];
      if (last && last.p === r.phase) last.n++; else segs.push({ p: r.phase, n: 1, k: r.k });
    });
    const N = R.rows.length;
    const pos = (k) => ((k - R.start + 0.5) / N) * 100;
    const marks = [];
    const todayIn = TODAY >= R.start && TODAY <= R.end;
    const near = (k) => todayIn && Math.abs(pos(k) - pos(TODAY)) < 9;
    if (!near(R.start)) marks.push({ k: R.start, t: ml(R.start) });
    if (todayIn) marks.push({ k: TODAY, t: 'Today', cls: 'today-tick' });
    if (!near(R.end)) marks.push({ k: R.end, t: ml(R.end) });
    const used = new Set(segs.map((s) => s.p));
    return `<div style="margin-top:14px"><div class="phases" role="img" aria-label="Phases of the investment over time">${segs.map((s) => `<span class="ph-${s.p}" style="width:${(s.n / N) * 100}%" title="${PHASE[s.p].l}: ${ml(s.k)}, ${s.n} months"></span>`).join('')}</div>
      <div class="timeline">${marks.map((m) => `<span class="${m.cls || ''}" style="left:${Math.min(96, Math.max(4, pos(m.k)))}%">${m.t}</span>`).join('')}</div>
      <div class="legend">${['build', 'preemi', 'topup', 'surplus', 'free'].filter((p) => used.has(p)).map((p) => `<span><i class="ph-${p}"></i>${PHASE[p].l}</span>`).join('')}</div></div>`;
  }

  function milestoneList(R) {
    const items = [];
    const tr = E.tranches(S);
    const firstEq = tr.filter((t) => t.funding === 'Equity').sort((a, b) => a.k - b.k)[0];
    const firstLoan = R.rows.find((r) => r.U > 0);
    if (firstEq) items.push([firstEq.k, `First payment from your savings: ${short(firstEq.amount)}`]);
    if (firstLoan) items.push([firstLoan.k, `Bank releases the first loan amount: ${short(firstLoan.U)}`]);
    const pre = R.rows.filter((r) => r.preEmi);
    if (pre.length) items.push([pre[0].k, `Pre-EMI starts (interest only, ${pre.length} months in total)`]);
    if (R.poss !== null) items.push([R.poss, 'Possession: you get the keys']);
    if (R.milestones.firstEMI !== null) items.push([R.milestones.firstEMI, `Full EMI starts: ${rs(R.rows.find((r) => r.k === R.milestones.firstEMI).D)}`]);
    if (R.milestones.firstRent !== null) items.push([R.milestones.firstRent, `Rent starts: ${rs(R.rows.find((r) => r.k === R.milestones.firstRent).C)} a month`]);
    if (R.milestones.rentBeatsEMI !== null) items.push([R.milestones.rentBeatsEMI, 'Rent overtakes the EMI']);
    if (R.foreclosure) items.push([R.foreclosure.k, 'Loan could be closed early if all spare rent goes to prepayment']);
    if (R.effEnd !== null) items.push([R.effEnd, 'Last EMI as per the loan tenure']);
    items.sort((a, b) => a[0] - b[0]);
    return `<ul class="milestones">${items.map((i) => `<li class="${i[0] < TODAY ? 'past' : ''}"><span class="when">${ml(i[0])}</span><span>${i[1]}<br><small class="faint">${rel(i[0])}</small></span></li>`).join('')}</ul>`;
  }

  /* ---------- Charts ---------- */
  const baseOpts = () => ({
    responsive: true, maintainAspectRatio: false, animation: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { labels: { color: css('--ink-2'), boxWidth: 12 } },
      tooltip: { callbacks: { label: (c) => `${c.dataset.label}: ${c.raw === null ? DASH : rs(c.raw)}` } }
    },
    scales: {
      x: { ticks: { color: css('--ink-3'), maxRotation: 0, autoSkip: true, maxTicksLimit: 10 }, grid: { display: false } },
      y: { ticks: { color: css('--ink-3'), callback: (v) => short(v) }, grid: { color: css('--line') } }
    }
  });
  const todayPlugin = {
    id: 'todayLine',
    afterDatasetsDraw(c, args, o) {
      if (o.index === undefined || o.index === null || o.index < 0) return;
      const x = c.scales.x.getPixelForValue(o.index);
      const { top, bottom } = c.chartArea;
      const ctx = c.ctx; ctx.save();
      ctx.strokeStyle = o.color; ctx.lineWidth = 2; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, bottom); ctx.stroke();
      ctx.fillStyle = o.color; ctx.font = '600 12px IBM Plex Sans, sans-serif'; ctx.fillText('Today', x + 5, top + 12);
      ctx.restore();
    }
  };
  function cashChart(R) {
    const labels = R.rows.map((r) => ml(r.k));
    const o = baseOpts();
    o.plugins.todayLine = { index: R.rows.findIndex((r) => r.k === TODAY), color: css('--today') };
    return {
      type: 'bar',
      data: { labels, datasets: [
        { type: 'line', label: 'Rent', data: R.rows.map((r) => r.C), borderColor: css('--in'), backgroundColor: css('--in'), pointRadius: 0, borderWidth: 2, tension: 0 },
        { type: 'line', label: 'EMI / pre-EMI', data: R.rows.map((r) => r.D), borderColor: css('--out'), backgroundColor: css('--out'), pointRadius: 0, borderWidth: 2, tension: 0 },
        { type: 'bar', label: 'Net (rent − EMI)', data: R.rows.map((r) => r.C - r.D), backgroundColor: R.rows.map((r) => (r.C - r.D >= 0 ? css('--in') : css('--out')) + '55'), borderWidth: 0 }
      ] },
      options: o, plugins: [todayPlugin]
    };
  }
  function owedChart(R) {
    const o = baseOpts();
    return {
      type: 'line',
      data: { labels: R.annual.map((a) => 'Yr ' + a.year), datasets: [
        { label: 'Property value', data: R.annual.map((a) => a.value), borderColor: css('--in'), backgroundColor: css('--in') + '22', fill: true, pointRadius: 0, borderWidth: 2, spanGaps: false },
        { label: 'Loan still owed', data: R.annual.map((a) => a.loanEnd), borderColor: css('--out'), backgroundColor: css('--out') + '22', fill: true, pointRadius: 0, borderWidth: 2 }
      ] },
      options: o
    };
  }

  /* ---------- Setup ---------- */
  VIEWS.setup = function () {
    const tr = S.tranches;
    const rates = S.rates;
    return `
      <div class="view-head"><div><h1>Set up your property</h1><p>Six short steps. Grey help text under each box tells you where to find the number (your loan sanction letter, builder demand letters, rent agreement).</p></div>
        <div class="no-print"><button class="btn" data-action="quickstart">Quick start instead</button></div></div>
      <div class="split wide-left">
        <div class="panel steps">
          <div class="step"><div class="step-no">1</div><div>
            <h2>The property</h2><p class="muted small">The all-in price you agreed, including parking and other charges paid to the builder or seller.</p>
            <div class="fields">
              ${fText('meta.name', 'Name it', 'Shows in the property switcher.')}
              ${fText('meta.city', 'City', '')}
              ${fMoney('purchasePrice', 'Total purchase price', 'Must equal the sum of payments in step 2.')}
              ${fMonth('rental.possession', 'Possession month', 'When you got (or get) the keys. For a ready flat, the month you bought it.')}
            </div></div></div>

          <div class="step"><div class="step-no">2</div><div>
            <h2>Payments to the builder or seller</h2><p class="muted small">One row per payment. Mark who paid it: your own money, or the bank from the loan. Ready flat? Two rows in the purchase month: your down payment and the loan amount.</p>
            <div class="table-wrap"><table class="edit-table"><thead><tr><th>#</th><th style="text-align:left">Month</th><th style="text-align:left">Amount</th><th style="text-align:left">Paid by</th><th></th></tr></thead><tbody>
            ${tr.map((t, i) => `<tr><td class="idx">${i + 1}</td><td style="min-width:200px">${monthPick('tranches.' + i + '.date')}</td>
              <td style="min-width:170px">${inMoney('tranches.' + i + '.amount')}</td>
              <td><select data-bind="tranches.${i}.funding" data-kind="text"><option value="Equity" ${t.funding !== 'Loan' ? 'selected' : ''}>Own money</option><option value="Loan" ${t.funding === 'Loan' ? 'selected' : ''}>Bank loan</option></select></td>
              <td><button class="btn ghost small danger" data-action="delTranche" data-i="${i}" aria-label="Remove payment ${i + 1}">Remove</button></td></tr>`).join('')}
            </tbody></table></div>
            <p style="margin-top:8px"><button class="btn small" data-action="addTranche">＋ Add a payment</button></p>
            ${live('chk-tranches', () => {
              const EL = OUT.equityLoan;
              const diff = EL.totalPaid - (Number(S.purchasePrice) || 0);
              return `<div class="callout ${Math.abs(diff) < 1 ? 'good' : 'warn'}"><p>Own money <b>${rs(EL.totalEquity)}</b> + bank loan <b>${rs(EL.totalLoan)}</b> = <b>${rs(EL.totalPaid)}</b>. ${Math.abs(diff) < 1 ? 'Matches the purchase price.' : `That's ${rs(Math.abs(diff))} ${diff > 0 ? 'more' : 'less'} than the purchase price. Fix one of them so the numbers tie up.`}</p></div>`;
            })}
          </div></div>

          <div class="step"><div class="step-no">3</div><div>
            <h2>Home loan</h2><p class="muted small">From your loan sanction letter.</p>
            <div class="fields">
              ${fMonth('loan.start', 'Loan start month', 'Month of the first disbursement.')}
              ${fMonth('loan.end', 'Loan end month', 'Start month plus tenure. A 20-year loan from Sep 2025 ends Aug 2045.')}
            </div>
            <div class="fields" style="margin-top:14px">
              <div class="field"><span class="lbl">When does the full EMI start? ${tip('Under-construction loans often charge only interest (pre-EMI) until possession. Ready flats start the full EMI straight away.')}</span>
                ${seg('loan.emiStarts', [{ v: 'loanStart', l: 'From loan start' }, { v: 'possession', l: 'From possession' }])}
                <div class="help">Ready flat or full EMI from day one: pick "From loan start". Pre-EMI until keys: pick "From possession". The tenure then counts from possession.</div></div>
              <div class="field"><span class="lbl">When the interest rate changes ${tip('Banks either recalculate the EMI or keep it the same and change the tenure. The Excel offers both.')}</span>
                ${seg('loan.behaviour', [{ v: 'change', l: 'EMI is recalculated' }, { v: 'constant', l: 'EMI stays the same' }])}
                <div class="help">Not sure? Most Indian banks keep the EMI and stretch the tenure, but you can ask for a new EMI.</div></div>
            </div></div></div>

          <div class="step"><div class="step-no">4</div><div>
            <h2>Interest rate</h2><p class="muted small">The first rate applies from the loan start. Add a row each time the bank changed your rate (check your loan statement or the bank's SMS).</p>
            <div class="table-wrap"><table class="edit-table"><thead><tr><th style="text-align:left">From</th><th style="text-align:left">Rate a year</th><th style="text-align:left">Note</th><th></th></tr></thead><tbody>
              ${rates.map((r, i) => `<tr><td style="min-width:200px">${i === 0 ? `<span class="muted">Loan start (${ml(M.parse(S.loan.start))})</span>` : monthPick('rates.' + i + '.start')}</td>
                <td style="min-width:130px">${inPct('rates.' + i + '.rate')}</td>
                <td><input type="text" data-bind="rates.${i}.note" data-kind="text" value="${esc(r.note)}" placeholder="e.g. RBI cut"></td>
                <td>${i === 0 ? '' : `<button class="btn ghost small danger" data-action="delRate" data-i="${i}">Remove</button>`}</td></tr>`).join('')}
            </tbody></table></div>
            <p style="margin-top:8px"><button class="btn small" data-action="addRate">＋ Add a rate change</button></p>
          </div></div>

          <div class="step"><div class="step-no">5</div><div>
            <h2>Rent</h2><p class="muted small">From your rent agreement. Most agreements in Pune, Mumbai and Bengaluru step rent up 5% to 10% every 11 or 12 months.</p>
            <div class="fields">
              ${fMonth('rental.rentStart', 'Rent started (or starts)', 'First month the tenant pays.', true)}
              ${fMoney('rental.rent', 'Monthly rent at the start', 'Rent only. Leave out maintenance the tenant pays the society.', 'step="500"')}
              ${fPct('rental.rentIncrease', 'Yearly rent increase', 'Rent steps up once every 12 months from the start.')}
              ${fMonth('rental.rentEnd', 'Rent stops (optional)', 'Leave blank if it continues.', true)}
            </div></div></div>

          <div class="step"><div class="step-no">6</div><div>
            <h2>Value, sale and horizon</h2><p class="muted small">Your best guesses. Change them any time and watch the results move.</p>
            <div class="fields">
              ${fMoney('rental.valueAtPossession', 'Market value at possession', 'What a similar flat sells for at handover.')}
              ${fPct('rental.appreciation', 'Expected price growth a year', 'Pune has averaged roughly 4% to 7% in recent years. Pick what you believe.')}
              ${fNum('rental.years', 'Years to project', 'How far ahead the cash flow runs (1 to 50).', 'min="1" max="50" step="1"')}
              ${fMonth('sale.date', 'If you sold: month', 'Used in Returns for the "sell" view.', true)}
              ${fMoney('sale.price', 'If you sold: price', '')}
            </div></div></div>
        </div>
        <div class="month-detail">${live('setup-live', setupSummary)}</div>
      </div>`;
  };

  function setupSummary() {
    if (!OUT) return '';
    const R = OUT.rental;
    if (!R.ok) return `<div class="panel"><h3>Not enough to calculate yet</h3><p class="muted">${esc(R.reason)}</p></div>`;
    const issues = [];
    const ls = M.parse(S.loan.start), le = M.parse(S.loan.end);
    if (OUT.equityLoan.totalLoan > 0 && ls === null) issues.push('Add the loan start month in step 3.');
    if (ls !== null && le !== null && le <= ls) issues.push('The loan end must be after the loan start.');
    if (R.poss === null) issues.push('Add the possession month in step 1.');
    const rentK = M.parse(S.rental.rentStart);
    if (rentK !== null && R.poss !== null && rentK < R.poss) issues.push('Rent starts before possession. Check the dates.');
    if (rentK !== null && rentK > R.end) issues.push('Rent starts after the projection ends. Increase "Years to project".');
    if (R.effEnd !== null) {
      const atEnd = R.rows.find((r) => r.k === R.effEnd);
      if (atEnd && atEnd.H > 1) issues.push(`About ${short(atEnd.H)} of loan is still unpaid at the last EMI. With "EMI stays the same", a rate rise can leave a balance. Switch to "EMI is recalculated" or extend the loan end.`);
    }
    const firstEmi = R.rows.find((r) => r.D > 0 && !r.preEmi);
    const tenure = ls !== null && le !== null ? le - ls + 1 : null;
    return `<div class="panel"><h3>Quick check</h3>
      <div class="ledger-line"><span>Loan amount</span><span class="num">${rs(R.totalLoan)}</span></div>
      <div class="ledger-line"><span>Tenure</span><span class="num">${tenure ? dur(tenure) : DASH}</span></div>
      <div class="ledger-line"><span>Full EMI starts</span><span class="num">${firstEmi ? ml(firstEmi.k) : DASH}</span></div>
      <div class="ledger-line"><span>First full EMI</span><span class="num out">${firstEmi ? rs(firstEmi.D) : DASH}</span></div>
      <div class="ledger-line"><span>Last EMI month</span><span class="num">${ml(R.effEnd)}</span></div>
      <div class="ledger-line"><span>Projection runs</span><span class="num">${ml(R.start)} to ${ml(R.end)}</span></div>
      ${issues.length ? `<div class="callout warn" style="margin-top:12px">${issues.map((x) => `<p>${x}</p>`).join('')}</div>` : '<div class="callout good" style="margin-top:12px"><p>Inputs look consistent.</p></div>'}
      <p class="small muted" style="margin-top:12px">Compare the first EMI with your bank statement. If it's off by more than a few hundred rupees, check the loan amount, rate and dates.</p>
      <p><button class="btn primary small" data-go="overview">See the overview</button></p></div>`;
  }

  /* ---------- Cash flow ---------- */
  VIEWS.cashflow = function () {
    return `
      <div class="view-head"><div><h1>Monthly cash flow</h1><p>Every rupee in and out, month by month. Tap any month to see it explained in plain words.</p></div>
        <div class="no-print" style="display:flex;gap:8px;flex-wrap:wrap">${uiSeg('cfMode', [{ v: 'month', l: 'Monthly' }, { v: 'year', l: 'Yearly' }], 'month')}
          <button class="btn small" data-action="csv">${needsPro('exportCSV') ? 'Download CSV (Pro)' : 'Download CSV'}</button></div></div>
      ${live('cf-main', () => {
        const R = OUT.rental;
        if (!R.ok) return `<div class="panel empty">${esc(R.reason)}</div>`;
        return ui('cfMode', 'month') === 'year' ? yearlyView(R) : monthlyView(R);
      })}`;
  };

  function monthlyView(R) {
    const filter = ui('cfFilter', 'all');
    let rows = R.rows;
    if (filter === 'rent' && R.milestones.firstRent !== null) rows = rows.filter((r) => r.k >= R.milestones.firstRent);
    if (filter === 'today') rows = rows.filter((r) => r.k >= TODAY - 6 && r.k <= TODAY + 18);
    if (filter === 'loan') rows = rows.filter((r) => r.T > 0);
    if (!rows.length) rows = R.rows;
    const selK = ui('cfSel', null) !== null ? ui('cfSel', null) : (focusRow() || R.rows[0]).k;
    const sel = R.rows.find((r) => r.k === selK) || R.rows[0];
    const sum = (f) => rows.reduce((s, r) => s + r[f], 0);
    const cell = (v, c) => (v ? `<td class="${c || ''}">${rs(v)}</td>` : `<td class="dash">${DASH}</td>`);
    return `
      <div class="no-print" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
        <span class="small muted">Show</span>${uiSeg('cfFilter', [{ v: 'all', l: 'All months' }, { v: 'today', l: 'Around today' }, { v: 'loan', l: 'From first loan' }, { v: 'rent', l: 'From rent start' }], 'all')}
      </div>
      <div class="panel" style="margin-bottom:16px"><div class="panel-head"><div><h3>${ml(sel.k)} explained</h3><p>${phaseTag(sel.phase)} ${sel.k === TODAY ? '<span class="tag today">today</span>' : rel(sel.k)}</p></div><span class="small faint no-print">Tap a row below to change month</span></div>
        <div class="detail-strip"><div>${ledgerFor(sel, ml(sel.k))}</div>
          <div>${explainMonth(sel).map((x) => `<p>${x}</p>`).join('')}
          ${sel.D > 0 && !sel.preEmi ? `<div style="margin-top:10px"><div class="small muted">How this EMI splits</div><div class="bar" style="margin-top:6px"><span style="width:${(sel.E / sel.D) * 100}%;background:var(--out)"></span><span style="width:${(sel.F / sel.D) * 100}%;background:var(--in)"></span></div>
            <div class="legend"><span><i style="background:var(--out)"></i>Interest ${pct(sel.E / sel.D, 0)}</span><span><i style="background:var(--in)"></i>Loan repaid ${pct(sel.F / sel.D, 0)}</span></div></div>` : ''}</div>
        </div></div>
      <div class="table-wrap tall"><table>
          <thead><tr><th>Month</th><th class="left">Stage</th><th>Rent in</th><th>EMI out</th><th>of which interest</th><th>of which loan repaid</th><th>Own money paid</th><th>Your pocket this month</th><th>Running total</th><th>Loan left</th><th>Rate</th></tr></thead>
          <tbody>${rows.map((r) => `<tr class="clickable ${r.k === TODAY ? 'is-today' : ''} ${r.k === sel.k ? 'selected' : ''}" data-action="pickMonth" data-k="${r.k}" tabindex="0">
            <td>${ml(r.k)}${r.k === TODAY ? ' <span class="tag today">today</span>' : ''}</td><td class="left">${phaseTag(r.phase)}</td>
            ${cell(r.C, 'in')}${cell(r.D, 'out')}${cell(r.E)}${cell(r.F)}${cell(r.AH, 'out')}
            <td class="${r.net < -0.5 ? 'out' : r.net > 0.5 ? 'in' : 'dash'}">${Math.abs(r.net) < 0.5 ? DASH : rs(r.net)}</td>
            <td>${short(r.cumNet)}</td><td>${short(r.H)}</td><td>${pct(r.B, 2)}</td></tr>`).join('')}</tbody>
          <tfoot><tr><td>Total</td><td></td><td>${short(sum('C'))}</td><td>${short(sum('D'))}</td><td>${short(sum('E'))}</td><td>${short(sum('F'))}</td><td>${short(sum('AH'))}</td><td>${short(sum('net'))}</td><td></td><td></td><td></td></tr></tfoot>
        </table></div>
      </div>`;
  }

  function yearlyView(R) {
    const sum = (f) => R.annual.reduce((s, a) => s + a[f], 0);
    return `
      <div class="panel" style="margin-bottom:16px"><div class="panel-head"><div><h3>What you owe vs what it's worth</h3><p>The gap between the green and red areas is your share of the property.</p></div></div>
        ${chart('owedChart', () => owedChart(R), '', 'Loan balance against property value by year')}</div>
      <div class="table-wrap"><table>
        <thead><tr><th>Year</th><th>Period</th><th>Rent in</th><th>EMI out</th><th>Interest</th><th>Loan repaid</th><th>Rent − EMI</th><th>Own money</th><th>Loan left</th><th>Property value</th></tr></thead>
        <tbody>${R.annual.map((a) => `<tr class="${TODAY >= a.from && TODAY <= a.to ? 'is-today' : ''}"><td>${a.year}</td><td>${ml(a.from)} to ${ml(a.to)}</td>
          <td class="in">${rs(a.rent)}</td><td class="out">${rs(a.emi)}</td><td>${rs(a.interest)}</td><td>${rs(a.principal)}</td>
          <td class="${a.net < 0 ? 'out' : 'in'}">${rs(a.net)}</td><td>${a.equity ? rs(a.equity) : DASH}</td><td>${short(a.loanEnd)}</td><td>${a.value === null ? '<span class="faint">before keys</span>' : short(a.value)}</td></tr>`).join('')}</tbody>
        <tfoot><tr><td>Total</td><td></td><td>${short(sum('rent'))}</td><td>${short(sum('emi'))}</td><td>${short(sum('interest'))}</td><td>${short(sum('principal'))}</td><td>${short(sum('net'))}</td><td>${short(sum('equity'))}</td><td></td><td></td></tr></tfoot>
      </table></div>
      <p class="small muted" style="margin-top:10px">Property value grows from the possession date, the same way the Excel calculates "Property Value at End of Projection". The Excel's yearly column S compounds from year 1 instead, even before possession, so it shows higher values. This app keeps both figures consistent.</p>`;
  }

  /* ---------- Explain it simply ---------- */
  VIEWS.explain = function () {
    return `<div class="view-head"><div><h1>Explain it simply</h1><p>A script you can read out to a parent, partner or friend who has never seen an EMI schedule. Every number is from your inputs.</p></div>
      <div class="no-print"><button class="btn" data-action="copyScript">Copy text</button></div></div>
      ${live('script', () => `<div class="script" id="scriptText">${scriptHTML()}</div>`)}`;
  };

  function scriptHTML() {
    const R = OUT.rental, EL = OUT.equityLoan;
    if (!R.ok) return `<p>${esc(R.reason)}</p>`;
    const r = focusRow();
    const firstEmi = R.rows.find((x) => x.D > 0 && !x.preEmi);
    const pre = R.rows.filter((x) => x.preEmi);
    const late = R.rows.filter((x) => x.D > 0 && !x.preEmi).slice(-1)[0];
    const s = [];
    s.push(`<p><b>The deal.</b> We bought ${esc(S.meta.name || 'this flat')}${S.meta.city ? ' in ' + esc(S.meta.city) : ''} for ${short(Number(S.purchasePrice) || EL.totalPaid)}. We paid ${short(EL.totalEquity)} from savings. The bank lent the other ${short(EL.totalLoan)}.</p>`);
    if (pre.length) s.push(`<p><b>While it was being built.</b> The bank paid the builder in instalments. Until we got the keys, we paid interest only on what the bank had released. That's called pre-EMI. It came to ${short(pre.reduce((a, x) => a + x.D, 0))} over ${dur(pre.length)}, and none of it reduced the loan.</p>`);
    if (firstEmi) s.push(`<p><b>The EMI.</b> From ${ml(firstEmi.k)} we pay the bank ${rs(firstEmi.D)} every month. Think of each EMI as two envelopes. One holds the bank's fee for lending (interest). The other pays back the loan (principal). In the first EMI, ${rs(firstEmi.E)} goes to interest and only ${rs(firstEmi.F)} to the loan.${late ? ` By the last years it flips: in ${ml(late.k)}, interest is just ${rs(late.E)} and ${rs(late.F)} repays the loan.` : ''}</p>`);
    if (R.milestones.firstRent !== null) {
      const fr = R.rows.find((x) => x.k === R.milestones.firstRent);
      s.push(`<p><b>The rent.</b> The tenant started paying ${rs(fr.C)} a month in ${ml(fr.k)}. It goes up ${pct(Number(S.rental.rentIncrease), 0)} every year.</p>`);
    }
    if (r && (r.phase === 'topup' || r.phase === 'surplus')) s.push(`<p><b>Right now.</b> ${r.phase === 'topup' ? `Rent of ${rs(r.C)} doesn't fully cover the EMI of ${rs(r.D)}, so we add ${rs(r.D - r.C)} a month ourselves.` : `Rent of ${rs(r.C)} covers the EMI of ${rs(r.D)}, with ${rs(r.C - r.D)} spare.`}</p>`);
    if (R.milestones.rentBeatsEMI !== null) s.push(`<p><b>The turning point.</b> In ${ml(R.milestones.rentBeatsEMI)}, rent becomes bigger than the EMI. From then on the flat pays its own loan.</p>`);
    s.push(`<p><b>Over ${R.years} years.</b> Tenants pay us about ${short(R.totals.rent)}. We pay the bank ${short(R.totals.emi)}, and ${short(R.totals.interest)} of that is interest. Together with the upfront ${short(R.totals.equity)}, our own pocket ${R.totals.net < 0 ? 'funds' : 'gains'} ${short(Math.abs(R.totals.net))} in total.</p>`);
    if (R.valueEnd !== null) s.push(`<p><b>What we end up with.</b> By ${ml(R.end)} the flat should be worth about ${short(R.valueEnd)}${R.loanEndBal > 1 ? `, with ${short(R.loanEndBal)} still owed` : ', fully ours'}. Counting every rupee we put in, including the monthly top-ups, that works out to roughly ${pct(R.allInXIRR)} a year on our own money. For comparison, a bank FD pays around 7% before tax.</p>`);
    s.push(`<p><b>The three numbers to remember:</b> ${firstEmi ? 'EMI ' + rs(firstEmi.D) + ', ' : ''}rent ${rs(Number(S.rental.rent))} rising ${pct(Number(S.rental.rentIncrease), 0)} a year, and ${R.milestones.rentBeatsEMI !== null ? ml(R.milestones.rentBeatsEMI) + ' when rent overtakes the EMI' : 'the loan end in ' + ml(R.effEnd)}.</p>`);
    return s.join('');
  }

  /* ---------- Returns ---------- */
  VIEWS.returns = function () {
    return `<div class="view-head"><div><h1>Returns</h1><p>Three ways to look at the same investment. Each answers a different question, so the numbers differ. That's expected.</p></div></div>
      ${live('ret', () => {
        const EL = OUT.equityLoan, R = OUT.rental;
        const saleK = M.parse(S.sale.date);
        return `
        <div class="figs">
          <div class="fig"><div class="label">Hold ${R.years} years ${tip('All-in XIRR: counts your down payment, every monthly top-up and every rupee of spare rent, plus your share of the flat at the end.')}</div><div class="value">${pct(R.allInXIRR)}</div><div class="note">a year, all-in (Excel method ${pct(R.equityXIRR)})</div></div>
          <div class="fig"><div class="label">Sell in ${ml(saleK)} ${tip('Equity XIRR from the Equity + Loan sheet: assumes you pay interest only until the sale, then repay the loan from the sale price.')}</div><div class="value">${pct(EL.equityXIRR)}</div><div class="note">a year on your money</div></div>
          <div class="fig"><div class="label">Property itself ${tip('Property XIRR: ignores how you funded it. The return the flat earns, as if you paid cash.')}</div><div class="value">${pct(EL.propertyXIRR)}</div><div class="note">a year, ignoring the loan</div></div>
          <div class="fig"><div class="label">Bank FD benchmark</div><div class="value">~7%</div><div class="note">before tax, for comparison</div></div>
        </div>

        <div class="panel" style="margin-top:16px"><div class="panel-head"><div><h2>1. If you hold for ${R.years} years</h2><p>From the Rental Scenario sheet.</p></div></div>
          <div class="grid g2"><div>
            <div class="ledger-line"><span>Own money you put in</span><span class="num out">${rs(R.totals.equity)}</span></div>
            <div class="ledger-line"><span>Property value in ${ml(R.end)}</span><span class="num">${rs(R.valueEnd)}</span></div>
            <div class="ledger-line"><span>Less loan still owed</span><span class="num">${rs(R.loanEndBal)}</span></div>
            <div class="ledger-line"><span><b>Your share (equity) at the end</b></span><span class="num in"><b>${rs(R.equityEnd)}</b></span></div>
            <div class="ledger-line"><span>Return on your own money ${tip('Equity at end divided by own money paid, minus 1.')}</span><span class="num">${R.roeOnEquity === null ? DASH : (R.roeOnEquity * 100).toFixed(0) + '%'}</span></div>
            <div class="ledger-line"><span>Equity XIRR, Excel method ${tip('Upfront own money in, equity out at the end. Monthly top-ups and spare rent are left out.')}</span><span class="num">${pct(R.equityXIRR, 2)}</span></div>
            <div class="ledger-line"><span><b>Equity XIRR, all-in</b> ${tip('Adds every monthly top-up and every rupee of spare rent to the Excel method.')}</span><span class="num"><b>${pct(R.allInXIRR, 2)}</b></span></div>
          </div><div class="callout ${R.allInXIRR !== null && R.equityXIRR !== null && R.equityXIRR - R.allInXIRR > 0.01 ? 'warn' : ''}"><p><b>Why two numbers?</b> The Excel's long-term XIRR counts only your upfront own money and what you own at the end. It leaves out the monthly top-ups while rent is below the EMI, and the spare rent later. Over ${R.years} years, rent minus EMI nets to <b>${short(R.cumNetRentMinusEMI)}</b>.</p>
            <p>The all-in figure includes all of that, so it's the one to compare with an FD.${R.allInXIRR !== null && R.equityXIRR !== null && R.equityXIRR - R.allInXIRR > 0.01 ? ` Here it's ${pct(R.equityXIRR - R.allInXIRR)} lower, because your top-ups are large.` : ''}</p></div></div>
        </div>

        <div class="panel"><div class="panel-head"><div><h2>2. If you sell in ${ml(saleK)} for ${short(Number(S.sale.price))}</h2><p>From the Equity + Loan sheet. Assumes you pay only interest on the loan until the sale (no principal), then clear the loan from the sale proceeds. Change the sale month and price in Set up, step 6.</p></div></div>
          <div class="table-wrap"><table><thead><tr><th>#</th><th>Month</th><th>Amount</th><th>Paid by</th><th>Interest until sale</th></tr></thead>
            <tbody>${EL.rows.map((t) => `<tr><td>${t.n}</td><td>${ml(t.k)}</td><td>${rs(t.amount)}</td><td>${t.funding === 'Loan' ? '<span class="tag brand">Bank loan</span>' : '<span class="tag">Own money</span>'}</td><td>${t.funding === 'Loan' ? rs(t.interest) : DASH}</td></tr>`).join('')}</tbody>
            <tfoot><tr><td>Total</td><td></td><td>${rs(EL.totalPaid)}</td><td></td><td>${rs(EL.totalInterest)}</td></tr></tfoot></table></div>
          <div class="grid g2" style="margin-top:14px"><div>
            <div class="ledger-line"><span>Sale price</span><span class="num in">${rs(Number(S.sale.price))}</span></div>
            <div class="ledger-line"><span>Less loan repaid</span><span class="num out">${rs(EL.totalLoan)}</span></div>
            <div class="ledger-line"><span>Less interest paid</span><span class="num out">${rs(EL.totalInterest)}</span></div>
            <div class="ledger-line"><span><b>What reaches your pocket</b></span><span class="num"><b>${rs(EL.netSale)}</b></span></div>
          </div><div>
            <div class="ledger-line"><span>Equity XIRR ${tip('Yearly return on your own money, timing included.')}</span><span class="num">${pct(EL.equityXIRR, 2)}</span></div>
            <div class="ledger-line"><span>Property XIRR</span><span class="num">${pct(EL.propertyXIRR, 2)}</span></div>
            <div class="ledger-line"><span>Simple gain on the property</span><span class="num">${pct(EL.propertyROE)}</span></div>
            <div class="ledger-line"><span>Simple gain on your own money</span><span class="num">${pct(EL.equityROE)}</span></div>
          </div></div>
          ${EL.totalLoan > 0 && EL.equityXIRR !== null && EL.propertyXIRR !== null ? `<div class="callout ${EL.equityXIRR > EL.propertyXIRR ? 'good' : 'bad'}" style="margin-top:12px"><p>${EL.equityXIRR > EL.propertyXIRR ? `The loan works for you here: borrowing at ${pct(OUT.rates.rows[0] && OUT.rates.rows[0].rate, 1)} to own an asset growing faster lifts your return from ${pct(EL.propertyXIRR)} to ${pct(EL.equityXIRR)}.` : `The loan costs more than the property earns, so borrowing drags your return down from ${pct(EL.propertyXIRR)} to ${pct(EL.equityXIRR)}.`}</p></div>` : ''}
        </div>

`;
      })}
      <div class="panel"><div class="panel-head"><div><h2>3. If you had paid everything yourself</h2><p>From the Simple ROE and Tranche Payments without Loan sheets.</p></div></div>
        <div class="grid g2">${live('ret-c1', () => {
          const SR = OUT.simpleROE;
          return `<div class="ledger-line"><span>Purchase price</span><span class="num">${rs(Number(S.purchasePrice))}</span></div>
            <div class="ledger-line"><span>Selling price</span><span class="num">${rs(Number(S.sale.price))}</span></div>
            <div class="ledger-line"><span>Profit</span><span class="num in">${rs(SR.profit)}</span></div>
            <div class="ledger-line"><span>Simple ROE</span><span class="num">${pct(SR.roe)}</span></div>`;
        })}<div>
          ${fNum('roe.yearsOverride', 'Holding period in years', 'Leave blank to count from your first payment to the sale month.', 'step="0.5" min="0"')}
          ${live('ret-c2', () => {
            const SR = OUT.simpleROE, SF = OUT.selfFunded;
            return `<div class="ledger-line"><span>Holding period used</span><span class="num">${SR.years === null ? DASH : SR.years.toFixed(2) + ' years'}</span></div>
            <div class="ledger-line"><span>Yearly growth (CAGR) ${tip('Compound annual growth: the steady yearly rate that turns the purchase price into the selling price.')}</span><span class="num">${pct(SR.cagr, 2)}</span></div>
            <div class="ledger-line"><span>XIRR on instalments ${tip('Like CAGR but credits you for paying in stages, which is why it is higher.')}</span><span class="num">${pct(SF.xirr, 2)}</span></div>`;
          })}
        </div></div>
      </div>`;
  };

  /* ---------- Compare plans ---------- */
  VIEWS.plans = function () {
    const tab = ui('planTab', 0);
    const P = S.plans.plans[tab] || S.plans.plans[0];
    const pi = S.plans.plans.indexOf(P);
    return `<div class="view-head"><div><h1>Compare payment plans</h1><p>Builders offer different schedules: 20:80, construction-linked, possession-linked. A rupee paid later costs you less today, because you could earn interest on it meanwhile. This page puts every plan in today's money so you can compare fairly.</p></div></div>
      <div class="panel"><div class="fields">
        ${fPct('plans.discountRate', 'What your money could earn instead', 'Your FD or loan rate. The Excel uses 7.2%.')}
        ${fMonth('plans.baseOverride', 'Compare in money of (optional)', 'Blank = the earliest payment across plans.', true)}
      </div></div>
      ${live('plans-sum', plansSummary)}
      <div class="panel">
        <div class="panel-head"><div class="seg" role="tablist">${S.plans.plans.map((p, i) => `<button type="button" role="tab" data-action="ui" data-key="planTab" data-val="${i}" data-num="1" aria-pressed="${i === pi}">${esc(p.name)}</button>`).join('')}</div>
          <div><button class="btn small" data-action="addPlan" ${S.plans.plans.length >= 5 ? 'disabled' : ''}>＋ Add plan</button> ${S.plans.plans.length > 2 ? `<button class="btn small ghost danger" data-action="delPlan" data-i="${pi}">Remove this plan</button>` : ''}</div></div>
        <div class="fields">
          ${fText(`plans.plans.${pi}.name`, 'Plan name', 'Tab label updates when you switch tabs.')}
          ${fMoney(`plans.plans.${pi}.price`, 'Total price in this plan', 'Builders often charge more for a lighter upfront payment.')}
          ${fPct(`plans.plans.${pi}.loanRate`, 'Loan interest rate', '')}
          ${fMonth(`plans.plans.${pi}.possession`, 'Possession month', 'Blank = last payment month. Loan interest runs from each loan payment until possession.', true)}
        </div>
        <p class="small muted" style="margin:14px 0 6px">Fill either the amount or the % of price for each payment. The other is worked out for you.</p>
        <div class="table-wrap"><table class="edit-table"><thead><tr><th>#</th><th style="text-align:left">Month</th><th style="text-align:left">Amount</th><th style="text-align:left">or % of price</th><th style="text-align:left">Paid by</th><th></th></tr></thead><tbody>
          ${P.rows.map((r, i) => `<tr><td class="idx">${i + 1}</td><td style="min-width:200px">${monthPick(`plans.plans.${pi}.rows.${i}.date`)}</td>
            <td style="min-width:160px">${inMoney(`plans.plans.${pi}.rows.${i}.amount`)}</td><td style="min-width:110px">${inPct(`plans.plans.${pi}.rows.${i}.pct`)}</td>
            <td><select data-bind="plans.plans.${pi}.rows.${i}.funding" data-kind="text"><option value="Equity" ${r.funding !== 'Loan' ? 'selected' : ''}>Own money</option><option value="Loan" ${r.funding === 'Loan' ? 'selected' : ''}>Bank loan</option></select></td>
            <td><button class="btn ghost small danger" data-action="delPlanRow" data-p="${pi}" data-i="${i}">Remove</button></td></tr>`).join('')}
        </tbody></table></div>
        <p style="margin-top:8px"><button class="btn small" data-action="addPlanRow" data-p="${pi}">＋ Add a payment</button></p>
        ${live('plan-detail', () => planDetail(pi))}
      </div>`;
  };

  function plansSummary() {
    const C = OUT.plans;
    const valid = C.plans.filter((p) => p.rows.some((x) => x.amount));
    return `<div class="panel"><div class="panel-head"><div><h2>Result</h2><p>All amounts in ${ml(C.base)} rupees, at ${pct(Number(S.plans.discountRate), 1)} a year.</p></div></div>
      ${C.best ? `<div class="callout good" style="margin-bottom:14px"><p><b>${esc(C.best)} is cheapest</b> in today's money, by <b>${rs(C.savings)}</b> over the next best option.</p></div>` : ''}
      <div class="table-wrap"><table><thead><tr><th>Plan</th><th>Price</th><th>Loan</th><th>Interest till possession</th><th>Payments, today's value</th><th>Interest, today's value</th><th>Total cost, today's value</th><th>Check</th></tr></thead>
      <tbody>${C.plans.map((p) => `<tr class="${p.name === C.best ? 'best-row' : ''}"><td>${esc(p.name)}${p.name === C.best ? ' <span class="tag in">cheapest</span>' : ''}</td><td>${short(p.price)}</td><td>${short(p.loanTotal)}</td><td>${short(p.interestNominal)}</td><td>${short(p.pvPay)}</td><td>${short(p.pvInt)}</td><td><b>${rs(p.pvTotal)}</b></td>
        <td>${Math.abs(p.difference) < 1 ? '<span class="tag in">adds up</span>' : `<span class="tag out">${p.difference > 0 ? 'over' : 'short'} by ${short(Math.abs(p.difference))}</span>`}</td></tr>`).join('')}</tbody></table></div>
      ${valid.length ? chart('plansChart', () => {
        const o = baseOpts(); o.scales.x.stacked = true; o.scales.y.stacked = true;
        return { type: 'bar', data: { labels: C.plans.map((p) => p.name), datasets: [
          { label: 'Payments (today\u2019s value)', data: C.plans.map((p) => p.pvPay), backgroundColor: css('--brand') },
          { label: 'Loan interest (today\u2019s value)', data: C.plans.map((p) => p.pvInt), backgroundColor: css('--out') }] }, options: o };
      }, 'short', 'Plan costs compared') : ''}</div>`;
  }

  function planDetail(pi) {
    const p = OUT.plans.plans[pi];
    return `<div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>#</th><th>Month</th><th>Amount used</th><th>% used</th><th>Paid by</th><th>Today's value</th><th>Loan interest, today's value</th></tr></thead>
      <tbody>${p.rows.map((r) => `<tr><td>${r.n}</td><td>${ml(r.k)}</td><td>${rs(r.amount)}</td><td>${pct(r.pct, 1)}</td><td>${r.funding === 'Loan' ? 'Bank loan' : 'Own money'}</td><td>${rs(r.pv)}</td><td>${r.pvInt === null ? DASH : rs(r.pvInt)}</td></tr>`).join('')}</tbody>
      <tfoot><tr><td>Total</td><td></td><td>${rs(p.used)}</td><td></td><td></td><td>${rs(p.pvPay)}</td><td>${rs(p.pvInt)}</td></tr></tfoot></table></div>
      <p class="small muted" style="margin-top:8px">Possession used: ${ml(p.poss)}${M.parse(S.plans.plans[pi].possession) === null ? ' (last payment month)' : ''}.</p>`;
  }

  /* ---------- Leverage ---------- */
  VIEWS.leverage = function () {
    return `<div class="view-head"><div><h1>Loan vs own money</h1><p>How much should you borrow? More loan means less cash upfront but a bigger EMI. This table finds the mix where rent pays the EMI.</p></div></div>
      ${live('lev', () => {
        const L = OUT.leverage;
        const tot = OUT.equityLoan.totalPaid || 1;
        const yourEq = OUT.equityLoan.totalEquity / tot;
        const nearest = L.rows.reduce((b, r) => (Math.abs(r.equityPct - yourEq) < Math.abs(b.equityPct - yourEq) ? r : b), L.rows[0]);
        const cell = (v) => (v === 'Never' ? '<span class="out">never</span>' : v === null ? DASH : v === 0 ? '<span class="in">already</span>' : dur(v));
        return `<div class="figs"><div class="fig"><div class="label">Property value</div><div class="value">${short(L.value)}</div></div>
          <div class="fig"><div class="label">Rent at start</div><div class="value">${rs(L.rent)}</div><div class="note">rising ${pct(L.g, 0)} a year</div></div>
          <div class="fig"><div class="label">Interest rate</div><div class="value">${pct(L.rate, 2)}</div><div class="note">first rate in your schedule</div></div>
          <div class="fig"><div class="label">Tenure</div><div class="value">${dur(L.n)}</div></div></div>
        ${L.sweetSpot ? `<div class="callout good" style="margin-top:16px"><p>Put in <b>${pct(L.sweetSpot.equityPct, 0)}</b> of your own money (${short(L.sweetSpot.equity)}) and borrow ${short(L.sweetSpot.loan)}: rent covers the EMI from day one. You're at about ${pct(yourEq, 0)} own money now.</p></div>` : ''}
        <div class="panel" style="margin-top:16px">${chart('levChart', () => {
          const o = baseOpts();
          return { type: 'bar', data: { labels: L.rows.map((r) => pct(r.equityPct, 0)), datasets: [{ label: 'Monthly top-up (EMI − rent)', data: L.rows.map((r) => r.outflow), backgroundColor: L.rows.map((r) => (r.outflow > 0 ? css('--out') : css('--in'))) }] }, options: o };
        }, 'short', 'Monthly top-up by own money share')}</div>
        <div class="table-wrap" style="margin-top:16px"><table><thead><tr><th>Own money</th><th>Own money ₹</th><th>Loan ₹</th><th>Interest a month</th><th>Rent ÷ interest</th><th>EMI</th><th>Rent ÷ EMI</th><th>Until rent > interest</th><th>Until rent > EMI</th><th>Monthly top-up</th></tr></thead>
          <tbody>${L.rows.map((r) => `<tr class="${r === nearest ? 'is-today' : ''} ${r === L.sweetSpot ? 'best-row' : ''}"><td>${pct(r.equityPct, 0)}${r === nearest ? ' <span class="tag today">you</span>' : ''}${r === L.sweetSpot ? ' <span class="tag in">rent covers EMI</span>' : ''}</td>
            <td>${short(r.equity)}</td><td>${short(r.loan)}</td><td>${rs(r.interest)}</td><td>${r.rentToInterest === null ? DASH : r.rentToInterest.toFixed(2) + '×'}</td><td>${rs(r.emi)}</td><td>${r.rentToEMI === null ? DASH : r.rentToEMI.toFixed(2) + '×'}</td>
            <td>${cell(r.monthsToInterest)}</td><td>${cell(r.monthsToEMI)}</td><td class="${r.outflow > 0 ? 'out' : 'in'}">${rs(r.outflow)}</td></tr>`).join('')}</tbody></table></div>
        <p class="small muted" style="margin-top:10px">Like the Excel, this uses one constant rate and the full tenure, and measures from rent at the start. For exact month-by-month figures with rate changes, use Monthly cash flow.</p>`;
      })}`;
  };

  /* ---------- What if ---------- */
  VIEWS.whatif = function () {
    const sel = S.scenario.selected;
    const t = S.scenario.table[sel];
    return `<div class="view-head"><div><h1>What if? Stress test</h1><p>Rates rise. A tenant leaves. Rent drops. See how long until rent covers your loan in each case, and how much you'd top up each month.</p></div></div>
      <div class="panel"><div class="panel-head"><div><h3>Pick a mood</h3><p>Each comes with its own assumptions, which you can edit.</p></div>${seg('scenario.selected', [{ v: 'Base', l: 'Base' }, { v: 'Conservative', l: 'Cautious' }, { v: 'Aggressive', l: 'Optimistic' }], 'segFull')}</div>
        <div class="fields">
          ${fPct(`scenario.table.${sel}.rentEsc`, 'Rent increase a year', '')}
          ${fPct(`scenario.table.${sel}.vacancy`, 'Vacancy', 'Share of the year the flat sits empty. 5% is about 18 days.')}
          ${fPct(`scenario.table.${sel}.appreciation`, 'Price growth a year', 'Used for the exit value below.')}
          ${fPct(`scenario.table.${sel}.sellCost`, 'Selling cost', 'Brokerage and other costs when you sell.')}
          ${fPct('scenario.rentShock', 'Rent shock', 'E.g. −10 if a new tenant pays 10% less.')}
          ${fPct('scenario.interestShock', 'Interest rate shock', 'E.g. 1 for a 1% rate rise.')}
        </div></div>
      ${live('wi', () => {
        const W = OUT.scenarios;
        const k = W.keys;
        const cls = (v, kind) => {
          if (kind === 'm') return v === null ? 'heat-bad' : v === 0 ? 'heat-good' : v <= 36 ? 'heat-mid' : 'heat-bad';
          return v <= 0 ? 'heat-good' : v < 10000 ? 'heat-mid' : 'heat-bad';
        };
        const grid = (g, kind, title, help) => `<div class="panel"><div class="panel-head"><div><h3>${title}</h3><p>${help}</p></div></div>
          <div class="table-wrap"><table><thead><tr><th class="left">Rent ↓ Rate →</th>${W.intShocks.map((s) => `<th>${s === 0 ? 'No change' : '+' + pct(s, 0)}</th>`).join('')}</tr></thead>
          <tbody>${g.map((row, i) => `<tr><td>${W.rentShocks[i] === 0 ? 'No change' : pct(W.rentShocks[i], 0).replace('-', '−')}</td>${row.map((v) => `<td class="${cls(v, kind)}">${kind === 'm' ? durS(v) : rs(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`;
        return `<div class="figs" style="margin-top:16px">
            <div class="fig"><div class="label">Rent after vacancy and shock</div><div class="value in">${rs(k.effRent)}</div><div class="note">a month</div></div>
            <div class="fig"><div class="label">EMI at ${pct(k.effRate, 2)}</div><div class="value out">${rs(k.emi)}</div><div class="note">constant rate, full tenure</div></div>
            <div class="fig"><div class="label">Until rent > EMI</div><div class="value">${k.monthsToEMI === null ? 'never' : k.monthsToEMI === 0 ? 'now' : dur(k.monthsToEMI)}</div><div class="note">until rent > interest: ${k.monthsToInterest === null ? 'never' : k.monthsToInterest === 0 ? 'now' : dur(k.monthsToInterest)}</div></div>
            <div class="fig"><div class="label">Monthly top-up at start</div><div class="value ${k.outflow > 0 ? 'out' : 'in'}">${rs(k.outflow)}</div></div></div>
          ${W.exit ? `<div class="callout" style="margin-top:16px"><p>Selling in ${ml(W.exit.k)} at ${pct(W.scenario.appreciation, 0)} growth: about <b>${short(W.exit.gross)}</b>, or <b>${short(W.exit.net)}</b> after ${pct(W.scenario.sellCost, 1)} selling costs. (Added in the app; the Excel lists these two inputs but doesn't use them.)</p></div>` : ''}
          <div class="grid g2" style="margin-top:16px">
            ${grid(W.gridEMI, 'm', 'How long until rent covers the EMI', 'Green: already. Amber: within 3 years. Red: longer, or never.')}
            ${grid(W.gridInterest, 'm', 'How long until rent covers the interest', 'The first milestone: rent pays the bank\u2019s fee, you only fund the principal.')}
          </div>
          ${grid(W.gridOutflow, 'r', 'Monthly top-up from your pocket at the start', 'EMI minus rent after vacancy. Negative means money left over.')}
          <p class="small muted">Same simplification as the Excel: constant rate over the full tenure, starting from today's rent. The Excel fixes vacancy at 5% whichever scenario you pick. Here vacancy follows the scenario.</p>`;
      })}`;
  };

  /* ---------- Spare money ---------- */
  VIEWS.spare = function () {
    return `<div class="view-head"><div><h1>Spare rent and prepaying</h1><p>Once rent is bigger than the EMI, you have money left over every month. Here's what it becomes if you save it, or if you use it to close the loan early.</p></div></div>
      <div class="panel"><div class="fields">
        ${fPct('spare.rd', 'Recurring deposit rate', '')}
        ${fPct('spare.fd', 'Fixed deposit rate', '')}
        ${fPct('spare.mf', 'Mutual fund return (expected)', 'Equity funds have no guaranteed return.')}
      </div></div>
      ${live('sp', () => {
        const R = OUT.rental;
        const totalSpare = R.rows.reduce((s, r) => s + r.V, 0);
        const fc = R.foreclosure;
        const firstSpare = R.rows.find((r) => r.V > 0);
        return `
        <div class="figs" style="margin-top:16px">
          <div class="fig"><div class="label">Spare rent over ${R.years} years</div><div class="value in">${short(totalSpare)}</div><div class="note">${firstSpare ? 'starting ' + ml(firstSpare.k) : 'rent never exceeds EMI'}</div></div>
          <div class="fig"><div class="label">In a recurring deposit</div><div class="value">${short(R.spare.rd)}</div><div class="note">by ${ml(R.end)}</div></div>
          <div class="fig"><div class="label">In a fixed deposit</div><div class="value">${short(R.spare.fd)}</div><div class="note">by ${ml(R.end)}</div></div>
          <div class="fig"><div class="label">In mutual funds</div><div class="value in">${short(R.spare.mf)}</div><div class="note">by ${ml(R.end)}</div></div>
        </div>
        ${totalSpare > 0 ? `<div class="panel" style="margin-top:16px"><div class="panel-head"><h3>How the savings grow</h3></div>${chart('spChart', () => {
          const pts = R.annual.map((a) => R.rows.find((r) => r.k === a.to) || R.rows[R.rows.length - 1]);
          const o = baseOpts();
          return { type: 'line', data: { labels: R.annual.map((a) => 'Yr ' + a.year), datasets: [
            { label: 'Mutual fund', data: pts.map((r) => r.Y), borderColor: css('--in'), pointRadius: 0, borderWidth: 2 },
            { label: 'Fixed deposit', data: pts.map((r) => r.X), borderColor: css('--brand'), pointRadius: 0, borderWidth: 2 },
            { label: 'Recurring deposit', data: pts.map((r) => r.W), borderColor: css('--today'), pointRadius: 0, borderWidth: 2 }] }, options: o };
        }, '', 'Growth of spare rent')}</div>` : ''}
        <div class="panel"><div class="panel-head"><div><h2>Or: pay the loan off early</h2><p>Every rupee of spare rent goes to the bank as a prepayment. Floating-rate home loans in India carry no prepayment penalty for individuals.</p></div></div>
          ${fc ? `<div class="grid g2"><div>
            <div class="ledger-line"><span>Loan closes</span><span class="num in"><b>${ml(fc.k)}</b></span></div>
            <div class="ledger-line"><span>Months from start of schedule</span><span class="num">${fc.months}</span></div>
            <div class="ledger-line"><span>Instead of</span><span class="num">${ml(R.effEnd)}</span></div>
            <div class="ledger-line"><span>Earlier by</span><span class="num in"><b>${dur(R.effEnd - fc.k)}</b></span></div>
          </div><div class="callout good"><p>Prepaying cuts your interest bill and frees the full rent sooner. Investing grows a separate pot. A simple rule: if the loan rate after tax is above what you expect from investments, prepay.</p></div></div>`
          : '<div class="callout">Within this projection, spare rent never clears the loan early. Rent may not exceed the EMI for long enough.</div>'}
        </div>`;
      })}`;
  };

  /* ---------- Overdraft ---------- */
  VIEWS.od = function () {
    return `<div class="view-head"><div><h1>Overdraft home loan</h1><p>Products like SBI MaxGain or ICICI Money Saver link a current account to your loan. Money you park there is subtracted from the loan when interest is worked out, yet you can withdraw it any time.</p></div></div>
      <div class="panel"><div class="fields">
        <div class="field"><span class="lbl">Include the overdraft?</span><label class="switch"><input type="checkbox" data-bind="od.enabled" data-kind="bool" data-rerender="1" ${S.od.enabled ? 'checked' : ''}> ${S.od.enabled ? 'Yes, include it' : 'No'}</label></div>
        ${fPct('od.rate', 'Overdraft loan interest rate', 'Usually 0.2% to 0.5% above a regular home loan.')}
      </div>
      <h3 style="margin:18px 0 8px">Money parked and taken out</h3>
      <div class="table-wrap"><table class="edit-table"><thead><tr><th style="text-align:left">Month</th><th style="text-align:left">Type</th><th style="text-align:left">Amount</th><th></th></tr></thead><tbody>
        ${S.od.txns.map((t, i) => `<tr><td style="min-width:200px">${monthPick('od.txns.' + i + '.date')}</td>
          <td><select data-bind="od.txns.${i}.type" data-kind="text"><option value="deposit" ${t.type !== 'withdraw' ? 'selected' : ''}>Parked (deposit)</option><option value="withdraw" ${t.type === 'withdraw' ? 'selected' : ''}>Taken out</option></select></td>
          <td style="min-width:170px">${inMoney('od.txns.' + i + '.amount')}</td><td><button class="btn ghost small danger" data-action="delOD" data-i="${i}">Remove</button></td></tr>`).join('')}
      </tbody></table></div>
      <p style="margin-top:8px"><button class="btn small" data-action="addOD">＋ Add an entry</button></p></div>
      ${live('odl', () => {
        const R = OUT.rental, O = R.od;
        if (!S.od.enabled) return '<div class="callout" style="margin-top:16px">Switch the overdraft on to see its effect.</div>';
        if (!O) return '<div class="callout warn" style="margin-top:16px">Add a loan in Set up first.</div>';
        return `<div class="figs" style="margin-top:16px">
          <div class="fig"><div class="label">Interest saved ${tip('Regular interest minus overdraft interest, summed over the projection. Can be negative in months when the overdraft rate is higher and little money is parked.')}</div><div class="value ${O.interestSaved >= 0 ? 'in' : 'out'}">${short(O.interestSaved)}</div></div>
          <div class="fig"><div class="label">Loan closes</div><div class="value">${ml(O.odDate)}</div><div class="note">${O.months === null ? 'not within projection' : O.months + ' months from first disbursement'}</div></div>
          <div class="fig"><div class="label">Without overdraft</div><div class="value">${ml(O.baseDate)}</div><div class="note">${O.baseMonths} months</div></div>
          <div class="fig"><div class="label">Months saved</div><div class="value in">${O.monthsSaved === null ? DASH : O.monthsSaved}</div><div class="note">${O.monthsSaved ? dur(O.monthsSaved) + ' sooner' : ''}</div></div></div>
          <div class="panel" style="margin-top:16px">${chart('odChart', () => {
            const rows = R.rows.filter((r) => r.T > 0);
            const o = baseOpts();
            return { type: 'line', data: { labels: rows.map((r) => ml(r.k)), datasets: [
              { label: 'Loan, regular', data: rows.map((r) => r.H), borderColor: css('--out'), pointRadius: 0, borderWidth: 2 },
              { label: 'Loan, with overdraft', data: rows.map((r) => r.AS), borderColor: css('--in'), pointRadius: 0, borderWidth: 2 },
              { label: 'Money parked', data: rows.map((r) => r.AI), borderColor: css('--today'), pointRadius: 0, borderWidth: 2, borderDash: [4, 3] }] }, options: o };
          }, '', 'Loan balance with and without overdraft')}</div>
          <p class="small muted">As in the Excel, the overdraft schedule keeps the EMI fixed (it doesn't recalculate on rate changes) and charges the overdraft rate on the loan minus money parked.</p>`;
      })}`;
  };

  /* ---------- Learn ---------- */
  const TERMS = [
    ['EMI', 'Equated Monthly Instalment. The fixed amount you pay the bank every month. Part is interest, part repays the loan.'],
    ['Pre-EMI', 'Interest-only payments while an under-construction flat is being built. You pay interest on what the bank has released so far. It doesn\u2019t reduce the loan.'],
    ['Principal', 'The amount you borrowed and still owe. Each EMI chips away at it.'],
    ['Interest', 'The bank\u2019s charge for lending. Early EMIs are mostly interest; later ones are mostly principal.'],
    ['Tranche', 'One instalment paid to the builder. Construction-linked plans release money in tranches as floors get built.'],
    ['Possession', 'The month you get the keys. Rent can start only after this.'],
    ['Own money (equity)', 'What you pay from savings. Also your share of the property: value minus loan.'],
    ['Leverage', 'Using a loan to buy more than your savings allow. It amplifies gains and losses.'],
    ['XIRR', 'Your yearly return when money goes in and comes out on different dates. Think: the FD rate that would give you the same result.'],
    ['CAGR', 'Steady yearly growth from a start value to an end value. Ignores when you paid in between.'],
    ['ROE', 'Return on equity: profit divided by your own money. Doesn\u2019t account for time.'],
    ['Present value', 'What a future payment is worth today. ₹1 lakh paid in 3 years is worth less than ₹1 lakh today, because today\u2019s money can earn interest.'],
    ['Discount rate', 'The rate used to convert future money into today\u2019s money. Usually your FD rate or loan rate.'],
    ['Floating rate', 'A loan rate linked to the RBI repo rate. It moves when RBI changes rates.'],
    ['Prepayment', 'Paying extra to the bank to cut the loan faster. No penalty on floating-rate home loans for individuals.'],
    ['Foreclosure', 'Paying off the whole loan before the tenure ends.'],
    ['Overdraft home loan', 'A loan linked to a current account. Money parked there reduces interest, and you can withdraw it.'],
    ['Vacancy', 'Months the flat sits empty between tenants. 1 month a year is about 8%.'],
    ['Rent escalation', 'The yearly rise written into the rent agreement, often 5% to 10%.'],
    ['Appreciation', 'How fast the property\u2019s market value rises each year.'],
    ['Stress test', 'Checking the numbers under bad conditions: higher rates, lower rent.']
  ];
  VIEWS.learn = function () {
    return `<div class="view-head"><div><h1>Jargon buster</h1><p>Every term used in this app, in one or two lines.</p></div></div>
      <div class="panel"><div class="terms">${TERMS.map((t) => `<div class="term"><h3>${t[0]}</h3><p>${t[1]}</p></div>`).join('')}</div></div>
      <div class="panel"><h3>How the app calculates</h3><p class="muted">Every formula comes from the Real Estate Decision Suite v3 workbook. The project folder includes <code>docs/HOW-IT-WORKS.md</code>, which maps each number to its Excel cell, and a test that checks 45 results against Excel to the rupee.</p></div>`;
  };

  /* ---------- Data ---------- */
  VIEWS.data = function () {
    const n = Object.keys(DB.properties).length;
    return `<div class="view-head"><div><h1>Save, export, reset</h1><p>Your inputs save automatically in this browser. Use a backup file to move them to another device or share with your CA.</p></div></div>
      <div class="grid g2">
        <div class="panel"><h3>Backup</h3><p class="muted small">A small file with every input for this property.</p>
          <p><button class="btn" data-action="exportJSON">Download backup</button> <button class="btn ghost" data-action="copyJSON">Copy backup text</button></p>
          <h3 style="margin-top:18px">Restore</h3><p class="muted small">Opens as a new property. Nothing is overwritten.</p>
          <p><label class="btn">Choose backup file<input type="file" accept="application/json,.json" data-action-change="importFile" hidden></label> <button class="btn ghost" data-action="pasteJSON">Paste backup text</button></p></div>
        <div class="panel"><h3>Export</h3>
          <p><button class="btn" data-action="csv">Monthly cash flow (CSV for Excel)</button></p>
          <p><button class="btn" data-action="print">Print or save as PDF</button></p>
          <h3 style="margin-top:18px">Start over</h3>
          <p><button class="btn" data-action="loadSample">Load the Excel sample</button> <button class="btn" data-action="quickstart">Quick start</button></p>
          <p><button class="btn danger" data-action="deleteProp" ${n < 2 ? 'disabled' : ''}>Delete this property</button> ${n < 2 ? '<small class="faint">Add another first.</small>' : ''}</p></div>
      </div>`;
  };

  /* ---------- Upgrade ---------- */
  VIEWS.upgrade = function () {
    if (isPro()) return `<div class="view-head"><div><h1>You're on Pro</h1><p>Thank you. Every feature is unlocked on this device.</p></div></div>
      <div class="panel upgrade"><p>Licence: <code>${esc(DB.pro.key)}</code></p><p><button class="btn ghost danger" data-action="removeLicence">Remove licence from this device</button></p></div>`;
    return `<div class="view-head"><div><h1>Upgrade to Pro</h1><p>Make every big property decision with the full toolkit.</p></div></div>
      <div class="panel upgrade"><div class="price">${esc(MON.priceLabel || '')}</div><p class="muted">${esc(MON.priceNote || '')}</p>
        <ul class="checklist"><li>Compare builder payment plans in today's money</li><li>Find the right loan and own-money mix</li><li>Stress test rate hikes, vacancy and rent cuts</li><li>Spare-rent, prepayment and overdraft planners</li><li>A read-aloud explanation for family</li><li>Unlimited properties, CSV export and print</li></ul>
        <p>${MON.paymentLink ? `<a class="btn primary" href="${esc(MON.paymentLink)}" target="_blank" rel="noopener" data-action="buyClick">Buy Pro</a>` : '<span class="callout warn">Payment link not set yet. Add it in js/config.js.</span>'}</p>
        <h3 style="margin-top:20px">Already bought?</h3><p class="muted small">Enter the licence key from your email.</p>
        <div style="display:flex;gap:8px;max-width:420px"><input id="licKey" type="text" placeholder="XXXX-XXXX-XXXX" autocomplete="off"><button class="btn" data-action="activate">Activate</button></div></div>`;
  };

  function gateView(item) {
    return `<div class="view-head"><div><h1>${esc(item.label)}</h1></div></div>
      <div class="panel gate"><span class="tag today">Pro</span><h2 style="margin:10px 0 6px">This tool is part of Pro</h2>
      <p class="muted">Your overview, setup, monthly cash flow and returns stay free.</p>
      <p><button class="btn primary" data-go="upgrade">See what Pro includes</button></p></div>`;
  }

  /* ================================================================ */
  /* Quick start dialog: the 2-minute path for a ready flat on a loan  */
  /* ================================================================ */
  function quickStart() {
    const d = document.getElementById('dialog');
    const t = TODAY;
    const mo = (name, k) => `<div class="mpick" data-qs="${name}"><select data-part="m" aria-label="Month">${MONTHS.map((n, i) => `<option value="${i + 1}" ${(k % 12) === i ? 'selected' : ''}>${n}</option>`).join('')}</select><select data-part="y" aria-label="Year">${YEARS.map((y) => `<option ${y === Math.floor(k / 12) ? 'selected' : ''}>${y}</option>`).join('')}</select></div>`;
    d.innerHTML = `<form method="dialog" id="qsForm">
      <h2>Quick start</h2><p class="muted small">For a flat you've already bought on a home loan. You can fine-tune everything in Set up afterwards.</p>
      <div class="fields" style="grid-template-columns:1fr 1fr">
        <div class="field"><label>Name</label><input name="name" value="My flat"></div>
        <div class="field"><label>City</label><input name="city" value="Pune"></div>
        <div class="field"><label>Total price</label><div class="affix"><span>₹</span><input name="price" type="number" required placeholder="e.g. 8000000"></div></div>
        <div class="field"><label>Loan amount</label><div class="affix"><span>₹</span><input name="loan" type="number" required placeholder="e.g. 6400000"></div></div>
        <div class="field"><span class="lbl">Loan started</span>${mo('loanStart', t - 12)}</div>
        <div class="field"><label>Tenure (years)</label><input name="tenure" type="number" value="20" min="1" max="30"></div>
        <div class="field"><label>Interest rate today</label><div class="affix"><input name="rate" type="number" step="0.05" value="8.5"><span>%</span></div></div>
        <div class="field"><span class="lbl">Keys received</span>${mo('poss', t - 12)}</div>
        <div class="field"><span class="lbl">Rent started</span>${mo('rentStart', t - 1)}</div>
        <div class="field"><label>Monthly rent</label><div class="affix"><span>₹</span><input name="rent" type="number" required placeholder="e.g. 25000"></div></div>
        <div class="field"><label>Rent rise a year</label><div class="affix"><input name="rentInc" type="number" step="0.5" value="5"><span>%</span></div></div>
        <div class="field"><label>Value today</label><div class="affix"><span>₹</span><input name="value" type="number" placeholder="Blank = price"></div></div>
      </div>
      <div class="field" style="margin-top:12px"><label class="switch"><input type="checkbox" name="preemi"> I paid pre-EMI (interest only) until I got the keys</label></div>
      <p class="small faint" style="margin-top:10px">Saved as a new property. Your current one stays as it is.</p>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px"><button class="btn ghost" value="cancel" formnovalidate>Cancel</button><button class="btn primary" value="ok">Build my cash flow</button></div>
    </form>`;
    d.showModal();
    const form = d.querySelector('#qsForm');
    form.addEventListener('submit', (ev) => {
      if (ev.submitter && ev.submitter.value === 'cancel') return;
      const f = new FormData(form);
      const getM = (n) => { const w = form.querySelector(`[data-qs="${n}"]`); return w.querySelector('[data-part="y"]').value + '-' + String(w.querySelector('[data-part="m"]').value).padStart(2, '0'); };
      const price = Number(f.get('price')) || 0, loan = Math.min(Number(f.get('loan')) || 0, price);
      const ls = getM('loanStart'), poss = getM('poss');
      const tenure = Math.max(1, Number(f.get('tenure')) || 20);
      const lsK = M.parse(ls);
      const preemi = !!f.get('preemi');
      const st = E.sampleState();
      st.meta = { name: String(f.get('name') || 'My flat'), city: String(f.get('city') || '') };
      st.purchasePrice = price;
      st.tranches = [{ date: ls, amount: price - loan, funding: 'Equity' }, { date: ls, amount: loan, funding: 'Loan' }].filter((x) => x.amount > 0);
      st.loan = { start: ls, end: M.str(lsK + tenure * 12 - 1), emiStarts: preemi ? 'possession' : 'loanStart', behaviour: 'change' };
      st.rates = [{ start: '', rate: (Number(f.get('rate')) || 8.5) / 100, note: 'Rate today' }];
      st.rental = { possession: poss, valueAtPossession: Number(f.get('value')) || price, appreciation: 0.05, rentStart: getM('rentStart'), rentEnd: '', rent: Number(f.get('rent')) || 0, rentIncrease: (Number(f.get('rentInc')) || 0) / 100, years: Math.max(tenure + 1, 20) };
      st.sale = { date: M.str(lsK + 60), price: Math.round(price * Math.pow(1.05, 5)) };
      st.od = { enabled: false, rate: st.rates[0].rate + 0.0025, txns: [] };
      if (!addProperty(st)) return;
      track('quickstart_done');
      toast('Your property is ready');
      go('overview');
    });
  }

  function addProperty(st) {
    const n = Object.keys(DB.properties).length;
    const onlySample = n === 1 && /sample/i.test(DB.properties[DB.active].meta.name || '');
    if (MON.enabled && !isPro() && n >= (MON.freePropertyLimit || 1) && !onlySample) {
      toast('Free plan holds ' + (MON.freePropertyLimit || 1) + ' property. Upgrade for more.');
      go('upgrade');
      return false;
    }
    const id = uid();
    if (onlySample && MON.enabled && !isPro()) delete DB.properties[DB.active];
    DB.properties[id] = withDefaults(st);
    DB.active = id;
    S = DB.properties[id];
    DB.ui = {};
    persist(); recompute();
    return true;
  }

  /* ================================================================ */
  /* Actions                                                           */
  /* ================================================================ */
  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }
  function download(name, text, type) {
    try {
      const blob = new Blob([text], { type });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
      toast('Download started. If nothing appears, use the copy option.');
    } catch (e) { copy(text); }
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast('Copied'); }
    catch (e) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); toast('Copied'); } catch (e2) { toast('Copy failed. Select and copy manually.'); }
      ta.remove();
    }
  }
  const slug = () => (S.meta.name || 'property').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  function csvText() {
    const R = OUT.rental;
    const head = ['Month', 'Stage', 'Interest rate', 'Rent', 'EMI', 'Interest', 'Principal', 'Loan disbursed this month', 'Own money paid', 'Net to pocket', 'Running total', 'Loan balance start', 'Loan balance end', 'Spare rent', 'RD balance', 'FD balance', 'MF balance', 'Prepay schedule balance', 'OD parked', 'OD loan balance'];
    const r2 = (v) => (v === null || v === undefined ? '' : Math.round(v * 100) / 100);
    const lines = [head.join(',')].concat(R.rows.map((r) => [ml(r.k), PHASE[r.phase].l, r.B, r2(r.C), r2(r.D), r2(r.E), r2(r.F), r2(r.U), r2(r.AH), r2(r.net), r2(r.cumNet), r2(r.G), r2(r.H), r2(r.V), r2(r.W), r2(r.X), r2(r.Y), r2(r.AD), r2(r.AI), r2(r.AS)].join(',')));
    return lines.join('\n');
  }
  function importText(text) {
    try {
      const obj = JSON.parse(text);
      const st = obj && obj.property ? obj.property : obj;
      if (!st || !st.tranches || !st.loan) throw new Error('bad');
      if (addProperty(st)) { toast('Restored as a new property'); go('overview'); }
    } catch (e) { toast('That file isn\u2019t a GharGanit backup.'); }
  }

  const ACTIONS = {
    menu() {
      const side = document.getElementById('side');
      side.classList.add('open');
      const scrim = document.createElement('div'); scrim.className = 'scrim'; scrim.addEventListener('click', () => { side.classList.remove('open'); scrim.remove(); });
      document.body.appendChild(scrim);
    },
    theme() { const order = ['auto', 'light', 'dark']; DB.theme = order[(order.indexOf(DB.theme || 'auto') + 1) % 3]; applyTheme(); persist(); render(); },
    print() { if (needsPro('print')) { go('upgrade'); return; } window.print(); },
    seg(el) { setPath(el.dataset.path, el.dataset.val); changed(true); },
    segFull(el) { setPath(el.dataset.path, el.dataset.val); changed(true); },
    ui(el) { DB.ui = DB.ui || {}; DB.ui[el.dataset.key] = el.dataset.num ? Number(el.dataset.val) : el.dataset.val; persist(); render(); },
    pickMonth(el) { DB.ui = DB.ui || {}; DB.ui.cfSel = Number(el.dataset.k); const w = document.querySelector('.table-wrap.tall'); keepScroll = w ? w.scrollTop : null; render(); const row = document.querySelector('tr.selected'); if (row) row.focus({ preventScroll: true }); if (window.innerWidth < 1080) { const d = document.querySelector('.month-detail'); if (d) d.scrollIntoView({ behavior: 'smooth' }); } },
    addTranche() { const last = S.tranches[S.tranches.length - 1]; S.tranches.push({ date: last ? last.date : M.str(TODAY), amount: '', funding: 'Loan' }); changed(true); },
    delTranche(el) { S.tranches.splice(Number(el.dataset.i), 1); changed(true); },
    addRate() { S.rates.push({ start: M.str(TODAY), rate: S.rates.length ? S.rates[S.rates.length - 1].rate : 0.085, note: '' }); changed(true); },
    delRate(el) { S.rates.splice(Number(el.dataset.i), 1); changed(true); },
    addOD() { S.od.txns.push({ date: M.str(TODAY), type: 'deposit', amount: '' }); changed(true); },
    delOD(el) { S.od.txns.splice(Number(el.dataset.i), 1); changed(true); },
    addPlanRow(el) { const p = S.plans.plans[Number(el.dataset.p)]; p.rows.push({ date: p.rows.length ? p.rows[p.rows.length - 1].date : M.str(TODAY), amount: '', pct: '', funding: 'Loan' }); changed(true); },
    delPlanRow(el) { S.plans.plans[Number(el.dataset.p)].rows.splice(Number(el.dataset.i), 1); changed(true); },
    addPlan() { const n = S.plans.plans.length; S.plans.plans.push({ name: 'Plan ' + String.fromCharCode(65 + n), price: S.purchasePrice || '', loanRate: 0.085, possession: '', rows: [{ date: M.str(TODAY), amount: '', pct: 1, funding: 'Equity' }] }); DB.ui.planTab = n; changed(true); },
    delPlan(el) { S.plans.plans.splice(Number(el.dataset.i), 1); DB.ui.planTab = 0; changed(true); },
    quickstart() { quickStart(); },
    loadSample() { if (addProperty(E.sampleState())) { toast('Sample loaded as a new property'); go('overview'); } },
    deleteProp() {
      if (Object.keys(DB.properties).length < 2) return;
      if (!confirm('Delete "' + (S.meta.name || 'this property') + '"? This can\u2019t be undone.')) return;
      delete DB.properties[DB.active];
      DB.active = Object.keys(DB.properties)[0]; S = DB.properties[DB.active];
      persist(); recompute(); toast('Deleted'); go('overview');
    },
    csv() { if (needsPro('exportCSV')) { go('upgrade'); return; } download(slug() + '-cash-flow.csv', csvText(), 'text/csv'); },
    exportJSON() { download(slug() + '-backup.json', JSON.stringify({ app: 'GharGanit', saved: new Date().toISOString(), property: S }, null, 2), 'application/json'); },
    copyJSON() { copy(JSON.stringify({ app: 'GharGanit', property: S })); },
    pasteJSON() {
      const d = document.getElementById('dialog');
      d.innerHTML = `<form method="dialog"><h2>Paste backup text</h2><textarea id="pasteBox" rows="8" style="margin-top:10px"></textarea>
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button class="btn ghost" value="cancel">Cancel</button><button class="btn primary" value="ok" id="pasteOk">Restore</button></div></form>`;
      d.showModal();
      d.querySelector('#pasteOk').addEventListener('click', () => importText(d.querySelector('#pasteBox').value));
    },
    copyScript() { if (needsPro('explainScript')) { go('upgrade'); return; } const el = document.getElementById('scriptText'); if (el) copy(el.innerText); },
    async activate() {
      const key = document.getElementById('licKey').value;
      const res = await validateKey(key);
      if (res) { DB.pro = res; persist(); toast('Pro unlocked. Thank you!'); track('pro_activated'); render(); }
      else toast('That key didn\u2019t work. Check for typos or write to ' + (CFG.supportEmail || 'support') + '.');
    },
    removeLicence() { DB.pro = null; persist(); render(); },
    buyClick() { track('buy_click'); return true; }
  };

  /* ================================================================ */
  /* Wiring                                                            */
  /* ================================================================ */
  document.addEventListener('click', (e) => {
    const g = e.target.closest('[data-go]');
    if (g) { e.preventDefault(); go(g.dataset.go); return; }
    const a = e.target.closest('[data-action]');
    if (a && ACTIONS[a.dataset.action]) {
      if (a.tagName === 'A' && a.dataset.action === 'buyClick') { ACTIONS.buyClick(); return; }
      e.preventDefault();
      ACTIONS[a.dataset.action](a);
    }
  });
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('tr[data-action]')) { e.preventDefault(); ACTIONS[e.target.dataset.action](e.target); }
  });
  const view = document.getElementById('view');
  view.addEventListener('input', (e) => { if (e.target.matches('input[type="number"],input[type="text"]')) onInput(e); });
  view.addEventListener('change', (e) => {
    if (e.target.matches('[data-action-change="importFile"]')) {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      const r = new FileReader(); r.onload = () => importText(String(r.result)); r.readAsText(f); return;
    }
    if (e.target.matches('select,input[type="checkbox"]')) onInput(e);
  });
  document.addEventListener('change', (e) => {
    if (e.target.id !== 'propSel') return;
    const v = e.target.value;
    if (v === '__new') {
      e.target.value = DB.active;
      const n = Object.keys(DB.properties).length;
      if (needsPro('multiProperty') && n >= (MON.freePropertyLimit || 1) && !isSample()) { go('upgrade'); return; }
      quickStart(); return;
    }
    DB.active = v; S = DB.properties[v]; DB.ui = {}; persist(); recompute(); render();
  });
  window.addEventListener('hashchange', () => { const id = location.hash.slice(1); if (id && id !== current) go(id); });
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const re = () => { if ((DB.theme || 'auto') === 'auto') render(); };
    if (mq.addEventListener) mq.addEventListener('change', re);
  }
  if (window.Chart) {
    window.Chart.defaults.font.family = "'IBM Plex Sans', system-ui, sans-serif";
  }

  applyTheme();
  recompute();
  const start = location.hash.slice(1);
  current = ALL.some((x) => x.id === start) ? start : 'overview';
  render();
})();
