/*
 * App configuration
 * -----------------
 * This is the only file you need to touch to rename the app or switch
 * on the paid tier. See README.md > "Going paid" for the full playbook.
 */
window.APP_CONFIG = {
  appName: 'GharGanit',
  tagline: 'Indian real estate decision suite',
  supportEmail: 'hello@example.com',

  monetization: {
    // false = every feature is free (use this while you build an audience).
    // true  = features listed in proFeatures sit behind the upgrade screen.
    enabled: false,

    currency: 'INR',
    priceLabel: '₹499 one-time',          // shown on the upgrade screen
    priceNote: 'Lifetime access on this device. GST included.',

    // A hosted checkout link (Razorpay Payment Link / Payment Page, Stripe Payment Link,
    // Instamojo, Gumroad). Buyers land here to pay and receive a licence key by email.
    paymentLink: '',

    // Optional: an HTTPS endpoint that verifies a licence key.
    // The app POSTs {"key": "..."} and expects {"valid": true, "plan": "pro", "expires": "2027-12-31"}.
    // Leave empty to use the offline demo keys below (fine for testing, NOT secure).
    licenseApiUrl: '',
    demoKeys: ['GHAR-DEMO-2026'],

    // How many properties a free user can save. Pro users get unlimited.
    freePropertyLimit: 1,

    // Feature ids that need Pro when monetization.enabled is true.
    // Available ids: comparePlans, leverage, whatIf, spareMoney, overdraft,
    //                explainScript, exportCSV, multiProperty, print
    proFeatures: ['comparePlans', 'leverage', 'whatIf', 'spareMoney', 'overdraft', 'explainScript', 'exportCSV', 'multiProperty', 'print']
  },

  // Small, privacy-friendly analytics hook. Wire to Plausible/GA/PostHog later.
  track: function (event, props) { /* e.g. window.plausible && window.plausible(event, { props }) */ }
};
