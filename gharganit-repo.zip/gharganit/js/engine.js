/*
 * Real Estate Decision Suite: calculation engine
 * ------------------------------------------------
 * Pure functions. No DOM. Every function mirrors a sheet in
 * RealEstateDecisionSuite_v3_08Mar26.xlsx. Cell references are noted
 * next to each formula so anyone can audit the app against the workbook.
 *
 * Dates are handled as "month keys": year * 12 + (month - 1).
 * Every date in the workbook is normalised to the 1st of the month,
 * so a month key is all the precision the model needs.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.REEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------------------------------------------------------------- */
  /* Date helpers                                                      */
  /* ---------------------------------------------------------------- */
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  const M = {
    /** 'YYYY-MM' -> month key. Returns null for blanks. */
    parse(s) {
      if (s === null || s === undefined || s === '') return null;
      if (typeof s === 'number') return s;
      const m = /^(\d{4})-(\d{1,2})/.exec(String(s).trim());
      if (!m) return null;
      return Number(m[1]) * 12 + (Number(m[2]) - 1);
    },
    str(k) {
      if (k === null || k === undefined) return '';
      const y = Math.floor(k / 12);
      return y + '-' + String((k % 12) + 1).padStart(2, '0');
    },
    label(k) {
      if (k === null || k === undefined) return '';
      return MONTHS[k % 12] + ' ' + Math.floor(k / 12);
    },
    ms(k) { return Date.UTC(Math.floor(k / 12), k % 12, 1); },
    days(a, b) { return (M.ms(b) - M.ms(a)) / 86400000; },
    today() { const d = new Date(); return d.getFullYear() * 12 + d.getMonth(); }
  };

  const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;

  /** Excel YEARFRAC(start, end, 1) (actual/actual) for 1st-of-month dates. */
  function yearFrac(a, b) {
    if (a === null || b === null) return null;
    if (a === b) return 0;
    if (a > b) return yearFrac(b, a);
    const y1 = Math.floor(a / 12), y2 = Math.floor(b / 12);
    const d = M.days(a, b);
    if (y1 === y2) return d / (isLeap(y1) ? 366 : 365);
    if (b <= a + 12) {
      let den = 365;
      if (isLeap(y1) && (a % 12) <= 1) den = 366;          // start on/before 29 Feb
      else if (isLeap(y2) && (b % 12) >= 2) den = 366;     // end on/after 29 Feb
      return d / den;
    }
    let total = 0;
    for (let y = y1; y <= y2; y++) total += isLeap(y) ? 366 : 365;
    return d / (total / (y2 - y1 + 1));
  }

  /* ---------------------------------------------------------------- */
  /* Finance helpers                                                   */
  /* ---------------------------------------------------------------- */

  /** -PMT(rate, nper, pv): the positive EMI. */
  function pmt(rate, nper, pv) {
    if (!(nper > 0) || !(pv > 0)) return 0;
    if (rate === 0) return pv / nper;
    return (pv * rate) / (1 - Math.pow(1 + rate, -nper));
  }

  /** Excel XIRR. cashflows[] and month keys[]. Returns null if no sign change. */
  function xirr(cashflows, keys, guess) {
    const cfs = [], t = [];
    const d0 = M.ms(keys[0]);
    for (let i = 0; i < cashflows.length; i++) {
      cfs.push(cashflows[i]);
      t.push((M.ms(keys[i]) - d0) / 86400000 / 365);
    }
    if (!(cfs.some((c) => c < 0) && cfs.some((c) => c > 0))) return null;
    const f = (r) => cfs.reduce((s, c, i) => s + c / Math.pow(1 + r, t[i]), 0);
    const df = (r) => cfs.reduce((s, c, i) => s - (t[i] * c) / Math.pow(1 + r, t[i] + 1), 0);
    let r = guess === undefined ? 0.1 : guess;
    for (let i = 0; i < 200; i++) {
      const v = f(r), d = df(r);
      if (!isFinite(v) || !isFinite(d) || d === 0) break;
      let nr = r - v / d;
      if (nr <= -0.9999) nr = (r - 0.9999) / 2;
      if (Math.abs(nr - r) < 1e-12) { r = nr; break; }
      r = nr;
    }
    if (isFinite(r) && Math.abs(f(r)) < 1e-4) return r;
    // Fallback: bisection
    let lo = -0.9999, hi = 100, flo = f(lo), fhi = f(hi);
    if (!isFinite(flo) || !isFinite(fhi) || flo * fhi > 0) return null;
    for (let i = 0; i < 400; i++) {
      const mid = (lo + hi) / 2, fm = f(mid);
      if (Math.abs(fm) < 1e-8) return mid;
      if (flo * fm < 0) { hi = mid; fhi = fm; } else { lo = mid; flo = fm; }
    }
    return (lo + hi) / 2;
  }

  const ceilSafe = (x) => Math.ceil(x - 1e-9);
  const num = (v) => (v === null || v === undefined || v === '' || isNaN(Number(v)) ? null : Number(v));

  /* ---------------------------------------------------------------- */
  /* Shared inputs                                                     */
  /* ---------------------------------------------------------------- */

  /** Property Data + Equity + Loan tranches (rows 14-28). */
  function tranches(st) {
    return (st.tranches || [])
      .map((t, i) => ({ n: i + 1, k: M.parse(t.date), amount: num(t.amount) || 0, funding: t.funding === 'Loan' ? 'Loan' : 'Equity' }))
      .filter((t) => t.k !== null && t.amount > 0);
  }

  /** Interest Rates sheet. First row starts on the loan start date (A8). */
  function rateSchedule(st) {
    const loanStart = M.parse(st.loan.start);
    const saleK = M.parse(st.sale.date);
    const loanEnd = M.parse(st.loan.end);
    // C6: Interest accrual end = MIN(sale, loan end)
    const accrualEnd = loanEnd === null ? null : saleK === null ? loanEnd : Math.min(loanEnd, saleK);
    const raw = (st.rates || []).map((r, i) => ({
      start: i === 0 ? loanStart : M.parse(r.start),
      rate: num(r.rate),
      note: r.note || ''
    }));
    const first = raw[0];
    const rest = raw.slice(1).filter((r) => r.start !== null && r.rate !== null).sort((a, b) => a.start - b.start);
    const rows = first && first.start !== null && first.rate !== null ? [first].concat(rest) : rest;
    // B8: end = EDATE(next start, -1); last row ends on the accrual end date
    rows.forEach((r, i) => { r.end = i < rows.length - 1 ? rows[i + 1].start - 1 : accrualEnd; });
    return { rows, accrualEnd, loanStart, loanEnd };
  }

  /** Rental Scenario column AM: rate that applies in month k. */
  function rateAt(sched, k) {
    const rows = sched.rows;
    if (!rows.length) return null;
    if (k < rows[0].start) return rows[0].rate;
    let r = null;
    for (const row of rows) { if (row.start <= k) r = row.rate; }
    return r;
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Simple ROE                                                 */
  /* ---------------------------------------------------------------- */
  function simpleROE(purchase, selling, years) {
    if (!(purchase > 0) || selling === null) return null;
    const roe = (selling - purchase) / purchase;                         // B7
    const cagr = years > 0 && selling > 0 ? Math.pow(selling / purchase, 1 / years) - 1 : null; // B8
    return { roe, cagr, profit: selling - purchase };                     // B9
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Tranche Payments without Loan                              */
  /* ---------------------------------------------------------------- */
  function selfFunded(st) {
    const tr = tranches(st);
    const saleK = M.parse(st.sale.date);
    const price = num(st.sale.price);
    const total = tr.reduce((s, t) => s + t.amount, 0);
    const purchase = num(st.purchasePrice) || 0;
    const flows = tr.map((t) => ({ k: t.k, cf: -t.amount, note: 'Instalment ' + t.n }));
    if (saleK !== null && price !== null) flows.push({ k: saleK, cf: price, note: 'Sale' });
    const r = flows.length ? xirr(flows.map((f) => f.cf), flows.map((f) => f.k)) : null;
    return {
      flows,
      total,
      difference: total - purchase,
      xirr: r,
      simpleROE: purchase > 0 && price !== null ? price / purchase - 1 : null
    };
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Equity + Loan (interest-only debt service)                 */
  /* ---------------------------------------------------------------- */
  function equityLoan(st) {
    const tr = tranches(st);
    const sched = rateSchedule(st);
    const saleK = M.parse(st.sale.date);
    const salePrice = num(st.sale.price);
    const purchase = num(st.purchasePrice) || 0;

    const rows = tr.map((t) => {
      let interest = 0;
      // F14: SUMPRODUCT over rate periods of amount * rate * days / 365.25
      if (t.funding === 'Loan' && sched.accrualEnd !== null) {
        for (const p of sched.rows) {
          if (p.start === null || p.end === null || p.rate === null) continue;
          const s = Math.max(t.k, p.start);
          const e = Math.min(sched.accrualEnd, p.end);
          if (e > s) interest += t.amount * p.rate * (M.days(s, e) / 365.25);
        }
      }
      return Object.assign({}, t, { interest });
    });

    const totalLoan = rows.filter((r) => r.funding === 'Loan').reduce((s, r) => s + r.amount, 0);     // B29
    const totalEquity = rows.filter((r) => r.funding === 'Equity').reduce((s, r) => s + r.amount, 0);
    const totalPaid = rows.reduce((s, r) => s + r.amount, 0);                                        // B30
    const totalInterest = rows.reduce((s, r) => s + r.interest, 0);                                   // B33
    const netSale = salePrice === null ? -totalInterest : salePrice - totalInterest - totalLoan;      // B34

    const equityFlows = rows.filter((r) => r.funding === 'Equity').map((r) => ({ k: r.k, cf: -r.amount, note: 'Own money: instalment ' + r.n }));
    const propertyFlows = rows.map((r) => ({ k: r.k, cf: -r.amount, note: 'Instalment ' + r.n }));
    if (saleK !== null && salePrice !== null) {
      equityFlows.push({ k: saleK, cf: netSale, note: 'Sale price less loan repaid and interest' });
      propertyFlows.push({ k: saleK, cf: salePrice, note: 'Sale price' });
    }
    const ex = (fl) => (fl.length ? xirr(fl.map((f) => f.cf), fl.map((f) => f.k)) : null);

    return {
      rows,
      sched,
      totalLoan,
      totalEquity,
      totalPaid,
      difference: totalPaid - purchase,                                   // B31
      totalInterest,
      netSale,
      equityFlows,
      propertyFlows,
      equityXIRR: salePrice === null ? null : ex(equityFlows),           // C56
      propertyXIRR: salePrice === null ? null : ex(propertyFlows),       // C57
      propertyROE: purchase > 0 && salePrice !== null ? (salePrice - purchase) / purchase : null,  // C58
      equityROE: totalEquity > 0 && salePrice !== null ? (netSale - totalEquity) / totalEquity : null // C59
    };
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Rental Scenario (+ Overdraft facility)                     */
  /* ---------------------------------------------------------------- */
  function rental(st) {
    const R = st.rental, L = st.loan;
    const tr = tranches(st);
    const sched = rateSchedule(st);
    const years = Math.max(0, Math.round(num(R.years) || 0));
    const N = years * 12;
    const poss = M.parse(R.possession);
    const loanStart = M.parse(L.start);
    const loanEnd = M.parse(L.end);
    const fromPossession = L.emiStarts !== 'loanStart';

    // F11: schedule starts at the earliest tranche, else loan start, else possession
    const start = tr.length ? Math.min.apply(null, tr.map((t) => t.k)) : loanStart !== null ? loanStart : poss;
    // C14: EMI start date
    const emiStart = fromPossession ? poss : loanStart;
    // F12: effective loan end. From possession, the tenure shifts to start at possession.
    let effEnd = null;
    if (loanEnd !== null) {
      if (fromPossession) effEnd = poss !== null && loanStart !== null ? poss + (loanEnd - loanStart) : null;
      else effEnd = loanEnd;
    }
    const rentStart = M.parse(R.rentStart);
    const rentEnd = M.parse(R.rentEnd);
    const rent0 = num(R.rent) || 0;
    const rentG = num(R.rentIncrease) || 0;
    const changeOnRate = L.behaviour !== 'constant';
    const sp = st.spare || {};
    const rd = num(sp.rd) || 0, fd = num(sp.fd) || 0, mf = num(sp.mf) || 0;
    const od = st.od || {};
    const odOn = !!od.enabled;
    const odRate = num(od.rate) || 0;
    const odTx = (od.txns || []).map((t) => ({ k: M.parse(t.date), amt: num(t.amount) || 0, dep: t.type !== 'withdraw' })).filter((t) => t.k !== null);

    const rows = [];
    if (start === null || N <= 0) return { ok: false, reason: 'Add at least one payment date or a loan start date, and a projection period.', rows };

    let prev = null;
    let cumLoan = 0;
    for (let i = 0; i < N; i++) {
      const k = start + i;
      const B = rateAt(sched, k);                                               // B / AM
      const C = rentStart !== null && k >= rentStart && (rentEnd === null || k <= rentEnd)
        ? rent0 * Math.pow(1 + rentG, Math.floor((k - rentStart) / 12)) : 0;    // C: rent steps up every 12 months
      let U = 0, AH = 0;
      for (const t of tr) {
        if (t.k === k) { if (t.funding === 'Loan') U += t.amount; else AH += t.amount; }
      }
      cumLoan += U;                                                             // T: loan disbursed to date
      const T = cumLoan;
      const G = i === 0 ? U : prev.H + U;                                        // G: balance start

      const emiCalc = (prevVal, allowRate) => {
        if (B === null || emiStart === null || effEnd === null) return 0;
        if (G <= 0 || k > effEnd) return 0;
        if (k < emiStart) return (G * B) / 12;                                   // pre-EMI: interest only
        const n = effEnd - k + 1;
        if (n <= 0) return 0;
        if (U > 0 || k === emiStart || (allowRate && (i === 0 || B !== prev.B))) return pmt(B / 12, n, G);
        return prevVal;
      };

      const D = emiCalc(prev ? prev.D : 0, changeOnRate);                         // D: EMI
      const E = G > 0 && B !== null ? (G * B) / 12 : 0;                            // E: interest
      const F = Math.max(0, Math.min(G, D - E));                                   // F: principal
      const H = Math.max(0, G - F);                                                // H: balance end
      const V = Math.max(0, C - D);                                                // V: surplus
      const W = (prev ? prev.W : 0) * (1 + rd / 12) + V;                           // W: RD
      const X = (prev ? prev.X : 0) * (1 + fd / 12) + V;                           // X: FD
      const Y = (prev ? prev.Y : 0) * (1 + mf / 12) + V;                           // Y: MF
      // Foreclosure using surplus as prepayment (Z..AE)
      const Z = i === 0 ? U : prev.AD + U;
      const AA = Z > 0 ? (Z * B) / 12 : 0;
      const AB = D > 0 ? Math.max(0, Math.min(Z, D - AA)) : 0;
      const AC = D > 0 && Z > 0 ? V : 0;
      const AD = Math.max(0, Z - AB - AC);
      const AE = Z > 0 && AD === 0 ? 1 : 0;
      // Overdraft (AI..AT)
      let AI = 0;
      if (odOn) {
        let dep = 0, wd = 0;
        for (const t of odTx) { if (t.k <= k) { if (t.dep) dep += t.amt; else wd += t.amt; } }
        AI = Math.max(0, dep - wd);
      }
      const AT = emiCalc(prev ? prev.AT : 0, false);                               // EMI ignoring rate-change recalculation
      const AQ = i === 0 ? T : (prev.AS === null ? 0 : prev.AS) + U;               // OD loan balance start
      const AL = odOn ? Math.max(0, AQ - AI) : AQ;                                 // effective outstanding
      const AJ = odOn && AL > 0 ? (AL * odRate) / 12 : 0;                          // OD interest
      const AR = odOn ? Math.max(0, Math.min(AQ, AT - AJ)) : 0;                    // OD principal
      const AS = odOn ? Math.max(0, AQ - AR) : null;                               // OD loan balance end
      const AO = odOn ? E - AJ : 0;                                                // interest saved

      const row = { i, k, B, C, D, E, F, G, H, T, U, V, W, X, Y, Z, AA, AB, AC, AD, AE, AH, AI, AJ, AL, AO, AQ, AR, AS, AT };
      // Plain-language helpers (not in the workbook)
      row.net = C - D - AH;                    // what lands in (or leaves) your pocket this month
      row.preEmi = emiStart !== null && k < emiStart && D > 0;
      rows.push(row);
      prev = row;
    }

    let cum = 0;
    rows.forEach((r) => { cum += r.net; r.cumNet = cum; r.phase = phaseOf(r, emiStart, effEnd); });

    const last = rows[N - 1];
    const lastK = last.k;
    const V0 = num(R.valueAtPossession) || 0;
    const app = num(R.appreciation) || 0;
    // N6: value at end of projection, grown from possession
    const valueEnd = poss === null || lastK < poss ? null : V0 * Math.pow(1 + app, yearFrac(poss, lastK));
    const loanEndBal = last.H;                                                    // N7
    const equityEnd = valueEnd === null ? null : valueEnd - loanEndBal;          // N5
    rows.forEach((r, idx) => { r.AF = -r.AH + (idx === N - 1 && equityEnd !== null ? equityEnd : 0); });
    const equityPaid = rows.reduce((s, r) => s + r.AH, 0);
    const equityXIRR = equityEnd === null ? null : xirr(rows.map((r) => r.AF), rows.map((r) => r.k)); // J10
    const roeOnEquity = equityEnd !== null && equityPaid > 0 ? equityEnd / equityPaid - 1 : null;      // J9
    // Not in the workbook: XIRR on every rupee that actually moved (own money, top-ups, spare rent) plus equity at the end
    let allInXIRR = null;
    if (equityEnd !== null) {
      const cf = rows.map((r) => r.net);
      cf[cf.length - 1] += equityEnd;
      allInXIRR = xirr(cf, rows.map((r) => r.k));
    }
    const totalRent = rows.reduce((s, r) => s + r.C, 0);
    const totalEMI = rows.reduce((s, r) => s + r.D, 0);
    const totalInterest = rows.reduce((s, r) => s + r.E, 0);
    const totalPrincipal = rows.reduce((s, r) => s + r.F, 0);

    // J7 / J8: foreclosure if every rupee of surplus pre-pays the loan
    const fc = rows.find((r) => r.AE === 1);
    const foreclosure = fc ? { k: fc.k, months: fc.k - start } : null;

    // OD outputs N8..N13
    const f13 = rows.findIndex((r) => r.T > 0);
    let odOut = null;
    if (odOn && f13 >= 0) {
      let payIdx = -1;
      for (let j = f13; j < N; j++) { if (rows[j].AS === 0) { payIdx = j; break; } }
      const months = payIdx >= 0 ? payIdx - f13 + 1 : null;                      // N9
      const baseMonths = effEnd === null ? null : effEnd - rows[f13].k + 1;       // N10
      odOut = {
        interestSaved: rows.reduce((s, r) => s + r.AO, 0),                         // N8
        months,
        baseMonths,
        monthsSaved: months !== null && baseMonths !== null ? baseMonths - months : null, // N11
        baseDate: baseMonths === null ? null : rows[f13].k + baseMonths - 1,       // N12
        odDate: months === null ? null : rows[f13].k + months - 1                  // N13
      };
    }

    // Annual summary (K..S)
    const annual = [];
    for (let y = 1; y <= years; y++) {
      const a = start + 12 * (y - 1), b = start + 12 * y;
      const rs = rows.filter((r) => r.k >= a && r.k < b);
      const sum = (f) => rs.reduce((s, r) => s + r[f], 0);
      const endK = b - 1;
      annual.push({
        year: y, from: a, to: endK,
        rent: sum('C'), emi: sum('D'), interest: sum('E'), principal: sum('F'),
        net: sum('C') - sum('D'), equity: sum('AH'), pocket: sum('net'),
        loanEnd: rs.length ? rs[rs.length - 1].H : 0,
        value: poss === null || endK < poss ? null : V0 * Math.pow(1 + app, yearFrac(poss, endK)),
        valueExcel: V0 * Math.pow(1 + app, y)   // workbook column S (compounds from year 1, before possession)
      });
    }

    // Milestones for the plain-language story
    const firstRent = rows.find((r) => r.C > 0);
    const firstEMI = rows.find((r) => r.D > 0 && !r.preEmi);
    const rentBeatsEMI = rows.find((r) => r.D > 0 && !r.preEmi && r.C >= r.D);
    const loanClosed = rows.find((r, idx) => idx > 0 && r.T > 0 && r.G > 0 && r.H === 0);
    const peakLoan = rows.reduce((m, r) => Math.max(m, r.G), 0);

    return {
      ok: true, rows, annual, start, end: lastK, N, years, poss, emiStart, effEnd, loanStart, loanEnd,
      totalLoan: cumLoan, peakLoan,
      totals: { rent: totalRent, emi: totalEMI, interest: totalInterest, principal: totalPrincipal, equity: equityPaid, net: totalRent - totalEMI - equityPaid },
      cumNetRentMinusEMI: totalRent - totalEMI,                                    // N4
      valueEnd, loanEndBal, equityEnd, equityXIRR, allInXIRR, roeOnEquity,
      spare: { rd: last.W, fd: last.X, mf: last.Y },                               // J4..J6
      foreclosure,
      od: odOut,
      milestones: {
        firstRent: firstRent ? firstRent.k : null,
        firstEMI: firstEMI ? firstEMI.k : null,
        rentBeatsEMI: rentBeatsEMI ? rentBeatsEMI.k : null,
        loanClosed: loanClosed ? loanClosed.k : null
      }
    };
  }

  function phaseOf(r, emiStart, effEnd) {
    if (r.T === 0 && r.D === 0) return 'build';            // before any loan money moves
    if (r.preEmi) return 'preemi';                          // interest-only while under construction
    if (r.D > 0 && r.C < r.D) return 'topup';               // rent doesn't cover EMI
    if (r.D > 0 && r.C >= r.D) return 'surplus';            // rent covers EMI
    if (r.T > 0 && r.G === 0 && r.D === 0) return 'free';   // loan repaid
    return 'idle';
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Leverage Optimiser                                         */
  /* ---------------------------------------------------------------- */
  function leverage(st) {
    const value = num(st.purchasePrice) || 0;                      // D5
    const rent = num(st.rental.rent) || 0;                          // D6
    const g = num(st.rental.rentIncrease) || 0;                     // D7
    const sched = rateSchedule(st);
    const rate = sched.rows.length ? sched.rows[0].rate : null;     // D8
    const ls = M.parse(st.loan.start), le = M.parse(st.loan.end);
    const n = ls !== null && le !== null ? le - ls + 1 : null;
    const out = [];
    for (let p = 15; p <= 100; p += 5) {
      const eq = p / 100;
      const loan = value * (1 - eq);
      const int = rate === null ? null : (loan * rate) / 12;
      const emi = rate === null || n === null ? null : pmt(rate / 12, n, loan);
      const months = (target) => {
        if (target === null || !(rent > 0)) return null;
        if (rent >= target) return 0;
        if (g === 0) return 'Never';
        return ceilSafe((12 * Math.log(target / rent)) / Math.log(1 + g));
      };
      out.push({
        equityPct: eq, equity: value * eq, loan, interest: int,
        rentToInterest: int ? rent / int : null,
        emi, rentToEMI: emi ? rent / emi : null,
        monthsToInterest: months(int), monthsToEMI: months(emi),
        outflow: emi === null ? null : emi - rent
      });
    }
    const sweet = out.find((r) => r.outflow !== null && r.outflow <= 0);
    return { value, rent, g, rate, n, rows: out, sweetSpot: sweet || null };
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Scenarios & Stress Test                                    */
  /* ---------------------------------------------------------------- */
  function scenarios(st, rentalOut) {
    const S = st.scenario;
    const sc = S.table[S.selected] || S.table.Base;
    const rent = num(st.rental.rent) || 0;                          // B9
    const loan = tranches(st).filter((t) => t.funding === 'Loan').reduce((s, t) => s + t.amount, 0); // B10
    const sched = rateSchedule(st);
    const baseRate = sched.rows.length ? sched.rows[0].rate : 0;    // B11
    const ls = M.parse(st.loan.start), le = M.parse(st.loan.end);
    const tenure = ls !== null && le !== null ? le - ls + 1 : null; // E10
    const esc = sc.rentEsc;                                         // B17
    const vac = sc.vacancy;                                         // B18
    const rentShock = num(S.rentShock) || 0;                        // B20
    const intShock = num(S.interestShock) || 0;                     // B21

    const netRent = (shock) => Math.max(0, rent * (1 + shock) * (1 - vac));
    const rateOf = (shock) => Math.max(0, baseRate + shock);
    const emiOf = (shock) => (tenure === null ? null : pmt(rateOf(shock) / 12, tenure, loan));
    const monthsTo = (target, nr) => {
      if (target === null) return null;
      if (nr >= target) return 0;
      if (!(esc > 0) || !(nr > 0)) return null;
      return ceilSafe((12 * Math.log(target / nr)) / Math.log(1 + esc));
    };

    const effRent = netRent(rentShock);                            // E8
    const effRate = rateOf(intShock);                              // E9
    const emi = emiOf(intShock);                                   // E11
    const keys = {
      effRent, effRate, tenure, emi,
      monthsToInterest: monthsTo((loan * effRate) / 12, effRent),  // E15
      monthsToEMI: monthsTo(emi, effRent),                         // E16
      outflow: emi === null ? null : emi - effRent                 // E17
    };
    const rentShocks = [0, -0.1, -0.2];
    const intShocks = [0, 0.01, 0.02];
    const grid = (fn) => rentShocks.map((rs) => intShocks.map((is) => fn(rs, is)));
    // Extra (not in workbook outputs): exit value net of the scenario's selling cost
    let exit = null;
    if (rentalOut && rentalOut.ok && rentalOut.poss !== null && rentalOut.end >= rentalOut.poss) {
      const v = (num(st.rental.valueAtPossession) || 0) * Math.pow(1 + sc.appreciation, yearFrac(rentalOut.poss, rentalOut.end));
      exit = { gross: v, net: v * (1 - sc.sellCost), k: rentalOut.end };
    }
    return {
      scenario: sc, name: S.selected, rent, loan, baseRate, tenure, rentShock, intShock, keys, rentShocks, intShocks,
      gridInterest: grid((rs, is) => monthsTo((loan * rateOf(is)) / 12, netRent(rs))),
      gridEMI: grid((rs, is) => monthsTo(emiOf(is), netRent(rs))),
      gridOutflow: grid((rs, is) => { const e = emiOf(is); return e === null ? null : e - netRent(rs); }),
      exit
    };
  }

  /* ---------------------------------------------------------------- */
  /* Sheet: Compare Plans                                              */
  /* ---------------------------------------------------------------- */
  function comparePlans(cp) {
    const r = num(cp.discountRate) || 0;
    const allDates = [];
    cp.plans.forEach((p) => p.rows.forEach((row) => { const k = M.parse(row.date); if (k !== null) allDates.push(k); }));
    const autoBase = allDates.length ? Math.min.apply(null, allDates) : null;   // C5
    const base = M.parse(cp.baseOverride) !== null ? M.parse(cp.baseOverride) : autoBase; // C7

    const plans = cp.plans.map((p) => {
      const price = num(p.price) || 0;
      const lr = num(p.loanRate) || 0;
      const dates = p.rows.map((x) => M.parse(x.date)).filter((k) => k !== null);
      const possAuto = dates.length ? Math.max.apply(null, dates) : null;
      const poss = M.parse(p.possession) !== null ? M.parse(p.possession) : possAuto;
      const rows = p.rows.map((row, i) => {
        const k = M.parse(row.date);
        const amt = num(row.amount) !== null ? num(row.amount) : num(row.pct) !== null ? num(row.pct) * price : null; // F
        const pct = num(row.pct) !== null ? num(row.pct) : num(row.amount) !== null && price > 0 ? num(row.amount) / price : null; // G
        let pv = null, pvInt = null;
        if (k !== null && amt !== null && base !== null) {
          pv = amt / Math.pow(1 + r, yearFrac(base, k));                                               // H
          if (row.funding === 'Loan' && poss !== null) {
            pvInt = (amt * lr * yearFrac(k, poss)) / Math.pow(1 + r, yearFrac(base, poss));            // I
          }
        }
        return { n: i + 1, k, amount: amt, pct, funding: row.funding, pv, pvInt };
      });
      const used = rows.reduce((s, x) => s + (x.amount || 0), 0);
      const pvPay = rows.reduce((s, x) => s + (x.pv || 0), 0);
      const pvInt = rows.reduce((s, x) => s + (x.pvInt || 0), 0);
      const loanTotal = rows.filter((x) => x.funding === 'Loan').reduce((s, x) => s + (x.amount || 0), 0);
      const interestNominal = rows.filter((x) => x.funding === 'Loan' && x.k !== null && poss !== null)
        .reduce((s, x) => s + (x.amount || 0) * lr * yearFrac(x.k, poss), 0);
      return { name: p.name, price, loanRate: lr, poss, possAuto, rows, used, difference: used - price, pvPay, pvInt, pvTotal: pvPay + pvInt, loanTotal, interestNominal };
    });
    const valid = plans.filter((p) => p.rows.some((x) => x.amount));
    const sorted = valid.slice().sort((a, b) => a.pvTotal - b.pvTotal);
    return {
      base, autoBase, plans,
      best: valid.length >= 2 ? sorted[0].name : null,
      savings: valid.length >= 2 ? sorted[1].pvTotal - sorted[0].pvTotal : null,
      ranking: sorted.map((p) => p.name)
    };
  }

  /* ---------------------------------------------------------------- */
  /* Everything at once                                                */
  /* ---------------------------------------------------------------- */
  function runAll(st) {
    const R = rental(st);
    const EL = equityLoan(st);
    const SF = selfFunded(st);
    const tr = tranches(st);
    const saleK = M.parse(st.sale.date);
    const firstK = tr.length ? Math.min.apply(null, tr.map((t) => t.k)) : null;
    const autoYears = firstK !== null && saleK !== null ? (saleK - firstK) / 12 : null;  // holding period in whole months / 12
    const years = num(st.roe && st.roe.yearsOverride) !== null ? num(st.roe.yearsOverride) : autoYears;
    return {
      rental: R,
      equityLoan: EL,
      selfFunded: SF,
      simpleROE: Object.assign({ years, autoYears }, simpleROE(num(st.purchasePrice), num(st.sale.price), years)),
      leverage: leverage(st),
      scenarios: scenarios(st, R),
      plans: comparePlans(st.plans),
      rates: rateSchedule(st)
    };
  }

  /* ---------------------------------------------------------------- */
  /* Sample data: exactly the values pre-filled in the workbook        */
  /* ---------------------------------------------------------------- */
  function sampleState() {
    return {
      version: 3,
      meta: { name: 'Sample flat (from the Excel)', city: 'Pune' },
      purchasePrice: 8000000,
      tranches: [
        { date: '2026-02', amount: 1600000, funding: 'Equity' },
        { date: '2027-02', amount: 1600000, funding: 'Loan' },
        { date: '2028-02', amount: 1600000, funding: 'Loan' },
        { date: '2029-02', amount: 1600000, funding: 'Loan' },
        { date: '2030-02', amount: 1600000, funding: 'Loan' }
      ],
      sale: { date: '2031-02', price: 12000000 },
      loan: { start: '2027-02', end: '2047-01', emiStarts: 'possession', behaviour: 'change' },
      rates: [
        { start: '', rate: 0.072, note: 'Starting rate' },
        { start: '2028-12', rate: 0.07, note: 'Step 2' },
        { start: '2030-12', rate: 0.067, note: 'Step 3' }
      ],
      rental: {
        possession: '2030-02', valueAtPossession: 11000000, appreciation: 0.05,
        rentStart: '2030-05', rentEnd: '', rent: 35000, rentIncrease: 0.05, years: 24
      },
      spare: { rd: 0.04, fd: 0.07, mf: 0.12 },
      od: {
        enabled: true, rate: 0.073,
        txns: [
          { date: '2027-08', type: 'deposit', amount: 500000 },
          { date: '2028-03', type: 'withdraw', amount: 50000 },
          { date: '2028-09', type: 'deposit', amount: 25000 }
        ]
      },
      roe: { yearsOverride: '' },
      scenario: {
        selected: 'Base', rentShock: 0, interestShock: 0,
        table: {
          Base: { appreciation: 0.05, rentEsc: 0.05, vacancy: 0.05, sellCost: 0.02 },
          Conservative: { appreciation: 0.03, rentEsc: 0.03, vacancy: 0.08, sellCost: 0.025 },
          Aggressive: { appreciation: 0.07, rentEsc: 0.06, vacancy: 0.04, sellCost: 0.015 }
        }
      },
      plans: {
        discountRate: 0.072, baseOverride: '',
        plans: [
          { name: 'Plan A', price: 8200000, loanRate: 0.072, possession: '2030-12', rows: [
            { date: '2026-02', amount: '', pct: 0.25, funding: 'Equity' },
            { date: '2028-02', amount: '', pct: 0.25, funding: 'Loan' },
            { date: '2029-02', amount: '', pct: 0.25, funding: 'Loan' },
            { date: '2030-12', amount: '', pct: 0.25, funding: 'Loan' }
          ] },
          { name: 'Plan B', price: 8000000, loanRate: 0.072, possession: '2030-12', rows: [
            { date: '2026-02', amount: '', pct: 0.2, funding: 'Equity' },
            { date: '2028-02', amount: '', pct: 0.3, funding: 'Loan' },
            { date: '2029-02', amount: '', pct: 0.3, funding: 'Loan' },
            { date: '2030-12', amount: '', pct: 0.2, funding: 'Loan' }
          ] },
          { name: 'Plan C', price: 9000000, loanRate: 0.072, possession: '2030-12', rows: [
            { date: '2026-02', amount: '', pct: 0.2, funding: 'Equity' },
            { date: '2030-02', amount: '', pct: 0.8, funding: 'Loan' }
          ] }
        ]
      }
    };
  }

  /** A clean slate shaped for a ready, rented, loan-funded flat. */
  function blankState() {
    const s = sampleState();
    const t = M.today();
    s.meta = { name: 'My property', city: '' };
    s.purchasePrice = '';
    s.tranches = [
      { date: M.str(t - 12), amount: '', funding: 'Equity' },
      { date: M.str(t - 12), amount: '', funding: 'Loan' }
    ];
    s.sale = { date: '', price: '' };
    s.loan = { start: M.str(t - 12), end: M.str(t - 12 + 239), emiStarts: 'loanStart', behaviour: 'change' };
    s.rates = [{ start: '', rate: 0.085, note: 'Starting rate' }];
    s.rental = { possession: M.str(t - 12), valueAtPossession: '', appreciation: 0.05, rentStart: M.str(t - 1), rentEnd: '', rent: '', rentIncrease: 0.05, years: 20 };
    s.od = { enabled: false, rate: 0.085, txns: [] };
    return s;
  }

  return { M, yearFrac, pmt, xirr, tranches, rateSchedule, rateAt, simpleROE, selfFunded, equityLoan, rental, leverage, scenarios, comparePlans, runAll, sampleState, blankState };
});
