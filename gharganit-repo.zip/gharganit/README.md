# GharGanit: Indian real estate decision suite

See exactly where every rupee goes when you buy an Indian property on a home loan. EMI, pre-EMI, rent, top-ups, prepayment, overdraft loans and returns, explained in plain language.

GharGanit is a web app version of the **Real Estate Decision Suite v3** Excel workbook. Every formula in the workbook is reproduced in `js/engine.js`, and an automated test checks 46 results against the numbers Excel itself calculated.

No sign-up. No server. Your numbers stay in your browser.

## What it does

| In the app | What you get | Excel sheet it comes from |
|---|---|---|
| Overview | A plain-English story of the property, this month's money ledger, rent vs EMI chart, key dates | Rental Scenario |
| Set up your property | 6 guided steps, plus a 2-minute Quick start for a ready flat on a loan | Property Data, Interest Rates, Equity + Loan |
| Monthly cash flow | Every month: rent, EMI, interest, principal, own money, net to your pocket, running total, loan left. Tap a month for a plain-language explanation. Yearly view and CSV export | Rental Scenario (monthly schedule and annual summary) |
| Explain it simply | A read-aloud script for family and friends, built from your numbers | New |
| Returns | Hold vs sell vs self-funded: equity XIRR, property XIRR, ROE, CAGR | Equity + Loan, Simple ROE, Tranche Payments without Loan, Rental Scenario |
| Compare payment plans | Up to 5 builder plans compared in today's money, with a recommendation | Compare Plans |
| Loan vs own money | The equity share at which rent covers the EMI | Leverage Optimiser |
| What if? Stress test | Base, cautious and optimistic cases, rent and rate shocks, 3 heat-map grids | Scenarios & Stress Test |
| Spare rent and prepaying | RD, FD and mutual fund growth of spare rent, or the month the loan closes if you prepay | Rental Scenario (spare usage, foreclosure) |
| Overdraft home loan | Interest saved and months saved with an MaxGain-style loan | Overdraft facility |
| Jargon buster | 21 terms in one or two lines each | New |

Also: multiple properties, backup and restore, print to PDF, light and dark mode, works on phones.

## Run it

It's plain HTML, CSS and JavaScript. No build step.

```bash
# any static server works
python3 -m http.server 8000
# then open http://localhost:8000
```

Or just double-click `index.html`.

The only things loaded from the internet are the IBM Plex Sans font and Chart.js 4.4.1 (pinned) from jsDelivr. Without them the app still calculates everything; charts show a short message instead.

## Publish on GitHub Pages

1. Create a repository and push these files to the `main` branch.
2. In the repository, open **Settings > Pages**.
3. Under **Build and deployment**, pick **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Your app is live at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Check the maths

```bash
node tests/validate-against-excel.js
```

Expected output ends with `46 passed, 0 failed`. A GitHub Action (`.github/workflows/test.yml`) runs the same check on every push, so a broken formula can't slip in unnoticed.

## Project structure

```
index.html                       App shell
css/styles.css                   All styling (light, dark, mobile, print)
js/config.js                     App name and the paid-tier switch
js/engine.js                     Every calculation. Pure functions, no DOM
js/app.js                        Screens, inputs, charts, storage, paywall
tests/validate-against-excel.js  46 checks against Excel's own results
scripts/build-single-file.js     Bundles everything into one HTML file
docs/HOW-IT-WORKS.md             Formula-by-formula map to the workbook
```

## Going paid

The app ships with every feature free. Monetisation is one switch away.

**1. Choose a payment provider.** For Indian buyers, Razorpay Payment Pages or Payment Links are the fastest route (UPI, cards, net banking, GST invoices). Stripe Payment Links, Instamojo or Gumroad also work.

**2. Turn it on** in `js/config.js`:

```js
monetization: {
  enabled: true,
  priceLabel: '₹499 one-time',
  paymentLink: 'https://rzp.io/l/your-link',
  licenseApiUrl: 'https://your-api.example.com/verify',
  freePropertyLimit: 1,
  proFeatures: ['comparePlans', 'leverage', 'whatIf', 'spareMoney', 'overdraft', 'explainScript', 'exportCSV', 'multiProperty', 'print']
}
```

Free users keep Overview, Set up, Monthly cash flow, Returns and the Jargon buster. That's enough to get hooked. Pro unlocks the decision tools.

**3. Issue licence keys.** When a payment succeeds, the provider calls a webhook. Your webhook generates a key, stores it and emails it. The app sends the key to `licenseApiUrl` and expects:

```json
{ "valid": true, "plan": "pro", "expires": "2027-12-31" }
```

A small serverless function (Cloudflare Workers, Vercel, Supabase Edge Functions or Firebase) handles both the webhook and the verify endpoint for free at low volume.

**Be honest with yourself about security.** Any check that runs in the browser can be bypassed by a determined user. For a ₹499 tool aimed at home buyers, that's an acceptable trade-off. If you later sell to brokers or developers at a higher price, move the paid calculations behind a server and require login.

**Before you charge:** add a privacy policy and terms page, register for GST if turnover crosses the threshold, and state clearly that the app is an estimator and doesn't give investment advice.

## Known differences from the workbook

The app matches the workbook to the rupee on every tested output. Where the workbook has an inconsistency, the app either keeps the Excel behaviour (so results reconcile) and documents it, or improves it and labels the change. Full list in `docs/HOW-IT-WORKS.md`. The two that matter most:

- **Long-term equity XIRR leaves out monthly top-ups.** The workbook's Rental Scenario XIRR counts only upfront own money and the equity at the end. The app shows that figure and adds an **all-in XIRR** that includes every top-up and every rupee of spare rent. On a typical rented flat that tops up for years, the all-in figure is several points lower, and it's the one to compare with an FD.
- **Rate changes drop one month of interest** in the Equity + Loan sheet, because each rate period ends the month before the next one starts. On the sample data, interest is understated by ₹55,721 (about 5%). The app reproduces this so it reconciles with Excel.

## Disclaimer

GharGanit is an estimator. It isn't financial, tax or legal advice. Bank calculations differ slightly by rounding, day-count and reset dates. Check important decisions with your bank statement and a qualified adviser.

## Licence

All rights reserved. See `LICENSE`.
