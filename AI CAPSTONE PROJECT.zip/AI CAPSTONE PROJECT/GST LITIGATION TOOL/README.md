# GST Lit assist
## GST Litigation Management & Reply Demo

**GST Lit assist** is an academic/project demonstration tool designed to showcase how AI and automation workflows can streamline GST litigation management, notice parsing, discrepancy tracking, document management, and point-wise legal reply draft generation.

---

## 🌟 Key Features

1. **100% Offline & Local Execution**: Runs locally on Windows without requiring paid APIs, Ollama, cloud services, or live GST credentials.
2. **GSTIN State Auto-Identification**: Automatically identifies the taxpayer's state from the first two digits of the GSTIN (e.g. `06` -> Haryana, `07` -> Delhi, `09` -> Uttar Pradesh).
3. **Excel Client & Case Import**: Import client records from `sample_clients.xlsx` with validation, GSTIN state derivation, duplicate checking, and import summary statistics.
4. **Zero-Click Automatic Document Processing**: Uploading a document automatically triggers the read → extract → metadata identification → status update pipeline (`Uploaded` → `Reading` → `Extracting` → `Completed`) without requiring a separate "Extract" button.
5. **Point-wise GST Reply Generator**: Generates professional, point-wise legal replies using database metadata, officer observations, and discrepancy points.
6. **Reply Safety Protocols**: Enforces strict safety rules by inserting `[INFORMATION REQUIRED]` placeholders rather than inventing facts or numbers.
7. **Simulated GST Portal Sync**: Demonstrates GST portal document retrieval and synchronization workflow.
8. **Automated Database Backup**: One-click database backup to the `backups/` directory with timestamping.

---

## 🛠️ System Requirements & Installation

- **Python**: Python 3.10 or higher
- **Operating System**: Windows (or Linux / macOS)
- **Dependencies**: `openpyxl`, `PyPDF2`, `python-docx`

### Installation Steps

1. Open your terminal / command prompt in the project root directory.
2. Install dependencies:
   ```bash
   py -m pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   py app.py
   ```

---

## 📂 Project Structure

```
GST_Lit_Assist/
│
├── app.py                      # Main Tkinter Desktop Application
├── database.py                 # SQLite Database Access Layer
├── gst_utils.py                # GSTIN validation & State dictionary
├── doc_processor.py            # Automatic Document Processing Pipeline
├── reply_generator.py          # Point-wise Legal Reply Generator
├── excel_handler.py            # Excel Import / Export module
├── sample_data_generator.py    # Sample Data & Database Seeder
├── requirements.txt            # Python dependencies
├── README.md                   # Project Overview & Quick Start Guide
├── PROJECT_DESCRIPTION.md      # Detailed Technical Architecture
├── DATABASE_STRUCTURE.md       # SQLite Schema & Relationships
├── USER_GUIDE.md               # User Operational Guide
├── PRESENTATION_FLOW.md        # Classroom Presentation Script
│
├── data/                       # Local SQLite database & uploaded documents
│   ├── gst_lit_assist.db
│   ├── clients/
│   ├── cases/
│   ├── notices/
│   ├── documents/
│   └── replies/
│
├── sample_data/                # Pre-built sample files for demo
│   ├── sample_clients.xlsx
│   ├── sample_cases.xlsx
│   ├── sample_notices/
│   └── sample_documents/
│
├── backups/                    # Automated Database Backups
└── logs/                       # Application event logs (application.log)
```

---

## 🚀 How to Run & Demo Workflows

### 1. Launch Application
Run `py app.py`. On first launch, the database is initialized and seeded with 3 sample clients, sample cases, and an ASMT-10 notice.

### 2. Client Management & Excel Import
- Go to the **Clients** tab.
- Click **IMPORT FROM EXCEL** and choose `sample_data/sample_clients.xlsx`.
- View the summary report showing total records found, imported, duplicate skipped, and errors.
- Click **+ CREATE CLIENT** to manually add a client. Type a GSTIN starting with `06`, `07`, or `09` and observe automatic State population.

### 3. Automatic Zero-Click Document Processing
- Go to the **Documents** tab.
- Click **UPLOAD DOCUMENT** and select `sample_data/sample_notices/ASMT-10_Notice_Mahajan_Life_Sciences.txt` (or any PDF/DOCX notice).
- The pipeline will automatically transition: `Uploaded` → `Reading` → `Extracting` → `Completed`. No manual "EXTRACT" click is needed.

### 4. Create & Generate Point-Wise Reply
- Go to the **Replies** tab.
- Click **+ CREATE REPLY**.
- Select Client (*Mahajan Life Sciences*), Case (*CASE-2026-001*), Notice (*ASMT10/2026/001*), and Reply Type (*Point-wise Reply*).
- Click **GENERATE DRAFT & EDIT**. The application generates a point-wise response incorporating departmental observations, quantified tax differences, taxpayer submissions, annexed documents, and a formal prayer.

### 5. GST Portal Demo
- Go to the **GST Portal** tab.
- Click **GET DATA FROM GST** to simulate document discovery.
- Click **IMPORT NOTICES** to simulate portal sync feeding directly into the automatic document processing pipeline.

---

## 🔒 Limitations & Safety Guidelines

- This project is an **academic/project demonstration tool**.
- It does **NOT** connect to live GST Portal servers, nor does it ask for or bypass real GST credentials, OTPs, CAPTCHAs, or EVC controls.
- The reply generator does **NOT** invent legal provisions or missing invoice figures; missing details are explicitly flagged with `[INFORMATION REQUIRED]`.

---

## 🔮 Future Development

1. Integration with officially supported GST API / GSP mechanisms (https://developer.gst.gov.in/apiportal/).
2. Fine-tuned AI models for advanced OCR and table extraction.
3. Automated GSTR-2B vs 3B and GSTR-1 vs 3B reconciliation engines.
4. Digital signature integration for reply filing.
