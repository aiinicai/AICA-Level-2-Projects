"""
GST Utilities for GST Lit assist
Includes GST State Code dictionary, GSTIN validation, and State identification logic.
"""

import re

# Comprehensive GST State Code Dictionary (First 2 digits of GSTIN)
GST_STATE_CODES = {
    "01": "Jammu & Kashmir",
    "02": "Himachal Pradesh",
    "03": "Punjab",
    "04": "Chandigarh",
    "05": "Uttarakhand",
    "06": "Haryana",
    "07": "Delhi",
    "08": "Rajasthan",
    "09": "Uttar Pradesh",
    "10": "Bihar",
    "11": "Sikkim",
    "12": "Arunachal Pradesh",
    "13": "Nagaland",
    "14": "Manipur",
    "15": "Mizoram",
    "16": "Tripura",
    "17": "Meghalaya",
    "18": "Assam",
    "19": "West Bengal",
    "20": "Jharkhand",
    "21": "Odisha",
    "22": "Chhattisgarh",
    "23": "Madhya Pradesh",
    "24": "Gujarat",
    "25": "Daman & Diu",
    "26": "Dadra & Nagar Haveli",
    "27": "Maharashtra",
    "28": "Andhra Pradesh (Old)",
    "29": "Karnataka",
    "30": "Goa",
    "31": "Lakshadweep",
    "32": "Kerala",
    "33": "Tamil Nadu",
    "34": "Puducherry",
    "35": "Andaman & Nicobar Islands",
    "36": "Telangana",
    "37": "Andhra Pradesh (New)",
    "38": "Ladakh",
    "97": "Other Territory",
    "99": "Center Jurisdiction / Special Zone"
}


def get_state_from_gstin(gstin: str) -> str:
    """
    Extract state name from the first two digits of GSTIN.
    Returns state name or 'Unknown State' if code is not matched.
    """
    if not gstin or len(gstin.strip()) < 2:
        return "Unknown State"

    code = gstin.strip()[:2]
    return GST_STATE_CODES.get(code, "Unknown State")


def validate_gstin_format(gstin: str) -> tuple[bool, str]:
    """
    Validate standard 15-character GSTIN format:
    Format: 2 digits (State) + 10 chars (PAN) + 1 char (Entity) + 1 char ('Z') + 1 char (Checksum)
    """
    if not gstin:
        return False, "GSTIN cannot be empty"

    gstin_clean = gstin.strip().upper()
    if len(gstin_clean) != 15:
        return False, f"GSTIN must be exactly 15 characters (Got {len(gstin_clean)})"

    pattern = r"^[0-3][0-9][A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$"
    # Basic check for state digits and PAN structure
    if not re.match(pattern, gstin_clean):
        # Fallback soft validation if exact regex doesn't match standard variation
        code = gstin_clean[:2]
        if code in GST_STATE_CODES and len(gstin_clean) == 15:
            return True, "Valid GSTIN format (Soft match)"
        return False, "Invalid GSTIN format structure (e.g. 06AAAAA7182F1ZD)"

    return True, "Valid GSTIN format"
