# DATABASE STRUCTURE: GST Lit assist

Database File: `data/gst_lit_assist.db`  
Engine: SQLite 3  
Pragmas: `PRAGMA foreign_keys = ON;`

---

## Entity Relationship Schema

```
clients (1) ────< (N) gstins
   │
   ├────< (N) cases (1) ────< (N) notices (1) ────< (N) discrepancies
   │             │                   │
   ├─────────────┼───────────────────┼────< (N) documents
   │             │                   │
   └─────────────┴───────────────────┴────< (N) replies
```

---

## Table Definitions

### 1. `clients`
Stores primary taxpayer client profiles.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `client_id` | TEXT | UNIQUE NOT NULL | Client code (e.g. `CLI-001`) |
| `client_name` | TEXT | NOT NULL | Legal name of taxpayer |
| `trade_name` | TEXT | NULL | Trade name of business |
| `contact_person` | TEXT | NULL | Name of contact person |
| `email` | TEXT | NULL | Email address |
| `phone` | TEXT | NULL | Contact phone number |
| `gstin` | TEXT | UNIQUE NOT NULL | 15-digit GSTIN |
| `state` | TEXT | NULL | Derived or entered State |
| `address` | TEXT | NULL | Principal place of business |
| `notes` | TEXT | NULL | Additional notes |
| `created_at` | TEXT | NULL | Registration timestamp |

---

### 2. `gstins`
Tracks GSTIN numbers associated with clients.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `gstin` | TEXT | UNIQUE NOT NULL | 15-digit GSTIN |
| `client_id` | INTEGER | FOREIGN KEY -> `clients(id)` | Parent client ID |
| `state` | TEXT | NULL | State name |
| `jurisdiction` | TEXT | NULL | Tax jurisdiction ward/range |
| `status` | TEXT | DEFAULT 'Active' | Active/Inactive status |

---

### 3. `cases`
Tracks litigation cases.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `case_id` | TEXT | UNIQUE NOT NULL | System case code |
| `case_number` | TEXT | UNIQUE NOT NULL | Case reference number |
| `client_id` | INTEGER | FOREIGN KEY -> `clients(id)` | Parent client |
| `gstin` | TEXT | NOT NULL | Associated GSTIN |
| `financial_year` | TEXT | NOT NULL | Financial Year (e.g. `2022-23`) |
| `notice_type` | TEXT | NULL | ASMT-10, DRC-01A, Audit, etc. |
| `section` | TEXT | NULL | CGST Act section |
| `notice_date` | TEXT | NULL | Issue date |
| `due_date` | TEXT | NULL | Reply due date |
| `jurisdiction` | TEXT | NULL | Tax ward |
| `officer` | TEXT | NULL | Proper Officer Name |
| `status` | TEXT | DEFAULT 'Open' | Open, Under Review, Reply Drafted, Closed |
| `description` | TEXT | NULL | Summary of case |
| `remarks` | TEXT | NULL | Internal remarks |
| `created_at` | TEXT | NULL | Creation timestamp |

---

### 4. `notices`
Stores notice metadata received from the GST Department.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `notice_id` | TEXT | UNIQUE NOT NULL | Notice code |
| `notice_number` | TEXT | UNIQUE NOT NULL | Official notice number |
| `notice_type` | TEXT | NOT NULL | Notice type (e.g. `ASMT-10`) |
| `client_id` | INTEGER | FOREIGN KEY -> `clients(id)` | Associated client |
| `gstin` | TEXT | NOT NULL | GSTIN |
| `case_id` | INTEGER | FOREIGN KEY -> `cases(id)` | Parent case ID |
| `financial_year` | TEXT | NULL | Financial Year |
| `tax_period` | TEXT | NULL | Tax period |
| `section` | TEXT | NULL | Section u/s |
| `notice_date` | TEXT | NULL | Issue date |
| `due_date` | TEXT | NULL | Due date |
| `subject` | TEXT | NULL | Subject line |
| `officer_observation` | TEXT | NULL | Officer summary observation |
| `status` | TEXT | DEFAULT 'New' | New, Under Review, Reply Pending, Replied |
| `created_at` | TEXT | NULL | Timestamp |

---

### 5. `discrepancies`
Stores point-wise discrepancy items attached to a notice.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `discrepancy_id` | TEXT | UNIQUE NOT NULL | Code |
| `notice_id` | INTEGER | FOREIGN KEY -> `notices(id)` | Parent notice ID |
| `point_number` | INTEGER | DEFAULT 1 | Point # |
| `description` | TEXT | NULL | Discrepancy title |
| `officer_remarks` | TEXT | NULL | Specific observation |
| `amount` | REAL | DEFAULT 0.0 | Total difference amount |
| `cgst` | REAL | DEFAULT 0.0 | CGST component |
| `sgst` | REAL | DEFAULT 0.0 | SGST component |
| `igst` | REAL | DEFAULT 0.0 | IGST component |
| `cess` | REAL | DEFAULT 0.0 | CESS component |
| `return_form` | TEXT | NULL | GSTR-3B / GSTR-2B |
| `section` | TEXT | NULL | Section u/s |
| `required_documents` | TEXT | NULL | Documents requested |
| `status` | TEXT | DEFAULT 'Pending' | Pending/Resolved |

---

### 6. `documents`
Stores uploaded notice files and extraction results.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `document_id` | TEXT | UNIQUE NOT NULL | Document code |
| `client_id` | INTEGER | FOREIGN KEY -> `clients(id)` | Associated client |
| `gstin` | TEXT | NULL | GSTIN |
| `case_id` | INTEGER | FOREIGN KEY -> `cases(id)` | Linked case |
| `notice_id` | INTEGER | FOREIGN KEY -> `notices(id)` | Linked notice |
| `document_type` | TEXT | NULL | Document type |
| `filename` | TEXT | NOT NULL | File basename |
| `file_path` | TEXT | NOT NULL | Disk path |
| `upload_date` | TEXT | NULL | Upload timestamp |
| `processing_status` | TEXT | DEFAULT 'Uploaded' | Uploaded → Reading → Extracting → Completed |
| `remarks` | TEXT | NULL | Status remarks |
| `extracted_text` | TEXT | NULL | Extracted raw text |
| `extracted_metadata` | TEXT | NULL | Extracted JSON metadata |

---

### 7. `replies`
Stores generated and edited GST reply drafts.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `reply_id` | TEXT | UNIQUE NOT NULL | Reply code |
| `client_id` | INTEGER | FOREIGN KEY -> `clients(id)` | Associated client |
| `gstin` | TEXT | NULL | GSTIN |
| `case_id` | INTEGER | FOREIGN KEY -> `cases(id)` | Associated case |
| `notice_id` | INTEGER | FOREIGN KEY -> `notices(id)` | Associated notice |
| `financial_year` | TEXT | NULL | Financial Year |
| `reply_date` | TEXT | NULL | Reply date |
| `reply_type` | TEXT | NULL | Point-wise / Basic / Manual |
| `status` | TEXT | DEFAULT 'Draft' | Draft / Submitted |
| `draft_text` | TEXT | NULL | Generated legal draft text |
| `created_at` | TEXT | NULL | Timestamp |

---

### 8. `portal_sync`
Stores demo GST portal synchronization records.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique row identifier |
| `sync_id` | TEXT | UNIQUE NOT NULL | Sync batch ID |
| `gstin` | TEXT | NULL | Target GSTIN |
| `sync_date` | TEXT | NULL | Sync timestamp |
| `documents_found` | INTEGER | DEFAULT 0 | Records found |
| `documents_imported` | INTEGER | DEFAULT 0 | Records imported |
| `duplicates` | INTEGER | DEFAULT 0 | Duplicate count |
| `errors` | INTEGER | DEFAULT 0 | Errors count |
| `status` | TEXT | DEFAULT 'Completed' | Sync status |
