"""
GST Litigation Reply Generator for GST Lit assist
Generates professional point-wise legal replies using database metadata.
Enforces Reply Safety Rules: Inserts [INFORMATION REQUIRED] instead of hallucinating facts.
"""

from datetime import datetime


class ReplyGenerator:
    def __init__(self, db_instance):
        self.db = db_instance

    def generate_reply_draft(
        self,
        client_dict: dict,
        case_dict: dict,
        notice_dict: dict,
        discrepancies: list,
        reply_type: str = "Point-wise Reply"
    ) -> str:
        """
        Generate structured GST reply draft based on client, case, notice, and discrepancy points.
        """
        # Safety helpers
        client_name = client_dict.get('client_name') if client_dict and client_dict.get('client_name') else "[INFORMATION REQUIRED: Client Name]"
        gstin = client_dict.get('gstin') if client_dict and client_dict.get('gstin') else (case_dict.get('gstin') if case_dict else "[INFORMATION REQUIRED: GSTIN]")
        trade_name = client_dict.get('trade_name', '') if client_dict else ''
        address = client_dict.get('address') if client_dict and client_dict.get('address') else "[INFORMATION REQUIRED: Address]"
        
        notice_number = notice_dict.get('notice_number') if notice_dict and notice_dict.get('notice_number') else "[INFORMATION REQUIRED: Notice Number]"
        notice_type = notice_dict.get('notice_type') if notice_dict and notice_dict.get('notice_type') else "Notice"
        section = notice_dict.get('section') if notice_dict and notice_dict.get('section') else (case_dict.get('section') if case_dict else "[INFORMATION REQUIRED: Section]")
        notice_date = notice_dict.get('notice_date') if notice_dict and notice_dict.get('notice_date') else "[INFORMATION REQUIRED: Notice Date]"
        fy = notice_dict.get('financial_year') if notice_dict and notice_dict.get('financial_year') else (case_dict.get('financial_year') if case_dict else "[INFORMATION REQUIRED: Financial Year]")
        officer_observation = notice_dict.get('officer_observation') if notice_dict and notice_dict.get('officer_observation') else ""
        
        officer_name = case_dict.get('officer') if case_dict and case_dict.get('officer') else "The Proper Officer"
        jurisdiction = case_dict.get('jurisdiction') if case_dict and case_dict.get('jurisdiction') else "State/Central Tax Department"

        current_date_str = datetime.now().strftime("%d-%m-%Y")

        if reply_type == "Manual Blank Reply":
            return f"""BEFORE THE {officer_name.upper()}
{jurisdiction.upper()}

Date: {current_date_str}

To,
{officer_name}
{jurisdiction}

GSTIN: {gstin}
Name of Taxpayer: {client_name}
Financial Year: {fy}

Subject: Written Submission / Reply to {notice_type} - {notice_number}

Respected Sir/Madam,

[WRITE YOUR CUSTOM LEGAL SUBMISSION HERE]


Yours faithfully,
For {client_name}

Authorized Signatory
"""

        # Basic Professional or Point-wise Reply
        lines = []
        lines.append("=" * 70)
        lines.append(f"FORMAL REPLY TO GST {notice_type.upper()} ({section.upper()})")
        lines.append("=" * 70)
        lines.append(f"Date: {current_date_str}")
        lines.append("")
        lines.append("To,")
        lines.append(f"{officer_name}")
        lines.append(f"Office of the Assistant/Deputy Commissioner of State/Central Tax,")
        lines.append(f"{jurisdiction}")
        lines.append("")
        lines.append(f"SUBJECT: DETAILED POINT-WISE REPLY TO NOTICE NO. {notice_number} DATED {notice_date}")
        lines.append(f"GSTIN: {gstin}")
        lines.append(f"TAXPAYER NAME: {client_name}" + (f" ({trade_name})" if trade_name else ""))
        lines.append(f"ADDRESS: {address}")
        lines.append(f"FINANCIAL YEAR: {fy}")
        lines.append("")
        lines.append("Respected Sir/Madam,")
        lines.append("")
        lines.append(f"With reference to the above-captioned notice issued under {section} of the CGST/SGST Act, 2017, for the Financial Year {fy}, the taxpayer respectfully submits the following detailed response for your kind consideration.")
        lines.append("")

        if officer_observation:
            lines.append("-" * 70)
            lines.append("GENERAL DEPARTMENTAL OVERVIEW / OBSERVATION:")
            lines.append("-" * 70)
            lines.append(officer_observation)
            lines.append("")

        lines.append("=" * 70)
        lines.append("POINT-WISE RESPONSES & SUBMISSIONS")
        lines.append("=" * 70)

        if not discrepancies:
            lines.append("1. Point No. 1: Departmental Observation")
            lines.append(f"   [Observation: {officer_observation if officer_observation else '[INFORMATION REQUIRED: Specific Discrepancy Observation]'}]")
            lines.append("")
            lines.append("2. Taxpayer Submission:")
            lines.append("   It is humbly submitted that all turnover, input tax credit (ITC), and tax payments declared in GSTR-1 and GSTR-3B have been duly reconciled with books of accounts. The alleged discrepancy is due to timing differences / reconciliation format differences.")
            lines.append("")
            lines.append("3. Supporting Documents Attached:")
            lines.append("   - GSTR-2A/2B vs GSTR-3B Reconciliation Statement")
            lines.append("   - Purchase Register and Sales Register")
            lines.append("   - Copy of Input Tax Credit Ledger & Bank Statements")
            lines.append("")
        else:
            for idx, disc in enumerate(discrepancies, 1):
                p_num = disc.get('point_number', idx)
                desc = disc.get('description', 'Discrepancy Point')
                off_rem = disc.get('officer_remarks', '')
                amt = disc.get('amount', 0.0)
                cgst = disc.get('cgst', 0.0)
                sgst = disc.get('sgst', 0.0)
                igst = disc.get('igst', 0.0)
                cess = disc.get('cess', 0.0)
                sec = disc.get('section', section)
                req_docs = disc.get('required_documents', 'Reconciliation Statement & Ledger')

                lines.append(f"POINT #{p_num}: {desc.upper()} ({sec})")
                lines.append("-" * 50)
                if off_rem:
                    lines.append(f"a) Departmental Observation: {off_rem}")
                else:
                    lines.append("a) Departmental Observation: ITC / Tax difference noted in Notice.")

                lines.append("b) Quantified Discrepancy Amount:")
                lines.append(f"   - CGST Amount : Rs. {cgst:,.2f}" if cgst else "   - CGST Amount : Rs. [INFORMATION REQUIRED]")
                lines.append(f"   - SGST Amount : Rs. {sgst:,.2f}" if sgst else "   - SGST Amount : Rs. [INFORMATION REQUIRED]")
                lines.append(f"   - IGST Amount : Rs. {igst:,.2f}" if igst else "   - IGST Amount : Rs. [INFORMATION REQUIRED]")
                lines.append(f"   - CESS Amount : Rs. {cess:,.2f}" if cess else "   - CESS Amount : Rs. 0.00")
                lines.append(f"   - Total Amount: Rs. {amt:,.2f}" if amt else f"   - Total Amount: Rs. {cgst+sgst+igst+cess:,.2f}")
                lines.append("")
                lines.append("c) Taxpayer Submission:")
                lines.append("   The taxpayer respectfully submits that the eligible Input Tax Credit has been claimed strictly in accordance with Section 16 of the CGST Act, 2017. The conditions of receipt of goods/services and payment of tax by suppliers have been duly satisfied. The discrepancy stands fully explained by the attached reconciliation.")
                lines.append("")
                lines.append("d) Supporting Documents Annexed:")
                lines.append(f"   - {req_docs}")
                lines.append("   - Tax Invoice copies & Payment proof")
                lines.append("")

        lines.append("=" * 70)
        lines.append("PRAYER")
        lines.append("=" * 70)
        lines.append("In view of the above factual submissions and annexed supporting reconciliation documents, it is respectfully requested that:")
        lines.append("  1. The detailed explanation and supporting documents submitted herein may kindly be taken on record.")
        lines.append(f"  2. The proposed demand/observation in Notice {notice_number} may kindly be dropped.")
        lines.append("  3. The proceedings under the said notice may kindly be formally concluded in accordance with law.")
        lines.append("  4. An opportunity of personal hearing may kindly be granted prior to passing any adverse order.")
        lines.append("")
        lines.append("Yours faithfully,")
        lines.append(f"For {client_name}")
        lines.append("")
        lines.append("")
        lines.append("______________________________________")
        lines.append("Authorized Signatory / Tax Practitioner")
        lines.append("")
        lines.append("Encl: As above")

        return "\n".join(lines)
