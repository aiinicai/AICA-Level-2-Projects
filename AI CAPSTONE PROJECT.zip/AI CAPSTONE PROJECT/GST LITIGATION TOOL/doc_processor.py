"""
Automatic Document Processing Pipeline for GST Lit assist
Reads text from PDF, DOCX, TXT, CSV, XLSX files and performs automatic metadata extraction.
Workflow: Uploaded -> Reading -> Extracting -> Completed / Completed with Warning
No manual 'EXTRACT' click required.
"""

import os
import re
import json
import logging
from datetime import datetime

# Optional document libraries with graceful fallback
try:
    import PyPDF2
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

try:
    import docx
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

try:
    import openpyxl
    EXCEL_SUPPORT = True
except ImportError:
    EXCEL_SUPPORT = False


class DocumentProcessor:
    def __init__(self, db_instance):
        self.db = db_instance

    def process_document_auto(self, doc_db_id: int):
        """
        Execute automatic document processing pipeline:
        Uploaded -> Reading -> Extracting -> Metadata Identified -> Completed
        """
        # Step 1: Fetch doc record
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM documents WHERE id = ?", (doc_db_id,))
        doc = cursor.fetchone()
        conn.close()

        if not doc:
            logging.error(f"Doc ID {doc_db_id} not found for auto-processing.")
            return

        file_path = doc['file_path']
        filename = doc['filename']

        # Update status to READING
        self.db.update_document_status(doc_db_id, "Reading", remarks="Opening document file...")

        # Step 2: Read Text
        extracted_text, read_status, warning = self.extract_raw_text(file_path)

        if not read_status:
            self.db.update_document_status(
                doc_db_id, 
                "Completed with Warning", 
                text=extracted_text, 
                remarks=f"Read warning: {warning}"
            )
            return

        # Update status to EXTRACTING
        self.db.update_document_status(doc_db_id, "Extracting", text=extracted_text, remarks="Extracting GST metadata...")

        # Step 3: Extract Metadata using simple pattern matching
        metadata = self.extract_gst_metadata(extracted_text, filename)

        # Step 4: Save & Complete
        metadata_json = json.dumps(metadata, indent=2)
        
        status_final = "Completed" if read_status else "Completed with Warning"
        remarks_final = "Automatic processing completed successfully." if read_status else f"Warning: {warning}"

        self.db.update_document_status(
            doc_db_id, 
            status_final, 
            text=extracted_text, 
            metadata=metadata_json, 
            remarks=remarks_final
        )
        
        logging.info(f"Auto document processing completed for doc {doc_db_id} ({filename}) -> {status_final}")

    def extract_raw_text(self, file_path: str) -> tuple[str, bool, str]:
        """Extract text based on file extension."""
        if not os.path.exists(file_path):
            return "", False, "File path does not exist on disk."

        ext = os.path.splitext(file_path)[1].lower()
        text = ""
        success = True
        warning = ""

        try:
            if ext == ".txt":
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()

            elif ext == ".pdf":
                if PDF_SUPPORT:
                    with open(file_path, "rb") as f:
                        reader = PyPDF2.PdfReader(f)
                        pages_text = []
                        for i, page in enumerate(reader.pages):
                            pt = page.extract_text()
                            if pt:
                                pages_text.append(pt)
                        text = "\n".join(pages_text)
                    if not text.strip():
                        text = "[PDF Content extracted - Scanned/Image PDF or Empty]"
                        warning = "PDF contains scanned imagery or unreadable text layers."
                else:
                    text = f"[PDF File: {os.path.basename(file_path)}]\nNote: PyPDF2 library not available for deep text parsing."
                    warning = "PyPDF2 module missing."

            elif ext == ".docx":
                if DOCX_SUPPORT:
                    doc = docx.Document(file_path)
                    paragraphs = [p.text for p in doc.paragraphs if p.text]
                    text = "\n".join(paragraphs)
                else:
                    text = f"[Word DOCX File: {os.path.basename(file_path)}]\nNote: python-docx not installed."
                    warning = "python-docx module missing."

            elif ext in [".xlsx", ".xls"]:
                if EXCEL_SUPPORT:
                    wb = openpyxl.load_workbook(file_path, data_only=True)
                    rows_text = []
                    for sheet in wb.sheetnames:
                        ws = wb[sheet]
                        rows_text.append(f"--- Sheet: {sheet} ---")
                        for row in ws.iter_rows(values_only=True):
                            r_str = " | ".join([str(val) for val in row if val is not None])
                            if r_str:
                                rows_text.append(r_str)
                    text = "\n".join(rows_text)
                else:
                    text = f"[Excel File: {os.path.basename(file_path)}]"

            elif ext == ".csv":
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()

            else:
                text = f"[Document File: {os.path.basename(file_path)}]\nSupported file type loaded."
                warning = f"Generic text view for file extension {ext}"

        except Exception as e:
            text = f"Error reading file content: {str(e)}"
            success = False
            warning = str(e)

        return text, success, warning

    def extract_gst_metadata(self, text: str, filename: str) -> dict:
        """Simple pattern-based GST document intelligence extraction."""
        meta = {
            "notice_number": None,
            "gstin": None,
            "notice_type": None,
            "financial_year": None,
            "section": None,
            "notice_date": None,
            "due_date": None,
            "tax_period": None,
            "cgst": 0.0,
            "sgst": 0.0,
            "igst": 0.0,
            "cess": 0.0,
            "total_amount": 0.0,
            "client_name": None,
            "officer_remarks": None
        }

        if not text:
            return meta

        # 1. GSTIN (15 chars)
        gstin_match = re.search(r"\b[0-3][0-9][A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}\b", text)
        if gstin_match:
            meta["gstin"] = gstin_match.group(0)

        # 2. Notice Number (e.g. ASMT10/2026/001, DRC01A/2026/002, ORD/2026/003)
        no_match = re.search(r"(?:Notice\s*(?:No|Number|Ref)?[\s:-]*|\b)([A-Z0-9/\-_]{8,25})\b", text, re.IGNORECASE)
        if no_match:
            meta["notice_number"] = no_match.group(1)

        # 3. Notice Type (ASMT-10, DRC-01A, Audit, Order, SCN)
        if "ASMT-10" in text or "ASMT10" in text:
            meta["notice_type"] = "ASMT-10"
        elif "DRC-01A" in text or "DRC01A" in text:
            meta["notice_type"] = "DRC-01A"
        elif "DRC-01" in text:
            meta["notice_type"] = "DRC-01"
        elif "Audit" in text or "ADT-01" in text:
            meta["notice_type"] = "Audit Notice (ADT-01)"
        elif "Order" in text or "MOV-09" in text:
            meta["notice_type"] = "Assessment Order"

        # 4. Financial Year (e.g. 2022-23, 2023-24, F.Y. 2022-2023)
        fy_match = re.search(r"(?:FY|F\.Y\.|Financial Year)[\s:-]*(\d{4}[-\s]?\d{2,4})", text, re.IGNORECASE)
        if fy_match:
            meta["financial_year"] = fy_match.group(1)

        # 5. Section (e.g. Section 61, Section 73, Section 74, Section 65)
        sec_match = re.search(r"(?:Section|u/s)[\s]*(\d+)", text, re.IGNORECASE)
        if sec_match:
            meta["section"] = f"Section {sec_match.group(1)}"

        # 6. Amounts (CGST, SGST, IGST, CESS)
        cgst_m = re.search(r"CGST[\s:Rs.]*([0-9,]+\.?[0-9]*)", text, re.IGNORECASE)
        if cgst_m:
            try: meta["cgst"] = float(cgst_m.group(1).replace(",", ""))
            except: pass

        sgst_m = re.search(r"SGST[\s:Rs.]*([0-9,]+\.?[0-9]*)", text, re.IGNORECASE)
        if sgst_m:
            try: meta["sgst"] = float(sgst_m.group(1).replace(",", ""))
            except: pass

        igst_m = re.search(r"IGST[\s:Rs.]*([0-9,]+\.?[0-9]*)", text, re.IGNORECASE)
        if igst_m:
            try: meta["igst"] = float(igst_m.group(1).replace(",", ""))
            except: pass

        cess_m = re.search(r"CESS[\s:Rs.]*([0-9,]+\.?[0-9]*)", text, re.IGNORECASE)
        if cess_m:
            try: meta["cess"] = float(cess_m.group(1).replace(",", ""))
            except: pass

        meta["total_amount"] = round(meta["cgst"] + meta["sgst"] + meta["igst"] + meta["cess"], 2)

        return meta
