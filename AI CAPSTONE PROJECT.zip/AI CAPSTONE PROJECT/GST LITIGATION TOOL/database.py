"""
SQLite Database Access Layer for GST Lit assist
Handles schema creation, connections, foreign keys, and CRUD queries.
"""

import os
import sqlite3
import logging
from datetime import datetime

# Setup logging
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "application.log")

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)


class Database:
    def __init__(self, db_path: str = None):
        if db_path is None:
            data_dir = os.path.join(os.path.dirname(__file__), "data")
            os.makedirs(data_dir, exist_ok=True)
            db_path = os.path.join(data_dir, "gst_lit_assist.db")
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def init_db(self):
        """Creates tables if they do not exist."""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Clients Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id TEXT UNIQUE NOT NULL,
            client_name TEXT NOT NULL,
            trade_name TEXT,
            contact_person TEXT,
            email TEXT,
            phone TEXT,
            gstin TEXT UNIQUE NOT NULL,
            state TEXT,
            address TEXT,
            notes TEXT,
            created_at TEXT
        );
        """)

        # GSTINs Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS gstins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gstin TEXT UNIQUE NOT NULL,
            client_id INTEGER,
            state TEXT,
            jurisdiction TEXT,
            status TEXT DEFAULT 'Active',
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
        );
        """)

        # Cases Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_id TEXT UNIQUE NOT NULL,
            case_number TEXT UNIQUE NOT NULL,
            client_id INTEGER NOT NULL,
            gstin TEXT NOT NULL,
            financial_year TEXT NOT NULL,
            notice_type TEXT,
            section TEXT,
            notice_date TEXT,
            due_date TEXT,
            jurisdiction TEXT,
            officer TEXT,
            status TEXT DEFAULT 'Open',
            description TEXT,
            remarks TEXT,
            created_at TEXT,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
        );
        """)

        # Notices Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS notices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notice_id TEXT UNIQUE NOT NULL,
            notice_number TEXT UNIQUE NOT NULL,
            notice_type TEXT NOT NULL,
            client_id INTEGER NOT NULL,
            gstin TEXT NOT NULL,
            case_id INTEGER,
            financial_year TEXT,
            tax_period TEXT,
            section TEXT,
            notice_date TEXT,
            due_date TEXT,
            subject TEXT,
            officer_observation TEXT,
            status TEXT DEFAULT 'New',
            created_at TEXT,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
            FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
        );
        """)

        # Discrepancies Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS discrepancies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discrepancy_id TEXT UNIQUE NOT NULL,
            notice_id INTEGER NOT NULL,
            point_number INTEGER DEFAULT 1,
            description TEXT,
            officer_remarks TEXT,
            amount REAL DEFAULT 0.0,
            cgst REAL DEFAULT 0.0,
            sgst REAL DEFAULT 0.0,
            igst REAL DEFAULT 0.0,
            cess REAL DEFAULT 0.0,
            return_form TEXT,
            section TEXT,
            required_documents TEXT,
            status TEXT DEFAULT 'Pending',
            FOREIGN KEY (notice_id) REFERENCES notices(id) ON DELETE CASCADE
        );
        """)

        # Documents Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id TEXT UNIQUE NOT NULL,
            client_id INTEGER,
            gstin TEXT,
            case_id INTEGER,
            notice_id INTEGER,
            document_type TEXT,
            filename TEXT NOT NULL,
            file_path TEXT NOT NULL,
            upload_date TEXT,
            processing_status TEXT DEFAULT 'Uploaded',
            remarks TEXT,
            extracted_text TEXT,
            extracted_metadata TEXT,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
            FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL,
            FOREIGN KEY (notice_id) REFERENCES notices(id) ON DELETE SET NULL
        );
        """)

        # Replies Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS replies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reply_id TEXT UNIQUE NOT NULL,
            client_id INTEGER NOT NULL,
            gstin TEXT,
            case_id INTEGER,
            notice_id INTEGER,
            financial_year TEXT,
            reply_date TEXT,
            reply_type TEXT,
            status TEXT DEFAULT 'Draft',
            draft_text TEXT,
            created_at TEXT,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
            FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL,
            FOREIGN KEY (notice_id) REFERENCES notices(id) ON DELETE SET NULL
        );
        """)

        # Portal Sync Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS portal_sync (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sync_id TEXT UNIQUE NOT NULL,
            gstin TEXT,
            sync_date TEXT,
            documents_found INTEGER DEFAULT 0,
            documents_imported INTEGER DEFAULT 0,
            duplicates INTEGER DEFAULT 0,
            errors INTEGER DEFAULT 0,
            status TEXT DEFAULT 'Completed'
        );
        """)

        conn.commit()
        conn.close()
        logging.info("Database schema initialized successfully.")

    # -------------------- CLIENTS CRUD --------------------
    def add_client(self, client_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        cursor.execute("""
        INSERT INTO clients (client_id, client_name, trade_name, contact_person, email, phone, gstin, state, address, notes, created_at)
        VALUES (:client_id, :client_name, :trade_name, :contact_person, :email, :phone, :gstin, :state, :address, :notes, :created_at)
        """, {
            'client_id': client_data.get('client_id'),
            'client_name': client_data.get('client_name'),
            'trade_name': client_data.get('trade_name', ''),
            'contact_person': client_data.get('contact_person', ''),
            'email': client_data.get('email', ''),
            'phone': client_data.get('phone', ''),
            'gstin': client_data.get('gstin').strip().upper(),
            'state': client_data.get('state', ''),
            'address': client_data.get('address', ''),
            'notes': client_data.get('notes', ''),
            'created_at': now_str
        })
        client_row_id = cursor.lastrowid

        # Also add to gstins table
        cursor.execute("""
        INSERT OR IGNORE INTO gstins (gstin, client_id, state, status)
        VALUES (?, ?, ?, 'Active')
        """, (client_data.get('gstin').strip().upper(), client_row_id, client_data.get('state', '')))

        conn.commit()
        conn.close()
        logging.info(f"Added client {client_data.get('client_name')} (GSTIN: {client_data.get('gstin')})")
        return client_row_id

    def get_all_clients(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients ORDER BY id DESC")
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    def get_client_by_id(self, client_db_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients WHERE id = ?", (client_db_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def get_client_by_gstin(self, gstin: str):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients WHERE gstin = ?", (gstin.strip().upper(),))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def delete_client(self, client_db_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clients WHERE id = ?", (client_db_id,))
        conn.commit()
        conn.close()
        logging.info(f"Deleted client id {client_db_id}")

    # -------------------- CASES CRUD --------------------
    def add_case(self, case_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
        INSERT INTO cases (case_id, case_number, client_id, gstin, financial_year, notice_type, section, notice_date, due_date, jurisdiction, officer, status, description, remarks, created_at)
        VALUES (:case_id, :case_number, :client_id, :gstin, :financial_year, :notice_type, :section, :notice_date, :due_date, :jurisdiction, :officer, :status, :description, :remarks, :created_at)
        """, {
            'case_id': case_data.get('case_id'),
            'case_number': case_data.get('case_number'),
            'client_id': case_data.get('client_id'),
            'gstin': case_data.get('gstin'),
            'financial_year': case_data.get('financial_year'),
            'notice_type': case_data.get('notice_type', ''),
            'section': case_data.get('section', ''),
            'notice_date': case_data.get('notice_date', ''),
            'due_date': case_data.get('due_date', ''),
            'jurisdiction': case_data.get('jurisdiction', ''),
            'officer': case_data.get('officer', ''),
            'status': case_data.get('status', 'Open'),
            'description': case_data.get('description', ''),
            'remarks': case_data.get('remarks', ''),
            'created_at': now_str
        })
        row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logging.info(f"Added case {case_data.get('case_number')}")
        return row_id

    def get_all_cases(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT c.*, cl.client_name 
        FROM cases c 
        LEFT JOIN clients cl ON c.client_id = cl.id 
        ORDER BY c.id DESC
        """)
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    def get_cases_by_client(self, client_db_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cases WHERE client_id = ? ORDER BY id DESC", (client_db_id,))
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    # -------------------- NOTICES CRUD --------------------
    def add_notice(self, notice_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
        INSERT INTO notices (notice_id, notice_number, notice_type, client_id, gstin, case_id, financial_year, tax_period, section, notice_date, due_date, subject, officer_observation, status, created_at)
        VALUES (:notice_id, :notice_number, :notice_type, :client_id, :gstin, :case_id, :financial_year, :tax_period, :section, :notice_date, :due_date, :subject, :officer_observation, :status, :created_at)
        """, {
            'notice_id': notice_data.get('notice_id'),
            'notice_number': notice_data.get('notice_number'),
            'notice_type': notice_data.get('notice_type'),
            'client_id': notice_data.get('client_id'),
            'gstin': notice_data.get('gstin'),
            'case_id': notice_data.get('case_id'),
            'financial_year': notice_data.get('financial_year', ''),
            'tax_period': notice_data.get('tax_period', ''),
            'section': notice_data.get('section', ''),
            'notice_date': notice_data.get('notice_date', ''),
            'due_date': notice_data.get('due_date', ''),
            'subject': notice_data.get('subject', ''),
            'officer_observation': notice_data.get('officer_observation', ''),
            'status': notice_data.get('status', 'New'),
            'created_at': now_str
        })
        notice_row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logging.info(f"Added notice {notice_data.get('notice_number')}")
        return notice_row_id

    def get_all_notices(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT n.*, cl.client_name, cs.case_number 
        FROM notices n 
        LEFT JOIN clients cl ON n.client_id = cl.id 
        LEFT JOIN cases cs ON n.case_id = cs.id 
        ORDER BY n.id DESC
        """)
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    # -------------------- DISCREPANCIES --------------------
    def add_discrepancy(self, disc_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO discrepancies (discrepancy_id, notice_id, point_number, description, officer_remarks, amount, cgst, sgst, igst, cess, return_form, section, required_documents, status)
        VALUES (:discrepancy_id, :notice_id, :point_number, :description, :officer_remarks, :amount, :cgst, :sgst, :igst, :cess, :return_form, :section, :required_documents, :status)
        """, {
            'discrepancy_id': disc_data.get('discrepancy_id'),
            'notice_id': disc_data.get('notice_id'),
            'point_number': disc_data.get('point_number', 1),
            'description': disc_data.get('description', ''),
            'officer_remarks': disc_data.get('officer_remarks', ''),
            'amount': disc_data.get('amount', 0.0),
            'cgst': disc_data.get('cgst', 0.0),
            'sgst': disc_data.get('sgst', 0.0),
            'igst': disc_data.get('igst', 0.0),
            'cess': disc_data.get('cess', 0.0),
            'return_form': disc_data.get('return_form', ''),
            'section': disc_data.get('section', ''),
            'required_documents': disc_data.get('required_documents', ''),
            'status': disc_data.get('status', 'Pending')
        })
        row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return row_id

    def get_discrepancies_by_notice(self, notice_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM discrepancies WHERE notice_id = ? ORDER BY point_number ASC", (notice_id,))
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    # -------------------- DOCUMENTS --------------------
    def add_document(self, doc_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
        INSERT INTO documents (document_id, client_id, gstin, case_id, notice_id, document_type, filename, file_path, upload_date, processing_status, remarks, extracted_text, extracted_metadata)
        VALUES (:document_id, :client_id, :gstin, :case_id, :notice_id, :document_type, :filename, :file_path, :upload_date, :processing_status, :remarks, :extracted_text, :extracted_metadata)
        """, {
            'document_id': doc_data.get('document_id'),
            'client_id': doc_data.get('client_id'),
            'gstin': doc_data.get('gstin', ''),
            'case_id': doc_data.get('case_id'),
            'notice_id': doc_data.get('notice_id'),
            'document_type': doc_data.get('document_type', 'Notice'),
            'filename': doc_data.get('filename'),
            'file_path': doc_data.get('file_path'),
            'upload_date': now_str,
            'processing_status': doc_data.get('processing_status', 'Uploaded'),
            'remarks': doc_data.get('remarks', ''),
            'extracted_text': doc_data.get('extracted_text', ''),
            'extracted_metadata': doc_data.get('extracted_metadata', '')
        })
        row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logging.info(f"Added document {doc_data.get('filename')}")
        return row_id

    def update_document_status(self, doc_id: int, status: str, text: str = "", metadata: str = "", remarks: str = ""):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE documents 
        SET processing_status = ?, extracted_text = COALESCE(NULLIF(?, ''), extracted_text), extracted_metadata = COALESCE(NULLIF(?, ''), extracted_metadata), remarks = COALESCE(NULLIF(?, ''), remarks)
        WHERE id = ?
        """, (status, text, metadata, remarks, doc_id))
        conn.commit()
        conn.close()

    def get_all_documents(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT d.*, cl.client_name 
        FROM documents d 
        LEFT JOIN clients cl ON d.client_id = cl.id 
        ORDER BY d.id DESC
        """)
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    # -------------------- REPLIES --------------------
    def add_reply(self, reply_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
        INSERT INTO replies (reply_id, client_id, gstin, case_id, notice_id, financial_year, reply_date, reply_type, status, draft_text, created_at)
        VALUES (:reply_id, :client_id, :gstin, :case_id, :notice_id, :financial_year, :reply_date, :reply_type, :status, :draft_text, :created_at)
        """, {
            'reply_id': reply_data.get('reply_id'),
            'client_id': reply_data.get('client_id'),
            'gstin': reply_data.get('gstin', ''),
            'case_id': reply_data.get('case_id'),
            'notice_id': reply_data.get('notice_id'),
            'financial_year': reply_data.get('financial_year', ''),
            'reply_date': reply_data.get('reply_date', now_str[:10]),
            'reply_type': reply_data.get('reply_type', 'Point-wise Reply'),
            'status': reply_data.get('status', 'Draft'),
            'draft_text': reply_data.get('draft_text', ''),
            'created_at': now_str
        })
        row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logging.info(f"Added reply draft ID {reply_data.get('reply_id')}")
        return row_id

    def get_all_replies(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT r.*, cl.client_name, n.notice_number 
        FROM replies r 
        LEFT JOIN clients cl ON r.client_id = cl.id 
        LEFT JOIN notices n ON r.notice_id = n.id 
        ORDER BY r.id DESC
        """)
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    def update_reply_text(self, reply_db_id: int, text: str, status: str = "Draft"):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE replies SET draft_text = ?, status = ? WHERE id = ?", (text, status, reply_db_id))
        conn.commit()
        conn.close()

    # -------------------- PORTAL SYNC --------------------
    def add_portal_sync(self, sync_data: dict) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
        INSERT INTO portal_sync (sync_id, gstin, sync_date, documents_found, documents_imported, duplicates, errors, status)
        VALUES (:sync_id, :gstin, :sync_date, :documents_found, :documents_imported, :duplicates, :errors, :status)
        """, {
            'sync_id': sync_data.get('sync_id'),
            'gstin': sync_data.get('gstin', ''),
            'sync_date': now_str,
            'documents_found': sync_data.get('documents_found', 0),
            'documents_imported': sync_data.get('documents_imported', 0),
            'duplicates': sync_data.get('duplicates', 0),
            'errors': sync_data.get('errors', 0),
            'status': sync_data.get('status', 'Completed')
        })
        row_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return row_id

    def get_portal_sync_history(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM portal_sync ORDER BY id DESC")
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows

    # -------------------- DASHBOARD STATS --------------------
    def get_dashboard_stats(self):
        conn = self.get_connection()
        cursor = conn.cursor()

        stats = {}
        cursor.execute("SELECT COUNT(*) FROM clients")
        stats['total_clients'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM gstins")
        stats['total_gstins'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM cases")
        stats['total_cases'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM cases WHERE status = 'Open' OR status = 'Under Review'")
        stats['open_cases'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM notices WHERE status IN ('New', 'Under Review', 'Reply Pending')")
        stats['pending_notices'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM replies WHERE status = 'Draft'")
        stats['pending_replies'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM documents")
        stats['total_documents'] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM replies WHERE status IN ('Submitted', 'Final')")
        stats['completed_replies'] = cursor.fetchone()[0]

        conn.close()
        return stats
