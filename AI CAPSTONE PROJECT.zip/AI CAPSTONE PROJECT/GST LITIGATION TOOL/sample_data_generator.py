"""
Sample Data Generator for GST Lit assist
Generates Excel sample files and populates SQLite database on initial application launch.
"""

import os
import openpyxl
import logging
from datetime import datetime
from gst_utils import get_state_from_gstin


def generate_sample_files(base_dir: str):
    """Generate sample_clients.xlsx and sample_cases.xlsx if they don't exist."""
    sample_dir = os.path.join(base_dir, "sample_data")
    os.makedirs(sample_dir, exist_ok=True)
    os.makedirs(os.path.join(sample_dir, "sample_notices"), exist_ok=True)
    os.makedirs(os.path.join(sample_dir, "sample_documents"), exist_ok=True)

    # 1. Create sample_clients.xlsx
    excel_clients_path = os.path.join(sample_dir, "sample_clients.xlsx")
    if not os.path.exists(excel_clients_path):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Clients"
        headers = ["Client Name", "Trade Name", "Contact Person", "Email", "Phone", "GSTIN", "State", "Address", "Notes"]
        ws.append(headers)

        rows = [
            ["Mahajan Life Sciences", "Mahajan Pharma", "Rajesh Mahajan", "info@mahajanlife.com", "9876543210", "06AAAAA7182F1ZD", "Haryana", "Plot 42, Industrial Area Phase I, Gurugram, Haryana", "Pharma Manufacturer"],
            ["ABC Engineering Works", "ABC Engg", "Anil Kumar", "contact@abcengineering.in", "9811223344", "07BBBBB1234C1ZA", "Delhi", "Mayapuri Industrial Area Phase II, New Delhi", "Capital Goods Fabricator"],
            ["Sunrise Trading Co.", "Sunrise Traders", "Suresh Sharma", "sales@sunrisetrading.com", "9935001122", "09CCCCC5678D1ZB", "Uttar Pradesh", "Transport Nagar, Kanpur, Uttar Pradesh", "FMCG Wholesale Distributor"],
            ["Apex Infra Projects Ltd", "Apex Infra", "Vikram Malhotra", "tax@apexinfra.com", "9820011223", "27DDDDD9999E1ZC", "Maharashtra", "BKC Complex, Bandra East, Mumbai", "Infrastructure Contractor"],
            ["Southern Logistics Pvt Ltd", "Southern Cargo", "K. Ramanathan", "accounts@southernlogistics.co.in", "9444055667", "33EEEEE4444F1ZD", "Tamil Nadu", "Mount Road, Guindy, Chennai", "Transport & Freight Forwarding"]
        ]
        for r in rows:
            ws.append(r)
        wb.save(excel_clients_path)
        logging.info(f"Created sample client Excel file at {excel_clients_path}")

    # 2. Create sample_cases.xlsx
    excel_cases_path = os.path.join(sample_dir, "sample_cases.xlsx")
    if not os.path.exists(excel_cases_path):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Cases"
        headers = ["Case Number", "Client Name", "GSTIN", "Financial Year", "Notice Type", "Section", "Notice Date", "Due Date", "Status", "Description"]
        ws.append(headers)

        rows = [
            ["CASE-2026-001", "Mahajan Life Sciences", "06AAAAA7182F1ZD", "2022-23", "ASMT-10", "Section 61", "2026-08-10", "2026-09-10", "Open", "ITC discrepancy & turnover verification notice"],
            ["CASE-2026-002", "ABC Engineering Works", "07BBBBB1234C1ZA", "2023-24", "DRC-01A", "Section 74", "2026-08-15", "2026-09-15", "Open", "Pre-show cause notice for alleged wrong ITC claim"],
            ["CASE-2026-003", "Sunrise Trading Co.", "09CCCCC5678D1ZB", "2022-23", "Audit", "Section 65", "2026-08-20", "2026-09-20", "Under Review", "GST Departmental Audit for FY 2022-23"]
        ]
        for r in rows:
            ws.append(r)
        wb.save(excel_cases_path)
        logging.info(f"Created sample case Excel file at {excel_cases_path}")

    # 3. Create Sample Notice Text File (ASMT-10)
    asmt10_file = os.path.join(sample_dir, "sample_notices", "ASMT-10_Notice_Mahajan_Life_Sciences.txt")
    if not os.path.exists(asmt10_file):
        notice_content = """FORM GST ASMT-10
[See rule 99(1)]
NOTICE FOR POINTING OUT DISCREPANCIES IN THE RETURN AFTER SCRUTINY

Reference No: ASMT10/2026/001
Date: 10-08-2026

To,
GSTIN: 06AAAAA7182F1ZD
Taxpayer Name: Mahajan Life Sciences
Trade Name: Mahajan Pharma
Address: Plot 42, Industrial Area Phase I, Gurugram, Haryana - 122001
Financial Year: 2022-23
Tax Period: April 2022 to March 2023

Subject: Notice for pointing out discrepancies in GSTR-3B vs GSTR-2B u/s 61 of CGST Act, 2017

This is to inform that on scrutiny of returns filed by you for FY 2022-23, the following discrepancies have been observed:

1. Input Tax Credit (ITC) Reconciliation Difference:
   On comparing GSTR-3B with GSTR-2B, excess ITC of Rs. 7,860.24 has been claimed:
   - CGST: Rs. 2,387.74
   - SGST: Rs. 2,387.74
   - IGST: Rs. 3,036.80
   - CESS: Rs. 47.96

2. Credit Notes Verification:
   Credit notes amounting to Rs. 22,019.65 declared in GSTR-1 require invoice-level verification with books of accounts.

3. B2B Outward Supply Turnover:
   Total B2B Outward turnover of Rs. 2,17,68,368.43 declared in GSTR-1 requires verification against HSN summary and GSTR-9.

Required Action:
You are hereby directed to explain the reasons for aforesaid discrepancies or pay tax along with interest within 30 days of receipt of this notice.

Requested Documents:
1. GSTR-2A/2B vs GSTR-3B reconciliation statement
2. Purchase register and sales register
3. Copies of credit notes
4. ITC Ledger & Bank statements

Officer Signature:
Shri R. K. Gupta, DCST
Office of Ward 4, Gurugram, Haryana
"""
        with open(asmt10_file, "w", encoding="utf-8") as f:
            f.write(notice_content)


def seed_database_if_empty(db_instance):
    """Seed initial sample clients, cases, notices, discrepancies, documents, and replies."""
    clients = db_instance.get_all_clients()
    if clients:
        logging.info("Database already contains data. Skipping initial seeding.")
        return

    logging.info("Database is empty. Populating sample data...")

    # 1. Seed Clients
    c1_id = db_instance.add_client({
        'client_id': 'CLI-001',
        'client_name': 'Mahajan Life Sciences',
        'trade_name': 'Mahajan Pharma',
        'contact_person': 'Rajesh Mahajan',
        'email': 'info@mahajanlife.com',
        'phone': '9876543210',
        'gstin': '06AAAAA7182F1ZD',
        'state': 'Haryana',
        'address': 'Plot 42, Industrial Area Phase I, Gurugram, Haryana',
        'notes': 'Pharma manufacturing unit'
    })

    c2_id = db_instance.add_client({
        'client_id': 'CLI-002',
        'client_name': 'ABC Engineering Works',
        'trade_name': 'ABC Engg',
        'contact_person': 'Anil Kumar',
        'email': 'contact@abcengineering.in',
        'phone': '9811223344',
        'gstin': '07BBBBB1234C1ZA',
        'state': 'Delhi',
        'address': 'Mayapuri Industrial Area Phase II, New Delhi',
        'notes': 'Heavy machinery fabrication'
    })

    c3_id = db_instance.add_client({
        'client_id': 'CLI-003',
        'client_name': 'Sunrise Trading Co.',
        'trade_name': 'Sunrise Traders',
        'contact_person': 'Suresh Sharma',
        'email': 'sales@sunrisetrading.com',
        'phone': '9935001122',
        'gstin': '09CCCCC5678D1ZB',
        'state': 'Uttar Pradesh',
        'address': 'Transport Nagar, Kanpur, Uttar Pradesh',
        'notes': 'FMCG goods trader'
    })

    # 2. Seed Cases
    case1_id = db_instance.add_case({
        'case_id': 'CS-001',
        'case_number': 'CASE-2026-001',
        'client_id': c1_id,
        'gstin': '06AAAAA7182F1ZD',
        'financial_year': '2022-23',
        'notice_type': 'ASMT-10',
        'section': 'Section 61',
        'notice_date': '2026-08-10',
        'due_date': '2026-09-10',
        'jurisdiction': 'Ward 4, Gurugram',
        'officer': 'Shri R. K. Gupta (DCST)',
        'status': 'Open',
        'description': 'Scrutiny of returns for FY 2022-23 (ASMT-10)',
        'remarks': 'Priority case for ITC reconciliation'
    })

    case2_id = db_instance.add_case({
        'case_id': 'CS-002',
        'case_number': 'CASE-2026-002',
        'client_id': c2_id,
        'gstin': '07BBBBB1234C1ZA',
        'financial_year': '2023-24',
        'notice_type': 'DRC-01A',
        'section': 'Section 74',
        'notice_date': '2026-08-15',
        'due_date': '2026-09-15',
        'jurisdiction': 'Ward 12, Delhi',
        'officer': 'Smt. Anita Sharma (ACST)',
        'status': 'Open',
        'description': 'Pre-show cause notice for excess ITC claimed',
        'remarks': 'Awaiting supplier confirmation'
    })

    case3_id = db_instance.add_case({
        'case_id': 'CS-003',
        'case_number': 'CASE-2026-003',
        'client_id': c3_id,
        'gstin': '09CCCCC5678D1ZB',
        'financial_year': '2022-23',
        'notice_type': 'Audit',
        'section': 'Section 65',
        'notice_date': '2026-08-20',
        'due_date': '2026-09-20',
        'jurisdiction': 'Range 1, Kanpur',
        'officer': 'Shri V. P. Singh (JCST)',
        'status': 'Under Review',
        'description': 'Departmental GST Audit for FY 2022-23',
        'remarks': 'Submitted initial document set'
    })

    # 3. Seed Notice (ASMT-10 for Mahajan Life Sciences)
    notice1_id = db_instance.add_notice({
        'notice_id': 'NTC-001',
        'notice_number': 'ASMT10/2026/001',
        'notice_type': 'ASMT-10',
        'client_id': c1_id,
        'gstin': '06AAAAA7182F1ZD',
        'case_id': case1_id,
        'financial_year': '2022-23',
        'tax_period': 'Apr 2022 - Mar 2023',
        'section': 'Section 61',
        'notice_date': '2026-08-10',
        'due_date': '2026-09-10',
        'subject': 'Scrutiny Notice u/s 61 for FY 2022-23',
        'officer_observation': 'ITC difference of Rs. 7,860.24 observed between GSTR-3B & GSTR-2B. Credit notes of Rs. 22,019.65 and B2B turnover of Rs. 2,17,68,368.43 require verification.',
        'status': 'Reply Pending'
    })

    # 4. Seed Discrepancies for ASMT-10
    db_instance.add_discrepancy({
        'discrepancy_id': 'DISC-001',
        'notice_id': notice1_id,
        'point_number': 1,
        'description': 'ITC Difference GSTR-3B vs GSTR-2B',
        'officer_remarks': 'Claimed excess ITC in GSTR-3B compared to auto-populated GSTR-2B.',
        'amount': 7860.24,
        'cgst': 2387.74,
        'sgst': 2387.74,
        'igst': 3036.80,
        'cess': 47.96,
        'return_form': 'GSTR-3B / GSTR-2B',
        'section': 'Section 16(2)',
        'required_documents': 'GSTR-2A/2B Reconciliation & Tax Invoices',
        'status': 'Pending'
    })

    db_instance.add_discrepancy({
        'discrepancy_id': 'DISC-002',
        'notice_id': notice1_id,
        'point_number': 2,
        'description': 'Credit Notes Verification',
        'officer_remarks': 'Credit notes reported in GSTR-1 require verification against books.',
        'amount': 22019.65,
        'cgst': 6605.90,
        'sgst': 6605.90,
        'igst': 8807.85,
        'cess': 0.0,
        'return_form': 'GSTR-1 / Books',
        'section': 'Section 34',
        'required_documents': 'Credit Notes Copies & Corresponding Tax Invoices',
        'status': 'Pending'
    })

    db_instance.add_discrepancy({
        'discrepancy_id': 'DISC-003',
        'notice_id': notice1_id,
        'point_number': 3,
        'description': 'B2B Outward Supply Turnover Verification',
        'officer_remarks': 'Outward supply turnover verification against HSN summary.',
        'amount': 21768368.43,
        'cgst': 0.0,
        'sgst': 0.0,
        'igst': 0.0,
        'cess': 0.0,
        'return_form': 'GSTR-1 / GSTR-9',
        'section': 'Section 37',
        'required_documents': 'Sales Register, GSTR-1, GSTR-9 & Financial Audited Statements',
        'status': 'Pending'
    })

    # 5. Seed Documents
    doc_dir = os.path.join(os.path.dirname(db_instance.db_path), "documents")
    os.makedirs(doc_dir, exist_ok=True)
    sample_notice_path = os.path.join(doc_dir, "ASMT-10_Notice_Mahajan_Life_Sciences.txt")

    # Copy sample notice to data/documents/ if not exists
    sample_src = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sample_data", "sample_notices", "ASMT-10_Notice_Mahajan_Life_Sciences.txt")
    if os.path.exists(sample_src):
        with open(sample_src, "r", encoding="utf-8") as sf:
            content = sf.read()
        with open(sample_notice_path, "w", encoding="utf-8") as df:
            df.write(content)

    db_instance.add_document({
        'document_id': 'DOC-001',
        'client_id': c1_id,
        'gstin': '06AAAAA7182F1ZD',
        'case_id': case1_id,
        'notice_id': notice1_id,
        'document_type': 'Notice (ASMT-10)',
        'filename': 'ASMT-10_Notice_Mahajan_Life_Sciences.txt',
        'file_path': sample_notice_path,
        'processing_status': 'Completed',
        'remarks': 'Automatic processing completed successfully.',
        'extracted_text': 'FORM GST ASMT-10... Notice ASMT10/2026/001 for Mahajan Life Sciences GSTIN 06AAAAA7182F1ZD...',
        'extracted_metadata': '{"notice_number": "ASMT10/2026/001", "gstin": "06AAAAA7182F1ZD", "notice_type": "ASMT-10", "financial_year": "2022-23", "cgst": 2387.74, "sgst": 2387.74, "igst": 3036.8, "cess": 47.96}'
    })

    db_instance.add_document({
        'document_id': 'DOC-002',
        'client_id': c1_id,
        'gstin': '06AAAAA7182F1ZD',
        'case_id': case1_id,
        'notice_id': notice1_id,
        'document_type': 'Reconciliation',
        'filename': 'GSTR2B_vs_GSTR3B_Reconciliation_FY22-23.xlsx',
        'file_path': os.path.join(doc_dir, 'GSTR2B_vs_GSTR3B_Reconciliation_FY22-23.xlsx'),
        'processing_status': 'Completed',
        'remarks': 'Reconciliation statement loaded.',
        'extracted_text': 'GSTR-2B vs 3B Reconciliation - All differences explained.',
        'extracted_metadata': '{}'
    })

    db_instance.add_document({
        'document_id': 'DOC-003',
        'client_id': c2_id,
        'gstin': '07BBBBB1234C1ZA',
        'case_id': case2_id,
        'notice_id': None,
        'document_type': 'DRC-01A Notice',
        'filename': 'DRC-01A_ABC_Engineering.txt',
        'file_path': os.path.join(doc_dir, 'DRC-01A_ABC_Engineering.txt'),
        'processing_status': 'Completed',
        'remarks': 'Processed pre-SCN notice.',
        'extracted_text': 'FORM GST DRC-01A for ABC Engineering Works...',
        'extracted_metadata': '{"notice_type": "DRC-01A"}'
    })

    # 6. Seed Sample Historical Replies (2 records)
    from reply_generator import ReplyGenerator
    rg = ReplyGenerator(db_instance)
    
    # Client 1 reply draft
    c1_dict = db_instance.get_client_by_id(c1_id)
    case1_dict = db_instance.get_cases_by_client(c1_id)[0]
    disc_list = db_instance.get_discrepancies_by_notice(notice1_id)
    
    draft_c1 = rg.generate_reply_draft(c1_dict, case1_dict, {'notice_number': 'ASMT10/2026/001', 'notice_type': 'ASMT-10', 'section': 'Section 61', 'notice_date': '2026-08-10', 'financial_year': '2022-23'}, disc_list)

    db_instance.add_reply({
        'reply_id': 'RPLY-001',
        'client_id': c1_id,
        'gstin': '06AAAAA7182F1ZD',
        'case_id': case1_id,
        'notice_id': notice1_id,
        'financial_year': '2022-23',
        'reply_date': '2026-08-25',
        'reply_type': 'Point-wise Reply',
        'status': 'Draft',
        'draft_text': draft_c1
    })

    # Client 2 reply draft
    c2_dict = db_instance.get_client_by_id(c2_id)
    case2_dict = db_instance.get_cases_by_client(c2_id)[0]
    draft_c2 = rg.generate_reply_draft(c2_dict, case2_dict, {'notice_number': 'DRC01A/2026/002', 'notice_type': 'DRC-01A', 'section': 'Section 74', 'notice_date': '2026-08-15', 'financial_year': '2023-24'}, [])

    db_instance.add_reply({
        'reply_id': 'RPLY-002',
        'client_id': c2_id,
        'gstin': '07BBBBB1234C1ZA',
        'case_id': case2_id,
        'notice_id': None,
        'financial_year': '2023-24',
        'reply_date': '2026-08-28',
        'reply_type': 'Basic Professional Reply',
        'status': 'Draft',
        'draft_text': draft_c2
    })

    logging.info("Sample data seeding completed successfully.")
