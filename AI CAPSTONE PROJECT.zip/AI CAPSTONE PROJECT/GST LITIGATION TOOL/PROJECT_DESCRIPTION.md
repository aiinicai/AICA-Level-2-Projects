# PROJECT DESCRIPTION: GST Lit assist

## Executive Summary
**GST Lit assist** (GST Litigation Management & Reply Demo) is a lightweight, academic desktop application developed using Python 3.10+, Tkinter, SQLite, and openpyxl. The primary objective of GST Lit assist is to demonstrate how software automation and structured document processing can modernize GST litigation workflows for tax professionals, chartered accountants, and corporate legal teams.

---

## Technical Stack & Architecture

- **User Interface**: Python Tkinter with customized `ttk` styling for a clean, modern CA-oriented appearance.
- **Local Database**: SQLite 3 with foreign key constraints, normalized tables, and automated indexing.
- **Excel Import / Export**: `openpyxl` engine for parsing `.xlsx` workbooks, validating records, and exporting summary reports.
- **Document Processing**: `PyPDF2`, `python-docx`, and regex pattern matching engine for zero-click automatic metadata extraction.
- **Logging**: Python `logging` module writing detailed runtime traces to `logs/application.log`.
- **Database Backup**: Standard Python `shutil` file copy engine creating timestamped backups in `backups/`.

---

## Core Operational Modules

1. **Dashboard Module**: Real-time aggregate statistics (Clients, GSTINs, Cases, Open Cases, Pending Notices, Pending Replies, Documents, Completed Replies) and a Recent Litigation table.
2. **Client Management**: Complete CRUD operations, Excel batch import, duplicate GSTIN prevention, and auto-derivation of State names from 2-digit GST state codes.
3. **Case Management**: Tracks litigation lifecycle from initiation (`Open`, `Under Review`) to conclusion (`Reply Drafted`, `Reply Submitted`, `Closed`).
4. **Notice & Discrepancy Engine**: Links notices to cases and supports point-wise discrepancy tracking (CGST, SGST, IGST, CESS amounts, return forms, sections, required documents).
5. **Zero-Click Automatic Document Pipeline**: Seamlessly moves uploaded documents from `Uploaded` → `Reading` → `Extracting` → `Completed` without requiring manual extraction clicks.
6. **Point-wise Legal Reply Generator**: Assembles structured GST litigation replies combining taxpayer information, notice observations, quantified tax differences, document references, and legal prayers.
7. **GST Portal Demo Screen**: Demonstrates mock GST portal authentication, document discovery, and portal sync feeding into the document processing pipeline.
8. **Reports & Settings**: Dynamic tabular reports with CSV export and one-click database backup capabilities.
