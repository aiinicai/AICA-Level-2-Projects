"""
===============================================================
GST Lit assist
GST Litigation Management & Reply Demo
Main GUI Application (Tkinter)
===============================================================
"""

import os
import sys
import shutil
import logging
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

# Import local modules
from database import Database, LOG_FILE
from gst_utils import GST_STATE_CODES, get_state_from_gstin, validate_gstin_format
from doc_processor import DocumentProcessor
from reply_generator import ReplyGenerator
from excel_handler import ExcelHandler
from sample_data_generator import generate_sample_files, seed_database_if_empty


class GSTLitAssistApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("GST Lit assist - GST Litigation Management & Reply Demo")
        self.geometry("1280x800")
        self.minsize(1024, 700)

        # Base directories
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_dir = os.path.join(self.base_dir, "data")
        self.backup_dir = os.path.join(self.base_dir, "backups")
        self.sample_dir = os.path.join(self.base_dir, "sample_data")
        
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        os.makedirs(self.sample_dir, exist_ok=True)

        # Initialize sample files & database
        generate_sample_files(self.base_dir)
        self.db = Database()
        seed_database_if_empty(self.db)

        # Initialize processors
        self.doc_processor = DocumentProcessor(self.db)
        self.reply_generator = ReplyGenerator(self.db)
        self.excel_handler = ExcelHandler(self.db)

        # App Settings State
        self.auto_doc_processing = tk.BooleanVar(value=True)
        self.demo_portal_mode = tk.BooleanVar(value=True)

        # Setup Styling
        self.setup_styles()

        # Build UI Components
        self.create_header()
        self.create_tabs()

        # Refresh initial tab
        self.refresh_dashboard()

    def setup_styles(self):
        """Configure modern clean theme for Tkinter ttk controls."""
        style = ttk.Style(self)
        style.theme_use("clam")

        # Color Palette
        NAVY = "#1a365d"
        SLATE = "#2b6cb0"
        BG_LIGHT = "#f7fafc"
        TEXT_DARK = "#2d3748"
        ACCENT_BLUE = "#3182ce"
        WHITE = "#ffffff"

        self.configure(bg=BG_LIGHT)

        # Frame & Label Styles
        style.configure("TFrame", background=BG_LIGHT)
        style.configure("Header.TFrame", background=NAVY)
        style.configure("HeaderTitle.TLabel", background=NAVY, foreground=WHITE, font=("Segoe UI", 18, "bold"))
        style.configure("HeaderSubtitle.TLabel", background=NAVY, foreground="#e2e8f0", font=("Segoe UI", 11, "italic"))

        # Notebook / Tabs
        style.configure("TNotebook", background=BG_LIGHT, borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=[14, 8], background="#e2e8f0", foreground=TEXT_DARK)
        style.map("TNotebook.Tab", 
                  background=[("selected", NAVY)], 
                  foreground=[("selected", WHITE)])

        # Buttons
        style.configure("TButton", font=("Segoe UI", 9, "bold"), padding=6, background=SLATE, foreground=WHITE)
        style.map("TButton", background=[("active", ACCENT_BLUE)])

        style.configure("Accent.TButton", font=("Segoe UI", 9, "bold"), padding=6, background="#2b6cb0", foreground=WHITE)
        style.configure("Success.TButton", font=("Segoe UI", 9, "bold"), padding=6, background="#2f855a", foreground=WHITE)

        # Treeview / Data Tables
        style.configure("Treeview", font=("Segoe UI", 9), rowheight=26, background=WHITE, fieldbackground=WHITE)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#edf2f7", foreground=TEXT_DARK)
        style.map("Treeview", background=[("selected", "#bee3f8")], foreground=[("selected", TEXT_DARK)])

        # Cards / Metric Panels
        style.configure("Card.TFrame", background=WHITE, relief="solid", borderwidth=1)
        style.configure("CardTitle.TLabel", background=WHITE, foreground="#718096", font=("Segoe UI", 9, "bold"))
        style.configure("CardValue.TLabel", background=WHITE, foreground=NAVY, font=("Segoe UI", 20, "bold"))

    def create_header(self):
        """Top Application Header Branding."""
        header_frame = ttk.Frame(self, style="Header.TFrame", padding=(20, 12))
        header_frame.pack(fill="x", side="top")

        title_lbl = ttk.Label(header_frame, text="GST Lit assist", style="HeaderTitle.TLabel")
        title_lbl.pack(anchor="w")

        subtitle_lbl = ttk.Label(header_frame, text="GST Litigation Management & Reply Demo", style="HeaderSubtitle.TLabel")
        subtitle_lbl.pack(anchor="w")

    def create_tabs(self):
        """Build Main 10 Navigation Tabs."""
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Tab Frames
        self.tab_dashboard = ttk.Frame(self.notebook)
        self.tab_clients = ttk.Frame(self.notebook)
        self.tab_cases = ttk.Frame(self.notebook)
        self.tab_notices = ttk.Frame(self.notebook)
        self.tab_documents = ttk.Frame(self.notebook)
        self.tab_replies = ttk.Frame(self.notebook)
        self.tab_portal = ttk.Frame(self.notebook)
        self.tab_reports = ttk.Frame(self.notebook)
        self.tab_settings = ttk.Frame(self.notebook)
        self.tab_about = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_dashboard, text="1. Dashboard")
        self.notebook.add(self.tab_clients, text="2. Clients")
        self.notebook.add(self.tab_cases, text="3. Cases")
        self.notebook.add(self.tab_notices, text="4. Notices")
        self.notebook.add(self.tab_documents, text="5. Documents")
        self.notebook.add(self.tab_replies, text="6. Replies")
        self.notebook.add(self.tab_portal, text="7. GST Portal")
        self.notebook.add(self.tab_reports, text="8. Reports")
        self.notebook.add(self.tab_settings, text="9. Settings")
        self.notebook.add(self.tab_about, text="10. About")

        # Tab Switch Listener
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)

        # Setup Tab Contents
        self.setup_tab_dashboard()
        self.setup_tab_clients()
        self.setup_tab_cases()
        self.setup_tab_notices()
        self.setup_tab_documents()
        self.setup_tab_replies()
        self.setup_tab_portal()
        self.setup_tab_reports()
        self.setup_tab_settings()
        self.setup_tab_about()

    def on_tab_change(self, event):
        """Handle Tab Change Events to auto-refresh views."""
        selected_idx = self.notebook.index(self.notebook.select())
        if selected_idx == 0:
            self.refresh_dashboard()
        elif selected_idx == 1:
            self.refresh_clients_table()
        elif selected_idx == 2:
            self.refresh_cases_table()
        elif selected_idx == 3:
            self.refresh_notices_table()
        elif selected_idx == 4:
            self.refresh_documents_table()
        elif selected_idx == 5:
            self.refresh_replies_table()
        elif selected_idx == 6:
            self.refresh_portal_history()

    # =========================================================================
    # 1. DASHBOARD TAB
    # =========================================================================
    def setup_tab_dashboard(self):
        container = ttk.Frame(self.tab_dashboard, padding=15)
        container.pack(fill="both", expand=True)

        # Header Title
        title_lbl = ttk.Label(container, text="GST LIT ASSIST DASHBOARD", font=("Segoe UI", 14, "bold"))
        title_lbl.pack(anchor="w", pady=(0, 15))

        # Cards Container Frame
        cards_frame = ttk.Frame(container)
        cards_frame.pack(fill="x", pady=(0, 20))

        self.card_labels = {}
        cards_data = [
            ("total_clients", "Total Clients"),
            ("total_gstins", "Total GSTINs"),
            ("total_cases", "Total Cases"),
            ("open_cases", "Open Cases"),
            ("pending_notices", "Pending Notices"),
            ("pending_replies", "Pending Replies"),
            ("total_documents", "Documents"),
            ("completed_replies", "Completed Replies")
        ]

        # 2 rows of 4 cards
        for i, (key, title) in enumerate(cards_data):
            row, col = divmod(i, 4)
            card = ttk.Frame(cards_frame, style="Card.TFrame", padding=12)
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
            cards_frame.columnconfigure(col, weight=1)

            t_lbl = ttk.Label(card, text=title.upper(), style="CardTitle.TLabel")
            t_lbl.pack(anchor="w")

            v_lbl = ttk.Label(card, text="0", style="CardValue.TLabel")
            v_lbl.pack(anchor="w", pady=(5, 0))
            self.card_labels[key] = v_lbl

        # Recent Litigation Section
        recent_hdr = ttk.Label(container, text="Recent Litigation", font=("Segoe UI", 12, "bold"))
        recent_hdr.pack(anchor="w", pady=(10, 5))

        cols = ("Case No.", "Client", "GSTIN", "FY", "Notice Type", "Status")
        self.dash_tree = ttk.Treeview(container, columns=cols, show="headings", height=8)
        for c in cols:
            self.dash_tree.heading(c, text=c)
            self.dash_tree.column(c, width=150, anchor="center")
        self.dash_tree.column("Client", width=220, anchor="w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.dash_tree.yview)
        self.dash_tree.configure(yscrollcommand=scrollbar.set)
        
        self.dash_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def refresh_dashboard(self):
        stats = self.db.get_dashboard_stats()
        for k, v in stats.items():
            if k in self.card_labels:
                self.card_labels[k].config(text=str(v))

        # Refresh recent litigation tree
        for row in self.dash_tree.get_children():
            self.dash_tree.delete(row)

        cases = self.db.get_all_cases()[:10]  # top 10 recent
        for c in cases:
            self.dash_tree.insert("", "end", values=(
                c.get('case_number', ''),
                c.get('client_name', ''),
                c.get('gstin', ''),
                c.get('financial_year', ''),
                c.get('notice_type', ''),
                c.get('status', '')
            ))

    # =========================================================================
    # 2. CLIENTS TAB
    # =========================================================================
    def setup_tab_clients(self):
        container = ttk.Frame(self.tab_clients, padding=15)
        container.pack(fill="both", expand=True)

        # Toolbar
        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_frame, text="+ CREATE CLIENT", style="Success.TButton", command=self.open_create_client_dialog).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="IMPORT FROM EXCEL", style="Accent.TButton", command=self.import_clients_excel_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="VIEW DETAILS", command=self.view_client_details_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="DELETE", command=self.delete_client_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH", command=self.refresh_clients_table).pack(side="right", padx=5)

        # Table
        cols = ("ID", "Client ID", "Client Name", "Trade Name", "GSTIN", "State", "Contact Person", "Phone", "Email")
        self.clients_tree = ttk.Treeview(container, columns=cols, show="headings")
        self.clients_tree.heading("ID", text="ID")
        self.clients_tree.column("ID", width=40, anchor="center")
        
        for c in cols[1:]:
            self.clients_tree.heading(c, text=c)
            self.clients_tree.column(c, width=130, anchor="center" if c in ("GSTIN", "State", "Phone") else "w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.clients_tree.yview)
        self.clients_tree.configure(yscrollcommand=scrollbar.set)

        self.clients_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.clients_tree.bind("<Double-1>", lambda e: self.view_client_details_action())

    def refresh_clients_table(self):
        for row in self.clients_tree.get_children():
            self.clients_tree.delete(row)

        clients = self.db.get_all_clients()
        for c in clients:
            self.clients_tree.insert("", "end", values=(
                c['id'],
                c.get('client_id', ''),
                c.get('client_name', ''),
                c.get('trade_name', ''),
                c.get('gstin', ''),
                c.get('state', ''),
                c.get('contact_person', ''),
                c.get('phone', ''),
                c.get('email', '')
            ))

    def open_create_client_dialog(self, edit_client_dict: dict = None):
        """Dialog to create or edit client with automatic GSTIN state lookup."""
        dialog = tk.Toplevel(self)
        dialog.title("Edit Client" if edit_client_dict else "Create New Client")
        dialog.geometry("520x620")
        dialog.resizable(False, False)
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)

        fields = [
            ("Client ID *", "client_id"),
            ("Client Name *", "client_name"),
            ("Trade Name", "trade_name"),
            ("GSTIN *", "gstin"),
            ("State (Auto-Derived)", "state"),
            ("Contact Person", "contact_person"),
            ("Email", "email"),
            ("Phone", "phone"),
            ("Address", "address"),
            ("Notes", "notes")
        ]

        entries = {}
        for idx, (label_text, field_key) in enumerate(fields):
            lbl = ttk.Label(frame, text=label_text, font=("Segoe UI", 9, "bold" if "*" in label_text else "normal"))
            lbl.grid(row=idx, column=0, sticky="w", pady=4)

            entry = ttk.Entry(frame, width=38)
            entry.grid(row=idx, column=1, sticky="w", pady=4)
            entries[field_key] = entry

        # Auto-generate Client ID if creating new
        if not edit_client_dict:
            count = len(self.db.get_all_clients()) + 101
            entries['client_id'].insert(0, f"CLI-{count:03d}")
        else:
            for k, entry in entries.items():
                entry.insert(0, edit_client_dict.get(k, ''))

        # Live State Lookup Trace on GSTIN entry
        def on_gstin_change(*args):
            gstin_val = entries['gstin'].get().strip()
            if len(gstin_val) >= 2:
                state_derived = get_state_from_gstin(gstin_val)
                entries['state'].delete(0, tk.END)
                entries['state'].insert(0, state_derived)

        entries['gstin'].bind("<KeyRelease>", on_gstin_change)

        def save_client():
            c_id = entries['client_id'].get().strip()
            c_name = entries['client_name'].get().strip()
            gstin = entries['gstin'].get().strip().upper()
            state = entries['state'].get().strip()

            if not c_id or not c_name or not gstin:
                messagebox.showerror("Validation Error", "Client ID, Client Name, and GSTIN are required fields.", parent=dialog)
                return

            valid, msg = validate_gstin_format(gstin)
            if not valid:
                if not messagebox.askyesno("GSTIN Format Warning", f"{msg}\nDo you still wish to proceed?", parent=dialog):
                    return

            client_data = {
                'client_id': c_id,
                'client_name': c_name,
                'trade_name': entries['trade_name'].get().strip(),
                'contact_person': entries['contact_person'].get().strip(),
                'email': entries['email'].get().strip(),
                'phone': entries['phone'].get().strip(),
                'gstin': gstin,
                'state': state if state else get_state_from_gstin(gstin),
                'address': entries['address'].get().strip(),
                'notes': entries['notes'].get().strip()
            }

            try:
                self.db.add_client(client_data)
                messagebox.showinfo("Success", f"Client '{c_name}' created successfully!", parent=dialog)
                dialog.destroy()
                self.refresh_clients_table()
                self.refresh_dashboard()
            except Exception as e:
                messagebox.showerror("Error", f"Could not save client: {str(e)}", parent=dialog)

        save_btn = ttk.Button(frame, text="SAVE CLIENT", style="Success.TButton", command=save_client)
        save_btn.grid(row=len(fields), column=0, columnspan=2, pady=15)

    def import_clients_excel_action(self):
        """Action for IMPORT FROM EXCEL button."""
        sample_excel = os.path.join(self.sample_dir, "sample_clients.xlsx")
        file_path = filedialog.askopenfilename(
            title="Select Client Excel File",
            initialdir=self.sample_dir if os.path.exists(sample_excel) else self.base_dir,
            filetypes=[("Excel Files", "*.xlsx *.xls")]
        )
        if not file_path:
            return

        res = self.excel_handler.import_clients_from_excel(file_path)

        msg_body = f"""EXCEL IMPORT RESULT

Records found: {res['total_found']}
Imported: {res['imported']}
Duplicates Skipped: {res['duplicates']}
Errors: {res['errors']}

--- DETAILS ---
""" + "\n".join(res['messages'][:8])

        messagebox.showinfo("Excel Import Report", msg_body)
        self.refresh_clients_table()
        self.refresh_dashboard()

    def view_client_details_action(self):
        """Client Detail Window showing comprehensive client tabs."""
        selected = self.clients_tree.selection()
        if not selected:
            messagebox.showwarning("Select Client", "Please select a client from the table first.")
            return

        item = self.clients_tree.item(selected[0])
        db_id = item['values'][0]
        client = self.db.get_client_by_id(db_id)

        if not client:
            return

        dialog = tk.Toplevel(self)
        dialog.title(f"Client Profile - {client['client_name']}")
        dialog.geometry("900x650")

        # Top Info Card
        info_frame = ttk.Frame(dialog, style="Card.TFrame", padding=15)
        info_frame.pack(fill="x", padx=15, pady=10)

        t_lbl = ttk.Label(info_frame, text=f"CLIENT INFORMATION: {client['client_name'].upper()}", font=("Segoe UI", 12, "bold"), background="#ffffff")
        t_lbl.pack(anchor="w")

        sub_info = f"GSTIN: {client['gstin']}  |  State: {client['state']}  |  Contact: {client.get('contact_person','N/A')}  |  Phone: {client.get('phone','N/A')}  |  Email: {client.get('email','N/A')}"
        d_lbl = ttk.Label(info_frame, text=sub_info, font=("Segoe UI", 9), background="#ffffff", foreground="#4a5568")
        d_lbl.pack(anchor="w", pady=(4, 0))

        # Client Detail Sub-Tabs
        nb = ttk.Notebook(dialog)
        nb.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        tab_overview = ttk.Frame(nb, padding=10)
        tab_cases = ttk.Frame(nb, padding=10)
        tab_notices = ttk.Frame(nb, padding=10)
        tab_docs = ttk.Frame(nb, padding=10)
        tab_replies = ttk.Frame(nb, padding=10)

        nb.add(tab_overview, text="Overview")
        nb.add(tab_cases, text="Cases")
        nb.add(tab_notices, text="Notices")
        nb.add(tab_docs, text="Documents")
        nb.add(tab_replies, text="Replies")

        # Overview Tab
        ov_txt = f"""Client ID     : {client['client_id']}
Client Name   : {client['client_name']}
Trade Name    : {client['trade_name']}
GSTIN         : {client['gstin']}
State         : {client['state']}
Contact Person: {client['contact_person']}
Email         : {client['email']}
Phone         : {client['phone']}
Address       : {client['address']}
Notes         : {client['notes']}
Created At    : {client['created_at']}
"""
        lbl_ov = ttk.Label(tab_overview, text=ov_txt, font=("Consolas", 10), justify="left")
        lbl_ov.pack(anchor="nw", pady=10)

        # Client Cases Tab
        cases = self.db.get_cases_by_client(db_id)
        c_tree = ttk.Treeview(tab_cases, columns=("Case No", "FY", "Notice Type", "Section", "Status"), show="headings")
        for col in ("Case No", "FY", "Notice Type", "Section", "Status"):
            c_tree.heading(col, text=col)
            c_tree.column(col, width=120, anchor="center")
        c_tree.pack(fill="both", expand=True)

        for c in cases:
            c_tree.insert("", "end", values=(c['case_number'], c['financial_year'], c['notice_type'], c['section'], c['status']))

    def delete_client_action(self):
        selected = self.clients_tree.selection()
        if not selected:
            messagebox.showwarning("Select Client", "Please select a client to delete.")
            return

        item = self.clients_tree.item(selected[0])
        db_id = item['values'][0]
        c_name = item['values'][2]

        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete client '{c_name}'?\nThis will also delete associated cases, notices, and replies."):
            self.db.delete_client(db_id)
            self.refresh_clients_table()
            self.refresh_dashboard()

    # =========================================================================
    # 3. CASES TAB
    # =========================================================================
    def setup_tab_cases(self):
        container = ttk.Frame(self.tab_cases, padding=15)
        container.pack(fill="both", expand=True)

        # Toolbar
        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_frame, text="+ CREATE CASE", style="Success.TButton", command=self.open_create_case_dialog).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH", command=self.refresh_cases_table).pack(side="right", padx=5)

        # Table
        cols = ("ID", "Case ID", "Case Number", "Client Name", "GSTIN", "FY", "Notice Type", "Section", "Officer", "Status")
        self.cases_tree = ttk.Treeview(container, columns=cols, show="headings")
        self.cases_tree.heading("ID", text="ID")
        self.cases_tree.column("ID", width=40, anchor="center")

        for c in cols[1:]:
            self.cases_tree.heading(c, text=c)
            self.cases_tree.column(c, width=130, anchor="center" if c in ("GSTIN", "FY", "Notice Type", "Status") else "w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.cases_tree.yview)
        self.cases_tree.configure(yscrollcommand=scrollbar.set)

        self.cases_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def refresh_cases_table(self):
        for row in self.cases_tree.get_children():
            self.cases_tree.delete(row)

        cases = self.db.get_all_cases()
        for c in cases:
            self.cases_tree.insert("", "end", values=(
                c['id'],
                c.get('case_id', ''),
                c.get('case_number', ''),
                c.get('client_name', ''),
                c.get('gstin', ''),
                c.get('financial_year', ''),
                c.get('notice_type', ''),
                c.get('section', ''),
                c.get('officer', ''),
                c.get('status', '')
            ))

    def open_create_case_dialog(self):
        """Create new litigation case dialog."""
        clients = self.db.get_all_clients()
        if not clients:
            messagebox.showwarning("No Clients", "Please create or import a client before creating a case.")
            return

        dialog = tk.Toplevel(self)
        dialog.title("Create New Litigation Case")
        dialog.geometry("540x650")
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)

        # Client dropdown selection
        ttk.Label(frame, text="Select Client *", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", pady=4)
        client_map = {f"{c['client_name']} ({c['gstin']})": c for c in clients}
        client_cb = ttk.Combobox(frame, values=list(client_map.keys()), width=36, state="readonly")
        client_cb.grid(row=0, column=1, sticky="w", pady=4)
        client_cb.current(0)

        fields = [
            ("Case ID *", "case_id"),
            ("Case Number *", "case_number"),
            ("Financial Year *", "financial_year"),
            ("Notice Type", "notice_type"),
            ("Section", "section"),
            ("Notice Date (YYYY-MM-DD)", "notice_date"),
            ("Due Date (YYYY-MM-DD)", "due_date"),
            ("Jurisdiction", "jurisdiction"),
            ("Officer Name", "officer"),
            ("Description", "description")
        ]

        entries = {}
        for idx, (lbl_txt, key) in enumerate(fields, start=1):
            ttk.Label(frame, text=lbl_txt, font=("Segoe UI", 9, "bold" if "*" in lbl_txt else "normal")).grid(row=idx, column=0, sticky="w", pady=4)
            ent = ttk.Entry(frame, width=38)
            ent.grid(row=idx, column=1, sticky="w", pady=4)
            entries[key] = ent

        case_count = len(self.db.get_all_cases()) + 1
        entries['case_id'].insert(0, f"CS-{case_count:03d}")
        entries['case_number'].insert(0, f"CASE-2026-{case_count:03d}")
        entries['financial_year'].insert(0, "2022-23")
        entries['notice_type'].insert(0, "ASMT-10")
        entries['section'].insert(0, "Section 61")

        def save_case():
            c_key = client_cb.get()
            selected_client = client_map[c_key]
            
            case_id = entries['case_id'].get().strip()
            case_num = entries['case_number'].get().strip()
            fy = entries['financial_year'].get().strip()

            if not case_id or not case_num or not fy:
                messagebox.showerror("Validation Error", "Case ID, Case Number, and Financial Year are required.", parent=dialog)
                return

            case_data = {
                'case_id': case_id,
                'case_number': case_num,
                'client_id': selected_client['id'],
                'gstin': selected_client['gstin'],
                'financial_year': fy,
                'notice_type': entries['notice_type'].get().strip(),
                'section': entries['section'].get().strip(),
                'notice_date': entries['notice_date'].get().strip(),
                'due_date': entries['due_date'].get().strip(),
                'jurisdiction': entries['jurisdiction'].get().strip(),
                'officer': entries['officer'].get().strip(),
                'status': 'Open',
                'description': entries['description'].get().strip()
            }

            try:
                self.db.add_case(case_data)
                messagebox.showinfo("Success", f"Case '{case_num}' created successfully!", parent=dialog)
                dialog.destroy()
                self.refresh_cases_table()
                self.refresh_dashboard()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save case: {str(e)}", parent=dialog)

        ttk.Button(frame, text="SAVE CASE", style="Success.TButton", command=save_case).grid(row=len(fields)+1, column=0, columnspan=2, pady=15)

    # =========================================================================
    # 4. NOTICES TAB
    # =========================================================================
    def setup_tab_notices(self):
        container = ttk.Frame(self.tab_notices, padding=15)
        container.pack(fill="both", expand=True)

        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_frame, text="+ ADD NOTICE", style="Success.TButton", command=self.open_add_notice_dialog).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="VIEW DISCREPANCIES", command=self.view_notice_discrepancies_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH", command=self.refresh_notices_table).pack(side="right", padx=5)

        cols = ("ID", "Notice ID", "Notice Number", "Notice Type", "Client", "GSTIN", "Case", "FY", "Section", "Notice Date", "Due Date", "Status")
        self.notices_tree = ttk.Treeview(container, columns=cols, show="headings")
        self.notices_tree.heading("ID", text="ID")
        self.notices_tree.column("ID", width=40, anchor="center")

        for c in cols[1:]:
            self.notices_tree.heading(c, text=c)
            self.notices_tree.column(c, width=120, anchor="center" if c in ("Notice Type", "GSTIN", "FY", "Notice Date", "Due Date", "Status") else "w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.notices_tree.yview)
        self.notices_tree.configure(yscrollcommand=scrollbar.set)

        self.notices_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.notices_tree.bind("<Double-1>", lambda e: self.view_notice_discrepancies_action())

    def refresh_notices_table(self):
        for row in self.notices_tree.get_children():
            self.notices_tree.delete(row)

        notices = self.db.get_all_notices()
        for n in notices:
            self.notices_tree.insert("", "end", values=(
                n['id'],
                n.get('notice_id', ''),
                n.get('notice_number', ''),
                n.get('notice_type', ''),
                n.get('client_name', ''),
                n.get('gstin', ''),
                n.get('case_number', ''),
                n.get('financial_year', ''),
                n.get('section', ''),
                n.get('notice_date', ''),
                n.get('due_date', ''),
                n.get('status', '')
            ))

    def open_add_notice_dialog(self):
        cases = self.db.get_all_cases()
        if not cases:
            messagebox.showwarning("No Cases", "Please create a case before adding a notice.")
            return

        dialog = tk.Toplevel(self)
        dialog.title("Add New GST Notice")
        dialog.geometry("540x650")
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Select Linked Case *", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", pady=4)
        case_map = {f"{c['case_number']} - {c['client_name']} ({c['notice_type']})": c for c in cases}
        case_cb = ttk.Combobox(frame, values=list(case_map.keys()), width=36, state="readonly")
        case_cb.grid(row=0, column=1, sticky="w", pady=4)
        case_cb.current(0)

        fields = [
            ("Notice ID *", "notice_id"),
            ("Notice Number *", "notice_number"),
            ("Notice Type", "notice_type"),
            ("Tax Period", "tax_period"),
            ("Notice Date", "notice_date"),
            ("Due Date", "due_date"),
            ("Subject", "subject"),
            ("Officer Observation", "officer_observation")
        ]

        entries = {}
        for idx, (lbl_txt, key) in enumerate(fields, start=1):
            ttk.Label(frame, text=lbl_txt, font=("Segoe UI", 9, "bold" if "*" in lbl_txt else "normal")).grid(row=idx, column=0, sticky="w", pady=4)
            ent = ttk.Entry(frame, width=38)
            ent.grid(row=idx, column=1, sticky="w", pady=4)
            entries[key] = ent

        ntc_count = len(self.db.get_all_notices()) + 1
        entries['notice_id'].insert(0, f"NTC-{ntc_count:03d}")
        entries['notice_number'].insert(0, f"ASMT10/2026/{ntc_count:03d}")
        entries['notice_type'].insert(0, "ASMT-10")

        def save_notice():
            c_obj = case_map[case_cb.get()]
            n_id = entries['notice_id'].get().strip()
            n_num = entries['notice_number'].get().strip()

            if not n_id or not n_num:
                messagebox.showerror("Validation Error", "Notice ID and Notice Number are required.", parent=dialog)
                return

            n_data = {
                'notice_id': n_id,
                'notice_number': n_num,
                'notice_type': entries['notice_type'].get().strip(),
                'client_id': c_obj['client_id'],
                'gstin': c_obj['gstin'],
                'case_id': c_obj['id'],
                'financial_year': c_obj['financial_year'],
                'tax_period': entries['tax_period'].get().strip(),
                'section': c_obj['section'],
                'notice_date': entries['notice_date'].get().strip(),
                'due_date': entries['due_date'].get().strip(),
                'subject': entries['subject'].get().strip(),
                'officer_observation': entries['officer_observation'].get().strip(),
                'status': 'Reply Pending'
            }

            try:
                self.db.add_notice(n_data)
                messagebox.showinfo("Success", f"Notice '{n_num}' added successfully!", parent=dialog)
                dialog.destroy()
                self.refresh_notices_table()
                self.refresh_dashboard()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add notice: {str(e)}", parent=dialog)

        ttk.Button(frame, text="SAVE NOTICE", style="Success.TButton", command=save_notice).grid(row=len(fields)+1, column=0, columnspan=2, pady=15)

    def view_notice_discrepancies_action(self):
        """View and add point-wise discrepancy items to a notice."""
        selected = self.notices_tree.selection()
        if not selected:
            messagebox.showwarning("Select Notice", "Please select a notice to view discrepancies.")
            return

        item = self.notices_tree.item(selected[0])
        notice_db_id = item['values'][0]
        n_num = item['values'][2]

        dialog = tk.Toplevel(self)
        dialog.title(f"Discrepancies for Notice: {n_num}")
        dialog.geometry("900x550")

        frame = ttk.Frame(dialog, padding=15)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text=f"NOTICE DISCREPANCY POINTS: {n_num}", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 10))

        cols = ("Pt", "Description", "CGST (Rs.)", "SGST (Rs.)", "IGST (Rs.)", "CESS (Rs.)", "Total Amount (Rs.)", "Return/Form", "Section")
        disc_tree = ttk.Treeview(frame, columns=cols, show="headings", height=10)
        disc_tree.heading("Pt", text="Pt #")
        disc_tree.column("Pt", width=40, anchor="center")
        for c in cols[1:]:
            disc_tree.heading(c, text=c)
            disc_tree.column(c, width=100, anchor="e" if "Rs." in c else "w")

        disc_tree.pack(fill="both", expand=True, pady=(0, 10))

        def load_discs():
            for r in disc_tree.get_children(): disc_tree.delete(r)
            discs = self.db.get_discrepancies_by_notice(notice_db_id)
            for d in discs:
                cgst = d.get('cgst', 0.0)
                sgst = d.get('sgst', 0.0)
                igst = d.get('igst', 0.0)
                cess = d.get('cess', 0.0)
                tot = d.get('amount') if d.get('amount') else (cgst + sgst + igst + cess)
                disc_tree.insert("", "end", values=(
                    d.get('point_number', 1),
                    d.get('description', ''),
                    f"{cgst:,.2f}",
                    f"{sgst:,.2f}",
                    f"{igst:,.2f}",
                    f"{cess:,.2f}",
                    f"{tot:,.2f}",
                    d.get('return_form', ''),
                    d.get('section', '')
                ))

        load_discs()

        # Add Discrepancy Button
        def add_disc_dialog():
            d_win = tk.Toplevel(dialog)
            d_win.title("Add Discrepancy Point")
            d_win.geometry("450x480")
            d_win.grab_set()

            df = ttk.Frame(d_win, padding=15)
            df.pack(fill="both", expand=True)

            existing_discs = self.db.get_discrepancies_by_notice(notice_db_id)
            pt_next = len(existing_discs) + 1

            fields = [
                ("Point Number", "pt_num", str(pt_next)),
                ("Description", "desc", "ITC Reconciliation Difference"),
                ("Officer Remarks", "remarks", "Excess ITC claimed in GSTR-3B vs 2B"),
                ("CGST Amount (Rs)", "cgst", "0.00"),
                ("SGST Amount (Rs)", "sgst", "0.00"),
                ("IGST Amount (Rs)", "igst", "0.00"),
                ("CESS Amount (Rs)", "cess", "0.00"),
                ("Return / Form", "return_form", "GSTR-3B / GSTR-2B"),
                ("Section", "section", "Section 16(2)")
            ]

            d_entries = {}
            for idx, (label_txt, key, def_val) in enumerate(fields):
                ttk.Label(df, text=label_txt, font=("Segoe UI", 9)).grid(row=idx, column=0, sticky="w", pady=3)
                e = ttk.Entry(df, width=30)
                e.insert(0, def_val)
                e.grid(row=idx, column=1, sticky="w", pady=3)
                d_entries[key] = e

            def save_d():
                try:
                    cgst_v = float(d_entries['cgst'].get().strip() or 0.0)
                    sgst_v = float(d_entries['sgst'].get().strip() or 0.0)
                    igst_v = float(d_entries['igst'].get().strip() or 0.0)
                    cess_v = float(d_entries['cess'].get().strip() or 0.0)
                    pt_num = int(d_entries['pt_num'].get().strip() or pt_next)

                    disc_data = {
                        'discrepancy_id': f"DISC-{notice_db_id}-{pt_num:02d}",
                        'notice_id': notice_db_id,
                        'point_number': pt_num,
                        'description': d_entries['desc'].get().strip(),
                        'officer_remarks': d_entries['remarks'].get().strip(),
                        'amount': cgst_v + sgst_v + igst_v + cess_v,
                        'cgst': cgst_v,
                        'sgst': sgst_v,
                        'igst': igst_v,
                        'cess': cess_v,
                        'return_form': d_entries['return_form'].get().strip(),
                        'section': d_entries['section'].get().strip(),
                        'required_documents': 'Reconciliation Statement & Invoices',
                        'status': 'Pending'
                    }
                    self.db.add_discrepancy(disc_data)
                    d_win.destroy()
                    load_discs()
                except Exception as ex:
                    messagebox.showerror("Error", f"Invalid values: {str(ex)}", parent=d_win)

            ttk.Button(df, text="+ ADD POINT", style="Success.TButton", command=save_d).grid(row=len(fields), column=0, columnspan=2, pady=10)

        ttk.Button(frame, text="+ ADD DISCREPANCY POINT", style="Accent.TButton", command=add_disc_dialog).pack(anchor="e")

    # =========================================================================
    # 5. DOCUMENTS TAB - AUTOMATIC ZERO-CLICK PROCESSING PIPELINE
    # =========================================================================
    def setup_tab_documents(self):
        container = ttk.Frame(self.tab_documents, padding=15)
        container.pack(fill="both", expand=True)

        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_frame, text="UPLOAD DOCUMENT", style="Success.TButton", command=self.upload_document_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="VIEW DOCUMENT", command=self.view_document_text_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH", command=self.refresh_documents_table).pack(side="right", padx=5)

        cols = ("ID", "Doc ID", "Client Name", "GSTIN", "Document Type", "Filename", "Upload Date", "Processing Status", "Remarks")
        self.docs_tree = ttk.Treeview(container, columns=cols, show="headings")
        self.docs_tree.heading("ID", text="ID")
        self.docs_tree.column("ID", width=40, anchor="center")

        for c in cols[1:]:
            self.docs_tree.heading(c, text=c)
            self.docs_tree.column(c, width=130, anchor="center" if c in ("Upload Date", "Processing Status") else "w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.docs_tree.yview)
        self.docs_tree.configure(yscrollcommand=scrollbar.set)

        self.docs_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.docs_tree.bind("<Double-1>", lambda e: self.view_document_text_action())

    def refresh_documents_table(self):
        for row in self.docs_tree.get_children():
            self.docs_tree.delete(row)

        docs = self.db.get_all_documents()
        for d in docs:
            self.docs_tree.insert("", "end", values=(
                d['id'],
                d.get('document_id', ''),
                d.get('client_name', ''),
                d.get('gstin', ''),
                d.get('document_type', ''),
                d.get('filename', ''),
                d.get('upload_date', ''),
                d.get('processing_status', ''),
                d.get('remarks', '')
            ))

    def upload_document_action(self):
        """
        Upload document action.
        EXECUTES ZERO-CLICK AUTOMATIC PROCESSING PIPELINE:
        SELECT DOCUMENT -> UPLOAD -> AUTOMATIC PROCESSING -> READ -> EXTRACT -> STORE RESULT -> COMPLETED
        No separate 'CLICK EXTRACT' button required!
        """
        file_path = filedialog.askopenfilename(
            title="Select Notice / Document to Upload",
            initialdir=self.sample_dir,
            filetypes=[("All Supported Files", "*.pdf *.docx *.txt *.xlsx *.csv"), ("PDF Files", "*.pdf"), ("Word Documents", "*.docx"), ("Text Files", "*.txt")]
        )
        if not file_path:
            return

        filename = os.path.basename(file_path)
        dest_dir = os.path.join(self.data_dir, "documents")
        os.makedirs(dest_dir, exist_ok=True)
        dest_path = os.path.join(dest_dir, filename)

        try:
            shutil.copy(file_path, dest_path)
        except Exception as e:
            dest_path = file_path

        clients = self.db.get_all_clients()
        client_id = clients[0]['id'] if clients else None
        gstin = clients[0]['gstin'] if clients else ""

        doc_count = len(self.db.get_all_documents()) + 1
        doc_data = {
            'document_id': f"DOC-{doc_count:03d}",
            'client_id': client_id,
            'gstin': gstin,
            'case_id': None,
            'notice_id': None,
            'document_type': 'Notice Document',
            'filename': filename,
            'file_path': dest_path,
            'processing_status': 'Uploaded',
            'remarks': 'Document uploaded.'
        }

        # Step 1: Add to DB (Status: Uploaded)
        doc_db_id = self.db.add_document(doc_data)
        self.refresh_documents_table()

        # Step 2: ZERO-CLICK AUTOMATIC PROCESSING PIPELINE
        if self.auto_doc_processing.get():
            self.doc_processor.process_document_auto(doc_db_id)
            self.refresh_documents_table()

            # Show automatic status transition summary
            doc_rec = [d for d in self.db.get_all_documents() if d['id'] == doc_db_id][0]
            status = doc_rec.get('processing_status')
            
            messagebox.showinfo(
                "Automatic Processing Completed",
                f"Document: {filename}\n\n"
                f"✓ Uploaded\n"
                f"✓ Reading\n"
                f"✓ Extracting\n"
                f"✓ Metadata identified\n"
                f"✓ Processing status: {status}\n\n"
                f"Status: READY FOR REVIEW"
            )
        else:
            messagebox.showinfo("Uploaded", f"Document '{filename}' uploaded successfully (Auto-processing OFF).")

        self.refresh_dashboard()

    def view_document_text_action(self):
        selected = self.docs_tree.selection()
        if not selected:
            messagebox.showwarning("Select Document", "Please select a document from the table.")
            return

        item = self.docs_tree.item(selected[0])
        doc_id = item['values'][0]

        docs = self.db.get_all_documents()
        doc = [d for d in docs if d['id'] == doc_id][0]

        dialog = tk.Toplevel(self)
        dialog.title(f"Document Intelligence Viewer: {doc['filename']}")
        dialog.geometry("750x600")

        frame = ttk.Frame(dialog, padding=15)
        frame.pack(fill="both", expand=True)

        info_txt = f"File: {doc['filename']}  |  Status: {doc['processing_status']}  |  Type: {doc['document_type']}"
        ttk.Label(frame, text=info_txt, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 10))

        nb = ttk.Notebook(frame)
        nb.pack(fill="both", expand=True)

        tab_text = ttk.Frame(nb, padding=10)
        tab_meta = ttk.Frame(nb, padding=10)

        nb.add(tab_text, text="Extracted Text")
        nb.add(tab_meta, text="Extracted Metadata")

        txt_widget = tk.Text(tab_text, font=("Consolas", 9), wrap="word")
        txt_widget.insert("1.0", doc.get('extracted_text', 'No text extracted.'))
        txt_widget.pack(fill="both", expand=True)

        meta_widget = tk.Text(tab_meta, font=("Consolas", 9), wrap="word")
        meta_widget.insert("1.0", doc.get('extracted_metadata', '{}'))
        meta_widget.pack(fill="both", expand=True)

    # =========================================================================
    # 6. REPLIES TAB
    # =========================================================================
    def setup_tab_replies(self):
        container = ttk.Frame(self.tab_replies, padding=15)
        container.pack(fill="both", expand=True)

        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_frame, text="+ CREATE REPLY", style="Success.TButton", command=self.open_create_reply_dialog).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="VIEW / EDIT DRAFT", style="Accent.TButton", command=self.view_edit_reply_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH", command=self.refresh_replies_table).pack(side="right", padx=5)

        cols = ("ID", "Reply ID", "Client Name", "GSTIN", "Notice Number", "FY", "Reply Type", "Reply Date", "Status")
        self.replies_tree = ttk.Treeview(container, columns=cols, show="headings")
        self.replies_tree.heading("ID", text="ID")
        self.replies_tree.column("ID", width=40, anchor="center")

        for c in cols[1:]:
            self.replies_tree.heading(c, text=c)
            self.replies_tree.column(c, width=130, anchor="center" if c in ("FY", "Reply Date", "Status") else "w")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.replies_tree.yview)
        self.replies_tree.configure(yscrollcommand=scrollbar.set)

        self.replies_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.replies_tree.bind("<Double-1>", lambda e: self.view_edit_reply_action())

    def refresh_replies_table(self):
        for row in self.replies_tree.get_children():
            self.replies_tree.delete(row)

        replies = self.db.get_all_replies()
        for r in replies:
            self.replies_tree.insert("", "end", values=(
                r['id'],
                r.get('reply_id', ''),
                r.get('client_name', ''),
                r.get('gstin', ''),
                r.get('notice_number', ''),
                r.get('financial_year', ''),
                r.get('reply_type', ''),
                r.get('reply_date', ''),
                r.get('status', '')
            ))

    def open_create_reply_dialog(self):
        """Workflow: Select Client -> Select GSTIN -> Select Case -> Select Notice -> Select Discrepancies -> Select Reply Type -> Create Draft."""
        clients = self.db.get_all_clients()
        if not clients:
            messagebox.showwarning("No Clients", "Please create a client first.")
            return

        dialog = tk.Toplevel(self)
        dialog.title("Create GST Litigation Reply Draft")
        dialog.geometry("560x520")
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)

        # 1. Select Client
        ttk.Label(frame, text="1. Select Client *", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", pady=6)
        client_map = {f"{c['client_name']} ({c['gstin']})": c for c in clients}
        client_cb = ttk.Combobox(frame, values=list(client_map.keys()), width=42, state="readonly")
        client_cb.grid(row=0, column=1, sticky="w", pady=6)
        client_cb.current(0)

        # 2. Select Case
        ttk.Label(frame, text="2. Select Case *", font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky="w", pady=6)
        cases = self.db.get_all_cases()
        case_map = {f"{cs['case_number']} - FY {cs['financial_year']} ({cs['notice_type']})": cs for cs in cases}
        case_cb = ttk.Combobox(frame, values=list(case_map.keys()) if case_map else ["No Cases Available"], width=42, state="readonly")
        case_cb.grid(row=1, column=1, sticky="w", pady=6)
        if case_map: case_cb.current(0)

        # 3. Select Notice
        ttk.Label(frame, text="3. Select Notice *", font=("Segoe UI", 9, "bold")).grid(row=2, column=0, sticky="w", pady=6)
        notices = self.db.get_all_notices()
        notice_map = {f"{n['notice_number']} ({n['notice_type']})": n for n in notices}
        notice_cb = ttk.Combobox(frame, values=list(notice_map.keys()) if notice_map else ["No Notices Available"], width=42, state="readonly")
        notice_cb.grid(row=2, column=1, sticky="w", pady=6)
        if notice_map: notice_cb.current(0)

        # 4. Reply Type
        ttk.Label(frame, text="4. Select Reply Type *", font=("Segoe UI", 9, "bold")).grid(row=3, column=0, sticky="w", pady=6)
        reply_types = ["Point-wise Reply", "Basic Professional Reply", "Manual Blank Reply"]
        type_cb = ttk.Combobox(frame, values=reply_types, width=42, state="readonly")
        type_cb.grid(row=3, column=1, sticky="w", pady=6)
        type_cb.current(0)

        # 5. Reply Source
        ttk.Label(frame, text="5. Reply Source", font=("Segoe UI", 9, "bold")).grid(row=4, column=0, sticky="w", pady=6)
        source_cb = ttk.Combobox(frame, values=["Current Notice Data", "Previous Reply Structure", "Knowledge/Template"], width=42, state="readonly")
        source_cb.grid(row=4, column=1, sticky="w", pady=6)
        source_cb.current(0)

        def generate_and_save():
            client_obj = client_map[client_cb.get()]
            case_obj = case_map.get(case_cb.get()) if case_map else None
            notice_obj = notice_map.get(notice_cb.get()) if notice_map else None
            reply_type_val = type_cb.get()

            disc_list = []
            if notice_obj:
                disc_list = self.db.get_discrepancies_by_notice(notice_obj['id'])

            # Generate draft text using template & safety rules
            draft_text = self.reply_generator.generate_reply_draft(
                client_dict=client_obj,
                case_dict=case_obj,
                notice_dict=notice_obj,
                discrepancies=disc_list,
                reply_type=reply_type_val
            )

            r_count = len(self.db.get_all_replies()) + 1
            reply_data = {
                'reply_id': f"RPLY-{r_count:03d}",
                'client_id': client_obj['id'],
                'gstin': client_obj['gstin'],
                'case_id': case_obj['id'] if case_obj else None,
                'notice_id': notice_obj['id'] if notice_obj else None,
                'financial_year': notice_obj['financial_year'] if notice_obj else (case_obj['financial_year'] if case_obj else "2022-23"),
                'reply_date': datetime.now().strftime("%Y-%m-%d"),
                'reply_type': reply_type_val,
                'status': 'Draft',
                'draft_text': draft_text
            }

            reply_db_id = self.db.add_reply(reply_data)
            dialog.destroy()
            self.refresh_replies_table()
            self.refresh_dashboard()

            # Open Editor Window directly
            self.open_reply_editor(reply_db_id)

        ttk.Button(frame, text="GENERATE DRAFT & EDIT", style="Success.TButton", command=generate_and_save).grid(row=5, column=0, columnspan=2, pady=20)

    def view_edit_reply_action(self):
        selected = self.replies_tree.selection()
        if not selected:
            messagebox.showwarning("Select Reply", "Please select a reply record from the table first.")
            return

        item = self.replies_tree.item(selected[0])
        reply_db_id = item['values'][0]
        self.open_reply_editor(reply_db_id)

    def open_reply_editor(self, reply_db_id: int):
        replies = self.db.get_all_replies()
        rep = [r for r in replies if r['id'] == reply_db_id][0]

        dialog = tk.Toplevel(self)
        dialog.title(f"GST Reply Editor - Reply ID: {rep['reply_id']}")
        dialog.geometry("900x700")

        frame = ttk.Frame(dialog, padding=15)
        frame.pack(fill="both", expand=True)

        info_hdr = f"Client: {rep.get('client_name')}  |  GSTIN: {rep.get('gstin')}  |  Notice: {rep.get('notice_number','N/A')}  |  Status: {rep.get('status')}"
        ttk.Label(frame, text=info_hdr, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 10))

        txt_editor = tk.Text(frame, font=("Consolas", 10), wrap="word", undo=True)
        txt_editor.insert("1.0", rep.get('draft_text', ''))
        txt_editor.pack(fill="both", expand=True, pady=(0, 10))

        btn_bar = ttk.Frame(frame)
        btn_bar.pack(fill="x")

        def save_draft_action():
            new_text = txt_editor.get("1.0", tk.END).strip()
            self.db.update_reply_text(reply_db_id, new_text, status="Draft")
            messagebox.showinfo("Saved", "Reply draft saved successfully!", parent=dialog)
            self.refresh_replies_table()

        def mark_final_action():
            new_text = txt_editor.get("1.0", tk.END).strip()
            self.db.update_reply_text(reply_db_id, new_text, status="Submitted")
            messagebox.showinfo("Completed", "Reply marked as SUBMITTED!", parent=dialog)
            dialog.destroy()
            self.refresh_replies_table()
            self.refresh_dashboard()

        def export_txt_action():
            file_p = filedialog.asksaveasfilename(
                title="Export Reply Draft",
                initialfile=f"GST_Reply_{rep['reply_id']}.txt",
                defaultextension=".txt",
                filetypes=[("Text File", "*.txt")]
            )
            if file_p:
                with open(file_p, "w", encoding="utf-8") as f:
                    f.write(txt_editor.get("1.0", tk.END))
                messagebox.showinfo("Exported", f"Reply saved to {file_p}", parent=dialog)

        ttk.Button(btn_bar, text="SAVE DRAFT", style="Accent.TButton", command=save_draft_action).pack(side="left", padx=5)
        ttk.Button(btn_bar, text="MARK AS SUBMITTED", style="Success.TButton", command=mark_final_action).pack(side="left", padx=5)
        ttk.Button(btn_bar, text="EXPORT / PRINT", command=export_txt_action).pack(side="left", padx=5)

    # =========================================================================
    # 7. GST PORTAL MODULE (SIMULATED DEMO)
    # =========================================================================
    def setup_tab_portal(self):
        container = ttk.Frame(self.tab_portal, padding=15)
        container.pack(fill="both", expand=True)

        # Title Header
        ttk.Label(container, text="GST PORTAL – DEMONSTRATION MODE", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 5))
        
        status_lbl = ttk.Label(container, text="Connection Status: DEMO MODE – NOT CONNECTED (No Real Credentials Required)", font=("Segoe UI", 10, "bold"), foreground="#c53030")
        status_lbl.pack(anchor="w", pady=(0, 15))

        # Toolbar Buttons
        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(0, 15))

        ttk.Button(btn_frame, text="AUTHENTICATION DEMO", command=lambda: messagebox.showinfo("Auth Demo", "GST Portal Auth Demo:\nSimulated OTP / EVC Handshake Passed (Demo Mode).")).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="GET DATA FROM GST", style="Accent.TButton", command=self.portal_get_data_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="IMPORT NOTICES", style="Success.TButton", command=self.portal_import_notices_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="SYNC NOW", command=self.portal_import_notices_action).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="REFRESH HISTORY", command=self.refresh_portal_history).pack(side="right", padx=5)

        # Portal Documents & Sync History
        ttk.Label(container, text="GST Portal Sync History & Document Logs", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(10, 5))

        cols = ("Sync ID", "GSTIN", "Sync Date", "Found", "Imported", "Duplicates", "Errors", "Status")
        self.portal_tree = ttk.Treeview(container, columns=cols, show="headings", height=10)
        for c in cols:
            self.portal_tree.heading(c, text=c)
            self.portal_tree.column(c, width=120, anchor="center")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.portal_tree.yview)
        self.portal_tree.configure(yscrollcommand=scrollbar.set)

        self.portal_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def refresh_portal_history(self):
        for r in self.portal_tree.get_children(): self.portal_tree.delete(r)
        history = self.db.get_portal_sync_history()
        for h in history:
            self.portal_tree.insert("", "end", values=(
                h.get('sync_id', ''),
                h.get('gstin', ''),
                h.get('sync_date', ''),
                h.get('documents_found', 0),
                h.get('documents_imported', 0),
                h.get('duplicates', 0),
                h.get('errors', 0),
                h.get('status', '')
            ))

    def portal_get_data_action(self):
        msg = """GST PORTAL SIMULATION - DOCUMENTS FOUND

Found 3 portal records:

1. ASMT-10 | ASMT10/2026/001 | 10-09-2026 | FY 2022-23 | 06AAAAA7182F1ZD
2. DRC-01A | DRC01A/2026/002 | 12-09-2026 | FY 2023-24 | 07BBBBB1234C1ZA
3. Order   | ORD/2026/003    | 15-09-2026 | FY 2022-23 | 09CCCCC5678D1ZB

Click 'IMPORT NOTICES' to automatically import into Litigation Pipeline."""
        messagebox.showinfo("GST Data Retrieval", msg)

    def portal_import_notices_action(self):
        """Simulate GST Portal document import into automatic document processing pipeline."""
        s_count = len(self.db.get_portal_sync_history()) + 1
        sync_id = f"SYNC-{s_count:03d}"

        # Record demo sync
        clients = self.db.get_all_clients()
        gstin = clients[0]['gstin'] if clients else "06AAAAA7182F1ZD"

        sync_data = {
            'sync_id': sync_id,
            'gstin': gstin,
            'documents_found': 3,
            'documents_imported': 3,
            'duplicates': 0,
            'errors': 0,
            'status': 'Completed'
        }
        self.db.add_portal_sync(sync_data)
        self.refresh_portal_history()

        # Trigger auto-processing pipeline simulation message
        messagebox.showinfo(
            "Portal Import Completed",
            f"Portal Sync: {sync_id}\n\n"
            f"✓ 3 Documents imported from GST Portal\n"
            f"✓ Automatic Read -> Extract -> Classify completed\n"
            f"✓ Linked to Client Litigation Records\n\n"
            f"Ready for Reply Generation!"
        )

    # =========================================================================
    # 8. REPORTS TAB
    # =========================================================================
    def setup_tab_reports(self):
        container = ttk.Frame(self.tab_reports, padding=15)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="LITIGATION REPORTS & SUMMARY", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 15))

        btn_bar = ttk.Frame(container)
        btn_bar.pack(fill="x", pady=(0, 10))

        ttk.Button(btn_bar, text="Client-wise Cases", command=lambda: self.load_report("cases")).pack(side="left", padx=5)
        ttk.Button(btn_bar, text="Open Cases", command=lambda: self.load_report("open_cases")).pack(side="left", padx=5)
        ttk.Button(btn_bar, text="Pending Replies", command=lambda: self.load_report("pending_replies")).pack(side="left", padx=5)
        ttk.Button(btn_bar, text="Notice Summary", command=lambda: self.load_report("notices")).pack(side="left", padx=5)

        ttk.Button(btn_bar, text="EXPORT TO EXCEL / CSV", style="Success.TButton", command=self.export_report_action).pack(side="right", padx=5)

        cols = ("Col 1", "Col 2", "Col 3", "Col 4", "Col 5", "Col 6")
        self.report_tree = ttk.Treeview(container, columns=cols, show="headings")
        for c in cols:
            self.report_tree.heading(c, text=c)
            self.report_tree.column(c, width=150, anchor="center")

        self.report_tree.pack(fill="both", expand=True)
        self.load_report("cases")

    def load_report(self, r_type: str):
        for r in self.report_tree.get_children(): self.report_tree.delete(r)

        if r_type == "cases":
            cases = self.db.get_all_cases()
            for c in cases:
                self.report_tree.insert("", "end", values=(c['case_number'], c['client_name'], c['gstin'], c['financial_year'], c['notice_type'], c['status']))
        elif r_type == "open_cases":
            cases = [c for c in self.db.get_all_cases() if c['status'] in ('Open', 'Under Review')]
            for c in cases:
                self.report_tree.insert("", "end", values=(c['case_number'], c['client_name'], c['gstin'], c['financial_year'], c['notice_type'], c['status']))
        elif r_type == "pending_replies":
            replies = [r for r in self.db.get_all_replies() if r['status'] == 'Draft']
            for r in replies:
                self.report_tree.insert("", "end", values=(r['reply_id'], r['client_name'], r['gstin'], r['notice_number'], r['reply_type'], r['status']))
        elif r_type == "notices":
            notices = self.db.get_all_notices()
            for n in notices:
                self.report_tree.insert("", "end", values=(n['notice_number'], n['client_name'], n['gstin'], n['financial_year'], n['notice_type'], n['status']))

    def export_report_action(self):
        file_path = filedialog.asksaveasfilename(
            title="Export Report to CSV",
            initialfile="GST_Litigation_Report.csv",
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv")]
        )
        if not file_path:
            return

        with open(file_path, "w", encoding="utf-8") as f:
            rows = []
            for item in self.report_tree.get_children():
                vals = [str(v) for v in self.report_tree.item(item)['values']]
                rows.append(",".join(vals))
            f.write("\n".join(rows))

        messagebox.showinfo("Export Successful", f"Report exported to {file_path}")

    # =========================================================================
    # 9. SETTINGS TAB
    # =========================================================================
    def setup_tab_settings(self):
        container = ttk.Frame(self.tab_settings, padding=20)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="APPLICATION SETTINGS", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 15))

        f_set = ttk.Frame(container)
        f_set.pack(fill="x", pady=10)

        # Config Options
        ttk.Checkbutton(f_set, text="Automatic Document Processing (ON by default)", variable=self.auto_doc_processing).pack(anchor="w", pady=8)
        ttk.Checkbutton(f_set, text="Demo GST Portal Mode (ON)", variable=self.demo_portal_mode).pack(anchor="w", pady=8)

        db_loc = f"Database Location: {self.db.db_path}"
        ttk.Label(f_set, text=db_loc, font=("Consolas", 9)).pack(anchor="w", pady=12)

        # Backup Button
        ttk.Button(f_set, text="BACKUP DATABASE", style="Success.TButton", command=self.backup_database_action).pack(anchor="w", pady=15)

    def backup_database_action(self):
        """Action to copy SQLite database to backups/ with timestamp."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"gst_lit_assist_backup_{ts}.db"
        dest_path = os.path.join(self.backup_dir, backup_name)

        try:
            shutil.copy2(self.db.db_path, dest_path)
            messagebox.showinfo("Backup Successful", f"Database backed up successfully to:\n{dest_path}")
            logging.info(f"Database backed up to {dest_path}")
        except Exception as e:
            messagebox.showerror("Backup Failed", f"Could not create database backup: {str(e)}")

    # =========================================================================
    # 10. ABOUT TAB
    # =========================================================================
    def setup_tab_about(self):
        container = ttk.Frame(self.tab_about, padding=25)
        container.pack(fill="both", expand=True)

        about_text = """
GST Lit assist
GST Litigation Management & Reply Demo

Academic Demonstration & Project Tool for GST Litigation Management

PURPOSE:
Demonstrate how AI/automation can be utilized for basic GST litigation management,
notice parsing, discrepancy tracking, and legal reply draft generation.

TECHNOLOGY STACK:
• Python 3.10+
• Tkinter Desktop GUI
• SQLite Local Database
• openpyxl Excel Import/Export
• PyPDF2 / python-docx Parsing Engine

GST PORTAL INTEGRATION & FUTURE API ARCHITECTURE:
For this academic demonstration, the portal module operates in mock/demonstration mode.
Future production implementation may connect through officially supported GST API mechanisms/GSP/ASP.
Official GST Developer Portal: https://developer.gst.gov.in/apiportal/

SECURITY & PRIVACY:
• 100% Local Execution (No external paid APIs, cloud services, or Ollama required)
• No real GST portal credentials or OTP bypass attempted.

Version: 1.0.0 (Academic Demonstration Release)
"""
        txt_w = tk.Text(container, font=("Segoe UI", 10), wrap="word", bg="#f7fafc", borderwidth=0)
        txt_w.insert("1.0", about_text.strip())
        txt_w.config(state="disabled")
        txt_w.pack(fill="both", expand=True)


if __name__ == "__main__":
    app = GSTLitAssistApp()
    app.mainloop()
