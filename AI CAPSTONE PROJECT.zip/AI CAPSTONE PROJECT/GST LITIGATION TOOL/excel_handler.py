"""
Excel Import / Export Handler for GST Lit assist
Handles client and case importing from Excel files with GSTIN state identification, duplicate checking, and error reporting.
"""

import os
import logging
from gst_utils import get_state_from_gstin, validate_gstin_format

try:
    import openpyxl
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False


class ExcelHandler:
    def __init__(self, db_instance):
        self.db = db_instance

    def import_clients_from_excel(self, file_path: str) -> dict:
        """
        Import clients from Excel (.xlsx) file.
        Returns summary statistics dictionary:
        {
            'total_found': int,
            'imported': int,
            'duplicates': int,
            'errors': int,
            'messages': list
        }
        """
        result = {
            'total_found': 0,
            'imported': 0,
            'duplicates': 0,
            'errors': 0,
            'messages': []
        }

        if not EXCEL_AVAILABLE:
            result['messages'].append("Error: openpyxl library is not installed.")
            result['errors'] += 1
            return result

        if not os.path.exists(file_path):
            result['messages'].append(f"Error: File '{file_path}' does not exist.")
            result['errors'] += 1
            return result

        try:
            wb = openpyxl.load_workbook(file_path, data_only=True)
            ws = wb.active

            # Header mapping
            headers = []
            rows = list(ws.iter_rows(values_only=True))

            if not rows:
                result['messages'].append("Error: Excel file is empty.")
                result['errors'] += 1
                return result

            # First row as header
            raw_headers = [str(cell).strip().lower() if cell is not None else "" for cell in rows[0]]
            
            header_map = {}
            for idx, h in enumerate(raw_headers):
                if "client name" in h or "name" in h:
                    header_map['client_name'] = idx
                elif "trade" in h:
                    header_map['trade_name'] = idx
                elif "contact" in h:
                    header_map['contact_person'] = idx
                elif "email" in h:
                    header_map['email'] = idx
                elif "phone" in h or "mobile" in h:
                    header_map['phone'] = idx
                elif "gstin" in h:
                    header_map['gstin'] = idx
                elif "state" in h:
                    header_map['state'] = idx
                elif "address" in h:
                    header_map['address'] = idx
                elif "notes" in h or "remark" in h:
                    header_map['notes'] = idx

            if 'client_name' not in header_map or 'gstin' not in header_map:
                result['messages'].append("Error: Missing required header columns ('Client Name', 'GSTIN').")
                result['errors'] += 1
                return result

            data_rows = rows[1:]
            result['total_found'] = len(data_rows)

            existing_clients = self.db.get_all_clients()
            existing_gstins = {c['gstin'].upper() for c in existing_clients}

            for row_num, row in enumerate(data_rows, start=2):
                # Skip empty row
                if not any(row):
                    continue

                client_name = str(row[header_map['client_name']]).strip() if row[header_map['client_name']] else ""
                gstin = str(row[header_map['gstin']]).strip().upper() if row[header_map['gstin']] else ""

                if not client_name or not gstin:
                    result['errors'] += 1
                    result['messages'].append(f"Row {row_num}: Skipped - Missing mandatory Client Name or GSTIN.")
                    continue

                # Validate GSTIN format
                is_valid_gstin, msg = validate_gstin_format(gstin)
                if not is_valid_gstin:
                    result['messages'].append(f"Row {row_num} ({client_name}): Warning - {msg}")

                # Derive State from GSTIN
                derived_state = get_state_from_gstin(gstin)
                excel_state = str(row[header_map['state']]).strip() if 'state' in header_map and row[header_map['state']] else ""
                final_state = excel_state if excel_state else derived_state

                # Check Duplicate GSTIN
                if gstin in existing_gstins:
                    result['duplicates'] += 1
                    result['messages'].append(f"Row {row_num}: Skipped duplicate GSTIN '{gstin}' for '{client_name}'.")
                    continue

                # Build Client Record
                client_id_code = f"CLI-{len(existing_clients) + result['imported'] + 101:03d}"
                client_data = {
                    'client_id': client_id_code,
                    'client_name': client_name,
                    'trade_name': str(row[header_map.get('trade_name', -1)]).strip() if header_map.get('trade_name', -1) >= 0 and row[header_map['trade_name']] else "",
                    'contact_person': str(row[header_map.get('contact_person', -1)]).strip() if header_map.get('contact_person', -1) >= 0 and row[header_map['contact_person']] else "",
                    'email': str(row[header_map.get('email', -1)]).strip() if header_map.get('email', -1) >= 0 and row[header_map['email']] else "",
                    'phone': str(row[header_map.get('phone', -1)]).strip() if header_map.get('phone', -1) >= 0 and row[header_map['phone']] else "",
                    'gstin': gstin,
                    'state': final_state,
                    'address': str(row[header_map.get('address', -1)]).strip() if header_map.get('address', -1) >= 0 and row[header_map['address']] else "",
                    'notes': str(row[header_map.get('notes', -1)]).strip() if header_map.get('notes', -1) >= 0 and row[header_map['notes']] else "Imported from Excel"
                }

                try:
                    self.db.add_client(client_data)
                    existing_gstins.add(gstin)
                    result['imported'] += 1
                    result['messages'].append(f"Row {row_num}: Successfully imported '{client_name}' (State: {final_state}).")
                except Exception as ex:
                    result['errors'] += 1
                    result['messages'].append(f"Row {row_num}: Database error importing '{client_name}' - {str(ex)}")

        except Exception as e:
            result['errors'] += 1
            result['messages'].append(f"Error processing Excel workbook: {str(e)}")

        logging.info(f"Excel Client Import Summary: Found {result['total_found']}, Imported {result['imported']}, Duplicates {result['duplicates']}, Errors {result['errors']}")
        return result
