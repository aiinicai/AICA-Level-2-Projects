# PRESENTATION FLOW: GST Lit assist DEMONSTRATION

This document provides an 18-step classroom presentation flow for demonstrating **GST Lit assist** to instructors, teachers, or audiences.

---

## 📋 Recommended Demonstration Sequence

### STEP 1: Launch Application
- Run `py app.py` from the command prompt.
- Point out the clean CA/GST-oriented visual appearance and main header branding (**GST Lit assist - GST Litigation Management & Reply Demo**).

### STEP 2: Dashboard Overview
- Navigate to **1. Dashboard**.
- Show the 8 real-time metric cards (Total Clients, GSTINs, Cases, Open Cases, Pending Notices, Pending Replies, Documents, Completed Replies).
- Highlight the **Recent Litigation** table showing active cases.

### STEP 3: Client Management
- Switch to **2. Clients** tab.
- Show the client list table.

### STEP 4: Import Clients from Excel
- Click **IMPORT FROM EXCEL**.
- Select `sample_data/sample_clients.xlsx`.
- Demonstrate the import result dialog showing total records found, imported, duplicate skipped, and errors.

### STEP 5: GSTIN State Identification
- Click **+ CREATE CLIENT**.
- Type a test GSTIN starting with `06` (e.g. `06AAAAA7182F1ZD`) and point out how **Haryana** is automatically populated in the State field (`07` -> Delhi, `09` -> UP).
- Explain that the state remains fully editable by the user if required.

### STEP 6: Open Client Detail Profile
- Double-click **Mahajan Life Sciences** in the client table.
- Show how all client litigation information (Overview, GSTIN, Cases, Notices, Documents, Replies) is accessible directly from the Client Profile window.

### STEP 7: Case Management
- Navigate to **3. Cases** tab.
- Review the list of active litigation cases.

### STEP 8: Open Target Case
- Select **CASE-2026-001** (Client: *Mahajan Life Sciences*, FY: *2022-23*, Notice Type: *ASMT-10*, Section: *Section 61*).

### STEP 9: Review GST Notice
- Switch to **4. Notices** tab.
- Select Notice **ASMT10/2026/001** issued to *Mahajan Life Sciences*.

### STEP 10: Point-wise Discrepancies
- Click **VIEW DISCREPANCIES**.
- Point out the exact notice observations and tax figures:
  1. **ITC Reconciliation Difference**: Rs. 7,860.24 (CGST: Rs. 2,387.74, SGST: Rs. 2,387.74, IGST: Rs. 3,036.80, CESS: Rs. 47.96)
  2. **Credit Notes Verification**: Rs. 22,019.65
  3. **B2B Outward Turnover**: Rs. 2,17,68,368.43

### STEP 11: Zero-Click Automatic Document Processing
- Switch to **5. Documents** tab.
- Click **UPLOAD DOCUMENT** and select `sample_data/sample_notices/ASMT-10_Notice_Mahajan_Life_Sciences.txt`.
- **CRITICAL DEMO POINT**: Do **NOT** click an Extract button!
- Show the automatic status progression popup: `Uploaded` → `Reading` → `Extracting` → `Completed` (`READY FOR REVIEW`).

### STEP 12: Initiate Reply Draft
- Switch to **6. Replies** tab.
- Click **+ CREATE REPLY**.

### STEP 13: Generate Point-wise Legal Reply
- Select Client (*Mahajan Life Sciences*), Case (*CASE-2026-001*), Notice (*ASMT10/2026/001*), and Reply Type (*Point-wise Reply*).
- Click **GENERATE DRAFT & EDIT**.
- Point out the generated legal draft containing:
  - Formal addressee header to the Proper Officer
  - Detailed departmental observation
  - Taxpayer submissions and quantified tax breakdowns
  - List of annexed supporting documents
  - Formal prayer for dropping demand proceedings

### STEP 14: Edit & Save Reply Draft
- Make a minor edit in the Reply Editor.
- Click **SAVE DRAFT** (or **MARK AS SUBMITTED**). Show that status updates across the Dashboard and Replies table.

### STEP 15: GST Portal Simulation Screen
- Switch to **7. GST Portal** tab.
- Point out connection status: `DEMO MODE – NOT CONNECTED`.
- Click **GET DATA FROM GST** to simulate finding portal records (ASMT-10, DRC-01A, Order).

### STEP 16: Import Notices from Portal
- Click **IMPORT NOTICES**.
- Show demo portal documents being fetched and ingested.

### STEP 17: Automatic Ingestion Pipeline
- Show how imported portal documents automatically enter the same read-extract-classify pipeline without duplicate logic.

### STEP 18: Future GST API Architecture
- Open **10. About** tab (or refer to documentation).
- Explain that production implementations can connect to live GST Portal data via official GST GSP/ASP API integration (https://developer.gst.gov.in/apiportal/).
