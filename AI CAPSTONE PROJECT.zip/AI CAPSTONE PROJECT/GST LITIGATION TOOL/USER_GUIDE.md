# USER GUIDE: GST Lit assist

Welcome to **GST Lit assist** (GST Litigation Management & Reply Demo). This guide provides step-by-step instructions for operating the application.

---

## 1. Application Launch

To start the application:
1. Open Windows Command Prompt or Terminal.
2. Navigate to the project root directory:
   ```cmd
   cd "d:\AI ICAI LEVEL II\DAY 4\GST LITIGATION TOOL"
   ```
3. Run:
   ```cmd
   py app.py
   ```
The desktop GUI window will launch and display the **Dashboard**.

---

## 2. Dashboard Navigation

The Dashboard displays live litigation statistics:
- **Metrics Cards**: Total Clients, GSTINs, Cases, Open Cases, Pending Notices, Pending Replies, Documents, Completed Replies.
- **Recent Litigation**: Real-time table displaying newly created cases, client names, GSTINs, financial years, notice types, and statuses.

---

## 3. Client Management & Excel Import

### Creating a Client Manually
1. Click the **2. Clients** tab.
2. Click **+ CREATE CLIENT**.
3. Enter Client Name and 15-digit GSTIN (e.g. `06AAAAA7182F1ZD`).
4. Notice that typing `06` automatically populates **Haryana** as the State. (State can be edited if needed).
5. Click **SAVE CLIENT**.

### Importing Clients from Excel
1. Click **IMPORT FROM EXCEL**.
2. Select `sample_data/sample_clients.xlsx`.
3. The system parses the workbook, validates required fields, derives states from GSTINs, checks for duplicate GSTINs, and displays an **Excel Import Result** report.

### Viewing Client Profile & Linked Litigation
Double-click any client row or click **VIEW DETAILS** to open the comprehensive Client Profile window with sub-tabs for Overview, Cases, Notices, Documents, and Replies.

---

## 4. Case Management

1. Click the **3. Cases** tab.
2. Click **+ CREATE CASE**.
3. Select the Client from the dropdown.
4. Enter Case Number (e.g. `CASE-2026-004`), Financial Year (`2022-23`), Notice Type (`ASMT-10`), Section (`Section 61`), and Proper Officer details.
5. Click **SAVE CASE**.

---

## 5. Notice & Discrepancy Tracking

1. Click the **4. Notices** tab.
2. Select a notice row and click **VIEW DISCREPANCIES**.
3. A modal opens displaying the point-wise discrepancy table (e.g. Point 1: ITC Difference Rs. 7,860.24, Point 2: Credit Notes Rs. 22,019.65, Point 3: B2B Turnover Rs. 2,17,68,368.43).
4. Click **+ ADD DISCREPANCY POINT** to add new tax observations with CGST, SGST, IGST, and CESS breakdowns.

---

## 6. Automatic Zero-Click Document Processing

1. Click the **5. Documents** tab.
2. Click **UPLOAD DOCUMENT** and select a notice text or PDF file (e.g. `sample_data/sample_notices/ASMT-10_Notice_Mahajan_Life_Sciences.txt`).
3. **AUTOMATIC PROCESSING PIPELINE**:
   - The file is saved to `data/documents/`.
   - The system automatically triggers `Uploaded` → `Reading` → `Extracting` → `Completed`.
   - No separate "Extract" button click is required.
4. Click **VIEW DOCUMENT** to inspect extracted text and JSON metadata.

---

## 7. Point-wise Reply Draft Generation

1. Click the **6. Replies** tab.
2. Click **+ CREATE REPLY**.
3. Select Client (*Mahajan Life Sciences*), Case (*CASE-2026-001*), Notice (*ASMT10/2026/001*), and Reply Type (*Point-wise Reply*).
4. Click **GENERATE DRAFT & EDIT**.
5. The Reply Editor opens with the full legal draft. You can edit the text, click **SAVE DRAFT**, **MARK AS SUBMITTED**, or **EXPORT / PRINT** to a `.txt` file.

---

## 8. GST Portal Simulation

1. Click the **7. GST Portal** tab.
2. Connection Status shows `DEMO MODE – NOT CONNECTED`.
3. Click **GET DATA FROM GST** to simulate portal document discovery.
4. Click **IMPORT NOTICES** to simulate portal retrieval feeding directly into the automatic document processing pipeline.
5. View the sync history log in the bottom table.

---

## 9. Reports & Database Backup

- **Reports**: Go to **8. Reports** to filter litigation records and export to CSV.
- **Backup**: Go to **9. Settings** and click **BACKUP DATABASE** to copy SQLite database to `backups/` with a timestamp.
