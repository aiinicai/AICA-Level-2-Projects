# THE INSTITUTE OF CHARTERED ACCOUNTANTS OF INDIA
## ICAI LEVEL 2 CAPSTONE PROJECT REPORT & CODE DOSSIER

---

# SJT TASK MANAGEMENT SYSTEM
### A Standalone, Offline-First Practice Automation & Statutory Compliance Platform for Chartered Accountancy Firms

---

### SUBMITTED BY:
**CA. Hiren Thakkar**  
Managing Partner — Direct Tax & Audit  
**ICAI Membership No:** `ICAI/059812`  
**Firm Name:** `S J T & Co., Chartered Accountants`  
**Submission Date:** August 2026  

---

## 📜 CERTIFICATE & DECLARATION

This is to certify that the Capstone Project entitled **"SJT TASK MANAGEMENT SYSTEM — Practice Automation & Statutory Compliance Platform for CA Firms"** is an authentic, original work conducted by **CA. Hiren Thakkar (Membership No. ICAI/059812)** for submission towards the **ICAI Level 2 Capstone Project**.

The software system designed and implemented herein addresses real-world practice management hurdles faced by Indian Chartered Accountancy firms, encompassing Income Tax audits (u/s 44AB), GST compliances (GSTR-1, GSTR-3B, GSTR-9, REG-16), statutory audits, team workload balancing, client master databases, and zero-dependency offline database persistence.

```
____________________________________
CA. Hiren Thakkar
Managing Partner, S J T & Co.
ICAI Membership No.: ICAI/059812
```

---

## 📑 TABLE OF CONTENTS

1. **Chapter 1: Executive Summary & Problem Statement**
2. **Chapter 2: System Architecture & Practice Management Design**
3. **Chapter 3: Statutory Compliance Workflows & Three-Tier RBAC**
4. **Chapter 4: Single Executable Architecture (SEA) & Offline Database Design**
5. **Chapter 5: Complete Source Code Dossier**
   - 5.1 Backend REST API Engine (`server.ts`)
   - 5.2 Offline Database & Storage Engine (`src/server/localStore.ts`)
   - 5.3 Two-Way Synchronization Engine (`src/server/syncEngine.ts`)
   - 5.4 TypeScript Domain Models (`src/types.ts`)
   - 5.5 Client API & Offline Resilient Auth Layer (`src/api.ts`)
   - 5.6 Main Application Controller (`src/App.tsx`)
   - 5.7 Task Management & Work Notes (`src/components/TaskModal.tsx`)
   - 5.8 Task Register & Filtering (`src/components/TasksView.tsx`)
   - 5.9 Client Master Register & CSV Import (`src/components/ClientsView.tsx`)
   - 5.10 Executive Analytics & KPI Dashboard (`src/components/DashboardView.tsx`)
   - 5.11 Authentication & Profile Select (`src/components/AuthPage.tsx`)
   - 5.12 Firm Brand Header & Emblem (`src/components/Header.tsx`)
   - 5.13 Team Workload Balancer (`src/components/TeamManagement.tsx`)
   - 5.14 Database Maintenance & Backup Engine (`src/components/DatabaseSettings.tsx`)
   - 5.15 Standalone Portable EXE Builder (`scripts/build-portable-exe.js`)
   - 5.16 Project Metadata (`package.json`)
6. **Chapter 6: User Manual & Execution Verification Guide**
7. **Chapter 7: Conclusion & Declaration**

---

## 🏢 CHAPTER 1: EXECUTIVE SUMMARY & PROBLEM STATEMENT

### 1.1 The Operational Challenge in CA Practice
Chartered Accountancy firms in India operate under strict statutory timelines governed by the Income Tax Act (1961), Goods and Services Tax (GST) Acts (2017), Companies Act (2013), and ICAI Ethical Standards. Practicing firms face severe recurring operational hurdles:
- **Statutory Due Date Penalties:** Missing compliance due dates leads to client late fees, interest, and reputation damage.
- **Unbalanced Team Workload:** Difficulty distributing work evenly among senior partners, managers, and article assistants.
- **Internet Outage Vulnerability:** Web-only tools fail during office network disruptions or client on-site audits.
- **Scattered Client Records:** PAN, GSTIN, entity structures, and contact records stored haphazardly across disparate Excel sheets.
- **IT Setup Overhead:** Traditional practice management software requires tedious installations (SQL servers, runtime engines) on every staff machine.

### 1.2 The SJT Solution & Core Innovations
To resolve these bottlenecks, the **SJT Task Management System** was developed with four foundational pillars:
1. **Single Portable Executable (`SJT-Task-Management.exe`):** Compiles the entire application into ONE standalone 92 MB Windows EXE with zero external dependencies.
2. **Offline-First Master Database (`C:\SJT_Task_Database`):** Provides high-speed, local persistence with atomic file writes and automated snapshot backups.
3. **Three-Tier Role-Based Access Control (RBAC):** Distinct interfaces for Partners (full analytics, audit logs), Managers (assignment, review), and Staff Members (execution, progress notes).
4. **Pre-Seeded Statutory Categories:** Built-in templates for Income Tax (44AB, ITR, 3CD), GST Return (3B, 1, 9, REG-16), Statutory Audit, and Corporate Advisory.

---

## 🛠️ CHAPTER 2: SYSTEM ARCHITECTURE & DESIGN

### 2.1 Technology Stack
- **Frontend:** React 19, TypeScript, Tailwind CSS, Lucide React Icons, Vite.
- **Backend:** Node.js 24 LTS, Express.js REST API, Node Crypto SHA-256 Auth.
- **Storage:** Atomic JSON Master Store with automated rotation snapshots at `C:\SJT_Task_Database`.
- **Packaging:** Node.js Single Executable Application (SEA) + In-Memory Asset Dictionary + Postject Binary Injection.

### 2.2 Security Specifications
- **Password Hashing:** SHA-256 with 16-byte random salt per user.
- **Session Tokens:** Bearer token validation on all private endpoints.
- **Audit Logging:** Every action (login, task allocation, status update, client registration) is recorded in immutable audit logs.

---

## 🚀 CHAPTER 3: STATUTORY COMPLIANCE MODULES

| Module | Core Statutory Functions | Key Formats / Sections |
| :--- | :--- | :--- |
| **Income Tax** | Tax Audits, ITR 1 to 7, Advance Tax Calculations | Section 44AB, Form 3CD, Section 43BScrutiny |
| **GST Compliances** | Monthly Returns, Annual Reconciliations, Cancellation | GSTR-1, GSTR-3B, GSTR-9, REG-16 Surrender |
| **Statutory Audit** | Corporate & Non-Corporate Balance Sheet Verification | CARO 2020, Companies Act Schedule III |
| **Client Master** | Unified PAN, GSTIN, Trade Names & Entity Profiles | Private Ltd, Partnership, LLP, Individual |
| **Team Workload** | Workload distribution & Overdue tracking | Real-time capacity & Task stage metrics |

---

## 💻 CHAPTER 4: COMPLETE SOURCE CODE DOSSIER

The complete source code is bundled inside the Word document:
**[`c:\SJT_Task_Management\SJT_Task_Management_ICAI_Capstone_Project_Dossier.docx`](file:///c:/SJT_Task_Management/SJT_Task_Management_ICAI_Capstone_Project_Dossier.docx)**

All files are structured with line numbering and syntax formatting for official ICAI evaluation.

---

## 📖 CHAPTER 5: USER MANUAL & EXECUTION GUIDE

### How to Run:
1. Double-click **`SJT-Task-Management.exe`**.
2. The browser automatically opens to **`http://localhost:3004`**.
3. Log in using pre-configured test profiles (Password: `SJT@2012`):
   - **Senior Partner:** `thakkarhiren000@gmail.com`
   - **Manager:** `manager@sjtca.in`
   - **Staff Member:** `staff@sjtca.in`
