import React, { useState } from 'react';
import {
  Sparkles,
  ShieldAlert,
  AlertTriangle,
  CheckCircle,
  X,
  RefreshCw,
  ExternalLink,
  Info,
  Lock,
} from 'lucide-react';
import { AIClauseAnalysis, DiffChange } from '../types/diff';

interface AIAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  changes: DiffChange[];
  onApplyAnalyses: (analyses: AIClauseAnalysis[]) => void;
  originalDocumentName: string;
  revisedDocumentName: string;
  preselectedChangeId?: string | null;
}

export const AIAnalysisModal: React.FC<AIAnalysisModalProps> = ({
  isOpen,
  onClose,
  changes,
  onApplyAnalyses,
  originalDocumentName,
  revisedDocumentName,
  preselectedChangeId,
}) => {
  const [hasConsented, setHasConsented] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>(() => {
    if (preselectedChangeId) return [preselectedChangeId];
    // By default select all material / high-significance changes (up to 10 for focused review)
    const priority = changes.filter(
      (c) => c.significance === 'High' || c.significance === 'Moderate' || c.type === 'clause' || c.type === 'amount'
    );
    return (priority.length > 0 ? priority : changes).slice(0, 8).map((c) => c.id);
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<AIClauseAnalysis[]>([]);

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedIds(changes.map((c) => c.id));
  };

  const selectNone = () => {
    setSelectedIds([]);
  };

  const handleRunAnalysis = async () => {
    if (selectedIds.length === 0) {
      setError('Please select at least one change to analyze.');
      return;
    }

    setIsLoading(true);
    setError(null);

    const changesToAnalyze = changes
      .filter((c) => selectedIds.includes(c.id))
      .map((c) => ({
        id: c.id,
        type: c.type,
        originalText: c.originalText,
        revisedText: c.revisedText,
        section: c.section,
        contextBefore: c.contextBefore,
        contextAfter: c.contextAfter,
      }));

    try {
      const response = await fetch('/api/gemini/analyze-clauses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          changes: changesToAnalyze,
          documentContext: {
            originalTitle: originalDocumentName,
            revisedTitle: revisedDocumentName,
          },
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Server error occurred while analyzing clauses.');
      }

      if (data.analyses && Array.isArray(data.analyses)) {
        setResults(data.analyses);
        onApplyAnalyses(data.analyses);
      } else {
        throw new Error('Received unexpected response format from AI service.');
      }
    } catch (err: unknown) {
      const error = err as Error;
      setError(error.message || 'Failed to analyze changes with AI.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-[#003875] text-white flex items-center justify-between border-b border-[#0052cc]">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-white text-[#003875] shadow-xs">
              <Sparkles className="w-5 h-5 text-[#0052cc]" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">AI Material Clause Analysis</h3>
              <p className="text-xs text-blue-100">
                Grounded semantic contract review
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Privacy & Data Flow Disclosure Banner */}
          <div className="p-4 bg-sky-50 rounded-xl border border-sky-200 text-xs text-sky-950 space-y-2">
            <div className="flex items-center space-x-2 font-bold text-sky-900">
              <Lock className="w-4 h-4 text-sky-600" />
              <span>Privacy & Grounding Disclosure</span>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Only the <strong>specific selected altered excerpts and their immediate surrounding sentence context</strong> are sent to the server for evaluation. Full original documents are not uploaded, indexed, or stored permanently.
            </p>
            <div className="text-[11px] text-slate-500 flex items-center space-x-1.5 pt-1">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>
                <strong>Review Notice:</strong> Risk ratings and clause impacts are automated preliminary flags for human document reviewers and do not constitute formal legal counsel.
              </span>
            </div>
          </div>

          {/* User Consent Checkbox */}
          {!hasConsented && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-start space-x-3">
              <input
                id="consent-checkbox"
                type="checkbox"
                checked={hasConsented}
                onChange={(e) => setHasConsented(e.target.checked)}
                className="rounded border-slate-300 text-sky-600 focus:ring-sky-500 mt-1 cursor-pointer w-4 h-4"
              />
              <label htmlFor="consent-checkbox" className="text-xs text-slate-700 cursor-pointer">
                I understand that selected clause snippets will be processed by Google Gemini to identify practical meaning and potential contract risks. I agree to proceed with this AI review.
              </label>
            </div>
          )}

          {/* Change Selection Checklist */}
          {hasConsented && results.length === 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  Select Changes for Material Risk Evaluation ({selectedIds.length} of {changes.length} selected):
                </span>
                <div className="flex items-center space-x-2 text-xs">
                  <button
                    onClick={selectAll}
                    className="text-sky-600 hover:text-sky-800 font-medium"
                  >
                    Select All
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    onClick={selectNone}
                    className="text-slate-500 hover:text-slate-800 font-medium"
                  >
                    Deselect All
                  </button>
                </div>
              </div>

              <div className="max-h-64 overflow-y-auto space-y-2 border border-slate-200 rounded-xl p-3 bg-slate-50/50">
                {changes.map((change) => {
                  const isChecked = selectedIds.includes(change.id);
                  return (
                    <label
                      key={change.id}
                      className={`flex items-start space-x-3 p-2.5 rounded-lg border text-xs cursor-pointer transition ${
                        isChecked
                          ? 'bg-white border-sky-300 shadow-2xs'
                          : 'bg-white/60 border-slate-200 hover:bg-white'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleSelect(change.id)}
                        className="rounded border-slate-300 text-sky-600 focus:ring-sky-500 mt-0.5 cursor-pointer"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="font-mono font-bold text-slate-800">
                            {change.id} • {change.section}
                          </span>
                          <span className="text-[10px] font-semibold uppercase text-slate-500 px-1.5 py-0.2 bg-slate-100 rounded">
                            {change.type}
                          </span>
                        </div>
                        <p className="text-slate-600 truncate font-mono text-[11px]">
                          {change.originalText || '(none)'} ➔ {change.revisedText || '(deleted)'}
                        </p>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start space-x-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">{error}</div>
            </div>
          )}

          {/* Results List */}
          {results.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>AI Clause Review Completed ({results.length} changes evaluated)</span>
                </h4>
                <button
                  onClick={() => {
                    setResults([]);
                  }}
                  className="text-xs text-sky-600 hover:text-sky-800 flex items-center space-x-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Reanalyze / Select Different Changes</span>
                </button>
              </div>

              <div className="space-y-3">
                {results.map((res) => {
                  const riskBadge =
                    res.riskLevel === 'High'
                      ? 'bg-red-50 text-red-700 border-red-300'
                      : res.riskLevel === 'Moderate'
                      ? 'bg-blue-50 text-[#0052cc] border-blue-200'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-300';

                  return (
                    <div
                      key={res.changeId}
                      className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs space-y-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
                            {res.changeId}
                          </span>
                          <span className="font-bold text-slate-800">{res.changeSummary}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px] border ${riskBadge}`}
                        >
                          Risk: {res.riskLevel}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
                        <div className="p-2 bg-rose-50/60 rounded border border-rose-100 text-rose-950">
                          <strong className="font-sans block text-rose-800 text-[10px] uppercase mb-0.5">
                            Original Wording
                          </strong>
                          {res.originalWording}
                        </div>
                        <div className="p-2 bg-emerald-50/60 rounded border border-emerald-100 text-emerald-950">
                          <strong className="font-sans block text-emerald-800 text-[10px] uppercase mb-0.5">
                            Revised Wording
                          </strong>
                          {res.revisedWording}
                        </div>
                      </div>

                      <div className="space-y-1.5 text-slate-700">
                        <p>
                          <strong className="text-slate-900">Practical Meaning:</strong>{' '}
                          {res.practicalMeaning}
                        </p>
                        <p>
                          <strong className="text-slate-900">Potential Impact:</strong>{' '}
                          {res.potentialImpact}
                        </p>
                        <p>
                          <strong className="text-slate-900">Risk Rationale:</strong>{' '}
                          {res.riskRationale}
                        </p>
                      </div>

                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-slate-800 text-[11px]">
                        <strong className="text-sky-900 flex items-center space-x-1 mb-0.5">
                          <Info className="w-3.5 h-3.5 text-sky-600" />
                          <span>Recommended Reviewer Action & Inquiry:</span>
                        </strong>
                        <p>{res.recommendedFollowUp}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 transition"
          >
            {results.length > 0 ? 'Done' : 'Cancel'}
          </button>

          {hasConsented && results.length === 0 && (
            <button
              onClick={handleRunAnalysis}
              disabled={isLoading || selectedIds.length === 0}
              className="inline-flex items-center space-x-2 px-5 py-2 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 shadow-sm transition disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Evaluating Clauses with Gemini...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Analyze {selectedIds.length} Selected Changes</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
