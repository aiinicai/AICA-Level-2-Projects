import React from 'react';
import {
  PlusCircle,
  MinusCircle,
  FileEdit,
  DollarSign,
  Calendar,
  ShieldAlert,
  CheckCircle2,
  Layers,
} from 'lucide-react';
import { ComparisonStats } from '../types/diff';

interface SummaryStatsBarProps {
  stats: ComparisonStats;
  aiAnalysesCount: number;
  activeFilter: string | null;
  onFilterClick: (filter: string | null) => void;
}

export const SummaryStatsBar: React.FC<SummaryStatsBarProps> = ({
  stats,
  aiAnalysesCount,
  activeFilter,
  onFilterClick,
}) => {
  const isIdentical = stats.totalDetectedChanges === 0;

  if (isIdentical) {
    return (
      <div className="bg-[#f0fdf4] border border-[#bbf7d0] rounded-2xl p-5 flex items-center justify-between shadow-xs">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 rounded-full bg-[#dcfce7] text-[#15803d] flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#14532d]">Documents are Completely Identical</h4>
            <p className="text-xs text-[#166534] mt-0.5">
              Zero textual, numerical, or formatting variances detected between Original and Revised versions.
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs font-bold text-[#15803d] bg-white px-3 py-1.5 rounded-full border border-[#bbf7d0] shadow-2xs">
            100% Match
          </span>
        </div>
      </div>
    );
  }

  const statItems = [
    {
      id: 'all',
      label: 'Total Differences',
      value: stats.totalDetectedChanges,
      icon: Layers,
      color: 'text-[#0052cc]',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      tag: 'Exact Diff',
    },
    {
      id: 'addition',
      label: 'Additions',
      value: `+${stats.totalAdditions}`,
      icon: PlusCircle,
      color: 'text-[#16a34a]',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-300',
      tag: 'Inserted',
    },
    {
      id: 'deletion',
      label: 'Deletions',
      value: `-${stats.totalDeletions}`,
      icon: MinusCircle,
      color: 'text-[#dc2626]',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-300',
      tag: 'Removed',
    },
    {
      id: 'modification',
      label: 'Modified Wording',
      value: stats.modifiedSegments,
      icon: FileEdit,
      color: 'text-[#0052cc]',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      tag: 'Replaced',
    },
    {
      id: 'amount',
      label: 'Numerical / Rates',
      value: stats.changedAmounts,
      icon: DollarSign,
      color: 'text-[#0052cc]',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      tag: 'Arithmetic',
    },
    {
      id: 'date',
      label: 'Dates & Deadlines',
      value: stats.changedDates,
      icon: Calendar,
      color: 'text-[#0052cc]',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      tag: 'Timing',
    },
    {
      id: 'clause',
      label: 'Clause Changes',
      value: stats.materialClauseChanges,
      icon: ShieldAlert,
      color: stats.materialClauseChanges > 0 ? 'text-[#dc2626]' : 'text-[#0052cc]',
      bgColor: stats.materialClauseChanges > 0 ? 'bg-red-50' : 'bg-blue-50',
      borderColor: stats.materialClauseChanges > 0 ? 'border-red-200' : 'border-blue-200',
      tag: aiAnalysesCount > 0 ? 'AI Evaluated' : 'Variance',
    },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-600 px-1">
        <span className="font-bold text-slate-900">
          Executive Comparison Statistics{' '}
          <span className="font-normal text-slate-500">
            ({stats.originalWordCount.toLocaleString()} vs {stats.revisedWordCount.toLocaleString()} words • {stats.similarityScore}% content similarity)
          </span>
        </span>
        <span className="text-[11px] text-slate-500 hidden sm:inline">
          Filter by clicking any category card
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
        {statItems.map((item) => {
          const Icon = item.icon;
          const isSelected = activeFilter === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onFilterClick(isSelected ? null : item.id)}
              className={`p-3.5 rounded-2xl border text-left transition relative cursor-pointer group shadow-xs ${
                isSelected
                  ? `${item.bgColor} ${item.borderColor} ring-2 ring-[#0052cc]`
                  : 'bg-white border-slate-200 hover:border-[#0052cc] hover:shadow-sm'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                  {item.tag}
                </span>
                <Icon className={`w-4 h-4 ${item.color}`} />
              </div>
              <div className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                {item.value}
              </div>
              <div className="text-[11px] font-bold text-slate-700 truncate mt-0.5">
                {item.label}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
