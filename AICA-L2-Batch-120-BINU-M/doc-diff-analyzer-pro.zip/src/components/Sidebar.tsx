import React, { useState, useMemo } from 'react';
import {
  FileText,
  Layers,
  Table,
  DollarSign,
  Calendar,
  Sparkles,
  Download,
  FileSearch,
  Shield,
  X,
  Bookmark,
  Check,
  Search,
  AlertTriangle,
  FolderOpen,
} from 'lucide-react';
import { ComparisonStats, DocumentSection } from '../types/diff';

export type ActiveSection =
  | 'workspace'
  | 'summary'
  | 'viewer'
  | 'register'
  | 'numerical'
  | 'dates'
  | 'ai-analysis';

interface SidebarProps {
  activeSection: ActiveSection;
  onSelectSection: (section: ActiveSection) => void;
  sections?: DocumentSection[];
  activeDocumentSectionId?: string | null;
  onSelectDocumentSection?: (section: DocumentSection) => void;
  ignoreCase?: boolean;
  onIgnoreCaseChange?: (val: boolean) => void;
  normalizeWhitespace?: boolean;
  onNormalizeWhitespaceChange?: (val: boolean) => void;
  onOpenExportModal: () => void;
  onOpenAIModal: () => void;
  stats: ComparisonStats | null;
  aiCount: number;
  originalFileName?: string;
  revisedFileName?: string;
  isOpenMobile: boolean;
  onToggleMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  sections = [],
  activeDocumentSectionId,
  onSelectDocumentSection,
  ignoreCase,
  onIgnoreCaseChange,
  normalizeWhitespace,
  onNormalizeWhitespaceChange,
  onOpenExportModal,
  onOpenAIModal,
  stats,
  aiCount,
  originalFileName,
  revisedFileName,
  isOpenMobile,
  onToggleMobile,
}) => {
  const [sectionFilter, setSectionFilter] = useState('');

  // Primary App Views
  const navItems = [
    {
      id: 'workspace' as ActiveSection,
      label: 'Document Workspace',
      icon: FileSearch,
      badge: originalFileName && revisedFileName ? '2 Files' : 'Inputs',
      badgeColor: 'bg-white/20 text-white',
    },
    {
      id: 'viewer' as ActiveSection,
      label: 'Side-by-Side Diff',
      icon: FileText,
      badge: stats ? `${stats.similarityScore}% match` : undefined,
      badgeColor: 'bg-emerald-500 text-white font-bold',
    },
    {
      id: 'register' as ActiveSection,
      label: 'Change Register',
      icon: Table,
      badge: stats ? `${stats.totalDetectedChanges}` : undefined,
      badgeColor: 'bg-white/20 text-white',
    },
    {
      id: 'numerical' as ActiveSection,
      label: 'Numerical Variance',
      icon: DollarSign,
      badge: stats && stats.changedAmounts > 0 ? `${stats.changedAmounts}` : undefined,
      badgeColor: 'bg-blue-300 text-blue-950 font-bold',
    },
    {
      id: 'dates' as ActiveSection,
      label: 'Dates & Deadlines',
      icon: Calendar,
      badge: stats && stats.changedDates > 0 ? `${stats.changedDates}` : undefined,
      badgeColor: 'bg-blue-200 text-blue-950 font-bold',
    },
    {
      id: 'ai-analysis' as ActiveSection,
      label: 'AI Clause Insights',
      icon: Sparkles,
      badge: aiCount > 0 ? `${aiCount} reviewed` : 'AI Review',
      badgeColor: 'bg-emerald-400 text-emerald-950 font-bold',
      isAi: true,
    },
  ];

  // Filtered Document Sections
  const filteredSections = useMemo(() => {
    if (!sectionFilter.trim()) return sections;
    const query = sectionFilter.toLowerCase();
    return sections.filter((s) => s.title.toLowerCase().includes(query));
  }, [sections, sectionFilter]);

  const totalDiffsInSections = useMemo(() => {
    return sections.reduce((acc, s) => acc + s.changeCount, 0);
  }, [sections]);

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between bg-gradient-to-b from-[#003875] via-[#004b99] to-[#002f6c] text-white w-76 select-none shadow-2xl border-r border-[#005bb5]">
      {/* Top Brand Header */}
      <div className="shrink-0">
        <div className="p-4 border-b border-white/15 flex items-center justify-between bg-black/10">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-white text-[#004b99] flex items-center justify-center font-bold shadow-md shrink-0">
              <FileText className="w-5 h-5 text-[#004b99]" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold tracking-tight text-white leading-tight">
                Doc Diff Analyzer
              </h2>
              <div className="flex items-center space-x-1.5 mt-0.5">
                <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded-full bg-white text-[#004b99]">
                  PRO
                </span>
                <span className="text-[11px] text-blue-100 font-medium">Enterprise Edition</span>
              </div>
            </div>
          </div>
          <button
            onClick={onToggleMobile}
            className="md:hidden p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Views Section */}
        <div className="p-3 pb-2 space-y-1 border-b border-white/10">
          <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-blue-200/90">
            Navigation Views
          </div>
          <div className="grid grid-cols-1 gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectSection(item.id);
                    if (item.id === 'ai-analysis' && stats) {
                      onOpenAIModal();
                    }
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition flex items-center justify-between group cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#004b99] font-bold shadow-md'
                      : 'text-white/90 hover:bg-white/15 hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    <div
                      className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 transition ${
                        isActive
                          ? 'bg-[#004b99] text-white shadow-2xs'
                          : item.isAi
                          ? 'bg-emerald-400 text-emerald-950 font-bold'
                          : 'bg-white/15 text-white'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-semibold truncate leading-tight">
                      {item.label}
                    </span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold shrink-0 ml-1 ${
                        isActive ? 'bg-[#004b99]/10 text-[#004b99]' : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* DOCUMENT SECTIONS & CLAUSES LIST — Visible without toggle */}
      <div className="flex-1 min-h-0 flex flex-col p-3 pt-2 overflow-hidden">
        <div className="flex items-center justify-between px-2 py-1 shrink-0">
          <div className="flex items-center space-x-1.5">
            <Bookmark className="w-3.5 h-3.5 text-blue-200" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-200">
              Document Sections
            </span>
          </div>
          {sections.length > 0 && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold bg-white/20 text-white">
              {sections.length} clauses
            </span>
          )}
        </div>

        {/* Section Search Bar if more than 3 sections */}
        {sections.length > 3 && (
          <div className="px-2 pt-1 pb-2 shrink-0">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-white/50" />
              <input
                type="text"
                placeholder="Search clauses..."
                value={sectionFilter}
                onChange={(e) => setSectionFilter(e.target.value)}
                className="w-full pl-8 pr-2 py-1 text-xs rounded-lg bg-black/20 border border-white/20 text-white placeholder-white/50 focus:outline-hidden focus:bg-black/30 focus:border-white/50 transition"
              />
              {sectionFilter && (
                <button
                  onClick={() => setSectionFilter('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-white/60 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Untoggled, Always-Visible Section List */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-1 text-xs">
          {sections.length > 0 ? (
            filteredSections.length > 0 ? (
              filteredSections.map((sec) => {
                const isSelected = activeDocumentSectionId === sec.id;
                const hasDiffs = sec.changeCount > 0;
                return (
                  <button
                    key={sec.id}
                    onClick={() => onSelectDocumentSection && onSelectDocumentSection(sec)}
                    title={sec.title}
                    className={`w-full text-left p-2 rounded-lg transition flex items-start justify-between gap-1.5 group cursor-pointer ${
                      isSelected
                        ? 'bg-white text-[#003875] font-bold shadow-md ring-2 ring-white/50'
                        : 'text-white/90 hover:bg-white/15 hover:text-white'
                    }`}
                  >
                    <div className="flex items-start space-x-2 min-w-0">
                      <span
                        className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                          hasDiffs ? 'bg-rose-400' : 'bg-emerald-400'
                        }`}
                      />
                      <div className="min-w-0">
                        <div
                          className={`text-xs truncate leading-snug ${
                            isSelected ? 'text-[#003875] font-bold' : 'text-white'
                          }`}
                        >
                          {sec.title}
                        </div>
                        <div className="flex items-center space-x-1.5 mt-0.5 text-[10px]">
                          {sec.hasAmountChange && (
                            <span
                              title="Contains monetary/number change"
                              className={`font-mono font-bold ${
                                isSelected ? 'text-blue-700' : 'text-amber-300'
                              }`}
                            >
                              $ amount
                            </span>
                          )}
                          {sec.hasDateChange && (
                            <span
                              title="Contains date or deadline change"
                              className={`font-medium ${
                                isSelected ? 'text-blue-600' : 'text-sky-200'
                              }`}
                            >
                              date/term
                            </span>
                          )}
                          {sec.hasHighRiskChange && (
                            <span
                              title="Material / High Risk clause modification"
                              className="text-rose-400 font-bold flex items-center"
                            >
                              <AlertTriangle className="w-2.5 h-2.5 mr-0.5" /> High Risk
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center space-x-1">
                      {hasDiffs ? (
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                            isSelected
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : 'bg-rose-500/25 text-rose-100 border-rose-400/40'
                          }`}
                        >
                          {sec.changeCount} {sec.changeCount === 1 ? 'diff' : 'diffs'}
                        </span>
                      ) : (
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-medium border flex items-center space-x-0.5 ${
                            isSelected
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : 'bg-emerald-500/25 text-emerald-100 border-emerald-400/40'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5" />
                          <span>0 diffs</span>
                        </span>
                      )}
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="text-center py-4 px-2 text-white/60 text-xs italic">
                No clauses match "{sectionFilter}"
              </div>
            )
          ) : (
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-center space-y-1.5 my-2">
              <FolderOpen className="w-5 h-5 text-white/50 mx-auto" />
              <div className="text-xs font-semibold text-white/90">
                Document Sections & Clauses
              </div>
              <p className="text-[11px] text-blue-100/70 leading-relaxed">
                Compare two documents to index articles, clauses, and sections here permanently for
                1-click jumping.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Configuration & Export Section */}
      <div className="p-3 border-t border-white/15 bg-black/15 space-y-2.5 shrink-0">
        {/* Export Reports Button */}
        <button
          onClick={onOpenExportModal}
          disabled={!stats}
          className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 border shadow-sm cursor-pointer ${
            stats
              ? 'bg-white text-[#004b99] border-white hover:bg-blue-50 active:scale-[0.99]'
              : 'bg-white/10 text-white/40 border-white/10 cursor-not-allowed'
          }`}
        >
          <Download className="w-4 h-4" />
          <span>Export Reports</span>
        </button>

        {/* Security / Confidentiality */}
        <div className="flex items-center justify-center space-x-1.5 text-[11px] text-blue-100 pt-0.5">
          <Shield className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
          <span>Confidential Session Security</span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Left Panel */}
      <aside className="hidden md:block shrink-0 sticky top-0 h-screen z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden bg-slate-900/60 backdrop-blur-xs flex">
          <div className="relative animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
          <div className="flex-1" onClick={onToggleMobile} />
        </div>
      )}
    </>
  );
};
