import React, { useRef, useState } from 'react';
import {
  UploadCloud,
  FileText,
  FileCheck,
  AlertCircle,
  X,
  Edit3,
  RefreshCw,
  AlertTriangle,
  ClipboardPaste,
} from 'lucide-react';
import { DocumentInputState } from '../types/diff';
import { parseUploadedFile, computeTextMetrics, MAX_FILE_SIZE_BYTES } from '../utils/documentParser';

interface DocumentInputPanelProps {
  title: 'Original Version' | 'Revised Version';
  badgeColor: 'sky' | 'emerald';
  state: DocumentInputState;
  onChange: (newState: DocumentInputState) => void;
  onClear: () => void;
  placeholderText: string;
}

export const DocumentInputPanel: React.FC<DocumentInputPanelProps> = ({
  title,
  badgeColor,
  state,
  onChange,
  onClear,
  placeholderText,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [activeTab, setActiveTab] = useState<'upload' | 'text'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelected = async (file: File) => {
    onChange({
      ...state,
      isLoading: true,
      error: null,
    });

    try {
      const result = await parseUploadedFile(file);
      onChange({
        text: result.text,
        fileName: result.fileName,
        fileSize: result.fileSize,
        charCount: result.charCount,
        wordCount: result.wordCount,
        lineCount: result.lineCount,
        fileType: result.fileType,
        isScannedPdfWithoutText: result.isScannedPdfWithoutText,
        isLoading: false,
        error: result.isScannedPdfWithoutText
          ? 'Scanned PDF detected with no extractable text layer. Optical Character Recognition (OCR) is required to process image-only documents.'
          : null,
      });
      setActiveTab('text');
    } catch (err: unknown) {
      const error = err as Error;
      onChange({
        ...state,
        isLoading: false,
        error: error.message || 'Failed to parse file.',
      });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleTextChange = (newText: string) => {
    const metrics = computeTextMetrics(newText);
    onChange({
      ...state,
      text: newText,
      charCount: metrics.charCount,
      wordCount: metrics.wordCount,
      lineCount: metrics.lineCount,
      error: null,
    });
  };

  const handlePasteClipboard = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (clipText) {
        handleTextChange(clipText);
        setActiveTab('text');
      }
    } catch {
      setActiveTab('text');
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const badgeClass =
    badgeColor === 'sky'
      ? 'bg-[#0071e3]/10 text-[#0071e3] border-[#0071e3]/20'
      : 'bg-[#059669]/10 text-[#059669] border-[#059669]/20';

  return (
    <div className="bg-white rounded-2xl border border-[#e5e7eb] shadow-sm flex flex-col h-full overflow-hidden transition-all duration-200">
      {/* Panel Header */}
      <div className="px-5 py-3.5 border-b border-[#f3f4f6] bg-[#fafafa] flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border tracking-wide ${badgeClass}`}>
            {title}
          </span>
          {state.fileName && (
            <span className="text-xs font-semibold text-[#1d1d1f] truncate max-w-[180px] sm:max-w-[240px]">
              {state.fileName}
            </span>
          )}
        </div>

        {/* View Switches & Clear */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-[#f0f0f2] p-0.5 rounded-lg text-xs">
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-2.5 py-1 rounded-md font-semibold transition ${
                activeTab === 'upload'
                  ? 'bg-white text-[#1d1d1f] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Upload
            </button>
            <button
              onClick={() => setActiveTab('text')}
              className={`px-2.5 py-1 rounded-md font-semibold transition ${
                activeTab === 'text'
                  ? 'bg-white text-[#1d1d1f] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Text Editor
            </button>
          </div>

          {(state.text.length > 0 || state.fileName) && (
            <button
              onClick={onClear}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
              title="Remove document and clear text"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Scanned PDF warning alert */}
      {state.isScannedPdfWithoutText && (
        <div className="bg-amber-50/80 border-b border-amber-200 p-3.5 flex items-start space-x-2 text-xs text-amber-900">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong className="font-bold">Scanned Document Notice:</strong> No extractable digital text was detected in this PDF.
            Doc Diff Analyzer Pro processes text-based layers. Flattened or image-only documents require Optical Character Recognition (OCR) before comparison.
          </div>
        </div>
      )}

      {/* Parsing error alert */}
      {state.error && !state.isScannedPdfWithoutText && (
        <div className="bg-rose-50 border-b border-rose-200 p-3.5 flex items-start space-x-2 text-xs text-rose-800">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">{state.error}</div>
          <button
            onClick={() => onChange({ ...state, error: null })}
            className="text-rose-500 hover:text-rose-800"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Body */}
      <div className="flex-1 flex flex-col min-h-[320px] relative">
        {state.isLoading && (
          <div className="absolute inset-0 bg-white/90 z-20 flex flex-col items-center justify-center space-y-2 backdrop-blur-2xs">
            <RefreshCw className="w-6 h-6 text-[#0071e3] animate-spin" />
            <span className="text-xs font-semibold text-slate-700">Extracting and parsing document...</span>
          </div>
        )}

        {activeTab === 'upload' ? (
          <div className="p-6 flex-1 flex flex-col justify-center">
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center space-y-3.5 ${
                isDragging
                  ? 'border-[#0071e3] bg-[#0071e3]/5 scale-[0.99]'
                  : 'border-slate-300 hover:border-[#0071e3] hover:bg-slate-50/60'
              }`}
            >
              <div className="w-14 h-14 rounded-2xl bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center shadow-2xs">
                <UploadCloud className="w-7 h-7" />
              </div>
              <div>
                <p className="text-sm font-bold text-[#1d1d1f]">
                  Drop real-life document here, or browse
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Supports <strong className="font-semibold text-slate-700">.docx, .pdf, .txt</strong> (up to 35 MB)
                </p>
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-[#0071e3] hover:bg-[#0077ed] text-white text-xs font-bold transition shadow-2xs cursor-pointer"
                >
                  Browse Files
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePasteClipboard();
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-semibold transition flex items-center space-x-1 cursor-pointer"
                >
                  <ClipboardPaste className="w-3.5 h-3.5 text-slate-500" />
                  <span>Paste Text</span>
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,.docx,.pdf,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelected(e.target.files[0]);
                  }
                }}
                className="hidden"
              />
            </div>

            {state.fileName && (
              <div className="mt-4 p-3.5 bg-[#fbfbfd] rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-2.5 truncate">
                  <FileCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="truncate">
                    <span className="text-xs font-bold text-slate-800 truncate block">
                      {state.fileName}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {formatFileSize(state.fileSize)} • {state.charCount.toLocaleString()} characters extracted
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('text')}
                  className="text-xs font-bold text-[#0071e3] hover:underline flex items-center space-x-1 ml-2 shrink-0"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Inspect text</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex flex-col p-3.5">
            <textarea
              value={state.text}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder={placeholderText}
              className="flex-1 w-full p-4 font-mono text-xs leading-relaxed text-slate-800 placeholder-slate-400 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0071e3]/20 focus:border-[#0071e3] resize-none transition"
              spellCheck="false"
            />
          </div>
        )}
      </div>

      {/* Footer Metrics */}
      <div className="px-5 py-2.5 border-t border-[#f3f4f6] bg-[#fafafa] text-[11px] text-slate-500 flex items-center justify-between font-medium">
        <div className="flex items-center space-x-4">
          <span>
            Words: <strong className="text-slate-800 font-bold">{state.wordCount.toLocaleString()}</strong>
          </span>
          <span>
            Chars: <strong className="text-slate-800 font-bold">{state.charCount.toLocaleString()}</strong>
          </span>
          <span>
            Lines: <strong className="text-slate-800 font-bold">{state.lineCount.toLocaleString()}</strong>
          </span>
        </div>
        <div>
          {state.fileSize > 0 && (
            <span className="text-slate-400 font-mono text-[10px]">
              {state.fileType} • {formatFileSize(state.fileSize)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
