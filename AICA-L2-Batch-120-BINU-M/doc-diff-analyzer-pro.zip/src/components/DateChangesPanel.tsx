import React from 'react';
import { Calendar, Clock, ArrowRight, Compass, AlertTriangle, Sparkles } from 'lucide-react';
import { DiffChange } from '../types/diff';

interface DateChangesPanelProps {
  changes: DiffChange[];
  activeChangeId: string | null;
  onSelectChange: (id: string) => void;
}

export const DateChangesPanel: React.FC<DateChangesPanelProps> = ({
  changes,
  activeChangeId,
  onSelectChange,
}) => {
  const dateChanges = changes.filter((c) => c.dateDetails);

  if (dateChanges.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center shadow-xs">
        <Calendar className="w-10 h-10 text-slate-300 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-slate-700">No Date or Deadline Alterations Detected</h4>
        <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
          No calendar dates, payment windows, renewal dates, notice periods, or timing covenants were altered.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-blue-50 text-[#0052cc] border border-blue-200">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-[#003875]">
              Dates, Deadlines & Timing Variations
            </h3>
            <p className="text-xs text-slate-500">
              Analysis of calendar milestones, renewal periods, business vs calendar days, and semantic shifts
            </p>
          </div>
        </div>
        <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-50 text-[#0052cc] border border-blue-200">
          {dateChanges.length} {dateChanges.length === 1 ? 'Timing Change' : 'Timing Changes'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {dateChanges.map((change) => {
          const date = change.dateDetails!;
          const isSelected = change.id === activeChangeId;

          return (
            <div
              key={change.id}
              onClick={() => onSelectChange(change.id)}
              className={`p-5 rounded-2xl border bg-white transition cursor-pointer relative shadow-xs flex flex-col justify-between ${
                isSelected
                  ? 'border-[#0052cc] ring-2 ring-[#0052cc]/20 shadow-md'
                  : 'border-slate-200 hover:border-[#0052cc] hover:shadow-sm'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-2.5 pb-2.5 border-b border-slate-100">
                  <span className="text-xs font-mono font-bold text-[#0052cc] bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    {change.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-600 truncate max-w-[160px]">
                    {change.section}
                  </span>
                </div>

                {/* Values Comparison: Red (Original) -> Green (Revised) */}
                <div className="grid grid-cols-5 items-center gap-2 mb-3.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div className="col-span-2 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Original
                    </span>
                    <span className="text-xs font-mono font-bold text-red-700 bg-red-50 px-2 py-1 rounded border border-red-200 line-through">
                      {date.originalRaw}
                    </span>
                  </div>

                  <div className="col-span-1 flex justify-center text-slate-400">
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>

                  <div className="col-span-2 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Revised
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded border border-emerald-300">
                      {date.revisedRaw}
                    </span>
                  </div>
                </div>

                {/* Details & Flags */}
                <div className="space-y-1.5 text-xs">
                  {date.durationDifferenceDays !== undefined && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600 font-medium">Duration Delta:</span>
                      <span className="font-mono font-extrabold text-[#0052cc] flex items-center space-x-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {date.durationDifferenceDays > 0
                            ? `+${date.durationDifferenceDays} days`
                            : `${date.durationDifferenceDays} days`}
                        </span>
                      </span>
                    </div>
                  )}

                  {date.dayType && date.dayType !== 'unspecified' && (
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Measurement:</span>
                      <span className="font-bold text-slate-700 capitalize">
                        {date.dayType.replace('_', ' ')}
                      </span>
                    </div>
                  )}

                  {date.semanticShift && (
                    <div className="p-2.5 bg-blue-50/70 rounded-xl text-[11px] text-[#003875] border border-blue-200">
                      <div className="font-bold flex items-center space-x-1 mb-0.5 text-[#0052cc]">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Semantic Covenant Shift</span>
                      </div>
                      <p className="leading-snug">{date.semanticShift}</p>
                    </div>
                  )}

                  {date.isAmbiguousDate && (
                    <div className="p-2 bg-red-50 rounded-lg text-[11px] text-red-900 border border-red-200 flex items-start space-x-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-red-600 mt-0.5" />
                      <span>Ambiguous slash date (DD/MM vs MM/DD); verify regional convention.</span>
                    </div>
                  )}

                  <p className="text-[11px] text-slate-600 pt-1.5 border-t border-slate-100">
                    {date.explanation}
                  </p>
                </div>
              </div>

              {/* Action */}
              <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex justify-end">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectChange(change.id);
                  }}
                  className="text-xs font-bold text-[#0052cc] hover:text-[#003875] flex items-center space-x-1"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Locate in Viewer</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
