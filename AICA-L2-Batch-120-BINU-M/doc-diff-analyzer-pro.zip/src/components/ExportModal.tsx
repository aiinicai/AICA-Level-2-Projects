import React from 'react';
import { Download, FileText, Table, FileCode, Printer, X, CheckCircle, Shield } from 'lucide-react';
import { ComparisonStats, DiffChange } from '../types/diff';
import {
  exportChangeRegisterToCSV,
  downloadMarkdownReport,
  openPrintableReport,
} from '../utils/exportUtils';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  changes: DiffChange[];
  stats: ComparisonStats;
  originalDocumentName: string;
  revisedDocumentName: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  changes,
  stats,
  originalDocumentName,
  revisedDocumentName,
}) => {
  if (!isOpen) return null;

  const handlePrintPdf = () => {
    openPrintableReport(changes, stats, originalDocumentName, revisedDocumentName);
  };

  const handleCsvExport = () => {
    exportChangeRegisterToCSV(changes, originalDocumentName, revisedDocumentName);
  };

  const handleMarkdownExport = () => {
    downloadMarkdownReport(changes, stats, originalDocumentName, revisedDocumentName);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-[#003875] text-white flex items-center justify-between border-b border-[#0052cc]">
          <div className="flex items-center space-x-2.5">
            <Download className="w-5 h-5 text-white" />
            <h3 className="text-base font-extrabold text-white">Export Comparison Reports</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            Select your desired report format. All exports are compiled from the deterministic comparison engine and include any active AI clause evaluations.
          </p>

          <div className="space-y-3">
            {/* PDF Report Option */}
            <div
              onClick={handlePrintPdf}
              className="p-4 rounded-xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/30 transition cursor-pointer flex items-start space-x-3 group"
            >
              <div className="p-2.5 rounded-lg bg-sky-100 text-sky-700 group-hover:bg-sky-600 group-hover:text-white transition">
                <Printer className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-800 group-hover:text-sky-700">
                    PDF Comparison Report
                  </h4>
                  <span className="text-[10px] font-semibold uppercase text-sky-600 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                    Printable
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Complete executive summary, side-by-side variance tables, numerical breakdowns, and formal review notices.
                </p>
              </div>
            </div>

            {/* CSV Register Option */}
            <div
              onClick={handleCsvExport}
              className="p-4 rounded-xl border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/30 transition cursor-pointer flex items-start space-x-3 group"
            >
              <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition">
                <Table className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-800 group-hover:text-emerald-700">
                    Excel-Compatible CSV Change Register
                  </h4>
                  <span className="text-[10px] font-semibold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Spreadsheet
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Tabular ledger of all {changes.length} changes with sanitized cells to prevent spreadsheet formula injection.
                </p>
              </div>
            </div>

            {/* Markdown Report Option */}
            <div
              onClick={handleMarkdownExport}
              className="p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30 transition cursor-pointer flex items-start space-x-3 group"
            >
              <div className="p-2.5 rounded-lg bg-indigo-100 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition">
                <FileCode className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-800 group-hover:text-indigo-700">
                    Markdown Summary Report (.md)
                  </h4>
                  <span className="text-[10px] font-semibold uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                    Text / Docs
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Clean GitHub-flavored markdown summary ideal for pasting into Jira, Notion, GitHub PRs, or legal briefs.
                </p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-500 flex items-center space-x-2">
            <Shield className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              All reports are generated locally in your browser. Document text is never logged or exposed.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-800 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
