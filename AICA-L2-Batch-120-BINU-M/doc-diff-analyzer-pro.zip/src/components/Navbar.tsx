import React from 'react';
import {
  FileText,
  Download,
  Sparkles,
  Menu,
  CheckCircle2,
} from 'lucide-react';

interface NavbarProps {
  onToggleMobileSidebar: () => void;
  onOpenExportModal: () => void;
  onTriggerAIAnalysis: () => void;
  hasComparison: boolean;
  similarityScore?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleMobileSidebar,
  onOpenExportModal,
  onTriggerAIAnalysis,
  hasComparison,
  similarityScore,
}) => {
  return (
    <header className="bg-white border-b border-slate-200 text-slate-900 sticky top-0 z-20 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Left: Mobile hamburger & title */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onToggleMobileSidebar}
              className="md:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer"
              aria-label="Toggle Navigation Sidebar"
            >
              <Menu className="w-5 h-5 text-[#0052cc]" />
            </button>

            <div className="flex items-center space-x-2.5">
              <span className="font-extrabold text-base tracking-tight text-[#003875]">
                Doc Diff Analyzer Pro
              </span>
              <span className="hidden sm:inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-[#0052cc] border border-blue-200">
                Variance & Risk Engine
              </span>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {hasComparison && similarityScore !== undefined && (
              <div className="hidden sm:flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{similarityScore}% Match</span>
              </div>
            )}

            {hasComparison && (
              <button
                onClick={onTriggerAIAnalysis}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-[#003875] bg-blue-50 hover:bg-blue-100 border border-blue-200 transition cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#0052cc]" />
                <span className="hidden sm:inline">AI Clause Analysis</span>
                <span className="sm:hidden">AI</span>
              </button>
            )}

            {hasComparison && (
              <button
                onClick={onOpenExportModal}
                className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-[#0052cc] hover:bg-[#0040a8] shadow-xs transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Export Report</span>
                <span className="sm:hidden">Export</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
