import React, { useRef, useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Columns,
  AlignLeft,
  Eye,
  EyeOff,
  Link,
  Sparkles,
  Info,
} from 'lucide-react';
import { DiffChange, DiffLine, DiffPart } from '../types/diff';

interface DiffViewerProps {
  lines: DiffLine[];
  changes: DiffChange[];
  activeChangeId: string | null;
  activeSectionId?: string | null;
  onSelectChange: (changeId: string) => void;
  originalFileName: string;
  revisedFileName: string;
}

export const DiffViewer: React.FC<DiffViewerProps> = ({
  lines,
  changes,
  activeChangeId,
  activeSectionId,
  onSelectChange,
  originalFileName,
  revisedFileName,
}) => {
  const [viewLayout, setViewLayout] = useState<'side-by-side' | 'unified'>('side-by-side');
  const [collapseUnchanged, setCollapseUnchanged] = useState<boolean>(false);
  const [syncScroll, setSyncScroll] = useState<boolean>(true);

  const leftScrollRef = useRef<HTMLDivElement>(null);
  const rightScrollRef = useRef<HTMLDivElement>(null);
  const unifiedScrollRef = useRef<HTMLDivElement>(null);
  const isSyncingScroll = useRef(false);

  // Active change index
  const activeChangeIndex = changes.findIndex((c) => c.id === activeChangeId);
  const currentNum = activeChangeIndex >= 0 ? activeChangeIndex + 1 : changes.length > 0 ? 1 : 0;

  // Handle Synchronized Scrolling
  const handleScrollLeft = () => {
    if (!syncScroll || isSyncingScroll.current || !rightScrollRef.current || !leftScrollRef.current) return;
    isSyncingScroll.current = true;
    rightScrollRef.current.scrollTop = leftScrollRef.current.scrollTop;
    rightScrollRef.current.scrollLeft = leftScrollRef.current.scrollLeft;
    requestAnimationFrame(() => {
      isSyncingScroll.current = false;
    });
  };

  const handleScrollRight = () => {
    if (!syncScroll || isSyncingScroll.current || !leftScrollRef.current || !rightScrollRef.current) return;
    isSyncingScroll.current = true;
    leftScrollRef.current.scrollTop = rightScrollRef.current.scrollTop;
    leftScrollRef.current.scrollLeft = rightScrollRef.current.scrollLeft;
    requestAnimationFrame(() => {
      isSyncingScroll.current = false;
    });
  };

  // Next / Prev navigation
  const handleNavigateNext = () => {
    if (changes.length === 0) return;
    const nextIdx = activeChangeIndex < changes.length - 1 ? activeChangeIndex + 1 : 0;
    const nextChange = changes[nextIdx];
    onSelectChange(nextChange.id);
    scrollToChange(nextChange.id);
  };

  const handleNavigatePrev = () => {
    if (changes.length === 0) return;
    const prevIdx = activeChangeIndex > 0 ? activeChangeIndex - 1 : changes.length - 1;
    const prevChange = changes[prevIdx];
    onSelectChange(prevChange.id);
    scrollToChange(prevChange.id);
  };

  const scrollToChange = (changeId: string) => {
    const el = document.getElementById(`diff-target-${changeId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Scroll into view whenever activeChangeId changes externally
  useEffect(() => {
    if (activeChangeId) {
      scrollToChange(activeChangeId);
    }
  }, [activeChangeId]);

  // Scroll into view whenever activeSectionId changes
  useEffect(() => {
    if (activeSectionId) {
      const el = document.getElementById(`doc-sec-${activeSectionId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [activeSectionId]);

  // Keyboard navigation shortcuts (P for prev, N for next)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only when not typing in an input/textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;
      if (e.key === 'n' || e.key === 'N') {
        handleNavigateNext();
      } else if (e.key === 'p' || e.key === 'P') {
        handleNavigatePrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeChangeIndex, changes]);

  // Filter lines if collapse unchanged is turned on
  const visibleLines = collapseUnchanged
    ? lines.filter((l, idx) => {
        // Keep lines with changes, or adjacent lines for context
        const hasChange = l.type !== 'unchanged';
        const prevHasChange = idx > 0 && lines[idx - 1].type !== 'unchanged';
        const nextHasChange = idx < lines.length - 1 && lines[idx + 1].type !== 'unchanged';
        return hasChange || prevHasChange || nextHasChange;
      })
    : lines;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm flex flex-col overflow-hidden">
      {/* Diff Viewer Control Bar */}
      <div className="px-5 py-3 bg-[#0b2447] text-white flex flex-wrap items-center justify-between gap-3 border-b border-[#1a4a82]">
        {/* Left: Change Navigation Counter */}
        <div className="flex items-center space-x-2.5">
          <div className="flex items-center bg-white/10 rounded-lg p-1 border border-white/15">
            <button
              onClick={handleNavigatePrev}
              disabled={changes.length === 0}
              className="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-700 transition disabled:opacity-40"
              title="Previous difference (Shortcut: P)"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 text-xs font-mono font-medium text-slate-200">
              {changes.length > 0 ? (
                <>
                  Change <strong className="text-sky-400">{currentNum}</strong> of {changes.length}
                </>
              ) : (
                'No Differences'
              )}
            </span>
            <button
              onClick={handleNavigateNext}
              disabled={changes.length === 0}
              className="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-700 transition disabled:opacity-40"
              title="Next difference (Shortcut: N)"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {activeChangeId && (
            <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">
              {activeChangeId}
            </span>
          )}
        </div>

        {/* Right: Layout & Display Options */}
        <div className="flex items-center space-x-2 text-xs">
          {/* Synchronized Scrolling Toggle */}
          {viewLayout === 'side-by-side' && (
            <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300 hover:text-white pr-2 border-r border-slate-800">
              <input
                type="checkbox"
                checked={syncScroll}
                onChange={(e) => setSyncScroll(e.target.checked)}
                className="rounded border-slate-700 text-sky-500 focus:ring-sky-500 bg-slate-800 w-3.5 h-3.5"
              />
              <span className="text-[11px]">Sync Scroll</span>
            </label>
          )}

          {/* Collapse unchanged text */}
          <button
            onClick={() => setCollapseUnchanged(!collapseUnchanged)}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded transition border ${
              collapseUnchanged
                ? 'bg-sky-600 border-sky-500 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
            }`}
            title="Focus exclusively on altered passages and nearby context"
          >
            {collapseUnchanged ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">
              {collapseUnchanged ? 'Showing Altered Passages' : 'Collapse Unchanged'}
            </span>
          </button>

          {/* View Mode Toggle: Side-by-Side vs Unified */}
          <div className="flex items-center bg-slate-800 rounded p-0.5 border border-slate-700">
            <button
              onClick={() => setViewLayout('side-by-side')}
              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-xs transition ${
                viewLayout === 'side-by-side'
                  ? 'bg-sky-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Side-by-Side</span>
            </button>
            <button
              onClick={() => setViewLayout('unified')}
              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-xs transition ${
                viewLayout === 'unified'
                  ? 'bg-sky-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <AlignLeft className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Unified Flow</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Diff Content Container */}
      {viewLayout === 'side-by-side' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200 min-h-[500px] max-h-[750px]">
          {/* Left Panel: Original Version */}
          <div className="flex flex-col h-full overflow-hidden bg-white">
            <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                <span>Original Version ({originalFileName || 'Document A'})</span>
              </span>
              <span className="text-[11px] font-normal text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                Red highlights = Deletions & Prior Wording
              </span>
            </div>

            <div
              ref={leftScrollRef}
              onScroll={handleScrollLeft}
              className="flex-1 p-4 font-mono text-xs leading-relaxed overflow-y-auto space-y-2 select-text"
            >
              {visibleLines.map((line, idx) => (
                <div
                  key={`orig-${idx}`}
                  id={
                    line.isSectionHeading && line.sectionId
                      ? `doc-sec-${line.sectionId}`
                      : line.changeId
                      ? `diff-target-${line.changeId}`
                      : undefined
                  }
                  className={`py-1 px-2 rounded transition ${
                    line.changeId && line.changeId === activeChangeId
                      ? 'ring-2 ring-sky-500 bg-sky-50/70 shadow-xs'
                      : ''
                  }`}
                >
                  {line.isSectionHeading && (
                    <div className="py-1 px-2.5 mb-2 rounded bg-blue-100/80 border border-blue-200 text-[#003875] font-sans font-extrabold text-xs flex items-center space-x-2">
                      <span className="bg-[#003875] text-white text-[9px] uppercase px-1.5 py-0.2 rounded font-bold">
                        Clause
                      </span>
                      <span className="truncate">{line.section || line.originalContent}</span>
                    </div>
                  )}
                  <div className="flex items-start space-x-3">
                    <span className="text-slate-400 text-[10px] w-7 shrink-0 text-right select-none pt-0.5 font-mono">
                      {line.lineNumOriginal || ''}
                    </span>
                    <div className="flex-1 whitespace-pre-wrap break-words">
                      {line.partsOriginal ? (
                        line.partsOriginal.map((part, pIdx) => renderOriginalPart(part, pIdx, activeChangeId, onSelectChange))
                      ) : (
                        <span className="text-slate-700">{line.originalContent || ' '}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel: Revised Version */}
          <div className="flex flex-col h-full overflow-hidden bg-white">
            <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Revised Version ({revisedFileName || 'Document B'})</span>
              </span>
              <span className="text-[11px] font-normal text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Green highlights = Additions & New Wording
              </span>
            </div>

            <div
              ref={rightScrollRef}
              onScroll={handleScrollRight}
              className="flex-1 p-4 font-mono text-xs leading-relaxed overflow-y-auto space-y-2 select-text"
            >
              {visibleLines.map((line, idx) => (
                <div
                  key={`rev-${idx}`}
                  id={
                    line.isSectionHeading && line.sectionId
                      ? `doc-sec-rev-${line.sectionId}`
                      : line.changeId
                      ? `diff-target-rev-${line.changeId}`
                      : undefined
                  }
                  className={`py-1 px-2 rounded transition ${
                    line.changeId && line.changeId === activeChangeId
                      ? 'ring-2 ring-sky-500 bg-sky-50/70 shadow-xs'
                      : ''
                  }`}
                >
                  {line.isSectionHeading && (
                    <div className="py-1 px-2.5 mb-2 rounded bg-blue-100/80 border border-blue-200 text-[#003875] font-sans font-extrabold text-xs flex items-center space-x-2">
                      <span className="bg-[#003875] text-white text-[9px] uppercase px-1.5 py-0.2 rounded font-bold">
                        Clause
                      </span>
                      <span className="truncate">{line.section || line.revisedContent}</span>
                    </div>
                  )}
                  <div className="flex items-start space-x-3">
                    <span className="text-slate-400 text-[10px] w-7 shrink-0 text-right select-none pt-0.5 font-mono">
                      {line.lineNumRevised || ''}
                    </span>
                    <div className="flex-1 whitespace-pre-wrap break-words">
                      {line.partsRevised ? (
                        line.partsRevised.map((part, pIdx) => renderRevisedPart(part, pIdx, activeChangeId, onSelectChange))
                      ) : (
                        <span className="text-slate-700">{line.revisedContent || ' '}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Unified View Layout */
        <div className="flex flex-col min-h-[500px] max-h-[750px] overflow-hidden bg-white">
          <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-between">
            <span>Unified Document Flow (Inline Changes)</span>
            <div className="flex items-center space-x-3 text-[11px]">
              <span className="inline-flex items-center space-x-1 text-rose-700">
                <span className="w-2.5 h-2.5 bg-rose-200 border border-rose-300 rounded-xs"></span>
                <span>Removed text</span>
              </span>
              <span className="inline-flex items-center space-x-1 text-emerald-700">
                <span className="w-2.5 h-2.5 bg-emerald-200 border border-emerald-300 rounded-xs"></span>
                <span>Added text</span>
              </span>
            </div>
          </div>

          <div
            ref={unifiedScrollRef}
            className="flex-1 p-4 font-mono text-xs leading-relaxed overflow-y-auto space-y-2 select-text"
          >
            {visibleLines.map((line, idx) => (
              <div
                key={`uni-${idx}`}
                id={
                  line.isSectionHeading && line.sectionId
                    ? `doc-sec-${line.sectionId}`
                    : line.changeId
                    ? `diff-target-${line.changeId}`
                    : undefined
                }
                className={`py-1 px-2 rounded transition ${
                  line.changeId && line.changeId === activeChangeId
                    ? 'ring-2 ring-sky-500 bg-sky-50/70 shadow-xs'
                    : ''
                }`}
              >
                {line.isSectionHeading && (
                  <div className="py-1 px-2.5 mb-2 rounded bg-blue-100/80 border border-blue-200 text-[#003875] font-sans font-extrabold text-xs flex items-center space-x-2">
                    <span className="bg-[#003875] text-white text-[9px] uppercase px-1.5 py-0.2 rounded font-bold">
                      Clause
                    </span>
                    <span className="truncate">
                      {line.section || line.originalContent || line.revisedContent}
                    </span>
                  </div>
                )}
                <div className="flex items-start space-x-3">
                  <div className="text-slate-400 text-[10px] w-14 shrink-0 text-right select-none pt-0.5 font-mono space-x-1">
                    <span>{line.lineNumOriginal || '-'}</span>
                    <span className="text-slate-300">/</span>
                    <span>{line.lineNumRevised || '-'}</span>
                  </div>
                  <div className="flex-1 whitespace-pre-wrap break-words">
                    {line.type === 'unchanged' && (
                      <span className="text-slate-700">{line.originalContent}</span>
                    )}
                    {line.type === 'modified' && (
                      <div className="space-y-1">
                        {line.partsOriginal && (
                          <div className="text-rose-900 bg-rose-50/50 p-1 rounded">
                            {line.partsOriginal.map((p, pIdx) =>
                              renderOriginalPart(p, pIdx, activeChangeId, onSelectChange)
                            )}
                          </div>
                        )}
                        {line.partsRevised && (
                          <div className="text-emerald-900 bg-emerald-50/50 p-1 rounded">
                            {line.partsRevised.map((p, pIdx) =>
                              renderRevisedPart(p, pIdx, activeChangeId, onSelectChange)
                            )}
                          </div>
                        )}
                      </div>
                    )}
                    {line.type === 'removed' && (
                      <span className="bg-rose-100 text-rose-900 line-through px-1 py-0.5 rounded">
                        {line.originalContent}
                      </span>
                    )}
                    {line.type === 'added' && (
                      <span className="bg-emerald-100 text-emerald-900 px-1 py-0.5 rounded">
                        {line.revisedContent}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

function renderOriginalPart(
  part: DiffPart,
  index: number,
  activeChangeId: string | null,
  onSelect: (id: string) => void
) {
  if (part.removed) {
    const isThisActive = part.changeId && part.changeId === activeChangeId;
    return (
      <mark
        key={`part-orig-${index}`}
        onClick={() => part.changeId && onSelect(part.changeId)}
        className={`bg-rose-100 text-rose-900 font-medium px-1 py-0.5 rounded border border-rose-300/80 cursor-pointer inline transition ${
          isThisActive ? 'ring-2 ring-sky-500 bg-rose-200' : 'hover:bg-rose-200'
        }`}
        title={part.changeId ? `Change ${part.changeId} (Click to inspect)` : 'Deleted text'}
      >
        <span className="line-through">{part.value}</span>
        {part.changeId && (
          <span className="ml-1 text-[9px] font-mono text-rose-700 bg-rose-200 px-1 py-0.2 rounded select-none">
            {part.changeId}
          </span>
        )}
      </mark>
    );
  }
  return (
    <span key={`part-orig-${index}`} className="text-slate-700">
      {part.value}
    </span>
  );
}

function renderRevisedPart(
  part: DiffPart,
  index: number,
  activeChangeId: string | null,
  onSelect: (id: string) => void
) {
  if (part.added) {
    const isThisActive = part.changeId && part.changeId === activeChangeId;
    return (
      <mark
        key={`part-rev-${index}`}
        onClick={() => part.changeId && onSelect(part.changeId)}
        className={`bg-emerald-100 text-emerald-900 font-medium px-1 py-0.5 rounded border border-emerald-300/80 cursor-pointer inline transition ${
          isThisActive ? 'ring-2 ring-sky-500 bg-emerald-200' : 'hover:bg-emerald-200'
        }`}
        title={part.changeId ? `Change ${part.changeId} (Click to inspect)` : 'Added text'}
      >
        <span>{part.value}</span>
        {part.changeId && (
          <span className="ml-1 text-[9px] font-mono text-emerald-800 bg-emerald-200 px-1 py-0.2 rounded select-none">
            {part.changeId}
          </span>
        )}
      </mark>
    );
  }
  return (
    <span key={`part-rev-${index}`} className="text-slate-700">
      {part.value}
    </span>
  );
}
