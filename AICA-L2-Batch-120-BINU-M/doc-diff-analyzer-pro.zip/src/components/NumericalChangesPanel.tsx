import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, ArrowRight, Compass, AlertCircle } from 'lucide-react';
import { DiffChange } from '../types/diff';

interface NumericalChangesPanelProps {
  changes: DiffChange[];
  activeChangeId: string | null;
  onSelectChange: (id: string) => void;
}

export const NumericalChangesPanel: React.FC<NumericalChangesPanelProps> = ({
  changes,
  activeChangeId,
  onSelectChange,
}) => {
  const numericalChanges = changes.filter((c) => c.numericalDetails);

  if (numericalChanges.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center shadow-xs">
        <DollarSign className="w-10 h-10 text-slate-300 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-slate-700">No Numerical Alterations Detected</h4>
        <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
          No financial amounts, fee percentages, interest rates, or quantities were modified between the compared documents.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-blue-50 text-[#0052cc] border border-blue-200">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-[#003875]">
              Numerical & Financial Variance Breakdown
            </h3>
            <p className="text-xs text-slate-500">
              Deterministic extraction of currencies (AED, USD, EUR, GBP), percentages, and arithmetic deltas
            </p>
          </div>
        </div>
        <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-50 text-[#0052cc] border border-blue-200">
          {numericalChanges.length} {numericalChanges.length === 1 ? 'Variance' : 'Variances'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {numericalChanges.map((change) => {
          const num = change.numericalDetails!;
          const isSelected = change.id === activeChangeId;
          const isIncrease = num.difference !== undefined && num.difference > 0;
          const isDecrease = num.difference !== undefined && num.difference < 0;

          return (
            <div
              key={change.id}
              onClick={() => onSelectChange(change.id)}
              className={`p-5 rounded-2xl border bg-white transition cursor-pointer relative shadow-xs flex flex-col justify-between ${
                isSelected
                  ? 'border-[#0052cc] ring-2 ring-[#0052cc]/20 shadow-md'
                  : 'border-slate-200 hover:border-[#0052cc] hover:shadow-sm'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-2.5 pb-2.5 border-b border-slate-100">
                  <span className="text-xs font-mono font-bold text-[#0052cc] bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    {change.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-600 truncate max-w-[160px]">
                    {change.section}
                  </span>
                </div>

                {/* Values Comparison: Red (Original) -> Green (Revised) */}
                <div className="grid grid-cols-5 items-center gap-2 mb-3.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div className="col-span-2 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Original
                    </span>
                    <span className="text-xs font-mono font-bold text-red-700 bg-red-50 px-2 py-1 rounded border border-red-200 line-through">
                      {num.originalRaw}
                    </span>
                  </div>

                  <div className="col-span-1 flex justify-center text-slate-400">
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>

                  <div className="col-span-2 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Revised
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded border border-emerald-300">
                      {num.revisedRaw}
                    </span>
                  </div>
                </div>

                {/* Computed Variance details in Blue */}
                <div className="space-y-1.5 text-xs">
                  {num.difference !== undefined && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600 font-medium">Calculated Difference:</span>
                      <span className="font-mono font-extrabold text-[#0052cc] flex items-center space-x-1">
                        {isIncrease && <TrendingUp className="w-3.5 h-3.5" />}
                        {isDecrease && <TrendingDown className="w-3.5 h-3.5" />}
                        <span>
                          {num.unit && `${num.unit} `}
                          {num.difference > 0 ? `+${num.difference.toLocaleString()}` : num.difference.toLocaleString()}
                          {num.isPercentagePoints && ' percentage points'}
                        </span>
                      </span>
                    </div>
                  )}

                  {num.relativeChangePercent !== undefined && (
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Relative Variation:</span>
                      <span className="font-mono font-bold text-slate-800">
                        {num.relativeChangePercent >= 0 ? `+${num.relativeChangePercent}%` : `${num.relativeChangePercent}%`}
                      </span>
                    </div>
                  )}

                  {num.uncertainMatch && (
                    <div className="flex items-start space-x-1.5 p-2 bg-blue-50 rounded-lg text-[11px] text-[#003875] border border-blue-200 mt-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0 text-[#0052cc] mt-0.5" />
                      <span>Currency conversion omitted between differing units.</span>
                    </div>
                  )}

                  <p className="text-[11px] text-slate-600 pt-1.5 border-t border-slate-100">
                    {num.explanation}
                  </p>
                </div>
              </div>

              {/* Action */}
              <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex justify-end">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectChange(change.id);
                  }}
                  className="text-xs font-bold text-[#0052cc] hover:text-[#003875] flex items-center space-x-1"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Locate in Viewer</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
