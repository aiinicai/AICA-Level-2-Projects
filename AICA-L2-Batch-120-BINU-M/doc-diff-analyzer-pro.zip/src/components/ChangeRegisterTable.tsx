import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Sparkles,
  Compass,
  AlertTriangle,
  Info,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { ChangeType, DiffChange, SignificanceLevel } from '../types/diff';

interface ChangeRegisterTableProps {
  changes: DiffChange[];
  activeChangeId: string | null;
  onSelectChange: (id: string) => void;
  onOpenAIAnalysisForChange?: (change: DiffChange) => void;
}

export const ChangeRegisterTable: React.FC<ChangeRegisterTableProps> = ({
  changes,
  activeChangeId,
  onSelectChange,
  onOpenAIAnalysisForChange,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [significanceFilter, setSignificanceFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'id' | 'type' | 'significance' | 'section'>('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);

  // Filtered and sorted list
  const filteredChanges = useMemo(() => {
    let result = [...changes];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (c) =>
          c.id.toLowerCase().includes(q) ||
          c.originalText.toLowerCase().includes(q) ||
          c.revisedText.toLowerCase().includes(q) ||
          c.section.toLowerCase().includes(q) ||
          c.aiAnalysis?.changeSummary.toLowerCase().includes(q) ||
          c.aiAnalysis?.practicalMeaning.toLowerCase().includes(q)
      );
    }

    // Type filter
    if (typeFilter !== 'all') {
      result = result.filter((c) => c.type === typeFilter);
    }

    // Significance filter
    if (significanceFilter !== 'all') {
      result = result.filter((c) => c.significance === significanceFilter);
    }

    // Sorting
    result.sort((a, b) => {
      let comparison = 0;
      if (sortField === 'id') {
        comparison = a.index - b.index;
      } else if (sortField === 'type') {
        comparison = a.type.localeCompare(b.type);
      } else if (sortField === 'section') {
        comparison = a.section.localeCompare(b.section);
      } else if (sortField === 'significance') {
        const priority: Record<SignificanceLevel, number> = {
          High: 4,
          Moderate: 3,
          Low: 2,
          Uncertain: 1,
          Informational: 0,
        };
        comparison = priority[b.significance] - priority[a.significance];
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [changes, searchQuery, typeFilter, significanceFilter, sortField, sortDirection]);

  const handleSort = (field: 'id' | 'type' | 'significance' | 'section') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSignificanceBadge = (level: SignificanceLevel) => {
    switch (level) {
      case 'High':
        return 'bg-red-50 text-red-700 border-red-300 font-bold';
      case 'Moderate':
        return 'bg-blue-50 text-[#0052cc] border-blue-200 font-semibold';
      case 'Low':
        return 'bg-slate-50 text-slate-700 border-slate-200';
      case 'Uncertain':
        return 'bg-blue-50 text-blue-900 border-blue-300';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getTypeBadge = (type: ChangeType) => {
    switch (type) {
      case 'amount':
        return 'bg-blue-50 text-[#0052cc] border-blue-200';
      case 'date':
        return 'bg-blue-50 text-[#003875] border-blue-200';
      case 'clause':
        return 'bg-blue-100 text-[#003875] border-blue-300 font-bold';
      case 'addition':
        return 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold';
      case 'deletion':
        return 'bg-red-50 text-red-800 border-red-300 font-bold';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm flex flex-col overflow-hidden">
      {/* Table Header & Filters */}
      <div className="p-5 border-b border-slate-200/80 bg-[#fafafa] space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Change Register & Audit Log</h3>
            <p className="text-xs text-slate-500">
              Filterable ledger of all detected alterations, numerical variances, and AI observations
            </p>
          </div>
          <div className="text-xs text-slate-500 font-medium">
            Showing <strong className="text-slate-800">{filteredChanges.length}</strong> of{' '}
            {changes.length} recorded differences
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
          {/* Text Search */}
          <div className="sm:col-span-1 lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search wording, sections, or AI notes..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
            />
          </div>

          {/* Type Filter */}
          <div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition font-medium text-slate-700"
            >
              <option value="all">All Change Types</option>
              <option value="addition">Additions</option>
              <option value="deletion">Deletions</option>
              <option value="modification">Wording Modifications</option>
              <option value="amount">Financial / Amounts</option>
              <option value="date">Dates & Deadlines</option>
              <option value="percentage">Percentages & Rates</option>
              <option value="clause">Material Clauses</option>
            </select>
          </div>

          {/* Significance Filter */}
          <div>
            <select
              value={significanceFilter}
              onChange={(e) => setSignificanceFilter(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition font-medium text-slate-700"
            >
              <option value="all">All Significance Levels</option>
              <option value="High">High Significance</option>
              <option value="Moderate">Moderate</option>
              <option value="Low">Low</option>
              <option value="Informational">Informational</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-100/80 text-slate-700 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider select-none">
              <th
                onClick={() => handleSort('id')}
                className="py-2.5 px-3 cursor-pointer hover:bg-slate-200/80 transition w-24"
              >
                <div className="flex items-center space-x-1">
                  <span>ID</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('type')}
                className="py-2.5 px-3 cursor-pointer hover:bg-slate-200/80 transition w-32"
              >
                <div className="flex items-center space-x-1">
                  <span>Type</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('significance')}
                className="py-2.5 px-3 cursor-pointer hover:bg-slate-200/80 transition w-28"
              >
                <div className="flex items-center space-x-1">
                  <span>Significance</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('section')}
                className="py-2.5 px-3 cursor-pointer hover:bg-slate-200/80 transition w-44"
              >
                <div className="flex items-center space-x-1">
                  <span>Location</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-2.5 px-3 min-w-[200px]">Original Text</th>
              <th className="py-2.5 px-3 min-w-[200px]">Revised Text</th>
              <th className="py-2.5 px-3 w-28 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredChanges.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  No differences match the current search filters.
                </td>
              </tr>
            ) : (
              filteredChanges.map((change) => {
                const isSelected = change.id === activeChangeId;
                const isExpanded = expandedRowId === change.id;

                return (
                  <React.Fragment key={change.id}>
                    <tr
                      onClick={() => onSelectChange(change.id)}
                      className={`hover:bg-slate-50 transition cursor-pointer ${
                        isSelected ? 'bg-sky-50/80 ring-1 ring-sky-300' : ''
                      }`}
                    >
                      {/* ID */}
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-800">
                        {change.id}
                      </td>

                      {/* Type */}
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border ${getTypeBadge(
                            change.type
                          )}`}
                        >
                          {change.type}
                        </span>
                      </td>

                      {/* Significance */}
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-medium border ${getSignificanceBadge(
                            change.significance
                          )}`}
                        >
                          {change.significance}
                        </span>
                      </td>

                      {/* Section */}
                      <td className="py-2.5 px-3 font-medium text-slate-600 truncate max-w-[170px]" title={change.section}>
                        {change.section}
                      </td>

                      {/* Original Text */}
                      <td className="py-2.5 px-3 font-mono text-[11px]">
                        {change.originalText ? (
                          <span className="bg-rose-50 text-rose-800 px-1.5 py-0.5 rounded line-through border border-rose-200/60 inline-block max-w-[280px] truncate" title={change.originalText}>
                            {change.originalText}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">(None / Added)</span>
                        )}
                      </td>

                      {/* Revised Text */}
                      <td className="py-2.5 px-3 font-mono text-[11px]">
                        {change.revisedText ? (
                          <span className="bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-200/60 inline-block max-w-[280px] truncate" title={change.revisedText}>
                            {change.revisedText}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">(Deleted)</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedRowId(isExpanded ? null : change.id);
                            }}
                            className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
                            title="Expand detailed explanation"
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectChange(change.id);
                            }}
                            className="p-1 rounded text-sky-600 hover:text-sky-800 hover:bg-sky-50 transition"
                            title="Jump to difference in Side-by-Side viewer"
                          >
                            <Compass className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>

                    {/* Expanded Detail Row */}
                    {isExpanded && (
                      <tr className="bg-slate-50/90 border-b border-slate-200">
                        <td colSpan={7} className="p-4">
                          <div className="space-y-3 bg-white p-4 rounded-lg border border-slate-200 text-xs shadow-2xs">
                            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                              <h4 className="font-bold text-slate-800 flex items-center space-x-2">
                                <span>Change Detail: {change.id}</span>
                                <span className="font-normal text-slate-500">in {change.section}</span>
                              </h4>
                              {change.aiAnalysis && (
                                <span className="flex items-center space-x-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 text-[11px] font-semibold">
                                  <Sparkles className="w-3 h-3 text-amber-500" />
                                  <span>AI Assessed Risk: {change.aiAnalysis.riskLevel}</span>
                                </span>
                              )}
                            </div>

                            {/* Full Text Snippets */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px]">
                              <div className="p-2.5 bg-rose-50/50 rounded border border-rose-100">
                                <span className="font-sans font-semibold text-rose-800 text-[10px] uppercase block mb-1">
                                  Original Text Wording:
                                </span>
                                <p className="text-rose-950 whitespace-pre-wrap">{change.originalText || '(None)'}</p>
                              </div>
                              <div className="p-2.5 bg-emerald-50/50 rounded border border-emerald-100">
                                <span className="font-sans font-semibold text-emerald-800 text-[10px] uppercase block mb-1">
                                  Revised Text Wording:
                                </span>
                                <p className="text-emerald-950 whitespace-pre-wrap">{change.revisedText || '(Deleted)'}</p>
                              </div>
                            </div>

                            {/* Numerical or Date explanation */}
                            {change.numericalDetails && (
                              <div className="p-2.5 bg-amber-50 rounded border border-amber-200 text-amber-900">
                                <strong>Numerical Variance:</strong> {change.numericalDetails.explanation}
                              </div>
                            )}

                            {change.dateDetails && (
                              <div className="p-2.5 bg-indigo-50 rounded border border-indigo-200 text-indigo-900">
                                <strong>Timing Variance:</strong> {change.dateDetails.explanation}
                              </div>
                            )}

                            {/* AI Clause Insights if available */}
                            {change.aiAnalysis ? (
                              <div className="p-3 bg-purple-50/60 rounded-lg border border-purple-200 space-y-2 text-purple-950">
                                <div className="font-semibold text-purple-900 flex items-center space-x-1.5">
                                  <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                                  <span>AI Clause Assessment</span>
                                </div>
                                <p><strong>Practical Meaning:</strong> {change.aiAnalysis.practicalMeaning}</p>
                                <p><strong>Potential Impact:</strong> {change.aiAnalysis.potentialImpact}</p>
                                <p><strong>Risk Rationale:</strong> {change.aiAnalysis.riskRationale}</p>
                                <div className="p-2 bg-white rounded border border-purple-200 text-[11px]">
                                  <strong>Follow-up Recommendation:</strong> {change.aiAnalysis.recommendedFollowUp}
                                </div>
                              </div>
                            ) : (
                              onOpenAIAnalysisForChange && (
                                <div className="flex justify-end pt-1">
                                  <button
                                    type="button"
                                    onClick={() => onOpenAIAnalysisForChange(change)}
                                    className="inline-flex items-center space-x-1 px-3 py-1 rounded text-xs font-semibold text-amber-800 bg-amber-100 hover:bg-amber-200 border border-amber-300 transition"
                                  >
                                    <Sparkles className="w-3 h-3 text-amber-600" />
                                    <span>Analyze This Change with Gemini AI</span>
                                  </button>
                                </div>
                              )
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
