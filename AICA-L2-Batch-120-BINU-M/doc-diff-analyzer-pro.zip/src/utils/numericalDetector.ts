import { NumericalChange } from '../types/diff';

// Currencies mapping and symbols
const CURRENCY_SYMBOLS: Record<string, string> = {
  $: 'USD',
  '€': 'EUR',
  '£': 'GBP',
  '¥': 'JPY',
  '₹': 'INR',
  AED: 'AED',
  USD: 'USD',
  EUR: 'EUR',
  GBP: 'GBP',
  CAD: 'CAD',
  AUD: 'AUD',
  CHF: 'CHF',
  SGD: 'SGD',
  SAR: 'SAR',
};

interface ExtractedNumberToken {
  raw: string;
  value: number;
  currency?: string;
  isPercentage: boolean;
  isDuration: boolean;
  durationUnit?: string;
  isDateOrPhoneOrRef: boolean;
  prefixContext: string;
  suffixContext: string;
}

function parseCleanNumber(str: string): number | null {
  // Remove thousand separators (commas or spaces between digits) and clean
  const cleaned = str.replace(/,/g, '').trim();
  const val = parseFloat(cleaned);
  return isNaN(val) ? null : val;
}

export function detectNumericalChangeInDiff(
  origText: string,
  revText: string,
  sourceContext: string
): NumericalChange | null {
  const origTokens = extractNumberTokens(origText);
  const revTokens = extractNumberTokens(revText);

  if (origTokens.length === 0 && revTokens.length === 0) {
    return null;
  }

  // If one side has a number and the other doesn't or has a different number
  if (origTokens.length === 1 && revTokens.length === 1) {
    const o = origTokens[0];
    const r = revTokens[0];

    // Check if both are dates or phone numbers
    if (o.isDateOrPhoneOrRef || r.isDateOrPhoneOrRef) {
      return null;
    }

    // Both are percentages
    if (o.isPercentage && r.isPercentage) {
      const diffPoints = +(r.value - o.value).toFixed(4);
      const relativeChange = o.value !== 0 ? +(((r.value - o.value) / o.value) * 100).toFixed(2) : undefined;
      return {
        originalRaw: o.raw,
        revisedRaw: r.raw,
        originalValue: o.value,
        revisedValue: r.value,
        difference: diffPoints,
        unit: '%',
        relativeChangePercent: relativeChange,
        isPercentagePoints: true,
        category: 'percentage',
        sourceContext,
        explanation: `Rate changed from ${o.raw} to ${r.raw} (${diffPoints >= 0 ? '+' : ''}${diffPoints} percentage points${
          relativeChange !== undefined ? `, ${relativeChange >= 0 ? '+' : ''}${relativeChange}% relative change` : ''
        })`,
      };
    }

    // Currencies
    if (o.currency || r.currency) {
      const curO = o.currency || r.currency;
      const curR = r.currency || o.currency;

      if (o.currency && r.currency && o.currency !== r.currency) {
        return {
          originalRaw: o.raw,
          revisedRaw: r.raw,
          originalValue: o.value,
          revisedValue: r.value,
          category: 'monetary',
          uncertainMatch: true,
          sourceContext,
          explanation: `Currency denomination changed from ${o.raw} to ${r.raw} (different currency units: ${o.currency} vs ${r.currency}; conversion calculation omitted).`,
        };
      }

      const diff = +(r.value - o.value).toFixed(2);
      const relative = o.value !== 0 ? +(((r.value - o.value) / o.value) * 100).toFixed(2) : undefined;
      const curDisplay = curO || curR || '';
      return {
        originalRaw: o.raw,
        revisedRaw: r.raw,
        originalValue: o.value,
        revisedValue: r.value,
        difference: diff,
        unit: curDisplay,
        relativeChangePercent: relative,
        isPercentagePoints: false,
        category: 'monetary',
        sourceContext,
        explanation: `Financial amount adjusted from ${o.raw} to ${r.raw} (Difference: ${curDisplay} ${diff >= 0 ? '+' : ''}${diff.toLocaleString()}${
          relative !== undefined ? ` / ${relative >= 0 ? '+' : ''}${relative}%` : ''
        })`,
      };
    }

    // Durations expressed numerically (e.g. 30 days vs 45 days)
    if (o.isDuration || r.isDuration) {
      const diff = r.value - o.value;
      const unit = o.durationUnit || r.durationUnit || 'units';
      return {
        originalRaw: o.raw,
        revisedRaw: r.raw,
        originalValue: o.value,
        revisedValue: r.value,
        difference: diff,
        unit,
        category: 'duration',
        sourceContext,
        explanation: `Duration altered from ${o.raw} to ${r.raw} (${diff >= 0 ? '+' : ''}${diff} ${unit})`,
      };
    }

    // General numbers / quantities / thresholds
    const diff = +(r.value - o.value).toFixed(2);
    const relative = o.value !== 0 ? +(((r.value - o.value) / o.value) * 100).toFixed(2) : undefined;
    return {
      originalRaw: o.raw,
      revisedRaw: r.raw,
      originalValue: o.value,
      revisedValue: r.value,
      difference: diff,
      relativeChangePercent: relative,
      category: 'quantity',
      sourceContext,
      explanation: `Value adjusted from ${o.raw} to ${r.raw} (Difference: ${diff >= 0 ? '+' : ''}${diff}${
        relative !== undefined ? ` / ${relative >= 0 ? '+' : ''}${relative}%` : ''
      })`,
    };
  }

  // If one side has a number and the other is new or removed
  if (origTokens.length > 0 && revTokens.length === 0) {
    const o = origTokens[0];
    return {
      originalRaw: o.raw,
      revisedRaw: '(removed)',
      originalValue: o.value,
      category: o.isPercentage ? 'percentage' : o.currency ? 'monetary' : 'quantity',
      sourceContext,
      explanation: `Numerical specification removed: previously ${o.raw}`,
    };
  }

  if (origTokens.length === 0 && revTokens.length > 0) {
    const r = revTokens[0];
    return {
      originalRaw: '(none)',
      revisedRaw: r.raw,
      revisedValue: r.value,
      category: r.isPercentage ? 'percentage' : r.currency ? 'monetary' : 'quantity',
      sourceContext,
      explanation: `New numerical specification introduced: ${r.raw}`,
    };
  }

  return null;
}

function extractNumberTokens(text: string): ExtractedNumberToken[] {
  const tokens: ExtractedNumberToken[] = [];
  if (!text) return tokens;

  // Pattern 1: Monetary with currency symbol or code (e.g., $50,000, AED 65,000, 10,000 USD, € 12.50)
  const currencyRegex =
    /(?:(AED|USD|EUR|GBP|CAD|AUD|CHF|SGD|SAR|\$|€|£|¥|₹)\s*(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)\s*(k|m|million|billion|thousand)?)|(?:(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)\s*(k|m|million|billion|thousand)?\s*(AED|USD|EUR|GBP|CAD|AUD|CHF|SGD|SAR|\$|€|£|¥|₹))/gi;

  let match: RegExpExecArray | null;
  while ((match = currencyRegex.exec(text)) !== null) {
    const rawMatch = match[0];
    const prefixCur = match[1];
    const numPart1 = match[2];
    const mult1 = match[3];

    const numPart2 = match[4];
    const mult2 = match[5];
    const suffixCur = match[6];

    const cur = (prefixCur || suffixCur || '').toUpperCase();
    const numStr = numPart1 || numPart2 || '';
    const mult = (mult1 || mult2 || '').toLowerCase();

    let val = parseCleanNumber(numStr);
    if (val !== null) {
      if (mult === 'k' || mult === 'thousand') val *= 1000;
      if (mult === 'm' || mult === 'million') val *= 1000000;
      if (mult === 'billion') val *= 1000000000;

      tokens.push({
        raw: rawMatch.trim(),
        value: val,
        currency: CURRENCY_SYMBOLS[cur] || cur,
        isPercentage: false,
        isDuration: false,
        isDateOrPhoneOrRef: false,
        prefixContext: text.substring(Math.max(0, match.index - 20), match.index),
        suffixContext: text.substring(match.index + rawMatch.length, match.index + rawMatch.length + 20),
      });
    }
  }

  // Pattern 2: Percentages (e.g. 5%, 8.25 percent, 12.5 %)
  const percentRegex = /(\d+(?:\.\d+)?)\s*(%|percent|percentage points)/gi;
  while ((match = percentRegex.exec(text)) !== null) {
    const val = parseFloat(match[1]);
    if (!isNaN(val)) {
      tokens.push({
        raw: match[0].trim(),
        value: val,
        isPercentage: true,
        isDuration: false,
        isDateOrPhoneOrRef: false,
        prefixContext: text.substring(Math.max(0, match.index - 20), match.index),
        suffixContext: text.substring(match.index + match[0].length, match.index + match[0].length + 20),
      });
    }
  }

  // Pattern 3: Durations with number (e.g. 30 days, 45 calendar days, 14 business days, 12 months, 3 years)
  const durationRegex =
    /(\d+)\s*(calendar\s*days?|business\s*days?|working\s*days?|days?|months?|years?|weeks?|hours?)/gi;
  while ((match = durationRegex.exec(text)) !== null) {
    const val = parseInt(match[1], 10);
    const unit = match[2].toLowerCase();
    tokens.push({
      raw: match[0].trim(),
      value: val,
      isPercentage: false,
      isDuration: true,
      durationUnit: unit,
      isDateOrPhoneOrRef: false,
      prefixContext: text.substring(Math.max(0, match.index - 20), match.index),
      suffixContext: text.substring(match.index + match[0].length, match.index + match[0].length + 20),
    });
  }

  // Pattern 4: Raw numbers that are not already captured
  const rawNumRegex = /\b\d{1,3}(?:,\d{3})*(?:\.\d+)?\b/g;
  while ((match = rawNumRegex.exec(text)) !== null) {
    const rawVal = match[0];
    const startIndex = match.index;
    const endIndex = startIndex + rawVal.length;

    // Check if this position was already included in a currency/percentage/duration match
    const alreadyCaptured = tokens.some(
      (t) => text.indexOf(t.raw) <= startIndex && text.indexOf(t.raw) + t.raw.length >= endIndex
    );

    if (!alreadyCaptured) {
      const val = parseCleanNumber(rawVal);
      if (val !== null) {
        // Detect if this looks like a date component (e.g. year 2026, 2024, or clause number like 4.1.2)
        const surrounding = text.substring(Math.max(0, startIndex - 10), Math.min(text.length, endIndex + 10));
        const isDatePattern = /(?:19|20)\d{2}|(?:\d{1,2}\/\d{1,2}\/\d{2,4})|(?:clause|section|article|p\.)\s*\d+/i.test(
          surrounding
        );

        tokens.push({
          raw: rawVal,
          value: val,
          isPercentage: false,
          isDuration: false,
          isDateOrPhoneOrRef: isDatePattern,
          prefixContext: text.substring(Math.max(0, startIndex - 20), startIndex),
          suffixContext: text.substring(endIndex, Math.min(text.length, endIndex + 20)),
        });
      }
    }
  }

  return tokens;
}
