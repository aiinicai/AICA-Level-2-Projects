import { DateChange } from '../types/diff';

const MONTH_NAMES: Record<string, number> = {
  january: 1,
  february: 2,
  march: 3,
  april: 4,
  may: 5,
  june: 6,
  july: 7,
  august: 8,
  september: 9,
  october: 10,
  november: 11,
  december: 12,
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  jun: 6,
  jul: 7,
  aug: 8,
  sep: 9,
  sept: 9,
  oct: 10,
  nov: 11,
  dec: 12,
};

interface ExtractedDateToken {
  raw: string;
  isCalendarDate: boolean;
  isDuration: boolean;
  durationDays?: number;
  dayType: 'calendar_days' | 'business_days' | 'unspecified';
  isAmbiguous: boolean;
  parsedDate?: Date;
  semanticModifier?: string; // 'before', 'on or before', 'within', 'by', etc.
}

export function detectDateChangeInDiff(
  origText: string,
  revText: string,
  sourceContext: string
): DateChange | null {
  const origTokens = extractDateTokens(origText);
  const revTokens = extractDateTokens(revText);

  // Check semantic deadline shifts even if numbers are similar
  const semanticShift = checkSemanticShift(origText, revText, sourceContext);

  if (origTokens.length === 0 && revTokens.length === 0 && !semanticShift) {
    return null;
  }

  if (origTokens.length >= 1 && revTokens.length >= 1) {
    const o = origTokens[0];
    const r = revTokens[0];

    // Check duration comparison (e.g. 30 days vs 45 days)
    if (o.isDuration && r.isDuration) {
      const diff = (r.durationDays ?? 0) - (o.durationDays ?? 0);
      const dayTypeNote =
        o.dayType !== r.dayType
          ? ` (Note: changed day type from ${o.dayType.replace('_', ' ')} to ${r.dayType.replace('_', ' ')})`
          : '';
      return {
        originalRaw: o.raw,
        revisedRaw: r.raw,
        durationDifferenceDays: diff,
        dayType: r.dayType,
        semanticShift: semanticShift || undefined,
        sourceContext,
        explanation: `Deadline duration changed from ${o.raw} to ${r.raw} (${diff >= 0 ? '+' : ''}${diff} days${dayTypeNote})${
          semanticShift ? ` [Semantic change: ${semanticShift}]` : ''
        }`,
      };
    }

    // Calendar dates comparison
    if (o.isCalendarDate || r.isCalendarDate) {
      const isAmbiguous = o.isAmbiguous || r.isAmbiguous;
      let dayDiff: number | undefined = undefined;

      if (o.parsedDate && r.parsedDate && !isNaN(o.parsedDate.getTime()) && !isNaN(r.parsedDate.getTime())) {
        const diffTime = r.parsedDate.getTime() - o.parsedDate.getTime();
        dayDiff = Math.round(diffTime / (1000 * 60 * 60 * 24));
      }

      const diffNote = dayDiff !== undefined ? ` (${dayDiff >= 0 ? '+' : ''}${dayDiff} days delta)` : '';
      const ambigNote = isAmbiguous
        ? ' [Warning: ambiguous slash date format e.g. DD/MM vs MM/DD; verify regional convention]'
        : '';

      return {
        originalRaw: o.raw,
        revisedRaw: r.raw,
        originalDateStr: o.raw,
        revisedDateStr: r.raw,
        durationDifferenceDays: dayDiff,
        isAmbiguousDate: isAmbiguous,
        semanticShift: semanticShift || undefined,
        sourceContext,
        explanation: `Specified date changed from "${o.raw}" to "${r.raw}"${diffNote}${ambigNote}${
          semanticShift ? ` [${semanticShift}]` : ''
        }`,
      };
    }
  }

  if (semanticShift) {
    return {
      originalRaw: origText.trim() || '(none)',
      revisedRaw: revText.trim() || '(none)',
      semanticShift,
      sourceContext,
      explanation: `Semantic deadline or renewal condition modified: ${semanticShift}`,
    };
  }

  if (origTokens.length > 0 && revTokens.length === 0) {
    return {
      originalRaw: origTokens[0].raw,
      revisedRaw: '(removed)',
      sourceContext,
      explanation: `Date / deadline reference removed: previously "${origTokens[0].raw}"`,
    };
  }

  if (origTokens.length === 0 && revTokens.length > 0) {
    return {
      originalRaw: '(none)',
      revisedRaw: revTokens[0].raw,
      sourceContext,
      explanation: `New date / deadline stipulation added: "${revTokens[0].raw}"`,
    };
  }

  return null;
}

function checkSemanticShift(origText: string, revText: string, sourceContext: string = ''): string | null {
  const o = origText.toLowerCase();
  const r = revText.toLowerCase();
  const ctx = sourceContext.toLowerCase();

  // "shall renew" vs "may renew"
  if (
    (o.includes('shall renew') && r.includes('may renew')) ||
    (o.includes('shall') && r.includes('may') && ctx.includes('renew'))
  ) {
    return 'Renewal converted from mandatory ("shall renew") to discretionary ("may renew")';
  }
  if (
    (o.includes('may renew') && r.includes('shall renew')) ||
    (o.includes('may') && r.includes('shall') && ctx.includes('renew'))
  ) {
    return 'Renewal converted from discretionary ("may renew") to mandatory ("shall renew")';
  }

  // "before" vs "on or before"
  if (o.includes('before') && !o.includes('on or before') && r.includes('on or before')) {
    return 'Deadline condition expanded from strict "before" to inclusive "on or before"';
  }
  if (o.includes('on or before') && r.includes('before') && !r.includes('on or before')) {
    return 'Deadline condition contracted from inclusive "on or before" to strict "before"';
  }

  // "automatic renewal" vs "mutual agreement"
  if (o.includes('automatically') && (r.includes('prior written consent') || r.includes('mutual agreement'))) {
    return 'Automatic renewal replaced with requirement for mutual written consent';
  }

  // "within X calendar days" vs "within X business days"
  if (o.includes('calendar days') && r.includes('business days')) {
    return 'Timing changed from calendar days to business days (extends effective working window)';
  }
  if (o.includes('business days') && r.includes('calendar days')) {
    return 'Timing changed from business days to calendar days (tightens effective working window)';
  }

  // "immediately" vs "promptly" or time period
  if (o.includes('immediately') && (r.includes('within') || r.includes('promptly') || r.includes('reasonable time'))) {
    return 'Strict immediate performance relaxed to defined period or reasonable time';
  }

  return null;
}

function extractDateTokens(text: string): ExtractedDateToken[] {
  const tokens: ExtractedDateToken[] = [];
  if (!text) return tokens;

  // 1. Durations (e.g., "within 30 days", "45 calendar days", "14 business days", "24 months")
  const durationPattern =
    /\b(\d+)\s*(calendar\s+days?|business\s+days?|working\s+days?|days?|months?|years?|weeks?)\b/gi;
  let match: RegExpExecArray | null;
  while ((match = durationPattern.exec(text)) !== null) {
    const count = parseInt(match[1], 10);
    const unit = match[2].toLowerCase();
    let dayType: 'calendar_days' | 'business_days' | 'unspecified' = 'unspecified';
    let durationDays = count;

    if (unit.includes('business') || unit.includes('working')) {
      dayType = 'business_days';
    } else if (unit.includes('calendar')) {
      dayType = 'calendar_days';
    }

    if (unit.includes('month')) {
      durationDays = count * 30;
    } else if (unit.includes('year')) {
      durationDays = count * 365;
    } else if (unit.includes('week')) {
      durationDays = count * 7;
    }

    tokens.push({
      raw: match[0],
      isCalendarDate: false,
      isDuration: true,
      durationDays,
      dayType,
      isAmbiguous: false,
    });
  }

  // 2. Written calendar dates: "15 January 2026", "January 15, 2026", "30th of June 2025", "30 June"
  const writtenDatePattern =
    /\b(\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\s*,?\s*(\d{4})?)|((january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2}(?:st|nd|rd|th)?\s*,?\s*(\d{4})?)\b/gi;

  while ((match = writtenDatePattern.exec(text)) !== null) {
    const raw = match[0];
    const parsed = new Date(raw.replace(/(st|nd|rd|th|of)/gi, ''));
    tokens.push({
      raw,
      isCalendarDate: true,
      isDuration: false,
      dayType: 'calendar_days',
      isAmbiguous: false,
      parsedDate: !isNaN(parsed.getTime()) ? parsed : undefined,
    });
  }

  // 3. Slash or dash dates: 2026-05-30 (ISO), 03/04/2026 (potentially ambiguous)
  const numericDatePattern = /\b(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b/g;
  while ((match = numericDatePattern.exec(text)) !== null) {
    const raw = match[0];
    const parts = raw.split(/[-/]/);
    let isAmbiguous = false;
    let parsedDate: Date | undefined;

    if (parts.length === 3) {
      if (parts[0].length === 4) {
        // ISO format YYYY-MM-DD
        parsedDate = new Date(`${parts[0]}-${parts[1]}-${parts[2]}`);
      } else {
        // DD/MM/YYYY or MM/DD/YYYY
        const p1 = parseInt(parts[0], 10);
        const p2 = parseInt(parts[1], 10);
        if (p1 <= 12 && p2 <= 12 && p1 !== p2) {
          isAmbiguous = true;
        }
        parsedDate = new Date(raw);
      }
    }

    tokens.push({
      raw,
      isCalendarDate: true,
      isDuration: false,
      dayType: 'calendar_days',
      isAmbiguous,
      parsedDate: parsedDate && !isNaN(parsedDate.getTime()) ? parsedDate : undefined,
    });
  }

  return tokens;
}
