import { ComparisonStats, DiffChange } from '../types/diff';

/**
 * Escapes CSV values and neutralizes spreadsheet formula injection risks.
 * Cells starting with =, +, -, @, \t, or \r are prefixed with a single quote (').
 */
function sanitizeCsvCell(value: unknown): string {
  if (value === null || value === undefined) return '""';
  let str = String(value);

  // CSV Formula injection prevention
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }

  // Escape double quotes by doubling them
  str = str.replace(/"/g, '""');

  return `"${str}"`;
}

export function exportChangeRegisterToCSV(
  changes: DiffChange[],
  originalName: string,
  revisedName: string
): void {
  const headers = [
    'Change ID',
    'Type',
    'Significance',
    'Location / Section',
    'Original Text',
    'Revised Text',
    'Numerical / Date Detail',
    'AI Summary',
    'AI Practical Meaning',
    'AI Risk Level',
    'AI Recommended Follow-up',
  ];

  const rows = changes.map((c) => {
    const numOrDateDetail = c.numericalDetails
      ? c.numericalDetails.explanation
      : c.dateDetails
      ? c.dateDetails.explanation
      : '';

    return [
      sanitizeCsvCell(c.id),
      sanitizeCsvCell(c.type.toUpperCase()),
      sanitizeCsvCell(c.significance),
      sanitizeCsvCell(c.section),
      sanitizeCsvCell(c.originalText),
      sanitizeCsvCell(c.revisedText),
      sanitizeCsvCell(numOrDateDetail),
      sanitizeCsvCell(c.aiAnalysis?.changeSummary || ''),
      sanitizeCsvCell(c.aiAnalysis?.practicalMeaning || ''),
      sanitizeCsvCell(c.aiAnalysis?.riskLevel || ''),
      sanitizeCsvCell(c.aiAnalysis?.recommendedFollowUp || ''),
    ].join(',');
  });

  const csvContent =
    `# Doc Diff Analyzer Pro - Change Register Export\n` +
    `# Original: ${originalName}\n` +
    `# Revised: ${revisedName}\n` +
    `# Generated: ${new Date().toISOString()}\n\n` +
    headers.map((h) => `"${h}"`).join(',') +
    '\n' +
    rows.join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Diff_Change_Register_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function generateMarkdownReport(
  changes: DiffChange[],
  stats: ComparisonStats,
  originalName: string,
  revisedName: string
): string {
  const dateStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  let md = `# Doc Diff Analyzer Pro — Document Comparison Report\n\n`;
  md += `**Date of Comparison:** ${dateStr}  \n`;
  md += `**Original Document:** ${originalName} (${stats.originalWordCount.toLocaleString()} words)  \n`;
  md += `**Revised Document:** ${revisedName} (${stats.revisedWordCount.toLocaleString()} words)  \n`;
  md += `**Content Similarity Score:** ${stats.similarityScore}%  \n\n`;

  md += `## 1. Executive Summary & Statistics\n\n`;
  md += `| Metric | Count |\n`;
  md += `| :--- | :--- |\n`;
  md += `| Total Detected Differences | **${stats.totalDetectedChanges}** |\n`;
  md += `| Additions | **${stats.totalAdditions}** |\n`;
  md += `| Deletions | **${stats.totalDeletions}** |\n`;
  md += `| Modified Wording Segments | **${stats.modifiedSegments}** |\n`;
  md += `| Changed Financial Amounts & Numbers | **${stats.changedAmounts}** |\n`;
  md += `| Changed Dates & Deadlines | **${stats.changedDates}** |\n`;
  md += `| Potentially Material Clause Changes | **${stats.materialClauseChanges}** |\n\n`;

  md += `## 2. Key Numerical & Financial Alterations\n\n`;
  const numChanges = changes.filter((c) => c.numericalDetails);
  if (numChanges.length === 0) {
    md += `*No financial amount or numerical alterations detected.*\n\n`;
  } else {
    numChanges.forEach((c) => {
      md += `- **[${c.id}] ${c.section}**: ${c.numericalDetails?.explanation}\n`;
      md += `  - *Original*: \`${c.originalText || '(none)'}\`\n`;
      md += `  - *Revised*: \`${c.revisedText || '(none)'}\`\n`;
    });
    md += `\n`;
  }

  md += `## 3. Dates, Deadlines & Timing Alterations\n\n`;
  const dateChanges = changes.filter((c) => c.dateDetails);
  if (dateChanges.length === 0) {
    md += `*No date, deadline, or duration alterations detected.*\n\n`;
  } else {
    dateChanges.forEach((c) => {
      md += `- **[${c.id}] ${c.section}**: ${c.dateDetails?.explanation}\n`;
      md += `  - *Original*: \`${c.originalText || '(none)'}\`\n`;
      md += `  - *Revised*: \`${c.revisedText || '(none)'}\`\n`;
    });
    md += `\n`;
  }

  md += `## 4. Complete Change Register\n\n`;
  changes.forEach((c) => {
    md += `### Change ${c.id}: ${c.type.toUpperCase()} (${c.significance} Significance)\n`;
    md += `- **Location**: ${c.section}\n`;
    md += `- **Original Text**:\n  > ${c.originalText || '*(None / Inserted)*'}\n`;
    md += `- **Revised Text**:\n  > ${c.revisedText || '*(None / Deleted)*'}\n`;

    if (c.aiAnalysis) {
      md += `- **AI Clause Assessment**:\n`;
      md += `  - **Summary**: ${c.aiAnalysis.changeSummary}\n`;
      md += `  - **Practical Meaning**: ${c.aiAnalysis.practicalMeaning}\n`;
      md += `  - **Potential Impact**: ${c.aiAnalysis.potentialImpact}\n`;
      md += `  - **Assessed Risk**: **${c.aiAnalysis.riskLevel}** (${c.aiAnalysis.riskRationale})\n`;
      md += `  - **Recommended Action**: ${c.aiAnalysis.recommendedFollowUp}\n`;
    }
    md += `\n---\n\n`;
  });

  md += `## 5. Review Limitations & Disclaimer\n\n`;
  md += `> **NOTICE**: This report is produced by Doc Diff Analyzer Pro as an automated document-processing aid for human reviewers. Deterministic comparison algorithms capture textual variations, while AI observations provide preliminary semantic interpretations. This report does not constitute formal legal advice, guarantee enforceability, or replace review by qualified legal counsel.\n`;

  return md;
}

export function downloadMarkdownReport(
  changes: DiffChange[],
  stats: ComparisonStats,
  originalName: string,
  revisedName: string
): void {
  const md = generateMarkdownReport(changes, stats, originalName, revisedName);
  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Diff_Report_${new Date().toISOString().slice(0, 10)}.md`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function openPrintableReport(
  changes: DiffChange[],
  stats: ComparisonStats,
  originalName: string,
  revisedName: string
): void {
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Please allow popups to open the printable PDF report.');
    return;
  }

  const dateStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const numChanges = changes.filter((c) => c.numericalDetails);
  const dateChanges = changes.filter((c) => c.dateDetails);
  const aiAnalyses = changes.filter((c) => c.aiAnalysis);

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Doc Diff Analyzer Pro — Comparison Report</title>
  <style>
    @page { size: A4; margin: 20mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      line-height: 1.5;
      font-size: 13px;
      margin: 0;
      padding: 24px;
    }
    .header {
      border-bottom: 2px solid #0284c7;
      padding-bottom: 12px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .header h1 { margin: 0; font-size: 22px; color: #0f172a; }
    .header .subtitle { color: #64748b; font-size: 12px; margin-top: 4px; }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      font-size: 11px;
      font-weight: 600;
      border-radius: 4px;
      text-transform: uppercase;
    }
    .badge-high { background: #fee2e2; color: #991b1b; }
    .badge-moderate { background: #fef3c7; color: #92400e; }
    .badge-low { background: #f1f5f9; color: #475569; }
    .meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 20px;
      background: #f8fafc;
      padding: 12px;
      border-radius: 6px;
      border: 1px solid #e2e8f0;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
      margin-bottom: 24px;
    }
    .stat-card {
      border: 1px solid #e2e8f0;
      padding: 10px;
      border-radius: 6px;
      background: #ffffff;
      text-align: center;
    }
    .stat-num { font-size: 20px; font-weight: 700; color: #0f172a; }
    .stat-label { font-size: 11px; color: #64748b; margin-top: 2px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 12px; }
    th, td { border: 1px solid #e2e8f0; padding: 8px 10px; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; color: #334155; font-weight: 600; }
    .del { background: #fee2e2; color: #991b1b; text-decoration: line-through; padding: 1px 4px; border-radius: 2px; }
    .ins { background: #dcfce7; color: #166534; padding: 1px 4px; border-radius: 2px; }
    .disclaimer {
      margin-top: 30px;
      padding: 12px;
      background: #f8fafc;
      border-left: 3px solid #94a3b8;
      font-size: 11px;
      color: #64748b;
    }
    @media print {
      body { padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 16px; display: flex; gap: 8px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0284c7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">Print / Save as PDF</button>
    <button onclick="window.close()" style="padding: 8px 16px; background: #e2e8f0; color: #334155; border: none; border-radius: 4px; cursor: pointer;">Close</button>
  </div>

  <div class="header">
    <div>
      <h1>Doc Diff Analyzer Pro</h1>
      <div class="subtitle">Official Document Comparison & Clause Variance Report</div>
    </div>
    <div style="text-align: right; font-size: 11px; color: #64748b;">
      Generated: ${dateStr}<br>
      Similarity: <strong>${stats.similarityScore}%</strong>
    </div>
  </div>

  <div class="meta-grid">
    <div>
      <strong>Original Version:</strong> ${escapeHtml(originalName)}<br>
      <span style="color:#64748b;">Word count: ${stats.originalWordCount.toLocaleString()} words</span>
    </div>
    <div>
      <strong>Revised Version:</strong> ${escapeHtml(revisedName)}<br>
      <span style="color:#64748b;">Word count: ${stats.revisedWordCount.toLocaleString()} words</span>
    </div>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-num">${stats.totalDetectedChanges}</div>
      <div class="stat-label">Total Differences</div>
    </div>
    <div class="stat-card">
      <div class="stat-num" style="color: #16a34a;">+${stats.totalAdditions}</div>
      <div class="stat-label">Additions</div>
    </div>
    <div class="stat-card">
      <div class="stat-num" style="color: #dc2626;">-${stats.totalDeletions}</div>
      <div class="stat-label">Deletions</div>
    </div>
    <div class="stat-card">
      <div class="stat-num" style="color: #d97706;">${stats.changedAmounts}</div>
      <div class="stat-label">Numerical Adjustments</div>
    </div>
  </div>

  ${
    numChanges.length > 0
      ? `
    <h3 style="margin-bottom: 8px; color: #0f172a;">Numerical & Financial Changes</h3>
    <table>
      <thead>
        <tr>
          <th style="width: 80px;">ID</th>
          <th style="width: 140px;">Location</th>
          <th>Original Value</th>
          <th>Revised Value</th>
          <th>Calculated Variance</th>
        </tr>
      </thead>
      <tbody>
        ${numChanges
          .map(
            (c) => `
          <tr>
            <td><strong>${c.id}</strong></td>
            <td>${escapeHtml(c.section)}</td>
            <td><span class="del">${escapeHtml(c.numericalDetails?.originalRaw || '-')}</span></td>
            <td><span class="ins">${escapeHtml(c.numericalDetails?.revisedRaw || '-')}</span></td>
            <td><strong>${escapeHtml(c.numericalDetails?.explanation || '')}</strong></td>
          </tr>
        `
          )
          .join('')}
      </tbody>
    </table>
  `
      : ''
  }

  ${
    dateChanges.length > 0
      ? `
    <h3 style="margin-bottom: 8px; color: #0f172a;">Dates, Deadlines & Timing Alterations</h3>
    <table>
      <thead>
        <tr>
          <th style="width: 80px;">ID</th>
          <th style="width: 140px;">Location</th>
          <th>Original Timing</th>
          <th>Revised Timing</th>
          <th>Analysis & Impact</th>
        </tr>
      </thead>
      <tbody>
        ${dateChanges
          .map(
            (c) => `
          <tr>
            <td><strong>${c.id}</strong></td>
            <td>${escapeHtml(c.section)}</td>
            <td><span class="del">${escapeHtml(c.dateDetails?.originalRaw || '-')}</span></td>
            <td><span class="ins">${escapeHtml(c.dateDetails?.revisedRaw || '-')}</span></td>
            <td><strong>${escapeHtml(c.dateDetails?.explanation || '')}</strong></td>
          </tr>
        `
          )
          .join('')}
      </tbody>
    </table>
  `
      : ''
  }

  <h3 style="margin-bottom: 8px; color: #0f172a;">Change Register</h3>
  <table>
    <thead>
      <tr>
        <th style="width: 75px;">ID</th>
        <th style="width: 100px;">Type</th>
        <th style="width: 90px;">Significance</th>
        <th style="width: 130px;">Section</th>
        <th>Original Wording</th>
        <th>Revised Wording</th>
      </tr>
    </thead>
    <tbody>
      ${changes
        .map(
          (c) => `
        <tr>
          <td><strong>${c.id}</strong></td>
          <td><span style="font-size: 10px; font-weight: bold; text-transform: uppercase;">${c.type}</span></td>
          <td><span class="badge ${
            c.significance === 'High'
              ? 'badge-high'
              : c.significance === 'Moderate'
              ? 'badge-moderate'
              : 'badge-low'
          }">${c.significance}</span></td>
          <td>${escapeHtml(c.section)}</td>
          <td>${c.originalText ? `<span class="del">${escapeHtml(c.originalText)}</span>` : '<em style="color:#94a3b8;">(None)</em>'}</td>
          <td>${c.revisedText ? `<span class="ins">${escapeHtml(c.revisedText)}</span>` : '<em style="color:#94a3b8;">(Deleted)</em>'}</td>
        </tr>
      `
        )
        .join('')}
    </tbody>
  </table>

  ${
    aiAnalyses.length > 0
      ? `
    <h3 style="margin-bottom: 8px; color: #0f172a;">AI Material Clause Analysis Observations</h3>
    ${aiAnalyses
      .map(
        (c) => `
      <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 12px; margin-bottom: 12px; background: #ffffff;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
          <strong>[${c.id}] ${escapeHtml(c.section)}: ${escapeHtml(c.aiAnalysis?.changeSummary || '')}</strong>
          <span class="badge ${
            c.aiAnalysis?.riskLevel === 'High'
              ? 'badge-high'
              : c.aiAnalysis?.riskLevel === 'Moderate'
              ? 'badge-moderate'
              : 'badge-low'
          }">Risk: ${c.aiAnalysis?.riskLevel}</span>
        </div>
        <div style="margin-bottom: 6px;"><strong>Practical Meaning:</strong> ${escapeHtml(c.aiAnalysis?.practicalMeaning || '')}</div>
        <div style="margin-bottom: 6px;"><strong>Potential Impact:</strong> ${escapeHtml(c.aiAnalysis?.potentialImpact || '')}</div>
        <div style="font-size: 11px; color: #475569; background: #f8fafc; padding: 6px; border-radius: 4px;">
          <strong>Recommended Follow-up:</strong> ${escapeHtml(c.aiAnalysis?.recommendedFollowUp || '')}
        </div>
      </div>
    `
      )
      .join('')}
  `
      : ''
  }

  <div class="disclaimer">
    <strong>Review Notice & Disclaimer:</strong> This comparison document is generated automatically by Doc Diff Analyzer Pro.
    Exact textual variations are determined via deterministic diffing. Semantic and clause assessments represent automated preliminary indicators for human reviewers and do not constitute formal legal counsel. Always consult qualified legal advisors for binding interpretations.
  </div>
</body>
</html>`;

  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
}

function escapeHtml(text: string): string {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
