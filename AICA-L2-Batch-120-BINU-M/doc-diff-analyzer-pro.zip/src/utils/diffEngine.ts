import * as Diff from 'diff';
import {
  ChangeType,
  ComparisonMode,
  ComparisonStats,
  DiffChange,
  DiffLine,
  DiffPart,
  DocumentSection,
  SignificanceLevel,
} from '../types/diff';
import { detectNumericalChangeInDiff } from './numericalDetector';
import { detectDateChangeInDiff } from './dateDetector';

export interface ComparisonOptions {
  mode: ComparisonMode;
  ignoreCase?: boolean;
  normalizeWhitespace?: boolean;
}

export interface ComparisonResult {
  changes: DiffChange[];
  stats: ComparisonStats;
  lines: DiffLine[];
  sections: DocumentSection[];
  originalTokensCount: number;
  revisedTokensCount: number;
}

// Regex to detect legal / document section headings
const HEADING_REGEX =
  /^(?:(?:SECTION|ARTICLE|CLAUSE|PARAGRAPH|SCHEDULE|EXHIBIT|APPENDIX)\s+[\dA-Z.-]+|[0-9]+(?:\.[0-9]+)*\s+[A-Z][\w\s-]{2,50}|[A-Z\s]{4,40}:?$)/im;

// Keywords that indicate potentially material contractual clauses
const MATERIAL_KEYWORDS = [
  'liability',
  'indemnif',
  'terminat',
  'warrant',
  'remed',
  'confidential',
  'intellectual property',
  'ownership',
  'penalty',
  'liquidated damages',
  'governing law',
  'jurisdiction',
  'arbitration',
  'force majeure',
  'exclusiv',
  'non-compete',
  'non-solicit',
  'fee',
  'payment',
  'interest',
  'deposit',
  'renewal',
  'price',
  'cost',
];

export function runDocumentComparison(
  originalText: string,
  revisedText: string,
  options: ComparisonOptions
): ComparisonResult {
  const normOriginal = preprocessText(originalText, options);
  const normRevised = preprocessText(revisedText, options);

  let rawDiff: Diff.Change[];

  if (options.mode === 'line') {
    rawDiff = (Diff.diffLines(normOriginal, normRevised, {
      newlineIsToken: true,
      ...(options.ignoreCase ? { ignoreCase: true } : {}),
    } as any) || []) as Diff.Change[];
  } else {
    // Word-level or normalized word diff
    rawDiff = Diff.diffWordsWithSpace(normOriginal, normRevised, {
      ignoreCase: options.ignoreCase,
    });
  }

  // Parse discrete changes with stable IDs
  const changes: DiffChange[] = [];
  let changeCounter = 1;

  // Track lines and context
  const origParagraphs = originalText.split(/\r?\n/);
  const revParagraphs = revisedText.split(/\r?\n/);

  let i = 0;
  while (i < rawDiff.length) {
    const part = rawDiff[i];

    if (!part.added && !part.removed) {
      i++;
      continue;
    }

    const prevContext = i > 0 ? rawDiff[i - 1].value : '';
    let origSnippet = '';
    let revSnippet = '';

    let j = i;
    while (j < rawDiff.length) {
      const cur = rawDiff[j];
      if (cur.removed) {
        origSnippet += cur.value;
        j++;
      } else if (cur.added) {
        revSnippet += cur.value;
        j++;
      } else if (
        /^\s+$/.test(cur.value) &&
        j + 1 < rawDiff.length &&
        (rawDiff[j + 1].added || rawDiff[j + 1].removed)
      ) {
        origSnippet += cur.value;
        revSnippet += cur.value;
        j++;
      } else {
        break;
      }
    }
    const nextContext = j < rawDiff.length ? rawDiff[j].value : '';
    i = j;

    let changeType: ChangeType = 'modification';
    if (origSnippet && !revSnippet) {
      changeType = 'deletion';
    } else if (!origSnippet && revSnippet) {
      changeType = 'addition';
    } else {
      changeType = 'modification';
    }

    // Skip empty whitespace-only changes if normalized
    if (
      options.normalizeWhitespace &&
      origSnippet.trim() === '' &&
      revSnippet.trim() === ''
    ) {
      continue;
    }

    const changeId = `CHG-${String(changeCounter).padStart(3, '0')}`;
    changeCounter++;

    // Context windows
    const contextBefore = prevContext.slice(-60).trim();
    const contextAfter = nextContext.slice(0, 60).trim();
    const fullContext = `${contextBefore} [${origSnippet || '(none)'} -> ${revSnippet || '(none)'}] ${contextAfter}`;

    // Expand numerical boundaries if adjacent to currency/commas
    let numOrig = origSnippet;
    let numRev = revSnippet;
    const curPrefixMatch =
      prevContext.match(/(?:AED|USD|EUR|GBP|CAD|AUD|CHF|SGD|SAR|\$|€|£|¥|₹)\s*[\d,]*$/i) ||
      prevContext.match(/[\d,]+\s*$/);
    const numSuffixMatch = nextContext.match(
      /^([,\d]+(?:\.\d+)?|\s*(?:%|percent|days|calendar days|business days))/i
    );

    if (curPrefixMatch || numSuffixMatch) {
      const pfx = curPrefixMatch ? curPrefixMatch[0] : '';
      const sfx = numSuffixMatch ? numSuffixMatch[0] : '';
      if (/\d/.test(origSnippet)) numOrig = pfx + origSnippet + sfx;
      if (/\d/.test(revSnippet)) numRev = pfx + revSnippet + sfx;
    }

    // Detect section heading
    const section = findNearestSection(origSnippet || revSnippet, origParagraphs, revParagraphs);

    // Check Numerical Change
    const numericalDetails = detectNumericalChangeInDiff(numOrig, numRev, fullContext);
    if (numericalDetails) {
      if (numericalDetails.category === 'monetary') changeType = 'amount';
      else if (numericalDetails.category === 'percentage') changeType = 'percentage';
      origSnippet = numOrig;
      revSnippet = numRev;
    }

    // Check Date / Deadline Change
    const dateDetails = detectDateChangeInDiff(numOrig, numRev, fullContext);
    if (dateDetails && changeType !== 'amount' && changeType !== 'percentage') {
      changeType = 'date';
      origSnippet = numOrig;
      revSnippet = numRev;
    }

    // Check Clause / Structural keywords
    const lowerCombined = (origSnippet + ' ' + revSnippet + ' ' + section).toLowerCase();
    const hasMaterialKeyword = MATERIAL_KEYWORDS.some((kw) => lowerCombined.includes(kw));

    if (hasMaterialKeyword && changeType === 'modification') {
      changeType = 'clause';
    }

    // Determine Significance
    let significance: SignificanceLevel = 'Low';
    if (changeType === 'amount' || changeType === 'percentage') {
      significance = 'High';
    } else if (changeType === 'clause' || hasMaterialKeyword) {
      significance = 'High';
    } else if (changeType === 'date') {
      significance = 'Moderate';
    } else if (changeType === 'addition' || changeType === 'deletion') {
      significance = origSnippet.length > 50 || revSnippet.length > 50 ? 'Moderate' : 'Low';
    } else if (origSnippet.length > 80 || revSnippet.length > 80) {
      significance = 'Moderate';
    } else if (/^[.,;:!?'"()\s]+$/.test(origSnippet + revSnippet)) {
      significance = 'Informational';
    }

    changes.push({
      id: changeId,
      index: changes.length + 1,
      type: changeType,
      originalText: origSnippet,
      revisedText: revSnippet,
      section,
      significance,
      contextBefore,
      contextAfter,
      numericalDetails: numericalDetails || undefined,
      dateDetails: dateDetails || undefined,
    });
  }

  // Build aligned side-by-side lines for viewer
  const lines = buildAlignedDiffLines(origParagraphs, revParagraphs, changes, options);

  // Calculate statistics
  const totalAdditions = changes.filter((c) => c.type === 'addition').length;
  const totalDeletions = changes.filter((c) => c.type === 'deletion').length;
  const modifiedSegments = changes.filter(
    (c) => c.type === 'modification' || c.type === 'clause' || c.type === 'structural'
  ).length;
  const changedAmounts = changes.filter((c) => c.type === 'amount' || c.numericalDetails?.category === 'monetary').length;
  const changedDates = changes.filter((c) => c.type === 'date' || Boolean(c.dateDetails)).length;
  const materialClauseChanges = changes.filter(
    (c) => c.significance === 'High' && (c.type === 'clause' || c.type === 'modification' || c.type === 'addition' || c.type === 'deletion')
  ).length;

  const originalWords = originalText.trim().split(/\s+/).filter(Boolean);
  const revisedWords = revisedText.trim().split(/\s+/).filter(Boolean);

  let unchangedWordsCount = 0;
  for (const part of rawDiff) {
    if (!part.added && !part.removed) {
      unchangedWordsCount += part.value.trim().split(/\s+/).filter(Boolean).length;
    }
  }

  const maxWords = Math.max(originalWords.length, revisedWords.length, 1);
  const similarityScore = Math.max(
    0,
    Math.min(100, Math.round((unchangedWordsCount / maxWords) * 100))
  );

  const stats: ComparisonStats = {
    totalAdditions,
    totalDeletions,
    modifiedSegments,
    changedAmounts,
    changedDates,
    materialClauseChanges,
    totalDetectedChanges: changes.length,
    originalWordCount: originalWords.length,
    revisedWordCount: revisedWords.length,
    similarityScore: changes.length === 0 ? 100 : similarityScore,
  };

  const sections = extractDocumentSections(lines, changes);

  return {
    changes,
    stats,
    lines,
    sections,
    originalTokensCount: originalWords.length,
    revisedTokensCount: revisedWords.length,
  };
}

function preprocessText(text: string, options: ComparisonOptions): string {
  let result = text;
  if (options.normalizeWhitespace) {
    // Normalize Windows/Mac line endings to \n and collapse repeated horizontal spaces
    result = result.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    result = result.replace(/[ \t]+/g, ' ');
  }
  return result;
}

function findNearestSection(
  snippet: string,
  origParagraphs: string[],
  revParagraphs: string[]
): string {
  const cleanSnippet = snippet.trim();
  if (!cleanSnippet) return 'General Text';

  // Search in original paragraphs
  for (let idx = 0; idx < origParagraphs.length; idx++) {
    const p = origParagraphs[idx];
    if (p.includes(cleanSnippet)) {
      // Look upwards for nearest heading
      for (let h = idx; h >= 0; h--) {
        const candidate = origParagraphs[h].trim();
        if (HEADING_REGEX.test(candidate)) {
          return candidate.length > 60 ? candidate.substring(0, 57) + '...' : candidate;
        }
      }
      return `Paragraph ${idx + 1}`;
    }
  }

  // Search in revised paragraphs
  for (let idx = 0; idx < revParagraphs.length; idx++) {
    const p = revParagraphs[idx];
    if (p.includes(cleanSnippet)) {
      for (let h = idx; h >= 0; h--) {
        const candidate = revParagraphs[h].trim();
        if (HEADING_REGEX.test(candidate)) {
          return candidate.length > 60 ? candidate.substring(0, 57) + '...' : candidate;
        }
      }
      return `Paragraph ${idx + 1}`;
    }
  }

  return 'Document Body';
}

function buildAlignedDiffLines(
  origParagraphs: string[],
  revParagraphs: string[],
  changes: DiffChange[],
  options: ComparisonOptions
): DiffLine[] {
  const diffLines: DiffLine[] = [];
  const maxLen = Math.max(origParagraphs.length, revParagraphs.length);

  // Helper map from snippet to changeId
  const findChangeIdForText = (text: string): { changeId?: string; changeType?: ChangeType } => {
    if (!text.trim()) return {};
    const matched = changes.find(
      (c) =>
        (c.originalText && text.includes(c.originalText.trim())) ||
        (c.revisedText && text.includes(c.revisedText.trim()))
    );
    return matched ? { changeId: matched.id, changeType: matched.type } : {};
  };

  for (let i = 0; i < maxLen; i++) {
    const orig = origParagraphs[i] !== undefined ? origParagraphs[i] : null;
    const rev = revParagraphs[i] !== undefined ? revParagraphs[i] : null;

    if (orig !== null && rev !== null) {
      if (orig === rev) {
        diffLines.push({
          lineNumOriginal: i + 1,
          lineNumRevised: i + 1,
          type: 'unchanged',
          originalContent: orig,
          revisedContent: rev,
        });
      } else {
        // Line diff or word diff inside this paragraph
        const wordParts = Diff.diffWordsWithSpace(orig, rev, { ignoreCase: options.ignoreCase });
        const partsOrig: DiffPart[] = [];
        const partsRev: DiffPart[] = [];
        let lineChangeId: string | undefined = undefined;

        for (const wp of wordParts) {
          if (wp.removed) {
            const { changeId, changeType } = findChangeIdForText(wp.value);
            if (changeId) lineChangeId = changeId;
            partsOrig.push({ value: wp.value, removed: true, changeId, changeType });
          } else if (wp.added) {
            const { changeId, changeType } = findChangeIdForText(wp.value);
            if (changeId) lineChangeId = changeId;
            partsRev.push({ value: wp.value, added: true, changeId, changeType });
          } else {
            partsOrig.push({ value: wp.value });
            partsRev.push({ value: wp.value });
          }
        }

        diffLines.push({
          lineNumOriginal: i + 1,
          lineNumRevised: i + 1,
          type: 'modified',
          originalContent: orig,
          revisedContent: rev,
          changeId: lineChangeId,
          partsOriginal: partsOrig,
          partsRevised: partsRev,
        });
      }
    } else if (orig !== null && rev === null) {
      const { changeId, changeType } = findChangeIdForText(orig);
      diffLines.push({
        lineNumOriginal: i + 1,
        type: 'removed',
        originalContent: orig,
        changeId,
        partsOriginal: [{ value: orig, removed: true, changeId, changeType }],
      });
    } else if (orig === null && rev !== null) {
      const { changeId, changeType } = findChangeIdForText(rev);
      diffLines.push({
        lineNumRevised: i + 1,
        type: 'added',
        revisedContent: rev,
        changeId,
        partsRevised: [{ value: rev, added: true, changeId, changeType }],
      });
    }
  }

  return diffLines;
}

export function isHeadingCandidate(text: string): boolean {
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 90) return false;
  // Markdown heading
  if (/^#{1,4}\s+\S+/i.test(trimmed)) return true;
  // Formal legal clause labels (SECTION 1, Article 2, CLAUSE 3, Schedule A, Exhibit B, etc.)
  if (
    /^(?:SECTION|ARTICLE|CLAUSE|PARAGRAPH|SCHEDULE|EXHIBIT|APPENDIX|PART|RECITALS|BACKGROUND|PREAMBLE)\b/i.test(
      trimmed
    )
  ) {
    return true;
  }
  // Numbered headings like 1. Scope, 2.1 Fees, 12. Governing Law
  if (/^[0-9]+(?:\.[0-9]+)*\s+[A-Z]/i.test(trimmed)) return true;
  // Regex heading match
  if (HEADING_REGEX.test(trimmed)) return true;
  // Short uppercase titles like "TERMS OF AGREEMENT" or "SCOPE OF WORK"
  if (
    trimmed.length >= 4 &&
    trimmed.length <= 45 &&
    /^[A-Z0-9\s,.:\-_&]+$/.test(trimmed) &&
    /[A-Z]/.test(trimmed) &&
    !trimmed.endsWith('.')
  ) {
    return true;
  }
  return false;
}

export function extractDocumentSections(
  lines: DiffLine[],
  changes: DiffChange[]
): DocumentSection[] {
  const sections: DocumentSection[] = [];
  let currentSection: DocumentSection | null = null;
  let sectionCounter = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const rawContent = (line.revisedContent || line.originalContent || '').trim();
    const isHeading = isHeadingCandidate(rawContent);

    if (isHeading) {
      sectionCounter++;
      const cleanTitle = rawContent.replace(/^#{1,4}\s+/, '').trim();
      const displayTitle =
        cleanTitle.length > 55 ? cleanTitle.substring(0, 52) + '...' : cleanTitle;
      const secId = `sec-${sectionCounter}-${displayTitle
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .slice(0, 24)}`;

      currentSection = {
        id: secId,
        title: displayTitle,
        lineIndex: i,
        changeCount: 0,
        hasAmountChange: false,
        hasDateChange: false,
        hasHighRiskChange: false,
        status:
          line.type === 'added'
            ? 'added'
            : line.type === 'removed'
            ? 'removed'
            : 'unchanged',
      };
      sections.push(currentSection);

      line.isSectionHeading = true;
      line.sectionId = secId;
      line.section = displayTitle;
    } else if (currentSection) {
      line.sectionId = currentSection.id;
      line.section = currentSection.title;
    }
  }

  // If no explicit headings found, generate sensible sections
  if (sections.length === 0) {
    if (lines.length <= 6) {
      const defaultSec: DocumentSection = {
        id: 'sec-all',
        title: 'Full Document Text',
        lineIndex: 0,
        changeCount: 0,
        hasAmountChange: false,
        hasDateChange: false,
        hasHighRiskChange: false,
        status: 'unchanged',
      };
      sections.push(defaultSec);
      for (const line of lines) {
        line.sectionId = defaultSec.id;
        line.section = defaultSec.title;
      }
    } else {
      const chunkSize = 6;
      for (let i = 0; i < lines.length; i += chunkSize) {
        const start = i + 1;
        const end = Math.min(i + chunkSize, lines.length);
        const secId = `sec-chunk-${Math.floor(i / chunkSize) + 1}`;
        const title = `Paragraphs ${start}–${end}`;
        const sec: DocumentSection = {
          id: secId,
          title,
          lineIndex: i,
          changeCount: 0,
          hasAmountChange: false,
          hasDateChange: false,
          hasHighRiskChange: false,
          status: 'unchanged',
        };
        sections.push(sec);
        for (let j = i; j < end; j++) {
          lines[j].sectionId = secId;
          lines[j].section = title;
        }
      }
    }
  }

  // Correlate changes to sections
  for (const chg of changes) {
    // 1. Direct match on section title
    let matchedSec = sections.find(
      (s) => s.title === chg.section || chg.section.includes(s.title)
    );
    // 2. Line number proximity
    if (!matchedSec && chg.originalLineNumber) {
      matchedSec = [...sections]
        .reverse()
        .find((s) => s.lineIndex <= (chg.originalLineNumber || 0) - 1);
    }
    // 3. Fallback to first section
    if (!matchedSec && sections.length > 0) {
      matchedSec = sections[0];
    }

    if (matchedSec) {
      matchedSec.changeCount++;
      if (!matchedSec.firstChangeId) {
        matchedSec.firstChangeId = chg.id;
      }
      if (chg.type === 'amount' || chg.numericalDetails?.category === 'monetary') {
        matchedSec.hasAmountChange = true;
      }
      if (chg.type === 'date' || Boolean(chg.dateDetails)) {
        matchedSec.hasDateChange = true;
      }
      if (chg.significance === 'High') {
        matchedSec.hasHighRiskChange = true;
      }
      if (matchedSec.status === 'unchanged') {
        matchedSec.status = 'modified';
      }
    }
  }

  return sections;
}
