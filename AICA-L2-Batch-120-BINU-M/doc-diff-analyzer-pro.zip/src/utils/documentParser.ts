import mammoth from 'mammoth';
import * as pdfjsLib from 'pdfjs-dist';

// Configure pdfjs worker safely
try {
  if (typeof window !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
  }
} catch {
  // worker fallback
}

export interface ParseDocumentResult {
  text: string;
  charCount: number;
  wordCount: number;
  lineCount: number;
  fileSize: number;
  fileName: string;
  fileType: string;
  isScannedPdfWithoutText?: boolean;
  warnings?: string[];
}

export const MAX_FILE_SIZE_BYTES = 35 * 1024 * 1024; // 35 MB

export async function parseUploadedFile(file: File): Promise<ParseDocumentResult> {
  const fileName = file.name;
  const fileSize = file.size;
  const fileExtension = fileName.split('.').pop()?.toLowerCase() || '';

  if (fileSize > MAX_FILE_SIZE_BYTES) {
    throw new Error(
      `File size (${(fileSize / (1024 * 1024)).toFixed(1)} MB) exceeds the maximum allowed limit of 35 MB.`
    );
  }

  if (fileSize === 0) {
    throw new Error(`The uploaded file "${fileName}" is empty (0 bytes).`);
  }

  let rawText = '';
  let isScannedPdfWithoutText = false;
  const warnings: string[] = [];

  if (fileExtension === 'txt' || file.type === 'text/plain') {
    rawText = await file.text();
  } else if (fileExtension === 'docx') {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.extractRawText({ arrayBuffer });
      rawText = result.value;
      if (result.messages && result.messages.length > 0) {
        warnings.push(...result.messages.map((m) => m.message));
      }
    } catch (err: unknown) {
      const error = err as Error;
      throw new Error(`Failed to parse Word document (.docx): ${error.message || 'Corrupt or unsupported format.'}`);
    }
  } else if (fileExtension === 'pdf' || file.type === 'application/pdf') {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
      const pdf = await loadingTask.promise;

      const pageTexts: string[] = [];
      let totalExtractedLength = 0;

      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        const pageItems = textContent.items
          .map((item) => ('str' in item ? (item as { str: string }).str : ''))
          .filter(Boolean);
        const pageString = pageItems.join(' ').trim();
        if (pageString) {
          totalExtractedLength += pageString.length;
          pageTexts.push(`--- Page ${pageNum} ---\n` + pageString);
        }
      }

      rawText = pageTexts.join('\n\n');

      if (totalExtractedLength < 10) {
        isScannedPdfWithoutText = true;
        warnings.push(
          'No extractable digital text found in this PDF. It appears to be an image-only or scanned document. Optical Character Recognition (OCR) is required to extract text from scanned images.'
        );
      }
    } catch (err: unknown) {
      const error = err as Error;
      throw new Error(`Failed to parse PDF document: ${error.message || 'Corrupt, encrypted, or invalid PDF format.'}`);
    }
  } else {
    // Unsupported extension
    throw new Error(
      `Unsupported file format ".${fileExtension}". Please upload a plain text (.txt), Word (.docx), or searchable PDF (.pdf) file.`
    );
  }

  // Calculate text statistics
  const charCount = rawText.length;
  const words = rawText.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const lines = rawText.split(/\r?\n/);
  const lineCount = rawText.trim() === '' ? 0 : lines.length;

  return {
    text: rawText,
    charCount,
    wordCount,
    lineCount,
    fileSize,
    fileName,
    fileType: fileExtension.toUpperCase() || 'TXT',
    isScannedPdfWithoutText,
    warnings,
  };
}

export function computeTextMetrics(text: string) {
  const charCount = text.length;
  const words = text.trim().split(/\s+/).filter(Boolean);
  const lines = text.split(/\r?\n/);
  return {
    charCount,
    wordCount: words.length,
    lineCount: text.trim() === '' ? 0 : lines.length,
  };
}
