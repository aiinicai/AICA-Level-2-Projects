export type ComparisonMode = 'word' | 'line' | 'normalized';

export type ChangeType =
  | 'addition'
  | 'deletion'
  | 'modification'
  | 'amount'
  | 'date'
  | 'percentage'
  | 'clause'
  | 'structural';

export type SignificanceLevel = 'High' | 'Moderate' | 'Low' | 'Uncertain' | 'Informational';

export interface NumericalChange {
  originalRaw: string;
  revisedRaw: string;
  originalValue?: number;
  revisedValue?: number;
  difference?: number;
  unit?: string;
  relativeChangePercent?: number;
  isPercentagePoints?: boolean;
  category: 'monetary' | 'percentage' | 'quantity' | 'duration' | 'threshold' | 'identifier';
  uncertainMatch?: boolean;
  sourceContext: string;
  explanation: string;
}

export interface DateChange {
  originalRaw: string;
  revisedRaw: string;
  originalDateStr?: string;
  revisedDateStr?: string;
  durationDifferenceDays?: number;
  dayType?: 'calendar_days' | 'business_days' | 'unspecified';
  isAmbiguousDate?: boolean;
  semanticShift?: string;
  sourceContext: string;
  explanation: string;
}

export interface AIClauseAnalysis {
  changeId: string;
  changeSummary: string;
  originalWording: string;
  revisedWording: string;
  practicalMeaning: string;
  potentialImpact: string;
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Uncertain';
  riskRationale: string;
  recommendedFollowUp: string;
}

export interface DiffChange {
  id: string; // Stable ID: CHG-001, CHG-002, etc.
  index: number;
  type: ChangeType;
  originalText: string;
  revisedText: string;
  section: string; // Nearest detected heading, clause number or paragraph index
  originalLineNumber?: number;
  revisedLineNumber?: number;
  significance: SignificanceLevel;
  contextBefore: string;
  contextAfter: string;
  numericalDetails?: NumericalChange;
  dateDetails?: DateChange;
  aiAnalysis?: AIClauseAnalysis;
}

export interface DiffPart {
  value: string;
  added?: boolean;
  removed?: boolean;
  changeId?: string; // Links back to DiffChange if modified/added/removed
  changeType?: ChangeType;
}

export interface DiffLine {
  lineNumOriginal?: number;
  lineNumRevised?: number;
  type: 'unchanged' | 'added' | 'removed' | 'modified';
  originalContent?: string;
  revisedContent?: string;
  changeId?: string;
  partsOriginal?: DiffPart[];
  partsRevised?: DiffPart[];
  section?: string;
  sectionId?: string;
  isSectionHeading?: boolean;
}

export interface DocumentInputState {
  text: string;
  fileName: string;
  fileSize: number;
  charCount: number;
  wordCount: number;
  lineCount: number;
  fileType: string;
  isScannedPdfWithoutText?: boolean;
  isLoading?: boolean;
  error?: string | null;
}

export interface ComparisonStats {
  totalAdditions: number;
  totalDeletions: number;
  modifiedSegments: number;
  changedAmounts: number;
  changedDates: number;
  materialClauseChanges: number;
  totalDetectedChanges: number;
  originalWordCount: number;
  revisedWordCount: number;
  similarityScore: number; // 0 - 100%
}

export interface DocumentSection {
  id: string; // e.g. "sec-1", "sec-definitions"
  title: string; // e.g. "Section 1: Scope of Services" or "1. Definitions"
  lineIndex: number; // line index in DiffLines
  changeCount: number; // total changes in this section
  hasAmountChange: boolean;
  hasDateChange: boolean;
  hasHighRiskChange: boolean;
  firstChangeId?: string; // e.g. "CHG-001"
  status: 'modified' | 'added' | 'removed' | 'unchanged';
}
