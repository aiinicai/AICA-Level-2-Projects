import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  FileText,
  Play,
  RotateCcw,
  ArrowLeftRight,
  Sparkles,
  Download,
  Layers,
  DollarSign,
  Calendar,
  Table,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  FileSearch,
} from 'lucide-react';
import {
  AIClauseAnalysis,
  ComparisonMode,
  DiffChange,
  DocumentInputState,
  DocumentSection,
} from './types/diff';
import { runDocumentComparison, ComparisonResult } from './utils/diffEngine';
import { Navbar } from './components/Navbar';
import { Sidebar, ActiveSection } from './components/Sidebar';
import { DocumentInputPanel } from './components/DocumentInputPanel';
import { SummaryStatsBar } from './components/SummaryStatsBar';
import { DiffViewer } from './components/DiffViewer';
import { ChangeRegisterTable } from './components/ChangeRegisterTable';
import { NumericalChangesPanel } from './components/NumericalChangesPanel';
import { DateChangesPanel } from './components/DateChangesPanel';
import { AIAnalysisModal } from './components/AIAnalysisModal';
import { ExportModal } from './components/ExportModal';

const EMPTY_DOC_STATE: DocumentInputState = {
  text: '',
  fileName: '',
  fileSize: 0,
  charCount: 0,
  wordCount: 0,
  lineCount: 0,
  fileType: 'TXT',
  isLoading: false,
  error: null,
};

export default function App() {
  // Document inputs
  const [originalDoc, setOriginalDoc] = useState<DocumentInputState>(EMPTY_DOC_STATE);
  const [revisedDoc, setRevisedDoc] = useState<DocumentInputState>(EMPTY_DOC_STATE);

  // Comparison Settings
  const [mode, setMode] = useState<ComparisonMode>('word');
  const [ignoreCase, setIgnoreCase] = useState<boolean>(false);
  const [normalizeWhitespace, setNormalizeWhitespace] = useState<boolean>(false);

  // Comparison Results State
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [activeChangeId, setActiveChangeId] = useState<string | null>(null);
  const [activeDocumentSectionId, setActiveDocumentSectionId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'viewer' | 'register' | 'amounts' | 'dates'>('viewer');

  // Navigation & Layout
  const [activeSection, setActiveSection] = useState<ActiveSection>('workspace');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // AI Store
  const [aiAnalyses, setAiAnalyses] = useState<Record<string, AIClauseAnalysis>>({});

  // Modals
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [preselectedAIChangeId, setPreselectedAIChangeId] = useState<string | null>(null);

  // Perform Comparison
  const handleExecuteComparison = useCallback(() => {
    if (!originalDoc.text.trim() || !revisedDoc.text.trim()) {
      return;
    }

    const result = runDocumentComparison(originalDoc.text, revisedDoc.text, {
      mode,
      ignoreCase,
      normalizeWhitespace,
    });

    // Merge any existing AI analyses
    if (Object.keys(aiAnalyses).length > 0) {
      result.changes = result.changes.map((c) => ({
        ...c,
        aiAnalysis: aiAnalyses[c.id] || c.aiAnalysis,
      }));
    }

    setComparisonResult(result);
    if (result.changes.length > 0) {
      setActiveChangeId(result.changes[0].id);
    } else {
      setActiveChangeId(null);
    }

    setActiveSection('viewer');
    setActiveTab('viewer');
  }, [originalDoc.text, revisedDoc.text, mode, ignoreCase, normalizeWhitespace, aiAnalyses]);

  // Re-run comparison if options change and comparison is active
  useEffect(() => {
    if (comparisonResult && originalDoc.text.trim() && revisedDoc.text.trim()) {
      handleExecuteComparison();
    }
  }, [mode, ignoreCase, normalizeWhitespace]);

  // Swap Documents
  const handleSwapDocuments = () => {
    const temp = { ...originalDoc };
    setOriginalDoc({ ...revisedDoc });
    setRevisedDoc(temp);
  };

  // Clear Session
  const handleClearSession = () => {
    setOriginalDoc(EMPTY_DOC_STATE);
    setRevisedDoc(EMPTY_DOC_STATE);
    setComparisonResult(null);
    setActiveChangeId(null);
    setActiveDocumentSectionId(null);
    setActiveFilter(null);
    setAiAnalyses({});
    setActiveSection('workspace');
  };

  // Document Section Selection from Left Panel
  const handleSelectDocumentSection = useCallback(
    (sec: DocumentSection) => {
      setActiveDocumentSectionId(sec.id);
      setActiveSection('viewer');
      setActiveTab('viewer');
      setIsMobileSidebarOpen(false);
      if (sec.firstChangeId) {
        setActiveChangeId(sec.firstChangeId);
      }
      setTimeout(() => {
        const el =
          document.getElementById(`doc-sec-${sec.id}`) ||
          (sec.firstChangeId ? document.getElementById(`diff-target-${sec.firstChangeId}`) : null);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 60);
    },
    []
  );

  // Apply AI analyses results
  const handleApplyAIAnalyses = (analyses: AIClauseAnalysis[]) => {
    const newAiMap = { ...aiAnalyses };
    analyses.forEach((a) => {
      newAiMap[a.changeId] = a;
    });
    setAiAnalyses(newAiMap);

    if (comparisonResult) {
      setComparisonResult({
        ...comparisonResult,
        changes: comparisonResult.changes.map((c) => ({
          ...c,
          aiAnalysis: newAiMap[c.id] || c.aiAnalysis,
        })),
      });
    }
  };

  // Section Jump Handler from Left Blue Panel
  const handleSelectSection = (section: ActiveSection) => {
    setActiveSection(section);
    setIsMobileSidebarOpen(false);

    if (section === 'workspace') {
      const el = document.getElementById('section-workspace');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'summary') {
      const el = document.getElementById('section-summary');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'viewer') {
      setActiveTab('viewer');
      const el = document.getElementById('section-results');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'register') {
      setActiveTab('register');
      const el = document.getElementById('section-results');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'numerical') {
      setActiveTab('amounts');
      const el = document.getElementById('section-results');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'dates') {
      setActiveTab('dates');
      const el = document.getElementById('section-results');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'ai-analysis') {
      setPreselectedAIChangeId(null);
      setIsAIModalOpen(true);
    }
  };

  // Filter changes based on activeFilter from SummaryStatsBar
  const filteredChanges = useMemo(() => {
    if (!comparisonResult) return [];
    if (!activeFilter || activeFilter === 'all') return comparisonResult.changes;
    if (activeFilter === 'addition') return comparisonResult.changes.filter((c) => c.type === 'addition');
    if (activeFilter === 'deletion') return comparisonResult.changes.filter((c) => c.type === 'deletion');
    if (activeFilter === 'modification') {
      return comparisonResult.changes.filter(
        (c) => c.type === 'modification' || c.type === 'clause' || c.type === 'structural'
      );
    }
    if (activeFilter === 'amount') {
      return comparisonResult.changes.filter((c) => c.type === 'amount' || Boolean(c.numericalDetails));
    }
    if (activeFilter === 'date') {
      return comparisonResult.changes.filter((c) => c.type === 'date' || Boolean(c.dateDetails));
    }
    if (activeFilter === 'clause') {
      return comparisonResult.changes.filter(
        (c) => c.significance === 'High' && (c.type === 'clause' || c.type === 'modification')
      );
    }
    return comparisonResult.changes;
  }, [comparisonResult, activeFilter]);

  const canCompare = originalDoc.text.trim().length > 0 && revisedDoc.text.trim().length > 0;
  const numChangesCount = comparisonResult ? comparisonResult.changes.filter((c) => c.numericalDetails).length : 0;
  const dateChangesCount = comparisonResult ? comparisonResult.changes.filter((c) => c.dateDetails).length : 0;
  const aiAnalysesCount = Object.keys(aiAnalyses).length;

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-row font-sans antialiased selection:bg-[#0052cc] selection:text-white">
      {/* Left-Side Navigation Panel in Blue & White */}
      <Sidebar
        activeSection={activeSection}
        onSelectSection={handleSelectSection}
        ignoreCase={ignoreCase}
        onIgnoreCaseChange={setIgnoreCase}
        normalizeWhitespace={normalizeWhitespace}
        onNormalizeWhitespaceChange={setNormalizeWhitespace}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenAIModal={() => {
          setPreselectedAIChangeId(null);
          setIsAIModalOpen(true);
        }}
        stats={comparisonResult ? comparisonResult.stats : null}
        aiCount={aiAnalysesCount}
        originalFileName={originalDoc.fileName}
        revisedFileName={revisedDoc.fileName}
        isOpenMobile={isMobileSidebarOpen}
        onToggleMobile={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#f8fafc]/50">
        {/* Top Navbar */}
        <Navbar
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onOpenExportModal={() => setIsExportModalOpen(true)}
          onTriggerAIAnalysis={() => {
            setPreselectedAIChangeId(null);
            setIsAIModalOpen(true);
          }}
          hasComparison={Boolean(comparisonResult && comparisonResult.changes.length > 0)}
          similarityScore={comparisonResult?.stats.similarityScore}
        />

        {/* Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          {/* Header Title */}
          <div className="pb-2 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#003875]">
                Document Difference & Variance Analyzer
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Compare text, contracts, Word (.docx), and PDF documents. Detect exact wording changes, numerical variations (AED, USD, %), and deadline shifts.
              </p>
            </div>
            {canCompare && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                Both documents loaded
              </span>
            )}
          </div>

          {/* SECTION 1: Document Workspace with On-Page Actions Toolbar */}
          <section id="section-workspace" aria-label="Document Workspace" className="space-y-4">
            {/* Main Action Bar (Compare, Swap, Clear directly on main page) */}
            <div className="p-4 bg-white rounded-2xl border border-blue-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center space-x-2 w-full sm:w-auto">
                {/* Single Compare instruction button */}
                <button
                  onClick={handleExecuteComparison}
                  disabled={!canCompare}
                  className={`flex-1 sm:flex-none inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white transition shadow-sm cursor-pointer ${
                    canCompare
                      ? 'bg-[#0052cc] hover:bg-[#0040a8] active:scale-[0.98]'
                      : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Play className={`w-4 h-4 ${canCompare ? 'fill-white' : 'fill-slate-400'}`} />
                  <span>Compare Documents</span>
                </button>

                {/* Swap button */}
                <button
                  onClick={handleSwapDocuments}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-[#0052cc] bg-blue-50 hover:bg-blue-100 border border-blue-200 transition cursor-pointer"
                  title="Swap Original and Revised documents"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span className="hidden sm:inline">Swap</span>
                </button>

                {/* Clear button */}
                <button
                  onClick={handleClearSession}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 transition cursor-pointer"
                  title="Clear inputs and reset comparison"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span className="hidden sm:inline">Clear</span>
                </button>
              </div>

              {/* Status information */}
              <div className="text-xs text-slate-500 flex items-center space-x-3">
                <span>
                  Original: {originalDoc.wordCount > 0 ? <strong className="text-slate-800">{originalDoc.wordCount.toLocaleString()} words</strong> : <span className="text-slate-400">empty</span>}
                </span>
                <span>•</span>
                <span>
                  Revised: {revisedDoc.wordCount > 0 ? <strong className="text-slate-800">{revisedDoc.wordCount.toLocaleString()} words</strong> : <span className="text-slate-400">empty</span>}
                </span>
              </div>
            </div>

            {/* Input Panels (Left Blue / Right Green accent) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <DocumentInputPanel
                title="Original Version"
                badgeColor="sky"
                state={originalDoc}
                onChange={setOriginalDoc}
                onClear={() => setOriginalDoc(EMPTY_DOC_STATE)}
                placeholderText="Upload your original document (.docx, .pdf, .txt) or paste its text here..."
              />
              <DocumentInputPanel
                title="Revised Version"
                badgeColor="emerald"
                state={revisedDoc}
                onChange={setRevisedDoc}
                onClear={() => setRevisedDoc(EMPTY_DOC_STATE)}
                placeholderText="Upload your revised document (.docx, .pdf, .txt) or paste its text here..."
              />
            </div>
          </section>

          {/* SECTION 2 & 3: Results Dashboard & Tabs */}
          {comparisonResult && (
            <div id="section-results" className="space-y-6 pt-2">
              {/* Summary Statistics Section */}
              <div id="section-summary">
                <SummaryStatsBar
                  stats={comparisonResult.stats}
                  aiAnalysesCount={aiAnalysesCount}
                  activeFilter={activeFilter}
                  onFilterClick={setActiveFilter}
                />
              </div>

              {/* View Tabs */}
              <div className="border-b border-slate-200 bg-white rounded-t-2xl px-5 pt-2 flex items-center justify-between shadow-2xs">
                <nav className="flex space-x-2 sm:space-x-6 overflow-x-auto">
                  <button
                    onClick={() => setActiveTab('viewer')}
                    className={`py-3.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center space-x-2 transition shrink-0 cursor-pointer ${
                      activeTab === 'viewer'
                        ? 'border-[#0052cc] text-[#0052cc]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Layers className="w-4 h-4" />
                    <span>Side-by-Side Diff</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('register')}
                    className={`py-3.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center space-x-2 transition shrink-0 cursor-pointer ${
                      activeTab === 'register'
                        ? 'border-[#0052cc] text-[#0052cc]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Table className="w-4 h-4" />
                    <span>Change Register</span>
                    <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-50 text-[#0052cc] rounded-full font-bold">
                      {comparisonResult.changes.length}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveTab('amounts')}
                    className={`py-3.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center space-x-2 transition shrink-0 cursor-pointer ${
                      activeTab === 'amounts'
                        ? 'border-[#0052cc] text-[#0052cc]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>Numerical Variance</span>
                    {numChangesCount > 0 && (
                      <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-50 text-[#0052cc] rounded-full font-bold">
                        {numChangesCount}
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => setActiveTab('dates')}
                    className={`py-3.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center space-x-2 transition shrink-0 cursor-pointer ${
                      activeTab === 'dates'
                        ? 'border-[#0052cc] text-[#0052cc]'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Dates & Deadlines</span>
                    {dateChangesCount > 0 && (
                      <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-50 text-[#0052cc] rounded-full font-bold">
                        {dateChangesCount}
                      </span>
                    )}
                  </button>
                </nav>

                <div className="hidden lg:flex items-center space-x-2">
                  <button
                    onClick={() => {
                      setPreselectedAIChangeId(activeChangeId);
                      setIsAIModalOpen(true);
                    }}
                    className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold text-[#003875] bg-blue-50 hover:bg-blue-100 border border-blue-200 transition shadow-2xs cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#0052cc]" />
                    <span>Analyze Clauses with AI</span>
                  </button>
                </div>
              </div>

              {/* Active Tab Panel */}
              <div>
                {activeTab === 'viewer' && (
                  <div className="space-y-4">
                    <DiffViewer
                      lines={comparisonResult.lines}
                      changes={comparisonResult.changes}
                      activeChangeId={activeChangeId}
                      onSelectChange={(id) => setActiveChangeId(id)}
                      originalFileName={originalDoc.fileName || 'Original Document'}
                      revisedFileName={revisedDoc.fileName || 'Revised Document'}
                    />

                    {/* Active Change Context Card */}
                    {activeChangeId && (
                      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                        <div className="flex items-center space-x-3">
                          <span className="px-2.5 py-1 rounded-md font-mono font-bold bg-blue-50 text-[#0052cc] border border-blue-200">
                            {activeChangeId}
                          </span>
                          <div>
                            {(() => {
                              const cur = comparisonResult.changes.find((c) => c.id === activeChangeId);
                              if (!cur) return null;
                              return (
                                <div className="text-slate-700">
                                  <strong className="text-slate-900 font-bold">{cur.section}:</strong>{' '}
                                  <span className="capitalize font-semibold">{cur.type}</span> ({cur.significance} significance).{' '}
                                  {cur.numericalDetails && (
                                    <span className="font-bold text-[#0052cc]">
                                      {cur.numericalDetails.explanation}
                                    </span>
                                  )}
                                  {cur.dateDetails && (
                                    <span className="font-bold text-[#003875]">
                                      {cur.dateDetails.explanation}
                                    </span>
                                  )}
                                </div>
                              );
                            })()}
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          <button
                            onClick={() => {
                              setPreselectedAIChangeId(activeChangeId);
                              setIsAIModalOpen(true);
                            }}
                            className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold text-[#003875] bg-blue-50 hover:bg-blue-100 border border-blue-200 transition cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-[#0052cc]" />
                            <span>AI Insights</span>
                          </button>

                          <button
                            onClick={() => setActiveTab('register')}
                            className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition cursor-pointer"
                          >
                            <Table className="w-3.5 h-3.5 text-slate-500" />
                            <span>Register</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'register' && (
                  <ChangeRegisterTable
                    changes={filteredChanges}
                    activeChangeId={activeChangeId}
                    onSelectChange={(id) => {
                      setActiveChangeId(id);
                      setActiveTab('viewer');
                    }}
                    onOpenAIAnalysisForChange={(change) => {
                      setPreselectedAIChangeId(change.id);
                      setIsAIModalOpen(true);
                    }}
                  />
                )}

                {activeTab === 'amounts' && (
                  <NumericalChangesPanel
                    changes={comparisonResult.changes}
                    activeChangeId={activeChangeId}
                    onSelectChange={(id) => {
                      setActiveChangeId(id);
                      setActiveTab('viewer');
                    }}
                  />
                )}

                {activeTab === 'dates' && (
                  <DateChangesPanel
                    changes={comparisonResult.changes}
                    activeChangeId={activeChangeId}
                    onSelectChange={(id) => {
                      setActiveChangeId(id);
                      setActiveTab('viewer');
                    }}
                  />
                )}
              </div>
            </div>
          )}

          {/* Footer Notice without Client-side Parsing wording */}
          <footer className="pt-8 pb-4 text-center text-xs text-slate-500 border-t border-slate-200 space-y-1">
            <p className="flex items-center justify-center space-x-2 font-bold text-[#003875]">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Doc Diff Analyzer Pro • Document Variance Engine</span>
            </p>
            <p className="text-[11px] text-slate-400 max-w-2xl mx-auto">
              Original documents remain confidential in session memory. Differences are extracted deterministically, with AI clause analysis providing grounded preliminary review observations.
            </p>
          </footer>
        </main>
      </div>

      {/* Modals */}
      {comparisonResult && (
        <>
          <ExportModal
            isOpen={isExportModalOpen}
            onClose={() => setIsExportModalOpen(false)}
            changes={comparisonResult.changes}
            stats={comparisonResult.stats}
            originalDocumentName={originalDoc.fileName || 'Original Document'}
            revisedDocumentName={revisedDoc.fileName || 'Revised Document'}
          />

          <AIAnalysisModal
            isOpen={isAIModalOpen}
            onClose={() => setIsAIModalOpen(false)}
            changes={comparisonResult.changes}
            onApplyAnalyses={handleApplyAIAnalyses}
            originalDocumentName={originalDoc.fileName || 'Original Document'}
            revisedDocumentName={revisedDoc.fileName || 'Revised Document'}
            preselectedChangeId={preselectedAIChangeId}
          />
        </>
      )}
    </div>
  );
}
