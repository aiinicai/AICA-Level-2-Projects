import { runDocumentComparison } from '../src/utils/diffEngine';
import { detectNumericalChangeInDiff } from '../src/utils/numericalDetector';
import { detectDateChangeInDiff } from '../src/utils/dateDetector';
import { generateMarkdownReport } from '../src/utils/exportUtils';

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`PASS: ${testName}`);
    passedTests++;
  } else {
    console.error(`FAIL: ${testName}`);
    failedTests++;
  }
}

console.log('--- RUNNING TEST SUITE: DOC DIFF ANALYZER PRO ---\n');

// 1. Identical documents test
{
  const text = 'This Agreement is entered into by and between Party A and Party B.';
  const res = runDocumentComparison(text, text, { mode: 'word' });
  assert(res.changes.length === 0, '1. Identical documents yield 0 detected changes');
  assert(res.stats.similarityScore === 100, '1. Identical documents have 100% similarity score');
}

// 2. Single inserted word test
{
  const orig = 'The fee shall be paid in full.';
  const rev = 'The fee shall always be paid in full.';
  const res = runDocumentComparison(orig, rev, { mode: 'word' });
  assert(res.changes.length === 1, '2. Single inserted word detected as 1 change');
  assert(res.changes[0].type === 'addition', '2. Single inserted word classified as addition');
  assert(res.changes[0].revisedText.includes('always'), '2. Inserted text contains "always"');
}

// 3. Single deleted word test
{
  const orig = 'The fee shall always be paid in full.';
  const rev = 'The fee shall be paid in full.';
  const res = runDocumentComparison(orig, rev, { mode: 'word' });
  assert(res.changes.length === 1, '3. Single deleted word detected as 1 change');
  assert(res.changes[0].type === 'deletion', '3. Single deleted word classified as deletion');
  assert(res.changes[0].originalText.includes('always'), '3. Deleted text contains "always"');
}

// 4. Replaced wording test
{
  const orig = 'Provider warrants that the system is operational.';
  const rev = 'Provider represents and guarantees that the system is operational.';
  const res = runDocumentComparison(orig, rev, { mode: 'word' });
  assert(res.changes.length === 1, '4. Replaced phrase detected as paired modification');
  assert(res.changes[0].originalText.includes('warrants'), '4. Original wording captured');
  assert(res.changes[0].revisedText.includes('represents and guarantees'), '4. Revised wording captured');
}

// 5. Changed amounts and percentages test (AED currency, percentage points)
{
  // Monetary AED
  const origFee = 'The annual fee shall be AED 50,000.';
  const revFee = 'The annual fee shall be AED 65,000.';
  const resFee = runDocumentComparison(origFee, revFee, { mode: 'word' });
  assert(resFee.changes.length === 1, '5a. AED Fee change detected');
  assert(resFee.changes[0].type === 'amount', '5a. Classified as amount change');
  assert(resFee.changes[0].numericalDetails?.difference === 15000, '5a. Arithmetic difference is 15,000');
  assert(resFee.changes[0].numericalDetails?.relativeChangePercent === 30, '5a. Relative change is 30%');

  // Percentage points
  const origRate = 'Interest shall be charged at 5% per annum.';
  const revRate = 'Interest shall be charged at 8% per annum.';
  const resRate = runDocumentComparison(origRate, revRate, { mode: 'word' });
  assert(resRate.changes[0].type === 'percentage', '5b. Rate classified as percentage change');
  assert(resRate.changes[0].numericalDetails?.difference === 3, '5b. Difference is 3 percentage points');
  assert(resRate.changes[0].numericalDetails?.isPercentagePoints === true, '5b. Flagged as percentage points');
}

// 6. Changed dates and deadlines test
{
  // Days duration
  const origDeadline = 'Payment is due within 30 days of receipt.';
  const revDeadline = 'Payment is due within 45 days of receipt.';
  const resDeadline = runDocumentComparison(origDeadline, revDeadline, { mode: 'word' });
  assert(resDeadline.changes.length === 1, '6a. Deadline duration change detected');
  assert(resDeadline.changes[0].dateDetails?.durationDifferenceDays === 15, '6a. Duration difference is 15 days');

  // Semantic shift: "shall renew" vs "may renew"
  const origRenew = 'This agreement shall renew automatically.';
  const revRenew = 'This agreement may renew upon mutual consent.';
  const resRenew = runDocumentComparison(origRenew, revRenew, { mode: 'word' });
  assert(
    Boolean(resRenew.changes[0].dateDetails?.semanticShift),
    '6b. Semantic renewal shift ("shall renew" -> "may renew") detected'
  );
}

// 7. Added and deleted paragraphs test
{
  const orig = 'Paragraph 1.\n\nParagraph 2.';
  const rev = 'Paragraph 1.\n\nParagraph 1.5 New Added Content.\n\nParagraph 2.';
  const res = runDocumentComparison(orig, rev, { mode: 'line' });
  assert(res.changes.some((c) => c.type === 'addition'), '7. Added paragraph detected in line mode');
}

// 8. Unicode and special characters
{
  const orig = 'Fees: €100,000 — 50% discount; «quoted clause».';
  const rev = 'Fees: €120,000 — 40% discount; «quoted clause».';
  const res = runDocumentComparison(orig, rev, { mode: 'word' });
  assert(res.changes.length > 0, '8. Handles Unicode characters (€, —, «») safely');
}

// 9. Markdown report generation test
{
  const orig = 'Section 1: The fee is $1,000 payable within 30 days.';
  const rev = 'Section 1: The fee is $1,500 payable within 45 days.';
  const res = runDocumentComparison(orig, rev, { mode: 'word' });
  const md = generateMarkdownReport(res.changes, res.stats, 'Contract_v1.txt', 'Contract_v2.txt');
  assert(md.includes('Doc Diff Analyzer Pro'), '9a. Markdown contains report header');
  assert(md.includes('$1,000'), '9b. Markdown includes original amount');
  assert(md.includes('$1,500'), '9c. Markdown includes revised amount');
  assert(md.includes('Review Limitations & Disclaimer'), '9d. Markdown includes legal disclaimer');
}

console.log(`\nTEST RESULTS: ${passedTests} passed, ${failedTests} failed.`);
if (failedTests > 0) {
  process.exit(1);
}
