using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace TDSClassifierApp
{
    public class MainForm : Form
    {
        private HttpListener listener;
        private Thread serverThread;
        private string appDir;
        private int port = 3005;
        private WebBrowser webBrowser;
        private Panel topBar;
        private Label statusLabel;
        private Button btnExternalBrowser;
        private Button btnRefresh;

        [STAThread]
        public static void Main()
        {
            // Enable modern browser rendering mode for WebBrowser control
            SetWebBrowserFeatureControl();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }

        private static void SetWebBrowserFeatureControl()
        {
            try
            {
                string appName = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION"))
                {
                    if (key != null)
                    {
                        key.SetValue(appName, 11001, RegistryValueKind.DWord); // IE11 / Edge mode
                    }
                }
            }
            catch { }
        }

        public MainForm()
        {
            appDir = AppDomain.CurrentDomain.BaseDirectory;
            InitializeUI();
            StartHttpServer();
            LoadAppContent();
        }

        private void InitializeUI()
        {
            this.Text = "TDS & TCS Section Classifier — Tax Year 2026-27 (Income Tax Act, 2025)";
            this.Size = new Size(1300, 850);
            this.MinimumSize = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(10, 14, 23);
            this.ForeColor = Color.White;

            // Top control bar
            topBar = new Panel()
            {
                Dock = DockStyle.Top,
                Height = 46,
                BackColor = Color.FromArgb(17, 24, 39),
                Padding = new Padding(12, 6, 12, 6)
            };

            Label brandLabel = new Label()
            {
                Text = "⚖️ TDS & TCS MASTER APP (IT ACT 2025)",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(96, 165, 250),
                Location = new Point(12, 12),
                AutoSize = true
            };

            statusLabel = new Label()
            {
                Text = "● Connected: http://127.0.0.1:" + port,
                Font = new Font("Segoe UI", 9, FontStyle.Regular),
                ForeColor = Color.FromArgb(52, 211, 153),
                Location = new Point(340, 14),
                AutoSize = true
            };

            btnExternalBrowser = new Button()
            {
                Text = "🌐 Open in Chrome / Edge / Default Browser",
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                BackColor = Color.FromArgb(59, 130, 246),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(300, 32),
                Location = new Point(680, 7),
                Cursor = Cursors.Hand
            };
            btnExternalBrowser.FlatAppearance.BorderSize = 0;
            btnExternalBrowser.Click += (s, e) => LaunchExternalBrowser();

            btnRefresh = new Button()
            {
                Text = "🔄 Refresh",
                Font = new Font("Segoe UI", 9, FontStyle.Regular),
                BackColor = Color.FromArgb(30, 41, 59),
                ForeColor = Color.FromArgb(203, 213, 225),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(90, 32),
                Location = new Point(990, 7),
                Cursor = Cursors.Hand
            };
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.Click += (s, e) => {
                if (webBrowser != null) webBrowser.Refresh();
            };

            topBar.Controls.Add(brandLabel);
            topBar.Controls.Add(statusLabel);
            topBar.Controls.Add(btnExternalBrowser);
            topBar.Controls.Add(btnRefresh);

            // Embedded Web Browser View
            webBrowser = new WebBrowser()
            {
                Dock = DockStyle.Fill,
                ScriptErrorsSuppressed = true,
                IsWebBrowserContextMenuEnabled = true
            };

            this.Controls.Add(webBrowser);
            this.Controls.Add(topBar);

            this.FormClosing += MainForm_FormClosing;
        }

        private void StartHttpServer()
        {
            int[] portsToTry = new int[] { 3005, 3006, 3010, 8085, 8090 };
            foreach (int p in portsToTry)
            {
                try
                {
                    listener = new HttpListener();
                    listener.Prefixes.Add("http://127.0.0.1:" + p + "/");
                    listener.Prefixes.Add("http://localhost:" + p + "/");
                    listener.Start();

                    port = p;
                    statusLabel.Text = "● Running: http://127.0.0.1:" + port;

                    serverThread = new Thread(ListenLoop);
                    serverThread.IsBackground = true;
                    serverThread.Start();
                    return;
                }
                catch
                {
                    if (listener != null)
                    {
                        try { listener.Close(); } catch { }
                    }
                }
            }
        }

        private void ListenLoop()
        {
            while (listener != null && listener.IsListening)
            {
                try
                {
                    HttpListenerContext context = listener.GetContext();
                    ThreadPool.QueueUserWorkItem((o) => ProcessRequest(context));
                }
                catch { }
            }
        }

        private void ProcessRequest(HttpListenerContext context)
        {
            try
            {
                string path = context.Request.Url.AbsolutePath.TrimStart('/');
                if (string.IsNullOrEmpty(path) || path == "/") path = "index.html";

                string filePath = Path.Combine(appDir, path);

                if (File.Exists(filePath))
                {
                    byte[] bytes = File.ReadAllBytes(filePath);
                    string ext = Path.GetExtension(filePath).ToLower();

                    if (ext == ".html") context.Response.ContentType = "text/html; charset=utf-8";
                    else if (ext == ".js") context.Response.ContentType = "application/javascript; charset=utf-8";
                    else if (ext == ".css") context.Response.ContentType = "text/css; charset=utf-8";
                    else if (ext == ".png") context.Response.ContentType = "image/png";
                    else if (ext == ".svg") context.Response.ContentType = "image/svg+xml";

                    context.Response.ContentLength64 = bytes.Length;
                    context.Response.OutputStream.Write(bytes, 0, bytes.Length);
                }
                else
                {
                    context.Response.StatusCode = 404;
                    byte[] notFound = Encoding.UTF8.GetBytes("File Not Found");
                    context.Response.OutputStream.Write(notFound, 0, notFound.Length);
                }
                context.Response.OutputStream.Close();
            }
            catch { }
        }

        private void LoadAppContent()
        {
            try
            {
                if (listener != null && listener.IsListening)
                {
                    webBrowser.Navigate("http://127.0.0.1:" + port + "/index.html");
                }
                else
                {
                    string localHtml = Path.Combine(appDir, "index.html");
                    if (File.Exists(localHtml))
                    {
                        webBrowser.Navigate(localHtml);
                    }
                }
            }
            catch { }
        }

        private void LaunchExternalBrowser()
        {
            string targetUrl = (listener != null && listener.IsListening) 
                ? ("http://127.0.0.1:" + port) 
                : Path.Combine(appDir, "index.html");

            try
            {
                // Method 1: Process.Start with UseShellExecute = true
                ProcessStartInfo psi = new ProcessStartInfo()
                {
                    FileName = targetUrl,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch
            {
                try
                {
                    // Method 2: Fallback via cmd start command
                    ProcessStartInfo psi = new ProcessStartInfo()
                    {
                        FileName = "cmd.exe",
                        Arguments = "/c start \"\" \"" + targetUrl + "\"",
                        CreateNoWindow = true,
                        UseShellExecute = false
                    };
                    Process.Start(psi);
                }
                catch
                {
                    try
                    {
                        // Method 3: Fallback directly to msedge.exe
                        Process.Start("msedge.exe", targetUrl);
                    }
                    catch
                    {
                        try
                        {
                            // Method 4: Fallback to chrome.exe
                            Process.Start("chrome.exe", targetUrl);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Could not launch external browser. The app is running inside this window.\n\nURL: " + targetUrl, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (listener != null && listener.IsListening)
                {
                    listener.Stop();
                    listener.Close();
                }
            }
            catch { }
        }
    }
}
