// OFFICIAL TDS & TCS RATE CHART APPLICATION ENGINE - TAX YEAR 2026-27 (INCOME TAX ACT, 2025)

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initNavTabs();
  initQuickClassifier();
  initMasterChartTable();
  initSectionDirectory();
  initBatchBuilder();
  initNoPanRulesModal();
});

// ==========================================
// 1. THEME MANAGEMENT
// ==========================================
function initTheme() {
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const currentTheme = localStorage.getItem('tds_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', currentTheme);
  updateThemeIcon(currentTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const activeTheme = document.documentElement.getAttribute('data-theme');
      const newTheme = activeTheme === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('tds_theme', newTheme);
      updateThemeIcon(newTheme);
    });
  }
}

function updateThemeIcon(theme) {
  const btn = document.getElementById('themeToggleBtn');
  if (!btn) return;
  if (theme === 'light') {
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;
    btn.title = "Switch to Dark Mode";
  } else {
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="24"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`;
    btn.title = "Switch to Light Mode";
  }
}

// ==========================================
// 2. NAVIGATION TABS
// ==========================================
function initNavTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const activeContent = document.getElementById(targetTab);
      if (activeContent) activeContent.classList.add('active');
    });
  });
}

// ==========================================
// 3. SMART NLP & MULTI-PARAM CLASSIFIER
// ==========================================
function initQuickClassifier() {
  const searchInput = document.getElementById('smartSearchInput');
  const searchBtn = document.getElementById('smartSearchBtn');
  const chips = document.querySelectorAll('.search-chip');

  if (searchBtn && searchInput) {
    searchBtn.addEventListener('click', () => {
      runClassifier(searchInput.value.trim());
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        runClassifier(searchInput.value.trim());
      }
    });
  }

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const query = chip.getAttribute('data-query');
      if (searchInput) {
        searchInput.value = query;
        runClassifier(query);
      }
    });
  });

  // Initial classification run
  runClassifier("1067");
}

function runClassifier(query) {
  if (!query) return;

  const normalized = query.toLowerCase().trim();
  let extractedAmount = parseAmount(query);

  let bestMatch = null;
  let highestScore = 0;

  TDS_TCS_MASTER_2026_27.forEach(item => {
    let score = 0;

    // Exact Return Code match (e.g. 1005, 1026, 1067, 1075)
    if (normalized === item.returnCode || normalized.includes(`code ${item.returnCode}`) || normalized.includes(item.returnCode)) {
      score += 100;
    }

    // Old Section match (e.g. 194T, 194C, 194J(a), 194H, 206C)
    if (normalized.includes(item.oldSection.toLowerCase())) {
      score += 60;
    }

    // New Section match (e.g. 393(1), 393(3), 394(1), 392(7))
    if (normalized.includes(item.newSection.toLowerCase())) {
      score += 50;
    }

    // Nature of payment match
    if (normalized.includes(item.nature.toLowerCase())) {
      score += 40;
    }

    // Keyword matches
    item.keywords.forEach(kw => {
      if (normalized.includes(kw.toLowerCase())) {
        score += 25;
      }
    });

    // Special scenario boosters
    if (normalized.includes("partner") && item.returnCode === "1067") score += 50;
    if (normalized.includes("machinery rent") && item.returnCode === "1008") score += 50;
    if (normalized.includes("building rent") && item.returnCode === "1009") score += 50;
    if (normalized.includes("contractor") && (item.returnCode === "1023" || item.returnCode === "1024")) score += 40;
    if (normalized.includes("technical") && item.returnCode === "1026") score += 45;
    if (normalized.includes("professional") && item.returnCode === "1027") score += 45;
    if (normalized.includes("brokerage") && item.returnCode === "1006") score += 45;
    if (normalized.includes("goods purchase") && item.returnCode === "1031") score += 50;
    if (normalized.includes("crypto") && item.returnCode === "1037") score += 50;
    if (normalized.includes("online game") && item.returnCode === "1060") score += 50;
    if (normalized.includes("motor vehicle") && item.returnCode === "1075") score += 50;
    if (normalized.includes("lrs") && item.returnCode === "1086") score += 50;
    if (normalized.includes("overseas tour") && item.returnCode === "1088") score += 50;

    if (score > highestScore) {
      highestScore = score;
      bestMatch = item;
    }
  });

  if (!bestMatch) {
    bestMatch = TDS_TCS_MASTER_2026_27.find(i => i.returnCode === "1067");
  }

  const amount = extractedAmount || 100000;
  displayClassificationResult(bestMatch, amount);
}

function parseAmount(text) {
  const clean = text.toLowerCase().replace(/,/g, '');
  const lakhMatch = clean.match(/(\d+(\.\d+)?)\s*(lakh|lakhs|lac|lacs|l)/);
  if (lakhMatch) return parseFloat(lakhMatch[1]) * 100000;

  const crMatch = clean.match(/(\d+(\.\d+)?)\s*(crore|crores|cr)/);
  if (crMatch) return parseFloat(crMatch[1]) * 10000000;

  const kMatch = clean.match(/(\d+(\.\d+)?)\s*(k|thousand)/);
  if (kMatch) return parseFloat(kMatch[1]) * 1000;

  const numMatch = clean.match(/₹?\s*(\d{4,10})/);
  if (numMatch) return parseFloat(numMatch[1]);

  return null;
}

function displayClassificationResult(item, amount) {
  const container = document.getElementById('classificationResultContainer');
  if (!container) return;

  const hasPan = document.getElementById('calcPanStatus')?.value !== 'no';
  const isCompany = document.getElementById('calcPayeeType')?.value === 'company';

  // Determine rate
  let effectiveRate = item.rateNumber || 10;
  if (item.rateIndividual && item.rateOthers) {
    effectiveRate = isCompany ? item.rateOthers : item.rateIndividual;
  }

  // Section 397(2) (Old 206AA / 206CC) No PAN rule:
  // 5% for 393(1) Sl 8(ii) [194Q] or 8(v) [194O]; 20% in any other case
  let isNoPanApplied = false;
  if (!hasPan) {
    isNoPanApplied = true;
    if (item.returnCode === "1031" || item.returnCode === "1035") {
      effectiveRate = 5;
    } else if (item.type === "TCS") {
      effectiveRate = Math.min(20, Math.max(effectiveRate * 2, 5));
    } else {
      effectiveRate = 20;
    }
  }

  let taxableAmount = amount;
  if (item.returnCode === "1031" && amount > 5000000) {
    taxableAmount = amount - 5000000;
  }

  const calculatedTax = (item.isSlab) 
    ? Math.round(calculateSlabTax(amount))
    : Math.round((taxableAmount * effectiveRate) / 100);

  const netPayable = item.type === "TCS" ? (amount + calculatedTax) : Math.max(0, amount - calculatedTax);

  container.innerHTML = `
    <div class="result-header-card">
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div class="section-code-pill">
          <span style="background: var(--primary-gradient); color: #fff; padding: 4px 10px; border-radius: 8px; font-size: 16px;">
            Return Code ${item.returnCode}
          </span>
          <span style="font-size: 16px; color: #60a5fa; font-weight: 700;">
            ${item.newSection}
          </span>
          <span style="font-size: 12px; color: var(--text-muted); background: var(--bg-chip); padding: 2px 8px; border-radius: 6px;">
            [Old Sec ${item.oldSection}]
          </span>
        </div>
        <div class="badge-pill rate-badge ${isNoPanApplied ? 'higher-rate' : ''}">
          ${item.type === 'TCS' ? 'TCS Rate' : 'TDS Rate'}: ${item.isSlab ? 'Slab Rates' : effectiveRate + '%'}
        </div>
      </div>
      
      <h3 class="section-title-large" style="margin-top: 14px;">${item.nature}</h3>
      
      <div class="result-badges">
        <span class="badge-pill">📋 Type: ${item.type}</span>
        <span class="badge-pill">📂 Category: ${item.category}</span>
        <span class="badge-pill">⚖️ Standard Rate: ${item.rateText}</span>
        <span class="badge-pill">🎯 Threshold: ${item.threshold}</span>
      </div>

      ${isNoPanApplied ? `
        <div class="notice-box" style="background: rgba(244, 63, 94, 0.1); border-left-color: var(--accent-rose); color: #fb7185;">
          <strong>⚠️ Section 397(2) Higher Deduction Applied:</strong> Payee has not furnished valid PAN. Rate set to <strong>${effectiveRate}%</strong>.
        </div>
      ` : ''}

      <!-- Computation Breakdown -->
      <div class="computation-box" style="margin-top: 18px;">
        <div class="comp-title">
          <span>${item.type === 'TCS' ? 'TCS Collection' : 'TDS Withholding'} Computation</span>
          <span style="font-size: 11px; text-transform: none; color: var(--text-muted); font-weight: 500;">
            Tax Year 2026-27 (IT Act 2025)
          </span>
        </div>
        
        <div class="comp-row">
          <span>Gross Transaction / Invoice Amount:</span>
          <span class="comp-val">₹${amount.toLocaleString('en-IN')}</span>
        </div>

        ${item.returnCode === "1031" ? `
        <div class="comp-row">
          <span>Less: Statutory Exemption (₹50 Lakhs):</span>
          <span class="comp-val">- ₹50,00,000</span>
        </div>
        <div class="comp-row">
          <span>Taxable Amount Subject to Deduction:</span>
          <span class="comp-val">₹${taxableAmount.toLocaleString('en-IN')}</span>
        </div>
        ` : ''}

        <div class="comp-row">
          <span>Applicable Rate:</span>
          <span class="comp-val">${item.isSlab ? 'Slab Computation' : effectiveRate + '%'}</span>
        </div>

        <div class="comp-row total-row">
          <span style="color: var(--accent-rose);">${item.type === 'TCS' ? 'Total TCS to Collect' : 'Total TDS to Withhold'}:</span>
          <span class="comp-val tax-val">${item.type === 'TCS' ? '+' : '-'} ₹${calculatedTax.toLocaleString('en-IN')}</span>
        </div>

        <div class="comp-row total-row" style="border-top: 1px dashed var(--border-subtle); margin-top: 4px; padding-top: 8px;">
          <span style="color: var(--accent-emerald);">${item.type === 'TCS' ? 'Total Invoice Amount Payable by Buyer' : 'Net Payout to Payee'}:</span>
          <span class="comp-val net-val">₹${netPayable.toLocaleString('en-IN')}</span>
        </div>
      </div>

      <!-- PDF Specifications Table -->
      <table class="info-table">
        <tbody>
          <tr>
            <td class="label-col">Codes to be used in Returns:</td>
            <td class="val-col"><strong style="font-family: var(--font-mono); color: #60a5fa;">${item.returnCode}</strong></td>
          </tr>
          <tr>
            <td class="label-col">Old Section (Income Tax Act 1961):</td>
            <td class="val-col">${item.oldSection}</td>
          </tr>
          <tr>
            <td class="label-col">New Section (Income Tax Act 2025):</td>
            <td class="val-col"><strong>${item.newSection}</strong></td>
          </tr>
          <tr>
            <td class="label-col">Prescribed Statutory Rates:</td>
            <td class="val-col">${item.rateText}</td>
          </tr>
          <tr>
            <td class="label-col">Statutory Threshold:</td>
            <td class="val-col">${item.threshold}</td>
          </tr>
        </tbody>
      </table>

      <div style="margin-top: 18px; display: flex; gap: 10px; justify-content: flex-end;">
        <button class="btn-secondary" onclick="addToBatchSchedule('${item.returnCode}', ${amount}, ${calculatedTax})">
          ➕ Add to Batch Schedule
        </button>
      </div>
    </div>
  `;
}

function calculateSlabTax(annualSalary) {
  const taxable = Math.max(0, annualSalary - 75000);
  if (taxable <= 700000) return 0;
  let tax = 0;
  if (taxable > 300000) tax += Math.min(taxable - 300000, 400000) * 0.05;
  if (taxable > 700000) tax += Math.min(taxable - 700000, 300000) * 0.10;
  if (taxable > 1000000) tax += Math.min(taxable - 1000000, 200000) * 0.15;
  if (taxable > 1200000) tax += Math.min(taxable - 1200000, 300000) * 0.20;
  if (taxable > 1500000) tax += (taxable - 1500000) * 0.30;
  return tax * 1.04;
}

// ==========================================
// 4. MASTER RATE CHART TABLE (MATCHING PDF)
// ==========================================
let currentChartFilterType = "All";
let currentChartSearch = "";

function initMasterChartTable() {
  const tbody = document.getElementById('masterChartTableBody');
  const searchInput = document.getElementById('masterChartSearchInput');
  const typeFilterBtns = document.querySelectorAll('.chart-type-btn');

  typeFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      typeFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentChartFilterType = btn.getAttribute('data-type');
      renderMasterChartTable();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentChartSearch = e.target.value.toLowerCase().trim();
      renderMasterChartTable();
    });
  }

  renderMasterChartTable();
}

function renderMasterChartTable() {
  const tbody = document.getElementById('masterChartTableBody');
  const countBadge = document.getElementById('masterChartCountBadge');
  if (!tbody) return;

  const filtered = TDS_TCS_MASTER_2026_27.filter(item => {
    const matchType = (currentChartFilterType === "All") || 
      (currentChartFilterType === "TDS Domestic" && item.type === "TDS Domestic") ||
      (currentChartFilterType === "TDS Foreign" && item.type === "TDS Foreign") ||
      (currentChartFilterType === "TCS" && item.type === "TCS");

    const matchSearch = currentChartSearch === "" ||
      item.returnCode.includes(currentChartSearch) ||
      item.oldSection.toLowerCase().includes(currentChartSearch) ||
      item.newSection.toLowerCase().includes(currentChartSearch) ||
      item.nature.toLowerCase().includes(currentChartSearch) ||
      item.rateText.toLowerCase().includes(currentChartSearch);

    return matchType && matchSearch;
  });

  if (countBadge) countBadge.textContent = `${filtered.length} Sections Found`;

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">No sections matched your query.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(row => `
    <tr onclick="selectSectionFromTable('${row.returnCode}')" style="cursor: pointer;">
      <td style="font-family: var(--font-mono); font-weight: 700; color: #60a5fa;">
        ${row.returnCode}
      </td>
      <td>
        <span class="badge-pill" style="font-size: 11px;">Sec ${row.oldSection}</span>
      </td>
      <td style="font-size: 13px; max-width: 380px;">
        <strong>${row.nature}</strong>
      </td>
      <td style="font-family: var(--font-mono); font-size: 12px; color: #34d399; font-weight: 600;">
        ${row.newSection}
      </td>
      <td style="font-family: var(--font-mono); font-weight: 700; color: #f59e0b;">
        ${row.rateText}
      </td>
      <td style="font-family: var(--font-mono); font-size: 12px; color: var(--text-secondary);">
        ${row.threshold}
      </td>
    </tr>
  `).join('');
}

function selectSectionFromTable(returnCode) {
  const item = TDS_TCS_MASTER_2026_27.find(i => i.returnCode === returnCode);
  if (!item) return;

  const tabBtn = document.querySelector('[data-tab="classifierTab"]');
  if (tabBtn) tabBtn.click();

  const searchInput = document.getElementById('smartSearchInput');
  if (searchInput) searchInput.value = item.returnCode;

  displayClassificationResult(item, item.thresholdAmount > 0 ? item.thresholdAmount * 1.5 : 100000);
}

// ==========================================
// 5. DIRECTORY CARDS
// ==========================================
function initSectionDirectory() {
  const container = document.getElementById('directoryCardsGrid');
  const searchInput = document.getElementById('directorySearchInput');
  const catWrap = document.getElementById('categoryFiltersContainer');

  let currentCategory = "All";

  if (catWrap) {
    catWrap.innerHTML = MASTER_CATEGORIES.map((cat, idx) => `
      <button class="filter-pill-btn ${idx === 0 ? 'active' : ''}" data-category="${cat}">
        ${cat}
      </button>
    `).join('');

    catWrap.querySelectorAll('.filter-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        catWrap.querySelectorAll('.filter-pill-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentCategory = btn.getAttribute('data-category');
        renderCards();
      });
    });
  }

  function renderCards() {
    if (!container) return;
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const list = TDS_TCS_MASTER_2026_27.filter(item => {
      const matchCat = currentCategory === "All" || item.category === currentCategory || item.type === currentCategory;
      const matchQ = query === "" || 
        item.returnCode.includes(query) ||
        item.oldSection.toLowerCase().includes(query) ||
        item.newSection.toLowerCase().includes(query) ||
        item.nature.toLowerCase().includes(query);
      return matchCat && matchQ;
    });

    if (list.length === 0) {
      container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">No cards matched.</div>`;
      return;
    }

    container.innerHTML = list.map(item => `
      <div class="section-card" onclick="selectSectionFromTable('${item.returnCode}')">
        <div>
          <div class="section-card-top">
            <div>
              <div class="section-card-code">Code ${item.returnCode}</div>
              <div style="font-size: 11px; color: var(--text-muted); font-family: var(--font-mono); margin-top: 2px;">
                Old: ${item.oldSection} ➔ New: ${item.newSection.split('[')[0]}
              </div>
            </div>
            <div class="section-rate-tag">${item.rateText.split('|')[0]}</div>
          </div>

          <div class="section-card-title" style="font-size: 14px; margin-bottom: 8px;">
            ${item.nature}
          </div>

          <div style="display: flex; gap: 6px; margin-bottom: 10px; flex-wrap: wrap;">
            <span style="font-size: 11px; padding: 2px 8px; border-radius: 999px; background: var(--bg-chip); color: var(--text-muted);">
              ${item.type}
            </span>
            <span style="font-size: 11px; padding: 2px 8px; border-radius: 999px; background: rgba(59, 130, 246, 0.15); color: #93c5fd;">
              ${item.category}
            </span>
          </div>
        </div>

        <div class="section-card-footer">
          <div><strong>Threshold:</strong> ${item.threshold}</div>
          <div class="view-details-link">
            Compute <span>→</span>
          </div>
        </div>
      </div>
    `).join('');
  }

  if (searchInput) {
    searchInput.addEventListener('input', renderCards);
  }

  renderCards();
}

// ==========================================
// 6. BATCH TDS/TCS VOUCHER BUILDER
// ==========================================
let batchItems = [
  { id: 1, party: "Alpha Tech Solutions", code: "1026", oldSec: "194J(a)", newSec: "393(1) [Table: Sl. No. 6(iii).D(a)]", gross: 120000, rate: 2, tax: 2400, type: "TDS" },
  { id: 2, party: "Supreme Logistics Corp", code: "1024", oldSec: "194C", newSec: "393(1) [Table: Sl. No. 6(i).D(b)]", gross: 85000, rate: 2, tax: 1700, type: "TDS" },
  { id: 3, party: "Rajesh Kumar (Partner)", code: "1067", oldSec: "194T", newSec: "393(3) [Table: Sl. No. 7]", gross: 80000, rate: 10, tax: 8000, type: "TDS" }
];

function initBatchBuilder() {
  const addBtn = document.getElementById('addBatchRowBtn');
  const printBtn = document.getElementById('printBatchBtn');
  const exportCsvBtn = document.getElementById('exportBatchCsvBtn');
  const codeSelect = document.getElementById('batchCodeSelect');

  // Populate code select from master
  if (codeSelect) {
    codeSelect.innerHTML = TDS_TCS_MASTER_2026_27.map(item => `
      <option value="${item.returnCode}">
        Code ${item.returnCode} | ${item.oldSection} ➔ ${item.newSection.split('[')[0]} | ${item.nature.substring(0, 45)}...
      </option>
    `).join('');
  }

  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const party = document.getElementById('batchPartyName').value.trim() || `Party ${batchItems.length + 1}`;
      const code = document.getElementById('batchCodeSelect').value;
      const amount = parseFloat(document.getElementById('batchAmount').value) || 50000;
      const hasPan = document.getElementById('batchPanStatus').value === 'yes';

      const item = TDS_TCS_MASTER_2026_27.find(i => i.returnCode === code) || TDS_TCS_MASTER_2026_27[0];
      let rate = item.rateNumber || 10;
      if (!hasPan) {
        rate = (code === "1031" || code === "1035") ? 5 : 20;
      }
      const tax = Math.round((amount * rate) / 100);

      batchItems.push({
        id: Date.now(),
        party,
        code: item.returnCode,
        oldSec: item.oldSection,
        newSec: item.newSection,
        gross: amount,
        rate,
        tax,
        type: item.type
      });

      renderBatchTable();
      document.getElementById('batchPartyName').value = '';
    });
  }

  if (printBtn) {
    printBtn.addEventListener('click', () => window.print());
  }

  if (exportCsvBtn) {
    exportCsvBtn.addEventListener('click', exportBatchToCsv);
  }

  renderBatchTable();
}

function addToBatchSchedule(returnCode, grossAmount, taxAmount) {
  const item = TDS_TCS_MASTER_2026_27.find(i => i.returnCode === returnCode) || TDS_TCS_MASTER_2026_27[0];
  batchItems.push({
    id: Date.now(),
    party: `Party u/s ${item.newSection.split('[')[0]}`,
    code: item.returnCode,
    oldSec: item.oldSection,
    newSec: item.newSection,
    gross: grossAmount,
    rate: item.rateNumber || 10,
    tax: taxAmount,
    type: item.type
  });

  const tabBtn = document.querySelector('[data-tab="batchTab"]');
  if (tabBtn) tabBtn.click();
  renderBatchTable();
}

function renderBatchTable() {
  const tbody = document.getElementById('batchTableBody');
  const totalGrossEl = document.getElementById('batchTotalGross');
  const totalTaxEl = document.getElementById('batchTotalTax');
  const totalNetEl = document.getElementById('batchTotalNet');

  if (!tbody) return;

  if (batchItems.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 24px;">No items in schedule.</td></tr>`;
    if (totalGrossEl) totalGrossEl.textContent = '₹0';
    if (totalTaxEl) totalTaxEl.textContent = '₹0';
    if (totalNetEl) totalNetEl.textContent = '₹0';
    return;
  }

  let sumGross = 0;
  let sumTax = 0;

  tbody.innerHTML = batchItems.map((item, idx) => {
    sumGross += item.gross;
    sumTax += item.tax;
    const net = item.type === "TCS" ? (item.gross + item.tax) : (item.gross - item.tax);

    return `
      <tr>
        <td>${idx + 1}</td>
        <td><strong>${item.party}</strong></td>
        <td><strong style="font-family: var(--font-mono); color: #60a5fa;">Code ${item.code}</strong></td>
        <td><span class="badge-pill" style="font-size: 11px;">${item.oldSec} ➔ ${item.newSec.split('[')[0]}</span></td>
        <td style="font-family: var(--font-mono);">₹${item.gross.toLocaleString('en-IN')}</td>
        <td style="font-family: var(--font-mono);">${item.rate}%</td>
        <td style="font-family: var(--font-mono); color: var(--accent-rose); font-weight: 700;">₹${item.tax.toLocaleString('en-IN')}</td>
        <td style="font-family: var(--font-mono); color: var(--accent-emerald); font-weight: 700;">₹${net.toLocaleString('en-IN')}</td>
        <td>
          <button class="delete-row-btn" onclick="deleteBatchRow(${item.id})" title="Delete">🗑️</button>
        </td>
      </tr>
    `;
  }).join('');

  if (totalGrossEl) totalGrossEl.textContent = `₹${sumGross.toLocaleString('en-IN')}`;
  if (totalTaxEl) totalTaxEl.textContent = `₹${sumTax.toLocaleString('en-IN')}`;
  if (totalNetEl) totalNetEl.textContent = `₹${(sumGross - sumTax).toLocaleString('en-IN')}`;
}

function deleteBatchRow(id) {
  batchItems = batchItems.filter(i => i.id !== id);
  renderBatchTable();
}

function exportBatchToCsv() {
  if (batchItems.length === 0) return;
  let csv = "ID,Party Name,Return Code,Old Section (1961),New Section (2025),Gross Amount (INR),Rate (%),Tax Amount (INR),Net Amount (INR)\n";
  batchItems.forEach((it, idx) => {
    csv += `${idx + 1},"${it.party}",${it.code},"${it.oldSec}","${it.newSec}",${it.gross},${it.rate}%,${it.tax},${it.gross - it.tax}\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `TDS_TCS_Schedule_TaxYear_2026_27_ITAct2025.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// ==========================================
// 7. SECTION 397(2) NO PAN RULES MODAL
// ==========================================
function initNoPanRulesModal() {
  const openBtn = document.getElementById('openNoPanRulesBtn');
  const modal = document.getElementById('noPanModal');
  const closeBtn = document.getElementById('noPanModalCloseBtn');

  if (openBtn && modal) {
    openBtn.addEventListener('click', () => modal.classList.add('active'));
  }
  if (closeBtn && modal) {
    closeBtn.addEventListener('click', () => modal.classList.remove('active'));
  }
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('active');
    });
  }
}
