# TDS & TCS Section Classifier Application (Tax Year 2026-27 / Income Tax Act 2025)

An interactive, responsive application for classifying, calculating, and managing TDS and TCS transactions under the **Income Tax Act, 2025** based on the official **TDS & TCS Rate Chart (Updated 08.04.2026)**.

---

## 🚀 How to Launch the Application

### Option 1: Double-Click Batch File (Recommended on Windows)
Double-click [`run_app.bat`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/run_app.bat). It will start the local server and open your default browser automatically.

### Option 2: Live Browser Link
Open **[http://localhost:3000](http://localhost:3000)** in Chrome, Edge, or Firefox.

### Option 3: Direct File Open (Offline)
Double-click [`index.html`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/index.html) to run standalone without any server requirements.

---

## 📂 Features Overview

1. **Smart NLP & Code Classifier**:
   - Search by **Return Code** (e.g. `1005`, `1006`, `1008`, `1009`, `1023`, `1026`, `1027`, `1031`, `1067`, `1075`, `1086`, etc.)
   - Search by **Old Section (1961 Act)** (e.g. `194T`, `194C`, `194J`, `194H`, `194Q`, `194-I`, `206C`)
   - Search by **New Section (2025 Act)** (e.g. `392(7)`, `393(1)`, `393(2)`, `393(3)`, `394(1)`)
   - Live tax withholding / collection calculation with net payout breakdown.

2. **Official Master Rate Chart (Full PDF Table)**:
   - Interactive data table matching all 9 pages of the PDF chart.
   - Filter by *All Sections (1004 - 1092)*, *Domestic TDS (1004 - 1067)*, *Foreign TDS (1039 - 1057)*, and *TCS (1068 - 1092)*.

3. **Section 397(2) No-PAN Rules (Old 206AA & 206CC)**:
   - Evaluates higher deduction rates (5% for Goods 393(1) Sl 8(ii) [194Q] & E-Commerce 393(1) Sl 8(v) [194O]; 20% for others; 2x rate or 5% for TCS).

4. **Batch Voucher Schedule Builder**:
   - Add multiple line items, calculate aggregated gross and tax values, export to CSV, and print professional withholding vouchers.

---

## 📁 Source Code Files

- [`index.html`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/index.html) — Single-page HTML5 UI.
- [`styles.css`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/styles.css) — Dark/Light theme design system.
- [`tds-data.js`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/tds-data.js) — Master PDF dataset (All 92 return codes and sections).
- [`app.js`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/app.js) — Classifier and calculation engine.
- [`run_app.bat`](file:///C:/Users/Gaurav%20Bhatti/.gemini/antigravity-ide/scratch/tds-classifier-app/run_app.bat) — One-click Windows application launcher.
