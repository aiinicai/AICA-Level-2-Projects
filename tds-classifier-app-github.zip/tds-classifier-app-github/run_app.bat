@echo off
title TDS ^& TCS Classifier Application (Income Tax Act 2025)
echo =========================================================================
echo    TDS ^& TCS RATE CHART ^& CLASSIFIER APPLICATION (TAX YEAR 2026-27)
echo                 INCOME TAX ACT, 2025 (PDF MASTER DATA)
echo =========================================================================
echo.
echo Starting local web server on port 3000...
start "" http://localhost:3000
python -m http.server 3000 --directory "%~dp0"
if %ERRORLEVEL% NEQ 0 (
    echo Python server not available, opening index.html directly...
    start "" "%~dp0index.html"
)
pause
