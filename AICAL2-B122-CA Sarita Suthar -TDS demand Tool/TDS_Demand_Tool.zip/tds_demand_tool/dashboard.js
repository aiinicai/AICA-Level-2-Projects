/*
 * dashboard.js - runs in the extension's dashboard tab and drives the TRACES
 * tab step by step (chrome.scripting). All data stays in this tab's memory
 * until the Excel file is downloaded. No network requests of its own.
 */
"use strict";
const C = self.TDECore, X = self.TDEXlsx;
// Each tool's page says which tool it is (<body data-tool="demand|challan|both" data-excel="...">).
// Controls that a tool's page does not have become harmless detached elements.
const TOOL = document.body.dataset.tool || "both";
const _stubs = {};
const $ = id => document.getElementById(id) || (_stubs[id] = _stubs[id] || document.createElement("div"));
const params = new URLSearchParams(location.search);
const HOME = params.get("home") || "https://www.tdscpc.gov.in/";   // ?home= only used by the test suite
const TRACES_MATCH = params.get("home") ? [new URL(HOME).protocol + "//" + new URL(HOME).hostname + "/*"] : ["https://*.tdscpc.gov.in/*"];
const FAST = params.has("fast");                                    // shorter pauses for the test suite
const PAUSE = FAST ? 250 : 1500, STEP_WAIT = FAST ? 300 : 1500, RETRIES = FAST ? 5 : 8;
const EXCEL_NAME = document.body.dataset.excel || "TDS_Demand_and_Challans.xlsx";
const VALIDATED_NAME = EXCEL_NAME.replace(/\.xlsx$/i, "_validated.xlsx");

const NO_DATA_SRC = "no\\s+(record|data|default|detail|challan)s?\\s+(found|available|exists?|to\\s+(view|display))|no\\s+defaults?\\b";
const RANGE_ERR_SRC = "(date|day|month|period|range).{0,50}(exceed|more\\s+than|maximum|max\\.?|within|not\\s+greater)|(exceed|maximum|not\\s+more\\s+than).{0,50}(day|month|period|range)";

let tabId = null, running = false, stopFlag = false, forceStart = false;
let demandRows = null, challanRows = null, challanFyList = [], readCount = 0;
let noFyInRange = false;
let menuPageUrl = null, askResolve = null, challanDumped = false, consumptionDumped = false, searchDumped = false;

class Stop extends Error {}

// ------------------------------------------------------------------ UI helpers
const logLines = [];
function log(msg) {
  const line = new Date().toTimeString().slice(0, 8) + "  " + msg;
  logLines.push(line);
  if (logLines.length > 3000) logLines.splice(0, 1000);
  if (params.has("test")) window.__logLines = logLines;
  status(msg.split("\n")[0]);
}
let section = "Run";              // "Run" (extraction) or "Val" (challan validation)
const status = msg => { $("status" + section).textContent = msg; };
const STAGE_CLASS = { "Validating challans": "run", "Status": "", "Waiting for you to log in": "wait", "Reading demand": "run", "Reading challans": "run", "Done": "done", "Stopped": "stop" };
function stage(s) { const b = $("stage" + section); b.textContent = s; b.className = "badge " + (STAGE_CLASS[s] || ""); }
function progress(p) { p = Math.max(0, Math.min(100, Math.round(p))); $("bar" + section).style.width = p + "%"; $("pct" + section).textContent = p + "%"; }
function setRunning(r) {
  running = r;
  $("stop").disabled = !r; $("browse").disabled = r;
  $("pickFilled").disabled = r; $("validate").disabled = r || !filledHandle;
  if (window.__checkRange) window.__checkRange(); else RUN_BUTTONS.forEach(id => { $(id).disabled = true; });
  if (r) RUN_BUTTONS.forEach(id => { $(id).disabled = true; });
  $("fyFrom").disabled = r; $("fyTo").disabled = r;
  $("saveAgain").disabled = r || (!demandRows && !challanRows);
}

// ------------------------------------------------------------------ timing
const ticker = new Worker("lib/tick.js");
const waiting = new Map(); let tickId = 0;
ticker.onmessage = e => { const r = waiting.get(e.data); waiting.delete(e.data); if (r) r(); };
const rawSleep = ms => new Promise(r => { const id = ++tickId; waiting.set(id, r); ticker.postMessage({ id, ms }); });
async function sleep(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (stopFlag) throw new Stop();
    await rawSleep(Math.min(200, end - Date.now()));
  }
  if (stopFlag) throw new Stop();
}
async function tabAlive() { try { await chrome.tabs.get(tabId); return true; } catch (e) { return false; } }
async function waitLoad() {
  await sleep(300);
  for (let i = 0; i < 100; i++) {
    let t; try { t = await chrome.tabs.get(tabId); } catch (e) { throw new Error("The TRACES tab was closed."); }
    if (t.status === "complete") break;
    await sleep(300);
  }
  await sleep(PAUSE);
}

// TRACES may open the Compliance module in a new tab: follow it.
chrome.tabs.onCreated.addListener(t => {
  if (running && tabId != null && t.openerTabId === tabId) { tabId = t.id; log("TRACES opened a new tab - following it."); }
});

// ------------------------------------------------------------------ page calls
async function ensure() {
  try { await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["lib/page.js"] }); } catch (e) { /* page busy / navigating */ }
}
async function call(fn, args = [], frameId = null) {
  await ensure();
  const target = frameId == null ? { tabId, allFrames: true } : { tabId, frameIds: [frameId] };
  try {
    const res = await chrome.scripting.executeScript({ target, func: (n, a) => (window.__tde ? window.__tde[n](...a) : null), args: [fn, args] });
    return res.filter(r => r.result != null).map(r => ({ frameId: r.frameId, result: r.result }));
  } catch (e) { return []; }
}
// Stop "Leave site?" pop-ups on the next navigation (runs in the page's own context).
async function allowLeave() {
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: "MAIN", func: () => {
      try { window.onbeforeunload = null; window.addEventListener("beforeunload", e => e.stopImmediatePropagation(), true); } catch (e) { /* ignore */ }
    } });
  } catch (e) { /* ignore */ }
}
async function tabPath() { try { return new URL((await chrome.tabs.get(tabId)).url).pathname; } catch (e) { return ""; } }
async function tabUrl() { try { return (await chrome.tabs.get(tabId)).url; } catch (e) { return ""; } }

// ------------------------------------------------------------------ clicking menus
let a11yLogged = false;
// The new TRACES dashboard is a Flutter app (drawn on a canvas). Its menus only
// exist as elements after its hidden "Enable accessibility" button is pressed.
async function enableFlutter() {
  const r = await call("enableA11y");
  if (r.some(x => x.result)) {
    if (!a11yLogged) { log("TRACES dashboard is a Flutter page - turned on its accessibility mode to see the menus."); a11yLogged = true; }
    await sleep(FAST ? 600 : 1500);
  }
}
async function clickStep(label, patterns, o = {}) {
  const retries = o.retries || RETRIES;
  for (let i = 0; i < retries; i++) {
    await enableFlutter();
    const found = (await call("find", [patterns, !!o.visibleOnly])).filter(r => r.result.found);
    if (found.length) {
      found.sort((a, b) => b.result.score - a.result.score);
      if (o.allowLeave) await allowLeave();
      const r = await call("click", [patterns, !!o.visibleOnly], found[0].frameId);
      if (r.length && r[0].result.clicked) {
        log("Clicked: " + label + (r[0].result.visible ? "" : " (hidden menu item)"));
        await waitLoad();
        return true;
      }
    }
    await sleep(STEP_WAIT);
  }
  if (!o.quiet) {
    log("NOT FOUND: " + label);
    if (!(await tabUrl())) log("The TRACES tab is now on a website this extension has no access to (only tdscpc.gov.in). Please tell me the address shown in that tab.");
  }
  return false;
}

async function followChain(steps, done) {
  let i = 0, last = null, reclicks = 0;
  while (i < steps.length) {
    const [label, pats, o = {}] = steps[i];
    if (o.optional) { await clickStep(label, pats, { retries: 4, visibleOnly: true, quiet: true, allowLeave: o.allowLeave }); i++; continue; }
    const before = await tabUrl();
    if (await clickStep(label, pats, o)) {
      if (o.menuPage) menuPageUrl = before;
      last = i; i++;
    } else if (last != null && reclicks < 3) {
      reclicks++; log(`'${steps[i][0]}' did not appear - clicking '${steps[last][0]}' again (${reclicks}/3)…`);
      await sleep(PAUSE); i = last;
    } else {
      let jumped = false;
      for (let j = steps.length - 1; j > i; j--) {
        if ((steps[j][2] || {}).optional) continue;
        if (await clickStep(steps[j][0], steps[j][1], Object.assign({}, steps[j][2], { retries: 1 }))) { i = j + 1; jumped = true; break; }
      }
      if (!jumped) return false;
    }
    if (await done()) return true;
  }
  for (let k = 0; k < RETRIES; k++) { if (await done()) return true; await sleep(STEP_WAIT); }
  return false;
}

// The path confirmed from the user's screenshots (Nov 2026).
const DEFAULT_STEPS = [
  ["Compliance under Income-tax Act, 1961", ["compliance\\W*under\\W*income\\W*tax", "income\\W*tax\\W*act\\W*,?\\W*1961"], { allowLeave: true }],
  ["Proceed", ["^\\s*proceed\\s*$"], { optional: true, allowLeave: true }],
  ["Defaults", ["^\\s*defaults?\\s*$", "defaults"], { menuPage: true }],
  ["View Default Summary", ["view\\s*default\\s*summary", "default\\s*summary"]],
];
const CHALLAN_STEPS = [
  ["Statements / Payments", ["statements?\\s*/\\s*payments?", "statements?\\s*(&|and)\\s*payments?", "^\\s*payments?\\s*$"], { menuPage: true }],
  ["Challan Status", ["challan\\s*status", "view\\s*challan", "challan\\s*details?"]],
];

// ------------------------------------------------------------------ login
async function loginSignals() {
  const res = await call("loginScan", [C.LOGIN_WEAK_SRC]);
  const texts = new Set(); let pwd = false;
  for (const r of res) { r.result.texts.forEach(t => texts.add(t)); pwd = pwd || r.result.pwd; }
  return { texts, pwd };
}
async function detectLogin(baseline) {
  const p = await tabPath();
  if (C.LOGGED_IN_PATH_RE.test(p) && !/login/i.test(p)) return "page " + p;
  const { texts, pwd } = await loginSignals();
  const strong = [...texts].filter(t => C.LOGIN_STRONG_RE.test(t)).sort();
  if (strong.length) return strong[0];
  if (pwd) return null;
  const fresh = [...texts].filter(t => !baseline.has(t)).sort();
  return fresh.length ? fresh[0] : null;
}

async function openTracesTab() {
  const existing = await chrome.tabs.query({ url: TRACES_MATCH });
  if (existing.length) {
    const rank = t => { const u = t.url || ""; return /\/app\//i.test(u) ? 3 : /dashboard|\/auth\//i.test(u) ? 2 : t.active ? 1 : 0; };
    existing.sort((a, b) => rank(b) - rank(a) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
    tabId = existing[0].id;
    await chrome.tabs.update(tabId, { active: true });
    log("Using the TRACES tab that is already open.");
    return false;
  }
  const t = await chrome.tabs.create({ url: HOME, active: true });
  tabId = t.id;
  log("Opening TRACES home page…");
  await waitLoad();
  return true;
}

async function waitForLogin() {
  const pre = await loginSignals();
  const baseline = new Set(pre.texts);
  if (!(await detectLogin(baseline))) {
    const r = await call("clickHomeLogin");
    if (r.some(x => x.result.clicked)) log("Clicked: Login");
  }
  stage("Waiting for you to log in");
  log("Please log in in the TRACES tab (User ID, password, TAN, captcha). The tool continues by itself.");
  const t0 = Date.now(); let hits = 0, dumped = false;
  while (true) {
    await sleep(1000);
    if (!(await tabAlive())) throw new Error("The TRACES tab was closed.");
    if (forceStart) { log("Starting now (you said you are logged in)."); return; }
    const el = (Date.now() - t0) / 1000;
    if (el < 6) { const s = await loginSignals(); if (!s.pwd && ![...s.texts].some(t => C.LOGIN_STRONG_RE.test(t))) s.texts.forEach(t => baseline.add(t)); continue; }
    const seen = await detectLogin(baseline);
    hits = seen ? hits + 1 : 0;
    if (seen && (hits >= 2 || seen.startsWith("page ") || C.LOGIN_STRONG_RE.test(seen))) {
      log("Login detected. Starting in a few seconds…");
      await sleep(FAST ? 1000 : 6000);
      return;
    }
    status(`Waiting for you to log in… (${Math.floor(el / 60)} min ${Math.floor(el % 60)} s)`);
    if (el > 90 && !dumped) { dumped = true; log("Still waiting for login… current page: " + (await tabPath())); }
  }
}

// ------------------------------------------------------------------ Default Summary
async function dropdowns() {
  const found = {};
  for (const r of await call("dropdowns")) {
    for (const d of r.result) {
      const kind = C.classifyDropdown(d.options);
      if (kind && !found[kind]) found[kind] = { frameId: r.frameId, index: d.index, values: C.dropdownValues(kind, d.options) };
    }
  }
  return found;
}
const onDefaultSummary = async () => !!(await dropdowns()).fy;
async function waitDropdowns() {
  for (let i = 0; i < RETRIES; i++) { const d = await dropdowns(); if (d.fy) return d; await sleep(STEP_WAIT); }
  return dropdowns();
}
async function selectKind(kind, val) {
  const d = await waitDropdowns();
  if (!d[kind]) throw new Error(`The ${kind === "fy" ? "Financial Year" : kind === "qtr" ? "Quarter" : "Form"} list disappeared.`);
  await call("selectOption", [d[kind].index, val], d[kind].frameId);
  await sleep(300);
  for (let i = 0; i < 30; i++) { const t = await chrome.tabs.get(tabId); if (t.status === "complete") break; await sleep(300); }
  await sleep(FAST ? 150 : 500);
}
async function optionsAfter(kind) {
  for (let i = 0; i < 3; i++) { const d = await dropdowns(); if (d[kind] && d[kind].values.length) return d[kind].values; await sleep(400); }
  return [null];
}
async function freshTables() {
  return (await call("tables", [true])).map(r => r.result);   // per frame
}
async function markStale() { await call("markStale", [[NO_DATA_SRC, RANGE_ERR_SRC]]); }
async function textVisible(src, skipStale) { return (await call("textVisible", [src, skipStale])).some(r => r.result); }

async function hasDetailsLink() {
  const a = (await call("hasAmountLink")).find(r => r.result);
  if (a) return { kind: "amount", frameId: a.frameId };
  const v = (await call("hasViewDetails")).find(r => r.result);
  return v ? { kind: "view", frameId: v.frameId } : null;
}
async function readSummary() {
  let noData = 0;
  for (let i = 0; i < RETRIES; i++) {
    for (const tables of await freshTables()) { const s = C.parseDefaultSummary(tables); if (s) return [s, "ok"]; }
    if ((await call("quarterList", [false])).some(r => r.result)) return [null, "list"];
    if (await textVisible(NO_DATA_SRC, true)) { if (++noData >= 2) return [null, "nodata"]; }
    else if (await hasDetailsLink()) return [null, "unknown"];      // a list: drill down
    await sleep(STEP_WAIT);
  }
  return [null, "unknown"];
}
function readList(tablesPerFrame) {
  for (const t of tablesPerFrame) { const s = C.parseDefaultList(t); if (s) return s; }
  return null;
}
// Result is a list: click the amount (or "View Details") to open the breakdown,
// read it, then come back - also when TRACES opens it in a new tab / pop-up.
async function drillDown() {
  const link = await hasDetailsLink();
  if (!link) return null;
  const home = tabId;
  await markStale();
  if (link.kind === "amount") {
    const r = await call("clickAmount", [], link.frameId);
    if (!r.length || !r[0].result) { log("Could not click the amount link."); return null; }
    log("Clicked the amount" + (r[0].result.header ? ` in '${r[0].result.header}'` : "") + " to open the details");
  } else { await call("viewDetails", [], link.frameId); log("Clicked: View Details"); }
  await sleep(500);
  await waitLoad();
  let s = null;
  for (let i = 0; i < RETRIES && !s; i++) {
    for (const t of await freshTables()) { s = C.parseDefaultSummary(t); if (s) break; }
    if (!s) await sleep(STEP_WAIT);
  }
  await returnToSearch(home);
  return s;
}
async function returnToSearch(home) {
  if (tabId !== home) {                       // details opened in a new tab / pop-up
    try { await chrome.tabs.remove(tabId); } catch (e) { /* already closed */ }
    tabId = home;
    await sleep(PAUSE);
  }
  if (!(await onDefaultSummary())) {
    for (const b of ["Back", "Close", "Cancel", "OK"]) {
      if (await clickStep(b, [`^\\s*${b}\\s*$`], { retries: 1, visibleOnly: true, quiet: true }) && await onDefaultSummary()) break;
    }
  }
  if (!(await onDefaultSummary())) { try { await chrome.tabs.goBack(tabId); } catch (e) { /* no history */ } await waitLoad(); }
  if (!(await onDefaultSummary())) { log("Re-opening View Default Summary…"); await followChain(DEFAULT_STEPS.slice(2), onDefaultSummary); }
}
async function readBreakdown() {
  for (let i = 0; i < RETRIES; i++) {
    for (const t of await freshTables()) { const s = C.parseDefaultSummary(t); if (s) return s; }
    await sleep(STEP_WAIT);
  }
  return null;
}

async function navigateDefaultSummary() {
  if (await onDefaultSummary()) { log("Default Summary page is already open."); return true; }
  // Already inside Compliance under Income-tax Act, 1961 (old TRACES tabs)? Go straight to Defaults.
  if (await followChain(DEFAULT_STEPS.slice(2).map(x => [x[0], x[1], Object.assign({}, x[2], { retries: 2 })]), onDefaultSummary)) return true;
  return followChain(DEFAULT_STEPS, onDefaultSummary);
}

async function search(fy, q, form) {
  for (const [k, v] of [["fy", fy], ["qtr", q], ["form", form]]) if (v != null) await selectKind(k, v);
  const dd = await waitDropdowns();
  await markStale();
  const sub = await call("clickSubmit", [], dd.fy.frameId);
  if (!sub.length || !sub[0].result) throw new Error("Submit / Go button not found on the Default Summary page.");
  await waitLoad();
}

// Result = "Default details for FY …": Quarter (blue link) | Form Type | Net Payable.
// Click each quarter with an amount > 0, read its breakdown, come back.
async function processQuarterList(fy, q, form, seen, rows) {
  const home = tabId;
  let list = (await call("quarterList", [false])).find(r => r.result);
  const items = list.result.rows;
  // Only when the list shows OTHER quarters is one search enough for the whole FY.
  // (Several forms of the SAME quarter is normal: Q2 -> 24Q and 26Q.)
  const coversMore = q == null || items.some(r => C.normalizeQtr(r.qtr) !== C.normalizeQtr(q));
  for (const it of items) {
    const qtr = C.normalizeQtr(it.qtr), frm = it.form ? C.normalizeForm(it.form) : (form ? C.normalizeForm(form) : "");
    const key = [C.normalizeFy(fy), qtr, frm].join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    const net = C.parseAmount(it.net) || 0;
    const label = [C.normalizeFy(fy), qtr, frm].filter(Boolean).join(" / ");
    let s = null, how = "";
    for (let attempt = 1; net > 0 && !s && attempt <= 2; attempt++) {
      if (!list) {                                   // list gone after coming back: search again
        await search(fy, q, form);
        list = (await call("quarterList", [true])).find(r => r.result) || null;
        if (!list) { log(`${label}: the list did not come back after returning.`); break; }
      }
      await markStale();
      const c = await call("clickListRow", [it.k], list.frameId);
      if (!c.length || !c[0].result) break;
      log(`Clicked quarter ${qtr}${frm ? " (" + frm + ")" : ""} for its details`);
      await sleep(500); await waitLoad();
      // the breakdown must belong to THIS row: its Net Payable must match the list
      let got = null;
      for (let k = 0; k < RETRIES && !got; k++) {
        for (const t of await freshTables()) {
          const b = C.parseDefaultSummary(t);
          if (b && Math.abs(b[C.NET_COL] - net) <= 10) { got = b; break; }
        }
        if (!got) await sleep(STEP_WAIT);
      }
      if (got) { s = got; how = " (full details)"; }
      else log(`${label}: the details shown did not match Net Payable ${net.toFixed(2)}` + (attempt === 1 ? " - trying again." : "."));
      await returnToSearch(home);
      list = (await call("quarterList", [true])).find(r => r.result) || null;
    }
    if (net > 0 && !s) { s = C.parseDefaultList([{ rows: [["Net Payable (Rs.)"], [String(net)]] }]); how = " (total only - breakdown not read)"; }
    const row = C.buildDemandRow(fy, qtr, frm, s);
    row._read = true;
    rows.push(row);
    log(`${label}: ` + (row[C.NET_COL] > 0 ? "demand found" : "nil") + how);
  }
  return coversMore;
}

async function extractDemand(fyFrom, fyTo) {
  const d = await waitDropdowns();
  if (!d.fy) throw new Error("Financial Year list not found on the Default Summary page.");
  const fys = d.fy.values.filter(f => C.fyInRange(f, fyFrom, fyTo));
  log(fys.length === 1 ? `Reading FY ${C.normalizeFy(fys[0])} only.` :
      `Reading ${fys.length} financial years: ${fys.map(C.normalizeFy).join(", ") || "none"}`);
  noFyInRange = !fys.length;
  if (!fys.length) log("TRACES does not offer any FY in the chosen range.");
  const rows = [], seen = new Set(); let n = 0, dumped = false;
  for (let fi = 0; fi < fys.length; fi++) {
    const fy = fys[fi];
    await selectKind("fy", fy);
    let fyDone = false;
    for (const q of await optionsAfter("qtr")) {
      if (fyDone) break;
      if (q != null) { await selectKind("fy", fy); await selectKind("qtr", q); }
      for (const form of await optionsAfter("form")) {
        if (fyDone) break;
        n++;
        await search(fy, q, form);
        let [s, state] = await readSummary();
        const label = [C.normalizeFy(fy), q && C.normalizeQtr(q), form && C.normalizeForm(form)].filter(Boolean).join(" / ");
        if (state === "list") {
          // one search lists the quarters/forms of the FY: no need to try every combination
          if (await processQuarterList(fy, q, form, seen, rows)) { fyDone = true; log(`FY ${C.normalizeFy(fy)}: all quarters read from its list.`); }
          continue;
        }
        let how = "";
        if (!s && state === "unknown") {
          const lst = readList(await freshTables());
          if (await hasDetailsLink()) { s = await drillDown(); if (s) how = " (full details)"; }
          if (!s && lst) { s = lst; how = " (total only - breakdown not shown)"; }
          if (!s && !dumped) { dumped = true; await saveStructure(`Result for ${label} not recognised`); }
        }
        const key = [C.normalizeFy(fy), q ? C.normalizeQtr(q) : "", form ? C.normalizeForm(form) : ""].join("|");
        if (seen.has(key)) continue;
        seen.add(key);
        const row = C.buildDemandRow(fy, q, form, s);
        row._read = !!s || state === "nodata";
        rows.push(row);
        log(`[${n}] ${label}: ` + (s ? (row[C.NET_COL] > 0 ? "demand found" : "nil") : state === "nodata" ? "no record" : "result not recognised") + how);
      }
    }
    progress(5 + 60 * (fi + 1) / Math.max(fys.length, 1));
  }
  return rows;
}

// ------------------------------------------------------------------ challans
// Statements / Payments -> Challan Status -> CIN + "Period of payment" -> Go ->
// Challan Deposit Date From / To (dd-mmm-yyyy, same FY) + Challan Status "All" -> Go ->
// "Challan Details" list (Date Of Deposit | Challan Serial Number | Challan Status), many pages.
const onChallanPage = async () => (await call("hasChallanForm")).some(r => r.result);
async function navigateChallan() {
  if (await onChallanPage()) return true;
  if (await followChain(CHALLAN_STEPS.map(x => [x[0], x[1], Object.assign({}, x[2], { retries: 3 })]), onChallanPage)) return true;
  if (menuPageUrl) {
    log("Going back to the TRACES menu page…");
    await chrome.tabs.update(tabId, { url: menuPageUrl });
    await waitLoad();
    if (await followChain(CHALLAN_STEPS, onChallanPage)) return true;
  }
  // still on the new dashboard: Compliance under Income-tax Act -> Proceed first
  return followChain(DEFAULT_STEPS.slice(0, 2).concat(CHALLAN_STEPS), onChallanPage);
}
const ONE_FY_ERR_SRC = "same\\s*(financial|fin\\.?)\\s*year|within.{0,30}financial\\s*year";
const AMOUNT_ERR_SRC = "invalid\\s*(challan\\s*)?amount|does\\s*not\\s*match|mismatch|incorrect\\s*(challan\\s*)?amount";

// First screen: CIN + "Period of payment" + Go, until the From / To date boxes show.
async function openPeriodSearch() {
  if (!(await onChallanPage()) && !(await navigateChallan())) return null;
  for (let i = 0; i < RETRIES; i++) {
    const f = (await call("dateFields")).find(r => r.result.length >= 2);
    if (f) return f;
    const pr = (await call("checkRadio", ["period\\s*of\\s*payment"])).find(r => r.result);
    if (pr) {
      await call("checkRadio", ["^\\s*CIN\\b"], pr.frameId);
      await sleep(300);
      await call("clickSubmit", ["first"], pr.frameId);
      log("Selected CIN + Period of payment, clicked Go");
      await waitLoad();
    } else await sleep(STEP_WAIT);
  }
  return null;
}
async function readChallanList(skipStale) {
  const out = [];
  for (const r of await call("tables", [!!skipStale])) out.push(...C.parseChallanList(r.result));
  return out;
}
async function readAllChallanPages() {
  const rows = await readChallanList(false);
  const keys = new Set(rows.map(C.challanKey));
  let pages = 1;
  while (pages < 200) {
    const nx = await call("nextPage");
    if (!nx.some(r => r.result)) break;
    await waitLoad();
    const fresh = (await readChallanList(false)).filter(r => !keys.has(C.challanKey(r)));
    if (!fresh.length) break;
    fresh.forEach(r => keys.add(C.challanKey(r)));
    rows.push(...fresh); pages++;
  }
  return [rows, pages];
}
// One search. -> ["rows", list, pages] | ["none"] | ["range"] | ["timeout"]
async function searchPeriod(from, to, allPages = true) {
  const f = await openPeriodSearch();
  if (!f) return ["timeout", (await onChallanPage()) ? "the From / To date boxes did not appear" : "could not open Challan Status"];
  // TRACES fills the results into the SAME grid table each time (jqGrid), so remember
  // what is on screen now and wait for the list to change.
  const before = new Set((await readChallanList(false)).map(C.challanKey));
  const fields = f.result, a = fields.find(x => /from|start/i.test(x.hint)) || fields[0];
  const b = fields.find(x => x !== a && /\bto\b|end|till|upto/i.test(x.hint)) || fields.find(x => x !== a);
  await call("fillInput", [a.index, C.formatDateForField(from, a.hint, a.type)], f.frameId);
  await call("fillInput", [b.index, C.formatDateForField(to, b.hint, b.type)], f.frameId);
  await call("selectByOption", ["^\\s*all\\s*$"], f.frameId);
  await sleep(300);
  await markStale();
  await call("clickSubmit", ["last"], f.frameId);
  await waitLoad();
  let same = 0;
  for (let i = 0; i < RETRIES + 6; i++) {
    const now = await readChallanList(false);
    if (now.length && (before.size === 0 || now.some(r => !before.has(C.challanKey(r))) || ++same >= 3)) {
      await call("unmarkStale");
      if (!allPages) return ["rows", now, 1];
      const [list, pages] = await readAllChallanPages();
      return ["rows", list, pages];
    }
    if (await textVisible(RANGE_ERR_SRC, true) || await textVisible(ONE_FY_ERR_SRC, true)) return ["range"];
    if (await textVisible(NO_DATA_SRC, true)) return ["none"];
    await sleep(STEP_WAIT);
  }
  if (await textVisible(NO_DATA_SRC, false)) return ["none"];
  return ["timeout", "no challan list appeared after Go"];
}
async function ask(text) {
  $("askText").textContent = text; $("ask").style.display = "block";
  try {
    const a = await new Promise(resolve => { askResolve = resolve; });
    if (a === "stop") throw new Stop();
    return a;
  } finally { $("ask").style.display = "none"; askResolve = null; }
}
async function challansForFy(fy) {
  status(`Reading challans for FY ${fy}…`);
  const [start, end] = C.fyBounds(fy);
  try {
    for (const months of [12, 3, 1]) {
      const all = new Map(); let ok = true;
      for (const [s, e] of C.splitMonths(start, end, months)) {
        const r = await searchPeriod(s, e);
        if (r[0] === "range") { log("TRACES limits the date range - searching in smaller parts."); ok = false; break; }
        if (r[0] === "timeout") throw new Error(r[1] || "no result appeared");
        if (r[0] === "rows") { r[1].forEach(c => all.set(C.challanKey(c), c)); log(`FY ${fy} ${C.fmtTracesDate(s)} to ${C.fmtTracesDate(e)}: ${r[1].length} challan(s) on ${r[2]} page(s)`); }
        else log(`FY ${fy} ${C.fmtTracesDate(s)} to ${C.fmtTracesDate(e)}: no challans`);
      }
      if (ok) return [...all.values()];
    }
  } catch (e) {
    if (e instanceof Stop) throw e;
    log(`FY ${fy}: automatic challan search did not work (${e.message}) - asking you to search once.`);
    if (!challanDumped) { challanDumped = true; await saveStructure(`Challan list not read (FY ${fy})`); }
  }
  const rows = new Map();
  while (true) {
    const a = await ask(`FY ${fy}: in the TRACES tab open Statements / Payments → Challan Status → Period of payment and search ` +
      `${C.fmtTracesDate(start)} to ${C.fmtTracesDate(end)} (Challan Status: All). Then click "Results are on screen".`);
    if (a === "skip") break;
    (await readAllChallanPages())[0].forEach(c => rows.set(C.challanKey(c), c));
    if (a !== "more") break;
  }
  return [...rows.values()];
}

// ------------------------------------------------------------------ challan validation
// For each challan whose Amount Deposited the user typed into the Excel file:
// search its date, click its row, give the amount if TRACES asks, read the details.
async function validateOne(row) {
  let rawDate = row[C.CH.DATE];
  if (typeof rawDate === "number") rawDate = C.fromExcelDate(rawDate);      // Excel turned the text into a date
  const date = C.parseDate(String(rawDate || "")), serial = String(row[C.CH.SERIAL] || "").replace(/\s/g, "").replace(/\.0+$/, "");
  const dep = C.parseAmount(row[C.CH.AMOUNT]);
  if (!date || !serial) return { remarks: "Date or serial number missing" };
  // Search the challan's whole FY (the same search that works for extraction),
  // then find its row on whichever page it is.
  const [fs, fe] = C.fyBounds(C.fyOfDate(date));
  let r = await searchPeriod(fs, fe, false);
  if (r[0] === "range" || r[0] === "timeout") r = await searchPeriod(date, date, false);     // fall back to that one day
  if (r[0] !== "rows") {
    if (r[0] === "timeout" && !searchDumped) { searchDumped = true; await saveStructure("Validation search: " + (r[1] || "no list")); }
    return { remarks: r[0] === "none" ? "Not found in TRACES for that date" : "TRACES search did not work: " + (r[1] || "no list appeared") };
  }
  let clicked = null;
  for (let page = 0; page < 200 && !clicked; page++) {
    await markStale();
    clicked = (await call("clickChallanRow", [serial])).find(x => x.result);
    if (clicked) break;
    await call("unmarkStale");
    if (!(await call("nextPage")).some(x => x.result)) break;
    await waitLoad();
  }
  if (!clicked) return { remarks: `Challan serial ${serial} not in the TRACES list for FY ${C.fyOfDate(date)}` };
  await sleep(400);
  // TRACES: select the row -> "View Consumption Details" -> pop-up "Enter Challan Amount(Rs.)" -> Proceed
  if (!(await clickStep("View Consumption Details", ["view\\s*consumption\\s*details?", "consumption\\s*details?"], { retries: 4, visibleOnly: true })))
    return { remarks: "'View Consumption Details' not found" };
  let box = null;
  for (let i = 0; i < RETRIES && !box; i++) {
    for (const x of await call("textInputs")) {
      // the pop-up's own box first; never the From / To date boxes
      const ok = x.result.filter(t => !/date|from|\bto\b/i.test(t.near));
      const f = ok.find(t => t.inDialog && /amount/i.test(t.hint)) || ok.find(t => t.inDialog) || ok.find(t => /amount/i.test(t.near));
      if (f) { box = { frameId: x.frameId, f }; break; }
    }
    if (!box) await sleep(STEP_WAIT);
  }
  if (!box) return { remarks: "Challan amount box did not appear" };
  const amt = Number.isInteger(dep) ? String(dep) : dep.toFixed(2);
  await call("fillInput", [box.f.index, amt], box.frameId);
  await sleep(300);
  await call("markStale", [[NO_DATA_SRC, RANGE_ERR_SRC, AMOUNT_ERR_SRC]]);   // an old red message is not this challan's
  if (!(await clickStep("Proceed", ["^\\s*proceed\\s*$"], { retries: 3, visibleOnly: true })))
    await call("clickSubmit", ["last"], box.frameId);
  await sleep(500); await waitLoad();
  // wrong amount -> "Invalid Challan Amount" in red; right amount -> consumption details
  let found = { deposited: null, consumed: null, balance: null, status: "" };
  for (let i = 0; i < RETRIES + 2; i++) {
    if (await textVisible(AMOUNT_ERR_SRC, true)) return INVALID;
    const pairs = [];
    for (const p of await call("pairs", [i >= 3])) pairs.push(...p.result);
    found = C.challanAmountsFromPairs(pairs);
    for (const t of (await call("tables", [i < 3])).map(r => r.result)) {
      const g = C.challanAmountsFromTables(t);
      if (found.consumed == null && g.consumed != null) found.consumed = g.consumed;
      if (found.balance == null && g.balance != null) found.balance = g.balance;
      if (found.deposited == null && g.deposited != null) found.deposited = g.deposited;
    }
    if (found.consumed != null || found.balance != null) break;
    await sleep(STEP_WAIT);
  }
  if (found.consumed == null && found.balance == null && await textVisible(AMOUNT_ERR_SRC, false)) return INVALID;
  const res = C.validateResult(dep, found, row[C.CH.TSTATUS]);
  if (found.consumed == null && found.balance == null) {
    res.remarks = "Amount accepted by TRACES, but its consumption details were not recognised" + (res.remarks ? "; " + res.remarks : "");
    if (!consumptionDumped) { consumptionDumped = true; await saveStructure("Consumption details page not recognised"); }
  }
  if (found.deposited != null && Math.abs(found.deposited - dep) > 0.5) res.remarks = (res.remarks ? res.remarks + "; " : "") + `TRACES shows amount ${found.deposited}`;
  return res;
}

const INVALID = { status: "Invalid amount", remarks: "TRACES: Invalid Challan Amount (does not match the amount deposited)" };
let filledHandle = null;
function sheetObjects(rows) {
  const head = (rows[0] || []).map(h => C.normSpace(h));
  return { head, rows: rows.slice(1).filter(r => r && r.some(v => v !== null && v !== "")).map(r => Object.fromEntries(head.map((h, i) => [h, r[i] == null ? null : r[i]]))) };
}
async function validateAll() {
  section = "Val";
  if (!filledHandle) { log("Choose the filled Excel file first."); return; }
  stopFlag = false; setRunning(true); stage("Validating challans"); progress(0);
  try {
    const wb = await TDEXlsxRead.readXlsx(await (await filledHandle.getFile()).arrayBuffer());
    if (!wb.challans) throw new Error("The file has no 'challans' sheet.");
    const ch = sheetObjects(wb.challans);
    const findCol = re => ch.head.find(h => re.test(h));
    const map = { [C.CH.FY]: findCol(/^fy$/i), [C.CH.DATE]: findCol(/date/i), [C.CH.SERIAL]: findCol(/serial/i),
      [C.CH.TSTATUS]: findCol(/challan\s*status|traces/i), [C.CH.AMOUNT]: findCol(/amount\s*deposited/i) };
    if (!map[C.CH.DATE] || !map[C.CH.SERIAL] || !map[C.CH.AMOUNT]) throw new Error("The challans sheet needs Date Of Deposit, Challan Serial Number and Amount Deposited columns.");
    const rows = ch.rows.map(r => { const o = {}; for (const k of C.CHALLAN_COLUMNS) o[k] = map[k] ? r[map[k]] : (r[k] == null ? null : r[k]); return o; });
    rows.forEach(r => {
      r[C.CH.SERIAL] = r[C.CH.SERIAL] == null ? "" : String(r[C.CH.SERIAL]);
      if (typeof r[C.CH.DATE] === "number") r[C.CH.DATE] = C.fmtTracesDate(C.fromExcelDate(r[C.CH.DATE]));   // Excel date -> text
    });
    const todo = rows.filter(r => (C.parseAmount(r[C.CH.AMOUNT]) || 0) > 0);
    log(`${todo.length} of ${rows.length} challan(s) have an Amount Deposited - validating them in TRACES.`);
    if (!todo.length) throw new Error("No Amount Deposited was filled in. Type the amounts in the yellow column, save the file, then try again.");
    const opened = await openTracesTab();
    const inside = !opened && (await detectLogin(new Set()) || await onChallanPage() || await onDefaultSummary());
    if (!inside) await waitForLogin();
    stage("Validating challans");
    for (let i = 0; i < todo.length; i++) {
      const r = todo[i];
      status(`Validating challan ${i + 1} of ${todo.length}: ${r[C.CH.DATE]} / ${r[C.CH.SERIAL]}`);
      let res;
      try { res = await validateOne(r); } catch (e) { if (e instanceof Stop) throw e; res = { remarks: "Error: " + e.message }; }
      r[C.CH.AMOUNT] = C.parseAmount(r[C.CH.AMOUNT]);
      r[C.CH.VSTATUS] = res.status || null; r[C.CH.CONSUMED] = res.consumed ?? null; r[C.CH.UNUSED] = res.unused ?? null;
      r[C.CH.OVER] = res.over ?? null; r[C.CH.REMARKS] = res.remarks || null;
      log(`${r[C.CH.DATE]} / ${r[C.CH.SERIAL]}: ${res.status || "not validated"}` + (res.unused ? ` - unconsumed ${res.unused}` : "") + (res.over ? ` - overbooked ${res.over}` : "") + (res.remarks ? ` (${res.remarks})` : ""));
      progress(100 * (i + 1) / todo.length);
    }
    // write back: demand sheet as it was, challans sheet with the results
    const sheets = [];
    if (wb.demand) {
      const dem = sheetObjects(wb.demand);
      sheets.push({ name: "demand", headerHeight: 75, rows: dem.rows,
        columns: dem.head.map((k, i) => ({ key: k, type: i < 3 ? "text" : "num", width: i < 3 ? 10 : 16 })) });
    }
    sheets.push(challanSheet(rows));
    const bytes = X.buildXlsx(sheets);
    let saved = false;
    try {
      if ((await filledHandle.queryPermission({ mode: "readwrite" })) === "granted") {
        const w = await filledHandle.createWritable(); await w.write(bytes); await w.close(); saved = true;
        log(`Results written into ${filledHandle.name || "the Excel file"}.`);
      }
    } catch (e) { log(`Could not write into ${filledHandle.name} (${e.name}) - is it open in Excel? Saving a copy instead.`); }
    if (!saved) { const where = await download(bytes, VALIDATED_NAME, "application/octet-stream"); log(`Saved ${VALIDATED_NAME} in ${where}.`); }
    if (params.has("test")) window.__validatedDone = true;
    const by = {};
    todo.forEach(r => { const k = r[C.CH.VSTATUS] || "not validated"; by[k] = (by[k] || 0) + 1; });
    log("Validation done: " + Object.entries(by).map(([k, v]) => `${v} ${k}`).join(", "));
    challanRows = rows;
    $("result").style.display = "block"; $("boxDemand").style.display = "none"; $("boxChallans").style.display = "block";
    renderTable($("tChallans"), C.CHALLAN_COLUMNS, rows);
    stage("Done"); progress(100);
    popup("Challans Validated", `${todo.length} challan(s) checked. The results are in ${saved ? filledHandle.name : VALIDATED_NAME}.`);
  } catch (e) {
    stage("Stopped");
    log(e instanceof Stop ? "Stopped." : "Stopped: " + e.message);
  } finally { setRunning(false); }
}

// ------------------------------------------------------------------ saving
// Where to save: a folder picked with "Browse…" (Chrome's folder picker) or Downloads.
// The folder permission lives only in this tab's memory; nothing is stored.
let dirHandle = null;
const destDownloads = () => document.querySelector("input[name=dest]:checked").value === "downloads";
function whereText() { return destDownloads() || !dirHandle ? "your Downloads folder" : `folder "${dirHandle.name}"`; }
async function writeToFolder(bytes, name) {
  try {
    let perm = await dirHandle.queryPermission({ mode: "readwrite" });
    if (perm !== "granted") perm = await dirHandle.requestPermission({ mode: "readwrite" });
    if (perm !== "granted") return false;
    const fh = await dirHandle.getFileHandle(name, { create: true });
    const w = await fh.createWritable();
    await w.write(bytes); await w.close();
    return true;
  } catch (e) {
    log(`Could not write to folder "${dirHandle.name}" (${e.name || e.message}) - saving to Downloads instead.`);
    return false;
  }
}
async function download(bytes, name, mime) {
  if (!destDownloads() && dirHandle && await writeToFolder(bytes, name)) return dirHandle.name ? `folder "${dirHandle.name}"` : "the folder you chose";
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  try { await chrome.downloads.download({ url, filename: name, saveAs: false, conflictAction: "overwrite" }); }
  finally { setTimeout(() => URL.revokeObjectURL(url), 60000); }
  return "your Downloads folder";
}
function challanSheet(rows) {
  const W = { [C.CH.FY]: 10, [C.CH.DATE]: 15, [C.CH.SERIAL]: 15, [C.CH.TSTATUS]: 16, [C.CH.AMOUNT]: 18, [C.CH.VSTATUS]: 20, [C.CH.REMARKS]: 36 };
  return { name: "challans", headerHeight: 32, rows,
    columns: C.CHALLAN_COLUMNS.map(k => ({ key: k, width: W[k] || 16, input: k === C.CH.AMOUNT,
      type: [C.CH.AMOUNT, C.CH.CONSUMED, C.CH.UNUSED, C.CH.OVER].includes(k) ? "num" : "text" })) };
}
function excelBytes() {
  const sheets = [];
  if (runMode !== "challan") sheets.push({ name: "demand", headerHeight: 75, rows: demandRows || [],
    columns: C.DEMAND_COLUMNS.map((k, i) => ({ key: k, type: i < 3 ? "text" : "num", width: i === 2 ? 14 : i < 3 ? 9 : 16 })) });
  if (runMode !== "demand") sheets.push(challanSheet(challanRows || []));
  return X.buildXlsx(sheets);
}
async function saveExcel(again) {
  if (!demandRows && !challanRows) { log("Nothing to save yet - run the extraction first."); return; }
  const bytes = excelBytes();
  if (params.has("test")) { let b = ""; for (let i = 0; i < bytes.length; i += 8192) b += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); window.__lastXlsx = btoa(b); }
  const where = await download(bytes, EXCEL_NAME, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  let note = "";
  if (runMode !== "challan" && !demandRows.length)
    note = noFyInRange ? " TRACES does not offer any FY in the chosen range."
         : readCount === 0 ? " No Default Summary result could be read (traces_structure.txt was saved - please send it)."
         : " TRACES shows no amount payable in the chosen years.";
  log((again ? `Saved again at ${new Date().toTimeString().slice(0, 8)}: ` : "Saved: ") + `${EXCEL_NAME} in ${where}.` + note);
  showResult();
  popup("Details Downloaded", `${EXCEL_NAME} has been saved in ${where}.` + note);
}
async function saveStructure(reason) {
  if (tabId == null || !(await tabAlive())) { log("Open TRACES first."); return; }
  await enableFlutter();
  const lines = [`TRACES structure (names only) ${new Date().toISOString()}`, `Reason: ${reason}`, `Tab: ${await tabPath()}`];
  for (const r of await call("structure")) {
    const o = r.result;
    lines.push(`\n--- frame ${r.frameId}: ${o.url}`);
    if (o.loginFormSkipped) lines.push("  [login form present - not inspected]");
    for (const k of ["headings", "menus", "links", "buttons"]) if (o[k].length) lines.push(`  ${k}: ` + o[k].map(C.redact).join(" | "));
    for (const s of o.selects) lines.push(`  dropdown '${C.redact(s.name)}': ` + s.options.map(C.redact).join(" | "));
    for (const t of o.tables) lines.push("  table headings: " + t.map(C.redact).join(" | "));
  }
  const text = lines.join("\n") + "\n";
  if (params.has("test")) window.__lastStructure = text;
  const where = await download(new TextEncoder().encode(text), "traces_structure.txt", "text/plain");
  log(`traces_structure.txt (names only) saved in ${where}.`);
}
function renderTable(el, cols, rows) {
  el.textContent = "";
  const t = document.createElement("table"), hr = t.createTHead().insertRow();
  cols.forEach(c => { const th = document.createElement("th"); th.textContent = c; hr.appendChild(th); });
  const tb = t.createTBody();
  if (!rows.length) { const td = tb.insertRow().insertCell(); td.colSpan = cols.length; td.textContent = "(no rows)"; }
  rows.forEach(r => { const tr = tb.insertRow(); cols.forEach(c => { const td = tr.insertCell(); const v = r[c];
    if (typeof v === "number") { td.textContent = v.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); td.className = "n"; }
    else td.textContent = v == null ? "" : v; }); });
  el.appendChild(t);
}
function showResult() {
  $("result").style.display = "block";
  $("boxDemand").style.display = runMode !== "challan" ? "block" : "none";
  $("boxChallans").style.display = runMode !== "demand" ? "block" : "none";
  if (runMode !== "challan") renderTable($("tDemand"), C.DEMAND_COLUMNS, demandRows || []);
  if (runMode !== "demand") renderTable($("tChallans"), C.CHALLAN_COLUMNS, challanRows || []);
}
// "Details Downloaded" pop-up; also brings the dashboard tab to the front.
async function popup(title, text) {
  $("modalTitle").textContent = title; $("modalText").textContent = text;
  $("modal").classList.add("show");
  try { const me = await chrome.tabs.getCurrent(); if (me) { await chrome.tabs.update(me.id, { active: true }); await chrome.windows.update(me.windowId, { focused: true }); } } catch (e) { /* ignore */ }
}

// ------------------------------------------------------------------ main run
const RUN_BUTTONS = ["runDemand", "runChallan", "runBoth"].filter(id => document.getElementById(id));
let runMode = TOOL;
// mode: "demand" | "challan" | "both"
async function runAll(mode) {
  runMode = mode; section = "Run";
  stopFlag = false; forceStart = false; setRunning(true);
  demandRows = challanRows = null; challanFyList = []; readCount = 0; menuPageUrl = null;
  $("result").style.display = "none"; progress(0);
  const fyFrom = $("fyFrom").value, fyTo = $("fyTo").value;
  if (!fyFrom || !fyTo) { log("Please select both From FY and To FY."); setRunning(false); return; }
  try {
    const opened = await openTracesTab();
    const already = !opened && (await detectLogin(new Set()) || await onChallanPage() || await onDefaultSummary());
    if (!already) await waitForLogin();
    if (mode !== "challan") {
      stage("Reading demand"); progress(3);
      if (!(await navigateDefaultSummary())) {
        await saveStructure("Could not open View Default Summary");
        throw new Error("Could not open View Default Summary. Open Defaults → View Default Summary in the TRACES tab and run again.");
      }
      const rows = await extractDemand(fyFrom, fyTo);
      readCount = rows.filter(r => r._read).length;
      if (rows.length && !readCount) await saveStructure("No Default Summary result could be read");
      else if (!rows.length) readCount = -1;
      demandRows = C.filterDemand(rows).map(r => { const o = Object.assign({}, r); delete o._read; return o; });
      log(`Demand rows with Net Payable > 0: ${demandRows.length}.`);
    }
    if (mode !== "demand") {
      // Both: each demand FY plus one before and after. Challan only: every FY in the chosen range.
      const cur = C.fyStartYear(C.currentFy());
      challanFyList = mode === "both" ? C.challanFys(C.demandFys(demandRows))
        : C.fyChoices().reverse().filter(fy => C.fyInRange(fy, fyFrom, fyTo) && C.fyStartYear(fy) <= cur);
      log(`Challan years: ${challanFyList.join(", ") || "none"}`);
      stage("Reading challans"); progress(mode === "both" ? 66 : 5);
      challanRows = [];
      for (let i = 0; i < challanFyList.length; i++) {
        const fy = challanFyList[i];
        const list = (await challansForFy(fy)).sort((x, y) => x.date.localeCompare(y.date));
        challanRows.push(...C.challanSheetRows(list, fy));
        progress((mode === "both" ? 66 : 5) + (mode === "both" ? 30 : 90) * (i + 1) / challanFyList.length);
      }
      log(`Challans read: ${challanRows.length}.`);
    }
    stage("Done"); progress(100);
    await saveExcel(false);
  } catch (e) {
    stage("Stopped");
    log(e instanceof Stop ? "Stopped." : "Stopped: " + e.message);
  } finally {
    setRunning(false);
  }
}

// ------------------------------------------------------------------ reset
// Clear every choice and result so the tool can be used again - with the same or
// another TRACES login. A run in progress is stopped first. Nothing is stored anyway.
async function resetAll() {
  if (running) {
    stopFlag = true; if (askResolve) askResolve("stop");
    for (let i = 0; i < 100 && running; i++) await new Promise(r => setTimeout(r, 100));
  }
  stopFlag = false; forceStart = false;
  tabId = null; menuPageUrl = null; a11yLogged = false;
  demandRows = challanRows = null; challanFyList = []; readCount = 0; runMode = TOOL;
  challanDumped = consumptionDumped = searchDumped = false;
  dirHandle = null; filledHandle = null;
  logLines.length = 0;
  $("fyFrom").value = ""; $("fyTo").value = "";
  document.querySelector("input[name=dest][value=pick]").checked = true;
  $("folderName").textContent = "No Folder Selected"; $("folderName").className = "folder none";
  $("filledName").textContent = "No File Chosen"; $("filledName").className = "folder none";
  for (const sec of ["Run", "Val"]) {
    section = sec; stage("Status"); progress(0); $("status" + sec).textContent = "Ready.";
  }
  section = "Run";
  $("result").style.display = "none"; $("tDemand").textContent = ""; $("tChallans").textContent = "";
  $("ask").style.display = "none"; $("modal").classList.remove("show");
  setRunning(false);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ------------------------------------------------------------------ wiring
(function init() {
  // oldest first, so the lists read naturally
  for (const id of ["fyFrom", "fyTo"]) for (const fy of C.fyChoices().reverse()) { const o = document.createElement("option"); o.value = o.textContent = fy; $(id).appendChild(o); }
  const checkRange = () => {
    const f = $("fyFrom").value;
    // "To FY" may not be earlier than "From FY": hide and disable those years
    for (const o of $("fyTo").options) {
      if (!o.value) continue;
      const early = !!f && C.fyStartYear(o.value) < C.fyStartYear(f);
      o.disabled = early; o.hidden = early;
    }
    if (f && $("fyTo").value && C.fyStartYear($("fyTo").value) < C.fyStartYear(f)) $("fyTo").value = "";
    const t = $("fyTo").value;
    if (!f || !t) $("fyMsg").textContent = "Select From FY and To FY (fewer years = faster).";
    else $("fyMsg").textContent = f === t ? `Only FY ${f} will be read.` : `FY ${f} to ${t}: ${C.fyStartYear(t) - C.fyStartYear(f) + 1} years will be read.`;
    const needFolder = !destDownloads() && !dirHandle;
    RUN_BUTTONS.forEach(id => { $(id).disabled = !f || !t || needFolder || running; });
    if (needFolder && f && t) $("fyMsg").textContent += " Choose a save folder (Browse…) to start.";
  };
  window.__checkRange = checkRange;
  for (const r of document.querySelectorAll("input[name=dest]")) r.onchange = checkRange;
  $("browse").onclick = async () => {
    try {
      dirHandle = params.has("opfs") ? await navigator.storage.getDirectory()       // test suite only
        : await window.showDirectoryPicker({ id: "tds-output", mode: "readwrite", startIn: "documents" });
      $("folderName").textContent = params.has("opfs") ? "Test Folder" : dirHandle.name;
      $("folderName").className = "folder";
      document.querySelector("input[name=dest][value=pick]").checked = true;
    } catch (e) {
      if (e.name !== "AbortError") log("Folder picker not available here (" + (e.name || e.message) + "). Use 'My Downloads Folder'.");
    }
    checkRange();
  };
  $("fyFrom").onchange = checkRange; $("fyTo").onchange = checkRange;
  checkRange();
  RUN_BUTTONS.forEach(id => { $(id).onclick = () => runAll($(id).dataset.mode); });
  $("modalOk").onclick = () => $("modal").classList.remove("show");
  $("reset").onclick = resetAll;
  $("stop").onclick = () => { stopFlag = true; if (askResolve) askResolve("stop"); };
  $("saveAgain").onclick = () => saveExcel(true);
  $("pickFilled").onclick = async () => {
    try {
      if (params.has("opfs")) filledHandle = await (await navigator.storage.getDirectory()).getFileHandle(EXCEL_NAME);  // test suite
      else [filledHandle] = await window.showOpenFilePicker({ id: "tds-output", multiple: false,
        types: [{ description: "Excel file", accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"] } }] });
      // ask now (while you are clicking) for permission to write the results back into it
      try { await filledHandle.requestPermission({ mode: "readwrite" }); } catch (e) { /* a copy is saved instead */ }
      $("filledName").textContent = filledHandle.name; $("filledName").className = "folder";
      $("validate").disabled = running;
    } catch (e) { if (e.name !== "AbortError") log("File picker not available (" + (e.name || e.message) + ")."); }
  };
  $("validate").onclick = () => validateAll();
  $("askOk").onclick = () => askResolve && askResolve("read");
  $("askMore").onclick = () => askResolve && askResolve("more");
  $("askSkip").onclick = () => askResolve && askResolve("skip");
  window.addEventListener("beforeunload", e => { if (running) { e.preventDefault(); e.returnValue = ""; } });
})();
