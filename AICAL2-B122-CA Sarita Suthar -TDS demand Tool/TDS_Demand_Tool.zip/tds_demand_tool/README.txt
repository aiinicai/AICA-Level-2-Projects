TDS Demand Tool
===============

Install (once, about 1 minute)
  1. Unzip to a folder you will keep, e.g. C:\TDS\tds_demand_tool
     (do not delete or move it later - Chrome runs the tool from this folder).
  2. In Chrome open chrome://extensions   (Edge: edge://extensions)
  3. Turn ON "Developer mode" (top right).
  4. Click "Load unpacked" and select the tds_demand_tool folder (the one with manifest.json).
  5. Click the puzzle icon next to the address bar and pin "TDS Demand Tool".
  Update: replace the files in the same folder, then click the reload arrow on the
  tool's card in chrome://extensions.

Use
  1. Log in to TRACES and go to Compliance under Income-tax Act, 1961 (Proceed, Leave).
  2. Click the tool's icon. Choose From FY / To FY and a save folder (Browse... or
     My Downloads Folder), then click Extract Demand Details.
  3. The tool opens Defaults -> View Default Summary, searches every FY and quarter,
     clicks each blue quarter number with an amount (one per form) and reads its
     breakdown. Leave the TRACES tab alone while it works.
  4. "Details Downloaded" appears when TDS_Default_Summary.xlsx is saved: one row per
     FY / quarter / form with Net Payable > 0 and the breakdown of each default.
  Reset clears everything to start again (same or another login).

Privacy
  You type your own TRACES login; the tool never sees or stores the password, works
  only on tdscpc.gov.in, sends nothing anywhere and stores nothing after you close it.
  If a TRACES page cannot be read it saves traces_structure.txt next to the Excel file
  (names of menus, buttons and table headings only); send that file for support.
