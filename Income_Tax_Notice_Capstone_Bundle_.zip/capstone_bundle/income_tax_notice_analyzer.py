"""
=====================================================================
 CAPSTONE PROJECT: AI-ASSISTED INCOME TAX NOTICE ANALYZER
=====================================================================
Project   : How AI Tools Can Be Used to Interpret & Respond to
            Income Tax Notices
Approach  : Rule-based text analysis engine (simulates how an AI/LLM
            pipeline would classify a notice, extract key fields,
            explain the issue in plain language, and draft a response)

Note: This runs fully OFFLINE in IDLE (no internet/API needed), since
IDLE cannot call external AI APIs without extra setup. It uses
pattern matching + regex to emulate the classification and drafting
steps an LLM would perform. In your report, describe this as a
"rule-based NLP prototype" demonstrating the same pipeline concept
that a real LLM-based tool (ChatGPT/Claude API) would automate.

How to run:
1. Open IDLE (Python 3.x)
2. File > Open > select this .py file
3. Press F5 to Run
4. To analyze a different notice, replace the text inside
   SAMPLE_NOTICE_TEXT with the actual notice text (copy-paste from
   a PDF, or use OCR separately to extract it first)
=====================================================================
"""

import re

# ---------------------------------------------------------------
# STEP 1: INPUT — Notice text (replace with real notice text)
# ---------------------------------------------------------------
SAMPLE_NOTICE_TEXT = """
INCOME TAX DEPARTMENT
Centralized Processing Centre (CPC)
Bengaluru - 560500

Document Identification No. (DIN): ITBA/AST/S/143(1)/2026-27/1234567890
Date of Issue: 15-Aug-2026

Name of Assessee : RAMESH KUMAR SAHOO
PAN              : ABCDE1234F
Assessment Year  : 2025-26

Subject: Intimation under Section 143(1) of the Income Tax Act, 1961

Your Return of Income for Assessment Year 2025-26 filed on 28-Jul-2025
has been processed under Section 143(1) of the Income Tax Act, 1961.

A discrepancy was noted between the TDS credit claimed by you in your
return and the TDS credit reflected in Form 26AS / Annual Information
Statement (AIS).

TDS claimed under Salary (Sec 192): Rs. 45,000
TDS as per 26AS: Rs. 38,500

Total Demand Payable: Rs. 21,850

You are requested to pay the outstanding demand within 30 days of
receipt of this intimation, or file a rectification request u/s 154.
"""

# ---------------------------------------------------------------
# STEP 2: KNOWLEDGE BASE — section meanings (mini rule engine)
# In a real LLM-based tool, this reasoning would be generated
# dynamically. Here it's a lookup table simulating that knowledge.
# ---------------------------------------------------------------
SECTION_INFO = {
    "143(1)": {
        "name": "Intimation under Section 143(1)",
        "meaning": "An automated intimation generated after your ITR is "
                   "processed, comparing your return with Form 26AS/AIS "
                   "and other department records. NOT a scrutiny or "
                   "accusation of wrongdoing.",
        "severity": "Low",
    },
    "139(9)": {
        "name": "Defective Return Notice under Section 139(9)",
        "meaning": "Your filed return has been marked defective (e.g., "
                   "missing schedule, mismatched figures) and must be "
                   "corrected within the given time or it will be treated "
                   "as not filed.",
        "severity": "Medium",
    },
    "148": {
        "name": "Notice for Reassessment under Section 148",
        "meaning": "The department believes income may have escaped "
                   "assessment in a prior year and is reopening the case. "
                   "This is more serious and usually warrants professional "
                   "help.",
        "severity": "High",
    },
    "245": {
        "name": "Notice under Section 245 (Adjustment of Refund)",
        "meaning": "The department intends to adjust your current refund "
                   "against an outstanding demand from a previous year.",
        "severity": "Medium",
    },
    "142(1)": {
        "name": "Notice under Section 142(1)",
        "meaning": "A notice calling for filing of return or additional "
                   "documents/information before assessment.",
        "severity": "Medium",
    },
}


# ---------------------------------------------------------------
# STEP 3: FUNCTIONS
# ---------------------------------------------------------------
def classify_notice(text):
    """Detects which section the notice was issued under."""
    for section in SECTION_INFO:
        pattern = re.escape(section).replace(r"\(", r"\(?").replace(r"\)", r"\)?")
        if re.search(r"Section\s*" + pattern, text, re.IGNORECASE) or section in text:
            return section, SECTION_INFO[section]
    return None, None


def extract_field(pattern, text, group=1, default="Not found"):
    match = re.search(pattern, text, re.IGNORECASE)
    return match.group(group).strip() if match else default


def extract_key_details(text):
    details = {
        "Assessee Name": extract_field(r"Name of Assessee\s*:\s*([^\n]+)", text),
        "PAN": extract_field(r"PAN\s*:\s*([A-Z0-9]+)", text),
        "Assessment Year": extract_field(r"Assessment Year\s*:\s*([\d\-]+)", text),
        "DIN": extract_field(r"\(DIN\)\s*:\s*([^\n]+)", text),
        "Date of Issue": extract_field(r"Date of Issue\s*:\s*([\d\-A-Za-z]+)", text),
        "Total Demand": extract_field(r"Total Demand Payable\s*:\s*Rs\.?\s*([\d,]+)", text),
    }
    return details


def find_tds_mismatch(text):
    claimed = extract_field(r"TDS claimed.*?Rs\.?\s*([\d,]+)", text)
    as_per_26as = extract_field(r"TDS as per 26AS\s*:\s*Rs\.?\s*([\d,]+)", text)
    return claimed, as_per_26as


def explain_issue(section, details, claimed, as_per_26as):
    print("\n" + "=" * 90)
    print("ISSUE EXPLANATION (Plain Language)".center(90))
    print("=" * 90)

    if section == "143(1)" and claimed != "Not found" and as_per_26as != "Not found":
        print(f"This notice was triggered because the TDS you claimed in your return")
        print(f"(Rs. {claimed}) does not match the TDS reflected in Form 26AS/AIS")
        print(f"(Rs. {as_per_26as}). The department has disallowed the difference,")
        print(f"resulting in a tax demand of Rs. {details['Total Demand']}.")
        print("\nLikely causes:")
        print("  - Employer/deductor hasn't fully deposited or filed correct TDS return")
        print("  - Wrong PAN quoted by deductor in their TDS filing")
        print("  - Data entry error while filing your ITR")
    elif section:
        print(f"This is a {SECTION_INFO[section]['name']}.")
        print(f"{SECTION_INFO[section]['meaning']}")
    else:
        print("Could not determine the specific issue automatically.")
        print("Recommend manual review or consultation with a tax professional.")


def recommend_actions(section):
    print("\n" + "=" * 90)
    print("RECOMMENDED ACTION PLAN".center(90))
    print("=" * 90)

    if section == "143(1)":
        steps = [
            "Log in to www.incometax.gov.in and check Form 26AS/AIS for actual TDS credited",
            "Contact your employer/deductor if Form 16 shows a higher TDS than 26AS",
            "If 26AS is correct, pay the demand within 30 days to avoid further interest",
            "If you have proof (Form 16) of higher TDS, file a rectification request u/s 154",
            "Attach supporting documents (Form 16, TDS certificate) with your response",
        ]
    elif section == "139(9)":
        steps = [
            "Read the defect description carefully in the notice/portal",
            "Correct the identified defect in your return (e.g., missing schedule)",
            "Re-submit the corrected return within the time allowed",
            "If you disagree the return is defective, respond explaining why on the portal",
        ]
    elif section == "148":
        steps = [
            "Do NOT ignore this notice — respond within the given timeline",
            "Consult a Chartered Accountant immediately given the higher severity",
            "Gather all financial records for the relevant assessment year",
            "File your response/return as directed under Section 148",
        ]
    else:
        steps = [
            "Review the notice carefully and note the response deadline",
            "Consult a tax professional if the required action is unclear",
            "Respond via the income tax e-filing portal before the due date",
        ]

    for i, step in enumerate(steps, start=1):
        print(f"  {i}. {step}")


def draft_response(details, section):
    print("\n" + "=" * 90)
    print("DRAFT RESPONSE (Template)".center(90))
    print("=" * 90)

    response = f"""
To,
The Assessing Officer,
Centralized Processing Centre (CPC), Bengaluru - 560500

Subject: Response to Intimation u/s {section} for A.Y. {details['Assessment Year']}
         DIN: {details['DIN']}
         PAN: {details['PAN']}

Respected Sir/Madam,

I am in receipt of the Intimation u/s {section} dated {details['Date of Issue']}
raising a demand of Rs. {details['Total Demand']}.

I am submitting my response along with supporting documents (Form 16,
TDS certificate, Form 26AS/AIS extract) via the e-filing portal under
"Response to Outstanding Demand" / "Rectification Request" as applicable.

I request that the matter be reviewed and, if warranted, the demand be
revised/rectified accordingly.

Thanking you,

{details['Assessee Name'].title()}
PAN: {details['PAN']}
Place: [Your City]
Date: [Response Date]
"""
    print(response)


# ---------------------------------------------------------------
# STEP 4: MAIN EXECUTION
# ---------------------------------------------------------------
def main():
    print("#" * 90)
    print("AI-ASSISTED INCOME TAX NOTICE ANALYZER".center(90))
    print("(Rule-based offline prototype — IDLE demo)".center(90))
    print("#" * 90)

    section, info = classify_notice(SAMPLE_NOTICE_TEXT)

    print("\n" + "=" * 90)
    print("NOTICE CLASSIFICATION".center(90))
    print("=" * 90)
    if section:
        print(f"Detected Section : {section}")
        print(f"Notice Type      : {info['name']}")
        print(f"Severity Level   : {info['severity']}")
    else:
        print("Could not classify the notice automatically.")

    details = extract_key_details(SAMPLE_NOTICE_TEXT)
    print("\n" + "=" * 90)
    print("KEY DETAILS EXTRACTED".center(90))
    print("=" * 90)
    for k, v in details.items():
        print(f"{k:<20}: {v}")

    claimed, as_per_26as = find_tds_mismatch(SAMPLE_NOTICE_TEXT)
    explain_issue(section, details, claimed, as_per_26as)
    recommend_actions(section)
    draft_response(details, section)

    print("\n" + "=" * 90)
    print("Analysis Complete. Replace SAMPLE_NOTICE_TEXT with a real notice to re-run.")
    print("=" * 90)


if __name__ == "__main__":
    main()
