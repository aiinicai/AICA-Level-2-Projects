import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Serve public directory (videos, images, etc.) as static files
app.use(express.static(path.join(process.cwd(), 'public')));

// Initialize Gemini AI Client
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health Check API
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", geminiConfigured: !!apiKey });
});

// AI Personal Coach Endpoint
app.post("/api/ai/coach", async (req, res) => {
  try {
    if (!aiClient) {
      return res.status(503).json({
        error: "Gemini API key is not configured in server environment."
      });
    }

    const { profile, subjects, testRecords, chapterStats, totalHoursSpent } = req.body;

    const prompt = `
You are an expert ICAI Chartered Accountant Mentor and Academic Coach for a CA ${profile?.course || 'Intermediate'} student named ${profile?.name || 'Student'}.
Student Target Exam Attempt: ${profile?.attempt || 'Upcoming Attempt'} (Target Date: ${profile?.targetExamDate || 'Next 2 Months'})

Current Academic Context:
- Total Study Hours Logged: ${totalHoursSpent || 0} Hours
- Test Records & Marks: ${JSON.stringify(testRecords || [])}
- Subject Performance: ${JSON.stringify(subjects || [])}
- Chapter Progress: ${JSON.stringify(chapterStats || [])}

Analyze the student's marks, consistency, revision counts, and remaining days.
Return a structured JSON object containing:
1. "dailyAdvice": Specific 2-sentence action recommendation for today.
2. "weeklyStrategy": Strategic focus for the current week.
3. "examStrategy": Key ICAI paper writing & time management strategy for their upcoming attempt.
4. "motivationalQuote": Inspiring quote tailored to a CA student preparing for ICAI exams.
5. "passProbability": Integer between 0 and 100 estimating probability of clearing the upcoming attempt.
6. "expectedMarksRange": String estimating total marks (e.g. "240 - 265 / 400").
7. "weakSubjectIds": Array of subject IDs requiring priority attention.
8. "recommendedTopics": Array of 4-5 specific high-weightage chapters/topics to revise immediately.
9. "suggestedSchedule": Array of 5-6 timetable slot objects ({ "time": "06:00 AM", "activity": "Accounts Revision", "subject": "Advanced Accounting", "duration": "2 Hours" }).
10. "confidenceScore": Integer between 0 and 100.
11. "riskAreas": Array of 3 high-risk technical areas or ICAI exam pitfalls to avoid.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dailyAdvice: { type: Type.STRING },
            weeklyStrategy: { type: Type.STRING },
            examStrategy: { type: Type.STRING },
            motivationalQuote: { type: Type.STRING },
            passProbability: { type: Type.INTEGER },
            expectedMarksRange: { type: Type.STRING },
            weakSubjectIds: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendedTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedSchedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  time: { type: Type.STRING },
                  activity: { type: Type.STRING },
                  subject: { type: Type.STRING },
                  duration: { type: Type.STRING },
                },
              },
            },
            confidenceScore: { type: Type.INTEGER },
            riskAreas: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            "dailyAdvice",
            "weeklyStrategy",
            "examStrategy",
            "motivationalQuote",
            "passProbability",
            "expectedMarksRange",
            "weakSubjectIds",
            "recommendedTopics",
            "suggestedSchedule",
            "confidenceScore",
            "riskAreas",
          ],
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/coach:", error);
    res.status(500).json({ error: error?.message || "Failed to generate AI coach advice." });
  }
});

// AI Doubt Solver & Concept Clarifier Endpoint
app.post("/api/ai/doubt-solver", async (req, res) => {
  try {
    if (!aiClient) {
      return res.status(503).json({ error: "Gemini API key is not configured." });
    }

    const { course, subject, chapter, question } = req.body;

    const prompt = `
You are a Senior ICAI Chartered Accountant Professor and Subject Matter Expert answering a CA ${course || 'Intermediate'} student's technical doubt.

Subject: ${subject}
Chapter/Topic: ${chapter}
Student Question: ${question}

Provide an authentic, clear, ICAI-compliant explanation following standard Indian Chartered Accountancy syllabus guidelines (referencing relevant Accounting Standards [AS/Ind AS], Sections of Companies Act 2013, Income Tax Act 1961, GST Act 2017, Standards on Auditing [SAs], or SQC where applicable).

Format your response clearly with headings:
1. Executive Summary Answer
2. ICAI Legal / Accounting Provision Reference
3. Practical Application / Step-by-Step Numerical or Conceptual Breakdown
4. Key Exam Tip / Common ICAI Mistake to Avoid
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    res.json({ answer: response.text });
  } catch (error: any) {
    console.error("Error in /api/ai/doubt-solver:", error);
    res.status(500).json({ error: error?.message || "Failed to solve doubt." });
  }
});

// AI Quiz Generator Endpoint
app.post("/api/ai/quiz-generator", async (req, res) => {
  try {
    if (!aiClient) {
      return res.status(503).json({ error: "Gemini API key is not configured." });
    }

    const { course, subject, chapter, count } = req.body;

    const prompt = `
Generate ${count || 3} high-yield multiple-choice questions (MCQs) for ICAI CA ${course || 'Intermediate'} exam preparation.

Subject: ${subject}
Chapter: ${chapter}

Return a JSON array of question objects:
Each object must have:
- "id": string
- "question": string
- "options": array of 4 strings
- "correctOptionIndex": integer (0, 1, 2, or 3)
- "explanation": concise ICAI reasoning with relevant section or standard number
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctOptionIndex: { type: Type.INTEGER },
              explanation: { type: Type.STRING },
            },
            required: ["id", "question", "options", "correctOptionIndex", "explanation"],
          },
        },
      },
    });

    const resultText = response.text || "[]";
    const data = JSON.parse(resultText);
    res.json({ questions: data });
  } catch (error: any) {
    console.error("Error in /api/ai/quiz-generator:", error);
    res.status(500).json({ error: error?.message || "Failed to generate quiz questions." });
  }
});

// AI Flashcard Generator from Chapter Notes Endpoint
app.post("/api/ai/flashcards/generate", async (req, res) => {
  try {
    if (!aiClient) {
      return res.status(503).json({ error: "Gemini API key is not configured in server environment." });
    }

    const { course, subjectName, chapterTitle, chapterNotes, customPrompt, cardCount = 5 } = req.body;

    const prompt = `
You are an expert ICAI Chartered Accountant Professor and Active Recall Specialist creating study flashcards for a CA ${course || 'Intermediate'} student.

Subject: ${subjectName || 'General CA Subject'}
Chapter Title: ${chapterTitle || 'Chapter'}
Student's Personal Chapter Notes:
${chapterNotes && chapterNotes.trim() ? chapterNotes : '(No notes provided. Use standard ICAI syllabus high-yield exam provisions, section numbers, accounting standards, formulas, and common exam traps for this chapter.)'}

${customPrompt ? `Additional Focus Instruction: ${customPrompt}` : ''}

Generate ${cardCount} high-yield, active recall study cards.
Requirements:
1. "question": A clear, direct test question testing active recall of key rules, conditions, limits, or formulas.
2. "answer": Concise, bulleted or step-by-step correct legal/accounting answer with relevant Section or Accounting Standard references.
3. "hint": A short 1-line memory clue or mnemonic.
4. "difficulty": Exactly one of "Easy", "Medium", "Hard".
5. "tags": Array of 2-3 short relevant topic strings (e.g. ["AS 16", "Borrowing Costs"]).

Return a valid JSON array of objects matching the schema.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              answer: { type: Type.STRING },
              hint: { type: Type.STRING },
              difficulty: { type: Type.STRING },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ["question", "answer", "hint", "difficulty", "tags"],
          },
        },
      },
    });

    const resultText = response.text || "[]";
    const data = JSON.parse(resultText);
    res.json({ flashcards: data });
  } catch (error: any) {
    console.error("Error in /api/ai/flashcards/generate:", error);
    res.status(500).json({ error: error?.message || "Failed to generate AI flashcards." });
  }
});

// AI Personalized Daily Plan Generator Endpoint
app.post("/api/ai/daily-personalized-plan", async (req, res) => {
  try {
    const { profile, subjects, testRecords, targetHours = 6 } = req.body;

    if (!aiClient) {
      return res.status(200).json({
        plan: {
          date: new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' }),
          overallStrategy: "Precision diagnostic schedule targeting high-yield ICAI chapters with low test retention.",
          totalPlannedHours: `${targetHours} Hours`,
          focusSubject: "Auditing & Taxation",
          diagnosticSummary: "Analysis of your last 5 test records highlights vulnerable accuracy in Audit SA standards and GST Input Tax Credit. Today's plan isolates these exact gaps before evening active recall.",
          tasks: [
            {
              id: "task_1",
              timeSlot: "2:00–3:30 PM",
              subjectName: "Audit",
              subjectCode: "P5",
              topic: "SA 315 (Identifying and Assessing Risks of Material Misstatement)",
              taskType: "concept",
              taskIcon: "📖",
              reason: "Your last 3 tests show 54% accuracy.",
              detailedWhy: "SA 315 carries 8–12 mandatory marks in the ICAI Audit paper. Diagnostic test logs indicate recurring marks loss in Internal Control components and Risk Assessment Procedures. Scheduled at 2:00 PM during prime cognitive alertness to solidify core clauses.",
              metricHighlight: "Accuracy: 54% (Low)",
              priority: "Critical",
              durationMins: 90,
              isCompleted: false
            },
            {
              id: "task_2",
              timeSlot: "3:45–4:30 PM",
              subjectName: "Tax",
              subjectCode: "P4",
              topic: "GST – Input Tax Credit (ITC & Blocked Credits Sec 17(5))",
              taskType: "concept",
              taskIcon: "📖",
              reason: "High exam importance + low retention score.",
              detailedWhy: "Sec 16, 17(5), and 18 form the backbone of 14–18 marks in GST practical computations. Spaced repetition interval is overdue by 5 days, requiring an immediate 45-minute refresher before forgetting curves steepen.",
              metricHighlight: "High Exam Weightage (16M)",
              priority: "High",
              durationMins: 45,
              isCompleted: false
            },
            {
              id: "task_3",
              timeSlot: "5:00–5:30 PM",
              subjectName: "Practice",
              subjectCode: "ALL",
              topic: "20 questions from previous ICAI exams (RTP & Past Papers)",
              taskType: "practice",
              taskIcon: "🎯",
              reason: "Application speed & question pattern familiarity.",
              detailedWhy: "Passive reading creates a false sense of mastery. Timed solving of 20 past questions directly trains exam-speed drafting under simulated ICAI 1.8 mins/mark pressure.",
              metricHighlight: "Active Application",
              priority: "High",
              durationMins: 30,
              isCompleted: false
            },
            {
              id: "task_4",
              timeSlot: "9:00–9:15 PM",
              subjectName: "Revision",
              subjectCode: "ALL",
              topic: "Revise yesterday's weak concepts & flashcard flags",
              taskType: "revision",
              taskIcon: "🔁",
              reason: "Revise yesterday's weak concepts to lock in memory consolidation.",
              detailedWhy: "Cognitive consolidation occurs overnight. Spending 15 targeted minutes reviewing flashcards and tagged test errors before sleeping increases memory retention by up to 68%.",
              metricHighlight: "Memory Consolidation",
              priority: "Medium",
              durationMins: 15,
              isCompleted: false
            }
          ]
        }
      });
    }

    const prompt = `
You are the master AI Mentor for a CA ${profile?.course || 'Intermediate'} student (${profile?.name || 'Student'}).
Generate a high-intelligence, personalized daily study plan for today.

Student Context:
- Target Attempt: ${profile?.attempt || 'Upcoming Attempt'}
- Subjects: ${JSON.stringify(subjects?.map((s: any) => ({ name: s.name, code: s.code })) || [])}
- Recent Test Log Diagnostics: ${JSON.stringify(testRecords?.slice(0, 5) || [])}
- Target Planned Hours: ${targetHours} Hours

Format strictly as JSON with this schema:
{
  "date": "Today's Date string",
  "overallStrategy": "Short 1-sentence strategy summary",
  "totalPlannedHours": "${targetHours} Hours",
  "focusSubject": "Key focus subject",
  "diagnosticSummary": "2-sentence summary explaining the rationale of today's focus based on weak areas and high exam weightage",
  "tasks": [
    {
      "id": "unique string id",
      "timeSlot": "e.g. 2:00–3:30 PM",
      "subjectName": "e.g. Audit / Tax / Practice / Revision",
      "subjectCode": "e.g. P1 / P4 / P5",
      "topic": "e.g. SA 315 or GST – ITC or 20 questions from previous exams",
      "taskType": "concept" | "practice" | "revision" | "test" | "mcq",
      "taskIcon": "📖" | "🎯" | "🔁" | "📝",
      "reason": "Clear concise reason, e.g. 'Your last 3 tests show 54% accuracy.' or 'High exam importance + low retention score.'",
      "detailedWhy": "Deep 2-3 sentence explanation detailing WHY this specific task, topic, and time slot was selected by the AI based on cognitive rhythm, ICAI weightage, and past performance gaps.",
      "metricHighlight": "e.g. Accuracy: 54% or High Weightage (16M) or Weak Retention",
      "priority": "Critical" | "High" | "Medium",
      "durationMins": 90
    }
  ]
}

Include at least 4 well-structured tasks mimicking:
1. Deep Study Block with exact reason (e.g. "2:00–3:30 PM — Audit | 📖 SA 315 | Reason: Your last 3 tests show 54% accuracy.")
2. High-Yield Subject Block with exact reason (e.g. "3:45–4:30 PM — Tax | 📖 GST – ITC | Reason: High exam importance + low retention score.")
3. Timed Practice Block with exact reason (e.g. "5:00–5:30 PM — Practice | 🎯 20 questions from previous exams.")
4. Night Memory Consolidation Block with exact reason (e.g. "9:00–9:15 PM — Revision | 🔁 Revise yesterday's weak concepts.")
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json({ plan: data });
  } catch (error: any) {
    console.error("Error in /api/ai/daily-personalized-plan:", error);
    res.status(500).json({ error: error?.message || "Failed to generate personalized daily plan." });
  }
});

// AI Friend Discussion Advisor Endpoint
app.post("/api/ai/friend-discussion-advisor", async (req, res) => {
  try {
    if (!aiClient) {
      return res.status(503).json({ error: "Gemini API key is not configured in server environment." });
    }

    const { course, title, category, problemDescription } = req.body;

    const prompt = `
You are a empathetic, highly experienced Ranker Chartered Accountant Mentor and Senior Peer Advisor helping a CA ${course || 'Intermediate'} student with a common student challenge.

Problem Category: ${category || 'General CA Challenge'}
Discussion Title: ${title || 'Student Problem'}
Student's Problem Statement:
"${problemDescription}"

Provide a compassionate, highly practical, 3-point action plan to solve this problem effectively for a CA student.
Keep your tone encouraging, realistic, and structured. Include:
1. Empathy & Mindset Shift (1-2 sentences acknowledging the reality)
2. Practical 3-Step Strategy (bullet points with immediate actionable steps)
3. CA Ranker Tip or Habit (a short golden habit or study strategy)
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    res.json({ advice: response.text || "Every CA student faces hurdles. Break your syllabus into micro-goals and focus on consistent 45-minute study sprints." });
  } catch (error: any) {
    console.error("Error in /api/ai/friend-discussion-advisor:", error);
    res.status(500).json({ error: error?.message || "Failed to generate mentor advice." });
  }
});

// AI Topic Weakness Root Cause Detector Endpoint
app.post("/api/ai/diagnose-weakness-root-cause", async (req, res) => {
  try {
    const { course, subjectName, topicName, scorePct, userMistakes = "" } = req.body;

    if (!aiClient) {
      return res.status(200).json({
        diagnosis: {
          scorePct: scorePct || 48,
          status: (scorePct || 48) < 50 ? 'critical' : (scorePct || 48) < 75 ? 'moderate' : 'strong',
          aiIdentifiedProblem: `You are losing marks in ${topicName || 'this topic'} primarily because you identify the correct statutory standard or concept but fail to apply it to the factual case study scenario in sub-parts.`,
          rootCauseCategory: 'Application Deficit',
          examWeightage: '8–12 Marks',
          commonICMITrap: 'Writing generic theoretical definitions instead of linking specific facts with statutory provisions and reaching a definitive conclusion.',
          aiActionPlan: [
            'Structure your answer in 3 clear paragraphs: (1) Statutory Reference/Section/SA, (2) Factual Case Analysis, (3) Final Conclusion.',
            'Cite verbatim ICAI keywords in bold rather than casual paraphrasing.',
            'Solve 3 case studies from recent Mock Test Papers under timed 1.8 mins/mark conditions.'
          ]
        }
      });
    }

    const prompt = `
You are an elite ICAI Head Examiner and Master CA Coach with deep expertise in checking CA ${course || 'Intermediate'} exam answer sheets.

Subject: ${subjectName}
Specific Topic / Standard / Section: ${topicName}
Current Accuracy / Score: ${scorePct}%
Student Error Notes / Mistakes: "${userMistakes || 'Loses marks on case study application and standard reference in recent tests'}"

TASK:
Do NOT merely summarize percentages. Go one level deeper to identify the EXACT underlying psychological, conceptual, or examination drafting problem.

Examples of deep root causes:
- "You are losing marks primarily because you identify the correct auditing standard but fail to apply it to the case."
- "You understand Section 16 ITC eligibility, but consistently overlook the 180-day supplier payment reversal rule in multi-stage problems."
- "You calculate the right mathematical answer but omit the mandatory statutory disclosure notes under Schedule III Division I."

Respond ONLY with valid JSON conforming to this schema (no markdown outside JSON):
{
  "scorePct": number,
  "status": "critical" | "moderate" | "strong",
  "aiIdentifiedProblem": string (1-2 sharp, highly specific sentences identifying the underlying cause of marks loss),
  "rootCauseCategory": "Application Deficit" | "Provision Clause Precision" | "Calculation Speed" | "ICAI Keyword Omission" | "Conceptual Gap",
  "examWeightage": string (e.g. "8-12 Marks"),
  "commonICMITrap": string (the exact trick or trap ICAI test papers use here),
  "aiActionPlan": [
    string (Actionable step 1),
    string (Actionable step 2),
    string (Actionable step 3)
  ]
}
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json({ diagnosis: data });
  } catch (error: any) {
    console.error("Error in /api/ai/diagnose-weakness-root-cause:", error);
    res.status(500).json({ error: error?.message || "Failed to diagnose root cause." });
  }
});

// AI Question Mistake Diagnosis Endpoint
app.post("/api/ai/diagnose-question-mistake", async (req, res) => {
  try {
    const { questionText, subjectName, selectedReason, userNote = "" } = req.body;

    if (!aiClient) {
      return res.status(200).json({
        tip: "Before jumping into calculations, circle the key constraints in the question (dates, non-resident status, public vs private entity) to prevent misinterpretation.",
        correctAnswerSummary: "Always ensure the statutory provision and factual application are separated into distinct paragraphs."
      });
    }

    const prompt = `
You are an expert CA Ranker Mentor and Examiner. A CA student just attempted a question and marked it wrong.

Subject: ${subjectName || 'CA Subject'}
Question Text: "${questionText}"
Student's Tagged Mistake Reason: "${selectedReason}"
Student's Notes on Why they Failed: "${userNote}"

Provide a crisp, 1-2 sentence Ranker Action Tip that directly fixes this specific mistake for future ICAI exams, and a 1-sentence correct answer highlight.

Return valid JSON conforming to:
{
  "aiTip": string (1-2 sentences of actionable ranker advice),
  "correctAnswerSummary": string (1 sentence summary of correct conceptual approach)
}
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/diagnose-question-mistake:", error);
    res.status(500).json({ error: error?.message || "Failed to diagnose mistake." });
  }
});

// AI Answer Writing Coach Endpoint
app.post("/api/ai/evaluate-answer", async (req, res) => {
  try {
    const { questionText, studentAnswer, subjectName = "Auditing / Law / Tax", totalMarks = 5 } = req.body;

    if (!aiClient) {
      return res.status(200).json({
        marksEstimated: { awarded: 3, total: totalMarks || 5 },
        ratings: {
          structure: 4,
          technicalContent: 3,
          application: 3,
          conclusion: 4,
          presentation: 3
        },
        diagnostics: {
          missingKeywords: ["Professional Skepticism", "Direct or Indirect Interest", "Sufficient Appropriate Audit Evidence"],
          missingProvisions: ["Section 141(3)(d)", "SA 200 Fundamental Principles"],
          poorStructureNotes: "The provision and factual analysis are merged into a single paragraph. Split them into dedicated labeled sections.",
          unnecessaryContentNotes: "Lengthy recap of historical corporate history in intro paragraph wastes 3 valuable minutes without fetching marks.",
          missingConclusionNotes: "The conclusion is hesitant ('it might be possible'). Needs an authoritative verdict ('the appointment is invalid under Section 141').",
          lackOfCaseApplicationNotes: "You quoted the standard but didn't tie the specific holding relationship given in the question stem."
        },
        betterAnswerStructure: {
          issue: "Whether statutory appointment of Mr. X is invalid due to holding company relative shareholding limits exceeding statutory thresholds.",
          provision: "As per Section 141(3)(d)(i) of the Companies Act 2013 read with Rule 10, a person whose relative holds securities in the company or its holding/subsidiary having face value exceeding ₹1,00,000 is disqualified.",
          application: "In the present case, Mr. X's brother holds shares worth ₹2,50,000 (face value) in ABC Holding Ltd. Since the face value exceeds the threshold of ₹1,00,000, the statutory disqualification is immediately triggered unless corrective action is taken within 60 days.",
          conclusion: "Therefore, Mr. X cannot be appointed as statutory auditor of XYZ Ltd unless the relative disposes of the excess shares within the 60-day grace period."
        },
        rankerExaminerRemarks: "Follow the 4-tier Issue → Provision → Application → Conclusion architecture. Always use bold headings and quote statutory numerical thresholds."
      });
    }

    const prompt = `
You are a senior ICAI Head Examiner and All India Ranker (AIR 1) Mentor for CA Final and CA Intermediate examinations.
Evaluate the following student's descriptive / case-law answer with rigorous ICAI marking scheme precision.

Question:
"${questionText}"

Subject:
"${subjectName}"

Student's Written Answer:
"${studentAnswer}"

Evaluate the student's answer and return a JSON object with:
1. marksEstimated: { awarded: number (e.g. 3.5), total: ${totalMarks} }
2. ratings: (ratings from 1 to 5 integer stars)
   - structure (1-5)
   - technicalContent (1-5)
   - application (1-5)
   - conclusion (1-5)
   - presentation (1-5)
3. diagnostics:
   - missingKeywords: array of exact ICAI statutory/standard terms omitted (e.g., ["Professional Skepticism", "Direct or Indirect", "True & Fair View"])
   - missingProvisions: array of relevant Sections, SAs, AS, Ind AS, Rules, or Case Laws omitted
   - poorStructureNotes: specific commentary on paragraphing and formatting
   - unnecessaryContentNotes: specific commentary on filler text or time-wasting points
   - missingConclusionNotes: commentary on clarity and decisiveness of the verdict
   - lackOfCaseApplicationNotes: commentary on how the law was synthesized with the given case facts
4. betterAnswerStructure:
   Provide the restructured answer following the exact Gold Standard ICAI Architecture:
   - issue: The core legal / accounting issue involved
   - provision: The statutory provision / standard clauses with key verbatim terms
   - application: The synthesis applying the statutory rules directly to the question's facts
   - conclusion: The unambiguous, authoritative conclusion
5. rankerExaminerRemarks: A motivating, high-impact 2-sentence summary highlighting the #1 lever to convert this answer into full marks.

Return ONLY valid JSON.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/evaluate-answer:", error);
    res.status(500).json({ error: error?.message || "Failed to evaluate answer." });
  }
});

// 🎓 AI Examiner Mode: Generate Case-Based Question
app.post("/api/ai/generate-examiner-question", async (req, res) => {
  try {
    const { subject = "Audit", topic = "SA 315", difficulty = "ICAI exam level", marks = 10 } = req.body;

    if (!aiClient) {
      return res.status(200).json({
        id: `exam_q_${Date.now()}`,
        subject,
        topic,
        difficulty,
        marks: marks || 10,
        timeLimitMinutes: 15,
        questionTitle: `Audit Risk Assessment & IT Controls under ${topic}`,
        questionText: `CA Samarth is the statutory auditor of Zenith Retail Logistics Ltd for FY 2024-25. The company recently transitioned to an integrated automated ERP warehouse management system. During his preliminary evaluation, CA Samarth observed that:\n\n1. Warehouse dispatch logs are auto-generated without secondary supervisory sign-off.\n2. Access rights for inventory adjustments above ₹5,00,000 were assigned to three branch accountants without dual authentication.\n3. The internal auditor's report highlighted frequent manual overrides during month-end inventory reconciliations.\n\nIn light of SA 315 (Revised) "Identifying and Assessing the Risks of Material Misstatement", guide CA Samarth on how he should identify and assess the Risks of Material Misstatement (RoMM) at both the Financial Statement level and Assertion level. Also explain the auditor's responsibility regarding General IT Controls (GITCs) and Automated Application Controls.`,
        sampleStudentDraft: `CA Samarth should check the internal controls of the company. Under SA 315, auditor must understand the entity and its environment. Since ERP system is implemented, auditor should check IT controls. If warehouse dispatch logs have no sign-off, it is a big risk. Branch accountants having access above ₹5,00,000 without dual approval increases risk of fraud. The auditor should inform the audit committee and do detailed substantive testing of inventory balances.`,
        sourceContext: `Simulated from ICAI CA Final Advanced Auditing (May/Nov Exam Pattern) & Revised SA 315 Framework.`
      });
    }

    const prompt = `
You are a senior ICAI Paper Setter and Chief Examiner for Chartered Accountancy examinations.
Generate a high-yield, realistic case-based question for the following parameters:
- Subject: ${subject}
- Topic: ${topic}
- Difficulty Level: ${difficulty}
- Total Marks: ${marks} Marks

Requirements for the generated question:
1. It must present a realistic corporate / practice scenario with numerical limits, entities, and practical dilemmas.
2. It must directly test the student's mastery of the topic (${topic}) at the ${difficulty} standard.
3. Return a JSON object with:
   - id: string
   - subject: string
   - topic: string
   - difficulty: string
   - marks: number (${marks})
   - timeLimitMinutes: number (approx 1.5 min per mark, e.g. 15 mins for 10 marks)
   - questionTitle: A crisp title for the case
   - questionText: The full, detailed question text formatted clearly with numbered sub-points if relevant
   - sampleStudentDraft: A realistic 100-word average student draft answer that makes common mistakes (to allow 1-click test fill)
   - sourceContext: ICAI exam source context (e.g. "Patterned on ICAI Past Exam / RTP Case Study")

Return ONLY valid JSON.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/generate-examiner-question:", error);
    res.status(500).json({ error: error?.message || "Failed to generate examiner question." });
  }
});

// 🎓 AI Examiner Mode: Rigorous Evaluation
app.post("/api/ai/evaluate-examiner-answer", async (req, res) => {
  try {
    const { question, studentAnswer, timeSpentSeconds = 300 } = req.body;

    if (!aiClient) {
      const awarded = 6.5;
      const total = question?.marks || 10;
      const lost = Math.round((total - awarded) * 10) / 10;

      return res.status(200).json({
        id: `eval_res_${Date.now()}`,
        question,
        studentAnswer,
        timeSpentSeconds,
        scores: {
          concept: 8,
          application: 5,
          relevantProvisions: 7,
          presentation: 6,
          conclusion: 8
        },
        estimatedMarks: {
          awarded: 6.5,
          total: 10,
          lostMarks: 3.5
        },
        whatYouShouldHaveWritten: {
          fullModelAnswer: `**1. IDENTIFICATION OF RISKS UNDER SA 315 (REVISED)**\nUnder SA 315 (Revised), the auditor must assess Risks of Material Misstatement (RoMM) at:\n- **Financial Statement Level**: Pervasive risk arising from manual overrides during month-end reconciliations.\n- **Assertion Level**: Specific risks regarding *Existence & Valuation* of Inventory and *Completeness & Accuracy* of dispatches.\n\n**2. EVALUATION OF IT CONTROLS**\n- **General IT Controls (GITCs)**: Assess User Access Management (breach in segregation of duties u/s access above ₹5,00,000) and Change Management.\n- **Automated Application Controls**: Test automatic invoice-dispatch matching and tolerance checks in the ERP.\n\n**3. AUDITOR'S COURSE OF ACTION**\n- Design tests of controls around IT environment.\n- If GITCs are ineffective, increase substantive analytical procedures and physical inventory verification at warehouse locations.`,
          statutoryHighlights: [
            "SA 315 (Revised) - Risks at Financial Statement vs Assertion Level",
            "General IT Controls (GITCs) vs Automated Application Controls",
            "Entity's Risk Assessment Process & Control Activities",
            "Segregation of Duties (SoD) and Manual Override Risks"
          ],
          crucialWorkingNotes: [
            "Note 1: When GITCs are deficient, reliance on automated controls must be replaced with extensive substantive testing.",
            "Note 2: Distinction between pervasive risk and assertion-specific risks is mandatory to secure full 10 marks."
          ]
        },
        whyYouLostMarks: {
          summary: `You lost 3.5 marks primarily due to weak application of IT control components and skipping the required distinction between Financial Statement level vs Assertion level risks.`,
          deductions: [
            {
              pointsDeducted: 1.5,
              reason: "Omitted explicit classification of RoMM into Financial Statement Level vs Assertion Level",
              flawType: "Concept",
              examinerComment: "SA 315 requires two-tier risk classification. You lumped all risks into general observation without identifying specific assertions (Existence, Cut-off)."
            },
            {
              pointsDeducted: 1.0,
              reason: "Did not distinguish between GITCs (General IT Controls) and Automated Application Controls",
              flawType: "Relevant Provisions",
              examinerComment: "The question specifically asked for GITC responsibilities (Access controls, change mgmt). You only used vague general phrases."
            },
            {
              pointsDeducted: 1.0,
              reason: "Lack of specific audit response to manual overrides in month-end reconciliation",
              flawType: "Application",
              examinerComment: "Failed to prescribe specific audit procedures for the ₹5,00,000 threshold overrides."
            }
          ]
        },
        examinerVerdict: `Good grasp of basic audit direction (Score: 6.5/10), but ICAI examinations require technical precision with standard taxonomy (GITCs, Assertion Mapping) to reach 8.5+ range.`
      });
    }

    const totalMarks = question?.marks || 10;

    const prompt = `
You are a senior ICAI Head Examiner for CA Final / Intermediate examinations.
Evaluate the student's answer to this case-based question with extreme academic rigor.

Question:
"${question?.questionText || ''}"

Subject: "${question?.subject || ''}"
Topic: "${question?.topic || ''}"
Difficulty: "${question?.difficulty || ''}"
Total Marks: ${totalMarks}

Student's Written Answer:
"${studentAnswer}"

Evaluate and return a JSON object with:
1. scores: (All integer ratings strictly out of 10)
   - concept (1-10) -> e.g. 8
   - application (1-10) -> e.g. 5
   - relevantProvisions (1-10) -> e.g. 7
   - presentation (1-10) -> e.g. 6
   - conclusion (1-10) -> e.g. 8
2. estimatedMarks:
   - awarded: float (e.g. 6.5)
   - total: ${totalMarks}
   - lostMarks: float (e.g. 3.5)
3. whatYouShouldHaveWritten:
   - fullModelAnswer: A pristine, ICAI-grade model answer with bold subheadings and clear bullet points
   - statutoryHighlights: array of exact standards/sections/clauses
   - crucialWorkingNotes: array of examiner tips/working notes
4. whyYouLostMarks:
   - summary: A clear 1-2 sentence overview of why the lost marks occurred (e.g. "Why you lost 3.5 marks")
   - deductions: array of objects with:
     - pointsDeducted: number (e.g. 1.5, 1.0)
     - reason: string (concise title of the lost mark cause)
     - flawType: 'Concept' | 'Application' | 'Relevant Provisions' | 'Presentation' | 'Conclusion'
     - examinerComment: detailed examiner justification
5. examinerVerdict: A concise 2-sentence summary of the candidate's performance.

Return ONLY valid JSON.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/evaluate-examiner-answer:", error);
    res.status(500).json({ error: error?.message || "Failed to evaluate examiner answer." });
  }
});

// ☀️ AI Daily Briefing: Personalized Morning / Daily Strategic Briefing
app.post("/api/ai/daily-briefing", async (req, res) => {
  try {
    const { profile, studentName = "Rahul", course = "Intermediate", streakDays = 14, daysToExam = 259 } = req.body;

    const hour = new Date().getHours();
    const timeGreeting = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
    const displayName = profile?.name ? profile.name.split(' ')[0] : studentName;

    if (!aiClient) {
      return res.status(200).json({
        id: `briefing_${Date.now()}`,
        greeting: `☀️ ${timeGreeting}, ${displayName}`,
        studentName: displayName,
        readinessPercentage: 72,
        yesterdayDeltaPct: 2.0,
        dateString: new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' }),
        priorities: [
          {
            id: 'prio_1',
            iconType: 'critical',
            title: 'Audit — SA 315',
            subject: 'Audit',
            topic: 'SA 315',
            detail: 'Identifying & Assessing Risks of Material Misstatement + IT Controls',
            estimatedMins: 90,
            completed: false,
            actionView: 'ai-examiner',
            actionLabel: 'Launch SA 315 Examiner Case'
          },
          {
            id: 'prio_2',
            iconType: 'critical',
            title: 'Tax — ITC',
            subject: 'Direct & Indirect Tax',
            topic: 'Input Tax Credit (Sec 16, 17(5))',
            detail: 'Eligibility, Conditions & Blocked Credits computation drill',
            estimatedMins: 60,
            completed: false,
            actionView: 'academic-tracker',
            actionLabel: 'Solve ITC Practice Set'
          },
          {
            id: 'prio_3',
            iconType: 'high',
            title: 'FR — Ind AS 116',
            subject: 'Financial Reporting',
            topic: 'Ind AS 116 Leases',
            detail: 'Right-of-Use (ROU) Asset, Lease Liability & Remeasurements',
            estimatedMins: 45,
            completed: false,
            actionView: 'answer-coach',
            actionLabel: 'Practice Ind AS 116 Descriptive Answer'
          },
          {
            id: 'prio_4',
            iconType: 'revision',
            title: 'Revise yesterday\'s mistakes',
            subject: 'All Subjects',
            topic: 'Error Ledger & Trap Concepts',
            detail: 'Review 8 tagged mistakes from yesterday\'s test drill',
            estimatedMins: 20,
            completed: false,
            actionView: 'mistake-intelligence',
            actionLabel: 'Open Mistake Intelligence'
          },
          {
            id: 'prio_5',
            iconType: 'practice',
            title: 'Attempt 25 PYQs',
            subject: 'Past Exams & RTP',
            topic: 'ICAI Exam Standard PYQs',
            detail: 'Timed 25 questions under ICAI examination conditions',
            estimatedMins: 45,
            completed: false,
            actionView: 'academic-tracker',
            actionLabel: 'Start 25 PYQs Timer'
          }
        ],
        aiCoachQuote: "You are progressing well, but Audit is becoming your biggest risk. Spend at least 90 minutes on SA 315 today.",
        targetHoursToday: 6.5,
        streakDays: streakDays || 14,
        daysToExam: daysToExam || 259,
        criticalAlert: "Audit SA accuracy dropped to 54% in last 3 tests. Prioritize 90 mins on SA 315."
      });
    }

    const prompt = `
You are a senior personal AI Mentor & Exam Strategist for a Chartered Accountancy student (${course}).
Create a crisp, direct, and motivating "AI Daily Briefing" for today.

Student Details:
- Name: ${displayName}
- Course: ${course}
- Target Exam in: ${daysToExam} days
- Current Streak: ${streakDays} days
- Time of Day Greeting: ${timeGreeting}

Format Requirements:
1. greeting: "☀️ ${timeGreeting}, ${displayName}"
2. readinessPercentage: integer (e.g. 72)
3. yesterdayDeltaPct: float (e.g. +2.0)
4. priorities: Array of 5 high-yield items strictly following these priorities:
   - 🔴 Critical Subject Item (e.g. "Audit — SA 315" - 90 mins)
   - 🔴 Critical Subject Item (e.g. "Tax — ITC" - 60 mins)
   - 🟠 High Importance Item (e.g. "FR — Ind AS 116" - 45 mins)
   - 🔄 Revision Item (e.g. "Revise yesterday's mistakes" - 20 mins)
   - 📝 Practice Drill Item (e.g. "Attempt 25 PYQs" - 45 mins)
5. aiCoachQuote: A direct, personal, human coach statement, e.g.:
   "You are progressing well, but Audit is becoming your biggest risk. Spend at least 90 minutes on SA 315 today."
6. targetHoursToday: number (e.g. 6.5)
7. criticalAlert: string

Return ONLY valid JSON matching this schema.
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Error in /api/ai/daily-briefing:", error);
    res.status(500).json({ error: error?.message || "Failed to generate daily briefing." });
  }
});




// Start Express and Vite server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
