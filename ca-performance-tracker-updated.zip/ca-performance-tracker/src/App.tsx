import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';

// Types and Initial Data
import { 
  ICAIStudentProfile, 
  CourseLevel, 
  Subject, 
  Chapter, 
  TestRecord, 
  Goal, 
  Badge, 
  DoubtQuestion, 
  StudySession,
  Flashcard,
  ProblemDiscussion,
  StudyGroup,
  AIDailyBriefing
} from './types';

import { 
  INITIAL_PROFILE, 
  INITIAL_SUBJECTS, 
  INITIAL_CHAPTERS, 
  INITIAL_TEST_RECORDS, 
  INITIAL_GOALS, 
  INITIAL_BADGES, 
  INITIAL_DOUBTS,
  INITIAL_FLASHCARDS,
  INITIAL_DISCUSSIONS,
  INITIAL_STUDY_GROUPS,
  INITIAL_DAILY_BRIEFING
} from './data/initialData';

// Layout Components
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';

// View Components
import { DashboardView } from './components/DashboardView';
import { ICAIProfileVerificationView } from './components/ICAIProfileVerificationView';
import { AcademicTrackerView } from './components/AcademicTrackerView';
import { AIExaminerModeView } from './components/AIExaminerModeView';
import { AnswerWritingCoachView } from './components/AnswerWritingCoachView';
import { MistakeIntelligenceView } from './components/MistakeIntelligenceView';
import { SubjectAnalyticsView } from './components/SubjectAnalyticsView';
import { AICoachView } from './components/AICoachView';
import { AIStudyPlannerView } from './components/AIStudyPlannerView';
import { AIFlashcardsView } from './components/AIFlashcardsView';
import { TodayAIPlanView } from './components/TodayAIPlanView';
import { GoalGamificationView } from './components/GoalGamificationView';
import { SportsMotivationalVideosView } from './components/SportsMotivationalVideosView';
import { ICAIResourcesView } from './components/ICAIResourcesView';
import { FriendDiscussionsView } from './components/FriendDiscussionsView';
import { CommunityDoubtsView } from './components/CommunityDoubtsView';
import { ReportGeneratorView } from './components/ReportGeneratorView';
import { AdminPanelView } from './components/AdminPanelView';

// Modal
import { AddTestModal } from './components/AddTestModal';
import { AIDailyBriefingModal } from './components/AIDailyBriefingModal';

export default function App() {
  const [profile, setProfile] = useState<ICAIStudentProfile>(INITIAL_PROFILE);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [chapters, setChapters] = useState<Chapter[]>(INITIAL_CHAPTERS);
  const [testRecords, setTestRecords] = useState<TestRecord[]>(INITIAL_TEST_RECORDS);
  const [goals, setGoals] = useState<Goal[]>(INITIAL_GOALS);
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);
  const [doubts, setDoubts] = useState<DoubtQuestion[]>(INITIAL_DOUBTS);
  const [flashcards, setFlashcards] = useState<Flashcard[]>(INITIAL_FLASHCARDS);
  const [discussions, setDiscussions] = useState<ProblemDiscussion[]>(INITIAL_DISCUSSIONS);
  const [studyGroups, setStudyGroups] = useState<StudyGroup[]>(INITIAL_STUDY_GROUPS);

  // AI Daily Briefing State
  const [dailyBriefing, setDailyBriefing] = useState<AIDailyBriefing>(() => {
    const saved = localStorage.getItem('ca_daily_briefing');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_DAILY_BRIEFING;
      }
    }
    return INITIAL_DAILY_BRIEFING;
  });
  const [isDailyBriefingOpen, setIsDailyBriefingOpen] = useState<boolean>(false);
  const [isRefreshingBriefing, setIsRefreshingBriefing] = useState<boolean>(false);

  // App UI State
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [flashcardChapterFilter, setFlashcardChapterFilter] = useState<string | undefined>(undefined);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [isAddTestModalOpen, setIsAddTestModalOpen] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Synchronize Dark Mode Class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Handlers
  const handleCourseChange = (newCourse: CourseLevel) => {
    setProfile(prev => ({ ...prev, course: newCourse }));
  };

  const handleUpdateProfile = (updated: ICAIStudentProfile) => {
    setProfile(updated);
  };

  const handleAddTestRecord = (newTest: Omit<TestRecord, 'id'>) => {
    const testWithId: TestRecord = {
      ...newTest,
      id: `t_${Date.now()}`,
    };
    setTestRecords(prev => [testWithId, ...prev]);

    // Award XP
    setProfile(prev => {
      const newXp = prev.xpPoints + 150;
      const newStreak = prev.dailyStreak + 1;
      return {
        ...prev,
        xpPoints: newXp,
        dailyStreak: newStreak,
      };
    });

    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const handleDeleteTestRecord = (id: string) => {
    setTestRecords(prev => prev.filter(t => t.id !== id));
  };

  const handleUpdateChapter = (updatedChapter: Chapter) => {
    setChapters(prev => prev.map(c => c.id === updatedChapter.id ? updatedChapter : c));
  };

  const handleLogStudySession = (session: StudySession) => {
    const xpGained = session.durationMins * 5;
    setProfile(prev => ({
      ...prev,
      xpPoints: prev.xpPoints + xpGained,
    }));

    // Update time spent in chapter if relevant
    setChapters(prev => prev.map((ch, idx) => {
      if (idx === 0) {
        return { ...ch, timeSpentMins: ch.timeSpentMins + session.durationMins };
      }
      return ch;
    }));
  };

  const handleAddGoal = (newGoal: Omit<Goal, 'id'>) => {
    setGoals(prev => [
      { ...newGoal, id: `g_${Date.now()}` },
      ...prev,
    ]);
  };

  const handleToggleGoal = (id: string) => {
    setGoals(prev => prev.map(g => {
      if (g.id === id) {
        const nextState = !g.completed;
        if (nextState) {
          confetti({ particleCount: 50, spread: 50, origin: { y: 0.7 } });
        }
        return { ...g, completed: nextState };
      }
      return g;
    }));
  };

  const handleDeleteGoal = (id: string) => {
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  const handleAddDoubt = (newDoubt: DoubtQuestion) => {
    setDoubts(prev => [newDoubt, ...prev]);
  };

  const handleAddFlashcards = (newCards: Flashcard[]) => {
    setFlashcards(prev => [...newCards, ...prev]);
  };

  const handleUpdateFlashcard = (updatedCard: Flashcard) => {
    setFlashcards(prev => prev.map(f => f.id === updatedCard.id ? updatedCard : f));
  };

  const handleDeleteFlashcard = (id: string) => {
    setFlashcards(prev => prev.filter(f => f.id !== id));
  };

  const handleAwardXp = (xp: number) => {
    setProfile(prev => ({
      ...prev,
      xpPoints: prev.xpPoints + xp,
    }));
  };

  const handleNavigateToFlashcards = (chapterId?: string) => {
    setFlashcardChapterFilter(chapterId);
    setActiveView('flashcards');
  };

  const handleAddDiscussion = (newDisc: ProblemDiscussion) => {
    setDiscussions(prev => [newDisc, ...prev]);
  };

  const handleUpdateDiscussion = (updatedDisc: ProblemDiscussion) => {
    setDiscussions(prev => prev.map(d => d.id === updatedDisc.id ? updatedDisc : d));
  };

  const handleAddStudyGroup = (newGroup: StudyGroup) => {
    setStudyGroups(prev => [...prev, newGroup]);
  };

  const handleSendMessageToGroup = (groupId: string, msg: { id: string; sender: string; time: string; text: string; isUser: boolean }) => {
    setStudyGroups(prev => prev.map(group => {
      if (group.id === groupId) {
        return {
          ...group,
          groupChat: [...group.groupChat, msg]
        };
      }
      return group;
    }));
  };

  const handleToggleBriefingPriority = (id: string) => {
    setDailyBriefing(prev => {
      const updatedPriorities = prev.priorities.map(p => {
        if (p.id === id) {
          const next = !p.completed;
          if (next) {
            confetti({ particleCount: 40, spread: 45, origin: { y: 0.6 } });
            handleAwardXp(100);
          }
          return { ...p, completed: next };
        }
        return p;
      });
      const updated = { ...prev, priorities: updatedPriorities };
      localStorage.setItem('ca_daily_briefing', JSON.stringify(updated));
      return updated;
    });
  };

  const handleRefreshDailyBriefing = async () => {
    setIsRefreshingBriefing(true);
    try {
      const res = await fetch('/api/ai/daily-briefing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile,
          studentName: profile.name.split(' ')[0] || 'Rahul',
          course: profile.course,
          streakDays: profile.streakDays,
          daysToExam: 259
        })
      });
      if (res.ok) {
        const data = await res.json();
        setDailyBriefing(data);
        localStorage.setItem('ca_daily_briefing', JSON.stringify(data));
      }
    } catch (err) {
      console.error('Error refreshing briefing:', err);
    } finally {
      setIsRefreshingBriefing(false);
    }
  };

  return (
    <div className={`h-screen w-full flex font-sans overflow-hidden transition-colors duration-200 relative ${
      isDarkMode ? 'bg-slate-950 text-slate-100 dark' : 'bg-gradient-to-br from-indigo-50/30 via-slate-50 to-purple-50/30 text-slate-900'
    }`}>
      {/* Background Ambient Color Glow Blobs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 right-10 w-80 h-80 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Mobile Sidebar Overlay Backdrop */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar Navigation */}
      <Sidebar
        activeView={activeView}
        onNavigate={(view) => { setActiveView(view); setIsSidebarOpen(false); }}
        isDarkMode={isDarkMode}
        onOpenBriefing={() => setIsDailyBriefingOpen(true)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Right Area */}
      <main className="flex-1 flex flex-col overflow-hidden min-w-0">
        
        {/* Top Header */}
        <Navbar
          profile={profile}
          onCourseChange={handleCourseChange}
          onNavigate={setActiveView}
          activeView={activeView}
          isDarkMode={isDarkMode}
          toggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          unreadNotificationsCount={3}
          onOpenNotifications={() => setActiveView('community')}
          onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
        />

        {/* Content View Container */}
        <div className="flex-1 p-6 space-y-6 overflow-y-auto">
          {activeView === 'dashboard' && (
            <DashboardView
              profile={profile}
              subjects={subjects}
              testRecords={testRecords}
              goals={goals}
              chapters={chapters}
              onNavigate={setActiveView}
              isDarkMode={isDarkMode}
              onOpenAddTestModal={() => setIsAddTestModalOpen(true)}
              briefing={dailyBriefing}
              onTogglePriority={handleToggleBriefingPriority}
              onOpenBriefingModal={() => setIsDailyBriefingOpen(true)}
              onRefreshBriefing={handleRefreshDailyBriefing}
              isRefreshingBriefing={isRefreshingBriefing}
            />
          )}

          {activeView === 'profile' && (
            <ICAIProfileVerificationView
              profile={profile}
              onUpdateProfile={handleUpdateProfile}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'academic-tracker' && (
            <AcademicTrackerView
              testRecords={testRecords}
              subjects={subjects.filter(s => s.course === profile.course)}
              onAddTest={handleAddTestRecord}
              onDeleteTest={handleDeleteTestRecord}
              isDarkMode={isDarkMode}
              onOpenAddModal={() => setIsAddTestModalOpen(true)}
            />
          )}

          {activeView === 'ai-examiner' && (
            <AIExaminerModeView
              profile={profile}
              subjects={subjects}
              isDarkMode={isDarkMode}
              onNavigate={setActiveView}
              onAwardXp={handleAwardXp}
            />
          )}

          {activeView === 'answer-coach' && (
            <AnswerWritingCoachView
              profile={profile}
              subjects={subjects}
              isDarkMode={isDarkMode}
              onNavigate={setActiveView}
              onAwardXp={handleAwardXp}
            />
          )}

          {activeView === 'mistake-intelligence' && (
            <MistakeIntelligenceView
              profile={profile}
              subjects={subjects}
              isDarkMode={isDarkMode}
              onNavigate={setActiveView}
              onAwardXp={handleAwardXp}
            />
          )}

          {activeView === 'subject-analytics' && (
            <SubjectAnalyticsView
              course={profile.course}
              subjects={subjects}
              testRecords={testRecords}
              chapters={chapters}
              isDarkMode={isDarkMode}
              onNavigate={setActiveView}
            />
          )}

          {activeView === 'ai-coach' && (
            <AICoachView
              profile={profile}
              subjects={subjects}
              testRecords={testRecords}
              chapters={chapters}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'ai-planner' && (
            <AIStudyPlannerView
              profile={profile}
              subjects={subjects.filter(s => s.course === profile.course)}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'flashcards' && (
            <AIFlashcardsView
              course={profile.course}
              subjects={subjects}
              chapters={chapters}
              flashcards={flashcards}
              onAddFlashcards={handleAddFlashcards}
              onUpdateFlashcard={handleUpdateFlashcard}
              onDeleteFlashcard={handleDeleteFlashcard}
              onAwardXp={handleAwardXp}
              isDarkMode={isDarkMode}
              initialChapterId={flashcardChapterFilter}
            />
          )}

          {(activeView === 'today-ai-plan' || activeView === 'study-timer') && (
            <TodayAIPlanView
              profile={profile}
              subjects={subjects.filter(s => s.course === profile.course)}
              testRecords={testRecords}
              onLogSession={handleLogStudySession}
              onAwardXp={handleAwardXp}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'goals' && (
            <GoalGamificationView
              goals={goals}
              badges={badges}
              profile={profile}
              onAddGoal={handleAddGoal}
              onToggleGoal={handleToggleGoal}
              onDeleteGoal={handleDeleteGoal}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'motivation' && (
            <SportsMotivationalVideosView
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'resources' && (
            <ICAIResourcesView
              course={profile.course}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'friend-discussions' && (
            <FriendDiscussionsView
              course={profile.course}
              studentName={profile.name}
              discussions={discussions}
              studyGroups={studyGroups}
              onAddDiscussion={handleAddDiscussion}
              onUpdateDiscussion={handleUpdateDiscussion}
              onAddStudyGroup={handleAddStudyGroup}
              onSendMessageToGroup={handleSendMessageToGroup}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'community' && (
            <CommunityDoubtsView
              course={profile.course}
              subjects={subjects.filter(s => s.course === profile.course)}
              doubts={doubts}
              onAddDoubt={handleAddDoubt}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'report' && (
            <ReportGeneratorView
              profile={profile}
              subjects={subjects}
              testRecords={testRecords}
              chapters={chapters}
              isDarkMode={isDarkMode}
            />
          )}

          {activeView === 'admin' && (
            <AdminPanelView
              subjects={subjects}
              isDarkMode={isDarkMode}
            />
          )}
        </div>

        {/* Footer */}
        <footer className={`shrink-0 py-2.5 px-6 border-t text-center text-[11px] font-semibold tracking-wide transition-colors duration-200 ${
          isDarkMode
            ? 'border-slate-800 text-slate-500 bg-slate-900/80'
            : 'border-slate-200 text-slate-400 bg-white/80'
        }`}>
          <span>Developed by </span>
          <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent font-black">
            CA. Mishu Singhal
          </span>
          <span className="ml-1.5 text-slate-400">✦ CA Mentor AI</span>
        </footer>
      </main>

      {/* Global Modals */}
      <AddTestModal
        isOpen={isAddTestModalOpen}
        onClose={() => setIsAddTestModalOpen(false)}
        subjects={subjects.filter(s => s.course === profile.course)}
        onAddTest={handleAddTestRecord}
        isDarkMode={isDarkMode}
      />

      <AIDailyBriefingModal
        briefing={dailyBriefing}
        profile={profile}
        isOpen={isDailyBriefingOpen}
        onClose={() => setIsDailyBriefingOpen(false)}
        onNavigate={setActiveView}
        onTogglePriority={handleToggleBriefingPriority}
        onRefreshBriefing={handleRefreshDailyBriefing}
        isRefreshing={isRefreshingBriefing}
        isDarkMode={isDarkMode}
      />

    </div>
  );
}
