import { Subject, Chapter, TestRecord, Goal, Badge, ICAIResource, DoubtQuestion, ICAIStudentProfile, Flashcard, TopicWeaknessDiagnostic, QuestionMistakeLog, MistakePatternSummary, AnswerWritingEvaluation, ExaminerQuestion, ExaminerEvaluationResult, AIDailyBriefing } from '../types';

export const INITIAL_PROFILE: ICAIStudentProfile = {
  registrationNumber: 'CRO0784219',
  name: 'Rohan Sharma',
  email: 'rohan.sharma.ca@gmail.com',
  mobile: '+91 98765 43210',
  course: 'Intermediate',
  attempt: 'May 2026',
  articleshipStatus: 'Not Started',
  city: 'Delhi',
  verified: true,
  registrationDate: '2024-08-15',
  validityUntil: '2028-08-14',
  photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
  xpPoints: 3450,
  levelNumber: 4,
  streakDays: 12,
  lastStudyDate: new Date().toISOString().split('T')[0],
  targetExamDate: '2026-05-02',
};

export const INITIAL_SUBJECTS: Subject[] = [
  // Foundation
  { id: 'f_acc', name: 'Accounting', code: 'F-P1', course: 'Foundation', totalChapters: 10, recommendedHours: 120, icaiWeightageMarks: 100 },
  { id: 'f_law', name: 'Business Laws', code: 'F-P2', course: 'Foundation', totalChapters: 7, recommendedHours: 100, icaiWeightageMarks: 100 },
  { id: 'f_qa', name: 'Quantitative Aptitude', code: 'F-P3', course: 'Foundation', totalChapters: 12, recommendedHours: 110, icaiWeightageMarks: 100 },
  { id: 'f_eco', name: 'Business Economics', code: 'F-P4', course: 'Foundation', totalChapters: 10, recommendedHours: 90, icaiWeightageMarks: 100 },

  // Intermediate - Group 1
  { id: 'i_advacc', name: 'Advanced Accounting', code: 'INT-P1', course: 'Intermediate', group: 1, totalChapters: 15, recommendedHours: 180, icaiWeightageMarks: 100 },
  { id: 'i_law', name: 'Corporate & Other Laws', code: 'INT-P2', course: 'Intermediate', group: 1, totalChapters: 11, recommendedHours: 140, icaiWeightageMarks: 100 },
  { id: 'i_tax', name: 'Taxation (DT & IDT)', code: 'INT-P3', course: 'Intermediate', group: 1, totalChapters: 18, recommendedHours: 200, icaiWeightageMarks: 100 },

  // Intermediate - Group 2
  { id: 'i_cost', name: 'Cost & Management Accounting', code: 'INT-P4', course: 'Intermediate', group: 2, totalChapters: 14, recommendedHours: 160, icaiWeightageMarks: 100 },
  { id: 'i_audit', name: 'Auditing & Ethics', code: 'INT-P5', course: 'Intermediate', group: 2, totalChapters: 11, recommendedHours: 150, icaiWeightageMarks: 100 },
  { id: 'i_fmsm', name: 'FM & SM', code: 'INT-P6', course: 'Intermediate', group: 2, totalChapters: 13, recommendedHours: 150, icaiWeightageMarks: 100 },

  // Final - Group 1
  { id: 'fn_fr', name: 'Financial Reporting (FR)', code: 'FIN-P1', course: 'Final', group: 1, totalChapters: 17, recommendedHours: 220, icaiWeightageMarks: 100 },
  { id: 'fn_afm', name: 'Advanced Financial Mgmt (AFM)', code: 'FIN-P2', course: 'Final', group: 1, totalChapters: 14, recommendedHours: 190, icaiWeightageMarks: 100 },
  { id: 'fn_audit', name: 'Advanced Auditing & Ethics', code: 'FIN-P3', course: 'Final', group: 1, totalChapters: 19, recommendedHours: 200, icaiWeightageMarks: 100 },

  // Final - Group 2
  { id: 'fn_dt', name: 'Direct Tax & Int Taxation', code: 'FIN-P4', course: 'Final', group: 2, totalChapters: 22, recommendedHours: 230, icaiWeightageMarks: 100 },
  { id: 'fn_idt', name: 'Indirect Tax Laws (GST & Customs)', code: 'FIN-P5', course: 'Final', group: 2, totalChapters: 20, recommendedHours: 210, icaiWeightageMarks: 100 },
  { id: 'fn_ibs', name: 'Integrated Business Solutions (IBS)', code: 'FIN-P6', course: 'Final', group: 2, totalChapters: 10, recommendedHours: 150, icaiWeightageMarks: 100 },
];

export const INITIAL_CHAPTERS: Chapter[] = [
  // Intermediate Advanced Accounts
  { 
    id: 'ch_advacc_1', 
    subjectId: 'i_advacc', 
    title: 'Accounting Standards Framework & AS 1, 2, 3', 
    chapterNo: 1, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 45, 
    timeSpentMins: 420, 
    difficulty: 'Medium',
    notes: '📌 [AS 2 Valuation]: Cost or Net Realizable Value (NRV), whichever is lower. Exclude abnormal waste and storage costs.\n📐 [AS 3 Cash Flow]: Operating vs Investing vs Financing. Bank overdraft is part of Cash & Cash Equivalents.'
  },
  { 
    id: 'ch_advacc_2', 
    subjectId: 'i_advacc', 
    title: 'AS 10 Property, Plant & Equipment & AS 16 Borrowing Costs', 
    chapterNo: 2, 
    status: 'Revision 2', 
    completionPct: 90, 
    questionsSolved: 38, 
    timeSpentMins: 380, 
    difficulty: 'Hard',
    notes: '📌 [AS 16 Borrowing Costs]: Capitalization starts when expenditure incurred + borrowing cost incurred + active development underway.\n⚠️ [Common ICAI Pitfall]: Do not capitalize borrowing cost during extended periods of suspension.'
  },
  { id: 'ch_advacc_3', subjectId: 'i_advacc', title: 'AS 13 Accounting for Investments', chapterNo: 3, status: 'Revision 1', completionPct: 80, questionsSolved: 28, timeSpentMins: 290, difficulty: 'Medium' },
  { 
    id: 'ch_advacc_4', 
    subjectId: 'i_advacc', 
    title: 'Financial Statements of Companies (Schedule III)', 
    chapterNo: 4, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 50, 
    timeSpentMins: 510, 
    difficulty: 'Hard',
    notes: '📌 [Division I Schedule III]: Operating cycle definition. If operating cycle cannot be identified, assume 12 months.\n⭐ [Important RTP Point]: Disclosures for trade payables MSME vs Non-MSME aging schedule required.'
  },
  { id: 'ch_advacc_5', subjectId: 'i_advacc', title: 'Buyback of Securities & Differential Rights', chapterNo: 5, status: 'Completed', completionPct: 100, questionsSolved: 30, timeSpentMins: 240, difficulty: 'Easy' },
  { id: 'ch_advacc_6', subjectId: 'i_advacc', title: 'Amalgamation & Internal Reconstruction', chapterNo: 6, status: 'Started', completionPct: 45, questionsSolved: 18, timeSpentMins: 210, difficulty: 'Extreme' },
  { id: 'ch_advacc_7', subjectId: 'i_advacc', title: 'Consolidated Financial Statements (AS 21, AS 23, AS 27)', chapterNo: 7, status: 'Started', completionPct: 30, questionsSolved: 12, timeSpentMins: 180, difficulty: 'Extreme' },
  { id: 'ch_advacc_8', subjectId: 'i_advacc', title: 'Branch Accounting & Foreign Branches', chapterNo: 8, status: 'Not Started', completionPct: 0, questionsSolved: 0, timeSpentMins: 0, difficulty: 'Hard' },

  // Intermediate Law
  { 
    id: 'ch_law_1', 
    subjectId: 'i_law', 
    title: 'Preliminary & Incorporation of Company', 
    chapterNo: 1, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 40, 
    timeSpentMins: 310, 
    difficulty: 'Easy',
    notes: '📌 [Section 2(87)]: Subsidiary company threshold > 50% total voting power or control over board composition.\n📌 [Section 3A]: Members severely liable if number falls below 7 (public) or 2 (private) and company carries on business for > 6 months.'
  },
  { id: 'ch_law_2', subjectId: 'i_law', title: 'Prospectus and Allotment of Securities', chapterNo: 2, status: 'Revision 2', completionPct: 85, questionsSolved: 32, timeSpentMins: 260, difficulty: 'Medium' },
  { id: 'ch_law_3', subjectId: 'i_law', title: 'Share Capital and Debentures', chapterNo: 3, status: 'Revision 1', completionPct: 75, questionsSolved: 25, timeSpentMins: 240, difficulty: 'Hard' },
  { 
    id: 'ch_law_4', 
    subjectId: 'i_law', 
    title: 'Management and Administration (AGM & EGM)', 
    chapterNo: 4, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 48, 
    timeSpentMins: 360, 
    difficulty: 'Medium',
    notes: '📌 [Section 96 AGM]: Gap between 2 AGMs shall not exceed 15 months. First AGM within 9 months from close of financial year.\n📌 [Section 101 Notice]: Clear 21 days notice required for general meeting.'
  },
  { id: 'ch_law_5', subjectId: 'i_law', title: 'Declaration and Payment of Dividend', chapterNo: 5, status: 'Completed', completionPct: 100, questionsSolved: 20, timeSpentMins: 180, difficulty: 'Easy' },
  { id: 'ch_law_6', subjectId: 'i_law', title: 'Foreign Exchange Management Act (FEMA, 1999)', chapterNo: 6, status: 'Started', completionPct: 40, questionsSolved: 15, timeSpentMins: 150, difficulty: 'Hard' },

  // Intermediate Tax
  { 
    id: 'ch_tax_1', 
    subjectId: 'i_tax', 
    title: 'Basic Concepts & Residential Status (Income Tax)', 
    chapterNo: 1, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 35, 
    timeSpentMins: 290, 
    difficulty: 'Easy',
    notes: '📌 [Section 6(1)]: Resident if in India >= 182 days OR (>= 60 days in PY AND >= 365 days in 4 preceding PYs).\n📌 [Section 115BAC]: Default new tax regime tax slabs (FY 2025-26 / AY 2026-27).'
  },
  { id: 'ch_tax_2', subjectId: 'i_tax', title: 'Salaries & House Property', chapterNo: 2, status: 'Revision 2', completionPct: 90, questionsSolved: 50, timeSpentMins: 450, difficulty: 'Medium' },
  { id: 'ch_tax_3', subjectId: 'i_tax', title: 'Profits & Gains of Business or Profession (PGBP)', chapterNo: 3, status: 'Started', completionPct: 50, questionsSolved: 22, timeSpentMins: 380, difficulty: 'Extreme' },
  { id: 'ch_tax_4', subjectId: 'i_tax', title: 'Capital Gains & Income from Other Sources', chapterNo: 4, status: 'Started', completionPct: 40, questionsSolved: 18, timeSpentMins: 240, difficulty: 'Hard' },
  { id: 'ch_tax_5', subjectId: 'i_tax', title: 'Levy and Collection of GST & Supply under GST', chapterNo: 5, status: 'Mastered', completionPct: 100, questionsSolved: 42, timeSpentMins: 320, difficulty: 'Medium' },
  { id: 'ch_tax_6', subjectId: 'i_tax', title: 'Input Tax Credit (ITC) under GST', chapterNo: 6, status: 'Revision 1', completionPct: 70, questionsSolved: 30, timeSpentMins: 310, difficulty: 'Extreme' },

  // Intermediate Audit
  { id: 'ch_audit_1', subjectId: 'i_audit', title: 'Nature, Objective and Scope of Audit (SA 200 series)', chapterNo: 1, status: 'Mastered', completionPct: 100, questionsSolved: 35, timeSpentMins: 280, difficulty: 'Easy' },
  { id: 'ch_audit_2', subjectId: 'i_audit', title: 'Audit Strategy, Audit Planning and Audit Programme', chapterNo: 2, status: 'Revision 1', completionPct: 80, questionsSolved: 25, timeSpentMins: 220, difficulty: 'Medium' },
  { id: 'ch_audit_3', subjectId: 'i_audit', title: 'Risk Assessment and Internal Control (SA 315)', chapterNo: 3, status: 'Started', completionPct: 55, questionsSolved: 19, timeSpentMins: 260, difficulty: 'Hard' },
  { id: 'ch_audit_4', subjectId: 'i_audit', title: 'Audit Documentation and Audit Evidence (SA 230, 500)', chapterNo: 4, status: 'Not Started', completionPct: 0, questionsSolved: 0, timeSpentMins: 0, difficulty: 'Hard' },

  // Intermediate Costing
  { 
    id: 'ch_cost_1', 
    subjectId: 'i_cost', 
    title: 'Material Cost & Employee Cost', 
    chapterNo: 1, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 45, 
    timeSpentMins: 340, 
    difficulty: 'Easy',
    notes: '📐 [EOQ Formula]: EOQ = √[(2 × A × O) / C]\n📌 [Re-order Level]: Max Consumption × Max Reorder Period.'
  },
  { id: 'ch_cost_2', subjectId: 'i_cost', title: 'Overheads & Activity Based Costing (ABC)', chapterNo: 2, status: 'Revision 2', completionPct: 90, questionsSolved: 38, timeSpentMins: 310, difficulty: 'Medium' },
  { 
    id: 'ch_cost_3', 
    subjectId: 'i_cost', 
    title: 'Marginal Costing & CVP Analysis', 
    chapterNo: 3, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 55, 
    timeSpentMins: 420, 
    difficulty: 'Hard',
    notes: '📐 [P/V Ratio]: (Contribution / Sales) × 100 OR (Change in Profit / Change in Sales) × 100.\n📐 [Break-Even Point (Units)]: Fixed Cost / Contribution per unit.'
  },
  { id: 'ch_cost_4', subjectId: 'i_cost', title: 'Standard Costing & Variance Analysis', chapterNo: 4, status: 'Started', completionPct: 60, questionsSolved: 28, timeSpentMins: 350, difficulty: 'Extreme' },

  // Intermediate FM SM
  { 
    id: 'ch_fmsm_1', 
    subjectId: 'i_fmsm', 
    title: 'Ratio Analysis & Cost of Capital', 
    chapterNo: 1, 
    status: 'Mastered', 
    completionPct: 100, 
    questionsSolved: 40, 
    timeSpentMins: 310, 
    difficulty: 'Medium',
    notes: '📐 [Ke Dividend Growth Model]: Ke = (D1 / P0) + g\n📐 [Interest Coverage Ratio]: EBIT / Interest.'
  },
  { id: 'ch_fmsm_2', subjectId: 'i_fmsm', title: 'Capital Budgeting Decisions & Leverage', chapterNo: 2, status: 'Revision 1', completionPct: 75, questionsSolved: 30, timeSpentMins: 290, difficulty: 'Hard' },
  { id: 'ch_fmsm_3', subjectId: 'i_fmsm', title: 'Introduction to Strategic Management & Dynamics', chapterNo: 3, status: 'Mastered', completionPct: 100, questionsSolved: 25, timeSpentMins: 200, difficulty: 'Easy' },
];

export const INITIAL_TEST_RECORDS: TestRecord[] = [
  { id: 't1', subjectId: 'i_advacc', testType: 'Mock Test', title: 'ICAI Series 1 Mock - Adv Accounts', date: '2026-02-10', maxMarks: 100, marksObtained: 72, attemptNumber: 1, difficultyLevel: 'ICAI Standard', timeTakenMins: 175, remarks: 'Strong in AS and Schedule III. Need speed improvement in Amalgamation.' },
  { id: 't2', subjectId: 'i_law', testType: 'RTP', title: 'May 2026 RTP Question Paper', date: '2026-02-15', maxMarks: 100, marksObtained: 64, attemptNumber: 1, difficultyLevel: 'Challenging', timeTakenMins: 180, remarks: 'Good accuracy in Corporate Law. Need clearer presentation in FEMA case laws.' },
  { id: 't3', subjectId: 'i_tax', testType: 'MTP', title: 'ICAI MTP Series 1 - Tax', date: '2026-02-20', maxMarks: 100, marksObtained: 58, attemptNumber: 1, difficultyLevel: 'Challenging', timeTakenMins: 180, remarks: 'GST section was 42/50. Income tax PGBP calculation had minor deduction error.' },
  { id: 't4', subjectId: 'i_cost', testType: 'Past Paper', title: 'Nov 2025 Past Exam Paper', date: '2026-02-28', maxMarks: 100, marksObtained: 79, attemptNumber: 1, difficultyLevel: 'Moderate', timeTakenMins: 165, remarks: 'Excellent score in Marginal Costing and ABC. Missed 5 marks in Reconciliation.' },
  { id: 't5', subjectId: 'i_audit', testType: 'Coaching Test', title: 'Audit SA 200-500 Chapter Unit Test', date: '2026-03-02', maxMarks: 50, marksObtained: 31, attemptNumber: 1, difficultyLevel: 'ICAI Standard', timeTakenMins: 90, remarks: 'Audit keywords were missing in 2 answer paragraphs. Work on SA numbers.' },
  { id: 't6', subjectId: 'i_fmsm', testType: 'ICAI Unit Test', title: 'FM Ratio Analysis & Cost of Capital', date: '2026-03-05', maxMarks: 50, marksObtained: 41, attemptNumber: 1, difficultyLevel: 'Easy', timeTakenMins: 80, remarks: 'Very confident in formulas. Full marks in Leverage calculations.' },
];

export const INITIAL_GOALS: Goal[] = [
  { id: 'g1', title: 'Complete Amalgamation Chapter 6 Revision', subjectId: 'i_advacc', targetDate: '2026-03-15', completed: false, category: 'Syllabus', progressPct: 45 },
  { id: 'g2', title: 'Solve 100 MCQs in GST Input Tax Credit', subjectId: 'i_tax', targetDate: '2026-03-12', completed: false, category: 'Weekly', progressPct: 70 },
  { id: 'g3', title: 'Memorize SA 200, 210, 220, 230 Objectives', subjectId: 'i_audit', targetDate: '2026-03-10', completed: true, category: 'Daily', progressPct: 100 },
  { id: 'g4', title: 'Attempt 1 Full 3-Hour Costing Mock Test', subjectId: 'i_cost', targetDate: '2026-03-18', completed: false, category: 'Weekly', progressPct: 20 },
];

export const INITIAL_BADGES: Badge[] = [
  { id: 'b1', name: '7-Day Fire Streak', description: 'Maintained a uninterrupted 7-day study logging streak', icon: '🔥', unlocked: true, unlockedAt: '2026-02-25' },
  { id: 'b2', name: 'Mock Test Warrior', description: 'Scored above 70% in an official ICAI Mock Test', icon: '🛡️', unlocked: true, unlockedAt: '2026-02-10' },
  { id: 'b3', name: 'AS Champion', description: 'Completed 100% revision on Accounting Standards', icon: '🏆', unlocked: true, unlockedAt: '2026-02-28' },
  { id: 'b4', name: 'Night Owl Scholar', description: 'Logged 25+ total study hours in a single week', icon: '🦉', unlocked: true, unlockedAt: '2026-03-01' },
  { id: 'b5', name: '500 MCQ Crusher', description: 'Solved over 500 practice MCQs across subjects', icon: '⚡', unlocked: false },
  { id: 'b6', name: 'CA Rank Holder Mindset', description: 'Achieved an AI Exam Readiness Score above 85%', icon: '👑', unlocked: false },
];

export const ICAI_RESOURCES: ICAIResource[] = [
  { id: 'r1', title: 'ICAI Board of Studies (BOS) Knowledge Portal', category: 'BOS Portal', course: 'All', url: 'https://boslive.icai.org/', description: 'Official e-learning hub for Study Material, live lectures, and podcasts.' },
  { id: 'r2', title: 'Revision Test Papers (RTP) - May 2026', category: 'RTP', course: 'Intermediate', url: 'https://www.icai.org/post/revision-test-papers-intermediate', description: 'Official ICAI Revision Test Papers with latest amendments for upcoming attempt.' },
  { id: 'r3', title: 'Model Test Papers (MTP) Series 1 & 2', category: 'MTP', course: 'Intermediate', url: 'https://www.icai.org/post/mock-test-papers-intermediate', description: 'Standard ICAI Mock question papers with suggested answer keys.' },
  { id: 'r4', title: 'Past Year Question Papers & Suggested Answers', category: 'Past Papers', course: 'Intermediate', url: 'https://www.icai.org/post/question-papers-intermediate', description: 'Download actual exam question papers from past 5 years.' },
  { id: 'r5', title: 'ICAI Student Journal (The CA Student)', category: 'Student Journal', course: 'All', url: 'https://www.icai.org/post/the-ca-student', description: 'Monthly magazine containing academic updates, case laws, and exam tips.' },
  { id: 'r6', title: 'ICAI Examination Portal & Registration', category: 'Announcements', course: 'All', url: 'https://icaiexam.icai.org/', description: 'Official portal for exam form filling, admit cards, and result announcements.' },
];

export const INITIAL_DOUBTS: DoubtQuestion[] = [
  { id: 'd1', studentName: 'Ananya Verma', course: 'Intermediate', subject: 'Taxation', chapter: 'PGBP', question: 'How do we treat additional depreciation under Section 32(1)(iia) if machinery was acquired and put to use for less than 180 days in the previous year?', aiAnswer: 'Under Section 32(1)(iia), if machinery is put to use for less than 180 days in PY, 50% of the additional depreciation rate (i.e. 10% instead of 20%) is allowed in that PY. The remaining 10% balance additional depreciation can be claimed in the immediately succeeding PY!', upvotes: 14, createdAt: '2026-03-04', resolved: true },
  { id: 'd2', studentName: 'Vikram Mehta', course: 'Intermediate', subject: 'Advanced Accounting', chapter: 'AS 10 PPE', question: 'Should dismantling and site restoration costs be capitalised into the cost of Property, Plant & Equipment under AS 10?', aiAnswer: 'Yes! Under AS 10 (Revised), the initial estimate of dismantling, removing the item, and restoring the site on which it is located is included in the cost of PPE as a present obligation.', upvotes: 9, createdAt: '2026-03-05', resolved: true },
  { id: 'd3', studentName: 'Priya Nair', course: 'Intermediate', subject: 'Auditing & Ethics', chapter: 'SA 230', question: 'What is the assembly period for audit documentation file under SA 230 after the audit report date?', aiAnswer: 'Under SA 230, the auditor should assemble the audit documentation in an audit file and complete the administrative process of assembling the final audit file on a timely basis, ordinarily within 60 days after the date of the auditor’s report.', upvotes: 21, createdAt: '2026-03-06', resolved: true }
];

export const INITIAL_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc_1',
    chapterId: 'ch_advacc_1',
    subjectId: 'i_advacc',
    question: 'Under AS 2 (Valuation of Inventories), how are inventories measured and what costs must be strictly EXCLUDED?',
    answer: 'Inventories must be valued at the LOWER of Cost or Net Realizable Value (NRV).\n\nCosts strictly EXCLUDED:\n• Abnormal amounts of wasted materials or labor\n• Storage costs (unless necessary in production)\n• Administrative overheads not contributing to bringing inventory to location/condition\n• Selling & distribution costs',
    hint: 'Lower of Cost or NRV rule.',
    difficulty: 'Medium',
    reviewCount: 3,
    status: 'Mastered',
    tags: ['AS 2', 'Inventories', 'Valuation'],
    createdFromNotes: true
  },
  {
    id: 'fc_2',
    chapterId: 'ch_advacc_1',
    subjectId: 'i_advacc',
    question: 'How is Bank Overdraft treated under AS 3 (Cash Flow Statements)?',
    answer: 'Bank overdrafts repayable on demand that form an integral part of an enterprise\'s cash management are included as a component of Cash and Cash Equivalents (not financing activity).',
    hint: 'Component of Cash & Cash Equivalents.',
    difficulty: 'Easy',
    reviewCount: 2,
    status: 'Mastered',
    tags: ['AS 3', 'Cash Flow', 'Bank Overdraft'],
    createdFromNotes: true
  },
  {
    id: 'fc_3',
    chapterId: 'ch_advacc_2',
    subjectId: 'i_advacc',
    question: 'What three criteria must be satisfied simultaneously to commence capitalization of borrowing costs under AS 16?',
    answer: '1. Capital expenditure for the asset is being incurred.\n2. Borrowing costs are being incurred.\n3. Activities necessary to prepare the qualifying asset for intended use or sale are actively in progress.',
    hint: 'Expenditure + Borrowing Cost + Active Development.',
    difficulty: 'Hard',
    reviewCount: 1,
    status: 'Learning',
    tags: ['AS 16', 'Borrowing Costs', 'Capitalization'],
    createdFromNotes: true
  },
  {
    id: 'fc_4',
    chapterId: 'ch_advacc_4',
    subjectId: 'i_advacc',
    question: 'Under Schedule III Division I of Companies Act 2013, what is the default rule for Operating Cycle length if it cannot be identified?',
    answer: 'If an entity\'s normal operating cycle cannot be clearly identified, its duration is assumed to be 12 months.',
    hint: '12-month standard rule.',
    difficulty: 'Easy',
    reviewCount: 4,
    status: 'Mastered',
    tags: ['Schedule III', 'Operating Cycle'],
    createdFromNotes: true
  },
  {
    id: 'fc_5',
    chapterId: 'ch_law_1',
    subjectId: 'i_law',
    question: 'Under Section 3A of Companies Act 2013, what happens if the number of members drops below the legal minimum and business continues for over 6 months?',
    answer: 'Every person who remains a member after 6 months and is aware of this condition shall be personally and severally liable for the payment of the whole debts of the company contracted during that period.',
    hint: 'Personal unlimited liability after 6 months.',
    difficulty: 'Hard',
    reviewCount: 0,
    status: 'New',
    tags: ['Companies Act', 'Sec 3A', 'Personal Liability']
  },
  {
    id: 'fc_6',
    chapterId: 'ch_fmsm_1',
    subjectId: 'i_fmsm',
    question: 'State the formula for Cost of Equity (Ke) under Dividend Growth Model and Interest Coverage Ratio.',
    answer: '1. Cost of Equity (Ke) = (D1 / P0) + g\n   where D1 = Expected Dividend = D0(1+g), P0 = Current Market Price, g = Growth Rate.\n\n2. Interest Coverage Ratio = EBIT / Interest Expenses.',
    hint: 'Ke = (D1/P0)+g and EBIT / Interest.',
    difficulty: 'Medium',
    reviewCount: 2,
    status: 'Mastered',
    tags: ['FM', 'Ke Formula', 'Ratio Analysis'],
    createdFromNotes: true
  }
];

export const INITIAL_DISCUSSIONS: any[] = [
  {
    id: 'disc_1',
    title: 'How to manage 10-12 hours study daily without total mental burnout?',
    category: 'Burnout & Focus',
    authorName: 'Aarav Mehta',
    course: 'Intermediate',
    problemStatement: 'Hi everyone! As May 2026 attempt approaches, I try sitting for 10-12 hours daily, but after 5 hours my concentration plummets and I start feeling overwhelmed by Audit and Tax provisions. How do you all keep focus high without getting burned out?',
    createdAt: '2026-08-10',
    upvotes: 24,
    tags: ['Burnout', 'Pomodoro', 'Study Routine', 'Mental Health'],
    isSolved: true,
    aiAdvisorSummary: 'Switch from time-based sitting to 50/10 Pomodoro sprints. Rotate between heavy theoretical subjects (Audit/Law) in the morning and numerical subjects (Accounts/Costing) in the evening.',
    comments: [
      {
        id: 'c_101',
        authorName: 'Priya Verma (CA Ranker AIR 14)',
        authorBadge: 'AIR 14 Ranker',
        content: 'Do NOT try sitting continuously! Use 50 minutes study + 10 minutes walk rule. Also, complete your hardest subject (e.g. Audit or Tax) in the first 3 hours after waking up when willpower is maximum.',
        createdAt: '2026-08-10',
        upvotes: 18,
        isVerifiedRanker: true
      },
      {
        id: 'c_102',
        authorName: 'AI CA Mentor',
        authorBadge: 'AI Senior Mentor',
        content: 'Mental fatigue occurs when passive reading replaces active recall. Instead of re-reading Law chapters, test yourself with Flashcards or outline 3 RTP questions on paper. Active recall keeps your brain alert!',
        createdAt: '2026-08-10',
        upvotes: 15,
        isAiAdvisor: true
      },
      {
        id: 'c_103',
        authorName: 'Vikram Singh',
        content: 'I joined a study group on this app where we post our completed study blocks every 2 hours. That peer accountability helped me stay focused without getting isolated!',
        createdAt: '2026-08-11',
        upvotes: 8
      }
    ]
  },
  {
    id: 'disc_2',
    title: 'Huge Tax & Law Backlogs! 60 Days Left – How to prioritize syllabus?',
    category: 'Backlogs & Timetable',
    authorName: 'Neha Agarwal',
    course: 'Intermediate',
    problemStatement: 'I am way behind in Income Tax (PGBP & Capital Gains) and Companies Act chapters. Should I try completing 100% syllabus or focus on high-weightage ABC analysis chapters first?',
    createdAt: '2026-08-09',
    upvotes: 19,
    tags: ['Backlogs', 'ABC Analysis', 'Taxation', 'Revision'],
    isSolved: false,
    comments: [
      {
        id: 'c_201',
        authorName: 'Karan Malhotra',
        authorBadge: 'CA Finalist',
        content: 'Strictly follow ICAI Category A topics first! For Income Tax: PGBP, Salary, TDS/TCS, Assessment of Individuals, and GSTR 1/3B carry ~65% weightage. Master these before touching smaller chapters.',
        createdAt: '2026-08-09',
        upvotes: 14,
        isVerifiedRanker: true
      },
      {
        id: 'c_202',
        authorName: 'Rohan Sharma',
        content: 'Same situation here! I created a 3-pass revision schedule: Pass 1 on Category A (15 days), Pass 2 on Category B & RTP (10 days), and Pass 3 for Full Mock Test.',
        createdAt: '2026-08-10',
        upvotes: 6
      }
    ]
  },
  {
    id: 'disc_3',
    title: 'Big 4 vs Top Mid-Size CA Firm Articleship: What gives better exposure?',
    category: 'Articleship & Career',
    authorName: 'Siddharth Roy',
    course: 'Intermediate',
    problemStatement: 'Cleared CA Inter both groups! I am confused between applying for Big 4 (E&Y / PwC / Deloitte / KPMG) vs a reputed mid-size firm in Delhi. Big 4 offers specialized domain depth but long hours; mid-size offers all-round audit, tax, & ROC exposure. Which is better long term?',
    createdAt: '2026-08-08',
    upvotes: 31,
    tags: ['Articleship', 'Big 4', 'Mid Size Firm', 'Career'],
    isSolved: true,
    comments: [
      {
        id: 'c_301',
        authorName: 'Ananya Gupta',
        authorBadge: 'CA Articleship Mentor',
        content: 'If your goal is corporate finance / MNC / investment banking after CA, Big 4 brand value is unbeatable. If your goal is starting your own CA practice, a mid-size firm gives broader hands-on GST, ITR, and Bank Audit experience!',
        createdAt: '2026-08-08',
        upvotes: 25,
        isVerifiedRanker: true
      }
    ]
  },
  {
    id: 'disc_4',
    title: 'How to tackle ICAI 30% MCQ Section in Audit & Law without losing marks?',
    category: 'Exam Strategy',
    authorName: 'Simran Kaur',
    course: 'Intermediate',
    problemStatement: 'In full length mock tests, I lose 8-10 marks in tricky ICAI MCQs due to negative marking and subtle wording traps in Standards on Auditing (SAs). How do you approach case-scenario MCQs?',
    createdAt: '2026-08-07',
    upvotes: 16,
    tags: ['MCQs', 'Audit', 'Law', 'ICAI Pattern'],
    isSolved: false,
    comments: [
      {
        id: 'c_401',
        authorName: 'AI CA Mentor',
        authorBadge: 'AI Senior Mentor',
        content: '1. Read the MCQ question options FIRST before reading the long case scenario. This gives your brain a filter on what specific facts to search for in the paragraph.\n2. Practice ICAI MCQ Booklet twice – 60% of exam scenarios borrow identical clauses.',
        createdAt: '2026-08-07',
        upvotes: 11,
        isAiAdvisor: true
      }
    ]
  }
];

export const INITIAL_WEAKNESS_DIAGNOSTICS: TopicWeaknessDiagnostic[] = [
  // Auditing & Ethics (i_audit)
  {
    id: 'diag_audit_1',
    subjectId: 'i_audit',
    subjectName: 'Auditing & Ethics',
    topicName: 'Company Audit (Sec 139–148)',
    scorePct: 82,
    status: 'strong',
    testsAttempted: 4,
    aiIdentifiedProblem: 'Solid command over statutory disqualifications and rotation criteria under Section 139(2). Minor precision loss on Cost Audit turnover limits.',
    rootCauseCategory: 'Provision Clause Precision',
    aiActionPlan: [
      'Maintain memory with 5-minute flashcard sweeps on Cost Audit Rule 3 & 4 applicability thresholds.',
      'Solve 2 mixed case studies from ICAI Mock Exam Series 1.'
    ],
    examWeightage: '12–16 Marks',
    commonICMITrap: 'Confusing 5 consecutive years vs 10 consecutive years cooling period for individual vs audit firm.',
    lastTestedDate: '2026-08-10'
  },
  {
    id: 'diag_audit_2',
    subjectId: 'i_audit',
    subjectName: 'Auditing & Ethics',
    topicName: 'SA 315 (Identifying & Assessing RoMM)',
    scorePct: 48,
    status: 'critical',
    testsAttempted: 5,
    aiIdentifiedProblem: 'You are losing marks primarily because you identify the correct auditing standard but fail to apply it to the case.',
    rootCauseCategory: 'Application Deficit',
    aiActionPlan: [
      'Structure your case study answer into 3 separate paragraphs: (1) Reference & core mandate of SA 315, (2) Analysis linking internal control deficiency in the given facts, (3) Direct conclusion on whether RoMM is pervasive.',
      'Explicitly cite the 5 components of Internal Control: Control Environment, Risk Assessment, Information System, Control Activities, and Monitoring.',
      'Practice 4 past exam case studies from May 2024 and Nov 2024 RTPs.'
    ],
    examWeightage: '8–12 Marks',
    commonICMITrap: 'Writing generic audit procedures instead of specific risk assessment procedures at the financial statement and assertion level.',
    lastTestedDate: '2026-08-14'
  },
  {
    id: 'diag_audit_3',
    subjectId: 'i_audit',
    subjectName: 'Auditing & Ethics',
    topicName: 'SA 500 (Audit Evidence & Reliability Hierarchy)',
    scorePct: 76,
    status: 'strong',
    testsAttempted: 3,
    aiIdentifiedProblem: 'Accurate grasp of direct vs indirect evidence. High scoring on written representation linkage.',
    rootCauseCategory: 'ICAI Keyword Omission',
    aiActionPlan: [
      'Ensure standard phrases like "sufficient appropriate audit evidence" and "persuasive rather than conclusive" are written verbatim in conclusions.'
    ],
    examWeightage: '6–10 Marks',
    commonICMITrap: 'Relying solely on inquiry without corroborating external third-party confirmations.',
    lastTestedDate: '2026-08-11'
  },
  {
    id: 'diag_audit_4',
    subjectId: 'i_audit',
    subjectName: 'Auditing & Ethics',
    topicName: 'Audit Evidence Procedures (SA 501/505/520)',
    scorePct: 54,
    status: 'moderate',
    testsAttempted: 4,
    aiIdentifiedProblem: 'Weakness in SA 505 External Confirmation exception handling when management refuses permission to send confirmation requests.',
    rootCauseCategory: 'Application Deficit',
    aiActionPlan: [
      'Memorize the 3-step auditor action when management refuses confirmation: (1) Inquire reasons, (2) Evaluate implications on RoMM & fraud risk, (3) Perform alternative audit procedures.',
      'Review SA 501 inventory count attendance exceptions when inventory is held with third parties.'
    ],
    examWeightage: '8–10 Marks',
    commonICMITrap: 'Accepting oral management explanations without documenting reasons or alternative inspection.',
    lastTestedDate: '2026-08-12'
  },
  {
    id: 'diag_audit_5',
    subjectId: 'i_audit',
    subjectName: 'Auditing & Ethics',
    topicName: 'Audit Reporting (CARO 2020 & SA 700/705/706)',
    scorePct: 68,
    status: 'moderate',
    testsAttempted: 4,
    aiIdentifiedProblem: 'You correctly identify Qualified vs Adverse opinion, but confuse CARO 2020 Clause (i) Inventory reporting with Clause (ii) Working capital limits.',
    rootCauseCategory: 'Provision Clause Precision',
    aiActionPlan: [
      'Create a 1-page summary chart for CARO 2020 Clause 3(i) to 3(xx) with exact sub-clause keywords (e.g. quarterly returns vs sanction limit > ₹5 Crores).',
      'Solve 3 drafting questions on Emphasis of Matter vs Key Audit Matters (KAM SA 701).'
    ],
    examWeightage: '10–14 Marks',
    commonICMITrap: 'Reporting internal financial controls under SA 700 instead of Section 143(3)(i).',
    lastTestedDate: '2026-08-09'
  },

  // Taxation (i_tax)
  {
    id: 'diag_tax_1',
    subjectId: 'i_tax',
    subjectName: 'Taxation (DT & IDT)',
    topicName: 'GST – Input Tax Credit (Sec 16 & Blocked Credit Sec 17(5))',
    scorePct: 46,
    status: 'critical',
    testsAttempted: 6,
    aiIdentifiedProblem: 'You understand general ITC conditions under Sec 16, but lose marks because you fail to check the 180-day supplier payment reversal rule and misinterpret Sec 17(5) food & beverage exemptions for statutory obligations.',
    rootCauseCategory: 'Application Deficit',
    aiActionPlan: [
      'Make an exhaustive checklist of Sec 17(5) exceptions (e.g., motor vehicle seating capacity > 13 persons, outdoor catering provided under statutory employer mandate under Factories Act).',
      'Practice 5 multi-concept computation sums from past 3 RTPs focusing on invoice matching and blocked credit line items.'
    ],
    examWeightage: '12–16 Marks',
    commonICMITrap: 'Taking full ITC on motor vehicles used for general business conveyance.',
    lastTestedDate: '2026-08-13'
  },
  {
    id: 'diag_tax_2',
    subjectId: 'i_tax',
    subjectName: 'Taxation (DT & IDT)',
    topicName: 'Profits & Gains of Business or Profession (PGBP Sec 30–44DB)',
    scorePct: 52,
    status: 'moderate',
    testsAttempted: 5,
    aiIdentifiedProblem: 'Calculation errors in Section 43B statutory dues payment before ITR filing date vs Section 40(a)(ia) 30% TDS disallowance.',
    rootCauseCategory: 'Calculation Speed',
    aiActionPlan: [
      'Solve comprehensive 14-mark PGBP computation questions with timer enabled.',
      'Review depreciation rates under Section 32 (Block of Assets) and additional depreciation 20% criteria.'
    ],
    examWeightage: '14–18 Marks',
    commonICMITrap: 'Disallowing 100% of expense under 40(a)(ia) for resident payee instead of 30%.',
    lastTestedDate: '2026-08-12'
  },
  {
    id: 'diag_tax_3',
    subjectId: 'i_tax',
    subjectName: 'Taxation (DT & IDT)',
    topicName: 'Salary Income & Perquisites (Sec 15–17)',
    scorePct: 84,
    status: 'strong',
    testsAttempted: 4,
    aiIdentifiedProblem: 'Strong conceptual clarity on HRA exemption formula, gratuity limits, and standard deduction of ₹75,000 under new tax regime.',
    rootCauseCategory: 'Provision Clause Precision',
    aiActionPlan: [
      'Double check employer contribution to EPF/NPS exceeding ₹7.5 Lakhs combined limit.'
    ],
    examWeightage: '8–12 Marks',
    commonICMITrap: 'Applying ₹50,000 standard deduction instead of revised ₹75,000 in updated assessment year computations.',
    lastTestedDate: '2026-08-08'
  },
  {
    id: 'diag_tax_4',
    subjectId: 'i_tax',
    subjectName: 'Taxation (DT & IDT)',
    topicName: 'TDS & TCS Provisions (Sec 192–195 & 206C)',
    scorePct: 71,
    status: 'moderate',
    testsAttempted: 3,
    aiIdentifiedProblem: 'Solid on 194C contractor limits (₹30k / ₹1L), but occasional mistakes in Section 194Q buyer TDS vs 206C(1H) seller TCS prioritization hierarchy.',
    rootCauseCategory: 'Provision Clause Precision',
    aiActionPlan: [
      'Remember rule: Section 194Q takes absolute priority over Section 206C(1H) if both buyer and seller cross ₹10 Crore threshold.'
    ],
    examWeightage: '8–10 Marks',
    commonICMITrap: 'Charging both TDS 194Q and TCS 206C(1H) on the same invoice transaction.',
    lastTestedDate: '2026-08-11'
  },

  // Advanced Accounting (i_advacc)
  {
    id: 'diag_advacc_1',
    subjectId: 'i_advacc',
    subjectName: 'Advanced Accounting',
    topicName: 'Consolidated Financial Statements (AS 21 / AS 23)',
    scorePct: 42,
    status: 'critical',
    testsAttempted: 5,
    aiIdentifiedProblem: 'You understand the consolidation balance sheet format, but lose marks in the time-apportionment of subsidiary post-acquisition profits and eliminating downstream unrealized stock reserve from holding parent profit.',
    rootCauseCategory: 'Application Deficit',
    aiActionPlan: [
      'Write out the 6 Standard Steps of Consolidation: (1) Date of acquisition ratio, (2) Analysis of subsidiary reserves, (3) Cost of Control / Goodwill calculation, (4) Minority Interest, (5) Consolidated P&L, (6) Balance sheet alignment.',
      'Practice 3 full consolidation problems with dividend distribution and bonus shares.'
    ],
    examWeightage: '14–18 Marks',
    commonICMITrap: 'Deducting unrealized inventory profit from Minority Interest during downstream sales.',
    lastTestedDate: '2026-08-14'
  },
  {
    id: 'diag_advacc_2',
    subjectId: 'i_advacc',
    subjectName: 'Advanced Accounting',
    topicName: 'Schedule III Company Financials',
    scorePct: 80,
    status: 'strong',
    testsAttempted: 4,
    aiIdentifiedProblem: 'Clean balance sheet presentation. Occasional omission of MSME ageing disclosure footnotes.',
    rootCauseCategory: 'ICAI Keyword Omission',
    aiActionPlan: [
      'Revise trade payables aging schedule bucket format (Not due, <1 yr, 1-2 yrs, 2-3 yrs, >3 yrs).'
    ],
    examWeightage: '10–14 Marks',
    commonICMITrap: 'Presenting proposed dividend as a liability on the balance sheet face instead of a contingent footnote.',
    lastTestedDate: '2026-08-07'
  },

  // Corporate & Other Laws (i_law)
  {
    id: 'diag_law_1',
    subjectId: 'i_law',
    subjectName: 'Corporate & Other Laws',
    topicName: 'General Clauses Act & Interpretation of Statutes',
    scorePct: 49,
    status: 'critical',
    testsAttempted: 4,
    aiIdentifiedProblem: 'You remember the general concept of statutory interpretation, but fail to cite specific Latin maxims (Noscitur a Sociis, Ejusdem Generis, Ut Res Magis Valeat Quam Pereat) required to score full marks in sub-parts.',
    rootCauseCategory: 'ICAI Keyword Omission',
    aiActionPlan: [
      'Create a flashcard deck for the 6 primary rules of interpretation with their exact Latin name, meaning, and landmark case scenario.',
      'Draft 2 case studies applying General Clauses Act Section 6 effect of repeal on pending legal proceedings.'
    ],
    examWeightage: '10–12 Marks',
    commonICMITrap: 'Giving purely subjective reasoning without quoting the statutory rule or section number.',
    lastTestedDate: '2026-08-12'
  }
];

export const INITIAL_STUDY_GROUPS: any[] = [
  {
    id: 'sg_1',
    name: 'CA Inter May 26 Both Groups Rankers',
    goal: 'Targeting 500+ Marks with 10-hour daily accountability logs',
    memberCount: 8,
    category: 'Both Groups',
    activeMembers: ['Rohan Sharma', 'Priya Verma', 'Aarav Mehta', 'Neha Agarwal', 'Siddharth Roy', 'Simran Kaur'],
    groupChat: [
      { id: 'm1', sender: 'Priya Verma', time: '08:30 AM', text: 'Good morning warriors! Target today: Completed AS 10 & AS 16 revision + 20 MCQs.' },
      { id: 'm2', sender: 'Rohan Sharma', time: '08:32 AM', text: 'Target for today: Income Tax Capital Gains section 54 exemptions + 15 practical sums!' },
      { id: 'm3', sender: 'Aarav Mehta', time: '11:45 AM', text: 'Completed 3 hours study block! Starting Audit SA 200 series now.' },
      { id: 'm4', sender: 'Neha Agarwal', time: '02:15 PM', text: 'Guys, check out the new AI Flashcards in our app for Law Section 139–148! Super helpful for quick recall.' }
    ]
  },
  {
    id: 'sg_2',
    name: 'Taxation & Audit Sprint Squad',
    goal: 'Exemption in Tax (DT/IDT) & Auditing with daily RTP solving',
    memberCount: 12,
    category: 'Subject Focus',
    activeMembers: ['Rohan Sharma', 'Karan Malhotra', 'Simran Kaur', 'Vikram Singh'],
    groupChat: [
      { id: 'm21', sender: 'Karan Malhotra', time: '09:00 AM', text: 'Who wants to discuss the GSTR-2B vs Purchase Register 2% tolerance rule?' },
      { id: 'm22', sender: 'Simran Kaur', time: '09:12 AM', text: 'Count me in! Posted a discussion thread on it in the forum as well.' }
    ]
  },
  {
    id: 'sg_3',
    name: 'Articleship Interview & Resume Prep Circle',
    goal: 'Preparing for Big 4, Top 10, & Industrial Training interviews',
    memberCount: 15,
    category: 'Career & Articleship',
    activeMembers: ['Siddharth Roy', 'Ananya Gupta', 'Rohan Sharma'],
    groupChat: [
      { id: 'm31', sender: 'Ananya Gupta', time: ' Yesterday', text: 'Tip for Big 4 Stat Audit interviews: Be thorough with CARO 2020 clauses and Ind AS 115 revenue recognition principles!' }
    ]
  }
];

export const INITIAL_MISTAKE_SUMMARY: MistakePatternSummary = {
  totalLoggedQuestions: 100,
  percentages: {
    conceptual: 31,              // 🟥 Conceptual errors — 31%
    questionInterpretation: 24,  // 🟨 Question interpretation — 24%
    memoryRecall: 21,            // 🟦 Memory/recall — 21%
    calculation: 12,             // 🟧 Calculation errors — 12%
    presentationTime: 12,        // 🟩 Presentation & Time — 12%
  },
  aiStrategicInsight: "Your marks can potentially improve faster by working on question interpretation rather than learning new chapters.",
  fastestImprovementLever: "24% of your marks loss is purely from misreading question constraints (e.g. 'excluding GST', 'non-resident assessee', 'individual vs firm cooling period'). Applying the 2-pass reading rule will immediately recover 16–22 marks across all 6 papers."
};

export const INITIAL_MISTAKE_LOGS: QuestionMistakeLog[] = [
  {
    id: 'mistake_1',
    questionText: 'Whether statutory auditor can accept direct appointment as internal auditor for the same company or its holding subsidiary under Section 144?',
    subjectName: 'Auditing & Ethics',
    chapterTitle: 'Company Audit & Audit Report',
    topicName: 'Section 144 Restricted Services',
    selectedReason: 'misread_question',
    userNote: 'Missed that the question asked about holding company, thought it was only about the subsidiary company.',
    correctAnswerSummary: 'Section 144 prohibits internal audit services directly or indirectly to the company, holding company, or subsidiary company.',
    aiTip: 'Underline key organizational entities (holding/subsidiary/associate) in the second line of the problem before framing the conclusion.',
    date: '2026-08-14',
    sourceType: 'Mock Test'
  },
  {
    id: 'mistake_2',
    questionText: 'Compute Input Tax Credit eligibility for motor vehicles purchased by an IT consulting company for employee travel with 7-passenger capacity.',
    subjectName: 'Taxation (DT & IDT)',
    chapterTitle: 'Input Tax Credit',
    topicName: 'Sec 17(5)(a) Blocked Credits',
    selectedReason: 'concept_gap',
    userNote: 'Thought employee travel qualified as business purpose so ITC would be allowed.',
    correctAnswerSummary: 'Under Sec 17(5)(a), motor vehicles for transportation of persons having approved seating capacity <= 13 persons are blocked unless used for supply of vehicles, passenger transportation service, or driving school.',
    aiTip: 'Business use alone does NOT override Sec 17(5) statutory blocked items unless one of the 3 specified business exceptions is present.',
    date: '2026-08-13',
    sourceType: 'Chapter Test'
  },
  {
    id: 'mistake_3',
    questionText: 'Calculation of standard deduction under Section 16(ia) and employer contribution to NPS under Section 80CCD(2) for AY 2025-26 under new regime.',
    subjectName: 'Taxation (DT & IDT)',
    chapterTitle: 'Salary Income & Deductions',
    topicName: 'Sec 115BAC New Tax Regime',
    selectedReason: 'forgot_provision',
    userNote: 'Applied old standard deduction of ₹50,000 instead of updated ₹75,000 amendment.',
    correctAnswerSummary: 'Budget amendment increased standard deduction to ₹75,000 under Section 115BAC(1A).',
    aiTip: 'Keep an amendment change sheet beside your desk. Test papers explicitly check the revised numbers.',
    date: '2026-08-12',
    sourceType: 'RTP/MTP'
  },
  {
    id: 'mistake_4',
    questionText: 'Consolidated balance sheet: elimination of upstream unrealized profit on closing inventory held by parent company.',
    subjectName: 'Advanced Accounting',
    chapterTitle: 'Consolidated Financial Statements',
    topicName: 'AS 21 Upstream Stock Reserve',
    selectedReason: 'calculation_mistake',
    userNote: 'Accidentally deducted 100% of the unrealized profit from holding company instead of apportioning between Holding and NCI.',
    correctAnswerSummary: 'In upstream sales (subsidiary to parent), unrealized profit must be allocated between Holding (via P&L) and Minority Interest in profit sharing ratio.',
    aiTip: 'Write down (Upstream = Split between Holding & NCI) vs (Downstream = 100% from Holding P&L) before computing line items.',
    date: '2026-08-11',
    sourceType: 'Self Practice'
  },
  {
    id: 'mistake_5',
    questionText: 'Under SA 315, what are the mandatory 5 components of Internal Control an auditor must evaluate?',
    subjectName: 'Auditing & Ethics',
    chapterTitle: 'Risk Assessment & Internal Control',
    topicName: 'SA 315 Components of Internal Control',
    selectedReason: 'poor_presentation',
    userNote: 'Wrote general explanations in paragraph form without listing the 5 official subheadings.',
    correctAnswerSummary: 'Must list: (1) Control Environment, (2) Risk Assessment Process, (3) Information System, (4) Control Activities, (5) Monitoring of Controls.',
    aiTip: 'ICAI examiners award marks on exact sub-clause headings. Always use bulleted bold headings before explaining.',
    date: '2026-08-10',
    sourceType: 'Mock Test'
  },
  {
    id: 'mistake_6',
    questionText: 'Filing of form DPT-3: Whether loan received from director relative is considered as deposit or exempted deposit under Companies Act 2013?',
    subjectName: 'Corporate & Other Laws',
    chapterTitle: 'Acceptance of Deposits by Companies',
    topicName: 'Sec 73 & Deposit Rules',
    selectedReason: 'misread_question',
    userNote: 'Did not notice the company was a Public Limited Company where relative of director exemption is NOT available.',
    correctAnswerSummary: 'Exemption for loan from relative of director is available ONLY to Private Companies, not Public Companies.',
    aiTip: 'First step in company law case studies: Circle whether the entity is a PRIVATE or PUBLIC company.',
    date: '2026-08-09',
    sourceType: 'Chapter Test'
  },
  {
    id: 'mistake_7',
    questionText: 'Compute direct material yield variance and mix variance from given standard and actual input tables.',
    subjectName: 'Cost & Management Accounting',
    chapterTitle: 'Standard Costing',
    topicName: 'Material Mix & Yield Variances',
    selectedReason: 'time_pressure',
    userNote: 'Ran out of time in the last 15 minutes of the mock and rushed the revised standard quantity (RSQ) formula.',
    correctAnswerSummary: 'RSQ = (Standard quantity of individual material / Total standard quantity) * Total actual quantity.',
    aiTip: 'For standard costing sums, pre-draw the 4-column master table format immediately to prevent panic math.',
    date: '2026-08-08',
    sourceType: 'Mock Test'
  },
  {
    id: 'mistake_8',
    questionText: 'What is the effect of repeal on legal proceedings under Section 6 of the General Clauses Act 1897?',
    subjectName: 'Corporate & Other Laws',
    chapterTitle: 'Interpretation of Statutes & General Clauses',
    topicName: 'Sec 6 Effect of Repeal',
    selectedReason: 'concept_gap',
    userNote: 'Assumed pending investigations automatically collapse once a statute is repealed.',
    correctAnswerSummary: 'Unless different intention appears, repeal does not affect any investigation, legal proceeding, or remedy in respect of any right, privilege, obligation, liability, penalty acquired or incurred under repealed Act.',
    aiTip: 'Section 6 General Clauses Act preserves existing vested rights unless the new Act contains an express contrary repeal clause.',
    date: '2026-08-07',
    sourceType: 'AI Quiz'
  }
];

export const INITIAL_ANSWER_EVALUATIONS: AnswerWritingEvaluation[] = [
  {
    id: 'eval_1',
    subjectName: 'Advanced Auditing & Professional Ethics (CA Final)',
    questionText: 'M/s Bright Star Ltd. is an unlisted public company with paid-up share capital of ₹12 Crore and turnover of ₹180 Crore. CA Anish was statutory auditor for 6 continuous years. The board proposes to appoint CA Bharat, who is a partner in the same audit firm as CA Anish, as statutory auditor for the upcoming AGM. Analyze whether such appointment is valid under Companies Act 2013.',
    studentAnswer: 'CA Bharat cannot be appointed because CA Anish was already auditor for 6 years. Under rotation rules, once an auditor finishes their term of 5 years or 10 years, they have a cooling period of 5 years. Also Bharat is a partner in the same firm, so cooling period applies to him as well. Therefore the appointment proposed by Bright Star Ltd is invalid.',
    marksEstimated: {
      awarded: 2.5,
      total: 5
    },
    ratings: {
      structure: 4,          // ⭐⭐⭐⭐
      technicalContent: 3,   // ⭐⭐⭐
      application: 3,        // ⭐⭐⭐
      conclusion: 4,         // ⭐⭐⭐⭐
      presentation: 3        // ⭐⭐⭐
    },
    diagnostics: {
      missingKeywords: [
        'Applicability thresholds under Rule 5 of Companies (Audit & Auditors) Rules 2014',
        'Unlisted public company threshold (Paid-up capital >= ₹10 Crore or Turnover >= ₹100 Crore)',
        'Common Partner / Same Network Firm clause',
        'Section 139(2) statutory mandatory rotation'
      ],
      missingProvisions: [
        'Section 139(2) of Companies Act 2013',
        'Rule 5 of Companies (Audit and Auditors) Rules, 2014',
        'Explanation to Section 139(2)'
      ],
      poorStructureNotes: 'Answer lacks distinct bold subheadings. The statutory eligibility threshold was completely skipped before jumping to the conclusion.',
      unnecessaryContentNotes: 'Mentioned "5 years or 10 years" vaguely without clarifying individual vs audit firm tenure distinctions.',
      missingConclusionNotes: 'Conclusion is correct in outcome but lacks statutory authority citation.',
      lackOfCaseApplicationNotes: 'Did not mathematically test whether Bright Star Ltd (₹12 Cr Capital / ₹180 Cr Turnover) meets the Rule 5 applicability criteria.'
    },
    betterAnswerStructure: {
      issue: 'Whether the proposed appointment of CA Bharat as statutory auditor of M/s Bright Star Ltd is valid under Section 139(2) of the Companies Act, 2013 considering rotation and cooling period provisions.',
      provision: 'As per Section 139(2) read with Rule 5 of Companies (Audit and Auditors) Rules 2014, mandatory rotation applies to unlisted public companies having paid-up share capital >= ₹10 Crore OR turnover >= ₹100 Crore. Furthermore, as per the Explanation to Section 139(2), as on the date of appointment, no audit firm shall be appointed for 5 years from completion of tenure if it has common partner(s) with the retiring auditor firm.',
      application: 'In the present case, Bright Star Ltd has paid-up share capital of ₹12 Crore (>= ₹10 Cr) and turnover of ₹180 Crore (>= ₹100 Cr), thereby attracting mandatory rotation under Section 139(2). Since CA Bharat is a partner in the same audit firm where CA Anish served for 6 years, CA Bharat is ineligible due to the statutory 5-year cooling period applying to common partners/same firm.',
      conclusion: 'Therefore, the proposed appointment of CA Bharat as statutory auditor of M/s Bright Star Ltd at the upcoming AGM is invalid in law.'
    },
    rankerExaminerRemarks: 'Always follow the 4-tier Issue → Provision → Application → Conclusion architecture. You lost 2.5 marks because you skipped testing the Rule 5 applicability limits (₹10 Cr Capital / ₹100 Cr Turnover).',
    createdAt: '2026-08-14'
  }
];

export const SAMPLE_ANSWER_PROMPTS = [
  {
    id: 'sample_audit',
    subject: 'Advanced Auditing & Professional Ethics',
    title: 'Section 139(2) Rotation & Common Partner Disqualification',
    question: 'M/s Bright Star Ltd. is an unlisted public company with paid-up share capital of ₹12 Crore and turnover of ₹180 Crore. CA Anish was statutory auditor for 6 continuous years. The board proposes to appoint CA Bharat, who is a partner in the same audit firm as CA Anish, as statutory auditor for the upcoming AGM. Analyze whether such appointment is valid under Companies Act 2013.',
    studentDraft: 'CA Bharat cannot be appointed because CA Anish was already auditor for 6 years. Under rotation rules, once an auditor finishes their term of 5 years or 10 years, they have a cooling period of 5 years. Also Bharat is a partner in the same firm, so cooling period applies to him as well. Therefore the appointment proposed by Bright Star Ltd is invalid.'
  },
  {
    id: 'sample_tax',
    subject: 'Direct Tax Laws & International Taxation',
    title: 'Section 40(a)(ia) Non-Deduction of TDS on Subcontractor Charges',
    question: 'XYZ Ltd paid ₹15,00,000 towards contractor charges on 15-01-2025 without deducting TDS under Section 194C. The company deducted TDS on 20-05-2025 and deposited it with the government on 10-07-2025 before filing its return of income under Section 139(1). Discuss the disallowance under Section 40(a)(ia) for AY 2025-26.',
    studentDraft: 'Since the company deposited the TDS before the due date of filing return under Section 139(1), no disallowance will be made in AY 2025-26. 30% of expense is disallowed if not paid. Here it was paid on 10th July so full ₹15,00,000 is allowed as deduction.'
  },
  {
    id: 'sample_law',
    subject: 'Corporate & Economic Laws',
    title: 'Section 185 Loans to Entities in which Directors are Interested',
    question: 'Apex Pharma Ltd wishes to provide a corporate guarantee of ₹5 Crore to a bank for a credit facility extended to Zen Healthcare Pvt Ltd. Director Mr. Mehta of Apex Pharma holds 28% voting power in Zen Healthcare Pvt Ltd. Can Apex Pharma Ltd provide this guarantee?',
    studentDraft: 'Under Section 185, companies cannot give loans or guarantees to private companies where directors are interested. Here Mr. Mehta has 28% shares which is more than 25%, so the guarantee cannot be given without special resolution. If special resolution is passed and loan is used for principal business, it might be allowed.'
  }
];

export const INITIAL_EXAMINER_QUESTIONS: ExaminerQuestion[] = [
  {
    id: 'exam_sa315_audit',
    subject: 'Audit',
    topic: 'SA 315',
    difficulty: 'ICAI exam level',
    marks: 10,
    timeLimitMinutes: 15,
    questionTitle: 'Risk Assessment & Automated Control Deficiencies under SA 315',
    questionText: `CA Samarth is the statutory auditor of Zenith Retail Logistics Ltd for FY 2024-25. The company recently transitioned to an integrated automated ERP warehouse management system. During his preliminary evaluation, CA Samarth observed that:\n\n1. Warehouse dispatch logs are auto-generated without secondary supervisory sign-off.\n2. Access rights for inventory adjustments above ₹5,00,000 were assigned to three branch accountants without dual authentication.\n3. The internal auditor's report highlighted frequent manual overrides during month-end inventory reconciliations.\n\nIn light of SA 315 (Revised) "Identifying and Assessing the Risks of Material Misstatement", guide CA Samarth on how he should identify and assess the Risks of Material Misstatement (RoMM) at both the Financial Statement level and Assertion level. Also explain the auditor's responsibility regarding General IT Controls (GITCs) and Automated Application Controls.`,
    sampleStudentDraft: `CA Samarth should check the internal controls of the company. Under SA 315, auditor must understand the entity and its environment. Since ERP system is implemented, auditor should check IT controls. If warehouse dispatch logs have no sign-off, it is a big risk. Branch accountants having access above ₹5,00,000 without dual approval increases risk of fraud. The auditor should inform the audit committee and do detailed substantive testing of inventory balances.`,
    sourceContext: 'Patterned after ICAI CA Final Advanced Auditing (May 2024/Nov 2024 Exam Standard)'
  },
  {
    id: 'exam_dt_115bac',
    subject: 'Direct Tax',
    topic: 'Section 115BAC vs Normal Provisions',
    difficulty: 'ICAI exam level',
    marks: 10,
    timeLimitMinutes: 15,
    questionTitle: 'Concessional Tax Regime & Foregone Deductions under Section 115BAC',
    questionText: `Mr. Rajesh (aged 48 years), a resident individual carrying on professional consultancy, reports gross professional receipts of ₹62,00,000 (presumptive income u/s 44ADA computed at 50%). During FY 2024-25, he incurred interest on housing loan of ₹2,20,000 for a self-occupied property, paid health insurance premium of ₹32,000 for self, and made PPF contribution of ₹1,50,000. He also has agricultural income of ₹90,000.\n\nAdvise Mr. Rajesh whether he should opt for Section 115BAC default regime or exercise the option to be taxed under old normal provisions for AY 2025-26. Support your answer with full computation of total income and tax liability under both options (including cess and rebate u/s 87A if applicable).`,
    sampleStudentDraft: `Under Section 115BAC, deductions under Section 80C and 80D and self-occupied housing loan interest are not allowed. Presumptive income under 44ADA is ₹31,00,000. Under normal provisions, deductions of ₹1,50,000 (80C), ₹25,000 (80D), and ₹2,00,000 (housing loan interest) can be claimed. Tax under new regime will have revised slab rates with lower rates up to ₹15 Lakhs. Since income is above ₹15 Lakhs, new regime usually saves tax unless heavy deductions exist. Agricultural income is added for rate purposes.`,
    sourceContext: 'ICAI Direct Tax Laws & International Taxation Exam Level'
  },
  {
    id: 'exam_indas_115',
    subject: 'Financial Reporting',
    topic: 'Ind AS 115 Revenue with Variable Consideration',
    difficulty: 'ICAI exam level',
    marks: 10,
    timeLimitMinutes: 15,
    questionTitle: '5-Step Revenue Model & Volume Rebate Constraints under Ind AS 115',
    questionText: `Nova Dynamics Ltd enters into a contract on 01-04-2024 to sell 1,000 units of custom industrial equipment to a customer for ₹12,000 per unit. Under the terms, if the customer purchases more than 800 units in the financial year, the price per unit is retrospectively reduced to ₹10,500 for all units sold.\n\nDuring Q1 (ended 30-06-2024), Nova Dynamics delivered 250 units. Based on historical trends, Nova initially estimates that total annual purchases will not exceed 800 units. However, in Q2, due to surging customer demand, Nova delivers an additional 350 units (cumulative 600 units) and reassesses that total annual sales will exceed 800 units (expected 950 units).\n\nPass necessary journal entries and explain revenue recognition for Q1 and Q2 under Ind AS 115, clearly discussing the "Variable Consideration Constraint" rule.`,
    sampleStudentDraft: `In Q1, 250 units are sold at ₹12,000 each because Nova expects customer won't cross 800 units. So revenue is ₹30,00,000. In Q2, additional 350 units are sold. Now Nova expects total purchases will exceed 800 units, so price is ₹10,500. Nova must give retrospective discount for Q1 units as well. In Q2 revenue will be calculated on 350 units plus adjustment for 250 units.`,
    sourceContext: 'ICAI CA Final Financial Reporting Standard'
  }
];

export const INITIAL_EXAMINER_EVALUATION: ExaminerEvaluationResult = {
  id: 'eval_sa315_initial',
  question: INITIAL_EXAMINER_QUESTIONS[0],
  studentAnswer: INITIAL_EXAMINER_QUESTIONS[0].sampleStudentDraft || '',
  timeSpentSeconds: 480,
  scores: {
    concept: 8,              // Concept: 8/10
    application: 5,          // Application: 5/10
    relevantProvisions: 7,   // Relevant provisions: 7/10
    presentation: 6,         // Presentation: 6/10
    conclusion: 8            // Conclusion: 8/10
  },
  estimatedMarks: {
    awarded: 6.5,
    total: 10,
    lostMarks: 3.5
  },
  whatYouShouldHaveWritten: {
    fullModelAnswer: `**1. IDENTIFICATION AND ASSESSMENT OF RoMM UNDER SA 315 (REVISED)**
Under SA 315 (Revised), the auditor is required to identify and assess Risks of Material Misstatement (RoMM) at two distinct levels:

*(a) At the Financial Statement Level (Pervasive Risk):*
- Frequent manual overrides during month-end inventory reconciliations create an entity-wide pervasive risk of fraudulent financial reporting or management bias. This directly impacts the integrity of the overall financial statements.

*(b) At the Assertion Level:*
- **Valuation & Allocation / Accuracy:** Lack of dual-authorization on inventory adjustments exceeding ₹5,00,000 creates high susceptibility to intentional inventory inflation or unrecorded write-offs.
- **Completeness & Occurrence / Cut-off:** Auto-generation of dispatch logs without supervisory sign-off exposes revenue and inventory dispatches to fictitious or prematurely recognized transactions.

---

**2. AUDITOR'S EVALUATION OF IT CONTROLS**

*(a) General IT Controls (GITCs):*
- **User Access Management:** Auditor must evaluate Segregation of Duties (SoD) and privileged access rights given to branch accountants without dual controls.
- **Change Management & Program Overrides:** Assess audit logging mechanisms for manual overrides.

*(b) Automated Application Controls:*
- Evaluate input validation checks, automated numerical sequence controls for dispatch notes, and automated tolerances for inventory adjustments.

---

**3. AUDITOR'S PROCEDURAL RESPONSE (SA 330)**
- Perform walkthroughs of ERP automated workflows and test the operating effectiveness of GITCs.
- If GITCs are found deficient, the auditor cannot rely on automated application controls and must perform extensive substantive procedures, including 100% verification of manual journal entries and surprise physical stock counts.`,
    statutoryHighlights: [
      'SA 315 (Revised) - Assessment of RoMM at Financial Statement vs Assertion Level',
      'General IT Controls (GITCs) - User Access, Program Changes, Operations',
      'Automated Application Controls - Input, Processing, and Output validations',
      'SA 240 / SA 330 - Audit response to management override of controls'
    ],
    crucialWorkingNotes: [
      'Note 1: Categorizing risks into Financial Statement Level (Pervasive) vs Assertion Level (Specific) carries 3 mandatory marks in the ICAI marking scheme.',
      'Note 2: Distinguishing GITCs from Application Controls is explicitly tested under the revised syllabus.'
    ]
  },
  whyYouLostMarks: {
    summary: 'You lost 3.5 marks because you failed to explicitly segregate RoMM into Financial Statement Level vs Assertion Level, and omitted the technical distinction between GITCs and Automated Application Controls.',
    deductions: [
      {
        pointsDeducted: 1.5,
        reason: 'Omitted explicit classification of RoMM into Financial Statement Level vs Assertion Level',
        flawType: 'Concept',
        examinerComment: 'SA 315 mandates a two-tier risk classification. You lumped all risks into general observation without identifying specific assertions (Valuation, Cut-off, Occurrence).'
      },
      {
        pointsDeducted: 1.0,
        reason: 'Did not distinguish between GITCs (General IT Controls) and Automated Application Controls',
        flawType: 'Relevant Provisions',
        examinerComment: 'The question specifically tested IT controls. You only mentioned generic "IT controls" without citing User Access, Change Management, and Application Tolerances.'
      },
      {
        pointsDeducted: 1.0,
        reason: 'Lack of specific audit response to ₹5,00,000 threshold overrides',
        flawType: 'Application',
        examinerComment: 'You suggested informing the audit committee but missed the primary procedural step: performing extensive substantive audit testing of ERP journal overrides under SA 330/SA 240.'
      }
    ]
  },
  examinerVerdict: 'Good conceptual understanding of auditing risks (Score: 6.5/10), but technical presentation and structured assertion mapping are required to secure an Exemption (8.5+ range).',
  createdAt: '2026-08-15'
};

export const INITIAL_DAILY_BRIEFING: AIDailyBriefing = {
  id: 'briefing_today',
  greeting: 'Good Morning, Rahul',
  studentName: 'Rahul',
  readinessPercentage: 72,
  yesterdayDeltaPct: 2.0,
  dateString: new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' }),
  priorities: [
    {
      id: 'prio_1',
      iconType: 'critical',
      title: 'Audit — SA 315',
      subject: 'Audit',
      topic: 'SA 315',
      detail: 'Identifying & Assessing Risks of Material Misstatement + IT Controls',
      estimatedMins: 90,
      completed: false,
      actionView: 'ai-examiner',
      actionLabel: 'Launch SA 315 Examiner Case'
    },
    {
      id: 'prio_2',
      iconType: 'critical',
      title: 'Tax — ITC',
      subject: 'Direct & Indirect Tax',
      topic: 'Input Tax Credit (Sec 16, 17(5))',
      detail: 'Eligibility, Conditions & Blocked Credits computation drill',
      estimatedMins: 60,
      completed: false,
      actionView: 'academic-tracker',
      actionLabel: 'Solve ITC Practice Set'
    },
    {
      id: 'prio_3',
      iconType: 'high',
      title: 'FR — Ind AS 116',
      subject: 'Financial Reporting',
      topic: 'Ind AS 116 Leases',
      detail: 'Right-of-Use (ROU) Asset, Lease Liability & Remeasurements',
      estimatedMins: 45,
      completed: false,
      actionView: 'answer-coach',
      actionLabel: 'Practice Ind AS 116 Descriptive Answer'
    },
    {
      id: 'prio_4',
      iconType: 'revision',
      title: 'Revise yesterday\'s mistakes',
      subject: 'All Subjects',
      topic: 'Error Ledger & Trap Concepts',
      detail: 'Review 8 tagged mistakes from yesterday\'s test drill',
      estimatedMins: 20,
      completed: false,
      actionView: 'mistake-intelligence',
      actionLabel: 'Open Mistake Intelligence'
    },
    {
      id: 'prio_5',
      iconType: 'practice',
      title: 'Attempt 25 PYQs',
      subject: 'Past Exams & RTP',
      topic: 'ICAI Exam Standard PYQs',
      detail: 'Timed 25 questions under ICAI examination conditions',
      estimatedMins: 45,
      completed: false,
      actionView: 'academic-tracker',
      actionLabel: 'Start 25 PYQs Timer'
    }
  ],
  aiCoachQuote: 'You are progressing well, but Audit is becoming your biggest risk. Spend at least 90 minutes on SA 315 today.',
  targetHoursToday: 6.5,
  streakDays: 14,
  daysToExam: 259,
  criticalAlert: 'Audit SA accuracy dropped to 54% in last 3 tests. Prioritize 90 mins on SA 315.'
};



