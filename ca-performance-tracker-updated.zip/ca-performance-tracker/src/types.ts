export type CourseLevel = 'Foundation' | 'Intermediate' | 'Final';

export type ArticleshipStatus = 'Not Started' | 'Ongoing' | 'Completed' | 'Exempted';

export interface ICAIStudentProfile {
  registrationNumber: string;
  name: string;
  email: string;
  mobile: string;
  course: CourseLevel;
  attempt: string; // e.g., "May 2026" or "Nov 2026"
  articleshipStatus: ArticleshipStatus;
  city: string;
  verified: boolean;
  registrationDate: string;
  validityUntil: string;
  photoUrl: string;
  xpPoints: number;
  levelNumber: number;
  streakDays: number;
  lastStudyDate: string;
  targetExamDate: string; // YYYY-MM-DD
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  course: CourseLevel;
  group?: number; // 1 or 2 for Inter/Final
  totalChapters: number;
  recommendedHours: number;
  icaiWeightageMarks: number;
}

export type ChapterStatus = 'Not Started' | 'Started' | 'Revision 1' | 'Revision 2' | 'Completed' | 'Mastered';

export interface Chapter {
  id: string;
  subjectId: string;
  title: string;
  chapterNo: number;
  status: ChapterStatus;
  completionPct: number;
  questionsSolved: number;
  timeSpentMins: number;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Extreme';
  notes?: string;
  lastStudied?: string;
}

export type TestType = 
  | 'Mock Test' 
  | 'RTP' 
  | 'MTP' 
  | 'Past Paper' 
  | 'Coaching Test' 
  | 'ICAI Unit Test' 
  | 'Internal Test';

export interface TestRecord {
  id: string;
  subjectId: string;
  testType: TestType;
  title: string;
  date: string;
  maxMarks: number;
  marksObtained: number;
  attemptNumber: number;
  difficultyLevel: 'Easy' | 'Moderate' | 'Challenging' | 'ICAI Standard';
  timeTakenMins: number;
  remarks: string;
}

export type SessionCategory = 'Reading' | 'Question Practice' | 'Revision' | 'Mock Test' | 'MCQs';

export interface StudySession {
  id: string;
  subjectId: string;
  chapterId?: string;
  category: SessionCategory;
  startTime: string;
  durationMins: number;
  focusScore: number; // 0 - 100
  notes?: string;
}

export interface Goal {
  id: string;
  title: string;
  subjectId?: string;
  targetDate: string;
  completed: boolean;
  category: 'Daily' | 'Weekly' | 'Syllabus';
  progressPct: number;
}

export interface ScheduleItem {
  time: string;
  activity: string;
  subject: string;
  duration: string;
  completed?: boolean;
}

export interface AICoachAnalysis {
  dailyAdvice: string;
  weeklyStrategy: string;
  examStrategy: string;
  motivationalQuote: string;
  passProbability: number; // 0 - 100
  expectedMarksRange: string;
  weakSubjectIds: string[];
  recommendedTopics: string[];
  suggestedSchedule: ScheduleItem[];
  confidenceScore: number;
  riskAreas: string[];
}

export interface DoubtQuestion {
  id: string;
  studentName: string;
  course: CourseLevel;
  subject: string;
  chapter: string;
  question: string;
  aiAnswer?: string;
  upvotes: number;
  createdAt: string;
  resolved: boolean;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface ICAIResource {
  id: string;
  title: string;
  category: 'Study Material' | 'BOS Portal' | 'RTP' | 'MTP' | 'Past Papers' | 'Announcements' | 'Student Journal';
  course: CourseLevel | 'All';
  url: string;
  description: string;
}

export type FlashcardDifficulty = 'Easy' | 'Medium' | 'Hard';
export type FlashcardStatus = 'New' | 'Learning' | 'Mastered';

export interface Flashcard {
  id: string;
  chapterId: string;
  subjectId: string;
  question: string;
  answer: string;
  hint?: string;
  difficulty: FlashcardDifficulty;
  lastReviewed?: string;
  reviewCount: number;
  status: FlashcardStatus;
  tags?: string[];
  createdFromNotes?: boolean;
}

export type DiscussionCategory = 
  | 'Burnout & Focus' 
  | 'Backlogs & Timetable' 
  | 'Articleship & Career' 
  | 'Subject Concepts' 
  | 'Exam Strategy' 
  | 'Study Partners';

export interface DiscussionComment {
  id: string;
  authorName: string;
  authorBadge?: string;
  content: string;
  createdAt: string;
  upvotes: number;
  isAiAdvisor?: boolean;
  isVerifiedRanker?: boolean;
}

export interface ProblemDiscussion {
  id: string;
  title: string;
  category: DiscussionCategory;
  authorName: string;
  course: CourseLevel;
  problemStatement: string;
  createdAt: string;
  comments: DiscussionComment[];
  upvotes: number;
  tags: string[];
  isSolved?: boolean;
  aiAdvisorSummary?: string;
}

export interface StudyGroup {
  id: string;
  name: string;
  goal: string;
  memberCount: number;
  category: string;
  activeMembers: string[];
  groupChat: {
    id: string;
    sender: string;
    time: string;
    text: string;
  }[];
}

export interface DailyAITask {
  id: string;
  timeSlot: string; // e.g. "2:00–3:30 PM"
  subjectName: string; // e.g. "Audit"
  subjectCode?: string;
  topic: string; // e.g. "SA 315"
  taskType: 'concept' | 'practice' | 'revision' | 'test' | 'mcq';
  taskIcon?: string; // e.g. '📖', '🎯', '🔁', '📝'
  reason: string; // e.g. "Your last 3 tests show 54% accuracy." or "High exam importance + low retention score."
  detailedWhy: string; // Deep diagnostic reasoning explaining why the AI selected this specific task and time block
  metricHighlight?: string; // e.g. "Accuracy: 54%", "Weightage: 18 Marks", "Weakness Alert"
  priority: 'High' | 'Critical' | 'Medium';
  durationMins: number;
  isCompleted?: boolean;
}

export interface DailyAIPlan {
  date: string;
  overallStrategy: string;
  totalPlannedHours: string;
  focusSubject: string;
  diagnosticSummary: string;
  tasks: DailyAITask[];
}

export interface TopicWeaknessDiagnostic {
  id: string;
  subjectId: string;
  subjectName: string;
  topicName: string;
  scorePct: number; // e.g. 48, 82, 76, 54, 68
  status: 'critical' | 'moderate' | 'strong'; // 🔴 <50%, 🟠 50-74%, 🟢 75%+
  testsAttempted: number;
  aiIdentifiedProblem: string; // e.g. "You are losing marks primarily because you identify the correct auditing standard but fail to apply it to the case."
  rootCauseCategory: 'Application Deficit' | 'Provision Clause Precision' | 'Calculation Speed' | 'ICAI Keyword Omission' | 'Conceptual Gap';
  aiActionPlan: string[];
  examWeightage: string;
  commonICMITrap?: string;
  lastTestedDate?: string;
}

export type MistakeReasonType = 
  | 'concept_gap'            // ❌ Didn't know concept (Conceptual errors)
  | 'misread_question'       // ❌ Misread question (Question interpretation)
  | 'calculation_mistake'    // ❌ Calculation mistake (Calculation errors)
  | 'forgot_provision'       // ❌ Forgot provision (Memory/recall)
  | 'time_pressure'          // ❌ Time pressure (Exam speed & pacing)
  | 'poor_presentation'      // ❌ Poor presentation (ICAI formatting)
  | 'guess';                 // ❌ Guess (Uncertain attempt)

export interface QuestionMistakeLog {
  id: string;
  questionText: string;
  subjectName: string;
  subjectId?: string;
  chapterTitle?: string;
  topicName: string;
  selectedReason: MistakeReasonType;
  userNote?: string;
  correctAnswerSummary?: string;
  aiTip: string;
  date: string;
  sourceType: 'Mock Test' | 'Chapter Test' | 'RTP/MTP' | 'AI Quiz' | 'Self Practice';
  resolved?: boolean;
}

export interface MistakePatternSummary {
  totalLoggedQuestions: number;
  percentages: {
    conceptual: number;      // 31%
    questionInterpretation: number; // 24%
    memoryRecall: number;    // 21%
    calculation: number;     // 12%
    presentationTime: number; // 12%
  };
  aiStrategicInsight: string;
  fastestImprovementLever: string;
}

export interface AnswerWritingEvaluation {
  id: string;
  subjectName: string;
  questionText: string;
  studentAnswer: string;
  marksEstimated: {
    awarded: number;
    total: number;
  };
  ratings: {
    structure: number;        // 1 to 5 (e.g. ⭐⭐⭐⭐)
    technicalContent: number; // 1 to 5 (e.g. ⭐⭐⭐)
    application: number;      // 1 to 5 (e.g. ⭐⭐⭐)
    conclusion: number;       // 1 to 5 (e.g. ⭐⭐⭐⭐)
    presentation: number;     // 1 to 5 (e.g. ⭐⭐⭐)
  };
  diagnostics: {
    missingKeywords: string[];
    missingProvisions: string[];
    poorStructureNotes?: string;
    unnecessaryContentNotes?: string;
    missingConclusionNotes?: string;
    lackOfCaseApplicationNotes?: string;
  };
  betterAnswerStructure: {
    issue: string;            // Core legal / auditing question
    provision: string;        // Applicable Section / SA / Ind AS
    application: string;      // Facts linked to law
    conclusion: string;       // Direct authoritative verdict
  };
  rankerExaminerRemarks: string;
  createdAt: string;
}

export interface ExaminerQuestion {
  id: string;
  subject: string;
  topic: string;
  difficulty: 'ICAI exam level' | 'RTP / MTP Level' | 'AIR Ranker Tough Level';
  marks: number;
  timeLimitMinutes: number;
  questionTitle: string;
  questionText: string;
  sampleStudentDraft?: string;
  sourceContext?: string;
}

export interface ExaminerLostMarkReason {
  pointsDeducted: number;
  reason: string;
  flawType: 'Concept' | 'Application' | 'Relevant Provisions' | 'Presentation' | 'Conclusion';
  examinerComment: string;
}

export interface ExaminerEvaluationResult {
  id: string;
  question: ExaminerQuestion;
  studentAnswer: string;
  timeSpentSeconds: number;
  scores: {
    concept: number;           // out of 10
    application: number;       // out of 10
    relevantProvisions: number;// out of 10
    presentation: number;      // out of 10
    conclusion: number;        // out of 10
  };
  estimatedMarks: {
    awarded: number;           // e.g. 6.5
    total: number;             // e.g. 10
    lostMarks: number;         // e.g. 3.5
  };
  whatYouShouldHaveWritten: {
    fullModelAnswer: string;
    statutoryHighlights: string[];
    crucialWorkingNotes?: string[];
  };
  whyYouLostMarks: {
    summary: string;
    deductions: ExaminerLostMarkReason[];
  };
  examinerVerdict: string;
  createdAt: string;
}

export interface BriefingPriorityItem {
  id: string;
  iconType: 'critical' | 'high' | 'medium' | 'revision' | 'practice'; // 🔴, 🟠, 🔄, 📝
  title: string;          // e.g. "Audit — SA 315"
  subject: string;        // e.g. "Audit"
  topic: string;          // e.g. "SA 315"
  detail: string;         // e.g. "Identifying and Assessing Risks of Material Misstatement"
  estimatedMins: number;  // e.g. 90
  completed: boolean;
  actionView?: string;    // e.g. 'ai-examiner' | 'answer-coach' | 'mistake-intelligence' | 'academic-tracker'
  actionLabel?: string;   // e.g. 'Launch SA 315 Examiner Drill'
}

export interface AIDailyBriefing {
  id: string;
  greeting: string;             // "Good Morning, Rahul"
  studentName: string;          // "Rahul"
  readinessPercentage: number;  // 72
  yesterdayDeltaPct: number;    // +2.0
  dateString: string;
  priorities: BriefingPriorityItem[];
  aiCoachQuote: string;         // "You are progressing well, but Audit is becoming your biggest risk. Spend at least 90 minutes on SA 315 today."
  targetHoursToday: number;
  streakDays: number;
  daysToExam: number;
  criticalAlert?: string;
}




