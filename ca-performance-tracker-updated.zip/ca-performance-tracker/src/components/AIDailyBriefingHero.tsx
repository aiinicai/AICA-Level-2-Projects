import React, { useState } from 'react';
import {
  Sun,
  Target,
  TrendingUp,
  Flame,
  CheckCircle2,
  Circle,
  Clock,
  ArrowRight,
  Sparkles,
  Volume2,
  VolumeX,
  BrainCircuit,
  ChevronRight,
  Maximize2,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { AIDailyBriefing, ICAIStudentProfile } from '../types';

interface AIDailyBriefingHeroProps {
  briefing: AIDailyBriefing;
  profile: ICAIStudentProfile;
  onNavigate: (view: string) => void;
  onTogglePriority: (id: string) => void;
  onOpenModal: () => void;
  onRefreshBriefing: () => void;
  isRefreshing?: boolean;
  isDarkMode: boolean;
}

export const AIDailyBriefingHero: React.FC<AIDailyBriefingHeroProps> = ({
  briefing,
  profile,
  onNavigate,
  onTogglePriority,
  onOpenModal,
  onRefreshBriefing,
  isRefreshing = false,
  isDarkMode,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const handleSpeakBriefing = () => {
    if ('speechSynthesis' in window) {
      if (isPlayingAudio) {
        window.speechSynthesis.cancel();
        setIsPlayingAudio(false);
        return;
      }

      const text = `${briefing.greeting}. Your preparation readiness is ${briefing.readinessPercentage} percent, up ${briefing.yesterdayDeltaPct} percent from yesterday. Coach note: ${briefing.aiCoachQuote}`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);

      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    }
  };

  const getPriorityBadge = (iconType: string) => {
    switch (iconType) {
      case 'critical':
        return {
          symbol: '🔴',
          bg: 'bg-rose-50/80 dark:bg-rose-950/40',
          border: 'border-rose-200/80 dark:border-rose-900/50',
          text: 'text-rose-700 dark:text-rose-300',
        };
      case 'high':
        return {
          symbol: '🟠',
          bg: 'bg-amber-50/80 dark:bg-amber-950/40',
          border: 'border-amber-200/80 dark:border-amber-900/50',
          text: 'text-amber-700 dark:text-amber-300',
        };
      case 'revision':
        return {
          symbol: '🔄',
          bg: 'bg-blue-50/80 dark:bg-blue-950/40',
          border: 'border-blue-200/80 dark:border-blue-900/50',
          text: 'text-blue-700 dark:text-blue-300',
        };
      case 'practice':
        return {
          symbol: '📝',
          bg: 'bg-purple-50/80 dark:bg-purple-950/40',
          border: 'border-purple-200/80 dark:border-purple-900/50',
          text: 'text-purple-700 dark:text-purple-300',
        };
      default:
        return {
          symbol: '⚡',
          bg: 'bg-indigo-50/80 dark:bg-indigo-950/40',
          border: 'border-indigo-200/80 dark:border-indigo-900/50',
          text: 'text-indigo-700 dark:text-indigo-300',
        };
    }
  };

  const completedCount = briefing.priorities.filter(p => p.completed).length;

  return (
    <div className={`p-6 sm:p-7 rounded-3xl border shadow-md relative overflow-hidden transition-all ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border-indigo-900/40' 
        : 'bg-gradient-to-br from-amber-50/40 via-white to-indigo-50/30 border-indigo-100'
    }`}>
      
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400">
            <Sun className="w-5 h-5" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-black uppercase text-amber-700 dark:text-amber-400 tracking-wider">
                Personal AI Mentor • Daily Briefing
              </span>
              <span className="text-[10px] px-2 py-0.2 rounded-md font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                {briefing.dateString}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-0.5">
              {briefing.greeting}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSpeakBriefing}
            className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              isPlayingAudio 
                ? 'bg-purple-600 text-white border-purple-600 animate-pulse' 
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-purple-950/40'
            }`}
            title="Listen to Voice Briefing"
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-purple-600" />}
            <span className="hidden sm:inline">{isPlayingAudio ? 'Mute Voice' : 'Listen'}</span>
          </button>

          <button
            onClick={onRefreshBriefing}
            disabled={isRefreshing}
            className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all cursor-pointer"
            title="Regenerate Briefing with AI"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-purple-600' : ''}`} />
          </button>

          <button
            onClick={onOpenModal}
            className="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-purple-500/20 transition-all cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>Full Briefing</span>
          </button>
        </div>

      </div>

      {/* Main 2-Column Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-5">
        
        {/* Left 5 Columns: Status Gauges + AI Coach Message */}
        <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
          
          {/* Status Metric Blocks */}
          <div>
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 block mb-2">
              Your preparation status
            </span>

            <div className="grid grid-cols-2 gap-3">
              
              {/* 🎯 Readiness: 72% */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-indigo-100 dark:border-indigo-900/40 shadow-xs space-y-1">
                <div className="flex items-center gap-1 text-[11px] font-black text-indigo-700 dark:text-indigo-300">
                  <Target className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>Readiness</span>
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-slate-900 dark:text-white">
                    {briefing.readinessPercentage}%
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">Target 85%</span>
                </div>
              </div>

              {/* 📈 Yesterday: +2% */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-emerald-100 dark:border-emerald-900/40 shadow-xs space-y-1">
                <div className="flex items-center gap-1 text-[11px] font-black text-emerald-700 dark:text-emerald-300">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Yesterday</span>
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                    +{briefing.yesterdayDeltaPct}%
                  </span>
                  <span className="text-[10px] text-emerald-600 font-bold">Gained</span>
                </div>
              </div>

            </div>
          </div>

          {/* 🤖 AI Says Box (High visual impact) */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white shadow-md space-y-2 border border-purple-800/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <BrainCircuit className="w-3.5 h-3.5 text-purple-300" />
                <span className="text-[11px] font-black uppercase text-purple-300 tracking-wider">
                  AI Coach says:
                </span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-800 text-purple-200 font-bold">
                Daily Focus
              </span>
            </div>

            <p className="text-xs sm:text-sm font-bold italic leading-relaxed text-purple-100">
              “{briefing.aiCoachQuote}”
            </p>

            <div className="pt-2 border-t border-purple-800/40 flex items-center justify-between text-[11px]">
              <span className="text-purple-300 font-medium">
                Target: 90 mins on Audit SA 315
              </span>
              <button
                onClick={() => onNavigate('ai-examiner')}
                className="font-black text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>Launch Drill</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Right 7 Columns: Today's Priorities List */}
        <div className="lg:col-span-7 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
              Today's priorities
            </span>
            <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
              {completedCount}/{briefing.priorities.length} Tasks Finished
            </span>
          </div>

          <div className="space-y-2">
            {briefing.priorities.map((item) => {
              const badge = getPriorityBadge(item.iconType);
              return (
                <div
                  key={item.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    item.completed
                      ? 'bg-slate-50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-60'
                      : `${badge.bg} ${badge.border} bg-white dark:bg-slate-900 shadow-xs hover:border-purple-300 dark:hover:border-purple-700`
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <button
                      onClick={() => onTogglePriority(item.id)}
                      className="shrink-0 text-slate-400 hover:text-purple-600 transition-colors cursor-pointer"
                    >
                      {item.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-400 hover:text-purple-600" />
                      )}
                    </button>

                    <span className="text-sm shrink-0">{badge.symbol}</span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-black truncate ${item.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                          {item.title}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-400 shrink-0">
                          • {item.estimatedMins}m
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        {item.detail}
                      </p>
                    </div>
                  </div>

                  {item.actionView && !item.completed && (
                    <button
                      onClick={() => onNavigate(item.actionView!)}
                      className="shrink-0 px-2.5 py-1 rounded-xl bg-purple-50 hover:bg-purple-600 hover:text-white dark:bg-purple-950/60 dark:hover:bg-purple-600 text-[11px] font-black text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                    >
                      <span>{item.actionLabel?.split(' ')[0] || 'Start'}</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
