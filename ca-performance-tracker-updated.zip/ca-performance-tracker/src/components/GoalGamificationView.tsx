import React, { useState } from 'react';
import { 
  Target, 
  Award, 
  Flame, 
  Plus, 
  CheckCircle2, 
  Trophy, 
  Zap, 
  Sparkles, 
  Users, 
  Trash2 
} from 'lucide-react';
import { Goal, Badge, ICAIStudentProfile } from '../types';

interface GoalGamificationViewProps {
  goals: Goal[];
  badges: Badge[];
  profile: ICAIStudentProfile;
  onAddGoal: (goal: Omit<Goal, 'id'>) => void;
  onToggleGoal: (id: string) => void;
  onDeleteGoal: (id: string) => void;
  isDarkMode: boolean;
}

export const GoalGamificationView: React.FC<GoalGamificationViewProps> = ({
  goals,
  badges,
  profile,
  onAddGoal,
  onToggleGoal,
  onDeleteGoal,
  isDarkMode,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Daily' | 'Weekly' | 'Syllabus'>('Daily');

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddGoal({
      title: newTitle.trim(),
      targetDate: new Date().toISOString().split('T')[0],
      completed: false,
      category: newCategory,
      progressPct: 0,
    });

    setNewTitle('');
  };

  const unlockedBadgesCount = badges.filter(b => b.unlocked).length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400">
          <Trophy className="w-4 h-4" />
          <span>Goal Setting & Gamification Engine</span>
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          Study Targets, XP Levels & Achievement Badges
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Set daily and weekly academic goals, accumulate XP points, and unlock achievements.
        </p>
      </div>

      {/* Profile XP & Level Progress Card */}
      <div className={`p-6 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-6 ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-slate-800' 
          : 'bg-gradient-to-r from-indigo-500 via-purple-500 to-blue-600 text-white border-indigo-500 shadow-md'
      }`}>
        <div className="space-y-1 text-center sm:text-left">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-white/20 text-white">
            Level {profile.levelNumber} CA Scholar
          </span>
          <h3 className="text-2xl font-black text-white">
            {profile.xpPoints} Total Study XP
          </h3>
          <p className="text-xs text-indigo-100">
            Next Level (Level {profile.levelNumber + 1}) in {5000 - profile.xpPoints} XP!
          </p>
        </div>

        {/* Level Bar */}
        <div className="w-full sm:w-64 space-y-1.5">
          <div className="flex justify-between text-xs font-bold text-white">
            <span>Level {profile.levelNumber} Progress</span>
            <span>{Math.round((profile.xpPoints / 5000) * 100)}%</span>
          </div>
          <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden p-0.5 border border-white/20">
            <div 
              className="bg-amber-400 h-full rounded-full transition-all duration-500 shadow-sm" 
              style={{ width: `${Math.round((profile.xpPoints / 5000) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Goal Creator & Goals List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Goals Management */}
        <div className={`p-5 rounded-2xl border space-y-4 ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-blue-500" />
            <span>Academic Target Goals</span>
          </h3>

          <form onSubmit={handleCreateGoal} className="flex gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. Solve 50 Income Tax MCQs by 8 PM..."
              className={`flex-1 px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value as any)}
              className={`px-2 py-2 rounded-xl border text-xs font-bold ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Daily">Daily</option>
              <option value="Weekly">Weekly</option>
              <option value="Syllabus">Syllabus</option>
            </select>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shrink-0"
            >
              Add
            </button>
          </form>

          <div className="space-y-2">
            {goals.map((goal) => (
              <div
                key={goal.id}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 text-xs ${
                  goal.completed
                    ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 text-emerald-800 dark:text-emerald-300 line-through'
                    : isDarkMode ? 'bg-slate-800/60 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}
              >
                <div 
                  onClick={() => onToggleGoal(goal.id)}
                  className="flex items-center gap-2.5 cursor-pointer min-w-0 flex-1"
                >
                  <CheckCircle2 className={`w-4 h-4 shrink-0 ${
                    goal.completed ? 'text-emerald-500 fill-emerald-500/20' : 'text-slate-400'
                  }`} />
                  <span className="truncate font-semibold">{goal.title}</span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 uppercase">
                    {goal.category}
                  </span>
                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="text-rose-500 hover:text-rose-700 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Badges & Achievements Grid */}
        <div className={`p-5 rounded-2xl border space-y-4 ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span>Unlocked Badges & Achievements</span>
            </h3>
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
              {unlockedBadgesCount}/{badges.length} Unlocked
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {badges.map((b) => (
              <div
                key={b.id}
                className={`p-3.5 rounded-xl border flex items-center gap-3 ${
                  b.unlocked
                    ? 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-300'
                    : isDarkMode ? 'bg-slate-800/40 border-slate-800 opacity-40' : 'bg-slate-100 border-slate-200 opacity-50'
                }`}
              >
                <div className="text-2xl shrink-0">{b.icon}</div>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold leading-tight truncate">{b.name}</h4>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">{b.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
