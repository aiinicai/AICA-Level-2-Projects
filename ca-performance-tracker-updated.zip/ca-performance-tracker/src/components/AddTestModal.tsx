import React, { useState } from 'react';
import { X, Plus, FileText } from 'lucide-react';
import { Subject, TestRecord, TestType } from '../types';

interface AddTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  subjects: Subject[];
  onAddTest: (test: Omit<TestRecord, 'id'>) => void;
  isDarkMode: boolean;
}

export const AddTestModal: React.FC<AddTestModalProps> = ({
  isOpen,
  onClose,
  subjects,
  onAddTest,
  isDarkMode,
}) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState(subjects[0]?.id || '');
  const [testType, setTestType] = useState<TestType>('Mock Test');
  const [maxMarks, setMaxMarks] = useState(100);
  const [marksObtained, setMarksObtained] = useState(65);
  const [attemptNumber, setAttemptNumber] = useState(1);
  const [difficultyLevel, setDifficultyLevel] = useState<'Standard' | 'ICAI Standard' | 'Challenging'>('ICAI Standard');
  const [timeTakenMins, setTimeTakenMins] = useState(180);
  const [remarks, setRemarks] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddTest({
      subjectId: subjectId || subjects[0]?.id,
      title: title.trim(),
      testType,
      date: new Date().toISOString().split('T')[0],
      maxMarks,
      marksObtained,
      attemptNumber,
      difficultyLevel,
      timeTakenMins,
      remarks: remarks.trim() || 'Logged via test portal',
    });

    onClose();
  };

  const testTypes: TestType[] = [
    'Mock Test', 'RTP', 'MTP', 'Past Paper', 'Coaching Test', 'ICAI Unit Test', 'Internal Test'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className={`w-full max-w-lg rounded-2xl border p-6 space-y-5 shadow-2xl ${
        isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            <h3 className="text-base font-extrabold">Log New Test / Assessment Score</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Test Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. ICAI Mock Test Series 1 - Paper 1"
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Subject
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Test Type
              </label>
              <select
                value={testType}
                onChange={(e) => setTestType(e.target.value as TestType)}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              >
                {testTypes.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Max Marks
              </label>
              <input
                type="number"
                value={maxMarks}
                onChange={(e) => setMaxMarks(Number(e.target.value))}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Marks Obtained
              </label>
              <input
                type="number"
                value={marksObtained}
                onChange={(e) => setMarksObtained(Number(e.target.value))}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Time (Mins)
              </label>
              <input
                type="number"
                value={timeTakenMins}
                onChange={(e) => setTimeTakenMins(Number(e.target.value))}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Remarks & Weak Concepts Identified
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Lost marks in GST Input Tax Credit Section 17(5)..."
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20"
            >
              Save Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
