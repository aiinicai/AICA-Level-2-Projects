import React, { useState, useEffect, useRef } from 'react';
import {
  GraduationCap,
  Sparkles,
  Award,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  Play,
  Pause,
  RotateCcw,
  BookOpen,
  ArrowRight,
  TrendingUp,
  FileText,
  Copy,
  Check,
  Zap,
  Target,
  BarChart2,
  RefreshCw,
  HelpCircle,
  Layers,
  Send,
  Lightbulb,
  Sliders,
  ChevronDown
} from 'lucide-react';
import { ExaminerQuestion, ExaminerEvaluationResult, Subject, ICAIStudentProfile } from '../types';
import { INITIAL_EXAMINER_QUESTIONS, INITIAL_EXAMINER_EVALUATION } from '../data/initialData';

interface AIExaminerModeViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  isDarkMode: boolean;
  onNavigate?: (view: string) => void;
  onAwardXp?: (amount: number, reason: string) => void;
}

export const AIExaminerModeView: React.FC<AIExaminerModeViewProps> = ({
  profile,
  subjects,
  isDarkMode,
  onNavigate,
  onAwardXp
}) => {
  // Configuration State
  const [selectedSubject, setSelectedSubject] = useState<string>('Audit');
  const [topicInput, setTopicInput] = useState<string>('SA 315');
  const [difficulty, setDifficulty] = useState<'ICAI exam level' | 'RTP / MTP Level' | 'AIR Ranker Tough Level'>('ICAI exam level');
  const [totalMarks, setTotalMarks] = useState<number>(10);

  // Active Question & Session State
  const [activeQuestion, setActiveQuestion] = useState<ExaminerQuestion>(INITIAL_EXAMINER_QUESTIONS[0]);
  const [studentAnswer, setStudentAnswer] = useState<string>(INITIAL_EXAMINER_QUESTIONS[0].sampleStudentDraft || '');
  const [evaluation, setEvaluation] = useState<ExaminerEvaluationResult | null>(INITIAL_EXAMINER_EVALUATION);

  // Loading & Generation States
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Exam Clock / Timer
  const [secondsRemaining, setSecondsRemaining] = useState<number>(15 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isTimerRunning && secondsRemaining > 0) {
      timerRef.current = setInterval(() => {
        setSecondsRemaining(prev => prev - 1);
        setSecondsElapsed(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isTimerRunning, secondsRemaining]);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
  };

  // Quick Presets
  const TOPIC_PRESETS = [
    { subject: 'Audit', topic: 'SA 315' },
    { subject: 'Audit', topic: 'SA 700 / SA 705 / Key Audit Matters' },
    { subject: 'Audit', topic: 'SA 240 Fraud in Audit' },
    { subject: 'Direct Tax', topic: 'Section 115BAC' },
    { subject: 'Direct Tax', topic: 'Section 40(a)(ia) TDS Disallowance' },
    { subject: 'Financial Reporting', topic: 'Ind AS 115' },
    { subject: 'Financial Reporting', topic: 'Ind AS 116 Leases' },
    { subject: 'Law', topic: 'Section 185 Loans to Directors' }
  ];

  const handleSelectPreset = (p: { subject: string; topic: string }) => {
    setSelectedSubject(p.subject);
    setTopicInput(p.topic);
  };

  // Generate Case-Based Question
  const handleGenerateQuestion = async () => {
    if (!topicInput.trim()) return;
    setIsGenerating(true);
    setEvaluation(null);

    try {
      const response = await fetch('/api/ai/generate-examiner-question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: selectedSubject,
          topic: topicInput,
          difficulty,
          marks: totalMarks
        })
      });

      const data = await response.json();
      const newQuestion: ExaminerQuestion = {
        id: data.id || `exam_${Date.now()}`,
        subject: data.subject || selectedSubject,
        topic: data.topic || topicInput,
        difficulty: data.difficulty || difficulty,
        marks: data.marks || totalMarks,
        timeLimitMinutes: data.timeLimitMinutes || Math.round(totalMarks * 1.5),
        questionTitle: data.questionTitle || `${selectedSubject} - ${topicInput}`,
        questionText: data.questionText || 'Detailed case study question...',
        sampleStudentDraft: data.sampleStudentDraft || '',
        sourceContext: data.sourceContext || 'ICAI Exam Pattern'
      };

      setActiveQuestion(newQuestion);
      setStudentAnswer('');
      setSecondsRemaining(newQuestion.timeLimitMinutes * 60);
      setSecondsElapsed(0);
      setIsTimerRunning(true);
    } catch (err) {
      console.error('Failed to generate question:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Load Sample Initial Preset
  const handleLoadInitialCase = (q: ExaminerQuestion) => {
    setActiveQuestion(q);
    setSelectedSubject(q.subject);
    setTopicInput(q.topic);
    setDifficulty(q.difficulty);
    setTotalMarks(q.marks);
    setStudentAnswer(q.sampleStudentDraft || '');
    setSecondsRemaining(q.timeLimitMinutes * 60);
    setSecondsElapsed(0);
    setIsTimerRunning(false);
    if (q.id === INITIAL_EXAMINER_QUESTIONS[0].id) {
      setEvaluation(INITIAL_EXAMINER_EVALUATION);
    } else {
      setEvaluation(null);
    }
  };

  // Evaluate Answer via AI Examiner
  const handleEvaluateAnswer = async () => {
    if (!studentAnswer.trim() || !activeQuestion) return;

    setIsEvaluating(true);
    setIsTimerRunning(false);

    try {
      const response = await fetch('/api/ai/evaluate-examiner-answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: activeQuestion,
          studentAnswer,
          timeSpentSeconds: secondsElapsed || 300
        })
      });

      const data = await response.json();
      setEvaluation(data);

      if (onAwardXp) {
        onAwardXp(80, `Completed 🎓 AI Examiner Case: ${activeQuestion.topic}`);
      }
    } catch (err) {
      console.error('Failed to evaluate examiner answer:', err);
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Helper for score bar
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-emerald-600 dark:text-emerald-400 bg-emerald-500';
    if (score >= 6) return 'text-indigo-600 dark:text-indigo-400 bg-indigo-500';
    if (score >= 4) return 'text-amber-600 dark:text-amber-400 bg-amber-500';
    return 'text-rose-600 dark:text-rose-400 bg-rose-500';
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* 🎓 Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-black uppercase text-purple-600 dark:text-purple-400">
            <GraduationCap className="w-4 h-4" />
            <span>ICAI Chief Examiner Rigorous Simulation</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2.5">
            <span>🎓 AI Examiner Mode</span>
            <span className="px-2.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-xs font-black">
              CA Final & Inter
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Select subject, topic & difficulty. The AI Chief Examiner generates a case study, grades your answer on 5 core parameters (out of 10), estimates your marks, and shows <strong>What you should have written</strong> & <strong>Why you lost marks</strong>.
          </p>
        </div>

        {/* Quick Presets Strip */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-bold text-slate-400">Pre-built Cases:</span>
          {INITIAL_EXAMINER_QUESTIONS.map((q) => (
            <button
              key={q.id}
              onClick={() => handleLoadInitialCase(q)}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold border transition-all cursor-pointer truncate max-w-[150px] ${
                activeQuestion?.id === q.id
                  ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
              }`}
            >
              {q.subject}: {q.topic}
            </button>
          ))}
        </div>
      </div>

      {/* ⚙️ EXAMINER SETUP PANEL (Subject, Topic, Difficulty, Marks) */}
      <div className={`p-6 rounded-3xl border shadow-sm ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-2 mb-4">
          <span className="p-1.5 rounded-xl bg-purple-600 text-white">
            <Sliders className="w-4 h-4" />
          </span>
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-white">
              Examiner Test Configuration
            </h3>
            <span className="text-[11px] text-slate-400 font-semibold">
              Customize the topic and rigorous testing standard
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          
          {/* Subject */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-700 dark:text-slate-300">
              Subject:
            </label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="Audit">Audit (Advanced Auditing & Ethics)</option>
              <option value="Direct Tax">Direct Tax & International Tax</option>
              <option value="Financial Reporting">Financial Reporting (Ind AS)</option>
              <option value="Corporate Law">Corporate & Economic Laws</option>
              <option value="AFM / SFM">Strategic Financial Management (AFM)</option>
              <option value="Costing / SCMPE">Strategic Cost & Performance Evaluation</option>
            </select>
          </div>

          {/* Topic */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-700 dark:text-slate-300">
              Topic / Standard / Section:
            </label>
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              placeholder="e.g. SA 315, Ind AS 115, Sec 115BAC"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
            />
          </div>

          {/* Difficulty */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-700 dark:text-slate-300">
              Difficulty Level:
            </label>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as any)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="ICAI exam level">ICAI exam level (Standard)</option>
              <option value="RTP / MTP Level">RTP / MTP Level (Application Heavy)</option>
              <option value="AIR Ranker Tough Level">AIR Ranker Tough Level (Complex Integration)</option>
            </select>
          </div>

          {/* Total Marks & Action */}
          <div className="space-y-1 flex flex-col justify-end">
            <button
              onClick={handleGenerateQuestion}
              disabled={isGenerating || !topicInput.trim()}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-purple-500/25 transition-all cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Drafting Case Question...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate Case Question</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Quick Topic Chips */}
        <div className="flex items-center gap-1.5 flex-wrap mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-bold text-slate-400">Popular Exam Topics:</span>
          {TOPIC_PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSelectPreset(p)}
              className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-purple-50 dark:bg-slate-800 dark:hover:bg-purple-950/50 text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:text-purple-600 dark:hover:text-purple-300 transition-all cursor-pointer"
            >
              {p.subject}: {p.topic}
            </button>
          ))}
        </div>

      </div>

      {/* 📝 CASE QUESTION & STUDENT WRITING CANVAS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 6 Columns: The Generated Question Stem */}
        <div className={`lg:col-span-6 p-6 rounded-3xl border space-y-4 flex flex-col justify-between ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          
          <div className="space-y-3">
            
            {/* Question Header & Meta */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-extrabold text-[11px]">
                    {activeQuestion.subject} • {activeQuestion.topic}
                  </span>
                  <span className="px-2 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold text-[10px]">
                    {activeQuestion.difficulty}
                  </span>
                </div>
                <h3 className="text-base font-black text-slate-900 dark:text-white mt-1.5">
                  {activeQuestion.questionTitle}
                </h3>
              </div>

              {/* Marks & Suggested Time */}
              <div className="text-right shrink-0">
                <span className="text-xl font-black text-purple-600 dark:text-purple-400 block">
                  {activeQuestion.marks} Marks
                </span>
                <span className="text-[11px] font-bold text-slate-400">
                  {activeQuestion.timeLimitMinutes} Mins Suggested
                </span>
              </div>
            </div>

            {/* Question Text */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2 text-xs leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-line font-medium max-h-[380px] overflow-y-auto">
              {activeQuestion.questionText}
            </div>

            {activeQuestion.sourceContext && (
              <div className="text-[11px] text-slate-400 font-medium italic flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                <span>{activeQuestion.sourceContext}</span>
              </div>
            )}

          </div>

          {/* Timer & Controls Bar */}
          <div className="p-3.5 rounded-2xl bg-purple-50/70 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-900/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-1.5 rounded-xl ${
                secondsRemaining < 120 ? 'bg-rose-500 text-white animate-pulse' : 'bg-purple-600 text-white'
              }`}>
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-purple-700 dark:text-purple-300 block uppercase">
                  Exam Timer
                </span>
                <span className={`text-base font-black ${
                  secondsRemaining < 120 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'
                }`}>
                  {formatTime(secondsRemaining)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300 hover:bg-purple-50 text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
              >
                {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isTimerRunning ? 'Pause' : 'Start Timer'}</span>
              </button>

              <button
                onClick={() => {
                  setSecondsRemaining(activeQuestion.timeLimitMinutes * 60);
                  setSecondsElapsed(0);
                  setIsTimerRunning(false);
                }}
                className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-800 text-xs font-bold transition-all cursor-pointer"
                title="Reset Timer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Right 6 Columns: Student Answer Input & Evaluation Trigger */}
        <div className={`lg:col-span-6 p-6 rounded-3xl border space-y-4 flex flex-col justify-between ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white">
                  Student Answer Booklet
                </h3>
                <span className="text-[11px] text-slate-400 font-semibold">
                  Write your descriptive answer as in the ICAI exam hall
                </span>
              </div>

              {activeQuestion.sampleStudentDraft && (
                <button
                  type="button"
                  onClick={() => setStudentAnswer(activeQuestion.sampleStudentDraft || '')}
                  className="px-2.5 py-1 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/60 dark:hover:bg-purple-900/60 text-purple-700 dark:text-purple-300 text-[11px] font-bold border border-purple-200 dark:border-purple-800 transition-all cursor-pointer"
                >
                  ⚡ Fill Sample Draft
                </button>
              )}
            </div>

            <textarea
              rows={13}
              value={studentAnswer}
              onChange={(e) => setStudentAnswer(e.target.value)}
              placeholder="Type your structured answer here (e.g. Issue involved, Statutory provisions, Application to facts, and Conclusion)..."
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium text-xs text-slate-900 dark:text-white leading-relaxed focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium pt-1">
              <span>{studentAnswer.trim() ? studentAnswer.trim().split(/\s+/).length : 0} words written</span>
              <span>Time spent: {formatTime(secondsElapsed)}</span>
            </div>
          </div>

          {/* Submit for AI Examiner Evaluation */}
          <button
            onClick={handleEvaluateAnswer}
            disabled={isEvaluating || !studentAnswer.trim()}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-500/25 transition-all cursor-pointer"
          >
            {isEvaluating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Chief Examiner Grading Answer (Concept, Application, Provisions)...</span>
              </>
            ) : (
              <>
                <Award className="w-4 h-4" />
                <span>Submit to AI Chief Examiner & Get Evaluation (+80 XP)</span>
              </>
            )}
          </button>

        </div>

      </div>

      {/* 🏆 THE FULL EXAMINER EVALUATION DASHBOARD (Shown once evaluated) */}
      {evaluation && (
        <div className="space-y-6 pt-4">
          
          {/* Main Examiner Evaluation Header & 5-Parameter Grid */}
          <div className={`p-6 rounded-3xl border shadow-sm space-y-6 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            
            {/* Header: Title + Estimated Marks Hero */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-xl bg-purple-600 text-white font-black text-xs flex items-center gap-1.5 shadow-xs">
                    <GraduationCap className="w-4 h-4" />
                    <span>Examiner Evaluation</span>
                  </span>
                  <span className="text-xs text-slate-400 font-semibold">
                    {evaluation.question.subject} • {evaluation.question.topic}
                  </span>
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white mt-1.5">
                  Official Examiner Scorecard & Performance Audit
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Evaluated against ICAI Suggested Answers marking keys and strict examiner grading standards.
                </p>
              </div>

              {/* Estimated Marks Hero Display */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/60 dark:to-indigo-950/60 border border-purple-200 dark:border-purple-800/60 text-right shrink-0 flex items-center gap-4">
                <div>
                  <span className="text-[11px] font-black text-purple-700 dark:text-purple-300 block uppercase">
                    Estimated Marks
                  </span>
                  <span className="text-3xl font-black text-purple-900 dark:text-white">
                    {evaluation.estimatedMarks.awarded}
                    <span className="text-base font-semibold text-slate-400"> / {evaluation.estimatedMarks.total}</span>
                  </span>
                </div>

                <div className="h-10 w-px bg-purple-200 dark:bg-purple-800" />

                <div className="text-left">
                  <span className="text-[10px] font-extrabold text-rose-600 dark:text-rose-400 block uppercase">
                    Lost Marks
                  </span>
                  <span className="text-xl font-black text-rose-600 dark:text-rose-400">
                    -{evaluation.estimatedMarks.lostMarks} M
                  </span>
                </div>
              </div>
            </div>

            {/* 5-Criteria Ratings (Concept, Application, Relevant Provisions, Presentation, Conclusion - ALL OUT OF 10) */}
            <div>
              <span className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider block mb-3">
                Criterion-Wise Marking Breakdown (Out of 10):
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                
                {/* 1. Concept */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Concept</span>
                    <span className={`text-sm font-black ${getScoreColor(evaluation.scores.concept).split(' ')[0]}`}>
                      {evaluation.scores.concept}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreColor(evaluation.scores.concept).split(' ')[2]}`}
                      style={{ width: `${evaluation.scores.concept * 10}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block">Core doctrine grasp</span>
                </div>

                {/* 2. Application */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Application</span>
                    <span className={`text-sm font-black ${getScoreColor(evaluation.scores.application).split(' ')[0]}`}>
                      {evaluation.scores.application}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreColor(evaluation.scores.application).split(' ')[2]}`}
                      style={{ width: `${evaluation.scores.application * 10}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block">Synthesis with facts</span>
                </div>

                {/* 3. Relevant Provisions */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Relevant provisions</span>
                    <span className={`text-sm font-black ${getScoreColor(evaluation.scores.relevantProvisions).split(' ')[0]}`}>
                      {evaluation.scores.relevantProvisions}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreColor(evaluation.scores.relevantProvisions).split(' ')[2]}`}
                      style={{ width: `${evaluation.scores.relevantProvisions * 10}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block">Sections / SAs cited</span>
                </div>

                {/* 4. Presentation */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Presentation</span>
                    <span className={`text-sm font-black ${getScoreColor(evaluation.scores.presentation).split(' ')[0]}`}>
                      {evaluation.scores.presentation}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreColor(evaluation.scores.presentation).split(' ')[2]}`}
                      style={{ width: `${evaluation.scores.presentation * 10}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block">Subheadings & layout</span>
                </div>

                {/* 5. Conclusion */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Conclusion</span>
                    <span className={`text-sm font-black ${getScoreColor(evaluation.scores.conclusion).split(' ')[0]}`}>
                      {evaluation.scores.conclusion}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreColor(evaluation.scores.conclusion).split(' ')[2]}`}
                      style={{ width: `${evaluation.scores.conclusion * 10}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block">Legal verdict accuracy</span>
                </div>

              </div>
            </div>

            {/* Examiner Verdict Banner */}
            <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-900/40 text-xs flex items-start gap-3">
              <div className="p-1.5 rounded-lg bg-purple-600 text-white shrink-0 mt-0.5">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <span className="font-extrabold text-purple-900 dark:text-purple-200 block">
                  Chief Examiner Verdict:
                </span>
                <p className="text-purple-800 dark:text-purple-300 font-medium mt-0.5 leading-relaxed">
                  {evaluation.examinerVerdict}
                </p>
              </div>
            </div>

          </div>

          {/* TWO PILLARS: 1. Why you lost marks & 2. What you should have written */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* ❌ WHY YOU LOST MARKS (5 Cols) */}
            <div className={`lg:col-span-5 p-6 rounded-3xl border shadow-sm space-y-4 ${
              isDarkMode 
                ? 'bg-slate-900 border-rose-900/30' 
                : 'bg-rose-50/40 border-rose-200'
            }`}>
              
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-rose-600 text-white">
                  <XCircle className="w-4 h-4" />
                </span>
                <div>
                  <h4 className="text-base font-black text-rose-950 dark:text-rose-200">
                    Why you lost {evaluation.estimatedMarks.lostMarks} marks
                  </h4>
                  <span className="text-[11px] text-rose-700 dark:text-rose-400 font-semibold">
                    Itemized deduction ledger from the marking scheme
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {evaluation.whyYouLostMarks.summary}
              </p>

              <div className="space-y-3 pt-2">
                {evaluation.whyYouLostMarks.deductions.map((ded, index) => (
                  <div
                    key={index}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/40 shadow-xs space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-md bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-black text-[10px] uppercase">
                        {ded.flawType} Gap
                      </span>
                      <span className="font-black text-rose-600 dark:text-rose-400">
                        -{ded.pointsDeducted} Marks
                      </span>
                    </div>

                    <h5 className="font-black text-slate-900 dark:text-white leading-snug">
                      {ded.reason}
                    </h5>

                    <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                      {ded.examinerComment}
                    </p>
                  </div>
                ))}
              </div>

            </div>

            {/* 🎯 WHAT YOU SHOULD HAVE WRITTEN (7 Cols) */}
            <div className={`lg:col-span-7 p-6 rounded-3xl border shadow-sm space-y-4 ${
              isDarkMode 
                ? 'bg-slate-900 border-indigo-900/40' 
                : 'bg-white border-indigo-200'
            }`}>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-xl bg-emerald-600 text-white">
                    <CheckCircle2 className="w-4 h-4" />
                  </span>
                  <div>
                    <h4 className="text-base font-black text-slate-900 dark:text-white">
                      What you should have written
                    </h4>
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold">
                      ICAI Suggested Answers Model Benchmark (10/10 Standard)
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleCopyText(
                    `${evaluation.whatYouShouldHaveWritten.fullModelAnswer}\n\n[STATUTORY HIGHLIGHTS]\n${evaluation.whatYouShouldHaveWritten.statutoryHighlights.join('\n')}`,
                    'model_answer'
                  )}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {copiedKey === 'model_answer' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="text-emerald-600 font-black">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Model Answer</span>
                    </>
                  )}
                </button>
              </div>

              {/* Statutory Highlights Pill Strip */}
              {evaluation.whatYouShouldHaveWritten.statutoryHighlights && (
                <div className="p-3 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40 space-y-1.5">
                  <span className="text-[11px] font-black text-indigo-900 dark:text-indigo-200 uppercase tracking-wider block">
                    Mandatory Statutory References & Terms:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {evaluation.whatYouShouldHaveWritten.statutoryHighlights.map((term, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded-lg bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 text-[11px] font-bold text-indigo-700 dark:text-indigo-300"
                      >
                        ✓ {term}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Full Model Answer Display */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-xs leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-line font-medium max-h-[420px] overflow-y-auto">
                {evaluation.whatYouShouldHaveWritten.fullModelAnswer}
              </div>

              {/* Crucial Working Notes */}
              {evaluation.whatYouShouldHaveWritten.crucialWorkingNotes && evaluation.whatYouShouldHaveWritten.crucialWorkingNotes.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/40 space-y-1 text-xs">
                  <span className="font-black text-amber-900 dark:text-amber-200 block">
                    Examiner Working Notes:
                  </span>
                  <ul className="list-disc list-inside space-y-1 text-amber-800 dark:text-amber-300 text-[11px]">
                    {evaluation.whatYouShouldHaveWritten.crucialWorkingNotes.map((note, i) => (
                      <li key={i}>{note}</li>
                    ))}
                  </ul>
                </div>
              )}

            </div>

          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <button
              onClick={() => {
                setStudentAnswer('');
                setSecondsRemaining(activeQuestion.timeLimitMinutes * 60);
                setSecondsElapsed(0);
                setIsTimerRunning(true);
                setEvaluation(null);
              }}
              className="px-5 py-2.5 rounded-xl border border-purple-300 dark:border-purple-800 bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 font-bold text-xs hover:bg-purple-50 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retry this Case Question</span>
            </button>

            <button
              onClick={handleGenerateQuestion}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs shadow-md shadow-purple-500/25 transition-all cursor-pointer flex items-center gap-2"
            >
              <span>Next Examiner Question</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
