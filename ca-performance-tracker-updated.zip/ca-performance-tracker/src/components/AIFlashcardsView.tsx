import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  BrainCircuit, 
  RotateCw, 
  Volume2, 
  Plus, 
  Check, 
  X, 
  Trash2, 
  Edit3, 
  BookOpen, 
  CheckCircle2, 
  Award, 
  ChevronRight, 
  ChevronLeft, 
  Lightbulb, 
  Filter, 
  Search, 
  Layers, 
  Flame, 
  HelpCircle,
  Zap,
  ArrowRight,
  Shuffle
} from 'lucide-react';
import { 
  Flashcard, 
  Subject, 
  Chapter, 
  CourseLevel, 
  FlashcardDifficulty, 
  FlashcardStatus 
} from '../types';

interface AIFlashcardsViewProps {
  course: CourseLevel;
  subjects: Subject[];
  chapters: Chapter[];
  flashcards: Flashcard[];
  onAddFlashcards: (cards: Flashcard[]) => void;
  onUpdateFlashcard: (updated: Flashcard) => void;
  onDeleteFlashcard: (id: string) => void;
  onAwardXp: (xp: number) => void;
  isDarkMode: boolean;
  initialChapterId?: string;
}

export const AIFlashcardsView: React.FC<AIFlashcardsViewProps> = ({
  course,
  subjects,
  chapters,
  flashcards,
  onAddFlashcards,
  onUpdateFlashcard,
  onDeleteFlashcard,
  onAwardXp,
  isDarkMode,
  initialChapterId,
}) => {
  const currentSubjects = subjects.filter(s => s.course === course);
  const currentSubjectIds = currentSubjects.map(s => s.id);
  const courseFlashcards = flashcards.filter(f => currentSubjectIds.includes(f.subjectId));

  // Mode: 'practice' | 'manager'
  const [activeTab, setActiveTab] = useState<'practice' | 'manager'>('practice');

  // Filters
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [selectedChapterId, setSelectedChapterId] = useState<string>(initialChapterId || 'all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // AI Generator Modal state
  const [isGeneratorOpen, setIsGeneratorOpen] = useState<boolean>(false);
  const [genSubjectId, setGenSubjectId] = useState<string>(currentSubjects[0]?.id || '');
  const [genChapterId, setGenChapterId] = useState<string>('');
  const [genPrompt, setGenPrompt] = useState<string>('');
  const [genCardCount, setGenCardCount] = useState<number>(5);
  const [genLoading, setGenLoading] = useState<boolean>(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [generatedPreviewCards, setGeneratedPreviewCards] = useState<Array<Omit<Flashcard, 'id' | 'subjectId' | 'chapterId' | 'reviewCount' | 'status'> & { selected: boolean }>>([]);

  // Manual Card Modal State
  const [isManualModalOpen, setIsManualModalOpen] = useState<boolean>(false);
  const [manualSubjectId, setManualSubjectId] = useState<string>(currentSubjects[0]?.id || '');
  const [manualChapterId, setManualChapterId] = useState<string>('');
  const [manualQuestion, setManualQuestion] = useState<string>('');
  const [manualAnswer, setManualAnswer] = useState<string>('');
  const [manualHint, setManualHint] = useState<string>('');
  const [manualDifficulty, setManualDifficulty] = useState<FlashcardDifficulty>('Medium');
  const [manualTags, setManualTags] = useState<string>('');

  // Practice State
  const [practiceDeck, setPracticeDeck] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [sessionStats, setSessionStats] = useState({ mastered: 0, learning: 0, hard: 0, totalXpGained: 0 });
  const [isSessionFinished, setIsSessionFinished] = useState<boolean>(false);

  // Set default chapter when subject changes in generator
  useEffect(() => {
    const subChs = chapters.filter(c => c.subjectId === genSubjectId);
    if (subChs.length > 0) {
      setGenChapterId(subChs[0].id);
    } else {
      setGenChapterId('');
    }
  }, [genSubjectId, chapters]);

  useEffect(() => {
    const subChs = chapters.filter(c => c.subjectId === manualSubjectId);
    if (subChs.length > 0) {
      setManualChapterId(subChs[0].id);
    } else {
      setManualChapterId('');
    }
  }, [manualSubjectId, chapters]);

  // Build filtered list of flashcards for practice or management
  const filteredFlashcards = courseFlashcards.filter(card => {
    if (selectedSubjectId !== 'all' && card.subjectId !== selectedSubjectId) return false;
    if (selectedChapterId !== 'all' && card.chapterId !== selectedChapterId) return false;
    if (statusFilter !== 'all' && card.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchQ = card.question.toLowerCase().includes(q);
      const matchA = card.answer.toLowerCase().includes(q);
      const matchTag = card.tags?.some(t => t.toLowerCase().includes(q));
      if (!matchQ && !matchA && !matchTag) return false;
    }
    return true;
  });

  // Start Practice Session
  const handleStartPractice = (cardsToPractice?: Flashcard[]) => {
    const deck = cardsToPractice || (filteredFlashcards.length > 0 ? filteredFlashcards : courseFlashcards);
    if (deck.length === 0) return;

    setPracticeDeck([...deck]);
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowHint(false);
    setSessionStats({ mastered: 0, learning: 0, hard: 0, totalXpGained: 0 });
    setIsSessionFinished(false);
  };

  useEffect(() => {
    handleStartPractice();
  }, [selectedSubjectId, selectedChapterId, statusFilter]);

  const currentCard = practiceDeck[currentIndex];

  const handleShuffleDeck = () => {
    const shuffled = [...practiceDeck].sort(() => Math.random() - 0.5);
    setPracticeDeck(shuffled);
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowHint(false);
  };

  const handleGradeCard = (rating: 'hard' | 'good' | 'easy') => {
    if (!currentCard) return;

    let newStatus: FlashcardStatus = currentCard.status;
    let xpGained = 0;

    if (rating === 'easy') {
      newStatus = 'Mastered';
      xpGained = 25;
      setSessionStats(prev => ({ ...prev, mastered: prev.mastered + 1, totalXpGained: prev.totalXpGained + 25 }));
      confetti({ particleCount: 30, spread: 40, origin: { y: 0.7 } });
    } else if (rating === 'good') {
      newStatus = 'Learning';
      xpGained = 15;
      setSessionStats(prev => ({ ...prev, learning: prev.learning + 1, totalXpGained: prev.totalXpGained + 15 }));
    } else {
      newStatus = 'Learning';
      xpGained = 5;
      setSessionStats(prev => ({ ...prev, hard: prev.hard + 1, totalXpGained: prev.totalXpGained + 5 }));
    }

    if (xpGained > 0) {
      onAwardXp(xpGained);
    }

    // Update global card
    onUpdateFlashcard({
      ...currentCard,
      status: newStatus,
      reviewCount: currentCard.reviewCount + 1,
      lastReviewed: new Date().toISOString().split('T')[0],
    });

    // Move to next
    if (currentIndex < practiceDeck.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
      setShowHint(false);
    } else {
      setIsSessionFinished(true);
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
  };

  const handleSpeakText = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Generate AI Cards from Chapter Notes
  const handleGenerateAICards = async () => {
    if (!genSubjectId || !genChapterId) {
      setGenError('Please select a subject and chapter.');
      return;
    }

    setGenLoading(true);
    setGenError(null);

    const subObj = subjects.find(s => s.id === genSubjectId);
    const chObj = chapters.find(c => c.id === genChapterId);

    try {
      const res = await fetch('/api/ai/flashcards/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course,
          subjectName: subObj?.name || 'CA Subject',
          chapterTitle: chObj?.title || 'Chapter',
          chapterNotes: chObj?.notes || '',
          customPrompt: genPrompt,
          cardCount: genCardCount,
        }),
      });

      const data = await res.json();

      if (res.ok && data.flashcards) {
        const cardsWithSelection = data.flashcards.map((c: any) => ({
          question: c.question,
          answer: c.answer,
          hint: c.hint,
          difficulty: (c.difficulty || 'Medium') as FlashcardDifficulty,
          tags: c.tags || [],
          selected: true,
          createdFromNotes: !!chObj?.notes,
        }));
        setGeneratedPreviewCards(cardsWithSelection);
      } else {
        setGenError(data.error || 'Failed to generate flashcards.');
      }
    } catch (err: any) {
      setGenError('Failed to connect to AI Flashcard Generator.');
    } finally {
      setGenLoading(false);
    }
  };

  const handleSaveGeneratedCards = () => {
    const selectedToSave = generatedPreviewCards.filter(c => c.selected);
    if (selectedToSave.length === 0) return;

    const newCards: Flashcard[] = selectedToSave.map((c, idx) => ({
      id: `fc_gen_${Date.now()}_${idx}`,
      subjectId: genSubjectId,
      chapterId: genChapterId,
      question: c.question,
      answer: c.answer,
      hint: c.hint,
      difficulty: c.difficulty,
      tags: c.tags,
      reviewCount: 0,
      status: 'New',
      createdFromNotes: true,
    }));

    onAddFlashcards(newCards);
    setIsGeneratorOpen(false);
    setGeneratedPreviewCards([]);
    setGenPrompt('');
    onAwardXp(newCards.length * 20);

    confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    handleStartPractice(newCards);
  };

  // Add Manual Card
  const handleSaveManualCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualQuestion.trim() || !manualAnswer.trim()) return;

    const tagsArray = manualTags
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const newCard: Flashcard = {
      id: `fc_man_${Date.now()}`,
      subjectId: manualSubjectId,
      chapterId: manualChapterId,
      question: manualQuestion.trim(),
      answer: manualAnswer.trim(),
      hint: manualHint.trim() || undefined,
      difficulty: manualDifficulty,
      tags: tagsArray.length > 0 ? tagsArray : ['Manual'],
      reviewCount: 0,
      status: 'New',
    };

    onAddFlashcards([newCard]);
    setIsManualModalOpen(false);
    setManualQuestion('');
    setManualAnswer('');
    setManualHint('');
    setManualTags('');
    onAwardXp(15);
  };

  // Stats calculation
  const totalCourseCards = courseFlashcards.length;
  const masteredCardsCount = courseFlashcards.filter(c => c.status === 'Mastered').length;
  const learningCardsCount = courseFlashcards.filter(c => c.status === 'Learning').length;
  const masteryPct = totalCourseCards > 0 ? Math.round((masteredCardsCount / totalCourseCards) * 100) : 0;

  const currentSubjectObj = subjects.find(s => s.id === currentCard?.subjectId);
  const currentChapterObj = chapters.find(c => c.id === currentCard?.chapterId);

  return (
    <div className="space-y-6">
      
      {/* Top Banner Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            <BrainCircuit className="w-4 h-4" />
            <span>CA {course} Active Recall Engine</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white">
            AI Flashcards & Memory Recall Deck
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Convert chapter notes, accounting standards, and section provisions into high-yield active recall flashcards.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsGeneratorOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-black text-xs shadow-md shadow-indigo-500/20 hover:brightness-110 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span>Generate Cards from Notes</span>
          </button>
          
          <button
            onClick={() => setIsManualModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs hover:bg-slate-50 dark:hover:bg-slate-750 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-indigo-500" />
            <span>Add Card</span>
          </button>
        </div>
      </div>

      {/* Progress Metric Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black uppercase text-slate-400">Total Cards</p>
            <h3 className="text-2xl font-black text-slate-800 dark:text-white">{totalCourseCards}</h3>
          </div>
          <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black uppercase text-amber-500">Learning Phase</p>
            <h3 className="text-2xl font-black text-amber-600 dark:text-amber-400">{learningCardsCount}</h3>
          </div>
          <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
            <RotateCw className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black uppercase text-emerald-500">Mastered Cards</p>
            <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{masteredCardsCount}</h3>
          </div>
          <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-900 to-purple-900 p-4 rounded-2xl text-white shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black uppercase text-purple-300">Memory Mastery</p>
            <h3 className="text-2xl font-black text-amber-300">{masteryPct}%</h3>
          </div>
          <div className="p-2 rounded-xl bg-white/10 border border-white/20 text-amber-300">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Tab Controller */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          
          {/* Mode Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-fit">
            <button
              onClick={() => setActiveTab('practice')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-black transition-all ${
                activeTab === 'practice'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Practice Deck ({filteredFlashcards.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('manager')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-black transition-all ${
                activeTab === 'manager'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All Cards Deck ({courseFlashcards.length})</span>
            </button>
          </div>

          {/* Quick Shuffle button */}
          {activeTab === 'practice' && practiceDeck.length > 0 && !isSessionFinished && (
            <button
              onClick={handleShuffleDeck}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              <Shuffle className="w-3.5 h-3.5 text-indigo-500" />
              <span>Shuffle Deck</span>
            </button>
          )}
        </div>

        {/* Filter dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          
          {/* Subject Select */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Subject</label>
            <select
              value={selectedSubjectId}
              onChange={(e) => {
                setSelectedSubjectId(e.target.value);
                setSelectedChapterId('all');
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Subjects ({currentSubjects.length})</option>
              {currentSubjects.map(sub => (
                <option key={sub.id} value={sub.id}>{sub.code} - {sub.name}</option>
              ))}
            </select>
          </div>

          {/* Chapter Select */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Chapter</label>
            <select
              value={selectedChapterId}
              onChange={(e) => setSelectedChapterId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Chapters</option>
              {chapters
                .filter(c => selectedSubjectId === 'all' || c.subjectId === selectedSubjectId)
                .map(ch => (
                  <option key={ch.id} value={ch.id}>Ch {ch.chapterNo}: {ch.title.substring(0, 30)}...</option>
                ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="New">New Cards</option>
              <option value="Learning">Learning / Hard Cards</option>
              <option value="Mastered">Mastered Cards</option>
            </select>
          </div>

          {/* Search query */}
          <div>
            <label className="text-[10px] font-black uppercase text-slate-400 block mb-1">Search Keywords</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Search provisions, section, tag..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

        </div>

      </div>

      {/* TAB 1: PRACTICE DECK INTERACTIVE VIEW */}
      {activeTab === 'practice' && (
        <div className="space-y-4">
          
          {practiceDeck.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center flex flex-col items-center justify-center space-y-4 shadow-xs">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 flex items-center justify-center">
                <BrainCircuit className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-black text-slate-800 dark:text-white">No Flashcards Match Your Filter</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md">
                Generate flashcards from your chapter notes or select a different subject filter to start active recall practice!
              </p>
              <button
                onClick={() => setIsGeneratorOpen(true)}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-xs shadow-md shadow-indigo-500/20"
              >
                ⚡ Generate Flashcards from Notes
              </button>
            </div>
          ) : isSessionFinished ? (
            /* SESSION FINISHED SUMMARY CARD */
            <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 rounded-3xl p-8 text-white text-center flex flex-col items-center space-y-6 shadow-xl border border-purple-500/30">
              <div className="w-20 h-20 rounded-3xl bg-amber-400/20 border border-amber-300/40 text-amber-300 flex items-center justify-center shadow-inner">
                <Award className="w-10 h-10 animate-bounce" />
              </div>

              <div>
                <span className="text-xs font-black uppercase tracking-widest text-amber-300">Active Recall Session Completed</span>
                <h3 className="text-2xl font-black mt-1">Great Job, {course} Aspirant! 🎉</h3>
                <p className="text-xs text-indigo-200 mt-1 max-w-md">
                  Active recall triggers neural pathways and long-term memory retention for ICAI exam questions.
                </p>
              </div>

              {/* Stats pill */}
              <div className="grid grid-cols-3 gap-4 w-full max-w-md bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15">
                <div>
                  <p className="text-[10px] uppercase font-bold text-emerald-300">Mastered</p>
                  <p className="text-xl font-black text-emerald-400">{sessionStats.mastered}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-amber-300">Learning</p>
                  <p className="text-xl font-black text-amber-300">{sessionStats.learning}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-indigo-200">XP Earned</p>
                  <p className="text-xl font-black text-amber-300">+{sessionStats.totalXpGained}</p>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => handleStartPractice()}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg hover:brightness-110 transition-all cursor-pointer"
                >
                  Practice Again
                </button>
                <button
                  onClick={() => setActiveTab('manager')}
                  className="px-5 py-3 rounded-xl bg-white/10 border border-white/20 text-white font-bold text-xs hover:bg-white/20 transition-all cursor-pointer"
                >
                  View All Cards Deck
                </button>
              </div>
            </div>
          ) : (
            /* ACTIVE FLIP CARD INTERACTIVE UI */
            <div className="flex flex-col items-center space-y-4">
              
              {/* Progress & Deck Nav Bar */}
              <div className="w-full max-w-2xl flex items-center justify-between text-xs font-extrabold text-slate-500 dark:text-slate-400 px-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-[11px]">
                    Card {currentIndex + 1} of {practiceDeck.length}
                  </span>
                  {currentSubjectObj && (
                    <span className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-bold">
                      {currentSubjectObj.code}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (currentIndex > 0) {
                        setCurrentIndex(prev => prev - 1);
                        setIsFlipped(false);
                        setShowHint(false);
                      }
                    }}
                    disabled={currentIndex === 0}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Previous Card"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      if (currentIndex < practiceDeck.length - 1) {
                        setCurrentIndex(prev => prev + 1);
                        setIsFlipped(false);
                        setShowHint(false);
                      }
                    }}
                    disabled={currentIndex === practiceDeck.length - 1}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Next Card"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* FLIP CARD CONTAINER */}
              <div 
                onClick={() => setIsFlipped(!isFlipped)}
                className="w-full max-w-2xl min-h-[320px] sm:min-h-[360px] cursor-pointer perspective-1000 group relative"
              >
                <div 
                  className={`w-full h-full min-h-[320px] sm:min-h-[360px] rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-500 transform-style-3d border shadow-lg ${
                    isFlipped 
                      ? 'bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-950 text-white border-purple-500/40 shadow-indigo-500/10' 
                      : isDarkMode
                        ? 'bg-slate-900 text-slate-100 border-slate-800 hover:border-indigo-500/50'
                        : 'bg-white text-slate-900 border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  
                  {/* Top Card Meta */}
                  <div className="flex items-center justify-between border-b border-slate-100/10 pb-3">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-md ${
                        currentCard?.difficulty === 'Hard'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : currentCard?.difficulty === 'Medium'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}>
                        {currentCard?.difficulty || 'Medium'}
                      </span>

                      {currentCard?.createdFromNotes && (
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-purple-400" /> From Notes
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => handleSpeakText(isFlipped ? currentCard?.answer : currentCard?.question, e)}
                        className="p-1.5 rounded-lg bg-slate-500/10 hover:bg-slate-500/20 text-indigo-400 transition-all"
                        title="Listen Audio Speech"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>

                      <span className="text-[10px] font-bold opacity-60">
                        {isFlipped ? 'ANSWER REVEALED' : 'CLICK TO REVEAL ANSWER'}
                      </span>
                    </div>
                  </div>

                  {/* Center Content */}
                  <div className="my-auto py-4 space-y-3">
                    
                    {!isFlipped ? (
                      /* QUESTION SIDE */
                      <div className="space-y-4">
                        {currentChapterObj && (
                          <p className="text-[11px] font-black uppercase text-indigo-500 dark:text-indigo-400 tracking-wider">
                            Chapter {currentChapterObj.chapterNo}: {currentChapterObj.title}
                          </p>
                        )}

                        <h3 className="text-lg sm:text-xl font-black leading-relaxed">
                          {currentCard?.question}
                        </h3>

                        {/* Hint Section */}
                        {currentCard?.hint && (
                          <div className="pt-2">
                            {showHint ? (
                              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-semibold flex items-start gap-2">
                                <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                                <div>
                                  <span className="font-bold uppercase text-[10px] block">Hint Trigger:</span>
                                  <span>{currentCard.hint}</span>
                                </div>
                              </div>
                            ) : (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setShowHint(true);
                                }}
                                className="text-xs font-bold text-amber-500 hover:text-amber-600 flex items-center gap-1 cursor-pointer"
                              >
                                <Lightbulb className="w-3.5 h-3.5" /> Show Hint Clue
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    ) : (
                      /* ANSWER SIDE */
                      <div className="space-y-3 animate-fadeIn">
                        <p className="text-[10px] font-black uppercase tracking-widest text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Official Provision / Answer Key
                        </p>
                        <div className="text-sm sm:text-base font-medium leading-relaxed whitespace-pre-line text-indigo-100">
                          {currentCard?.answer}
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Bottom Tags & Flip Indicator */}
                  <div className="border-t border-slate-100/10 pt-3 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {currentCard?.tags?.map((t, idx) => (
                        <span key={idx} className="text-[9px] font-black px-2 py-0.5 rounded-full bg-slate-500/15 text-slate-400">
                          #{t}
                        </span>
                      ))}
                    </div>

                    <div className="text-xs font-black text-indigo-500 dark:text-indigo-400 flex items-center gap-1">
                      <RotateCw className={`w-3.5 h-3.5 ${isFlipped ? 'rotate-180' : ''} transition-transform`} />
                      <span>{isFlipped ? 'Flip Back' : 'Flip Card'}</span>
                    </div>
                  </div>

                </div>
              </div>

              {/* SELF ASSESSMENT RECALL BUTTONS (Visible when card is flipped) */}
              {isFlipped && (
                <div className="w-full max-w-2xl bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md space-y-2 animate-fadeIn">
                  <p className="text-center text-[11px] font-black uppercase text-slate-400 tracking-wider">
                    Rate Your Memory Recall Accuracy
                  </p>
                  
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => handleGradeCard('hard')}
                      className="py-3 px-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 font-extrabold text-xs flex flex-col items-center gap-0.5 hover:bg-rose-100 dark:hover:bg-rose-900 transition-all cursor-pointer"
                    >
                      <span className="text-sm">🔴 Hard / Forgot</span>
                      <span className="text-[9px] opacity-75 font-normal">Review Soon (+5 XP)</span>
                    </button>

                    <button
                      onClick={() => handleGradeCard('good')}
                      className="py-3 px-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900/50 text-amber-700 dark:text-amber-300 font-extrabold text-xs flex flex-col items-center gap-0.5 hover:bg-amber-100 dark:hover:bg-amber-900 transition-all cursor-pointer"
                    >
                      <span className="text-sm">🟡 Good Recalled</span>
                      <span className="text-[9px] opacity-75 font-normal">Good Speed (+15 XP)</span>
                    </button>

                    <button
                      onClick={() => handleGradeCard('easy')}
                      className="py-3 px-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/50 text-emerald-700 dark:text-emerald-300 font-extrabold text-xs flex flex-col items-center gap-0.5 hover:bg-emerald-100 dark:hover:bg-emerald-900 transition-all cursor-pointer"
                    >
                      <span className="text-sm">🟢 Easy / Mastered</span>
                      <span className="text-[9px] opacity-75 font-normal">Perfect Recall (+25 XP)</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>
      )}

      {/* TAB 2: ALL CARDS DECK MANAGER */}
      {activeTab === 'manager' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-500" />
                <span>Card Repository ({filteredFlashcards.length} Cards)</span>
              </h3>

              <button
                onClick={() => setIsManualModalOpen(true)}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Card</span>
              </button>
            </div>

            {filteredFlashcards.length === 0 ? (
              <p className="text-xs text-slate-400 py-8 text-center">No flashcards found matching filters.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredFlashcards.map((card) => {
                  const sub = subjects.find(s => s.id === card.subjectId);
                  const ch = chapters.find(c => c.id === card.chapterId);

                  return (
                    <div 
                      key={card.id}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-indigo-500/40 transition-all flex flex-col justify-between space-y-3"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400">
                            {sub?.code || 'SUB'} • {ch ? `Ch ${ch.chapterNo}` : ''}
                          </span>

                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                              card.status === 'Mastered' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            }`}>
                              {card.status}
                            </span>
                            <button
                              onClick={() => onDeleteFlashcard(card.id)}
                              className="text-slate-400 hover:text-rose-500 transition-colors"
                              title="Delete Card"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className="text-xs font-extrabold text-slate-900 dark:text-white">
                          Q: {card.question}
                        </p>

                        <p className="text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 line-clamp-3 font-medium">
                          {card.answer}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800 text-[10px] text-slate-400">
                        <span>Reviewed {card.reviewCount} times</span>
                        <div className="flex gap-1">
                          {card.tags?.map((t, idx) => (
                            <span key={idx} className="px-1.5 py-0.5 bg-slate-200 dark:bg-slate-700 rounded text-slate-600 dark:text-slate-300 font-bold">
                              #{t}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI GENERATOR MODAL */}
      {isGeneratorOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full p-6 space-y-5 shadow-2xl relative my-8">
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 text-white shadow-xs">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-base">
                    AI Flashcard Generator from Chapter Notes
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Extract active recall questions directly from your saved study notes or ICAI syllabus rules.
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setIsGeneratorOpen(false);
                  setGeneratedPreviewCards([]);
                }}
                className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* If no generated preview yet, show configuration form */}
            {generatedPreviewCards.length === 0 ? (
              <div className="space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Subject selector */}
                  <div>
                    <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300 block mb-1">
                      Target Subject
                    </label>
                    <select
                      value={genSubjectId}
                      onChange={(e) => setGenSubjectId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                    >
                      {currentSubjects.map(sub => (
                        <option key={sub.id} value={sub.id}>{sub.code} - {sub.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Chapter Selector */}
                  <div>
                    <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300 block mb-1">
                      Target Chapter
                    </label>
                    <select
                      value={genChapterId}
                      onChange={(e) => setGenChapterId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                    >
                      {chapters
                        .filter(c => c.subjectId === genSubjectId)
                        .map(ch => (
                          <option key={ch.id} value={ch.id}>
                            Ch {ch.chapterNo}: {ch.title} {ch.notes ? '📝 (Has Notes)' : ''}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>

                {/* Chapter Notes Preview box */}
                {(() => {
                  const currentCh = chapters.find(c => c.id === genChapterId);
                  return (
                    <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-900/40 space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] font-black text-indigo-700 dark:text-indigo-300">
                        <span className="flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                          Saved Notes Source
                        </span>
                        {currentCh?.notes ? (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-extrabold">
                            ✓ Notes Available ({currentCh.notes.length} chars)
                          </span>
                        ) : (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-extrabold">
                            ⚡ No notes saved (Will generate from ICAI syllabus)
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-300 italic line-clamp-3">
                        {currentCh?.notes || 'No chapter notes found. Gemini will automatically extract high-weightage ICAI exam provisions for this chapter title.'}
                      </p>
                    </div>
                  );
                })()}

                {/* Card Count & Custom Focus */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300 block mb-1">
                      Number of Cards
                    </label>
                    <select
                      value={genCardCount}
                      onChange={(e) => setGenCardCount(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                    >
                      <option value={3}>3 Cards (Quick Recall)</option>
                      <option value={5}>5 Cards (Recommended)</option>
                      <option value={8}>8 Cards (Deep Practice)</option>
                      <option value={10}>10 Cards (Full Mastery Deck)</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300 block mb-1">
                      Special Focus Request (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Focus on penalty sections, time limits, or numerical formulas..."
                      value={genPrompt}
                      onChange={(e) => setGenPrompt(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                    />
                  </div>
                </div>

                {genError && (
                  <p className="text-xs font-bold text-rose-500 bg-rose-50 dark:bg-rose-950/60 p-2.5 rounded-xl border border-rose-200 dark:border-rose-900">
                    ⚠️ {genError}
                  </p>
                )}

                <button
                  onClick={handleGenerateAICards}
                  disabled={genLoading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-indigo-500/20 hover:brightness-110 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  {genLoading ? (
                    <>
                      <RotateCw className="w-4 h-4 animate-spin" />
                      <span>Gemini AI Analyzing Notes & Formulating Cards...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Generate {genCardCount} Active Recall Cards</span>
                    </>
                  )}
                </button>

              </div>
            ) : (
              /* PREVIEW & SELECT GENERATED CARDS STEP */
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/40 text-xs text-emerald-800 dark:text-emerald-300 font-bold">
                  <span>✨ Successfully generated {generatedPreviewCards.length} study cards! Select which ones to add to your deck:</span>
                </div>

                <div className="max-h-[340px] overflow-y-auto space-y-3 pr-1">
                  {generatedPreviewCards.map((card, idx) => (
                    <div 
                      key={idx}
                      onClick={() => {
                        setGeneratedPreviewCards(prev => prev.map((c, i) => i === idx ? { ...c, selected: !c.selected } : c));
                      }}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                        card.selected 
                          ? 'border-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/30' 
                          : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/20 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400">
                          Card #{idx + 1} • {card.difficulty}
                        </span>

                        <div className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                          card.selected ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 dark:border-slate-700'
                        }`}>
                          {card.selected && <Check className="w-3.5 h-3.5" />}
                        </div>
                      </div>

                      <p className="text-xs font-black text-slate-900 dark:text-white">Q: {card.question}</p>
                      <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-line font-medium bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                        A: {card.answer}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => setGeneratedPreviewCards([])}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold"
                  >
                    Back to Config
                  </button>

                  <button
                    onClick={handleSaveGeneratedCards}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-black text-xs uppercase tracking-wider shadow-md hover:bg-indigo-700 transition-all cursor-pointer"
                  >
                    Add {generatedPreviewCards.filter(c => c.selected).length} Cards & Start Practice
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* MANUAL CARD MODAL */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-lg w-full p-6 space-y-4 shadow-2xl relative my-8">
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-black text-slate-900 dark:text-white text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-500" />
                <span>Create Custom Study Card</span>
              </h3>
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveManualCard} className="space-y-3">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Subject</label>
                  <select
                    value={manualSubjectId}
                    onChange={(e) => setManualSubjectId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    {currentSubjects.map(sub => (
                      <option key={sub.id} value={sub.id}>{sub.code} - {sub.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Chapter</label>
                  <select
                    value={manualChapterId}
                    onChange={(e) => setManualChapterId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    {chapters
                      .filter(c => c.subjectId === manualSubjectId)
                      .map(ch => (
                        <option key={ch.id} value={ch.id}>Ch {ch.chapterNo}: {ch.title.substring(0, 25)}...</option>
                      ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Question / Memory Prompt</label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. What is the threshold limit for TDS under Section 194C?"
                  value={manualQuestion}
                  onChange={(e) => setManualQuestion(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200"
                />
              </div>

              <div>
                <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Answer Key / Explanation</label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Single sum > ₹30,000 or Aggregate in FY > ₹1,000,000..."
                  value={manualAnswer}
                  onChange={(e) => setManualAnswer(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Hint (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. 30k single or 100k aggregate"
                    value={manualHint}
                    onChange={(e) => setManualHint(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300 block mb-1">Tags (Comma separated)</label>
                  <input
                    type="text"
                    placeholder="TDS, Sec 194C"
                    value={manualTags}
                    onChange={(e) => setManualTags(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 text-white font-black text-xs shadow-md hover:bg-indigo-700 transition-all cursor-pointer"
                >
                  Save Flashcard (+15 XP)
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
