import React, { useState } from 'react';
import { 
  Flame, 
  Bell, 
  Search, 
  Award, 
  ChevronDown, 
  User, 
  BookOpen, 
  Sparkles,
  Sun,
  Moon,
  CheckCircle2,
  Calendar,
  Menu
} from 'lucide-react';
import { ICAIStudentProfile, CourseLevel } from '../types';
import fisheyeFocusIcon from '../assets/images/fisheye_focus_1786821178271.jpg';

interface NavbarProps {
  profile: ICAIStudentProfile;
  onCourseChange: (course: CourseLevel) => void;
  onNavigate: (view: string) => void;
  activeView: string;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
  onToggleSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  profile,
  onCourseChange,
  onNavigate,
  activeView,
  isDarkMode,
  toggleDarkMode,
  unreadNotificationsCount,
  onOpenNotifications,
  onToggleSidebar,
}) => {
  const [courseDropdownOpen, setCourseDropdownOpen] = useState(false);

  const courses: CourseLevel[] = ['Foundation', 'Intermediate', 'Final'];

  return (
    <header className={`h-16 border-b px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 backdrop-blur-md transition-colors duration-200 ${
      isDarkMode 
        ? 'bg-slate-900/95 border-slate-800 text-slate-100' 
        : 'bg-white/95 border-slate-200 text-slate-800'
    }`}>
      {/* Left: Hamburger (mobile) + Title */}
      <div className="flex items-center gap-3">
        {/* Hamburger menu button — mobile only */}
        <button
          onClick={onToggleSidebar}
          className={`lg:hidden p-2 rounded-xl border transition-all ${
            isDarkMode
              ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
          }`}
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="relative w-9 h-9 rounded-xl overflow-hidden shadow-md shadow-indigo-500/20 border border-indigo-200/50 dark:border-indigo-700/50 shrink-0 hidden sm:block">
          <img
            src={fisheyeFocusIcon}
            alt="CA Mentor Focus"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover rounded-xl hover:scale-110 transition-transform duration-300"
          />
        </div>
        <div className="flex flex-col">
          <h1 className="text-lg font-bold text-slate-800 dark:text-slate-100 leading-tight flex items-center gap-2">
            <span>{profile.name.split(' ')[0]}</span>
          </h1>
        
        </div>
      </div>

      {/* Center & Right Controls */}
      <div className="flex items-center gap-4">
        
        {/* Course Level Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => setCourseDropdownOpen(!courseDropdownOpen)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md border text-xs font-semibold transition-all ${
              isDarkMode 
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750' 
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span>CA {profile.course}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {courseDropdownOpen && (
            <div className={`absolute top-full right-0 mt-1 w-44 rounded-xl border shadow-xl py-1 z-50 ${
              isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
            }`}>
              <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Switch Level
              </div>
              {courses.map((course) => (
                <button
                  key={course}
                  onClick={() => {
                    onCourseChange(course);
                    setCourseDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs font-medium flex items-center justify-between transition-colors ${
                    profile.course === course
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span>CA {course}</span>
                  {profile.course === course && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Study Streak Badge */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-red-500/10 border border-orange-500/30 text-orange-600 dark:text-orange-400">
          <Flame className="w-4 h-4 text-orange-500 fill-orange-500 animate-pulse" />
          <div className="flex flex-col">
            <span className="text-[9px] font-black uppercase tracking-wider text-orange-500/90 leading-none">Streak</span>
            <span className="text-xs font-black leading-none mt-0.5">{profile.streakDays} Days</span>
          </div>
        </div>

        {/* XP Points Pill */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 border border-purple-500/30 text-purple-700 dark:text-purple-300 text-xs font-extrabold shadow-xs">
          <Award className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          <span>Lvl {profile.levelNumber} ({profile.xpPoints} XP)</span>
        </div>

        {/* Theme Toggle Button */}
        <button
          onClick={toggleDarkMode}
          className={`p-2 rounded-xl border transition-all ${
            isDarkMode 
              ? 'bg-slate-800/80 border-slate-700 text-amber-400 hover:bg-slate-700 hover:scale-105 shadow-xs' 
              : 'bg-amber-50 border-amber-200 text-amber-600 hover:bg-amber-100 hover:scale-105 shadow-xs'
          }`}
          title="Toggle Theme"
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className={`relative p-2 rounded-xl border transition-all ${
            isDarkMode 
              ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700 hover:scale-105 shadow-xs' 
              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:scale-105 shadow-xs'
          }`}
          title="Notifications"
        >
          <Bell className="w-4 h-4 text-indigo-500" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-r from-rose-500 to-pink-500 text-white text-[10px] font-black flex items-center justify-center shadow-xs animate-bounce">
              {unreadNotificationsCount}
            </span>
          )}
        </button>

        {/* User Profile Avatar */}
        <div 
          onClick={() => onNavigate('profile')}
          className="cursor-pointer flex items-center gap-2 group"
          title="View Profile"
        >
          <div className="p-0.5 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 shadow-md group-hover:scale-105 transition-all">
            <img
              src={profile.photoUrl}
              alt={profile.name}
              className="h-9 w-9 rounded-full bg-slate-200 border border-white dark:border-slate-900 object-cover"
            />
          </div>
        </div>

      </div>
    </header>
  );
};
