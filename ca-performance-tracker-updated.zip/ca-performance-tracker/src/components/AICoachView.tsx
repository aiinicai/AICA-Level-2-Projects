import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  BrainCircuit, 
  Send, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Award, 
  Calendar, 
  Zap, 
  BookOpen, 
  HelpCircle,
  Clock,
  TrendingUp,
  Target
} from 'lucide-react';
import { ICAIStudentProfile, Subject, TestRecord, Chapter, AICoachAnalysis } from '../types';

interface AICoachViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  testRecords: TestRecord[];
  chapters: Chapter[];
  isDarkMode: boolean;
}

export const AICoachView: React.FC<AICoachViewProps> = ({
  profile,
  subjects,
  testRecords,
  chapters,
  isDarkMode,
}) => {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<AICoachAnalysis | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Interactive AI Chat state
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: `Hello ${profile.name}! I am your AI CA Study Mentor. I've reviewed your test scores for CA ${profile.course} (${profile.attempt}). How can I assist your preparation today? You can ask me for topic breakdowns, exam presentation tips, or revision strategies!`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  const fetchAICoachAdvice = async () => {
    setLoading(true);
    setErrorMsg(null);

    const totalHoursSpent = Math.round(chapters.reduce((acc, c) => acc + c.timeSpentMins, 0) / 60);

    try {
      const res = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile,
          subjects: subjects.filter(s => s.course === profile.course),
          testRecords,
          chapterStats: chapters.map(c => ({ title: c.title, status: c.status, timeMins: c.timeSpentMins })),
          totalHoursSpent,
        }),
      });

      const data = await res.json();

      if (res.ok && data) {
        setAnalysis(data);
      } else {
        setErrorMsg(data.error || 'Failed to fetch AI coach advice.');
      }
    } catch (err: any) {
      setErrorMsg('Failed to connect to AI Coach service.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAICoachAdvice();
  }, [profile.course]);

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userText = chatInput.trim();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setChatMessages(prev => [...prev, { sender: 'user', text: userText, time: timeStr }]);
    setChatInput('');
    setChatLoading(true);

    try {
      const res = await fetch('/api/ai/doubt-solver', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course: profile.course,
          subject: 'General CA Preparation',
          chapter: 'Exam Guidance',
          question: userText,
        }),
      });

      const data = await res.json();
      if (res.ok && data.answer) {
        setChatMessages(prev => [
          ...prev,
          { sender: 'ai', text: data.answer, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
        ]);
      } else {
        setChatMessages(prev => [
          ...prev,
          { sender: 'ai', text: 'I faced a temporary issue answering your question. Please try again.', time: timeStr },
        ]);
      }
    } catch (err) {
      setChatMessages(prev => [
        ...prev,
        { sender: 'ai', text: 'Connection error while communicating with AI Mentor.', time: timeStr },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-purple-600 dark:text-purple-400">
            <Sparkles className="w-4 h-4" />
            <span>Gemini AI Personal Study Coach</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
            AI Exam Diagnostics & Personalized Strategy
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Data-driven insights based on your ICAI syllabus completion, test history, and target exam date.
          </p>
        </div>

        <button
          onClick={fetchAICoachAdvice}
          disabled={loading}
          className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-500/20 flex items-center justify-center gap-2 transition-all shrink-0 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'Analyzing Data...' : 'Refresh AI Analysis'}</span>
        </button>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-rose-800 dark:text-rose-300 text-xs font-semibold flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Analysis Display */}
      {analysis && (
        <div className="space-y-6">
          
          {/* Row 1: AI Pass Probability + Expected Marks + Motivational Quote */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Card 1: Pass Probability */}
            <div className={`p-5 rounded-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>Pass Probability</span>
                <BrainCircuit className="w-4 h-4 text-purple-500" />
              </div>
              <div className="mt-2 text-3xl font-black text-purple-600 dark:text-purple-400">
                {analysis.passProbability}%
              </div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Confidence Rating: <strong>{analysis.confidenceScore}/100</strong>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-purple-600 to-indigo-500 h-full rounded-full" 
                  style={{ width: `${analysis.passProbability}%` }}
                />
              </div>
            </div>

            {/* Card 2: Expected Marks */}
            <div className={`p-5 rounded-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>Expected Marks Range</span>
                <Award className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="mt-2 text-3xl font-black text-emerald-600 dark:text-emerald-400">
                {analysis.expectedMarksRange}
              </div>
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                Estimated ICAI Aggregate Range
              </div>
            </div>

            {/* Card 3: Motivational Quote */}
            <div className={`p-5 rounded-2xl border bg-gradient-to-br from-indigo-900 to-slate-900 text-white border-indigo-900 shadow-sm`}>
              <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5 mb-2">
                <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>Coach Motivational Insight</span>
              </div>
              <p className="text-xs italic font-medium leading-relaxed text-indigo-100">
                "{analysis.motivationalQuote}"
              </p>
            </div>

          </div>

          {/* Row 2: Daily Advice, Weekly Strategy & Exam Strategy */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className={`p-5 rounded-2xl border space-y-2 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
                <Target className="w-4 h-4" />
                <span>Today's Priority Advice</span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {analysis.dailyAdvice}
              </p>
            </div>

            <div className={`p-5 rounded-2xl border space-y-2 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div className="flex items-center gap-2 text-xs font-bold text-purple-600 dark:text-purple-400">
                <Calendar className="w-4 h-4" />
                <span>7-Day Strategic Goal</span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {analysis.weeklyStrategy}
              </p>
            </div>

            <div className={`p-5 rounded-2xl border space-y-2 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <BookOpen className="w-4 h-4" />
                <span>ICAI Exam Writing Strategy</span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {analysis.examStrategy}
              </p>
            </div>

          </div>

          {/* Row 3: Recommended Topics & High Risk Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Recommended High-Yield Topics */}
            <div className={`p-5 rounded-2xl border space-y-3 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Recommended High-Yield Revision Topics</span>
              </h3>

              <div className="space-y-2">
                {analysis.recommendedTopics?.map((topic, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 text-xs font-semibold text-emerald-900 dark:text-emerald-300 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span>{topic}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* High Risk Areas */}
            <div className={`p-5 rounded-2xl border space-y-3 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <span>High-Risk ICAI Exam Pitfalls to Avoid</span>
              </h3>

              <div className="space-y-2">
                {analysis.riskAreas?.map((risk, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200/60 dark:border-rose-900/40 text-xs font-semibold text-rose-900 dark:text-rose-300 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center shrink-0">
                      !
                    </span>
                    <span>{risk}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Interactive Chat with AI Mentor */}
      <div className={`p-6 rounded-2xl border space-y-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-purple-500" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
              Ask AI Mentor a CA Question / Revision Doubt
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">Gemini 3.6 Flash</span>
        </div>

        {/* Message Container */}
        <div className="h-64 overflow-y-auto space-y-3 p-2">
          {chatMessages.map((msg, idx) => (
            <div 
              key={idx}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className={`max-w-xl p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap ${
                msg.sender === 'user'
                  ? 'bg-blue-600 text-white font-medium rounded-tr-none'
                  : isDarkMode
                    ? 'bg-slate-800 text-slate-200 border border-slate-700 rounded-tl-none'
                    : 'bg-slate-100 text-slate-800 border border-slate-200 rounded-tl-none'
              }`}>
                {msg.text}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 px-1">
                {msg.time}
              </span>
            </div>
          ))}

          {chatLoading && (
            <div className="flex items-center gap-2 text-xs text-purple-500 font-semibold p-2">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>AI Coach is drafting response...</span>
            </div>
          )}
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSendChatMessage} className="flex gap-2 pt-2">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Ask about AS 10, GST ITC rules, SA 230, or exam writing tips..."
            className={`flex-1 px-4 py-2.5 rounded-xl border text-xs font-medium ${
              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
          <button
            type="submit"
            disabled={chatLoading}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Ask Coach</span>
          </button>
        </form>
      </div>

    </div>
  );
};
