import React, { useState } from 'react';
import { 
  Users, 
  MessageSquare, 
  Sparkles, 
  ThumbsUp, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  Briefcase, 
  Flame, 
  Clock, 
  Tag, 
  UserPlus, 
  Award,
  BookOpen,
  MessageCircle,
  TrendingUp,
  Share2,
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { CourseLevel, DiscussionCategory, ProblemDiscussion, DiscussionComment, StudyGroup } from '../types';

interface FriendDiscussionsViewProps {
  course: CourseLevel;
  studentName: string;
  discussions: ProblemDiscussion[];
  studyGroups: StudyGroup[];
  onAddDiscussion: (discussion: ProblemDiscussion) => void;
  onUpdateDiscussion: (discussion: ProblemDiscussion) => void;
  onAddStudyGroup: (group: StudyGroup) => void;
  onSendMessageToGroup: (groupId: string, message: { id: string; sender: string; time: string; text: string; isUser: boolean }) => void;
  isDarkMode: boolean;
}

export const FriendDiscussionsView: React.FC<FriendDiscussionsViewProps> = ({
  course,
  studentName,
  discussions,
  studyGroups,
  onAddDiscussion,
  onUpdateDiscussion,
  onAddStudyGroup,
  onSendMessageToGroup,
  isDarkMode,
}) => {
  const [activeTab, setActiveTab] = useState<'forum' | 'study_groups'>('forum');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Form State for New Discussion
  const [isNewDiscussionOpen, setIsNewDiscussionOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<DiscussionCategory>('Burnout & Focus');
  const [newProblem, setNewProblem] = useState('');
  const [newTags, setNewTags] = useState('');
  const [askAiAdvisor, setAskAiAdvisor] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Active Selected Discussion for Detailed Thread
  const [expandedDiscId, setExpandedDiscId] = useState<string | null>(discussions[0]?.id || null);
  const [commentInput, setCommentInput] = useState<{ [discId: string]: string }>({});
  const [aiGeneratingForId, setAiGeneratingForId] = useState<string | null>(null);

  // Active Study Group View
  const [selectedGroupId, setSelectedGroupId] = useState<string>(studyGroups[0]?.id || '');
  const [groupMessageText, setGroupMessageText] = useState('');

  // Form State for New Study Group
  const [isNewGroupModalOpen, setIsNewGroupModalOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupGoal, setNewGroupGoal] = useState('');
  const [newGroupCategory, setNewGroupCategory] = useState('Both Groups');

  // Categories list
  const categories: string[] = [
    'All',
    'Burnout & Focus',
    'Backlogs & Timetable',
    'Articleship & Career',
    'Subject Concepts',
    'Exam Strategy',
    'Study Partners'
  ];

  // Filtered discussions
  const filteredDiscussions = discussions.filter(disc => {
    const matchesCategory = selectedCategory === 'All' || disc.category === selectedCategory;
    const matchesSearch = disc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          disc.problemStatement.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          disc.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // Upvote Discussion
  const handleUpvoteDiscussion = (disc: ProblemDiscussion) => {
    const updated = {
      ...disc,
      upvotes: disc.upvotes + 1
    };
    onUpdateDiscussion(updated);
  };

  // Upvote Comment
  const handleUpvoteComment = (disc: ProblemDiscussion, commentId: string) => {
    const updatedComments = disc.comments.map(c => 
      c.id === commentId ? { ...c, upvotes: c.upvotes + 1 } : c
    );
    onUpdateDiscussion({ ...disc, comments: updatedComments });
  };

  // Post Comment/Reply
  const handleAddComment = (disc: ProblemDiscussion, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInput[disc.id];
    if (!text || !text.trim()) return;

    const newComment: DiscussionComment = {
      id: `c_${Date.now()}`,
      authorName: studentName || 'Rohan Sharma',
      content: text.trim(),
      createdAt: 'Just now',
      upvotes: 0,
    };

    const updatedDisc: ProblemDiscussion = {
      ...disc,
      comments: [...disc.comments, newComment]
    };

    onUpdateDiscussion(updatedDisc);
    setCommentInput(prev => ({ ...prev, [disc.id]: '' }));
  };

  // Generate AI Mentor Advice
  const handleFetchAiAdvice = async (disc: ProblemDiscussion) => {
    setAiGeneratingForId(disc.id);
    try {
      const res = await fetch('/api/ai/friend-discussion-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course: disc.course,
          title: disc.title,
          category: disc.category,
          problemDescription: disc.problemStatement
        }),
      });

      const data = await res.json();
      if (res.ok && data.advice) {
        const aiComment: DiscussionComment = {
          id: `ai_${Date.now()}`,
          authorName: 'AI CA Senior Mentor',
          authorBadge: 'AI Ranker Guidance',
          content: data.advice,
          createdAt: 'Just now',
          upvotes: 5,
          isAiAdvisor: true,
        };

        const updated = {
          ...disc,
          aiAdvisorSummary: data.advice,
          comments: [aiComment, ...disc.comments]
        };
        onUpdateDiscussion(updated);
      }
    } catch (err) {
      console.error('Failed to generate AI advice:', err);
    } finally {
      setAiGeneratingForId(null);
    }
  };

  // Post New Discussion Thread
  const handleCreateDiscussion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newProblem.trim()) return;

    setIsSubmitting(true);

    let initialAiAdvice = '';
    if (askAiAdvisor) {
      try {
        const res = await fetch('/api/ai/friend-discussion-advisor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            course,
            title: newTitle,
            category: newCategory,
            problemDescription: newProblem
          }),
        });
        const data = await res.json();
        if (res.ok && data.advice) {
          initialAiAdvice = data.advice;
        }
      } catch (err) {
        console.error(err);
      }
    }

    const initialComments: DiscussionComment[] = [];
    if (initialAiAdvice) {
      initialComments.push({
        id: `ai_${Date.now()}`,
        authorName: 'AI CA Senior Mentor',
        authorBadge: 'AI Ranker Guidance',
        content: initialAiAdvice,
        createdAt: 'Just now',
        upvotes: 3,
        isAiAdvisor: true
      });
    }

    const tagList = newTags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    const newDisc: ProblemDiscussion = {
      id: `disc_${Date.now()}`,
      title: newTitle,
      category: newCategory,
      authorName: studentName || 'Rohan Sharma',
      course,
      problemStatement: newProblem,
      createdAt: new Date().toISOString().split('T')[0],
      comments: initialComments,
      upvotes: 1,
      tags: tagList.length > 0 ? tagList : [newCategory, 'CA Prep'],
      isSolved: false,
      aiAdvisorSummary: initialAiAdvice || undefined
    };

    onAddDiscussion(newDisc);
    setExpandedDiscId(newDisc.id);

    // Reset form
    setNewTitle('');
    setNewProblem('');
    setNewTags('');
    setIsNewDiscussionOpen(false);
    setIsSubmitting(false);
  };

  // Send message in study group
  const handleSendGroupMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupMessageText.trim() || !selectedGroupId) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const msg = {
      id: `msg_${Date.now()}`,
      sender: studentName || 'Rohan Sharma',
      time: timeStr,
      text: groupMessageText.trim(),
      isUser: true
    };

    onSendMessageToGroup(selectedGroupId, msg);
    setGroupMessageText('');
  };

  // Create new study group
  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim() || !newGroupGoal.trim()) return;

    const newGroup: StudyGroup = {
      id: `sg_${Date.now()}`,
      name: newGroupName,
      goal: newGroupGoal,
      memberCount: 1,
      category: newGroupCategory,
      activeMembers: [studentName || 'Rohan Sharma'],
      groupChat: [
        {
          id: `m_${Date.now()}`,
          sender: 'System Bot',
          time: 'Just now',
          text: `Welcome to ${newGroupName}! Start logging your daily study hours and discussing challenges here.`,
        }
      ]
    };

    onAddStudyGroup(newGroup);
    setSelectedGroupId(newGroup.id);
    setNewGroupName('');
    setNewGroupGoal('');
    setIsNewGroupModalOpen(false);
  };

  const activeGroup = studyGroups.find(g => g.id === selectedGroupId) || studyGroups[0];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Banner Header */}
      <div className={`p-6 rounded-3xl border relative overflow-hidden transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-indigo-900/40' 
          : 'bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 border-indigo-100'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-extrabold text-xs flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                <span>CA Student Peer Network</span>
              </span>
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Active Peer Community
              </span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              Discuss Common CA Student Problems & Study Groups
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              Share real-world exam challenges, syllabus backlogs, burnout recovery strategies, and articleship queries with fellow CA students and rankers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsNewDiscussionOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 text-white text-xs font-black shadow-lg shadow-indigo-500/25 flex items-center gap-2 cursor-pointer transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Discuss a Problem</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-200/60 dark:border-slate-800">
          <button
            onClick={() => setActiveTab('forum')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'forum'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                : isDarkMode 
                  ? 'bg-slate-800/80 text-slate-300 hover:bg-slate-800' 
                  : 'bg-white/80 text-slate-700 border border-slate-200 hover:bg-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Common Problem Forum ({discussions.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('study_groups')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'study_groups'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                : isDarkMode 
                  ? 'bg-slate-800/80 text-slate-300 hover:bg-slate-800' 
                  : 'bg-white/80 text-slate-700 border border-slate-200 hover:bg-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Friend Study Groups ({studyGroups.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: COMMON PROBLEM FORUM */}
      {activeTab === 'forum' && (
        <div className="space-y-6">
          
          {/* Category Filter Pills & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search common problems (e.g., Burnout, Backlogs, Articleship, MCQs)..."
                className={`w-full pl-9 pr-3 py-1.5 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              />
            </div>

            {/* Category Select Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : isDarkMode
                        ? 'bg-slate-800 text-slate-400 hover:text-slate-200'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Discussion List */}
          {filteredDiscussions.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <MessageCircle className="w-10 h-10 text-slate-400 mx-auto" />
              <h4 className="text-sm font-black text-slate-800 dark:text-slate-200">
                No discussion threads match this category or search.
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Be the first to post a common CA study problem or ask your friends for advice!
              </p>
              <button
                onClick={() => setIsNewDiscussionOpen(true)}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold inline-flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Start Discussion</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredDiscussions.map((disc) => {
                const isExpanded = expandedDiscId === disc.id;

                return (
                  <div
                    key={disc.id}
                    className={`rounded-2xl border transition-all ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800 hover:border-slate-700'
                        : 'bg-white border-slate-200 shadow-xs hover:border-indigo-200'
                    }`}
                  >
                    {/* Main Thread Content */}
                    <div className="p-5 space-y-3">
                      
                      {/* Category Badge & Metadata */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full ${
                            disc.category === 'Burnout & Focus'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              : disc.category === 'Backlogs & Timetable'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : disc.category === 'Articleship & Career'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                          }`}>
                            {disc.category}
                          </span>

                          <span className="text-xs font-black text-slate-700 dark:text-slate-300">
                            {disc.authorName}
                          </span>
                          <span className="text-slate-400 text-xs">•</span>
                          <span className="text-xs text-indigo-600 dark:text-indigo-400 font-bold">
                            CA {disc.course}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{disc.createdAt}</span>
                          {disc.isSolved && (
                            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold ml-1 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Resolved</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Title */}
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white leading-snug">
                        {disc.title}
                      </h3>

                      {/* Problem Statement */}
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                        {disc.problemStatement}
                      </p>

                      {/* Tags */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {disc.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center gap-1"
                          >
                            <Tag className="w-2.5 h-2.5" />
                            <span>#{tag}</span>
                          </span>
                        ))}
                      </div>

                      {/* Action Bar */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-bold">
                        <div className="flex items-center gap-3">
                          {/* Upvote Button */}
                          <button
                            onClick={() => handleUpvoteDiscussion(disc)}
                            className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 transition-all flex items-center gap-1.5 cursor-pointer border border-indigo-200 dark:border-indigo-900/50"
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>{disc.upvotes} Upvotes</span>
                          </button>

                          {/* Comments Count / Expand Button */}
                          <button
                            onClick={() => setExpandedDiscId(isExpanded ? null : disc.id)}
                            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                            <span>{disc.comments.length} Friends Discussion</span>
                          </button>
                        </div>

                        {/* AI Mentor Advice Trigger */}
                        <button
                          onClick={() => handleFetchAiAdvice(disc)}
                          disabled={aiGeneratingForId === disc.id}
                          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700 transition-all flex items-center gap-1.5 cursor-pointer text-xs font-black shadow-xs disabled:opacity-50"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{aiGeneratingForId === disc.id ? 'Generating AI Advice...' : 'Get AI CA Mentor Advice'}</span>
                        </button>
                      </div>
                    </div>

                    {/* EXPANDED COMMENTS & FRIEND THREAD VIEW */}
                    {isExpanded && (
                      <div className="p-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 space-y-4 rounded-b-2xl">
                        
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <MessageCircle className="w-4 h-4 text-indigo-500" />
                            <span>Replies & Peer Insights ({disc.comments.length})</span>
                          </h4>
                        </div>

                        {/* Comments List */}
                        <div className="space-y-3">
                          {disc.comments.length === 0 ? (
                            <p className="text-xs text-slate-400 italic">
                              No replies yet. Be the first friend to post an answer or strategy!
                            </p>
                          ) : (
                            disc.comments.map((comment) => (
                              <div
                                key={comment.id}
                                className={`p-3.5 rounded-xl border text-xs space-y-2 ${
                                  comment.isAiAdvisor
                                    ? 'bg-purple-50/80 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800'
                                    : comment.isVerifiedRanker
                                    ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2 font-bold">
                                    <span className="text-slate-900 dark:text-white">
                                      {comment.authorName}
                                    </span>
                                    {comment.authorBadge && (
                                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                                        comment.isAiAdvisor
                                          ? 'bg-purple-200 text-purple-900 dark:bg-purple-900 dark:text-purple-200'
                                          : 'bg-emerald-200 text-emerald-900 dark:bg-emerald-900 dark:text-emerald-200'
                                      }`}>
                                        {comment.authorBadge}
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex items-center gap-2 text-[10px] text-slate-400">
                                    <span>{comment.createdAt}</span>
                                    <button
                                      onClick={() => handleUpvoteComment(disc, comment.id)}
                                      className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                                    >
                                      <ThumbsUp className="w-3 h-3" />
                                      <span>{comment.upvotes}</span>
                                    </button>
                                  </div>
                                </div>

                                <div className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                                  {comment.content}
                                </div>
                              </div>
                            ))
                          )}
                        </div>

                        {/* Post Reply Input Box */}
                        <form onSubmit={(e) => handleAddComment(disc, e)} className="flex items-center gap-2 pt-2">
                          <input
                            type="text"
                            value={commentInput[disc.id] || ''}
                            onChange={(e) => setCommentInput(prev => ({ ...prev, [disc.id]: e.target.value }))}
                            placeholder={`Reply as ${studentName || 'Rohan Sharma'} to share your experience or advice...`}
                            className={`flex-1 px-3.5 py-2 rounded-xl border text-xs font-medium ${
                              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                            }`}
                          />
                          <button
                            type="submit"
                            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Reply</span>
                          </button>
                        </form>

                      </div>
                    )}

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* TAB 2: FRIEND STUDY GROUPS */}
      {activeTab === 'study_groups' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Group Selector */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-500" />
                <span>Active Study Groups</span>
              </h3>
              <button
                onClick={() => setIsNewGroupModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-purple-700 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Group</span>
              </button>
            </div>

            <div className="space-y-3">
              {studyGroups.map((group) => {
                const isSelected = selectedGroupId === group.id;

                return (
                  <div
                    key={group.id}
                    onClick={() => setSelectedGroupId(group.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-500/10 border-purple-500 text-slate-900 dark:text-white shadow-xs'
                        : isDarkMode
                          ? 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                          : 'bg-white border-slate-200 hover:border-purple-300 text-slate-700 shadow-2xs'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs font-black text-slate-900 dark:text-white">
                        {group.name}
                      </h4>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                        {group.category}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                      {group.goal}
                    </p>

                    <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 font-bold">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-purple-500" />
                        <span>{group.activeMembers.length} Members Online</span>
                      </span>
                      <span className="text-purple-600 dark:text-purple-400 flex items-center gap-0.5">
                        <span>Open Chat</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Live Chat & Member Activity */}
          <div className="lg:col-span-2 space-y-4">
            {activeGroup && (
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[520px] shadow-xs">
                
                {/* Chat Header */}
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50 rounded-t-2xl">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {activeGroup.name}
                      </h3>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Live Room
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Goal: {activeGroup.goal}
                    </p>
                  </div>

                  <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>{activeGroup.activeMembers.length} Active Friends</span>
                  </div>
                </div>

                {/* Chat Messages Feed */}
                <div className="flex-1 p-4 overflow-y-auto space-y-3">
                  {activeGroup.groupChat.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col max-w-[80%] ${
                        msg.isUser ? 'ml-auto items-end' : 'mr-auto items-start'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-0.5 font-bold">
                        <span>{msg.sender}</span>
                        <span>•</span>
                        <span>{msg.time}</span>
                      </div>

                      <div
                        className={`p-3 rounded-2xl text-xs leading-relaxed ${
                          msg.isUser
                            ? 'bg-indigo-600 text-white rounded-br-none shadow-xs'
                            : isDarkMode
                            ? 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700'
                            : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Message Input Form */}
                <form
                  onSubmit={handleSendGroupMsg}
                  className="p-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 bg-slate-50/50 dark:bg-slate-800/30 rounded-b-2xl"
                >
                  <input
                    type="text"
                    value={groupMessageText}
                    onChange={(e) => setGroupMessageText(e.target.value)}
                    placeholder={`Message ${activeGroup.name} members...`}
                    className={`flex-1 px-3.5 py-2 rounded-xl border text-xs font-medium ${
                      isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </form>

              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: POST NEW DISCUSSION */}
      {isNewDiscussionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-500" />
                <span>Discuss a Common Problem with Friends</span>
              </h3>
              <button
                onClick={() => setIsNewDiscussionOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateDiscussion} className="space-y-3 text-xs">
              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Problem Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as DiscussionCategory)}
                  className={`w-full px-3 py-2 rounded-xl border font-bold ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="Burnout & Focus">Burnout, Anxiety & Focus Routine</option>
                  <option value="Backlogs & Timetable">Syllabus Backlogs & ABC Revision</option>
                  <option value="Articleship & Career">Articleship & Firm Selection (Big 4 vs Mid-Size)</option>
                  <option value="Subject Concepts">Subject Conceptual Doubt</option>
                  <option value="Exam Strategy">ICAI Exam Strategy & MCQ Tricks</option>
                  <option value="Study Partners">Find Study Group & Accountability Partner</option>
                </select>
              </div>

              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Discussion Title / Problem Headline
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. How do you keep momentum after 6 hours of continuous study?"
                  className={`w-full px-3 py-2 rounded-xl border font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Problem Description / Details
                </label>
                <textarea
                  value={newProblem}
                  onChange={(e) => setNewProblem(e.target.value)}
                  rows={4}
                  placeholder="Describe your challenge in detail so friends and rankers can share specific advice..."
                  className={`w-full px-3 py-2 rounded-xl border font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="e.g. Burnout, Audit, Revision, Big4"
                  className={`w-full px-3 py-2 rounded-xl border font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="askAi"
                  checked={askAiAdvisor}
                  onChange={(e) => setAskAiAdvisor(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="askAi" className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer">
                  <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                  <span>Ask AI CA Senior Mentor to automatically suggest an action plan</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewDiscussionOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-black shadow-md shadow-indigo-500/20 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Posting...' : 'Post Problem Thread'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL: CREATE STUDY GROUP */}
      {isNewGroupModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-500" />
                <span>Create a Friend Study Group</span>
              </h3>
              <button
                onClick={() => setIsNewGroupModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateGroup} className="space-y-3 text-xs">
              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Group Name
                </label>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="e.g. Tax & Law Exemption Squad"
                  className={`w-full px-3 py-2 rounded-xl border font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Group Target / Goal
                </label>
                <input
                  type="text"
                  value={newGroupGoal}
                  onChange={(e) => setNewGroupGoal(e.target.value)}
                  placeholder="e.g. Daily 8-hour study logs + solving 1 RTP daily"
                  className={`w-full px-3 py-2 rounded-xl border font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block font-extrabold text-slate-700 dark:text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={newGroupCategory}
                  onChange={(e) => setNewGroupCategory(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border font-bold ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="Both Groups">Both Groups</option>
                  <option value="Subject Focus">Subject Focus</option>
                  <option value="Career & Articleship">Career & Articleship</option>
                  <option value="Mock Tests">Mock Tests & MCQs</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewGroupModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black shadow-md shadow-purple-500/20 cursor-pointer"
                >
                  Create Study Group
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
