import React, { useState } from 'react';
import { 
  BrainCircuit, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  HelpCircle, 
  Filter, 
  Plus, 
  RotateCcw, 
  Search, 
  CheckCircle, 
  BookOpen, 
  Clock, 
  Award, 
  ChevronRight, 
  XCircle, 
  TrendingUp, 
  Lightbulb, 
  RefreshCw,
  Eye,
  Calculator,
  Bookmark,
  Zap,
  Target
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import { QuestionMistakeLog, MistakeReasonType, MistakePatternSummary, Subject, CourseLevel, ICAIStudentProfile } from '../types';
import { INITIAL_MISTAKE_LOGS, INITIAL_MISTAKE_SUMMARY } from '../data/initialData';

interface MistakeIntelligenceViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  isDarkMode: boolean;
  onNavigate?: (view: string) => void;
  onAwardXp?: (amount: number, reason: string) => void;
}

export const MistakeIntelligenceView: React.FC<MistakeIntelligenceViewProps> = ({
  profile,
  subjects,
  isDarkMode,
  onNavigate,
  onAwardXp
}) => {
  const currentSubjects = subjects.filter(s => s.course === profile.course);
  
  const [mistakeLogs, setMistakeLogs] = useState<QuestionMistakeLog[]>(INITIAL_MISTAKE_LOGS);
  const [mistakeSummary, setMistakeSummary] = useState<MistakePatternSummary>(INITIAL_MISTAKE_SUMMARY);
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // New Mistake Logging Modal State
  const [showLogModal, setShowLogModal] = useState<boolean>(false);
  const [newQuestionText, setNewQuestionText] = useState<string>('');
  const [newSubjectName, setNewSubjectName] = useState<string>(currentSubjects[0]?.name || 'Auditing & Ethics');
  const [newTopicName, setNewTopicName] = useState<string>('');
  const [newSelectedReason, setNewSelectedReason] = useState<MistakeReasonType>('misread_question');
  const [newUserNote, setNewUserNote] = useState<string>('');
  const [newSourceType, setNewSourceType] = useState<'Mock Test' | 'Chapter Test' | 'RTP/MTP' | 'AI Quiz' | 'Self Practice'>('Mock Test');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Quick Interactive Drill State
  const [activeDrillIndex, setActiveDrillIndex] = useState<number | null>(null);
  const [drillResolved, setDrillResolved] = useState<Record<string, boolean>>({});

  // Mistake category definitions with colors and icons
  const mistakeCategories: Array<{
    id: MistakeReasonType;
    label: string;
    shortLabel: string;
    icon: string;
    color: string;
    bgLight: string;
    bgDark: string;
    borderColor: string;
    description: string;
    percentage: number;
  }> = [
    {
      id: 'concept_gap',
      label: "Didn't know concept",
      shortLabel: "Conceptual errors",
      icon: "🟥",
      color: "text-rose-600 dark:text-rose-400",
      bgLight: "bg-rose-50",
      bgDark: "bg-rose-950/40",
      borderColor: "border-rose-200 dark:border-rose-900/40",
      description: "Fundamental gap in understanding the core provision or standard.",
      percentage: mistakeSummary.percentages.conceptual,
    },
    {
      id: 'misread_question',
      label: "Misread question",
      shortLabel: "Question interpretation",
      icon: "🟨",
      color: "text-amber-600 dark:text-amber-400",
      bgLight: "bg-amber-50",
      bgDark: "bg-amber-950/40",
      borderColor: "border-amber-200 dark:border-amber-900/40",
      description: "Overlooked facts, negative stems ('not included'), dates, or entity types.",
      percentage: mistakeSummary.percentages.questionInterpretation,
    },
    {
      id: 'forgot_provision',
      label: "Forgot provision",
      shortLabel: "Memory / Recall",
      icon: "🟦",
      color: "text-blue-600 dark:text-blue-400",
      bgLight: "bg-blue-50",
      bgDark: "bg-blue-950/40",
      borderColor: "border-blue-200 dark:border-blue-900/40",
      description: "Forgot exact numerical threshold, time limit, or recent amendment.",
      percentage: mistakeSummary.percentages.memoryRecall,
    },
    {
      id: 'calculation_mistake',
      label: "Calculation mistake",
      shortLabel: "Calculation errors",
      icon: "🟧",
      color: "text-orange-600 dark:text-orange-400",
      bgLight: "bg-orange-50",
      bgDark: "bg-orange-950/40",
      borderColor: "border-orange-200 dark:border-orange-900/40",
      description: "Sign error, apportionment fraction slip, or hurried arithmetic.",
      percentage: mistakeSummary.percentages.calculation,
    },
    {
      id: 'poor_presentation',
      label: "Poor presentation",
      shortLabel: "Presentation & Format",
      icon: "🟩",
      color: "text-emerald-600 dark:text-emerald-400",
      bgLight: "bg-emerald-50",
      bgDark: "bg-emerald-950/40",
      borderColor: "border-emerald-200 dark:border-emerald-900/40",
      description: "Omitted statutory subheadings, working notes, or concluding paragraph.",
      percentage: 7,
    },
    {
      id: 'time_pressure',
      label: "Time pressure",
      shortLabel: "Time Pressure",
      icon: "⏱️",
      color: "text-purple-600 dark:text-purple-400",
      bgLight: "bg-purple-50",
      bgDark: "bg-purple-950/40",
      borderColor: "border-purple-200 dark:border-purple-900/40",
      description: "Rushed the final solution due to poor clock management.",
      percentage: 3,
    },
    {
      id: 'guess',
      label: "Guess / Unsure",
      shortLabel: "Guess attempt",
      icon: "🎲",
      color: "text-slate-600 dark:text-slate-400",
      bgLight: "bg-slate-50",
      bgDark: "bg-slate-900",
      borderColor: "border-slate-200 dark:border-slate-800",
      description: "Random or 50/50 intuition pick without concrete proof.",
      percentage: 2,
    }
  ];

  // Chart data for visualization
  const chartData = [
    { name: 'Conceptual', value: mistakeSummary.percentages.conceptual, fill: '#f43f5e', icon: '🟥' },
    { name: 'Interpretation', value: mistakeSummary.percentages.questionInterpretation, fill: '#eab308', icon: '🟨' },
    { name: 'Memory Recall', value: mistakeSummary.percentages.memoryRecall, fill: '#3b82f6', icon: '🟦' },
    { name: 'Calculation', value: mistakeSummary.percentages.calculation, fill: '#f97316', icon: '🟧' },
    { name: 'Presentation', value: mistakeSummary.percentages.presentationTime, fill: '#10b981', icon: '🟩' },
  ];

  // Handle Logging a New Question Mistake
  const handleLogNewMistake = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestionText.trim()) return;

    setIsSubmitting(true);
    let aiTip = "Read the question stem twice and underline explicit constraints before starting your answer.";
    let correctAnswerSummary = "Ensure statutory provision and application paragraphs are clearly separated.";

    try {
      const res = await fetch('/api/ai/diagnose-question-mistake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionText: newQuestionText,
          subjectName: newSubjectName,
          selectedReason: newSelectedReason,
          userNote: newUserNote
        })
      });

      const data = await res.json();
      if (data.aiTip) aiTip = data.aiTip;
      if (data.correctAnswerSummary) correctAnswerSummary = data.correctAnswerSummary;
    } catch (err) {
      console.error('Error getting AI tip for question mistake:', err);
    } finally {
      setIsSubmitting(false);
    }

    const newLog: QuestionMistakeLog = {
      id: `mistake_${Date.now()}`,
      questionText: newQuestionText,
      subjectName: newSubjectName,
      topicName: newTopicName || 'General Topic',
      selectedReason: newSelectedReason,
      userNote: newUserNote || 'Self-logged test error',
      correctAnswerSummary,
      aiTip,
      date: new Date().toISOString().split('T')[0],
      sourceType: newSourceType
    };

    setMistakeLogs(prev => [newLog, ...prev]);
    setShowLogModal(false);
    setNewQuestionText('');
    setNewTopicName('');
    setNewUserNote('');

    if (onAwardXp) {
      onAwardXp(30, 'Logged question mistake for cognitive profiling');
    }
  };

  // Toggle resolved state
  const handleToggleResolved = (id: string) => {
    setDrillResolved(prev => {
      const nextState = !prev[id];
      if (nextState && onAwardXp) {
        onAwardXp(50, 'Mastered and resolved past mistake question');
      }
      return { ...prev, [id]: nextState };
    });
  };

  // Filter logs
  const filteredLogs = mistakeLogs.filter(log => {
    const matchesFilter = selectedFilter === 'ALL' || log.selectedReason === selectedFilter;
    const matchesSearch = log.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.subjectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.topicName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.userNote && log.userNote.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-rose-600 dark:text-rose-400">
            <BrainCircuit className="w-4 h-4" />
            <span>AI Mistake Intelligence & Cognitive Profiler</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white">
            Mistake Profile & Root-Cause Pattern
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Every wrong question has a psychological trigger. Identify your error patterns to stop marks leaks.
          </p>
        </div>

        <button
          onClick={() => setShowLogModal(true)}
          className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-2 shadow-md shadow-rose-500/25 cursor-pointer self-start md:self-auto transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Why Did You Get This Wrong? (+ Log Mistake)</span>
        </button>
      </div>

      {/* 💡 HERO STRATEGIC INSIGHT SPOTLIGHT CARD */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border-amber-900/40' 
          : 'bg-gradient-to-r from-amber-50/90 via-orange-50/60 to-yellow-50/70 border-amber-200'
      }`}>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-xl bg-amber-500 text-white font-black text-[11px] flex items-center gap-1.5 shadow-xs">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>AI Strategic Breakthrough</span>
              </span>
              <span className="text-xs font-black uppercase tracking-wider text-amber-800 dark:text-amber-300">
                Pattern Detected Across 100 Questions
              </span>
            </div>

            <h3 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white leading-tight">
              “Your marks can potentially improve faster by working on question interpretation rather than learning new chapters.”
            </h3>

            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {mistakeSummary.fastestImprovementLever}
            </p>
          </div>

          {/* Quick Action Pill */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-amber-200/80 dark:border-amber-900/40 shadow-xs space-y-2 shrink-0 self-stretch lg:self-auto">
            <div className="flex items-center justify-between gap-4 text-xs font-black">
              <span className="text-slate-500">Quickest Mark Gain:</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">+18 to +24 Marks</span>
            </div>
            <div className="text-[11px] text-slate-600 dark:text-slate-400">
              Target: <strong>Question Interpretation Drill</strong>
            </div>
            <button
              onClick={() => setSelectedFilter('misread_question')}
              className="w-full py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Target className="w-3.5 h-3.5" />
              <span>Practice Misread Questions</span>
            </button>
          </div>
        </div>
      </div>

      {/* 📊 100-QUESTIONS MISTAKE PATTERN BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Visual Progress Breakdown (7 cols) */}
        <div className={`lg:col-span-7 p-6 rounded-3xl border space-y-5 ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                  Profiled Over 100 Questions
                </span>
                <span className="text-slate-300 dark:text-slate-700">•</span>
                <span className="text-xs text-slate-500 font-bold">Accuracy Diagnostics</span>
              </div>
              <h3 className="text-base font-black text-slate-900 dark:text-white mt-0.5">
                Your Mistake Pattern
              </h3>
            </div>

            <span className="px-3 py-1 rounded-xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              100 Total Logged
            </span>
          </div>

          {/* 5 Core Pattern Bars Matching User Request */}
          <div className="space-y-4">
            
            {/* 🟥 Conceptual errors — 31% */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
                  <span>🟥</span>
                  <span>Conceptual errors</span>
                  <span className="text-[11px] font-normal text-slate-500">("Didn't know concept")</span>
                </div>
                <span className="font-black text-rose-600 dark:text-rose-400">31%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full transition-all duration-500" style={{ width: '31%' }} />
              </div>
            </div>

            {/* 🟨 Question interpretation — 24% */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
                  <span>🟨</span>
                  <span>Question interpretation</span>
                  <span className="text-[11px] font-normal text-slate-500">("Misread question constraints")</span>
                </div>
                <span className="font-black text-amber-600 dark:text-amber-400">24%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full transition-all duration-500" style={{ width: '24%' }} />
              </div>
            </div>

            {/* 🟦 Memory/recall — 21% */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
                  <span>🟦</span>
                  <span>Memory / recall</span>
                  <span className="text-[11px] font-normal text-slate-500">("Forgot provision / section limits")</span>
                </div>
                <span className="font-black text-blue-600 dark:text-blue-400">21%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full transition-all duration-500" style={{ width: '21%' }} />
              </div>
            </div>

            {/* 🟧 Calculation errors — 12% */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
                  <span>🟧</span>
                  <span>Calculation errors</span>
                  <span className="text-[11px] font-normal text-slate-500">("Arithmetic & fraction slip")</span>
                </div>
                <span className="font-black text-orange-600 dark:text-orange-400">12%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-orange-500 h-full rounded-full transition-all duration-500" style={{ width: '12%' }} />
              </div>
            </div>

            {/* 🟩 Presentation — 12% */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
                  <span>🟩</span>
                  <span>Presentation & Pacing</span>
                  <span className="text-[11px] font-normal text-slate-500">("Poor presentation / time pressure")</span>
                </div>
                <span className="font-black text-emerald-600 dark:text-emerald-400">12%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: '12%' }} />
              </div>
            </div>

          </div>

          <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-2 border-t border-slate-100 dark:border-slate-800">
            <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span>AI continuously recalibrates your profile every time you log a question in tests, quizzes, or flashcards.</span>
          </div>
        </div>

        {/* Right: Distribution Chart & Ranker Strategy (5 cols) */}
        <div className={`lg:col-span-5 p-6 rounded-3xl border space-y-5 ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span>Error Frequency Distribution</span>
          </h3>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: isDarkMode ? '#94a3b8' : '#64748b', fontSize: 10 }} />
                <YAxis tick={{ fill: isDarkMode ? '#94a3b8' : '#64748b', fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="value" name="Percentage (%)" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Targeted AI Prescription Box */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5">
            <div className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>🎯</span>
              <span>The "2-Pass Reading" Protocol:</span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              Pass 1: Read the final question line first to identify what is being asked.<br/>
              Pass 2: Underline 3 things in the stem — <strong>Assessee Type</strong>, <strong>Applicable Financial Year</strong>, and <strong>Exclusion words</strong>.
            </p>
          </div>
        </div>

      </div>

      {/* 📋 MISTAKE LEDGER & DRILL TABLE */}
      <div className={`p-6 rounded-3xl border space-y-5 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        
        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-indigo-500" />
              <span>Logged Question Mistake Ledger</span>
            </h3>
            <p className="text-xs text-slate-500">
              Review specific questions where you tripped up and re-test your understanding.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setSelectedFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                selectedFilter === 'ALL'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              All ({mistakeLogs.length})
            </button>

            {mistakeCategories.slice(0, 5).map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedFilter(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1 ${
                  selectedFilter === cat.id
                    ? `${cat.bgDark || 'bg-slate-800'} text-white shadow-xs`
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.shortLabel}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Question Cards Grid */}
        <div className="grid grid-cols-1 gap-4">
          {filteredLogs.length === 0 ? (
            <div className="p-8 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-2">
              <p className="text-xs text-slate-500">No question mistakes found matching this filter.</p>
              <button
                onClick={() => setSelectedFilter('ALL')}
                className="px-3 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-xs font-bold"
              >
                Clear Filter
              </button>
            </div>
          ) : (
            filteredLogs.map((log) => {
              const catMeta = mistakeCategories.find(c => c.id === log.selectedReason) || mistakeCategories[0];
              const isResolved = drillResolved[log.id];

              return (
                <div
                  key={log.id}
                  className={`p-5 rounded-2xl border transition-all space-y-3.5 ${
                    isResolved
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40 opacity-80'
                      : isDarkMode 
                        ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700' 
                        : 'bg-white border-slate-200/90 hover:border-slate-300 shadow-xs'
                  }`}
                >
                  {/* Top Bar: Subject, Topic & Reason Chip */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                        {log.subjectName}
                      </span>
                      <span className="text-slate-300 dark:text-slate-700">•</span>
                      <span className="text-xs font-bold text-slate-600 dark:text-slate-400">
                        {log.topicName}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1.5 ${catMeta.bgLight} dark:${catMeta.bgDark} ${catMeta.color} ${catMeta.borderColor}`}>
                        <span>{catMeta.icon}</span>
                        <span>{catMeta.label}</span>
                      </span>

                      <span className="text-[10px] text-slate-400 font-semibold">
                        {log.sourceType} • {log.date}
                      </span>
                    </div>
                  </div>

                  {/* Question Text */}
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white leading-relaxed">
                    "{log.questionText}"
                  </div>

                  {/* Student's Reason & Reflection */}
                  {log.userNote && (
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs">
                      <span className="font-extrabold text-slate-500 block text-[10px] uppercase">
                        Why You Got It Wrong:
                      </span>
                      <p className="text-slate-700 dark:text-slate-300 italic mt-0.5">
                        "{log.userNote}"
                      </p>
                    </div>
                  )}

                  {/* AI Ranker Action Tip */}
                  <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-xs flex items-start gap-2.5">
                    <div className="p-1 rounded-md bg-amber-500 text-white shrink-0 mt-0.5">
                      <Sparkles className="w-3.5 h-3.5" />
                    </div>
                    <div className="space-y-0.5">
                      <span className="font-black text-amber-900 dark:text-amber-200 block">
                        AI Ranker Fix:
                      </span>
                      <span className="text-amber-800 dark:text-amber-300 font-medium">
                        {log.aiTip}
                      </span>
                    </div>
                  </div>

                  {/* Bottom Action Row */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-500">
                      Correct Key: <strong>{log.correctAnswerSummary || 'Review standard clauses'}</strong>
                    </span>

                    <button
                      onClick={() => handleToggleResolved(log.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                        isResolved
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{isResolved ? 'Resolved & Mastered' : 'Mark as Resolved (+50 XP)'}</span>
                    </button>
                  </div>

                </div>
              );
            })
          )}
        </div>

      </div>

      {/* 🚀 MODAL: "WHY DID YOU GET THIS WRONG?" LOGGING INTERFACE */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className={`w-full max-w-xl p-6 rounded-3xl border shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-rose-600 text-white">
                  <BrainCircuit className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-black">Why did you get this wrong?</h3>
                  <p className="text-xs text-slate-500">Tag your cognitive error reason to train your Mistake Profile</p>
                </div>
              </div>

              <button
                onClick={() => setShowLogModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-black cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleLogNewMistake} className="space-y-4 text-xs">
              
              {/* Question Text */}
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Question Stem / Problem Summary
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. Whether statutory auditor can accept direct appointment as internal auditor for the same company or its holding subsidiary under Section 144?"
                  value={newQuestionText}
                  onChange={(e) => setNewQuestionText(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium"
                />
              </div>

              {/* Subject & Topic */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Subject
                  </label>
                  <select
                    value={newSubjectName}
                    onChange={(e) => setNewSubjectName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-bold"
                  >
                    {currentSubjects.map(s => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Specific Standard / Section
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. SA 315 / Sec 17(5) / AS 16"
                    value={newTopicName}
                    onChange={(e) => setNewTopicName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium"
                  />
                </div>
              </div>

              {/* The Core 7 Mistake Options */}
              <div className="space-y-2">
                <label className="font-black text-slate-900 dark:text-white block">
                  Select the Exact Reason for Marks Loss:
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {mistakeCategories.map(cat => {
                    const isSelected = newSelectedReason === cat.id;
                    return (
                      <div
                        key={cat.id}
                        onClick={() => setNewSelectedReason(cat.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center gap-2.5 ${
                          isSelected
                            ? 'bg-indigo-50/90 dark:bg-indigo-950/60 border-indigo-600 dark:border-indigo-500 ring-2 ring-indigo-500/20 font-bold'
                            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                        }`}
                      >
                        <span className="text-base">{cat.icon}</span>
                        <div>
                          <div className="font-black text-slate-900 dark:text-white text-xs">
                            {cat.label}
                          </div>
                          <div className="text-[10px] text-slate-500 line-clamp-1">
                            {cat.description}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Reflection notes */}
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  What went wrong in your head? (Personal Reflection)
                </label>
                <input
                  type="text"
                  placeholder="e.g. I knew the rule for private company, but didn't notice the question had a public company..."
                  value={newUserNote}
                  onChange={(e) => setNewUserNote(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium"
                />
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting || !newQuestionText.trim()}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-rose-500/25 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Generating AI Tip...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Log to Mistake Profile (+30 XP)</span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
