import React, { useState } from 'react';
import { 
  Briefcase, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Sparkles, 
  Award, 
  Building2, 
  FileText, 
  Laptop, 
  ChevronRight, 
  ExternalLink, 
  Zap, 
  GraduationCap,
  TrendingUp,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { ICAIStudentProfile, CourseLevel } from '../types';

interface CareerReadinessCardProps {
  profile: ICAIStudentProfile;
  onNavigate?: (view: string) => void;
  isDarkMode: boolean;
}

interface ReadinessRequirement {
  id: string;
  category: 'Mandatory ICAI' | 'Practical Tool' | 'Career Asset';
  title: string;
  description: string;
  completed: boolean;
  icaiMandatory: boolean;
  recommendation: string;
  badgeTag: string;
}

export const CareerReadinessCard: React.FC<CareerReadinessCardProps> = ({
  profile,
  onNavigate,
  isDarkMode,
}) => {
  // Initial ICAI Articleship readiness requirements
  const [requirements, setRequirements] = useState<ReadinessRequirement[]>([
    {
      id: 'icitss_it',
      category: 'Mandatory ICAI',
      title: 'ICITSS - Information Technology (100 Hours)',
      description: 'Mandatory 4-week computer training on MS Office, Tally, and Information Systems before Articleship commencement.',
      completed: true,
      icaiMandatory: true,
      recommendation: 'Completed. Ensure certificate is uploaded on ICAI SSP Portal.',
      badgeTag: 'Mandatory ICAI'
    },
    {
      id: 'icitss_oc',
      category: 'Mandatory ICAI',
      title: 'ICITSS - Orientation Course (15 Days)',
      description: 'Mandatory soft skills, presentation, and etiquette training conducted at ICAI regional branches.',
      completed: true,
      icaiMandatory: true,
      recommendation: 'Completed. Certificate valid for articleship registration.',
      badgeTag: 'Mandatory ICAI'
    },
    {
      id: 'group_clearance',
      category: 'Mandatory ICAI',
      title: 'CA Inter Both Groups Clearance',
      description: 'Under New Scheme of Education and Training (2023+), both Groups of CA Intermediate must be cleared before starting 2-year Articleship.',
      completed: profile.course === 'Final' || profile.articleshipStatus === 'Ongoing' || profile.articleshipStatus === 'Completed',
      icaiMandatory: true,
      recommendation: profile.course === 'Final' 
        ? 'Cleared Both Groups. Ready for Articleship / Final.' 
        : 'In Progress. Clear Group 1 & 2 in upcoming May/Nov attempt.',
      badgeTag: 'Mandatory ICAI'
    },
    {
      id: 'excel_modeling',
      category: 'Practical Tool',
      title: 'Advanced MS Excel & Data Analytics',
      description: 'VLOOKUP/XLOOKUP, Pivot Tables, Financial Modeling, Power Query, and Keyboard Shortcuts used daily in Audit & Taxation.',
      completed: true,
      icaiMandatory: false,
      recommendation: 'Suggested Certification: ICAI Digital Learning Hub (DLH) Advanced Excel Masterclass or Microsoft Office Specialist.',
      badgeTag: 'High Value Skill'
    },
    {
      id: 'tally_gst',
      category: 'Practical Tool',
      title: 'Tally Prime & GST Return Filing (GSTR 1/3B)',
      description: 'Hands-on practical experience in voucher entry, bank reconciliation, and live GST/ITR portal navigation.',
      completed: false,
      icaiMandatory: false,
      recommendation: 'Suggested Action: Complete Tally Essential Level 2 & Practice live GST mock returns on GST Portal Sandbox.',
      badgeTag: 'Missing Skill Gap'
    },
    {
      id: 'audit_paperwork',
      category: 'Practical Tool',
      title: 'Statutory & Internal Audit Working Papers',
      description: 'Understanding SAs (Standards on Auditing), verification of vouchers, fixed assets register, and inventory verification.',
      completed: false,
      icaiMandatory: false,
      recommendation: 'Suggested Action: Review ICAI Technical Guides on Audit of Financial Statements & Internal Control Questionnaires.',
      badgeTag: 'Missing Skill Gap'
    },
    {
      id: 'articleship_resume',
      category: 'Career Asset',
      title: 'CA Articleship Resume & LinkedIn Profile',
      description: '1-Page professional CA Articleship resume highlighting attempt history, ICITSS marks, academic aggregate, and technical skills.',
      completed: true,
      icaiMandatory: false,
      recommendation: 'Resume Ready. Include links to articleship interest areas (Stat Audit, Direct Tax, Management Consulting).',
      badgeTag: 'Career Asset'
    },
  ]);

  const [activeTab, setActiveTab] = useState<'overview' | 'certifications' | 'interview_tips'>('overview');

  const toggleRequirement = (id: string) => {
    setRequirements(prev => prev.map(req => {
      if (req.id === id) {
        return { ...req, completed: !req.completed };
      }
      return req;
    }));
  };

  const totalReqs = requirements.length;
  const completedReqs = requirements.filter(r => r.completed).length;
  const mandatoryReqs = requirements.filter(r => r.icaiMandatory);
  const mandatoryCompleted = mandatoryReqs.filter(r => r.completed).length;

  const scorePercentage = Math.round((completedReqs / totalReqs) * 100);

  const getReadinessTier = (score: number) => {
    if (score >= 85) return { label: 'Big 4 & Top-10 CA Firm Ready 🏆', color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800' };
    if (score >= 60) return { label: 'Mid-Size CA Firm Ready 📈', color: 'text-indigo-500', bg: 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800' };
    return { label: 'In Training Phase (Skill Gaps Identified) ⚠️', color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800' };
  };

  const tier = getReadinessTier(scorePercentage);
  const missingItems = requirements.filter(r => !r.completed);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-600 text-white shadow-md shadow-indigo-500/20">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                ICAI Articleship & Career Readiness Evaluator
              </h3>
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                CA {profile.course}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Automated audit of mandatory ICAI compliance, practical software skills, and top-tier CA firm selection criteria.
            </p>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-fit">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Audit Matrix
          </button>
          <button
            onClick={() => setActiveTab('certifications')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
              activeTab === 'certifications'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Recommended Courses ({missingItems.length})
          </button>
          <button
            onClick={() => setActiveTab('interview_tips')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
              activeTab === 'interview_tips'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Interview Playbook
          </button>
        </div>
      </div>

      {/* Readiness Score Progress Meter */}
      <div className={`p-4 rounded-2xl border ${tier.bg} flex flex-col sm:flex-row items-center justify-between gap-4 transition-all`}>
        <div className="flex items-center gap-4 w-full sm:w-auto">
          <div className="relative flex items-center justify-center shrink-0">
            <svg className="w-16 h-16 transform -rotate-90">
              <circle
                cx="32"
                cy="32"
                r="26"
                stroke="currentColor"
                strokeWidth="6"
                className="text-slate-200 dark:text-slate-700"
                fill="transparent"
              />
              <circle
                cx="32"
                cy="32"
                r="26"
                stroke="currentColor"
                strokeWidth="6"
                className={tier.color}
                strokeDasharray={163}
                strokeDashoffset={163 - (163 * scorePercentage) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <span className="absolute text-sm font-black text-slate-900 dark:text-white">
              {scorePercentage}%
            </span>
          </div>

          <div>
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">
              Readiness Status
            </span>
            <h4 className="text-sm font-black text-slate-900 dark:text-white">
              {tier.label}
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
              {mandatoryCompleted}/{mandatoryReqs.length} Mandatory ICAI Regulations satisfied • {completedReqs}/{totalReqs} total profile requirements met.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          {onNavigate && (
            <button
              onClick={() => onNavigate('icai-verification')}
              className="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-750 transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <GraduationCap className="w-4 h-4 text-indigo-500" />
              <span>Verify SSP Portal</span>
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: OVERVIEW AUDIT MATRIX */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-500" />
              <span>Articleship Eligibility & Skill Checklist (Click to Update Status)</span>
            </h4>
            <span className="text-[10px] text-slate-400 italic">
              Interactive • Click checkbox to mark completed
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {requirements.map((req) => (
              <div
                key={req.id}
                onClick={() => toggleRequirement(req.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                  req.completed
                    ? 'bg-slate-50/80 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 hover:border-emerald-500/40'
                    : 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-900/40 hover:border-amber-500/50'
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  {req.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  ) : (
                    <XCircle className="w-5 h-5 text-amber-500" />
                  )}
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <h5 className={`text-xs font-black ${req.completed ? 'text-slate-800 dark:text-slate-200' : 'text-slate-900 dark:text-white'}`}>
                      {req.title}
                    </h5>
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                      req.icaiMandatory 
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300' 
                        : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                    }`}>
                      {req.badgeTag}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                    {req.description}
                  </p>

                  {!req.completed && (
                    <div className="mt-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[10px] font-bold text-amber-700 dark:text-amber-300 flex items-start gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                      <span>{req.recommendation}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: SUGGESTED CERTIFICATIONS & SKILL GAPS */}
      {activeTab === 'certifications' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-purple-500" />
                <span>Recommended Certifications & Skill Boosters for CA Articleship</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Targeted short courses that distinguish your profile during Big-4 and Top CA Firm Articleship interviews.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Course 1: Advanced Excel */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                    <Laptop className="w-4 h-4" />
                  </span>
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    High Demand
                  </span>
                </div>
                <h5 className="text-xs font-black text-slate-900 dark:text-white">
                  ICAI DLH: Advanced Financial Modeling & Excel
                </h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                  Covers XLOOKUP, INDEX-MATCH, Financial Statements Modeling, Sensitivity Analysis, and Audit Working Paper templates.
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[10px]">
                <span className="font-bold text-slate-400">Duration: 15 Hours</span>
                <span className="font-black text-indigo-600 dark:text-indigo-400">Provider: ICAI DLH</span>
              </div>
            </div>

            {/* Course 2: Tally & GST */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                    <FileText className="w-4 h-4" />
                  </span>
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                    Practical Tax
                  </span>
                </div>
                <h5 className="text-xs font-black text-slate-900 dark:text-white">
                  Tally Prime & Live GST Return Practitioner
                </h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                  Practical walkthrough of GSTR-1, GSTR-3B filing, E-way bills, ITC Reconciliation (2B vs 3B), and TDS Return entry.
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[10px]">
                <span className="font-bold text-slate-400">Duration: 20 Hours</span>
                <span className="font-black text-indigo-600 dark:text-indigo-400">Provider: Tally Education / ICAI</span>
              </div>
            </div>

            {/* Course 3: Statutory Audit SAs */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-600 dark:text-purple-400">
                    <Zap className="w-4 h-4" />
                  </span>
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                    Big 4 Prep
                  </span>
                </div>
                <h5 className="text-xs font-black text-slate-900 dark:text-white">
                  Audit Execution & SA Implementation Masterclass
                </h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                  How to draft Audit Reports, perform analytical procedures (SA 520), evaluate sampling risks (SA 530), and verify CARO 2020 clauses.
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[10px]">
                <span className="font-bold text-slate-400">Duration: 12 Hours</span>
                <span className="font-black text-indigo-600 dark:text-indigo-400">Provider: ICAI Board of Studies</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: INTERVIEW PLAYBOOK */}
      {activeTab === 'interview_tips' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-950 text-white space-y-3 border border-purple-500/30">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-black uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>CA Articleship Interview Blueprint</span>
            </div>

            <h4 className="text-sm font-black">
              Key Questions Top CA Partners Ask in Articleship Rounds:
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 space-y-1">
                <span className="font-black text-amber-300">1. Accounting Standards (AS/Ind AS):</span>
                <p className="text-indigo-100 leading-relaxed">
                  "Explain AS 2 Inventory Valuation rule or AS 16 Borrowing Cost capitalization conditions with a live corporate example."
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 space-y-1">
                <span className="font-black text-amber-300">2. Direct & Indirect Tax Provisions:</span>
                <p className="text-indigo-100 leading-relaxed">
                  "What are the section limits under Sec 194C / 194J TDS, and how do you reconcile GSTR-2B with purchase register?"
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 space-y-1">
                <span className="font-black text-amber-300">3. Practical Tool Testing:</span>
                <p className="text-indigo-100 leading-relaxed">
                  "How do you build a VLOOKUP / INDEX-MATCH formula to compare two trial balances of 10,000 ledger rows?"
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 space-y-1">
                <span className="font-black text-amber-300">4. Domain Preference & Rigor:</span>
                <p className="text-indigo-100 leading-relaxed">
                  "Why do you prefer Statutory Audit over Direct Tax? Are you comfortable with outstation audit travel?"
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
