import React from 'react';
import { 
  ExternalLink, 
  BookOpen, 
  FileText, 
  Award, 
  Newspaper, 
  Globe, 
  ChevronRight 
} from 'lucide-react';
import { ICAI_RESOURCES } from '../data/initialData';
import { CourseLevel } from '../types';

interface ICAIResourcesViewProps {
  course: CourseLevel;
  isDarkMode: boolean;
}

export const ICAIResourcesView: React.FC<ICAIResourcesViewProps> = ({ course, isDarkMode }) => {
  const filteredResources = ICAI_RESOURCES.filter(
    r => r.course === 'All' || r.course === course
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
          <Globe className="w-4 h-4" />
          <span>Official ICAI Student Portals & Materials</span>
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          ICAI Knowledge Hub & Direct Resources
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Direct verified links to ICAI Board of Studies (BOS) portal, study material, RTPs, MTPs & Student Journals.
        </p>
      </div>

      {/* Grid of Resource Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredResources.map((res) => (
          <a
            key={res.id}
            href={res.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`p-5 rounded-2xl border transition-all hover:scale-[1.01] flex flex-col justify-between space-y-3 group ${
              isDarkMode 
                ? 'bg-slate-900 border-slate-800 hover:border-blue-500/50' 
                : 'bg-white border-slate-200 hover:border-blue-400 shadow-sm'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  {res.category}
                </span>
                <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-500 transition-colors" />
              </div>

              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {res.title}
              </h3>

              <p className="text-xs text-slate-500 leading-relaxed">
                {res.description}
              </p>
            </div>

            <div className="flex items-center text-xs font-bold text-blue-600 dark:text-blue-400 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span>Visit Official Portal</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </a>
        ))}
      </div>

    </div>
  );
};
