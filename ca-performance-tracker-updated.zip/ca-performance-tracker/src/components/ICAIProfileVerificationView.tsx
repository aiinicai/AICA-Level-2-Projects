import React, { useState } from 'react';
import { 
  ShieldCheck, 
  UserCheck, 
  Save, 
} from 'lucide-react';
import { ICAIStudentProfile, CourseLevel, ArticleshipStatus } from '../types';

interface ICAIProfileVerificationViewProps {
  profile: ICAIStudentProfile;
  onUpdateProfile: (updated: ICAIStudentProfile) => void;
  isDarkMode: boolean;
}

export const ICAIProfileVerificationView: React.FC<ICAIProfileVerificationViewProps> = ({
  profile,
  onUpdateProfile,
  isDarkMode,
}) => {
  // Form editable state
  const [formProfile, setFormProfile] = useState<ICAIStudentProfile>({ ...profile });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formProfile);
    alert('Profile updated successfully!');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header Banner */}
      <div className={`p-6 rounded-2xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
            <ShieldCheck className="w-4 h-4" />
            <span>ICAI Student Profile</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            Student Identity & Academic Credentials
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage your ICAI student and course details below.
          </p>
        </div>
      </div>

      {/* Editable Student Details Form */}
      <form onSubmit={handleSaveProfile} className={`p-6 rounded-2xl border space-y-6 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2 border-b pb-3 border-slate-200 dark:border-slate-800">
          <UserCheck className="w-4 h-4 text-blue-500" />
          <span>Student Registration & Personal Profile</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Student Full Name
            </label>
            <input
              type="text"
              value={formProfile.name}
              onChange={(e) => setFormProfile({ ...formProfile, name: e.target.value })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={formProfile.email}
              onChange={(e) => setFormProfile({ ...formProfile, email: e.target.value })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Mobile Number
            </label>
            <input
              type="text"
              value={formProfile.mobile}
              onChange={(e) => setFormProfile({ ...formProfile, mobile: e.target.value })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              City
            </label>
            <input
              type="text"
              value={formProfile.city}
              onChange={(e) => setFormProfile({ ...formProfile, city: e.target.value })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ICAI Course Level
            </label>
            <select
              value={formProfile.course}
              onChange={(e) => setFormProfile({ ...formProfile, course: e.target.value as CourseLevel })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Foundation">Foundation</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Final">Final</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Target Exam Attempt
            </label>
            <input
              type="text"
              value={formProfile.attempt}
              onChange={(e) => setFormProfile({ ...formProfile, attempt: e.target.value })}
              placeholder="e.g. May 2026 or Nov 2026"
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Articleship Status
            </label>
            <select
              value={formProfile.articleshipStatus}
              onChange={(e) => setFormProfile({ ...formProfile, articleshipStatus: e.target.value as ArticleshipStatus })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Not Started">Not Started</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Completed">Completed</option>
              <option value="Exempted">Exempted</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Target Exam Date
            </label>
            <input
              type="date"
              value={formProfile.targetExamDate}
              onChange={(e) => setFormProfile({ ...formProfile, targetExamDate: e.target.value })}
              className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>
        </div>

        <div className="pt-4 flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center gap-2 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile Details</span>
          </button>
        </div>
      </form>

    </div>
  );
};
