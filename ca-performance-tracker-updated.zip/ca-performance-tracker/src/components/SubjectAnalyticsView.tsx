import React, { useState } from 'react';
import { 
  BarChart3, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  RotateCcw, 
  Award, 
  TrendingUp, 
  Sparkles,
  BookOpen,
  Search,
  ChevronRight,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  CheckCircle,
  HelpCircle,
  BrainCircuit,
  Bot,
  Flame,
  Filter,
  Plus,
  RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Subject, TestRecord, Chapter, CourseLevel, TopicWeaknessDiagnostic } from '../types';
import { INITIAL_WEAKNESS_DIAGNOSTICS } from '../data/initialData';

interface SubjectAnalyticsViewProps {
  course: CourseLevel;
  subjects: Subject[];
  testRecords: TestRecord[];
  chapters: Chapter[];
  isDarkMode: boolean;
  onNavigate?: (view: string) => void;
}

export const SubjectAnalyticsView: React.FC<SubjectAnalyticsViewProps> = ({
  course,
  subjects,
  testRecords,
  chapters,
  isDarkMode,
  onNavigate
}) => {
  const currentSubjects = subjects.filter(s => s.course === course);

  // Default selected subject (prefer Audit if available, otherwise first subject)
  const defaultSub = currentSubjects.find(s => s.id === 'i_audit') || currentSubjects[0];
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(defaultSub?.id || '');
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'moderate' | 'strong'>('all');
  const [diagnosticsList, setDiagnosticsList] = useState<TopicWeaknessDiagnostic[]>(INITIAL_WEAKNESS_DIAGNOSTICS);
  const [selectedTopicId, setSelectedTopicId] = useState<string>('diag_audit_2'); // default to SA 315

  // Custom AI Diagnostic Tool State
  const [customTopicName, setCustomTopicName] = useState('');
  const [customMistakeNotes, setCustomMistakeNotes] = useState('');
  const [customScorePct, setCustomScorePct] = useState<number>(45);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [aiDiagnosisResult, setAiDiagnosisResult] = useState<TopicWeaknessDiagnostic | null>(null);
  const [showCustomModal, setShowCustomModal] = useState(false);

  // Compute subject-wise analytics metrics
  const analyticsData = currentSubjects.map((sub) => {
    const subChapters = chapters.filter(c => c.subjectId === sub.id);
    const completedChs = subChapters.filter(c => c.status === 'Completed' || c.status === 'Mastered').length;
    const revChs = subChapters.filter(c => c.status === 'Revision 1' || c.status === 'Revision 2' || c.status === 'Mastered').length;
    
    const syllabusPct = subChapters.length > 0 ? Math.round((completedChs / subChapters.length) * 100) : 0;

    const subTests = testRecords.filter(t => t.subjectId === sub.id);
    const avgScore = subTests.length > 0 
      ? Math.round(subTests.reduce((acc, t) => acc + (t.marksObtained / t.maxMarks) * 100, 0) / subTests.length)
      : 0;

    const totalTimeSpentMins = subChapters.reduce((acc, c) => acc + c.timeSpentMins, 0);
    const timeSpentHours = Math.round((totalTimeSpentMins / 60) * 10) / 10;

    // Derived scores
    const strengthScore = Math.min(100, Math.round((avgScore * 0.6) + (syllabusPct * 0.4)));
    const weaknessScore = 100 - strengthScore;
    const accuracyPct = avgScore > 0 ? avgScore : 65;

    let riskIndicator: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    if (strengthScore < 40) riskIndicator = 'Critical';
    else if (strengthScore < 60) riskIndicator = 'High';
    else if (strengthScore < 75) riskIndicator = 'Medium';

    return {
      id: sub.id,
      code: sub.code,
      name: sub.name,
      strengthScore,
      weaknessScore,
      accuracyPct,
      avgScore,
      syllabusPct,
      revisionCount: revChs,
      timeSpentHours,
      recommendedHours: sub.recommendedHours,
      riskIndicator,
      confidenceMeter: strengthScore,
    };
  });

  // Selected subject info
  const activeSubject = currentSubjects.find(s => s.id === selectedSubjectId) || currentSubjects[0];
  const activeSubjectAnalytics = analyticsData.find(a => a.id === selectedSubjectId) || analyticsData[0];

  // Topics for selected subject
  const subjectDiagnostics = diagnosticsList.filter(d => d.subjectId === selectedSubjectId);
  const filteredDiagnostics = subjectDiagnostics.filter(d => {
    if (activeFilter === 'all') return true;
    return d.status === activeFilter;
  });

  // Selected topic diagnostic
  const activeTopicDiagnostic = diagnosticsList.find(d => d.id === selectedTopicId) || subjectDiagnostics[0] || diagnosticsList[0];

  // Run Custom Live AI Diagnosis
  const handleRunAiDiagnosis = async () => {
    if (!customTopicName.trim()) return;
    setIsDiagnosing(true);
    try {
      const response = await fetch('/api/ai/diagnose-weakness-root-cause', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course,
          subjectName: activeSubject?.name || 'CA Intermediate Subject',
          topicName: customTopicName,
          scorePct: customScorePct,
          userMistakes: customMistakeNotes
        })
      });

      const data = await response.json();
      if (data.diagnosis) {
        const newDiag: TopicWeaknessDiagnostic = {
          id: `diag_custom_${Date.now()}`,
          subjectId: selectedSubjectId,
          subjectName: activeSubject?.name || 'Subject',
          topicName: customTopicName,
          scorePct: Number(data.diagnosis.scorePct) || customScorePct,
          status: (Number(data.diagnosis.scorePct) || customScorePct) < 50 ? 'critical' : (Number(data.diagnosis.scorePct) || customScorePct) < 75 ? 'moderate' : 'strong',
          testsAttempted: 1,
          aiIdentifiedProblem: data.diagnosis.aiIdentifiedProblem || 'AI diagnosed underlying application gap in case scenarios.',
          rootCauseCategory: data.diagnosis.rootCauseCategory || 'Application Deficit',
          aiActionPlan: data.diagnosis.aiActionPlan || ['Step 1: Focus on ICAI case facts', 'Step 2: Quote relevant standard clauses'],
          examWeightage: data.diagnosis.examWeightage || '8–10 Marks',
          commonICMITrap: data.diagnosis.commonICMITrap || 'Memorizing keywords without practicing factual application.',
          lastTestedDate: new Date().toISOString().split('T')[0]
        };

        setDiagnosticsList(prev => [newDiag, ...prev]);
        setSelectedTopicId(newDiag.id);
        setAiDiagnosisResult(newDiag);
        setShowCustomModal(false);
        setCustomTopicName('');
        setCustomMistakeNotes('');
      }
    } catch (err) {
      console.error('Error running AI weakness diagnosis:', err);
    } finally {
      setIsDiagnosing(false);
    }
  };

  // Data for Radar Chart
  const radarChartData = analyticsData.map(d => ({
    subject: d.code,
    Strength: d.strengthScore,
    Accuracy: d.accuracyPct,
    Syllabus: d.syllabusPct,
  }));

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400">
            <BarChart3 className="w-4 h-4" />
            <span>CA {course} Subject Performance & Diagnostics</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white">
            Subject Analytics & Deep Weakness Detector
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Don't stop at subject averages like 62%. Uncover the exact underlying reason why you are losing marks.
          </p>
        </div>

        <button
          onClick={() => setShowCustomModal(true)}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center gap-2 shadow-md shadow-indigo-500/20 cursor-pointer self-start md:self-auto transition-all"
        >
          <Sparkles className="w-4 h-4" />
          <span>Diagnose Custom Topic with AI</span>
        </button>
      </div>

      {/* 🔬 FEATURE SPOTLIGHT: DEEP WEAKNESS DETECTOR */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950/40 border-indigo-900/40' 
          : 'bg-gradient-to-b from-white via-indigo-50/30 to-purple-50/40 border-indigo-100 shadow-sm'
      }`}>
        {/* Banner Title */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-200/80 dark:border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-black text-[11px] flex items-center gap-1.5 shadow-xs">
                <BrainCircuit className="w-3.5 h-3.5" />
                <span>AI Weakness Detector</span>
              </span>
              <span className="text-xs font-extrabold uppercase tracking-wide text-indigo-700 dark:text-indigo-300">
                Root-Cause Cognitive Diagnosis
              </span>
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Sub-Topic Accuracy Breakdown & Underlying Problem Identification
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Select any subject to see the micro-level breakdown and AI's deep analysis of your test error patterns.
            </p>
          </div>

          {/* Quick Subject Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60">
            {currentSubjects.map(sub => {
              const isSelected = sub.id === selectedSubjectId;
              return (
                <button
                  key={sub.id}
                  onClick={() => {
                    setSelectedSubjectId(sub.id);
                    const firstDiag = diagnosticsList.find(d => d.subjectId === sub.id);
                    if (firstDiag) setSelectedTopicId(firstDiag.id);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {sub.code} • {sub.name.split(' ')[0]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Core Weakness Inspector: 2 Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
          
          {/* Left Column: Sub-Topic Performance List (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <span>{activeSubject?.name || 'Subject'} Performance</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  Overall Mock Average: <span className="font-extrabold text-slate-900 dark:text-white">{activeSubjectAnalytics?.avgScore || 62}%</span>
                </p>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1 text-[11px]">
                <button
                  onClick={() => setActiveFilter('all')}
                  className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                    activeFilter === 'all'
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setActiveFilter('critical')}
                  className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                    activeFilter === 'critical'
                      ? 'bg-rose-600 text-white'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  🔴 Weak
                </button>
                <button
                  onClick={() => setActiveFilter('moderate')}
                  className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                    activeFilter === 'moderate'
                      ? 'bg-amber-600 text-white'
                      : 'text-amber-600 dark:text-amber-400'
                  }`}
                >
                  🟠 Mid
                </button>
                <button
                  onClick={() => setActiveFilter('strong')}
                  className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                    activeFilter === 'strong'
                      ? 'bg-emerald-600 text-white'
                      : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  🟢 Strong
                </button>
              </div>
            </div>

            {/* List of Sub-Topics with percentages and status dot */}
            <div className="space-y-2.5">
              {filteredDiagnostics.length === 0 ? (
                <div className="p-6 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-2">
                  <p className="text-xs text-slate-500">No sub-topics logged under this filter for {activeSubject?.name}.</p>
                  <button
                    onClick={() => setShowCustomModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-xs font-bold"
                  >
                    + Add Topic Diagnosis with AI
                  </button>
                </div>
              ) : (
                filteredDiagnostics.map((topic) => {
                  const isSelected = topic.id === activeTopicDiagnostic?.id;
                  const isCritical = topic.scorePct < 50;
                  const isModerate = topic.scorePct >= 50 && topic.scorePct < 75;
                  const isStrong = topic.scorePct >= 75;

                  return (
                    <div
                      key={topic.id}
                      onClick={() => setSelectedTopicId(topic.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-white dark:bg-slate-900 border-indigo-600 dark:border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                          : 'bg-white/70 dark:bg-slate-900/60 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Status Indicator Icon */}
                        <div className={`w-3 h-3 rounded-full shrink-0 ${
                          isCritical ? 'bg-rose-500 ring-4 ring-rose-500/20' :
                          isModerate ? 'bg-amber-500 ring-4 ring-amber-500/20' :
                          'bg-emerald-500 ring-4 ring-emerald-500/20'
                        }`} />

                        <div className="min-w-0">
                          <div className="text-xs font-black text-slate-900 dark:text-white truncate">
                            {topic.topicName}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-500">
                            <span>Weightage: {topic.examWeightage}</span>
                            <span>•</span>
                            <span>{topic.testsAttempted} Tests</span>
                          </div>
                        </div>
                      </div>

                      {/* Percentage Badge */}
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`px-2.5 py-1 rounded-xl text-xs font-black ${
                          isCritical
                            ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/40'
                            : isModerate
                              ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-900/40'
                              : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/40'
                        }`}>
                          {topic.scorePct}% {isCritical ? '🔴' : isModerate ? '🟠' : '🟢'}
                        </span>
                        <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${isSelected ? 'translate-x-0.5 text-indigo-600' : ''}`} />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Column: AI Underlying Problem Detective (7 cols) */}
          <div className="lg:col-span-7">
            {activeTopicDiagnostic ? (
              <div className={`p-5 md:p-6 rounded-3xl border space-y-5 ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 shadow-sm' 
                  : 'bg-white border-slate-200 shadow-sm'
              }`}>
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                        {activeTopicDiagnostic.subjectName}
                      </span>
                      <span className="text-slate-300 dark:text-slate-700">•</span>
                      <span className="text-xs font-bold text-slate-500">
                        ICAI Weightage: {activeTopicDiagnostic.examWeightage}
                      </span>
                    </div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                      {activeTopicDiagnostic.topicName}
                    </h3>
                  </div>

                  {/* Accuracy Chip */}
                  <div className="flex items-center gap-2 self-start sm:self-auto">
                    <span className={`px-3 py-1.5 rounded-2xl text-xs font-black flex items-center gap-1.5 ${
                      activeTopicDiagnostic.scorePct < 50
                        ? 'bg-rose-500 text-white shadow-sm shadow-rose-500/20'
                        : activeTopicDiagnostic.scorePct < 75
                          ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/20'
                          : 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/20'
                    }`}>
                      <span>Score: {activeTopicDiagnostic.scorePct}%</span>
                      <span>{activeTopicDiagnostic.scorePct < 50 ? '🔴' : activeTopicDiagnostic.scorePct < 75 ? '🟠' : '🟢'}</span>
                    </span>
                  </div>
                </div>

                {/* 🎯 The Underlying Problem Callout Box */}
                <div className={`p-4 md:p-5 rounded-2xl border ${
                  activeTopicDiagnostic.scorePct < 50
                    ? 'bg-rose-50/80 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/40 text-rose-950 dark:text-rose-200'
                    : activeTopicDiagnostic.scorePct < 75
                      ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/40 text-amber-950 dark:text-amber-200'
                      : 'bg-emerald-50/80 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/40 text-emerald-950 dark:text-emerald-200'
                }`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-xl shrink-0 ${
                      activeTopicDiagnostic.scorePct < 50
                        ? 'bg-rose-600 text-white shadow-xs'
                        : activeTopicDiagnostic.scorePct < 75
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'bg-emerald-600 text-white shadow-xs'
                    }`}>
                      <AlertTriangle className="w-4 h-4" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-black uppercase tracking-wider">
                          AI Underlying Problem Diagnosis
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-extrabold bg-white dark:bg-slate-900 shadow-2xs">
                          {activeTopicDiagnostic.rootCauseCategory}
                        </span>
                      </div>
                      
                      <p className="text-sm font-extrabold leading-relaxed text-slate-900 dark:text-white">
                        "{activeTopicDiagnostic.aiIdentifiedProblem}"
                      </p>
                    </div>
                  </div>
                </div>

                {/* Common ICAI Trap */}
                {activeTopicDiagnostic.commonICMITrap && (
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
                    <div className="p-1.5 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 shrink-0 mt-0.5">
                      <Lightbulb className="w-4 h-4" />
                    </div>
                    <div className="text-xs space-y-0.5">
                      <span className="font-extrabold text-slate-900 dark:text-white block">
                        ICAI Examination Trap Alert:
                      </span>
                      <span className="text-slate-600 dark:text-slate-400">
                        {activeTopicDiagnostic.commonICMITrap}
                      </span>
                    </div>
                  </div>
                )}

                {/* 3-Step Precision Action Plan */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span>AI Prescribed 3-Step Remediation Plan</span>
                    </h4>
                    <span className="text-[10px] text-slate-400 font-bold">Immediate Fix</span>
                  </div>

                  <div className="space-y-2">
                    {activeTopicDiagnostic.aiActionPlan.map((step, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/80 flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300"
                      >
                        <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-black text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed font-medium">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Direct Action Buttons */}
                <div className="flex flex-wrap items-center gap-2.5 pt-2">
                  {onNavigate && (
                    <button
                      onClick={() => onNavigate('today-ai-plan')}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm shadow-indigo-500/25 transition-all cursor-pointer"
                    >
                      <Bot className="w-3.5 h-3.5" />
                      <span>Add to Today's AI Plan</span>
                    </button>
                  )}

                  {onNavigate && (
                    <button
                      onClick={() => onNavigate('flashcards')}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <BrainCircuit className="w-3.5 h-3.5 text-purple-500" />
                      <span>Review Flashcards</span>
                    </button>
                  )}

                  {onNavigate && (
                    <button
                      onClick={() => onNavigate('academic-tracker')}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Award className="w-3.5 h-3.5 text-rose-500" />
                      <span>Log New Test Mark</span>
                    </button>
                  )}
                </div>

              </div>
            ) : (
              <div className="p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
                <BrainCircuit className="w-10 h-10 text-slate-400 mx-auto" />
                <h4 className="text-sm font-black text-slate-900 dark:text-white">Select a Sub-Topic on the Left</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Click any topic (like SA 315 or GST ITC) to inspect the AI's deep root-cause diagnostic.
                </p>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Recharts Visualizations Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Radar Chart */}
        <div className={`p-5 rounded-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span>Multi-Axis Subject Readiness Radar</span>
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarChartData}>
                <PolarGrid stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
                <PolarAngleAxis dataKey="subject" tick={{ fill: isDarkMode ? '#94a3b8' : '#64748b', fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
                <Radar name="Strength" dataKey="Strength" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.4} />
                <Radar name="Accuracy" dataKey="Accuracy" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                <Tooltip />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Hours Spent vs Recommended Hours */}
        <div className={`p-5 rounded-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-500" />
            <span>Time Invested vs Recommended Hours</span>
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData}>
                <XAxis dataKey="code" stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={11} />
                <YAxis stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={11} />
                <Tooltip />
                <Legend />
                <Bar dataKey="timeSpentHours" name="Logged Hours" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="recommendedHours" name="Recommended Hours" fill="#94a3b8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Detailed Subject Analytics Grid */}
      <div>
        <div className="mb-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
            All Papers Readiness Overview
          </h3>
          <p className="text-xs text-slate-500">
            Click on any card to switch deep weakness analysis above.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {analyticsData.map((item) => {
            const isSelected = item.id === selectedSubjectId;
            return (
              <div
                key={item.id}
                onClick={() => {
                  setSelectedSubjectId(item.id);
                  const firstDiag = diagnosticsList.find(d => d.subjectId === item.id);
                  if (firstDiag) setSelectedTopicId(firstDiag.id);
                }}
                className={`p-5 rounded-2xl border space-y-4 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-white dark:bg-slate-900 border-indigo-600 dark:border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                    : isDarkMode 
                      ? 'bg-slate-900 border-slate-800 hover:border-slate-700' 
                      : 'bg-white border-slate-200 shadow-sm hover:border-slate-300'
                }`}
              >
                {/* Top Bar */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                    {item.code}
                  </span>

                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    item.riskIndicator === 'Low'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                      : item.riskIndicator === 'Medium'
                        ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                        : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                  }`}>
                    {item.riskIndicator} Risk
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white line-clamp-1">
                    {item.name}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Confidence Score: <strong className="text-slate-900 dark:text-white">{item.confidenceMeter}%</strong>
                  </p>
                </div>

                {/* Metrics Breakdown */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-semibold block">Strength Score</span>
                    <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">{item.strengthScore}%</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-semibold block">Mock Avg Marks</span>
                    <span className="text-sm font-black text-blue-600 dark:text-blue-400">{item.avgScore > 0 ? `${item.avgScore}%` : 'N/A'}</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-semibold block">Revisions Done</span>
                    <span className="text-sm font-black text-purple-600 dark:text-purple-400">{item.revisionCount} Chapters</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-semibold block">Time Invested</span>
                    <span className="text-sm font-black text-amber-600 dark:text-amber-400">{item.timeSpentHours} Hrs</span>
                  </div>
                </div>

                {/* Confidence Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-semibold text-slate-500">
                    <span>Subject Readiness</span>
                    <span>{item.confidenceMeter}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 h-full rounded-full" 
                      style={{ width: `${item.confidenceMeter}%` }}
                    />
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Custom AI Weakness Diagnosis */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className={`w-full max-w-lg p-6 rounded-3xl border shadow-2xl space-y-4 ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-600 text-white">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-black">AI Topic Root-Cause Detective</h3>
                  <p className="text-xs text-slate-500">Diagnose the underlying reason behind lost marks in any CA topic</p>
                </div>
              </div>
              <button
                onClick={() => setShowCustomModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-black cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Subject
                </label>
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-bold"
                >
                  {currentSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.code} – {s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Specific Standard, Section, or Topic
                </label>
                <input
                  type="text"
                  placeholder="e.g. SA 560 Subsequent Events or GST Blocked Credit Sec 17(5)"
                  value={customTopicName}
                  onChange={(e) => setCustomTopicName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Approximate Score / Accuracy Percentage: <span className="font-black text-indigo-600">{customScorePct}%</span>
                </label>
                <input
                  type="range"
                  min={10}
                  max={95}
                  value={customScorePct}
                  onChange={(e) => setCustomScorePct(Number(e.target.value))}
                  className="w-full cursor-pointer accent-indigo-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  What mistakes do you usually make? (Optional)
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. I remember the definition but get confused when applying to a case with multiple conditions..."
                  value={customMistakeNotes}
                  onChange={(e) => setCustomMistakeNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 font-medium"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setShowCustomModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRunAiDiagnosis}
                disabled={isDiagnosing || !customTopicName.trim()}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-indigo-500/25 cursor-pointer"
              >
                {isDiagnosing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing Error Patterns...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Run AI Diagnosis</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
