import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Flame, 
  Target, 
  Clock, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  AlertTriangle, 
  BookOpen, 
  Plus, 
  ArrowUpRight, 
  Zap, 
  ShieldCheck, 
  ChevronRight,
  BrainCircuit,
  BarChart2,
  Users,
  Bot,
  PenTool,
  Star,
  GraduationCap
} from 'lucide-react';
import { ICAIStudentProfile, Subject, TestRecord, Goal, Chapter, AIDailyBriefing } from '../types';
import { CareerReadinessCard } from './CareerReadinessCard';
import { AIDailyBriefingHero } from './AIDailyBriefingHero';

interface DashboardViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  testRecords: TestRecord[];
  goals: Goal[];
  chapters: Chapter[];
  onNavigate: (view: string) => void;
  isDarkMode: boolean;
  onOpenAddTestModal: () => void;
  briefing?: AIDailyBriefing;
  onTogglePriority?: (id: string) => void;
  onOpenBriefingModal?: () => void;
  onRefreshBriefing?: () => void;
  isRefreshingBriefing?: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  subjects,
  testRecords,
  goals,
  chapters,
  onNavigate,
  isDarkMode,
  onOpenAddTestModal,
  briefing,
  onTogglePriority,
  onOpenBriefingModal,
  onRefreshBriefing,
  isRefreshingBriefing,
}) => {
  // Countdown state
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0 });

  useEffect(() => {
    const calculateCountdown = () => {
      const examDate = new Date(profile.targetExamDate || '2026-05-02T09:00:00').getTime();
      const now = new Date().getTime();
      const diff = examDate - now;

      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setTimeLeft({ days, hours, minutes });
      }
    };

    calculateCountdown();
    const interval = setInterval(calculateCountdown, 60000);
    return () => clearInterval(interval);
  }, [profile.targetExamDate]);

  // Derived metrics
  const levelSubjects = subjects.filter(s => s.course === profile.course);
  
  const totalTests = testRecords.length;
  const avgMockScore = totalTests > 0
    ? Math.round(testRecords.reduce((acc, t) => acc + (t.marksObtained / t.maxMarks) * 100, 0) / totalTests)
    : 0;

  const totalChaptersCount = chapters.length;
  const completedChaptersCount = chapters.filter(c => c.status === 'Completed' || c.status === 'Mastered').length;
  const syllabusCompletionPct = totalChaptersCount > 0 
    ? Math.round((completedChaptersCount / totalChaptersCount) * 100) 
    : 0;

  // AI Readiness Score
  const aiReadinessScore = Math.min(100, Math.round((avgMockScore * 0.5) + (syllabusCompletionPct * 0.4) + (Math.min(profile.streakDays, 30) * 0.33)));

  // Time greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  const dailyGoals = goals.filter(g => g.category === 'Daily');
  const dailyCompleted = dailyGoals.filter(g => g.completed).length;
  const dailyPct = dailyGoals.length > 0 ? Math.round((dailyCompleted / dailyGoals.length) * 100) : 75;

  return (
    <div className="space-y-6">
      
      {/* ☀️ AI Daily Briefing Hero (Personal Coach Command Center) */}
      {briefing && (
        <AIDailyBriefingHero
          briefing={briefing}
          profile={profile}
          onNavigate={onNavigate}
          onTogglePriority={onTogglePriority || (() => {})}
          onOpenModal={onOpenBriefingModal || (() => {})}
          onRefreshBriefing={onRefreshBriefing || (() => {})}
          isRefreshing={isRefreshingBriefing}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 4 Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Exam Readiness */}
        <div className="bg-gradient-to-br from-indigo-50/80 via-white to-purple-50/50 dark:from-indigo-950/40 dark:via-slate-900 dark:to-purple-950/20 p-4 rounded-2xl border border-indigo-200/80 dark:border-indigo-900/40 shadow-sm flex flex-col justify-between relative overflow-hidden group hover:shadow-md transition-all">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              Exam Readiness
            </p>
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
              <BrainCircuit className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-end justify-between mt-2">
            <h2 className="text-3xl font-black bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-300 bg-clip-text text-transparent">
              {aiReadinessScore || 78.4}%
            </h2>
            <span className="text-[10px] px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-extrabold rounded-full border border-emerald-300 dark:border-emerald-800">
              +2.1%
            </span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800/80 mt-3 rounded-full overflow-hidden p-0.5">
            <div 
              className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${aiReadinessScore || 78.4}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Avg Mock Score */}
        <div className="bg-gradient-to-br from-cyan-50/80 via-white to-blue-50/50 dark:from-cyan-950/40 dark:via-slate-900 dark:to-blue-950/20 p-4 rounded-2xl border border-cyan-200/80 dark:border-cyan-900/40 shadow-sm flex flex-col justify-between relative overflow-hidden group hover:shadow-md transition-all">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-wider">
              Avg Mock Score
            </p>
            <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-600 dark:text-cyan-400">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-end mt-2">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white">
              {avgMockScore || 64}
            </h2>
            <span className="text-cyan-600 dark:text-cyan-400 font-extrabold ml-1 text-sm">/ 100</span>
          </div>
          <p className="text-[10px] text-cyan-700 dark:text-cyan-300 font-bold mt-2 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Consistent growth on ICAI pattern
          </p>
        </div>

        {/* Metric 3: Hours Invested */}
        <div className="bg-gradient-to-br from-emerald-50/80 via-white to-teal-50/50 dark:from-emerald-950/40 dark:via-slate-900 dark:to-teal-950/20 p-4 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/40 shadow-sm flex flex-col justify-between relative overflow-hidden group hover:shadow-md transition-all">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              Hours Invested
            </p>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-end mt-2">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white">
              428
            </h2>
            <span className="text-emerald-600 dark:text-emerald-400 font-extrabold ml-1 text-sm">hours</span>
          </div>
          <p className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold mt-2">
            ⚡ 8.2 hrs avg daily revision
          </p>
        </div>

        {/* Metric 4: Days to Exam (Vibrant Colorful Mesh Gradient Card) */}
        <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white p-4 rounded-2xl shadow-md border border-purple-400/20 flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between z-10">
            <p className="text-[11px] font-black text-amber-300 uppercase tracking-wider">
              Days to ICAI Exam
            </p>
            <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
          </div>
          <div className="flex items-baseline mt-2 z-10">
            <h2 className="text-3xl font-black text-amber-300">{timeLeft.days || 52}</h2>
            <span className="text-amber-200/80 font-extrabold ml-1 text-xs">Days</span>
            <h2 className="text-2xl font-black text-white ml-3">{timeLeft.hours || 14}</h2>
            <span className="text-purple-200/80 font-extrabold ml-1 text-xs">Hours</span>
          </div>
          <p className="text-[10px] text-pink-200 mt-2 font-black z-10 flex items-center gap-1">
            🔥 Target: Group 2 Revision Cycle
          </p>
          <div className="absolute -bottom-8 -right-8 w-28 h-28 bg-pink-500/30 rounded-full blur-2xl pointer-events-none" />
        </div>

      </div>

      {/* 🤖 Today's AI Plan Spotlight Card */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950/50 to-purple-950/40 border-indigo-900/50' 
          : 'bg-gradient-to-r from-indigo-50/90 via-purple-50/70 to-pink-50/50 border-indigo-100'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-indigo-600 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-xs">
                <Bot className="w-3.5 h-3.5" />
                <span>Today's AI Plan</span>
              </span>
              <span className="text-[11px] font-black uppercase text-indigo-700 dark:text-indigo-300">
                Diagnostic-Driven Schedule
              </span>
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              Personalized Focus Blocks for CA {profile.course}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-xl">
              AI calibrated tasks based on your test error records, weak SA standards, and ICAI exam importance.
            </p>
          </div>

          <button
            onClick={() => onNavigate('today-ai-plan')}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-indigo-500/25 transition-all cursor-pointer shrink-0"
          >
            <span>Open Interactive AI Plan</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Preview Task Chips */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-5">
          
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-extrabold text-slate-900 dark:text-white">2:00–3:30 PM</span>
              <span className="font-black text-indigo-600 dark:text-indigo-400">Audit</span>
            </div>
            <div className="text-xs font-black text-slate-800 dark:text-slate-200 truncate">
              📖 SA 315
            </div>
            <div className="text-[10px] text-rose-600 dark:text-rose-400 font-bold bg-rose-50 dark:bg-rose-950/40 p-1.5 rounded-lg border border-rose-100 dark:border-rose-900/30">
              Reason: Last 3 tests show 54% accuracy.
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-extrabold text-slate-900 dark:text-white">3:45–4:30 PM</span>
              <span className="font-black text-purple-600 dark:text-purple-400">Tax</span>
            </div>
            <div className="text-xs font-black text-slate-800 dark:text-slate-200 truncate">
              📖 GST – ITC
            </div>
            <div className="text-[10px] text-amber-700 dark:text-amber-300 font-bold bg-amber-50 dark:bg-amber-950/40 p-1.5 rounded-lg border border-amber-100 dark:border-amber-900/30">
              Reason: High exam importance + low retention.
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-extrabold text-slate-900 dark:text-white">5:00–5:30 PM</span>
              <span className="font-black text-emerald-600 dark:text-emerald-400">Practice</span>
            </div>
            <div className="text-xs font-black text-slate-800 dark:text-slate-200 truncate">
              🎯 20 questions from exams
            </div>
            <div className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold bg-emerald-50 dark:bg-emerald-950/40 p-1.5 rounded-lg border border-emerald-100 dark:border-emerald-900/30">
              Reason: Speed & pattern familiarity.
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-extrabold text-slate-900 dark:text-white">9:00–9:15 PM</span>
              <span className="font-black text-cyan-600 dark:text-cyan-400">Revision</span>
            </div>
            <div className="text-xs font-black text-slate-800 dark:text-slate-200 truncate">
              🔁 Revise weak concepts
            </div>
            <div className="text-[10px] text-cyan-700 dark:text-cyan-300 font-bold bg-cyan-50 dark:bg-cyan-950/40 p-1.5 rounded-lg border border-cyan-100 dark:border-cyan-900/30">
              Reason: Overnight memory consolidation.
            </div>
          </div>

        </div>
      </div>

      {/* 🧠 Mistake Intelligence & Cognitive Profiler Dashboard Banner */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-rose-950/30 to-amber-950/30 border-rose-900/40' 
          : 'bg-gradient-to-r from-rose-50/90 via-amber-50/60 to-orange-50/50 border-rose-200/80'
      }`}>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-rose-600 text-white text-[11px] font-black flex items-center gap-1 shadow-xs">
                <BrainCircuit className="w-3.5 h-3.5" />
                <span>Mistake Intelligence</span>
              </span>
              <span className="text-[11px] font-black uppercase text-amber-800 dark:text-amber-300">
                100-Question Error Profile Active
              </span>
            </div>

            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              “Your marks can potentially improve faster by working on question interpretation rather than learning new chapters.”
            </h3>

            {/* Quick 5-Pill Pattern Strip */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span>🟥</span>
                <span>Conceptual: <strong>31%</strong></span>
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/40 text-[11px] font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                <span>🟨</span>
                <span>Question Interpretation: <strong>24%</strong></span>
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span>🟦</span>
                <span>Memory/Recall: <strong>21%</strong></span>
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span>🟧</span>
                <span>Calculation: <strong>12%</strong></span>
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span>🟩</span>
                <span>Presentation: <strong>12%</strong></span>
              </span>
            </div>
          </div>

          <button
            onClick={() => onNavigate('mistake-intelligence')}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-rose-500/25 transition-all cursor-pointer shrink-0 self-start lg:self-auto"
          >
            <span>Explore Mistake Profile</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 🎓 AI Examiner Mode Spotlight Banner */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/70 border-purple-900/50' 
          : 'bg-gradient-to-r from-purple-50/90 via-indigo-50/60 to-pink-50/50 border-purple-200'
      }`}>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-purple-600 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-xs">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Examiner Mode</span>
              </span>
              <span className="text-[11px] font-black uppercase text-purple-700 dark:text-purple-300">
                ICAI Chief Examiner Rigorous Simulation
              </span>
            </div>

            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-snug">
              Simulate Real ICAI Case Studies: <span className="text-purple-600 dark:text-purple-400">Subject + Topic + Difficulty → Instant Chief Examiner Evaluation</span>
            </h3>

            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl">
              Select <strong>Audit (SA 315)</strong>, <strong>Direct Tax (Sec 115BAC)</strong> or any Ind AS. AI grades on 5 criteria (Concept, Application, Provisions, Presentation, Conclusion /10), estimates marks, and reveals <strong>What you should have written</strong> & <strong>Why you lost marks</strong>.
            </p>
          </div>

          <button
            onClick={() => onNavigate('ai-examiner')}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-purple-500/25 transition-all cursor-pointer shrink-0 self-start lg:self-auto"
          >
            <span>Launch Examiner Mode</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ✍️ Answer Writing Coach Spotlight Banner */}
      <div className={`p-6 rounded-3xl border shadow-sm transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950/60 to-purple-950/40 border-indigo-900/50' 
          : 'bg-gradient-to-r from-indigo-50/90 via-blue-50/60 to-purple-50/50 border-indigo-100'
      }`}>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-indigo-600 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-xs">
                <PenTool className="w-3.5 h-3.5" />
                <span>Answer Writing Coach</span>
              </span>
              <span className="text-[11px] font-black uppercase text-indigo-700 dark:text-indigo-300">
                CA Final & Inter Descriptive Masterclass
              </span>
            </div>

            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-snug">
              Master the 4-Tier Blueprint: <span className="text-indigo-600 dark:text-indigo-400">Issue → Provision → Application → Conclusion</span>
            </h3>

            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl">
              Upload or type your case study answer. AI scans for missing keywords & sections, evaluates 5 criteria (Structure, Technical Content, Application, Conclusion, Presentation), and provides the better answer framework.
            </p>
          </div>

          <button
            onClick={() => onNavigate('answer-coach')}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-indigo-500/25 transition-all cursor-pointer shrink-0 self-start lg:self-auto"
          >
            <span>Practice Descriptive Answers</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 12-Column Main Section: Analytics + AI Coach */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 8 Cols: Subject Performance Analytics */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-500" />
              <h3 className="font-extrabold text-slate-900 dark:text-white">
                Subject Performance Analytics
              </h3>
            </div>
            <div className="flex gap-3">
              <span className="flex items-center gap-1.5 text-[10px] font-black text-slate-600 dark:text-slate-300">
                <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500" /> Actual Score
              </span>
              <span className="flex items-center gap-1.5 text-[10px] font-black text-slate-400">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-200 dark:bg-slate-800" /> Target
              </span>
            </div>
          </div>

          {/* Bar Chart Bars with Vibrant Color Gradients */}
          <div className="flex-1 flex items-end justify-around pb-2 px-2 min-h-[220px]">
            {[
              { label: 'FR', actualH: 'h-32', expH: 'h-40', color: 'bg-gradient-to-t from-indigo-600 to-purple-500 shadow-indigo-500/20' },
              { label: 'AFM', actualH: 'h-28', expH: 'h-32', color: 'bg-gradient-to-t from-blue-600 to-cyan-500 shadow-blue-500/20' },
              { label: 'Audit', actualH: 'h-24', expH: 'h-44', color: 'bg-gradient-to-t from-rose-600 to-pink-500 shadow-rose-500/20' },
              { label: 'DT', actualH: 'h-34', expH: 'h-36', color: 'bg-gradient-to-t from-emerald-600 to-teal-500 shadow-emerald-500/20' },
              { label: 'IDT', actualH: 'h-30', expH: 'h-40', color: 'bg-gradient-to-t from-sky-600 to-indigo-500 shadow-sky-500/20' },
              { label: 'IBS', actualH: 'h-38', expH: 'h-48', color: 'bg-gradient-to-t from-purple-600 to-fuchsia-500 shadow-purple-500/20' },
            ].map((bar, i) => (
              <div key={i} className="flex flex-col items-center gap-2 group">
                <div className="relative flex gap-1 items-end">
                  <div className={`w-10 sm:w-12 bg-slate-100 dark:bg-slate-800/80 rounded-t-xl ${bar.expH}`} />
                  <div className={`absolute bottom-0 w-10 sm:w-12 ${bar.color} rounded-t-xl shadow-md ${bar.actualH} group-hover:brightness-110 transition-all`} />
                </div>
                <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">{bar.label}</p>
              </div>
            ))}
          </div>

          {/* Key Insights Stats at bottom of card */}
          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900/40">
              <Award className="w-6 h-6 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div className="flex flex-col">
                <span className="text-[10px] uppercase font-black text-emerald-700 dark:text-emerald-400">Strongest Subject</span>
                <span className="text-xs font-black text-slate-900 dark:text-white">Financial Reporting (74% Avg)</span>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/80 dark:border-rose-900/40">
              <AlertTriangle className="w-6 h-6 text-rose-600 dark:text-rose-400 shrink-0" />
              <div className="flex flex-col">
                <span className="text-[10px] uppercase font-black text-rose-700 dark:text-rose-400">Critical Weakness</span>
                <span className="text-xs font-black text-slate-900 dark:text-white">Audit Professional Ethics (42%)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: AI Personal Coach + Deadlines */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* AI Personal Coach Card */}
          <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 rounded-2xl p-6 text-white flex-1 relative overflow-hidden shadow-lg border border-purple-500/30 flex flex-col justify-between">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-1.5 rounded-lg bg-pink-500/20 border border-pink-400/30">
                  <Sparkles className="w-5 h-5 text-pink-300 animate-pulse" />
                </div>
                <h3 className="font-extrabold text-base tracking-tight text-white">AI Personal Mentor</h3>
              </div>

              <div className="space-y-4">
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/15">
                  <p className="text-[10px] text-amber-300 uppercase font-black tracking-widest">Daily Strategic Advice</p>
                  <p className="text-xs sm:text-sm mt-1.5 leading-relaxed text-indigo-100 font-medium">
                    "{profile.name}, prioritize Direct Tax Transfer Pricing today. Your mock scores dipped in international tax. Dedicate 3 hours to case studies."
                  </p>
                </div>

                <div className="flex gap-3 mt-4">
                  <div className="flex-1 bg-white/10 backdrop-blur-md rounded-xl p-2.5 text-center border border-white/10">
                    <p className="text-[10px] opacity-80 uppercase font-bold text-indigo-200">Focus Index</p>
                    <p className="font-black text-xl text-emerald-300">8.8/10</p>
                  </div>
                  <div className="flex-1 bg-white/10 backdrop-blur-md rounded-xl p-2.5 text-center border border-white/10">
                    <p className="text-[10px] opacity-80 uppercase font-bold text-indigo-200">Morale State</p>
                    <p className="font-black text-xl text-amber-300">Peak 🔥</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => onNavigate('ai-coach')}
                className="w-full bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 text-slate-950 font-black py-3 rounded-xl mt-6 text-xs uppercase tracking-wider shadow-lg shadow-orange-500/25 hover:brightness-110 transition-all"
              >
                Launch AI Assistant
              </button>
            </div>
            {/* Background Blur Orbs */}
            <div className="absolute -bottom-10 -right-10 w-44 h-44 bg-pink-500/25 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -top-10 -left-10 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />
          </div>

          {/* Upcoming Deadlines */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
            <h3 className="font-bold text-slate-800 dark:text-white text-sm mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span>Upcoming Deadlines</span>
            </h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-2 rounded-xl bg-orange-50/60 dark:bg-orange-950/30 border border-orange-200/60 dark:border-orange-900/40">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 text-white flex flex-col items-center justify-center shrink-0 shadow-xs">
                  <span className="text-[9px] font-black leading-none uppercase">OCT</span>
                  <span className="text-sm font-black leading-none mt-0.5">12</span>
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs font-bold text-slate-800 dark:text-white truncate">Advanced Audit - Mock #4</p>
                  <p className="text-[10px] text-orange-600 dark:text-orange-400 font-semibold">ICAI Official Pattern</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-900/40">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 text-white flex flex-col items-center justify-center shrink-0 shadow-xs">
                  <span className="text-[9px] font-black leading-none uppercase">OCT</span>
                  <span className="text-sm font-black leading-none mt-0.5">15</span>
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs font-bold text-slate-800 dark:text-white truncate">Direct Tax Revision 2.0</p>
                  <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">Vividh-Shastra Modules</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Peer Discussions Link */}
          <div className="bg-gradient-to-br from-purple-50 via-indigo-50 to-pink-50 dark:from-purple-950/40 dark:via-slate-900 dark:to-indigo-950/30 rounded-2xl border border-purple-200/80 dark:border-purple-900/40 p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-600 dark:text-purple-400">
                <Users className="w-4 h-4" />
              </span>
              <h4 className="text-xs font-black text-slate-900 dark:text-white">
                Discuss Common Problems with Friends
              </h4>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-normal">
              Facing study burnout, backlogs, or articleship queries? Share and discuss with friends & CA Rankers in active study groups.
            </p>
            <button
              onClick={() => onNavigate('friend-discussions')}
              className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
            >
              <span>Open Friend Forum</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
