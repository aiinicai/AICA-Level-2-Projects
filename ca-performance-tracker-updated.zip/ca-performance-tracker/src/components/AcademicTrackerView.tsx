import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Filter, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  Award, 
  Trash2, 
  Edit3, 
  BarChart2, 
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';
import { TestRecord, Subject, TestType } from '../types';

interface AcademicTrackerViewProps {
  testRecords: TestRecord[];
  subjects: Subject[];
  onAddTest: (test: Omit<TestRecord, 'id'>) => void;
  onDeleteTest: (id: string) => void;
  isDarkMode: boolean;
  onOpenAddModal: () => void;
}

export const AcademicTrackerView: React.FC<AcademicTrackerViewProps> = ({
  testRecords,
  subjects,
  onAddTest,
  onDeleteTest,
  isDarkMode,
  onOpenAddModal,
}) => {
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('ALL');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filter test records
  const filteredTests = testRecords.filter((test) => {
    const matchesSub = selectedSubjectFilter === 'ALL' || test.subjectId === selectedSubjectFilter;
    const matchesType = selectedTypeFilter === 'ALL' || test.testType === selectedTypeFilter;
    const matchesSearch = test.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.remarks.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSub && matchesType && matchesSearch;
  });

  // Calculate stats
  const totalCount = filteredTests.length;
  const scoresPct = filteredTests.map(t => (t.marksObtained / t.maxMarks) * 100);
  
  const avgPct = totalCount > 0 ? Math.round(scoresPct.reduce((a, b) => a + b, 0) / totalCount) : 0;
  const highestPct = totalCount > 0 ? Math.round(Math.max(...scoresPct)) : 0;
  const lowestPct = totalCount > 0 ? Math.round(Math.min(...scoresPct)) : 0;

  // Consistency (standard deviation proxy)
  const consistencyIndex = totalCount > 1 
    ? Math.max(0, 100 - Math.round(Math.sqrt(scoresPct.reduce((sq, n) => sq + Math.pow(n - avgPct, 2), 0) / totalCount)))
    : 85;

  const passProbability = Math.min(98, Math.max(15, Math.round(avgPct * 1.1 - (100 - consistencyIndex) * 0.2)));

  const testTypes: TestType[] = [
    'Mock Test', 'RTP', 'MTP', 'Past Paper', 'Coaching Test', 'ICAI Unit Test', 'Internal Test'
  ];

  return (
    <div className="space-y-6">
      
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            <span>Academic Performance Tracker</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Log and analyze ICAI Mock Tests, RTPs, MTPs, Past Papers & Unit Assessment Scores.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Log New Test Record</span>
        </button>
      </div>

      {/* Analytics Summary Banner */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-[11px] font-bold text-slate-400 uppercase">Average Marks</div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">{avgPct}%</div>
          <div className="text-[10px] text-slate-500 font-medium">{totalCount} Tests Logged</div>
        </div>

        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-[11px] font-bold text-slate-400 uppercase">Highest Score</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{highestPct}%</div>
          <div className="text-[10px] text-slate-500 font-medium">Best Performance</div>
        </div>

        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-[11px] font-bold text-slate-400 uppercase">Lowest Score</div>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1">{lowestPct}%</div>
          <div className="text-[10px] text-slate-500 font-medium">Revision Area</div>
        </div>

        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-[11px] font-bold text-slate-400 uppercase">Consistency Index</div>
          <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">{consistencyIndex}%</div>
          <div className="text-[10px] text-slate-500 font-medium">Score Stability</div>
        </div>

        <div className={`p-4 rounded-xl border col-span-2 md:col-span-1 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-[11px] font-bold text-slate-400 uppercase">Pass Probability</div>
          <div className="text-2xl font-black text-purple-600 dark:text-purple-400 mt-1">{passProbability}%</div>
          <div className="text-[10px] text-emerald-500 font-bold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> AI Estimated
          </div>
        </div>
      </div>

      {/* Filter & Search Controls */}
      <div className={`p-4 rounded-xl border flex flex-col md:flex-row items-center justify-between gap-3 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by test title..."
            className={`w-full pl-9 pr-3 py-1.5 rounded-lg border text-xs font-medium ${
              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Subject Filter */}
          <select
            value={selectedSubjectFilter}
            onChange={(e) => setSelectedSubjectFilter(e.target.value)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-800'
            }`}
          >
            <option value="ALL">All Subjects</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>

          {/* Test Type Filter */}
          <select
            value={selectedTypeFilter}
            onChange={(e) => setSelectedTypeFilter(e.target.value)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold ${
              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-800'
            }`}
          >
            <option value="ALL">All Test Types</option>
            {testTypes.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Test Records Table */}
      <div className={`rounded-2xl border overflow-hidden ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className={`border-b font-bold uppercase text-[10px] tracking-wider ${
              isDarkMode ? 'bg-slate-850 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-500'
            }`}>
              <tr>
                <th className="p-3">Subject & Title</th>
                <th className="p-3">Type</th>
                <th className="p-3">Date</th>
                <th className="p-3">Marks Obtained</th>
                <th className="p-3">Time Taken</th>
                <th className="p-3">Difficulty</th>
                <th className="p-3">Remarks</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredTests.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400 font-medium">
                    No test records match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredTests.map((test) => {
                  const sub = subjects.find(s => s.id === test.subjectId);
                  const scorePct = Math.round((test.marksObtained / test.maxMarks) * 100);

                  return (
                    <tr key={test.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-slate-900 dark:text-white">{test.title}</div>
                        <div className="text-[10px] font-semibold text-blue-600 dark:text-blue-400">
                          {sub?.name || 'Subject'}
                        </div>
                      </td>

                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                          {test.testType}
                        </span>
                      </td>

                      <td className="p-3 font-medium text-slate-600 dark:text-slate-300">
                        {test.date}
                      </td>

                      <td className="p-3">
                        <div className={`font-black ${
                          scorePct >= 70 ? 'text-emerald-600 dark:text-emerald-400' : scorePct >= 50 ? 'text-blue-600 dark:text-blue-400' : 'text-rose-600 dark:text-rose-400'
                        }`}>
                          {test.marksObtained} / {test.maxMarks} ({scorePct}%)
                        </div>
                      </td>

                      <td className="p-3 font-medium text-slate-600 dark:text-slate-300">
                        {test.timeTakenMins} Mins
                      </td>

                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          test.difficultyLevel === 'ICAI Standard' || test.difficultyLevel === 'Challenging'
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}>
                          {test.difficultyLevel}
                        </span>
                      </td>

                      <td className="p-3 max-w-xs truncate text-slate-500 italic">
                        {test.remarks || 'No remarks added'}
                      </td>

                      <td className="p-3 text-right">
                        <button
                          onClick={() => onDeleteTest(test.id)}
                          className="p-1.5 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-rose-500 transition-colors"
                          title="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
