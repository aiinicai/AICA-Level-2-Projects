import React, { useState } from 'react';
import { 
  CalendarDays, 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  RefreshCw, 
  Sliders, 
  Check, 
  BookOpen, 
  AlertCircle 
} from 'lucide-react';
import { ScheduleItem, ICAIStudentProfile, Subject } from '../types';

interface AIStudyPlannerViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  isDarkMode: boolean;
}

export const AIStudyPlannerView: React.FC<AIStudyPlannerViewProps> = ({
  profile,
  subjects,
  isDarkMode,
}) => {
  const [dailyHours, setDailyHours] = useState<number>(10);
  const [focusArea, setFocusArea] = useState<string>('Balanced (Weak + Strong)');
  
  // Timetable State
  const [schedule, setSchedule] = useState<ScheduleItem[]>([
    { time: '06:00 AM', activity: 'Advanced Accounts Theory & Standards (AS 10 & 16)', subject: 'Advanced Accounting', duration: '2 Hours', completed: true },
    { time: '08:15 AM', activity: 'Taxation - GST Input Tax Credit Numerical Practice', subject: 'Taxation (DT & IDT)', duration: '2.5 Hours', completed: true },
    { time: '11:15 AM', activity: 'Corporate Law Reading (Management & Administration)', subject: 'Corporate & Other Laws', duration: '1.5 Hours', completed: false },
    { time: '02:00 PM', activity: 'Solving 50 MCQs in Costing & Marginal Costing', subject: 'Cost & Management Accounting', duration: '2 Hours', completed: false },
    { time: '04:30 PM', activity: 'Audit SA 200 & SA 230 Memory Flashcard Drill', subject: 'Auditing & Ethics', duration: '1.5 Hours', completed: false },
    { time: '07:00 PM', activity: 'FM Ratio Analysis Formula Drill & Past Paper Solving', subject: 'FM & SM', duration: '1.5 Hours', completed: false },
    { time: '09:00 PM', activity: 'Daily Progress Review & Flashcard Self-Quiz', subject: 'All Subjects', duration: '1 Hour', completed: false },
  ]);

  const [loading, setLoading] = useState(false);

  const toggleComplete = (idx: number) => {
    setSchedule(prev => prev.map((item, i) => i === idx ? { ...item, completed: !item.completed } : item));
  };

  const handleRegenerateTimetable = () => {
    setLoading(true);
    setTimeout(() => {
      // Regenerate dynamic schedule based on selected target hours
      let newSlots: ScheduleItem[] = [];
      if (dailyHours <= 6) {
        newSlots = [
          { time: '06:30 AM', activity: 'Core Subject Revision & Standards', subject: 'Advanced Accounting', duration: '2 Hours', completed: false },
          { time: '09:30 AM', activity: 'Practical Problem Solving & RTP Questions', subject: 'Taxation', duration: '2 Hours', completed: false },
          { time: '03:00 PM', activity: 'Law Reading & Section Memorandum', subject: 'Corporate Laws', duration: '1.5 Hours', completed: false },
          { time: '08:00 PM', activity: 'MCQs Practice & Quick Formula Recall', subject: 'Costing', duration: '0.5 Hours', completed: false },
        ];
      } else {
        newSlots = [
          { time: '06:00 AM', activity: 'High-Weightage Subject Revision (AS / Ind AS)', subject: 'Advanced Accounting', duration: '2.5 Hours', completed: false },
          { time: '09:00 AM', activity: 'Taxation Computation Practice & Case Laws', subject: 'Taxation', duration: '2.5 Hours', completed: false },
          { time: '01:30 PM', activity: 'Law Case Study Practice & Writing Presentation', subject: 'Corporate Laws', duration: '2 Hours', completed: false },
          { time: '04:15 PM', activity: 'Costing Numerical Problem Drills', subject: 'Costing', duration: '2 Hours', completed: false },
          { time: '07:00 PM', activity: 'Audit Standards Memory & Keywords Drill', subject: 'Auditing', duration: '1.5 Hours', completed: false },
          { time: '09:00 PM', activity: 'Evening Revision & Next Day Goal Setting', subject: 'All Subjects', duration: '1 Hour', completed: false },
        ];
      }
      setSchedule(newSlots);
      setLoading(false);
    }, 600);
  };

  const completedCount = schedule.filter(s => s.completed).length;
  const progressPct = schedule.length > 0 ? Math.round((completedCount / schedule.length) * 100) : 0;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400">
            <CalendarDays className="w-4 h-4" />
            <span>Adaptive AI Study Timetable</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            Daily Study Schedule & Slot Tracker
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Automatically balanced timetable tailored to your available study hours, exam countdown & weak areas.
          </p>
        </div>

        <button
          onClick={handleRegenerateTimetable}
          disabled={loading}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2 transition-all shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Regenerate Timetable</span>
        </button>
      </div>

      {/* Planner Customization Bar */}
      <div className={`p-4 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase">Target Study Hours</label>
            <select
              value={dailyHours}
              onChange={(e) => setDailyHours(Number(e.target.value))}
              className={`block w-full px-3 py-1.5 rounded-lg border text-xs font-bold ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value={6}>6 Hours / Day</option>
              <option value={8}>8 Hours / Day</option>
              <option value={10}>10 Hours / Day (Recommended)</option>
              <option value={12}>12 Hours / Day (Marathon)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase">Strategy Priority</label>
            <select
              value={focusArea}
              onChange={(e) => setFocusArea(e.target.value)}
              className={`block w-full px-3 py-1.5 rounded-lg border text-xs font-bold ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            >
              <option value="Balanced (Weak + Strong)">Balanced (Weak + Strong)</option>
              <option value="Focus on Weak Subjects">Focus on Weak Subjects</option>
              <option value="Full Mock Test & RTP Drills">Full Mock Test & RTP Drills</option>
            </select>
          </div>
        </div>

        {/* Progress Summary */}
        <div className="flex items-center gap-4 w-full md:w-auto justify-between border-t md:border-t-0 pt-3 md:pt-0 border-slate-200 dark:border-slate-800">
          <div className="text-right">
            <div className="text-xs font-bold text-slate-900 dark:text-white">
              {completedCount} of {schedule.length} Slots Completed
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              Daily Target Completion: <strong>{progressPct}%</strong>
            </div>
          </div>

          <div className="w-12 h-12 rounded-full border-4 border-indigo-500 flex items-center justify-center font-black text-xs text-indigo-600 dark:text-indigo-400">
            {progressPct}%
          </div>
        </div>
      </div>

      {/* Timetable Slot List */}
      <div className="space-y-3">
        {schedule.map((item, idx) => (
          <div
            key={idx}
            onClick={() => toggleComplete(idx)}
            className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-4 ${
              item.completed
                ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40 text-slate-500 dark:text-slate-400'
                : isDarkMode
                  ? 'bg-slate-900 border-slate-800 hover:border-indigo-500/50'
                  : 'bg-white border-slate-200 hover:border-indigo-300 shadow-sm'
            }`}
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <button
                className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 transition-all ${
                  item.completed
                    ? 'bg-emerald-500 border-emerald-500 text-white'
                    : 'border-slate-300 dark:border-slate-700 text-transparent hover:border-indigo-500'
                }`}
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </button>

              <div className="space-y-0.5 min-w-0">
                <div className="flex items-center gap-2 text-[11px] font-bold">
                  <span className="text-indigo-600 dark:text-indigo-400 font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {item.time} ({item.duration})
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold">
                    {item.subject}
                  </span>
                </div>

                <h4 className={`text-xs font-bold leading-tight truncate ${
                  item.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                }`}>
                  {item.activity}
                </h4>
              </div>
            </div>

            <div className="shrink-0 text-right">
              <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                item.completed
                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}>
                {item.completed ? 'Done' : 'Pending'}
              </span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
