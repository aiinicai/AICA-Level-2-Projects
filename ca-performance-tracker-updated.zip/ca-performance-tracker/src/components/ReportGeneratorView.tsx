import React from 'react';
import { 
  Download, 
  Printer, 
  ShieldCheck, 
  Award, 
  BarChart3, 
  CheckCircle2, 
  Clock, 
  BookOpen 
} from 'lucide-react';
import { ICAIStudentProfile, Subject, TestRecord, Chapter } from '../types';

interface ReportGeneratorViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  testRecords: TestRecord[];
  chapters: Chapter[];
  isDarkMode: boolean;
}

export const ReportGeneratorView: React.FC<ReportGeneratorViewProps> = ({
  profile,
  subjects,
  testRecords,
  chapters,
  isDarkMode,
}) => {
  const levelSubjects = subjects.filter(s => s.course === profile.course);

  const totalTests = testRecords.length;
  const avgMockScore = totalTests > 0
    ? Math.round(testRecords.reduce((acc, t) => acc + (t.marksObtained / t.maxMarks) * 100, 0) / totalTests)
    : 0;

  const totalMins = chapters.reduce((acc, c) => acc + c.timeSpentMins, 0);
  const totalHours = Math.round(totalMins / 60);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Header Controls */}
      <div className="flex items-center justify-between print:hidden">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Download className="w-5 h-5 text-blue-500" />
            <span>Academic Performance & Diagnostic Report</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generate and print a full academic progress sheet for self-audit, parents, or mentors.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center gap-2 transition-all"
        >
          <Printer className="w-4 h-4" />
          <span>Print / Export PDF</span>
        </button>
      </div>

      {/* Printable Report Document Card */}
      <div className="p-8 rounded-3xl border bg-white text-slate-900 border-slate-200 shadow-xl space-y-6 print:shadow-none print:border-none print:p-0">
        
        {/* Document Header */}
        <div className="flex items-center justify-between border-b pb-6 border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xl">
              CA
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-900">
                ICAI STUDENT PERFORMANCE AUDIT REPORT
              </h1>
              <p className="text-xs text-slate-500 font-semibold">
                Official AI Track Progress & Readiness Certificate
              </p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs font-bold text-slate-900">{profile.registrationNumber}</div>
            <div className="text-[10px] text-emerald-600 font-bold">VERIFIED STUDENT</div>
            <div className="text-[10px] text-slate-400">Generated: {new Date().toLocaleDateString()}</div>
          </div>
        </div>

        {/* Student Profile Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Student Name</span>
            <span className="font-bold text-slate-900">{profile.name}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Course & Attempt</span>
            <span className="font-bold text-slate-900">CA {profile.course} ({profile.attempt})</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Articleship Status</span>
            <span className="font-bold text-slate-900">{profile.articleshipStatus}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Hours Logged</span>
            <span className="font-bold text-slate-900">{totalHours} Hours</span>
          </div>
        </div>

        {/* Subject-wise Marks & Progress Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Subject-wise Academic Audit
          </h3>

          <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
            <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-600">
              <tr>
                <th className="p-2.5">Subject Code & Name</th>
                <th className="p-2.5">Syllabus %</th>
                <th className="p-2.5">Mock Test Avg %</th>
                <th className="p-2.5">Readiness Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {levelSubjects.map((sub) => {
                const subChs = chapters.filter(c => c.subjectId === sub.id);
                const compChs = subChs.filter(c => c.status === 'Completed' || c.status === 'Mastered').length;
                const pct = subChs.length > 0 ? Math.round((compChs / subChs.length) * 100) : 0;

                const subTests = testRecords.filter(t => t.subjectId === sub.id);
                const avg = subTests.length > 0 
                  ? Math.round(subTests.reduce((a, b) => a + (b.marksObtained / b.maxMarks) * 100, 0) / subTests.length)
                  : 0;

                return (
                  <tr key={sub.id}>
                    <td className="p-2.5 font-bold">{sub.code} - {sub.name}</td>
                    <td className="p-2.5 font-medium">{pct}%</td>
                    <td className="p-2.5 font-bold">{avg > 0 ? `${avg}%` : 'N/A'}</td>
                    <td className="p-2.5 font-bold text-emerald-600">
                      {pct >= 70 ? 'On Track' : 'Needs Revision'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mentor Signature & Disclaimer */}
        <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div>
            <p className="font-semibold text-slate-700">ICAI Performance Portal AI Verification Engine</p>
            <p className="text-[10px]">Autogenerated Report. No signature required.</p>
          </div>

          <div className="text-right">
            <div className="w-32 h-10 border-b border-slate-400 font-mono text-[10px] flex items-end justify-center text-slate-400">
              ICAI Track Seal
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
