import React from 'react';
import { 
  LayoutDashboard, 
  ShieldCheck, 
  FileText, 
  BarChart3, 
  Sparkles, 
  CalendarDays, 
  Target, 
  ExternalLink, 
  HelpCircle, 
  Download, 
  Settings,
  ChevronRight,
  Zap,
  Flame,
  BrainCircuit,
  MessageSquare,
  Bot,
  PenTool,
  GraduationCap,
  Sun,
  X
} from 'lucide-react';

import fisheyeIcon from '../assets/images/fisheye_icon_1786821166028.jpg';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  isDarkMode: boolean;
  onOpenBriefing?: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onNavigate, isDarkMode, onOpenBriefing, isOpen = false, onClose }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null, color: 'text-amber-500', activeBg: 'from-amber-500/15 via-amber-500/10 to-transparent text-amber-700 dark:text-amber-300 border-l-4 border-amber-500' },
    { id: 'ai-examiner', label: '🎓 AI Examiner Mode', icon: GraduationCap, badge: 'Rigorous', color: 'text-purple-500', activeBg: 'from-purple-500/15 via-purple-500/10 to-transparent text-purple-700 dark:text-purple-300 border-l-4 border-purple-500' },
    { id: 'answer-coach', label: 'Answer Writing Coach', icon: PenTool, badge: 'CA Final', color: 'text-indigo-500', activeBg: 'from-indigo-500/15 via-indigo-500/10 to-transparent text-indigo-700 dark:text-indigo-300 border-l-4 border-indigo-500' },
    { id: 'today-ai-plan', label: "Today's AI Plan", icon: Bot, badge: 'Smart AI', color: 'text-indigo-500', activeBg: 'from-indigo-500/15 via-indigo-500/10 to-transparent text-indigo-700 dark:text-indigo-300 border-l-4 border-indigo-500' },
    { id: 'profile', label: 'ICAI Student Profile', icon: ShieldCheck, badge: null, color: 'text-emerald-500', activeBg: 'from-emerald-500/15 via-emerald-500/10 to-transparent text-emerald-700 dark:text-emerald-300 border-l-4 border-emerald-500' },
    { id: 'academic-tracker', label: 'Test & Marks Log', icon: FileText, badge: null, color: 'text-rose-500', activeBg: 'from-rose-500/15 via-rose-500/10 to-transparent text-rose-700 dark:text-rose-300 border-l-4 border-rose-500' },
    { id: 'mistake-intelligence', label: 'Mistake Intelligence', icon: BrainCircuit, badge: 'Insights', color: 'text-rose-500', activeBg: 'from-rose-500/15 via-rose-500/10 to-transparent text-rose-700 dark:text-rose-300 border-l-4 border-rose-500' },
    { id: 'subject-analytics', label: 'Subject Analytics', icon: BarChart3, badge: null, color: 'text-violet-500', activeBg: 'from-violet-500/15 via-violet-500/10 to-transparent text-violet-700 dark:text-violet-300 border-l-4 border-violet-500' },
    { id: 'ai-coach', label: 'AI Personal Coach', icon: Sparkles, badge: 'AI', color: 'text-pink-500', activeBg: 'from-pink-500/15 via-pink-500/10 to-transparent text-pink-700 dark:text-pink-300 border-l-4 border-pink-500' },
    { id: 'ai-planner', label: 'AI Study Timetable', icon: CalendarDays, badge: 'Auto', color: 'text-cyan-500', activeBg: 'from-cyan-500/15 via-cyan-500/10 to-transparent text-cyan-700 dark:text-cyan-300 border-l-4 border-cyan-500' },
    { id: 'flashcards', label: 'AI Flashcards Deck', icon: BrainCircuit, badge: 'Recall', color: 'text-indigo-500', activeBg: 'from-indigo-500/15 via-indigo-500/10 to-transparent text-indigo-700 dark:text-indigo-300 border-l-4 border-indigo-500' },
    { id: 'goals', label: 'Goals & Badges', icon: Target, badge: null, color: 'text-emerald-500', activeBg: 'from-emerald-500/15 via-emerald-500/10 to-transparent text-emerald-700 dark:text-emerald-300 border-l-4 border-emerald-500' },
    { id: 'motivation', label: 'Sportic Motivation', icon: Flame, badge: 'Videos', color: 'text-red-500', activeBg: 'from-red-500/15 via-red-500/10 to-transparent text-red-700 dark:text-red-300 border-l-4 border-red-500' },
    { id: 'resources', label: 'ICAI Official Links', icon: ExternalLink, badge: null, color: 'text-teal-500', activeBg: 'from-teal-500/15 via-teal-500/10 to-transparent text-teal-700 dark:text-teal-300 border-l-4 border-teal-500' },
    { id: 'friend-discussions', label: 'Discuss with Friends', icon: MessageSquare, badge: 'Forum', color: 'text-purple-500', activeBg: 'from-purple-500/15 via-purple-500/10 to-transparent text-purple-700 dark:text-purple-300 border-l-4 border-purple-500' },
    { id: 'community', label: 'Doubts & AI Quiz', icon: HelpCircle, badge: null, color: 'text-sky-500', activeBg: 'from-sky-500/15 via-sky-500/10 to-transparent text-sky-700 dark:text-sky-300 border-l-4 border-sky-500' },
    { id: 'report', label: 'Progress Report', icon: Download, badge: 'PDF', color: 'text-lime-500', activeBg: 'from-lime-500/15 via-lime-500/10 to-transparent text-lime-700 dark:text-lime-300 border-l-4 border-lime-500' },
    { id: 'admin', label: 'Admin Portal', icon: Settings, badge: null, color: 'text-slate-400', activeBg: 'from-slate-500/15 via-slate-500/10 to-transparent text-slate-700 dark:text-slate-300 border-l-4 border-slate-500' },
  ];

  return (
    <aside className={`
      w-64 border-r border-slate-200 dark:border-slate-800 flex flex-col shrink-0 transition-transform duration-300 ease-in-out
      ${isDarkMode ? 'bg-slate-900/95 text-slate-300' : 'bg-white text-slate-700'}
      fixed lg:relative inset-y-0 left-0 z-50 h-full
      ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
    `}>
      {/* Brand Header */}
      <div className="p-4 flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 mb-2">
        <div className="relative w-10 h-10 rounded-2xl overflow-hidden shadow-lg shadow-purple-500/20 border border-purple-300/40 dark:border-purple-600/40 shrink-0 group">
          <img
            src={fisheyeIcon}
            alt="CA Mentor AI Fish-Eye Focus Logo"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover rounded-2xl transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/30 pointer-events-none" />
        </div>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="font-black text-base tracking-tight bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-tight">
            CA Mentor AI
          </span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold tracking-tight leading-tight mt-0.5">
            Your Personal AI Coach for CA Success
          </span>
        </div>
        {/* Close button — mobile only */}
        {onClose && (
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {/* Quick Launch Daily Briefing Card */}
        {onOpenBriefing && (
          <div className="mb-2">
            <button
              onClick={onOpenBriefing}
              className="w-full p-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-purple-500/20 hover:from-amber-500/30 hover:to-purple-500/30 border border-amber-500/30 text-amber-700 dark:text-amber-300 transition-all flex items-center justify-between text-left group shadow-xs cursor-pointer"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="p-1 rounded-lg bg-amber-500/20 text-amber-500">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-black block leading-tight text-slate-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-300">
                    AI Daily Briefing
                  </span>
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold block leading-tight">
                    Readiness: 72% • Today's Focus
                  </span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-amber-500 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        )}

        <div className="px-3 py-2 text-[10px] font-black tracking-wider text-slate-400 uppercase">
          Navigation Menu
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                isActive
                  ? `bg-gradient-to-r ${item.activeBg} font-bold shadow-xs`
                  : isDarkMode
                    ? 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-100'
                    : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon className={`w-4 h-4 shrink-0 transition-transform ${isActive ? 'scale-110 ' + item.color : item.color + ' opacity-80'}`} />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider ${
                  isActive 
                    ? 'bg-indigo-600 text-white shadow-xs' 
                    : item.badge === 'AI' 
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-xs' 
                      : item.badge === 'Verified'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                        : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer Next Goal Widget */}
      <div className="p-3.5 mt-auto border-t border-slate-100 dark:border-slate-800">
        <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-2xl p-4 text-white shadow-lg shadow-purple-500/20 border border-white/10">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-black opacity-90 uppercase tracking-widest text-amber-300">Next Target Goal</p>
            <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
          </div>
          <p className="text-sm font-extrabold mt-1 truncate">Audit RTP Completion</p>
          <div className="w-full bg-black/20 h-1.5 mt-2.5 rounded-full overflow-hidden p-0.5 border border-white/20">
            <div className="w-3/4 bg-gradient-to-r from-amber-300 to-emerald-300 h-full rounded-full" />
          </div>
          <div className="flex justify-between items-center text-[10px] mt-2 font-bold opacity-90">
            <span>75% Completed</span>
            <span className="bg-white/20 px-1.5 py-0.5 rounded-full">2 days left</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
