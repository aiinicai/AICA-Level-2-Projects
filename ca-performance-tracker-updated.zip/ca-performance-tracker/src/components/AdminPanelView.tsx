import React, { useState } from 'react';
import { 
  Settings, 
  Users, 
  BookOpen, 
  Upload, 
  BarChart3, 
  CheckCircle2, 
  Plus, 
  ShieldCheck,
  FileText
} from 'lucide-react';
import { Subject, CourseLevel } from '../types';

interface AdminPanelViewProps {
  subjects: Subject[];
  isDarkMode: boolean;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({ subjects, isDarkMode }) => {
  const [announcementTitle, setAnnouncementTitle] = useState('');
  const [announcements, setAnnouncements] = useState<Array<{ id: string; title: string; date: string }>>([
    { id: 'a1', title: 'ICAI Board of Studies May 2026 Revision Test Papers (RTP) Released', date: '2026-03-01' },
    { id: 'a2', title: 'ICAI Mock Test Series 1 Schedule for Intermediate & Final Announced', date: '2026-02-20' },
  ]);

  const handlePublishAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementTitle.trim()) return;

    setAnnouncements(prev => [
      { id: `a_${Date.now()}`, title: announcementTitle.trim(), date: new Date().toISOString().split('T')[0] },
      ...prev,
    ]);
    setAnnouncementTitle('');
    alert('Announcement published to student portals!');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
          <Settings className="w-4 h-4" />
          <span>ICAI Portal Administration & Management</span>
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          Platform Curriculum & Student Analytics Control
        </h2>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-xs font-bold text-slate-400 uppercase">Active Platform Students</div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">14,280</div>
          <div className="text-[10px] text-emerald-500 font-bold">+12% this month</div>
        </div>

        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-xs font-bold text-slate-400 uppercase">Active Curriculum Subjects</div>
          <div className="text-2xl font-black text-purple-600 dark:text-purple-400 mt-1">{subjects.length}</div>
          <div className="text-[10px] text-slate-500 font-medium">Foundation, Inter, Final</div>
        </div>

        <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <div className="text-xs font-bold text-slate-400 uppercase">Mock Tests Evaluated</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">48,920</div>
          <div className="text-[10px] text-slate-500 font-medium">Avg Score 68%</div>
        </div>
      </div>

      {/* Publish Announcements */}
      <div className={`p-5 rounded-2xl border space-y-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Upload className="w-4 h-4 text-blue-500" />
          <span>Publish Official ICAI Announcement / RTP Upload</span>
        </h3>

        <form onSubmit={handlePublishAnnouncement} className="flex gap-2">
          <input
            type="text"
            value={announcementTitle}
            onChange={(e) => setAnnouncementTitle(e.target.value)}
            placeholder="e.g. Uploaded May 2026 MTP Series 2 Question Papers..."
            className={`flex-1 px-3 py-2 rounded-xl border text-xs font-medium ${
              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shrink-0"
          >
            Publish
          </button>
        </form>

        <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
          {announcements.map((anc) => (
            <div key={anc.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-900 dark:text-white">{anc.title}</span>
              <span className="text-[10px] text-slate-400 font-mono">{anc.date}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
