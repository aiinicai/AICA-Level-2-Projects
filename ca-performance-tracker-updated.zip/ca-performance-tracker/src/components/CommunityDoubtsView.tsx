import React, { useState } from 'react';
import { 
  HelpCircle, 
  MessageSquare, 
  ThumbsUp, 
  Send, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  BrainCircuit,
  Plus
} from 'lucide-react';
import { DoubtQuestion, CourseLevel, Subject } from '../types';

interface CommunityDoubtsViewProps {
  course: CourseLevel;
  subjects: Subject[];
  doubts: DoubtQuestion[];
  onAddDoubt: (doubt: DoubtQuestion) => void;
  isDarkMode: boolean;
}

export const CommunityDoubtsView: React.FC<CommunityDoubtsViewProps> = ({
  course,
  subjects,
  doubts,
  onAddDoubt,
  isDarkMode,
}) => {
  const [activeTab, setActiveTab] = useState<'doubts' | 'quiz'>('doubts');
  
  // New doubt form state
  const [selectedSub, setSelectedSub] = useState(subjects[0]?.name || 'Taxation');
  const [chapterName, setChapterName] = useState('');
  const [questionText, setQuestionText] = useState('');
  const [solvingAi, setSolvingAi] = useState(false);

  // AI Quiz Generator State
  const [quizSubject, setQuizSubject] = useState(subjects[0]?.name || 'Advanced Accounting');
  const [quizChapter, setQuizChapter] = useState('AS 10 Property Plant & Equipment');
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizQuestions, setQuizQuestions] = useState<Array<{
    id: string;
    question: string;
    options: string[];
    correctOptionIndex: number;
    explanation: string;
  }>>([]);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [submittedQuiz, setSubmittedQuiz] = useState(false);

  const handlePostDoubt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;

    setSolvingAi(true);

    let aiSolution = '';
    try {
      const res = await fetch('/api/ai/doubt-solver', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course,
          subject: selectedSub,
          chapter: chapterName || 'General Topic',
          question: questionText,
        }),
      });

      const data = await res.json();
      if (res.ok && data.answer) {
        aiSolution = data.answer;
      }
    } catch (err) {
      aiSolution = 'AI solution generation faced a network timeout.';
    } finally {
      setSolvingAi(false);
    }

    const newDoubt: DoubtQuestion = {
      id: `d_${Date.now()}`,
      studentName: 'Rohan Sharma',
      course,
      subject: selectedSub,
      chapter: chapterName || 'General Topic',
      question: questionText,
      aiAnswer: aiSolution,
      upvotes: 1,
      createdAt: new Date().toISOString().split('T')[0],
      resolved: true,
    };

    onAddDoubt(newDoubt);
    setQuestionText('');
    setChapterName('');
  };

  const handleGenerateQuiz = async () => {
    setQuizLoading(true);
    setSubmittedQuiz(false);
    setUserAnswers({});

    try {
      const res = await fetch('/api/ai/quiz-generator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course,
          subject: quizSubject,
          chapter: quizChapter,
          count: 3,
        }),
      });

      const data = await res.json();
      if (res.ok && data.questions) {
        setQuizQuestions(data.questions);
      }
    } catch (err) {
      alert('Failed to generate quiz.');
    } finally {
      setQuizLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
            <HelpCircle className="w-4 h-4" />
            <span>CA Student Peer Community & AI Hub</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            Concept Doubts & AI Quiz Practice
          </h2>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('doubts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'doubts'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            Ask & View Doubts
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'quiz'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                : isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Quiz Generator</span>
          </button>
        </div>
      </div>

      {activeTab === 'doubts' ? (
        <div className="space-y-6">
          
          {/* Post Doubt Form */}
          <form onSubmit={handlePostDoubt} className={`p-5 rounded-2xl border space-y-4 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-500" />
              <span>Ask a Technical Accounting / Tax / Audit Doubt</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Subject</label>
                <select
                  value={selectedSub}
                  onChange={(e) => setSelectedSub(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Chapter / Section</label>
                <input
                  type="text"
                  value={chapterName}
                  onChange={(e) => setChapterName(e.target.value)}
                  placeholder="e.g. AS 10 / Section 32 PGBP"
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Your Question</label>
              <textarea
                value={questionText}
                onChange={(e) => setQuestionText(e.target.value)}
                rows={3}
                placeholder="Type your question in detail..."
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                  isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
                required
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={solvingAi}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>{solvingAi ? 'Generating AI Solution...' : 'Post Doubt & Get AI Answer'}</span>
              </button>
            </div>
          </form>

          {/* Doubts List */}
          <div className="space-y-4">
            {doubts.map((d) => (
              <div key={d.id} className={`p-5 rounded-2xl border space-y-3 ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold">
                    <span className="text-slate-900 dark:text-white">{d.studentName}</span>
                    <span className="text-slate-400">•</span>
                    <span className="text-blue-600 dark:text-blue-400">{d.subject} ({d.chapter})</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{d.createdAt}</span>
                </div>

                <p className="text-xs font-bold text-slate-900 dark:text-white leading-relaxed">
                  Q: {d.question}
                </p>

                {d.aiAnswer && (
                  <div className={`p-4 rounded-xl border text-xs leading-relaxed space-y-1 ${
                    isDarkMode ? 'bg-purple-950/30 border-purple-900/40 text-purple-200' : 'bg-purple-50 border-purple-200 text-purple-950'
                  }`}>
                    <div className="font-extrabold flex items-center gap-1.5 text-purple-600 dark:text-purple-400 mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>ICAI AI Solution & Legal Explanation:</span>
                    </div>
                    <div className="whitespace-pre-wrap">{d.aiAnswer}</div>
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>
      ) : (
        /* AI Quiz Practice Generator */
        <div className="space-y-6">
          <div className={`p-5 rounded-2xl border space-y-4 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-purple-500" />
              <span>Generate Custom ICAI Practice MCQs</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Subject</label>
                <select
                  value={quizSubject}
                  onChange={(e) => setQuizSubject(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Chapter</label>
                <input
                  type="text"
                  value={quizChapter}
                  onChange={(e) => setQuizChapter(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>
            </div>

            <button
              onClick={handleGenerateQuiz}
              disabled={quizLoading}
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{quizLoading ? 'Generating MCQs...' : 'Generate 3 Quiz MCQs'}</span>
            </button>
          </div>

          {/* Quiz Display */}
          {quizQuestions.length > 0 && (
            <div className="space-y-4">
              {quizQuestions.map((q, qIdx) => (
                <div key={q.id} className={`p-5 rounded-2xl border space-y-3 ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {qIdx + 1}. {q.question}
                  </h4>

                  <div className="space-y-1.5">
                    {q.options.map((opt, optIdx) => (
                      <button
                        key={optIdx}
                        onClick={() => setUserAnswers(prev => ({ ...prev, [q.id]: optIdx }))}
                        className={`w-full text-left p-2.5 rounded-xl text-xs font-medium border transition-all ${
                          userAnswers[q.id] === optIdx
                            ? 'bg-purple-100 dark:bg-purple-950/60 border-purple-500 text-purple-900 dark:text-purple-200 font-bold'
                            : isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        {String.fromCharCode(65 + optIdx)}. {opt}
                      </button>
                    ))}
                  </div>

                  {submittedQuiz && (
                    <div className="space-y-2">
                      <div className={`p-3 rounded-xl border text-xs font-semibold ${
                        userAnswers[q.id] === q.correctOptionIndex
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 text-emerald-800 dark:text-emerald-300'
                          : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 text-rose-800 dark:text-rose-300'
                      }`}>
                        <div>{userAnswers[q.id] === q.correctOptionIndex ? 'Correct! 🎉 (+20 XP)' : `Incorrect. Correct Option: ${String.fromCharCode(65 + q.correctOptionIndex)}`}</div>
                        <div className="text-[11px] font-normal mt-1 text-slate-600 dark:text-slate-300">{q.explanation}</div>
                      </div>

                      {userAnswers[q.id] !== q.correctOptionIndex && (
                        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                          <div className="text-[11px] font-black text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                            <span>🧠</span>
                            <span>Mistake Intelligence: Why did you get this wrong?</span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[10px]">
                            {[
                              { label: "❌ Didn't know concept", reason: "concept_gap" },
                              { label: "❌ Misread question", reason: "misread_question" },
                              { label: "❌ Calculation mistake", reason: "calculation_mistake" },
                              { label: "❌ Forgot provision", reason: "forgot_provision" },
                              { label: "❌ Time pressure", reason: "time_pressure" },
                              { label: "❌ Poor presentation", reason: "poor_presentation" },
                              { label: "❌ Guess", reason: "guess" },
                            ].map((item) => (
                              <button
                                key={item.reason}
                                type="button"
                                onClick={() => {
                                  alert(`Mistake tagged as: ${item.label}. Added to your Mistake Profile!`);
                                }}
                                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:border-rose-300 text-slate-700 dark:text-slate-300 text-left font-bold transition-all cursor-pointer truncate"
                              >
                                {item.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}

              <div className="flex justify-end">
                <button
                  onClick={() => setSubmittedQuiz(true)}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20"
                >
                  Submit & View Answers
                </button>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
