import React, { useState } from 'react';
import {
  Sparkles,
  Sun,
  Target,
  TrendingUp,
  Flame,
  CheckCircle2,
  Circle,
  Clock,
  ArrowRight,
  RefreshCw,
  X,
  Volume2,
  VolumeX,
  AlertTriangle,
  Play,
  BrainCircuit,
  Award,
  ChevronRight,
  BookOpen
} from 'lucide-react';
import { AIDailyBriefing, BriefingPriorityItem, ICAIStudentProfile } from '../types';

interface AIDailyBriefingModalProps {
  briefing: AIDailyBriefing;
  profile: ICAIStudentProfile;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string) => void;
  onTogglePriority: (id: string) => void;
  onRefreshBriefing: () => void;
  isRefreshing?: boolean;
  isDarkMode: boolean;
}

export const AIDailyBriefingModal: React.FC<AIDailyBriefingModalProps> = ({
  briefing,
  profile,
  isOpen,
  onClose,
  onNavigate,
  onTogglePriority,
  onRefreshBriefing,
  isRefreshing = false,
  isDarkMode,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  if (!isOpen) return null;

  const handleSpeakBriefing = () => {
    if ('speechSynthesis' in window) {
      if (isPlayingAudio) {
        window.speechSynthesis.cancel();
        setIsPlayingAudio(false);
        return;
      }

      const text = `${briefing.greeting}. Your preparation status is at ${briefing.readinessPercentage} percent, up ${briefing.yesterdayDeltaPct} percent from yesterday. Your top priorities today are: ${briefing.priorities.map(p => p.title).join(', ')}. Coach reminder: ${briefing.aiCoachQuote}`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);

      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    }
  };

  const getPriorityBadge = (iconType: string) => {
    switch (iconType) {
      case 'critical':
        return {
          symbol: '🔴',
          bg: 'bg-rose-50 dark:bg-rose-950/40',
          border: 'border-rose-200 dark:border-rose-900/50',
          text: 'text-rose-700 dark:text-rose-300',
          label: 'Critical Focus'
        };
      case 'high':
        return {
          symbol: '🟠',
          bg: 'bg-amber-50 dark:bg-amber-950/40',
          border: 'border-amber-200 dark:border-amber-900/50',
          text: 'text-amber-700 dark:text-amber-300',
          label: 'High Priority'
        };
      case 'revision':
        return {
          symbol: '🔄',
          bg: 'bg-blue-50 dark:bg-blue-950/40',
          border: 'border-blue-200 dark:border-blue-900/50',
          text: 'text-blue-700 dark:text-blue-300',
          label: 'Memory Retention'
        };
      case 'practice':
        return {
          symbol: '📝',
          bg: 'bg-purple-50 dark:bg-purple-950/40',
          border: 'border-purple-200 dark:border-purple-900/50',
          text: 'text-purple-700 dark:text-purple-300',
          label: 'Exam Speed Drill'
        };
      default:
        return {
          symbol: '⚡',
          bg: 'bg-indigo-50 dark:bg-indigo-950/40',
          border: 'border-indigo-200 dark:border-indigo-900/50',
          text: 'text-indigo-700 dark:text-indigo-300',
          label: 'Daily Task'
        };
    }
  };

  const completedCount = briefing.priorities.filter(p => p.completed).length;
  const progressPct = Math.round((completedCount / briefing.priorities.length) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fade-in">
      <div className={`relative w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-3xl border shadow-2xl transition-all ${
        isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        
        {/* Top Decorative Gradient Header */}
        <div className="relative p-6 pb-5 bg-gradient-to-r from-amber-500/15 via-purple-500/10 to-indigo-500/15 border-b border-slate-100 dark:border-slate-800">
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[11px] font-black uppercase tracking-wider flex items-center gap-1">
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>AI Daily Briefing</span>
            </span>
            <span className="text-[11px] font-bold text-slate-400">
              {briefing.dateString}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
            {briefing.greeting}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Here is your daily strategic exam plan calibrated to your recent mock mistakes and syllabus weightage.
          </p>

          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={handleSpeakBriefing}
              className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border transition-all cursor-pointer ${
                isPlayingAudio
                  ? 'bg-purple-600 text-white border-purple-600 animate-pulse'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-purple-50 dark:hover:bg-purple-950/40'
              }`}
            >
              {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-purple-600" />}
              <span>{isPlayingAudio ? 'Mute AI Briefing' : 'Listen to Audio Coach'}</span>
            </button>

            <button
              onClick={onRefreshBriefing}
              disabled={isRefreshing}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-purple-600' : ''}`} />
              <span>Regenerate Briefing</span>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">

          {/* 🎯 PREPARATION STATUS ROW */}
          <div>
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 block mb-2">
              Your preparation status
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              {/* 🎯 Readiness */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50/80 to-purple-50/50 dark:from-indigo-950/40 dark:to-purple-950/30 border border-indigo-200/80 dark:border-indigo-900/50 flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-black text-indigo-700 dark:text-indigo-300">
                    <Target className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Readiness Score</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-900 dark:text-white">
                      {briefing.readinessPercentage}%
                    </span>
                    <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                      Target 85%+
                    </span>
                  </div>
                </div>

                <div className="w-12 h-12 rounded-full border-4 border-indigo-600 flex items-center justify-center font-black text-xs text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-900 shadow-xs">
                  {briefing.readinessPercentage}%
                </div>
              </div>

              {/* 📈 Yesterday's Momentum */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50/80 to-teal-50/50 dark:from-emerald-950/40 dark:to-teal-950/30 border border-emerald-200/80 dark:border-emerald-900/50 flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700 dark:text-emerald-300">
                    <TrendingUp className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Yesterday's Progress</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-emerald-600 dark:text-emerald-400">
                      +{briefing.yesterdayDeltaPct}%
                    </span>
                    <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                      Daily Gain
                    </span>
                  </div>
                </div>

                <div className="p-2.5 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                  <Flame className="w-6 h-6 text-amber-500" />
                </div>
              </div>

            </div>
          </div>

          {/* 📋 TODAY'S PRIORITIES */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                Today's priorities
              </span>
              <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
                {completedCount} of {briefing.priorities.length} Completed ({progressPct}%)
              </span>
            </div>

            <div className="space-y-2.5">
              {briefing.priorities.map((item) => {
                const badge = getPriorityBadge(item.iconType);
                return (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                      item.completed
                        ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60'
                        : `${badge.bg} ${badge.border} shadow-xs`
                    }`}
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <button
                        onClick={() => onTogglePriority(item.id)}
                        className="mt-0.5 shrink-0 text-slate-400 hover:text-purple-600 transition-colors cursor-pointer"
                        title={item.completed ? 'Mark pending' : 'Mark completed'}
                      >
                        {item.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-400 hover:text-purple-600" />
                        )}
                      </button>

                      <div className="min-w-0 space-y-0.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm">{badge.symbol}</span>
                          <span className={`text-xs font-black ${item.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                            {item.title}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-md font-bold bg-white/80 dark:bg-slate-900/80 border border-slate-200/60 dark:border-slate-800 text-slate-600 dark:text-slate-300">
                            {item.estimatedMins} Mins
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium truncate">
                          {item.detail}
                        </p>
                      </div>
                    </div>

                    {item.actionView && !item.completed && (
                      <button
                        onClick={() => {
                          onClose();
                          onNavigate(item.actionView!);
                        }}
                        className="shrink-0 px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 hover:bg-purple-600 hover:text-white dark:hover:bg-purple-600 text-[11px] font-black text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                      >
                        <span>Start</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 🤖 AI COACH VOICE BOX */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white shadow-lg space-y-2 border border-purple-800/60">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1 rounded-lg bg-purple-500/20 text-purple-300">
                  <BrainCircuit className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-black uppercase tracking-wider text-purple-300">
                  AI Coach says:
                </span>
              </div>
              <span className="text-[10px] font-bold text-purple-300/80 px-2 py-0.5 rounded-full bg-purple-800/60">
                Live Diagnostic
              </span>
            </div>

            <p className="text-sm sm:text-base font-bold italic leading-snug text-purple-100">
              “{briefing.aiCoachQuote}”
            </p>

            <div className="flex items-center justify-between pt-2 border-t border-purple-800/40 text-[11px]">
              <span className="text-purple-300">
                Recommended: 90 mins on Audit SA 315
              </span>
              <button
                onClick={() => {
                  onClose();
                  onNavigate('ai-examiner');
                }}
                className="font-black text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>Launch SA 315 Drill</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-[11px] font-bold text-slate-400">
            Daily Goal: {briefing.targetHoursToday} Study Hours Target
          </span>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                onClose();
                onNavigate('today-ai-plan');
              }}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-white font-black text-xs transition-all cursor-pointer"
            >
              View Full Schedule
            </button>

            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs shadow-md shadow-purple-500/25 transition-all cursor-pointer"
            >
              Let's Crush Today 🚀
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
