import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  CheckCircle2, 
  Circle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Play, 
  Pause, 
  Square, 
  RotateCcw, 
  Clock, 
  Flame, 
  Zap, 
  Target, 
  BookOpen, 
  Repeat, 
  Award, 
  ArrowRight, 
  AlertCircle,
  Sliders,
  RefreshCw,
  Info,
  Layers,
  TrendingUp,
  BrainCircuit,
  Check
} from 'lucide-react';
import { DailyAITask, DailyAIPlan, Subject, TestRecord, ICAIStudentProfile, StudySession, SessionCategory } from '../types';

interface TodayAIPlanViewProps {
  profile: ICAIStudentProfile;
  subjects: Subject[];
  testRecords: TestRecord[];
  onLogSession: (session: StudySession) => void;
  onAwardXp?: (amount: number, reason: string) => void;
  isDarkMode: boolean;
}

const DEFAULT_PLAN: DailyAIPlan = {
  date: new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' }),
  overallStrategy: "Precision diagnostic schedule targeting high-yield ICAI chapters with low test retention.",
  totalPlannedHours: "6.5 Hours",
  focusSubject: "Audit & Taxation",
  diagnosticSummary: "Based on your recent 5 test logs, your lowest accuracy is in Audit SA Standards (54%) and GST Input Tax Credit (ITC). Today's schedule prioritizes these high-yield topics during peak cognitive alertness.",
  tasks: [
    {
      id: "task_1",
      timeSlot: "2:00–3:30 PM",
      subjectName: "Audit",
      subjectCode: "P5",
      topic: "SA 315 (Identifying and Assessing Risks of Material Misstatement)",
      taskType: "concept",
      taskIcon: "📖",
      reason: "Your last 3 tests show 54% accuracy.",
      detailedWhy: "SA 315 carries 8–12 mandatory marks in the ICAI Audit paper. Diagnostic test logs indicate recurring marks loss in Internal Control components and Risk Assessment Procedures. Scheduled at 2:00 PM during prime cognitive alertness to solidify core clauses.",
      metricHighlight: "Accuracy: 54% (Low)",
      priority: "Critical",
      durationMins: 90,
      isCompleted: false
    },
    {
      id: "task_2",
      timeSlot: "3:45–4:30 PM",
      subjectName: "Tax",
      subjectCode: "P4",
      topic: "GST – ITC (Input Tax Credit & Blocked Credit Sec 17(5))",
      taskType: "concept",
      taskIcon: "📖",
      reason: "High exam importance + low retention score.",
      detailedWhy: "Sec 16, 17(5), and 18 form the backbone of 14–18 marks in GST practical computations. Spaced repetition interval is overdue by 5 days, requiring an immediate 45-minute refresher before forgetting curves steepen.",
      metricHighlight: "High Weightage (16M)",
      priority: "High",
      durationMins: 45,
      isCompleted: false
    },
    {
      id: "task_3",
      timeSlot: "5:00–5:30 PM",
      subjectName: "Practice",
      subjectCode: "ALL",
      topic: "20 questions from previous exams (ICAI RTP & Past Papers)",
      taskType: "practice",
      taskIcon: "🎯",
      reason: "Application speed & ICAI examination pattern calibration.",
      detailedWhy: "Passive reading creates a false sense of mastery. Timed solving of 20 past questions directly trains exam-speed drafting under simulated ICAI 1.8 mins/mark pressure.",
      metricHighlight: "Active Speed Drill",
      priority: "High",
      durationMins: 30,
      isCompleted: false
    },
    {
      id: "task_4",
      timeSlot: "9:00–9:15 PM",
      subjectName: "Revision",
      subjectCode: "ALL",
      topic: "Revise yesterday's weak concepts & flashcard flags",
      taskType: "revision",
      taskIcon: "🔁",
      reason: "Revise yesterday's weak concepts to lock in memory consolidation.",
      detailedWhy: "Cognitive consolidation occurs overnight. Spending 15 targeted minutes reviewing flashcards and tagged test errors before sleeping increases memory retention by up to 68%.",
      metricHighlight: "Memory Consolidation",
      priority: "Medium",
      durationMins: 15,
      isCompleted: false
    }
  ]
};

export const TodayAIPlanView: React.FC<TodayAIPlanViewProps> = ({
  profile,
  subjects,
  testRecords,
  onLogSession,
  onAwardXp,
  isDarkMode,
}) => {
  const [plan, setPlan] = useState<DailyAIPlan>(() => {
    const saved = localStorage.getItem('ca_today_ai_plan');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_PLAN;
      }
    }
    return DEFAULT_PLAN;
  });

  const [expandedWhyIds, setExpandedWhyIds] = useState<Record<string, boolean>>({
    task_1: true, // Expand first "Why?" by default for instant delight
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [targetHours, setTargetHours] = useState<number>(6);
  const [customGoal, setCustomGoal] = useState<string>('');

  // Active Task Timer State
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [seconds, setSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [timerNotes, setTimerNotes] = useState<string>('');

  // Save to local storage
  useEffect(() => {
    localStorage.setItem('ca_today_ai_plan', JSON.stringify(plan));
  }, [plan]);

  // Stopwatch Interval
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    } else if (!isTimerRunning && seconds !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, seconds]);

  // Toggle "Why?" Details
  const toggleWhy = (taskId: string) => {
    setExpandedWhyIds(prev => ({
      ...prev,
      [taskId]: !prev[taskId]
    }));
  };

  // Toggle Task Completion
  const toggleTaskCompletion = (taskId: string) => {
    setPlan(prev => {
      const updatedTasks = prev.tasks.map(t => {
        if (t.id === taskId) {
          const nextCompleted = !t.isCompleted;
          if (nextCompleted && onAwardXp) {
            onAwardXp(30, `Completed task: ${t.subjectName} - ${t.topic}`);
          }
          return { ...t, isCompleted: nextCompleted };
        }
        return t;
      });
      return { ...prev, tasks: updatedTasks };
    });
  };

  // Start Focus Session for a Task
  const startTaskTimer = (task: DailyAITask) => {
    setActiveTaskId(task.id);
    setSeconds(0);
    setIsTimerRunning(true);
    setTimerNotes(`Focusing on: ${task.topic}`);
  };

  // Stop & Log Timer Session
  const handleEndTimer = () => {
    if (!activeTaskId) return;
    const task = plan.tasks.find(t => t.id === activeTaskId);
    if (!task) return;

    if (seconds < 10) {
      setIsTimerRunning(false);
      setActiveTaskId(null);
      setSeconds(0);
      return;
    }

    const durationMins = Math.max(1, Math.round(seconds / 60));
    const focusScore = Math.min(100, Math.max(70, 88 + Math.floor(Math.random() * 12)));

    // Find corresponding subject id
    const matchingSubject = subjects.find(s => 
      s.name.toLowerCase().includes(task.subjectName.toLowerCase()) || 
      task.subjectName.toLowerCase().includes(s.name.toLowerCase())
    ) || subjects[0];

    const categoryMap: Record<string, SessionCategory> = {
      concept: 'Reading',
      practice: 'Question Practice',
      revision: 'Revision',
      test: 'Mock Test',
      mcq: 'MCQs'
    };

    const newSession: StudySession = {
      id: `s_${Date.now()}`,
      subjectId: matchingSubject?.id || 'p1',
      category: categoryMap[task.taskType] || 'Question Practice',
      startTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      durationMins,
      focusScore,
      notes: timerNotes || `${task.subjectName}: ${task.topic}`,
    };

    onLogSession(newSession);

    // Auto mark task as completed if session was significant
    if (durationMins >= 10) {
      setPlan(prev => ({
        ...prev,
        tasks: prev.tasks.map(t => t.id === task.id ? { ...t, isCompleted: true } : t)
      }));
    }

    setIsTimerRunning(false);
    setActiveTaskId(null);
    setSeconds(0);
    setTimerNotes('');
  };

  // Generate Personalized Plan from AI
  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/ai/daily-personalized-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile,
          subjects,
          testRecords,
          targetHours,
          customGoal
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.plan && Array.isArray(data.plan.tasks)) {
          setPlan(data.plan);
          // Expand first task explanation
          setExpandedWhyIds({ [data.plan.tasks[0]?.id || 'task_1']: true });
        }
      }
    } catch (e) {
      console.error('Failed to generate AI plan:', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const formatTime = (totalSec: number) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const completedCount = plan.tasks.filter(t => t.isCompleted).length;
  const progressPct = plan.tasks.length > 0 ? Math.round((completedCount / plan.tasks.length) * 100) : 0;

  const activeTask = plan.tasks.find(t => t.id === activeTaskId);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Top Header Card */}
      <div className={`p-6 rounded-3xl border relative overflow-hidden transition-all ${
        isDarkMode 
          ? 'bg-gradient-to-br from-slate-900 via-indigo-950/70 to-slate-900 border-indigo-900/50 shadow-xl' 
          : 'bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50/50 border-indigo-100 shadow-sm'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-extrabold text-xs flex items-center gap-1.5">
                <Bot className="w-4 h-4" />
                <span>AI Intelligent Scheduling Engine</span>
              </span>
              <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Personalized for CA {profile.course}
              </span>
            </div>
            
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <span>🤖 Today's AI Plan</span>
            </h2>
            
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              Every study block is dynamically selected based on your test error history, low retention scores, and high-yield ICAI exam weightages — with clear <strong className="text-indigo-600 dark:text-indigo-400">Why?</strong> diagnostic reasoning.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-3 bg-white/80 dark:bg-slate-800/80 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs backdrop-blur-xs">
            <div className="text-center px-2">
              <div className="text-xs font-bold text-slate-400">Target</div>
              <div className="text-sm font-black text-indigo-600 dark:text-indigo-400">{plan.totalPlannedHours}</div>
            </div>
            <div className="h-7 w-px bg-slate-200 dark:bg-slate-700" />
            <div className="text-center px-2">
              <div className="text-xs font-bold text-slate-400">Progress</div>
              <div className="text-sm font-black text-emerald-600 dark:text-emerald-400">{completedCount}/{plan.tasks.length} Done</div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-5 space-y-1.5">
          <div className="flex justify-between text-[11px] font-bold text-slate-600 dark:text-slate-400">
            <span>Today's Completion Goal</span>
            <span>{progressPct}% Completed</span>
          </div>
          <div className="w-full h-2.5 bg-slate-200/70 dark:bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* AI Rationale Summary Banner */}
        <div className="mt-4 p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-200 dark:border-indigo-800/50 flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-200">
          <BrainCircuit className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="text-indigo-600 dark:text-indigo-400 font-extrabold">Diagnostic Rationale: </strong>
            {plan.diagnosticSummary}
          </div>
        </div>

        {/* AI Plan Re-generation Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-200/60 dark:border-slate-800/60 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-600 dark:text-slate-400">Daily Study Target:</span>
            <select
              value={targetHours}
              onChange={(e) => setTargetHours(Number(e.target.value))}
              className={`px-2.5 py-1 rounded-xl border text-xs font-bold ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <option value={4}>4 Hours (Light Sprint)</option>
              <option value={6}>6 Hours (Standard Deep Work)</option>
              <option value={8}>8 Hours (Intense Exam Prep)</option>
              <option value={10}>10 Hours (Ranker Grind)</option>
            </select>
          </div>

          <button
            onClick={handleGeneratePlan}
            disabled={isGenerating}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 text-white text-xs font-black shadow-md shadow-indigo-500/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Analyzing Test Records...' : 'Regenerate Plan with AI'}</span>
          </button>
        </div>
      </div>

      {/* ACTIVE TASK LIVE STOPWATCH DRAWER (When Timer is running) */}
      {activeTask && (
        <div className={`p-6 rounded-3xl border shadow-xl animate-in fade-in slide-in-from-top-4 duration-300 ${
          isDarkMode 
            ? 'bg-slate-900 border-amber-500/40 ring-1 ring-amber-500/20' 
            : 'bg-gradient-to-b from-amber-50/70 to-white border-amber-200 ring-1 ring-amber-300/30'
        }`}>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-xl shrink-0">
                {activeTask.taskIcon || '⏱️'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500 text-white animate-pulse">
                    Live Focus Block
                  </span>
                  <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                    {activeTask.timeSlot} — {activeTask.subjectName}
                  </span>
                </div>
                <div className="text-sm font-black text-slate-900 dark:text-white mt-0.5">
                  {activeTask.topic}
                </div>
              </div>
            </div>

            {/* Digital Clock & Controls */}
            <div className="flex items-center gap-4">
              <div className="px-4 py-2 rounded-2xl bg-slate-950 text-amber-400 font-mono text-2xl sm:text-3xl font-black tracking-wider border border-slate-800 shadow-inner">
                {formatTime(seconds)}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className={`p-3 rounded-2xl text-white font-bold transition-all shadow-md cursor-pointer ${
                    isTimerRunning 
                      ? 'bg-amber-500 hover:bg-amber-600' 
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                  title={isTimerRunning ? "Pause" : "Resume"}
                >
                  {isTimerRunning ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                </button>

                <button
                  onClick={handleEndTimer}
                  className="px-4 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Complete & Log</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TODAY'S AI PLAN TASK LIST */}
      <div className="space-y-4">
        
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-500" />
            <span>Scheduled Diagnostic Blocks</span>
          </h3>
          <span className="text-xs text-slate-400 font-bold">
            {plan.date}
          </span>
        </div>

        {plan.tasks.map((task, index) => {
          const isExpanded = !!expandedWhyIds[task.id];
          const isCurrentActive = activeTaskId === task.id;

          return (
            <div
              key={task.id}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                task.isCompleted
                  ? isDarkMode
                    ? 'bg-slate-900/60 border-slate-800 opacity-75'
                    : 'bg-slate-50 border-slate-200 opacity-80'
                  : isCurrentActive
                  ? isDarkMode
                    ? 'bg-slate-900 border-amber-500 ring-2 ring-amber-500/20 shadow-lg'
                    : 'bg-white border-amber-400 ring-2 ring-amber-400/20 shadow-md'
                  : isDarkMode
                  ? 'bg-slate-900 border-slate-800 hover:border-slate-700 shadow-xs'
                  : 'bg-white border-slate-200 hover:border-indigo-200 shadow-xs'
              }`}
            >
              
              {/* Task Header & Content */}
              <div className="p-5 space-y-3">
                
                {/* Top Row: Time Slot & Subject Badge */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    
                    {/* Completion Checkbox */}
                    <button
                      onClick={() => toggleTaskCompletion(task.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                        task.isCompleted
                          ? 'bg-emerald-500 text-white'
                          : isDarkMode
                          ? 'border-2 border-slate-700 hover:border-emerald-500 text-transparent'
                          : 'border-2 border-slate-300 hover:border-emerald-500 text-transparent'
                      }`}
                      title={task.isCompleted ? "Mark incomplete" : "Mark completed"}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </button>

                    {/* Time Slot — Subject Title */}
                    <h4 className={`text-base font-black tracking-tight ${
                      task.isCompleted 
                        ? 'line-through text-slate-400 dark:text-slate-500' 
                        : 'text-slate-900 dark:text-white'
                    }`}>
                      <span>{task.timeSlot}</span>
                      <span className="mx-2 text-slate-400 font-normal">—</span>
                      <span className="text-indigo-600 dark:text-indigo-400">{task.subjectName}</span>
                    </h4>
                  </div>

                  {/* Priority & Metric Tag */}
                  <div className="flex items-center gap-2">
                    {task.metricHighlight && (
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                        {task.metricHighlight}
                      </span>
                    )}

                    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                      task.priority === 'Critical'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        : task.priority === 'High'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                    }`}>
                      {task.priority} Priority
                    </span>
                  </div>
                </div>

                {/* Topic / Task Statement */}
                <div className="flex items-start gap-2 pt-0.5">
                  <span className="text-lg shrink-0 select-none">
                    {task.taskIcon || '📖'}
                  </span>
                  <div className={`text-sm font-extrabold ${
                    task.isCompleted ? 'text-slate-500 dark:text-slate-400' : 'text-slate-800 dark:text-slate-100'
                  }`}>
                    {task.topic}
                  </div>
                </div>

                {/* Reason Callout Box (Exact format from user prompt) */}
                <div className={`p-3 rounded-xl border text-xs font-semibold flex items-start gap-2 ${
                  isDarkMode 
                    ? 'bg-slate-950/60 border-slate-800 text-slate-300' 
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}>
                  <span className="font-black text-indigo-600 dark:text-indigo-400 shrink-0">Reason:</span>
                  <span className="leading-relaxed">{task.reason}</span>
                </div>

                {/* Action Bar: "Why?" Toggle + "Start Focus Timer" */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                  
                  {/* "Why?" Deep Diagnostic Button */}
                  <button
                    onClick={() => toggleWhy(task.id)}
                    className="text-xs font-black text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center gap-1.5 cursor-pointer py-1 px-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-all"
                  >
                    <Info className="w-3.5 h-3.5" />
                    <span>Why did AI pick this task?</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  {/* Focus Timer Launch Button */}
                  {!task.isCompleted && (
                    <button
                      onClick={() => isCurrentActive ? setIsTimerRunning(!isTimerRunning) : startTaskTimer(task)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                        isCurrentActive
                          ? 'bg-amber-500 hover:bg-amber-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {isCurrentActive ? (
                        <>
                          <Pause className="w-3 h-3 fill-current" />
                          <span>Timer Active ({formatTime(seconds)})</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3 h-3 fill-current" />
                          <span>Start Focus Stopwatch ({task.durationMins}m)</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

              </div>

              {/* EXPANDED "WHY?" REASONING BOX */}
              {isExpanded && (
                <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-gradient-to-r from-indigo-50/80 via-purple-50/60 to-pink-50/50 dark:from-indigo-950/40 dark:via-purple-950/30 dark:to-slate-900 space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-300 font-black uppercase text-[10px] tracking-wider">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    <span>AI Diagnostic Reasoning Engine</span>
                  </div>
                  
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                    {task.detailedWhy}
                  </p>
                </div>
              )}

            </div>
          );
        })}

      </div>

      {/* Motivational Bottom Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
        <div className="space-y-0.5 text-center sm:text-left">
          <div className="text-sm font-black flex items-center justify-center sm:justify-start gap-1.5 text-amber-400">
            <Flame className="w-4 h-4 fill-amber-400" />
            <span>Consistency Builds Chartered Accountants</span>
          </div>
          <p className="text-xs text-slate-300">
            Completing today's plan awards +120 XP and advances your CA Readiness Score.
          </p>
        </div>

        <button
          onClick={() => {
            const allCompleted = plan.tasks.every(t => t.isCompleted);
            if (allCompleted) {
              alert("All tasks are already completed! Fantastic job! 🎉");
            } else {
              setPlan(prev => ({
                ...prev,
                tasks: prev.tasks.map(t => ({ ...t, isCompleted: true }))
              }));
              if (onAwardXp) onAwardXp(120, "Completed all Today's AI Plan tasks!");
            }
          }}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black text-xs shadow-md shadow-emerald-500/25 flex items-center gap-1.5 cursor-pointer shrink-0 transition-all"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Mark All Today's Tasks Done</span>
        </button>
      </div>

    </div>
  );
};
