import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Flame,
  Zap,
  Clock,
  Sparkles,
  Filter,
  Bookmark,
  X,
  Trophy,
  Activity,
  Volume2,
  VolumeX,
  Maximize2,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

/* ─── Video Data ─────────────────────────────────────────────────── */
interface VideoItem {
  id: string;
  title: string;
  athlete: string;
  sport: string;
  category: 'Mindset' | 'Endurance' | 'Comeback' | 'Focus' | 'Discipline';
  duration: string;
  src: string;           // local /videos/<file>.mp4
  thumbnail: string;    // Mixkit CDN thumbnail
  description: string;
  studyTakeaway: string;
}

const MOTIVATIONAL_VIDEOS: VideoItem[] = [
  {
    id: '1',
    title: 'Mamba Mentality: Daily Relentless Execution',
    athlete: 'Kobe Bryant — Basketball Legend',
    sport: 'Basketball',
    category: 'Discipline',
    duration: '0:33',
    src: '/videos/basketball-discipline.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/43483/43483-thumb-360-0.jpg',
    description:
      'Outwork everyone when nobody is watching. True champions show up every single day — no excuses, just relentless execution on the practice court and in the exam room.',
    studyTakeaway:
      'Treat your 10-hour daily CA study plan like Kobe treated 4 AM practice. Consistency during unseen hours creates championship results.',
  },
  {
    id: '2',
    title: 'Knocked Down, Never Knocked Out',
    athlete: 'Mike Tyson — Boxing Champion',
    sport: 'Boxing',
    category: 'Comeback',
    duration: '0:28',
    src: '/videos/running-endurance.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/40969/40969-thumb-360-0.jpg',
    description:
      'Champions get knocked down. What separates them is getting back up faster than anyone else. Every setback is ammunition for the next comeback.',
    studyTakeaway:
      'Failed a mock test or previous CA attempt? Reset your strategy immediately and treat every new revision paper as a match-winning opportunity.',
  },
  {
    id: '3',
    title: 'Urban Sprint: Speed, Focus & Mental Clarity',
    athlete: 'City Athlete',
    sport: 'Running',
    category: 'Focus',
    duration: '0:22',
    src: '/videos/tennis-comeback.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/40766/40766-thumb-360-0.jpg',
    description:
      'Running through urban obstacles mirrors your CA exam journey — constant obstacles, noise, and pressure. Stay on course, keep your pace, and fix your gaze on the finish line.',
    studyTakeaway:
      'Maintain intense concentration during mock tests like you\'re running a race through busy streets. Distractions are just noise — filter them out.',
  },
  {
    id: '4',
    title: 'Pushing Past Exhaustion: The 40% Rule',
    athlete: 'David Goggins',
    sport: 'Strength Training',
    category: 'Endurance',
    duration: '0:38',
    src: '/videos/marathon-endurance.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/40248/40248-thumb-360-0.jpg',
    description:
      'When your brain tells you that you\'re done, you\'re only at 40% capacity. Every rep beyond exhaustion builds the mental armor that carries you through 3-hour exam papers.',
    studyTakeaway:
      'When exhausted during late-night Audit or Tax revisions, tap into your mental reservoir. You have far more than you think.',
  },
  {
    id: '5',
    title: 'Championship Calm Under High Pressure',
    athlete: 'Michael Jordan',
    sport: 'Mindset Training',
    category: 'Mindset',
    duration: '0:14',
    src: '/videos/focus-mindset.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/780/780-thumb-360-0.jpg',
    description:
      'Before every clutch moment, center yourself. Breathe. Champions don\'t panic — they execute. A quiet mind under pressure is the most powerful weapon you have in the exam hall.',
    studyTakeaway:
      'Practice a 2-minute mindfulness reset before every mock exam. Calm execution outperforms anxious rushing every single time.',
  },
  {
    id: '6',
    title: 'Lightweight Warrior: Power in Preparation',
    athlete: 'Every Champion Boxer',
    sport: 'Boxing',
    category: 'Discipline',
    duration: '0:31',
    src: '/videos/discipline-training.mp4',
    thumbnail: 'https://assets.mixkit.co/videos/45874/45874-thumb-360-4.jpg',
    description:
      'Greatness is forged in the training hall long before the spotlight arrives. Every shadow-box rep, every early morning drill — that\'s your CA preparation in miniature.',
    studyTakeaway:
      'Your toughest CA chapters are your heavy bags. Hit them hard every day. When exam day arrives, you\'ll be ready.',
  },
];

/* ─── Props ──────────────────────────────────────────────────────── */
interface SportsMotivationalVideosViewProps {
  isDarkMode: boolean;
}

/* ─── Helper: Category colours ───────────────────────────────────── */
const categoryColor: Record<string, string> = {
  Discipline: 'bg-orange-600',
  Focus: 'bg-blue-600',
  Endurance: 'bg-emerald-600',
  Comeback: 'bg-rose-600',
  Mindset: 'bg-violet-600',
};

/* ═══════════════════════════════════════════════════════════════════
   VIDEO PLAYER MODAL
═══════════════════════════════════════════════════════════════════ */
interface VideoPlayerProps {
  video: VideoItem;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
  hasPrev: boolean;
  hasNext: boolean;
  isDarkMode: boolean;
}

const VideoPlayerModal: React.FC<VideoPlayerProps> = ({
  video, onClose, onPrev, onNext, hasPrev, hasNext, isDarkMode,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.load();
    v.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  }, [video.id]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { v.play(); setPlaying(true); }
    else { v.pause(); setPlaying(false); }
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setCurrentTime(v.currentTime);
    setProgress(v.currentTime / (v.duration || 1));
  };

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (!v) return;
    setDuration(v.duration);
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    if (!v) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    v.currentTime = pct * v.duration;
  };

  const handleFullscreen = () => {
    const v = videoRef.current as any;
    if (!v) return;
    (v.requestFullscreen || v.webkitRequestFullscreen || v.mozRequestFullScreen)?.call(v);
  };

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className={`w-full max-w-3xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[95vh] ${
          isDarkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'
        }`}
        onClick={e => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className={`flex items-center justify-between gap-3 px-4 py-3 border-b ${
          isDarkMode ? 'border-slate-800' : 'border-slate-200'
        }`}>
          <div className="flex items-center gap-2 min-w-0">
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold text-white uppercase shrink-0 ${categoryColor[video.category]}`}>
              {video.category}
            </span>
            <h3 className="text-sm font-bold truncate">{video.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video element */}
        <div className="relative bg-black w-full">
          <video
            ref={videoRef}
            src={video.src}
            className="w-full max-h-[50vh] object-contain"
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onEnded={() => setPlaying(false)}
            onClick={togglePlay}
            playsInline
          />

          {/* Controls overlay */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 flex flex-col gap-2">
            {/* Progress bar */}
            <div
              className="w-full h-1.5 bg-white/20 rounded-full cursor-pointer"
              onClick={handleSeek}
            >
              <div
                className="h-full bg-indigo-500 rounded-full transition-all"
                style={{ width: `${progress * 100}%` }}
              />
            </div>

            {/* Buttons row */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {/* Prev */}
                <button
                  onClick={e => { e.stopPropagation(); onPrev(); }}
                  disabled={!hasPrev}
                  className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/15 disabled:opacity-30 transition-all"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {/* Play/Pause */}
                <button
                  onClick={e => { e.stopPropagation(); togglePlay(); }}
                  className="w-9 h-9 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center transition-all"
                >
                  {playing
                    ? <Pause className="w-4 h-4 fill-white" />
                    : <Play className="w-4 h-4 fill-white ml-0.5" />}
                </button>

                {/* Next */}
                <button
                  onClick={e => { e.stopPropagation(); onNext(); }}
                  disabled={!hasNext}
                  className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/15 disabled:opacity-30 transition-all"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {/* Time */}
                <span className="text-white/70 text-[11px] font-mono ml-1">
                  {fmt(currentTime)} / {fmt(duration)}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* Mute */}
                <button
                  onClick={e => { e.stopPropagation(); toggleMute(); }}
                  className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/15 transition-all"
                >
                  {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                {/* Fullscreen */}
                <button
                  onClick={e => { e.stopPropagation(); handleFullscreen(); }}
                  className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/15 transition-all"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Info body */}
        <div className="p-5 space-y-3 overflow-y-auto">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-bold text-orange-500 flex items-center gap-1">
              <Flame className="w-4 h-4 fill-orange-500" />
              {video.athlete} · {video.sport}
            </span>
            <span>{video.duration}</span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {video.description}
          </p>

          <div className="p-3.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-xs">
            <div className="font-bold text-indigo-700 dark:text-indigo-300 uppercase text-[10px] tracking-wider mb-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Key Takeaway for your CA Exam Preparation
            </div>
            <p className="text-slate-700 dark:text-slate-200 font-medium">{video.studyTakeaway}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════════════════════════════
   MAIN VIEW
═══════════════════════════════════════════════════════════════════ */
export const SportsMotivationalVideosView: React.FC<SportsMotivationalVideosViewProps> = ({ isDarkMode }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [savedVideoIds, setSavedVideoIds] = useState<string[]>(['1', '4']);

  const categories = ['All', 'Discipline', 'Focus', 'Endurance', 'Comeback', 'Mindset'];
  const filteredVideos = selectedCategory === 'All'
    ? MOTIVATIONAL_VIDEOS
    : MOTIVATIONAL_VIDEOS.filter(v => v.category === selectedCategory);

  const toggleSave = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedVideoIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const openVideo = (idx: number) => setActiveIndex(idx);
  const closeVideo = () => setActiveIndex(null);
  const prevVideo = () => setActiveIndex(i => (i !== null && i > 0 ? i - 1 : i));
  const nextVideo = () => setActiveIndex(i => (i !== null && i < filteredVideos.length - 1 ? i + 1 : i));

  return (
    <div className="space-y-6 max-w-6xl mx-auto">

      {/* ── Header Banner ─────────────────────────────────────────── */}
      <div className={`p-6 sm:p-8 rounded-2xl border relative overflow-hidden ${
        isDarkMode
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-slate-800'
          : 'bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white border-indigo-900 shadow-lg'
      }`}>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center gap-1">
                <Flame className="w-3 h-3 fill-orange-400" /> Sportic High-Energy Motivation
              </span>
              <span className="text-xs text-indigo-200 font-medium">Peak Performance Mindset</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Athletic Discipline for CA Exam Marathon
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Fuel your 8–12 hour daily study sessions with high-octane sports motivation.
              All videos play <strong className="text-white">directly inside the app</strong> — no YouTube required.
            </p>

            <div className="flex items-center gap-2 pt-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                ✅ Plays Offline · No YouTube Needed
              </span>
              <span className="text-[10px] text-slate-400">Free stock footage — fully licensed</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/15 flex items-center gap-4 shrink-0">
            <div className="w-12 h-12 rounded-xl bg-orange-500/20 border border-orange-400/40 flex items-center justify-center text-orange-400">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-200 uppercase tracking-wider">Exam Endurance</p>
              <p className="text-lg font-black text-white">100% Grit Mode</p>
              <p className="text-[10px] text-orange-300 font-medium">6 High-Impact Videos</p>
            </div>
          </div>
        </div>
      </div>

      {/* ── Category Filter Pills ──────────────────────────────────── */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0 mr-1">
          <Filter className="w-3.5 h-3.5" /> Category:
        </span>
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
              selectedCategory === cat
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                : isDarkMode
                  ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* ── Video Card Grid ────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVideos.map((video, idx) => {
          const isSaved = savedVideoIds.includes(video.id);

          return (
            <div
              key={video.id}
              onClick={() => openVideo(idx)}
              className={`rounded-2xl border overflow-hidden cursor-pointer group transition-all duration-200 hover:-translate-y-1 flex flex-col justify-between ${
                isDarkMode
                  ? 'bg-slate-900 border-slate-800 hover:border-indigo-500/50 hover:shadow-xl hover:shadow-indigo-950/40'
                  : 'bg-white border-slate-200 hover:border-indigo-300 shadow-sm hover:shadow-md'
              }`}
            >
              {/* Thumbnail / preview */}
              <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                {/* Static thumbnail image */}
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                  onError={e => {
                    (e.target as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&auto=format&fit=crop&q=80';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/20" />

                {/* Play button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:bg-indigo-500 transition-all">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>

                {/* In-app badge */}
                <span className="absolute bottom-2.5 left-2.5 flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-700/90 text-white text-[10px] font-bold shadow-md">
                  ▶ Plays In-App
                </span>

                {/* Duration */}
                <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 text-white text-[10px] font-bold flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {video.duration}
                </span>

                {/* Category */}
                <span className={`absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider text-white shadow-md ${categoryColor[video.category]}`}>
                  {video.category}
                </span>

                {/* Bookmark */}
                <button
                  onClick={e => toggleSave(video.id, e)}
                  className={`absolute top-2.5 right-2.5 p-1.5 rounded-full backdrop-blur-md transition-colors ${
                    isSaved ? 'bg-orange-500 text-white' : 'bg-black/40 text-slate-200 hover:bg-black/70'
                  }`}
                  title={isSaved ? 'Saved' : 'Save for study break'}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
                </button>
              </div>

              {/* Video info */}
              <div className="p-4 space-y-2">
                <div className="flex items-center gap-2 text-[11px] font-bold text-orange-500">
                  <Activity className="w-3.5 h-3.5" />
                  <span>{video.athlete} · {video.sport}</span>
                </div>

                <h3 className={`text-sm font-bold line-clamp-2 group-hover:text-indigo-600 transition-colors ${
                  isDarkMode ? 'text-white dark:group-hover:text-indigo-400' : 'text-slate-900'
                }`}>
                  {video.title}
                </h3>

                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                  {video.description}
                </p>
              </div>

              {/* CA Study Takeaway */}
              <div className="p-3 mx-4 mb-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900/50 text-[11px] font-medium text-indigo-900 dark:text-indigo-300 space-y-1">
                <div className="flex items-center gap-1 font-bold text-indigo-700 dark:text-indigo-400 uppercase text-[10px] tracking-wider">
                  <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />
                  <span>CA Exam Application</span>
                </div>
                <p className="leading-snug">{video.studyTakeaway}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Video Player Modal ─────────────────────────────────────── */}
      {activeIndex !== null && (
        <VideoPlayerModal
          video={filteredVideos[activeIndex]}
          onClose={closeVideo}
          onPrev={prevVideo}
          onNext={nextVideo}
          hasPrev={activeIndex > 0}
          hasNext={activeIndex < filteredVideos.length - 1}
          isDarkMode={isDarkMode}
        />
      )}
    </div>
  );
};
