import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.camentor.ai',
  appName: 'CA Mentor AI',
  webDir: 'dist'
};

export default config;
