package com.camentor.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
