"""
staff_panel.py
Rendered only for users with role == 'staff'.

CRITICAL SECURITY NOTE: every query here calls db.get_tasks_for_staff(user["id"]),
which filters by assigned_to = user["id"] at the SQL layer inside db.py.
This file never fetches all tasks and filters client-side - that would be
the kind of bug that leaks other staff's data if ever written wrong. The
enforcement point is the database query, not this UI code.
"""

import streamlit as st
import db
from app import is_overdue, status_badge_class, render_header


def render(user: dict):
    render_header(f"My Tasks — welcome, {user['name']}")

    tasks = db.get_tasks_for_staff(user["id"])

    if not tasks:
        st.info("You have no tasks assigned yet.")
        return

    # --- Banner: overdue / pending summary, shown every login -------------
    open_tasks = [t for t in tasks if t["current_status"] != "Done"]
    overdue_tasks = [t for t in open_tasks if is_overdue(t)]
    pending_tasks = [t for t in open_tasks if t["current_status"] == "Pending"]

    if overdue_tasks or pending_tasks:
        b1, b2, b3 = st.columns(3)
        with b1:
            st.markdown(
                f'<div class="metric-card" style="border-left-color:#DC2626;">'
                f'<h3>{len(overdue_tasks)}</h3><p>Overdue</p></div>',
                unsafe_allow_html=True,
            )
        with b2:
            st.markdown(
                f'<div class="metric-card" style="border-left-color:#D97706;">'
                f'<h3>{len(pending_tasks)}</h3><p>Pending (not started)</p></div>',
                unsafe_allow_html=True,
            )
        with b3:
            st.markdown(
                f'<div class="metric-card" style="border-left-color:#16A34A;">'
                f'<h3>{len(open_tasks)}</h3><p>Total open tasks</p></div>',
                unsafe_allow_html=True,
            )
        st.write("")

    # --- Filter -------------------------------------------------------
    status_filter = st.radio(
        "Show:", ["All", "Pending", "In Process", "Done"], horizontal=True
    )
    if status_filter != "All":
        visible_tasks = [t for t in tasks if t["current_status"] == status_filter]
    else:
        visible_tasks = tasks

    st.write("")

    # --- Task cards -----------------------------------------------------
    for task in visible_tasks:
        overdue = is_overdue(task)
        card_class = f"task-card priority-{task['priority']}" + (" overdue" if overdue else "")
        badge_status = status_badge_class(task["current_status"])

        with st.container():
            st.markdown(
                f"""
                <div class="{card_class}">
                    <div class="task-title">{task['title']}</div>
                    <div class="task-meta">
                        <span class="badge badge-{badge_status}">{task['current_status']}</span>
                        <span class="badge badge-{task['priority']}">{task['priority']} priority</span>
                        {'<span class="badge badge-overdue">OVERDUE</span>' if overdue else ''}
                        {f" · Category: {task['category_name']}" if task['category_name'] else ""}
                        {f" · Due: {task['due_date']}" if task['due_date'] else " · No due date"}
                        · Assigned by: {task['assigned_by_name']}
                    </div>
                    {f'<div class="task-desc">{task["description"]}</div>' if task['description'] else ''}
                </div>
                """,
                unsafe_allow_html=True,
            )

            with st.expander("Update status / view history"):
                col1, col2 = st.columns([1, 2])
                with col1:
                    new_status = st.selectbox(
                        "Status",
                        ["Pending", "In Process", "Done"],
                        index=["Pending", "In Process", "Done"].index(task["current_status"]),
                        key=f"status_{task['id']}",
                    )
                with col2:
                    remarks = st.text_area(
                        "Remarks (optional)",
                        key=f"remarks_{task['id']}",
                        placeholder="e.g. Draft ready, sent for your review.",
                        height=80,
                    )

                if st.button("Submit update", key=f"submit_{task['id']}"):
                    ok, msg = db.add_status_update(task["id"], new_status, remarks, user["id"])
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)

                st.markdown("**History**")
                history = db.get_status_history(task["id"])
                for h in history:
                    st.caption(
                        f"{h['updated_at'][:16].replace('T', ' ')} — "
                        f"**{h['status']}** by {h['updated_by_name']}"
                        + (f": {h['remarks']}" if h["remarks"] else "")
                    )
