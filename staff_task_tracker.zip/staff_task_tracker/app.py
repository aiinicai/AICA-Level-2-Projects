"""
app.py
Staff Work Allocation & Status Tracker
Main entry point: handles login/session and routes to admin or staff view.

Run locally with:  streamlit run app.py
"""

import streamlit as st
import db
import base64
from pathlib import Path
from datetime import date
import pandas as pd

st.set_page_config(
    page_title="Staff Operations Portal | Saawariya & Co.",
    page_icon="✅",
    layout="wide",
    initial_sidebar_state="expanded",
)

db.init_db()


def _img_b64(path: str) -> str:
    """Reads an image file and returns a base64 string for inline embedding
    in HTML/CSS — needed because Streamlit's st.image() can't be positioned
    freely inside a custom-styled header banner."""
    data = Path(path).read_bytes()
    return base64.b64encode(data).decode("utf-8")


VAC_LOGO_B64 = _img_b64("assets/vac_logo.png")
TWT_LOGO_B64 = _img_b64("assets/twt_logo.png")

APP_NAME = "Staff Operations Portal"

# ---------------------------------------------------------------------------
# Custom styling - card-based layout, colored badges, no default Streamlit
# gray look. Kept in one CSS block so it's easy to re-theme later.
# ---------------------------------------------------------------------------

CUSTOM_CSS = """
<style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}

    .app-header {
        position: relative;
        padding: 1.4rem 6rem;
        border-radius: 16px;
        background: linear-gradient(135deg, #1E3A8A 0%, #4F46E5 55%, #2563EB 100%);
        color: white;
        margin-bottom: 1.5rem;
        text-align: center;
        overflow: visible;
        box-shadow: 0 4px 18px rgba(30, 58, 138, 0.35);
    }
    .app-header h1 {
        margin: 0;
        font-size: 1.7rem;
        letter-spacing: 0.02em;
        text-shadow: 0 1px 4px rgba(0,0,0,0.25);
    }
    .app-header p { margin: 0.3rem 0 0 0; opacity: 0.92; font-size: 0.9rem; }

    .logo-badge {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: white;
        border-radius: 16px;
        padding: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        transition: transform 0.2s ease;
    }
    .logo-badge img { display: block; height: 58px; width: auto; border-radius: 10px; }

    .logo-badge-left {
        left: 22px;
        transform: translateY(-50%) rotate(-6deg);
    }
    .logo-badge-right {
        right: 22px;
        transform: translateY(-50%) rotate(6deg);
        background: linear-gradient(135deg, #F8FAFC, #E0E7FF);
    }
    .logo-badge-left:hover, .logo-badge-right:hover {
        transform: translateY(-50%) rotate(0deg) scale(1.05);
    }

    .app-footer {
        text-align: center;
        color: #94A3B8;
        font-size: 0.8rem;
        padding: 1.4rem 0 0.6rem 0;
        margin-top: 2rem;
        border-top: 1px solid #E2E8F0;
        letter-spacing: 0.03em;
    }
    .app-footer b { color: #64748B; }

    .metric-card {
        background: white;
        border-radius: 12px;
        padding: 1rem 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        border-left: 5px solid #2563EB;
    }
    .metric-card h3 { margin: 0; font-size: 1.8rem; color: #1E293B; }
    .metric-card p { margin: 0; color: #64748B; font-size: 0.85rem; }

    .task-card {
        background: white;
        border-radius: 12px;
        padding: 1rem 1.3rem;
        margin-bottom: 0.8rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        border-left: 5px solid #CBD5E1;
    }
    .task-card.priority-High { border-left-color: #DC2626; }
    .task-card.priority-Medium { border-left-color: #D97706; }
    .task-card.priority-Low { border-left-color: #16A34A; }
    .task-card.overdue { background: #FEF2F2; }

    .badge {
        display: inline-block;
        padding: 0.15rem 0.6rem;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 0.3rem;
    }
    .badge-Pending { background: #FEF3C7; color: #92400E; }
    .badge-InProcess { background: #DBEAFE; color: #1E40AF; }
    .badge-Done { background: #DCFCE7; color: #166534; }
    .badge-High { background: #FEE2E2; color: #991B1B; }
    .badge-Medium { background: #FEF3C7; color: #92400E; }
    .badge-Low { background: #E0F2FE; color: #075985; }
    .badge-overdue { background: #DC2626; color: white; }

    .task-title { font-weight: 700; font-size: 1.05rem; color: #1E293B; }
    .task-meta { color: #64748B; font-size: 0.82rem; margin-top: 0.1rem; }
    .task-desc { color: #334155; font-size: 0.9rem; margin-top: 0.5rem; white-space: pre-wrap; }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# PWA setup — manifest, icons, service worker. Requires enableStaticServing
# in .streamlit/config.toml and a static/ folder deployed alongside app.py.
# Deliberately no offline caching of task data (see static/sw.js) — this
# only makes the app installable as a home-screen app with its own icon
# and no browser chrome, not usable without a network connection.
# ---------------------------------------------------------------------------
PWA_SETUP_JS = """
<script>
(function() {
    if (!document.querySelector('link[rel="manifest"]')) {
        var link = document.createElement('link');
        link.rel = 'manifest';
        link.href = 'app/static/manifest.json';
        document.head.appendChild(link);
    }
    if (!document.querySelector('meta[name="theme-color"]')) {
        var meta = document.createElement('meta');
        meta.name = 'theme-color';
        meta.content = '#2563EB';
        document.head.appendChild(meta);
    }
    if (!document.querySelector('link[rel="apple-touch-icon"]')) {
        var appleIcon = document.createElement('link');
        appleIcon.rel = 'apple-touch-icon';
        appleIcon.href = 'app/static/icon-192.png';
        document.head.appendChild(appleIcon);
    }
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('app/static/sw.js').catch(function(err) {
            console.warn('Service worker registration failed:', err);
        });
    }
})();
</script>
"""
st.markdown(PWA_SETUP_JS, unsafe_allow_html=True)


def render_header(subtitle: str):
    """Shared branded header: VAC logo top-left, TWT logo top-right, both
    tilted and card-mounted for a designed feel rather than flat corner
    placement. Used on the login screen and every interior page."""
    st.markdown(
        f"""
        <div class="app-header">
            <div class="logo-badge logo-badge-left">
                <img src="data:image/png;base64,{VAC_LOGO_B64}" alt="VAC logo">
            </div>
            <h1>📋 {APP_NAME}</h1>
            <p>{subtitle}</p>
            <div class="logo-badge logo-badge-right">
                <img src="data:image/png;base64,{TWT_LOGO_B64}" alt="TWT logo">
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_footer():
    st.markdown(
        '<div class="app-footer">Developed by <b>Team TAX WITHOUT TEARS</b></div>',
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Session state helpers
# ---------------------------------------------------------------------------

def init_session():
    if "user" not in st.session_state:
        st.session_state.user = None


def logout():
    st.session_state.user = None
    st.rerun()


def status_badge_class(status: str) -> str:
    return status.replace(" ", "")


def is_overdue(task: dict) -> bool:
    if task["current_status"] == "Done" or not task["due_date"]:
        return False
    return task["due_date"] < date.today().isoformat()


# ---------------------------------------------------------------------------
# Login screen
# ---------------------------------------------------------------------------

def login_screen():
    render_header("Internal Task Management System")

    col1, col2, col3 = st.columns([1, 1.2, 1])
    with col2:
        st.markdown("### Login")
        with st.form("login_form"):
            username = st.text_input("Email")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Log in", width='stretch')

        if submitted:
            if not username or not password:
                st.error("Enter both your email and password.")
            else:
                user = db.authenticate(username.strip(), password)
                if user:
                    st.session_state.user = user
                    st.rerun()
                else:
                    st.error("Invalid email or password, or account is inactive.")

    render_footer()


# ---------------------------------------------------------------------------
# Main router
# ---------------------------------------------------------------------------

def main():
    init_session()

    if st.session_state.user is None:
        login_screen()
        return

    user = st.session_state.user

    with st.sidebar:
        st.markdown(f"**{user['name']}**")
        st.caption(f"Role: {user['role'].capitalize()}")
        st.divider()
        if st.button("Log out", width='stretch'):
            logout()

    if user["role"] == "admin":
        import admin_panel
        admin_panel.render(user)
    else:
        import staff_panel
        staff_panel.render(user)

    render_footer()


if __name__ == "__main__":
    main()
