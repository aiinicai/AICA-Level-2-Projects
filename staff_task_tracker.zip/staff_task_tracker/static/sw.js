/*
Minimal service worker for the Staff Operations Portal PWA.

Deliberately does NOT cache task data, status updates, or anything from
the live app — this is a live-data tool (task assignments, statuses,
remarks change constantly), and caching stale responses would mean a
staff member could see out-of-date task info while believing it's
current. That's worse than no offline support at all for this use case.

This service worker exists only to satisfy the browser's installability
requirement (a registered service worker is one of the PWA install
criteria alongside the manifest and HTTPS). It passes every network
request straight through with no caching layer.
*/

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  // Network-only passthrough — no caching, no offline fallback.
  event.respondWith(fetch(event.request));
});
