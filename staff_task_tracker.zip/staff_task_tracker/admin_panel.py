"""
admin_panel.py
Rendered only for users with role == 'admin'. Both admins (as agreed) get
identical permissions - no hierarchy between them.
"""

import streamlit as st
import db
import pandas as pd
from datetime import date, timedelta
from app import is_overdue, status_badge_class, render_header


def render(user: dict):
    render_header(f"Admin Dashboard — logged in as {user['name']}")

    tab_dashboard, tab_new_task, tab_categories, tab_users, tab_export = st.tabs(
        ["📊 Dashboard", "➕ New Task", "🏷️ Categories", "👥 Staff & Admins", "📥 Export"]
    )

    with tab_dashboard:
        render_dashboard()
    with tab_new_task:
        render_new_task(user)
    with tab_categories:
        render_categories(user)
    with tab_users:
        render_users(user)
    with tab_export:
        render_export()


# ---------------------------------------------------------------------------
# Dashboard tab
# ---------------------------------------------------------------------------

def render_dashboard():
    tasks = db.get_all_tasks()

    if not tasks:
        st.info("No tasks created yet. Use the 'New Task' tab to assign the first one.")
        return

    pending = sum(1 for t in tasks if t["current_status"] == "Pending")
    in_process = sum(1 for t in tasks if t["current_status"] == "In Process")
    done = sum(1 for t in tasks if t["current_status"] == "Done")
    overdue = sum(1 for t in tasks if is_overdue(t))

    m1, m2, m3, m4 = st.columns(4)
    for col, val, label, color in [
        (m1, pending, "Pending", "#D97706"),
        (m2, in_process, "In Process", "#2563EB"),
        (m3, done, "Done", "#16A34A"),
        (m4, overdue, "Overdue", "#DC2626"),
    ]:
        with col:
            st.markdown(
                f'<div class="metric-card" style="border-left-color:{color};">'
                f'<h3>{val}</h3><p>{label}</p></div>',
                unsafe_allow_html=True,
            )

    st.write("")

    # --- Filters ------------------------------------------------------
    staff_list = db.get_all_staff()
    categories = db.get_categories()

    f1, f2, f3 = st.columns(3)
    with f1:
        staff_names = ["All"] + [s["name"] for s in staff_list]
        staff_filter = st.selectbox("Filter by staff", staff_names)
    with f2:
        status_filter = st.selectbox("Filter by status", ["All", "Pending", "In Process", "Done"])
    with f3:
        cat_names = ["All"] + [c["name"] for c in categories]
        cat_filter = st.selectbox("Filter by category", cat_names)

    filtered = tasks
    if staff_filter != "All":
        filtered = [t for t in filtered if t["assigned_to_name"] == staff_filter]
    if status_filter != "All":
        filtered = [t for t in filtered if t["current_status"] == status_filter]
    if cat_filter != "All":
        filtered = [t for t in filtered if t["category_name"] == cat_filter]

    st.caption(f"Showing {len(filtered)} of {len(tasks)} tasks")
    st.write("")

    # --- Workload snapshot ----------------------------------------------
    with st.expander("Staff workload snapshot (check before assigning new work)"):
        wl_rows = []
        for s in staff_list:
            wl = db.get_staff_workload(s["id"])
            wl_rows.append({
                "Staff": s["name"],
                "Open tasks": wl["open"],
                "Overdue": wl["overdue"],
                "Total (all time)": wl["total"],
            })
        if wl_rows:
            st.dataframe(pd.DataFrame(wl_rows), width='stretch', hide_index=True)

    # --- Task cards -----------------------------------------------------
    for task in filtered:
        overdue_flag = is_overdue(task)
        card_class = f"task-card priority-{task['priority']}" + (" overdue" if overdue_flag else "")
        badge_status = status_badge_class(task["current_status"])

        st.markdown(
            f"""
            <div class="{card_class}">
                <div class="task-title">{task['title']}</div>
                <div class="task-meta">
                    <span class="badge badge-{badge_status}">{task['current_status']}</span>
                    <span class="badge badge-{task['priority']}">{task['priority']} priority</span>
                    {'<span class="badge badge-overdue">OVERDUE</span>' if overdue_flag else ''}
                    · Assigned to: <b>{task['assigned_to_name']}</b>
                    {f" · Category: {task['category_name']}" if task['category_name'] else ""}
                    {f" · Due: {task['due_date']}" if task['due_date'] else " · No due date"}
                    · By: {task['assigned_by_name']}
                </div>
                {f'<div class="task-desc">{task["description"]}</div>' if task['description'] else ''}
            </div>
            """,
            unsafe_allow_html=True,
        )
        with st.expander(f"History for '{task['title']}'"):
            history = db.get_status_history(task["id"])
            for h in history:
                st.caption(
                    f"{h['updated_at'][:16].replace('T', ' ')} — "
                    f"**{h['status']}** by {h['updated_by_name']}"
                    + (f": {h['remarks']}" if h["remarks"] else "")
                )


# ---------------------------------------------------------------------------
# New Task tab
# ---------------------------------------------------------------------------

def render_new_task(user: dict):
    st.subheader("Assign a new task")

    staff_list = db.get_all_staff()
    categories = db.get_categories()

    if not staff_list:
        st.warning("No staff accounts exist yet. Add staff in the 'Staff & Admins' tab first.")
        return

    staff_options = {s["name"]: s["id"] for s in staff_list}

    selected_staff_name = st.selectbox("Assign to", list(staff_options.keys()))
    selected_staff_id = staff_options[selected_staff_name]

    # Show workload before assigning, so a double-booking risk is visible
    # right at the point of decision (agreed during planning).
    wl = db.get_staff_workload(selected_staff_id)
    st.caption(
        f"{selected_staff_name} currently has **{wl['open']} open task(s)**, "
        f"of which **{wl['overdue']} overdue**."
    )

    with st.form("new_task_form", clear_on_submit=True):
        title = st.text_input("Title (short, shows in task list)*", placeholder="e.g. Ecopack Solutions — Annexure B — August")

        cat_options = ["-- No category --"] + [c["name"] for c in categories]
        cat_choice = st.selectbox("Category", cat_options)

        description = st.text_area(
            "Description / instructions for staff",
            placeholder="Full instructions here — e.g. Prepare Annexure B for FY 25-26, use GSTR-2B as base, flag mismatches, send draft by Thursday.",
            height=150,
        )

        col1, col2 = st.columns(2)
        with col1:
            priority = st.selectbox("Priority", ["High", "Medium", "Low"], index=1)
        with col2:
            due = st.date_input("Due date", value=date.today() + timedelta(days=7))

        submitted = st.form_submit_button("Assign task", width='stretch')

    if submitted:
        category_id = None
        if cat_choice != "-- No category --":
            category_id = next(c["id"] for c in categories if c["name"] == cat_choice)

        ok, msg = db.create_task(
            title=title,
            category_id=category_id,
            description=description,
            assigned_to=selected_staff_id,
            assigned_by=user["id"],
            priority=priority,
            due_date=due,
        )
        if ok:
            st.success(msg)
        else:
            st.error(msg)


# ---------------------------------------------------------------------------
# Categories tab
# ---------------------------------------------------------------------------

def render_categories(user: dict):
    st.subheader("Manage categories")
    st.caption(
        "Categories are the dropdown options staff and admins use to tag tasks "
        "(e.g. GST Refund, Litigation, Content). Deleting a category is blocked "
        "if any task still uses it — reassign those tasks first."
    )

    with st.form("add_category_form", clear_on_submit=True):
        new_cat = st.text_input("New category name")
        add_submitted = st.form_submit_button("Add category")
    if add_submitted:
        ok, msg = db.add_category(new_cat, user["id"])
        st.success(msg) if ok else st.error(msg)

    st.write("")
    categories = db.get_categories()
    if not categories:
        st.info("No categories yet.")
        return

    for cat in categories:
        c1, c2, c3 = st.columns([3, 2, 1])
        with c1:
            st.write(f"**{cat['name']}**")
        with c2:
            new_name = st.text_input("Rename to", key=f"rename_{cat['id']}", label_visibility="collapsed", placeholder="Rename to...")
            if st.button("Rename", key=f"rename_btn_{cat['id']}"):
                if new_name.strip():
                    ok, msg = db.rename_category(cat["id"], new_name)
                    st.success(msg) if ok else st.error(msg)
                    st.rerun()
                else:
                    st.warning("Enter a new name first.")
        with c3:
            if st.button("Delete", key=f"delete_{cat['id']}"):
                ok, msg = db.delete_category(cat["id"])
                st.success(msg) if ok else st.error(msg)
                if ok:
                    st.rerun()


# ---------------------------------------------------------------------------
# Users tab
# ---------------------------------------------------------------------------

def render_users(user: dict):
    st.subheader("Manage staff & admin accounts")
    st.caption(
        "No self-registration by design — every account is created here by an admin. "
        "This keeps access control simple and auditable."
    )

    with st.form("add_user_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            name = st.text_input("Full name")
            username = st.text_input("Email (this is their login ID)", placeholder="rahul@saawariyaco.com")
        with c2:
            role = st.selectbox("Role", ["staff", "admin"])
            password = st.text_input("Temporary password", type="password")
        add_submitted = st.form_submit_button("Create account", width='stretch')

    if add_submitted:
        ok, msg = db.create_user(name, username, password, role)
        st.success(msg) if ok else st.error(msg)

    st.write("")
    st.markdown("**Existing accounts**")
    all_users = db.get_all_users()

    for u in all_users:
        c1, c2, c3, c4 = st.columns([2, 1, 1, 1.5])
        with c1:
            status_txt = "🟢 Active" if u["is_active"] else "🔴 Inactive"
            st.write(f"**{u['name']}** ({u['username']}) — {u['role']} — {status_txt}")
        with c2:
            if u["is_active"]:
                if st.button("Deactivate", key=f"deact_{u['id']}"):
                    db.set_user_active(u["id"], False)
                    st.rerun()
            else:
                if st.button("Activate", key=f"act_{u['id']}"):
                    db.set_user_active(u["id"], True)
                    st.rerun()
        with c3:
            pass
        with c4:
            new_pw = st.text_input("New password", key=f"pw_{u['id']}", type="password", label_visibility="collapsed", placeholder="New password")
            if st.button("Reset password", key=f"reset_{u['id']}"):
                if new_pw.strip():
                    ok, msg = db.reset_password(u["id"], new_pw)
                    st.success(f"Password reset for {u['name']}.") if ok else st.error(msg)
                else:
                    st.warning("Enter a new password first.")


# ---------------------------------------------------------------------------
# Export tab - the weekly-backup safety net agreed on during planning
# ---------------------------------------------------------------------------

def render_export():
    st.subheader("Export data (backup / audit trail)")
    st.caption(
        "Streamlit Community Cloud's free tier does not guarantee the database file "
        "survives every restart. Download this export regularly — weekly at minimum — "
        "so task history is never fully lost."
    )

    tasks = db.get_all_tasks()
    if not tasks:
        st.info("No data to export yet.")
        return

    df = pd.DataFrame(tasks)
    df = df[[
        "id", "title", "category_name", "assigned_to_name", "assigned_by_name",
        "priority", "due_date", "current_status", "latest_remarks",
        "status_updated_at", "created_at",
    ]]
    df.columns = [
        "Task ID", "Title", "Category", "Assigned To", "Assigned By",
        "Priority", "Due Date", "Current Status", "Latest Remarks",
        "Status Updated At", "Created At",
    ]

    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download current task snapshot (CSV)",
        data=csv,
        file_name=f"task_snapshot_{date.today().isoformat()}.csv",
        mime="text/csv",
        width='stretch',
    )

    st.write("")
    st.markdown("**Full status history (every change, every task)**")
    all_history_rows = []
    for t in tasks:
        for h in db.get_status_history(t["id"]):
            all_history_rows.append({
                "Task ID": t["id"],
                "Task Title": t["title"],
                "Status": h["status"],
                "Remarks": h["remarks"],
                "Updated By": h["updated_by_name"],
                "Updated At": h["updated_at"],
            })
    hist_df = pd.DataFrame(all_history_rows)
    hist_csv = hist_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download full audit trail / history (CSV)",
        data=hist_csv,
        file_name=f"audit_trail_{date.today().isoformat()}.csv",
        mime="text/csv",
        width='stretch',
    )

    st.dataframe(df, width='stretch', hide_index=True)
