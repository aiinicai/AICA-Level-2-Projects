"""
db.py
Database layer for the Staff Work Allocation & Tracking app.

Design decisions locked in during planning:
- SQLite single file (workapp.db), acceptable per user's explicit choice
  to start on Streamlit Community Cloud free tier with weekly manual export
  as the backup/audit mechanism.
- Categories are a separate table (admin-editable: add/rename/delete),
  NOT hardcoded, so no redeploy is needed to change them.
- Category deletion is BLOCKED if any task still references it (Option A,
  confirmed by user) to avoid silently orphaning historical records.
- Status updates are stored as a running history (task_id, status, remarks,
  updated_at) rather than overwritten in place, so "current status" is
  derived as the latest row per task. This preserves an audit trail of
  every status change, which was flagged as valuable for a compliance
  practice.
- Passwords are stored as bcrypt hashes, never plaintext.
- All staff-scoped queries filter by assigned_to = current logged-in user
  id at the SQL level (never trust a UI-only filter) so one staff member
  can never see another's rows even if the frontend had a bug.
"""

import sqlite3
import bcrypt
import re
from datetime import datetime, date
from contextlib import contextmanager

DB_PATH = "workapp.db"

# Login ID is the employee's email address (per user decision). Column is
# still named `username` internally to avoid a disruptive schema rename,
# but every value stored in it is validated as an email address from here
# on. The UI labels this field "Email" / "Email (login ID)" throughout.
EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def is_valid_email(value: str) -> bool:
    return bool(EMAIL_REGEX.match(value.strip())) if value else False


# ---------------------------------------------------------------------------
# Connection handling
# ---------------------------------------------------------------------------

@contextmanager
def get_conn():
    """Context-managed connection so every caller commits/closes correctly,
    even if an exception is raised mid-query."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Schema creation
# ---------------------------------------------------------------------------

def init_db():
    """Creates all tables if they do not already exist. Safe to call every
    app startup — CREATE TABLE IF NOT EXISTS is idempotent."""
    with get_conn() as conn:
        c = conn.cursor()

        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin', 'staff')),
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            )
        """)

        c.execute("""
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                created_by INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        """)

        c.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category_id INTEGER,
                description TEXT,
                assigned_to INTEGER NOT NULL,
                assigned_by INTEGER NOT NULL,
                priority TEXT NOT NULL CHECK (priority IN ('High', 'Medium', 'Low')),
                due_date TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (category_id) REFERENCES categories(id),
                FOREIGN KEY (assigned_to) REFERENCES users(id),
                FOREIGN KEY (assigned_by) REFERENCES users(id)
            )
        """)

        c.execute("""
            CREATE TABLE IF NOT EXISTS status_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                status TEXT NOT NULL CHECK (status IN ('Pending', 'In Process', 'Done')),
                remarks TEXT,
                updated_by INTEGER NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id),
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        """)

        # Seed one default admin account on first-ever run only, so the
        # app is never left with zero logins. Username/password are
        # intentionally simple and MUST be changed after first login.
        c.execute("SELECT COUNT(*) as cnt FROM users")
        if c.fetchone()["cnt"] == 0:
            default_hash = hash_password("admin123")
            c.execute(
                "INSERT INTO users (name, username, password_hash, role, is_active, created_at) "
                "VALUES (?, ?, ?, 'admin', 1, ?)",
                ("Default Admin", "admin@saawariyaco.com", default_hash, datetime.now().isoformat()),
            )


# ---------------------------------------------------------------------------
# Password helpers
# ---------------------------------------------------------------------------

def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        # Defensive: malformed hash should never crash the login flow,
        # it should just fail the login.
        return False


# ---------------------------------------------------------------------------
# User management (admin-only actions)
# ---------------------------------------------------------------------------

def authenticate(username: str, password: str):
    """Returns the user row (as dict) if credentials are valid and the
    account is active, else None. `username` here is the employee's email
    address, matched case-insensitively since emails are stored lowercase."""
    email = username.strip().lower()
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username = ? AND is_active = 1", (email,)
        ).fetchone()
        if row and verify_password(password, row["password_hash"]):
            return dict(row)
        return None


def create_user(name: str, username: str, password: str, role: str) -> tuple[bool, str]:
    """Returns (success, message). Fails cleanly on duplicate emails or bad
    formats instead of raising, so the Streamlit UI can show a friendly error.
    `username` is the employee's email address, used as their login ID."""
    if role not in ("admin", "staff"):
        return False, "Invalid role."
    if not username.strip() or not password.strip() or not name.strip():
        return False, "Name, email, and password cannot be empty."
    email = username.strip().lower()
    if not is_valid_email(email):
        return False, f"'{username}' doesn't look like a valid email address."
    with get_conn() as conn:
        existing = conn.execute(
            "SELECT id FROM users WHERE username = ?", (email,)
        ).fetchone()
        if existing:
            return False, f"An account with email '{email}' already exists."
        conn.execute(
            "INSERT INTO users (name, username, password_hash, role, is_active, created_at) "
            "VALUES (?, ?, ?, ?, 1, ?)",
            (name.strip(), email, hash_password(password), role, datetime.now().isoformat()),
        )
    return True, f"Account created for '{name}' ({email})."


def set_user_active(user_id: int, active: bool):
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active = ? WHERE id = ?", (1 if active else 0, user_id))


def reset_password(user_id: int, new_password: str) -> tuple[bool, str]:
    if not new_password.strip():
        return False, "Password cannot be empty."
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (hash_password(new_password), user_id),
        )
    return True, "Password reset successfully."


def get_all_staff():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM users WHERE role = 'staff' ORDER BY name"
        ).fetchall()
        return [dict(r) for r in rows]


def get_all_users():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM users ORDER BY role, name").fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Category management
# ---------------------------------------------------------------------------

def get_categories():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
        return [dict(r) for r in rows]


def add_category(name: str, created_by: int) -> tuple[bool, str]:
    name = name.strip()
    if not name:
        return False, "Category name cannot be empty."
    with get_conn() as conn:
        existing = conn.execute("SELECT id FROM categories WHERE name = ?", (name,)).fetchone()
        if existing:
            return False, f"Category '{name}' already exists."
        conn.execute(
            "INSERT INTO categories (name, created_by, created_at) VALUES (?, ?, ?)",
            (name, created_by, datetime.now().isoformat()),
        )
    return True, f"Category '{name}' added."


def rename_category(category_id: int, new_name: str) -> tuple[bool, str]:
    new_name = new_name.strip()
    if not new_name:
        return False, "New name cannot be empty."
    with get_conn() as conn:
        clash = conn.execute(
            "SELECT id FROM categories WHERE name = ? AND id != ?", (new_name, category_id)
        ).fetchone()
        if clash:
            return False, f"Another category is already named '{new_name}'."
        conn.execute("UPDATE categories SET name = ? WHERE id = ?", (new_name, category_id))
    return True, "Category renamed."


def delete_category(category_id: int) -> tuple[bool, str]:
    """Option A (locked): block deletion if any task references this
    category, to avoid orphaning historical records."""
    with get_conn() as conn:
        in_use = conn.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE category_id = ?", (category_id,)
        ).fetchone()["cnt"]
        if in_use > 0:
            return False, f"Cannot delete: {in_use} task(s) use this category. Reassign them first."
        conn.execute("DELETE FROM categories WHERE id = ?", (category_id,))
    return True, "Category deleted."


# ---------------------------------------------------------------------------
# Task management
# ---------------------------------------------------------------------------

def create_task(title, category_id, description, assigned_to, assigned_by, priority, due_date):
    title = title.strip()
    if not title:
        return False, "Task title cannot be empty."
    if priority not in ("High", "Medium", "Low"):
        return False, "Invalid priority."
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO tasks (title, category_id, description, assigned_to, assigned_by, "
            "priority, due_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                title, category_id, description.strip() if description else "",
                assigned_to, assigned_by, priority,
                due_date.isoformat() if isinstance(due_date, date) else due_date,
                datetime.now().isoformat(),
            ),
        )
        task_id = cur.lastrowid
        # Every new task starts life with an implicit "Pending" status row
        # so the status_updates table is the single source of truth for
        # status from creation onward (no special-casing "no status yet").
        conn.execute(
            "INSERT INTO status_updates (task_id, status, remarks, updated_by, updated_at) "
            "VALUES (?, 'Pending', 'Task created.', ?, ?)",
            (task_id, assigned_by, datetime.now().isoformat()),
        )
    return True, "Task created and assigned."


def add_status_update(task_id: int, status: str, remarks: str, updated_by: int) -> tuple[bool, str]:
    if status not in ("Pending", "In Process", "Done"):
        return False, "Invalid status."
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO status_updates (task_id, status, remarks, updated_by, updated_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (task_id, status, remarks.strip() if remarks else "", updated_by, datetime.now().isoformat()),
        )
    return True, "Status updated."


def _tasks_with_latest_status(where_clause: str = "", params: tuple = ()):
    """Shared query builder: joins each task to its MOST RECENT status
    update via a correlated subquery on MAX(updated_at), plus assignee/
    assigner names and category name. where_clause should start with
    'WHERE' or be empty."""
    query = f"""
        SELECT
            t.id, t.title, t.description, t.priority, t.due_date, t.created_at,
            c.name AS category_name, c.id AS category_id,
            staff.id AS assigned_to_id, staff.name AS assigned_to_name,
            admin.name AS assigned_by_name,
            su.status AS current_status, su.remarks AS latest_remarks, su.updated_at AS status_updated_at
        FROM tasks t
        LEFT JOIN categories c ON t.category_id = c.id
        JOIN users staff ON t.assigned_to = staff.id
        JOIN users admin ON t.assigned_by = admin.id
        LEFT JOIN status_updates su ON su.id = (
            SELECT id FROM status_updates
            WHERE task_id = t.id
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
        )
        {where_clause}
        ORDER BY
            CASE t.priority WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END,
            t.due_date IS NULL, t.due_date ASC
    """
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]


def get_all_tasks():
    """Admin view: every task across every staff member."""
    return _tasks_with_latest_status()


def get_tasks_for_staff(staff_id: int):
    """Staff view: ONLY this staff member's tasks. Filtering happens here,
    at the SQL layer, not in the UI — this is the enforcement point for
    'staff cannot see each other's work'."""
    return _tasks_with_latest_status("WHERE t.assigned_to = ?", (staff_id,))


def get_status_history(task_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT su.*, u.name as updated_by_name FROM status_updates su "
            "JOIN users u ON su.updated_by = u.id "
            "WHERE su.task_id = ? ORDER BY su.updated_at ASC, su.id ASC",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_staff_workload(staff_id: int) -> dict:
    """Count of currently-open (not Done) tasks for a given staff member —
    shown to admins before assigning, to avoid accidental double-booking
    across the two-admin setup."""
    tasks = get_tasks_for_staff(staff_id)
    open_count = sum(1 for t in tasks if t["current_status"] != "Done")
    overdue_count = sum(
        1 for t in tasks
        if t["current_status"] != "Done" and t["due_date"] and t["due_date"] < date.today().isoformat()
    )
    return {"open": open_count, "overdue": overdue_count, "total": len(tasks)}
