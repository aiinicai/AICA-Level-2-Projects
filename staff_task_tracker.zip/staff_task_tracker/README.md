# Staff Operations Portal

A web-based task allocation and tracking tool. Two admins can create staff
accounts, assign tasks with instructions, and track status. Each staff
member logs in and sees **only their own tasks** — enforced at the database
query level, not just hidden in the UI.

## What's included

| File | Purpose |
|---|---|
| `app.py` | Entry point — login screen, session handling, routing, shared branded header/footer |
| `db.py` | All database logic (SQLite) — schema, auth, tasks, categories |
| `admin_panel.py` | Admin dashboard, task creation, category & user management, export |
| `staff_panel.py` | Staff view — own tasks only, status updates |
| `assets/vac_logo.png` | VAC (CA Vijender Aggarwal Classes) logo, shown top-left of header |
| `assets/twt_logo.png` | Tax Without Tears logo, shown top-right of header |
| `.streamlit/config.toml` | Custom color theme |
| `requirements.txt` | Python dependencies |

## First login

A default admin account is created automatically the first time the app runs:

- **Email:** `admin@saawariyaco.com`
- **Password:** `admin123`

**Change this password immediately** after your first login, from the
"Staff & Admins" tab → Reset password next to the Default Admin row. Then
create your second real admin account and your staff accounts from the
same tab (no self-registration by design — every account is admin-created,
and every login ID is the employee's real email address, entered by the
admin when the account is created).

## Deploying on Streamlit Community Cloud (free)

1. Create a **private** GitHub repository and push all files in this folder
   to it (keep the folder structure, including `.streamlit/config.toml`).
2. Go to [share.streamlit.io](https://share.streamlit.io), sign in with
   GitHub, click "New app," and point it at your repo, branch `main`, and
   file `app.py`.
3. Deploy. You'll get a URL like `yourapp.streamlit.app` — this is what
   admins and staff use to log in, from any device, any browser.
4. Log in with the default admin credentials above and change the password
   immediately.

## Important limitation — read before relying on this in production

Streamlit Community Cloud's **free tier does not guarantee the underlying
file storage survives every restart** (code pushes, platform maintenance,
or extended inactivity can trigger a redeploy that wipes local files,
including the SQLite database `workapp.db`).

**Mitigation built into the app:** use the **Export** tab regularly —
weekly at minimum, more often around filing deadlines — to download a full
CSV snapshot of tasks and the complete status-change audit trail. This is
your safety net until/unless you move to a persistently-hosted database
(e.g., a free-tier hosted Postgres like Supabase or Neon), which is a
natural next step if this tool proves useful and you want to remove this
risk entirely.

## Design decisions worth knowing

- **Staff isolation is enforced in SQL**, not just hidden in the UI —
  `get_tasks_for_staff()` filters by `assigned_to = <logged-in user id>`
  at the database query itself.
- **Categories** are admin-editable (add/rename/delete) but a category
  **cannot be deleted while any task still uses it** — you'll be told how
  many tasks reference it and asked to reassign them first, so historical
  records are never silently orphaned.
- **Status history is never overwritten** — every status change is a new
  row with a timestamp, so you can see exactly when a task moved from
  Pending → In Process → Done, not just its current state.
- **No self-registration** — every login is created by an admin. This
  keeps the access-control surface small and easy to reason about.
- Passwords are stored as **bcrypt hashes**, never plaintext.

## Installing as an app (PWA) on phones and desktops

Once deployed on Streamlit Community Cloud (HTTPS is required — this does
**not** work on plain `http://` hosting), staff and admins can install this
as an app icon on their phone or desktop, with no browser address bar or
tabs around it:

- **Android (Chrome):** open the site → tap the three-dot menu → "Add to
  Home screen" / "Install app"
- **iPhone (Safari):** open the site → tap the Share icon → "Add to Home
  Screen"
- **Desktop (Chrome/Edge):** open the site → look for an install icon (⊕
  or a small monitor icon) at the right side of the address bar → Install

**What this does and doesn't give you:** a real home-screen icon and a
standalone window without browser chrome. It does **not** work offline —
every screen still needs a live connection to load or update tasks, and
the service worker (`static/sw.js`) deliberately does not cache task data,
since showing a staff member stale status information would be worse than
no offline support at all.

**Files this depends on** — make sure `static/` (containing `manifest.json`,
`icon-192.png`, `icon-512.png`, `sw.js`) is pushed to GitHub alongside
everything else, and that `.streamlit/config.toml` still has
`enableStaticServing = true` under `[server]` — both are required for the
install prompt to appear at all.

## Running locally (optional, to preview before deploying)

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL it prints (usually `http://localhost:8501`).
