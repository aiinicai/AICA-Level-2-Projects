================================================================
 PDF Manager Offline v1.0.0
 Capstone submission - ICAI AICA Level 2 Certificate Course
================================================================

 Submitted by : CA Laxmi
 Organisation : Finance & Accounts, POWERGRID Corporation of India Limited
 Date         : 20 August 2026

----------------------------------------------------------------
 TO RUN THE TOOL: double-click  START.bat
----------------------------------------------------------------

 That one file does everything, in order:

     1. Finds Python on this computer
     2. Builds a private box of libraries, inside this folder only
     3. Installs what the tool needs
     4. Runs a self-test and shows PASS or FAIL for each check
     5. Opens the application

 First run takes 5 to 15 minutes, almost all of it downloading.
 Every run after that takes about 5 seconds.

 No administrator rights are needed.
 Nothing is written outside this folder.
 To remove it completely, delete this folder. Nothing is left behind.

 If Python is not installed, START.bat will say so and tell you where
 to get it. Please tick "Add python.exe to PATH" during that install.

----------------------------------------------------------------
 WHAT IS IN EACH FOLDER
----------------------------------------------------------------

 01_Project_Summary       The written report: problem, architecture,
                          design decisions, results, limitations.
                          Also the Baby-Step User Guide.

 02_Prompt_Files          The full log of prompts used to engineer the
                          tool, including the rounds that were
                          corrections rather than successes.

 03_Example_Files         What goes in and what comes out, sample
                          outputs, and three mock bid documents you
                          can test the tool on.

 04_Executable_Files      The complete working source code, plus the
                          self-test. START.bat runs from here.

 05_Supporting_Documents  Settings file, the editable keyword list,
                          the demonstration script and slide deck.

----------------------------------------------------------------
 THE VIDEO
----------------------------------------------------------------

 The video explanation is uploaded as a SEPARATE file alongside this
 ZIP, because the upload form allows up to five files. Keeping it
 outside keeps this ZIP small and quick to download.

----------------------------------------------------------------
 A NOTE ON SCOPE
----------------------------------------------------------------

 This tool assists document review. It does not evaluate bids and it
 does not replace professional judgement. Every figure it extracts
 automatically must be verified against the source document before it
 is relied upon.

================================================================
