# PDF Manager Offline — Project Summary

**Version:** 1.0.0
**Author:** CA Laxmi
**Organisation:** Finance & Accounts, POWERGRID Corporation of India Limited
**Date:** 20 August 2026

---

## 1. Problem Statement

Financial qualification of bidders in a large transmission tender is a
document-handling problem before it is an analytical one. A single package
routinely contains:

| Reality on the ground | Consequence |
|---|---|
| 15–20 bidders, each submitting 50–500 pages | 5,000+ pages to review per tender |
| A mixture of native PDFs and scanned annexures | Half the pages cannot be searched at all |
| Password-protected financial statements | Each file opened by hand, password re-typed |
| The same annexure uploaded twice under different names | Duplicated review effort, inconsistent findings |
| Figures reported in crore, lakh and absolute rupees | Manual re-basing before any comparison |

The consequence is that a qualified professional spends the majority of the
available time on mechanical work — opening, unlocking, merging, hunting for
the phrase "Maximum Annual Average Turnover" — rather than on judgement.

Commercial tools exist, but three constraints rule them out:

1. **Data sovereignty.** Bid documents cannot be uploaded to a cloud service.
2. **Environment.** No administrator rights; a restrictive corporate firewall.
3. **Cost and procurement.** A licensed tool requires a procurement cycle
   longer than the tender itself.

## 2. Objective

Build a desktop tool that runs entirely offline, needs no administrator
rights, and removes the mechanical layer from bid document review — while
making it explicit that the tool assists judgement and never replaces it.

### Success criteria

| # | Criterion | Achieved |
|---|---|---|
| 1 | Runs with no internet connection after installation | Yes |
| 2 | Installs without administrator rights | Yes |
| 3 | Never modifies a source document | Yes — enforced in code |
| 4 | Passwords never written to disk | Yes — memory only |
| 5 | Handles 200 files / 500 pages per file | Yes — with a resumable index |
| 6 | Produces an auditable trail of every action | Yes — log + errors.csv |
| 7 | Bilingual interface (English / Hindi) | Yes — single toggle |

## 3. Architecture

The tool is layered. Each layer knows only about the layer beneath it, which
is what allowed the command-line engine to be built and tested completely
before any window existed.

```
    +--------------------------------------------------------+
    |  PRESENTATION                                          |
    |  gui.py            PyQt6 window, sidebar, tabs         |
    |  pdf_workspace.py  page grid, drag reorder, preview    |
    |  theme.py          3D style sheet, password field      |
    |  run_cli.py        the same engine from a command line |
    +--------------------------------------------------------+
                              |
    +--------------------------------------------------------+
    |  ANALYSIS AND REPORTING                                |
    |  analysis.py       facts -> report descriptions        |
    |  highlight.py      keyword lists + automatic rules     |
    |  writers.py        one report -> Word, PPT, HTML, PDF  |
    +--------------------------------------------------------+
                              |
    +--------------------------------------------------------+
    |  DOCUMENT ENGINE                                       |
    |  intake.py         collection, duplicates, unlocking   |
    |  pdf_ops.py        merge, split, rotate, crop, ...     |
    |  ocr_engine.py     three OCR backends, one interface   |
    |  search.py         SQLite index and global search      |
    +--------------------------------------------------------+
                              |
    +--------------------------------------------------------+
    |  FOUNDATION                                            |
    |  config.py         every setting in one file           |
    |  common.py         logging, hashing, cancellation      |
    +--------------------------------------------------------+
```

### Module responsibilities

| Module | Responsibility | Key design point |
|---|---|---|
| `config.py` | All settings, limits, colours, keywords | One place to change behaviour |
| `common.py` | Logging, SHA-256 hashing, cancel token, progress | Errors are collected, never fatal |
| `intake.py` | Collect files, detect duplicates, unlock PDFs | Passwords held in memory only |
| `pdf_ops.py` | Eight PDF operations | Source files opened read-only |
| `ocr_engine.py` | RapidOCR / Tesseract / EasyOCR behind one interface | Engine chosen at run time |
| `search.py` | SQLite index, global search, three output formats | Resumable by file fingerprint |
| `highlight.py` | Decide what deserves colour | Editable list plus automatic rules |
| `analysis.py` | Turn page text into report descriptions | Format-agnostic |
| `writers.py` | Render one description into four formats | Charts drawn once, reused |
| `gui.py` | The window | Long jobs on a background thread |
| `pdf_workspace.py` | Page-level workspace | Lazy thumbnails, LRU cache |

## 4. Workflow

```
   Bid documents (PDF / DOCX / XLSX / images / scans)
                        |
        [1] INTAKE      | duplicates flagged by SHA-256 fingerprint
                        | locked PDFs opened with supplied passwords
                        v
        [2] WORKSPACE   | merge, split, rotate, reorder, crop,
                        | compress, stamp, retype -- with live preview
                        v
        [3] READ        | OCR where needed; searchable PDF produced;
                        | every page stored in a local SQLite index
                        v
        [4] SEARCH      | "MAAT" across 200 files, instantly
                        v
        [5] REPORT      | Document Digest / Bid Comparison /
                        | Search Findings, each in Word, PPT, HTML, PDF
                        v
              Output\<timestamp>_<job>\
```

## 5. Key design decisions

| Decision | Alternative rejected | Reason |
|---|---|---|
| Never overwrite a source file | In-place editing | An auditor must be able to return to the original |
| Passwords in memory only | An encrypted password file | A file on disk is a file that can be copied |
| Resumable index keyed by file hash | Re-read every run | A 4-hour OCR job survives interruption |
| Lazy thumbnail rendering | Render all pages upfront | 2,000 pages would need ~3 GB and freeze the window |
| Three OCR engines behind one interface | Commit to one engine | The firewall may block whichever one is chosen |
| Ship Python plus a shortcut | A PyInstaller .exe | Windows Smart App Control blocks unsigned executables |
| A bare integer is never read as money | Accept any number | "page 4 of 4" was being read as a turnover of 4 crore |

The last row is worth dwelling on. During testing the tool reported
`Turnover = 4.00 Cr` for a bidder. The text was *"Turnover statement —
audited … Original page 4 of 4"*. The rule now requires a decimal point, a
comma, or a unit before a number is treated as a financial figure. A silent
error of this kind is more dangerous than a crash, because it looks like an
answer.

## 6. Security and audit posture

| Concern | Control |
|---|---|
| Data leaving the organisation | No network calls after installation |
| Source document integrity | Opened read-only; every output is a new file |
| Password handling | In memory only; wiped when the job ends; never in reports |
| Password cracking | Not implemented, by design; only supplied passwords are tried |
| Traceability | Rolling log, per-job `errors.csv`, timestamped output folders |
| Shareable settings | Job profiles store settings only — never passwords or file names |

## 7. Results

| Measure | Result |
|---|---|
| Modules | 11 Python files, approximately 7,900 lines |
| Command-line commands | 17 |
| PDF operations | 8 |
| Report combinations | 3 reports x 4 formats = 12 documents from one action |
| Compression achieved | 12.4 MB scan reduced to 283 KB at the balanced setting |
| Re-run of a completed index | Seconds instead of hours |
| Administrator rights required | None |

## 8. Known limitations

1. OCR reads printed text; handwriting is unreliable.
2. The PDF footer uses a Latin font. Hindi inside a page is unaffected.
3. "Retype" is intended for short corrections and redactions, not for
   rewriting paragraphs.
4. Automatically extracted figures are a first-cut working aid. Every figure
   must be verified against the source before it is relied upon.
5. An unsigned executable may be blocked by Windows Smart App Control; the
   shortcut route is the supported method.

## 9. Possible extensions

| Idea | Value |
|---|---|
| Bundle a Devanagari font | Hindi footers and fully bilingual PDFs |
| Table extraction into Excel | Balance sheet figures without re-keying |
| Confidence score per extracted figure | Reviewer sees which numbers to check first |
| Side-by-side comparison of two revisions | Faster review of resubmitted bids |
