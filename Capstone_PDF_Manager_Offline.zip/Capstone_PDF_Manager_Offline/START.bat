@echo off
REM ==========================================================================
REM  PDF Manager Offline - START HERE
REM
REM  Just double-click this file. It does everything, in order:
REM
REM     Stage 1  Find Python on this PC
REM     Stage 2  Build a private box of libraries (does not touch your PC)
REM     Stage 3  Install what the tool needs
REM     Stage 4  Run a self-test and show the result
REM     Stage 5  Open the application
REM
REM  No administrator rights are needed.
REM  Nothing is written outside this folder.
REM ==========================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0\04_Executable_Files\Tool"
color 0B
title PDF Manager Offline - Setup and Run

cls
echo.
echo  ================================================================
echo   PDF MANAGER OFFLINE  v1.0.0
echo   Capstone submission - ICAI AICA Level 2
echo  ================================================================
echo.
echo   This will set up and open the tool. It takes 5 to 15 minutes
echo   the first time, and about 5 seconds every time after that.
echo.
echo   Press any key to begin, or close this window to stop.
pause >nul

REM ------------------------------------------------------- STAGE 1: Python
echo.
echo  [1/5] Looking for Python ...
set "PY_CMD="
py -3.12 --version >nul 2>&1 && set "PY_CMD=py -3.12"
if not defined PY_CMD ( py -3.11 --version >nul 2>&1 && set "PY_CMD=py -3.11" )
if not defined PY_CMD ( py -3.13 --version >nul 2>&1 && set "PY_CMD=py -3.13" )
if not defined PY_CMD ( py -3.10 --version >nul 2>&1 && set "PY_CMD=py -3.10" )
if not defined PY_CMD ( py        --version >nul 2>&1 && set "PY_CMD=py"      )
if not defined PY_CMD ( python    --version >nul 2>&1 && set "PY_CMD=python"  )

if not defined PY_CMD (
    color 0C
    echo.
    echo   X  Python was not found on this computer.
    echo.
    echo      Please install Python from  https://www.python.org/downloads/
    echo      IMPORTANT: tick "Add python.exe to PATH" during the install.
    echo      Then run this file again.
    echo.
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('%PY_CMD% --version 2^>^&1') do set "PY_VER=%%v"
echo        Found !PY_VER!

REM --------------------------------------------------------- STAGE 2: venv
echo.
echo  [2/5] Preparing a private box of libraries ...
if exist ".venv\Scripts\python.exe" (
    echo        Already prepared - skipping.
) else (
    %PY_CMD% -m venv .venv
    if errorlevel 1 (
        color 0C
        echo   X  Could not create the private box.
        echo      Try copying this whole folder to C:\ and running it again.
        pause & exit /b 1
    )
    echo        Done.
)
set "VPY=%CD%\.venv\Scripts\python.exe"

REM ----------------------------------------------------- STAGE 3: libraries
echo.
echo  [3/5] Installing what the tool needs ...
"%VPY%" -c "import fitz, openpyxl, docx, pptx, PyQt6" >nul 2>&1
if not errorlevel 1 (
    echo        Already installed - skipping.
) else (
    echo        About 250 MB. On a slow network this takes 5 to 15 minutes.
    echo        The screen may look frozen. Please wait.
    echo.
    "%VPY%" -m pip install --upgrade pip --quiet >nul 2>&1
    "%VPY%" -m pip install --only-binary=:all: -r requirements.txt
    if errorlevel 1 (
        color 0C
        echo.
        echo   X  Some libraries did not install.
        echo      If this mentions pypi.org, a firewall is blocking it.
        echo      Allow  pypi.org  and  files.pythonhosted.org  and retry.
        echo.
        pause & exit /b 1
    )
)

REM ---------------------------------------------------- STAGE 4: self-test
echo.
echo  [4/5] Running the self-test ...
echo.
"%VPY%" "..\SELF_TEST.py"
if errorlevel 1 (
    color 0E
    echo.
    echo   !  The self-test reported a problem. See the lines above.
    echo      You can still try opening the tool.
    echo.
    pause
)

REM ---------------------------------------------------- STAGE 5: launch it
echo.
echo  [5/5] Opening the application ...
echo.
echo        The window is opening now. This black window can be
echo        minimised, but please leave it open while you work.
echo.
"%VPY%" run_gui.py

echo.
echo  ================================================================
echo   The application has closed. Thank you.
echo  ================================================================
echo.
pause
endlocal
