# Input and Output Reference — PDF Manager Offline

This folder documents what the tool expects to receive and what it produces,
so an assessor can predict the result before running anything.

## 1. Expected input

```
D:\Bids\TL02_765kV\
    Bidder_A_Annexure_E4B.pdf        native PDF, 4 pages
    Bidder_A_Annexure_E4B_copy.pdf   identical file, different name
    Bidder_B_Balance_Sheet.pdf       native PDF, 3 pages
    Bidder_C_LOCKED.pdf              password protected
    Scanned_Statement.pdf            image-only scan, needs OCR
    notes.txt                        plain text
```

Accepted extensions: `.pdf .docx .xlsx .xlsm .csv .tsv .json .txt .md .html
.htm .png .jpg .jpeg .tif .tiff .bmp .webp`

## 2. Produced output

Every run creates its own timestamped folder, so results never mix.

```
Output\20260810_143012_intake\
    01_Intake_Manifest.xlsx        3 sheets: Manifest, Summary, Legend
    01_Intake_Summary.txt          plain text, for pasting into email
    errors.csv                     only present if something went wrong

Output\20260810_144530_read\
    Scanned_Statement_searchable.pdf   invisible text layer added

Output\20260810_150118_search\
    02_Search_Hits.xlsx            one row per mention
    03_Matching_Pages.pdf          only the pages that matched
    04_Highlighted\                copies with every hit marked amber

Output\20260810_152244_report\
    Document_Digest.docx / .pptx / .html / .pdf
    Bid_Comparison.docx  / .pptx / .html / .pdf
    Search_Findings.docx / .pptx / .html / .pdf
    _charts\                       the PNG charts, reused by all formats
```

## 3. Colour convention, used identically in every format

| Colour | Meaning | Triggered by |
|---|---|---|
| Red | Critical | rejected, disqualified, deviation, a negative figure |
| Amber | Needs review | provisional, unaudited, subject to, a duplicate file |
| Green | Compliant | file ready, all figures located |
| Blue | Financial figure | detected automatically by shape |
| Purple | Date | detected automatically by shape |
| Orange | Watch word | your editable keyword list |

## 4. Reproducing the sample outputs

```
pgbt demo                                   create practice files
pgbt intake "Demo_Files" -p demo123         check them
pgbt ocr "Demo_Files" -y                    read them into the index
pgbt search MAAT "Net Worth"                search everything
pgbt report --type all --format all         build all twelve documents
```
