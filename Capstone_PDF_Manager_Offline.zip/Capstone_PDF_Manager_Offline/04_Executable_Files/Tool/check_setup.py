"""
check_setup.py
==============
A friendly health check.

Run it any time you are unsure whether the tool is properly installed:

    .venv\\Scripts\\python.exe check_setup.py

It prints a green tick for every part that works and a cross for anything
missing, then tells you exactly what to do next.  It changes nothing.
"""

from __future__ import annotations

import importlib
import platform
import sys
from pathlib import Path

TICK = "[ OK ]"
CROSS = "[FAIL]"
WARN = "[ -- ]"

# (import name, friendly name, what it is used for, is it essential?)
CORE_CHECKS = [
    ("fitz",        "PyMuPDF",      "read / crop / rotate / watermark PDFs", True),
    ("pypdf",       "pypdf",        "merge, split, bookmarks, passwords",    True),
    ("pikepdf",     "pikepdf",      "compress and repair PDFs",              True),
    ("pandas",      "pandas",       "tables and data",                       True),
    ("openpyxl",    "openpyxl",     "Excel with live formulas",              True),
    ("xlsxwriter",  "XlsxWriter",   "Excel charts and colour rules",         True),
    ("docx",        "python-docx",  "Word output",                           True),
    ("pptx",        "python-pptx",  "PowerPoint output",                     True),
    ("PIL",         "Pillow",       "images",                                True),
    ("bs4",         "BeautifulSoup", "HTML reading",                         True),
    ("requests",    "requests",     "optional web-link fetching",            False),
    ("jinja2",      "Jinja2",       "HTML reports",                          False),
    ("matplotlib",  "matplotlib",   "charts",                                False),
    ("PyQt6",       "PyQt6",        "the desktop window (needed from Step 8)", False),
]

OCR_CHECKS = [
    ("rapidocr_onnxruntime", "RapidOCR",   "fast OCR, English"),
    ("pytesseract",          "Tesseract",  "balanced OCR, English + Hindi"),
    ("easyocr",              "EasyOCR",    "best OCR for messy Hindi scans"),
]


def _try_import(module_name: str) -> tuple[bool, str]:
    try:
        mod = importlib.import_module(module_name)
        version = getattr(mod, "__version__", "") or getattr(mod, "VersionString", "")
        return True, str(version)
    except Exception as exc:                      # noqa: BLE001 - we want everything
        return False, exc.__class__.__name__


def main() -> int:
    print()
    print("=" * 66)
    print(" PG BID TOOLKIT - HEALTH CHECK")
    print("=" * 66)
    print(f" Python   : {sys.version.split()[0]}  ({platform.machine()})")
    print(f" Running  : {sys.executable}")
    inside_venv = ".venv" in sys.executable.replace("/", "\\")
    print(f" In .venv : {'yes' if inside_venv else 'NO - please use .venv\\Scripts\\python.exe'}")
    print("-" * 66)

    missing_essential: list[str] = []

    print(" CORE LIBRARIES")
    for module, friendly, purpose, essential in CORE_CHECKS:
        ok, info = _try_import(module)
        mark = TICK if ok else (CROSS if essential else WARN)
        version = f"v{info}" if ok and info else ""
        print(f"  {mark} {friendly:<15} {version:<10} {purpose}")
        if not ok and essential:
            missing_essential.append(friendly)

    print()
    print(" OCR ENGINES  (optional - install later with setup_ocr.bat)")
    ocr_available = 0
    for module, friendly, purpose in OCR_CHECKS:
        ok, _ = _try_import(module)
        print(f"  {TICK if ok else WARN} {friendly:<15} {'':<10} {purpose}")
        ocr_available += int(ok)

    print()
    print(" PROJECT FILES")
    root = Path(__file__).resolve().parent
    for rel in ("app/config.py", "app/common.py", "requirements.txt"):
        exists = (root / rel).exists()
        print(f"  {TICK if exists else CROSS} {rel}")
        if not exists:
            missing_essential.append(rel)

    # The tool's own plumbing
    sys.path.insert(0, str(root))
    try:
        from app import common, config
        common.ensure_dirs()
        print(f"  {TICK} folders created under {config.APP_ROOT}")
    except Exception as exc:                      # noqa: BLE001
        print(f"  {CROSS} app package failed to load: {exc}")
        missing_essential.append("app package")

    print("-" * 66)
    if missing_essential:
        print(" RESULT: NOT READY")
        print(" Missing:", ", ".join(missing_essential))
        print(" Fix    : run  setup_env.bat  again and read the red message.")
        print("=" * 66)
        return 1

    print(" RESULT: READY TO USE")
    if ocr_available == 0:
        print(" Note   : no OCR engine yet. Scanned PDFs will be skipped until")
        print("          you run setup_ocr.bat (Step 2).")
    else:
        print(f" Note   : {ocr_available} OCR engine(s) available.")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
