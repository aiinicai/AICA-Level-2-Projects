"""
fetch_ocr_models.py
===================
Run this ONCE, while you still have internet.

Why it exists
-------------
EasyOCR does not ship its "brain files" inside the package.  The first time
you ask it to read a page, it quietly tries to download them from the
internet.  Inside a firewalled office that download fails -- and it fails at
the worst moment, in the middle of a real job.

This script pulls those brain files NOW, into
    PGBidToolkit\\models\\easyocr\\
so that from tomorrow the tool never needs the internet again.

It also runs a tiny reading test on each installed engine and prints how
fast each one is on YOUR machine, so you can pick sensibly later.

Nothing is changed or deleted.  Safe to run again any time.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app import common, config  # noqa: E402

log = common.get_logger("ocr-setup")

# EasyOCR reads this environment variable to decide where to keep its brains.
# We set it BEFORE importing easyocr so the models land inside our folder.
os.environ["EASYOCR_MODULE_PATH"] = str(config.EASYOCR_MODEL_DIR)

TICK, CROSS, WARN = "[ OK ]", "[FAIL]", "[ -- ]"


# ---------------------------------------------------------------------------
# A tiny picture of text, used to prove each engine can actually read
# ---------------------------------------------------------------------------
def make_test_image() -> Path:
    """Draw a small white image with black text and save it to _temp."""
    from PIL import Image, ImageDraw

    common.ensure_dirs()
    path = config.TEMP_DIR / "ocr_test.png"
    img = Image.new("RGB", (640, 120), "white")
    draw = ImageDraw.Draw(img)
    draw.text((20, 30), "MAAT 4523.75 Cr as on 31.03.2025", fill="black")
    draw.text((20, 70), "Net Worth positive", fill="black")
    img.save(path)
    return path


# ---------------------------------------------------------------------------
# Engine 1 : RapidOCR  (models are bundled inside the package -- nothing to fetch)
# ---------------------------------------------------------------------------
def setup_rapidocr(test_image: Path) -> bool:
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError:
        print(f"  {WARN} RapidOCR      not installed")
        return False

    try:
        started = time.time()
        engine = RapidOCR()
        result, _ = engine(str(test_image))
        elapsed = time.time() - started
        words = len(result) if result else 0
        print(f"  {TICK} RapidOCR      ready  ({elapsed:.1f}s, read {words} text block(s))")
        print("         Models live inside the package - fully offline already.")
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  {CROSS} RapidOCR      failed: {exc}")
        return False


# ---------------------------------------------------------------------------
# Engine 2 : Tesseract  (needs the separate program in models\tesseract)
# ---------------------------------------------------------------------------
def setup_tesseract(test_image: Path) -> bool:
    try:
        import pytesseract
    except ImportError:
        print(f"  {WARN} Tesseract     python connector not installed")
        return False

    if not config.TESSERACT_EXE.exists():
        print(f"  {WARN} Tesseract     program not found at:")
        print(f"         {config.TESSERACT_EXE}")
        print("         See option T in setup_ocr.bat if you want it.")
        return False

    try:
        pytesseract.pytesseract.tesseract_cmd = str(config.TESSERACT_EXE)
        os.environ["TESSDATA_PREFIX"] = str(config.TESSDATA_DIR)
        started = time.time()
        text = pytesseract.image_to_string(str(test_image), lang="eng")
        elapsed = time.time() - started
        print(f"  {TICK} Tesseract     ready  ({elapsed:.1f}s, {len(text.strip())} chars)")
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  {CROSS} Tesseract     failed: {exc}")
        return False


# ---------------------------------------------------------------------------
# Engine 3 : EasyOCR  (THE important one -- this is what we pre-download)
# ---------------------------------------------------------------------------
def setup_easyocr(test_image: Path) -> bool:
    try:
        import easyocr
    except ImportError:
        print(f"  {WARN} EasyOCR       not installed")
        return False

    config.EASYOCR_MODEL_DIR.mkdir(parents=True, exist_ok=True)

    print("         Downloading EasyOCR brain files (about 150 MB).")
    print("         This happens ONCE. Please do not close the window.")
    try:
        started = time.time()
        reader = easyocr.Reader(
            config.OCR_LANGUAGES,                     # ["en", "hi"]
            gpu=False,                                # office laptops have no GPU
            model_storage_directory=str(config.EASYOCR_MODEL_DIR),
            user_network_directory=str(config.EASYOCR_MODEL_DIR),
            download_enabled=True,                    # allowed ONLY during setup
            verbose=False,
        )
        load_time = time.time() - started

        started = time.time()
        result = reader.readtext(str(test_image), detail=0)
        read_time = time.time() - started

        saved = list(config.EASYOCR_MODEL_DIR.glob("*.pth"))
        total_mb = sum(f.stat().st_size for f in saved) / (1024 * 1024)

        print(f"  {TICK} EasyOCR       ready  (load {load_time:.1f}s, "
              f"read {read_time:.1f}s, {len(result)} block(s))")
        print(f"         Saved {len(saved)} brain file(s), {total_mb:.0f} MB, in:")
        print(f"         {config.EASYOCR_MODEL_DIR}")
        return True

    except Exception as exc:  # noqa: BLE001
        print(f"  {CROSS} EasyOCR       failed: {exc}")
        print()
        print("         If this mentions a URL, connection, SSL or timeout, your")
        print("         firewall blocked the brain-file download. Two options:")
        print("           1. Ask IT to allow:  github.com  jaided.ai")
        print("           2. Download the files on a home PC and copy them into:")
        print(f"              {config.EASYOCR_MODEL_DIR}")
        return False


# ---------------------------------------------------------------------------
def main() -> int:
    common.ensure_dirs()
    print()
    print("=" * 66)
    print(" PG BID TOOLKIT - PREPARING OCR ENGINES FOR OFFLINE USE")
    print("=" * 66)
    print(f" Models folder: {config.MODELS_DIR}")
    print("-" * 66)

    test_image = make_test_image()
    print(f" Test image   : {test_image.name} (created fresh)")
    print("-" * 66)

    ready = {
        "rapidocr": setup_rapidocr(test_image),
        "tesseract": setup_tesseract(test_image),
        "easyocr": setup_easyocr(test_image),
    }

    print("-" * 66)
    working = [name for name, ok in ready.items() if ok]
    if working:
        print(f" RESULT: {len(working)} engine(s) ready -> {', '.join(working)}")
        print(" You can now read scanned PDFs with NO internet connection.")
    else:
        print(" RESULT: no OCR engine is ready.")
        print(" The toolkit still works fully for normal (non-scanned) PDFs.")
    print("=" * 66)

    common.clean_temp()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
