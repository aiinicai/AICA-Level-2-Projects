"""
MAKE_ICONS.py
=============
Just run me.  No commands, no arguments.

    1. Put this file in  C:\\PGTools\\PGBidToolkit
    2. Double-click it   (IDLE opens)
    3. Press F5
    4. Look at your Desktop

WHAT I CREATE
-------------
    PG Bid Toolkit.lnk            <- normal use.  No black window at all.
    PG Bid Toolkit (console).lnk  <- same app, with a black window behind it
                                     so you can read errors if anything breaks.

Both carry a proper icon and open the window straight away.

WHY TWO?
--------
You asked for both.  Day to day, use the plain one.  If something misbehaves,
open the console one and the black window will show exactly what went wrong.

WHY A SCRIPT INSTEAD OF A DOWNLOAD?
-----------------------------------
Windows Smart App Control refuses downloaded, unsigned shortcut and script
files.  Anything created here, on your own PC, is fine.  No Windows setting
is changed or weakened.
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ICON_PATH = ROOT / "pgbt.ico"


# ---------------------------------------------------------------------------
#  1.  DRAW THE ICON
# ---------------------------------------------------------------------------
def make_icon() -> Path | None:
    """
    Draw a simple, clear icon: a dark rounded tile, a document, and 'PG'.

    Small icons must stay readable at 16x16 pixels, so we keep the shapes
    large and the contrast high rather than adding fine detail.
    """
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("  Pillow not available - the shortcuts will use the default icon.")
        return None

    size = 256
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)

    # Dark tile background
    draw.rounded_rectangle([8, 8, size - 8, size - 8], radius=46,
                           fill=(30, 31, 38, 255), outline=(45, 108, 223, 255),
                           width=6)

    # A sheet of paper with a folded corner
    draw.polygon([(78, 58), (150, 58), (186, 96), (186, 198), (78, 198)],
                 fill=(240, 243, 250, 255))
    draw.polygon([(150, 58), (186, 96), (150, 96)], fill=(190, 205, 230, 255))

    # Lines of text on the sheet, one highlighted amber like a flagged figure
    for index, y in enumerate(range(112, 186, 20)):
        colour = (255, 190, 80, 255) if index == 1 else (120, 132, 158, 255)
        width = 84 if index != 2 else 58
        draw.rounded_rectangle([96, y, 96 + width, y + 9], radius=4, fill=colour)

    # "PG" badge in the corner
    draw.ellipse([150, 150, 214, 214], fill=(45, 108, 223, 255))
    try:
        draw.text((166, 168), "PG", fill=(255, 255, 255, 255))
    except Exception:                            # noqa: BLE001
        pass

    sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)]
    image.save(ICON_PATH, format="ICO", sizes=sizes)
    return ICON_PATH


# ---------------------------------------------------------------------------
#  2.  FIND THE DESKTOP
# ---------------------------------------------------------------------------
def find_desktop() -> Path | None:
    """Locate the Desktop, even when OneDrive has taken it over."""
    for candidate in (Path.home() / "Desktop", Path.home() / "OneDrive" / "Desktop"):
        if candidate.exists():
            return candidate
    for folder in Path.home().glob("OneDrive*"):
        desktop = folder / "Desktop"
        if desktop.exists():
            return desktop
    return None


# ---------------------------------------------------------------------------
#  3.  MAKE A SHORTCUT
# ---------------------------------------------------------------------------
def make_shortcut(link_path: Path, target: Path, arguments: str,
                  icon: Path | None, description: str) -> bool:
    """
    Create a real Windows shortcut (.lnk) using PowerShell.

    A .lnk pointing at pythonw.exe opens with NO black window at all, which
    a .bat file cannot do.  If PowerShell is blocked by policy, we fall back
    to a .bat file, which still works.
    """
    icon_line = (f'$s.IconLocation = "{icon},0";' if icon and icon.exists() else "")
    script = (
        "$w = New-Object -ComObject WScript.Shell;"
        f'$s = $w.CreateShortcut("{link_path}");'
        f'$s.TargetPath = "{target}";'
        f'$s.Arguments = \'{arguments}\';'
        f'$s.WorkingDirectory = "{ROOT}";'
        f'$s.Description = "{description}";'
        f"{icon_line}"
        "$s.Save()"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-Command", script],
            capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and link_path.exists():
            return True
        print(f"     PowerShell said: {(result.stderr or '').strip()[:120]}")
    except Exception as exc:                     # noqa: BLE001
        print(f"     PowerShell unavailable: {exc}")
    return False


def make_bat_fallback(path: Path, python_exe: Path, silent: bool) -> None:
    """If shortcuts cannot be made, a .bat still opens the app."""
    if silent:
        content = (f'@echo off\r\n'
                   f'start "" "{python_exe}" "{ROOT / "run_cli.py"}" gui\r\n')
    else:
        content = (f'@echo off\r\n'
                   f'cd /d "{ROOT}"\r\n'
                   f'"{python_exe}" "{ROOT / "run_cli.py"}" gui\r\n'
                   f'echo.\r\n'
                   f'echo The window has closed. Any error is shown above.\r\n'
                   f'pause\r\n')
    path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
#  4.  MAIN
# ---------------------------------------------------------------------------
def main() -> int:
    print()
    print("=" * 66)
    print(" PG BID TOOLKIT - CREATING YOUR DESKTOP ICONS")
    print("=" * 66)
    print(f" Toolkit folder : {ROOT}")

    pythonw = ROOT / ".venv" / "Scripts" / "pythonw.exe"   # no black window
    python = ROOT / ".venv" / "Scripts" / "python.exe"     # with black window

    if not python.exists():
        print()
        print(" X  .venv\\Scripts\\python.exe not found here.")
        print("    Either this file is in the wrong folder, or setup_env.bat")
        print("    has not been run yet.")
        print("=" * 66)
        return 1
    print(" Virtual env    : found  [OK]")

    if not (ROOT / "run_cli.py").exists():
        print(" X  run_cli.py not found in this folder.")
        return 1

    icon = make_icon()
    print(f" Icon           : {'created ' + icon.name if icon else 'skipped'}")

    desktop = find_desktop()
    if not desktop:
        print(" X  Could not find your Desktop folder.")
        return 1
    print(f" Desktop        : {desktop}")
    print("-" * 66)

    script = ROOT / "run_cli.py"
    made = 0

    # -- icon 1: the quiet one -------------------------------------------
    target = pythonw if pythonw.exists() else python
    link = desktop / "PG Bid Toolkit.lnk"
    link.unlink(missing_ok=True)
    if make_shortcut(link, target, f'"{script}" gui', icon,
                     "PG Bid Toolkit - offline document tool"):
        print(f" [OK] {link.name}")
        print("      Opens the window only. No black window.")
        made += 1
    else:
        fallback = desktop / "PG Bid Toolkit.bat"
        make_bat_fallback(fallback, target, silent=True)
        print(f" [OK] {fallback.name}  (shortcut blocked, .bat used instead)")
        made += 1

    # -- icon 2: the talkative one ---------------------------------------
    link = desktop / "PG Bid Toolkit (console).lnk"
    link.unlink(missing_ok=True)
    if make_shortcut(link, python, f'"{script}" gui', icon,
                     "PG Bid Toolkit - with console, for troubleshooting"):
        print(f" [OK] {link.name}")
        print("      Same app, plus a black window showing what is happening.")
        made += 1
    else:
        fallback = desktop / "PG Bid Toolkit (console).bat"
        make_bat_fallback(fallback, python, silent=False)
        print(f" [OK] {fallback.name}  (shortcut blocked, .bat used instead)")
        made += 1

    print("-" * 66)
    print(f" DONE - {made} icon(s) on your Desktop.")
    print()
    print(" Day to day  : double-click 'PG Bid Toolkit'")
    print(" If it fails : double-click 'PG Bid Toolkit (console)' and read")
    print("               the black window, then send me what it says.")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    code = main()
    if sys.stdin and sys.stdin.isatty():
        input("\nPress Enter to close...")
    raise SystemExit(code)
