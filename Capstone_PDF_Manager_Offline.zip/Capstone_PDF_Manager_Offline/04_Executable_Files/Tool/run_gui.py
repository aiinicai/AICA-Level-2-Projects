"""
run_gui.py
==========
Opens the window directly, with no command needed.

This exists so the .exe and the desktop shortcut have a single, obvious
starting point: PyInstaller builds this file, and it does exactly one thing.

Double-clicking this file in IDLE also works.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> int:
    try:
        from app import gui
    except ImportError as exc:
        print("Could not start PDF Manager Offline.")
        print(f"Reason: {exc}")
        print()
        print("If this says 'No module named PyQt6', install it with:")
        print("   .venv\\Scripts\\python.exe -m pip install "
              "--only-binary=:all: PyQt6")
        input("\nPress Enter to close...")
        return 1
    return gui.run()


if __name__ == "__main__":
    raise SystemExit(main())
