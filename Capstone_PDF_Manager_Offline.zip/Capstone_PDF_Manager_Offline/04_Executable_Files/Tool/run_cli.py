"""
run_cli.py
==========
The command-line front door.

You chose "engine first, window later", so this file is how you drive the
toolkit until the PyQt6 window arrives.  Everything the window will do later,
this can do now.

Examples
--------
    # Look at one folder of bid documents
    .venv\\Scripts\\python.exe run_cli.py intake "D:\\Bids\\TL02"

    # Several folders and a stray file, with two known passwords
    .venv\\Scripts\\python.exe run_cli.py intake "D:\\Bids\\A" "D:\\Bids\\B" ^
        --password PGCIL@2025 --password bidder123

    # Overnight run: never stop to ask a human anything
    .venv\\Scripts\\python.exe run_cli.py intake "D:\\Bids" --unattended

    # Just build sample files so you can try it safely
    .venv\\Scripts\\python.exe run_cli.py demo

    # --- PDF workshop (Step 3) ---------------------------------------
    run_cli.py merge    "A.pdf" "B.pdf" --name TL02_Merged
    run_cli.py split    "Big.pdf" --ranges "1-40, 41-80"
    run_cli.py split    "Big.pdf" --every 25
    run_cli.py rotate   "Sideways.pdf" --degrees 90 --pages "2-5"
    run_cli.py reorder  "Jumbled.pdf" --order "3,1,2,4-10"
    run_cli.py crop     "Scan.pdf" --top 20 --bottom 20
    run_cli.py compress "Heavy.pdf" --level all
    run_cli.py stamp    "Report.pdf" --text "Internal - F&A"
    run_cli.py retype   "Draft.pdf" --find "1,234" --replace "1,432"
"""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import common, config                       # noqa: E402
from app.intake import (                             # noqa: E402
    IntakeEngine, PasswordDecision, PasswordVault,
    collect_paths, write_manifest, write_summary_text,
)
from app import pdf_ops                               # noqa: E402

log = common.get_logger("cli")


# ---------------------------------------------------------------------------
#  The "ask the human" function for command-line use.
#  Later, the PyQt6 window will supply its own version showing a dialog box --
#  the engine will not know or care about the difference.
# ---------------------------------------------------------------------------
def console_password_asker(path: Path) -> tuple[PasswordDecision, str | None]:
    print()
    print("  " + "-" * 58)
    print(f"  LOCKED FILE : {path.name}")
    print("  None of the passwords you gave me opened this file.")
    print("  " + "-" * 58)
    print("    1  Type the password for this file")
    print("    2  Skip this file, carry on with the rest")
    print("    3  Skip this and every other locked file (no more questions)")
    choice = input("  Choose 1, 2 or 3: ").strip()

    if choice == "1":
        # getpass hides the typing, so nobody reading over your shoulder sees it
        password = getpass.getpass("  Password (typing is hidden): ")
        return PasswordDecision.RETRY, password
    if choice == "3":
        return PasswordDecision.SKIP_ALL, None
    return PasswordDecision.SKIP_ONE, None


# ---------------------------------------------------------------------------
def command_intake(args: argparse.Namespace) -> int:
    common.ensure_dirs()

    vault = PasswordVault(args.password or [])
    if args.ask_passwords:
        print("\n  Type each password you know, one per line. Blank line = done.")
        while True:
            entry = getpass.getpass("  Password (hidden): ")
            if not entry:
                break
            vault.add(entry)
    print(f"\n  {len(vault) - 1} password(s) loaded into memory "
          f"(never written to disk).")

    job_folder = common.new_job_folder(args.name)
    errors = common.ErrorLog(job_folder)

    engine = IntakeEngine(
        vault=vault,
        errors=errors,
        ask_password=console_password_asker,
        unattended=args.unattended,
    )

    print(f"\n  Job folder: {job_folder}\n")
    records = engine.run(args.inputs)
    tally = engine.tally()

    manifest = write_manifest(records, job_folder)
    summary = write_summary_text(records, tally, job_folder)
    error_csv = errors.save_csv()

    vault.clear()                       # wipe passwords from memory
    common.clean_temp()

    print()
    print("=" * 62)
    print(f"  Files received   : {tally['Total']}")
    print(f"  Ready to process : {tally['Processable']}")
    print(f"  Total pages      : {tally['Total pages']}")
    if errors.count:
        print(f"  Issues logged    : {errors.count}")
    print("-" * 62)
    print(f"  Manifest : {manifest.name}")
    print(f"  Summary  : {summary.name}")
    if error_csv:
        print(f"  Errors   : {error_csv.name}")
    print(f"  Location : {job_folder}")
    print("=" * 62)
    return 0


# ---------------------------------------------------------------------------
def command_demo(args: argparse.Namespace) -> int:
    """
    Create a small set of safe practice files.

    Made from scratch, containing no real data, but rich enough to try every
    command on: searchable text, bookmarks, one big scanned-looking file,
    one locked file, and one exact duplicate.
    """
    try:
        import pymupdf as fitz
    except ImportError:                                  # older PyMuPDF
        import fitz

    folder = Path(args.folder).expanduser().resolve()
    folder.mkdir(parents=True, exist_ok=True)

    def make_pdf(name, lines_of_text, password=None, toc=None,
                 heavy_image=False):
        doc = fitz.open()
        for index, line in enumerate(lines_of_text, start=1):
            page = doc.new_page(width=595, height=842)          # A4
            page.insert_text((60, 90), line, fontsize=14)
            page.insert_text((60, 130),
                             f"Original page {index} of {len(lines_of_text)}",
                             fontsize=10)
            if heavy_image:
                # A deliberately oversized picture, so "compress" has real
                # work to do -- this imitates a 600 dpi scanner output.
                pix = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 1600, 1100))
                pix.set_rect(pix.irect, (235, 235, 245))
                for band in range(0, 1100, 90):
                    pix.set_rect(fitz.IRect(0, band, 1600, band + 45),
                                 (205, 215, 235))
                page.insert_image(fitz.Rect(50, 190, 545, 530), pixmap=pix)
        if toc:
            doc.set_toc(toc)
        doc.set_metadata({"title": name, "author": "POWERGRID F&A (practice)"})
        target = folder / name
        if password:
            doc.save(str(target), encryption=fitz.PDF_ENCRYPT_AES_256,
                     owner_pw=password, user_pw=password)
        else:
            doc.save(str(target))
        doc.close()
        return target

    make_pdf("Bidder_A_Annexure_E4B.pdf",
             ["MAAT 4523.75 Cr as on 31.03.2025",
              "Net Worth 8,912.40 Cr - positive",
              "Liquid Assets 812.50 Cr",
              "Turnover statement - audited"],
             toc=[[1, "Financial Summary", 1], [2, "MAAT working", 2]])

    make_pdf("Bidder_B_Balance_Sheet.pdf",
             ["Net Worth 1,234 Cr provisional",
              "Bid conditional - deviation noted",
              "Unaudited figures for FY 2025-26"])

    make_pdf("Scanned_Statement.pdf",
             ["Scanned balance sheet - page one",
              "Scanned balance sheet - page two"],
             heavy_image=True)

    make_pdf("Bidder_C_LOCKED.pdf",
             ["Locked annexure - opens with demo123", "Second page"],
             password="demo123")

    make_pdf("Bidder_D_UNKNOWN_LOCK.pdf",
             ["You are not meant to know this password", "Second page"],
             password="nobody-knows-this")

    # An exact duplicate under a different name, to prove duplicate detection
    (folder / "Bidder_A_Annexure_E4B_copy.pdf").write_bytes(
        (folder / "Bidder_A_Annexure_E4B.pdf").read_bytes())
    (folder / "notes.txt").write_text(
        "MAAT and Net Worth notes for practice", encoding="utf-8")

    print(f"\n  Practice files created in: {folder}\n")
    for item in sorted(folder.iterdir()):
        print(f"     {item.name:<38} {common.human_size(item.stat().st_size)}")
    print("\n  Now try these, one at a time:")
    print('     pgbt intake "Demo_Files" -p demo123')
    print('     pgbt merge "Demo_Files\\Bidder_A_Annexure_E4B.pdf" '
          '"Demo_Files\\Bidder_B_Balance_Sheet.pdf" --name TL02')
    print('     pgbt compress "Demo_Files\\Scanned_Statement.pdf" --level all')
    print('     pgbt retype "Demo_Files\\Bidder_B_Balance_Sheet.pdf" '
          '--find "1,234 Cr" --replace "1,432 Cr"\n')
    return 0


# ===========================================================================
#  STEP 3 COMMANDS - the PDF workshop
# ===========================================================================
def _job(args) -> Path:
    """Every command gets its own dated output folder."""
    common.ensure_dirs()
    folder = common.new_job_folder(getattr(args, "name", None) or args.command)
    print(f"\n  Job folder: {folder}\n")
    return folder


def _report(paths) -> int:
    print()
    print("=" * 62)
    for item in (paths if isinstance(paths, list) else [paths]):
        size = common.human_size(Path(item).stat().st_size)
        print(f"  Created: {Path(item).name}  ({size})")
    print("=" * 62)
    return 0


def command_merge(args) -> int:
    folder = _job(args)
    items = [pdf_ops.MergeItem(Path(p), password=args.password,
                               label=Path(p).stem) for p in args.inputs]
    result = pdf_ops.merge_pdfs(items, folder,
                                output_name=args.name or "Merged",
                                stamp_text=args.text)
    print()
    print("=" * 62)
    print(f"  Merged file : {result.output.name}")
    print(f"  Pages       : {result.total_pages}")
    print(f"  Sources     : {result.sources}")
    print(f"  Bookmarks   : {result.bookmarks}")
    if result.skipped:
        print(f"  Skipped     : {', '.join(result.skipped)}")
    print(f"  Location    : {folder}")
    print("=" * 62)
    return 0


def command_split(args) -> int:
    folder = _job(args)
    parts = pdf_ops.split_pdf(args.input, folder, ranges=args.ranges,
                              every=args.every, password=args.password)
    return _report(parts)


def command_rotate(args) -> int:
    folder = _job(args)
    out = pdf_ops.rotate_pdf(args.input, folder, args.degrees,
                             pages=args.pages, password=args.password)
    return _report(out)


def command_reorder(args) -> int:
    folder = _job(args)
    out = pdf_ops.reorder_pdf(args.input, folder, args.order,
                              password=args.password)
    return _report(out)


def command_crop(args) -> int:
    folder = _job(args)
    out = pdf_ops.crop_pdf(args.input, folder, top_mm=args.top,
                           bottom_mm=args.bottom, left_mm=args.left,
                           right_mm=args.right, pages=args.pages,
                           password=args.password)
    return _report(out)


def command_compress(args) -> int:
    folder = _job(args)
    if args.level == "all":
        results = pdf_ops.compare_compression(args.input, folder, args.password)
        print()
        print("=" * 74)
        print("  All three strengths, so you can choose with evidence:")
        print("-" * 74)
        for res in results:
            print(f"  {res.level:9s} {res.describe()}")
            print(f"            -> {res.output.name}")
        print("=" * 74)
        print("  Open each one and pick the smallest that still reads clearly.")
        return 0
    res = pdf_ops.compress_pdf(args.input, folder, args.level, args.password)
    print(f"\n  {res.level}: {res.describe()}")
    return _report(res.output)


def command_stamp(args) -> int:
    folder = _job(args)
    out = pdf_ops.stamp_pdf(args.input, folder, text=args.text,
                            include_datetime=not args.no_date,
                            password=args.password)
    return _report(out)


def command_retype(args) -> int:
    folder = _job(args)
    edit = pdf_ops.TextEdit(page=args.page, find=args.find,
                            new_text=args.replace, font_size=args.size)
    out, count = pdf_ops.whiteout_and_retype(args.input, folder, [edit],
                                             password=args.password)
    print(f"\n  {count} place(s) replaced.")
    if count == 0:
        print("  Nothing matched. Check the spelling, spacing and capital letters.")
    return _report(out)


LAUNCHER_CONTENT = r"""@echo off
REM ==========================================================================
REM  PG Bid Toolkit - START HERE
REM  This file was CREATED ON THIS PC by run_cli.py, not downloaded.
REM  That is why Windows Smart App Control is happy with it.
REM ==========================================================================

cd /d "%~dp0"
color 0B
title PG Bid Toolkit - Command Window

if not exist ".venv\Scripts\python.exe" (
    color 0C
    echo.
    echo   X  .venv not found.  Please run setup_env.bat first.
    echo.
    pause & exit /b 1
)

doskey pgbt=.venv\Scripts\python.exe run_cli.py $*

cls
echo.
echo  ================================================================
echo   PG BID TOOLKIT - ready.  You are in the right folder.
echo   %CD%
echo  ================================================================
echo.
echo   Type  pgbt  followed by what you want.  Examples:
echo.
echo     pgbt demo                          make practice files
echo     pgbt --help                        list every command
echo.
echo     pgbt intake "Demo_Files" -p demo123
echo     pgbt merge  "Demo_Files\Bidder_A_Annexure_E4B.pdf" "Demo_Files\Bidder_B_Balance_Sheet.pdf" --name TL02
echo     pgbt split  "Demo_Files\Bidder_A_Annexure_E4B.pdf" --every 2
echo     pgbt rotate "Demo_Files\Bidder_A_Annexure_E4B.pdf" --degrees 90
echo     pgbt reorder "Demo_Files\Bidder_A_Annexure_E4B.pdf" --order "3,1,2,4"
echo     pgbt crop   "Demo_Files\Bidder_A_Annexure_E4B.pdf" --top 20 --bottom 20
echo     pgbt compress "Demo_Files\Scanned_Statement.pdf" --level all
echo     pgbt stamp  "Demo_Files\Bidder_A_Annexure_E4B.pdf"
echo     pgbt retype "Demo_Files\Bidder_B_Balance_Sheet.pdf" --find "1,234 Cr" --replace "1,432 Cr"
echo.
echo   Results always appear in the  Output\  folder.
echo   Type  exit  to close this window.
echo.
echo  ----------------------------------------------------------------
echo.

cmd /k
"""


def command_launcher(args: argparse.Namespace) -> int:
    """
    Write START_HERE.bat onto this PC.

    Why this exists
    ---------------
    Windows Smart App Control refuses unsigned script files that arrived from
    the internet.  A file WRITTEN HERE, by Python, on your own machine, is not
    treated that way -- so this sidesteps the block completely, without
    weakening any security setting on your laptop.
    """
    root = Path(__file__).resolve().parent
    target = root / "START_HERE.bat"

    if target.exists():
        target.unlink()                 # remove the blocked downloaded copy
        print(f"\n  Removed the old blocked copy of {target.name}")

    target.write_text(LAUNCHER_CONTENT, encoding="utf-8")
    print(f"  Created locally: {target}")

    # A convenience copy on the Desktop, also created locally.
    if args.desktop:
        desktop = Path.home() / "Desktop"
        if not desktop.exists():                       # OneDrive-redirected Desktop
            alternative = Path.home() / "OneDrive" / "Desktop"
            desktop = alternative if alternative.exists() else desktop
        if desktop.exists():
            shortcut = desktop / "PG Bid Toolkit.bat"
            shortcut.write_text(LAUNCHER_CONTENT.replace(
                'cd /d "%~dp0"', f'cd /d "{root}"'), encoding="utf-8")
            print(f"  Created on Desktop: {shortcut.name}")
        else:
            print("  (Desktop folder not found - skipped the Desktop copy)")

    print("\n  Now just double-click START_HERE.bat. No more long typing.\n")
    return 0


# ===========================================================================
#  STEP 4 COMMANDS - reading scans and searching everything
# ===========================================================================
def command_ocr(args: argparse.Namespace) -> int:
    """Read one folder or file and add its pages to the search index."""
    from app import ocr_engine, search

    folder = _job(args)
    paths, warnings = collect_paths([args.input])
    pdfs = [p for p in paths if p.suffix.lower() == ".pdf"]
    for warning in warnings:
        print(f"  ! {warning}")

    manager = ocr_engine.OCRManager(args.engine)
    installed = ocr_engine.available_engines()

    print(f"  OCR engines installed : {', '.join(installed) or 'none'}")
    print(f"  Engine being used     : {manager.engine_name}")
    print(f"  PDFs to read          : {len(pdfs)}")

    # Count the pages first, so the forecast is honest.
    total_pages = 0
    for path in pdfs:
        try:
            from app.pdf_ops import open_pdf
            doc = open_pdf(path, args.password)
            total_pages += doc.page_count
            doc.close()
        except Exception:                              # noqa: BLE001
            pass

    forecast = ocr_engine.estimate_time(total_pages, manager.engine_name)
    print(f"  Pages to read         : {total_pages}")
    print(f"  Rough time needed     : {forecast}")
    print()

    if not args.yes and manager.ready and total_pages > 200:
        answer = input("  This is a long job. Type Y to start, anything else to stop: ")
        if answer.strip().lower() != "y":
            print("  Stopped. Nothing was changed.")
            return 0

    index = search.SearchIndex()
    errors = common.ErrorLog(folder)
    passwords = {p.name: args.password for p in pdfs} if args.password else {}

    report = search.build_index(
        pdfs, folder, engine=args.engine, smart=args.smart,
        make_searchable=not args.no_searchable,
        passwords=passwords, index=index, errors=errors,
    )
    stats = index.stats()
    index.close()
    errors.save_csv()

    print()
    print("=" * 62)
    print(f"  Files read now    : {report.files_read}")
    print(f"  Already indexed   : {report.files_skipped}")
    print(f"  Pages read        : {report.pages_read}")
    print(f"  Time taken        : {common.human_duration(report.seconds)}")
    if report.searchable_pdfs:
        print(f"  Searchable PDFs   : {len(report.searchable_pdfs)} in {folder.name}")
    print("-" * 62)
    print(f"  Index now holds   : {stats['files']} files, {stats['pages']} pages")
    print(f"  Index file        : {stats['database']}")
    print("=" * 62)
    print("  Now search it, instantly:   pgbt search MAAT \"net worth\"")
    return 0


def command_search(args: argparse.Namespace) -> int:
    """Search the index and produce all three outputs."""
    from app import search

    folder = _job(args)
    index = search.SearchIndex()
    stats = index.stats()

    if stats["pages"] == 0:
        print("  The index is empty. Run this first:")
        print('     pgbt ocr "D:\\Bids\\TL02"')
        index.close()
        return 1

    print(f"  Searching {stats['pages']} page(s) across {stats['files']} file(s)")
    print(f"  Looking for: {', '.join(args.terms)}")

    hits = index.search(args.terms, whole_word=args.whole_word,
                        case_sensitive=args.case_sensitive)
    index.close()

    print(f"  Found {len(hits)} mention(s)\n")
    if not hits:
        print("  Nothing matched. Try a shorter word, or check the spelling.")
        return 0

    passwords = {}
    excel = search.write_hits_excel(hits, args.terms, folder)
    pdf = search.extract_matching_pages(hits, folder, passwords)
    highlighted = search.write_highlighted_copies(hits, folder, passwords)

    by_file: dict[str, int] = {}
    for hit in hits:
        by_file[hit.file_name] = by_file.get(hit.file_name, 0) + 1

    print("  Where the mentions are:")
    for name, count in sorted(by_file.items(), key=lambda x: -x[1])[:15]:
        print(f"     {count:>4}  {name}")

    print()
    print("=" * 62)
    print(f"  1. Hit list      : {excel.name}")
    if pdf:
        print(f"  2. Matching pages: {pdf.name}")
    if highlighted:
        print(f"  3. Highlighted   : {len(highlighted)} file(s) in 04_Highlighted\\")
    print(f"  Location         : {folder}")
    print("=" * 62)
    return 0


def command_index(args: argparse.Namespace) -> int:
    """Show what the index currently holds, or empty it."""
    from app import search

    index = search.SearchIndex()
    stats = index.stats()
    print()
    print("=" * 62)
    print(f"  Index file : {stats['database']}")
    print(f"  Files      : {stats['files']}")
    print(f"  Pages      : {stats['pages']}")
    print("=" * 62)

    if args.clear:
        answer = input("  Empty the whole index? Type YES to confirm: ")
        if answer.strip() == "YES":
            index.close()
            Path(stats["database"]).unlink(missing_ok=True)
            print("  Index emptied. Files on disk were not touched.")
            return 0
        print("  Left alone.")
    index.close()
    return 0


# ===========================================================================
#  STEP 5 COMMANDS - reports in four formats
# ===========================================================================
def command_keywords(args: argparse.Namespace) -> int:
    """Create or show the editable keyword lists."""
    from app import highlight

    xlsx_path, txt_path = highlight.create_keyword_files(overwrite=args.reset)
    keywords = highlight.load_keywords()

    print()
    print("=" * 62)
    print("  YOUR KEYWORD LISTS")
    print("=" * 62)
    print(f"  Excel version : {xlsx_path}")
    print(f"  Text version  : {txt_path}")
    print("  Both are read and merged, so edit whichever suits you.")
    print("-" * 62)
    for category, words in keywords.items():
        label = config.HIGHLIGHT_STYLES.get(category, {}).get("label", category)
        print(f"  {label}  ({len(words)} words)")
        print(f"     {', '.join(words[:8])}{' ...' if len(words) > 8 else ''}")
    print("=" * 62)
    print("  Money, dates and negative figures are found automatically -")
    print("  you do not need to list those.")
    return 0


def command_report(args: argparse.Namespace) -> int:
    """Build the digest, comparison and/or findings report in four formats."""
    from app import analysis, highlight, search, writers

    folder = _job(args)
    index = search.SearchIndex()
    stats = index.stats()

    if stats["pages"] == 0:
        print("  The index is empty. Read some files first:")
        print('     pgbt ocr "Demo_Files" -y')
        index.close()
        return 1

    highlighter = highlight.Highlighter()
    print(f"  Index holds     : {stats['files']} file(s), {stats['pages']} page(s)")
    print(f"  Keyword lists   : {sum(len(v) for v in highlighter.keywords.values())} words")

    formats = (("word", "pptx", "html", "pdf") if args.format == "all"
               else (args.format,))
    wanted = (["digest", "comparison", "findings"] if args.type == "all"
              else [args.type])

    facts = analysis.gather_facts(index, highlighter)
    print(f"  Documents read  : {len(facts)}")

    reports: list[analysis.Report] = []
    if "digest" in wanted:
        reports.append(analysis.build_digest(facts, highlighter))
    if "comparison" in wanted:
        reports.append(analysis.build_comparison(facts))
    if "findings" in wanted:
        terms = args.terms or [w for w in highlighter.keywords.get("keyword", [])[:6]]
        hits = index.search(terms) if terms else []
        reports.append(analysis.build_findings(hits, terms, highlighter))
        print(f"  Search terms    : {', '.join(terms) or 'none'}")

    index.close()

    print()
    all_files: list[Path] = []
    for report in reports:
        produced = writers.write_all(report, folder, formats)
        print(f"  {report.title}")
        for name, path in produced.items():
            size = common.human_size(path.stat().st_size)
            print(f"     {name:<6} {path.name}  ({size})")
            all_files.append(path)

    print()
    print("=" * 62)
    print(f"  {len(all_files)} file(s) created")
    print(f"  Location: {folder}")
    print("=" * 62)
    return 0


def command_gui(args: argparse.Namespace) -> int:
    """Open the desktop window."""
    try:
        from app import gui
    except ImportError as exc:
        print("\n  PyQt6 is not installed. Add it with:")
        print("     .venv\\Scripts\\python.exe -m pip install "
              "--only-binary=:all: PyQt6")
        print(f"\n  ({exc})")
        return 1
    return gui.run()


# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_cli.py",
        description=f"{config.APP_NAME} v{config.APP_VERSION} - command line",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_intake = sub.add_parser("intake", help="Collect, check and unlock files")
    p_intake.add_argument("inputs", nargs="+",
                          help="Files and/or folders to take in")
    p_intake.add_argument("--password", "-p", action="append",
                          help="A password to try (repeat for several)")
    p_intake.add_argument("--ask-passwords", action="store_true",
                          help="Type passwords interactively (hidden)")
    p_intake.add_argument("--unattended", action="store_true",
                          help="Never stop to ask; skip and log instead")
    p_intake.add_argument("--name", default="intake",
                          help="Short job name used in the output folder")
    p_intake.set_defaults(func=command_intake)

    p_demo = sub.add_parser("demo", help="Create safe practice files")
    p_demo.add_argument("--folder", default="Demo_Files")
    p_demo.set_defaults(func=command_demo)

    p_launch = sub.add_parser(
        "launcher",
        help="Write START_HERE.bat locally (avoids Smart App Control)")
    p_launch.add_argument("--desktop", action="store_true",
                          help="Also place a copy on your Desktop")
    p_launch.set_defaults(func=command_launcher)

    # ---- Step 3: the PDF workshop ---------------------------------------
    def add_common(parser_obj, single_input: bool = True):
        """Options every PDF command shares."""
        if single_input:
            parser_obj.add_argument("input", help="The PDF to work on")
        parser_obj.add_argument("--password", "-p", default=None,
                                help="Password, if the PDF is locked")
        parser_obj.add_argument("--name", default=None,
                                help="Short job name for the output folder")

    p_merge = sub.add_parser("merge", help="Join several PDFs into one")
    p_merge.add_argument("inputs", nargs="+", help="PDFs, in the order you want")
    add_common(p_merge, single_input=False)
    p_merge.add_argument("--text", default=None,
                         help='Footer stamp text (default "Internal - F&A")')
    p_merge.set_defaults(func=command_merge)

    p_split = sub.add_parser("split", help="Cut one PDF into several")
    add_common(p_split)
    p_split.add_argument("--ranges", default=None,
                         help='Page ranges, e.g. "1-40, 41-80"')
    p_split.add_argument("--every", type=int, default=None,
                         help="Start a new file every N pages")
    p_split.set_defaults(func=command_split)

    p_rot = sub.add_parser("rotate", help="Turn pages 90/180/270/360")
    add_common(p_rot)
    p_rot.add_argument("--degrees", type=int, required=True,
                       choices=[0, 90, 180, 270, 360])
    p_rot.add_argument("--pages", default=None,
                       help='Which pages, e.g. "2-5". Leave out for all')
    p_rot.set_defaults(func=command_rotate)

    p_ord = sub.add_parser("reorder", help="Rearrange pages, renumber footers")
    add_common(p_ord)
    p_ord.add_argument("--order", required=True,
                       help='New order, e.g. "3,1,2,4-10"')
    p_ord.set_defaults(func=command_reorder)

    p_crop = sub.add_parser("crop", help="Trim margins (in millimetres)")
    add_common(p_crop)
    for side in ("top", "bottom", "left", "right"):
        p_crop.add_argument(f"--{side}", type=float, default=0.0)
    p_crop.add_argument("--pages", default=None)
    p_crop.set_defaults(func=command_crop)

    p_comp = sub.add_parser("compress", help="Make a PDF smaller")
    add_common(p_comp)
    p_comp.add_argument("--level", default="all",
                        choices=list(config.COMPRESSION_LEVELS) + ["all"],
                        help='"all" makes one file per strength so you can compare')
    p_comp.set_defaults(func=command_compress)

    p_stamp = sub.add_parser("stamp", help="Add the F&A footer with date/time")
    add_common(p_stamp)
    p_stamp.add_argument("--text", default=None)
    p_stamp.add_argument("--no-date", action="store_true",
                         help="Stamp the words only, without date and time")
    p_stamp.set_defaults(func=command_stamp)

    p_type = sub.add_parser("retype", help="White out some text and type new")
    add_common(p_type)
    p_type.add_argument("--find", required=True, help="Exact text to cover")
    p_type.add_argument("--replace", default="", help="What to type instead")
    p_type.add_argument("--page", type=int, default=1)
    p_type.add_argument("--size", type=float, default=9.0)
    p_type.set_defaults(func=command_retype)

    # ---- Step 4: OCR and global search ----------------------------------
    p_ocr = sub.add_parser("ocr", help="Read files into the search index")
    p_ocr.add_argument("input", help="A PDF or a folder of PDFs")
    p_ocr.add_argument("--engine", default=None,
                       choices=list(config.OCR_ENGINES),
                       help="Which reading engine to use")
    p_ocr.add_argument("--password", "-p", default=None)
    p_ocr.add_argument("--smart", action="store_true",
                       help="Skip OCR where the page already has good text")
    p_ocr.add_argument("--no-searchable", action="store_true",
                       help="Do not produce the searchable PDF copies")
    p_ocr.add_argument("--yes", "-y", action="store_true",
                       help="Do not ask before starting a long job")
    p_ocr.add_argument("--name", default="ocr")
    p_ocr.set_defaults(func=command_ocr)

    p_search = sub.add_parser("search", help="Find words across everything indexed")
    p_search.add_argument("terms", nargs="+", help='Words, e.g. MAAT "net worth"')
    p_search.add_argument("--whole-word", action="store_true",
                          help="Match only complete words")
    p_search.add_argument("--case-sensitive", action="store_true")
    p_search.add_argument("--name", default="search")
    p_search.set_defaults(func=command_search)

    p_index = sub.add_parser("index", help="Show or clear the search index")
    p_index.add_argument("--clear", action="store_true")
    p_index.set_defaults(func=command_index)

    # ---- Step 5: reports -------------------------------------------------
    p_key = sub.add_parser("keywords", help="Create/show your editable word lists")
    p_key.add_argument("--reset", action="store_true",
                       help="Overwrite with the starting lists again")
    p_key.set_defaults(func=command_keywords)

    p_rep = sub.add_parser("report", help="Build reports in Word/PPT/HTML/PDF")
    p_rep.add_argument("--type", default="all",
                       choices=["digest", "comparison", "findings", "all"])
    p_rep.add_argument("--format", default="all",
                       choices=["word", "pptx", "html", "pdf", "all"])
    p_rep.add_argument("--terms", nargs="*", default=None,
                       help="Words for the findings report")
    p_rep.add_argument("--name", default="report")
    p_rep.set_defaults(func=command_report)

    # ---- Step 6: the desktop window --------------------------------------
    p_gui = sub.add_parser("gui", help="Open the desktop window")
    p_gui.set_defaults(func=command_gui)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n  Stopped by the user (Ctrl+C).")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
