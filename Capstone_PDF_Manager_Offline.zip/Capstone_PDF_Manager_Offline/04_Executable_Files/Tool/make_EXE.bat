@echo off
REM ==========================================================================
REM  PDF Manager Offline - build the .exe
REM
REM  WHAT THIS DOES
REM    1. Checks the virtual environment exists
REM    2. Makes the icon file (pgbt.ico) if it is missing
REM    3. Installs PyInstaller into the venv
REM    4. Builds a ONE-FOLDER exe  (--onedir)
REM    5. Copies the app folder next to the exe
REM
REM  READ THIS FIRST
REM  ---------------
REM  Your laptop has Windows Smart App Control switched ON.  An .exe built
REM  here is not signed by a known publisher, so Windows will very likely
REM  refuse to run it.  That is not a fault in the build.
REM
REM  If it is blocked, use the Desktop shortcut instead (MAKE_ICONS.py).
REM  The shortcut runs the same app through python.exe, which IS signed by
REM  Microsoft, so Smart App Control allows it.
REM
REM  ONE FOLDER, not one file:  --onefile unpacks 2 GB to a temp folder on
REM  every launch, which takes 30-60 seconds and often trips antivirus.
REM  --onedir starts in about 3 seconds.
REM ==========================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"
color 0B
title PDF Manager Offline - Build EXE

echo.
echo  ============================================================
echo   PDF MANAGER OFFLINE  ^|  Building the .exe
echo  ============================================================
echo   Folder: %CD%
echo.

REM ---------------------------------------------------------------- 1. venv
if not exist ".venv\Scripts\python.exe" (
    color 0C
    echo   X  .venv not found.  Run setup_env.bat first.
    pause & exit /b 1
)
set "VPY=%CD%\.venv\Scripts\python.exe"
echo  [1/5] Virtual environment found.

REM ---------------------------------------------------------------- 2. icon
echo.
echo  [2/5] Checking the icon ...
if not exist "pgbt.ico" (
    echo        Creating pgbt.ico ...
    "%VPY%" -c "import MAKE_ICONS; MAKE_ICONS.make_icon()"
)
if exist "pgbt.ico" (
    echo        pgbt.ico ready.
    set "ICON=--icon=pgbt.ico"
) else (
    echo        ^!  No icon - the exe will use the default one.
    set "ICON="
)

REM --------------------------------------------------------- 3. pyinstaller
echo.
echo  [3/5] Installing PyInstaller ...
"%VPY%" -m pip install --only-binary=:all: --upgrade pyinstaller >nul 2>&1
if errorlevel 1 (
    color 0C
    echo   X  Could not install PyInstaller.  Check the firewall.
    pause & exit /b 1
)
echo        Done.

REM ------------------------------------------------------------- 4. cleanup
echo.
echo  [4/5] Clearing the previous build ...
if exist "build" rmdir /s /q "build"
if exist "dist"  rmdir /s /q "dist"
if exist "PDFManagerOffline.spec" del /q "PDFManagerOffline.spec"
echo        Done.

REM --------------------------------------------------------------- 5. build
echo.
echo  [5/5] Building.  This takes 3-10 minutes.  Please wait.
echo.

"%VPY%" -m PyInstaller ^
    --noconfirm ^
    --clean ^
    --onedir ^
    --windowed ^
    --name "PDFManagerOffline" ^
    %ICON% ^
    --add-data "app;app" ^
    --collect-all pymupdf ^
    --collect-all PyQt6 ^
    --hidden-import openpyxl ^
    --hidden-import xlsxwriter ^
    --hidden-import docx ^
    --hidden-import pptx ^
    --hidden-import matplotlib ^
    --hidden-import PIL ^
    --hidden-import pypdf ^
    --hidden-import pikepdf ^
    --exclude-module tkinter ^
    --exclude-module pytest ^
    run_gui.py

if errorlevel 1 (
    color 0C
    echo.
    echo   X  The build failed.  Read the last red lines above.
    pause & exit /b 1
)

REM ---- copy the things the app reads at run time ---------------------------
echo.
echo  Copying supporting folders ...
if exist "models"   xcopy /E /I /Y /Q "models"   "dist\PDFManagerOffline\models"   >nul
if exist "profiles" xcopy /E /I /Y /Q "profiles" "dist\PDFManagerOffline\profiles" >nul
if exist "pgbt.ico" copy /Y "pgbt.ico" "dist\PDFManagerOffline\" >nul

echo.
echo  ============================================================
echo   BUILD FINISHED
echo  ============================================================
echo   Your app is here:
echo     %CD%\dist\PDFManagerOffline\PDFManagerOffline.exe
echo.
echo   The exe opens the window directly.
echo   The exe opens the window straight away - no argument needed.
echo
echo.
echo   If Smart App Control blocks it, use the Desktop shortcut made
echo   by MAKE_ICONS.py instead - that route always works.
echo  ============================================================
echo.
pause
endlocal
