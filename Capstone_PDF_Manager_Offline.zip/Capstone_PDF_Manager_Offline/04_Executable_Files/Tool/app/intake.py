"""
intake.py
=========
STEP 2 - the front door of the toolkit.

Everything a file must survive before any real work begins:

    1. FOUND      -- picked up from files, folders or drag-and-drop
    2. CHECKED    -- is the type supported?  too big?  too many pages?
    3. FINGERPRINTED -- SHA-256, so an identical re-upload is spotted
    4. UNLOCKED   -- if it is a password-protected PDF
    5. RECORDED   -- one row in the Excel manifest, whatever the outcome

Golden rules obeyed here:
    * a source file is NEVER opened for writing
    * passwords live in memory only, never on disk, and never in the report
    * one bad file never stops the batch
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Callable, Iterable, Sequence

from . import common, config

log = common.get_logger("intake")


# ===========================================================================
#  1.  VOCABULARY
# ===========================================================================
class Status(str, Enum):
    """The final verdict on one file."""
    READY = "Ready"                    # green  - go ahead and process
    UNLOCKED = "Ready (unlocked)"      # green  - was locked, we opened it
    DUPLICATE = "Duplicate"            # amber  - identical twin already seen
    LOCKED = "Locked - skipped"        # red    - no password worked
    TOO_BIG = "Too big - skipped"      # red
    TOO_MANY_PAGES = "Too long - skipped"
    UNSUPPORTED = "Unsupported type"   # amber
    ERROR = "Error"                    # red


# How each status should be coloured in the Excel manifest.
STATUS_STYLE = {
    Status.READY: "ok",
    Status.UNLOCKED: "ok",
    Status.DUPLICATE: "warning",
    Status.LOCKED: "critical",
    Status.TOO_BIG: "critical",
    Status.TOO_MANY_PAGES: "critical",
    Status.UNSUPPORTED: "warning",
    Status.ERROR: "critical",
}


class PasswordDecision(str, Enum):
    """What the human chose when a file would not open."""
    RETRY = "retry"        # a new password was typed in
    SKIP_ONE = "skip_one"  # skip just this file
    SKIP_ALL = "skip_all"  # stop asking, skip every locked file from now on


@dataclass
class FileRecord:
    """One row of the manifest.  Plain data, no behaviour."""
    path: Path
    size_bytes: int = 0
    digest: str = ""
    kind: str = ""                       # PDF / Word / Excel / Image ...
    pages: int | None = None
    was_encrypted: bool = False
    status: Status = Status.READY
    note: str = ""
    duplicate_of: Path | None = None

    # Held in memory ONLY.  Never written to the manifest or any file.
    password: str | None = field(default=None, repr=False)

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def is_processable(self) -> bool:
        """Should the later stages (PDF ops, OCR, export) touch this file?"""
        return self.status in (Status.READY, Status.UNLOCKED)


# ===========================================================================
#  2.  FILE COLLECTION
# ===========================================================================
def describe_kind(path: Path) -> str:
    """Turn a file ending into a friendly word for the report."""
    ext = path.suffix.lower()
    if ext in config.EXT_PDF:
        return "PDF"
    if ext in config.EXT_WORD:
        return "Word"
    if ext in config.EXT_EXCEL:
        return "Excel"
    if ext in config.EXT_DATA:
        return "Data"
    if ext in config.EXT_TEXT:
        return "Text"
    if ext in config.EXT_HTML:
        return "HTML"
    if ext in config.EXT_IMAGE:
        return "Image"
    return "Other"


def collect_paths(
    inputs: Sequence[str | Path],
    recursive: bool = True,
    limit: int = config.MAX_FILES_PER_BATCH,
) -> tuple[list[Path], list[str]]:
    """
    Turn whatever the user gave us into a tidy list of real files.

    `inputs` may mix single files and whole folders -- exactly what
    drag-and-drop produces.

    Returns (files_found, warnings).
    """
    found: list[Path] = []
    warnings: list[str] = []
    seen: set[Path] = set()

    for raw in inputs:
        item = Path(raw).expanduser()

        if not item.exists():
            warnings.append(f"Not found, ignored: {item}")
            continue

        candidates = (
            sorted(item.rglob("*") if recursive else item.glob("*"))
            if item.is_dir() else [item]
        )

        for candidate in candidates:
            if not candidate.is_file():
                continue
            resolved = candidate.resolve()
            if resolved in seen:            # same path given twice
                continue
            seen.add(resolved)
            found.append(resolved)

    if len(found) > limit:
        warnings.append(
            f"{len(found)} files found, but the batch limit is {limit}. "
            f"Only the first {limit} will be processed."
        )
        found = found[:limit]

    return found, warnings


# ===========================================================================
#  3.  PASSWORDS
# ===========================================================================
class PasswordVault:
    """
    Holds the passwords for THIS RUN ONLY, in memory.

    It does not crack, guess or brute-force anything.  It simply tries the
    passwords you already know, so you type each one once instead of 40 times.
    """

    def __init__(self, passwords: Iterable[str] | None = None) -> None:
        # An empty password is tried first: many PDFs are "owner locked" only
        # (printing restricted) and open perfectly with no password at all.
        self._passwords: list[str] = [""]
        for pw in passwords or []:
            self.add(pw)

    def add(self, password: str) -> None:
        pw = str(password)
        if pw and pw not in self._passwords:
            self._passwords.append(pw)

    @property
    def passwords(self) -> list[str]:
        return list(self._passwords)

    def __len__(self) -> int:
        return len(self._passwords)

    def clear(self) -> None:
        """Wipe every password from memory. Called when the job ends."""
        self._passwords = [""]


def try_open_pdf(path: Path, vault: PasswordVault) -> tuple[bool, str | None, int | None, bool]:
    """
    Attempt to open a PDF.

    Returns (opened, password_that_worked, page_count, was_encrypted).
    """
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    encrypted = bool(reader.is_encrypted)

    if not encrypted:
        return True, None, len(reader.pages), False

    attempts = 0
    for pw in vault.passwords:
        if attempts >= config.MAX_PASSWORD_ATTEMPTS_PER_FILE:
            break
        attempts += 1
        try:
            if reader.decrypt(pw):          # 0 / False means "no"
                return True, pw, len(reader.pages), True
        except Exception:                   # noqa: BLE001 - odd encryption schemes
            continue

    return False, None, None, True


# ===========================================================================
#  4.  THE INTAKE ENGINE
# ===========================================================================
# The GUI (or the command line) supplies this function.  It is called only
# when no known password opens a file.  It must return a (decision, password)
# pair.  Returning None means "use the configured default".
PasswordAsker = Callable[[Path], tuple[PasswordDecision, str | None]]


class IntakeEngine:
    """Runs the whole front-door process for a batch of files."""

    def __init__(
        self,
        vault: PasswordVault | None = None,
        errors: common.ErrorLog | None = None,
        cancel: common.CancelToken | None = None,
        ask_password: PasswordAsker | None = None,
        unattended: bool = config.UNATTENDED_MODE,
    ) -> None:
        self.vault = vault or PasswordVault()
        self.errors = errors or common.ErrorLog()
        self.cancel = cancel or common.CancelToken()
        self.ask_password = ask_password
        self.unattended = unattended

        self.duplicates = common.DuplicateRegistry()
        self.records: list[FileRecord] = []
        self._stop_asking = False           # set by "skip all remaining"

    # -- one file ----------------------------------------------------------
    def _process_one(self, path: Path) -> FileRecord:
        record = FileRecord(path=path, kind=describe_kind(path))

        # (a) type supported?
        if path.suffix.lower() not in config.SUPPORTED_EXTENSIONS:
            record.status = Status.UNSUPPORTED
            record.note = f"'{path.suffix}' is not a supported file type"
            return record

        # (b) size sensible?
        record.size_bytes = path.stat().st_size
        size_mb = record.size_bytes / (1024 * 1024)
        if size_mb > config.MAX_FILE_SIZE_MB:
            record.status = Status.TOO_BIG
            record.note = (f"{size_mb:.0f} MB exceeds the "
                           f"{config.MAX_FILE_SIZE_MB} MB limit")
            self.errors.add(path.name, "intake", "File too big", record.note)
            return record

        # (c) seen this exact file before?
        record.digest = common.file_hash(path)
        is_dup, original = self.duplicates.check(path)
        if is_dup:
            record.status = Status.DUPLICATE
            record.duplicate_of = original
            record.note = f"Identical to: {original.name}"
            if config.DUPLICATE_ACTION == "flag":
                record.status = Status.READY      # report it, still process it
                record.note = f"DUPLICATE of {original.name} - processed anyway"
            log.info("Duplicate spotted: %s == %s", path.name, original.name)
            if config.DUPLICATE_ACTION != "flag":
                return record

        # (d) PDFs: open, unlock if needed, count pages
        if record.kind == "PDF":
            opened, password, pages, encrypted = try_open_pdf(path, self.vault)
            record.was_encrypted = encrypted

            if not opened:
                opened, password, pages = self._handle_locked(path)
                if not opened:
                    record.status = Status.LOCKED
                    record.note = "No supplied password opened this file"
                    self.errors.add(path.name, "unlock",
                                    "Could not open - password not known")
                    return record

            record.password = password
            record.pages = pages
            if encrypted:
                record.status = Status.UNLOCKED
                record.note = "Was password-protected; opened in memory"

            if pages and pages > config.MAX_PAGES_PER_FILE:
                record.status = Status.TOO_MANY_PAGES
                record.note = (f"{pages} pages exceeds the "
                               f"{config.MAX_PAGES_PER_FILE} page limit")
                self.errors.add(path.name, "intake", "Too many pages", record.note)

        elif record.kind == "Image":
            record.pages = 1

        return record

    # -- the "ask the human" moment ----------------------------------------
    def _handle_locked(self, path: Path) -> tuple[bool, str | None, int | None]:
        """
        Called only when every known password failed.

        Unattended mode, or 'skip all', means we never bother the user.
        """
        if self.unattended or self._stop_asking:
            return False, None, None
        if config.UNKNOWN_PASSWORD_POLICY != "ask" or self.ask_password is None:
            return False, None, None

        while True:
            self.cancel.raise_if_cancelled()
            decision, new_password = self.ask_password(path)

            if decision == PasswordDecision.SKIP_ALL:
                self._stop_asking = True
                log.info("User chose to skip all remaining locked files.")
                return False, None, None

            if decision == PasswordDecision.SKIP_ONE or not new_password:
                return False, None, None

            # A new password helps every later file too, so keep it.
            self.vault.add(new_password)
            opened, password, pages, _ = try_open_pdf(path, self.vault)
            if opened:
                log.info("Opened %s with the newly supplied password.", path.name)
                return True, password, pages
            log.warning("That password did not work for %s", path.name)

    # -- the whole batch ---------------------------------------------------
    def run(self, inputs: Sequence[str | Path],
            progress_callback=None) -> list[FileRecord]:
        paths, warnings = collect_paths(inputs)
        for warning in warnings:
            log.warning(warning)
            self.errors.add("-", "intake", warning)

        log.info("Intake starting: %d file(s)", len(paths))
        progress = common.Progress(len(paths), progress_callback, "Intake")

        for path in paths:
            try:
                self.cancel.raise_if_cancelled()
                record = self._process_one(path)
            except common.CancelToken.Cancelled:
                log.warning("Intake cancelled by the user.")
                break
            except Exception as exc:            # noqa: BLE001 - never crash a batch
                record = FileRecord(path=path, kind=describe_kind(path),
                                    status=Status.ERROR, note=str(exc)[:200])
                self.errors.add(path.name, "intake", "Unexpected problem", str(exc))

            self.records.append(record)
            progress.step(f"{record.name} -> {record.status.value}")

        elapsed = progress.finish()
        log.info("Intake finished in %s", elapsed)
        return self.records

    # -- headline numbers --------------------------------------------------
    def tally(self) -> dict[str, int]:
        counts = {status.value: 0 for status in Status}
        for record in self.records:
            counts[record.status.value] += 1
        counts["Total"] = len(self.records)
        counts["Processable"] = sum(1 for r in self.records if r.is_processable)
        counts["Total pages"] = sum(r.pages or 0 for r in self.records)
        return counts


# ===========================================================================
#  5.  THE TWO DELIVERABLES
# ===========================================================================
def write_manifest(records: Sequence[FileRecord], job_folder: Path) -> Path:
    """Excel manifest: one row per file, colour-coded, with live formulas."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()

    # ---------------- Sheet 1 : the manifest ------------------------------
    ws = wb.active
    ws.title = "01_Manifest"

    headers = ["#", "File name", "Type", "Size (MB)", "Pages",
               "Was locked?", "Duplicate of", "Status", "Note", "Folder"]
    ws.append(headers)

    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)
        cell.border = border

    for index, record in enumerate(records, start=1):
        ws.append([
            index,
            record.name,
            record.kind,
            round(record.size_bytes / (1024 * 1024), 2),
            record.pages if record.pages is not None else "",
            "Yes" if record.was_encrypted else "No",
            record.duplicate_of.name if record.duplicate_of else "",
            record.status.value,
            record.note,
            str(record.path.parent),
        ])

        style_key = STATUS_STYLE[record.status]
        style = config.HIGHLIGHT_STYLES[style_key]
        fill = PatternFill("solid", fgColor=style["fill"].lstrip("#"))
        font = Font(color=style["font"].lstrip("#"), bold=style["bold"])
        for column in range(1, len(headers) + 1):
            cell = ws.cell(row=index + 1, column=column)
            cell.border = border
            if column in (8, 9):                 # Status and Note columns
                cell.fill = fill
                cell.font = font

    widths = [5, 46, 9, 11, 8, 12, 26, 20, 44, 40]
    for column, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(column)].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(records) + 1}"

    # ---------------- Sheet 2 : live summary ------------------------------
    ws2 = wb.create_sheet("02_Summary")
    last = len(records) + 1

    ws2["A1"] = f"{config.APP_NAME} - Intake Summary"
    ws2["A1"].font = Font(bold=True, size=14, color="1F4E79")
    ws2["A2"] = "Generated"
    ws2["B2"] = datetime.now().strftime("%d-%b-%Y %H:%M")

    ws2["A4"] = "Status / स्थिति"
    ws2["B4"] = "Count"
    ws2["C4"] = "Pages"
    for cell in ("A4", "B4", "C4"):
        ws2[cell].fill = header_fill
        ws2[cell].font = header_font

    # These are LIVE formulas -- edit the manifest and the summary follows.
    row = 5
    for status in Status:
        ws2.cell(row=row, column=1, value=status.value)
        ws2.cell(row=row, column=2,
                 value=f'=COUNTIF(\'01_Manifest\'!H2:H{last},A{row})')
        ws2.cell(row=row, column=3,
                 value=f'=SUMIF(\'01_Manifest\'!H2:H{last},A{row},'
                       f'\'01_Manifest\'!E2:E{last})')
        row += 1

    ws2.cell(row=row, column=1, value="TOTAL").font = Font(bold=True)
    ws2.cell(row=row, column=2, value=f"=SUM(B5:B{row - 1})").font = Font(bold=True)
    ws2.cell(row=row, column=3, value=f"=SUM(C5:C{row - 1})").font = Font(bold=True)

    ws2.column_dimensions["A"].width = 24
    ws2.column_dimensions["B"].width = 10
    ws2.column_dimensions["C"].width = 10

    # ---------------- Sheet 3 : colour legend -----------------------------
    ws3 = wb.create_sheet("03_Legend")
    ws3["A1"] = "Colour code / रंग संकेत"
    ws3["A1"].font = Font(bold=True, size=12, color="1F4E79")
    legend_row = 3
    for key, style in config.HIGHLIGHT_STYLES.items():
        cell = ws3.cell(row=legend_row, column=1, value=style["label"])
        cell.fill = PatternFill("solid", fgColor=style["fill"].lstrip("#"))
        cell.font = Font(color=style["font"].lstrip("#"), bold=style["bold"])
        ws3.cell(row=legend_row, column=2, value=f"key: {key}")
        legend_row += 1
    ws3.column_dimensions["A"].width = 32
    ws3.column_dimensions["B"].width = 18

    target = job_folder / config.MANIFEST_FILE_NAME
    wb.save(target)
    log.info("Manifest written: %s", target)
    return target


def write_summary_text(records: Sequence[FileRecord], tally: dict[str, int],
                       job_folder: Path) -> Path:
    """A plain-text summary you can paste straight into an email."""
    lines: list[str] = []
    add = lines.append

    add(f"{config.APP_NAME} - Intake Summary")
    add(f"Generated : {datetime.now().strftime('%d-%b-%Y %H:%M')}")
    add(f"Job folder: {job_folder}")
    add("=" * 62)
    add("")
    add(f"Files received      : {tally['Total']}")
    add(f"Ready to process    : {tally['Processable']}")
    add(f"Total pages         : {tally['Total pages']}")
    add("")
    add("Breakdown:")
    for status in Status:
        count = tally.get(status.value, 0)
        if count:
            add(f"  - {status.value:<22}: {count}")
    add("")

    problems = [r for r in records if not r.is_processable]
    if problems:
        add("-" * 62)
        add("ITEMS NEEDING YOUR ATTENTION")
        add("-" * 62)
        for record in problems:
            add(f"  * {record.name}")
            add(f"      {record.status.value} - {record.note}")
        add("")

    add("-" * 62)
    add("Note: passwords are held in memory only and are never saved to")
    add("any file. Source documents were opened read-only and not modified.")
    add("=" * 62)

    target = job_folder / config.SUMMARY_FILE_NAME
    target.write_text("\n".join(lines), encoding="utf-8")
    log.info("Summary written: %s", target)
    return target
