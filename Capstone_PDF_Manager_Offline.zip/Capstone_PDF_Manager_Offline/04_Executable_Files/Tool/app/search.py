"""
search.py
=========
STEP 4b - "find every mention of MAAT across all 200 files".

How it works, in three sentences:

    1. BUILD  - every page of every file is read once and its text stored in
                a small database (the index).  This is the slow part.
    2. SEARCH - looking through that database is instant, however many times
                you search.
    3. REPORT - you get all three outputs you asked for.

The index is RESUMABLE.  It remembers each file by fingerprint, so running
the same folder again skips everything already done.  If a 4-hour OCR job is
interrupted, you lose only the file it was working on.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

from . import common, config, ocr_engine

log = common.get_logger("search")

INDEX_FILE = "search_index.db"
SNIPPET_CHARS = 90          # how much text to show either side of a hit


# ===========================================================================
#  1.  THE INDEX
# ===========================================================================
@dataclass
class Hit:
    """One place where the search word was found."""
    file_name: str
    file_path: str
    page_no: int
    term: str
    snippet: str
    source: str             # "native" (already in the PDF) or "ocr" (read from a picture)


class SearchIndex:
    """A small database of page text. Lives in the toolkit folder, not the cloud."""

    def __init__(self, folder: Path | None = None) -> None:
        common.ensure_dirs()
        self.path = (folder or config.APP_ROOT) / INDEX_FILE
        self.conn = sqlite3.connect(str(self.path))
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self) -> None:
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS files (
                id        INTEGER PRIMARY KEY,
                path      TEXT UNIQUE,
                name      TEXT,
                digest    TEXT,
                pages     INTEGER,
                engine    TEXT,
                indexed   TEXT
            );
            CREATE TABLE IF NOT EXISTS pages (
                file_id      INTEGER,
                page_no      INTEGER,
                native_text  TEXT,
                ocr_text     TEXT,
                confidence   REAL,
                PRIMARY KEY (file_id, page_no)
            );
            CREATE INDEX IF NOT EXISTS idx_digest ON files(digest);
        """)
        self.conn.commit()

    # -- writing ----------------------------------------------------------
    def already_done(self, digest: str, engine: str) -> bool:
        """Has this exact file already been read by this exact engine?"""
        row = self.conn.execute(
            "SELECT 1 FROM files WHERE digest = ? AND engine = ?",
            (digest, engine)).fetchone()
        return row is not None

    def store(self, path: Path, digest: str, engine: str,
              pages: Sequence[ocr_engine.PageText]) -> None:
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM files WHERE path = ?", (str(path),))
        cursor.execute(
            "INSERT INTO files (path, name, digest, pages, engine, indexed) "
            "VALUES (?,?,?,?,?,?)",
            (str(path), path.name, digest, len(pages), engine,
             datetime.now().isoformat(" ", "seconds")))
        file_id = cursor.lastrowid

        cursor.executemany(
            "INSERT OR REPLACE INTO pages "
            "(file_id, page_no, native_text, ocr_text, confidence) "
            "VALUES (?,?,?,?,?)",
            [(file_id, p.page_no, p.native_text, p.ocr_text,
              p.average_confidence) for p in pages])
        self.conn.commit()

    # -- reading ----------------------------------------------------------
    def stats(self) -> dict:
        files = self.conn.execute("SELECT COUNT(*) c FROM files").fetchone()["c"]
        pages = self.conn.execute("SELECT COUNT(*) c FROM pages").fetchone()["c"]
        return {"files": files, "pages": pages, "database": str(self.path)}

    def search(self, terms: Sequence[str],
               whole_word: bool = False,
               case_sensitive: bool = False) -> list[Hit]:
        """Look for each term. A page can produce more than one hit."""
        hits: list[Hit] = []
        flags = 0 if case_sensitive else re.IGNORECASE

        patterns = []
        for term in terms:
            escaped = re.escape(term)
            if whole_word:
                escaped = rf"\b{escaped}\b"
            patterns.append((term, re.compile(escaped, flags)))

        rows = self.conn.execute("""
            SELECT f.name, f.path, p.page_no, p.native_text, p.ocr_text
            FROM pages p JOIN files f ON f.id = p.file_id
            ORDER BY f.name, p.page_no
        """)

        for row in rows:
            for source_name, text in (("native", row["native_text"] or ""),
                                      ("ocr", row["ocr_text"] or "")):
                if not text:
                    continue
                for term, pattern in patterns:
                    for match in pattern.finditer(text):
                        start = max(match.start() - SNIPPET_CHARS, 0)
                        end = min(match.end() + SNIPPET_CHARS, len(text))
                        snippet = " ".join(text[start:end].split())
                        hits.append(Hit(row["name"], row["path"], row["page_no"],
                                        term, snippet, source_name))
        return hits

    def close(self) -> None:
        self.conn.close()


# ===========================================================================
#  2.  BUILDING THE INDEX
# ===========================================================================
@dataclass
class IndexReport:
    files_read: int = 0
    files_skipped: int = 0
    pages_read: int = 0
    seconds: float = 0.0
    searchable_pdfs: list[Path] = None

    def __post_init__(self):
        if self.searchable_pdfs is None:
            self.searchable_pdfs = []


def build_index(paths: Sequence[Path],
                job_folder: Path,
                engine: str | None = None,
                smart: bool = False,
                make_searchable: bool = True,
                passwords: dict[str, str] | None = None,
                index: SearchIndex | None = None,
                errors: common.ErrorLog | None = None,
                cancel: common.CancelToken | None = None,
                progress_callback=None) -> IndexReport:
    """
    Read every file once and remember what is on each page.

    Because you chose "searchable PDF AND index", each scanned file also
    produces a *_searchable.pdf in the job folder.
    """
    import time

    index = index or SearchIndex()
    errors = errors or common.ErrorLog(job_folder)
    cancel = cancel or common.CancelToken()
    passwords = passwords or {}
    manager = ocr_engine.OCRManager(engine)
    report = IndexReport()
    started = time.time()

    log.info("Indexing %d file(s) with engine '%s'", len(paths), manager.engine_name)
    progress = common.Progress(len(paths), progress_callback, "Indexing")

    for path in paths:
        cancel.raise_if_cancelled()
        path = Path(path)

        if path.suffix.lower() not in config.EXT_PDF:
            progress.step(f"skipped (not a PDF) {path.name}")
            report.files_skipped += 1
            continue

        try:
            digest = common.file_hash(path)
            if index.already_done(digest, manager.engine_name):
                report.files_skipped += 1
                progress.step(f"already indexed: {path.name}")
                continue

            pages = ocr_engine.read_pdf(
                path, manager,
                password=passwords.get(path.name),
                smart=smart, cancel=cancel,
            )
            index.store(path, digest, manager.engine_name, pages)
            report.files_read += 1
            report.pages_read += len(pages)

            if make_searchable and manager.ready and any(p.words for p in pages):
                pdf = ocr_engine.write_searchable_pdf(
                    path, pages, job_folder, passwords.get(path.name))
                report.searchable_pdfs.append(pdf)

            progress.step(f"{path.name} ({len(pages)} pages)")

        except common.CancelToken.Cancelled:
            log.warning("Indexing cancelled - progress so far is saved.")
            break
        except Exception as exc:                       # noqa: BLE001
            errors.add(path.name, "index", "Could not read", str(exc))
            progress.step(f"FAILED {path.name}")

    report.seconds = time.time() - started
    progress.finish()
    return report


# ===========================================================================
#  3.  THE THREE OUTPUTS
# ===========================================================================
def write_hits_excel(hits: Sequence[Hit], terms: Sequence[str],
                     job_folder: Path) -> Path:
    """Output 1: one row per hit, with the sentence around it."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "01_Hits"

    headers = ["#", "File", "Page", "Term found", "Where from", "Text around it"]
    ws.append(headers)
    header_fill = PatternFill("solid", fgColor="1F4E79")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center")

    style = config.HIGHLIGHT_STYLES["keyword"]
    term_fill = PatternFill("solid", fgColor=style["fill"].lstrip("#"))
    term_font = Font(color=style["font"].lstrip("#"), bold=True)

    for number, hit in enumerate(hits, start=1):
        ws.append([number, hit.file_name, hit.page_no, hit.term,
                   "Already in PDF" if hit.source == "native" else "Read by OCR",
                   hit.snippet])
        ws.cell(row=number + 1, column=4).fill = term_fill
        ws.cell(row=number + 1, column=4).font = term_font
        ws.cell(row=number + 1, column=6).alignment = Alignment(wrap_text=True)

    for column, width in enumerate([5, 40, 7, 18, 16, 90], start=1):
        ws.column_dimensions[get_column_letter(column)].width = width
    ws.freeze_panes = "A2"
    if hits:
        ws.auto_filter.ref = f"A1:F{len(hits) + 1}"

    # Summary sheet with live formulas
    ws2 = wb.create_sheet("02_Summary")
    ws2["A1"] = "Search summary"
    ws2["A1"].font = Font(bold=True, size=14, color="1F4E79")
    ws2["A2"] = "Searched for"
    ws2["B2"] = ", ".join(terms)
    ws2["A3"] = "When"
    ws2["B3"] = datetime.now().strftime("%d-%b-%Y %H:%M")

    ws2["A5"] = "Term"
    ws2["B5"] = "Times found"
    ws2["C5"] = "Files affected"
    for cell in ("A5", "B5", "C5"):
        ws2[cell].fill = header_fill
        ws2[cell].font = Font(color="FFFFFF", bold=True)

    last = len(hits) + 1
    for offset, term in enumerate(terms):
        row = 6 + offset
        ws2.cell(row=row, column=1, value=term)
        ws2.cell(row=row, column=2, value=f"=COUNTIF('01_Hits'!D2:D{last},A{row})")
        distinct = len({h.file_name for h in hits if h.term == term})
        ws2.cell(row=row, column=3, value=distinct)

    ws2.column_dimensions["A"].width = 24
    ws2.column_dimensions["B"].width = 14
    ws2.column_dimensions["C"].width = 16

    target = job_folder / "02_Search_Hits.xlsx"
    wb.save(target)
    log.info("Hit list written: %s (%d hits)", target.name, len(hits))
    return target


def extract_matching_pages(hits: Sequence[Hit], job_folder: Path,
                           passwords: dict[str, str] | None = None) -> Path | None:
    """Output 2: a single new PDF holding ONLY the pages that matched."""
    try:
        import pymupdf as fitz
    except ImportError:                                # pragma: no cover
        import fitz
    from .pdf_ops import _safe_output_path, _save, open_pdf, stamp_footer

    if not hits:
        return None
    passwords = passwords or {}

    # Group by file, so each source is opened only once
    wanted: dict[str, set[int]] = {}
    for hit in hits:
        wanted.setdefault(hit.file_path, set()).add(hit.page_no)

    merged = fitz.open()
    toc: list[list] = []

    for file_path, page_numbers in wanted.items():
        source_path = Path(file_path)
        try:
            source = open_pdf(source_path, passwords.get(source_path.name))
        except Exception as exc:                       # noqa: BLE001
            log.warning("Skipped %s: %s", source_path.name, exc)
            continue
        try:
            first = merged.page_count + 1
            toc.append([1, source_path.stem, first])
            for page_no in sorted(page_numbers):
                position = merged.page_count
                merged.insert_pdf(source, from_page=page_no - 1, to_page=page_no - 1)
                stamp_footer(merged[position],
                             left=f"{source_path.stem} - p{page_no}",
                             centre=str(position + 1),
                             right="Search result - Internal - F&A")
        finally:
            source.close()

    if merged.page_count == 0:
        merged.close()
        return None

    merged.set_toc(toc)
    target = _safe_output_path(job_folder, "03_Matching_Pages")
    _save(merged, target)
    merged.close()
    log.info("Matching pages PDF: %s", target.name)
    return target


def write_highlighted_copies(hits: Sequence[Hit], job_folder: Path,
                             passwords: dict[str, str] | None = None) -> list[Path]:
    """Output 3: a copy of each source PDF with every hit marked in colour."""
    from .pdf_ops import _safe_output_path, _save, open_pdf

    if not hits:
        return []
    passwords = passwords or {}
    folder = job_folder / "04_Highlighted"
    folder.mkdir(parents=True, exist_ok=True)

    grouped: dict[str, list[Hit]] = {}
    for hit in hits:
        grouped.setdefault(hit.file_path, []).append(hit)

    outputs: list[Path] = []
    for file_path, file_hits in grouped.items():
        source_path = Path(file_path)
        try:
            doc = open_pdf(source_path, passwords.get(source_path.name))
        except Exception as exc:                       # noqa: BLE001
            log.warning("Skipped %s: %s", source_path.name, exc)
            continue

        marked = 0
        try:
            for hit in file_hits:
                if hit.page_no > doc.page_count:
                    continue
                page = doc[hit.page_no - 1]
                for rect in page.search_for(hit.term):
                    annotation = page.add_highlight_annot(rect)
                    annotation.set_colors(stroke=(1.0, 0.85, 0.4))   # amber
                    annotation.update()
                    marked += 1

            if marked:
                target = _safe_output_path(folder, f"{source_path.stem}_highlighted")
                _save(doc, target)
                outputs.append(target)
        finally:
            doc.close()

    log.info("Highlighted copies: %d file(s)", len(outputs))
    return outputs
