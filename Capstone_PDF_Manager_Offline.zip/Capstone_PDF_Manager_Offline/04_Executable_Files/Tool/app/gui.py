"""
gui.py
======
STEP 6 - the desktop window.

Layout, as you asked (all three ideas combined):

    +--------------------------------------------------------------+
    |  FILE STRIP - drag files here, or Browse. Always visible.     |
    +----------+---------------------------------------------------+
    | SIDEBAR  |  TABS for the chosen stage                         |
    |  Files   |                                                    |
    |  PDF     |     (the actual controls live here)                |
    |  Read    |                                                    |
    |  Reports |                                                    |
    |  Log     |                                                    |
    +----------+---------------------------------------------------+
    |  Progress bar     Cancel     EN/हिं     Save/Load profile     |
    +--------------------------------------------------------------+

Design rules kept throughout:
  * long jobs run on a background thread, so the window never freezes
  * Cancel stops at a safe point, never mid-write
  * passwords are typed here, held in memory, and NEVER saved to a profile
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import traceback
from pathlib import Path

from PyQt6.QtCore import QObject, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QSizePolicy, QSpinBox, QSplitter, QStackedWidget, QTabWidget,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from . import common, config
from .theme import THEME_3D, PasswordEdit
from .pdf_workspace import PdfWorkspacePage

log = common.get_logger("gui")


# ===========================================================================
#  1.  LANGUAGE
# ===========================================================================
TEXT = {
    "app_title":      ("PDF Manager Offline", "पीडीएफ मैनेजर ऑफलाइन"),
    "drop_hint":      ("Drop files or folders here",
                       "फाइलें यहाँ छोड़ें"),
    "browse_files":   ("Browse files", "फाइलें चुनें"),
    "browse_folder":  ("Browse folder", "फोल्डर चुनें"),
    "clear":          ("Clear", "साफ़ करें"),
    "selected":       ("selected", "चयनित"),
    "nav_files":      ("Files", "फाइलें"),
    "nav_pdf":        ("PDF Workspace", "पीडीएफ कार्यक्षेत्र"),
    "nav_read":       ("Read & Search", "पढ़ें और खोजें"),
    "nav_reports":    ("Reports", "रिपोर्ट"),
    "nav_log":        ("Log", "लॉग"),
    "passwords":      ("Passwords (one per line, never saved to disk)",
                       "पासवर्ड (प्रति पंक्ति एक, डिस्क पर कभी नहीं सहेजे जाते)"),
    "unattended":     ("Unattended - never stop to ask me",
                       "स्वचालित - कभी न पूछें"),
    "run_intake":     ("Check files", "फाइलें जाँचें"),
    "merge":          ("Merge", "मिलाएँ"),
    "split":          ("Split", "विभाजित करें"),
    "rotate":         ("Rotate", "घुमाएँ"),
    "reorder":        ("Reorder", "क्रम बदलें"),
    "crop":           ("Crop", "किनारे काटें"),
    "compress":       ("Compress", "आकार घटाएँ"),
    "stamp":          ("Stamp", "मोहर लगाएँ"),
    "retype":         ("Retype", "पाठ बदलें"),
    "engine":         ("OCR engine", "ओसीआर इंजन"),
    "smart":          ("Smart - skip pages that already have text",
                       "स्मार्ट - पहले से टेक्स्ट वाले पृष्ठ छोड़ें"),
    "searchable":     ("Also make searchable PDF copies",
                       "खोजने योग्य पीडीएफ प्रतियाँ भी बनाएँ"),
    "read_files":     ("Read files into index", "फाइलें पढ़कर सूची बनाएँ"),
    "search_terms":   ("Words to find (one per line)",
                       "खोजने के शब्द (प्रति पंक्ति एक)"),
    "search_now":     ("Search everything", "सब में खोजें"),
    "whole_word":     ("Whole words only", "केवल पूरे शब्द"),
    "case":           ("Match capital letters", "बड़े-छोटे अक्षर मिलाएँ"),
    "report_types":   ("Which reports", "कौन सी रिपोर्ट"),
    "formats":        ("Which formats", "कौन से प्रारूप"),
    "build_report":   ("Build reports", "रिपोर्ट बनाएँ"),
    "edit_keywords":  ("Edit keyword list", "शब्द सूची संपादित करें"),
    "cancel":         ("Cancel", "रद्द करें"),
    "ready":          ("Ready", "तैयार"),
    "open_output":    ("Open Output folder", "आउटपुट फोल्डर खोलें"),
    "save_profile":   ("Save settings", "सेटिंग सहेजें"),
    "load_profile":   ("Load settings", "सेटिंग लोड करें"),
    "no_files":       ("Please choose some files first.",
                       "कृपया पहले कुछ फाइलें चुनें।"),
    "busy":           ("A job is already running.", "एक कार्य पहले से चल रहा है।"),
    "done":           ("Finished", "पूर्ण"),
    "cancelled":      ("Cancelled", "रद्द किया गया"),
    "note_passwords": ("Passwords are kept in memory only and are never "
                       "written to any file or profile.",
                       "पासवर्ड केवल मेमोरी में रहते हैं, किसी फाइल में नहीं।"),
}

LANGUAGE = {"index": 0}          # 0 = English, 1 = Hindi


def t(key: str) -> str:
    """Translate one label into the language currently chosen."""
    pair = TEXT.get(key)
    if not pair:
        return key
    return pair[LANGUAGE["index"]]


# ===========================================================================
#  2.  DARK THEME
# ===========================================================================
DARK = """
QWidget { background:#1E1F26; color:#E6E6E6; font-size:10.5pt; }
QLabel#Title { font-size:16pt; font-weight:700; color:#7FB3FF; }
QLabel#Hint  { color:#9AA0AC; }
QLabel#Section { font-size:11.5pt; font-weight:700; color:#7FB3FF;
                 padding-top:4px; }
QFrame#Card { background:#262832; border:1px solid #343746; border-radius:8px; }
QFrame#Drop { background:#232530; border:2px dashed #4A5068; border-radius:10px; }
QFrame#Drop[hot="true"] { border-color:#7FB3FF; background:#2A3346; }

QPushButton { background:#2F3342; border:1px solid #3E4356; border-radius:6px;
              padding:7px 14px; }
QPushButton:hover { background:#3A4055; }
QPushButton:pressed { background:#2A2E3C; }
QPushButton:disabled { color:#6B7080; background:#26283040; }
QPushButton#Primary { background:#2D6CDF; border:none; font-weight:600; }
QPushButton#Primary:hover { background:#3A7BF0; }
QPushButton#Danger { background:#8A3030; border:none; }
QPushButton#Danger:hover { background:#A63A3A; }

QListWidget#Nav { background:#191A21; border:none; padding:8px 4px;
                  font-size:11pt; }
QListWidget#Nav::item { padding:11px 14px; border-radius:6px; margin:2px 6px; }
QListWidget#Nav::item:selected { background:#2D6CDF; font-weight:600; }
QListWidget#Nav::item:hover:!selected { background:#262832; }

QLineEdit, QPlainTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
    background:#171820; border:1px solid #3A3E4E; border-radius:5px;
    padding:6px; selection-background-color:#2D6CDF; }
QPlainTextEdit#Log { font-family:Consolas,monospace; font-size:9pt; }

QTabWidget::pane { border:1px solid #343746; border-radius:6px; top:-1px; }
QTabBar::tab { background:#232530; padding:8px 16px; margin-right:2px;
               border-top-left-radius:6px; border-top-right-radius:6px; }
QTabBar::tab:selected { background:#2D6CDF; font-weight:600; }

QGroupBox { border:1px solid #343746; border-radius:6px; margin-top:14px;
            padding-top:10px; }
QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 6px;
                   color:#7FB3FF; font-weight:600; }

QProgressBar { background:#171820; border:1px solid #3A3E4E; border-radius:6px;
               height:20px; text-align:center; }
QProgressBar::chunk { background:#2D6CDF; border-radius:5px; }

QTableWidget { background:#171820; gridline-color:#2E3140;
               alternate-background-color:#1C1E27; }
QHeaderView::section { background:#2D3242; padding:6px; border:none;
                       font-weight:600; }
QCheckBox::indicator { width:16px; height:16px; }
QScrollBar:vertical { background:#1E1F26; width:11px; }
QScrollBar::handle:vertical { background:#3E4356; border-radius:5px;
                              min-height:24px; }
"""


# ===========================================================================
#  3.  BACKGROUND WORKER
# ===========================================================================
class Worker(QThread):
    """
    Runs one engine function away from the window.

    The window stays alive and responsive; progress arrives by signal.
    """
    progress = pyqtSignal(int, str)
    message = pyqtSignal(str)
    finished_ok = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, function, *args, **kwargs) -> None:
        super().__init__()
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.cancel = common.CancelToken()

    def report(self, percent: int, text: str = "") -> None:
        self.progress.emit(int(percent), str(text))

    def run(self) -> None:                       # noqa: D102 - Qt calls this
        try:
            result = self.function(self, *self.args, **self.kwargs)
            self.finished_ok.emit(result)
        except common.CancelToken.Cancelled:
            self.message.emit("cancelled")
            self.finished_ok.emit(None)
        except Exception as exc:                 # noqa: BLE001
            log.error("Job failed: %s", exc)
            log.debug(traceback.format_exc())
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class LogBridge(QObject):
    """Sends log lines to the Log tab. Kept simple on purpose."""
    line = pyqtSignal(str)


# ===========================================================================
#  4.  THE FILE STRIP
# ===========================================================================
class FileStrip(QFrame):
    """
    The file bar, made deliberately small.

    It used to be a tall drop box with a column of buttons, which ate about a
    third of the screen for something you touch once per job.  It is now a
    single compact row pinned to the top-left, so the workspace gets the room.

    Dropping files anywhere on this row still works.
    """

    changed = pyqtSignal()

    HEIGHT = 46

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("Card")
        self.paths: list[Path] = []
        self.setAcceptDrops(True)
        self.setFixedHeight(self.HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Fixed)

        row = QHBoxLayout(self)
        row.setContentsMargins(8, 4, 8, 4)
        row.setSpacing(8)

        # A slim drop target, not a big empty box
        self.drop = QFrame()
        self.drop.setObjectName("Drop")
        self.drop.setFixedHeight(self.HEIGHT - 12)
        self.drop.setMinimumWidth(260)
        self.drop.setSizePolicy(QSizePolicy.Policy.Expanding,
                                QSizePolicy.Policy.Fixed)
        drop_row = QHBoxLayout(self.drop)
        drop_row.setContentsMargins(10, 0, 10, 0)
        self.drop_label = QLabel(t("drop_hint"))
        self.drop_label.setObjectName("Hint")
        self.drop_label.setAlignment(Qt.AlignmentFlag.AlignVCenter
                                     | Qt.AlignmentFlag.AlignLeft)
        drop_row.addWidget(self.drop_label)
        row.addWidget(self.drop, 1)

        # Buttons side by side, compact
        self.btn_files = QPushButton(t("browse_files"))
        self.btn_folder = QPushButton(t("browse_folder"))
        self.btn_clear = QPushButton(t("clear"))
        for button in (self.btn_files, self.btn_folder, self.btn_clear):
            button.setFixedHeight(self.HEIGHT - 14)
            button.setMinimumWidth(96)
            row.addWidget(button, 0)

        self.count = QLabel("0 " + t("selected"))
        self.count.setObjectName("Stat")
        self.count.setMinimumWidth(96)
        self.count.setAlignment(Qt.AlignmentFlag.AlignVCenter
                                | Qt.AlignmentFlag.AlignRight)
        row.addWidget(self.count, 0)

        self.btn_files.clicked.connect(self.pick_files)
        self.btn_folder.clicked.connect(self.pick_folder)
        self.btn_clear.clicked.connect(self.clear)

    # -- drag and drop -----------------------------------------------------
    def dragEnterEvent(self, event):             # noqa: N802 - Qt naming
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.drop.setProperty("hot", "true")
            self.drop.style().polish(self.drop)

    def dragLeaveEvent(self, event):             # noqa: N802
        self.drop.setProperty("hot", "false")
        self.drop.style().polish(self.drop)

    def dropEvent(self, event):                  # noqa: N802
        self.drop.setProperty("hot", "false")
        self.drop.style().polish(self.drop)
        for url in event.mimeData().urls():
            self.add(Path(url.toLocalFile()))
        self.refresh()

    # -- adding ------------------------------------------------------------
    def add(self, path: Path) -> None:
        if path.exists() and path not in self.paths:
            self.paths.append(path)

    def pick_files(self) -> None:
        names, _ = QFileDialog.getOpenFileNames(
            self, t("browse_files"), str(Path.home()),
            "Documents (*.pdf *.docx *.xlsx *.csv *.json *.txt *.html "
            "*.png *.jpg *.jpeg *.tif *.tiff);;All files (*.*)")
        for name in names:
            self.add(Path(name))
        self.refresh()

    def pick_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, t("browse_folder"), str(Path.home()))
        if folder:
            self.add(Path(folder))
        self.refresh()

    def clear(self) -> None:
        self.paths.clear()
        self.refresh()

    def refresh(self) -> None:
        """Keep the summary short so the row never needs to grow."""
        self.count.setText(f"{len(self.paths)} {t('selected')}")
        if self.paths:
            first = self.paths[0].name
            extra = f"  +{len(self.paths) - 1} more" if len(self.paths) > 1 else ""
            self.drop_label.setText(first[:52] + extra)
            self.drop_label.setToolTip("\n".join(str(p) for p in self.paths))
        else:
            self.drop_label.setText(t("drop_hint"))
            self.drop_label.setToolTip("")
        self.changed.emit()

    def retranslate(self) -> None:
        self.btn_files.setText(t("browse_files"))
        self.btn_folder.setText(t("browse_folder"))
        self.btn_clear.setText(t("clear"))
        self.refresh()


# ===========================================================================
#  5.  SMALL BUILDING BLOCKS
# ===========================================================================
def section_label(key: str) -> QLabel:
    label = QLabel(t(key))
    label.setObjectName("Section")
    return label


def primary(text_key: str) -> QPushButton:
    button = QPushButton(t(text_key))
    button.setObjectName("Primary")
    button.setMinimumHeight(36)
    return button


def results_table(headers: list[str]) -> QTableWidget:
    table = QTableWidget(0, len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setAlternatingRowColors(True)
    table.horizontalHeader().setStretchLastSection(True)
    table.verticalHeader().setVisible(False)
    return table


def fill_table(table: QTableWidget, rows: list[list[str]]) -> None:
    table.setRowCount(len(rows))
    for row_index, row in enumerate(rows):
        for column_index, value in enumerate(row):
            if column_index >= table.columnCount():
                break
            table.setItem(row_index, column_index,
                          QTableWidgetItem(str(value)))
    table.resizeColumnsToContents()


# ===========================================================================
#  6.  PAGE 1 - FILES  (intake, duplicates, passwords)
# ===========================================================================
class FilesPage(QWidget):
    """Checks the chosen files: type, size, duplicates, locked PDFs."""

    def __init__(self, window: "MainWindow") -> None:
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)

        self.heading = section_label("nav_files")
        layout.addWidget(self.heading)

        box = QGroupBox()
        grid = QGridLayout(box)
        self.pw_label = QLabel(t("passwords"))
        self.passwords = QPlainTextEdit()
        self.passwords.setPlaceholderText("PGCIL@2025\nbidder123")
        self.passwords.setMaximumHeight(84)
        self.note = QLabel(t("note_passwords"))
        self.note.setObjectName("Hint")
        self.note.setWordWrap(True)
        self.unattended = QCheckBox(t("unattended"))

        grid.addWidget(self.pw_label, 0, 0, 1, 2)
        grid.addWidget(self.passwords, 1, 0, 1, 2)
        grid.addWidget(self.note, 2, 0, 1, 2)
        grid.addWidget(self.unattended, 3, 0)
        layout.addWidget(box)

        self.run = primary("run_intake")
        layout.addWidget(self.run)

        self.table = results_table(["File", "Type", "Pages", "Locked",
                                    "Status", "Note"])
        layout.addWidget(self.table, 1)
        self.run.clicked.connect(self.start)

    def password_list(self) -> list[str]:
        return [line.strip() for line in
                self.passwords.toPlainText().splitlines() if line.strip()]

    def start(self) -> None:
        paths = self.window.strip.paths
        if not paths:
            self.window.warn(t("no_files"))
            return

        passwords = self.password_list()
        unattended = self.unattended.isChecked()

        def job(worker):
            from .intake import (IntakeEngine, PasswordVault,
                                 write_manifest, write_summary_text)
            folder = common.new_job_folder("intake")
            vault = PasswordVault(passwords)
            errors = common.ErrorLog(folder)
            engine = IntakeEngine(vault=vault, errors=errors,
                                  cancel=worker.cancel, unattended=True)
            # In the window we never block on a console prompt.  Files that
            # do not open are listed, so you can add the password and re-run.
            records = engine.run(paths, progress_callback=worker.report)
            manifest = write_manifest(records, folder)
            write_summary_text(records, engine.tally(), folder)
            errors.save_csv()
            vault.clear()
            return {"folder": folder, "records": records,
                    "manifest": manifest, "tally": engine.tally()}

        self.window.start_job(job, self.done, "Checking files")

    def done(self, result) -> None:
        if not result:
            return
        rows = [[r.name, r.kind, r.pages or "", "Yes" if r.was_encrypted else "No",
                 r.status.value, r.note] for r in result["records"]]
        fill_table(self.table, rows)
        tally = result["tally"]
        self.window.finish(
            f"{tally['Total']} file(s), {tally['Processable']} ready, "
            f"{tally['Total pages']} pages", result["folder"])

    def retranslate(self) -> None:
        self.heading.setText(t("nav_files"))
        self.pw_label.setText(t("passwords"))
        self.note.setText(t("note_passwords"))
        self.unattended.setText(t("unattended"))
        self.run.setText(t("run_intake"))


# ===========================================================================
#  7.  PAGE 2 - PDF TOOLS  (one tab per tool)
# ===========================================================================
class PdfPage(QWidget):
    """All eight PDF tools, one tab each."""

    def __init__(self, window: "MainWindow") -> None:
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        self.heading = section_label("nav_pdf")
        layout.addWidget(self.heading)

        self.password = PasswordEdit("Password, if the PDF is locked "
                                     "(double-click to reveal)")
        layout.addWidget(self.password)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_tabs()

    # -- helpers -----------------------------------------------------------
    def _tab(self, key: str) -> tuple[QWidget, QGridLayout]:
        page = QWidget()
        grid = QGridLayout(page)
        grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.tabs.addTab(page, t(key))
        return page, grid

    def _first_pdf(self) -> Path | None:
        for path in self.window.strip.paths:
            if path.is_file() and path.suffix.lower() == ".pdf":
                return path
        for path in self.window.strip.paths:
            if path.is_dir():
                for candidate in sorted(path.glob("*.pdf")):
                    return candidate
        return None

    def _all_pdfs(self) -> list[Path]:
        found: list[Path] = []
        for path in self.window.strip.paths:
            if path.is_file() and path.suffix.lower() == ".pdf":
                found.append(path)
            elif path.is_dir():
                found.extend(sorted(path.rglob("*.pdf")))
        return found

    def _run(self, function, label: str) -> None:
        if not self.window.strip.paths:
            self.window.warn(t("no_files"))
            return
        password = self.password.text() or None

        def job(worker):
            from . import pdf_ops
            folder = common.new_job_folder(label.lower().replace(" ", "_"))
            return {"folder": folder,
                    "info": function(pdf_ops, folder, password, worker)}

        self.window.start_job(job, self._done, label)

    def _done(self, result) -> None:
        if not result:
            return
        self.window.finish(str(result["info"]), result["folder"])

    # -- the tabs ----------------------------------------------------------
    def _build_tabs(self) -> None:
        # MERGE ------------------------------------------------------------
        page, grid = self._tab("merge")
        self.merge_name = QLineEdit("Merged")
        grid.addWidget(QLabel("Output name"), 0, 0)
        grid.addWidget(self.merge_name, 0, 1)
        self.merge_stamp = QLineEdit(config.STAMP_TEXT)
        grid.addWidget(QLabel("Footer stamp"), 1, 0)
        grid.addWidget(self.merge_stamp, 1, 1)
        button = primary("merge")
        grid.addWidget(button, 2, 0, 1, 2)
        grid.addWidget(QLabel("Every page gets: source | new page number | "
                              "stamp. Bookmarks are nested per file."), 3, 0, 1, 2)

        def do_merge(ops, folder, password, worker):
            items = [ops.MergeItem(p, password=password, label=p.stem)
                     for p in self._all_pdfs()]
            result = ops.merge_pdfs(items, folder, self.merge_name.text(),
                                    stamp_text=self.merge_stamp.text(),
                                    cancel=worker.cancel,
                                    progress_callback=worker.report)
            return (f"{result.total_pages} pages from {result.sources} file(s), "
                    f"{result.bookmarks} bookmarks")
        button.clicked.connect(lambda: self._run(do_merge, "Merge"))

        # SPLIT ------------------------------------------------------------
        page, grid = self._tab("split")
        self.split_ranges = QLineEdit()
        self.split_ranges.setPlaceholderText("1-40, 41-80   (leave empty to use Every)")
        self.split_every = QSpinBox()
        self.split_every.setRange(0, 5000)
        self.split_every.setValue(0)
        grid.addWidget(QLabel("Page ranges"), 0, 0)
        grid.addWidget(self.split_ranges, 0, 1)
        grid.addWidget(QLabel("Or every N pages"), 1, 0)
        grid.addWidget(self.split_every, 1, 1)
        button = primary("split")
        grid.addWidget(button, 2, 0, 1, 2)

        def do_split(ops, folder, password, worker):
            source = self._first_pdf()
            parts = ops.split_pdf(source, folder,
                                  ranges=self.split_ranges.text() or None,
                                  every=self.split_every.value() or None,
                                  password=password)
            return f"{len(parts)} file(s) created"
        button.clicked.connect(lambda: self._run(do_split, "Split"))

        # ROTATE + REORDER --------------------------------------------------
        page, grid = self._tab("rotate")
        self.rotate_degrees = QComboBox()
        self.rotate_degrees.addItems(["90", "180", "270", "360"])
        self.rotate_pages = QLineEdit()
        self.rotate_pages.setPlaceholderText("2-5   (empty = all pages)")
        grid.addWidget(QLabel("Degrees"), 0, 0)
        grid.addWidget(self.rotate_degrees, 0, 1)
        grid.addWidget(QLabel("Pages"), 1, 0)
        grid.addWidget(self.rotate_pages, 1, 1)
        button = primary("rotate")
        grid.addWidget(button, 2, 0, 1, 2)

        self.reorder_order = QLineEdit()
        self.reorder_order.setPlaceholderText("3,1,2,4-10")
        grid.addWidget(QLabel("New page order"), 3, 0)
        grid.addWidget(self.reorder_order, 3, 1)
        button2 = primary("reorder")
        grid.addWidget(button2, 4, 0, 1, 2)
        grid.addWidget(QLabel("Reordering renumbers the footer automatically, "
                              "and notes where each page came from."), 5, 0, 1, 2)

        def do_rotate(ops, folder, password, worker):
            out = ops.rotate_pdf(self._first_pdf(), folder,
                                 int(self.rotate_degrees.currentText()),
                                 pages=self.rotate_pages.text() or None,
                                 password=password)
            return out.name
        button.clicked.connect(lambda: self._run(do_rotate, "Rotate"))

        def do_reorder(ops, folder, password, worker):
            out = ops.reorder_pdf(self._first_pdf(), folder,
                                  self.reorder_order.text(), password=password)
            return out.name
        button2.clicked.connect(lambda: self._run(do_reorder, "Reorder"))

        # CROP -------------------------------------------------------------
        page, grid = self._tab("crop")
        self.crop_boxes = {}
        for index, side in enumerate(("top", "bottom", "left", "right")):
            spin = QDoubleSpinBox()
            spin.setRange(0, 200)
            spin.setSuffix(" mm")
            grid.addWidget(QLabel(side.title()), index, 0)
            grid.addWidget(spin, index, 1)
            self.crop_boxes[side] = spin
        button = primary("crop")
        grid.addWidget(button, 4, 0, 1, 2)
        grid.addWidget(QLabel("Cropping hides the margin. Nothing is deleted "
                              "from the original file."), 5, 0, 1, 2)

        def do_crop(ops, folder, password, worker):
            out = ops.crop_pdf(self._first_pdf(), folder,
                               top_mm=self.crop_boxes["top"].value(),
                               bottom_mm=self.crop_boxes["bottom"].value(),
                               left_mm=self.crop_boxes["left"].value(),
                               right_mm=self.crop_boxes["right"].value(),
                               password=password)
            return out.name
        button.clicked.connect(lambda: self._run(do_crop, "Crop"))

        # COMPRESS ----------------------------------------------------------
        page, grid = self._tab("compress")
        self.compress_level = QComboBox()
        for key, settings in config.COMPRESSION_LEVELS.items():
            self.compress_level.addItem(settings["label"], key)
        self.compress_level.addItem("Compare all three", "all")
        self.compress_level.setCurrentIndex(self.compress_level.count() - 1)
        grid.addWidget(QLabel("Strength"), 0, 0)
        grid.addWidget(self.compress_level, 0, 1)
        button = primary("compress")
        grid.addWidget(button, 1, 0, 1, 2)

        def do_compress(ops, folder, password, worker):
            source = self._first_pdf()
            level = self.compress_level.currentData()
            if level == "all":
                results = ops.compare_compression(source, folder, password)
                return " | ".join(f"{r.level}: {r.saved_percent:.0f}% smaller"
                                  for r in results)
            result = ops.compress_pdf(source, folder, level, password)
            return result.describe()
        button.clicked.connect(lambda: self._run(do_compress, "Compress"))

        # STAMP -------------------------------------------------------------
        page, grid = self._tab("stamp")
        self.stamp_text = QLineEdit(config.STAMP_TEXT)
        self.stamp_date = QCheckBox("Include date and time")
        self.stamp_date.setChecked(True)
        self.stamp_numbers = QCheckBox("Add page numbers")
        self.stamp_numbers.setChecked(True)
        grid.addWidget(QLabel("Stamp text"), 0, 0)
        grid.addWidget(self.stamp_text, 0, 1)
        grid.addWidget(self.stamp_date, 1, 0, 1, 2)
        grid.addWidget(self.stamp_numbers, 2, 0, 1, 2)
        button = primary("stamp")
        grid.addWidget(button, 3, 0, 1, 2)

        def do_stamp(ops, folder, password, worker):
            out = ops.stamp_pdf(self._first_pdf(), folder,
                                text=self.stamp_text.text(),
                                include_datetime=self.stamp_date.isChecked(),
                                number_pages=self.stamp_numbers.isChecked(),
                                password=password)
            return out.name
        button.clicked.connect(lambda: self._run(do_stamp, "Stamp"))

        # RETYPE ------------------------------------------------------------
        page, grid = self._tab("retype")
        self.find_text = QLineEdit()
        self.find_text.setPlaceholderText("Exact text to cover")
        self.replace_text = QLineEdit()
        self.replace_text.setPlaceholderText("What to type instead")
        self.retype_page = QSpinBox()
        self.retype_page.setRange(1, 5000)
        grid.addWidget(QLabel("Find"), 0, 0)
        grid.addWidget(self.find_text, 0, 1)
        grid.addWidget(QLabel("Replace with"), 1, 0)
        grid.addWidget(self.replace_text, 1, 1)
        grid.addWidget(QLabel("Page"), 2, 0)
        grid.addWidget(self.retype_page, 2, 1)
        button = primary("retype")
        grid.addWidget(button, 3, 0, 1, 2)
        grid.addWidget(QLabel("The old text is genuinely removed, not just "
                              "hidden. The new text uses a standard font."),
                       4, 0, 1, 2)

        def do_retype(ops, folder, password, worker):
            edit = ops.TextEdit(page=self.retype_page.value(),
                                find=self.find_text.text(),
                                new_text=self.replace_text.text())
            out, count = ops.whiteout_and_retype(self._first_pdf(), folder,
                                                 [edit], password=password)
            return f"{count} place(s) replaced -> {out.name}"
        button.clicked.connect(lambda: self._run(do_retype, "Retype"))

    def retranslate(self) -> None:
        self.heading.setText(t("nav_pdf"))
        for index, key in enumerate(["merge", "split", "rotate", "crop",
                                     "compress", "stamp", "retype"]):
            if index < self.tabs.count():
                self.tabs.setTabText(index, t(key))


# ===========================================================================
#  8.  PAGE 3 - READ AND SEARCH
# ===========================================================================
class ReadPage(QWidget):
    """OCR the files into the index, then search everything at once."""

    def __init__(self, window: "MainWindow") -> None:
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        self.heading = section_label("nav_read")
        layout.addWidget(self.heading)

        # -- reading -------------------------------------------------------
        read_box = QGroupBox("1. Read")
        grid = QGridLayout(read_box)
        self.engine_label = QLabel(t("engine"))
        self.engine = QComboBox()
        self.smart = QCheckBox(t("smart"))
        self.searchable = QCheckBox(t("searchable"))
        self.searchable.setChecked(True)
        self.password = PasswordEdit("Password, if the PDFs are locked "
                                     "(double-click to reveal)")
        self.forecast = QLabel("")
        self.forecast.setObjectName("Hint")

        grid.addWidget(self.engine_label, 0, 0)
        grid.addWidget(self.engine, 0, 1)
        grid.addWidget(self.password, 1, 0, 1, 2)
        grid.addWidget(self.smart, 2, 0, 1, 2)
        grid.addWidget(self.searchable, 3, 0, 1, 2)
        grid.addWidget(self.forecast, 4, 0, 1, 2)
        self.read_button = primary("read_files")
        grid.addWidget(self.read_button, 5, 0, 1, 2)
        layout.addWidget(read_box)

        # -- searching -----------------------------------------------------
        search_box = QGroupBox("2. Search")
        grid2 = QGridLayout(search_box)
        self.terms_label = QLabel(t("search_terms"))
        self.terms = QPlainTextEdit()
        self.terms.setPlaceholderText("MAAT\nNet Worth\nLiquid Assets")
        self.terms.setMaximumHeight(76)
        self.whole_word = QCheckBox(t("whole_word"))
        self.case_sensitive = QCheckBox(t("case"))
        grid2.addWidget(self.terms_label, 0, 0, 1, 2)
        grid2.addWidget(self.terms, 1, 0, 1, 2)
        grid2.addWidget(self.whole_word, 2, 0)
        grid2.addWidget(self.case_sensitive, 2, 1)
        self.search_button = primary("search_now")
        grid2.addWidget(self.search_button, 3, 0, 1, 2)
        layout.addWidget(search_box)

        self.table = results_table(["File", "Page", "Word", "Source",
                                    "Text around it"])
        layout.addWidget(self.table, 1)

        self.read_button.clicked.connect(self.start_read)
        self.search_button.clicked.connect(self.start_search)
        self.refresh_engines()

    def refresh_engines(self) -> None:
        """Show only the engines actually installed on this machine."""
        from . import ocr_engine
        self.engine.clear()
        installed = ocr_engine.available_engines()
        self.engine.addItem("No OCR - use existing text only", "none")
        for name in installed:
            self.engine.addItem(config.OCR_ENGINES.get(name, name), name)
        if installed:
            self.engine.setCurrentIndex(1)
            self.forecast.setText(f"Installed: {', '.join(installed)}")
        else:
            self.forecast.setText(
                "No OCR engine installed. Run setup_ocr.bat to add one. "
                "Files with real text still work.")

    def start_read(self) -> None:
        if not self.window.strip.paths:
            self.window.warn(t("no_files"))
            return
        paths = list(self.window.strip.paths)
        engine = self.engine.currentData()
        smart = self.smart.isChecked()
        searchable = self.searchable.isChecked()
        password = self.password.text() or None

        def job(worker):
            from .intake import collect_paths
            from . import search as search_module
            folder = common.new_job_folder("read")
            found, _ = collect_paths(paths)
            pdfs = [p for p in found if p.suffix.lower() == ".pdf"]
            index = search_module.SearchIndex()
            passwords = {p.name: password for p in pdfs} if password else {}
            report = search_module.build_index(
                pdfs, folder, engine=engine, smart=smart,
                make_searchable=searchable, passwords=passwords,
                index=index, cancel=worker.cancel,
                progress_callback=worker.report)
            stats = index.stats()
            index.close()
            return {"folder": folder, "report": report, "stats": stats}

        self.window.start_job(job, self.read_done, "Reading files")

    def read_done(self, result) -> None:
        if not result:
            return
        report, stats = result["report"], result["stats"]
        self.window.finish(
            f"Read {report.files_read} file(s), {report.pages_read} page(s). "
            f"Index now holds {stats['files']} files / {stats['pages']} pages.",
            result["folder"])

    def start_search(self) -> None:
        terms = [line.strip() for line in
                 self.terms.toPlainText().splitlines() if line.strip()]
        if not terms:
            self.window.warn("Please type at least one word to find.")
            return
        whole = self.whole_word.isChecked()
        case = self.case_sensitive.isChecked()

        def job(worker):
            from . import search as search_module
            folder = common.new_job_folder("search")
            index = search_module.SearchIndex()
            if index.stats()["pages"] == 0:
                index.close()
                raise RuntimeError(
                    "Nothing has been read yet. Use 'Read files into index' first.")
            worker.report(20, "searching")
            hits = index.search(terms, whole_word=whole, case_sensitive=case)
            index.close()
            worker.report(45, "writing hit list")
            excel = search_module.write_hits_excel(hits, terms, folder)
            worker.report(70, "collecting matching pages")
            search_module.extract_matching_pages(hits, folder)
            worker.report(88, "highlighting")
            search_module.write_highlighted_copies(hits, folder)
            worker.report(100, "done")
            return {"folder": folder, "hits": hits, "excel": excel}

        self.window.start_job(job, self.search_done, "Searching")

    def search_done(self, result) -> None:
        if not result:
            return
        hits = result["hits"]
        rows = [[h.file_name, h.page_no, h.term,
                 "In PDF" if h.source == "native" else "OCR", h.snippet]
                for h in hits[:800]]
        fill_table(self.table, rows)
        self.window.finish(f"{len(hits)} mention(s) found", result["folder"])

    def retranslate(self) -> None:
        self.heading.setText(t("nav_read"))
        self.engine_label.setText(t("engine"))
        self.smart.setText(t("smart"))
        self.searchable.setText(t("searchable"))
        self.read_button.setText(t("read_files"))
        self.terms_label.setText(t("search_terms"))
        self.whole_word.setText(t("whole_word"))
        self.case_sensitive.setText(t("case"))
        self.search_button.setText(t("search_now"))


# ===========================================================================
#  9.  PAGE 4 - REPORTS
# ===========================================================================
class ReportPage(QWidget):
    """Three reports, four formats, driven by your keyword lists."""

    def __init__(self, window: "MainWindow") -> None:
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        self.heading = section_label("nav_reports")
        layout.addWidget(self.heading)

        self.types_box = QGroupBox(t("report_types"))
        types_layout = QHBoxLayout(self.types_box)
        self.types = {}
        for key, label in (("digest", "Document Digest"),
                           ("comparison", "Bid Comparison"),
                           ("findings", "Search Findings")):
            check = QCheckBox(label)
            check.setChecked(True)
            types_layout.addWidget(check)
            self.types[key] = check
        layout.addWidget(self.types_box)

        self.formats_box = QGroupBox(t("formats"))
        formats_layout = QHBoxLayout(self.formats_box)
        self.formats = {}
        for key, label in (("word", "Word"), ("pptx", "PowerPoint"),
                           ("html", "HTML"), ("pdf", "PDF")):
            check = QCheckBox(label)
            check.setChecked(True)
            formats_layout.addWidget(check)
            self.formats[key] = check
        layout.addWidget(self.formats_box)

        self.terms = QLineEdit()
        self.terms.setPlaceholderText(
            "Words for the Findings report, separated by commas "
            "(empty = use your keyword list)")
        layout.addWidget(self.terms)

        buttons = QHBoxLayout()
        self.build = primary("build_report")
        self.edit_keywords = QPushButton(t("edit_keywords"))
        buttons.addWidget(self.build, 2)
        buttons.addWidget(self.edit_keywords, 1)
        layout.addLayout(buttons)

        self.table = results_table(["Report", "Format", "File", "Size"])
        layout.addWidget(self.table, 1)

        self.build.clicked.connect(self.start)
        self.edit_keywords.clicked.connect(self.open_keywords)

    def open_keywords(self) -> None:
        from . import highlight
        xlsx_path, txt_path = highlight.create_keyword_files()
        open_in_explorer(xlsx_path)
        self.window.status.setText(
            f"Opened {xlsx_path.name}. Edit, save, then build again.")

    def start(self) -> None:
        wanted = [key for key, check in self.types.items() if check.isChecked()]
        formats = tuple(key for key, check in self.formats.items()
                        if check.isChecked())
        if not wanted or not formats:
            self.window.warn("Please tick at least one report and one format.")
            return
        raw_terms = [item.strip() for item in self.terms.text().split(",")
                     if item.strip()]

        def job(worker):
            from . import analysis, highlight, search as search_module, writers
            folder = common.new_job_folder("report")
            index = search_module.SearchIndex()
            if index.stats()["pages"] == 0:
                index.close()
                raise RuntimeError(
                    "Nothing has been read yet. Use 'Read & Search' first.")

            highlighter = highlight.Highlighter()
            worker.report(15, "gathering facts")
            facts = analysis.gather_facts(index, highlighter)

            reports = []
            if "digest" in wanted:
                reports.append(analysis.build_digest(facts, highlighter))
            if "comparison" in wanted:
                reports.append(analysis.build_comparison(facts))
            if "findings" in wanted:
                terms = raw_terms or highlighter.keywords.get("keyword", [])[:6]
                hits = index.search(terms) if terms else []
                reports.append(analysis.build_findings(hits, terms, highlighter))
            index.close()

            produced = []
            for number, report in enumerate(reports, start=1):
                worker.report(int(20 + 75 * number / max(len(reports), 1)),
                              report.title)
                for name, path in writers.write_all(report, folder, formats).items():
                    produced.append((report.title, name, path))
            worker.report(100, "done")
            return {"folder": folder, "produced": produced}

        self.window.start_job(job, self.done, "Building reports")

    def done(self, result) -> None:
        if not result:
            return
        rows = [[title, name, path.name,
                 common.human_size(path.stat().st_size)]
                for title, name, path in result["produced"]]
        fill_table(self.table, rows)
        self.window.finish(f"{len(rows)} document(s) created", result["folder"])

    def retranslate(self) -> None:
        self.heading.setText(t("nav_reports"))
        self.types_box.setTitle(t("report_types"))
        self.formats_box.setTitle(t("formats"))
        self.build.setText(t("build_report"))
        self.edit_keywords.setText(t("edit_keywords"))


# ===========================================================================
#  10.  PAGE 5 - LOG
# ===========================================================================
class LogPage(QWidget):
    """The audit trail: what happened, in order, with a way to open the files."""

    def __init__(self, window: "MainWindow") -> None:
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        self.heading = section_label("nav_log")
        layout.addWidget(self.heading)

        self.view = QPlainTextEdit()
        self.view.setObjectName("Log")
        self.view.setReadOnly(True)
        layout.addWidget(self.view, 1)

        buttons = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh")
        self.folder_button = QPushButton("Open Logs folder")
        self.clear_button = QPushButton("Clear view")
        for button in (self.refresh_button, self.folder_button, self.clear_button):
            buttons.addWidget(button)
        layout.addLayout(buttons)

        self.refresh_button.clicked.connect(self.reload)
        self.folder_button.clicked.connect(
            lambda: open_in_explorer(config.LOG_DIR))
        self.clear_button.clicked.connect(self.view.clear)
        self.reload()

    def append(self, line: str) -> None:
        self.view.appendPlainText(line)

    def reload(self) -> None:
        path = config.LOG_DIR / config.LOG_FILE_NAME
        if path.exists():
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            self.view.setPlainText("\n".join(lines[-500:]))
            self.view.verticalScrollBar().setValue(
                self.view.verticalScrollBar().maximum())

    def retranslate(self) -> None:
        self.heading.setText(t("nav_log"))


def open_in_explorer(path: Path) -> None:
    """Open a folder, or a file's folder, in Windows Explorer."""
    try:
        path = Path(path)
        if sys.platform.startswith("win"):
            if path.is_file():
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                os.startfile(str(path))          # noqa: S606
        else:
            subprocess.Popen(["xdg-open", str(path if path.is_dir()
                                              else path.parent)])
    except Exception as exc:                     # noqa: BLE001
        log.warning("Could not open %s: %s", path, exc)


# ===========================================================================
#  11.  THE MAIN WINDOW
# ===========================================================================
class MainWindow(QWidget):
    """Holds everything together: file strip, sidebar, pages, bottom bar."""

    def __init__(self) -> None:
        super().__init__()
        common.ensure_dirs()
        self.worker: Worker | None = None
        self.last_folder: Path | None = None

        self.setWindowTitle(f"{t('app_title')}  v{config.APP_VERSION}")
        self.resize(1180, 800)
        self.setMinimumSize(940, 640)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 12, 14, 12)
        outer.setSpacing(10)

        # -- title ---------------------------------------------------------
        header = QHBoxLayout()
        self.title = QLabel(f"{config.APP_NAME}")
        self.title.setObjectName("Title")
        header.addWidget(self.title)
        header.addStretch(1)
        self.subtitle = QLabel(f"{config.APP_OWNER}  |  fully offline")
        self.subtitle.setObjectName("Hint")
        header.addWidget(self.subtitle)
        outer.addLayout(header)

        # -- file strip ----------------------------------------------------
        self.strip = FileStrip()
        outer.addWidget(self.strip)
        # When the chosen files change, the PDF workspace reloads, and any
        # memory held for the previous files is released immediately.
        self.strip.changed.connect(self.on_files_changed)

        # -- sidebar + pages -----------------------------------------------
        splitter = QSplitter(Qt.Orientation.Horizontal)

        self.nav = QListWidget()
        self.nav.setObjectName("Nav")
        self.nav.setMaximumWidth(190)
        self.nav.setMinimumWidth(150)

        self.pages = QStackedWidget()
        self.files_page = FilesPage(self)
        self.pdf_page = PdfWorkspacePage(self)
        self.read_page = ReadPage(self)
        self.report_page = ReportPage(self)
        self.log_page = LogPage(self)

        self.page_keys = ["nav_files", "nav_pdf", "nav_read",
                          "nav_reports", "nav_log"]
        for key, page in zip(self.page_keys,
                             [self.files_page, self.pdf_page, self.read_page,
                              self.report_page, self.log_page]):
            QListWidgetItem(t(key), self.nav)
            self.pages.addWidget(page)

        splitter.addWidget(self.nav)
        splitter.addWidget(self.pages)
        splitter.setStretchFactor(1, 1)
        outer.addWidget(splitter, 1)

        self.nav.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.nav.setCurrentRow(0)

        # -- bottom bar ----------------------------------------------------
        bottom = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.status = QLabel(t("ready"))
        self.status.setObjectName("Hint")

        self.cancel_button = QPushButton(t("cancel"))
        self.cancel_button.setObjectName("Danger")
        self.cancel_button.setEnabled(False)
        self.output_button = QPushButton(t("open_output"))
        self.language_button = QPushButton("हिंदी")
        self.save_button = QPushButton(t("save_profile"))
        self.load_button = QPushButton(t("load_profile"))

        bottom.addWidget(self.progress, 3)
        bottom.addWidget(self.cancel_button)
        bottom.addWidget(self.output_button)
        bottom.addWidget(self.save_button)
        bottom.addWidget(self.load_button)
        bottom.addWidget(self.language_button)
        outer.addLayout(bottom)
        outer.addWidget(self.status)

        self.cancel_button.clicked.connect(self.cancel_job)
        self.output_button.clicked.connect(
            lambda: open_in_explorer(self.last_folder or config.OUTPUT_DIR))
        self.language_button.clicked.connect(self.toggle_language)
        self.save_button.clicked.connect(self.save_profile)
        self.load_button.clicked.connect(self.load_profile)

    # -- running jobs ------------------------------------------------------
    def start_job(self, function, on_done, label: str) -> None:
        if self.worker and self.worker.isRunning():
            self.warn(t("busy"))
            return

        self.progress.setValue(0)
        self.progress.setFormat("%p%")
        self.status.setText(f"{label}...")
        self.cancel_button.setEnabled(True)
        self.set_buttons_enabled(False)

        self.worker = Worker(function)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(on_done)
        self.worker.finished_ok.connect(lambda _: self.job_ended())
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def on_progress(self, percent: int, text: str) -> None:
        self.progress.setValue(percent)
        if text:
            self.status.setText(text[:150])
            self.log_page.append(f"[{percent:3d}%] {text}")

    def on_failed(self, message: str) -> None:
        self.job_ended()
        self.status.setText(message[:150])
        self.log_page.append(f"ERROR: {message}")
        QMessageBox.warning(self, "Something went wrong", message)

    def job_ended(self) -> None:
        self.cancel_button.setEnabled(False)
        self.set_buttons_enabled(True)
        self.log_page.reload()

    def cancel_job(self) -> None:
        if self.worker and self.worker.isRunning():
            self.worker.cancel.cancel()
            self.status.setText(t("cancelled") + " - stopping at a safe point...")

    def finish(self, message: str, folder: Path | None = None) -> None:
        self.progress.setValue(100)
        self.last_folder = folder
        self.status.setText(f"{t('done')}: {message}")
        self.log_page.append(f"DONE: {message}")
        if folder:
            self.log_page.append(f"      -> {folder}")

    def set_buttons_enabled(self, enabled: bool) -> None:
        for page in (self.files_page, self.pdf_page,
                     self.read_page, self.report_page):
            for button in page.findChildren(QPushButton):
                if button.objectName() == "Primary":
                    button.setEnabled(enabled)

    def warn(self, message: str) -> None:
        self.status.setText(message)
        QMessageBox.information(self, config.APP_NAME, message)

    # -- language ----------------------------------------------------------
    def toggle_language(self) -> None:
        LANGUAGE["index"] = 1 - LANGUAGE["index"]
        self.language_button.setText("English" if LANGUAGE["index"] else "हिंदी")
        self.setWindowTitle(f"{t('app_title')}  v{config.APP_VERSION}")

        for index, key in enumerate(self.page_keys):
            self.nav.item(index).setText(t(key))
        self.strip.retranslate()
        for page in (self.files_page, self.pdf_page, self.read_page,
                     self.report_page, self.log_page):
            page.retranslate()

        self.cancel_button.setText(t("cancel"))
        self.output_button.setText(t("open_output"))
        self.save_button.setText(t("save_profile"))
        self.load_button.setText(t("load_profile"))
        self.status.setText(t("ready"))

    # -- job profiles (settings only, never passwords or file lists) -------
    def collect_settings(self) -> dict:
        return {
            "version": config.APP_VERSION,
            "language": LANGUAGE["index"],
            "unattended": self.files_page.unattended.isChecked(),
            "ocr_engine": self.read_page.engine.currentData(),
            "ocr_smart": self.read_page.smart.isChecked(),
            "ocr_searchable": self.read_page.searchable.isChecked(),
            "search_whole_word": self.read_page.whole_word.isChecked(),
            "search_case": self.read_page.case_sensitive.isChecked(),
            "compression": self.pdf_page.compress_level.currentData(),
            "stamp_text": self.pdf_page.stamp_text.text(),
            "report_types": {k: c.isChecked()
                             for k, c in self.report_page.types.items()},
            "report_formats": {k: c.isChecked()
                               for k, c in self.report_page.formats.items()},
        }

    def apply_settings(self, data: dict) -> None:
        if data.get("language") is not None and data["language"] != LANGUAGE["index"]:
            self.toggle_language()
        self.files_page.unattended.setChecked(bool(data.get("unattended")))
        self.read_page.smart.setChecked(bool(data.get("ocr_smart")))
        self.read_page.searchable.setChecked(bool(data.get("ocr_searchable", True)))
        self.read_page.whole_word.setChecked(bool(data.get("search_whole_word")))
        self.read_page.case_sensitive.setChecked(bool(data.get("search_case")))
        self.pdf_page.stamp_text.setText(data.get("stamp_text", config.STAMP_TEXT))

        for combo, value in ((self.read_page.engine, data.get("ocr_engine")),
                             (self.pdf_page.compress_level, data.get("compression"))):
            if value is not None:
                position = combo.findData(value)
                if position >= 0:
                    combo.setCurrentIndex(position)

        for key, checked in (data.get("report_types") or {}).items():
            if key in self.report_page.types:
                self.report_page.types[key].setChecked(bool(checked))
        for key, checked in (data.get("report_formats") or {}).items():
            if key in self.report_page.formats:
                self.report_page.formats[key].setChecked(bool(checked))

    def save_profile(self) -> None:
        config.PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        name, _ = QFileDialog.getSaveFileName(
            self, t("save_profile"),
            str(config.PROFILES_DIR / "my_job.json"), "Settings (*.json)")
        if not name:
            return
        Path(name).write_text(
            json.dumps(self.collect_settings(), indent=2), encoding="utf-8")
        self.status.setText(f"Settings saved: {Path(name).name} "
                            f"(no passwords, no file names)")

    def load_profile(self) -> None:
        name, _ = QFileDialog.getOpenFileName(
            self, t("load_profile"), str(config.PROFILES_DIR), "Settings (*.json)")
        if not name:
            return
        try:
            self.apply_settings(json.loads(Path(name).read_text(encoding="utf-8")))
            self.status.setText(f"Settings loaded: {Path(name).name}")
        except Exception as exc:                 # noqa: BLE001
            self.warn(f"Could not read that settings file: {exc}")

    def on_files_changed(self) -> None:
        """
        The file list changed.

        The workspace flushes whatever it held for the old files before
        loading the new ones, so memory never accumulates across jobs.
        """
        try:
            if self.strip.paths:
                self.pdf_page.load(list(self.strip.paths))
            else:
                self.pdf_page.flush(ask=False)
        except Exception as exc:                     # noqa: BLE001
            log.warning("Workspace reload failed: %s", exc)

    def closeEvent(self, event):                     # noqa: N802 - Qt naming
        """
        Closing the window.

        1. If a job is running, offer to stop it.
        2. If the workspace has unsaved changes, ask: Save / Discard / Cancel.
           Choosing Save writes the output before the window closes.
        3. Release all memory: thumbnails, open documents, worker threads.
        """
        if self.worker and self.worker.isRunning():
            answer = QMessageBox.question(
                self, config.APP_NAME,
                "A job is still running. Stop it and close?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.worker.cancel.cancel()
            self.worker.wait(4000)

        if getattr(self.pdf_page, "dirty", False):
            box = QMessageBox(self)
            box.setWindowTitle("Unsaved changes")
            box.setText("You have unsaved changes in the PDF Workspace.")
            box.setInformativeText(
                "Save them to the Output folder before closing?")
            save = box.addButton("Save", QMessageBox.ButtonRole.AcceptRole)
            discard = box.addButton("Discard", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(save)
            box.exec()

            clicked = box.clickedButton()
            if clicked is save:
                written = self.pdf_page.export(download=False, silent=True)
                if written:
                    QMessageBox.information(
                        self, config.APP_NAME,
                        f"{len(written)} file(s) saved to:\n{written[0].parent}")
            elif clicked is not discard:
                event.ignore()
                return

        try:
            self.pdf_page.shutdown()
        except Exception:                            # noqa: BLE001
            pass
        event.accept()


# ===========================================================================
#  12.  START THE APPLICATION
# ===========================================================================
def run() -> int:
    application = QApplication(sys.argv)
    application.setApplicationName(config.APP_NAME)
    application.setStyleSheet(THEME_3D)
    font = QFont("Segoe UI", 10)
    font.setWeight(QFont.Weight.DemiBold)   # bold, high contrast
    application.setFont(font)

    window = MainWindow()
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(run())
