"""
highlight.py
============
STEP 5a - the brain that decides what deserves attention.

Two sources of judgement, exactly as you asked:

    1. YOUR KEYWORD LIST  - edited in profiles\\keywords.xlsx (nice tables)
                            or profiles\\keywords.txt (quick typing).
                            Both are read and merged, so use whichever
                            is handy at the time.

    2. AUTOMATIC RULES    - no list needed.  Money, dates and negative
                            figures are spotted by their shape alone.

Everything downstream (Excel, Word, PPT, HTML, PDF) asks this module what
colour a piece of text should be, so one word means one colour everywhere.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from . import common, config

log = common.get_logger("highlight")

KEYWORDS_XLSX = "keywords.xlsx"
KEYWORDS_TXT = "keywords.txt"


# ===========================================================================
#  1.  AUTOMATIC RULES  (shape-based, no list needed)
# ===========================================================================
# Indian money: Rs. 1,23,456.78 / ₹ 4,523.75 Cr / INR 812.50 lakh / 45.5 Crore
MONEY_PATTERN = re.compile(
    r"(?:(?:Rs\.?|INR|₹)\s*)?"
    r"\d{1,3}(?:[,\d]{0,15})(?:\.\d{1,2})?"
    r"\s*(?:Cr\.?|Crores?|Lakhs?|Lacs?|Mn|Bn)\b"
    r"|(?:Rs\.?|INR|₹)\s*\d{1,3}(?:[,\d]{0,15})(?:\.\d{1,2})?",
    re.IGNORECASE,
)

# 31.03.2025 / 31-Mar-2025 / 31/03/25 / 2025-03-31 / 31 March 2025
DATE_PATTERN = re.compile(
    r"\b\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}\b"
    r"|\b\d{4}-\d{2}-\d{2}\b"
    r"|\b\d{1,2}[-\s](?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
    r"[a-z]*[-\s]\d{2,4}\b",
    re.IGNORECASE,
)

# Accountants write a loss as (1,234) -- brackets mean negative
NEGATIVE_PATTERN = re.compile(r"\(\s*\d{1,3}(?:[,\d]{0,15})(?:\.\d{1,2})?\s*\)"
                              r"|(?<![\w.])-\s?\d{1,3}(?:[,\d]{0,15})(?:\.\d{1,2})?")


@dataclass
class Flag:
    """One thing worth noticing, and why."""
    text: str
    category: str          # critical / warning / ok / money / date / keyword
    reason: str
    start: int = 0
    end: int = 0

    @property
    def style(self) -> dict:
        return config.HIGHLIGHT_STYLES.get(
            self.category, config.HIGHLIGHT_STYLES["keyword"])


# ===========================================================================
#  2.  THE EDITABLE KEYWORD FILES
# ===========================================================================
def create_keyword_files(folder: Path | None = None,
                         overwrite: bool = False) -> tuple[Path, Path]:
    """
    Write BOTH editable lists into profiles\\, pre-filled with sensible
    starting words.  You edit them in Excel or Notepad; the tool reads
    whichever exists (and merges if both do).
    """
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    folder = folder or config.PROFILES_DIR
    folder.mkdir(parents=True, exist_ok=True)
    xlsx_path = folder / KEYWORDS_XLSX
    txt_path = folder / KEYWORDS_TXT

    # ---- the Excel version, one sheet per colour -------------------------
    if overwrite or not xlsx_path.exists():
        wb = Workbook()
        wb.remove(wb.active)

        for category, words in config.DEFAULT_KEYWORDS.items():
            style = config.HIGHLIGHT_STYLES[category]
            ws = wb.create_sheet(category[:31])
            ws["A1"] = f"Words to flag as: {style['label']}"
            ws["A1"].font = Font(bold=True, size=12,
                                 color=style["font"].lstrip("#"))
            ws["A2"] = "Type one word or phrase per row, from row 4 downwards."
            ws["A3"] = "Word or phrase"
            ws["A3"].fill = PatternFill("solid", fgColor="1F4E79")
            ws["A3"].font = Font(color="FFFFFF", bold=True)
            for offset, word in enumerate(words):
                cell = ws.cell(row=4 + offset, column=1, value=word)
                cell.fill = PatternFill("solid",
                                        fgColor=style["fill"].lstrip("#"))
                cell.font = Font(color=style["font"].lstrip("#"),
                                 bold=style["bold"])
            ws.column_dimensions["A"].width = 44
            ws["A2"].alignment = Alignment(wrap_text=True)

        # A read-me sheet so the file explains itself
        ws = wb.create_sheet("READ_ME", 0)
        ws["A1"] = "How this file works / यह फाइल कैसे काम करती है"
        ws["A1"].font = Font(bold=True, size=14, color="1F4E79")
        guidance = [
            "",
            "Each sheet is one colour category.",
            "Add or delete words freely, then SAVE. The tool reads this file",
            "every time it makes a report - no restart needed.",
            "",
            "critical  = red    - stop and look (rejected, disqualified)",
            "warning   = amber  - check this (provisional, unaudited)",
            "keyword   = orange - your watch words (MAAT, Net Worth)",
            "",
            "Money, dates and negative figures are found automatically.",
            "You do not need to list those.",
        ]
        for offset, line in enumerate(guidance, start=2):
            ws.cell(row=offset, column=1, value=line)
        ws.column_dimensions["A"].width = 78

        wb.save(xlsx_path)
        log.info("Keyword workbook created: %s", xlsx_path)

    # ---- the plain-text version, for quick edits -------------------------
    if overwrite or not txt_path.exists():
        lines = [
            "# PG Bid Toolkit - keyword watch list",
            "# One word or phrase per line.",
            "# A line starting with [name] begins a new colour category.",
            "# Lines starting with # are notes and are ignored.",
            "",
        ]
        for category, words in config.DEFAULT_KEYWORDS.items():
            label = config.HIGHLIGHT_STYLES[category]["label"]
            lines.append(f"[{category}]   # {label}")
            lines.extend(words)
            lines.append("")
        txt_path.write_text("\n".join(lines), encoding="utf-8")
        log.info("Keyword text file created: %s", txt_path)

    return xlsx_path, txt_path


def load_keywords(folder: Path | None = None) -> dict[str, list[str]]:
    """
    Read your lists.

    Both files are read and merged, so a word added in either place counts.
    If neither file exists, the built-in starting list is used.
    """
    folder = folder or config.PROFILES_DIR
    merged: dict[str, set[str]] = {
        key: set(words) for key, words in config.DEFAULT_KEYWORDS.items()
    }

    # -- the Excel file ----------------------------------------------------
    xlsx_path = folder / KEYWORDS_XLSX
    if xlsx_path.exists():
        try:
            from openpyxl import load_workbook
            wb = load_workbook(xlsx_path, read_only=True, data_only=True)
            for sheet_name in wb.sheetnames:
                if sheet_name.upper() == "READ_ME":
                    continue
                category = sheet_name.lower()
                if category not in config.HIGHLIGHT_STYLES:
                    continue
                found: set[str] = set()
                for row in wb[sheet_name].iter_rows(min_row=4, max_col=1,
                                                    values_only=True):
                    value = (row[0] or "").strip() if row[0] else ""
                    if value:
                        found.add(value)
                if found:                      # an edited sheet replaces defaults
                    merged[category] = found
            wb.close()
        except Exception as exc:               # noqa: BLE001
            log.warning("Could not read %s (%s) - using defaults", xlsx_path.name, exc)

    # -- the text file, merged on top --------------------------------------
    txt_path = folder / KEYWORDS_TXT
    if txt_path.exists():
        try:
            category = "keyword"
            for line in txt_path.read_text(encoding="utf-8").splitlines():
                line = line.split("#")[0].strip()
                if not line:
                    continue
                if line.startswith("[") and line.endswith("]"):
                    name = line[1:-1].strip().lower()
                    category = name if name in config.HIGHLIGHT_STYLES else "keyword"
                    continue
                merged.setdefault(category, set()).add(line)
        except Exception as exc:               # noqa: BLE001
            log.warning("Could not read %s (%s)", txt_path.name, exc)

    return {key: sorted(words) for key, words in merged.items() if words}


# ===========================================================================
#  3.  THE JUDGE
# ===========================================================================
class Highlighter:
    """Looks at text and says what, if anything, deserves colour."""

    def __init__(self, keywords: dict[str, list[str]] | None = None,
                 auto_rules: dict | None = None) -> None:
        self.keywords = keywords or load_keywords()
        self.rules = auto_rules or dict(config.AUTO_RULES)
        self._patterns: list[tuple[str, str, re.Pattern]] = []
        for category, words in self.keywords.items():
            for word in words:
                self._patterns.append(
                    (category, word,
                     re.compile(re.escape(word), re.IGNORECASE)))

    # -- the main question -------------------------------------------------
    def scan(self, text: str) -> list[Flag]:
        """Return every flag found in a piece of text, in order."""
        if not text:
            return []
        flags: list[Flag] = []

        for category, word, pattern in self._patterns:
            for match in pattern.finditer(text):
                flags.append(Flag(match.group(0), category,
                                  f"watch word: {word}",
                                  match.start(), match.end()))

        if self.rules.get("highlight_negatives"):
            for match in NEGATIVE_PATTERN.finditer(text):
                flags.append(Flag(match.group(0), "critical",
                                  "negative figure", match.start(), match.end()))

        if self.rules.get("highlight_currency"):
            for match in MONEY_PATTERN.finditer(text):
                flags.append(Flag(match.group(0).strip(), "money",
                                  "financial figure", match.start(), match.end()))

        if self.rules.get("highlight_dates"):
            for match in DATE_PATTERN.finditer(text):
                flags.append(Flag(match.group(0), "date",
                                  "date", match.start(), match.end()))

        flags.sort(key=lambda f: f.start)
        return flags

    def classify(self, text: str) -> str | None:
        """
        One colour for a whole cell or line -- the most serious wins.

        Order of seriousness: critical > warning > keyword > money > date.
        """
        flags = self.scan(text)
        if not flags:
            return None
        for category in ("critical", "warning", "keyword", "money", "date"):
            if any(f.category == category for f in flags):
                return category
        return None

    def summarise(self, text: str) -> dict[str, int]:
        """How many of each kind -- used for the report dashboards."""
        counts: dict[str, int] = {}
        for flag in self.scan(text):
            counts[flag.category] = counts.get(flag.category, 0) + 1
        return counts

    def legend(self) -> list[tuple[str, dict]]:
        """The colour key, for printing at the end of every report."""
        return [(key, style) for key, style in config.HIGHLIGHT_STYLES.items()]
