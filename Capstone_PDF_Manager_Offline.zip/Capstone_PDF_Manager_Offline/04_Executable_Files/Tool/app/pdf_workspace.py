"""
pdf_workspace.py
================
The unified PDF workspace.

One screen, three columns:

    +-------------------------------------------------------------+
    |  MERGE  SPLIT  ROTATE  CROP  COMPRESS  STAMP  RETYPE  DELETE |
    +-------------------------+-----------------------------------+
    |  PAGE GRID              |  SETTINGS for the chosen tool      |
    |  drag to reshuffle      |-----------------------------------|
    |  numbers update live    |  LIVE PREVIEW                     |
    |                         |  [ Original ]  [ Current ]        |
    +-------------------------+-----------------------------------+
    |  Save Changes    Download Output    Flush memory            |
    +-------------------------------------------------------------+

How it works underneath
-----------------------
Nothing is written to disk while you work.  The workspace keeps a simple
list of PageRef objects -- "page 4 of Bidder_A, rotated 90" -- and the grid
is just a picture of that list.  Dragging a thumbnail moves an item in the
list, and the numbers are recalculated.

Only when you press Save Changes or Download Output is a real PDF built.

Memory
------
Thumbnails are drawn lazily: only the ones you can actually see, unless you
press "Render all".  A 500-page file therefore opens instantly.  Everything
is released the moment you clear the files or close the tool.
"""

from __future__ import annotations

from collections import OrderedDict, deque
from dataclasses import dataclass, field
from pathlib import Path

try:
    import pymupdf as fitz
except ImportError:                                   # pragma: no cover
    import fitz

from PyQt6.QtCore import QMutex, QSize, Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QIcon, QImage, QPixmap
from PyQt6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDoubleSpinBox,
    QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QScrollArea,
    QSpinBox, QSplitter, QStackedWidget, QVBoxLayout, QWidget,
)

from PyQt6.QtWidgets import QSizePolicy

from . import common, config
from .theme import PasswordEdit


def sized(widget, height: int = 32):
    """
    Give an input a floor height and let it fill its column.

    Without this, Qt happily shrinks a QLineEdit to a few pixels when the
    panel is tight -- which is what made the Find/Replace boxes look like
    thin stripes behind their own labels.
    """
    widget.setMinimumHeight(height)
    widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
    return widget

log = common.get_logger("workspace")

THUMB_WIDTH = 132
THUMB_HEIGHT = 178
PREVIEW_WIDTH = 620
CACHE_LIMIT = 400            # thumbnails kept in memory at once


# ===========================================================================
#  1.  THE WORKING MODEL
# ===========================================================================
@dataclass
class PageRef:
    """One page in the working order. Purely a description, not an image."""
    source: Path
    index: int                       # 0-based page number inside the source
    rotation: int = 0                # extra rotation applied here, degrees
    crop_mm: tuple = (0.0, 0.0, 0.0, 0.0)     # top, bottom, left, right
    edits: list = field(default_factory=list)  # (find, replace) pairs

    @property
    def label(self) -> str:
        return f"{self.source.stem[:18]}  p{self.index + 1}"

    @property
    def cache_key(self) -> str:
        return f"{self.source}|{self.index}|{self.rotation}|{self.crop_mm}"

    @property
    def is_modified(self) -> bool:
        return bool(self.rotation or any(self.crop_mm) or self.edits)


class DocumentPool:
    """
    Keeps each source PDF open once, instead of re-opening it per page.

    close_all() is the memory flush: every handle released, nothing left
    holding a file open.
    """

    def __init__(self) -> None:
        self._docs: dict[str, fitz.Document] = {}
        self._passwords: dict[str, str] = {}
        self._lock = QMutex()

    def set_password(self, path: Path, password: str | None) -> None:
        if password:
            self._passwords[str(path)] = password

    def get(self, path: Path) -> fitz.Document:
        key = str(path)
        self._lock.lock()
        try:
            doc = self._docs.get(key)
            if doc is None or doc.is_closed:
                doc = fitz.open(key)
                if doc.needs_pass:
                    password = self._passwords.get(key, "")
                    if not doc.authenticate(password):
                        doc.close()
                        raise ValueError(f"Password needed: {Path(key).name}")
                self._docs[key] = doc
            return doc
        finally:
            self._lock.unlock()

    def close_all(self) -> int:
        self._lock.lock()
        try:
            count = 0
            for doc in self._docs.values():
                try:
                    if not doc.is_closed:
                        doc.close()
                        count += 1
                except Exception:                     # noqa: BLE001
                    pass
            self._docs.clear()
            self._passwords.clear()
            return count
        finally:
            self._lock.unlock()


# ===========================================================================
#  2.  LAZY THUMBNAIL RENDERING
# ===========================================================================
class ThumbnailWorker(QThread):
    """
    Draws thumbnails away from the window, so scrolling never stutters.

    Requests arrive in a queue.  The newest request is served first, because
    that is whatever you have just scrolled to.
    """
    ready = pyqtSignal(str, QImage)

    def __init__(self, pool: DocumentPool) -> None:
        super().__init__()
        self.pool = pool
        self.queue: deque = deque()
        self._lock = QMutex()
        self._stop = False

    def request(self, key: str, page: PageRef, width: int = THUMB_WIDTH) -> None:
        self._lock.lock()
        self.queue.append((key, page, width))
        self._lock.unlock()

    def clear_queue(self) -> None:
        self._lock.lock()
        self.queue.clear()
        self._lock.unlock()

    def stop(self) -> None:
        self._stop = True
        self.clear_queue()
        self.wait(3000)

    def run(self) -> None:                            # noqa: D102
        while not self._stop:
            self._lock.lock()
            item = self.queue.pop() if self.queue else None   # newest first
            self._lock.unlock()

            if item is None:
                self.msleep(35)
                continue

            key, page, width = item
            try:
                image = render_page_image(self.pool, page, width)
                if image is not None:
                    self.ready.emit(key, image)
            except Exception as exc:                  # noqa: BLE001
                log.debug("Thumbnail failed for %s: %s", key, exc)


def render_page_image(pool: DocumentPool, page: PageRef,
                      width: int) -> QImage | None:
    """Draw one page to a picture, honouring rotation and crop."""
    doc = pool.get(page.source)
    if page.index >= doc.page_count:
        return None
    source_page = doc[page.index]

    # Crop is applied as a temporary view; the source file is never altered.
    if any(page.crop_mm):
        mm = 72.0 / 25.4
        top, bottom, left, right = page.crop_mm
        box = source_page.rect
        try:
            source_page.set_cropbox(fitz.Rect(
                box.x0 + left * mm, box.y0 + top * mm,
                box.x1 - right * mm, box.y1 - bottom * mm))
        except Exception:                             # noqa: BLE001
            pass

    scale = width / max(source_page.rect.width, 1)
    matrix = fitz.Matrix(scale, scale)
    if page.rotation:
        matrix = matrix * fitz.Matrix(page.rotation)

    pixmap = source_page.get_pixmap(matrix=matrix, alpha=False)
    image = QImage(pixmap.samples, pixmap.width, pixmap.height,
                   pixmap.stride, QImage.Format.Format_RGB888)
    return image.copy()          # copy: the pixmap buffer dies with this call


class ThumbnailCache:
    """A small memory of recently drawn thumbnails. Oldest are dropped."""

    def __init__(self, limit: int = CACHE_LIMIT) -> None:
        self._items: OrderedDict[str, QPixmap] = OrderedDict()
        self.limit = limit

    def get(self, key: str) -> QPixmap | None:
        pixmap = self._items.get(key)
        if pixmap is not None:
            self._items.move_to_end(key)
        return pixmap

    def put(self, key: str, pixmap: QPixmap) -> None:
        self._items[key] = pixmap
        self._items.move_to_end(key)
        while len(self._items) > self.limit:
            self._items.popitem(last=False)

    def clear(self) -> int:
        count = len(self._items)
        self._items.clear()
        return count


# ===========================================================================
#  3.  THE PAGE GRID
# ===========================================================================
class PageGrid(QListWidget):
    """
    The reshuffling area.

    Drag a thumbnail and drop it somewhere else; the page numbers underneath
    every thumbnail update immediately, so what you see is the final order.
    """
    order_changed = pyqtSignal()
    visible_changed = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("Pages")
        self.setViewMode(QListWidget.ViewMode.IconMode)
        self.setIconSize(QSize(THUMB_WIDTH, THUMB_HEIGHT))
        self.setGridSize(QSize(THUMB_WIDTH + 26, THUMB_HEIGHT + 46))
        self.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.setMovement(QListWidget.Movement.Static)
        self.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setSpacing(4)
        self.setWordWrap(True)
        self.setUniformItemSizes(True)

        self._scroll_timer = QTimer(self)
        self._scroll_timer.setSingleShot(True)
        self._scroll_timer.setInterval(90)
        self._scroll_timer.timeout.connect(self.visible_changed.emit)
        self.verticalScrollBar().valueChanged.connect(self._scroll_timer.start)

    def dropEvent(self, event):                       # noqa: N802
        super().dropEvent(event)
        self.order_changed.emit()

    def visible_rows(self) -> list[int]:
        """Which items are actually on screen right now (plus a little extra)."""
        if self.count() == 0:
            return []
        area = self.viewport().rect()
        first, last = None, None
        for row in range(self.count()):
            rect = self.visualItemRect(self.item(row))
            if rect.bottom() >= area.top() - 200 and rect.top() <= area.bottom() + 200:
                first = row if first is None else first
                last = row
        if first is None:
            return []
        return list(range(first, last + 1))


# ===========================================================================
#  4.  LIVE PREVIEW PANEL
# ===========================================================================
class PreviewPanel(QFrame):
    """
    Shows one page, large.

    Two buttons let you flip between the page as it was in the source file,
    and the page as it is now with your changes applied -- so you can check a
    rotation or a crop without leaving the window.
    """

    def __init__(self, pool: DocumentPool) -> None:
        super().__init__()
        self.setObjectName("Card")
        self.pool = pool
        self.page: PageRef | None = None
        self.mode = "current"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 10)

        header = QHBoxLayout()
        self.caption = QLabel("Live preview")
        self.caption.setObjectName("Section")
        header.addWidget(self.caption)
        header.addStretch(1)

        self.btn_original = QPushButton("Original Preview")
        self.btn_current = QPushButton("Current Preview")
        self.btn_original.setCheckable(True)
        self.btn_current.setCheckable(True)
        self.btn_current.setChecked(True)
        group = QButtonGroup(self)
        group.setExclusive(True)
        group.addButton(self.btn_original)
        group.addButton(self.btn_current)
        header.addWidget(self.btn_original)
        header.addWidget(self.btn_current)
        layout.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setMinimumHeight(200)
        self.image_label = QLabel("Select a page to preview it here")
        self.image_label.setObjectName("Hint")
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setMinimumHeight(240)
        self.scroll.setWidget(self.image_label)
        layout.addWidget(self.scroll, 1)

        self.info = QLabel("")
        self.info.setObjectName("Hint")
        layout.addWidget(self.info)

        self.btn_original.clicked.connect(lambda: self.set_mode("original"))
        self.btn_current.clicked.connect(lambda: self.set_mode("current"))

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.refresh()

    def show_page(self, page: PageRef | None) -> None:
        self.page = page
        self.refresh()

    def refresh(self) -> None:
        if self.page is None:
            self.image_label.setText("Select a page to preview it here")
            self.image_label.setPixmap(QPixmap())
            self.info.setText("")
            return

        # "Original" means: exactly as it sits in the source file.
        target = (self.page if self.mode == "current"
                  else PageRef(self.page.source, self.page.index))
        try:
            image = render_page_image(self.pool, target, PREVIEW_WIDTH)
            if image is None:
                raise ValueError("page not found")
            self.image_label.setPixmap(QPixmap.fromImage(image))
            self.image_label.setText("")
        except Exception as exc:                      # noqa: BLE001
            self.image_label.setPixmap(QPixmap())
            self.image_label.setText(f"Cannot preview: {exc}")

        changes = []
        if self.page.rotation:
            changes.append(f"rotated {self.page.rotation}°")
        if any(self.page.crop_mm):
            changes.append("cropped")
        if self.page.edits:
            changes.append(f"{len(self.page.edits)} text edit(s)")
        self.info.setText(
            f"{self.page.source.name}  ·  source page {self.page.index + 1}  ·  "
            f"{'showing ORIGINAL' if self.mode == 'original' else 'showing CURRENT'}"
            + (f"  ·  {', '.join(changes)}" if changes else "  ·  unchanged"))

    def clear(self) -> None:
        self.page = None
        self.image_label.setPixmap(QPixmap())
        self.image_label.setText("Select a page to preview it here")
        self.info.setText("")


# ===========================================================================
#  5.  THE TOOL SETTINGS PANELS
# ===========================================================================
class ToolPanels(QStackedWidget):
    """
    One settings panel per tool.

    Why each panel sits inside its own scroll area
    ----------------------------------------------
    A QStackedWidget gives every page the same height. Previously the tallest
    panel (Crop, with four spin boxes) was squashed into the height of the
    shortest, so titles were sliced in half and labels overlapped their
    fields. Wrapping each panel in a scroll area means a panel is always drawn
    at its natural size; if the window is short, that panel scrolls instead of
    being crushed.
    """

    MIN_HEIGHT = 250

    def __init__(self) -> None:
        super().__init__()
        self.widgets: dict[str, dict] = {}
        self.setMinimumHeight(self.MIN_HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)

        for name in ("merge", "split", "rotate", "crop",
                     "compress", "stamp", "retype", "delete"):
            panel = getattr(self, f"_build_{name}")()
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setHorizontalScrollBarPolicy(
                Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            scroll.setWidget(panel)
            self.addWidget(scroll)

    def _panel(self) -> tuple[QWidget, QGridLayout]:
        widget = QFrame()
        widget.setObjectName("Card")
        grid = QGridLayout(widget)
        grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        grid.setContentsMargins(14, 14, 14, 14)
        grid.setVerticalSpacing(10)          # rows can no longer collide
        grid.setHorizontalSpacing(12)
        grid.setColumnMinimumWidth(0, 118)   # the label column has a floor
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)
        return widget, grid

    def _title(self, grid, text: str, hint: str) -> None:
        """
        The heading and its explanation.

        Both are given a minimum height, because a label with no floor is the
        first thing Qt shrinks when space runs short -- which is exactly how
        'Crop' ended up rendered as a few stray dashes.
        """
        label = QLabel(text)
        label.setObjectName("Section")
        label.setMinimumHeight(26)
        label.setSizePolicy(QSizePolicy.Policy.Expanding,
                            QSizePolicy.Policy.Minimum)
        grid.addWidget(label, 0, 0, 1, 2)

        note = QLabel(hint)
        note.setObjectName("Hint")
        note.setWordWrap(True)
        note.setMinimumHeight(38)
        note.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Minimum)
        note.setAlignment(Qt.AlignmentFlag.AlignTop)
        grid.addWidget(note, 1, 0, 1, 2)

    # -- the eight panels --------------------------------------------------
    def _build_merge(self):
        widget, grid = self._panel()
        self._title(grid, "Merge",
                    "Every page in the grid, in the order shown, becomes one "
                    "PDF. Drag thumbnails to change the order. Each page gets "
                    "source | new number | stamp, and bookmarks per file.")
        name = QLineEdit("Merged")
        stamp = QLineEdit(config.STAMP_TEXT)
        bookmarks = QCheckBox("Build a bookmark tree")
        bookmarks.setChecked(True)
        footer = QCheckBox("Add the footer line")
        footer.setChecked(True)
        for box in (footer, bookmarks):
            box.setMinimumHeight(26)
        grid.addWidget(QLabel("Output name"), 2, 0)
        grid.addWidget(sized(name), 2, 1)
        grid.addWidget(QLabel("Footer stamp"), 3, 0)
        grid.addWidget(sized(stamp), 3, 1)
        grid.addWidget(footer, 4, 0, 1, 2)
        grid.addWidget(bookmarks, 5, 0, 1, 2)
        self.widgets["merge"] = {"name": name, "stamp": stamp,
                                 "footer": footer, "bookmarks": bookmarks}
        return widget

    def _build_split(self):
        widget, grid = self._panel()
        self._title(grid, "Split",
                    "Cut the current order into several files. Ranges use the "
                    "NEW page numbers you see in the grid.")
        ranges = QLineEdit()
        ranges.setPlaceholderText("1-40, 41-80")
        every = QSpinBox()
        every.setRange(0, 5000)
        selected = QCheckBox("Or: just export the pages I have selected")
        selected.setMinimumHeight(26)
        grid.addWidget(QLabel("Ranges"), 2, 0)
        grid.addWidget(sized(ranges), 2, 1)
        grid.addWidget(QLabel("Every N pages"), 3, 0)
        grid.addWidget(sized(every), 3, 1)
        grid.addWidget(selected, 4, 0, 1, 2)
        self.widgets["split"] = {"ranges": ranges, "every": every,
                                 "selected": selected}
        return widget

    def _build_rotate(self):
        widget, grid = self._panel()
        self._title(grid, "Rotate",
                    "Turns the selected thumbnails. You see the result "
                    "immediately in the grid and the preview.")
        degrees = QComboBox()
        degrees.addItems(["90", "180", "270", "360 (reset)"])
        apply_all = QCheckBox("Apply to every page, not just the selected ones")
        apply_all.setMinimumHeight(26)
        grid.addWidget(QLabel("Degrees"), 2, 0)
        grid.addWidget(sized(degrees), 2, 1)
        grid.addWidget(apply_all, 3, 0, 1, 2)
        self.widgets["rotate"] = {"degrees": degrees, "all": apply_all}
        return widget

    def _build_crop(self):
        widget, grid = self._panel()
        self._title(grid, "Crop",
                    "Trims margins from the selected pages, in millimetres. "
                    "Cropping hides the margin; nothing is deleted.")
        boxes = {}
        for row, side in enumerate(("top", "bottom", "left", "right"), start=2):
            spin = QDoubleSpinBox()
            spin.setRange(0, 200)
            spin.setSuffix(" mm")
            grid.addWidget(QLabel(side.title()), row, 0)
            grid.addWidget(sized(spin), row, 1)
            boxes[side] = spin
        apply_all = QCheckBox("Apply to every page")
        apply_all.setMinimumHeight(26)
        grid.addWidget(apply_all, 6, 0, 1, 2)
        self.widgets["crop"] = {"boxes": boxes, "all": apply_all}
        return widget

    def _build_compress(self):
        widget, grid = self._panel()
        self._title(grid, "Compress",
                    "Applied when you save. Try all three first, then decide "
                    "which one still reads clearly.")
        level = QComboBox()
        for key, settings in config.COMPRESSION_LEVELS.items():
            level.addItem(settings["label"], key)
        level.addItem("Compare all three when I save", "all")
        grid.addWidget(QLabel("Strength"), 2, 0)
        grid.addWidget(sized(level), 2, 1)
        self.widgets["compress"] = {"level": level}
        return widget

    def _build_stamp(self):
        widget, grid = self._panel()
        self._title(grid, "Stamp",
                    "The footer line added to every page when you save.")
        text = QLineEdit(config.STAMP_TEXT)
        date = QCheckBox("Include date and time")
        date.setChecked(True)
        numbers = QCheckBox("Add page numbers")
        numbers.setChecked(True)
        for box in (date, numbers):
            box.setMinimumHeight(26)
        grid.addWidget(QLabel("Stamp text"), 2, 0)
        grid.addWidget(sized(text), 2, 1)
        grid.addWidget(date, 3, 0, 1, 2)
        grid.addWidget(numbers, 4, 0, 1, 2)
        self.widgets["stamp"] = {"text": text, "date": date, "numbers": numbers}
        return widget

    def _build_retype(self):
        widget, grid = self._panel()
        self._title(grid, "Retype",
                    "Covers text on the selected page and types new text over "
                    "it. The old text is genuinely removed. Best for short "
                    "corrections, not paragraphs.")
        find = QLineEdit()
        find.setPlaceholderText("Exact text to cover")
        replace = QLineEdit()
        replace.setPlaceholderText("What to type instead")
        grid.addWidget(QLabel("Find"), 2, 0)
        grid.addWidget(sized(find), 2, 1)
        grid.addWidget(QLabel("Replace"), 3, 0)
        grid.addWidget(sized(replace), 3, 1)
        self.widgets["retype"] = {"find": find, "replace": replace}
        return widget

    def _build_delete(self):
        widget, grid = self._panel()
        self._title(grid, "Remove pages",
                    "Takes the selected thumbnails out of the working order. "
                    "Your source files are untouched -- press Reload to bring "
                    "everything back.")
        self.widgets["delete"] = {}
        return widget


# ===========================================================================
#  6.  THE WORKSPACE PAGE ITSELF
# ===========================================================================
TOOLS = [("merge", "Merge"), ("split", "Split"), ("rotate", "Rotate"),
         ("crop", "Crop"), ("compress", "Compress"), ("stamp", "Stamp"),
         ("retype", "Retype"), ("delete", "Remove")]


class PdfWorkspacePage(QWidget):
    """The whole PDF workspace: one tab, all tools, live preview."""

    def __init__(self, window) -> None:
        super().__init__()
        self.window = window
        self.pool = DocumentPool()
        self.cache = ThumbnailCache()
        self.pages: list[PageRef] = []
        self.dirty = False
        self.saved_paths: list[Path] = []
        self._placeholder = self._make_placeholder()

        self.worker = ThumbnailWorker(self.pool)
        self.worker.ready.connect(self.on_thumbnail)
        self.worker.start()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # -- unified action bar --------------------------------------------
        bar = QFrame()
        bar.setObjectName("Card")
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(10, 8, 10, 8)
        self.tool_buttons: dict[str, QPushButton] = {}
        group = QButtonGroup(self)
        group.setExclusive(True)
        for index, (key, label) in enumerate(TOOLS):
            button = QPushButton(label)
            button.setObjectName("Tool")
            button.setCheckable(True)
            button.setChecked(index == 0)
            group.addButton(button)
            bar_layout.addWidget(button)
            self.tool_buttons[key] = button
            button.clicked.connect(lambda _, k=key: self.choose_tool(k))
        bar_layout.addStretch(1)
        self.apply_button = QPushButton("Apply to selection")
        self.apply_button.setObjectName("Primary")
        bar_layout.addWidget(self.apply_button)
        layout.addWidget(bar)

        # -- middle: grid | settings + preview ------------------------------
        splitter = QSplitter(Qt.Orientation.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        head = QHBoxLayout()
        self.grid_title = QLabel("Pages — drag to reshuffle")
        self.grid_title.setObjectName("Section")
        head.addWidget(self.grid_title)
        head.addStretch(1)
        self.render_all_button = QPushButton("Render all now")
        self.reload_button = QPushButton("Reload files")
        head.addWidget(self.render_all_button)
        head.addWidget(self.reload_button)
        left_layout.addLayout(head)

        self.grid = PageGrid()
        self.grid.setMinimumWidth(330)
        self.grid.setMinimumHeight(240)
        left_layout.addWidget(self.grid, 1)
        self.stats = QLabel("No pages loaded")
        self.stats.setObjectName("Stat")
        left_layout.addWidget(self.stats)
        splitter.addWidget(left)

        # The right-hand column is itself a splitter: settings on top,
        # preview below.  You can drag the divider, so a tall Crop panel and a
        # large preview never have to fight for the same pixels.
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(6)

        self.password = PasswordEdit()
        self.password.setMinimumHeight(32)
        right_layout.addWidget(self.password, 0)

        self.right_split = QSplitter(Qt.Orientation.Vertical)
        self.panels = ToolPanels()
        self.preview = PreviewPanel(self.pool)
        self.right_split.addWidget(self.panels)
        self.right_split.addWidget(self.preview)
        self.right_split.setStretchFactor(0, 0)     # settings keep their size
        self.right_split.setStretchFactor(1, 1)     # preview takes the slack
        self.right_split.setSizes([280, 520])
        self.right_split.setChildrenCollapsible(False)
        right_layout.addWidget(self.right_split, 1)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 5)             # page grid
        splitter.setStretchFactor(1, 4)             # settings + preview
        splitter.setChildrenCollapsible(False)
        splitter.setSizes([760, 620])
        self.main_split = splitter
        layout.addWidget(splitter, 1)

        # -- export bar -----------------------------------------------------
        export = QFrame()
        export.setObjectName("Card")
        export_layout = QHBoxLayout(export)
        export_layout.setContentsMargins(10, 8, 10, 8)
        self.dirty_label = QLabel("No unsaved changes")
        self.dirty_label.setObjectName("Hint")
        export_layout.addWidget(self.dirty_label)
        export_layout.addStretch(1)
        self.flush_button = QPushButton("Flush memory")
        self.save_button = QPushButton("Save Changes")
        self.download_button = QPushButton("Download Output")
        self.save_button.setObjectName("Primary")
        self.download_button.setObjectName("Primary")
        for button in (self.flush_button, self.save_button, self.download_button):
            export_layout.addWidget(button)
        layout.addWidget(export)

        # -- wiring ---------------------------------------------------------
        self.grid.order_changed.connect(self.on_reordered)
        self.grid.visible_changed.connect(self.request_visible)
        self.grid.currentRowChanged.connect(self.on_selected)
        self.apply_button.clicked.connect(self.apply_tool)
        self.render_all_button.clicked.connect(self.render_all)
        self.reload_button.clicked.connect(self.reload)
        self.flush_button.clicked.connect(lambda: self.flush(ask=True))
        self.save_button.clicked.connect(lambda: self.export(download=False))
        self.download_button.clicked.connect(lambda: self.export(download=True))
        self.password.editingFinished.connect(self.reload)

        self._sized_once = False
        self.choose_tool("merge")

    # ------------------------------------------------------------ proportions
    def showEvent(self, event):                       # noqa: N802 - Qt naming
        """
        Set the splitter proportions once the window has a real width.

        Setting them in __init__ does not work: at that moment the widget has
        no size, so Qt quietly rescales whatever numbers you give it.  Doing
        it on first show means the panels get the share we actually intended,
        on any monitor.
        """
        super().showEvent(event)
        if not self._sized_once:
            self._sized_once = True
            QTimer.singleShot(0, self.apply_default_proportions)

    def apply_default_proportions(self) -> None:
        width = max(self.main_split.width(), 900)
        self.main_split.setSizes([int(width * 0.54), int(width * 0.46)])
        height = max(self.right_split.height(), 520)
        self.right_split.setSizes([int(height * 0.42), int(height * 0.58)])

    # ---------------------------------------------------------------- setup
    def _make_placeholder(self) -> QIcon:
        """A plain grey tile shown until the real thumbnail is drawn."""
        pixmap = QPixmap(THUMB_WIDTH, THUMB_HEIGHT)
        pixmap.fill(Qt.GlobalColor.darkGray)
        return QIcon(pixmap)

    def choose_tool(self, key: str) -> None:
        index = [k for k, _ in TOOLS].index(key)
        self.panels.setCurrentIndex(index)
        self.current_tool = key
        self.tool_buttons[key].setChecked(True)
        verbs = {"merge": "Build merged PDF", "split": "Split now",
                 "rotate": "Rotate selected", "crop": "Crop selected",
                 "compress": "Set compression", "stamp": "Set stamp",
                 "retype": "Retype on selected page", "delete": "Remove selected"}
        self.apply_button.setText(verbs.get(key, "Apply"))

    # ------------------------------------------------------------- loading
    def load(self, paths: list[Path]) -> None:
        """
        Build the working order from the files in the top strip.

        Only PDFs are taken; anything else is ignored here and handled by the
        other tabs.
        """
        self.flush(ask=False, keep_files=True)
        pdfs: list[Path] = []
        for path in paths:
            if path.is_file() and path.suffix.lower() == ".pdf":
                pdfs.append(path)
            elif path.is_dir():
                pdfs.extend(sorted(path.rglob("*.pdf")))

        password = self.password.text() or None
        problems: list[str] = []
        for path in pdfs:
            self.pool.set_password(path, password)
            try:
                doc = self.pool.get(path)
                for index in range(doc.page_count):
                    self.pages.append(PageRef(path, index))
            except Exception as exc:                  # noqa: BLE001
                problems.append(f"{path.name}: {exc}")

        self.rebuild_grid()
        if problems:
            self.window.status.setText("Could not open: " + "; ".join(problems[:3]))

    def reload(self) -> None:
        self.load(list(self.window.strip.paths))

    def rebuild_grid(self) -> None:
        self.grid.clear()
        for position, page in enumerate(self.pages, start=1):
            item = QListWidgetItem(f"{position}\n{page.label}")
            cached = self.cache.get(page.cache_key)
            item.setIcon(cached and QIcon(cached) or self._placeholder)
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.grid.addItem(item)
        self.update_stats()
        QTimer.singleShot(60, self.request_visible)

    def renumber(self) -> None:
        """After a drag, the numbers under the thumbnails must be redone."""
        for position in range(self.grid.count()):
            item = self.grid.item(position)
            page = self.pages[position]
            item.setText(f"{position + 1}\n{page.label}")

    def update_stats(self) -> None:
        sources = len({p.source for p in self.pages})
        modified = sum(1 for p in self.pages if p.is_modified)
        self.stats.setText(
            f"{len(self.pages)} page(s) from {sources} file(s)"
            + (f"  ·  {modified} page(s) changed" if modified else ""))

    # ------------------------------------------------------------ rendering
    def request_visible(self) -> None:
        """Ask the worker only for thumbnails that are on screen."""
        for row in self.grid.visible_rows():
            if row >= len(self.pages):
                continue
            page = self.pages[row]
            key = page.cache_key
            cached = self.cache.get(key)
            if cached is not None:
                self.grid.item(row).setIcon(QIcon(cached))
            else:
                self.worker.request(key, page)

    def render_all(self) -> None:
        """You asked for this button: draw every thumbnail, on demand."""
        if not self.pages:
            return
        self.window.status.setText(
            f"Rendering all {len(self.pages)} thumbnails in the background...")
        for page in self.pages:
            if self.cache.get(page.cache_key) is None:
                self.worker.request(page.cache_key, page)

    def on_thumbnail(self, key: str, image: QImage) -> None:
        pixmap = QPixmap.fromImage(image)
        self.cache.put(key, pixmap)
        icon = QIcon(pixmap)
        for row, page in enumerate(self.pages):
            if page.cache_key == key and row < self.grid.count():
                self.grid.item(row).setIcon(icon)

    # ------------------------------------------------------------- editing
    def on_reordered(self) -> None:
        """
        The grid moved an item; move the same item in our list.

        We work out the new order by matching the text label, which carries
        the source and original page number.
        """
        labels = [self.grid.item(row).text().split("\n", 1)[-1]
                  for row in range(self.grid.count())]
        pool = list(self.pages)
        reordered: list[PageRef] = []
        for label in labels:
            for candidate in pool:
                if candidate.label == label:
                    reordered.append(candidate)
                    pool.remove(candidate)
                    break
        if len(reordered) == len(self.pages):
            self.pages = reordered
        self.renumber()
        self.mark_dirty("pages reordered")
        self.update_stats()

    def on_selected(self, row: int) -> None:
        if 0 <= row < len(self.pages):
            self.preview.show_page(self.pages[row])

    def selected_pages(self) -> list[PageRef]:
        rows = sorted(index.row() for index in self.grid.selectedIndexes())
        return [self.pages[row] for row in rows if row < len(self.pages)]

    def mark_dirty(self, reason: str = "") -> None:
        self.dirty = True
        self.dirty_label.setText(
            f"Unsaved changes{': ' + reason if reason else ''}")

    def mark_clean(self) -> None:
        self.dirty = False
        self.dirty_label.setText("No unsaved changes")

    def refresh_after_edit(self, changed: list[PageRef]) -> None:
        for page in changed:
            self.cache.get(page.cache_key)          # touch, may be absent
        self.rebuild_grid()
        self.preview.refresh()
        self.update_stats()

    def apply_tool(self) -> None:
        """The single Apply button acts on whichever tool is chosen."""
        tool = self.current_tool
        if not self.pages:
            self.window.warn("Please choose some PDF files first.")
            return

        if tool in ("merge", "split"):
            self.export(download=False, split=(tool == "split"))
            return

        settings = self.panels.widgets.get(tool, {})
        selected = self.selected_pages()

        if tool == "rotate":
            targets = self.pages if settings["all"].isChecked() else selected
            if not targets:
                self.window.warn("Select some thumbnails first, or tick "
                                 "'Apply to every page'.")
                return
            text = settings["degrees"].currentText()
            degrees = 0 if text.startswith("360") else int(text)
            for page in targets:
                page.rotation = (page.rotation + degrees) % 360 if degrees else 0
            self.refresh_after_edit(targets)
            self.mark_dirty(f"{len(targets)} page(s) rotated")

        elif tool == "crop":
            targets = self.pages if settings["all"].isChecked() else selected
            if not targets:
                self.window.warn("Select some thumbnails first.")
                return
            boxes = settings["boxes"]
            values = (boxes["top"].value(), boxes["bottom"].value(),
                      boxes["left"].value(), boxes["right"].value())
            for page in targets:
                page.crop_mm = values
            self.refresh_after_edit(targets)
            self.mark_dirty(f"{len(targets)} page(s) cropped")

        elif tool == "delete":
            if not selected:
                self.window.warn("Select the thumbnails you want removed.")
                return
            keep = [p for p in self.pages if p not in selected]
            self.pages = keep
            self.rebuild_grid()
            self.preview.clear()
            self.mark_dirty(f"{len(selected)} page(s) removed")

        elif tool == "retype":
            if len(selected) != 1:
                self.window.warn("Select exactly one thumbnail to retype.")
                return
            find = settings["find"].text().strip()
            if not find:
                self.window.warn("Type the text you want to cover.")
                return
            selected[0].edits.append((find, settings["replace"].text()))
            self.update_stats()
            self.mark_dirty("text edit queued (applied when you save)")

        elif tool in ("compress", "stamp"):
            self.mark_dirty(f"{tool} setting changed")
            self.window.status.setText(
                f"{tool.title()} setting will be applied when you save.")

    # -------------------------------------------------------------- export
    def build_document(self, pages: list[PageRef]) -> "fitz.Document":
        """
        Turn the working list into a real PDF, in memory.

        Order of work matters: pages first, then rotation and crop, then the
        text edits, and the footer last so it is never covered or rotated.
        """
        stamp_settings = self.panels.widgets["stamp"]
        merge_settings = self.panels.widgets["merge"]
        from .pdf_ops import build_stamp_text, stamp_footer

        output = fitz.open()
        toc: list[list] = []
        last_source: Path | None = None
        mm = 72.0 / 25.4

        for position, page in enumerate(pages, start=1):
            source = self.pool.get(page.source)
            output.insert_pdf(source, from_page=page.index, to_page=page.index)
            new_page = output[position - 1]

            if page.rotation:
                new_page.set_rotation((new_page.rotation + page.rotation) % 360)

            if any(page.crop_mm):
                top, bottom, left, right = page.crop_mm
                box = new_page.rect
                candidate = fitz.Rect(box.x0 + left * mm, box.y0 + top * mm,
                                      box.x1 - right * mm, box.y1 - bottom * mm)
                if candidate.width > 10 and candidate.height > 10:
                    new_page.set_cropbox(candidate)

            for find, replace in page.edits:
                boxes = new_page.search_for(find)
                for box in boxes:
                    new_page.add_redact_annot(box, fill=(1, 1, 1))
                if boxes:
                    new_page.apply_redactions()
                    if replace:
                        new_page.insert_textbox(boxes[0], replace,
                                                fontname="helv", fontsize=9,
                                                color=(0, 0, 0))

            if merge_settings["bookmarks"].isChecked() and page.source != last_source:
                toc.append([1, page.source.stem, position])
                last_source = page.source

        if merge_settings["footer"].isChecked():
            right_zone = build_stamp_text(
                stamp_settings["text"].text(),
                stamp_settings["date"].isChecked())
            for position, page in enumerate(pages, start=1):
                stamp_footer(
                    output[position - 1],
                    left=f"{page.source.stem[:22]} - p{page.index + 1}",
                    centre=str(position) if stamp_settings["numbers"].isChecked() else "",
                    right=right_zone)

        if toc:
            output.set_toc(toc)
        return output

    def export(self, download: bool = False, split: bool = False,
               folder: Path | None = None, silent: bool = False) -> list[Path]:
        """
        Save Changes  -> writes into a dated folder under Output\\
        Download Output -> asks you where to put it

        Either way the source files are untouched.
        """
        if not self.pages:
            if not silent:
                self.window.warn("There are no pages to save.")
            return []

        job_folder = folder or common.new_job_folder("pdf_workspace")
        produced: list[Path] = []

        try:
            if split:
                produced = self._export_split(job_folder)
            else:
                produced = self._export_single(job_folder, download)
        except Exception as exc:                      # noqa: BLE001
            log.error("Export failed: %s", exc)
            if not silent:
                self.window.warn(f"Could not save: {exc}")
            return []

        self.saved_paths.extend(produced)
        self.mark_clean()
        if not silent:
            self.window.finish(
                f"{len(produced)} file(s) written", job_folder)
        return produced

    def _apply_compression(self, path: Path, folder: Path) -> list[Path]:
        from .pdf_ops import compare_compression, compress_pdf
        level = self.panels.widgets["compress"]["level"].currentData()
        if level == "all":
            return [r.output for r in compare_compression(path, folder)]
        if level and level != "light":
            return [compress_pdf(path, folder, level).output]
        return []

    def _export_single(self, folder: Path, download: bool) -> list[Path]:
        from .pdf_ops import _safe_output_path, _save

        name = self.panels.widgets["merge"]["name"].text() or "Merged"
        document = self.build_document(self.pages)

        if download:
            suggested = str(Path.home() / "Documents" / f"{name}.pdf")
            chosen, _ = QFileDialog.getSaveFileName(
                self, "Download Output", suggested, "PDF (*.pdf)")
            if not chosen:
                document.close()
                return []
            target = Path(chosen)
            _save(document, target)
            document.close()
            return [target]

        target = _safe_output_path(folder, name)
        _save(document, target)
        document.close()
        return [target] + self._apply_compression(target, folder)

    def _export_split(self, folder: Path) -> list[Path]:
        from .pdf_ops import _safe_output_path, _save, parse_ranges

        settings = self.panels.widgets["split"]
        total = len(self.pages)

        if settings["selected"].isChecked():
            rows = sorted(index.row() for index in self.grid.selectedIndexes())
            spans = [(row + 1, row + 1) for row in rows]
        elif settings["ranges"].text().strip():
            spans = parse_ranges(settings["ranges"].text(), total)
        elif settings["every"].value():
            step = settings["every"].value()
            spans = [(start, min(start + step - 1, total))
                     for start in range(1, total + 1, step)]
        else:
            raise ValueError("Give a range, or a number of pages per file, "
                             "or tick 'just the pages I have selected'.")

        produced: list[Path] = []
        for number, (start, end) in enumerate(spans, start=1):
            chunk = self.pages[start - 1:end]
            if not chunk:
                continue
            document = self.build_document(chunk)
            target = _safe_output_path(folder, f"Part{number:02d}_p{start}-{end}")
            _save(document, target)
            document.close()
            produced.append(target)
        return produced

    # --------------------------------------------------------------- memory
    def flush(self, ask: bool = True, keep_files: bool = False) -> None:
        """
        Release everything held for the current files.

        This is the memory flush you asked for: thumbnails dropped, PDF
        handles closed, page list emptied.  Called when you clear the file
        strip, load different files, or close the tool.
        """
        if ask and self.dirty:
            answer = QMessageBox.question(
                self, "Unsaved changes",
                "You have unsaved changes. Flush memory and lose them?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return

        self.worker.clear_queue()
        thumbnails = self.cache.clear()
        documents = self.pool.close_all()
        self.pages.clear()
        self.grid.clear()
        self.preview.clear()
        self.mark_clean()
        self.update_stats()
        if not keep_files:
            self.password.wipe()
        log.info("Memory flushed: %d thumbnail(s), %d document handle(s)",
                 thumbnails, documents)
        self.window.status.setText(
            f"Memory flushed — {thumbnails} thumbnail(s) and "
            f"{documents} file handle(s) released")

    def shutdown(self) -> None:
        """Called when the application closes."""
        self.worker.stop()
        self.cache.clear()
        self.pool.close_all()

    def retranslate(self) -> None:
        self.grid_title.setText("Pages — drag to reshuffle")
