"""
ocr_engine.py
=============
STEP 4a - teaching the toolkit to READ a picture of text.

Three engines are supported.  You install whichever you like; the toolkit
uses whatever it finds:

    RapidOCR    fast, English strong, models bundled  (~2 sec/page)
    Tesseract   balanced, English + Hindi             (~3 sec/page)
    EasyOCR     slowest, best on messy Hindi scans    (~8 sec/page)

Two important design choices you made:

    1. "OCR everything" -- even pages that already contain text.
       Both versions are kept, so nothing is ever lost.  A --smart switch
       is available when you are in a hurry.

    2. "Searchable PDF AND index".  We write an invisible text layer over
       the scan, so the page LOOKS identical but the words can be selected,
       copied and searched in any PDF reader.
"""

from __future__ import annotations

import io
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

try:
    import pymupdf as fitz
except ImportError:                                   # pragma: no cover
    import fitz

from . import common, config

log = common.get_logger("ocr")


# ===========================================================================
#  1.  WHAT AN ENGINE GIVES BACK
# ===========================================================================
@dataclass
class OCRWord:
    """One piece of text the engine found, and where it sits on the page."""
    text: str
    x0: float
    y0: float
    x1: float
    y1: float
    confidence: float = 0.0        # 0.0 to 1.0; how sure the engine is

    @property
    def rect(self) -> "fitz.Rect":
        return fitz.Rect(self.x0, self.y0, self.x1, self.y1)


@dataclass
class PageText:
    """Everything we know about one page after reading it."""
    page_no: int                       # human numbering, first page = 1
    native_text: str = ""              # text that was already in the PDF
    ocr_text: str = ""                 # text the OCR engine saw
    words: list[OCRWord] = field(default_factory=list)
    engine: str = "none"
    seconds: float = 0.0

    @property
    def best_text(self) -> str:
        """
        The text to search.

        We keep both, and search both, because either can be better:
        a native layer may be broken, and OCR may misread a stamp.
        """
        if self.native_text and self.ocr_text:
            return f"{self.native_text}\n{self.ocr_text}"
        return self.native_text or self.ocr_text

    @property
    def has_good_native_text(self) -> bool:
        return len(self.native_text.strip()) >= config.MIN_CHARS_FOR_TEXT_LAYER

    @property
    def average_confidence(self) -> float:
        if not self.words:
            return 0.0
        return sum(w.confidence for w in self.words) / len(self.words)


# ===========================================================================
#  2.  THE THREE ENGINES
# ===========================================================================
class BaseOCR:
    """Common shape for every engine."""
    name = "base"

    def available(self) -> bool:
        raise NotImplementedError

    def read(self, image_bytes: bytes, scale: float) -> list[OCRWord]:
        """`scale` converts image pixels back into PDF points."""
        raise NotImplementedError


class RapidOCRBackend(BaseOCR):
    """Fast, no PyTorch, models bundled inside the package."""
    name = "rapidocr"

    def __init__(self) -> None:
        self._engine = None

    def available(self) -> bool:
        try:
            import rapidocr_onnxruntime      # noqa: F401
            return True
        except ImportError:
            return False

    def _load(self):
        if self._engine is None:
            from rapidocr_onnxruntime import RapidOCR
            self._engine = RapidOCR()
            log.info("RapidOCR loaded")
        return self._engine

    def read(self, image_bytes: bytes, scale: float) -> list[OCRWord]:
        import numpy as np
        from PIL import Image

        engine = self._load()
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        result, _ = engine(np.array(image))
        words: list[OCRWord] = []
        for item in (result or []):
            box, text, score = item[0], item[1], item[2]
            xs = [point[0] for point in box]
            ys = [point[1] for point in box]
            words.append(OCRWord(
                text=str(text),
                x0=min(xs) * scale, y0=min(ys) * scale,
                x1=max(xs) * scale, y1=max(ys) * scale,
                confidence=float(score),
            ))
        return words


class TesseractBackend(BaseOCR):
    """Balanced. Needs the Tesseract program in models\\tesseract."""
    name = "tesseract"

    def available(self) -> bool:
        try:
            import pytesseract              # noqa: F401
        except ImportError:
            return False
        return config.TESSERACT_EXE.exists()

    def read(self, image_bytes: bytes, scale: float) -> list[OCRWord]:
        import os
        import pytesseract
        from PIL import Image

        pytesseract.pytesseract.tesseract_cmd = str(config.TESSERACT_EXE)
        os.environ["TESSDATA_PREFIX"] = str(config.TESSDATA_DIR)

        image = Image.open(io.BytesIO(image_bytes))
        data = pytesseract.image_to_data(
            image, lang="eng+hin",
            output_type=pytesseract.Output.DICT,
        )

        words: list[OCRWord] = []
        for index, text in enumerate(data["text"]):
            text = (text or "").strip()
            if not text:
                continue
            try:
                confidence = float(data["conf"][index]) / 100.0
            except (ValueError, TypeError):
                confidence = 0.0
            if confidence < 0:
                continue
            left, top = data["left"][index], data["top"][index]
            width, height = data["width"][index], data["height"][index]
            words.append(OCRWord(
                text=text,
                x0=left * scale, y0=top * scale,
                x1=(left + width) * scale, y1=(top + height) * scale,
                confidence=confidence,
            ))
        return words


class EasyOCRBackend(BaseOCR):
    """Slowest, but the best on messy Hindi scans."""
    name = "easyocr"

    def __init__(self) -> None:
        self._reader = None

    def available(self) -> bool:
        try:
            import easyocr                  # noqa: F401
            return True
        except ImportError:
            return False

    def _load(self):
        if self._reader is None:
            import easyocr
            self._reader = easyocr.Reader(
                config.OCR_LANGUAGES, gpu=False,
                model_storage_directory=str(config.EASYOCR_MODEL_DIR),
                download_enabled=False,     # offline: models must already be here
                verbose=False,
            )
            log.info("EasyOCR loaded (offline)")
        return self._reader

    def read(self, image_bytes: bytes, scale: float) -> list[OCRWord]:
        import numpy as np
        from PIL import Image

        reader = self._load()
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        results = reader.readtext(np.array(image))

        words: list[OCRWord] = []
        for box, text, score in results:
            xs = [point[0] for point in box]
            ys = [point[1] for point in box]
            words.append(OCRWord(
                text=str(text),
                x0=min(xs) * scale, y0=min(ys) * scale,
                x1=max(xs) * scale, y1=max(ys) * scale,
                confidence=float(score),
            ))
        return words


BACKENDS: dict[str, type[BaseOCR]] = {
    "rapidocr": RapidOCRBackend,
    "tesseract": TesseractBackend,
    "easyocr": EasyOCRBackend,
}


def available_engines() -> list[str]:
    """Which engines are actually installed and usable right now."""
    return [name for name, klass in BACKENDS.items() if klass().available()]


# ===========================================================================
#  3.  THE MANAGER
# ===========================================================================
class OCRManager:
    """
    Chooses an engine and keeps it loaded.

    Loading an engine takes a few seconds, so we do it once and reuse it for
    every page of every file in the batch.
    """

    def __init__(self, engine: str | None = None) -> None:
        self.requested = engine or config.DEFAULT_OCR_ENGINE
        self.backend: BaseOCR | None = None
        self.engine_name = "none"

        if self.requested == "none":
            return

        order = [self.requested] + [e for e in ("rapidocr", "tesseract", "easyocr")
                                    if e != self.requested]
        for name in order:
            candidate = BACKENDS[name]()
            if candidate.available():
                self.backend = candidate
                self.engine_name = name
                if name != self.requested:
                    log.warning("'%s' not installed - using '%s' instead",
                                self.requested, name)
                break

        if self.backend is None:
            log.warning("No OCR engine installed. Scanned pages will be skipped.")

    @property
    def ready(self) -> bool:
        return self.backend is not None

    def read_page(self, page: "fitz.Page", dpi: int = config.OCR_RENDER_DPI
                  ) -> list[OCRWord]:
        """Take a picture of the page, then ask the engine to read it."""
        if not self.ready:
            return []
        zoom = dpi / 72.0                       # 72 points = 1 inch
        pixmap = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
        image_bytes = pixmap.tobytes("png")
        return self.backend.read(image_bytes, scale=1.0 / zoom)


# ===========================================================================
#  4.  READING A WHOLE PDF
# ===========================================================================
def estimate_time(page_count: int, engine: str) -> str:
    """A rough but honest forecast, so nobody starts a 40-hour job by mistake."""
    per_page = {"rapidocr": 2.0, "tesseract": 3.0, "easyocr": 8.0}.get(engine, 0.0)
    if not per_page:
        return "instant (no OCR)"
    return common.human_duration(page_count * per_page)


def read_pdf(path: str | Path,
             manager: OCRManager,
             password: str | None = None,
             smart: bool = False,
             dpi: int = config.OCR_RENDER_DPI,
             cancel: common.CancelToken | None = None,
             progress_callback=None) -> list[PageText]:
    """
    Read every page of one PDF.

    smart=False (your default): OCR every page, keep native text too.
    smart=True              : skip OCR where the page already has good text.
    """
    from .pdf_ops import open_pdf

    cancel = cancel or common.CancelToken()
    doc = open_pdf(path, password)
    pages: list[PageText] = []

    try:
        for index in range(doc.page_count):
            cancel.raise_if_cancelled()
            page = doc[index]
            result = PageText(page_no=index + 1,
                              native_text=page.get_text().strip())

            skip = smart and result.has_good_native_text
            if manager.ready and not skip:
                started = time.time()
                result.words = manager.read_page(page, dpi)
                result.ocr_text = " ".join(w.text for w in result.words)
                result.engine = manager.engine_name
                result.seconds = time.time() - started

            pages.append(result)
            if progress_callback:
                progress_callback(index + 1, doc.page_count)
    finally:
        doc.close()

    return pages


# ===========================================================================
#  5.  THE SEARCHABLE PDF
# ===========================================================================
def write_searchable_pdf(path: str | Path,
                         pages: Sequence[PageText],
                         job_folder: Path,
                         password: str | None = None) -> Path:
    """
    Make a copy of the scan with an INVISIBLE text layer on top.

    The page looks exactly the same to the eye.  But Ctrl+F now works, text
    can be selected and copied, and our own search can read it.

    render_mode=3 is the PDF instruction for "draw this text, but show
    nothing" -- the standard way searchable scans are built.
    """
    from .pdf_ops import _safe_output_path, _save, open_pdf

    source = Path(path)
    doc = open_pdf(source, password)
    added = 0

    try:
        for result in pages:
            if not result.words or result.page_no > doc.page_count:
                continue
            page = doc[result.page_no - 1]
            for word in result.words:
                height = max(word.y1 - word.y0, 4.0)
                try:
                    page.insert_text(
                        (word.x0, word.y1 - height * 0.15),
                        word.text,
                        fontname="helv",
                        fontsize=height * 0.85,
                        render_mode=3,          # invisible
                    )
                    added += 1
                except Exception:               # noqa: BLE001 - odd glyphs
                    continue

        target = _safe_output_path(job_folder, f"{source.stem}_searchable")
        _save(doc, target)
    finally:
        doc.close()

    log.info("Searchable PDF: %s (%d words embedded)", target.name, added)
    return target
