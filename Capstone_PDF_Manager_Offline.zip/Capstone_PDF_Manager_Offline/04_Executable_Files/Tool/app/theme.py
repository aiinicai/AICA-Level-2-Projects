"""
theme.py
========
The look of the application, in one place.

Two things live here:

    1. THEME_3D  - a raised, tactile style sheet.  Buttons have a light top
                   edge and a dark bottom edge, so they appear to stand off
                   the surface, and press inwards when clicked.

    2. PasswordEdit - a password box that shows ****, and reveals the real
                   text while you double-click and hold your attention on it.
"""

from __future__ import annotations

from PyQt6.QtCore import QTimer, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QLineEdit

# ===========================================================================
#  COLOURS
# ===========================================================================
INK = "#EDEFF5"          # main text - high contrast on the dark surface
DIM = "#98A0B4"          # secondary text
BLUE = "#3B82F6"
BLUE_DARK = "#1D4ED8"
SURFACE = "#232733"
SURFACE_HI = "#2E3342"
LINE_LIGHT = "#454C60"   # the "lit" edge of a raised object
LINE_DARK = "#12141C"    # the shadow edge

# ===========================================================================
#  THE STYLE SHEET
# ===========================================================================
# The 3D effect is made with two tricks used consistently:
#   * a vertical gradient  (lighter at the top, darker at the bottom)
#   * a 2-pixel border where the top edge is light and the bottom is dark
# Pressing a button swaps the gradient, so it appears to sink.
THEME_3D = f"""
QWidget {{
    background: #1A1D26;
    color: {INK};
    font-family: "Segoe UI", Arial;
    font-size: 10.5pt;
    font-weight: 600;
}}

QLabel {{ background: transparent; }}
QLabel#Title {{
    font-size: 19pt; font-weight: 800; color: #8AB4FF;
}}
QLabel#Hint {{ color: {DIM}; font-weight: 600; }}
QLabel#Section {{
    font-size: 13pt; font-weight: 800; color: #8AB4FF;
    padding: 2px 0 6px 0;
}}
QLabel#Stat {{
    color: {INK}; font-weight: 800; font-size: 11pt;
}}

/* ---------- raised panels ---------- */
QFrame#Card, QGroupBox {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 {SURFACE_HI}, stop:1 {SURFACE});
    border-top: 2px solid {LINE_LIGHT};
    border-left: 2px solid {LINE_LIGHT};
    border-right: 2px solid {LINE_DARK};
    border-bottom: 2px solid {LINE_DARK};
    border-radius: 10px;
}}
QGroupBox {{ margin-top: 16px; padding-top: 14px; }}
QGroupBox::title {{
    subcontrol-origin: margin; left: 14px; padding: 0 8px;
    color: #8AB4FF; font-weight: 800; background: transparent;
}}

/* ---------- sunken drop zone ---------- */
QFrame#Drop {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #14161E, stop:1 #1D2029);
    border-top: 2px solid {LINE_DARK};
    border-left: 2px solid {LINE_DARK};
    border-right: 2px solid #3A4054;
    border-bottom: 2px solid #3A4054;
    border-radius: 10px;
}}
QFrame#Drop[hot="true"] {{
    border: 2px solid {BLUE}; background: #1E2A45;
}}

/* ---------- buttons: raised, and sinking when pressed ---------- */
QPushButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #3A4152, stop:1 #262B37);
    border-top: 2px solid #5A6377;
    border-left: 2px solid #4B5366;
    border-right: 2px solid {LINE_DARK};
    border-bottom: 3px solid {LINE_DARK};
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 700;
}}
QPushButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #464F64, stop:1 #2E3441);
}}
QPushButton:pressed {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #22262F, stop:1 #313744);
    border-top: 3px solid {LINE_DARK};
    border-bottom: 2px solid #5A6377;
    padding-top: 9px;
}}
QPushButton:disabled {{
    background: #23262F; color: #5C6377;
    border-top: 2px solid #2E323D; border-bottom: 2px solid #14161C;
}}
QPushButton#Primary {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5A9BFF, stop:1 {BLUE_DARK});
    border-top: 2px solid #8FBEFF;
    border-bottom: 3px solid #0F2E6B;
    border-left: 2px solid #4A86E8;
    border-right: 2px solid #0F2E6B;
    color: #FFFFFF; font-weight: 800;
}}
QPushButton#Primary:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #6EA9FF, stop:1 #2560E8);
}}
QPushButton#Primary:pressed {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #1B4FBF, stop:1 #4A86E8);
    border-top: 3px solid #0F2E6B; border-bottom: 2px solid #8FBEFF;
}}
QPushButton#Danger {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #C24A4A, stop:1 #7E2626);
    border-top: 2px solid #E38080; border-bottom: 3px solid #4A1414;
    border-left: 2px solid #B04040; border-right: 2px solid #4A1414;
    color: #FFFFFF; font-weight: 800;
}}
QPushButton#Tool {{
    padding: 9px 12px; font-size: 10pt; font-weight: 800;
}}
QPushButton#Tool:checked {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5A9BFF, stop:1 {BLUE_DARK});
    border-top: 2px solid #8FBEFF; border-bottom: 3px solid #0F2E6B;
    color: #FFFFFF;
}}

/* ---------- sidebar ---------- */
QListWidget#Nav {{
    background: #14161E; border: none;
    border-right: 2px solid {LINE_DARK};
    padding: 10px 6px; font-size: 11pt; font-weight: 700;
}}
QListWidget#Nav::item {{
    padding: 12px 14px; border-radius: 8px; margin: 3px 6px;
}}
QListWidget#Nav::item:selected {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5A9BFF, stop:1 {BLUE_DARK});
    color: #FFFFFF; font-weight: 800;
}}
QListWidget#Nav::item:hover:!selected {{ background: #232733; }}

/* ---------- inputs: sunken ---------- */
QLineEdit, QPlainTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
    background: #12141C;
    border-top: 2px solid {LINE_DARK};
    border-left: 2px solid {LINE_DARK};
    border-right: 2px solid #3A4054;
    border-bottom: 2px solid #3A4054;
    border-radius: 7px; padding: 7px;
    color: {INK}; font-weight: 600;
    selection-background-color: {BLUE};
}}
QLineEdit:focus, QPlainTextEdit:focus {{ border: 2px solid {BLUE}; }}
QLineEdit#Password {{
    font-family: Consolas, monospace; letter-spacing: 2px;
}}
QLineEdit#PasswordShown {{
    font-family: Consolas, monospace; letter-spacing: 1px;
    background: #2A2416; border: 2px solid #C79A2E; color: #FFD87A;
}}
QPlainTextEdit#Log {{
    font-family: Consolas, monospace; font-size: 9.5pt; font-weight: 500;
}}

/* ---------- tabs ---------- */
QTabWidget::pane {{
    border-top: 2px solid {LINE_LIGHT};
    border-left: 2px solid {LINE_LIGHT};
    border-right: 2px solid {LINE_DARK};
    border-bottom: 2px solid {LINE_DARK};
    border-radius: 10px; top: -2px; background: {SURFACE};
}}
QTabBar::tab {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #333A49, stop:1 #23272F);
    border-top: 2px solid #4B5366; border-left: 2px solid #4B5366;
    border-right: 2px solid {LINE_DARK};
    padding: 9px 18px; margin-right: 3px; font-weight: 700;
    border-top-left-radius: 8px; border-top-right-radius: 8px;
}}
QTabBar::tab:selected {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5A9BFF, stop:1 {BLUE_DARK});
    color: #FFFFFF; font-weight: 800;
}}

/* ---------- page grid ---------- */
QListWidget#Pages {{
    background: #101219;
    border-top: 2px solid {LINE_DARK}; border-left: 2px solid {LINE_DARK};
    border-right: 2px solid #3A4054; border-bottom: 2px solid #3A4054;
    border-radius: 8px; padding: 6px;
}}
QListWidget#Pages::item {{
    border: 2px solid transparent; border-radius: 6px; margin: 4px;
    color: {DIM}; font-weight: 700; font-size: 8.5pt;
}}
QListWidget#Pages::item:selected {{
    border: 2px solid {BLUE}; background: #1E2A45; color: #FFFFFF;
}}

/* ---------- progress ---------- */
QProgressBar {{
    background: #12141C;
    border-top: 2px solid {LINE_DARK}; border-left: 2px solid {LINE_DARK};
    border-right: 2px solid #3A4054; border-bottom: 2px solid #3A4054;
    border-radius: 9px; height: 22px; text-align: center;
    font-weight: 800; color: #FFFFFF;
}}
QProgressBar::chunk {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #6EA9FF, stop:1 {BLUE_DARK});
    border-radius: 7px; margin: 1px;
}}

/* ---------- tables ---------- */
QTableWidget {{
    background: #12141C; gridline-color: #2B3040;
    alternate-background-color: #171A23; font-weight: 600;
}}
QHeaderView::section {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #3A4152, stop:1 #262B37);
    padding: 7px; border: none; border-right: 1px solid {LINE_DARK};
    border-bottom: 2px solid {LINE_DARK}; font-weight: 800;
}}

QCheckBox {{ font-weight: 600; spacing: 8px; }}
QCheckBox::indicator {{
    width: 17px; height: 17px; border-radius: 4px;
    background: #12141C; border: 2px solid #4B5366;
}}
QCheckBox::indicator:checked {{
    background: {BLUE}; border: 2px solid #8FBEFF;
}}
QScrollBar:vertical {{ background: #14161E; width: 13px; margin: 0; }}
QScrollBar::handle:vertical {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #4B5366, stop:1 #333A49);
    border-radius: 6px; min-height: 30px;
}}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QSplitter::handle {{ background: {LINE_DARK}; width: 3px; }}
"""


# ===========================================================================
#  PASSWORD BOX WITH DOUBLE-CLICK REVEAL
# ===========================================================================
class PasswordEdit(QLineEdit):
    """
    Shows **** normally.

    Double-click to reveal the real characters.  It hides itself again after
    a few seconds, or as soon as the box loses focus -- so a password is never
    left visible on an unattended screen.

    Nothing is stored: this widget only changes how the text is displayed.
    """

    revealed = pyqtSignal(bool)

    def __init__(self, placeholder: str = "Password (double-click to reveal)",
                 reveal_seconds: int = 5) -> None:
        super().__init__()
        self.setObjectName("Password")
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.setPlaceholderText(placeholder)
        self.setToolTip("Double-click to show the password for a few seconds")

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(reveal_seconds * 1000)
        self._timer.timeout.connect(self.hide_text)

    # -- reveal ------------------------------------------------------------
    def mouseDoubleClickEvent(self, event):      # noqa: N802 - Qt naming
        self.show_text()
        super().mouseDoubleClickEvent(event)

    def show_text(self) -> None:
        if not self.text():
            return
        self.setEchoMode(QLineEdit.EchoMode.Normal)
        self.setObjectName("PasswordShown")
        self._restyle()
        self._timer.start()
        self.revealed.emit(True)

    def hide_text(self) -> None:
        self._timer.stop()
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.setObjectName("Password")
        self._restyle()
        self.revealed.emit(False)

    def focusOutEvent(self, event):              # noqa: N802
        self.hide_text()
        super().focusOutEvent(event)

    def _restyle(self) -> None:
        """Qt only re-reads the style sheet when told to."""
        self.style().unpolish(self)
        self.style().polish(self)

    # -- safety ------------------------------------------------------------
    def wipe(self) -> None:
        """Clear the box and forget the text."""
        self.hide_text()
        self.clear()


def bold_font(points: float = 10.5, weight: int = 700) -> QFont:
    font = QFont("Segoe UI", int(points))
    font.setWeight(QFont.Weight.DemiBold if weight < 750 else QFont.Weight.Bold)
    return font
