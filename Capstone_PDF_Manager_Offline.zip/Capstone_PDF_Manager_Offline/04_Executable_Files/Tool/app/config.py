"""
config.py
=========
The single place where ALL settings live.

Rule of thumb: if you ever feel like typing a number, a colour or a folder
name inside another file -- stop, and put it here instead.

Nothing in this file needs any other part of the tool, so it can never
create a circular import.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 1.  WHERE ARE WE RUNNING FROM?
# ---------------------------------------------------------------------------
# When we later build the .exe with PyInstaller, the folder layout changes.
# This little helper makes the tool find its own folder in BOTH cases.

def _application_root() -> Path:
    """Return the folder that contains the tool (script mode or .exe mode)."""
    if getattr(sys, "frozen", False):          # running as a PyInstaller .exe
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent   # ...\PGBidToolkit


APP_ROOT: Path = _application_root()

# ---------------------------------------------------------------------------
# 2.  FOLDERS
# ---------------------------------------------------------------------------
OUTPUT_DIR: Path = APP_ROOT / "Output"      # every result file lands here
LOG_DIR: Path = APP_ROOT / "Logs"           # run logs + error logs
MODELS_DIR: Path = APP_ROOT / "models"      # offline OCR brains live here
PROFILES_DIR: Path = APP_ROOT / "profiles"  # saved job settings (.json)
TEMP_DIR: Path = APP_ROOT / "_temp"         # scratch space, auto-cleaned

ALL_DIRS = (OUTPUT_DIR, LOG_DIR, MODELS_DIR, PROFILES_DIR, TEMP_DIR)

# Sub-folders inside models/ for each OCR engine (all fully offline)
EASYOCR_MODEL_DIR: Path = MODELS_DIR / "easyocr"
TESSERACT_DIR: Path = MODELS_DIR / "tesseract"          # portable program
TESSERACT_EXE: Path = TESSERACT_DIR / "tesseract.exe"
TESSDATA_DIR: Path = TESSERACT_DIR / "tessdata"         # eng.traineddata etc.
RAPIDOCR_MODEL_DIR: Path = MODELS_DIR / "rapidocr"

# ---------------------------------------------------------------------------
# 3.  APPLICATION IDENTITY
# ---------------------------------------------------------------------------
APP_NAME = "PDF Manager Offline"
APP_NAME_HI = "पीडीएफ मैनेजर ऑफलाइन"
APP_VERSION = "1.0.0"
APP_OWNER = "Finance & Accounts"
DEFAULT_WATERMARK_TEXT = "Internal - F&A"

# ---------------------------------------------------------------------------
# 4.  SAFETY LIMITS  (guard-rails so one bad file cannot hang the machine)
# ---------------------------------------------------------------------------
MAX_FILE_SIZE_MB = 200          # skip + log anything bigger
MAX_PAGES_PER_FILE = 500        # skip + log anything longer
MAX_FILES_PER_BATCH = 200       # queue ceiling
HASH_CHUNK_BYTES = 1024 * 1024  # read files 1 MB at a time when hashing

# OCR is slow, so we never OCR a page that already has real text.
MIN_CHARS_FOR_TEXT_LAYER = 40   # fewer characters than this => treat as scan
OCR_RENDER_DPI = 300            # 300 dpi is the sweet spot for accuracy/speed

# ---------------------------------------------------------------------------
# 5.  SUPPORTED FILE TYPES
# ---------------------------------------------------------------------------
EXT_PDF = {".pdf"}
EXT_WORD = {".docx", ".doc"}
EXT_EXCEL = {".xlsx", ".xlsm", ".xls"}
EXT_DATA = {".csv", ".tsv", ".json"}
EXT_TEXT = {".txt", ".md", ".log"}
EXT_HTML = {".html", ".htm"}
EXT_IMAGE = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}

SUPPORTED_EXTENSIONS = (
    EXT_PDF | EXT_WORD | EXT_EXCEL | EXT_DATA
    | EXT_TEXT | EXT_HTML | EXT_IMAGE
)

# ---------------------------------------------------------------------------
# 6.  OCR ENGINE OPTIONS  (the UI drop-down reads this list)
# ---------------------------------------------------------------------------
OCR_ENGINES = {
    "none": "No OCR - use existing text only / केवल मौजूदा टेक्स्ट",
    "rapidocr": "RapidOCR - fastest, English (80 MB) / सबसे तेज़",
    "tesseract": "Tesseract - balanced, Eng+Hindi (150 MB) / संतुलित",
    "easyocr": "EasyOCR - best for messy Hindi scans (2 GB) / सर्वश्रेष्ठ",
}
DEFAULT_OCR_ENGINE = "rapidocr"
OCR_LANGUAGES = ["en", "hi"]        # English + Hindi

# ---------------------------------------------------------------------------
# 7.  PASSWORD POLICY
# ---------------------------------------------------------------------------
# Passwords are typed in the UI and kept in memory only.  We NEVER write them
# to disk, and we NEVER attempt to guess/crack an unknown password.
ALLOW_PASSWORD_FILE = False     # keep False for audit safety
MAX_PASSWORD_ATTEMPTS_PER_FILE = 50

# What to do when NONE of the supplied passwords opens a file:
#   "ask"  -> stop and offer: enter password / skip this one / skip all
#   "skip" -> log it and carry on  (use this for overnight unattended runs)
UNKNOWN_PASSWORD_POLICY = "ask"

# Unattended mode forces "skip" everywhere, so a 200-file overnight job never
# sits waiting for a human.  The GUI will expose this as a tick-box.
UNATTENDED_MODE = False

# ---------------------------------------------------------------------------
# 8.  COLOUR SCHEME FOR HIGHLIGHTING
# ---------------------------------------------------------------------------
# One scheme, used identically in Excel, Word, PPT, HTML and PDF, so the
# reviewer learns the colours once.
#            key            fill       font      meaning
HIGHLIGHT_STYLES = {
    "critical": {"fill": "#FFC7CE", "font": "#9C0006", "bold": True,
                 "label": "Critical / अत्यावश्यक"},
    "warning":  {"fill": "#FFEB9C", "font": "#9C6500", "bold": True,
                 "label": "Needs review / जाँच आवश्यक"},
    "ok":       {"fill": "#C6EFCE", "font": "#006100", "bold": False,
                 "label": "Compliant / अनुपालन"},
    "money":    {"fill": "#DDEBF7", "font": "#1F4E79", "bold": True,
                 "label": "Financial figure / वित्तीय आंकड़ा"},
    "date":     {"fill": "#E4DFEC", "font": "#5F497A", "bold": False,
                 "label": "Date / दिनांक"},
    "keyword":  {"fill": "#FCE4D6", "font": "#833C00", "bold": True,
                 "label": "Watch keyword / निगरानी शब्द"},
}

# Default keyword watch-list.  The UI can edit this and save it to
# profiles/keywords.json, which then overrides the list below.
DEFAULT_KEYWORDS = {
    "critical": ["deviation", "non-compliant", "rejected", "disqualif",
                 "conditional", "arbitration", "litigation", "blacklist"],
    "warning":  ["provisional", "subject to", "unaudited", "qualified opinion",
                 "extension", "shortfall", "clarification"],
    "keyword":  ["MAAT", "net worth", "liquid asset", "turnover", "EMD",
                 "bid security", "solvency", "QR", "MSE", "start-up"],
}

# Auto-rules (no keyword needed) -- switched on/off from the UI
AUTO_RULES = {
    "highlight_currency": True,     # ₹ 12,34,567 / Rs. / INR / Cr / Lakh
    "highlight_dates": True,        # 31.03.2025, 31-Mar-2025 ...
    "highlight_negatives": True,    # (1,234) or -1,234  -> critical
    "highlight_blank_mandatory": True,
}

# ---------------------------------------------------------------------------
# 9.  OUTPUT BEHAVIOUR
# ---------------------------------------------------------------------------
NEVER_OVERWRITE_SOURCE = True   # hard rule -- do not change this
TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S"

# ---------------------------------------------------------------------------
# 9b. PDF TOOLKIT (Step 3)
# ---------------------------------------------------------------------------
# The footer is one thin line at the bottom of every page, in three zones:
#
#   [ Bidder A - p3 ]        [ 12 ]        [ Internal - F&A  09-Aug-26 18:40 ]
#      LEFT = where it                       RIGHT = watermark + stamp
#      came from            CENTRE = new
#                           page number
#
FOOTER_ENABLED = True
FOOTER_FONT = "helv"            # built-in, no font file needed
FOOTER_FONT_SIZE = 7
FOOTER_COLOUR = (0.35, 0.35, 0.35)      # soft grey, never distracting
FOOTER_MARGIN_PT = 18           # distance from the paper edge (about 6 mm)
FOOTER_DATE_FORMAT = "%d-%b-%y %H:%M"

# Bookmarks: when merging, each source file becomes a top-level bookmark and
# its own original bookmarks are nested underneath it.
MERGE_BUILD_BOOKMARKS = True
MERGE_KEEP_METADATA = True

# Watermark / stamp defaults
STAMP_INCLUDE_DATETIME = True
STAMP_TEXT = DEFAULT_WATERMARK_TEXT     # "Internal - F&A"

# Compression: you asked to be offered all three levels every time.
COMPRESSION_LEVELS = {
    "light": {
        "dpi": None, "quality": None,
        "label": "Light - tidy up only, images untouched (safest)",
        "label_hi": "हल्का - चित्र अछूते",
    },
    "balanced": {
        "dpi": 150, "quality": 75,
        "label": "Balanced - images to 150 dpi, still clearly readable",
        "label_hi": "संतुलित - 150 dpi",
    },
    "strong": {
        "dpi": 100, "quality": 55,
        "label": "Strong - images to 100 dpi, smallest file (check before sending)",
        "label_hi": "अधिकतम - 100 dpi",
    },
}
DEFAULT_COMPRESSION_LEVEL = "balanced"
# "flag_and_skip" -> show the duplicate in the report, but do NOT process it
#                    again (best of both: you see it, machine saves time)
# "flag"          -> report it AND still process it
# "skip"          -> silently ignore the second copy
DUPLICATE_ACTION = "flag_and_skip"

# Names of the two things the intake stage hands you at the end
MANIFEST_FILE_NAME = "01_Intake_Manifest.xlsx"
SUMMARY_FILE_NAME = "01_Intake_Summary.txt"

# ---------------------------------------------------------------------------
# 10. LOGGING
# ---------------------------------------------------------------------------
LOG_LEVEL = os.environ.get("PGBT_LOG_LEVEL", "INFO")
LOG_FILE_NAME = "pg_bid_toolkit.log"
ERROR_FILE_NAME = "errors.csv"
LOG_MAX_BYTES = 5 * 1024 * 1024
LOG_BACKUP_COUNT = 3
