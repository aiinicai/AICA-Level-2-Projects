"""
pdf_ops.py
==========
STEP 3 - the PDF workshop.

Eight tools, one rule: the file you gave me is never touched.  Every job
writes a NEW file into the job folder.

    merge      several PDFs -> one, with footers and a bookmark tree
    split      one PDF -> many, by page ranges or every N pages
    rotate     90 / 180 / 270 / 360 degrees, all pages or chosen ones
    reorder    move pages around, footers renumbered automatically
    crop       trim margins away (useful for scanned A3 sheets)
    compress   three strengths: light / balanced / strong
    stamp      the "Internal - F&A" footer with date and time
    retype     white-out a box and type new text over it

A word on the footer, because you chose the audit-friendly option:

    left zone    "Bidder_A - p3"     where this page originally came from
    centre zone  "12"                its new number in the merged file
    right zone   "Internal - F&A     09-Aug-26 18:40"

Note: the footer uses a built-in Latin font, so footer text is English only.
Hindi text inside the page body is untouched and displays normally.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

# PyMuPDF renamed itself from "fitz" to "pymupdf" in version 1.24.  We accept
# both, so this file works whichever version pip gave you.
try:
    import pymupdf as fitz          # version 1.24 and newer (your machine)
except ImportError:                 # pragma: no cover
    import fitz                     # older versions

from . import common, config

log = common.get_logger("pdf")


# ===========================================================================
#  0.  OPENING AND SAVING SAFELY
# ===========================================================================
class PdfLockedError(Exception):
    """Raised when a PDF will not open with the password given."""


def open_pdf(path: str | Path, password: str | None = None) -> fitz.Document:
    """
    Open a PDF read-only, unlocking it in memory if a password is needed.

    The document object returned is a working copy in memory.  Saving it
    always goes to a NEW path -- never back over the original.
    """
    doc = fitz.open(str(path))
    if doc.needs_pass:
        if password is None or not doc.authenticate(password):
            doc.close()
            raise PdfLockedError(f"Password did not open: {Path(path).name}")
    return doc


def _safe_output_path(folder: Path, stem: str, suffix: str = ".pdf") -> Path:
    """
    Build an output path that cannot clash with anything.

    If Merged.pdf already exists we produce Merged_2.pdf, and so on.  We would
    rather make one extra file than destroy one.
    """
    folder.mkdir(parents=True, exist_ok=True)
    candidate = folder / f"{common.safe_filename(stem)}{suffix}"
    counter = 2
    while candidate.exists():
        candidate = folder / f"{common.safe_filename(stem)}_{counter}{suffix}"
        counter += 1
    return candidate


def _save(doc: fitz.Document, target: Path, compress: bool = True) -> Path:
    """Write the working copy out. garbage=4 removes unused leftovers."""
    doc.save(
        str(target),
        garbage=4,          # throw away orphaned objects
        deflate=True,       # zip the streams
        clean=True,         # tidy the internal structure
        pretty=False,
    )
    log.info("Saved: %s (%s)", target.name, common.human_size(target.stat().st_size))
    return target


# ===========================================================================
#  1.  THE FOOTER  (shared by merge, reorder and stamp)
# ===========================================================================
def build_stamp_text(text: str | None = None,
                     include_datetime: bool | None = None) -> str:
    """Compose the right-hand zone, e.g. 'Internal - F&A   09-Aug-26 18:40'."""
    label = text if text is not None else config.STAMP_TEXT
    want_time = (config.STAMP_INCLUDE_DATETIME
                 if include_datetime is None else include_datetime)
    if want_time:
        return f"{label}   {datetime.now().strftime(config.FOOTER_DATE_FORMAT)}"
    return label


def stamp_footer(page: fitz.Page,
                 left: str = "",
                 centre: str = "",
                 right: str = "") -> None:
    """
    Draw one thin grey line at the foot of a page.

    We work in "points" (72 points = 1 inch).  The page rectangle already
    accounts for any rotation, so this lands correctly on rotated pages too.
    """
    rect = page.rect
    y = rect.height - config.FOOTER_MARGIN_PT
    size = config.FOOTER_FONT_SIZE
    colour = config.FOOTER_COLOUR
    font = config.FOOTER_FONT

    if left:
        page.insert_text((config.FOOTER_MARGIN_PT, y), left,
                         fontname=font, fontsize=size, color=colour)

    if centre:
        width = fitz.get_text_length(centre, fontname=font, fontsize=size)
        page.insert_text(((rect.width - width) / 2, y), centre,
                         fontname=font, fontsize=size, color=colour)

    if right:
        width = fitz.get_text_length(right, fontname=font, fontsize=size)
        page.insert_text((rect.width - config.FOOTER_MARGIN_PT - width, y), right,
                         fontname=font, fontsize=size, color=colour)


# ===========================================================================
#  2.  MERGE
# ===========================================================================
@dataclass
class MergeItem:
    """One PDF waiting to join the merged file."""
    path: Path
    password: str | None = None
    label: str | None = None        # shown in the footer and the bookmark

    @property
    def display(self) -> str:
        return self.label or self.path.stem


@dataclass
class MergeResult:
    output: Path
    total_pages: int
    sources: int
    bookmarks: int
    skipped: list[str] = field(default_factory=list)


def merge_pdfs(items: Sequence[MergeItem],
               job_folder: Path,
               output_name: str = "Merged",
               add_footer: bool = True,
               stamp_text: str | None = None,
               errors: common.ErrorLog | None = None,
               cancel: common.CancelToken | None = None,
               progress_callback=None) -> MergeResult:
    """
    Join several PDFs into one.

    What you get, because you chose "footer + bookmark tree":
      * every page carries  source | new page number | Internal - F&A + time
      * a bookmark per source file, with that file's own bookmarks nested
        underneath, so the merged file is navigable in any PDF reader
      * the first file's metadata (title, author) is carried across
    """
    errors = errors or common.ErrorLog(job_folder)
    cancel = cancel or common.CancelToken()
    merged = fitz.open()                       # a brand-new empty PDF
    toc: list[list] = []
    skipped: list[str] = []
    right_zone = build_stamp_text(stamp_text)
    metadata_taken = False

    progress = common.Progress(len(items), progress_callback, "Merging")

    for item in items:
        cancel.raise_if_cancelled()
        try:
            source = open_pdf(item.path, item.password)
        except Exception as exc:               # noqa: BLE001
            skipped.append(item.path.name)
            errors.add(item.path.name, "merge", "Could not open", str(exc))
            progress.step(f"SKIPPED {item.path.name}")
            continue

        try:
            first_new_page = merged.page_count + 1
            merged.insert_pdf(source)          # copies pages, images, fonts

            if config.MERGE_KEEP_METADATA and not metadata_taken:
                merged.set_metadata(source.metadata or {})
                metadata_taken = True

            if config.MERGE_BUILD_BOOKMARKS:
                # Level 1: this source file
                toc.append([1, item.display, first_new_page])
                # Level 2+: whatever bookmarks that file already had
                for level, title, page_no in (source.get_toc() or []):
                    toc.append([level + 1, title, page_no + first_new_page - 1])

            if add_footer and config.FOOTER_ENABLED:
                for offset in range(source.page_count):
                    page = merged[first_new_page - 1 + offset]
                    stamp_footer(
                        page,
                        left=f"{item.display} - p{offset + 1}",
                        centre=str(first_new_page + offset),
                        right=right_zone,
                    )

            progress.step(f"{item.path.name} ({source.page_count} pages)")
        finally:
            source.close()

    if config.MERGE_BUILD_BOOKMARKS and toc:
        merged.set_toc(toc)

    target = _safe_output_path(job_folder, output_name)
    _save(merged, target)
    result = MergeResult(target, merged.page_count,
                         len(items) - len(skipped), len(toc), skipped)
    merged.close()
    progress.finish()
    return result


# ===========================================================================
#  3.  SPLIT
# ===========================================================================
def parse_ranges(text: str, max_page: int) -> list[tuple[int, int]]:
    """
    Turn "1-5, 8, 12-20" into [(1,5), (8,8), (12,20)].

    Page numbers are the ones a human sees: the first page is 1, not 0.
    """
    ranges: list[tuple[int, int]] = []
    for chunk in str(text).split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            start_txt, _, end_txt = chunk.partition("-")
            start = int(start_txt.strip())
            end = int(end_txt.strip() or max_page)
        else:
            start = end = int(chunk)
        start = max(1, start)
        end = min(max_page, end)
        if start <= end:
            ranges.append((start, end))
    return ranges


def split_pdf(path: str | Path,
              job_folder: Path,
              ranges: str | None = None,
              every: int | None = None,
              password: str | None = None) -> list[Path]:
    """
    Cut one PDF into several.

    Give EITHER  ranges="1-5, 6-10"   OR  every=25  (a new file every 25 pages).
    """
    source = Path(path)
    doc = open_pdf(source, password)
    outputs: list[Path] = []

    try:
        if ranges:
            spans = parse_ranges(ranges, doc.page_count)
        elif every:
            spans = [(s, min(s + every - 1, doc.page_count))
                     for s in range(1, doc.page_count + 1, every)]
        else:                                   # default: one file per page
            spans = [(p, p) for p in range(1, doc.page_count + 1)]

        for index, (start, end) in enumerate(spans, start=1):
            piece = fitz.open()
            piece.insert_pdf(doc, from_page=start - 1, to_page=end - 1)
            name = f"{source.stem}_part{index:02d}_p{start}-{end}"
            target = _safe_output_path(job_folder, name)
            _save(piece, target)
            piece.close()
            outputs.append(target)
    finally:
        doc.close()

    log.info("Split %s into %d file(s)", source.name, len(outputs))
    return outputs


# ===========================================================================
#  4.  ROTATE
# ===========================================================================
def rotate_pdf(path: str | Path,
               job_folder: Path,
               degrees: int,
               pages: str | None = None,
               password: str | None = None) -> Path:
    """
    Turn pages. 90 = clockwise quarter turn, 180 = upside down, 360 = no change.

    `pages` uses the same "1-5, 8" wording as split. Leave it empty for all.
    """
    if degrees % 90 != 0:
        raise ValueError("Rotation must be 0, 90, 180, 270 or 360 degrees")
    turn = degrees % 360                    # 360 politely becomes 0

    source = Path(path)
    doc = open_pdf(source, password)
    try:
        if pages:
            wanted = {p for start, end in parse_ranges(pages, doc.page_count)
                      for p in range(start, end + 1)}
        else:
            wanted = set(range(1, doc.page_count + 1))

        for number in wanted:
            page = doc[number - 1]
            page.set_rotation((page.rotation + turn) % 360)

        target = _safe_output_path(job_folder, f"{source.stem}_rotated{degrees}")
        _save(doc, target)
    finally:
        doc.close()
    return target


# ===========================================================================
#  5.  REORDER  (with automatic renumbering)
# ===========================================================================
def reorder_pdf(path: str | Path,
                job_folder: Path,
                order: str,
                renumber: bool = True,
                stamp_text: str | None = None,
                password: str | None = None) -> Path:
    """
    Rebuild a PDF in a new page order, e.g. order="3,1,2,4-10".

    Because pages have moved, the old printed numbers now lie.  With
    renumber=True we stamp the TRUE new position in the footer centre, and
    keep a note of where each page came from on the left -- exactly what an
    auditor needs when bid annexures have been re-sequenced.
    """
    source = Path(path)
    doc = open_pdf(source, password)
    try:
        sequence = [p for start, end in parse_ranges(order, doc.page_count)
                    for p in range(start, end + 1)]
        if not sequence:
            raise ValueError("The page order you gave is empty")

        rebuilt = fitz.open()
        right_zone = build_stamp_text(stamp_text)

        for new_position, original in enumerate(sequence, start=1):
            rebuilt.insert_pdf(doc, from_page=original - 1, to_page=original - 1)
            if renumber and config.FOOTER_ENABLED:
                stamp_footer(
                    rebuilt[new_position - 1],
                    left=f"was p{original}",
                    centre=str(new_position),
                    right=right_zone,
                )

        target = _safe_output_path(job_folder, f"{source.stem}_reordered")
        _save(rebuilt, target)
        rebuilt.close()
    finally:
        doc.close()
    return target


# ===========================================================================
#  6.  CROP
# ===========================================================================
def crop_pdf(path: str | Path,
             job_folder: Path,
             top_mm: float = 0, bottom_mm: float = 0,
             left_mm: float = 0, right_mm: float = 0,
             pages: str | None = None,
             password: str | None = None) -> Path:
    """
    Trim margins away.  Sizes are in millimetres, as on a ruler.

    Cropping HIDES the margin, it does not delete the content underneath --
    so nothing is ever truly lost from the source.
    """
    mm = 72.0 / 25.4                          # points per millimetre
    source = Path(path)
    doc = open_pdf(source, password)
    try:
        if pages:
            wanted = {p for start, end in parse_ranges(pages, doc.page_count)
                      for p in range(start, end + 1)}
        else:
            wanted = set(range(1, doc.page_count + 1))

        for number in wanted:
            page = doc[number - 1]
            box = page.rect
            new_box = fitz.Rect(
                box.x0 + left_mm * mm,
                box.y0 + top_mm * mm,
                box.x1 - right_mm * mm,
                box.y1 - bottom_mm * mm,
            )
            if new_box.width > 10 and new_box.height > 10:
                page.set_cropbox(new_box)
            else:
                log.warning("Page %d: crop too aggressive, left as it was", number)

        target = _safe_output_path(job_folder, f"{source.stem}_cropped")
        _save(doc, target)
    finally:
        doc.close()
    return target


# ===========================================================================
#  7.  COMPRESS  (three strengths, as you asked)
# ===========================================================================
@dataclass
class CompressResult:
    output: Path
    level: str
    before_bytes: int
    after_bytes: int
    images_shrunk: int

    @property
    def saved_percent(self) -> float:
        if not self.before_bytes:
            return 0.0
        return (1 - self.after_bytes / self.before_bytes) * 100

    def describe(self) -> str:
        return (f"{common.human_size(self.before_bytes)} -> "
                f"{common.human_size(self.after_bytes)} "
                f"({self.saved_percent:.0f}% smaller, "
                f"{self.images_shrunk} image(s) reduced)")


def _shrink_images(doc: fitz.Document, dpi: int, quality: int) -> int:
    """
    Make the pictures inside a PDF smaller.

    A scanner often stores a page at 600 dpi even though nobody will ever
    look that closely.  We work out how big each picture actually appears on
    the page, and store it at the requested dpi instead.
    """
    from io import BytesIO
    from PIL import Image

    shrunk = 0
    seen: set[int] = set()

    for page in doc:
        for info in page.get_images(full=True):
            xref = info[0]
            if xref in seen:
                continue
            seen.add(xref)
            try:
                rects = page.get_image_rects(xref)
                if not rects:
                    continue
                display_width_pt = max(r.width for r in rects)
                target_px = max(int(display_width_pt / 72.0 * dpi), 50)

                raw = doc.extract_image(xref)
                image = Image.open(BytesIO(raw["image"]))
                if image.width <= target_px:
                    continue                       # already small enough

                ratio = target_px / image.width
                smaller = image.convert("RGB").resize(
                    (target_px, max(int(image.height * ratio), 1)),
                    Image.LANCZOS,
                )
                buffer = BytesIO()
                smaller.save(buffer, format="JPEG", quality=quality, optimize=True)
                page.replace_image(xref, stream=buffer.getvalue())
                shrunk += 1
            except Exception as exc:               # noqa: BLE001
                log.debug("Image xref %s left alone: %s", xref, exc)
    return shrunk


def compress_pdf(path: str | Path,
                 job_folder: Path,
                 level: str = config.DEFAULT_COMPRESSION_LEVEL,
                 password: str | None = None) -> CompressResult:
    """Shrink a PDF at one of three strengths: light, balanced or strong."""
    if level not in config.COMPRESSION_LEVELS:
        raise ValueError(f"Unknown level '{level}'. "
                         f"Choose from: {', '.join(config.COMPRESSION_LEVELS)}")

    settings = config.COMPRESSION_LEVELS[level]
    source = Path(path)
    before = source.stat().st_size
    doc = open_pdf(source, password)
    shrunk = 0

    try:
        if settings["dpi"]:
            shrunk = _shrink_images(doc, settings["dpi"], settings["quality"])
        try:
            doc.subset_fonts()          # keep only the letters actually used
        except Exception:               # noqa: BLE001 - not fatal
            pass

        target = _safe_output_path(job_folder, f"{source.stem}_{level}")
        _save(doc, target)
    finally:
        doc.close()

    result = CompressResult(target, level, before, target.stat().st_size, shrunk)
    log.info("Compress (%s): %s", level, result.describe())
    return result


def compare_compression(path: str | Path,
                        job_folder: Path,
                        password: str | None = None) -> list[CompressResult]:
    """
    Run all three strengths so you can SEE the trade-off before deciding.

    This is what you asked for: choose each time, with evidence.
    """
    results = []
    for level in config.COMPRESSION_LEVELS:
        try:
            results.append(compress_pdf(path, job_folder, level, password))
        except Exception as exc:                   # noqa: BLE001
            log.warning("Level '%s' failed: %s", level, exc)
    return results


# ===========================================================================
#  8.  STAMP  (watermark footer on an existing PDF)
# ===========================================================================
def stamp_pdf(path: str | Path,
              job_folder: Path,
              text: str | None = None,
              include_datetime: bool | None = None,
              number_pages: bool = True,
              password: str | None = None) -> Path:
    """Add the 'Internal - F&A' footer with date and time to every page."""
    source = Path(path)
    doc = open_pdf(source, password)
    right_zone = build_stamp_text(text, include_datetime)
    try:
        for index, page in enumerate(doc, start=1):
            stamp_footer(page,
                         centre=str(index) if number_pages else "",
                         right=right_zone)
        target = _safe_output_path(job_folder, f"{source.stem}_stamped")
        _save(doc, target)
    finally:
        doc.close()
    return target


# ===========================================================================
#  9.  WHITE-OUT AND RETYPE
# ===========================================================================
@dataclass
class TextEdit:
    """One correction: cover this box on this page, and type this instead."""
    page: int                       # human numbering, first page = 1
    find: str | None = None         # find this text and cover it...
    rect: tuple[float, float, float, float] | None = None   # ...or give a box
    new_text: str = ""
    font_size: float = 9.0


def whiteout_and_retype(path: str | Path,
                        job_folder: Path,
                        edits: Iterable[TextEdit],
                        password: str | None = None) -> tuple[Path, int]:
    """
    Cover something with a white box and type new words on top.

    Please be realistic about this feature:
      * the old text is genuinely REMOVED, not merely hidden (good for redaction)
      * the replacement is typed in a standard font, so it may not match the
        original typeface exactly
      * it is meant for short corrections and redactions, not for rewriting
        whole paragraphs
    """
    source = Path(path)
    doc = open_pdf(source, password)
    applied = 0

    try:
        for edit in edits:
            if not 1 <= edit.page <= doc.page_count:
                log.warning("Page %d does not exist - skipped", edit.page)
                continue
            page = doc[edit.page - 1]

            boxes: list[fitz.Rect] = []
            if edit.find:
                boxes = list(page.search_for(edit.find))
                if not boxes:
                    log.warning("'%s' not found on page %d", edit.find, edit.page)
            elif edit.rect:
                boxes = [fitz.Rect(*edit.rect)]

            for box in boxes:
                page.add_redact_annot(box, fill=(1, 1, 1))   # white
            if boxes:
                page.apply_redactions()                      # old text removed

            if edit.new_text and boxes:
                target_box = boxes[0]
                page.insert_textbox(
                    target_box, edit.new_text,
                    fontname=config.FOOTER_FONT,
                    fontsize=edit.font_size,
                    color=(0, 0, 0),
                    align=fitz.TEXT_ALIGN_LEFT,
                )
            applied += len(boxes)

        target = _safe_output_path(job_folder, f"{source.stem}_edited")
        _save(doc, target)
    finally:
        doc.close()

    log.info("Retype: %d box(es) replaced in %s", applied, source.name)
    return target, applied
