"""
common.py
=========
The tool's "toolbox drawer".

Everything here is small, boring and reusable:
  * making folders                      -> ensure_dirs()
  * writing to the log file             -> get_logger()
  * a tidy audit trail of failures      -> ErrorLog
  * giving every file a fingerprint     -> file_hash() / DuplicateRegistry
  * stopping a long job safely          -> CancelToken
  * making a fresh Output sub-folder    -> new_job_folder()

No PDF code, no GUI code.  Just plumbing.
"""

from __future__ import annotations

import csv
import hashlib
import logging
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterable

from . import config


# ===========================================================================
#  1.  FOLDERS
# ===========================================================================
def ensure_dirs(dirs: Iterable[Path] = config.ALL_DIRS) -> None:
    """Create every folder the tool needs.  Safe to call again and again."""
    for folder in dirs:
        folder.mkdir(parents=True, exist_ok=True)


def new_job_folder(job_name: str = "job") -> Path:
    """
    Make a brand-new, uniquely named folder inside Output/.

    Example:  Output/20260809_143012_TL02_bids/
    Keeping one folder per run means results never mix up, and a failed run
    can simply be deleted.
    """
    ensure_dirs()
    stamp = datetime.now().strftime(config.TIMESTAMP_FORMAT)
    folder = config.OUTPUT_DIR / f"{stamp}_{safe_filename(job_name)}"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def clean_temp() -> None:
    """Empty the scratch folder.  Called at the end of every run."""
    if config.TEMP_DIR.exists():
        shutil.rmtree(config.TEMP_DIR, ignore_errors=True)
    config.TEMP_DIR.mkdir(parents=True, exist_ok=True)


# ===========================================================================
#  2.  NAMES AND SIZES
# ===========================================================================
_UNSAFE_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_filename(name: str, max_length: int = 80) -> str:
    """Turn any text into something Windows will happily accept as a name."""
    cleaned = _UNSAFE_CHARS.sub("_", str(name)).strip(" .")
    cleaned = re.sub(r"\s+", "_", cleaned)
    return (cleaned or "untitled")[:max_length]


def human_size(num_bytes: float) -> str:
    """1536000 -> '1.5 MB'.  Purely for readable logs and the UI."""
    for unit in ("B", "KB", "MB", "GB"):
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} TB"


def human_duration(seconds: float) -> str:
    """95 -> '1 min 35 s'."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds} s"
    minutes, secs = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes} min {secs} s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours} h {minutes} min"


# ===========================================================================
#  3.  LOGGING
# ===========================================================================
_LOGGER_READY = False


def get_logger(name: str = "pgbt") -> logging.Logger:
    """
    Return the tool's logger.

    It writes to BOTH the black console window and Logs/pg_bid_toolkit.log,
    so an auditor can always see what happened, even days later.
    """
    global _LOGGER_READY
    logger = logging.getLogger(name)

    if not _LOGGER_READY:
        ensure_dirs()
        logger.setLevel(getattr(logging, config.LOG_LEVEL, logging.INFO))
        logger.propagate = False

        fmt = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        console = logging.StreamHandler()
        console.setFormatter(fmt)
        logger.addHandler(console)

        file_handler = RotatingFileHandler(
            config.LOG_DIR / config.LOG_FILE_NAME,
            maxBytes=config.LOG_MAX_BYTES,
            backupCount=config.LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)

        _LOGGER_READY = True

    return logger


# ===========================================================================
#  4.  ERROR LOG  (the audit trail the UI will display)
# ===========================================================================
@dataclass
class ErrorRow:
    """One line of trouble."""
    file_name: str
    stage: str            # e.g. "intake", "unlock", "ocr", "export"
    problem: str          # short, human wording
    detail: str = ""      # technical detail for the developer
    when: str = field(default_factory=lambda: datetime.now().isoformat(" ", "seconds"))


class ErrorLog:
    """
    Collects problems instead of crashing.

    Philosophy: ONE bad file out of 200 must never stop the batch.  We note
    it, move on, and show the whole list at the end.
    """

    def __init__(self, job_folder: Path | None = None) -> None:
        ensure_dirs()
        self.rows: list[ErrorRow] = []
        self.job_folder = job_folder or config.LOG_DIR
        self.log = get_logger()

    def add(self, file_name: str, stage: str, problem: str, detail: str = "") -> None:
        row = ErrorRow(str(file_name), stage, problem, str(detail)[:500])
        self.rows.append(row)
        self.log.warning("[%s] %s -> %s", stage, file_name, problem)

    @property
    def count(self) -> int:
        return len(self.rows)

    def save_csv(self, path: Path | None = None) -> Path | None:
        """Write errors.csv.  Returns the path, or None if there were none."""
        if not self.rows:
            return None
        target = path or (self.job_folder / config.ERROR_FILE_NAME)
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh)
            writer.writerow(["When", "File", "Stage", "Problem", "Detail"])
            for r in self.rows:
                writer.writerow([r.when, r.file_name, r.stage, r.problem, r.detail])
        self.log.info("Error log written: %s (%d issue(s))", target, len(self.rows))
        return target


# ===========================================================================
#  5.  DUPLICATE DETECTION
# ===========================================================================
def file_hash(path: Path, chunk: int = config.HASH_CHUNK_BYTES) -> str:
    """
    A file's fingerprint (SHA-256).

    Two files with the same fingerprint are byte-for-byte identical, even if
    somebody renamed one of them "Annexure_E4B_FINAL_v2.pdf".
    We read the file in 1 MB slices so a 200 MB PDF never fills the memory.
    """
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


class DuplicateRegistry:
    """Remembers every fingerprint seen in this run."""

    def __init__(self) -> None:
        self._seen: dict[str, Path] = {}

    def check(self, path: Path) -> tuple[bool, Path | None]:
        """
        Returns (is_duplicate, original_path).

        The FIRST copy is always accepted; only later copies are flagged.
        """
        digest = file_hash(path)
        if digest in self._seen:
            return True, self._seen[digest]
        self._seen[digest] = path
        return False, None

    def __len__(self) -> int:
        return len(self._seen)


# ===========================================================================
#  6.  CANCEL BUTTON SUPPORT
# ===========================================================================
class CancelToken:
    """
    A polite stop signal.

    The GUI's Cancel button calls .cancel().  Long loops call .raise_if_cancelled()
    between files/pages, so the job stops at a SAFE point -- never mid-write.
    """

    class Cancelled(Exception):
        """Raised when the user has asked to stop."""

    def __init__(self) -> None:
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled

    def raise_if_cancelled(self) -> None:
        if self._cancelled:
            raise CancelToken.Cancelled("Job cancelled by user / उपयोगकर्ता द्वारा रद्द")


# ===========================================================================
#  7.  PROGRESS REPORTING
# ===========================================================================
class Progress:
    """
    Tiny progress reporter.

    In command-line mode it prints lines.  Later, the GUI will hand in its own
    `callback` so the same engine code drives the PyQt6 progress bar.
    """

    def __init__(self, total: int, callback=None, label: str = "Working") -> None:
        self.total = max(int(total), 1)
        self.done = 0
        self.callback = callback
        self.label = label
        self.started = time.time()

    def step(self, message: str = "") -> None:
        self.done += 1
        percent = min(int(self.done * 100 / self.total), 100)
        if self.callback:
            self.callback(percent, message)
        else:
            print(f"  [{percent:3d}%] {self.done}/{self.total}  {message}")

    def finish(self) -> str:
        elapsed = human_duration(time.time() - self.started)
        if self.callback:
            self.callback(100, f"Finished in {elapsed}")
        return elapsed


# ===========================================================================
#  8.  SELF-TEST  (run:  python -m app.common)
# ===========================================================================
if __name__ == "__main__":
    log = get_logger()
    ensure_dirs()
    log.info("%s v%s - plumbing self-test", config.APP_NAME, config.APP_VERSION)
    log.info("Root folder      : %s", config.APP_ROOT)
    log.info("Output folder    : %s", config.OUTPUT_DIR)
    log.info("Safe name test   : %s", safe_filename('TL-02: Bid <FINAL>?.pdf'))
    log.info("Size test        : %s", human_size(157_286_400))
    log.info("Duration test    : %s", human_duration(3725))
    errors = ErrorLog()
    errors.add("demo.pdf", "intake", "Demo problem row", "no real error")
    log.info("Error rows       : %d", errors.count)
    log.info("All plumbing OK.")
