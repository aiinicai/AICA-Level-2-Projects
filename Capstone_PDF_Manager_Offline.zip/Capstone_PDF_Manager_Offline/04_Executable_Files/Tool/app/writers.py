"""
writers.py
==========
STEP 5c - painting one report description into four formats.

    write_word(report, folder)   ->  .docx   editable, tables shaded
    write_pptx(report, folder)   ->  .pptx   one slide per section
    write_html(report, folder)   ->  .html   opens in any browser, prints well
    write_pdf(report, folder)    ->  .pdf    fixed layout, for the file

The same colours are used in all four, taken from config.HIGHLIGHT_STYLES,
so a red cell in Word is the same red cell in the slide deck.

Charts are drawn once with matplotlib and reused by every writer.
"""

from __future__ import annotations

import base64
import html as html_module
import re
from pathlib import Path

from . import common, config
from .analysis import Chart, Report, Table

log = common.get_logger("writers")


# ===========================================================================
#  0.  SHARED HELPERS
# ===========================================================================
def _hex(colour: str) -> str:
    """'#FFC7CE' -> 'FFC7CE'."""
    return colour.lstrip("#").upper()


def _style_for(key: str | None) -> dict | None:
    if not key:
        return None
    return config.HIGHLIGHT_STYLES.get(key)


def draw_chart(chart: Chart, folder: Path, name: str) -> Path | None:
    """Draw one chart to a PNG. Returns None if matplotlib is unavailable."""
    try:
        import matplotlib
        matplotlib.use("Agg")               # no screen needed
        import matplotlib.pyplot as plt
    except ImportError:                     # pragma: no cover
        log.warning("matplotlib not installed - charts skipped")
        return None

    if not chart.labels or not chart.values:
        return None

    height = max(2.2, 0.42 * len(chart.labels) + 1.1)
    figure, axis = plt.subplots(figsize=(8.2, height), dpi=140)

    colour = _hex(config.HIGHLIGHT_STYLES["money"]["font"])
    if chart.horizontal:
        positions = range(len(chart.labels))
        axis.barh(list(positions), chart.values, color=f"#{colour}", height=0.55)
        axis.set_yticks(list(positions))
        axis.set_yticklabels(chart.labels, fontsize=8)
        axis.invert_yaxis()
        axis.set_xlabel(chart.unit, fontsize=8)
        for position, value in zip(positions, chart.values):
            axis.text(value, position, f"  {value:,.2f}",
                      va="center", fontsize=7.5)
    else:
        axis.bar(chart.labels, chart.values, color=f"#{colour}")
        axis.set_ylabel(chart.unit, fontsize=8)
        plt.xticks(rotation=30, ha="right", fontsize=8)

    axis.set_title(chart.title, fontsize=10, fontweight="bold")
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="x" if chart.horizontal else "y", alpha=0.25)
    figure.tight_layout()

    target = folder / f"{common.safe_filename(name)}.png"
    figure.savefig(target, bbox_inches="tight")
    plt.close(figure)
    return target


def _chart_images(report: Report, folder: Path) -> dict[int, Path]:
    """Draw every chart once, keyed by id() so all writers share them."""
    images: dict[int, Path] = {}
    charts_folder = folder / "_charts"
    charts_folder.mkdir(parents=True, exist_ok=True)
    counter = 0
    for section in report.sections:
        for chart in section.charts:
            counter += 1
            path = draw_chart(chart, charts_folder, f"chart_{counter:02d}")
            if path:
                images[id(chart)] = path
    return images


# ===========================================================================
#  1.  WORD
# ===========================================================================
def write_word(report: Report, folder: Path,
               images: dict[int, Path] | None = None) -> Path:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches, Pt, RGBColor

    images = images if images is not None else _chart_images(report, folder)
    document = Document()

    def shade(cell, colour_hex: str) -> None:
        """Word has no simple API for cell colour, so we set the XML directly."""
        element = OxmlElement("w:shd")
        element.set(qn("w:val"), "clear")
        element.set(qn("w:color"), "auto")
        element.set(qn("w:fill"), colour_hex)
        cell._tc.get_or_add_tcPr().append(element)

    # -- cover -------------------------------------------------------------
    heading = document.add_heading(report.title, level=0)
    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if report.subtitle:
        paragraph = document.add_paragraph(report.subtitle)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.runs[0].italic = True
    footer = document.add_paragraph(
        f"{config.APP_NAME} v{config.APP_VERSION}  |  {config.APP_OWNER}  |  "
        f"Generated {report.generated}")
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.runs[0].font.size = Pt(8)
    footer.runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    document.add_paragraph()

    # -- sections ----------------------------------------------------------
    for section in report.sections:
        document.add_heading(section.heading, level=1)

        for text in section.paragraphs:
            document.add_paragraph(text)

        for table_data in section.tables:
            document.add_heading(table_data.title, level=2)
            table = document.add_table(rows=1, cols=len(table_data.headers))
            table.style = "Table Grid"

            for index, header in enumerate(table_data.headers):
                cell = table.rows[0].cells[index]
                cell.text = header
                shade(cell, "1F4E79")
                for run in cell.paragraphs[0].runs:
                    run.font.bold = True
                    run.font.size = Pt(9)
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

            for row_cells in table_data.rows:
                row = table.add_row()
                for index, cell_data in enumerate(row_cells):
                    if index >= len(table_data.headers):
                        break
                    cell = row.cells[index]
                    cell.text = str(cell_data.text)
                    style = _style_for(cell_data.style)
                    if style:
                        shade(cell, _hex(style["fill"]))
                        for run in cell.paragraphs[0].runs:
                            run.font.bold = style["bold"]
                            run.font.color.rgb = RGBColor.from_string(
                                _hex(style["font"]))
                    for run in cell.paragraphs[0].runs:
                        run.font.size = Pt(8.5)

            if table_data.note:
                note = document.add_paragraph(table_data.note)
                note.runs[0].font.size = Pt(8)
                note.runs[0].italic = True

        for chart in section.charts:
            image = images.get(id(chart))
            if image and image.exists():
                document.add_picture(str(image), width=Inches(6.2))
                caption = document.add_paragraph(chart.title)
                caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
                caption.runs[0].font.size = Pt(8)
                caption.runs[0].italic = True

    # -- colour legend -----------------------------------------------------
    document.add_page_break()
    document.add_heading("Colour key / रंग संकेत", level=1)
    legend = document.add_table(rows=1, cols=2)
    legend.style = "Table Grid"
    legend.rows[0].cells[0].text = "Colour"
    legend.rows[0].cells[1].text = "Meaning"
    for style in config.HIGHLIGHT_STYLES.values():
        row = legend.add_row()
        row.cells[0].text = "  "
        shade(row.cells[0], _hex(style["fill"]))
        row.cells[1].text = style["label"]

    target = folder / f"{common.safe_filename(report.title)}.docx"
    document.save(str(target))
    log.info("Word written: %s", target.name)
    return target


# ===========================================================================
#  2.  POWERPOINT
# ===========================================================================
def write_pptx(report: Report, folder: Path,
               images: dict[int, Path] | None = None) -> Path:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.util import Inches, Pt

    images = images if images is not None else _chart_images(report, folder)
    deck = Presentation()
    deck.slide_width = Inches(13.333)          # widescreen
    deck.slide_height = Inches(7.5)

    blank = deck.slide_layouts[6]
    title_layout = deck.slide_layouts[0]
    title_and_content = deck.slide_layouts[5]

    def add_title(slide, text: str) -> None:
        slide.shapes.title.text = text
        slide.shapes.title.text_frame.paragraphs[0].runs[0].font.size = Pt(28)

    # -- cover slide -------------------------------------------------------
    slide = deck.slides.add_slide(title_layout)
    slide.shapes.title.text = report.title
    slide.placeholders[1].text = (
        f"{report.subtitle}\n{config.APP_OWNER}  |  {report.generated}")

    # -- content slides ----------------------------------------------------
    for section in report.sections:
        if section.paragraphs:
            slide = deck.slides.add_slide(title_and_content)
            add_title(slide, section.heading)
            box = slide.shapes.add_textbox(Inches(0.7), Inches(1.6),
                                           Inches(11.9), Inches(4.5))
            frame = box.text_frame
            frame.word_wrap = True
            for index, text in enumerate(section.paragraphs):
                paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
                paragraph.text = text
                paragraph.font.size = Pt(15)

        for table_data in section.tables:
            # Long tables are split across slides so nothing is squashed
            per_slide = 11
            chunks = [table_data.rows[i:i + per_slide]
                      for i in range(0, len(table_data.rows), per_slide)] or [[]]

            for part, chunk in enumerate(chunks, start=1):
                slide = deck.slides.add_slide(title_and_content)
                suffix = f" ({part}/{len(chunks)})" if len(chunks) > 1 else ""
                add_title(slide, f"{table_data.title}{suffix}")

                columns = len(table_data.headers)
                shape = slide.shapes.add_table(
                    len(chunk) + 1, columns,
                    Inches(0.45), Inches(1.5),
                    Inches(12.4), Inches(0.4 * (len(chunk) + 1)))
                table = shape.table

                for index, header in enumerate(table_data.headers):
                    cell = table.cell(0, index)
                    cell.text = header
                    paragraph = cell.text_frame.paragraphs[0]
                    paragraph.font.size = Pt(11)
                    paragraph.font.bold = True

                for row_index, row_cells in enumerate(chunk, start=1):
                    for column_index in range(columns):
                        cell = table.cell(row_index, column_index)
                        if column_index < len(row_cells):
                            data = row_cells[column_index]
                            cell.text = str(data.text)[:160]
                            style = _style_for(data.style)
                            if style:
                                cell.fill.solid()
                                cell.fill.fore_color.rgb = RGBColor.from_string(
                                    _hex(style["fill"]))
                        paragraph = cell.text_frame.paragraphs[0]
                        paragraph.font.size = Pt(10)

        for chart in section.charts:
            image = images.get(id(chart))
            if image and image.exists():
                slide = deck.slides.add_slide(title_and_content)
                add_title(slide, chart.title)
                slide.shapes.add_picture(str(image), Inches(1.4), Inches(1.5),
                                         width=Inches(10.5))

    # -- legend slide ------------------------------------------------------
    slide = deck.slides.add_slide(blank)
    box = slide.shapes.add_textbox(Inches(0.8), Inches(0.6),
                                   Inches(11.5), Inches(6))
    frame = box.text_frame
    frame.text = "Colour key / रंग संकेत"
    frame.paragraphs[0].font.size = Pt(26)
    frame.paragraphs[0].font.bold = True
    for style in config.HIGHLIGHT_STYLES.values():
        paragraph = frame.add_paragraph()
        paragraph.text = f"■  {style['label']}"
        paragraph.font.size = Pt(16)
        paragraph.font.color.rgb = RGBColor.from_string(_hex(style["font"]))

    target = folder / f"{common.safe_filename(report.title)}.pptx"
    deck.save(str(target))
    log.info("PowerPoint written: %s", target.name)
    return target


# ===========================================================================
#  3.  HTML
# ===========================================================================
def _table_html(table: Table) -> str:
    parts = [f'<h3>{html_module.escape(table.title)}</h3>', "<table>", "<thead><tr>"]
    for header in table.headers:
        parts.append(f"<th>{html_module.escape(header)}</th>")
    parts.append("</tr></thead><tbody>")

    for row in table.rows:
        parts.append("<tr>")
        for cell in row:
            style = _style_for(cell.style)
            attribute = ""
            if style:
                weight = "700" if style["bold"] else "400"
                attribute = (f' style="background:{style["fill"]};'
                             f'color:{style["font"]};font-weight:{weight}"')
            parts.append(f"<td{attribute}>{html_module.escape(str(cell.text))}</td>")
        parts.append("</tr>")

    parts.append("</tbody></table>")
    if table.note:
        parts.append(f'<p class="note">{html_module.escape(table.note)}</p>')
    return "\n".join(parts)


def write_html(report: Report, folder: Path,
               images: dict[int, Path] | None = None) -> Path:
    """One self-contained file: charts are embedded, so it can be emailed."""
    images = images if images is not None else _chart_images(report, folder)

    body: list[str] = []
    for section in report.sections:
        body.append(f"<h2>{html_module.escape(section.heading)}</h2>")
        for text in section.paragraphs:
            body.append(f"<p>{html_module.escape(text)}</p>")
        for table in section.tables:
            body.append(_table_html(table))
        for chart in section.charts:
            image = images.get(id(chart))
            if image and image.exists():
                encoded = base64.b64encode(image.read_bytes()).decode("ascii")
                body.append(
                    f'<div class="chart"><img alt="{html_module.escape(chart.title)}" '
                    f'src="data:image/png;base64,{encoded}"></div>')

    legend_rows = "".join(
        f'<tr><td style="background:{style["fill"]};width:70px">&nbsp;</td>'
        f'<td>{html_module.escape(style["label"])}</td></tr>'
        for style in config.HIGHLIGHT_STYLES.values())

    document = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>{html_module.escape(report.title)}</title>
<style>
 body {{ font-family: "Segoe UI", Arial, sans-serif; margin: 28px auto;
        max-width: 1120px; color: #222; line-height: 1.55; }}
 h1 {{ color:#1F4E79; border-bottom:3px solid #1F4E79; padding-bottom:8px; }}
 h2 {{ color:#1F4E79; margin-top:34px; }}
 h3 {{ color:#333; font-size:1.02em; margin-bottom:6px; }}
 .sub {{ color:#666; font-style:italic; margin-top:-6px; }}
 .meta {{ color:#888; font-size:0.83em; }}
 table {{ border-collapse:collapse; width:100%; margin:10px 0 18px;
          font-size:0.87em; }}
 th {{ background:#1F4E79; color:#fff; padding:8px; text-align:left; }}
 td {{ border:1px solid #D6D6D6; padding:6px 8px; vertical-align:top; }}
 tr:nth-child(even) td {{ background-color:#FAFAFA; }}
 td[style] {{ background-image:none; }}
 .note {{ font-size:0.8em; color:#666; font-style:italic; margin-top:-12px; }}
 .chart {{ text-align:center; margin:18px 0; }}
 .chart img {{ max-width:100%; border:1px solid #E4E4E4; border-radius:4px; }}
 @media print {{ body {{ margin:0; }} h2 {{ page-break-after:avoid; }}
                 table {{ page-break-inside:avoid; }} }}
</style></head><body>
<h1>{html_module.escape(report.title)}</h1>
<p class="sub">{html_module.escape(report.subtitle)}</p>
<p class="meta">{config.APP_NAME} v{config.APP_VERSION} &nbsp;|&nbsp;
{config.APP_OWNER} &nbsp;|&nbsp; Generated {report.generated}</p>
{"".join(body)}
<h2>Colour key / रंग संकेत</h2>
<table><tbody>{legend_rows}</tbody></table>
</body></html>"""

    target = folder / f"{common.safe_filename(report.title)}.html"
    target.write_text(document, encoding="utf-8")
    log.info("HTML written: %s", target.name)
    return target


# ===========================================================================
#  4.  PDF
# ===========================================================================
def write_pdf(report: Report, folder: Path,
              images: dict[int, Path] | None = None) -> Path:
    """
    Build the PDF directly with PyMuPDF.

    We draw it ourselves rather than converting the HTML, because that keeps
    the result predictable on a locked-down machine with no extra software.
    """
    try:
        import pymupdf as fitz
    except ImportError:                                # pragma: no cover
        import fitz

    images = images if images is not None else _chart_images(report, folder)

    # -- Devanagari support -------------------------------------------------
    # PDF built-in fonts have no Hindi letters, so Hindi would print as dots.
    # Windows already ships "Nirmala UI", which covers Devanagari, so we use
    # it when present.  If it is missing, we quietly drop the Hindi half of a
    # bilingual heading rather than printing rubbish.
    devanagari_font: str | None = None
    for candidate in (Path("C:/Windows/Fonts/Nirmala.ttf"),
                      Path("C:/Windows/Fonts/mangal.ttf"),
                      config.MODELS_DIR / "fonts" / "NotoSansDevanagari-Regular.ttf"):
        if candidate.exists():
            devanagari_font = str(candidate)
            log.info("Hindi font for PDF: %s", candidate.name)
            break
    if devanagari_font is None:
        log.info("No Devanagari font found - Hindi text omitted from the PDF only")

    has_devanagari = re.compile(r"[\u0900-\u097F]")

    def pdf_text(value: str) -> str:
        """Make a string safe for the PDF font we actually have."""
        if devanagari_font or not has_devanagari.search(value):
            return value
        # "1. Overview / अवलोकन" -> "1. Overview"
        cleaned = re.split(r"\s*/\s*", value)
        keep = [part for part in cleaned if not has_devanagari.search(part)]
        return " / ".join(keep).strip() or has_devanagari.sub("", value).strip()

    PAGE_W, PAGE_H = 595, 842                # A4 portrait, in points
    MARGIN = 42
    doc = fitz.open()
    state = {"page": None, "y": 0.0}

    def font_for(content: str, bold: bool) -> str:
        """Pick the Hindi font when the text needs it."""
        if devanagari_font and has_devanagari.search(content):
            return "deva"
        return "hebo" if bold else "helv"

    def new_page():
        page = doc.new_page(width=PAGE_W, height=PAGE_H)
        if devanagari_font:
            page.insert_font(fontname="deva", fontfile=devanagari_font)
        state["page"] = page
        state["y"] = MARGIN
        return page

    def space(needed: float):
        if state["page"] is None or state["y"] + needed > PAGE_H - MARGIN:
            new_page()

    def text(content: str, size: float = 9, colour=(0, 0, 0),
             bold: bool = False, gap: float = 4):
        content = pdf_text(str(content))
        font = font_for(content, bold)
        width = PAGE_W - 2 * MARGIN
        for line in _wrap(content, width, size, font):
            space(size + gap)
            state["page"].insert_text((MARGIN, state["y"] + size), line,
                                      fontname=font, fontsize=size, color=colour)
            state["y"] += size + gap

    def _wrap(content: str, width: float, size: float, font: str) -> list[str]:
        if font == "deva":
            font = "helv"          # measuring only; close enough for wrapping
        lines, current = [], ""
        for word in str(content).split():
            trial = f"{current} {word}".strip()
            if fitz.get_text_length(trial, fontname=font, fontsize=size) > width:
                if current:
                    lines.append(current)
                current = word
            else:
                current = trial
        lines.append(current)
        return lines or [""]

    # -- cover -------------------------------------------------------------
    new_page()
    state["y"] = 180
    text(report.title, size=22, bold=True, colour=(0.12, 0.31, 0.47), gap=10)
    text(report.subtitle, size=11, colour=(0.35, 0.35, 0.35), gap=8)
    text(f"{config.APP_NAME} v{config.APP_VERSION}  |  {config.APP_OWNER}",
         size=8.5, colour=(0.5, 0.5, 0.5))
    text(f"Generated {report.generated}", size=8.5, colour=(0.5, 0.5, 0.5))

    # -- sections ----------------------------------------------------------
    for section in report.sections:
        new_page()
        text(section.heading, size=14, bold=True, colour=(0.12, 0.31, 0.47), gap=9)

        for paragraph in section.paragraphs:
            text(paragraph, size=9, gap=4)
            state["y"] += 5

        for table in section.tables:
            state["y"] += 8
            text(table.title, size=10.5, bold=True, gap=6)

            columns = len(table.headers)
            usable = PAGE_W - 2 * MARGIN
            col_width = usable / columns
            row_height = 15

            def header_row():
                space(row_height + 4)
                y = state["y"]
                state["page"].draw_rect(
                    fitz.Rect(MARGIN, y, PAGE_W - MARGIN, y + row_height),
                    color=None, fill=(0.12, 0.31, 0.47))
                for index, header in enumerate(table.headers):
                    label = pdf_text(str(header))[:int(col_width / 4.4)]
                    state["page"].insert_text(
                        (MARGIN + index * col_width + 3, y + 10.5), label,
                        fontname=font_for(label, True),
                        fontsize=7.4, color=(1, 1, 1))
                state["y"] += row_height

            header_row()
            for row in table.rows:
                if state["y"] + row_height > PAGE_H - MARGIN:
                    new_page()
                    header_row()
                y = state["y"]
                for index in range(columns):
                    cell = row[index] if index < len(row) else None
                    rect = fitz.Rect(MARGIN + index * col_width, y,
                                     MARGIN + (index + 1) * col_width,
                                     y + row_height)
                    style = _style_for(cell.style) if cell else None
                    if style:
                        fill = tuple(int(_hex(style["fill"])[i:i + 2], 16) / 255
                                     for i in (0, 2, 4))
                        state["page"].draw_rect(rect, color=(0.85, 0.85, 0.85),
                                                fill=fill, width=0.4)
                    else:
                        state["page"].draw_rect(rect, color=(0.85, 0.85, 0.85),
                                                width=0.4)
                    if cell:
                        colour = (0, 0, 0)
                        if style:
                            colour = tuple(int(_hex(style["font"])[i:i + 2], 16) / 255
                                           for i in (0, 2, 4))
                        value = pdf_text(str(cell.text))[:int(col_width / 4.2)]
                        state["page"].insert_text(
                            (rect.x0 + 3, y + 10.5), value,
                            fontname=font_for(value, bool(style and style["bold"])),
                            fontsize=7.2, color=colour)
                state["y"] += row_height

            if table.note:
                state["y"] += 4
                text(table.note, size=7.5, colour=(0.42, 0.42, 0.42), gap=3)

        for chart in section.charts:
            image = images.get(id(chart))
            if image and image.exists():
                pixmap = fitz.Pixmap(str(image))
                width = PAGE_W - 2 * MARGIN
                height = width * pixmap.height / pixmap.width
                space(height + 14)
                state["page"].insert_image(
                    fitz.Rect(MARGIN, state["y"], MARGIN + width,
                              state["y"] + height), filename=str(image))
                state["y"] += height + 12

    # -- legend ------------------------------------------------------------
    new_page()
    text("Colour key / रंग संकेत", size=14, bold=True,
         colour=(0.12, 0.31, 0.47), gap=10)
    for style in config.HIGHLIGHT_STYLES.values():
        space(20)
        y = state["y"]
        fill = tuple(int(_hex(style["fill"])[i:i + 2], 16) / 255 for i in (0, 2, 4))
        state["page"].draw_rect(fitz.Rect(MARGIN, y, MARGIN + 48, y + 13),
                                color=(0.8, 0.8, 0.8), fill=fill, width=0.4)
        label = pdf_text(style["label"])
        state["page"].insert_text((MARGIN + 58, y + 10), label,
                                  fontname=font_for(label, False), fontsize=9)
        state["y"] += 19

    target = folder / f"{common.safe_filename(report.title)}.pdf"
    doc.save(str(target), garbage=4, deflate=True)
    doc.close()
    log.info("PDF written: %s", target.name)
    return target


# ===========================================================================
#  5.  ALL FOUR AT ONCE
# ===========================================================================
def write_all(report: Report, folder: Path,
              formats: tuple[str, ...] = ("word", "pptx", "html", "pdf")
              ) -> dict[str, Path]:
    """Draw the charts once, then produce every format you asked for."""
    folder.mkdir(parents=True, exist_ok=True)
    images = _chart_images(report, folder)
    writers = {"word": write_word, "pptx": write_pptx,
               "html": write_html, "pdf": write_pdf}

    produced: dict[str, Path] = {}
    for name in formats:
        writer = writers.get(name)
        if not writer:
            continue
        try:
            produced[name] = writer(report, folder, images)
        except Exception as exc:                       # noqa: BLE001
            log.warning("%s failed: %s", name, exc)
    return produced
