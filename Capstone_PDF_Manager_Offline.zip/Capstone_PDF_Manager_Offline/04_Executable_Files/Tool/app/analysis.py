"""
analysis.py
===========
STEP 5b - turning raw page text into the three reports you asked for.

    1. DOCUMENT DIGEST   per file: pages, how it was read, key figures found,
                         and every flagged word, with counts
    2. BID COMPARISON    one row per bidder, with MAAT / Net Worth /
                         Liquid Assets / Turnover side by side
    3. SEARCH FINDINGS   a formal write-up of what a search turned up

A "Report" here is just a description of what should appear -- headings,
tables, charts.  It knows nothing about Word or PowerPoint.  writers.py then
paints that same description into any format.  One analysis, four documents.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import common, config, highlight

log = common.get_logger("analysis")


# ===========================================================================
#  1.  THE SHAPE OF A REPORT
# ===========================================================================
@dataclass
class Cell:
    """One box in a table. `style` is a colour key from config."""
    text: str
    style: str | None = None


@dataclass
class Table:
    title: str
    headers: list[str]
    rows: list[list[Cell]] = field(default_factory=list)
    note: str = ""


@dataclass
class Chart:
    title: str
    labels: list[str]
    values: list[float]
    unit: str = ""
    horizontal: bool = True


@dataclass
class Section:
    heading: str
    paragraphs: list[str] = field(default_factory=list)
    tables: list[Table] = field(default_factory=list)
    charts: list[Chart] = field(default_factory=list)


@dataclass
class Report:
    title: str
    subtitle: str = ""
    sections: list[Section] = field(default_factory=list)
    generated: str = field(
        default_factory=lambda: datetime.now().strftime("%d-%b-%Y %H:%M"))

    def add(self, section: Section) -> Section:
        self.sections.append(section)
        return section


# ===========================================================================
#  2.  FINDING FINANCIAL FIGURES
# ===========================================================================
# The labels an Indian bid document actually uses, with their variations.
FIGURE_LABELS: dict[str, list[str]] = {
    "MAAT": ["MAAT", "maximum annual average turnover",
             "annual average turnover"],
    "Net Worth": ["net worth", "networth", "net-worth"],
    "Liquid Assets": ["liquid assets", "liquid asset"],
    "Turnover": ["turnover", "revenue from operations"],
}

# A number that may carry a unit: 4,523.75 Cr / 812.50 lakh / 1,23,456
_NUMBER = r"(\d{1,3}(?:[,\d]{0,15})(?:\.\d{1,4})?)"
_UNIT = r"\s*(Cr\.?|Crores?|Lakhs?|Lacs?)?"


def _to_crore(number_text: str, unit: str | None) -> float | None:
    """Bring every figure onto one scale (₹ crore), so they can be compared."""
    try:
        value = float(number_text.replace(",", ""))
    except ValueError:
        return None
    unit = (unit or "").lower().rstrip(".")
    if unit.startswith("lakh") or unit.startswith("lac"):
        return round(value / 100.0, 4)
    return round(value, 4)          # crore, or already in crore


@dataclass
class Figure:
    label: str
    raw: str
    crore: float | None
    page_no: int


def find_figures(text: str, page_no: int = 0) -> list[Figure]:
    """
    Look for '<label> ... <number> <unit>' anywhere in a page of text.

    We allow a little noise between the label and the number, because scanned
    tables insert colons, dots and stray spaces.

    IMPORTANT SAFETY RULE
    ---------------------
    A bare whole number is REJECTED unless it carries a unit (Cr, lakh).
    Without this, a line like "Turnover statement ... Original page 4 of 4"
    would be read as a turnover of 4 crore.  A genuine financial figure
    almost always has a decimal point, a comma, or a unit beside it.
    """
    body = text or ""
    found: list[Figure] = []

    for label, variants in FIGURE_LABELS.items():
        if any(item.label == label for item in found):
            continue                     # already located under another spelling

        for variant in variants:
            pattern = re.compile(
                re.escape(variant) + r"[^0-9\n]{0,30}?" + _NUMBER + _UNIT,
                re.IGNORECASE)
            matched = False

            for match in pattern.finditer(body):
                number_text, unit = match.group(1), match.group(2)
                looks_financial = bool(unit) or "." in number_text or "," in number_text
                if not looks_financial:
                    continue             # a stray page number, not money

                crore = _to_crore(number_text, unit)
                if crore is None:
                    continue

                # An accountant writes a loss as (1,180.25) or -1,180.25.
                # Reading that as POSITIVE would be the worst possible error
                # in a qualification check, so we look at the character
                # immediately before the number and negate when required.
                start = match.start(1)
                preceding = body[max(start - 2, 0):start].strip()
                closing = body[match.end(1):match.end(1) + 3]
                if preceding.endswith("(") and ")" in closing:
                    crore = -abs(crore)
                elif preceding.endswith("-"):
                    crore = -abs(crore)

                found.append(Figure(label, match.group(0).strip(),
                                    crore, page_no))
                matched = True
                break                    # first clean hit per variant is enough

            if matched:
                break                    # stop trying other spellings

    return found


# ===========================================================================
#  3.  READING THE INDEX
# ===========================================================================
@dataclass
class FileFacts:
    """Everything we know about one indexed document."""
    name: str
    path: str
    pages: int = 0
    engine: str = "none"
    native_chars: int = 0
    ocr_chars: int = 0
    figures: list[Figure] = field(default_factory=list)
    flag_counts: dict[str, int] = field(default_factory=dict)
    flagged_words: dict[str, int] = field(default_factory=dict)

    @property
    def read_how(self) -> str:
        if self.native_chars and self.ocr_chars:
            return "Text + OCR"
        if self.ocr_chars:
            return "OCR only (scan)"
        if self.native_chars:
            return "Text only"
        return "Nothing readable"

    def figure(self, label: str) -> Figure | None:
        for item in self.figures:
            if item.label == label:
                return item
        return None


def gather_facts(index, highlighter: highlight.Highlighter | None = None
                 ) -> list[FileFacts]:
    """Walk the whole index once and work out the facts for every file."""
    highlighter = highlighter or highlight.Highlighter()
    facts: dict[str, FileFacts] = {}

    rows = index.conn.execute("""
        SELECT f.name, f.path, f.pages, f.engine,
               p.page_no, p.native_text, p.ocr_text
        FROM pages p JOIN files f ON f.id = p.file_id
        ORDER BY f.name, p.page_no
    """)

    for row in rows:
        record = facts.setdefault(row["path"], FileFacts(
            name=row["name"], path=row["path"],
            pages=row["pages"], engine=row["engine"]))

        native = row["native_text"] or ""
        ocr = row["ocr_text"] or ""
        record.native_chars += len(native)
        record.ocr_chars += len(ocr)

        page_text = f"{native}\n{ocr}".strip()
        if not page_text:
            continue

        for figure in find_figures(page_text, row["page_no"]):
            if not record.figure(figure.label):
                record.figures.append(figure)

        for flag in highlighter.scan(page_text):
            record.flag_counts[flag.category] = \
                record.flag_counts.get(flag.category, 0) + 1
            if flag.category in ("critical", "warning", "keyword"):
                key = flag.text.strip()[:40]
                record.flagged_words[key] = record.flagged_words.get(key, 0) + 1

    return sorted(facts.values(), key=lambda f: f.name)


# ===========================================================================
#  4.  REPORT 1 - DOCUMENT DIGEST
# ===========================================================================
def build_digest(facts: list[FileFacts],
                 highlighter: highlight.Highlighter) -> Report:
    report = Report(
        title="Document Digest",
        subtitle="What each document contains, and what needs your attention")

    # -- overview ----------------------------------------------------------
    overview = report.add(Section("1. Overview / अवलोकन"))
    total_pages = sum(f.pages for f in facts)
    scanned = sum(1 for f in facts if f.read_how.startswith("OCR"))
    overview.paragraphs.append(
        f"{len(facts)} document(s) were read, covering {total_pages} page(s). "
        f"{scanned} of them were scans that needed OCR. "
        f"Everything below comes from the text actually found inside them.")

    table = Table("Documents read",
                  ["Document", "Pages", "How it was read", "Engine",
                   "Critical", "Warning", "Watch words"])
    for item in facts:
        critical = item.flag_counts.get("critical", 0)
        warning = item.flag_counts.get("warning", 0)
        row_style = "critical" if critical else ("warning" if warning else "ok")
        table.rows.append([
            Cell(item.name),
            Cell(str(item.pages)),
            Cell(item.read_how),
            Cell(item.engine),
            Cell(str(critical), "critical" if critical else None),
            Cell(str(warning), "warning" if warning else None),
            Cell(str(item.flag_counts.get("keyword", 0)), row_style),
        ])
    overview.tables.append(table)

    # -- figures -----------------------------------------------------------
    figures_section = report.add(Section("2. Key figures found / मुख्य आंकड़े"))
    figures_section.paragraphs.append(
        "Figures are shown exactly as they appear in the document, and also "
        "converted to a single scale (₹ crore) so they can be compared. "
        "Please verify against the source before relying on any number.")

    figure_table = Table("Financial figures picked up",
                         ["Document"] + list(FIGURE_LABELS))
    for item in facts:
        row = [Cell(item.name)]
        for label in FIGURE_LABELS:
            figure = item.figure(label)
            if figure and figure.crore is not None:
                row.append(Cell(f"{figure.crore:,.2f} Cr (p{figure.page_no})",
                                "money"))
            else:
                row.append(Cell("not found", "warning"))
        figure_table.rows.append(row)
    figure_table.note = ("'not found' means the label was not seen in the text. "
                         "For scans, check the OCR quality before concluding.")
    figures_section.tables.append(figure_table)

    # -- flagged words -----------------------------------------------------
    flags_section = report.add(Section("3. Words that need attention / ध्यान देने योग्य"))
    flag_table = Table("Flagged words, by document",
                       ["Document", "Word or phrase", "Times seen"])
    any_flags = False
    for item in facts:
        for word, count in sorted(item.flagged_words.items(),
                                  key=lambda x: -x[1])[:12]:
            category = highlighter.classify(word) or "keyword"
            flag_table.rows.append([Cell(item.name), Cell(word, category),
                                    Cell(str(count))])
            any_flags = True
    if not any_flags:
        flag_table.rows.append([Cell("-"), Cell("Nothing flagged", "ok"), Cell("0")])
    flags_section.tables.append(flag_table)

    if any(f.flag_counts.get("keyword") for f in facts):
        flags_section.charts.append(Chart(
            "Watch words per document",
            [f.name[:26] for f in facts],
            [float(f.flag_counts.get("keyword", 0)) for f in facts],
            unit="mentions"))

    return report


# ===========================================================================
#  5.  REPORT 2 - BID COMPARISON
# ===========================================================================
def build_comparison(facts: list[FileFacts]) -> Report:
    report = Report(
        title="Bid Comparison",
        subtitle="Financial figures of each bidder, side by side")

    intro = report.add(Section("1. How to read this / इसे कैसे पढ़ें"))
    intro.paragraphs.append(
        "Each document is treated as one bidder. Figures were picked up "
        "automatically from the text and converted to ₹ crore. This is a "
        "first-cut working aid, not an evaluation: every figure must be "
        "verified against the audited statement before use.")

    labels = list(FIGURE_LABELS)
    table = Table("Bidder comparison (₹ crore)", ["Bidder"] + labels + ["Notes"])

    for item in facts:
        row = [Cell(item.name.replace(".pdf", ""))]
        missing = []
        for label in labels:
            figure = item.figure(label)
            if figure and figure.crore is not None:
                row.append(Cell(f"{figure.crore:,.2f}", "money"))
            else:
                row.append(Cell("-", "warning"))
                missing.append(label)
        if missing:
            row.append(Cell("Not found: " + ", ".join(missing), "warning"))
        else:
            row.append(Cell("All figures located", "ok"))
        table.rows.append(row)

    comparison = report.add(Section("2. Side by side / तुलना"))
    comparison.tables.append(table)

    # One chart per figure type, where we actually have numbers
    for label in labels:
        pairs = [(f.name.replace(".pdf", "")[:26], f.figure(label).crore)
                 for f in facts
                 if f.figure(label) and f.figure(label).crore is not None]
        if len(pairs) >= 2:
            comparison.charts.append(Chart(
                f"{label} by bidder", [p[0] for p in pairs],
                [p[1] for p in pairs], unit="₹ crore"))

    # -- gaps --------------------------------------------------------------
    gaps = report.add(Section("3. Where information is missing / अनुपलब्ध जानकारी"))
    gap_table = Table("Follow-up needed", ["Bidder", "Missing figure", "Suggested action"])
    for item in facts:
        for label in labels:
            if not item.figure(label):
                gap_table.rows.append([
                    Cell(item.name.replace(".pdf", "")),
                    Cell(label, "warning"),
                    Cell("Check the annexure, or the scan quality"),
                ])
    if not gap_table.rows:
        gap_table.rows.append([Cell("-"), Cell("Nothing missing", "ok"), Cell("-")])
    gaps.tables.append(gap_table)

    return report


# ===========================================================================
#  6.  REPORT 3 - SEARCH FINDINGS
# ===========================================================================
def build_findings(hits, terms: list[str],
                   highlighter: highlight.Highlighter) -> Report:
    report = Report(
        title="Search Findings",
        subtitle="Searched for: " + ", ".join(terms))

    by_term: dict[str, int] = {}
    by_file: dict[str, int] = {}
    by_source = {"native": 0, "ocr": 0}
    for hit in hits:
        by_term[hit.term] = by_term.get(hit.term, 0) + 1
        by_file[hit.file_name] = by_file.get(hit.file_name, 0) + 1
        by_source[hit.source] = by_source.get(hit.source, 0) + 1

    summary = report.add(Section("1. Summary / सारांश"))
    summary.paragraphs.append(
        f"{len(hits)} mention(s) were found across {len(by_file)} document(s). "
        f"{by_source.get('native', 0)} came from text already inside the PDF, "
        f"and {by_source.get('ocr', 0)} were read from scanned pages by OCR.")

    term_table = Table("By search word", ["Word", "Times found", "Documents"])
    for term in terms:
        documents = len({h.file_name for h in hits if h.term == term})
        term_table.rows.append([
            Cell(term, "keyword"),
            Cell(str(by_term.get(term, 0)),
                 "ok" if by_term.get(term) else "warning"),
            Cell(str(documents)),
        ])
    summary.tables.append(term_table)

    if by_file:
        summary.charts.append(Chart(
            "Mentions per document",
            [name[:26] for name, _ in sorted(by_file.items(), key=lambda x: -x[1])[:12]],
            [float(count) for _, count in sorted(by_file.items(), key=lambda x: -x[1])[:12]],
            unit="mentions"))

    detail = report.add(Section("2. Every mention / प्रत्येक उल्लेख"))
    detail_table = Table("Where each word appears",
                         ["Document", "Page", "Word", "Source", "Text around it"])
    for hit in hits[:400]:                 # keep the document readable
        detail_table.rows.append([
            Cell(hit.file_name),
            Cell(str(hit.page_no)),
            Cell(hit.term, "keyword"),
            Cell("In PDF" if hit.source == "native" else "OCR"),
            Cell(hit.snippet, highlighter.classify(hit.snippet)),
        ])
    if len(hits) > 400:
        detail_table.note = (f"Showing the first 400 of {len(hits)} mentions. "
                             f"The Excel hit list contains all of them.")
    detail.tables.append(detail_table)

    return report
