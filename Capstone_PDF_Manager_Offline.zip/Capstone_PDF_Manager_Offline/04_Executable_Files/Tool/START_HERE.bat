@echo off
REM ==========================================================================
REM  PG Bid Toolkit - START HERE
REM
REM  Double-click this file whenever you want to use the toolkit.
REM
REM  It opens a command window that is ALREADY standing in the right folder
REM  with the right Python switched on.  From then on you simply type:
REM
REM       pgbt merge "file1.pdf" "file2.pdf"
REM
REM  ...instead of the long .venv\Scripts\python.exe run_cli.py wording.
REM ==========================================================================

cd /d "%~dp0"
color 0B
title PG Bid Toolkit - Command Window

if not exist ".venv\Scripts\python.exe" (
    color 0C
    echo.
    echo   X  .venv not found in this folder.
    echo      Please run setup_env.bat first.
    echo.
    pause & exit /b 1
)

REM "pgbt" becomes a short nickname for the long command, for this window only.
doskey pgbt=.venv\Scripts\python.exe run_cli.py $*

cls
echo.
echo  ================================================================
echo   PG BID TOOLKIT - ready.  You are standing in the right folder.
echo   %CD%
echo  ================================================================
echo.
echo   Type  pgbt  followed by what you want.  Examples:
echo.
echo     pgbt demo                          make practice files
echo     pgbt --help                        list every command
echo.
echo     pgbt intake "Demo_Files" -p demo123
echo     pgbt merge  "Demo_Files\A.pdf" "Demo_Files\B.pdf" --name TL02
echo     pgbt split  "Demo_Files\A.pdf" --every 2
echo     pgbt rotate "Demo_Files\A.pdf" --degrees 90
echo     pgbt reorder "Demo_Files\A.pdf" --order "3,1,2,4"
echo     pgbt crop   "Demo_Files\A.pdf" --top 20 --bottom 20
echo     pgbt compress "Demo_Files\Scanned_Statement.pdf" --level all
echo     pgbt stamp  "Demo_Files\A.pdf"
echo     pgbt retype "Demo_Files\B.pdf" --find "1,234" --replace "1,432"
echo.
echo   Results always appear in the  Output\  folder.
echo   Type  exit  to close this window.
echo.
echo  ----------------------------------------------------------------
echo.

cmd /k
