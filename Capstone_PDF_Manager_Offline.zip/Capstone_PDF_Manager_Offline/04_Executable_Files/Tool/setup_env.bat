@echo off
REM ==========================================================================
REM  PG Bid Toolkit - Environment Setup  v2
REM
REM  WHAT IS NEW IN v2
REM    * Shows your exact Python version before doing anything
REM    * Warns if the folder sits inside OneDrive (a common cause of failure)
REM    * Offers to delete a half-built .venv and start clean
REM    * Uses --only-binary=:all:  so pip NEVER tries to compile anything
REM      (this is the fix for the "Unable to find Visual Studio" error)
REM
REM  No administrator rights needed.  Just double-click.
REM ==========================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"
color 0B
title PG Bid Toolkit - Environment Setup v2

echo.
echo  ============================================================
echo   PG BID TOOLKIT  ^|  Setup v2  ^|  STEP 1 of 2
echo  ============================================================
echo   Folder: %CD%
echo.

REM ------------------------------------------------- 0. OneDrive path check
echo %CD% | find /i "OneDrive" >nul
if not errorlevel 1 (
    color 0E
    echo   !  WARNING: this folder is inside OneDrive.
    echo.
    echo      OneDrive keeps syncing thousands of small library files,
    echo      which can lock them mid-install and slow everything down.
    echo      The long folder name also risks Windows' 260-character limit.
    echo.
    echo      STRONGLY RECOMMENDED: move the whole PGBidToolkit folder to
    echo         C:\PGTools\PGBidToolkit
    echo      ...then run this file again from there.
    echo.
    set /p ONEDRIVE_GO="   Continue here anyway? (Y = yes, N = stop): "
    if /i not "!ONEDRIVE_GO!"=="Y" (
        echo   Stopped.  Please move the folder and try again.
        pause & exit /b 0
    )
    color 0B
)

REM ---------------------------------------------------------------- 1. Python
echo.
echo  [1/6] Looking for Python ...
set "PY_CMD="

REM 3.12 is the sweet spot - every library has a ready-made package for it.
py -3.12 --version >nul 2>&1 && set "PY_CMD=py -3.12"
if not defined PY_CMD ( py -3.11 --version >nul 2>&1 && set "PY_CMD=py -3.11" )
if not defined PY_CMD ( py -3.13 --version >nul 2>&1 && set "PY_CMD=py -3.13" )
if not defined PY_CMD ( py -3.10 --version >nul 2>&1 && set "PY_CMD=py -3.10" )
if not defined PY_CMD ( py        --version >nul 2>&1 && set "PY_CMD=py"      )
if not defined PY_CMD ( python    --version >nul 2>&1 && set "PY_CMD=python"  )

if not defined PY_CMD (
    color 0C
    echo   X  No Python found.
    echo      Install Python 3.12 from python.org and tick "Add python.exe to PATH".
    pause & exit /b 1
)

for /f "tokens=*" %%v in ('%PY_CMD% --version 2^>^&1') do set "PY_VER=%%v"
echo        Using : !PY_VER!   ^(command: %PY_CMD%^)
echo.
echo        All Pythons installed on this PC:
py -0 2>nul || echo        ^(py launcher not available - that is fine^)

REM ------------------------------------------------------------ 2. clean venv
echo.
echo  [2/6] Checking the private box  .venv  ...
if exist ".venv\Scripts\python.exe" (
    echo        An existing .venv was found.
    echo        If your last run FAILED, it is safest to rebuild it.
    set /p REBUILD="        Delete and rebuild .venv? (Y/N): "
    if /i "!REBUILD!"=="Y" (
        echo        Deleting old .venv ...
        rmdir /s /q ".venv"
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo        Creating .venv ...
    %PY_CMD% -m venv .venv
    if errorlevel 1 (
        color 0C
        echo   X  Could not create .venv
        echo      Tip: move this folder to C:\PGTools\PGBidToolkit and retry.
        pause & exit /b 1
    )
)
set "VPY=%CD%\.venv\Scripts\python.exe"
echo        Ready.

REM ------------------------------------------------------------- 3. clear cache
echo.
echo  [3/6] Clearing pip's memory of the failed download ...
"%VPY%" -m pip cache remove pymupdf >nul 2>&1
"%VPY%" -m pip cache remove PyMuPDF >nul 2>&1
echo        Done.

REM ------------------------------------------------------------------- 4. pip
echo.
echo  [4/6] Updating the installer ^(pip^) ...
"%VPY%" -m pip install --upgrade pip setuptools wheel --quiet
if errorlevel 1 echo        ^!  pip upgrade failed - continuing anyway.

REM ------------------------------------------------------- 5. core libraries
echo.
echo  [5/6] Installing core libraries ^(about 250 MB^) ...
echo        Mode: ready-made packages ONLY - nothing will be compiled.
echo        On a slow office network this takes 5-15 minutes. Please wait.
echo.
"%VPY%" -m pip install --only-binary=:all: --upgrade -r requirements.txt
if errorlevel 1 (
    color 0C
    echo.
    echo   X  Installation stopped.
    echo.
    echo      Read the LAST few red lines above:
    echo        - "Could not find a version that satisfies"  =^> your Python is
    echo          too new for one library. Install Python 3.12 and re-run.
    echo        - "pypi.org" / connection / proxy / SSL      =^> firewall.
    echo          Ask IT to allow: pypi.org  files.pythonhosted.org
    echo.
    pause & exit /b 1
)

REM ------------------------------------------------------------ 6. health check
echo.
echo  [6/6] Running health check ...
echo.
"%VPY%" check_setup.py

echo.
echo  ============================================================
echo   STEP 1 COMPLETE.
echo   OCR is not installed yet - that is a later step.
echo  ============================================================
echo.
pause
endlocal
