"""
MAKE_LAUNCHER.py
================
Just run me.  No commands, no arguments, no typing.

HOW TO USE
----------
    1. Put this file in  C:\\PGTools\\PGBidToolkit
    2. Double-click it   (a window called IDLE opens)
    3. Press the F5 key  (or menu: Run > Run Module)
    4. Read the message.  Done.

WHAT I DO
---------
I write a small file called START_HERE.bat into this folder, and another
copy onto your Desktop.

WHY THIS IS NEEDED
------------------
Windows Smart App Control refuses script files that were downloaded from
the internet.  A file created here, on your own PC, is not treated that
way.  So instead of you downloading the launcher, I build it for you.

I change no Windows setting, install nothing, and touch nothing else.
"""

import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# The contents of the launcher file.  Plain Windows commands, nothing clever.
# ---------------------------------------------------------------------------
LAUNCHER = r"""@echo off
REM  PG Bid Toolkit - START HERE
REM  Created on this PC by MAKE_LAUNCHER.py (not downloaded).

cd /d "{root}"
color 0B
title PG Bid Toolkit - Command Window

if not exist ".venv\Scripts\python.exe" (
    color 0C
    echo.
    echo   X  .venv not found.  Please run setup_env.bat first.
    echo.
    pause & exit /b 1
)

doskey pgbt=.venv\Scripts\python.exe run_cli.py $*

cls
echo.
echo  ================================================================
echo   PG BID TOOLKIT - ready.  You are in the right folder.
echo   %CD%
echo  ================================================================
echo.
echo   Type  pgbt  followed by what you want.  Examples:
echo.
echo     pgbt demo                        make practice files
echo     pgbt --help                      list every command
echo.
echo     pgbt intake "Demo_Files" -p demo123
echo     pgbt merge "Demo_Files\Bidder_A_Annexure_E4B.pdf" "Demo_Files\Bidder_B_Balance_Sheet.pdf" --name TL02
echo     pgbt split "Demo_Files\Bidder_A_Annexure_E4B.pdf" --every 2
echo     pgbt rotate "Demo_Files\Bidder_A_Annexure_E4B.pdf" --degrees 90
echo     pgbt reorder "Demo_Files\Bidder_A_Annexure_E4B.pdf" --order "3,1,2,4"
echo     pgbt crop "Demo_Files\Bidder_A_Annexure_E4B.pdf" --top 20 --bottom 20
echo     pgbt compress "Demo_Files\Scanned_Statement.pdf" --level all
echo     pgbt stamp "Demo_Files\Bidder_A_Annexure_E4B.pdf"
echo     pgbt retype "Demo_Files\Bidder_B_Balance_Sheet.pdf" --find "1,234 Cr" --replace "1,432 Cr"
echo.
echo   Results always appear in the  Output\  folder.
echo   Type  exit  to close this window.
echo.
echo  ----------------------------------------------------------------
echo.

cmd /k
"""


def find_desktop() -> Path | None:
    """Find the Desktop, even when OneDrive has taken it over."""
    for candidate in (Path.home() / "Desktop",
                      Path.home() / "OneDrive" / "Desktop"):
        if candidate.exists():
            return candidate
    # POWERGRID's OneDrive uses a long company name, so search for it
    for folder in Path.home().glob("OneDrive*"):
        desktop = folder / "Desktop"
        if desktop.exists():
            return desktop
    return None


def main() -> int:
    root = Path(__file__).resolve().parent
    content = LAUNCHER.format(root=root)

    print()
    print("=" * 64)
    print(" PG BID TOOLKIT - BUILDING YOUR LAUNCHER")
    print("=" * 64)
    print(f" Toolkit folder : {root}")

    # A quick sanity check, so we fail with a helpful message rather than
    # silently making a launcher that cannot work.
    venv = root / ".venv" / "Scripts" / "python.exe"
    if not venv.exists():
        print()
        print(" X  I cannot see .venv\\Scripts\\python.exe in this folder.")
        print("    Either this file is in the wrong place, or setup_env.bat")
        print("    has not been run yet.")
        print("=" * 64)
        return 1
    print(" Virtual env    : found  [OK]")

    # 1. The launcher in the toolkit folder
    target = root / "START_HERE.bat"
    if target.exists():
        target.unlink()
        print(" Old copy       : removed (it was the blocked download)")
    target.write_text(content, encoding="utf-8")
    print(f" Created        : {target}")

    # 2. A copy on the Desktop, for convenience
    desktop = find_desktop()
    if desktop:
        shortcut = desktop / "PG Bid Toolkit.bat"
        shortcut.write_text(content, encoding="utf-8")
        print(f" Also created   : {shortcut}")
    else:
        print(" Desktop        : not found, skipped (not a problem)")

    print("-" * 64)
    print(" ALL DONE.")
    print()
    print(" Now open the folder and DOUBLE-CLICK  START_HERE.bat")
    print(" A blue window will open with a list of commands.")
    print(" In that window, type:   pgbt demo")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    code = main()
    # Keep the window readable if this was run by double-clicking.
    if sys.stdin and sys.stdin.isatty():
        input("\nPress Enter to close...")
    raise SystemExit(code)
