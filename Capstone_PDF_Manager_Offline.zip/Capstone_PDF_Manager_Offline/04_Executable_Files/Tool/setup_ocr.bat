@echo off
REM ==========================================================================
REM  PG Bid Toolkit - STEP 2 of 2 : Install OCR engines
REM
REM  OCR = teaching the tool to READ a scanned page (a photo of text).
REM  Normal PDFs do not need it.  Scanned bid documents do.
REM
REM  You picked "build all" -- but you do NOT have to install all today.
REM  Start with A (small and fast).  Add C later if Hindi scans need it.
REM
REM  No administrator rights needed.
REM ==========================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"
color 0B
title PG Bid Toolkit - OCR Setup

if not exist ".venv\Scripts\python.exe" (
    color 0C
    echo   X  .venv not found.  Please run setup_env.bat first.
    pause & exit /b 1
)
set "VPY=%CD%\.venv\Scripts\python.exe"

:MENU
cls
echo.
echo  ============================================================
echo   PG BID TOOLKIT  ^|  OCR Setup  ^|  STEP 2 of 2
echo  ============================================================
echo.
echo   Which reading engine do you want to install?
echo.
echo     A  RapidOCR      ~   80 MB   Fast. English very good.
echo                                  Models are INSIDE the package,
echo                                  so it works offline immediately.
echo.
echo     B  EasyOCR       ~ 2000 MB   Slow. Best for messy Hindi scans.
echo                                  Downloads PyTorch + brain files.
echo.
echo     C  Both A and B              Recommended if disk space allows.
echo.
echo     T  Tesseract                 Show instructions (needs a separate
echo                                  program download, not pip).
echo.
echo     S  Skip / finish             The toolkit works without OCR for
echo                                  normal text PDFs.
echo.
set /p CHOICE="   Type A, B, C, T or S then press Enter: "

if /i "%CHOICE%"=="A" goto RAPID
if /i "%CHOICE%"=="B" goto EASY
if /i "%CHOICE%"=="C" goto BOTH
if /i "%CHOICE%"=="T" goto TESS
if /i "%CHOICE%"=="S" goto DONE
goto MENU

:RAPID
echo.
echo  Installing RapidOCR ^(about 80 MB^) ...
"%VPY%" -m pip install --only-binary=:all: rapidocr-onnxruntime onnxruntime
if errorlevel 1 goto FAILED
echo  RapidOCR installed.
goto VERIFY

:EASY
echo.
echo  Installing EasyOCR.  This is the BIG one - please be patient.
echo.
echo  Part 1 of 2 : PyTorch, CPU-only build ^(about 200 MB^)
echo  If this fails, ask IT to allow:  download.pytorch.org
echo.
"%VPY%" -m pip install --only-binary=:all: torch torchvision --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto FAILED
echo.
echo  Part 2 of 2 : EasyOCR itself
"%VPY%" -m pip install --only-binary=:all: easyocr
if errorlevel 1 goto FAILED
echo  EasyOCR installed.
goto VERIFY

:BOTH
echo.
echo  Installing RapidOCR first ^(small^), then EasyOCR ^(big^) ...
"%VPY%" -m pip install --only-binary=:all: rapidocr-onnxruntime onnxruntime
if errorlevel 1 goto FAILED
"%VPY%" -m pip install --only-binary=:all: torch torchvision --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto FAILED
"%VPY%" -m pip install --only-binary=:all: easyocr
if errorlevel 1 goto FAILED
goto VERIFY

:TESS
cls
echo.
echo  ============================================================
echo   TESSERACT - manual step
echo  ============================================================
echo.
echo   Tesseract is a separate PROGRAM, so pip cannot fetch it.
echo.
echo   1. Download the Windows installer from:
echo        https://github.com/UB-Mannheim/tesseract/wiki
echo   2. During install choose "Install for me only"  ^(no admin needed^)
echo   3. In "Additional language data", tick  Hindi  and  English
echo   4. After install, COPY the whole Tesseract-OCR folder to:
echo        %CD%\models\tesseract\
echo      so that this file exists:
echo        %CD%\models\tesseract\tesseract.exe
echo.
echo   If your office blocks github.com, skip Tesseract entirely.
echo   RapidOCR ^(A^) and EasyOCR ^(B^) cover the same ground.
echo.
"%VPY%" -m pip install --only-binary=:all: pytesseract >nul 2>&1
echo   ^(The small Python connector "pytesseract" has been installed for you.^)
echo.
pause
goto MENU

:VERIFY
echo.
echo  ------------------------------------------------------------
echo   Preparing engines for OFFLINE use ^(one-time^) ...
echo  ------------------------------------------------------------
"%VPY%" fetch_ocr_models.py
goto DONE

:FAILED
color 0C
echo.
echo   X  That install did not finish.
echo.
echo      Common causes:
echo        - firewall: ask IT for  pypi.org, files.pythonhosted.org,
echo          download.pytorch.org, github.com
echo        - not enough disk space ^(EasyOCR needs about 2.5 GB free^)
echo.
echo      The toolkit still works without this engine.
echo.
pause
goto MENU

:DONE
echo.
"%VPY%" check_setup.py
echo.
echo  ============================================================
echo   INSTALLATION COMPLETE.
echo  ============================================================
echo.
pause
endlocal
