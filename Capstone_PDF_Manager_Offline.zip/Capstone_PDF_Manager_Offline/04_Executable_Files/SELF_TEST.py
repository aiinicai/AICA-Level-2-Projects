"""
SELF_TEST.py
============
Proves the tool actually works, without anybody having to read a manual.

It builds a few small practice files, runs the whole pipeline over them,
and prints PASS or FAIL for each stage. Nothing on your computer is
touched: everything happens inside a temporary folder that is deleted at
the end.

Run time: about 20 seconds.
"""

import logging
import os
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

TOOL = Path(__file__).resolve().parent / "Tool"
sys.path.insert(0, str(TOOL))

# Keep the screen clean: this test should show PASS / FAIL lines and nothing
# else, so the reader can see the result at a glance.
os.environ["PGBT_LOG_LEVEL"] = "ERROR"
logging.getLogger().setLevel(logging.ERROR)
SILENT = lambda percent, message="": None          # noqa: E731

PASS, FAIL = "[PASS]", "[FAIL]"
results = []


def check(name, condition, detail=""):
    results.append((name, bool(condition)))
    mark = PASS if condition else FAIL
    print(f"  {mark} {name}" + (f"   {detail}" if detail else ""))
    return bool(condition)


def main() -> int:
    print()
    print("=" * 64)
    print(" PDF MANAGER OFFLINE - SELF TEST")
    print("=" * 64)
    print(" Building practice files and running the whole pipeline.")
    print(" Nothing outside this folder is touched.")
    print("-" * 64)

    workspace = Path(tempfile.mkdtemp(prefix="pdfmgr_test_"))
    try:
        # -- 1. libraries -------------------------------------------------
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        import openpyxl                                    # noqa: F401
        check("Libraries load", True)

        from app import analysis, common, config, highlight, intake
        from app import pdf_ops, search, writers
        for name in ("pgbt", "intake", "pdf", "search", "writers",
                     "analysis", "highlight", "ocr"):
            logging.getLogger(name).setLevel(logging.ERROR)
        check("Tool modules load", True, f"v{config.APP_VERSION}")

        # -- 2. make practice PDFs ----------------------------------------
        source_dir = workspace / "bids"
        source_dir.mkdir()

        def make(name, lines, password=None):
            doc = fitz.open()
            for index, line in enumerate(lines, start=1):
                page = doc.new_page(width=595, height=842)
                page.insert_text((60, 90), line, fontsize=13)
                page.insert_text((60, 120), f"Page {index}", fontsize=9)
            target = source_dir / name
            if password:
                doc.save(str(target), encryption=fitz.PDF_ENCRYPT_AES_256,
                         owner_pw=password, user_pw=password)
            else:
                doc.save(str(target))
            doc.close()
            return target

        make("Bidder_A.pdf",
             ["MAAT 4,523.75 Cr as on 31.03.2025",
              "Net Worth 8,912.40 Cr - positive",
              "Liquid Assets 812.50 Cr"])
        make("Bidder_B.pdf",
             ["Net Worth (1,180.25) Cr negative",
              "Bid conditional - deviation noted"])
        make("Bidder_C_LOCKED.pdf", ["Locked annexure"], password="demo123")
        shutil.copy(source_dir / "Bidder_A.pdf", source_dir / "Bidder_A_copy.pdf")
        check("Practice files created", len(list(source_dir.iterdir())) == 4,
              "4 files")

        # -- 3. intake ----------------------------------------------------
        job = workspace / "out"
        job.mkdir()
        vault = intake.PasswordVault(["demo123"])
        errors = common.ErrorLog(job)
        engine = intake.IntakeEngine(vault=vault, errors=errors, unattended=True)
        records = engine.run([source_dir], progress_callback=SILENT)
        tally = engine.tally()

        duplicates = sum(1 for r in records
                         if r.status == intake.Status.DUPLICATE)
        unlocked = sum(1 for r in records
                       if r.status == intake.Status.UNLOCKED)
        check("Intake reads every file", tally["Total"] == 4,
              f"{tally['Total']} files")
        check("Duplicate spotted by fingerprint", duplicates == 1)
        check("Locked file opened with the password", unlocked == 1)

        manifest = intake.write_manifest(records, job)
        check("Excel manifest written", manifest.exists(), manifest.name)

        # -- 4. PDF operations --------------------------------------------
        items = [pdf_ops.MergeItem(source_dir / "Bidder_A.pdf", label="A"),
                 pdf_ops.MergeItem(source_dir / "Bidder_B.pdf", label="B")]
        merged = pdf_ops.merge_pdfs(items, job, "Merged_Test",
                                    progress_callback=SILENT)
        check("Merge with footer and bookmarks",
              merged.total_pages == 5 and merged.bookmarks >= 2,
              f"{merged.total_pages} pages, {merged.bookmarks} bookmarks")

        rotated = pdf_ops.rotate_pdf(source_dir / "Bidder_A.pdf", job, 90)
        check("Rotate", rotated.exists())

        parts = pdf_ops.split_pdf(merged.output, job, ranges="1-3, 4-5")
        check("Split", len(parts) == 2, f"{len(parts)} files")

        stamped = pdf_ops.stamp_pdf(source_dir / "Bidder_B.pdf", job)
        check("Stamp", stamped.exists())

        # -- 5. source files untouched ------------------------------------
        original = (source_dir / "Bidder_A.pdf").read_bytes()
        check("Source files never modified",
              len(original) > 0 and original[:4] == b"%PDF")

        # -- 6. index and search ------------------------------------------
        index = search.SearchIndex(job)
        pdfs = [p for p in sorted(source_dir.glob("*.pdf"))
                if "LOCKED" not in p.name]
        report = search.build_index(pdfs, job, engine="none",
                                    make_searchable=False, index=index,
                                    progress_callback=SILENT)
        hits = index.search(["MAAT", "Net Worth"])
        stats = index.stats()
        index.close()
        check("Pages indexed", stats["pages"] >= 5, f"{stats['pages']} pages")
        check("Global search finds the words", len(hits) >= 3,
              f"{len(hits)} mentions")

        # -- 7. figure reading, including the negative --------------------
        text_a = "MAAT 4,523.75 Cr as on 31.03.2025 Net Worth 8,912.40 Cr"
        figures = {f.label: f.crore for f in analysis.find_figures(text_a, 1)}
        check("Reads MAAT correctly", figures.get("MAAT") == 4523.75,
              str(figures.get("MAAT")))

        negative = analysis.find_figures("Net Worth (1,180.25) Cr", 1)
        value = negative[0].crore if negative else None
        check("Reads a loss in brackets as negative", value == -1180.25,
              str(value))

        page_number = analysis.find_figures(
            "Turnover statement audited Original page 4 of 4", 1)
        check("Does not mistake a page number for money",
              len(page_number) == 0)

        # -- 8. reports in four formats -----------------------------------
        index = search.SearchIndex(job)
        highlighter = highlight.Highlighter()
        facts = analysis.gather_facts(index, highlighter)
        digest = analysis.build_digest(facts, highlighter)
        comparison = analysis.build_comparison(facts)
        index.close()

        produced = writers.write_all(digest, job)
        check("Word / PowerPoint / HTML / PDF written", len(produced) == 4,
              ", ".join(produced))
        produced2 = writers.write_all(comparison, job, ("word",))
        check("Bid Comparison built", len(produced2) == 1)

        # -- 9. colour rules ----------------------------------------------
        check("Red flag on a deviation",
              highlighter.classify("bid conditional - deviation") == "critical")
        check("Amber flag on provisional figures",
              highlighter.classify("provisional unaudited") == "warning")
        check("Blue on a money figure",
              highlighter.classify("4,523.75 Cr") == "money")

    except Exception as exc:                              # noqa: BLE001
        print()
        print(f"  {FAIL} Unexpected problem: {exc}")
        print()
        traceback.print_exc()
        results.append(("Unexpected problem", False))
    finally:
        shutil.rmtree(workspace, ignore_errors=True)

    passed = sum(1 for _, ok in results if ok)
    total = len(results)
    print("-" * 64)
    if passed == total and total > 0:
        print(f" RESULT: ALL {total} CHECKS PASSED")
        print(" The tool is installed correctly and working.")
        print("=" * 64)
        return 0

    print(f" RESULT: {passed} of {total} checks passed")
    for name, ok in results:
        if not ok:
            print(f"   failed -> {name}")
    print("=" * 64)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
