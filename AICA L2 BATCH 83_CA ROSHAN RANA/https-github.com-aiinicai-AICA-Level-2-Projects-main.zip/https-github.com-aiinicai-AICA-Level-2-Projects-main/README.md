# SMART BANK STATEMENT ANALYSER

[![React](https://img.shields.io/badge/React-19.0-blue.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-blue.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4.1-38bdf8.svg)](https://tailwindcss.com/)
[![Google Gemini](https://img.shields.io/badge/Gemini_API-2.5_Flash-orange.svg)](https://ai.google.dev/)
[![Express](https://img.shields.io/badge/Express-4.21-lightgrey.svg)](https://expressjs.com/)
[![License](https://img.shields.io/badge/License-Apache_2.0-green.svg)](LICENSE)

An intelligent, AI-assisted risk analysis and statement audit decision-support platform designed to safeguard users, auditors, and fintech compliance teams against deceptive banking/UPI payment anomalies, phishing scams, and transaction irregularities.

---

## 📌 Project Overview & Problem Statement

Modern banking and digital payment ecosystems handle billions of financial transactions every month. However, rapid adoption has been accompanied by a steep surge in social engineering schemes and transaction irregularities:
- **Deceptive Collect Requests**: Attackers send "Collect Requests" masquerading as cashbacks or refunds, deceiving victims into entering their UPI PIN.
- **Midnight & Velocity Bursts**: Irregular debit transactions initiated during unusual hours (e.g., 2:00 AM – 4:00 AM) or in rapid bursts to drain accounts before the account holder notices.
- **Manipulative Phishing Messages**: SMS and WhatsApp messages threatening electricity disconnection, bank account freezes, or fake lottery payouts with APK malware links.
- **Unverified Device & Location Changes**: High-value transfers directed to newly added beneficiaries from unverified devices or foreign IP ranges.

**SMART BANK STATEMENT ANALYSER** provides a unified decision-support cockpit for retail consumers, accountants, and fintech analysts. It combines real-time rule-based heuristics with Google Gemini AI to analyze transaction telemetry, audit historical statements, detect scam messages, and generate formal audit dossiers with vector PDF export.

---

## 🚀 Key Modules & Capabilities

### 1. Executive Analytics Dashboard
- **Key Risk Indicators (KRI)**: Instant visibility into total volume, monitored values, and flagged high-risk transactions.
- **Risk Tier Distribution**: Graphical breakdown of transactions across **LOW**, **MODERATE**, **HIGH**, and **CRITICAL** tiers.
- **High-Risk Case Feed**: Direct action queue to drill into individual anomalies.

### 2. Live Transaction Analyzer
- Multi-dimensional parameter evaluation:
  - Time-of-day risk (night-time / dormant hour flags)
  - Amount deviation relative to user's 30-day baseline average
  - Velocity checks (recent transaction bursts)
  - New beneficiary and foreign device indicators
  - Deceptive narration and keyword heuristics
- Outputs a normalized **Risk Score (0–100)**, confidence rating, primary anomaly signals, and clear mitigation advice.

### 3. Statement History & Ingestion (Batch Auditing)
- Ingest bank statements via **drag-and-drop CSV, XLSX, or XLS** files.
- Automated column mapping (`Date`, `Time`, `Amount`, `Beneficiary`, `Remarks`, `Type`).
- **Top 10 Investigation Queue**: Automatically ranks high-risk outliers requiring immediate review.
- Search and multi-tier filtering with one-click dataset export.

### 4. Scam & Threat Message Analyzer
- Real-time classification of SMS, WhatsApp texts, and emails.
- Identifies social engineering triggers (urgency, fear, fake official authority, malicious APK shortlinks).
- Provides step-by-step guidance on how to report threats without sharing sensitive credentials.

### 5. Fintech Audit & Risk Investigation Dossier
- Generates comprehensive compliance and investigation reports summarizing flagged transactions, behavioral patterns, and recommended containment protocols.
- **Vector PDF Export (`.pdf`)**: Client-side multi-page PDF generation via `jsPDF`, producing publication-quality reports with running headers, footers, and official classification watermarks.
- Built-in system print support with automated fallback.

---

## 🛠️ Architecture & Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend UI** | React 19, TypeScript | Reactive, type-safe single-page application |
| **Styling** | Tailwind CSS v4 | High-density, professional fintech design |
| **AI Engine** | Google Gemini 2.5 Flash (`@google/genai`) | Server-side natural language inference and anomaly synthesis |
| **Backend Server** | Node.js, Express | Secure API proxy keeping Gemini API keys hidden from client |
| **Build Tooling** | Vite 6, esbuild, tsx | Ultra-fast bundling, HMR, and server compilation |
| **Data Parsing** | PapaParse, SheetJS (XLSX) | Client-side spreadsheet and statement ingestion |
| **PDF Generation** | jsPDF | High-fidelity, client-side vector PDF rendering |
| **Icons** | Lucide React | Consistent, lightweight vector iconography |

---

## 📁 Repository Structure

```
├── .env.example              # Environment variables template
├── metadata.json             # AI Studio platform configuration
├── package.json              # NPM dependencies and scripts
├── server.ts                 # Express backend entry point
├── vite.config.ts            # Vite configuration with Tailwind plugin
├── tsconfig.json             # TypeScript compiler settings
├── server/
│   └── geminiService.ts      # Server-side Gemini AI integration handlers
└── src/
    ├── App.tsx               # Main application controller
    ├── main.tsx              # React entry point
    ├── index.css             # Global styles and print media rules
    ├── types.ts              # Global TypeScript interfaces & data models
    ├── components/
    │   ├── Navbar.tsx             # Header, Sidebar, and Mobile navigation
    │   ├── DashboardView.tsx      # Executive metrics and distribution
    │   ├── SingleAnalyzerView.tsx # Live transaction risk analysis
    │   ├── HistoryAnalyzerView.tsx# Statement batch upload and Top 10 queue
    │   ├── ScamCheckerView.tsx    # SMS/WhatsApp scam message detector
    │   ├── ReportView.tsx         # Formal audit dossier with PDF export
    │   └── DisclaimerBanner.tsx   # Responsible AI & advisory notices
    ├── data/
    │   └── demoData.ts       # Synthetic UPI banking statements & scam presets
    └── utils/
        ├── riskAnalyzer.ts   # Rule-based fallback risk & heuristics engine
        └── pdfGenerator.ts   # jsPDF multi-page report generator
```

---

## ⚡ Quickstart & Local Setup

### Prerequisites
- [Node.js](https://nodejs.org/) (version 18 or higher recommended)
- [npm](https://www.npmjs.com/) or [bun](https://bun.sh/)
- A Google Gemini API Key from [Google AI Studio](https://aistudio.google.com/)

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/<your-repo-name>.git
cd <your-repo-name>
```

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment variables
Create a `.env` file in the root directory (based on `.env.example`):
```bash
cp .env.example .env
```
Edit `.env` and supply your Gemini API key:
```env
GEMINI_API_KEY="your_actual_gemini_api_key_here"
```

### 4. Start the development server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000`.

### 5. Build for production
```bash
npm run build
npm start
```

---

## 🔌 API Endpoints

The Express server exposes the following endpoints (with API keys kept strictly server-side):

- `GET /api/health` — Service health check and AI status verification.
- `POST /api/analyze-transaction` — Evaluates a single transaction payload using Gemini AI with fallback to local heuristic models.
- `POST /api/check-scam` — Analyzes raw SMS/WhatsApp text to detect coercive fraud patterns and phishing URLs.
- `POST /api/generate-report` — Synthesizes multi-transaction batches into a structured investigation dossier.

---

## 🛡️ Responsible AI & Ethical Safety Guidelines

1. **Zero Credential Exposure**: This platform **NEVER** asks for, processes, or stores sensitive user credentials such as UPI PINs, OTPs, netbanking passwords, or CVV numbers.
2. **Decision-Support Mandate**: SMART BANK STATEMENT ANALYSER does not automatically seize funds or block accounts autonomously; it delivers structured, explainable decision support for human verification.
3. **National Helpline Integration**: In case of financial fraud, users are advised to immediately dial the **National Cyber Crime Helpline at 1930** or log a complaint at **[cybercrime.gov.in](https://cybercrime.gov.in)** within the golden hour.

---

## 📦 How to Download / Submit for GitHub

To download this project as a complete ZIP folder or export directly to GitHub from Google AI Studio:
1. Click the **Export / Settings menu** (top-right corner of the AI Studio interface).
2. Choose **"Export to GitHub"** to push directly to your repository, or select **"Download as ZIP"** to save the entire project archive to your local machine.
3. Extract the ZIP file and commit the contents to your GitHub capstone project submission.

---

## 📄 License

This project is licensed under the Apache-2.0 License.
