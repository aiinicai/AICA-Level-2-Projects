import { GoogleGenAI } from '@google/genai';
import { Transaction, ScamMessageAnalysis, InvestigationReportData } from '../src/types';
import { calculateTransactionRisk, analyzeScamMessage, generateInvestigationReport } from '../src/utils/riskAnalyzer';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function analyzeTransactionWithGemini(tx: Transaction): Promise<Transaction> {
  const fallback = calculateTransactionRisk(tx);
  const ai = getAiClient();

  if (!ai) {
    return fallback;
  }

  try {
    const prompt = `You are UPI Guardian, a specialized AI financial risk assessment engine.
Analyze the following transaction for anomaly indicators, social engineering patterns, and risk signals:
Transaction Details:
- ID: ${tx.id}
- Date: ${tx.date}, Time: ${tx.time}
- Amount: ₹${tx.amount} (User normal average: ₹${tx.normalAvgAmount || 'Not provided'})
- Transaction Type: ${tx.type}
- Beneficiary: ${tx.beneficiary}
- Is New Beneficiary: ${tx.isNewBeneficiary ? 'Yes' : 'No'}
- Is New Device: ${tx.isNewDevice ? 'Yes' : 'No'}
- Location: ${tx.location || 'Not provided'}
- Recent Transaction Count (last 1-24h): ${tx.recentTransactionCount}
- Remarks: "${tx.remarks || 'Not provided'}"

Evaluate:
1. Amount anomaly vs normal spend baseline
2. Unusual transaction timing (e.g., late night / early hours)
3. Velocity / burst frequency
4. New beneficiary & transaction type hazard (e.g., Collect Request hazard)
5. New device or location anomaly
6. Psychological coercion, urgency, or scam keywords in remarks (e.g. KYC, Electricity disconnect, TDS, QR scan to receive)

Risk Score Scale:
- 0–25: LOW
- 26–50: MODERATE
- 51–75: HIGH
- 76–100: CRITICAL

CRITICAL GUIDELINES:
- Never declare a transaction definitely fraudulent. Use terms like "potentially suspicious", "risk indicator", and "requires verification".
- Never invent evidence. If details are absent, state "Not provided".
- Return pure JSON matching this exact structure:
{
  "riskScore": number (0-100),
  "riskLevel": "LOW" | "MODERATE" | "HIGH" | "CRITICAL",
  "confidence": number (0-100),
  "riskFactors": ["factor 1", "factor 2"],
  "evidence": ["evidence 1", "evidence 2"],
  "missingInformation": ["missing item 1"],
  "recommendedActions": ["action 1", "action 2"],
  "analysisSummary": "Concise 2-sentence executive summary with responsible risk language.",
  "anomaliesDetected": {
    "amountAnomaly": boolean,
    "unusualTime": boolean,
    "velocityAnomaly": boolean,
    "newBeneficiaryAnomaly": boolean,
    "newDeviceAnomaly": boolean,
    "locationAnomaly": boolean,
    "urgentLanguageAnomaly": boolean,
    "collectRequestRisk": boolean
  }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim();
    if (!text) return fallback;

    const parsed = JSON.parse(text);
    return {
      ...tx,
      riskScore: typeof parsed.riskScore === 'number' ? parsed.riskScore : fallback.riskScore,
      riskLevel: parsed.riskLevel || fallback.riskLevel,
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : fallback.confidence,
      riskFactors: Array.isArray(parsed.riskFactors) && parsed.riskFactors.length ? parsed.riskFactors : fallback.riskFactors,
      evidence: Array.isArray(parsed.evidence) && parsed.evidence.length ? parsed.evidence : fallback.evidence,
      missingInformation: Array.isArray(parsed.missingInformation) ? parsed.missingInformation : fallback.missingInformation,
      recommendedActions: Array.isArray(parsed.recommendedActions) ? parsed.recommendedActions : fallback.recommendedActions,
      analysisSummary: parsed.analysisSummary || fallback.analysisSummary,
      anomaliesDetected: parsed.anomaliesDetected || fallback.anomaliesDetected
    };
  } catch (err) {
    console.warn('Gemini AI call fallback triggered for single transaction:', err);
    return fallback;
  }
}

export async function analyzeScamMessageWithGemini(messageText: string): Promise<ScamMessageAnalysis> {
  const fallback = analyzeScamMessage(messageText);
  const ai = getAiClient();

  if (!ai) {
    return fallback;
  }

  try {
    const prompt = `You are UPI Guardian Scam Message Detector. Analyze this message (from SMS/WhatsApp/Email) for scam indicators:
Message Content:
"""
${messageText}
"""

Detect:
- Urgency, threats (e.g. electricity power cut tonight, account blocked in 24h, KYC freeze)
- Impersonation (banks, discoms, officials, customer support)
- OTP, UPI PIN, password or CVV solicitations
- Suspicious links (.xyz, .top, bit.ly, fake web portals)
- Refund / lottery / prize / reward points scams
- Collect request or QR scan deception (e.g., "scan to receive payment")

Output pure JSON matching this exact structure:
{
  "riskScore": number (0-100),
  "riskCategory": "LOW RISK" | "MODERATE RISK" | "SUSPICIOUS" | "HIGH RISK SCAM" | "CRITICAL THREAT",
  "confidence": number (0-100),
  "detectedScamTypes": ["type 1", "type 2"],
  "urgencyThreats": ["threat 1", "threat 2"],
  "indicators": ["indicator 1", "indicator 2"],
  "safeNextSteps": ["step 1", "step 2", "step 3"],
  "explanation": "Clear explanation of why this message is safe or potentially suspicious.",
  "channelGuess": "SMS" | "WhatsApp" | "Email" | "Unknown"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim();
    if (!text) return fallback;

    const parsed = JSON.parse(text);
    return {
      messageText,
      riskScore: typeof parsed.riskScore === 'number' ? parsed.riskScore : fallback.riskScore,
      riskCategory: parsed.riskCategory || fallback.riskCategory,
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : fallback.confidence,
      detectedScamTypes: Array.isArray(parsed.detectedScamTypes) ? parsed.detectedScamTypes : fallback.detectedScamTypes,
      urgencyThreats: Array.isArray(parsed.urgencyThreats) ? parsed.urgencyThreats : fallback.urgencyThreats,
      indicators: Array.isArray(parsed.indicators) ? parsed.indicators : fallback.indicators,
      safeNextSteps: Array.isArray(parsed.safeNextSteps) ? parsed.safeNextSteps : fallback.safeNextSteps,
      explanation: parsed.explanation || fallback.explanation,
      channelGuess: parsed.channelGuess || fallback.channelGuess
    };
  } catch (err) {
    console.warn('Gemini AI scam detector fallback triggered:', err);
    return fallback;
  }
}

export async function generateInvestigationReportWithGemini(transactions: Transaction[]): Promise<InvestigationReportData> {
  const fallback = generateInvestigationReport(transactions);
  const ai = getAiClient();

  if (!ai) {
    return fallback;
  }

  try {
    const summaryData = {
      totalCount: transactions.length,
      totalValue: fallback.totalTransactionValue,
      breakdown: fallback.riskBreakdown,
      topHighRiskTransactions: fallback.topRiskCases.slice(0, 5).map(t => ({
        id: t.id,
        amount: t.amount,
        beneficiary: t.beneficiary,
        riskScore: t.riskScore,
        riskLevel: t.riskLevel,
        remarks: t.remarks,
        anomalies: t.riskFactors
      }))
    };

    const prompt = `You are a Senior Fintech Risk & Compliance Analyst at UPI Guardian.
Generate a structured, professional executive investigation report based on these aggregated transactions:
${JSON.stringify(summaryData, null, 2)}

Provide an objective, decision-support analysis with responsible AI terminology ("potentially suspicious", "requires verification", "risk indicator").

Return pure JSON matching this exact structure:
{
  "executiveSummary": "Comprehensive 3-paragraph executive overview summarizing the transaction volume, risk distribution, primary anomaly vectors, and key decision-support findings.",
  "evidenceSynthesis": ["Key empirical observation 1", "Key empirical observation 2", "Key empirical observation 3"],
  "recommendedProcedures": ["Standard verification procedure 1", "Bank escalation procedure 2", "User safeguard procedure 3", "Cyber cell reporting guidance 4"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim();
    if (!text) return fallback;

    const parsed = JSON.parse(text);
    return {
      ...fallback,
      executiveSummary: parsed.executiveSummary || fallback.executiveSummary,
      evidenceSynthesis: Array.isArray(parsed.evidenceSynthesis) ? parsed.evidenceSynthesis : fallback.evidenceSynthesis,
      recommendedProcedures: Array.isArray(parsed.recommendedProcedures) ? parsed.recommendedProcedures : fallback.recommendedProcedures
    };
  } catch (err) {
    console.warn('Gemini AI report generator fallback triggered:', err);
    return fallback;
  }
}
