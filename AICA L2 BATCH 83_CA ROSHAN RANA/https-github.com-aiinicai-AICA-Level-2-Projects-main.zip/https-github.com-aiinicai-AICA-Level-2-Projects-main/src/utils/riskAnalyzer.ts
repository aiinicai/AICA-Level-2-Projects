import { Transaction, RiskLevel, ScamMessageAnalysis, InvestigationReportData } from '../types';

export function calculateTransactionRisk(tx: Omit<Transaction, 'riskScore' | 'riskLevel' | 'confidence' | 'riskFactors' | 'evidence' | 'missingInformation' | 'recommendedActions' | 'analysisSummary' | 'anomaliesDetected'>): Transaction {
  let score = 5; // Base baseline
  const factors: string[] = [];
  const evidence: string[] = [];
  const missingInfo: string[] = [];
  const actions: string[] = [];

  // 1. Amount Anomaly
  const normal = tx.normalAvgAmount > 0 ? tx.normalAvgAmount : 2000;
  const ratio = tx.amount / normal;
  let amountAnomaly = false;

  if (ratio > 10) {
    score += 35;
    amountAnomaly = true;
    factors.push(`Severe Amount Anomaly: Amount (₹${tx.amount.toLocaleString('en-IN')}) is ${(ratio).toFixed(1)}x higher than normal profile average (₹${normal.toLocaleString('en-IN')}).`);
    evidence.push(`Transaction amount is substantially above historical 30-day baseline.`);
  } else if (ratio > 4) {
    score += 22;
    amountAnomaly = true;
    factors.push(`High Amount Anomaly: Amount (₹${tx.amount.toLocaleString('en-IN')}) is ${(ratio).toFixed(1)}x above expected average.`);
  } else if (ratio > 2) {
    score += 10;
    amountAnomaly = true;
    factors.push(`Moderate Amount Anomaly: ${ratio.toFixed(1)}x above routine average.`);
  }

  // 2. Unusual Transaction Time (e.g. 11 PM to 5 AM)
  let unusualTime = false;
  const hour = parseInt(tx.time.split(':')[0] || '12', 10);
  if (hour >= 23 || hour < 5) {
    score += 18;
    unusualTime = true;
    factors.push(`Unusual Transaction Hour (${tx.time}): Executed during high-risk overnight window (11:00 PM – 5:00 AM).`);
    evidence.push(`Execution timestamp ${tx.time} falls outside standard consumer active banking hours.`);
  }

  // 3. Velocity / Frequency Anomaly
  let velocityAnomaly = false;
  if (tx.recentTransactionCount >= 5) {
    score += 20;
    velocityAnomaly = true;
    factors.push(`High Velocity Anomaly: ${tx.recentTransactionCount} transactions attempted in rapid succession within the recent window.`);
    evidence.push(`Sudden burst of multiple transactions within a short duration is characteristic of account drainage attempts.`);
  } else if (tx.recentTransactionCount >= 3) {
    score += 10;
    velocityAnomaly = true;
    factors.push(`Elevated Velocity: ${tx.recentTransactionCount} recent transactions recorded.`);
  }

  // 4. Beneficiary & Transaction Type Risk
  let newBeneficiaryAnomaly = false;
  if (tx.isNewBeneficiary) {
    newBeneficiaryAnomaly = true;
    score += 12;
    factors.push(`New / First-Time Beneficiary: Recipient handle (${tx.beneficiary}) has no verified past transaction history.`);
  }

  // Collect Request Hazard
  let collectRequestRisk = false;
  if (tx.type === 'Collect Request') {
    collectRequestRisk = true;
    score += 20;
    factors.push(`Collect Request Protocol: Incoming pull payment request initiated externally, creating high risk of accidental PIN authorization.`);
    evidence.push(`UPI Collect requests require entering a UPI PIN to DEBIT funds. Scammers often disguise this as receiving money.`);
  }

  // 5. Device & Location Anomaly
  let newDeviceAnomaly = false;
  let locationAnomaly = false;

  if (tx.isNewDevice) {
    newDeviceAnomaly = true;
    score += 15;
    factors.push(`New / Unrecognized Device: Initiated from an un-enrolled device or modified client environment.`);
    evidence.push(`Device identifier does not match the customer's primary registered smartphone.`);
  }

  const suspiciousLocations = ['jamtara', 'nuh', 'mewat', 'alwar', 'bharatpur', 'proxy', 'vpn', 'tor', 'unknown'];
  const locLower = (tx.location || '').toLowerCase();
  if (suspiciousLocations.some(l => locLower.includes(l))) {
    locationAnomaly = true;
    score += 18;
    factors.push(`High-Risk / Anomalous Geolocation: Origin flagged from "${tx.location}".`);
    evidence.push(`Originating IP/Location matches geographic hotspot or VPN/proxy relay.`);
  }

  // 6. Remarks / Coercive Language
  let urgentLanguageAnomaly = false;
  const remarkLower = (tx.remarks || '').toLowerCase();
  const scamKeywords = [
    'urgent', 'electricity', 'disconnect', 'kyc', 'pan', 'block', 'freeze', 
    'refund', 'tds', 'lottery', 'prize', 'claim', 'winner', 'qr scan', 
    'barcode', 'otp', 'pin', 'bonus', 'escrow', 'overdue', 'penalty'
  ];

  const matchedKeywords = scamKeywords.filter(k => remarkLower.includes(k));
  if (matchedKeywords.length > 0) {
    urgentLanguageAnomaly = true;
    score += Math.min(25, matchedKeywords.length * 10);
    factors.push(`Suspicious / Urgent Remarks Pattern: Contains flagged keywords [${matchedKeywords.join(', ')}].`);
    evidence.push(`Transaction narration uses psychological pressure or regulatory pretext to bypass verification.`);
  }

  // Cap score between 0 and 100
  score = Math.min(100, Math.max(0, score));

  // Determine Risk Level
  let riskLevel: RiskLevel = 'LOW';
  if (score >= 76) riskLevel = 'CRITICAL';
  else if (score >= 51) riskLevel = 'HIGH';
  else if (score >= 26) riskLevel = 'MODERATE';
  else riskLevel = 'LOW';

  // Calculate Confidence Score
  let confidence = 85;
  if (factors.length >= 3) confidence = 94;
  if (factors.length >= 5) confidence = 98;
  if (!tx.remarks || tx.remarks.trim() === '') confidence -= 5;

  // Missing Information
  if (!tx.location || tx.location === 'Unknown' || tx.location === '') {
    missingInfo.push('Accurate GPS/Cell tower location coordinate telemetry');
  }
  if (tx.isNewBeneficiary) {
    missingInfo.push('Beneficiary account name resolution (NPCI Payee Name lookup)');
  }
  if (tx.remarks.length === 0) {
    missingInfo.push('Transaction narration or invoice purpose');
  }

  // Recommended Actions based on severity
  if (riskLevel === 'CRITICAL') {
    actions.push('Decline or halt the transaction immediately.');
    actions.push('NEVER enter your 4/6-digit UPI PIN. A UPI PIN is NEVER required to receive money or refunds.');
    actions.push('If a Collect Request was received, decline and block the sender in your UPI app.');
    actions.push('Contact your bank support or call National Cyber Crime Helpline (1930) if funds were debited.');
  } else if (riskLevel === 'HIGH') {
    actions.push('Verify the beneficiary name and bank account details through independent, trusted channels before proceeding.');
    actions.push('Confirm that you are not acting under urgent instructions from unknown callers claiming to be bank or utility officials.');
    actions.push('Check the recipient name displayed on the UPI confirmation screen against your intended party.');
  } else if (riskLevel === 'MODERATE') {
    actions.push('Perform a secondary check on the UPI ID and amount.');
    actions.push('Ensure the amount matches your exact purchase or transfer intention.');
  } else {
    actions.push('No unusual anomalies detected. Follow standard digital payment security practices.');
    actions.push('Always keep your UPI PIN confidential.');
  }

  let summary = '';
  if (riskLevel === 'CRITICAL') {
    summary = `CRITICAL RISK INDICATOR (${score}/100): Multiple high-severity anomalies detected including ${amountAnomaly ? 'severe amount spike, ' : ''}${unusualTime ? 'unusual night execution, ' : ''}${urgentLanguageAnomaly ? 'coercive remark pretext, ' : ''}and ${collectRequestRisk ? 'external collect request hazard' : 'unrecognized device footprint'}. Requires immediate user caution.`;
  } else if (riskLevel === 'HIGH') {
    summary = `HIGH RISK INDICATOR (${score}/100): Elevated risk profile with behavioral and parameter deviations. Counterparty or context requires verification prior to authorization.`;
  } else if (riskLevel === 'MODERATE') {
    summary = `MODERATE RISK INDICATOR (${score}/100): Minor deviations from baseline profile observed. Standard verification recommended.`;
  } else {
    summary = `LOW RISK INDICATOR (${score}/100): Transaction parameters align well with expected historical behavioral patterns.`;
  }

  return {
    ...tx,
    riskScore: score,
    riskLevel,
    confidence,
    riskFactors: factors.length > 0 ? factors : ['Transaction behavior matches routine historical baseline.'],
    evidence: evidence.length > 0 ? evidence : ['All evaluated attributes align with standard authorized profile.'],
    missingInformation: missingInfo.length > 0 ? missingInfo : ['None identified. Key metadata is available.'],
    recommendedActions: actions,
    analysisSummary: summary,
    anomaliesDetected: {
      amountAnomaly,
      unusualTime,
      velocityAnomaly,
      newBeneficiaryAnomaly,
      newDeviceAnomaly,
      locationAnomaly,
      urgentLanguageAnomaly,
      collectRequestRisk
    }
  };
}

export function analyzeScamMessage(text: string): ScamMessageAnalysis {
  const lower = text.toLowerCase();
  let score = 10;
  const detectedScamTypes: string[] = [];
  const urgencyThreats: string[] = [];
  const indicators: string[] = [];
  const safeNextSteps: string[] = [];

  // Electricity / Utility Threat
  if (lower.includes('electric') || lower.includes('power') || lower.includes('disconnect') || lower.includes('light cut') || lower.includes('mseb') || lower.includes('bill overdue')) {
    score += 45;
    detectedScamTypes.push('Electricity / Utility Disconnection Extortion');
    urgencyThreats.push('Threatening imminent disconnection of power supply tonight.');
    indicators.push('Official power utilities never send personal mobile numbers for bill clearance.');
    indicators.push('Coercive deadline intended to induce panic.');
  }

  // KYC / Account Block / PAN
  if (lower.includes('kyc') || lower.includes('pan') || lower.includes('aadhaar') || lower.includes('blocked') || lower.includes('suspended') || lower.includes('freeze') || lower.includes('reactivate') || lower.includes('deactivate')) {
    score += 40;
    detectedScamTypes.push('Bank KYC Suspension / Phishing Impersonation');
    urgencyThreats.push('Threatening immediate bank account or UPI suspension within 24 hours.');
    indicators.push('Banks never ask users to update KYC by clicking unverified short links or downloading third-party APKs.');
  }

  // OTP / UPI PIN solicitation
  if (lower.includes('pin') || lower.includes('otp') || lower.includes('upi pin') || lower.includes('cvv') || lower.includes('password') || lower.includes('scan qr') || lower.includes('enter pin')) {
    score += 50;
    detectedScamTypes.push('Direct OTP / UPI PIN / Credential Solicitation');
    urgencyThreats.push('Attempting to induce entry or disclosure of secret PIN/OTP credentials.');
    indicators.push('Entering a UPI PIN ALWAYS DEBITS money from your account. You NEVER enter a PIN to receive payments.');
  }

  // Lottery / Prize / Refund / Reward points
  if (lower.includes('lottery') || lower.includes('prize') || lower.includes('won') || lower.includes('reward points') || lower.includes('cashback') || lower.includes('tds') || lower.includes('bonus') || lower.includes('redeem')) {
    score += 35;
    detectedScamTypes.push('Advance-Fee / Fake Reward Points & Cashback Bait');
    urgencyThreats.push('Luring target with artificial urgency around expiring points or fake prize.');
    indicators.push('Legitimate banks do not require paying fees or logging into third-party websites to redeem credit card points.');
  }

  // Suspicious Links or Domains
  const hasUrl = /https?:\/\/[^\s]+|bit\.ly|tinyurl|\.xyz|\.top|\.online|\.site|\.app|\.info/i.test(lower);
  if (hasUrl) {
    score += 25;
    detectedScamTypes.push('Suspicious URL / Phishing Domain Redirect');
    indicators.push('Contains shortened URL or non-standard domain extension (.xyz, .top, bit.ly) designed to mask malicious servers.');
  }

  // Phone numbers provided for instant contact
  if (/\b\d{10}\b|\b\d{5}[-\s]\d{5}\b/.test(text) && (lower.includes('officer') || lower.includes('call') || lower.includes('contact'))) {
    indicators.push('Direct personal mobile numbers provided pretending to be "Electricity Officer" or "Bank Manager".');
  }

  // Normal safe check
  if (lower.includes('package') && lower.includes('delivery') && lower.includes('agent') && !lower.includes('click') && !lower.includes('suspended')) {
    // Delivery OTP
    score = Math.max(5, score - 30);
    indicators.push('Message follows legitimate e-commerce delivery notification pattern with physical receipt guidance.');
  }

  score = Math.min(100, Math.max(5, score));

  let riskCategory: ScamMessageAnalysis['riskCategory'] = 'LOW RISK';
  if (score >= 76) riskCategory = 'CRITICAL THREAT';
  else if (score >= 51) riskCategory = 'HIGH RISK SCAM';
  else if (score >= 26) riskCategory = 'SUSPICIOUS';
  else riskCategory = 'LOW RISK';

  // Safe Next Steps
  if (riskCategory === 'CRITICAL THREAT' || riskCategory === 'HIGH RISK SCAM') {
    safeNextSteps.push('DO NOT click any links, open attachments, or dial the phone numbers in the message.');
    safeNextSteps.push('DO NOT enter your UPI PIN or share any OTP with anyone.');
    safeNextSteps.push('Block and report the sender number immediately in WhatsApp / SMS.');
    safeNextSteps.push('Verify bill dues or account status ONLY through official banking apps or Bharat BillPay.');
    safeNextSteps.push('Forward the scam message to the Cyber Crime Helpline at 1930 or report on cybercrime.gov.in.');
  } else if (riskCategory === 'SUSPICIOUS') {
    safeNextSteps.push('Exercise caution. Independently verify the message sender.');
    safeNextSteps.push('Do not share sensitive credentials or approve unsolicited requests.');
  } else {
    safeNextSteps.push('Message appears routine. Remember to only share delivery OTPs upon receiving physical goods.');
  }

  return {
    messageText: text,
    riskScore: score,
    riskCategory,
    confidence: score > 70 ? 96 : 88,
    detectedScamTypes: detectedScamTypes.length > 0 ? detectedScamTypes : ['No major scam archetypes identified'],
    urgencyThreats: urgencyThreats.length > 0 ? urgencyThreats : ['No coercive urgency or threats detected'],
    indicators: indicators.length > 0 ? indicators : ['Language aligns with standard informational notification.'],
    safeNextSteps,
    explanation: score > 50
      ? `This message exhibits distinct hallmarks of a ${detectedScamTypes[0] || 'financial scam'}, leveraging urgent emotional pressure, unauthorized links, or credential solicitation.`
      : `This message does not appear to contain coercive threats or fraudulent credential solicitations, but standard verification is always advised.`,
    channelGuess: text.toLowerCase().includes('dear consumer') || text.toLowerCase().includes('alert:') ? 'SMS' : 'WhatsApp'
  };
}

export function generateInvestigationReport(transactions: Transaction[]): InvestigationReportData {
  const total = transactions.length;
  const totalValue = transactions.reduce((sum, t) => sum + (t.amount || 0), 0);

  const lowCount = transactions.filter(t => (t.riskLevel || 'LOW') === 'LOW').length;
  const modCount = transactions.filter(t => t.riskLevel === 'MODERATE').length;
  const highCount = transactions.filter(t => t.riskLevel === 'HIGH').length;
  const critCount = transactions.filter(t => t.riskLevel === 'CRITICAL').length;
  const suspiciousCount = highCount + critCount;

  // Sort top risk cases
  const sorted = [...transactions].sort((a, b) => (b.riskScore || 0) - (a.riskScore || 0));
  const topRiskCases = sorted.slice(0, 10);

  // Aggregate major anomalies
  const amountAnomaliesCount = transactions.filter(t => t.anomaliesDetected?.amountAnomaly).length;
  const timeAnomaliesCount = transactions.filter(t => t.anomaliesDetected?.unusualTime).length;
  const velocityCount = transactions.filter(t => t.anomaliesDetected?.velocityAnomaly).length;
  const newBeneficiaryCount = transactions.filter(t => t.isNewBeneficiary).length;
  const collectCount = transactions.filter(t => t.type === 'Collect Request').length;

  const majorAnomalies = [
    {
      title: 'Disproportionate Amount Spikes',
      description: 'Transactions exhibiting >4x to 50x deviation from the established baseline average spend.',
      affectedCount: amountAnomaliesCount,
      severity: (amountAnomaliesCount > 0 ? 'HIGH' : 'LOW') as RiskLevel
    },
    {
      title: 'Off-Hours & Nocturnal Execution',
      description: 'Transactions initiated during low-activity windows (11:00 PM to 05:00 AM) typical of unauthorized access.',
      affectedCount: timeAnomaliesCount,
      severity: (timeAnomaliesCount > 0 ? 'HIGH' : 'LOW') as RiskLevel
    },
    {
      title: 'High Velocity / Burst Transfers',
      description: 'Multiple consecutive transaction attempts triggered within rapid 1-hour window.',
      affectedCount: velocityCount,
      severity: (velocityCount > 0 ? 'CRITICAL' : 'LOW') as RiskLevel
    },
    {
      title: 'First-Time / Unverified PayeeVPAs',
      description: 'Transactions directed to newly added beneficiary handles with no historical trust score.',
      affectedCount: newBeneficiaryCount,
      severity: 'MODERATE' as RiskLevel
    },
    {
      title: 'Inbound Collect Request Traps',
      description: 'External pull payment requests masquerading as incoming refunds or prize disbursements.',
      affectedCount: collectCount,
      severity: (collectCount > 0 ? 'CRITICAL' : 'LOW') as RiskLevel
    }
  ];

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });

  return {
    generatedAt: dateStr,
    reportId: `UPIG-AUDIT-${now.getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
    executiveSummary: `Analysis of ${total} transactions totalling ₹${totalValue.toLocaleString('en-IN')} identified ${suspiciousCount} potentially suspicious transactions requiring review (${critCount} Critical, ${highCount} High). Key anomaly drivers include extreme amount variance, unverified collect requests, and coercive payment narratives.`,
    totalTransactionsAnalysed: total,
    totalTransactionValue: totalValue,
    riskBreakdown: {
      low: lowCount,
      moderate: modCount,
      high: highCount,
      critical: critCount
    },
    suspiciousCount,
    majorAnomalies,
    topRiskCases,
    evidenceSynthesis: [
      `Aggregated behavioral profiling indicates ${((suspiciousCount / (total || 1)) * 100).toFixed(1)}% of processed records fall in the elevated risk zone.`,
      `Identified ${collectCount} incoming Collect Requests targeting high-value funds extraction.`,
      `Geographic and device fingerprint variances detected in ${transactions.filter(t => t.isNewDevice).length} records.`
    ],
    recommendedProcedures: [
      'Initiate formal counterparty verification for all transactions scored above 50.',
      'Enforce mandate verification with respective issuing banks for recurring debits.',
      'Educate users regarding UPI Collect Request inversion patterns (PIN is strictly for outgoing debits).',
      'Lodge incident dossiers with National Cyber Crime Helpline (1930 / cybercrime.gov.in) for critical records.',
      'Check device authorization logs and revoke obsolete session tokens in the UPI application.'
    ],
    limitations: [
      'Evaluation is derived from metadata heuristics, behavioral baselines, and synthetic risk modeling.',
      'Absence of an anomaly flag does not guarantee complete absence of malicious activity.',
      'Independent verification with authorized financial institutions is required prior to taking legal or administrative action.'
    ],
    responsibleAiDisclaimer: 'This application provides AI-assisted risk indicators for educational and decision-support purposes. A high risk score does not establish that a transaction is fraudulent. Users should independently verify suspicious transactions and follow applicable bank and regulatory procedures.'
  };
}
