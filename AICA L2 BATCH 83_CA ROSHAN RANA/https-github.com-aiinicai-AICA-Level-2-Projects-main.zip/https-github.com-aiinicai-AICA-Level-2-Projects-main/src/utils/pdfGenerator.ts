import { jsPDF } from 'jspdf';
import { InvestigationReportData } from '../types';

/**
 * Generates and downloads a clean, professional vector PDF audit dossier
 * using jsPDF directly in the browser. Completely bypasses iframe print blocks.
 */
export function generatePdfReport(report: InvestigationReportData): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2; // 182mm
  let currentY = 16;

  // Helper to check page break
  const ensureSpace = (neededHeight: number) => {
    if (currentY + neededHeight > pageHeight - 16) {
      doc.addPage();
      currentY = 18;
      drawRunningHeader();
    }
  };

  const drawRunningHeader = () => {
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text('SMART BANK STATEMENT ANALYSER — ANOMALY & RISK DOSSIER', margin, 10);
    doc.text(`REF: ${report.reportId}`, pageWidth - margin, 10, { align: 'right' });
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.3);
    doc.line(margin, 12, pageWidth - margin, 12);
  };

  // --- 1. TITLE HEADER BLOCK ---
  // Top brand bar
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(margin, currentY, contentWidth, 22, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('SMART BANK STATEMENT ANALYSER // AUDIT DOSSIER', margin + 4, currentY + 7);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225); // slate-300
  doc.text('AI-ASSISTED STATEMENT AUDIT & FINANCIAL THREAT DECISION SUPPORT', margin + 4, currentY + 12);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(248, 113, 113); // red-400
  doc.text('DECISION-SUPPORT CLASSIFICATION: CONFIDENTIAL / RESTRICTED', margin + 4, currentY + 17);

  // Meta stats right aligned inside header
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(226, 232, 240);
  doc.text(`Dossier ID: ${report.reportId}`, pageWidth - margin - 4, currentY + 7, { align: 'right' });
  doc.text(`Generated: ${report.generatedAt}`, pageWidth - margin - 4, currentY + 12, { align: 'right' });
  doc.text(`Total Records: ${report.totalTransactionsAnalysed} Txns`, pageWidth - margin - 4, currentY + 17, { align: 'right' });

  currentY += 26;

  // --- 2. EXECUTIVE SUMMARY ---
  ensureSpace(28);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text('1. EXECUTIVE SUMMARY', margin, currentY);
  currentY += 4;

  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(203, 213, 225); // slate-300
  doc.setLineWidth(0.3);

  const summaryLines = doc.splitTextToSize(report.executiveSummary, contentWidth - 8);
  const summaryBoxHeight = summaryLines.length * 4.2 + 6;

  doc.roundedRect(margin, currentY, contentWidth, summaryBoxHeight, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  doc.text(summaryLines, margin + 4, currentY + 5);

  currentY += summaryBoxHeight + 5;

  // --- 3. VOLUME & RISK STATS SUMMARY ---
  ensureSpace(42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('2. AGGREGATE VOLUME & RISK BREAKDOWN', margin, currentY);
  currentY += 4;

  const cardWidth = (contentWidth - 6) / 4;
  const cardHeight = 13;

  // Card 1: Total Volume
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, cardWidth, cardHeight, 'F');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL VOLUME', margin + 2.5, currentY + 4);
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(`${report.totalTransactionsAnalysed} Records`, margin + 2.5, currentY + 9.5);

  // Card 2: Total Value
  doc.setFillColor(241, 245, 249);
  doc.rect(margin + cardWidth + 2, currentY, cardWidth, cardHeight, 'F');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL VALUE', margin + cardWidth + 4.5, currentY + 4);
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(`INR ${report.totalTransactionValue.toLocaleString('en-IN')}`, margin + cardWidth + 4.5, currentY + 9.5);

  // Card 3: Suspicious
  doc.setFillColor(254, 242, 242); // rose-50
  doc.rect(margin + (cardWidth + 2) * 2, currentY, cardWidth, cardHeight, 'F');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(190, 18, 60); // rose-700
  doc.text('CRITICAL & HIGH', margin + (cardWidth + 2) * 2 + 2.5, currentY + 4);
  doc.setFontSize(9);
  doc.text(`${report.suspiciousCount} Txns`, margin + (cardWidth + 2) * 2 + 2.5, currentY + 9.5);

  // Card 4: Safe
  doc.setFillColor(236, 253, 245); // emerald-50
  doc.rect(margin + (cardWidth + 2) * 3, currentY, cardWidth, cardHeight, 'F');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(4, 120, 87); // emerald-700
  doc.text('SAFE BASELINE', margin + (cardWidth + 2) * 3 + 2.5, currentY + 4);
  doc.setFontSize(9);
  doc.text(`${report.riskBreakdown.low + report.riskBreakdown.moderate} Txns`, margin + (cardWidth + 2) * 3 + 2.5, currentY + 9.5);

  currentY += cardHeight + 4;

  // Breakdown Table
  const tableX = margin;
  const colWidths = [28, 28, 26, 24, 76];
  const headers = ['Risk Tier', 'Score Range', 'Txn Count', '% Total', 'Recommended Stance'];

  doc.setFillColor(226, 232, 240); // slate-200
  doc.rect(tableX, currentY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(30, 41, 59);

  let curColX = tableX + 2;
  headers.forEach((h, i) => {
    doc.text(h, curColX, currentY + 4.2);
    curColX += colWidths[i];
  });
  currentY += 6;

  const total = report.totalTransactionsAnalysed || 1;
  const tableRows = [
    { tier: 'LOW', range: '0 - 25', count: report.riskBreakdown.low, pct: `${Math.round((report.riskBreakdown.low / total) * 100)}%`, stance: 'Standard execution. Routine monitoring.' },
    { tier: 'MODERATE', range: '26 - 50', count: report.riskBreakdown.moderate, pct: `${Math.round((report.riskBreakdown.moderate / total) * 100)}%`, stance: 'Minor deviations. Confirm payee identity.' },
    { tier: 'HIGH', range: '51 - 75', count: report.riskBreakdown.high, pct: `${Math.round((report.riskBreakdown.high / total) * 100)}%`, stance: 'Elevated risk. Secondary phone confirmation required.' },
    { tier: 'CRITICAL', range: '76 - 100', count: report.riskBreakdown.critical, pct: `${Math.round((report.riskBreakdown.critical / total) * 100)}%`, stance: 'Decline collect requests. Audit credentials immediately.' }
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);

  tableRows.forEach((r, idx) => {
    const rowY = currentY;
    if (r.tier === 'CRITICAL') {
      doc.setFillColor(255, 241, 242);
      doc.rect(tableX, rowY, contentWidth, 5.5, 'F');
      doc.setTextColor(190, 18, 60);
      doc.setFont('helvetica', 'bold');
    } else {
      doc.setFillColor(idx % 2 === 0 ? 255 : 248, 250, 252);
      doc.rect(tableX, rowY, contentWidth, 5.5, 'F');
      doc.setTextColor(30, 41, 59);
      doc.setFont('helvetica', 'normal');
    }

    curColX = tableX + 2;
    doc.text(r.tier, curColX, rowY + 3.8);
    curColX += colWidths[0];
    doc.text(r.range, curColX, rowY + 3.8);
    curColX += colWidths[1];
    doc.text(String(r.count), curColX, rowY + 3.8);
    curColX += colWidths[2];
    doc.text(r.pct, curColX, rowY + 3.8);
    curColX += colWidths[3];
    doc.text(r.stance, curColX, rowY + 3.8);

    doc.setDrawColor(241, 245, 249);
    doc.line(tableX, rowY + 5.5, tableX + contentWidth, rowY + 5.5);
    currentY += 5.5;
  });

  currentY += 5;

  // --- 4. MAJOR ANOMALIES IDENTIFIED ---
  ensureSpace(35);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('3. MAJOR ANOMALY VECTORS IDENTIFIED', margin, currentY);
  currentY += 4;

  report.majorAnomalies.forEach((anom) => {
    ensureSpace(12);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, currentY, contentWidth, 10, 1, 1, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    doc.text(`• ${anom.title}`, margin + 3, currentY + 4);

    doc.setFontSize(7);
    const badgeText = `[${anom.severity} — ${anom.affectedCount} Affected]`;
    doc.setTextColor(anom.severity === 'CRITICAL' ? 190 : 180, anom.severity === 'CRITICAL' ? 18 : 83, anom.severity === 'CRITICAL' ? 60 : 9);
    doc.text(badgeText, pageWidth - margin - 3, currentY + 4, { align: 'right' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    const descLines = doc.splitTextToSize(anom.description, contentWidth - 6);
    doc.text(descLines[0] || '', margin + 3, currentY + 7.8);

    currentY += 12;
  });

  currentY += 2;

  // --- 5. HIGH RISK CASES REQUIRING INVESTIGATION ---
  ensureSpace(40);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('4. HIGH-PRIORITY CASES REQUIRING INVESTIGATION', margin, currentY);
  currentY += 4;

  const caseColWidths = [26, 24, 38, 24, 18, 52];
  const caseHeaders = ['Txn ID', 'Timestamp', 'Payee / Counterparty', 'Amount', 'Score', 'Primary Anomaly Signal'];

  doc.setFillColor(226, 232, 240);
  doc.rect(tableX, currentY, contentWidth, 5.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(30, 41, 59);

  let cX = tableX + 2;
  caseHeaders.forEach((h, i) => {
    doc.text(h, cX, currentY + 3.8);
    cX += caseColWidths[i];
  });
  currentY += 5.5;

  report.topRiskCases.slice(0, 6).forEach((tx) => {
    ensureSpace(7);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);

    if (tx.riskLevel === 'CRITICAL') {
      doc.setFillColor(254, 242, 242);
      doc.rect(tableX, currentY, contentWidth, 6, 'F');
      doc.setTextColor(159, 18, 57);
    } else {
      doc.setFillColor(255, 255, 255);
      doc.rect(tableX, currentY, contentWidth, 6, 'F');
      doc.setTextColor(30, 41, 59);
    }

    cX = tableX + 2;
    doc.text(tx.id, cX, currentY + 4.2);
    cX += caseColWidths[0];
    doc.text(`${tx.date} ${tx.time}`, cX, currentY + 4.2);
    cX += caseColWidths[1];

    const payeeShort = tx.beneficiary.length > 20 ? tx.beneficiary.substring(0, 18) + '..' : tx.beneficiary;
    doc.text(payeeShort, cX, currentY + 4.2);
    cX += caseColWidths[2];

    doc.text(`INR ${tx.amount.toLocaleString('en-IN')}`, cX, currentY + 4.2);
    cX += caseColWidths[3];

    doc.setFont('helvetica', 'bold');
    doc.text(`${tx.riskScore}/100`, cX, currentY + 4.2);
    cX += caseColWidths[4];

    doc.setFont('helvetica', 'normal');
    const signalShort = (tx.riskFactors?.[0] || 'Deviation').substring(0, 36);
    doc.text(signalShort, cX, currentY + 4.2);

    doc.setDrawColor(226, 232, 240);
    doc.line(tableX, currentY + 6, tableX + contentWidth, currentY + 6);
    currentY += 6;
  });

  currentY += 4;

  // --- 6. SYNTHESIZED EVIDENCE & RECOMMENDED PROCEDURES ---
  ensureSpace(45);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('5. SYNTHESIZED EVIDENCE & RECOMMENDED PROCEDURES', margin, currentY);
  currentY += 4;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);

  report.evidenceSynthesis.slice(0, 4).forEach((ev) => {
    ensureSpace(6);
    const evLines = doc.splitTextToSize(`• ${ev}`, contentWidth - 4);
    doc.text(evLines, margin + 2, currentY + 3.5);
    currentY += evLines.length * 3.8 + 1;
  });

  currentY += 2;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('Required Security Protocols:', margin, currentY + 3);
  currentY += 5;

  report.recommendedProcedures.slice(0, 4).forEach((proc, idx) => {
    ensureSpace(6);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(4, 120, 87); // emerald-700
    const procLines = doc.splitTextToSize(`[Step ${idx + 1}] ${proc}`, contentWidth - 4);
    doc.text(procLines, margin + 2, currentY + 3.5);
    currentY += procLines.length * 3.8 + 1;
  });

  // --- 7. LEGAL & RESPONSIBLE AI NOTICE ---
  ensureSpace(24);
  currentY += 2;
  doc.setFillColor(254, 243, 199); // amber-100
  doc.setDrawColor(245, 158, 11); // amber-500
  doc.setLineWidth(0.3);
  doc.roundedRect(margin, currentY, contentWidth, 18, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(146, 64, 14); // amber-900
  doc.text('RESPONSIBLE-AI NOTICE & CYBER CRIME HELPLINE', margin + 3, currentY + 4.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  const legalText = `"${report.responsibleAiDisclaimer}" — This system does not request, store, or process OTPs, UPI PINs, CVV codes, or netbanking passwords. If unauthorized debits occur, immediately report to the National Cyber Crime Portal at cybercrime.gov.in or dial the 24x7 Helpline at 1930.`;
  const legalLines = doc.splitTextToSize(legalText, contentWidth - 6);
  doc.text(legalLines, margin + 3, currentY + 8.5);

  // --- RUNNING FOOTERS ON ALL PAGES ---
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);

    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('Smart Bank Statement Analyser Risk Decision Support • https://cybercrime.gov.in (Helpline: 1930)', margin, pageHeight - 8);
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 8, { align: 'right' });
  }

  // Save the document with a clean filename
  const cleanId = report.reportId.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save(`SMART_BANK_STATEMENT_ANALYSER_${cleanId}.pdf`);
}
