export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export type TransactionType =
  | 'P2P'
  | 'P2M (Merchant)'
  | 'Collect Request'
  | 'QR Code Scan'
  | 'Auto-Debit / Mandate'
  | 'NetBanking'
  | 'ATM / Cash';

export interface AnomalyFlags {
  amountAnomaly: boolean;
  unusualTime: boolean;
  velocityAnomaly: boolean;
  newBeneficiaryAnomaly: boolean;
  newDeviceAnomaly: boolean;
  locationAnomaly: boolean;
  urgentLanguageAnomaly: boolean;
  collectRequestRisk?: boolean;
}

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  amount: number;
  type: TransactionType;
  beneficiary: string;
  isNewBeneficiary: boolean;
  isNewDevice: boolean;
  location: string;
  normalAvgAmount: number;
  recentTransactionCount: number; // in past 1h - 24h
  remarks: string;
  // Analysis results
  riskScore?: number; // 0 - 100
  riskLevel?: RiskLevel;
  confidence?: number; // 0 - 100
  riskFactors?: string[];
  evidence?: string[];
  missingInformation?: string[];
  recommendedActions?: string[];
  analysisSummary?: string;
  anomaliesDetected?: AnomalyFlags;
}

export interface ScamMessageAnalysis {
  messageText: string;
  riskScore: number; // 0 - 100
  riskCategory: 'LOW RISK' | 'MODERATE RISK' | 'SUSPICIOUS' | 'HIGH RISK SCAM' | 'CRITICAL THREAT';
  confidence: number;
  detectedScamTypes: string[];
  urgencyThreats: string[];
  indicators: string[];
  safeNextSteps: string[];
  explanation: string;
  channelGuess?: 'SMS' | 'WhatsApp' | 'Email' | 'Unknown';
}

export interface InvestigationReportData {
  generatedAt: string;
  reportId: string;
  executiveSummary: string;
  totalTransactionsAnalysed: number;
  totalTransactionValue: number;
  riskBreakdown: {
    low: number;
    moderate: number;
    high: number;
    critical: number;
  };
  suspiciousCount: number;
  majorAnomalies: Array<{
    title: string;
    description: string;
    affectedCount: number;
    severity: RiskLevel;
  }>;
  topRiskCases: Transaction[];
  evidenceSynthesis: string[];
  recommendedProcedures: string[];
  limitations: string[];
  responsibleAiDisclaimer: string;
}
