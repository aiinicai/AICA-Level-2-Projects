import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  Sparkles, 
  RefreshCw, 
  Calendar, 
  Building2, 
  Lock, 
  Layers, 
  Scale,
  Check,
  Info
} from 'lucide-react';
import { Transaction, InvestigationReportData } from '../types';
import { generateInvestigationReport } from '../utils/riskAnalyzer';
import { generatePdfReport } from '../utils/pdfGenerator';
import { DisclaimerBanner } from './DisclaimerBanner';

interface ReportViewProps {
  transactions: Transaction[];
  onGenerateReportWithAi: (transactions: Transaction[]) => Promise<InvestigationReportData>;
}

export const ReportView: React.FC<ReportViewProps> = ({
  transactions,
  onGenerateReportWithAi
}) => {
  const [reportData, setReportData] = useState<InvestigationReportData>(() => {
    return generateInvestigationReport(transactions);
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<{ type: 'success' | 'info' | 'error'; message: string } | null>(null);

  const handleRefreshReport = async () => {
    setIsGenerating(true);
    setStatusFeedback(null);
    try {
      const fresh = await onGenerateReportWithAi(transactions);
      setReportData(fresh);
      setStatusFeedback({
        type: 'success',
        message: 'Report re-synthesized successfully with latest transaction signals.'
      });
    } catch (err) {
      console.error('Failed to generate report with AI:', err);
      setStatusFeedback({
        type: 'error',
        message: 'Failed to re-synthesize report via AI; local fallback retained.'
      });
    } finally {
      setIsGenerating(false);
      setTimeout(() => setStatusFeedback(null), 4000);
    }
  };

  const handleDownloadPdf = () => {
    setIsExportingPdf(true);
    try {
      generatePdfReport(reportData);
      setStatusFeedback({
        type: 'success',
        message: `PDF dossier generated and downloaded successfully (${reportData.reportId}.pdf).`
      });
    } catch (err: any) {
      console.error('PDF export error:', err);
      setStatusFeedback({
        type: 'error',
        message: `Failed to export PDF: ${err?.message || 'Unexpected error'}`
      });
    } finally {
      setIsExportingPdf(false);
      setTimeout(() => setStatusFeedback(null), 5000);
    }
  };

  const handlePrint = () => {
    try {
      // In browsers, window.print() might be blocked in cross-origin / sandboxed iframes
      window.print();
      setStatusFeedback({
        type: 'info',
        message: 'Sent to system print preview dialog.'
      });
    } catch (err) {
      console.warn('window.print() prevented by sandbox iframe permissions. Downloading PDF directly...', err);
      handleDownloadPdf();
      setStatusFeedback({
        type: 'info',
        message: 'Browser print dialog was restricted in iframe. Automatically generated and downloaded direct PDF file instead.'
      });
    }
    setTimeout(() => setStatusFeedback(null), 6000);
  };

  return (
    <div className="space-y-4">
      {/* Action Bar (Hidden in Print) */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs flex items-center justify-between flex-wrap gap-2 print:hidden">
        <div>
          <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-indigo-600" />
            Fintech Audit & Risk Investigation Dossier
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Decision-support document synthesized from current transaction analytics.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRefreshReport}
            disabled={isGenerating}
            className="flex items-center gap-1 px-2.5 py-1 rounded text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors shadow-2xs disabled:opacity-50 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>Synthesizing AI Audit...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3 h-3 text-indigo-200" />
                <span>Re-Synthesize Report</span>
              </>
            )}
          </button>

          {/* Dedicated Direct PDF Download Button */}
          <button
            onClick={handleDownloadPdf}
            disabled={isExportingPdf}
            className="flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white transition-colors shadow-2xs disabled:opacity-50 cursor-pointer"
            title="Download formatted multi-page PDF document"
          >
            {isExportingPdf ? (
              <>
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>Building PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-indigo-300" />
                <span>Download PDF (.pdf)</span>
              </>
            )}
          </button>

          {/* Print / System Dialog Button */}
          <button
            onClick={handlePrint}
            className="flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-colors shadow-2xs cursor-pointer"
            title="Print or Save via System Dialog (with auto PDF fallback)"
          >
            <Printer className="w-3 h-3 text-slate-500" />
            <span>Print / Dialog</span>
          </button>
        </div>
      </div>

      {statusFeedback && (
        <div className={`p-2.5 rounded text-xs flex items-center justify-between gap-2 print:hidden ${
          statusFeedback.type === 'success' ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' :
          statusFeedback.type === 'info' ? 'bg-indigo-50 text-indigo-900 border border-indigo-200' :
          'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            {statusFeedback.type === 'success' ? <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" /> : <Info className="w-3.5 h-3.5 text-indigo-600 shrink-0" />}
            <span>{statusFeedback.message}</span>
          </div>
          <button 
            onClick={() => setStatusFeedback(null)}
            className="text-[10px] underline font-medium hover:opacity-80 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="print:hidden">
        <DisclaimerBanner compact />
      </div>

      {/* Main Formal Report Paper */}
      <div className="bg-white rounded-lg p-6 sm:p-8 border border-slate-200 shadow-2xs max-w-4xl mx-auto space-y-6 print:border-none print:shadow-none print:p-0">
        {/* Report Header */}
        <div className="border-b border-slate-900 pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                  S
                </span>
                <span className="font-bold text-sm sm:text-base tracking-tight text-slate-900">
                  SMART BANK STATEMENT ANALYSER
                </span>
                <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded font-mono border border-slate-200">
                  DECISION SUPPORT
                </span>
              </div>
              <h1 className="text-sm font-bold text-slate-800 mt-1">
                Statement Anomaly & Risk Evaluation Dossier
              </h1>
            </div>

            <div className="text-left sm:text-right text-[11px] text-slate-600 font-mono space-y-0.5">
              <div><span className="text-slate-400">Dossier ID:</span> <strong>{reportData.reportId}</strong></div>
              <div><span className="text-slate-400">Generated:</span> {reportData.generatedAt}</div>
              <div><span className="text-slate-400">Classification:</span> DECISION SUPPORT / CONFIDENTIAL</div>
            </div>
          </div>
        </div>

        {/* Executive Summary */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            1. Executive Summary
          </h2>
          <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs leading-relaxed text-slate-800">
            <p>{reportData.executiveSummary}</p>
          </div>
        </section>

        {/* Aggregate Volume & Risk Breakdown */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            2. Aggregate Volume & Risk Breakdown
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Volume</span>
              <span className="text-sm font-bold text-slate-900 font-mono">{reportData.totalTransactionsAnalysed} Records</span>
            </div>
            <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Value</span>
              <span className="text-sm font-bold text-slate-900 font-mono">₹{reportData.totalTransactionValue.toLocaleString('en-IN')}</span>
            </div>
            <div className="p-2.5 bg-rose-50 rounded border border-rose-200">
              <span className="text-[10px] font-bold text-rose-700 uppercase block">Critical & High</span>
              <span className="text-sm font-bold text-rose-700 font-mono">{reportData.suspiciousCount} Txns</span>
            </div>
            <div className="p-2.5 bg-emerald-50 rounded border border-emerald-200">
              <span className="text-[10px] font-bold text-emerald-700 uppercase block">Safe Baseline</span>
              <span className="text-sm font-bold text-emerald-700 font-mono">{reportData.riskBreakdown.low + reportData.riskBreakdown.moderate} Txns</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-700 border border-slate-200 rounded">
              <thead className="bg-slate-50 text-slate-600 font-bold text-[10px] uppercase tracking-wider">
                <tr>
                  <th className="p-2">Risk Tier</th>
                  <th className="p-2">Score Range</th>
                  <th className="p-2 text-center">Transaction Count</th>
                  <th className="p-2 text-right">% of Total</th>
                  <th className="p-2">Recommended Stance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[11px]">
                <tr>
                  <td className="p-2 font-bold text-emerald-700">LOW</td>
                  <td className="p-2 font-mono">0 – 25</td>
                  <td className="p-2 text-center font-semibold font-mono">{reportData.riskBreakdown.low}</td>
                  <td className="p-2 text-right font-mono">{reportData.totalTransactionsAnalysed > 0 ? Math.round((reportData.riskBreakdown.low / reportData.totalTransactionsAnalysed) * 100) : 0}%</td>
                  <td className="p-2 text-slate-600">Standard execution. Routine monitoring.</td>
                </tr>
                <tr>
                  <td className="p-2 font-bold text-amber-700">MODERATE</td>
                  <td className="p-2 font-mono">26 – 50</td>
                  <td className="p-2 text-center font-semibold font-mono">{reportData.riskBreakdown.moderate}</td>
                  <td className="p-2 text-right font-mono">{reportData.totalTransactionsAnalysed > 0 ? Math.round((reportData.riskBreakdown.moderate / reportData.totalTransactionsAnalysed) * 100) : 0}%</td>
                  <td className="p-2 text-slate-600">Minor deviations. Confirm payee details.</td>
                </tr>
                <tr>
                  <td className="p-2 font-bold text-orange-700">HIGH</td>
                  <td className="p-2 font-mono">51 – 75</td>
                  <td className="p-2 text-center font-semibold font-mono">{reportData.riskBreakdown.high}</td>
                  <td className="p-2 text-right font-mono">{reportData.totalTransactionsAnalysed > 0 ? Math.round((reportData.riskBreakdown.high / reportData.totalTransactionsAnalysed) * 100) : 0}%</td>
                  <td className="p-2 text-slate-600">Elevated risk. Secondary phone confirmation required.</td>
                </tr>
                <tr className="bg-rose-50/50">
                  <td className="p-2 font-bold text-rose-700">CRITICAL</td>
                  <td className="p-2 font-mono">76 – 100</td>
                  <td className="p-2 text-center font-semibold text-rose-700 font-mono">{reportData.riskBreakdown.critical}</td>
                  <td className="p-2 text-right font-semibold text-rose-700 font-mono">{reportData.totalTransactionsAnalysed > 0 ? Math.round((reportData.riskBreakdown.critical / reportData.totalTransactionsAnalysed) * 100) : 0}%</td>
                  <td className="p-2 text-rose-900 font-bold">Immediate decline of collect request. Audit credentials.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* Major Anomalies Matrix */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            3. Major Anomaly Vectors Identified
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {reportData.majorAnomalies.map((anom, idx) => (
              <div key={idx} className="p-2.5 rounded border border-slate-200 bg-slate-50/70 space-y-0.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs">{anom.title}</span>
                  <span className={`text-[9px] font-bold font-mono px-1.5 py-0.2 rounded ${
                    anom.severity === 'CRITICAL' ? 'bg-rose-100 text-rose-800' :
                    anom.severity === 'HIGH' ? 'bg-orange-100 text-orange-800' :
                    'bg-slate-200 text-slate-700'
                  }`}>
                    {anom.affectedCount} Affected
                  </span>
                </div>
                <p className="text-slate-600 text-[10px] leading-snug">{anom.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* High-Risk Cases Detail Table */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            4. High-Priority Cases Requiring Investigation
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-700 border border-slate-200 rounded">
              <thead className="bg-slate-50 text-slate-600 font-bold text-[10px] uppercase tracking-wider">
                <tr>
                  <th className="p-2">Txn ID</th>
                  <th className="p-2">Time</th>
                  <th className="p-2">Beneficiary / Type</th>
                  <th className="p-2 text-right">Amount</th>
                  <th className="p-2 text-center">Score</th>
                  <th className="p-2">Primary Anomaly Signal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[11px]">
                {reportData.topRiskCases.slice(0, 5).map((tx) => (
                  <tr key={tx.id} className={tx.riskLevel === 'CRITICAL' ? 'bg-rose-50/40' : ''}>
                    <td className="p-2 font-mono font-bold text-slate-900">{tx.id}</td>
                    <td className="p-2 text-slate-500 whitespace-nowrap text-[10px]">{tx.date} {tx.time}</td>
                    <td className="p-2">
                      <span className="font-semibold text-slate-900 block truncate max-w-[150px]">{tx.beneficiary}</span>
                      <span className="text-[9px] text-slate-500 font-mono">{tx.type}</span>
                    </td>
                    <td className="p-2 text-right font-bold text-slate-900 font-mono whitespace-nowrap">
                      ₹{tx.amount.toLocaleString('en-IN')}
                    </td>
                    <td className="p-2 text-center font-mono font-bold">
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                        tx.riskLevel === 'CRITICAL' ? 'bg-rose-600 text-white' : 'bg-orange-500 text-white'
                      }`}>
                        {tx.riskScore}
                      </span>
                    </td>
                    <td className="p-2 text-slate-600 max-w-xs truncate text-[10px]">
                      {tx.riskFactors?.[0] || 'Deviation from baseline'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Evidence Synthesis */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            5. Synthesized Behavioral Evidence
          </h2>
          <div className="space-y-1.5">
            {reportData.evidenceSynthesis.map((ev, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs text-slate-700 bg-slate-50 p-2 rounded border border-slate-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                <span className="text-[11px] leading-snug">{ev}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Recommended Verification Procedures */}
        <section className="space-y-2">
          <h2 className="text-[10px] uppercase font-bold tracking-wider text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
            6. Recommended Verification Procedures & Escalations
          </h2>
          <div className="space-y-1.5">
            {reportData.recommendedProcedures.map((proc, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs text-slate-800 bg-emerald-50/50 p-2.5 rounded border border-emerald-200/80">
                <span className="w-3.5 h-3.5 rounded bg-emerald-200 text-emerald-900 font-bold text-[9px] flex items-center justify-center shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-[11px] leading-snug">{proc}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Responsible AI Disclaimer */}
        <section className="pt-3 border-t border-slate-900">
          <div className="bg-amber-50/80 border border-amber-200 p-3 rounded text-amber-950 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[10px] uppercase tracking-wider text-amber-900">
              <Scale className="w-3.5 h-3.5 text-amber-700" />
              Responsible-AI Disclaimer & Legal Notice
            </div>
            <p className="text-[11px] leading-relaxed text-amber-900">
              <strong>“{reportData.responsibleAiDisclaimer}”</strong>
            </p>
            <p className="text-[10px] text-amber-800/80">
              This system does not request, store, or process OTPs, UPI PINs, CVV codes, or netbanking passwords.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};
