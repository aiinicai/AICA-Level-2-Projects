import React from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  DollarSign, 
  TrendingUp, 
  Zap, 
  FileText, 
  Search, 
  MessageSquareWarning, 
  ArrowUpRight, 
  Shield, 
  CheckCircle2,
  Clock,
  Smartphone,
  MapPin,
  HelpCircle,
  Activity
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';
import { Transaction } from '../types';
import { TabType } from './Navbar';
import { DisclaimerBanner } from './DisclaimerBanner';

interface DashboardViewProps {
  transactions: Transaction[];
  setActiveTab: (tab: TabType) => void;
  onSelectTransaction: (tx: Transaction) => void;
}

const RISK_COLORS = {
  LOW: '#10b981',      // Emerald 500
  MODERATE: '#f59e0b', // Amber 500
  HIGH: '#f97316',     // Orange 500
  CRITICAL: '#ef4444'  // Rose/Red 500
};

export const DashboardView: React.FC<DashboardViewProps> = ({
  transactions,
  setActiveTab,
  onSelectTransaction
}) => {
  const totalCount = transactions.length;
  const totalValue = transactions.reduce((sum, t) => sum + (t.amount || 0), 0);

  const lowTransactions = transactions.filter(t => (t.riskLevel || 'LOW') === 'LOW');
  const modTransactions = transactions.filter(t => t.riskLevel === 'MODERATE');
  const highTransactions = transactions.filter(t => t.riskLevel === 'HIGH');
  const critTransactions = transactions.filter(t => t.riskLevel === 'CRITICAL');

  const suspiciousCount = highTransactions.length + critTransactions.length;
  const suspiciousValue = [...highTransactions, ...critTransactions].reduce((sum, t) => sum + t.amount, 0);

  const overallRiskTier = critTransactions.length > 0 ? 'Critical' : highTransactions.length > 0 ? 'High' : modTransactions.length > 0 ? 'Moderate' : 'Low';
  const overallRiskColor = critTransactions.length > 0 ? 'text-rose-700 border-l-rose-500' : highTransactions.length > 0 ? 'text-orange-700 border-l-orange-500' : modTransactions.length > 0 ? 'text-amber-700 border-l-amber-500' : 'text-emerald-700 border-l-emerald-500';

  const pieData = [
    { name: 'Low (0-25)', value: lowTransactions.length, color: RISK_COLORS.LOW },
    { name: 'Moderate (26-50)', value: modTransactions.length, color: RISK_COLORS.MODERATE },
    { name: 'High (51-75)', value: highTransactions.length, color: RISK_COLORS.HIGH },
    { name: 'Critical (76-100)', value: critTransactions.length, color: RISK_COLORS.CRITICAL },
  ].filter(d => d.value > 0);

  const barData = [
    {
      level: 'Low',
      count: lowTransactions.length,
      amount: lowTransactions.reduce((acc, t) => acc + t.amount, 0),
      fill: RISK_COLORS.LOW
    },
    {
      level: 'Moderate',
      count: modTransactions.length,
      amount: modTransactions.reduce((acc, t) => acc + t.amount, 0),
      fill: RISK_COLORS.MODERATE
    },
    {
      level: 'High',
      count: highTransactions.length,
      amount: highTransactions.reduce((acc, t) => acc + t.amount, 0),
      fill: RISK_COLORS.HIGH
    },
    {
      level: 'Critical',
      count: critTransactions.length,
      amount: critTransactions.reduce((acc, t) => acc + t.amount, 0),
      fill: RISK_COLORS.CRITICAL
    }
  ];

  // Calculate top risk indicators
  const indicatorCounts = {
    amount: transactions.filter(t => t.anomaliesDetected?.amountAnomaly).length,
    time: transactions.filter(t => t.anomaliesDetected?.unusualTime).length,
    velocity: transactions.filter(t => t.anomaliesDetected?.velocityAnomaly).length,
    newBeneficiary: transactions.filter(t => t.isNewBeneficiary).length,
    newDevice: transactions.filter(t => t.isNewDevice).length,
    collectRequest: transactions.filter(t => t.type === 'Collect Request').length,
    urgentRemarks: transactions.filter(t => t.anomaliesDetected?.urgentLanguageAnomaly).length
  };

  const topIndicators = [
    {
      title: 'Amount Outliers (>4x - 50x Baseline)',
      count: indicatorCounts.amount,
      pct: totalCount > 0 ? Math.round((indicatorCounts.amount / totalCount) * 100) : 0,
      icon: TrendingUp,
      badge: 'Spike Anomaly'
    },
    {
      title: 'Incoming Collect Request Traps',
      count: indicatorCounts.collectRequest,
      pct: totalCount > 0 ? Math.round((indicatorCounts.collectRequest / totalCount) * 100) : 0,
      icon: AlertTriangle,
      badge: 'Inbound Pull'
    },
    {
      title: 'Off-Hours / Overnight (11 PM - 5 AM)',
      count: indicatorCounts.time,
      pct: totalCount > 0 ? Math.round((indicatorCounts.time / totalCount) * 100) : 0,
      icon: Clock,
      badge: 'Timing Anomaly'
    },
    {
      title: 'Unregistered / Foreign Device Login',
      count: indicatorCounts.newDevice,
      pct: totalCount > 0 ? Math.round((indicatorCounts.newDevice / totalCount) * 100) : 0,
      icon: Smartphone,
      badge: 'Device Flag'
    },
    {
      title: 'Coercive Pretexts in Narration',
      count: indicatorCounts.urgentRemarks,
      pct: totalCount > 0 ? Math.round((indicatorCounts.urgentRemarks / totalCount) * 100) : 0,
      icon: MessageSquareWarning,
      badge: 'NLP Threat'
    }
  ];

  return (
    <div className="space-y-4">
      {/* Top Advisory Banner */}
      <DisclaimerBanner compact />

      {/* High-Density 4-KPI Grid (Matching the theme archetype) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 shrink-0">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Total Analyzed</div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">{totalCount.toLocaleString('en-IN')}</div>
          <div className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
            <span>+12% batch velocity</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Anomalies Detected</div>
          <div className="text-xl sm:text-2xl font-black text-rose-600 mt-0.5">{suspiciousCount}</div>
          <div className="text-xs text-rose-600 font-medium mt-1">
            {critTransactions.length} Critical Cases
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Volume Audited</div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
            ₹{(totalValue / 100000).toFixed(2)}L
          </div>
          <div className="text-xs text-slate-500 mt-1 font-medium italic">
            Avg ₹{totalCount > 0 ? Math.round(totalValue / totalCount).toLocaleString('en-IN') : 0}
          </div>
        </div>

        <div className={`bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs border-l-4 ${overallRiskColor}`}>
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Active Risk Stance</div>
          <div className={`text-xl sm:text-2xl font-black mt-0.5 ${critTransactions.length > 0 ? 'text-rose-600' : 'text-orange-600'}`}>
            {overallRiskTier}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-medium">
            {suspiciousCount > 0 ? `${suspiciousCount} requiring review` : 'Baseline Normal'}
          </div>
        </div>
      </div>

      {/* 4 Risk Tiers Breakdown Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-lg p-2.5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-[10px] font-bold text-emerald-900 uppercase">Low (0–25)</span>
            </div>
            <p className="text-base font-bold text-emerald-950 mt-0.5">{lowTransactions.length} txns</p>
          </div>
          <span className="text-[11px] font-semibold text-emerald-800 font-mono">
            ₹{lowTransactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString('en-IN')}
          </span>
        </div>

        <div className="bg-amber-50/70 border border-amber-200 rounded-lg p-2.5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span className="text-[10px] font-bold text-amber-900 uppercase">Moderate (26–50)</span>
            </div>
            <p className="text-base font-bold text-amber-950 mt-0.5">{modTransactions.length} txns</p>
          </div>
          <span className="text-[11px] font-semibold text-amber-800 font-mono">
            ₹{modTransactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString('en-IN')}
          </span>
        </div>

        <div className="bg-orange-50/70 border border-orange-200 rounded-lg p-2.5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-orange-500" />
              <span className="text-[10px] font-bold text-orange-900 uppercase">High (51–75)</span>
            </div>
            <p className="text-base font-bold text-orange-950 mt-0.5">{highTransactions.length} txns</p>
          </div>
          <span className="text-[11px] font-semibold text-orange-800 font-mono">
            ₹{highTransactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString('en-IN')}
          </span>
        </div>

        <div className="bg-rose-50/70 border border-rose-200 rounded-lg p-2.5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span className="text-[10px] font-bold text-rose-900 uppercase">Critical (76–100)</span>
            </div>
            <p className="text-base font-bold text-rose-950 mt-0.5">{critTransactions.length} txns</p>
          </div>
          <span className="text-[11px] font-semibold text-rose-800 font-mono">
            ₹{critTransactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString('en-IN')}
          </span>
        </div>
      </div>

      {/* Visual Analytics Dual Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Risk Distribution Chart */}
        <div className="lg:col-span-6 bg-white rounded-lg p-4 border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-indigo-600" />
              Risk Tier Distribution
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">{totalCount} Samples</span>
          </div>

          <div className="h-56 w-full flex items-center justify-center my-2">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={48}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(val: any) => [`${val} transactions`, 'Volume']}
                    contentStyle={{ borderRadius: '6px', fontSize: '11px', border: '1px solid #cbd5e1', padding: '6px 10px' }}
                  />
                  <Legend 
                    formatter={(val) => <span className="text-[11px] font-medium text-slate-700">{val}</span>} 
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-slate-400 text-xs py-8">
                No transaction data available.
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between text-slate-600 bg-slate-50 px-2.5 py-1 rounded">
              <span>Safe Baseline:</span>
              <span className="font-bold text-emerald-700">
                {totalCount > 0 ? Math.round(((lowTransactions.length + modTransactions.length) / totalCount) * 100) : 0}%
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600 bg-slate-50 px-2.5 py-1 rounded">
              <span>Elevated Risk:</span>
              <span className="font-bold text-rose-700">
                {totalCount > 0 ? Math.round((suspiciousCount / totalCount) * 100) : 0}%
              </span>
            </div>
          </div>
        </div>

        {/* Volume & Value Exposure by Risk Level */}
        <div className="lg:col-span-6 bg-white rounded-lg p-4 border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
              Financial Exposure (INR ₹)
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Rupees</span>
          </div>

          <div className="h-56 w-full my-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <XAxis dataKey="level" tick={{ fontSize: 10, fill: '#475569' }} />
                <YAxis 
                  tick={{ fontSize: 9, fill: '#64748b' }}
                  tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} 
                />
                <Tooltip 
                  formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Exposure']}
                  contentStyle={{ borderRadius: '6px', fontSize: '11px', border: '1px solid #cbd5e1', padding: '6px 10px' }}
                />
                <Bar dataKey="amount" radius={[3, 3, 0, 0]}>
                  {barData.map((entry, index) => (
                    <Cell key={`bar-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[11px] text-slate-600 bg-slate-50 px-2.5 py-1 rounded border border-slate-100 flex items-center justify-between">
            <span className="font-medium text-slate-700">Critical Exposure:</span>
            <span className="font-bold text-rose-700">
              ₹{critTransactions.reduce((acc, t) => acc + t.amount, 0).toLocaleString('en-IN')} (Needs Verification)
            </span>
          </div>
        </div>
      </div>

      {/* Primary Risk Indicators Matrix */}
      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              Primary Anomaly & Risk Indicators Detected
            </h3>
          </div>
          <button
            onClick={() => setActiveTab('history')}
            className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 hover:underline cursor-pointer"
          >
            Statement Audit <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {topIndicators.map((ind, i) => {
            const Icon = ind.icon;
            return (
              <div key={i} className="p-2.5 rounded border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-colors">
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded bg-white border border-slate-200 text-slate-700">
                    <Icon className="w-3.5 h-3.5 text-indigo-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-900 truncate">
                        {ind.title}
                      </span>
                      <span className="text-[10px] font-mono font-bold text-slate-700 bg-white px-1.5 py-0.2 rounded border border-slate-200">
                        {ind.count}
                      </span>
                    </div>
                    <div className="mt-1.5 w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                      <div 
                        className="bg-indigo-600 h-full rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(5, ind.pct))}%` }}
                      />
                    </div>
                    <span className="text-[9px] text-slate-500 mt-1 block">
                      Present in {ind.pct}% of records
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Launch Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div 
          onClick={() => setActiveTab('single')}
          className="group cursor-pointer bg-white p-3.5 rounded-lg border border-slate-200 hover:border-indigo-400 shadow-2xs transition-all flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">Live Evaluation</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </div>
            <h4 className="font-bold text-xs text-slate-900">Single Transaction Analyzer</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
              Evaluate real-time payments with comprehensive AI dials and checklist.
            </p>
          </div>
          <span className="text-[10px] text-indigo-600 font-semibold mt-2 block">Launch Analyzer →</span>
        </div>

        <div 
          onClick={() => setActiveTab('history')}
          className="group cursor-pointer bg-white p-3.5 rounded-lg border border-slate-200 hover:border-indigo-400 shadow-2xs transition-all flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">Batch Ingestion</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </div>
            <h4 className="font-bold text-xs text-slate-900">Statement History & Top 10</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
              Upload CSV/Excel statements to spot velocity bursts and audit anomalies.
            </p>
          </div>
          <span className="text-[10px] text-indigo-600 font-semibold mt-2 block">View Statement Table →</span>
        </div>

        <div 
          onClick={() => setActiveTab('scam')}
          className="group cursor-pointer bg-white p-3.5 rounded-lg border border-slate-200 hover:border-indigo-400 shadow-2xs transition-all flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">NLP Threat Check</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </div>
            <h4 className="font-bold text-xs text-slate-900">Scam & SMS Threat Checker</h4>
            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
              Inspect suspicious SMS, WhatsApp, and KYC threats with prompt AI diagnosis.
            </p>
          </div>
          <span className="text-[10px] text-indigo-600 font-semibold mt-2 block">Scan Message →</span>
        </div>
      </div>
    </div>
  );
};
