import React from 'react';
import { AlertTriangle, Lock, ShieldCheck } from 'lucide-react';

interface Props {
  compact?: boolean;
}

export const DisclaimerBanner: React.FC<Props> = ({ compact = false }) => {
  return (
    <div className={`w-full bg-amber-50/80 border border-amber-200/90 text-amber-950 rounded-lg ${compact ? 'p-2.5' : 'p-3'} shadow-2xs`}>
      <div className="flex items-start gap-2.5">
        <div className="p-1 bg-amber-100 rounded text-amber-700 shrink-0 mt-0.5">
          <AlertTriangle className="w-4 h-4" />
        </div>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-[10px] tracking-wider uppercase bg-amber-200/80 text-amber-900 px-1.5 py-0.2 rounded font-mono">
              Decision Support Notice
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] text-amber-800 font-medium">
              <Lock className="w-3 h-3 text-emerald-600" />
              Zero Credential Policy: Never share OTP or UPI PIN
            </span>
          </div>
          <p className="leading-snug text-amber-900/90 font-normal text-[11px] sm:text-xs">
            <strong>“This application provides AI-assisted risk indicators for educational and decision-support purposes. A high risk score does not establish that a transaction is fraudulent. Users should independently verify suspicious transactions and follow applicable bank and regulatory procedures.”</strong>
          </p>
          {!compact && (
            <div className="flex items-center gap-3 pt-0.5 text-[10px] text-amber-800/80 flex-wrap">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" /> Educational & Decision Support Only
              </span>
              <span>•</span>
              <span>Never request or store banking PINs, passwords, or CVV</span>
              <span>•</span>
              <span>National Cyber Fraud Helpline: 1930</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
