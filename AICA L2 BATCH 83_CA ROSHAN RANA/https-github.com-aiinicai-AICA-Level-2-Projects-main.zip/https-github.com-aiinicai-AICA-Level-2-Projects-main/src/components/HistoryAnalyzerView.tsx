import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileSpreadsheet, 
  FileText, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Search, 
  Filter, 
  Download, 
  Eye, 
  Sparkles, 
  RefreshCw, 
  TrendingUp, 
  Clock, 
  AlertCircle, 
  ArrowUpDown,
  X,
  FileCheck
} from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { Transaction, RiskLevel } from '../types';
import { calculateTransactionRisk } from '../utils/riskAnalyzer';
import { DisclaimerBanner } from './DisclaimerBanner';

interface HistoryAnalyzerViewProps {
  transactions: Transaction[];
  onUpdateTransactions: (txs: Transaction[]) => void;
  onSelectTransactionForSingleView: (tx: Transaction) => void;
}

export const HistoryAnalyzerView: React.FC<HistoryAnalyzerViewProps> = ({
  transactions,
  onUpdateTransactions,
  onSelectTransactionForSingleView
}) => {
  const [filterLevel, setFilterLevel] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'score' | 'amount' | 'date'>('score');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [selectedModalTx, setSelectedModalTx] = useState<Transaction | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Parse uploaded file (CSV or Excel)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    setUploadFeedback(null);

    const fileName = file.name.toLowerCase();
    const reader = new FileReader();

    if (fileName.endsWith('.csv') || fileName.endsWith('.txt')) {
      reader.onload = (evt) => {
        try {
          const csvText = evt.target?.result as string;
          Papa.parse(csvText, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
              processRawRows(results.data as any[]);
            },
            error: (err) => {
              setUploadFeedback(`CSV parse error: ${err.message}`);
              setIsProcessingFile(false);
            }
          });
        } catch (err: any) {
          setUploadFeedback(`Failed to parse CSV: ${err.message}`);
          setIsProcessingFile(false);
        }
      };
      reader.readAsText(file);
    } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
      reader.onload = (evt) => {
        try {
          const data = new Uint8Array(evt.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const json = XLSX.utils.sheet_to_json(worksheet);
          processRawRows(json as any[]);
        } catch (err: any) {
          setUploadFeedback(`Failed to parse Excel spreadsheet: ${err.message}`);
          setIsProcessingFile(false);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      setUploadFeedback('Supported formats: .csv, .xlsx, .xls, or .txt statements');
      setIsProcessingFile(false);
    }
  };

  const processRawRows = (rows: any[]) => {
    if (!rows || rows.length === 0) {
      setUploadFeedback('No rows found in uploaded statement.');
      setIsProcessingFile(false);
      return;
    }

    const parsedTxs: Transaction[] = rows.map((row, idx) => {
      const id = row.id || row['Transaction ID'] || row['Txn ID'] || row['Ref No'] || `TXN-STMT-${1000 + idx}`;
      const date = row.date || row['Date'] || row['Value Date'] || new Date().toISOString().split('T')[0];
      const time = row.time || row['Time'] || '12:00';
      const amount = parseFloat(String(row.amount || row['Amount'] || row['Debit'] || row['Withdrawal'] || 1000).replace(/[^0-9.]/g, '')) || 1000;
      const type = (row.type || row['Type'] || row['Txn Type'] || 'P2P') as any;
      const beneficiary = row.beneficiary || row['Beneficiary'] || row['Payee'] || row['Description'] || 'unknown_beneficiary@upi';
      const isNewBeneficiary = Boolean(row.isNewBeneficiary || row['New Beneficiary'] === 'Yes' || row['New Beneficiary'] === true);
      const isNewDevice = Boolean(row.isNewDevice || row['New Device'] === 'Yes' || row['New Device'] === true);
      const location = row.location || row['Location'] || row['City'] || 'Domestic';
      const normalAvgAmount = parseFloat(String(row.normalAvgAmount || row['Normal Avg'] || 2000)) || 2000;
      const recentTransactionCount = parseInt(String(row.recentTransactionCount || row['Velocity'] || 1), 10) || 1;
      const remarks = row.remarks || row['Remarks'] || row['Narration'] || row['Description'] || '';

      const baseTx = {
        id: String(id),
        date: String(date),
        time: String(time),
        amount,
        type,
        beneficiary: String(beneficiary),
        isNewBeneficiary,
        isNewDevice,
        location: String(location),
        normalAvgAmount,
        recentTransactionCount,
        remarks: String(remarks)
      };

      return calculateTransactionRisk(baseTx);
    });

    onUpdateTransactions(parsedTxs);
    setIsProcessingFile(false);
    setUploadFeedback(`Successfully imported and analyzed ${parsedTxs.length} transactions.`);
  };

  const top10Investigation = [...transactions]
    .sort((a, b) => (b.riskScore || 0) - (a.riskScore || 0))
    .slice(0, 10);

  const filteredTransactions = transactions.filter(t => {
    if (filterLevel !== 'ALL' && t.riskLevel !== filterLevel) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchId = t.id.toLowerCase().includes(q);
      const matchBeneficiary = t.beneficiary.toLowerCase().includes(q);
      const matchRemarks = t.remarks.toLowerCase().includes(q);
      const matchLocation = t.location.toLowerCase().includes(q);
      if (!matchId && !matchBeneficiary && !matchRemarks && !matchLocation) return false;
    }
    return true;
  }).sort((a, b) => {
    let comparison = 0;
    if (sortBy === 'score') comparison = (b.riskScore || 0) - (a.riskScore || 0);
    else if (sortBy === 'amount') comparison = (b.amount || 0) - (a.amount || 0);
    else if (sortBy === 'date') comparison = `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`);
    return sortOrder === 'desc' ? comparison : -comparison;
  });

  const getRiskBadge = (level?: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return <span className="bg-rose-100 text-rose-800 border border-rose-200 text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">CRITICAL</span>;
      case 'HIGH':
        return <span className="bg-orange-100 text-orange-800 border border-orange-200 text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">HIGH</span>;
      case 'MODERATE':
        return <span className="bg-amber-100 text-amber-800 border border-amber-200 text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">MODERATE</span>;
      default:
        return <span className="bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">LOW</span>;
    }
  };

  const handleExportCsv = () => {
    const csv = Papa.unparse(transactions.map(t => ({
      'Transaction ID': t.id,
      'Date': t.date,
      'Time': t.time,
      'Amount (INR)': t.amount,
      'Type': t.type,
      'Beneficiary': t.beneficiary,
      'Risk Score': t.riskScore,
      'Risk Level': t.riskLevel,
      'Confidence': `${t.confidence}%`,
      'Primary Anomaly': t.riskFactors?.[0] || 'None',
      'Remarks': t.remarks,
      'Recommended Action': t.recommendedActions?.[0] || 'None'
    })));

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `smart_bank_statement_audit_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      <DisclaimerBanner compact />

      {/* Upload Zone in High Density */}
      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between flex-wrap gap-2 pb-2.5 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
              Statement & Batch History Ingestion
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Upload bank statements (.csv, .xlsx, .xls) to scan for velocity bursts and amount outliers.
            </p>
          </div>
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded shadow-2xs transition-colors cursor-pointer"
          >
            <Download className="w-3 h-3 text-slate-500" />
            <span>Export CSV Dataset</span>
          </button>
        </div>

        <div className="mt-3 grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-8">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border border-dashed border-slate-300 hover:border-indigo-500 bg-slate-50 hover:bg-indigo-50/20 p-4 rounded-lg text-center cursor-pointer transition-all flex flex-col items-center justify-center"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv, .xlsx, .xls, .txt"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-1.5">
                <Upload className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                Click to browse or drop CSV / Excel bank statement
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">
                Auto-maps columns (Date, Time, Amount, Beneficiary, Remarks, Type)
              </span>
            </div>
          </div>

          <div className="md:col-span-4 bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1.5">
            <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">
              Statement Summary
            </span>
            <div className="flex justify-between text-xs text-slate-600">
              <span>Loaded records:</span>
              <span className="font-bold font-mono text-slate-900">{transactions.length}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-600">
              <span>Suspicious requiring review:</span>
              <span className="font-bold font-mono text-rose-600">
                {transactions.filter(t => t.riskLevel === 'HIGH' || t.riskLevel === 'CRITICAL').length}
              </span>
            </div>
            <div className="flex justify-between text-xs text-slate-600">
              <span>Total Volume:</span>
              <span className="font-bold font-mono text-slate-900">
                ₹{transactions.reduce((acc, t) => acc + t.amount, 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {uploadFeedback && (
          <div className="mt-2.5 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-900 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>{uploadFeedback}</span>
          </div>
        )}
      </div>

      {/* TOP 10 TRANSACTIONS REQUIRING INVESTIGATION */}
      <div className="bg-white rounded-lg p-4 border border-rose-200 shadow-2xs">
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-rose-100 text-rose-700 rounded">
              <ShieldAlert className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Top 10 Transactions Requiring Investigation
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Priority queue sorted by highest AI risk indicator score.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-mono font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded border border-rose-200">
            {top10Investigation.filter(t => (t.riskScore || 0) >= 50).length} Elevated Priority
          </span>
        </div>

        <div className="mt-3 space-y-2">
          {top10Investigation.map((tx, idx) => (
            <div 
              key={tx.id}
              onClick={() => setSelectedModalTx(tx)}
              className="group cursor-pointer bg-slate-50/60 hover:bg-slate-50 border border-slate-200 hover:border-rose-300 p-3 rounded-lg shadow-2xs transition-all"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded bg-slate-900 text-white font-mono font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-xs text-slate-900 font-mono">{tx.id}</span>
                      <span className="text-[10px] text-slate-500 font-medium">{tx.date} • {tx.time}</span>
                      <span className="text-[9px] font-semibold bg-white border border-slate-200 text-slate-700 px-1.5 py-0.2 rounded font-mono">
                        {tx.type}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-700 mt-0.5 flex items-center gap-1.5 flex-wrap">
                      <span className="text-slate-500">Payee:</span>
                      <span className="font-semibold text-slate-900">{tx.beneficiary}</span>
                      {tx.isNewBeneficiary && (
                        <span className="text-[9px] bg-rose-50 text-rose-700 border border-rose-200 px-1 py-0.2 rounded font-mono">
                          New Payee
                        </span>
                      )}
                      {tx.isNewDevice && (
                        <span className="text-[9px] bg-amber-50 text-amber-700 border border-amber-200 px-1 py-0.2 rounded font-mono">
                          Foreign Device
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-3 border-t md:border-t-0 pt-1.5 md:pt-0 border-slate-200">
                  <div className="text-right">
                    <span className="text-sm font-bold text-slate-900 block font-mono">
                      ₹{tx.amount.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      Normal: ₹{tx.normalAvgAmount?.toLocaleString('en-IN')}
                    </span>
                  </div>

                  <div className="text-right min-w-[75px]">
                    <div className="flex items-center justify-end gap-1">
                      <span className="text-xs font-bold text-slate-900 font-mono">{tx.riskScore}</span>
                      <span className="text-[9px] text-slate-400">/100</span>
                    </div>
                    {getRiskBadge(tx.riskLevel)}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectTransactionForSingleView(tx);
                    }}
                    className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors cursor-pointer"
                    title="Audit in Live Analyzer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-1.5 text-[11px]">
                <div className="text-slate-700">
                  <span className="font-semibold text-rose-950">Primary Risk Driver: </span>
                  <span className="text-slate-600">{tx.riskFactors?.[0] || 'Parameter deviation'}</span>
                </div>
                <div className="text-slate-700">
                  <span className="font-semibold text-emerald-950">Recommended Action: </span>
                  <span className="text-slate-600">{tx.recommendedActions?.[0] || 'Verify with counterparty'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Statement Explorer Table */}
      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              All Analysed Statement Records ({filteredTransactions.length})
            </h3>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3 h-3 absolute left-2 top-2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search payee / remarks..."
                className="pl-7 pr-2.5 py-1 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900 w-44 sm:w-56"
              />
            </div>

            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded border border-slate-200">
              {['ALL', 'CRITICAL', 'HIGH', 'MODERATE', 'LOW'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setFilterLevel(lvl)}
                  className={`px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer ${
                    filterLevel === lvl
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto mt-2">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="py-2 px-2.5">Txn ID / Time</th>
                <th className="py-2 px-2.5">Type</th>
                <th className="py-2 px-2.5">Beneficiary</th>
                <th className="py-2 px-2.5 text-right">Amount</th>
                <th className="py-2 px-2.5 text-center">Score</th>
                <th className="py-2 px-2.5 text-center">Risk Tier</th>
                <th className="py-2 px-2.5">Primary Anomaly Signal</th>
                <th className="py-2 px-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.map((tx) => (
                <tr 
                  key={tx.id} 
                  className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                  onClick={() => setSelectedModalTx(tx)}
                >
                  <td className="py-2 px-2.5">
                    <span className="font-mono font-bold text-slate-900 block text-xs">{tx.id}</span>
                    <span className="text-[9px] text-slate-500">{tx.date} • {tx.time}</span>
                  </td>
                  <td className="py-2 px-2.5">
                    <span className="bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded text-[9px] font-mono whitespace-nowrap">
                      {tx.type}
                    </span>
                  </td>
                  <td className="py-2 px-2.5">
                    <span className="font-semibold text-slate-900 block truncate max-w-[160px] text-xs">
                      {tx.beneficiary}
                    </span>
                    <span className="text-[9px] text-slate-500 truncate max-w-[160px] block">
                      {tx.remarks || 'No remarks'}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 text-right font-bold text-slate-900 font-mono whitespace-nowrap text-xs">
                    ₹{tx.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="py-2 px-2.5 text-center font-mono font-bold text-slate-900 text-xs">
                    {tx.riskScore || 0}
                  </td>
                  <td className="py-2 px-2.5 text-center">
                    {getRiskBadge(tx.riskLevel)}
                  </td>
                  <td className="py-2 px-2.5 text-slate-600 max-w-xs truncate text-[11px]">
                    {tx.riskFactors?.[0] || 'Within normal parameters'}
                  </td>
                  <td className="py-2 px-2.5 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTransactionForSingleView(tx);
                      }}
                      className="px-2 py-0.5 text-[10px] font-bold text-indigo-600 hover:bg-indigo-50 rounded border border-indigo-200 transition-colors cursor-pointer"
                    >
                      Audit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Detail Modal */}
      {selectedModalTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-xl w-full p-4 shadow-xl border border-slate-200 space-y-3 my-8">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-indigo-600" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                  Risk Dossier ({selectedModalTx.id})
                </h3>
              </div>
              <button
                onClick={() => setSelectedModalTx(null)}
                className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-50 p-2.5 rounded text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Amount</span>
                <span className="font-bold font-mono text-slate-900">₹{selectedModalTx.amount.toLocaleString('en-IN')}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Risk Score</span>
                <span className="font-bold font-mono text-slate-900">{selectedModalTx.riskScore} / 100</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Risk Tier</span>
                <div className="mt-0.5">{getRiskBadge(selectedModalTx.riskLevel)}</div>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Execution</span>
                <span className="font-semibold text-slate-900 text-[11px]">{selectedModalTx.date} {selectedModalTx.time}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-700 block mb-0.5">Payee & Location:</span>
                <p className="text-slate-700 bg-slate-50 p-1.5 rounded border border-slate-200 font-mono text-[11px]">
                  {selectedModalTx.beneficiary} ({selectedModalTx.location || 'Location Not provided'})
                </p>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-700 block mb-0.5">Narration / Remarks:</span>
                <p className="text-slate-700 bg-slate-50 p-1.5 rounded border border-slate-200 text-[11px]">
                  {selectedModalTx.remarks || 'None'}
                </p>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-950 block mb-0.5">Detected Anomaly Signals:</span>
                <ul className="list-disc list-inside space-y-0.5 text-slate-700 bg-rose-50/50 p-2 rounded border border-rose-100 text-[11px]">
                  {(selectedModalTx.riskFactors || []).map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-950 block mb-0.5">Recommended Actions:</span>
                <ul className="list-disc list-inside space-y-0.5 text-slate-700 bg-emerald-50/50 p-2 rounded border border-emerald-100 text-[11px]">
                  {(selectedModalTx.recommendedActions || []).map((a, i) => (
                    <li key={i}>{a}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => {
                  const tx = selectedModalTx;
                  setSelectedModalTx(null);
                  onSelectTransactionForSingleView(tx);
                }}
                className="px-3 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded transition-all shadow-2xs cursor-pointer"
              >
                Inspect in Live Analyzer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
