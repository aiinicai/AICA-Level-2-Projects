import React from 'react';
import { 
  Activity, 
  Search, 
  FileSpreadsheet, 
  MessageSquareWarning, 
  FileText, 
  Sparkles, 
  Shield, 
  Lock, 
  PhoneCall, 
  CheckCircle2,
  Download
} from 'lucide-react';

export type TabType = 'dashboard' | 'single' | 'history' | 'scam' | 'report';

interface HeaderProps {
  onLoadDemoData: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onLoadDemoData }) => {
  return (
    <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0 z-30">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-bold text-sm shadow-xs">
          S
        </div>
        <div className="flex items-center gap-2">
          <h1 className="text-sm sm:text-base font-bold tracking-tight text-slate-900">
            SMART <span className="text-indigo-600">BANK STATEMENT ANALYSER</span>
          </h1>
          <span className="hidden xl:inline-block px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[10px] font-mono border border-slate-200">
            v2.4.0-STABLE
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={onLoadDemoData}
          className="px-2.5 py-1.5 bg-white border border-indigo-200 text-indigo-600 hover:bg-indigo-50 text-xs font-semibold rounded transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
          title="Load 10 synthetic UPI banking transactions with verified anomaly profiles"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
          <span className="hidden sm:inline">Load Demo Data</span>
        </button>

        <a
          href="/api/download-project-zip"
          download="SMART_BANK_STATEMENT_ANALYSER.zip"
          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
          title="Download complete SMART BANK STATEMENT ANALYSER folder (.zip) for GitHub submission"
        >
          <Download className="w-3.5 h-3.5 text-indigo-300" />
          <span className="hidden md:inline">GitHub Submission ZIP</span>
          <span className="md:hidden">ZIP</span>
        </a>

        <div className="flex items-center gap-2 border-l border-slate-200 pl-2 sm:pl-3">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-medium text-slate-600 hidden lg:inline">
            AI Engine Online
          </span>
        </div>
      </div>
    </header>
  );
};

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  transactionCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  transactionCount
}) => {
  const monitoringNav = [
    { id: 'dashboard' as TabType, label: 'Dashboard', icon: Activity, emoji: '📊' },
    { id: 'single' as TabType, label: 'Live Analyzer', icon: Search, emoji: '🔍' },
    { id: 'history' as TabType, label: 'Statement History', icon: FileSpreadsheet, emoji: '📜', badge: transactionCount },
    { id: 'scam' as TabType, label: 'Scam Checker', icon: MessageSquareWarning, emoji: '💬' },
  ];

  const docNav = [
    { id: 'report' as TabType, label: 'Investigation Report', icon: FileText, emoji: '📋' },
  ];

  return (
    <aside className="w-56 bg-slate-900 text-slate-300 flex flex-col shrink-0 border-r border-slate-800 select-none">
      <nav className="flex-1 p-3 space-y-4 overflow-y-auto">
        {/* Monitoring Group */}
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1.5 px-2 tracking-wider">
            Monitoring
          </div>
          <div className="space-y-1">
            {monitoringNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <div
                  key={item.id}
                  id={`sidebar-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center justify-between px-3 py-2 rounded text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className="text-sm">{item.emoji}</span>
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                        isActive ? 'bg-indigo-800 text-white' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Documentation Group */}
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1.5 px-2 tracking-wider">
            Documentation
          </div>
          <div className="space-y-1">
            {docNav.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <div
                  key={item.id}
                  id={`sidebar-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className="text-sm">{item.emoji}</span>
                  <span className="truncate">{item.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Sidebar Footer */}
      <div className="p-3 border-t border-slate-800 text-[10px] text-slate-400 space-y-1 bg-slate-950/40">
        <div className="flex items-center gap-1.5 text-slate-300 font-medium">
          <Shield className="w-3 h-3 text-indigo-400" />
          <span>Decision-Support Mode</span>
        </div>
        <div className="text-[9px] text-slate-500">
          Cyber Helpline: <span className="text-slate-300 font-mono">1930</span>
        </div>
      </div>
    </aside>
  );
};

interface MobileNavProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  transactionCount: number;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  setActiveTab,
  transactionCount
}) => {
  const tabs = [
    { id: 'dashboard' as TabType, label: 'Dashboard', emoji: '📊' },
    { id: 'single' as TabType, label: 'Analyzer', emoji: '🔍' },
    { id: 'history' as TabType, label: 'History', emoji: '📜', badge: transactionCount },
    { id: 'scam' as TabType, label: 'Scams', emoji: '💬' },
    { id: 'report' as TabType, label: 'Report', emoji: '📋' },
  ];

  return (
    <div className="md:hidden bg-slate-900 border-b border-slate-800 px-2 py-1.5 flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs whitespace-nowrap transition-all ${
              isActive
                ? 'bg-indigo-600 text-white font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{tab.emoji}</span>
            <span>{tab.label}</span>
            {tab.badge !== undefined && (
              <span className="text-[9px] bg-slate-800 px-1 py-0.2 rounded font-mono text-slate-300">
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
