import React, { useState } from 'react';
import { 
  MessageSquareWarning, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Sparkles, 
  RefreshCw, 
  Copy, 
  Check, 
  Lock, 
  ExternalLink, 
  PhoneCall, 
  AlertOctagon, 
  FileQuestion, 
  HelpCircle 
} from 'lucide-react';
import { ScamMessageAnalysis } from '../types';
import { DEMO_SCAM_MESSAGES } from '../data/demoData';
import { DisclaimerBanner } from './DisclaimerBanner';

interface ScamCheckerViewProps {
  onCheckScamMessage: (messageText: string) => Promise<ScamMessageAnalysis>;
}

export const ScamCheckerView: React.FC<ScamCheckerViewProps> = ({
  onCheckScamMessage
}) => {
  const [messageInput, setMessageInput] = useState(DEMO_SCAM_MESSAGES[0].text);
  const [analysisResult, setAnalysisResult] = useState<ScamMessageAnalysis | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSelectPreset = (preset: typeof DEMO_SCAM_MESSAGES[0]) => {
    setMessageInput(preset.text);
    setAnalysisResult(null);
  };

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!messageInput.trim()) return;

    setIsChecking(true);
    try {
      const result = await onCheckScamMessage(messageInput);
      setAnalysisResult(result);
    } catch (err) {
      console.error('Failed to check scam message:', err);
    } finally {
      setIsChecking(false);
    }
  };

  const handleCopyReport = () => {
    if (!analysisResult) return;
    const text = `[UPI Guardian Scam Analysis]
Risk Category: ${analysisResult.riskCategory} (Score: ${analysisResult.riskScore}/100)
Detected Scam Types:
${analysisResult.detectedScamTypes.map(t => `- ${t}`).join('\n')}
Urgency & Threats:
${analysisResult.urgencyThreats.map(u => `- ${u}`).join('\n')}
Safe Next Steps:
${analysisResult.safeNextSteps.map(s => `- ${s}`).join('\n')}
Cyber Crime Helpline: 1930 / cybercrime.gov.in`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCategoryBadge = (cat?: ScamMessageAnalysis['riskCategory']) => {
    switch (cat) {
      case 'CRITICAL THREAT':
        return 'bg-rose-100 text-rose-800 border border-rose-200';
      case 'HIGH RISK SCAM':
        return 'bg-orange-100 text-orange-800 border border-orange-200';
      case 'SUSPICIOUS':
        return 'bg-amber-100 text-amber-800 border border-amber-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border border-emerald-200';
    }
  };

  return (
    <div className="space-y-4">
      <DisclaimerBanner compact />

      {/* Preset Selector */}
      <div className="bg-slate-900 text-white p-3 rounded-lg border border-slate-800 shadow-2xs">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              Scam & Phishing Test Archetypes
            </span>
          </div>
          <span className="text-[10px] text-slate-400">Select template to inspect AI threat detection</span>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          {DEMO_SCAM_MESSAGES.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSelectPreset(preset)}
              className="px-2.5 py-1 rounded text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span className="text-[9px] bg-slate-700 px-1 py-0.2 rounded font-mono text-slate-300">
                {preset.channel}
              </span>
              <span>{preset.title}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Message Input Area */}
        <div className="lg:col-span-6 bg-white rounded-lg p-4 border border-slate-200 shadow-2xs">
          <div className="pb-2.5 mb-3 border-b border-slate-100">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
              <MessageSquareWarning className="w-4 h-4 text-indigo-600" />
              Scam & Threat Message Analyzer
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Paste SMS notifications, WhatsApp payment links, or electricity/KYC pretexts.
            </p>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                Raw Message Content *
              </label>
              <textarea
                rows={6}
                required
                value={messageInput}
                onChange={e => setMessageInput(e.target.value)}
                className="w-full p-2.5 text-xs leading-relaxed border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900 font-sans"
                placeholder="Paste suspicious SMS, WhatsApp, or email text here..."
              />
              <div className="flex justify-between items-center text-[10px] text-slate-500 mt-1">
                <span>Length: {messageInput.length} chars</span>
                <span className="text-amber-800 font-bold">Never paste actual OTP or UPI PIN</span>
              </div>
            </div>

            <div className="p-2.5 bg-amber-50 rounded border border-amber-200 text-xs text-amber-900 space-y-1">
              <div className="font-bold flex items-center gap-1 text-[11px] uppercase tracking-wider text-amber-950">
                <Lock className="w-3 h-3 text-amber-700" />
                Golden Rules for UPI & SMS Security:
              </div>
              <ul className="list-disc list-inside text-[10px] text-amber-900/90 space-y-0.5">
                <li><strong>UPI PIN is ONLY for sending money</strong> — NEVER to receive money or refunds.</li>
                <li>Electricity discoms & banks never send personal mobile numbers for clearance.</li>
                <li>Banks never threaten 24h account freeze via SMS shortlinks.</li>
              </ul>
            </div>

            <button
              type="submit"
              disabled={isChecking || !messageInput.trim()}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded font-bold text-xs bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all disabled:opacity-50 cursor-pointer"
            >
              {isChecking ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning Threat Signals with AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                  <span>Analyze Message For Scam Indicators</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Column: AI Analysis Result */}
        <div className="lg:col-span-6 space-y-3">
          {analysisResult ? (
            <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-2xs space-y-3.5">
              {/* Header */}
              <div className="flex items-center justify-between pb-2.5 border-b border-slate-100 flex-wrap gap-2">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">
                    AI Threat Evaluation
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold font-mono ${getCategoryBadge(analysisResult.riskCategory)}`}>
                      {analysisResult.riskCategory}
                    </span>
                    <span className="text-xs font-bold font-mono text-slate-900">
                      Risk Score: {analysisResult.riskScore} / 100
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleCopyReport}
                  className="flex items-center gap-1 text-[11px] text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded border border-slate-200 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy Advisory'}</span>
                </button>
              </div>

              {/* Explanation Text */}
              <div className={`p-2.5 rounded border text-xs leading-relaxed ${
                analysisResult.riskScore >= 50
                  ? 'bg-rose-50 border-rose-200 text-rose-950'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-950'
              }`}>
                <span className="font-bold block text-[10px] uppercase tracking-wider mb-0.5">Risk Summary:</span>
                {analysisResult.explanation}
              </div>

              {/* Detected Scam Types */}
              <div>
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-rose-600" />
                  Identified Scam Patterns & Vectors
                </h4>
                <div className="flex flex-wrap gap-1">
                  {analysisResult.detectedScamTypes.map((type, idx) => (
                    <span 
                      key={idx}
                      className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200 font-mono"
                    >
                      {type}
                    </span>
                  ))}
                </div>
              </div>

              {/* Urgency & Threats */}
              <div>
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <AlertOctagon className="w-3 h-3 text-amber-600" />
                  Coercive Urgency & Threat Triggers
                </h4>
                <div className="space-y-1">
                  {analysisResult.urgencyThreats.map((threat, idx) => (
                    <div key={idx} className="text-xs text-slate-700 bg-amber-50/60 border border-amber-100 p-1.5 rounded flex items-start gap-1.5">
                      <span className="text-amber-600 font-bold shrink-0">•</span>
                      <span>{threat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safe Next Steps */}
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-indigo-600" />
                  Safe Next Steps & Protection Actions
                </h4>
                <div className="space-y-1">
                  {analysisResult.safeNextSteps.map((step, idx) => (
                    <div key={idx} className="text-xs text-slate-800 bg-slate-50 border border-slate-200 p-2 rounded flex items-start gap-2">
                      <span className="w-3.5 h-3.5 rounded bg-indigo-100 text-indigo-800 text-[9px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="text-[11px] leading-snug">{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Helpline info */}
              <div className="bg-slate-900 text-white p-2.5 rounded text-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                  <div>
                    <span className="font-bold text-slate-100 block text-[11px]">National Cyber Crime Helpline</span>
                    <span className="text-[10px] text-slate-400">Dial 1930 or visit cybercrime.gov.in</span>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-400 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700 font-mono">
                  24/7
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg p-8 border border-dashed border-slate-300 text-center flex flex-col items-center justify-center min-h-[340px] shadow-2xs">
              <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mb-2.5">
                <MessageSquareWarning className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Ready to Inspect Message</h4>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Paste any SMS, WhatsApp text, or email notice on the left to trigger real-time AI scam detection.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
