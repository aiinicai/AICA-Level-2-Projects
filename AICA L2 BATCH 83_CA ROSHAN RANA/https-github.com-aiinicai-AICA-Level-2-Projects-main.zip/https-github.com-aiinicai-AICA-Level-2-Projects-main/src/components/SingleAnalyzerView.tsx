import React, { useState } from 'react';
import { 
  Search, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  Clock, 
  Sparkles, 
  ArrowRight, 
  RefreshCw, 
  Info,
  Smartphone,
  MapPin,
  FileCheck,
  TrendingUp,
  AlertOctagon,
  Copy,
  Check
} from 'lucide-react';
import { Transaction, TransactionType, RiskLevel } from '../types';
import { DisclaimerBanner } from './DisclaimerBanner';

interface SingleAnalyzerViewProps {
  onAnalyzeTransaction: (tx: Transaction) => Promise<Transaction>;
  selectedTx?: Transaction | null;
  onSaveToHistory?: (tx: Transaction) => void;
}

const PRESET_EXAMPLES: Array<{ name: string; desc: string; data: Partial<Transaction> }> = [
  {
    name: '🔴 Utility Collect Trap',
    desc: '2:45 AM collect request of ₹89,500 claiming power cut',
    data: {
      id: 'TXN-2026-98124',
      date: '2026-08-20',
      time: '02:45',
      amount: 89500,
      type: 'Collect Request',
      beneficiary: 'helpdesk.power_urgent@oksbi',
      isNewBeneficiary: true,
      isNewDevice: true,
      location: 'Jamtara, JH (Unknown IP)',
      normalAvgAmount: 1800,
      recentTransactionCount: 6,
      remarks: 'URGENT ELECTRICITY BILL OVERDUE DISCONNECT REF 4492'
    }
  },
  {
    name: '🔴 Fake KYC QR Scan',
    desc: '3:12 AM ₹45,000 QR scan pretending to be KYC re-verification',
    data: {
      id: 'TXN-2026-89410',
      date: '2026-08-20',
      time: '03:12',
      amount: 45000,
      type: 'QR Code Scan',
      beneficiary: 'instant_kyc_verification@paytm',
      isNewBeneficiary: true,
      isNewDevice: true,
      location: 'Nuh, HR (Proxy Network)',
      normalAvgAmount: 2200,
      recentTransactionCount: 4,
      remarks: 'KYC RE-VERIFICATION REFUND DEPOSIT'
    }
  },
  {
    name: '🟠 Crypto Escrow Transfer',
    desc: '11:40 PM ₹32,000 transfer to unknown crypto escrow handle',
    data: {
      id: 'TXN-2026-77312',
      date: '2026-08-19',
      time: '23:40',
      amount: 32000,
      type: 'P2P',
      beneficiary: 'vikram.crypto.p2p@icici',
      isNewBeneficiary: true,
      isNewDevice: false,
      location: 'Bengaluru, KA',
      normalAvgAmount: 3500,
      recentTransactionCount: 3,
      remarks: 'USDT escrow exchange payment'
    }
  },
  {
    name: '🟡 Weekend Trip Split',
    desc: 'Moderate amount spike to a new friend handle',
    data: {
      id: 'TXN-2026-65109',
      date: '2026-08-19',
      time: '21:15',
      amount: 14500,
      type: 'P2P',
      beneficiary: 'rahul.verma@okhdfcbank',
      isNewBeneficiary: true,
      isNewDevice: false,
      location: 'Bengaluru, KA',
      normalAvgAmount: 4000,
      recentTransactionCount: 1,
      remarks: 'Weekend trip Airbnb split share'
    }
  },
  {
    name: '🟢 Routine Grocery (Safe)',
    desc: '₹450 routine grocery order during daytime',
    data: {
      id: 'TXN-2026-43198',
      date: '2026-08-19',
      time: '14:20',
      amount: 450,
      type: 'P2M (Merchant)',
      beneficiary: 'zepto.grocery@icici',
      isNewBeneficiary: false,
      isNewDevice: false,
      location: 'Bengaluru, KA',
      normalAvgAmount: 1200,
      recentTransactionCount: 1,
      remarks: 'Quick groceries delivery'
    }
  }
];

export const SingleAnalyzerView: React.FC<SingleAnalyzerViewProps> = ({
  onAnalyzeTransaction,
  selectedTx,
  onSaveToHistory
}) => {
  const [formData, setFormData] = useState<Transaction>(() => {
    if (selectedTx) return selectedTx;
    return {
      id: `TXN-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toISOString().split('T')[0],
      time: '14:30',
      amount: 25000,
      type: 'Collect Request',
      beneficiary: 'fast_support_billpay@oksbi',
      isNewBeneficiary: true,
      isNewDevice: true,
      location: 'Remote IP (Proxy)',
      normalAvgAmount: 2000,
      recentTransactionCount: 4,
      remarks: 'URGENT ELECTRICITY BILL REFUND VERIFICATION'
    };
  });

  const [analyzedResult, setAnalyzedResult] = useState<Transaction | null>(selectedTx || null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [checkedActions, setCheckedActions] = useState<{ [idx: number]: boolean }>({});

  const handleApplyPreset = (preset: typeof PRESET_EXAMPLES[0]) => {
    const newTx: Transaction = {
      ...formData,
      ...preset.data,
      id: preset.data.id || `TXN-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`
    } as Transaction;
    setFormData(newTx);
    setAnalyzedResult(null);
    setCheckedActions({});
  };

  const handleRunAnalysis = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsAnalyzing(true);
    try {
      const result = await onAnalyzeTransaction(formData);
      setAnalyzedResult(result);
      if (onSaveToHistory) {
        onSaveToHistory(result);
      }
    } catch (err) {
      console.error('Analysis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleAction = (idx: number) => {
    setCheckedActions(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const handleCopySummary = () => {
    if (!analyzedResult) return;
    const summaryText = `[UPI Guardian Risk Dossier]
Txn ID: ${analyzedResult.id}
Amount: ₹${analyzedResult.amount}
Risk Score: ${analyzedResult.riskScore}/100 (${analyzedResult.riskLevel})
Confidence: ${analyzedResult.confidence}%
Key Factors:
${(analyzedResult.riskFactors || []).map(f => `- ${f}`).join('\n')}
Recommended Actions:
${(analyzedResult.recommendedActions || []).map(a => `- ${a}`).join('\n')}
Disclaimer: AI-assisted risk indicator for decision-support purposes.`;

    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getRiskBadgeColor = (level?: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return 'bg-rose-100 text-rose-700 border border-rose-200';
      case 'HIGH':
        return 'bg-orange-100 text-orange-700 border border-orange-200';
      case 'MODERATE':
        return 'bg-amber-100 text-amber-800 border border-amber-200';
      default:
        return 'bg-emerald-100 text-emerald-700 border border-emerald-200';
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Advisory Banner */}
      <DisclaimerBanner compact />

      {/* Preset Quick Fill Bar in High Density */}
      <div className="bg-slate-900 text-white p-3 rounded-lg border border-slate-800 shadow-2xs">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              Synthetic Demo Test Scenarios
            </span>
          </div>
          <span className="text-[10px] text-slate-400">Click to instantly populate evaluation form</span>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          {PRESET_EXAMPLES.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="px-2.5 py-1 rounded text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 whitespace-nowrap transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>{preset.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Form Parameters */}
        <div className="lg:col-span-6 bg-white rounded-lg p-4 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-indigo-600" />
                Transaction Parameters
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Enter payment attributes to evaluate risk indicators.
              </p>
            </div>
            <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
              ID: {formData.id}
            </span>
          </div>

          <form onSubmit={handleRunAnalysis} className="space-y-3">
            {/* Row 1: Amount & Normal Baseline */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Transaction Amount (₹) *
                </label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1.5 text-slate-400 font-bold text-xs">₹</span>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={formData.amount}
                    onChange={e => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                    className="w-full pl-6 pr-2.5 py-1.5 text-xs font-bold border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-slate-900"
                    placeholder="50000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Normal Spend Baseline (₹) *
                </label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1.5 text-slate-400 font-bold text-xs">₹</span>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formData.normalAvgAmount}
                    onChange={e => setFormData({ ...formData, normalAvgAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full pl-6 pr-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-slate-900"
                    placeholder="2000"
                  />
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5 block">
                  Deviation: {(formData.amount / (formData.normalAvgAmount || 1)).toFixed(1)}x normal
                </span>
              </div>
            </div>

            {/* Row 2: Date & Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={e => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Time (24-Hour Format)
                </label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={e => setFormData({ ...formData, time: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                />
              </div>
            </div>

            {/* Row 3: Transaction Type & Beneficiary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Transaction Type
                </label>
                <select
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value as TransactionType })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                >
                  <option value="P2P">P2P (Peer-to-Peer)</option>
                  <option value="P2M (Merchant)">P2M (Merchant Payment)</option>
                  <option value="Collect Request">Collect Request (Incoming Pull)</option>
                  <option value="QR Code Scan">QR Code Scan</option>
                  <option value="Auto-Debit / Mandate">Auto-Debit / Mandate</option>
                  <option value="NetBanking">NetBanking</option>
                  <option value="ATM / Cash">ATM / Cash Withdrawal</option>
                </select>
                {formData.type === 'Collect Request' && (
                  <span className="text-[9px] text-rose-600 font-bold mt-0.5 block">
                    ⚠️ Inbound Collect requires entering UPI PIN
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Beneficiary (UPI ID / Payee)
                </label>
                <input
                  type="text"
                  value={formData.beneficiary}
                  onChange={e => setFormData({ ...formData, beneficiary: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                  placeholder="e.g. name@oksbi"
                />
              </div>
            </div>

            {/* Row 4: Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-2.5 bg-slate-50 rounded border border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-800 block">New Beneficiary?</span>
                  <span className="text-[9px] text-slate-500">First-time transfer</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isNewBeneficiary: !formData.isNewBeneficiary })}
                  className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${
                    formData.isNewBeneficiary ? 'bg-rose-500' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                      formData.isNewBeneficiary ? 'translate-x-4.5' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-800 block">New / Foreign Device?</span>
                  <span className="text-[9px] text-slate-500">Unrecognized handset/IP</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isNewDevice: !formData.isNewDevice })}
                  className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${
                    formData.isNewDevice ? 'bg-rose-500' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                      formData.isNewDevice ? 'translate-x-4.5' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Row 5: Location & Recent Velocity */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Location / Geolocation Tag
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                  placeholder="e.g. Mumbai, MH"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Recent Txns (Velocity Past 24h)
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.recentTransactionCount}
                  onChange={e => setFormData({ ...formData, recentTransactionCount: parseInt(e.target.value, 10) || 0 })}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900"
                  placeholder="1"
                />
              </div>
            </div>

            {/* Row 6: Remarks */}
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                Transaction Remarks / Narration
              </label>
              <textarea
                rows={2}
                value={formData.remarks}
                onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900 resize-none"
                placeholder="e.g. URGENT ELECTRICITY BILL OVERDUE DISCONNECT REF 4492"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-1">
              <button
                type="submit"
                disabled={isAnalyzing}
                className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded font-bold text-xs bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all disabled:opacity-50 cursor-pointer"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Evaluating Anomaly Signals with AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                    <span>Run AI Risk Evaluation</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: AI Risk Indicator Score & Decision Support Dossier */}
        <div className="lg:col-span-6 space-y-3">
          {analyzedResult ? (
            <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-2xs space-y-3.5">
              {/* Header: Score Gauge + Risk Level */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 flex-wrap gap-2">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">
                    AI Risk Indicator
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${getRiskBadgeColor(analyzedResult.riskLevel)}`}>
                      {analyzedResult.riskLevel} RISK ({analyzedResult.riskScore}/100)
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      Confidence: {analyzedResult.confidence}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopySummary}
                    className="flex items-center gap-1 text-[11px] text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded border border-slate-200 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy Dossier'}</span>
                  </button>
                </div>
              </div>

              {/* Score Meter Visual */}
              <div className="bg-slate-50 p-3 rounded border border-slate-200">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600">Risk Scale Meter</span>
                  <span className="text-xs font-mono font-bold text-slate-900">
                    {analyzedResult.riskScore} / 100
                  </span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden flex">
                  <div className="h-full bg-emerald-500" style={{ width: '25%' }} title="0-25 Low" />
                  <div className="h-full bg-amber-500" style={{ width: '25%' }} title="26-50 Moderate" />
                  <div className="h-full bg-orange-500" style={{ width: '25%' }} title="51-75 High" />
                  <div className="h-full bg-rose-500" style={{ width: '25%' }} title="76-100 Critical" />
                </div>
                <div className="relative mt-1">
                  <div 
                    className="absolute -top-1 transform -translate-x-1/2 flex flex-col items-center"
                    style={{ left: `${Math.min(98, Math.max(2, analyzedResult.riskScore || 0))}%` }}
                  >
                    <div className="w-2 h-2 rotate-45 bg-slate-900" />
                  </div>
                  <div className="flex justify-between text-[9px] text-slate-500 pt-2 font-mono">
                    <span>0 (Low)</span>
                    <span>25</span>
                    <span>50</span>
                    <span>75</span>
                    <span>100 (Critical)</span>
                  </div>
                </div>
              </div>

              {/* Summary Text */}
              {analyzedResult.analysisSummary && (
                <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded text-xs text-blue-950 leading-relaxed">
                  <span className="font-bold block text-blue-900 mb-0.5 text-[11px] uppercase tracking-wider">
                    Executive Assessment:
                  </span>
                  {analyzedResult.analysisSummary}
                </div>
              )}

              {/* Key Risk Factors */}
              <div>
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-600" />
                  Key Risk Factors Identified ({analyzedResult.riskFactors?.length || 0})
                </h4>
                <div className="space-y-1">
                  {(analyzedResult.riskFactors || []).map((factor, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-800 bg-rose-50/50 border border-rose-100 p-1.5 rounded">
                      <span className="text-rose-600 font-bold shrink-0">•</span>
                      <span>{factor}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Evidence Synthesized */}
              <div>
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <FileCheck className="w-3 h-3 text-emerald-600" />
                  Empirical Evidence & Behavioral Patterns
                </h4>
                <div className="space-y-1">
                  {(analyzedResult.evidence || []).map((item, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-700 bg-slate-50 p-1.5 rounded border border-slate-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Verification Checklist */}
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-[10px] font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-indigo-600" />
                  Recommended Verification Checklist
                </h4>
                <div className="space-y-1.5">
                  {(analyzedResult.recommendedActions || []).map((action, idx) => (
                    <label 
                      key={idx} 
                      onClick={() => toggleAction(idx)}
                      className={`flex items-start gap-2 p-2 rounded border text-xs cursor-pointer transition-all ${
                        checkedActions[idx] 
                          ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950 line-through opacity-75' 
                          : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={Boolean(checkedActions[idx])}
                        onChange={() => {}}
                        className="rounded text-indigo-600 focus:ring-indigo-500 mt-0.5 h-3.5 w-3.5"
                      />
                      <span className="leading-snug text-[11px]">{action}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg p-8 border border-dashed border-slate-300 text-center flex flex-col items-center justify-center min-h-[360px] shadow-2xs">
              <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-2.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Awaiting Analysis</h4>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Fill in transaction details or pick a synthetic preset scenario above to evaluate risk.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
