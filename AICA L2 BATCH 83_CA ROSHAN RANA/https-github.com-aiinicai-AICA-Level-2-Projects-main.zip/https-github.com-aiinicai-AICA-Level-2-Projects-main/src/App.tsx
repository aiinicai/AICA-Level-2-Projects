/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header, Sidebar, MobileNav, TabType } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { SingleAnalyzerView } from './components/SingleAnalyzerView';
import { HistoryAnalyzerView } from './components/HistoryAnalyzerView';
import { ScamCheckerView } from './components/ScamCheckerView';
import { ReportView } from './components/ReportView';
import { Transaction, ScamMessageAnalysis, InvestigationReportData } from './types';
import { INITIAL_DEMO_TRANSACTIONS } from './data/demoData';
import { calculateTransactionRisk, analyzeScamMessage, generateInvestigationReport } from './utils/riskAnalyzer';
import { Shield, Lock, PhoneCall, AlertTriangle, Sparkles, Check } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_DEMO_TRANSACTIONS);
  const [selectedTxForSingle, setSelectedTxForSingle] = useState<Transaction | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleLoadDemoData = () => {
    setTransactions(INITIAL_DEMO_TRANSACTIONS);
    showToast('Loaded synthetic UPI banking transactions with verified anomaly profiles.');
  };

  // Single transaction evaluation
  const handleAnalyzeSingleTransaction = async (tx: Transaction): Promise<Transaction> => {
    try {
      const response = await fetch('/api/analyze-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tx),
      });

      if (response.ok) {
        const result = await response.json();
        return result;
      }
    } catch (err) {
      console.warn('API error, falling back to local risk engine:', err);
    }
    return calculateTransactionRisk(tx);
  };

  // Scam message checking
  const handleCheckScamMessage = async (messageText: string): Promise<ScamMessageAnalysis> => {
    try {
      const response = await fetch('/api/check-scam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageText }),
      });

      if (response.ok) {
        const result = await response.json();
        return result;
      }
    } catch (err) {
      console.warn('API error, falling back to local scam analyzer:', err);
    }
    return analyzeScamMessage(messageText);
  };

  // Generate investigation report
  const handleGenerateReportWithAi = async (txs: Transaction[]): Promise<InvestigationReportData> => {
    try {
      const response = await fetch('/api/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactions: txs }),
      });

      if (response.ok) {
        const result = await response.json();
        return result;
      }
    } catch (err) {
      console.warn('API error, falling back to local report generator:', err);
    }
    return generateInvestigationReport(txs);
  };

  const handleSelectTransactionForAudit = (tx: Transaction) => {
    setSelectedTxForSingle(tx);
    setActiveTab('single');
  };

  const handleSaveToHistory = (newTx: Transaction) => {
    setTransactions(prev => {
      const exists = prev.some(t => t.id === newTx.id);
      if (exists) {
        return prev.map(t => (t.id === newTx.id ? newTx : t));
      }
      return [newTx, ...prev];
    });
    showToast(`Saved transaction ${newTx.id} to Statement History.`);
  };

  return (
    <div className="h-screen w-full flex flex-col bg-slate-50 text-slate-900 font-sans antialiased overflow-hidden">
      {/* High-Density Top Header */}
      <Header onLoadDemoData={handleLoadDemoData} />

      {/* Mobile Nav for small screens */}
      <MobileNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        transactionCount={transactions.length}
      />

      {/* Body: High-Density Sidebar + Content Area */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        {/* Dark Slate Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          transactionCount={transactions.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 bg-slate-50 text-slate-900 overflow-y-auto p-4 sm:p-5 flex flex-col gap-4">
          {activeTab === 'dashboard' && (
            <DashboardView
              transactions={transactions}
              setActiveTab={setActiveTab}
              onSelectTransaction={handleSelectTransactionForAudit}
            />
          )}

          {activeTab === 'single' && (
            <SingleAnalyzerView
              key={selectedTxForSingle ? selectedTxForSingle.id : 'default'}
              onAnalyzeTransaction={handleAnalyzeSingleTransaction}
              selectedTx={selectedTxForSingle}
              onSaveToHistory={handleSaveToHistory}
            />
          )}

          {activeTab === 'history' && (
            <HistoryAnalyzerView
              transactions={transactions}
              onUpdateTransactions={setTransactions}
              onSelectTransactionForSingleView={handleSelectTransactionForAudit}
            />
          )}

          {activeTab === 'scam' && (
            <ScamCheckerView
              onCheckScamMessage={handleCheckScamMessage}
            />
          )}

          {activeTab === 'report' && (
            <ReportView
              transactions={transactions}
              onGenerateReportWithAi={handleGenerateReportWithAi}
            />
          )}
        </main>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-10 right-6 z-50 bg-slate-900 text-white px-3.5 py-2 rounded-lg shadow-xl border border-slate-700 flex items-center gap-2 text-xs animate-in fade-in slide-in-from-bottom-2">
          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* High-Density Global Footer */}
      <footer className="h-8 bg-slate-100 border-t border-slate-200 flex items-center px-4 justify-between shrink-0 text-[10px] text-slate-500 print:hidden">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-700">SMART BANK STATEMENT ANALYSER</span>
          <span className="hidden sm:inline">•</span>
          <span className="hidden sm:inline">AI-Assisted Statement Audit & Anomaly Decision Support</span>
        </div>
        <div className="flex items-center gap-3 font-medium">
          <span className="text-emerald-700 flex items-center gap-1">
            <Lock className="w-2.5 h-2.5" /> Zero Credential Policy
          </span>
          <span>•</span>
          <span className="text-slate-700">Helpline: <strong className="font-mono text-slate-900">1930</strong></span>
        </div>
      </footer>
    </div>
  );
}
