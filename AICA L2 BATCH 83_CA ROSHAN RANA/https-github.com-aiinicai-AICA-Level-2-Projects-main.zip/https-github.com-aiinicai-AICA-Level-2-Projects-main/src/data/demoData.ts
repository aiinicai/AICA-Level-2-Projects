import { Transaction, ScamMessageAnalysis } from '../types';

export const INITIAL_DEMO_TRANSACTIONS: Transaction[] = [
  {
    id: 'TXN-2026-98124',
    date: '2026-08-20',
    time: '02:45',
    amount: 89500,
    type: 'Collect Request',
    beneficiary: 'helpdesk.power_urgent@oksbi',
    isNewBeneficiary: true,
    isNewDevice: true,
    location: 'Jamtara, JH (Unknown IP)',
    normalAvgAmount: 1800,
    recentTransactionCount: 6,
    remarks: 'URGENT ELECTRICITY BILL OVERDUE DISCONNECT REF 4492',
    riskScore: 94,
    riskLevel: 'CRITICAL',
    confidence: 96,
    riskFactors: [
      'Extreme amount deviation (49.7x higher than typical ₹1,800 average)',
      'Unusual transaction hour (02:45 AM)',
      'High velocity (6 rapid transactions triggered in last 1 hour)',
      'Collect Request initiated by unverified new beneficiary',
      'Transaction triggered from unrecognized device / remote IP',
      'Urgent/coercive payment remark simulating utility disconnection threat'
    ],
    evidence: [
      'Normal spend average is ₹1,800 vs requested ₹89,500.',
      'Beneficiary UPI ID is flagged with keywords "urgent" & "helpdesk" not matching standard MSEB/Discom handle.',
      'Collect request mechanism poses high risk of accidental authorization via PIN entry.'
    ],
    missingInformation: [
      'Prior utility payment receipt or bill consumer number',
      'Device MAC address and biometric authentication log'
    ],
    recommendedActions: [
      'Decline this Collect Request immediately in your UPI application.',
      'Do NOT enter your 4/6-digit UPI PIN (UPI PIN is ONLY required to send money, NEVER to receive or cancel).',
      'Verify official bill dues exclusively via your state electricity provider portal or Bharat BillPay.',
      'Contact your bank cyber cell to freeze compromised UPI handles if credentials were shared.'
    ],
    analysisSummary: 'CRITICAL RISK: Severe anomalies detected across amount (50x multiplier), early morning timestamp (02:45 AM), new remote device, and coercive threat language in remarks.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: true,
      velocityAnomaly: true,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: true,
      locationAnomaly: true,
      urgentLanguageAnomaly: true,
      collectRequestRisk: true
    }
  },
  {
    id: 'TXN-2026-89410',
    date: '2026-08-20',
    time: '03:12',
    amount: 45000,
    type: 'QR Code Scan',
    beneficiary: 'instant_kyc_verification@paytm',
    isNewBeneficiary: true,
    isNewDevice: true,
    location: 'Nuh, HR (Proxy Network)',
    normalAvgAmount: 2200,
    recentTransactionCount: 4,
    remarks: 'KYC RE-VERIFICATION REFUND DEPOSIT',
    riskScore: 88,
    riskLevel: 'CRITICAL',
    confidence: 92,
    riskFactors: [
      'High amount deviation (20.4x normal average)',
      'Odd hour execution (03:12 AM)',
      'Brand impersonation ("instant_kyc_verification") in beneficiary name',
      'New device login from flagged proxy IP address',
      'High velocity preceding larger transaction'
    ],
    evidence: [
      'Banks never charge money or require QR scans for KYC updates.',
      'Device fingerprint mismatches standard registered handset.',
      'Remark contains classic phishing pretext "KYC RE-VERIFICATION".'
    ],
    missingInformation: [
      'Official bank reference ticket number',
      'Location GPS coordinates verification'
    ],
    recommendedActions: [
      'Halt transaction immediately. Official KYC is free of cost at bank branches or verified apps.',
      'Block the beneficiary VPA immediately in your UPI app.',
      'Report the QR code to National Cyber Crime Reporting Portal (cybercrime.gov.in / 1930).'
    ],
    analysisSummary: 'CRITICAL RISK: High probability KYC impersonation scam. Scammers frequently use fake QR codes promising refunds or verification.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: true,
      velocityAnomaly: true,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: true,
      locationAnomaly: true,
      urgentLanguageAnomaly: true,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-77312',
    date: '2026-08-19',
    time: '23:40',
    amount: 32000,
    type: 'P2P',
    beneficiary: 'vikram.crypto.p2p@icici',
    isNewBeneficiary: true,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 3500,
    recentTransactionCount: 3,
    remarks: 'USDT escrow exchange payment',
    riskScore: 68,
    riskLevel: 'HIGH',
    confidence: 85,
    riskFactors: [
      'Significant amount deviation (9.1x standard ticket size)',
      'Unregistered new beneficiary with crypto/escrow remark',
      'Late night transaction timing (11:40 PM)',
      'Risk of P2P account freeze if counterparty account is involved in mule networks'
    ],
    evidence: [
      'Unregulated P2P cryptocurrency transactions frequently lead to cyber-cell bank account liens.',
      'First-time transfer to an unverified private seller.'
    ],
    missingInformation: [
      'Counterparty identity KYC verification / exchange escrow proof',
      'Agreement or invoice documentation'
    ],
    recommendedActions: [
      'Confirm seller identity through verifiable non-messaging channels.',
      'Ensure the beneficiary bank account matches their registered government ID.',
      'Keep records of all chat logs and trade proofs in case of bank inquiry.'
    ],
    analysisSummary: 'HIGH RISK: Unregulated peer-to-peer transfer with high deviation and mule account contagion risk.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: true,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-65109',
    date: '2026-08-19',
    time: '21:15',
    amount: 14500,
    type: 'P2P',
    beneficiary: 'rahul.verma@okhdfcbank',
    isNewBeneficiary: true,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 4000,
    recentTransactionCount: 1,
    remarks: 'Weekend trip Airbnb split share',
    riskScore: 38,
    riskLevel: 'MODERATE',
    confidence: 88,
    riskFactors: [
      'Moderate amount deviation (3.6x typical average)',
      'First-time transfer to a personal beneficiary handle'
    ],
    evidence: [
      'Sent from primary trusted device and standard domestic location.',
      'Normal evening timestamp with benign social remark.'
    ],
    missingInformation: [
      'Prior relationship or contact list synchronization with beneficiary'
    ],
    recommendedActions: [
      'Verify the UPI ID spelling directly with your friend or colleague via a quick phone call before sending large sums.',
      'Check the recipient name displayed in the UPI app before confirming.'
    ],
    analysisSummary: 'MODERATE RISK: Typical peer transfer with moderate amount spike and new recipient. Verify recipient name on the bank confirmation screen.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-54201',
    date: '2026-08-19',
    time: '19:30',
    amount: 1250,
    type: 'P2M (Merchant)',
    beneficiary: 'swiggy.food@hdfcbank',
    isNewBeneficiary: false,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 1500,
    recentTransactionCount: 1,
    remarks: 'Dinner food order delivery',
    riskScore: 8,
    riskLevel: 'LOW',
    confidence: 99,
    riskFactors: [
      'None detected. Fully consistent with historical profile.'
    ],
    evidence: [
      'Standard verified corporate merchant handle.',
      'Amount is within usual historical bounds.',
      'Trusted device and regular geolocation.'
    ],
    missingInformation: [],
    recommendedActions: [
      'No protective intervention required. Standard safe merchant transaction.'
    ],
    analysisSummary: 'LOW RISK: Standard verified merchant transaction within normal behavioral boundaries.',
    anomaliesDetected: {
      amountAnomaly: false,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: false,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-43198',
    date: '2026-08-19',
    time: '14:20',
    amount: 450,
    type: 'P2M (Merchant)',
    beneficiary: 'zepto.grocery@icici',
    isNewBeneficiary: false,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 1200,
    recentTransactionCount: 1,
    remarks: 'Quick groceries delivery',
    riskScore: 5,
    riskLevel: 'LOW',
    confidence: 99,
    riskFactors: [
      'None detected.'
    ],
    evidence: [
      'Routine everyday merchant payment from registered device.'
    ],
    missingInformation: [],
    recommendedActions: [
      'Standard routine transaction. No action required.'
    ],
    analysisSummary: 'LOW RISK: Routine daily expense.',
    anomaliesDetected: {
      amountAnomaly: false,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: false,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-32090',
    date: '2026-08-18',
    time: '11:15',
    amount: 28000,
    type: 'Auto-Debit / Mandate',
    beneficiary: 'hdfc_ergo_insurance@hdfcbank',
    isNewBeneficiary: false,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 2500,
    recentTransactionCount: 1,
    remarks: 'Annual Health Insurance Premium Auto Debit',
    riskScore: 18,
    riskLevel: 'LOW',
    confidence: 95,
    riskFactors: [
      'Amount is higher than daily average, but aligns with annual recurring insurance mandate profile'
    ],
    evidence: [
      'Mandate registered previously with valid bank mandate reference.',
      'Verified insurance provider entity.'
    ],
    missingInformation: [],
    recommendedActions: [
      'Verify policy renewal receipt received via registered email.'
    ],
    analysisSummary: 'LOW RISK: Legitimate annual mandate execution.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: false,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-21045',
    date: '2026-08-18',
    time: '01:50',
    amount: 50000,
    type: 'Collect Request',
    beneficiary: 'lottery_claim_officer@ybl',
    isNewBeneficiary: true,
    isNewDevice: true,
    location: 'Alwar, RJ (VPN Node)',
    normalAvgAmount: 1500,
    recentTransactionCount: 5,
    remarks: 'CLAIM PRIZE MONEY ₹25,00,000 PAY TDS CHARGE NOW',
    riskScore: 98,
    riskLevel: 'CRITICAL',
    confidence: 98,
    riskFactors: [
      'Classic lottery / advance fee scam pretext in remarks',
      'Massive amount anomaly (33.3x normal spending average)',
      'Collect Request demanding payment to "receive" funds',
      'Late night uncharacteristic activity (01:50 AM)',
      'New device and masked VPN node'
    ],
    evidence: [
      'Any claim requiring advance payment or PIN entry to receive prize money is an established scam pattern.',
      'UPI Collect Request deducts funds from the sender.'
    ],
    missingInformation: [
      'Originating phone number and scam reporting database match'
    ],
    recommendedActions: [
      'Decline and block immediately. You NEVER need to pay TDS or processing fees via UPI to win prizes.',
      'Do not dial any phone numbers provided in the remark.',
      'Report handle to 1930 Cyber Fraud helpline.'
    ],
    analysisSummary: 'CRITICAL RISK: Severe advance fee fraud attempt utilizing UPI Collect Request inversion trick.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: true,
      velocityAnomaly: true,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: true,
      locationAnomaly: true,
      urgentLanguageAnomaly: true,
      collectRequestRisk: true
    }
  },
  {
    id: 'TXN-2026-10933',
    date: '2026-08-17',
    time: '18:45',
    amount: 3200,
    type: 'P2M (Merchant)',
    beneficiary: 'tatacliq.fashion@axisbank',
    isNewBeneficiary: false,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 2000,
    recentTransactionCount: 1,
    remarks: 'Apparel purchase order #TC-99120',
    riskScore: 12,
    riskLevel: 'LOW',
    confidence: 98,
    riskFactors: [
      'Slightly above normal average, consistent with e-commerce shopping'
    ],
    evidence: [
      'Verified corporate VPA, matching order reference.'
    ],
    missingInformation: [],
    recommendedActions: [
      'Save merchant invoice for warranty.'
    ],
    analysisSummary: 'LOW RISK: Standard e-commerce transaction.',
    anomaliesDetected: {
      amountAnomaly: false,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: false,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: false,
      collectRequestRisk: false
    }
  },
  {
    id: 'TXN-2026-09822',
    date: '2026-08-17',
    time: '16:10',
    amount: 19500,
    type: 'P2P',
    beneficiary: 'olx_buyer_deposit@paytm',
    isNewBeneficiary: true,
    isNewDevice: false,
    location: 'Bengaluru, KA',
    normalAvgAmount: 2500,
    recentTransactionCount: 2,
    remarks: 'OLX sofa advance payment barcode scan',
    riskScore: 79,
    riskLevel: 'CRITICAL',
    confidence: 91,
    riskFactors: [
      'OLX QR code advance payment trap detected',
      'Significant amount deviation (7.8x normal average)',
      'Unverified new buyer demanding seller to scan QR or approve collect request'
    ],
    evidence: [
      'Sellers never need to scan a QR code or enter a PIN to RECEIVE money.',
      'The beneficiary handle is designed to mimic an OLX escrow wallet.'
    ],
    missingInformation: [
      'Buyer verified phone number and OLX profile age'
    ],
    recommendedActions: [
      'Do NOT scan any QR code or enter your UPI PIN. To receive money, the buyer only needs your UPI ID or phone number.',
      'Refuse any request to test transaction with ₹1 or ₹5.',
      'Block the buyer on OLX and reporting platform.'
    ],
    analysisSummary: 'CRITICAL RISK: Classic OLX marketplace buyer QR scam. PIN entry will result in debit rather than credit.',
    anomaliesDetected: {
      amountAnomaly: true,
      unusualTime: false,
      velocityAnomaly: false,
      newBeneficiaryAnomaly: true,
      newDeviceAnomaly: false,
      locationAnomaly: false,
      urgentLanguageAnomaly: true,
      collectRequestRisk: true
    }
  }
];

export const DEMO_SCAM_MESSAGES = [
  {
    title: 'Electricity Bill Disconnection Threat (Urgent SMS)',
    channel: 'SMS' as const,
    text: 'Dear Consumer, Your Electricity power connection will be disconnected tonight at 09:30 PM from the electric office because your previous month bill was not updated. Please immediately contact our Electricity Officer Mr. RK Sharma at 98765-43210 or click http://mseb-update-bill.xyz/pay to pay now.'
  },
  {
    title: 'Bank KYC Account Suspension Notice (Urgent SMS)',
    channel: 'SMS' as const,
    text: 'ALERT: Dear SBI / HDFC Customer, your NetBanking & UPI services have been blocked due to pending PAN/KYC update. Kindly click https://bit.ly/sbi-kyc-reactivate-2026 to update your Aadhaar and PAN immediately to avoid permanent account freeze within 24 hours.'
  },
  {
    title: 'OLX Buyer Fake Payment QR / PIN Request (WhatsApp)',
    channel: 'WhatsApp' as const,
    text: 'Sir I am sending you ₹15,000 for your furniture listed on OLX. I have generated PhonePe merchant QR code. Please scan this barcode and enter your 6 digit UPI PIN to receive the advance payment in your bank account right now.'
  },
  {
    title: 'Credit Card Reward Points Expiry (SMS)',
    channel: 'SMS' as const,
    text: 'Dear Customer, your 9,850 reward points worth ₹4,925 in your Credit Card are expiring today! Convert points into instant cash in your bank account by visiting http://hdfc-reward-redeem-cash.top and verify with OTP.'
  },
  {
    title: 'Legitimate Delivery OTP (Benign Safe Reference)',
    channel: 'SMS' as const,
    text: 'Your Amazon package with order #402-8819281-22910 is out for delivery with agent Ramesh (Phone: 9123456780). Please share OTP 4829 only when you receive the physical package in hand.'
  }
];
