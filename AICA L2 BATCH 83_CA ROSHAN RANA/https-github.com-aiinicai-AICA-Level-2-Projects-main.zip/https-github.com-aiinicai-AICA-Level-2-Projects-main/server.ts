import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import {
  analyzeTransactionWithGemini,
  analyzeScamMessageWithGemini,
  generateInvestigationReportWithGemini
} from './server/geminiService.ts';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API endpoints
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'UPI Guardian API',
      aiConfigured: Boolean(process.env.GEMINI_API_KEY),
      timestamp: new Date().toISOString()
    });
  });

  app.post('/api/analyze-transaction', async (req, res) => {
    try {
      const transaction = req.body;
      if (!transaction || typeof transaction !== 'object') {
        return res.status(400).json({ error: 'Invalid transaction payload' });
      }
      const result = await analyzeTransactionWithGemini(transaction);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/analyze-transaction:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  app.post('/api/check-scam', async (req, res) => {
    try {
      const { messageText } = req.body;
      if (!messageText || typeof messageText !== 'string') {
        return res.status(400).json({ error: 'messageText is required and must be a string' });
      }
      const result = await analyzeScamMessageWithGemini(messageText);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/check-scam:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  app.post('/api/generate-report', async (req, res) => {
    try {
      const { transactions } = req.body;
      if (!Array.isArray(transactions)) {
        return res.status(400).json({ error: 'transactions array is required' });
      }
      const result = await generateInvestigationReportWithGemini(transactions);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/generate-report:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // Download project submission zip for GitHub
  app.get('/api/download-project-zip', (req, res) => {
    let zipPath = path.join(process.cwd(), 'public', 'SMART_BANK_STATEMENT_ANALYSER.zip');
    if (!fs.existsSync(zipPath)) {
      zipPath = path.join(process.cwd(), 'public', 'UPI_GUARDIAN_PROJECT.zip');
    }
    res.download(zipPath, 'SMART_BANK_STATEMENT_ANALYSER.zip', (err) => {
      if (err) {
        console.error('Error downloading zip:', err);
        if (!res.headersSent) {
          res.status(500).json({ error: 'Zip file not available' });
        }
      }
    });
  });

  // Vite middleware in dev mode vs static in prod mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`UPI Guardian server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
