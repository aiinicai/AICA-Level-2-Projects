"""
Olympiad Quest - adaptive olympiad practice for children aged 4-16 (Flask + SQLite)

Run:    pip install flask
        python app.py              -> open http://127.0.0.1:5000
Check:  python app.py --check      -> validates questions.txt and prints counts

Files next to this one:
    questions.txt   the question bank (format explained at the top of that file)
    questions.json  optional extra questions:
                    [{"subject":"Math","band":"c","diff":2,"q":"...","opts":["..",".."],"ans":0,"why":"..."}]

How it adapts: every child has a skill level (0-17) per subject. It starts in the
middle of their age band and moves up after right answers and down after wrong
ones. Questions are picked close to that level, new questions first, and missed
questions come back later for review.
"""
import hashlib, json, math, os, random, sqlite3, sys, datetime as dt
from flask import Flask, g, jsonify, redirect, render_template, request, session, url_for
from jinja2 import DictLoader

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-in-production")
app.permanent_session_lifetime = dt.timedelta(days=365)
HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "olympiad.db")

SUBJECTS = {"Math": ("🧮", "#4f46e5"), "Science": ("🔬", "#059669"),
            "English": ("📖", "#db2777"), "Reasoning": ("🧩", "#d97706")}
MIN_AGE, MAX_AGE = 4, 16
# band: (min age, max age, title, icon)
BANDS = {"a": (4, 5, "Little Explorer", "🌱"), "b": (6, 7, "Young Thinker", "🚀"),
         "c": (8, 9, "Rising Star", "⭐"), "d": (10, 11, "Challenger", "🧭"),
         "e": (12, 13, "Achiever", "🏅"), "f": (14, 16, "Olympiad Pro", "🏆")}
BAND_KEYS = list(BANDS)
MAX_LEVEL = 18  # 6 bands x 3 difficulty steps


def band_index(age):
    return next(i for i, b in enumerate(BAND_KEYS) if BANDS[b][0] <= age <= BANDS[b][1])


def round_size(age):
    return 5 if age <= 5 else 8 if age <= 7 else 10


# ----------------------------------------------------------------- questions
BANK = {s: [] for s in SUBJECTS}
BYID = {}


def add_question(subject, band, diff, q, correct, wrong, why):
    if subject not in SUBJECTS or band not in BANDS or diff not in (1, 2, 3):
        raise ValueError(f"bad subject/band/difficulty for question: {q[:40]}")
    qid = hashlib.md5(f"{subject}|{q}".encode("utf-8")).hexdigest()[:10]
    if qid in BYID:
        return
    opts = [correct] + list(wrong)
    random.Random(qid).shuffle(opts)  # same order every run
    item = dict(id=qid, subject=subject, band=band, lvl=BAND_KEYS.index(band) * 3 + diff - 1,
                q=q, opts=opts, ans=opts.index(correct), why=why)
    BANK[subject].append(item)
    BYID[qid] = item


def load_bank():
    path = os.path.join(HERE, "questions.txt")
    if not os.path.exists(path):
        raise SystemExit("questions.txt not found next to app.py")
    subject = None
    for n, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        if line.startswith("# "):
            subject = line[2:].strip()
            continue
        p = [x.strip() for x in line.split("|")]
        if len(p) != 7 or len(p[0]) != 2 or not p[0][1].isdigit():
            raise SystemExit(f"questions.txt line {n}: expected code|question|correct|wrong|wrong|wrong|why")
        add_question(subject, p[0][0], int(p[0][1]), p[1], p[2], p[3:6], p[6])
    extra = os.path.join(HERE, "questions.json")
    if os.path.exists(extra):
        for d in json.load(open(extra, encoding="utf-8")):
            correct = d["opts"][d["ans"]]
            add_question(d["subject"], d["band"], int(d.get("diff", 2)), d["q"], correct,
                         [o for i, o in enumerate(d["opts"]) if i != d["ans"]], d["why"])


load_bank()


def report():
    print("Question bank:")
    for s in SUBJECTS:
        per = {b: sum(1 for q in BANK[s] if q["band"] == b) for b in BAND_KEYS}
        print(f"  {s:10} {len(BANK[s]):4}   " + "  ".join(f"{b}({BANDS[b][0]}-{BANDS[b][1]}):{n}" for b, n in per.items()))
    bad = [q["q"] for q in BYID.values() if len(set(q["opts"])) != len(q["opts"])]
    print("Problems:", bad or "none")


# ----------------------------------------------------------------------- db
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()


def init_db():
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT UNIQUE COLLATE NOCASE, age INTEGER, created TEXT);
    CREATE TABLE IF NOT EXISTS answers(id INTEGER PRIMARY KEY, user_id INTEGER, qid TEXT, subject TEXT, correct INTEGER, day TEXT);
    CREATE TABLE IF NOT EXISTS skill(user_id INTEGER, subject TEXT, rating REAL, PRIMARY KEY(user_id, subject));
    CREATE TABLE IF NOT EXISTS rounds(id INTEGER PRIMARY KEY, user_id INTEGER, subject TEXT, score INTEGER, total INTEGER, day TEXT);
    """)
    c.commit(); c.close()


def current_user():
    uid = session.get("uid")
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() if uid else None
    if not row:
        return None
    u = dict(row)
    u["age"] = max(MIN_AGE, min(MAX_AGE, u["age"] or MIN_AGE))
    return u


# ------------------------------------------------------------------ adaptive
def rating_range(age):
    i = band_index(age) * 3
    return max(0.0, i - 3.0), min(MAX_LEVEL - 0.01, i + 5.99)  # up to one band easier or harder


def get_rating(uid, subject, age):
    row = db().execute("SELECT rating FROM skill WHERE user_id=? AND subject=?", (uid, subject)).fetchone()
    lo, hi = rating_range(age)
    r = row["rating"] if row else band_index(age) * 3 + 1.0
    return max(lo, min(hi, r))


def history(uid, subject):
    """qid -> (times answered, last answer correct?)"""
    h = {}
    for r in db().execute("SELECT qid, correct FROM answers WHERE user_id=? AND subject=? ORDER BY id", (uid, subject)):
        h[r["qid"]] = (h.get(r["qid"], (0, 0))[0] + 1, bool(r["correct"]))
    return h


def pick_question(uid, subject, age, seen, review):
    hist = history(uid, subject)
    pool = [q for q in BANK[subject] if q["id"] not in seen]
    if review:
        pool = [q for q in pool if q["id"] in hist and not hist[q["id"]][1]]
        return random.choice(pool) if pool else None
    if not pool:
        return None
    rating = get_rating(uid, subject, age)
    for width in (1.2, 2.2, 4, 99):
        near = [q for q in pool if abs(q["lvl"] - rating) <= width]
        if near:
            break
    fresh = [q for q in near if q["id"] not in hist]
    missed = [q for q in near if q["id"] in hist and not hist[q["id"]][1]]
    if missed and (not fresh or random.random() < 0.3):
        return random.choice(missed)
    if fresh:
        return random.choice(fresh)
    return min(near, key=lambda q: (hist[q["id"]][0], random.random()))  # least practised


def stats(uid):
    d = db()
    tot, ok = d.execute("SELECT COUNT(*), COALESCE(SUM(correct),0) FROM answers WHERE user_id=?", (uid,)).fetchone()
    days = {r[0] for r in d.execute("SELECT DISTINCT day FROM answers WHERE user_id=?", (uid,))}
    today = dt.date.today()
    cur = today if today.isoformat() in days else today - dt.timedelta(days=1)
    streak = 0
    while cur.isoformat() in days:
        streak += 1; cur -= dt.timedelta(days=1)
    age = d.execute("SELECT age FROM users WHERE id=?", (uid,)).fetchone()[0]
    age = max(MIN_AGE, min(MAX_AGE, age or MIN_AGE))
    subj = {s: dict(total=0, ok=0) for s in SUBJECTS}
    for r in d.execute("SELECT subject, COUNT(*), SUM(correct) FROM answers WHERE user_id=? GROUP BY subject", (uid,)):
        if r[0] in subj:
            subj[r[0]] = dict(total=r[1], ok=r[2] or 0)
    for s, v in subj.items():
        v["pct"] = round(100 * v["ok"] / v["total"]) if v["total"] else 0
        r = get_rating(uid, s, age)
        key = BAND_KEYS[min(5, int(r // 3))]
        v.update(lvl=int(r) + 1, mastery=round(100 * (r + 0.5) / MAX_LEVEL), title=BANDS[key][2], icon=BANDS[key][3])
    week = []
    for i in range(6, -1, -1):
        day = today - dt.timedelta(days=i)
        n, k = d.execute("SELECT COUNT(*), COALESCE(SUM(correct),0) FROM answers WHERE user_id=? AND day=?", (uid, day.isoformat())).fetchone()
        week.append(dict(label=day.strftime("%a"), n=n, ok=k))
    acc = round(100 * ok / tot) if tot else 0
    perfect = d.execute("SELECT 1 FROM rounds WHERE user_id=? AND score=total AND total>=5 LIMIT 1", (uid,)).fetchone() is not None
    xp = ok * 10 + (tot - ok) * 2
    badges = [("🌟", "First answer", tot >= 1), ("🧠", "25 answers", tot >= 25), ("💯", "100 answers", tot >= 100),
              ("🚀", "500 answers", tot >= 500), ("🔥", "3-day streak", streak >= 3), ("⚡", "7-day streak", streak >= 7),
              ("🎯", "80%+ accuracy", tot >= 20 and acc >= 80), ("🌍", "All 4 subjects", all(v["total"] for v in subj.values())),
              ("🥇", "Perfect round", perfect)]
    return dict(total=tot, ok=ok, acc=acc, streak=streak, subj=subj, week=week, xp=xp,
                plevel=1 + int(math.sqrt(xp / 50)), badges=badges, maxday=max([w["n"] for w in week] + [1]))


# ------------------------------------------------------------------- routes
def ages():
    return range(MIN_AGE, MAX_AGE + 1)


@app.route("/")
def home():
    if current_user():
        return redirect(url_for("dashboard"))
    return render_template("home.html", user=None, ages=ages())


@app.post("/start")
def start():
    name = " ".join(request.form.get("name", "").split())[:20]
    try:
        age = int(request.form.get("age", 0))
    except ValueError:
        age = 0
    if len(name) < 2 or not MIN_AGE <= age <= MAX_AGE:
        return render_template("home.html", user=None, ages=ages(), error="Please enter a name (2+ letters) and choose your age.")
    d = db()
    row = d.execute("SELECT id FROM users WHERE name=?", (name,)).fetchone()
    if row:
        d.execute("UPDATE users SET age=? WHERE id=?", (age, row["id"])); uid = row["id"]
    else:
        uid = d.execute("INSERT INTO users(name,age,created) VALUES(?,?,?)", (name, age, dt.date.today().isoformat())).lastrowid
    d.commit(); session["uid"] = uid; session.permanent = True
    return redirect(url_for("dashboard"))


@app.post("/age")
def set_age():
    u = current_user()
    if u:
        try:
            age = max(MIN_AGE, min(MAX_AGE, int(request.form.get("age", u["age"]))))
        except ValueError:
            age = u["age"]
        db().execute("UPDATE users SET age=? WHERE id=?", (age, u["id"])); db().commit()
    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/dashboard")
def dashboard():
    u = current_user()
    if not u:
        return redirect(url_for("home"))
    return render_template("dash.html", user=u, st=stats(u["id"]), subjects=SUBJECTS, ages=ages())


@app.route("/practice/<subject>")
def practice(subject):
    u = current_user()
    if not u or subject not in SUBJECTS:
        return redirect(url_for("home"))
    return render_template("practice.html", user=u, subject=subject, icon=SUBJECTS[subject][0],
                           total=round_size(u["age"]), review=request.args.get("review") == "1")


@app.get("/api/question")
def api_question():
    u = current_user()
    subject = request.args.get("subject")
    if not u or subject not in SUBJECTS:
        return jsonify(error="bad request"), 400
    seen = set(request.args.get("seen", "").split(","))
    review = request.args.get("review") == "1"
    q = pick_question(u["id"], subject, u["age"], seen, review)
    if not q:
        return jsonify(done=True, review_empty=review)
    return jsonify(id=q["id"], q=q["q"], opts=q["opts"])


@app.post("/api/answer")
def api_answer():
    u = current_user()
    data = request.get_json(force=True, silent=True) or {}
    q = BYID.get(str(data.get("id")))
    try:
        choice = int(data.get("choice"))
    except (TypeError, ValueError):
        choice = -1
    if not u or not q or not 0 <= choice < len(q["opts"]):
        return jsonify(error="bad request"), 400
    ok = int(choice == q["ans"])
    d = db()
    d.execute("INSERT INTO answers(user_id,qid,subject,correct,day) VALUES(?,?,?,?,?)",
              (u["id"], q["id"], q["subject"], ok, dt.date.today().isoformat()))
    r = get_rating(u["id"], q["subject"], u["age"])
    expected = 1 / (1 + math.exp(-(r - q["lvl"]) * 0.8))  # Elo-style: surprises move you more
    lo, hi = rating_range(u["age"])
    r = max(lo, min(hi, r + 0.5 * (ok - expected)))
    d.execute("INSERT OR REPLACE INTO skill(user_id,subject,rating) VALUES(?,?,?)", (u["id"], q["subject"], r))
    d.commit()
    return jsonify(correct=bool(ok), answer=q["ans"], why=q["why"])


@app.post("/api/finish")
def api_finish():
    u = current_user()
    data = request.get_json(force=True, silent=True) or {}
    s = data.get("subject")
    if not u or s not in SUBJECTS:
        return jsonify(error="bad request"), 400
    try:
        total = max(1, min(int(data.get("total", 1)), 20)); score = max(0, min(int(data.get("score", 0)), total))
    except (TypeError, ValueError):
        return jsonify(error="bad request"), 400
    db().execute("INSERT INTO rounds(user_id,subject,score,total,day) VALUES(?,?,?,?,?)",
                 (u["id"], s, score, total, dt.date.today().isoformat()))
    db().commit()
    r = get_rating(u["id"], s, u["age"])
    return jsonify(title=BANDS[BAND_KEYS[min(5, int(r // 3))]][2], lvl=int(r) + 1)


# ---------------------------------------------------------------- templates
BASE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Olympiad Quest</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--blue:#1d4ed8;--deep:#1e3a8a;--indigo:#4f46e5;--yellow:#facc15;--ink:#0f172a;--mut:#64748b;--line:#e2e8f0;--bg:#f1f5f9}
*{box-sizing:border-box;margin:0}body{font-family:Outfit,system-ui,sans-serif;color:var(--ink);background:var(--bg);min-height:100vh}
a{text-decoration:none;color:inherit}
nav{background:#fff;display:flex;align-items:center;justify-content:space-between;padding:14px 5vw;box-shadow:0 1px 0 var(--line);position:sticky;top:0;z-index:5}
.logo{font-size:26px;font-weight:800;color:var(--indigo)}.logo span{color:var(--yellow);text-shadow:0 0 1px #ca8a04}
nav .links{display:flex;gap:26px;font-weight:500;color:#334155}nav .links a:hover{color:var(--indigo)}
.btn{display:inline-block;border:0;cursor:pointer;font:600 16px Outfit;padding:13px 24px;border-radius:12px;transition:.15s}
.btn:hover{transform:translateY(-2px)}.b-ind{background:var(--indigo);color:#fff}.b-yel{background:var(--yellow);color:#111;box-shadow:0 8px 24px #facc1566}
.b-out{background:transparent;color:#fff;border:1px solid #ffffff66}.b-ghost{background:#fff;border:1px solid var(--line)}
.hero{background:linear-gradient(135deg,#1d4ed8,#1e3a8a);color:#fff;padding:60px 5vw 80px;display:grid;grid-template-columns:1.1fr 1fr;gap:40px;align-items:center;min-height:calc(100vh - 66px);position:relative;overflow:hidden}
.pill{display:inline-block;background:#ffffff1f;border:1px solid #ffffff33;padding:8px 16px;border-radius:99px;font-size:14px;font-weight:600;margin-bottom:22px}
h1{font-size:clamp(40px,5.4vw,72px);line-height:1.02;font-weight:800;letter-spacing:-1.5px}h1 em{font-style:normal;color:var(--yellow)}
.hero p{font-size:19px;line-height:1.6;opacity:.9;margin:22px 0 30px;max-width:560px}
.card{background:#fff;border-radius:22px;box-shadow:0 30px 60px #0b1b5055;color:var(--ink)}
.signup{padding:32px}.signup h2{font-size:26px;margin-bottom:6px}.signup .sub{color:var(--mut);margin-bottom:20px}
label{font-weight:600;font-size:14px;display:block;margin:14px 0 6px}
input,select{width:100%;padding:14px 16px;border:1.5px solid var(--line);border-radius:12px;font:500 16px Outfit;background:#fff;outline:none}
input:focus,select:focus{border-color:var(--indigo);box-shadow:0 0 0 4px #4f46e51f}
.err{background:#fee2e2;color:#b91c1c;padding:10px 14px;border-radius:10px;margin-top:14px;font-weight:500}
.feats{display:flex;gap:26px;flex-wrap:wrap;margin-top:44px;padding-top:24px;border-top:1px solid #ffffff2e;font-size:14px;font-weight:600}
.float{position:absolute;font-size:42px;animation:fl 5s ease-in-out infinite}@keyframes fl{50%{transform:translateY(-16px)}}
.wrap{max-width:1180px;margin:28px auto;padding:0 20px}
.dash{display:grid;grid-template-columns:230px 1fr;overflow:hidden}.side{padding:24px 16px;border-right:1px solid var(--line)}
.side a{display:block;padding:12px 16px;border-radius:10px;font-weight:500;color:#475569;margin-bottom:4px}.side a.on{background:var(--indigo);color:#fff;font-weight:600}
.main{padding:28px}.top{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px}
.top h2{font-size:28px}.top p{color:var(--mut)}.who{display:flex;align-items:center;gap:10px;font-weight:600}
.av{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--indigo),#06b6d4);color:#fff;display:grid;place-items:center;font-weight:700}
.who select{width:auto;padding:8px 12px}
.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:24px 0}
.stat{border:1px solid var(--line);border-radius:14px;padding:16px;background:#f8fafc}.stat small{color:var(--mut);font-size:13px}.stat b{display:block;font-size:28px;margin-top:4px}
h3{margin:6px 0 14px;font-size:18px}.grid2{display:grid;grid-template-columns:1.5fr 1fr;gap:20px}
.subj{display:flex;align-items:center;gap:14px;border:1px solid var(--line);border-radius:14px;padding:14px 16px;margin-bottom:12px;transition:.15s;background:#fff}
.subj:hover{border-color:var(--indigo);box-shadow:0 8px 20px #4f46e51a;transform:translateY(-2px)}
.ic{width:46px;height:46px;border-radius:12px;display:grid;place-items:center;font-size:22px}.subj .m{flex:1}.subj b{display:block}.subj small{color:var(--mut)}
.bar{height:8px;background:#e2e8f0;border-radius:9px;margin-top:8px;overflow:hidden}.bar i{display:block;height:100%;background:var(--indigo);border-radius:9px;transition:width .5s}
.go{width:34px;height:34px;border-radius:50%;background:#eef2ff;color:var(--indigo);display:grid;place-items:center;font-weight:800}
.week{display:flex;align-items:flex-end;gap:10px;height:170px;border:1px solid var(--line);border-radius:14px;padding:16px;background:#f8fafc}
.col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;font-size:12px;color:var(--mut);gap:6px}
.col .b{width:100%;max-width:32px;background:#c7d2fe;border-radius:8px 8px 0 0;position:relative;min-height:3px}.col .b i{position:absolute;bottom:0;left:0;right:0;background:var(--indigo);border-radius:8px 8px 0 0}
.legend{font-size:12px;color:var(--mut);margin-top:8px}
.q{max-width:760px;margin:30px auto;padding:34px}.qh{display:flex;justify-content:space-between;font-weight:600;color:var(--mut);margin-bottom:12px}
.qt{font-size:26px;font-weight:700;margin:22px 0}.opt{display:block;width:100%;text-align:left;padding:16px 18px;margin-bottom:12px;border:2px solid var(--line);border-radius:14px;background:#fff;font:500 18px Outfit;cursor:pointer;transition:.15s}
.opt:hover:not(:disabled){border-color:var(--indigo);background:#eef2ff}.opt.ok{border-color:#16a34a;background:#dcfce7}.opt.no{border-color:#dc2626;background:#fee2e2}.opt:disabled{cursor:default}
.exp{margin-top:18px;padding:18px;border-radius:14px;background:#fffbeb;border:1px solid #fde68a;line-height:1.55}.exp b{display:block;margin-bottom:4px}
.res{text-align:center;padding:20px 0}.res .big{font-size:70px}.res h2{font-size:32px;margin:8px 0}
.kid .qt{font-size:34px}.kid .opt{font-size:24px;padding:22px}.badges{display:flex;flex-wrap:wrap;gap:10px;margin:6px 0 24px}.badge{border:1px solid var(--line);border-radius:12px;padding:8px 12px;font-size:13px;font-weight:600;background:#fff}.badge.off{opacity:.4;filter:grayscale(1)}.tag{display:inline-block;font-size:12px;font-weight:600;color:var(--indigo);background:#eef2ff;border-radius:99px;padding:3px 10px;margin-left:6px}.lnk{color:var(--indigo);font-weight:600;margin-right:12px}
@media(max-width:860px){.hero,.grid2,.dash{grid-template-columns:1fr}.side{display:none}.stats{grid-template-columns:1fr 1fr}nav .links{display:none}}
</style></head><body>
<nav><a href="/" class="logo">Olympiad<span>Quest</span></a>
<div class="links"><a href="/">Home</a><a href="/dashboard">Dashboard</a>{% for s in ['Math','Science','English','Reasoning'] %}{% if user %}<a href="/practice/{{s}}">{{s}}</a>{% endif %}{% endfor %}</div>
<div>{% if user %}<a class="btn b-ghost" href="/logout">Switch user</a>{% else %}<a class="btn b-ind" href="#start">Start</a>{% endif %}</div></nav>
{% block body %}{% endblock %}</body></html>"""

HOME = """{% extends 'base.html' %}{% block body %}
<section class="hero"><span class="float" style="top:90px;left:46%">🎓</span><span class="float" style="top:140px;right:4%;animation-delay:1s">🏆</span><span class="float" style="bottom:90px;right:3%;animation-delay:2s">💡</span>
<div><span class="pill">✨ Smart olympiad practice for ages 4 to 16</span>
<h1>Olympiads are not just exams. <em>They are a learning journey.</em></h1>
<p>Questions that match your age and adapt to how you are doing: a little easier when you need a boost, harder when you are flying. Learn from every explanation and watch your level grow!</p>
<div class="feats"><span>🛡️ Safe &amp; ad-free</span><span>🧠 Explanations for every answer</span><span>🎯 Adapts to your level</span><span>📈 Track your progress</span></div></div>
<form id="start" class="card signup" method="post" action="/start"><h2>Let's get started 🚀</h2><p class="sub">No password needed. Just your name!</p>
<label>Your name</label><input name="name" placeholder="e.g. Aarav" maxlength="20" required autofocus>
<label>Your age</label><select name="age" required><option value="">Choose age…</option>{% for a in ages %}<option value="{{a}}">{{a}} years</option>{% endfor %}</select>
{% if error %}<div class="err">{{error}}</div>{% endif %}
<button class="btn b-yel" style="width:100%;margin-top:22px">Start Free Learning →</button>
<p class="sub" style="margin:14px 0 0;font-size:13px">Coming back? Enter the same name to continue where you left off.</p></form></section>{% endblock %}"""

DASH = """{% extends 'base.html' %}{% block body %}<div class="wrap"><div class="card dash">
<div class="side"><a class="on" href="/dashboard">🏠 Dashboard</a>{% for s,(i,c) in subjects.items() %}<a href="/practice/{{s}}">{{i}} {{s}}</a>{% endfor %}</div>
<div class="main"><div class="top"><div><h2>Welcome back, {{user['name']}}! 👋</h2><p>Let's continue your learning journey.</p></div>
<form class="who" method="post" action="/age"><div class="av">{{user['name'][0]|upper}}</div>Age
<select name="age" onchange="this.form.submit()">{% for a in ages %}<option value="{{a}}" {{'selected' if a==user['age']}}>{{a}}</option>{% endfor %}</select></form></div>
<div class="stats"><div class="stat"><small>Questions answered</small><b>{{st.total}}</b></div><div class="stat"><small>Correct answers</small><b>{{st.ok}}</b></div>
<div class="stat"><small>Accuracy</small><b>{{st.acc}}%</b></div><div class="stat"><small>Current streak</small><b>{{st.streak}} day{{'' if st.streak==1 else 's'}} 🔥</b></div><div class="stat"><small>Player level</small><b>⭐ {{st.plevel}}</b></div></div>
<h3>Your badges</h3><div class="badges">{% for ic,nm,on in st.badges %}<span class="badge {{'' if on else 'off'}}">{{ic}} {{nm}}</span>{% endfor %}</div>
<div class="grid2"><div><h3>Choose a subject to practice</h3>
{% for s,(i,c) in subjects.items() %}<a class="subj" href="/practice/{{s}}"><div class="ic" style="background:{{c}}22">{{i}}</div>
<div class="m"><b>{{s}} Olympiad</b><span class="tag">{{st.subj[s].icon}} {{st.subj[s].title}}</span><small>Level {{st.subj[s].lvl}} of 18 · {{st.subj[s].total}} answered · {{st.subj[s].pct}}% correct</small><div class="bar"><i style="width:{{st.subj[s].mastery}}%;background:{{c}}"></i></div></div><div class="go">→</div></a>{% endfor %}<p class="legend">Review mistakes: {% for s in subjects %}<a class="lnk" href="/practice/{{s}}?review=1">{{s}}</a>{% endfor %}</p></div>
<div><h3>Weekly progress</h3><div class="week">{% for w in st.week %}<div class="col"><div class="b" style="height:{{(w.n/st.maxday*100)|round}}%" title="{{w.ok}}/{{w.n}} correct"><i style="height:{{(w.ok/w.n*100)|round if w.n else 0}}%"></i></div>{{w.label}}</div>{% endfor %}</div>
<div class="legend">Dark = correct · Light = attempted</div></div></div></div></div></div>{% endblock %}"""

PRACTICE = """{% extends 'base.html' %}{% block body %}<div class="card q{{' kid' if user['age']<=7}}" id="box">
<div class="qh"><span>{{icon}} {{subject}} · Age {{user['age']}}</span><span id="cnt"></span></div><div class="bar"><i id="pg" style="width:0"></i></div>
<div id="area"></div></div>
<script>
const SUB={{subject|tojson}},TOTAL={{total}},REVIEW={{review|tojson}},AGE={{user['age']}};let seen=[],n=0,score=0,cur=null;
const $=id=>document.getElementById(id),el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e};
function speak(r){if(!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(r.q+'. '+r.opts.map((o,i)=>String.fromCharCode(65+i)+', '+o).join('. '));u.rate=.85;speechSynthesis.speak(u)}
async function next(){
  const r=await (await fetch(`/api/question?subject=${SUB}&seen=${seen.join(',')}&review=${REVIEW?1:0}`)).json();
  if(r.done||n>=TOTAL)return finish(r.review_empty);
  cur=r;seen.push(r.id);$('cnt').textContent=`Question ${n+1} of ${TOTAL}`;$('pg').style.width=(n/TOTAL*100)+'%';
  const a=$('area');a.innerHTML='';a.append(el('div','qt',r.q));const sp=el('button','btn b-ghost','🔊 Read aloud');sp.style.marginBottom='14px';sp.onclick=()=>speak(r);a.append(sp);
  r.opts.forEach((o,i)=>{const b=el('button','opt',String.fromCharCode(65+i)+'.  '+o);b.onclick=()=>answer(i,b);a.append(b)});if(AGE<=5)speak(r);
}
async function answer(i,btn){
  const bs=[...document.querySelectorAll('.opt')];bs.forEach(b=>b.disabled=true);
  const r=await (await fetch('/api/answer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:cur.id,choice:i})})).json();
  bs[r.answer].classList.add('ok');if(!r.correct)btn.classList.add('no');else score++;
  n++;$('pg').style.width=(n/TOTAL*100)+'%';
  const e=el('div','exp');e.append(el('b','',r.correct?'🎉 Correct! Well done.':'💡 Not quite — here is why:'),el('span','',r.why));$('area').append(e);
  const nb=el('button','btn b-ind',n>=TOTAL?'See my result →':'Next question →');nb.style.marginTop='18px';nb.onclick=next;$('area').append(nb);
}
async function finish(empty){
  const a=$('area');a.innerHTML='';$('pg').style.width='100%';$('cnt').textContent='Done!';
  if(empty&&!n){const d=el('div','res');d.append(el('div','big','🎉'),el('h2','','No mistakes to review!'),el('p','','Everything you answered so far was right. Try a normal round.'));const b=el('a','btn b-ind','Dashboard');b.href='/dashboard';d.append(el('br'),b);a.append(d);return}
  let info=null;if(n){try{info=await (await fetch('/api/finish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({subject:SUB,score:score,total:n})})).json()}catch(e){}}
  const t=n||1,p=score/t,d=el('div','res');
  d.append(el('div','big',p>=.8?'🏆':p>=.5?'🌟':'💪'),el('h2','',`You scored ${score} / ${n}`),
    el('p','',p>=.8?'Brilliant work, Olympiad star!':p>=.5?'Good job! A little more practice and you will shine.':'Every mistake is a lesson. Try again!'));if(info&&info.title)d.append(el('p','',`Your ${SUB} level: ${info.title} · Level ${info.lvl} of 18`));
  const b1=el('a','btn b-ind','Practice again');b1.href=location.href;const b2=el('a','btn b-ghost','Dashboard');b2.href='/dashboard';b2.style.marginLeft='10px';
  d.append(el('br'),b1,b2);a.append(d);
}
next();
</script>{% endblock %}"""

app.jinja_loader = DictLoader({"base.html": BASE, "home.html": HOME, "dash.html": DASH, "practice.html": PRACTICE})

init_db()
if __name__ == "__main__":
    if "--check" in sys.argv:
        report()
    else:
        app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
