# VAT-DESK

A Windows desktop program (and a web version) for UAE VAT practitioners: VAT 201 workings, penalty calculators, a deadline calendar, VAT groups, a filing assistant and Excel/PDF reports, for any number of client entities. It covers VAT only. Corporate tax, transfer pricing and the registers are not part of VAT-DESK.

## Get the program (Windows EXE)

An EXE can only be built on Windows. On a Windows PC:

1. Install Python 3.10 or newer from python.org (tick "Add python.exe to PATH").
2. Double-click `build_exe.bat`. It creates a virtual environment, installs the packages, runs the calculation test and builds the program.
3. Copy the folder `dist\VAT-DESK` to any PC and run `VAT-DESK.exe`. No installation or Python is needed on those PCs.

To try it without building, double-click `run_dev.bat`. Windows may show a SmartScreen warning for an unsigned program.

## First start

The first run asks you to create the administrator account and firm name, and can load sample clients. The database is one file: `%APPDATA%\UAETaxSuite\uae_tax.db`. The data folder keeps its older name on purpose, so databases made with earlier versions open as they are.

Databases from earlier versions may hold corporate tax and transfer pricing data. VAT-DESK never deletes it and never shows it; it simply stays in the file.

**Several users:** on the sign-in window choose *Change database location* and point every PC at the same file on a shared network folder.

## Pages

| Page | What it does |
|---|---|
| Dashboard | Position of every client, overdue items, net VAT, penalty exposure, next deadlines, priority issues |
| Clients | Client records, search by ID or name, import from Excel/CSV, register export, start next VAT period |
| Data | VAT rows per client: edit in the grid, import Excel/CSV, download the import template, or **Connect to accounting software** (Tally, Zoho Books, ERPNext / Frappe) |
| Returns and workings | Summary, VAT 201 in the FTA format with a From / To period bar, reconciliations, sign-off, the 30 VAT schedules, the VAT checklist and the VAT Return basis. Excel and PDF packs, filing pack ZIP, client summary |
| FTA Filing Assistant | The saved VAT return fields for copying into EmaraTax, or review of a VAT 201 Excel template. Never connects to or submits to the FTA |
| Tax groups | VAT groups and the group VAT 201 (FTA) with an Excel export |
| Penalties | VAT late filing, late payment, late registration and record-keeping, prefilled from the client record |
| Calendar and open items | VAT deadlines and issues, reminders with penalties, calendar file (.ics), by-location summary |
| Rules and rates | Every VAT rate, threshold and deadline (admin edits; each change logged) |
| Users, Audit and backup (admin) | Roles, password reset, audit trail, database backup |

Totals on the VAT 201 come from the uploaded rows when a client has them; otherwise the figures typed on the client record are used.

## Roles

Admin (everything), Preparer and Reviewer (edit clients and data), Viewer (read only). Passwords are salted PBKDF2-SHA256 hashes; five wrong attempts lock the account for 15 minutes; new users must change their temporary password at first sign-in.

## Importing data

Use *Download import template* on the Data page. It has a Clients sheet, a VAT Data sheet and a VAT box mapping sheet. Transaction types must match the drop-down list. Rows with problems are skipped and listed.

## Connecting to accounting software

*Data > Connect to accounting software* pulls VAT rows into a review table first (nothing is saved until you press Import), then replaces the client's rows for that period. All connections are read only; secrets are kept only on that PC.

- **Tally / TallyPrime:** vouchers over Tally's local XML server (port 9000), month by month. Optional gateway address and access key.
- **Zoho Books:** read-only OAuth access to invoices, bills, credit notes and vendor credits.
- **ERPNext / Frappe:** read-only REST access with an API key and secret; submitted Sales and Purchase Invoices.

These connectors were tested against simulated servers, not live accounts: run a small period first and compare totals with the accounting system.

## Control features

- **Data validation** on every grid save, file import and accounting-software import (errors can block; warnings do not). *Data > Validate data* lists everything for a client.
- **Reconciliations** of ledger balances against the VAT 201.
- **Sign-off and locking** of a VAT period: submit, approve (locks data), return, reopen with a reason; the preparer and approver must differ unless self-approval is on.
- **Rules change log** with reasons, and a prompt to review rules every 90 days.
- **Backups:** a daily automatic copy (newest 14 kept), back up now and restore under Audit and backup.
- **Filing pack (ZIP):** readiness check, data-entry workbook in EmaraTax order, PDF and Excel packs, client summary (English and Arabic).
- **Formats:** amounts as 1,234,567.89; dates as DD-MM-YYYY with a calendar on every date box.
- **Export** to Excel and PDF of any page.

## Tests

`tests\` holds the regression tests; see `tests\README` comments in each file. Most run as scripts (`python tests\test_flow.py`); `test_fta_assistant.py` and `test_saved_assistant.py` run with `python -m unittest`.

## Limits to know

- Working papers and estimates, not filed returns. Box numbers, thresholds and penalty amounts must be checked against current FTA guidance before filing.
- Not modelled: e-invoicing and voluntary disclosure penalties.
- Branches are not modelled: a branch shares the head office TRN, so keep it in one client record.
- VAT groups: the group return is the members' returns added together with supplies between members left out (counterparty TRN, or name if there is no TRN, shown as "Name" for you to confirm). Members must share the same VAT period end.
