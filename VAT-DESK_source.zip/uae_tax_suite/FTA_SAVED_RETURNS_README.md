# FTA Filing Assistant - Saved Returns Integration

## Use
1. Start the application as before (install requirements.txt, then run main.py).
2. In Returns and workings, select the client and review calculations and reconciliations.
3. Click **Save return snapshot for Filing Assistant** to preserve the current VAT and CT field sets. Saving does not approve a return or change its calculations.
4. In FTA Filing Assistant, select client, VAT/CT and tax period ending. Data loads automatically; Fetch Return Data reloads the latest saved snapshot for that combination.
5. Review the source metadata, errors, warnings and detailed fields. Copy Value copies one value without thousands separators. Open EmaraTax and complete filing manually.
6. Export filing review packs and record filing evidence as before. Choose return Excel remains available for supported legacy templates.

## Saved data and periods
The latest snapshot is selected by increasing database version ID, not timestamp. Older periods appear only where detailed snapshots have been saved. Existing approval snapshots contain summary totals only and cannot reconstruct historical returns. For a current period without a detailed snapshot, the assistant uses the existing calculation engine on saved database inputs, with an explicit warning. Unsaved editor contents are excluded.

After changing saved inputs, save a new snapshot in Returns and workings. Otherwise the previously saved snapshot continues to appear, with a warning. Snapshot metadata records the approval status when saved and the current approval status when fetched; neither is a filing authorization. Historical snapshots retain the taxpayer details and figures saved at that time.

## Compatibility
Based on the downloaded UAE_Tax_Suite_With_FTA_Filing_Assistant (1).zip. The original source ZIP and earlier Option A package were inspected. The original assistant implementation was extended to retain its Excel parser, export, portal-opening and filing-evidence functions. Existing tax engines and other modules were preserved.

The database gains one additive table, filing_snapshots. Existing records are not rewritten. Keep a database backup before upgrading. Snapshot saving uses the existing edit permission; fetching checks client visibility and performs no database writes. The desktop interface is updated; the web interface is unchanged.

## Mapping limits
The field listing uses the application's existing VAT and CT return layouts. It is not certified against the current live EmaraTax interface. Verify conditional schedules, elections, declarations and current portal labels manually. Validation identifies malformed TRNs and return reconciliation differences; it is not a full tax-return completeness review. Excel import retains the original supported template formats; it does not add support for every workbook export format.

No automatic portal entry, API connection or FTA submission is implemented. The portal button only opens the existing URL. Evidence remains user-attested.
