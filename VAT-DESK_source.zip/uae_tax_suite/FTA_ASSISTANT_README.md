# FTA Filing Assistant (independent module)

New package: `fta_assistant/` provides a tab in the existing PyQt6 application. Original engines and tax rules have not been modified.

## Run on Windows
1. Extract this ZIP. Run existing install/setup procedures in `README.md`.
2. In `uae_tax_suite`, run `python -m pip install -r requirements.txt` then `python main.py`.
3. Select **FTA Filing Assistant**, choose **VAT** or **CT**, import Excel, click **Validate template**, then **Export filing review pack**.
4. Review HTML, CSV and validation JSON (these are NOT approved FTA upload formats). Open EmaraTax, sign in using authorized credentials, manually review/enter values and submit there.
5. Save the FTA acknowledgement locally and use **Record filing evidence** to associate a self-attested filing reference with a source-file hash.

## Important limits
- No direct EmaraTax API, automated field entry, login bypass, or programmatic submission.
- CT extraction is generic source field/value listing, not validated FTA portal mapping. All conditional CT schedules and elections require review.
- VAT reconciliation uses source-form boxes, but semantic tax/legal validation is not guaranteed.
- VAT sample contains inconsistent TRNs between its heading and detail sheet; the assistant will block the sample on validation.
- Do not distribute the provided sample files with customer data. Use synthetic data when testing.
- If marketing commercially, seek independent security testing and confirm current FTA software-vendor rules and any permitted integration.

## Source files
`fta_assistant/engine.py` reads, validates and writes ZIP review pack. `fta_assistant/widget.py` hosts the UI.
Run standalone tests: `python -m unittest tests.test_fta_assistant`.
