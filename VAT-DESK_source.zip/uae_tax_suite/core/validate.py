"""Checks on uploaded rows before they reach a return: duplicates, TRN format, VAT arithmetic, dates, signs and missing fields.

Each issue is a dict(row, severity, field, message). Severity is 'Error' (almost certainly wrong) or 'Warning' (look at it).
Row numbers are positions in the list given (1 based)."""
from __future__ import annotations

import datetime as dt
import re

from . import engine

TRN_RE = re.compile(r"^\d{15}$")


def _n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _d(x):
    try:
        return dt.date.fromisoformat(str(x)[:10]) if x not in (None, "") else None
    except ValueError:
        return None


def trn_ok(s) -> bool:
    return bool(TRN_RE.match(re.sub(r"[\s-]", "", str(s or ""))))


def _issue(out, row, sev, field, msg):
    out.append(dict(row=row, severity=sev, field=field, message=msg))


def validate_vat(rows, R=None, step=3, today=None):
    R = R or {}
    rate = float(R.get("vat_rate", 0.05) or 0.05)
    today = today or dt.date.today()
    out, seen = [], {}
    for i, r in enumerate(rows, 1):
        dd, pe = _d(r.get("doc_date")), _d(r.get("period_end"))
        net, vat = _n(r.get("net")), _n(r.get("vat"))
        t = r.get("doc_type") or ""
        if dd is None:
            _issue(out, i, "Error", "doc_date", "Document date is missing or not a date")
        elif dd > today + dt.timedelta(days=31):
            _issue(out, i, "Warning", "doc_date", "Document date %s is in the future" % dd)
        if pe is None:
            _issue(out, i, "Error", "period_end", "VAT period end is missing or not a date")
        elif dd is not None and not (engine.add_months(pe, -step) < dd <= pe):
            _issue(out, i, "Warning", "period_end", "Document date %s is outside the %d-month period ending %s" % (dd, step, pe))
        if not t:
            _issue(out, i, "Error", "doc_type", "Transaction type is missing")
        if net is None:
            _issue(out, i, "Error", "net", "Taxable value is missing or not a number")
            continue
        vat = vat or 0.0
        if not (r.get("party") or "").strip():
            _issue(out, i, "Warning", "party", "Customer / supplier name is missing")
        if not (r.get("doc_no") or "").strip():
            _issue(out, i, "Warning", "doc_no", "Document number is missing")
        if t in ("Sale - standard rated", "Purchase - standard rated"):
            if abs(vat - net * rate) > max(1.0, abs(net) * 0.002):
                _issue(out, i, "Warning", "vat", "VAT %s is not %.0f%% of %s (expected %s)" % ("{:,.2f}".format(vat), rate * 100, "{:,.2f}".format(net), "{:,.2f}".format(net * rate)))
        elif t in ("Sale - zero rated", "Sale - exempt", "Sale - designated zone goods") and abs(vat) > 0.005:
            _issue(out, i, "Error", "vat", "%s should carry no VAT but VAT is %s" % (t, "{:,.2f}".format(vat)))
        if t in ("Sale - credit note", "Purchase - credit note") and net < 0:
            _issue(out, i, "Warning", "net", "Credit notes are entered as positive amounts; this one is negative")
        elif t.startswith(("Sale - standard", "Sale - zero", "Sale - exempt", "Purchase - standard")) and net < 0:
            _issue(out, i, "Warning", "net", "Negative amount on %s: should this be a credit note?" % t)
        trn = str(r.get("trn") or "").strip()
        if trn and not trn_ok(trn):
            _issue(out, i, "Warning", "trn", "TRN '%s' is not 15 digits" % trn)
        if r.get("emirate") and r.get("emirate") not in ("Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Umm Al Quwain", "Ras Al Khaimah", "Fujairah"):
            _issue(out, i, "Warning", "emirate", "Emirate '%s' is not one of the seven emirates" % r.get("emirate"))
        key = ((r.get("doc_no") or "").strip().lower(), (r.get("party") or "").strip().lower(), t, round(net, 2), round(vat, 2))
        if key[0] and key in seen:
            _issue(out, i, "Warning", "doc_no", "Looks like a duplicate of row %d (same document no., party, type and amounts)" % seen[key])
        else:
            seen.setdefault(key, i)
    return out


def validate(kind, rows, R=None, entity=None, today=None):
    if kind == "vat":
        step = 1 if (entity or {}).get("vat_frequency") == "Monthly" else 3
        return validate_vat(rows, R, step, today)
    return []


def summary(issues):
    e = sum(1 for i in issues if i["severity"] == "Error")
    return e, len(issues) - e


def text(issues, limit=15):
    lines = [("Row %d: " % i["row"] if i["row"] else "") + "[%s] %s" % (i["severity"], i["message"]) for i in sorted(issues, key=lambda x: (x["severity"] != "Error", x["row"]))[:limit]]
    if len(issues) > limit:
        lines.append("... and %d more" % (len(issues) - limit))
    return "\n".join(lines)
