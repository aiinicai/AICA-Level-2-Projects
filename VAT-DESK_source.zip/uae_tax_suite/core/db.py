"""SQLite storage: users, clients, upload rows, rules, checklists and audit trail."""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
import os
import secrets
import shutil
import sqlite3
import sys

from . import engine

ROLES = ["Admin", "Preparer", "Reviewer", "Viewer"]
CAN_EDIT = {"Admin", "Preparer", "Reviewer"}
ITER = 240_000
MAX_FAILS = 5
LOCK_MIN = 15


def base_dir() -> str:
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def data_path(name: str) -> str:
    return os.path.join(base_dir(), "data", name)


def load_json(name: str):
    with open(data_path(name), encoding="utf-8") as f:
        return json.load(f)


def now() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def hash_pw(pw: str, salt: bytes | None = None, iters: int = ITER):
    salt = salt or secrets.token_bytes(16)
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, iters).hex(), salt.hex(), iters


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, display_name TEXT, role TEXT,
  pw_hash TEXT, salt TEXT, iters INTEGER, active INTEGER DEFAULT 1, fails INTEGER DEFAULT 0, locked_until TEXT, must_change INTEGER DEFAULT 0, created TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS entities(id TEXT PRIMARY KEY, data TEXT, updated_by TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS vat_rows(id INTEGER PRIMARY KEY, entity_id TEXT, period_end TEXT, doc_date TEXT, doc_no TEXT, party TEXT, doc_type TEXT, net REAL, vat REAL, description TEXT, trn TEXT, emirate TEXT);
CREATE TABLE IF NOT EXISTS ct_rows(id INTEGER PRIMARY KEY, entity_id TEXT, fy_end TEXT, account TEXT, account_name TEXT, category TEXT, amount REAL);
CREATE TABLE IF NOT EXISTS tp_rows(id INTEGER PRIMARY KEY, entity_id TEXT, fy_end TEXT, counterparty TEXT, relationship TEXT, country TEXT, txn_type TEXT, amount REAL, method TEXT, description TEXT, direction TEXT, trn TEXT, arm_value REAL, pay_type TEXT, method_other TEXT);
CREATE TABLE IF NOT EXISTS prop_rows(id INTEGER PRIMARY KEY, entity_id TEXT, address TEXT, makani TEXT, own_date TEXT, orig_cost REAL, nbv_start REAL);
CREATE TABLE IF NOT EXISTS tp_bench(id INTEGER PRIMARY KEY, entity_id TEXT, fy_end TEXT, group_revenue REAL, tested_base REAL, actual_margin REAL, range_low REAL, range_median REAL, range_high REAL, docs_status TEXT, disclosure_filed TEXT);
CREATE TABLE IF NOT EXISTS rules(key TEXT PRIMARY KEY, grp TEXT, label TEXT, value TEXT, unit TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS checklist(entity_id TEXT, area TEXT, item TEXT, status TEXT, note TEXT, updated_by TEXT, updated_at TEXT, PRIMARY KEY(entity_id, area, item));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts TEXT, username TEXT, action TEXT, target TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS account_map(entity_id TEXT, key TEXT, account_name TEXT, category TEXT, updated_by TEXT, updated_at TEXT, PRIMARY KEY(entity_id, key));
CREATE TABLE IF NOT EXISTS filing_snapshots(id INTEGER PRIMARY KEY, entity_id TEXT NOT NULL, kind TEXT NOT NULL, period_end TEXT NOT NULL, saved_at TEXT NOT NULL, saved_by TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS signoff(entity_id TEXT, kind TEXT, period_end TEXT, status TEXT, prepared_by TEXT, prepared_at TEXT, reviewed_by TEXT, reviewed_at TEXT,
  note TEXT, snapshot TEXT, PRIMARY KEY(entity_id, kind, period_end));
CREATE TABLE IF NOT EXISTS signoff_log(id INTEGER PRIMARY KEY, ts TEXT, username TEXT, entity_id TEXT, kind TEXT, period_end TEXT, action TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS rules_log(id INTEGER PRIMARY KEY, ts TEXT, username TEXT, key TEXT, label TEXT, old TEXT, new TEXT, effective_from TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS loss_reg(id INTEGER PRIMARY KEY, entity_id TEXT, fy_end TEXT, kind TEXT, amount REAL, note TEXT, source TEXT, updated_by TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS user_clients(username TEXT COLLATE NOCASE, entity_id TEXT, PRIMARY KEY(username, entity_id));
CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY, entity_id TEXT, area TEXT, item TEXT, filename TEXT, stored TEXT, note TEXT, added_by TEXT, added_at TEXT);
CREATE TABLE IF NOT EXISTS var_notes(entity_id TEXT, fy_end TEXT, line TEXT, note TEXT, updated_by TEXT, updated_at TEXT, PRIMARY KEY(entity_id, fy_end, line));
CREATE TABLE IF NOT EXISTS pe_inputs(entity_id TEXT, period TEXT, data TEXT, updated_by TEXT, updated_at TEXT, PRIMARY KEY(entity_id, period));
CREATE TABLE IF NOT EXISTS vat_groups(group_id TEXT PRIMARY KEY, name TEXT, trn TEXT, rep_member TEXT);
CREATE TABLE IF NOT EXISTS vat_group_members(group_id TEXT, entity_id TEXT, PRIMARY KEY(group_id, entity_id));
CREATE TABLE IF NOT EXISTS group_elims(id INTEGER PRIMARY KEY, group_id TEXT, fy_end TEXT, target TEXT, amount REAL, note TEXT, updated_by TEXT, updated_at TEXT);
CREATE INDEX IF NOT EXISTS ix_docs ON docs(entity_id);
CREATE INDEX IF NOT EXISTS ix_loss ON loss_reg(entity_id);
CREATE INDEX IF NOT EXISTS ix_vat ON vat_rows(entity_id); CREATE INDEX IF NOT EXISTS ix_ct ON ct_rows(entity_id);
CREATE INDEX IF NOT EXISTS ix_tp ON tp_rows(entity_id); CREATE INDEX IF NOT EXISTS ix_prop ON prop_rows(entity_id); CREATE INDEX IF NOT EXISTS ix_tb ON tp_bench(entity_id);
"""

VAT_COLS = ["period_end", "doc_date", "doc_no", "party", "doc_type", "net", "vat", "description", "trn", "emirate"]
CT_COLS = ["fy_end", "account", "account_name", "category", "amount"]
TP_COLS = ["fy_end", "counterparty", "relationship", "country", "txn_type", "amount", "method", "description", "direction", "trn", "arm_value", "pay_type", "method_other"]
PROP_COLS = ["address", "makani", "own_date", "orig_cost", "nbv_start"]
BENCH_COLS = ["fy_end", "group_revenue", "tested_base", "actual_margin", "range_low", "range_median", "range_high", "docs_status", "disclosure_filed"]
TABLES = {"vat": ("vat_rows", VAT_COLS)}      # the CT / TP tables stay in old database files (hidden, never deleted) but are no longer used


class AuthError(Exception):
    pass


class PermissionDenied(Exception):
    pass


class DB:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.c = sqlite3.connect(path, timeout=30)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA journal_mode=WAL")
        self.c.execute("PRAGMA foreign_keys=ON")
        self.c.executescript(SCHEMA)
        have = {r[1] for r in self.c.execute("PRAGMA table_info(tp_rows)")}
        for col, typ in (("direction", "TEXT"), ("trn", "TEXT"), ("arm_value", "REAL"), ("pay_type", "TEXT"), ("method_other", "TEXT")):
            if col not in have:
                self.c.execute("ALTER TABLE tp_rows ADD COLUMN %s %s" % (col, typ))
        for tbl, col, typ in (("vat_groups", "kind", "TEXT DEFAULT 'VAT'"), ("vat_group_members", "own_pct", "REAL")):
            if col not in {r[1] for r in self.c.execute("PRAGMA table_info(%s)" % tbl)}:
                self.c.execute("ALTER TABLE %s ADD COLUMN %s %s" % (tbl, col, typ))
        self.user: dict | None = None
        self._init_rules()

    # ---------------------------------------------------------------- users
    def has_users(self) -> bool:
        return self.c.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0

    def create_user(self, username, password, role="Preparer", display_name="", must_change=False, actor="system"):
        if role not in ROLES:
            raise ValueError("Unknown role")
        username = username.strip()
        if not username or len(password) < 8:
            raise ValueError("Username required and password must be at least 8 characters")
        h, s, it = hash_pw(password)
        try:
            self.c.execute("INSERT INTO users(username,display_name,role,pw_hash,salt,iters,must_change,created) VALUES(?,?,?,?,?,?,?,?)",
                           (username, display_name or username, role, h, s, it, int(must_change), now()))
        except sqlite3.IntegrityError:
            raise ValueError("That username already exists")
        self.c.commit()
        self.audit("user.create", username, role, actor)

    def login(self, username, password) -> dict:
        r = self.c.execute("SELECT * FROM users WHERE username=?", (username.strip(),)).fetchone()
        if not r or not r["active"]:
            raise AuthError("Invalid username or password")
        if r["locked_until"] and r["locked_until"] > now():
            raise AuthError("Account locked after repeated failures. Try again later or ask an administrator.")
        h, _, _ = hash_pw(password, bytes.fromhex(r["salt"]), r["iters"])
        if not hmac.compare_digest(h, r["pw_hash"]):
            fails = r["fails"] + 1
            lock = (dt.datetime.now() + dt.timedelta(minutes=LOCK_MIN)).strftime("%Y-%m-%d %H:%M:%S") if fails >= MAX_FAILS else None
            self.c.execute("UPDATE users SET fails=?, locked_until=? WHERE id=?", (0 if lock else fails, lock, r["id"]))
            self.c.commit()
            self.audit("login.fail", r["username"], "", r["username"])
            raise AuthError("Invalid username or password")
        self.c.execute("UPDATE users SET fails=0, locked_until=NULL WHERE id=?", (r["id"],))
        self.c.commit()
        self.user = dict(id=r["id"], username=r["username"], display_name=r["display_name"], role=r["role"], must_change=bool(r["must_change"]))
        self.audit("login", r["username"], "")
        return self.user

    def logout(self):
        if self.user:
            self.audit("logout", self.user["username"], "")
        self.user = None

    def change_password(self, username, new_pw, actor=None):
        if len(new_pw) < 8:
            raise ValueError("Password must be at least 8 characters")
        h, s, it = hash_pw(new_pw)
        self.c.execute("UPDATE users SET pw_hash=?,salt=?,iters=?,must_change=0,fails=0,locked_until=NULL WHERE username=?", (h, s, it, username))
        self.c.commit()
        self.audit("user.password", username, "", actor)

    def verify_password(self, username, pw) -> bool:
        r = self.c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if not r:
            return False
        h, _, _ = hash_pw(pw, bytes.fromhex(r["salt"]), r["iters"])
        return hmac.compare_digest(h, r["pw_hash"])

    def list_users(self):
        return [dict(r) for r in self.c.execute("SELECT id,username,display_name,role,active,created FROM users ORDER BY username")]

    def update_user(self, username, role=None, active=None, display_name=None):
        self.need("Admin")
        if role is not None:
            if role not in ROLES:
                raise ValueError("Unknown role")
        admins = self.c.execute("SELECT COUNT(*) FROM users WHERE role='Admin' AND active=1 AND username<>?", (username,)).fetchone()[0]
        if admins == 0 and ((role and role != "Admin") or active == 0):
            raise ValueError("At least one active administrator is required")
        for col, v in (("role", role), ("active", active), ("display_name", display_name)):
            if v is not None:
                self.c.execute("UPDATE users SET %s=? WHERE username=?" % col, (v, username))
        self.c.commit()
        self.audit("user.update", username, "role=%s active=%s" % (role, active))

    # ---------------------------------------------------------------- permissions
    def role(self):
        return self.user["role"] if self.user else None

    def can_edit(self):
        return self.role() in CAN_EDIT

    def need(self, *roles):
        if self.role() not in roles:
            raise PermissionDenied("Your role (%s) cannot do this." % (self.role() or "none"))

    def need_edit(self):
        if not self.can_edit():
            raise PermissionDenied("Your role (%s) is read only." % (self.role() or "none"))

    # ---------------------------------------------------------------- audit
    def audit(self, action, target="", detail="", actor=None):
        who = actor or (self.user["username"] if self.user else "")
        self.c.execute("INSERT INTO audit(ts,username,action,target,detail) VALUES(?,?,?,?,?)", (now(), who, action, target, str(detail)[:2000]))
        self.c.commit()

    def audit_log(self, limit=1000):
        return [dict(r) for r in self.c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))]

    # ---------------------------------------------------------------- rules
    def _init_rules(self):
        if self.c.execute("SELECT COUNT(*) FROM rules").fetchone()[0] == 0:
            self.reset_rules(audit=False)

    def reset_rules(self, audit=True, reason="Reset to shipped defaults"):
        if audit:
            self.need("Admin")
            self.c.execute("INSERT INTO rules_log(ts,username,key,label,old,new,effective_from,reason) VALUES(?,?,?,?,?,?,?,?)",
                           (now(), self.user["username"], "ALL", "All rules", "", "defaults", "", reason))
        self.c.execute("DELETE FROM rules")
        for r in load_json("rules_default.json"):
            self.c.execute("INSERT INTO rules VALUES(?,?,?,?,?,?)", (r["key"], r["group"], r["label"], json.dumps(r["value"]), r["unit"], r.get("note", "")))
        self.c.commit()
        if audit:
            self.audit("rules.reset", "rules")

    def rules(self):
        return [dict(key=r["key"], group=r["grp"], label=r["label"], value=json.loads(r["value"]), unit=r["unit"], note=r["note"])
                for r in self.c.execute("SELECT * FROM rules ORDER BY rowid")]

    def rules_dict(self):
        return engine.rules_to_dict(self.rules())

    def set_rule(self, key, value, reason="", effective_from=""):
        """Every change needs a reason (for example the FTA decision or guide) and may carry the date from which it applies. It is kept in the rules change log."""
        self.need("Admin")
        if len((reason or "").strip()) < 3:
            raise ValueError("Give a reason for the change (for example the FTA decision, guide or cabinet decision it follows).")
        old = self.c.execute("SELECT value, label FROM rules WHERE key=?", (key,)).fetchone()
        if not old:
            raise ValueError("Unknown rule")
        if json.loads(old["value"]) == value:
            return
        self.c.execute("UPDATE rules SET value=? WHERE key=?", (json.dumps(value), key))
        self.c.execute("INSERT INTO rules_log(ts,username,key,label,old,new,effective_from,reason) VALUES(?,?,?,?,?,?,?,?)",
                       (now(), self.user["username"], key, old["label"], old["value"], json.dumps(value), effective_from or "", reason.strip()))
        self.c.commit()
        self.audit("rules.update", key, "%s -> %s (%s)" % (old["value"], value, reason.strip()))

    def rules_log(self, limit=500):
        return [dict(r) for r in self.c.execute("SELECT * FROM rules_log ORDER BY id DESC LIMIT ?", (limit,))]

    def mark_rules_reviewed(self, note=""):
        self.need("Admin")
        self.set_setting("rules_reviewed_on", dt.date.today().isoformat())
        self.set_setting("rules_reviewed_by", self.user["username"])
        self.audit("rules.reviewed", "rules", note or "Checked against current FTA guidance")

    def rules_review_age(self, today=None):
        """Days since the rules were last confirmed against FTA guidance, or None if never."""
        d = self.setting("rules_reviewed_on", "")
        if not d:
            return None
        return ((today or dt.date.today()) - dt.date.fromisoformat(d)).days

    # ---------------------------------------------------------------- entities
    def visible_clients(self):
        """None when the signed-in user sees every client; otherwise the set of client IDs assigned to them.
        Administrators always see all clients. A user with no assignments sees all (the default for a small firm)."""
        if not self.user or self.user.get("role") == "Admin":
            return None
        ids = {r["entity_id"] for r in self.c.execute("SELECT entity_id FROM user_clients WHERE username=?", (self.user["username"],))}
        return ids or None

    def client_assignments(self, username):
        return sorted(r["entity_id"] for r in self.c.execute("SELECT entity_id FROM user_clients WHERE username=?", (username,)))

    def assign_clients(self, username, ids):
        """Limit a user to the listed clients (an empty list removes the limit)."""
        self.need("Admin")
        self.c.execute("DELETE FROM user_clients WHERE username=?", (username,))
        self.c.executemany("INSERT OR IGNORE INTO user_clients VALUES(?,?)", [(username, i) for i in ids])
        self.c.commit()
        self.audit("user.clients", username, ", ".join(ids) if ids else "all clients")

    def entities(self):
        vis = self.visible_clients()
        return [dict(json.loads(r["data"]), id=r["id"]) for r in self.c.execute("SELECT * FROM entities ORDER BY id") if vis is None or r["id"] in vis]

    def entity(self, eid):
        r = self.c.execute("SELECT * FROM entities WHERE id=?", (eid,)).fetchone()
        return dict(json.loads(r["data"]), id=r["id"]) if r else None

    def next_entity_id(self):
        nums = [int(r["id"][1:]) for r in self.c.execute("SELECT id FROM entities") if r["id"][1:].isdigit()]
        return "E%02d" % (max(nums, default=0) + 1)

    def save_entity(self, data: dict, _bypass_lock=False):
        self.need_edit()
        eid = (data.get("id") or "").strip()
        if not eid or not (data.get("name") or "").strip():
            raise ValueError("Entity ID and name are required")
        existed = self.c.execute("SELECT 1 FROM entities WHERE id=?", (eid,)).fetchone()
        if existed:
            old = self.entity(eid)
            hidden = {f["key"] for f in load_json("fields.json") if f.get("hidden")}
            data = dict(data, **{k: v for k, v in old.items() if k in hidden and k not in data})      # values the VAT screens do not show are kept
        if existed and not _bypass_lock:
            if {k: v for k, v in old.items()} != {k: v for k, v in data.items()}:
                vpe, fy = self.current_periods(eid)
                if vpe and self.is_locked(eid, "VAT", vpe):
                    raise PermissionDenied("The VAT period ending %s for %s is approved and locked. A reviewer must reopen it before the client record can change." % (vpe, eid))
        if existed and self.visible_clients() is not None and eid not in self.visible_clients():
            raise PermissionDenied("This client is not assigned to you.")
        self.c.execute("INSERT OR REPLACE INTO entities VALUES(?,?,?,?)", (eid, json.dumps(data), self.user["username"], now()))
        if not existed and self.visible_clients() is not None:
            self.c.execute("INSERT OR IGNORE INTO user_clients VALUES(?,?)", (self.user["username"], eid))
        self.c.commit()
        self.audit("entity.update" if existed else "entity.create", eid, data.get("name"))

    def delete_entity(self, eid):
        self.need("Admin")
        for t in ("vat_rows", "ct_rows", "tp_rows", "tp_bench", "prop_rows", "checklist", "account_map", "signoff", "signoff_log", "loss_reg", "user_clients", "docs", "var_notes", "pe_inputs", "vat_group_members"):
            self.c.execute("DELETE FROM %s WHERE entity_id=?" % t, (eid,))
        self.c.execute("DELETE FROM entities WHERE id=?", (eid,))
        self.c.commit()
        self.audit("entity.delete", eid)

    # ---------------------------------------------------------------- upload rows
    def rows(self, kind, eid=None):
        tbl, cols = TABLES[kind]
        q = "SELECT id, entity_id, %s FROM %s" % (", ".join(cols), tbl)
        a = ()
        if eid:
            q += " WHERE entity_id=?"
            a = (eid,)
        return [dict(r) for r in self.c.execute(q + " ORDER BY id", a)]

    # ---------------------------------------------------------------- sign-off and locks
    def current_periods(self, eid):
        """(VAT period end, "") a client's return is currently built for. The second item is kept empty for older callers."""
        e = self.entity(eid) or {}
        vpe = e.get("vat_period_end") or ""
        if not vpe:
            r = self.c.execute("SELECT MAX(period_end) m FROM vat_rows WHERE entity_id=?", (eid,)).fetchone()
            vpe = r["m"] or ""
        return str(vpe)[:10], ""

    def is_locked(self, eid, kind, period_end):
        r = self.c.execute("SELECT status FROM signoff WHERE entity_id=? AND kind=? AND period_end=?", (eid, kind, str(period_end)[:10])).fetchone()
        return bool(r and r["status"] == "Approved")

    def _guard(self, kind, eid, rows=(), existing_periods=()):
        """Refuse changes to an approved VAT period."""
        periods = {("VAT", str(r.get("period_end"))[:10]) for r in rows if r.get("period_end")} | {("VAT", str(p)[:10]) for p in existing_periods if p}
        for k, pe in sorted(periods):
            if pe and self.is_locked(eid, k, pe):
                raise PermissionDenied("The %s period ending %s for %s is approved and locked. A reviewer must reopen it before its data can change." % (k, pe, eid))

    def _existing_periods(self, kind, eid, where="", args=()):
        tbl, _ = TABLES[kind]
        col = "period_end" if kind == "vat" else "fy_end"
        if kind == "prop":
            return []
        return [r[0] for r in self.c.execute("SELECT DISTINCT %s FROM %s WHERE entity_id=? %s" % (col, tbl, where), (eid, *args))]

    def signoff_get(self, eid, kind, period_end):
        r = self.c.execute("SELECT * FROM signoff WHERE entity_id=? AND kind=? AND period_end=?", (eid, kind, str(period_end)[:10])).fetchone()
        if not r:
            return dict(entity_id=eid, kind=kind, period_end=str(period_end)[:10], status="Draft", prepared_by="", prepared_at="", reviewed_by="", reviewed_at="", note="", snapshot={})
        d = dict(r)
        d["snapshot"] = json.loads(d["snapshot"] or "{}")
        return d

    def signoff_list(self, eid=None):
        q, a = "SELECT * FROM signoff", ()
        if eid:
            q, a = q + " WHERE entity_id=?", (eid,)
        return [dict(r, snapshot=json.loads(r["snapshot"] or "{}")) for r in self.c.execute(q + " ORDER BY period_end DESC, kind", a)]

    def signoff_history(self, eid, limit=200):
        return [dict(r) for r in self.c.execute("SELECT * FROM signoff_log WHERE entity_id=? ORDER BY id DESC LIMIT ?", (eid, limit))]

    def _so_save(self, d, action, note=""):
        self.c.execute("INSERT OR REPLACE INTO signoff VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (d["entity_id"], d["kind"], d["period_end"], d["status"], d["prepared_by"], d["prepared_at"], d["reviewed_by"], d["reviewed_at"], d["note"], json.dumps(d["snapshot"])))
        self.c.execute("INSERT INTO signoff_log(ts,username,entity_id,kind,period_end,action,note) VALUES(?,?,?,?,?,?,?)",
                       (now(), self.user["username"], d["entity_id"], d["kind"], d["period_end"], action, note))
        self.c.commit()
        self.audit("signoff." + action.lower().replace(" ", "_"), "%s/%s/%s" % (d["entity_id"], d["kind"], d["period_end"]), note)

    def signoff_submit(self, eid, kind, period_end, note="", snapshot=None):
        self.need_edit()
        d = self.signoff_get(eid, kind, period_end)
        if d["status"] != "Draft":
            raise ValueError("Only a draft can be submitted for review (status is %s)." % d["status"])
        d.update(status="In review", prepared_by=self.user["username"], prepared_at=now(), reviewed_by="", reviewed_at="", note=note, snapshot=snapshot or {})
        self._so_save(d, "Submitted for review", note)

    def self_approval_allowed(self):
        return self.setting("allow_self_approval", "No") == "Yes"

    def signoff_approve(self, eid, kind, period_end, note="", snapshot=None, open_differences=0):
        self.need("Reviewer", "Admin")
        d = self.signoff_get(eid, kind, period_end)
        if d["status"] != "In review":
            raise ValueError("Only a return that is in review can be approved (status is %s)." % d["status"])
        me = self.user["username"]
        if me == d["prepared_by"] and not self.self_approval_allowed():
            raise PermissionDenied("Someone other than the preparer (%s) must approve. A sole practitioner can allow self-approval under Audit and backup > Controls." % d["prepared_by"])
        if open_differences and len((note or "").strip()) < 3:
            raise ValueError("%d reconciliation difference(s) or open high-severity item(s) remain: write a note explaining why the return is approved." % open_differences)
        d.update(status="Approved", reviewed_by=me, reviewed_at=now(), note=note or d["note"], snapshot=snapshot or d["snapshot"])
        self._so_save(d, "Approved" + (" (self)" if me == d["prepared_by"] else ""), note)

    def signoff_return(self, eid, kind, period_end, note):
        self.need("Reviewer", "Admin")
        d = self.signoff_get(eid, kind, period_end)
        if d["status"] != "In review":
            raise ValueError("Only a return in review can be sent back.")
        if len((note or "").strip()) < 3:
            raise ValueError("Say what the preparer needs to fix.")
        d.update(status="Draft", reviewed_by=self.user["username"], reviewed_at=now(), note=note)
        self._so_save(d, "Returned to preparer", note)

    def signoff_reopen(self, eid, kind, period_end, reason):
        self.need("Reviewer", "Admin")
        d = self.signoff_get(eid, kind, period_end)
        if d["status"] != "Approved":
            raise ValueError("Only an approved return can be reopened.")
        if len((reason or "").strip()) < 3:
            raise ValueError("A reason is required to reopen an approved return.")
        d.update(status="Draft", note="Reopened: " + reason.strip())
        self._so_save(d, "Reopened", reason.strip())

    def add_rows(self, kind, eid, rows, replace=False, source="manual"):
        self.need_edit()
        tbl, cols = TABLES[kind]
        self._guard(kind, eid, rows, self._existing_periods(kind, eid) if replace else ())
        if replace:
            self.c.execute("DELETE FROM %s WHERE entity_id=?" % tbl, (eid,))
        self.c.executemany("INSERT INTO %s(entity_id,%s) VALUES(?,%s)" % (tbl, ",".join(cols), ",".join("?" * len(cols))),
                           [(eid, *[r.get(c) for c in cols]) for r in rows])
        self.c.commit()
        self.audit("rows." + ("replace" if replace else "add"), "%s/%s" % (eid, kind), "%d rows via %s" % (len(rows), source))

    def replace_in_range(self, kind, eid, rows, d1, d2, source="connector"):
        """Replace this client's rows whose date lies in [d1, d2] (VAT: document date; CT: financial year end)."""
        self.need_edit()
        tbl, cols = TABLES[kind]
        col = "doc_date" if kind == "vat" else "fy_end"
        self._guard(kind, eid, rows, self._existing_periods(kind, eid, "AND %s BETWEEN ? AND ?" % col, (d1, d2)))
        cur = self.c.execute("DELETE FROM %s WHERE entity_id=? AND %s BETWEEN ? AND ?" % (tbl, col), (eid, d1, d2))
        self.c.executemany("INSERT INTO %s(entity_id,%s) VALUES(?,%s)" % (tbl, ",".join(cols), ",".join("?" * len(cols))),
                           [(eid, *[r.get(c) for c in cols]) for r in rows])
        self.c.commit()
        self.audit("rows.connector", "%s/%s" % (eid, kind), "%d rows replaced %d between %s and %s via %s" % (len(rows), cur.rowcount, d1, d2, source))

    def save_rows(self, kind, eid, rows):
        """Replace all rows of a kind for one entity (grid editor save).

        Rows of an approved (locked) period must come back unchanged; the rest are replaced."""
        self.need_edit()
        tbl, cols = TABLES[kind]
        col, k = "period_end", "VAT"
        locked = {str(p)[:10] for p in self._existing_periods(kind, eid) if p and self.is_locked(eid, k, p)}
        if not locked:
            return self.add_rows(kind, eid, rows, replace=True, source="grid")

        def norm(rs):
            return sorted(tuple("" if r.get(c) in (None, "") else (round(float(r.get(c)), 4) if isinstance(r.get(c), (int, float)) else str(r.get(c))) for c in cols) for r in rs)
        old = [r for r in self.rows(kind, eid) if str(r.get(col))[:10] in locked]
        new_locked = [r for r in rows if str(r.get(col))[:10] in locked]
        if norm(old) != norm(new_locked):
            raise PermissionDenied("Rows in an approved period (%s) were changed. A reviewer must reopen it first." % ", ".join(sorted(locked)))
        keep = [r for r in rows if str(r.get(col))[:10] not in locked]
        ph = ",".join("?" * len(locked))
        self.c.execute("DELETE FROM %s WHERE entity_id=? AND substr(%s,1,10) NOT IN (%s)" % (tbl, col, ph), (eid, *sorted(locked)))
        self.add_rows(kind, eid, keep, replace=False, source="grid")

    def delete_rows(self, kind, eid):
        self.need_edit()
        tbl, _ = TABLES[kind]
        self._guard(kind, eid, (), self._existing_periods(kind, eid))
        self.c.execute("DELETE FROM %s WHERE entity_id=?" % tbl, (eid,))
        self.c.commit()
        self.audit("rows.delete", "%s/%s" % (eid, kind))

    # ---------------------------------------------------------------- checklist
    def checklist(self, eid):
        return {(r["area"], r["item"]): dict(r) for r in self.c.execute("SELECT * FROM checklist WHERE entity_id=?", (eid,))}

    def set_check(self, eid, area, item, status, note=""):
        self.need_edit()
        self.c.execute("INSERT OR REPLACE INTO checklist VALUES(?,?,?,?,?,?,?)", (eid, area, item, status, note, self.user["username"], now()))
        self.c.commit()
        self.audit("check", "%s/%s/%s" % (eid, area, item), status)

    # ---------------------------------------------------------------- settings
    def setting(self, key, default=""):
        r = self.c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def set_setting(self, key, value):
        self.c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, value))
        self.c.commit()

    # ---------------------------------------------------------------- compute
    def effective_entity(self, e, R, rows=None):
        rows = rows or self.rows_by_entity()
        return engine.aggregate(e, rows["vat"].get(e["id"], []), R)

    def rows_by_entity(self):
        out = {}
        for k in TABLES:
            d = {}
            for r in self.rows(k):
                d.setdefault(r["entity_id"], []).append(r)
            out[k] = d
        return out

    def compute(self, today=None):
        R = engine.rules_to_dict(self.rules())
        rows = self.rows_by_entity()
        ents = [self.effective_entity(e, R, rows) for e in self.entities()]
        res = engine.run_all(ents, R, today)
        res["entities"] = ents
        return res

    def compute_period(self, eid, vat_period_end=None, fy_end=None, today=None):
        """Compute one client for a chosen VAT period and/or financial year (for viewing past returns). Returns (result, rows)."""
        R = engine.rules_to_dict(self.rules())
        rows = self.rows_by_entity()
        e = dict(self.entity(eid))
        if vat_period_end:
            e["vat_period_end"] = str(vat_period_end)[:10]
        if fy_end:
            e["fy_end"] = str(fy_end)[:10]
        e2 = self.effective_entity(e, R, rows)
        res = engine.run_all([e2], R, today)
        res["entities"] = [e2]
        return res, rows

    # ---------------------------------------------------------------- supporting documents
    def docs_dir(self, eid=None):
        d = os.path.join(os.path.dirname(os.path.abspath(self.path)), "documents")
        if eid:
            d = os.path.join(d, "".join(ch for ch in eid if ch.isalnum() or ch in "-_"))
        os.makedirs(d, exist_ok=True)
        return d

    def doc_add(self, eid, area, item, src_path, note=""):
        """Copy a file into the client's document folder and record it against a required item."""
        self.need_edit()
        if self.visible_clients() is not None and eid not in self.visible_clients():
            raise PermissionDenied("This client is not assigned to you.")
        if not os.path.isfile(src_path):
            raise ValueError("File not found: %s" % src_path)
        base = os.path.basename(src_path)
        stored = "%s_%s" % (dt.datetime.now().strftime("%Y%m%d%H%M%S%f"), "".join(ch if ch.isalnum() or ch in "._- " else "_" for ch in base))
        shutil.copy2(src_path, os.path.join(self.docs_dir(eid), stored))
        cur = self.c.execute("INSERT INTO docs(entity_id,area,item,filename,stored,note,added_by,added_at) VALUES(?,?,?,?,?,?,?,?)",
                             (eid, area, item, base, stored, note, self.user["username"], now()))
        self.c.commit()
        self.audit("doc.add", "%s/%s" % (eid, item), base)
        return cur.lastrowid

    def doc_list(self, eid):
        return [dict(r) for r in self.c.execute("SELECT * FROM docs WHERE entity_id=? ORDER BY area, item, id", (eid,))]

    def doc_path(self, row):
        return os.path.join(self.docs_dir(row["entity_id"]), row["stored"])

    def doc_remove(self, doc_id):
        self.need_edit()
        r = self.c.execute("SELECT * FROM docs WHERE id=?", (doc_id,)).fetchone()
        if not r:
            return
        self.c.execute("DELETE FROM docs WHERE id=?", (doc_id,))
        self.c.commit()
        try:
            os.remove(self.doc_path(r))
        except OSError:
            pass
        self.audit("doc.remove", "%s/%s" % (r["entity_id"], r["item"]), r["filename"])

    # ---------------------------------------------------------------- VAT groups
    def vat_groups(self, kind=None):
        """VAT groups. Each has members. Older corporate tax groups kept in a database file are ignored."""
        out = []
        for g in self.c.execute("SELECT * FROM vat_groups ORDER BY group_id"):
            k = g["kind"] or "VAT"
            if k != "VAT":
                continue
            ms = list(self.c.execute("SELECT entity_id, own_pct FROM vat_group_members WHERE group_id=? ORDER BY entity_id", (g["group_id"],)))
            out.append(dict(group_id=g["group_id"], name=g["name"], trn=g["trn"], rep_member=g["rep_member"], kind=k,
                            members=[r["entity_id"] for r in ms], ownership={r["entity_id"]: r["own_pct"] for r in ms if r["own_pct"] is not None}))
        return out

    def vat_group_save(self, group_id, name, trn, rep_member, members, kind="VAT", ownership=None):
        self.need("Admin", "Preparer", "Reviewer")
        kind = "VAT"
        if not group_id.strip() or not name.strip():
            raise ValueError("Group ID and name are required.")
        if rep_member and rep_member not in members:
            raise ValueError("The representative member must be one of the members.")
        if len(set(members)) < 2:
            raise ValueError("A group needs at least two members.")
        old = self.c.execute("SELECT kind FROM vat_groups WHERE group_id=?", (group_id,)).fetchone()
        if old and (old["kind"] or "VAT") != kind:
            raise ValueError("Group %s already exists as a %s group." % (group_id, old["kind"] or "VAT"))
        for g in self.vat_groups(kind):
            if g["group_id"] != group_id:
                clash = set(members) & set(g["members"])
                if clash:
                    raise ValueError("%s already belongs to %s group %s: a business can be in only one %s group." % (", ".join(sorted(clash)), kind, g["group_id"], kind))
        self.c.execute("INSERT OR REPLACE INTO vat_groups(group_id,name,trn,rep_member,kind) VALUES(?,?,?,?,?)", (group_id, name, trn, rep_member, kind))
        self.c.execute("DELETE FROM vat_group_members WHERE group_id=?", (group_id,))
        own = ownership or {}
        self.c.executemany("INSERT INTO vat_group_members(group_id,entity_id,own_pct) VALUES(?,?,?)", [(group_id, m, own.get(m)) for m in members])
        self.c.commit()
        self.audit("%sgroup.save" % kind.lower(), group_id, "%d members" % len(members))

    def vat_group_delete(self, group_id):
        self.need("Admin")
        self.c.execute("DELETE FROM vat_group_members WHERE group_id=?", (group_id,))
        self.c.execute("DELETE FROM group_elims WHERE group_id=?", (group_id,))
        self.c.execute("DELETE FROM vat_groups WHERE group_id=?", (group_id,))
        self.c.commit()
        self.audit("taxgroup.delete", group_id)

    # ---------------------------------------------------------------- sample data
    def load_sample(self):
        self.need("Admin")
        s = load_json("sample.json")
        for e in s["entities"]:
            self.c.execute("INSERT OR REPLACE INTO entities VALUES(?,?,?,?)", (e["id"], json.dumps(e), self.user["username"], now()))
        for kind, key in (("vat", "vat_rows"),):
            tbl, cols = TABLES[kind]
            by = {}
            for r in s.get(key, []):
                by.setdefault(r["entity_id"], []).append(r)
            for eid, rs in by.items():
                self.c.execute("DELETE FROM %s WHERE entity_id=?" % tbl, (eid,))
                self.c.executemany("INSERT INTO %s(entity_id,%s) VALUES(?,%s)" % (tbl, ",".join(cols), ",".join("?" * len(cols))),
                                   [(eid, *[r.get(c) for c in cols]) for r in rs])
        self.c.commit()
        self.audit("sample.load", "sample", "%d sample clients" % len(s["entities"]))

    # ---------------------------------------------------------------- backup and restore
    def backup_dir(self):
        d = self.setting("backup_dir", "") or os.path.join(os.path.dirname(os.path.abspath(self.path)), "backups")
        os.makedirs(d, exist_ok=True)
        return d

    def backup_to(self, path):
        self.c.execute("PRAGMA wal_checkpoint(FULL)")
        dst = sqlite3.connect(path)
        try:
            with dst:
                self.c.backup(dst)
        finally:
            dst.close()
        return path

    def auto_backup(self, today=None):
        """One backup a day in the backup folder, keeping the newest N (setting backup_keep, default 14). Returns the new file, or None if today's exists."""
        today = (today or dt.date.today()).isoformat()
        d = self.backup_dir()
        p = os.path.join(d, "uae_tax_auto_%s.db" % today)
        if os.path.exists(p):
            return None
        self.backup_to(p)
        try:
            src = self.docs_dir()
            if any(os.scandir(src)):
                shutil.copytree(src, os.path.join(d, "documents_mirror"), dirs_exist_ok=True)
        except OSError:
            pass
        keep = int(self.setting("backup_keep", "14") or 14)
        autos = sorted(f for f in os.listdir(d) if f.startswith("uae_tax_auto_") and f.endswith(".db"))
        for f in autos[:-keep]:
            try:
                os.remove(os.path.join(d, f))
            except OSError:
                pass
        self.audit("backup.auto", "database", p)
        return p

    def list_backups(self):
        d = self.backup_dir()
        out = []
        for f in sorted(os.listdir(d), reverse=True):
            if f.endswith(".db"):
                fp = os.path.join(d, f)
                out.append(dict(name=f, path=fp, size=os.path.getsize(fp), modified=dt.datetime.fromtimestamp(os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M")))
        return out

    def restore_from(self, path):
        """Replaces everything in this database with the contents of a backup file. A safety copy of the current data is taken first."""
        self.need("Admin")
        try:
            src = sqlite3.connect("file:%s?mode=ro" % path.replace("\\", "/"), uri=True)
            tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        except sqlite3.Error as e:
            raise ValueError("That file is not a readable database (%s)." % e)
        if not {"users", "entities", "rules"} <= tables:
            src.close()
            raise ValueError("That file is not a backup of this program (tables are missing).")
        safety = self.backup_to(os.path.join(self.backup_dir(), "before_restore_%s.db" % dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
        try:
            src.backup(self.c)
        finally:
            src.close()
        self.c.executescript(SCHEMA)
        self.c.commit()
        self.audit("backup.restore", "database", "from %s; previous data saved as %s" % (path, safety), actor=self.user["username"] if self.user else "")
        return safety

    # ---------------------------------------------------------------- start the next period
    def roll_forward(self, eid, c=None, ct=False, vat=True, force=False):
        """Carry a client into the next VAT period. Filing and payment flags and one-off adjustments are cleared."""
        self.need_edit()
        e = self.entity(eid)
        if not e:
            raise ValueError("Unknown client")
        vpe, fy = self.current_periods(eid)
        changes = []
        if vat:
            if not vpe:
                raise ValueError("The client has no VAT period end to advance.")
            if not force and not self.is_locked(eid, "VAT", vpe):
                raise ValueError("The VAT period ending %s is not approved. Approve it first, or roll forward anyway." % vpe)
            step = 1 if e.get("vat_frequency") == "Monthly" else 3
            npe = engine.Y(engine.eom(engine.D(vpe), step))
            e.update(vat_period_end=npe, vat_filed="No", vat_paid="No", vat_open_exceptions=0, prior_period_error_vat=0)
            changes.append("VAT period end %s -> %s" % (vpe, npe))
        if not changes:
            raise ValueError("Nothing selected.")
        try:
            self.backup_to(os.path.join(self.backup_dir(), "before_rollforward_%s_%s.db" % (eid, dt.datetime.now().strftime("%Y%m%d_%H%M%S"))))
        except OSError:
            pass
        self.save_entity(e, _bypass_lock=True)
        self.audit("rollforward", eid, "; ".join(changes) + ("; approval overridden" if force else ""))
        return changes

    def close(self):
        self.c.close()
