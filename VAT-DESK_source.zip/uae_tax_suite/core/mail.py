"""Email drafts opened in the user's own mail program (no passwords stored, nothing sent by the app)."""
from __future__ import annotations

from urllib.parse import quote

from . import deadlines as DL

MAX_URL = 1900   # many mail programs truncate longer mailto links


def contact(db, e):
    """The client's email: the record's email field, then a per-client override saved from the Reminders tab."""
    return (db.setting("contact:" + e["id"], "") or e.get("email") or "").strip()


def draft(to, subject, body):
    """A mailto link. Over-long bodies are shortened and the caller is told so."""
    link = "mailto:%s?subject=%s&body=%s" % (quote(to or ""), quote(subject), quote(body))
    cut = False
    while len(link) > MAX_URL and len(body) > 200:
        body = body[: int(len(body) * 0.8)].rsplit("\n", 1)[0] + "\n[...message shortened: use Copy client reminder for the full text]"
        link = "mailto:%s?subject=%s&body=%s" % (quote(to or ""), quote(subject), quote(body)); cut = True
    return link, cut


def reminder_draft(db, res, rows, eid, firm=""):
    e = next(x for x in res["entities"] if x["id"] == eid)
    mine = [r for r in rows if r["id"] == eid]
    body = DL.client_email(e["name"], [dict(r, entity=e["name"]) for r in mine], firm)
    sub = "UAE tax deadlines: %s" % e["name"]
    return contact(db, e), sub, body
