"""Reconciliations: ledger balances against what the returns report, in one list per client."""
from __future__ import annotations


def _n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def _row(area, check, ledger, ret, diff, tol=1.0):
    if diff is None:
        status = "Not provided"
    else:
        status = "Reconciled" if abs(diff) <= tol else "Difference"
    return dict(area=area, check=check, ledger=ledger, ret=ret, diff=diff, status=status)


def reconcile(b):
    """b is dataio.entity_bundle(). Returns a list of dicts: area, check, ledger, ret, diff, status."""
    e, v = b["e"], b["v"]
    out = []
    if v.get("vat_status") != "Not registered" and v.get("recon_status") != "Not registered":
        def mk(name, gl, diff):
            blank = gl in (None, "")
            ledger = None if blank else _n(gl)
            ret = None if (blank or diff is None) else ledger - diff
            out.append(_row("VAT", name, ledger, ret, None if blank else diff))
        mk("Sales revenue in the ledger vs supplies on the VAT return", e.get("gl_sales_revenue"), v.get("recon_sales_diff"))
        mk("Output VAT account vs output tax on the VAT return", e.get("gl_output_vat"), v.get("recon_output_diff"))
        mk("Input VAT account vs input tax on the VAT return", e.get("gl_input_vat"), v.get("recon_input_diff"))
    return out


def open_differences(rows):
    """Number of checks that still show a difference."""
    return sum(1 for r in rows if r["status"] == "Difference")
