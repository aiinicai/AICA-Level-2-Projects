"""Filing pack: a data-entry sheet in the order of the EmaraTax screens, a pre-filing readiness check, and a ZIP of everything for the file."""
from __future__ import annotations

import datetime as dt
import os
import shutil
import tempfile
import zipfile

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import validate as V

NAVY = "1F3864"
OK, NO, WARN = "Ready", "Not ready", "Check"


def readiness(db, b):
    """Checks to pass before filing. Returns a list of (check, result, detail)."""
    eid = b["e"]["id"]
    out = []
    so = {x["kind"]: x for x in (b.get("signoff") or [])}
    for k in ("VAT",):
        s = so.get(k)
        if s is None:
            continue
        out.append(("%s return approved" % k, OK if s["status"] == "Approved" else NO, "Status: %s" % s["status"]))
    R = b["R"]
    errs = warns = 0
    e_, w_ = V.summary(V.validate("vat", db.rows("vat", eid), R, b["e"]))
    errs += e_; warns += w_
    out.append(("Uploaded data passes validation", OK if errs == 0 else NO, "%d error(s), %d warning(s)" % (errs, warns)))
    rec = b.get("recon") or []
    diffs = [x for x in rec if x["status"] == "Difference"]
    out.append(("Ledger reconciles to the returns", OK if not diffs else NO, "%d difference(s) of %d checks" % (len(diffs), len(rec))))
    out.append(("VAT 201 workings agree to the VAT calculation", OK if not b["vat201"].get("diff") else NO, "Difference %s" % "{:,.2f}".format(b["vat201"].get("diff") or 0)))
    hi = [i for i in b["issues"] if i["severity"] == "High"]
    out.append(("No high-severity open items", OK if not hi else NO, "%d high-severity item(s)" % len(hi)))
    return out


def overall(checks):
    return NO if any(c[1] == NO for c in checks) else (WARN if any(c[1] == WARN for c in checks) else OK)


def _hdr(ws, r, vals, widths=None):
    for j, v in enumerate(vals, 1):
        c = ws.cell(r, j, v); c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=NAVY); c.alignment = Alignment(wrap_text=True, vertical="center")
    if widths:
        for j, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(j)].width = w


def _num(x):
    return x if isinstance(x, (int, float)) else None


def entry_sheet(path, b, checks, firm=""):
    """An Excel file: readiness, VAT 201 in screen order, schedules to attach."""
    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = "Readiness"
    ws["A1"] = "Filing data-entry sheet: %s (%s)" % (b["e"]["name"], b["e"]["id"]); ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    ws["A2"] = "%s | prepared %s | Key each figure into EmaraTax, then tick it off. Not a substitute for the filed return." % (firm or "VAT-DESK", dt.date.today().isoformat())
    ov = overall(checks)
    ws["A3"] = "Overall: " + ("READY TO FILE" if ov == OK else "NOT READY: resolve the red items first" if ov == NO else "Ready subject to the amber items")
    ws["A3"].font = Font(bold=True, color={"Ready": "2E7D32", "Not ready": "C62828", "Check": "B26A00"}[ov])
    _hdr(ws, 5, ["Check", "Result", "Detail"], (52, 12, 90))
    for i, (a, r_, d) in enumerate(checks, 6):
        ws.cell(i, 1, a); c = ws.cell(i, 2, r_); ws.cell(i, 3, d)
        c.fill = PatternFill("solid", fgColor={"Ready": "C6E0B4", "Not ready": "F8CBAD", "Check": "FFE699"}[r_])
    # VAT
    fv = b["vat_fta"]
    ws = wb.create_sheet("VAT 201 entry")
    ws["A1"] = fv["title"]; ws["A1"].font = Font(bold=True, size=13, color=NAVY)
    r = 3
    for k, v in fv["header"]:
        ws.cell(r, 1, k).font = Font(bold=True); ws.cell(r, 2, v); r += 1
    r += 1
    _hdr(ws, r, ["Box", "Description", "Amount (AED)", "VAT amount (AED)", "Adjustment (AED)", "Entered", "Note"], (7, 62, 18, 18, 18, 10, 50)); r += 1
    sec = None
    for l in fv["lines"]:
        if l["section"] != sec:
            sec = l["section"]; c = ws.cell(r, 1, sec); c.font = Font(bold=True, color=NAVY); r += 1
        ws.cell(r, 1, l["box"]); ws.cell(r, 2, l["desc"])
        for j, k in enumerate(("amount", "vat", "adj"), 3):
            v = _num(l[k])
            c = ws.cell(r, j, v)
            if v is not None:
                c.number_format = '#,##0.00;(#,##0.00)'
        ws.cell(r, 6, "[ ]")
        if l["bold"]:
            for j in range(1, 8):
                ws.cell(r, j).font = Font(bold=True)
        r += 1
    # schedules to attach
    ws = wb.create_sheet("Schedules to attach")
    _hdr(ws, 1, ["Return", "No.", "Schedule", "Reference", "Attached"], (10, 6, 70, 30, 10))
    r = 2
    for tag, sched, flags in (("VAT", b["vat_sched"], b["vat201"].get("sched_flags") or ""),):
        for i, s in enumerate(sched):
            if i < len(flags) and flags[i] == "1":
                ws.cell(r, 1, tag); ws.cell(r, 2, s["no"]); ws.cell(r, 3, s["name"]); ws.cell(r, 4, s.get("ref", "")); ws.cell(r, 5, "[ ]"); r += 1
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)


def build_zip(path, db, b, firm=""):
    """Write the whole filing pack to `path` (a .zip). Returns the readiness checks."""
    from . import clientsummary as CS
    from . import dataio
    eid = b["e"]["id"]
    checks = readiness(db, b)
    tmp = tempfile.mkdtemp()
    try:
        files = {}
        files["01_Readiness_and_data_entry.xlsx"] = os.path.join(tmp, "entry.xlsx"); entry_sheet(files["01_Readiness_and_data_entry.xlsx"], b, checks, firm)
        files["02_Compliance_pack.pdf"] = os.path.join(tmp, "pack.pdf"); dataio.export_entity_pdf(files["02_Compliance_pack.pdf"], b, firm)
        files["03_Compliance_pack.xlsx"] = os.path.join(tmp, "pack.xlsx"); dataio.export_entity_xlsx(files["03_Compliance_pack.xlsx"], b, firm)
        res = db.compute()
        files["04_Client_summary.pdf"] = os.path.join(tmp, "sum.pdf"); CS.pdf(files["04_Client_summary.pdf"], CS.build(res, eid, firm))
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for name, p in files.items():
                z.write(p, "%s/%s" % (eid, name))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return checks


def _val_counts(db, b):
    return V.summary(V.validate("vat", db.rows("vat", b["e"]["id"]), b["R"], b["e"]))
