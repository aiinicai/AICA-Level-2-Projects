"""A short, plain-language summary a client can read: where they stand, what is due, what we need from them.
It leaves out internal matters (risk score, reviewer names, working-paper detail)."""
from __future__ import annotations

from . import deadlines as DL
from .engine import Y, jr, n
try:
    from core.tabexport import patch_pdf_dates; patch_pdf_dates()   # PDFs show dates as DD-MM-YYYY
except Exception:
    pass


def aed(x):
    x = n(x)
    return "AED {:,.2f}".format(x) if x >= 0 else "(AED {:,.2f})".format(-x)


def build(res, eid, firm=""):
    i = next(k for k, e in enumerate(res["entities"]) if e["id"] == eid)
    e, v = res["entities"][i], res["vat"][i]
    dates = [d for d in DL.enrich(res) if d["id"] == eid]
    pos = []
    if v.get("registered") == "Yes":
        net = n(v.get("net_vat"))
        pos.append(("VAT", "Return for the period ending %s" % v.get("period_end"),
                    ("VAT payable %s" % aed(net)) if net > 0 else ("VAT refundable %s" % aed(-net)) if net < 0 else "No VAT payable", "Due %s" % v.get("due")))
    else:
        pos.append(("VAT", "Not registered", v.get("vat_status") or "", ""))
    need = [(i_["area"], i_["action"]) for i_ in res["issues"] if i_["id"] == eid and i_["severity"] in ("High", "Medium")]
    return dict(name=e["name"], name_ar=e.get("name_ar") or "", id=eid, trn=e.get("vat_trn") or e.get("trn") or "", as_of=Y(res["today"]), firm=firm, position=pos,
                deadlines=[(d["obligation"], d["period_end"], d["due"], d["level"], d["penalty_now"]) for d in dates],
                needs=need, penalty=sum(d["penalty_now"] for d in dates))


def pdf(path, s, arabic=True):
    """Client summary PDF. With arabic=True (and the shaping libraries present) headings and labels are shown in English and Arabic."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from . import arabic as AB

    bi = bool(arabic and AB.available())
    F, FB = AB.register_fonts() if bi else ("Helvetica", "Helvetica-Bold")
    navy = colors.HexColor("#1F3864")
    ss = getSampleStyleSheet()
    H1 = ParagraphStyle("h1", parent=ss["Title"], textColor=navy, fontSize=18, alignment=0, spaceAfter=2, fontName=FB)
    H2 = ParagraphStyle("h2", parent=ss["Heading2"], textColor=navy, fontSize=12, spaceBefore=10, spaceAfter=4, fontName=FB)
    H2R = ParagraphStyle("h2r", parent=H2, alignment=2)
    H1R = ParagraphStyle("h1r", parent=H1, alignment=2)
    P = ParagraphStyle("p", parent=ss["BodyText"], fontSize=9, leading=12, fontName=F)
    PR = ParagraphStyle("pr", parent=P, alignment=2)
    PH = ParagraphStyle("ph", parent=P, fontName=FB, textColor=colors.white)

    def lab(en):
        return en + ("<br/>" + AB.ar(en) if bi and AB.AR.get(en) else "")

    def head(en, big=False):
        if not bi or not AB.AR.get(en):
            return Paragraph(en, H1 if big else H2)
        t = Table([[Paragraph(en, H1 if big else H2), Paragraph(AB.ar(en), H1R if big else H2R)]], colWidths=[90 * mm, 90 * mm])
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        return t

    def tbl(heads, rows, widths):
        t = Table([[Paragraph(lab(h), PH) for h in heads]] + [[Paragraph(str(x), P) for x in r] for r in rows], colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), navy), ("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t

    def foot(cv, doc):
        cv.saveState(); cv.setFont(F, 7); cv.setFillColor(colors.grey)
        cv.drawString(15 * mm, 8 * mm, "%s | %s | %s %s. %s" % (s["firm"] or "VAT-DESK", s["name"], "as at", s["as_of"], "Estimates only; the Federal Tax Authority assesses tax and penalties."))
        if bi:
            cv.drawRightString(195 * mm, 4.5 * mm, AB.ar("Estimates only; the Federal Tax Authority assesses tax and penalties."))
        cv.restoreState()

    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=18 * mm, title=s["name"] + " tax summary")
    sub = "%s%s &nbsp;|&nbsp; %s %s" % (s["name"], (" &nbsp;|&nbsp; TRN " + s["trn"]) if s["trn"] else "", "as at", s["as_of"])
    S = [head("Your UAE tax summary", True), Paragraph(sub, P)]
    if bi and s.get("name_ar"):
        S.append(Paragraph(AB.shape(s["name_ar"]), PR))
    S += [head("Where you stand")]
    S.append(tbl(["Area", "Period", "Position", "Due"], [list(p) for p in s["position"]], [28 * mm, 52 * mm, 70 * mm, 30 * mm]))
    S.append(head("Deadlines"))
    if s["deadlines"]:
        S.append(tbl(["Obligation", "Period end", "Due", "Status", "Penalty so far"], [[a, b, c, d, aed(e)] for a, b, c, d, e in s["deadlines"]], [60 * mm, 28 * mm, 28 * mm, 28 * mm, 36 * mm]))
        if s["penalty"]:
            S.append(Paragraph("Estimated penalties already accrued: <b>%s</b>. They grow the longer a filing or payment is outstanding." % aed(s["penalty"]), P))
    else:
        S.append(Paragraph(lab("Nothing is outstanding."), P))
    S.append(head("What we need from you"))
    S.append(tbl(["Area", "What to do"], [list(x) for x in s["needs"]], [35 * mm, 145 * mm]) if s["needs"] else Paragraph(lab("Nothing at the moment. Thank you."), P))
    doc.build(S, onFirstPage=foot, onLaterPages=foot)
