"""Deadline reminders with estimated penalty exposure, plus calendar (.ics), CSV and client-email outputs."""
from __future__ import annotations

import csv
import datetime as dt
import io

from . import returns as RT
from .engine import D, Y, n

OBL_CODE = {"VAT return and payment": "VAT"}
ACTION = {"VAT": "File the VAT 201 and pay any VAT due"}


def _code(row):
    k = str(row.get("key", ""))
    return k.rsplit("-", 1)[-1] if "-" in k else ""


def penalty_if_filed_on(res, row, when):
    """Estimated late filing and late payment penalty if the obligation is dealt with on date `when` (VAT only)."""
    code, R = _code(row), res["R"]
    if code == "VAT":
        v = next((x for x in res["vat"] if x["id"] == row["id"]), None)
        if not v:
            return 0
        return RT.vat_penalty(R, row["due"], "", False, row["due"], max(0, n(v.get("net_vat"))), "", "", "", False, False, when)["total"]
    return 0


def enrich(res):
    """Calendar rows with the penalty accrued today and the penalty if the item slips another 30 days."""
    today = res["today"]
    out = []
    for r in res["calendar"]:
        code = _code(r)
        d = dict(r)
        d["code"] = code
        d["action"] = ACTION.get(code, "Action needed")
        d["penalty_now"] = penalty_if_filed_on(res, r, today) if (r.get("days_left") or 0) < 0 else 0
        d["penalty_in_30"] = penalty_if_filed_on(res, r, today + dt.timedelta(days=30)) if (r.get("days_left") or 0) < 30 else 0
        d["level"] = "Overdue" if (r.get("days_left") or 0) < 0 else "Urgent" if (r.get("days_left") or 0) <= 7 else "Due soon" if (r.get("days_left") or 0) <= 14 else "Upcoming"
        out.append(d)
    return out


def reminders(res, window_days=30):
    """Items overdue or falling due within the window, worst first."""
    rows = [r for r in enrich(res) if r.get("days_left") is not None and r["days_left"] <= window_days]
    return sorted(rows, key=lambda r: r["days_left"])


def summary(res, window=14):
    rs = reminders(res, window)
    od = [r for r in rs if r["days_left"] < 0]
    return dict(overdue=len(od), due_soon=len(rs) - len(od), exposure=int(sum(r["penalty_now"] for r in od)))


def status_line(res, window=14):
    s = summary(res, window)
    if not s["overdue"] and not s["due_soon"]:
        return "No deadlines overdue or due in the next %d days." % window
    return "%d overdue and %d due in the next %d days. Penalties already accrued: AED %s." % (s["overdue"], s["due_soon"], window, "{:,.2f}".format(s["exposure"]))


def to_csv(rows) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Client ID", "Client", "Obligation", "Period end", "Due date", "Days left", "Level", "Action", "Penalty accrued (AED)", "Penalty if 30 days later (AED)"])
    for r in rows:
        w.writerow([r["id"], r["entity"], r["obligation"], r["period_end"], r["due"], r["days_left"], r["level"], r["action"], r["penalty_now"], r["penalty_in_30"]])
    return buf.getvalue()


def _esc(s):
    return str(s).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def to_ics(rows, today=None) -> str:
    """An iCalendar file: an all-day event on each due date with alarms 7 days and 1 day before."""
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//VAT-DESK//EN", "CALSCALE:GREGORIAN"]
    for r in rows:
        d = D(r["due"])
        if not d:
            continue
        L += ["BEGIN:VEVENT", "UID:%s-%s@uae-tax-suite" % (r.get("key", r["id"]), d.strftime("%Y%m%d")), "DTSTAMP:" + stamp,
              "DTSTART;VALUE=DATE:" + d.strftime("%Y%m%d"), "DTEND;VALUE=DATE:" + (d + dt.timedelta(days=1)).strftime("%Y%m%d"),
              "SUMMARY:" + _esc("%s: %s (%s)" % (r["obligation"], r["entity"], r["id"])),
              "DESCRIPTION:" + _esc("%s. Period end %s." % (r["action"], r["period_end"]))]
        for days in (7, 1):
            L += ["BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + _esc("%s due in %d day(s)" % (r["obligation"], days)), "TRIGGER:-P%dD" % days, "END:VALARM"]
        L.append("END:VEVENT")
    L.append("END:VCALENDAR")
    return "\r\n".join(L) + "\r\n"


def client_email(name, rows, firm="") -> str:
    """A plain reminder a preparer can paste into an email to the client."""
    mine = [r for r in rows if r["entity"] == name]
    if not mine:
        return "Dear %s,\n\nNo UAE tax deadlines are overdue or approaching.\n\nRegards,\n%s" % (name, firm)
    L = ["Dear %s," % name, "", "This is a reminder of the following UAE tax deadlines:", ""]
    for r in mine:
        when = ("%d day(s) overdue" % -r["days_left"]) if r["days_left"] < 0 else ("due in %d day(s)" % r["days_left"])
        s = "- %s for the period ending %s: due %s (%s)." % (r["obligation"], r["period_end"], r["due"], when)
        if r["penalty_now"]:
            s += " Estimated penalties so far: AED {:,.2f}.".format(r["penalty_now"])
        L.append(s)
    L += ["", "Please send the information we need so that we can file on time. Penalties are estimates; the Federal Tax Authority assesses them.", "", "Regards,", firm]
    return "\n".join(L)
