"""VAT group: one return for the group, with supplies between members left out."""
from __future__ import annotations

import copy
import re

from . import engine as E
from . import ftaformat as FF
from . import returns as RT

NUM = ("amount", "vat", "adj")
_STOP = {"llc", "ltd", "limited", "fze", "fzc", "fz", "fzco", "pjsc", "the", "co", "company", "inc", "est", "establishment", "branch", "l", "l.l.c", "sole", "proprietorship"}


class GroupError(ValueError):
    """The group cannot be consolidated until something is fixed."""


def norm_name(s) -> str:
    """A name reduced for matching: lower case, punctuation and legal-form words removed."""
    words = re.findall(r"[a-z0-9؀-ۿ]+", str(s or "").lower())
    return " ".join(w for w in words if w not in _STOP)


def member_ids(db, members):
    """For each member: its normalised names and its TRNs, used to recognise the member as a counterparty."""
    out = {}
    for m in members:
        e = db.entity(m) or {}
        names = {x for x in (norm_name(e.get("name")), norm_name(e.get("name_ar"))) if x}
        trns = {str(e.get(k) or "").strip() for k in ("vat_trn",)} - {""}
        out[m] = dict(names=names, trns=trns, name=e.get("name") or m)
    return out


def find_member(ids, party, trn, exclude=None):
    """(member id, how matched) for a counterparty, or (None, None). TRN is tried first, then the name."""
    t = str(trn or "").strip()
    if t:
        for m, i in ids.items():
            if m != exclude and t in i["trns"]:
                return m, "TRN"
    n = norm_name(party)
    if n:
        for m, i in ids.items():
            if m != exclude and n in i["names"]:
                return m, "Name"
    return None, None


def check_periods(db, members):
    ps = {}
    for m in members:
        e = db.entity(m) or {}
        ps[m] = str(e.get("vat_period_end") or "")[:10]
    if len(set(ps.values())) > 1:
        raise GroupError("The members have different VAT period ends (%s). A group files for one period: align them first." % ", ".join("%s %s" % (k, v or "none") for k, v in ps.items()))


def consolidate(db, group, default_emirate=None):
    """Build the group's VAT 201 from the members' own data. Rows whose counterparty is another member are left out."""
    members = group["members"]
    if len(members) < 2:
        raise GroupError("Select at least two members.")
    check_periods(db, members)
    R = E.rules_to_dict(db.rules())
    allrows = db.rows_by_entity()
    ids = member_ids(db, members)
    rows = copy.copy(allrows)
    rows["vat"] = dict(allrows["vat"])
    elims, drop_n, drop_net = [], 0, 0.0
    for m in members:
        keep = []
        for r in allrows["vat"].get(m, []):
            other, how = find_member(ids, r.get("party"), r.get("trn"), exclude=m)
            if other:
                drop_n += 1; drop_net += E.n(r.get("net"))
                elims.append(dict(member=m, counterparty=other, how=how, doc_no=r.get("doc_no"), doc_date=r.get("doc_date"), party=r.get("party"),
                                  doc_type=r.get("doc_type"), net=round(E.n(r.get("net"))), vat=round(E.n(r.get("vat")))))
            else:
                keep.append(r)
        rows["vat"][m] = keep
    ents = [db.effective_entity(db.entity(m), R, rows) for m in members]
    for e in ents:     # the group is registered; members are not registered separately
        e["vat_registered"] = "Yes"
    today = E.as_of(R)
    vcalc = E.vat_calc(ents, R, today)
    sheets = [RT.vat201(e, v, R, rows["vat"].get(e["id"], []), None, default_emirate) for e, v in zip(ents, vcalc)]
    rep = group.get("rep_member") or members[0]
    ri = members.index(rep) if rep in members else 0
    base = copy.deepcopy(sheets[ri])
    for i, l in enumerate(base["lines"]):
        if l["kind"] == "head":
            continue
        for k in NUM:
            vals = [s["lines"][i][k] for s in sheets if s["lines"][i][k] is not None]
            l[k] = sum(vals) if vals else None
    box12 = next((l["vat"] for l in base["lines"] if l["box"] == "12"), 0)
    box13 = next((l["vat"] for l in base["lines"] if l["box"] == "13"), 0)
    base.update(box12=box12, box13=box13, net=box12 - box13)
    base["header"] = [("VAT group", group["name"]), ("Group TRN", group.get("trn") or ""), ("Representative member", rep), ("Members", ", ".join(members))] + \
                     [h for h in base["header"] if h[0] in ("Tax period end", "Return and payment due")]
    base["members"] = [dict(id=e["id"], name=e["name"], net_vat=round(s["net"]), vat_status=v["vat_status"]) for e, s, v in zip(ents, sheets, vcalc)]
    base["warnings"] = [("Name-only match (no TRN): %s -> %s, doc %s. Check these are really group members." % (x["member"], x["counterparty"], x["doc_no"]))
                        for x in elims if x["how"] == "Name"][:10]
    base["eliminations"] = elims
    base["intra_excluded_rows"], base["intra_excluded_net"] = drop_n, round(drop_net)
    base["sum_of_members"] = round(sum(s["net"] for s in sheets))
    # the group return in the FTA layout, under the group's name and TRN
    ge = dict(ents[ri], name=group["name"], vat_trn=group.get("trn") or ents[ri].get("vat_trn"), name_ar=(db.entity(rep) or {}).get("name_ar") or "")
    gv = dict(vcalc[ri], net_vat=base["net"])
    base["fta"] = FF.vat201_fta(ge, gv, R, base)
    base["group_entity"] = ge
    return base
