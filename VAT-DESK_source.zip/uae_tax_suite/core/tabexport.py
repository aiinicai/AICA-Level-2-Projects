"""Generic export of what a screen shows: blocks -> one Excel workbook or one PDF.

A block is {"title": str, "header": [str], "rows": [[str]]}  (a table)  or  {"title": str, "text": str}  (notes).
Amounts are written as numbers with the 1,000 separator and two decimals; dates as DD-MM-YYYY.
"""
from __future__ import annotations

import datetime as dt
import re

_AMT = re.compile(r"^\(?-?\d{1,3}(,\d{3})*(\.\d+)?\)?$|^\(?-?\d+\.\d+\)?$")
_DMY = re.compile(r"^(\d{2})-(\d{2})-(\d{4})$")
XL_AMT = '#,##0.00;[Red](#,##0.00)'
XL_DATE = "DD-MM-YYYY"


def cell_value(s):
    """Text from a screen cell -> (python value, number_format or None)."""
    if not isinstance(s, str):
        return s, None
    t = s.strip()
    m = _DMY.match(t)
    if m:
        try:
            return dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1))), XL_DATE
        except ValueError:
            return s, None
    if t and _AMT.match(t) and (("," in t) or ("." in t)) and not re.match(r"^\(?-?0\d", t):
        neg = t.startswith("(") or t.startswith("-")
        try:
            v = float(t.strip("()").replace(",", "").lstrip("-"))
        except ValueError:
            return s, None
        return (-v if neg else v), XL_AMT
    return s, None


def _sheet_name(title, used):
    n = re.sub(r"[\[\]\:\*\?\/\\]", " ", title or "Sheet").strip()[:31] or "Sheet"
    base, k = n, 2
    while n.lower() in used:
        suf = " (%d)" % k
        n = base[:31 - len(suf)] + suf; k += 1
    used.add(n.lower())
    return n


def to_xlsx(path, title, blocks, subtitle=""):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook(); wb.remove(wb.active)
    used = set()
    tabs = [b for b in blocks if "header" in b]
    notes = [b for b in blocks if "text" in b]
    hdr_fill = PatternFill("solid", fgColor="1E3A8A")
    for b in tabs:
        ws = wb.create_sheet(_sheet_name(b.get("title") or title, used))
        ws.append([b.get("title") or title]); ws["A1"].font = Font(bold=True, size=12)
        ws.append([subtitle] if subtitle else [])
        ws.append(list(b["header"]))
        for c in ws[3]:
            c.font = Font(bold=True, color="FFFFFF"); c.fill = hdr_fill; c.alignment = Alignment(wrap_text=True, vertical="center")
        for r in b["rows"]:
            ws.append([cell_value(x)[0] for x in r])
            for c, x in zip(ws[ws.max_row], r):
                f = cell_value(x)[1]
                if f:
                    c.number_format = f
        for j, h in enumerate(b["header"], 1):
            w = max([len(str(h))] + [len(str(r[j - 1])) for r in b["rows"][:300] if j - 1 < len(r)])
            ws.column_dimensions[get_column_letter(j)].width = min(max(10, w + 2), 60)
        ws.freeze_panes = "A4"
    if notes or not tabs:
        ws = wb.create_sheet(_sheet_name("Details", used), 0)
        ws.append([title]); ws["A1"].font = Font(bold=True, size=12)
        if subtitle:
            ws.append([subtitle])
        for b in notes:
            ws.append([])
            ws.append([b.get("title") or ""]); ws.cell(ws.max_row, 1).font = Font(bold=True)
            for line in str(b["text"]).splitlines():
                ws.append([line])
        ws.column_dimensions["A"].width = 120
    wb.save(path)
    return path


def to_pdf(path, title, blocks, subtitle=""):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from xml.sax.saxutils import escape
    try:
        from core.arabic import register_fonts
        reg, bold = register_fonts()
    except Exception:
        reg, bold = "Helvetica", "Helvetica-Bold"
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontName=bold, fontSize=14, alignment=0, textColor=colors.HexColor("#1E3A8A"))
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName=bold, fontSize=10.5, textColor=colors.HexColor("#1E3A8A"))
    cs = ParagraphStyle("c", fontName=reg, fontSize=6.8, leading=8.2)
    cr = ParagraphStyle("cr", parent=cs, alignment=2)
    ch = ParagraphStyle("ch", parent=cs, fontName=bold, textColor=colors.white)
    tx = ParagraphStyle("tx", parent=cs, fontSize=8, leading=10)
    pg = landscape(A4)
    doc = SimpleDocTemplate(path, pagesize=pg, leftMargin=10 * mm, rightMargin=10 * mm, topMargin=12 * mm, bottomMargin=12 * mm, title=title)

    def footer(c, d):
        c.saveState(); c.setFont(reg, 7); c.setFillColor(colors.grey)
        c.drawString(10 * mm, 6 * mm, "VAT-DESK  |  %s  |  %s" % (title, dt.date.today().strftime("%d-%m-%Y")))
        c.drawRightString(pg[0] - 10 * mm, 6 * mm, "Page %d" % d.page); c.restoreState()

    el = [Paragraph(escape(title), h1)]
    if subtitle:
        el.append(Paragraph(escape(subtitle), tx))
    el.append(Spacer(1, 4))
    width = pg[0] - 20 * mm
    for b in blocks:
        if b.get("title"):
            el.append(Paragraph(escape(b["title"]), h2))
        if "text" in b:
            for line in str(b["text"]).splitlines():
                el.append(Paragraph(escape(line) or "&nbsp;", tx))
            el.append(Spacer(1, 6)); continue
        hdr, rows = b["header"], b["rows"]
        n = max(1, len(hdr))
        lens = [max([len(str(hdr[j]))] + [len(str(r[j])) for r in rows[:200] if j < len(r)]) for j in range(n)]
        lens = [min(max(l, 6), 38) for l in lens]
        tot = float(sum(lens)); cw = [width * l / tot for l in lens]
        data = [[Paragraph(escape(str(h)), ch) for h in hdr]]
        for r in rows:
            row = []
            for j in range(n):
                v = r[j] if j < len(r) else ""
                num = isinstance(cell_value(v)[0], float)
                row.append(Paragraph(escape(str(v)), cr if num else cs))
            data.append(row)
        t = Table(data, colWidths=cw, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E3A8A")), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#CBD5E1")),
                               ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F1F5F9")]), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 2.5), ("RIGHTPADDING", (0, 0), (-1, -1), 2.5), ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
        el += [t, Spacer(1, 8)]
    if not blocks:
        el.append(Paragraph("Nothing to show on this screen.", tx))
    doc.build(el, onFirstPage=footer, onLaterPages=footer)
    return path


# ---- DD-MM-YYYY in every pack: ISO dates in text cells / paragraphs are shown day-month-year
ISO_RE = re.compile(r"(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)")


def dmy_text(s):
    return ISO_RE.sub(lambda m: "%s-%s-%s" % (m.group(3), m.group(2), m.group(1)), s) if isinstance(s, str) and "-" in s else s


def dmy_workbook(wb):
    """Text cells holding ISO dates -> DD-MM-YYYY; real date cells get the DD-MM-YYYY number format."""
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str):
                    if not v.startswith("=") and ISO_RE.search(v):
                        c.value = dmy_text(v)
                elif isinstance(v, (dt.date, dt.datetime)):
                    c.number_format = XL_DATE
    return wb


_pdf_patched = False


def patch_pdf_dates():
    """reportlab Paragraphs (and plain table cells) show ISO dates as DD-MM-YYYY. Safe to call repeatedly."""
    global _pdf_patched
    if _pdf_patched:
        return
    _pdf_patched = True
    from reportlab.platypus import paragraph as P
    o = P.Paragraph.__init__

    def init(self, text, *a, **k):
        o(self, dmy_text(text), *a, **k)
    P.Paragraph.__init__ = init


def to_iso(v):
    """Any accepted date text (DD-MM-YYYY, DD/MM/YYYY, ISO) -> ISO; anything else is returned unchanged."""
    from core import engine as E
    if v in (None, ""):
        return ""
    d = E.D(v)
    return d.isoformat() if d else str(v).strip()
