"""VAT-DESK calculation engine: VAT, risk, open items, calendar.

A faithful port of the logic in the UAE Tax Compliance Model workbook. All rates, thresholds and
deadlines come from the rules dictionary (editable by an administrator), nothing is hard coded
except the structure of the returns.
"""
from __future__ import annotations

import calendar
import datetime as dt
import math


DAY = dt.timedelta(days=1)


# ------------------------------------------------------------------ helpers
def n(x) -> float:
    """Number or zero (blank, text and None count as zero)."""
    if x is None or isinstance(x, bool):
        return 0.0
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    return v if math.isfinite(v) else 0.0


def jr(x: float) -> int:
    """Round half up, as the workbook does."""
    return int(math.floor(x + 0.5))


def D(s):
    if isinstance(s, dt.datetime):
        return s.date()
    if isinstance(s, dt.date):
        return s
    if not s:
        return None
    t = str(s).strip()
    try:
        return dt.date.fromisoformat(t[:10])
    except ValueError:
        pass
    for f in ("%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y"):
        try:
            return dt.datetime.strptime(t[:10], f).date()
        except ValueError:
            pass
    return None


def Y(d) -> str:
    return "" if d is None else d.isoformat()


def eom(d: dt.date, k: int) -> dt.date:
    m = d.month - 1 + k + 1
    y, m = d.year + m // 12, m % 12 + 1
    first_next = dt.date(y, m, 1)
    return first_next - DAY


def add_months(d: dt.date, k: int) -> dt.date:
    m = d.month - 1 + k
    y, m = d.year + m // 12, m % 12 + 1
    return dt.date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def blank(v) -> bool:
    return v is None or v == ""


def yes(v) -> bool:
    return v == "Yes"


def rules_to_dict(rules) -> dict:
    """Accepts a list of rule rows ({'key','value'}) or a plain dict."""
    if isinstance(rules, dict):
        return dict(rules)
    return {r["key"]: r["value"] for r in rules}


def as_of(R: dict) -> dt.date:
    d = D(R.get("as_of"))
    return d if d else dt.date.today()


# ------------------------------------------------------------------ aggregation of the upload tabs
def aggregate(inputs: dict, vat_rows, R: dict) -> dict:
    """Totals for one taxable person from the uploaded transaction rows.

    vat_rows: dicts with period_end, doc_date, doc_type, net, vat
    Where an entity has no rows, the figures typed on its master record are kept.
    """
    out = dict(inputs)
    if vat_rows:
        p = D(inputs.get("vat_period_end")) or max(D(r["period_end"]) for r in vat_rows)
        out["vat_period_end"] = Y(p)
        sel = [r for r in vat_rows if D(r["period_end"]) == p]

        def vs(t, f):
            return sum(n(r[f]) for r in sel if r["doc_type"] == t)

        lo = add_months(p, -12) + DAY
        t12 = sum(n(r["net"]) for r in vat_rows
                  if r["doc_type"] in ("Sale - standard rated", "Sale - zero rated")
                  and lo <= D(r["doc_date"]) <= p)
        blocked = vs("Purchase - blocked input VAT", "vat")
        out.update(
            std_supplies=vs("Sale - standard rated", "net"), zero_supplies=vs("Sale - zero rated", "net"),
            exempt_supplies=vs("Sale - exempt", "net"), dz_goods_supplies=vs("Sale - designated zone goods", "net"),
            taxable_supplies_12m=t12,
            input_vat=vs("Purchase - standard rated", "vat") + blocked + vs("Purchase - capital asset", "vat"),
            blocked_input_vat=blocked, reverse_charge_vat=vs("Purchase - reverse charge", "vat"),
            sales_cn_net=vs("Sale - credit note", "net"), sales_cn_vat=vs("Sale - credit note", "vat"),
            purchase_cn_net=vs("Purchase - credit note", "net"), purchase_cn_vat=vs("Purchase - credit note", "vat"),
            import_goods_value=vs("Import of goods", "net"), import_vat=vs("Import of goods", "vat"),
            import_adjust_vat=vs("Import VAT adjustment", "vat"), tourist_refund_vat=vs("Tourist refund", "vat"),
            bad_debt_vat=vs("Bad debt relief", "vat"), deemed_supplies_vat=vs("Deemed supply", "vat"),
            change_in_use_vat=vs("Change in use adjustment", "vat"), capital_assets_vat=vs("Purchase - capital asset", "vat"),
        )
    return out


# ------------------------------------------------------------------ VAT
def vat_calc(entities, R, today):
    rows = []
    for e in entities:
        reg = yes(e.get("vat_registered"))
        filed, paid = yes(e.get("vat_filed")), yes(e.get("vat_paid"))
        std = n(e.get("std_supplies"))
        taxable = std + n(e.get("zero_supplies"))
        exempt = n(e.get("exempt_supplies"))
        ratio = taxable / (taxable + exempt) if exempt > 0 else 1
        rc = n(e.get("reverse_charge_vat")) if reg else 0
        out = std * n(R["vat_rate"]) if reg else 0
        imp = n(e.get("import_vat")) + n(e.get("import_adjust_vat")) if reg else 0
        adj_out = (-n(e.get("sales_cn_vat")) - n(e.get("bad_debt_vat")) + n(e.get("deemed_supplies_vat")) - n(e.get("tourist_refund_vat"))) if reg else 0
        due_total = out + rc + imp + adj_out
        gross_in = max(0, n(e.get("input_vat")) - n(e.get("purchase_cn_vat")) + n(e.get("change_in_use_vat")) + imp) + rc
        recoverable = (max(0, n(e.get("input_vat")) - n(e.get("blocked_input_vat")) - n(e.get("purchase_cn_vat")) + n(e.get("change_in_use_vat")) + imp) + rc) * ratio if reg else 0
        net_vat = due_total - recoverable
        d_sales = jr(n(e.get("gl_sales_revenue")) - (std + n(e.get("zero_supplies")) + exempt + n(e.get("dz_goods_supplies")) - n(e.get("sales_cn_net")))) if not blank(e.get("gl_sales_revenue")) else None
        d_out = jr(n(e.get("gl_output_vat")) - due_total) if not blank(e.get("gl_output_vat")) else None
        d_in = jr(n(e.get("gl_input_vat")) - gross_in) if not blank(e.get("gl_input_vat")) else None
        diffs = [v for v in (d_sales, d_out, d_in) if v is not None]
        if not reg:
            recon = "Not registered"
        elif not diffs:
            recon = "Not provided"
        else:
            recon = "Reconciled" if max(abs(v) for v in diffs) <= 1 else "Difference"
        sched = [
            std > 0, std > 0, n(e.get("sales_cn_net")) > 0 or n(e.get("sales_cn_vat")) > 0, n(e.get("tourist_refund_vat")) > 0, rc > 0,
            n(e.get("zero_supplies")) > 0, exempt > 0, True,
            n(e.get("input_vat")) > 0, n(e.get("purchase_cn_net")) > 0 or n(e.get("purchase_cn_vat")) > 0, n(e.get("blocked_input_vat")) > 0,
            n(e.get("capital_assets_vat")) > 0, rc > 0, exempt > 0, n(e.get("input_vat")) > 0,
            n(e.get("import_goods_value")) > 0 or n(e.get("import_vat")) > 0, n(e.get("import_adjust_vat")) != 0, rc > 0, n(e.get("zero_supplies")) > 0,
            n(e.get("dz_goods_supplies")) > 0 or e.get("location") == "Designated Zone",
            n(e.get("bad_debt_vat")) != 0, n(e.get("deemed_supplies_vat")) != 0, n(e.get("prior_period_error_vat")) != 0,
            n(e.get("change_in_use_vat")) != 0 or n(e.get("capital_assets_vat")) > 0, yes(e.get("margin_scheme")),
            True, True, True, True, True,
        ]
        sched = [reg and bool(v) for v in sched]
        reg12 = n(e.get("taxable_supplies_12m"))
        step = 1 if e.get("vat_frequency") == "Monthly" else 3
        pe = D(e.get("vat_period_end"))
        due = pe + dt.timedelta(days=int(n(R["vat_due_days"]))) if pe else None
        next_end = eom(pe, step) if pe else None
        next_due = next_end + dt.timedelta(days=int(n(R["vat_due_days"]))) if next_end else None
        late = (today - due).days if (reg and due and today > due) else 0
        if not reg:
            if reg12 >= n(R["vat_reg_mandatory"]):
                status, flag = "Registration required", "red"
            elif reg12 >= n(R["vat_reg_voluntary"]):
                status, flag = "Voluntary eligible", "grey"
            else:
                status, flag = "Not registered", "grey"
        elif filed:
            if net_vat > 0 and not paid:
                status, flag = ("Overdue (unpaid)", "red") if late > 0 else ("Filed, payment due", "amber")
            else:
                status, flag = "Filed", "green"
        elif late > 0:
            status, flag = "Overdue", "red"
        elif due is not None and (due - today).days <= n(R["vat_due_soon_days"]):
            status, flag = "Due soon", "amber"
        else:
            status, flag = "On track", "green"
        unpaid = reg and net_vat > 0 and not paid
        base = net_vat if (unpaid and late > 0) else 0

        def mdiff(a, b):
            return (b.year - a.year) * 12 + b.month - a.month - (1 if b.day < a.day else 0)

        pay_rate = n(R["vat_late_pay_rate"]) / 12 * (mdiff(due + DAY, today) + 1) if late > 0 else 0
        penalty = (n(R["vat_late_filing_penalty"]) if (reg and not filed and late > 0) else 0) + base * pay_rate
        open_end = next_end if filed else pe
        open_due = next_due if filed else due
        rows.append(dict(
            id=e["id"], name=e["name"], location=e["location"], vat_status=status, vat_flag=flag, registered="Yes" if reg else "No",
            taxable_supplies=jr(taxable), dz_goods=jr(n(e.get("dz_goods_supplies"))), output_vat=jr(out), total_due=jr(due_total),
            vat_schedules_required=sum(sched), vat_sched_flags="".join("1" if v else "0" for v in sched),
            recon_status=recon, recon_sales_diff=d_sales, recon_output_diff=d_out, recon_input_diff=d_in,
            recoverable_vat=jr(recoverable), recovery_pct=ratio, net_vat=jr(net_vat), period_end=Y(pe), due=Y(due),
            open_period=Y(open_end), open_due=Y(open_due), days_to_open=None if open_due is None else (open_due - today).days,
            late_days=late, vat_penalty=jr(penalty), vat_overdue_tax=jr(base), open_exceptions=n(e.get("vat_open_exceptions")),
            taxable_12m=jr(reg12), asof=Y(today),
            # extra detail used by the return screens
            out_raw=out, rc=rc, imp=imp, adj_out=adj_out, gross_in=gross_in, ratio=ratio, step=step,
        ))
    return rows


# ------------------------------------------------------------------ corporate tax
def risk_calc(entities, vat_rows):
    V = {r["id"]: r for r in vat_rows}
    out = []
    for e in entities:
        v = V.get(e["id"], {})
        score = 0
        if v.get("vat_flag") == "red": score += 25 if v.get("vat_status") == "Registration required" else 30
        if v.get("vat_flag") == "amber": score += 8
        score += min(10, n(v.get("open_exceptions")) * 2)
        score = min(100, score)
        overdue = sum([str(v.get("vat_status")).startswith("Overdue"), v.get("vat_status") == "Registration required"])
        out.append(dict(
            id=e["id"], name=e["name"], location=e["location"], vat_status=v.get("vat_status"), vat_flag=v.get("vat_flag"),
            vat_net=n(v.get("net_vat")), risk_score=score,
            rag="Red" if score >= 40 else "Amber" if score >= 15 else "Green", overdue_items=overdue,
            exposure=n(v.get("vat_penalty")) + n(v.get("vat_overdue_tax")),
        ))
    return out


def aed(x) -> str:
    return "AED {:,.2f}".format(jr(n(x)))


def pct(x) -> str:
    return "{:.1f}%".format(n(x) * 100)


def issues_calc(entities, vat_rows):
    V = {r["id"]: r for r in vat_rows}
    out = []
    for e in entities:
        v = V.get(e["id"], {})

        def add(area, sev, issue, action):
            out.append(dict(id=e["id"], name=e["name"], location=e["location"], area=area, severity=sev, issue=issue, action=action))

        vs = v.get("vat_status")
        if vs == "Registration required": add("VAT", "High", "Taxable supplies of %s over 12 months exceed the mandatory registration threshold." % aed(v.get("taxable_12m")), "Register with the FTA, obtain a TRN and start charging VAT.")
        if vs == "Voluntary eligible": add("VAT", "Info", "Taxable supplies are above the voluntary registration threshold.", "Decide whether to register voluntarily.")
        if str(vs).startswith("Overdue"): add("VAT", "High", "VAT return for the period ending %s is %s days overdue." % (v.get("period_end"), v.get("late_days")), "File VAT 201 and pay any balance. Estimated penalties %s." % aed(v.get("vat_penalty")))
        if vs == "Filed, payment due": add("VAT", "Medium", "VAT return filed but the balance of %s is unpaid." % aed(v.get("net_vat")), "Pay before %s." % v.get("due"))
        if vs == "Due soon": add("VAT", "Medium", "VAT return for the period ending %s is due on %s." % (v.get("period_end"), v.get("due")), "Finalise and file VAT 201.")
        if n(v.get("open_exceptions")) > 0: add("VAT", "Medium", "%d open invoice exceptions (TRN, tax invoice fields, zero-rating evidence)." % n(v.get("open_exceptions")), "Clear the exceptions before the return is filed.")
        if v.get("registered") == "Yes" and n(v.get("recovery_pct")) < 1: add("VAT", "Info", "Input VAT is apportioned because of exempt supplies: %s recoverable." % pct(v.get("recovery_pct")), "Check the apportionment method and the annual adjustment.")
        if e.get("location") == "Designated Zone": add("VAT", "Info", "Designated zone: goods supplied within the zone (%s) are outside the scope of VAT." % aed(v.get("dz_goods")), "Keep customs and stock records; services stay taxable.")
        if v.get("recon_status") == "Difference": add("VAT", "Medium", "VAT control accounts do not agree to the return (sales difference %s, output VAT %s, input VAT %s)." % (aed(v.get("recon_sales_diff")), aed(v.get("recon_output_diff")), aed(v.get("recon_input_diff"))), "Reconcile the ledger to the VAT 201 boxes and document timing differences before filing.")
    rank = {"High": 0, "Medium": 1, "Info": 2}
    out.sort(key=lambda r: (rank[r["severity"]], r["id"]))
    for i, r in enumerate(out):
        r = dict(key="%s-%d" % (r["id"], i), **r)
        out[i] = r
    return out


def deadline_calc(vat_rows, R):
    soon = n(R.get("vat_due_soon_days")) or 14
    rows = []

    def rate(days):
        return ("Overdue", "red") if days < 0 else ("Due soon", "amber") if days <= soon else ("Upcoming", "green")

    for v in vat_rows:
        if v["registered"] == "Yes" and v["open_due"]:
            s_ = rate(v["days_to_open"])
            rows.append(dict(id=v["id"], key="%s-VAT" % v["id"], location=v["location"], entity=v["name"], obligation="VAT return and payment",
                             period_end=v["open_period"], due=v["open_due"], days_left=v["days_to_open"], status=s_[0], flag=s_[1]))
    rows.sort(key=lambda r: r["days_left"] if r["days_left"] is not None else 10 ** 9)
    return rows


def zone_calc(risk_rows, vat_rows, today=None):
    scopes = [("Mainland", "Mainland"), ("Free Zone", "Free zone"), ("Designated Zone", "Designated zone"), ("all", "All entities")]
    out = []
    for key, label in scopes:
        rs = [r for r in risk_rows if key == "all" or r["location"] == key]
        s = lambda f: sum(n(r[f]) for r in rs)
        out.append(dict(scope=key, label=label, entities=len(rs), overdue=s("overdue_items"), net_vat=s("vat_net"),
                        exposure=s("exposure"), avg_risk=jr(s("risk_score") / len(rs)) if rs else 0,
                        red_count=sum(1 for r in rs if r["rag"] == "Red"), asof=Y(today)))
    return out


def run_all(entities, rules, today=None):
    """Full VAT computation for a list of fully populated entity dicts."""
    R = rules_to_dict(rules)
    today = today or as_of(R)
    v = vat_calc(entities, R, today)
    k = risk_calc(entities, v)
    return dict(today=today, R=R, vat=v, risk=k, issues=issues_calc(entities, v), calendar=deadline_calc(v, R), zones=zone_calc(k, v, today))
