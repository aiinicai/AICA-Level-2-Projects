"""Shared helpers: VAT period assignment, classification flags, result container."""
from __future__ import annotations

import datetime as dt
import json
import os

from .. import engine as E

REVIEW = "Review"


def period_end_for(d: dt.date, anchor_end: dt.date, step: int) -> dt.date:
    """End of the VAT period (step months long) containing d, with periods aligned to anchor_end."""
    m = (d.year - anchor_end.year) * 12 + d.month - anchor_end.month
    k = -((-m) // step)  # ceil(m / step)
    return E.eom(anchor_end, k * step)


class Fetched:
    """Rows ready for the preview. Each row has a `flag` (empty or a reason it needs review)."""

    def __init__(self):
        self.vat = []
        self.ct = []
        self.notes = []
        self.skipped = 0

    def note(self, s):
        if s not in self.notes:
            self.notes.append(s)


def local_cfg_path():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    d = os.path.join(base, "UAETaxSuite")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "connectors.json")


def load_local():
    try:
        with open(local_cfg_path(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_local(cfg):
    p = local_cfg_path()
    with open(p, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=1)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
