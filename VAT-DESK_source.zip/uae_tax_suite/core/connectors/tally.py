"""Tally (Prime / ERP 9) over its built-in XML-over-HTTP server (Gateway of Tally, default port 9000).

In Tally: F1 Help > Settings > Connectivity (or F12 > Advanced Configuration), set TallyPrime to act as
Server (Both), port 9000, and open the company you want. Nothing is written to Tally: every request is a read.
"""
from __future__ import annotations

import datetime as dt
import os
import re
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET


from .. import engine as E
from .common import Fetched, period_end_for, REVIEW

DEFAULT_URL = "http://localhost:9000"
VAT_WORDS = ("vat",)
BLOCKED_WORDS = ("blocked", "non-recoverable", "non recoverable", "not recoverable")
RCM_WORDS = ("reverse", "rcm")
ZERO_WORDS = ("export", "zero", "0%")
EXEMPT_WORDS = ("exempt",)
VTYPE = {"sales": "Sale", "purchase": "Purchase", "credit note": "Sale - credit note", "debit note": "Purchase - credit note"}


class TallyError(Exception):
    pass


def _clean(xml: str) -> str:
    # Tally can emit character references (&#4; etc.) that XML parsers reject
    xml = re.sub(r"&#(?:[0-8]|1[0-9]|2[0-9]|3[01]|11|12);", "", xml)
    xml = xml.replace("\x00", "")
    # Tally writes user-defined fields as <UDF:Name> and attributes such as UDF:Name="..." without declaring the prefix,
    # which makes the XML invalid ("unbound prefix"). Drop namespace prefixes and declarations; nothing here needs them.
    if ":" in xml:
        def tag(m):
            t = re.sub(r'\sxmlns(?::[\w.-]+)?\s*=\s*("[^"]*"|\'[^\']*\')', "", m.group(0))
            t = re.sub(r"^<(/?)[\w.-]+:", r"<\1", t)
            return re.sub(r'(\s)[\w.-]+:([\w.-]+\s*=)', r"\1\2", t)
        xml = re.sub(r"<[^<>!?][^<>]*>", tag, xml)
    return xml


ACCESS_KEY = ""     # optional key for a gateway placed in front of Tally (Tally itself has no login)


def set_access_key(key: str):
    """Sent with every request as 'Authorization: Bearer <key>' and 'X-API-Key: <key>' so a reverse proxy or gateway can check it."""
    global ACCESS_KEY
    ACCESS_KEY = (key or "").strip()


def post(url: str, body: str, timeout=120) -> ET.Element:
    headers = {"Content-Type": "text/xml; charset=utf-8"}
    if ACCESS_KEY:
        headers["Authorization"] = "Bearer " + ACCESS_KEY
        headers["X-API-Key"] = ACCESS_KEY
    req = urllib.request.Request(url, data=body.encode("utf-8"), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise TallyError("The gateway in front of Tally refused the access key (HTTP %s). Check the key." % e.code)
        raise TallyError("The gateway or Tally answered with HTTP %s at %s." % (e.code, url))
    except Exception as e:
        raise TallyError("Cannot reach Tally at %s. Is Tally open with the company loaded and the server enabled on this port? (%s)" % (url, e))
    try:
        root = ET.fromstring(_clean(raw))
    except ET.ParseError as e:
        raise TallyError("Tally returned something that is not valid XML (%s). Start of reply: %s" % (e, " ".join(raw[:160].split())))
    err = root.find(".//LINEERROR")
    if err is not None and (err.text or "").strip():
        raise TallyError("Tally reported: " + err.text.strip())
    return root


def _static(company: str, d1: dt.date | None = None, d2: dt.date | None = None) -> str:
    s = "<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>"
    if company:
        s += "<SVCURRENTCOMPANY>%s</SVCURRENTCOMPANY>" % _esc(company)
    if d1:
        s += "<SVFROMDATE>%s</SVFROMDATE>" % d1.strftime("%Y%m%d")
    if d2:
        s += "<SVTODATE>%s</SVTODATE>" % d2.strftime("%Y%m%d")
    return s


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def req_report(report: str, company="", d1=None, d2=None) -> str:
    return ("<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Data</TYPE><ID>%s</ID></HEADER>"
            "<BODY><DESC><STATICVARIABLES>%s</STATICVARIABLES></DESC></BODY></ENVELOPE>" % (report, _static(company, d1, d2)))


def req_collection(name: str, ctype: str, fetch: str, company="", d1=None, d2=None) -> str:
    return ("<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>%s</ID></HEADER>"
            "<BODY><DESC><STATICVARIABLES>%s</STATICVARIABLES><TDL><TDLMESSAGE>"
            "<COLLECTION NAME=\"%s\" ISMODIFY=\"No\"><TYPE>%s</TYPE><FETCH>%s</FETCH></COLLECTION>"
            "</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>" % (name, _static(company, d1, d2), name, ctype, fetch))


def list_companies(url=DEFAULT_URL):
    root = post(url, req_collection("UAEListOfCompanies", "Company", "Name"))
    out = []
    for c in root.iter("COMPANY"):
        n = c.get("NAME") or (c.findtext("NAME") or "")
        if n and n not in out:
            out.append(n.strip())
    return out


def _f(x) -> float:
    try:
        return float(str(x).replace(",", "").strip().split()[0])
    except Exception:
        return 0.0


def _date(s) -> dt.date | None:
    try:
        return dt.datetime.strptime((s or "").strip(), "%Y%m%d").date()
    except ValueError:
        return None


def _has(name, words):
    n = name.lower()
    return any(w in n for w in words)


def resolve_vtype(name: str, vtmap: dict | None) -> str:
    """Map a company-specific voucher type (for example 'Tax Invoice' or 'Sales - VAT') to its Tally parent type."""
    n = (name or "").strip().lower()
    seen = set()
    while n and n not in VTYPE and vtmap and n in vtmap and n not in seen:
        seen.add(n)
        n = vtmap[n]
    return n


def parse_vouchers(root, anchor_end: dt.date, step: int, vat_words=VAT_WORDS, no_vat_sales="Sale - zero rated", out: Fetched | None = None,
                   vtmap: dict | None = None, d1: dt.date | None = None, d2: dt.date | None = None, stats: dict | None = None) -> Fetched:
    out = out or Fetched()
    st = stats if stats is not None else {}
    for v in root.iter("VOUCHER"):
        vtype = (v.get("VCHTYPE") or v.findtext("VOUCHERTYPENAME") or "").strip()
        st["seen"] = st.get("seen", 0) + 1
        base = VTYPE.get(resolve_vtype(vtype, vtmap))
        if not base:
            u = st.setdefault("unrecognised", {})
            u[vtype or "(blank)"] = u.get(vtype or "(blank)", 0) + 1
            continue
        _d = _date(v.findtext("DATE"))
        if _d and ((d1 and _d < d1) or (d2 and _d > d2)):
            st["outside"] = st.get("outside", 0) + 1
            continue
        if (v.findtext("ISCANCELLED") or "").strip().lower() == "yes" or (v.findtext("ISOPTIONAL") or "").strip().lower() == "yes":
            out.skipped += 1
            continue
        d = _date(v.findtext("DATE"))
        if not d:
            continue
        party = (v.findtext("PARTYLEDGERNAME") or v.findtext("PARTYNAME") or "").strip()
        number = (v.findtext("VOUCHERNUMBER") or "").strip()
        narr = (v.findtext("NARRATION") or "").strip()
        net = vat = 0.0
        vat_names, other_names = [], []
        entries = list(v.findall("LEDGERENTRIES.LIST")) + list(v.findall("ALLLEDGERENTRIES.LIST"))
        for le in entries:
            name = (le.findtext("LEDGERNAME") or "").strip()
            amt = _f(le.findtext("AMOUNT"))
            if (le.findtext("ISPARTYLEDGER") or "").strip().lower() == "yes" or name == party:
                continue
            if _has(name, vat_words):
                vat += amt
                vat_names.append(name)
            else:
                net += amt
                other_names.append(name)
        net_v, vat_v = abs(net), abs(vat)
        flag = ""
        if base == "Sale":
            if vat_v > 0:
                dtp = "Sale - standard rated"
            else:
                names = " ".join(other_names)
                if _has(names, ZERO_WORDS):
                    dtp = "Sale - zero rated"
                elif _has(names, EXEMPT_WORDS):
                    dtp = "Sale - exempt"
                else:
                    dtp, flag = no_vat_sales, "No VAT charged: confirm zero-rated, exempt or out of scope"
        elif base == "Purchase":
            vn = " ".join(vat_names)
            if vat_v == 0:
                out.skipped += 1
                continue
            if _has(vn, RCM_WORDS):
                dtp = "Purchase - reverse charge"
            elif _has(vn, BLOCKED_WORDS):
                dtp = "Purchase - blocked input VAT"
            else:
                dtp = "Purchase - standard rated"
        else:
            dtp = base
        out.vat.append(dict(period_end=period_end_for(d, anchor_end, step).isoformat(), doc_date=d.isoformat(), doc_no=number, party=party,
                            doc_type=dtp, net=round(net_v, 2), vat=round(vat_v, 2), description=narr[:120], trn="", emirate="", flag=flag,
                            source="Tally %s" % vtype))
    return out


def req_vouchers(company, d1, d2) -> str:
    fields = ("Date,VoucherTypeName,VoucherNumber,PartyLedgerName,Narration,IsCancelled,IsOptional,"
              "AllLedgerEntries.LedgerName,AllLedgerEntries.Amount,AllLedgerEntries.IsPartyLedger")
    return req_collection("UAEVouchers", "Voucher", fetch=fields, company=company, d1=d1, d2=d2)


def voucher_type_map(url, company) -> dict:
    """{custom type name (lower case): parent type name (lower case)}; empty if Tally does not answer."""
    try:
        root = post(url, req_collection("UAEVoucherTypes", "VoucherType", "Name,Parent", company))
    except TallyError:
        return {}
    m = {}
    for t in root.iter("VOUCHERTYPE"):
        nm = (t.get("NAME") or t.findtext("NAME") or "").strip().lower()
        par = (t.findtext("PARENT") or "").strip().lower()
        if nm and par:
            m[nm] = par
    return m


def month_chunks(d1: dt.date, d2: dt.date):
    cur = d1
    while cur <= d2:
        nxt = (cur.replace(day=1) + dt.timedelta(days=32)).replace(day=1)
        yield cur, min(d2, nxt - dt.timedelta(days=1))
        cur = nxt


def _key(r):
    return (r["doc_type"], r["doc_no"], r["doc_date"], r["party"], r["net"], r["vat"])


def dump_response(raw_root, name="tally_last_response.xml"):
    """Keep the first reply on disk so a support person can see exactly what Tally sent."""
    try:
        from .common import local_cfg_path
        p = os.path.join(os.path.dirname(local_cfg_path()), name)
        with open(p, "wb") as f:
            f.write(ET.tostring(raw_root))
        return p
    except Exception:
        return ""


def fetch_vat(url, company, d1, d2, anchor_end, step, no_vat_sales="Sale - zero rated", vat_words=VAT_WORDS, progress=None, cancelled=None) -> Fetched:
    """Reads the range one month at a time (a single long Day Book request often returns only part of the data)
    using both the Day Book and the Voucher collection, and merges the two without duplicates."""
    out = Fetched()
    vtmap = voucher_type_map(url, company)
    stats = {}
    seen = set()
    dumped = False
    for a, b in month_chunks(d1, d2):
        if cancelled and cancelled():
            break
        if progress:
            progress("Reading Tally vouchers for %s to %s (%d rows so far)..." % (a, b, len(out.vat)))
        for kind in ("daybook", "vouchers"):
            try:
                root = post(url, req_report("Day Book", company, a, b) if kind == "daybook" else req_vouchers(company, a, b))
            except TallyError as e:
                if kind == "daybook":
                    raise
                out.note("Voucher collection request failed for %s to %s (%s). Day Book data was used." % (a, b, e))
                continue
            if not dumped and kind == "daybook":
                dumped = bool(dump_response(root))
            part = Fetched()
            parse_vouchers(root, anchor_end, step, vat_words, no_vat_sales, part, vtmap, a, b, stats)
            out.skipped += part.skipped
            for r in part.vat:
                k = _key(r)
                if k not in seen:
                    seen.add(k)
                    out.vat.append(r)
    n_seen = stats.get("seen", 0)
    out.note("Tally sent %d voucher records for %s to %s (Day Book and Voucher collection together, read month by month); %d rows were read." % (n_seen, d1, d2, len(out.vat)))
    if stats.get("outside"):
        out.note("%d vouchers returned by Tally were dated outside the chosen period and were ignored." % stats["outside"])
    if stats.get("unrecognised"):
        top = sorted(stats["unrecognised"].items(), key=lambda x: -x[1])[:8]
        out.note("Voucher types not read as sales, purchase, credit or debit notes: " + ", ".join("%s (%d)" % t for t in top)
                 + ". If any of these are VAT invoices, make sure their parent type in Tally is Sales, Purchase, Credit Note or Debit Note.")
    if not out.vat:
        out.note("No sales, purchase, credit note or debit note vouchers with VAT were found in this date range for the open company.")
    out.note("Purchases without a VAT ledger are skipped. Imports, capital assets, bad debt relief and deemed supplies are not identified automatically: review the Transaction type column.")
    out.note("VAT ledgers are recognised by the word %s in the ledger name." % " / ".join("'%s'" % w for w in vat_words))
    return out


# ------------------------------------------------------------------ trial balance for corporate tax
PRIMARY_INCOME = {"sales accounts", "direct incomes", "income (direct)", "indirect incomes", "income (indirect)"}
PRIMARY_EXPENSE = {"purchase accounts", "direct expenses", "expenses (direct)", "indirect expenses", "expenses (indirect)"}
