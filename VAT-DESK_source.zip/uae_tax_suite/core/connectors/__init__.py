"""Connectors that pull data from accounting software into the VAT and CT upload tables."""
