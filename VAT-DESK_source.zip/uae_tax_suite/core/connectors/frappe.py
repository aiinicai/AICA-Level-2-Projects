"""Frappe / ERPNext (self-hosted or Frappe Cloud) through its REST API with an API key and secret. Read-only: only GET calls are made.

One-time setup in ERPNext: User list > open the user that will be used > API Access > Generate Keys. Copy the API key and the secret
(shown once) into the app. The user needs read permission on Sales Invoice, Purchase Invoice, Company, Account and GL Entry (the
Accounts User role is enough). The site address is the one you open in the browser, for example https://mycompany.frappe.cloud.
"""
from __future__ import annotations

import datetime as dt
import json
import time
import urllib.error
import urllib.parse
import urllib.request


from .common import Fetched, period_end_for


class FrappeError(Exception):
    pass


def normalise_site(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if not u:
        raise FrappeError("Enter the ERPNext site address, for example https://mycompany.frappe.cloud")
    if "://" not in u:
        u = "https://" + u
    p = urllib.parse.urlparse(u)
    return "%s://%s" % (p.scheme, p.netloc)          # drop /app/... or /login paths


def _http(url, headers, timeout=60):
    req = urllib.request.Request(url, method="GET", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        raise FrappeError("Cannot reach the ERPNext site (%s). Check the address and the internet connection." % e)


class Client:
    def __init__(self, site, api_key, api_secret, company="", pause=0.1):
        self.site = normalise_site(site)
        self.key, self.secret, self.company = api_key.strip(), api_secret.strip(), company
        self.pause = pause
        self.calls = 0
        self._last = 0.0

    def get(self, path, params=None):
        q = {}
        for k, v in (params or {}).items():
            q[k] = v if isinstance(v, str) else json.dumps(v)
        url = "%s/%s%s" % (self.site, path.lstrip("/"), ("?" + urllib.parse.urlencode(q)) if q else "")
        for attempt in range(3):
            wait = self.pause - (time.time() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.time()
            self.calls += 1
            st, body = _http(url, {"Authorization": "token %s:%s" % (self.key, self.secret), "Accept": "application/json"})
            if st == 429 or st == 503:
                time.sleep(5 * (attempt + 1))
                continue
            if st in (401, 403):
                raise FrappeError("ERPNext refused the API key or the user has no permission for this data (HTTP %s). Check the key, the secret and the user's roles." % st)
            try:
                j = json.loads(body)
            except ValueError:
                raise FrappeError("Unexpected reply from the site (HTTP %s). Check that the address is the ERPNext site itself." % st)
            if st >= 400:
                msg = j.get("exception") or j.get("message") or j.get("_server_messages") or body[:150]
                raise FrappeError("ERPNext said: %s" % str(msg)[:200])
            return j
        raise FrappeError("The site is busy or rate limiting requests. Try again in a minute.")

    def test(self):
        return self.get("api/method/frappe.auth.get_logged_user").get("message", "")

    def companies(self):
        rows = self.get("api/resource/Company", dict(fields=["name", "default_currency"], limit_page_length=100)).get("data", [])
        return [r["name"] for r in rows]

    def paged(self, doctype, fields, filters, order_by="", size=100, cancel=None, group_by=""):
        start = 0
        while True:
            q = dict(fields=fields, filters=filters, limit_start=start, limit_page_length=size)
            if order_by:
                q["order_by"] = order_by
            if group_by:
                q["group_by"] = group_by
            rows = self.get("api/resource/" + urllib.parse.quote(doctype), q).get("data", [])
            for r in rows:
                yield r
            if len(rows) < size or (cancel and cancel()):
                return
            start += size

    def doc(self, doctype, name):
        return self.get("api/resource/%s/%s" % (urllib.parse.quote(doctype), urllib.parse.quote(name, safe=""))).get("data") or {}


# ------------------------------------------------------------------ VAT documents
KINDS = [
    # doctype, number field, party field, base type
    ("Sales Invoice", "name", "customer_name", "Sale"),
    ("Purchase Invoice", "bill_no", "supplier_name", "Purchase"),
]
EMIRATES = {"abu dhabi", "dubai", "sharjah", "ajman", "umm al quwain", "ras al khaimah", "fujairah"}


def _n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def _rates(item):
    """Sum of the rates in the item's tax rate map (account -> rate), or None when the item has no map."""
    raw = item.get("item_tax_rate")
    if not raw:
        return None
    try:
        m = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        return None
    if not isinstance(m, dict) or not m:
        return None
    return sum(_n(v) for v in m.values())


def parse_doc(doc: dict, base: str, number_f: str, party_f: str, anchor_end: dt.date, step: int, no_vat_sales="Sale - zero rated", out: Fetched | None = None):
    out = out or Fetched()
    try:
        d = dt.date.fromisoformat(str(doc.get("posting_date") or "")[:10])
    except ValueError:
        return out
    fx = _n(doc.get("conversion_rate")) or 1.0
    ret = bool(doc.get("is_return"))
    taxes = doc.get("taxes") or []
    add_rows = [t for t in taxes if (t.get("add_deduct_tax") or "Add") == "Add"]
    ded_rows = [t for t in taxes if t.get("add_deduct_tax") == "Deduct"]
    doc_rate = sum(_n(t.get("rate")) for t in add_rows if t.get("charge_type") == "On Net Total")
    doc_text = " ".join([str(doc.get("taxes_and_charges") or "")] + [str(t.get("description") or "") + " " + str(t.get("account_head") or "") for t in taxes]).lower()
    rc_doc = "reverse" in doc_text or bool(ded_rows and any(_n(t.get("rate")) > 0 for t in ded_rows)) or str(doc.get("reverse_charge") or "").upper() in ("1", "Y", "YES", "TRUE")
    buckets = {}
    total_net = 0.0
    for it in doc.get("items") or []:
        net = _n(it.get("base_net_amount")) or _n(it.get("net_amount")) * fx
        net = abs(net) if ret else net
        total_net += net
        r = _rates(it)
        pct = doc_rate if r is None else r
        vat = net * pct / 100
        text = (doc_text + " " + str(it.get("item_tax_template") or "")).lower()
        rc = rc_doc or "reverse" in text
        flag = ""
        if ret:
            t = "Sale - credit note" if base == "Sale" else "Purchase - credit note"
        elif base == "Sale":
            if pct > 0:
                t = "Sale - standard rated"
            elif "exempt" in text:
                t = "Sale - exempt"
            elif "zero" in text or "export" in text:
                t = "Sale - zero rated"
            else:
                t, flag = no_vat_sales, "No VAT on this line: confirm zero-rated, exempt or out of scope"
        else:
            if pct <= 0 and not rc:
                continue
            t = "Purchase - reverse charge" if rc else ("Purchase - blocked input VAT" if any(w in text for w in ("blocked", "non-recoverable", "non recoverable")) else "Purchase - standard rated")
        b = buckets.setdefault((t, flag), [0.0, 0.0])
        b[0] += net
        b[1] += vat
    em = str(doc.get("emirate") or doc.get("place_of_supply") or "").strip().title()
    em = em if em.lower() in EMIRATES else ""
    for (t, flag), (net, vat) in buckets.items():
        out.vat.append(dict(period_end=period_end_for(d, anchor_end, step).isoformat(), doc_date=d.isoformat(), doc_no=str(doc.get(number_f) or doc.get("name") or ""),
                            party=str(doc.get(party_f) or ""), doc_type=t, net=round(net, 2), vat=round(vat, 2), description="",
                            trn=str(doc.get("tax_id") or ""), emirate=em, flag=flag, source="ERPNext " + base))
    tot = abs(_n(doc.get("base_total_taxes_and_charges"))) if ret else _n(doc.get("base_total_taxes_and_charges"))
    got = sum(v for (_, _), (_, v) in buckets.items())
    if not rc_doc and tot and abs(tot - got) > 1.0:
        out.note("%s %s: VAT computed from item rates (%.2f) differs from the document's tax total (%.2f). Check it." % (base, doc.get("name"), got, tot))
    return out


def fetch_vat(client: Client, d1: dt.date, d2: dt.date, anchor_end: dt.date, step: int, no_vat_sales="Sale - zero rated", progress=None, cancel=None) -> Fetched:
    out = Fetched()
    if not client.company:
        raise FrappeError("Choose the company first (press Load companies).")
    for doctype, numf, partyf, base in KINDS:
        flt = [["docstatus", "=", 1], ["company", "=", client.company], ["posting_date", "between", [d1.isoformat(), d2.isoformat()]]]
        names = [r["name"] for r in client.paged(doctype, ["name"], flt, "posting_date asc, name asc", cancel=cancel)]
        if progress:
            progress("%s: %d documents" % (doctype, len(names)))
        for i, nm in enumerate(names, 1):
            if cancel and cancel():
                out.note("Stopped before all documents were read.")
                return out
            parse_doc(client.doc(doctype, nm), base, numf, partyf, anchor_end, step, no_vat_sales, out)
            if progress and i % 10 == 0:
                progress("%s: %d of %d" % (doctype, i, len(names)))
    out.note("Only submitted Sales Invoices and Purchase Invoices (including returns as credit notes) are read. Draft and cancelled documents are skipped. Amounts are in the company currency.")
    out.note("VAT is taken from each item's tax rate (Item Tax Template), or the invoice's tax rows. Zero-rated and exempt sales are recognised from the template names (containing 'zero', 'export' or 'exempt'): check them, and the reverse charge and blocked input VAT lines.")
    out.note("Imports, capital assets, bad debt relief and journal-entry VAT are not picked up.")
    return out


# ------------------------------------------------------------------ trial balance (corporate tax)
