"""Zoho Books (cloud) through its REST API v3 with OAuth 2.0. Read-only: only list and get calls are made.

One-time setup, in the Zoho API Console (api-console.zoho.<region>):
  * Create a "Server-based Application" with redirect URI  http://localhost:8765/callback
    (or use a "Self Client" and paste the refresh token it gives you).
  * Copy the Client ID and Client Secret into the app and press "Sign in with Zoho".
Scopes requested: ZohoBooks.invoices.READ, bills.READ, creditnotes.READ, vendorcredits.READ, settings.READ.
"""
from __future__ import annotations

import datetime as dt
import http.server
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from .common import Fetched, period_end_for

SCOPES = "ZohoBooks.invoices.READ,ZohoBooks.bills.READ,ZohoBooks.creditnotes.READ,ZohoBooks.vendorcredits.READ,ZohoBooks.settings.READ"
# Region suffix -> (accounts domain, API domain). "ae" follows Zoho's UAE data centre naming: confirm in your Zoho URL.
DCS = {
    "com": ("https://accounts.zoho.com", "https://www.zohoapis.com"),
    "eu": ("https://accounts.zoho.eu", "https://www.zohoapis.eu"),
    "in": ("https://accounts.zoho.in", "https://www.zohoapis.in"),
    "com.au": ("https://accounts.zoho.com.au", "https://www.zohoapis.com.au"),
    "jp": ("https://accounts.zoho.jp", "https://www.zohoapis.jp"),
    "ca": ("https://accounts.zohocloud.ca", "https://www.zohoapis.ca"),
    "sa": ("https://accounts.zoho.sa", "https://www.zohoapis.sa"),
    "ae": ("https://accounts.zoho.ae", "https://www.zohoapis.ae"),
}
EMIRATE = {"AB": "Abu Dhabi", "DU": "Dubai", "SH": "Sharjah", "AJ": "Ajman", "UQ": "Umm Al Quwain", "RK": "Ras Al Khaimah", "FU": "Fujairah"}


class ZohoError(Exception):
    pass


def _http(method, url, data=None, headers=None, timeout=60):
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")
    except Exception as e:
        raise ZohoError("Cannot reach Zoho (%s). Check the internet connection and the data centre." % e)


def token_request(accounts, params):
    st, body = _http("POST", accounts + "/oauth/v2/token?" + urllib.parse.urlencode(params), data=b"")
    try:
        j = json.loads(body)
    except ValueError:
        raise ZohoError("Unexpected reply from Zoho sign-in (HTTP %s)." % st)
    if "error" in j:
        raise ZohoError("Zoho sign-in failed: %s" % j["error"])
    return j


def browser_sign_in(dc, client_id, client_secret, port=8765, timeout=180, accounts_override=None, open_browser=True):
    """Opens the Zoho consent page and catches the redirect on localhost. Returns the refresh token."""
    accounts = accounts_override or DCS[dc][0]
    redirect = "http://localhost:%d/callback" % port
    got = {}

    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "code" in q:
                got["code"] = q["code"][0]
            elif "error" in q:
                got["error"] = q["error"][0]
            self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers()
            self.wfile.write(b"<html><body style='font-family:sans-serif'><h3>You can close this tab and return to the app.</h3></body></html>")

        def log_message(self, *a):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", port), H)
    srv.timeout = 1
    url = accounts + "/oauth/v2/auth?" + urllib.parse.urlencode(dict(scope=SCOPES, client_id=client_id, response_type="code", access_type="offline", redirect_uri=redirect, prompt="consent"))
    if open_browser:
        webbrowser.open(url)
    t0 = time.time()
    try:
        while not got and time.time() - t0 < timeout:
            srv.handle_request()
    finally:
        srv.server_close()
    if "error" in got:
        raise ZohoError("Zoho refused access: %s" % got["error"])
    if "code" not in got:
        raise ZohoError("Sign-in timed out. Try again.")
    j = token_request(accounts, dict(grant_type="authorization_code", client_id=client_id, client_secret=client_secret, redirect_uri=redirect, code=got["code"]))
    if "refresh_token" not in j:
        raise ZohoError("Zoho did not return a refresh token. Remove the app's earlier access in Zoho and sign in again.")
    return j["refresh_token"]


def exchange_grant_code(dc, client_id, client_secret, code, accounts_override=None):
    """Self Client flow: swap the one-time grant code (generated in the API Console, valid a few minutes) for a permanent refresh token."""
    accounts = accounts_override or DCS[dc][0]
    j = token_request(accounts, dict(grant_type="authorization_code", client_id=client_id, client_secret=client_secret, code=code.strip()))
    if "refresh_token" not in j:
        raise ZohoError("Zoho did not return a refresh token. Generate a new grant code (it expires in a few minutes) and check the data centre.")
    return j["refresh_token"]


class Client:
    def __init__(self, dc, client_id, client_secret, refresh_token, org_id="", accounts=None, api=None, pause=0.7):
        a, p = DCS.get(dc, DCS["com"])
        self.accounts, self.api = accounts or a, api or p
        self.cid, self.secret, self.refresh, self.org = client_id, client_secret, refresh_token, org_id
        self.token = None
        self.pause = pause
        self._last = 0.0
        self.calls = 0

    def _token(self, force=False):
        if self.token is None or force:
            j = token_request(self.accounts, dict(grant_type="refresh_token", client_id=self.cid, client_secret=self.secret, refresh_token=self.refresh))
            self.token = j["access_token"]
        return self.token

    def get(self, path, params=None, org=True):
        q = dict(params or {})
        if org:
            if not self.org:
                raise ZohoError("Choose the Zoho organisation first.")
            q["organization_id"] = self.org
        url = "%s/books/v3/%s?%s" % (self.api, path.lstrip("/"), urllib.parse.urlencode(q))
        for attempt in range(4):
            wait = self.pause - (time.time() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.time()
            self.calls += 1
            st, body = _http("GET", url, headers={"Authorization": "Zoho-oauthtoken " + self._token()})
            if st == 401:
                self.token = None
                continue
            if st == 429:
                time.sleep(30)
                continue
            try:
                j = json.loads(body)
            except ValueError:
                raise ZohoError("Unexpected reply from Zoho (HTTP %s)." % st)
            if st >= 400 or j.get("code", 0) not in (0, None):
                raise ZohoError("Zoho said: %s (code %s)" % (j.get("message", body[:150]), j.get("code", st)))
            return j
        raise ZohoError("Zoho kept refusing the request (rate limit or expired access).")

    def organizations(self):
        return self.get("organizations", org=False).get("organizations", [])

    def paged(self, path, key, params=None, cancel=None):
        page = 1
        while True:
            q = dict(params or {}, page=page, per_page=200)
            j = self.get(path, q)
            for x in j.get(key, []):
                yield x
            if not j.get("page_context", {}).get("has_more_page"):
                return
            page += 1
            if cancel and cancel():
                return


# ------------------------------------------------------------------ parsing
KINDS = [
    # list path, list key, id field, number field, party field, sale/purchase/credit
    ("invoices", "invoices", "invoice_id", "invoice_number", "customer_name", "invoice", "Sale"),
    ("bills", "bills", "bill_id", "bill_number", "vendor_name", "bill", "Purchase"),
    ("creditnotes", "creditnotes", "creditnote_id", "creditnote_number", "customer_name", "creditnote", "Sale - credit note"),
    ("vendorcredits", "vendor_credits", "vendor_credit_id", "vendor_credit_number", "vendor_name", "vendor_credit", "Purchase - credit note"),
]
SKIP_STATUS = {"draft", "void", "voided", "deleted", "pending_approval"}


def _n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def parse_doc(doc: dict, base: str, number_f: str, party_f: str, anchor_end: dt.date, step: int, no_vat_sales="Sale - zero rated", out: Fetched | None = None):
    out = out or Fetched()
    try:
        d = dt.date.fromisoformat((doc.get("date") or "")[:10])
    except ValueError:
        return out
    fx = _n(doc.get("exchange_rate")) or 1.0
    incl = bool(doc.get("is_inclusive_tax"))
    rc_doc = bool(doc.get("is_reverse_charge_applied"))
    buckets = {}
    for li in doc.get("line_items", []):
        pct = _n(li.get("tax_percentage"))
        amt = _n(li.get("item_total"))
        net = amt / (1 + pct / 100) if (incl and pct) else amt
        vat = net * pct / 100
        tname = (li.get("tax_name") or li.get("tax_type") or "").lower()
        rc = rc_doc or bool(li.get("reverse_charge_tax_id")) or "reverse" in tname
        flag = ""
        if base == "Sale":
            if pct > 0:
                t = "Sale - standard rated"
            elif "exempt" in tname:
                t = "Sale - exempt"
            elif "zero" in tname or "export" in tname:
                t = "Sale - zero rated"
            else:
                t, flag = no_vat_sales, "No VAT on this line: confirm zero-rated, exempt or out of scope"
        elif base == "Purchase":
            if pct <= 0 and not rc:
                continue
            t = "Purchase - reverse charge" if rc else ("Purchase - blocked input VAT" if any(w in tname for w in ("blocked", "non-recoverable", "non recoverable")) else "Purchase - standard rated")
        else:
            t = base
        b = buckets.setdefault((t, flag), [0.0, 0.0])
        b[0] += net * fx
        b[1] += vat * fx
    em = EMIRATE.get((doc.get("place_of_supply") or "").upper(), "")
    for (t, flag), (net, vat) in buckets.items():
        out.vat.append(dict(period_end=period_end_for(d, anchor_end, step).isoformat(), doc_date=d.isoformat(), doc_no=str(doc.get(number_f) or ""),
                            party=str(doc.get(party_f) or doc.get("customer_name") or doc.get("vendor_name") or ""), doc_type=t, net=round(net, 2), vat=round(vat, 2),
                            description="", trn=str(doc.get("tax_reg_no") or ""), emirate=em, flag=flag, source="Zoho " + base))
    tot = _n(doc.get("tax_total")) * fx
    got = sum(v for (_, _), (_, v) in buckets.items())
    if tot and abs(tot - got) > 1.0 and base in ("Sale", "Sale - credit note"):
        out.note("%s %s: VAT computed from lines (%.2f) differs from the document's tax total (%.2f). Check it." % (base, doc.get(number_f), got, tot))
    return out


def fetch_vat(client: Client, d1: dt.date, d2: dt.date, anchor_end: dt.date, step: int, no_vat_sales="Sale - zero rated", progress=None, cancel=None) -> Fetched:
    out = Fetched()
    for path, key, idf, numf, partyf, dkey, base in KINDS:
        heads = [h for h in client.paged(path, key, dict(date_start=d1.isoformat(), date_end=d2.isoformat()), cancel)
                 if (h.get("status") or "").lower() not in SKIP_STATUS]
        if progress:
            progress("%s: %d documents" % (path, len(heads)))
        for i, h in enumerate(heads, 1):
            if cancel and cancel():
                out.note("Stopped before all documents were read.")
                return out
            det = client.get("%s/%s" % (path, h[idf])).get(dkey) or {}
            parse_doc(det, base, numf, partyf, anchor_end, step, no_vat_sales, out)
            if progress and i % 10 == 0:
                progress("%s: %d of %d" % (path, i, len(heads)))
    out.note("Zoho allows 100 calls a minute and a daily limit by plan (1,000 on Free to 10,000 on higher plans); each document costs one call. Large periods may need splitting across days.")
    out.note("Only invoices, bills, credit notes and vendor credits are read. Imports, capital assets, bad debt relief and manual journals are not picked up.")
    out.note("For corporate tax, export the trial balance from Zoho Books (Reports > Accountant > Trial Balance) and use Import file on the CT data tab.")
    return out
