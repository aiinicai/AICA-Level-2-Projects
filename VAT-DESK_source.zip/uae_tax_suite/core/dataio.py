"""Import of upload data (Excel or CSV) and export of reports to Excel and PDF."""
from __future__ import annotations

import csv
import datetime as dt
import os

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from . import db as dbm

from . import engine as E
from . import returns as RT
from .engine import D, Y, jr, n
try:
    from core.tabexport import patch_pdf_dates; patch_pdf_dates()   # PDFs show dates as DD-MM-YYYY
except Exception:
    pass

NAVY = "1F3864"
LISTS = None


def lists():
    global LISTS
    if LISTS is None:
        LISTS = dbm.load_json("lists.json")
    return LISTS


# ------------------------------------------------------------------ parsing helpers
def parse_date(v):
    if v is None or v == "":
        return None
    if isinstance(v, dt.datetime):
        return v.date().isoformat()
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, (int, float)) and 20000 < v < 80000:
        return (dt.date(1899, 12, 30) + dt.timedelta(days=int(v))).isoformat()
    s = str(v).strip()
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y", "%Y/%m/%d"):
        try:
            return dt.datetime.strptime(s, f).date().isoformat()
        except ValueError:
            pass
    return "?" + s


def parse_num(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("AED", "").strip()
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    pct = s.endswith("%")
    try:
        x = float(s.rstrip("%")) / (100 if pct else 1)
        return -x if neg else x
    except ValueError:
        return "?" + str(v)


SPEC = {
    # kind: (sheet names, columns [(key, header aliases, type)], required keys)
    "vat": (["VAT Data"], [
        ("entity_id", ["entity id", "id", "entity"], "text"), ("period_end", ["vat period end", "period end"], "date"),
        ("doc_date", ["document date", "invoice date", "date"], "date"), ("doc_no", ["document no.", "document no", "invoice no", "doc no"], "text"),
        ("party", ["customer / supplier name", "customer", "supplier", "party"], "text"),
        ("doc_type", ["transaction type", "type"], "text"),
        ("net", ["taxable value excl. vat (aed)", "taxable value", "net", "amount"], "num"), ("vat", ["vat amount (aed)", "vat amount", "vat"], "num"),
        ("description", ["remarks / supporting documents", "remarks", "description"], "text"),
        ("trn", ["customer / supplier trn", "trn"], "text"), ("emirate", ["emirate / place of supply", "emirate"], "text")],
        ["entity_id", "period_end", "doc_date", "doc_type", "net"]),
}
CHECKS = {"vat": ("doc_type", "vat_types")}


def _read_sheet_rows(path, sheet_names):
    """All rows of the best matching sheet as lists. CSV is a single table."""
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig") as f:
            return list(csv.reader(f))
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    names = {s.lower(): s for s in wb.sheetnames}
    for s in sheet_names:
        if s.lower() in names:
            return [list(r) for r in wb[names[s.lower()]].iter_rows(values_only=True)]
    return [list(r) for r in wb[wb.sheetnames[0]].iter_rows(values_only=True)]


def _find_header(rows, spec_cols):
    """Locate the header row and map column keys to indexes."""
    best, found = None, 0
    for i, r in enumerate(rows[:12]):
        cells = [str(c).strip().lower() if c is not None else "" for c in r]
        m = {}
        for key, aliases, _ in spec_cols:
            for j in range(len(cells)):
                if cells[j] in aliases and j not in m.values():
                    m[key] = j
                    break
        if len(m) > found:
            best, found = (i, m), len(m)
    return best


def read_upload(path, kind):
    """Returns (rows, issues). Each row is a dict ready for the database; issues are (row number, text)."""
    sheets, cols, req = SPEC[kind]
    raw = _read_sheet_rows(path, sheets)
    hdr = _find_header(raw, cols)
    if not hdr or "entity_id" not in hdr[1]:
        return [], [(0, "Could not find a header row with an 'Entity ID' column. Use the import template.")]
    hi, m = hdr
    rows, issues = [], []
    L = lists()
    for rn, r in enumerate(raw[hi + 1:], start=hi + 2):
        def cell(k):
            j = m.get(k)
            return r[j] if j is not None and j < len(r) else None
        if all(cell(k) in (None, "") for k, _, _ in cols):
            continue
        if cell("entity_id") in (None, ""):
            continue
        d, bad = {}, []
        for k, _, typ in cols:
            v = cell(k)
            if typ == "date":
                v = parse_date(v)
            elif typ == "num":
                v = parse_num(v)
            else:
                v = None if v is None or v == "" else str(v).strip()
            if isinstance(v, str) and v.startswith("?") and typ in ("date", "num"):
                bad.append("%s is not a valid %s (%s)" % (k, typ, v[1:]))
                v = None
            d[k] = v
        for k in req:
            if d.get(k) in (None, ""):
                bad.append("%s is missing" % k)
        if kind in CHECKS:
            fk, lk = CHECKS[kind]
            if d.get(fk) and d[fk] not in L[lk]:
                bad.append("unrecognised %s '%s'" % (fk, d[fk]))
        if bad:
            issues.append((rn, "; ".join(bad)))
            continue
        d["entity_id"] = d["entity_id"].upper()
        rows.append(d)
    return rows, issues


def import_upload(db, path, kind, mode="replace", force=False):
    """mode 'replace' swaps the rows of each entity found in the file; 'append' adds to them.

    The rows are checked first (core.validate). If any row has an Error nothing is written unless force=True; the result then has blocked=True
    and the problems under 'validation'. Remembered account mappings fill blank categories for trial balance files."""
    from . import validate as V
    rows, issues = read_upload(path, kind)
    known = {e["id"] for e in db.entities()}
    by = {}
    for r in rows:
        if r["entity_id"] not in known:
            issues.append((0, "Entity ID %s is not in the client list: rows skipped" % r["entity_id"]))
            continue
        by.setdefault(r["entity_id"], []).append(r)
    R = db.rules_dict()
    val, filled = {}, 0
    for eid, rs in by.items():
        ent = db.entity(eid)
        val[eid] = V.validate(kind, rs, R, ent)
    errors = sum(V.summary(v)[0] for v in val.values())
    seen, uniq = set(), []
    for i in issues:
        if i not in seen:
            seen.add(i)
            uniq.append(i)
    if errors and not force:
        return dict(imported=0, entities=[], issues=uniq, validation=val, blocked=True, filled=filled)
    for eid, rs in by.items():
        db.add_rows(kind, eid, rs, replace=(mode == "replace"), source=os.path.basename(path))
    return dict(imported=sum(len(v) for v in by.values()), entities=sorted(by), issues=uniq, validation=val, blocked=False, filled=filled)


def read_entities(path):
    """Clients from Excel/CSV: headers may be field labels or keys."""
    fields = [f for f in dbm.load_json("fields.json") if not f.get("hidden")]
    alias = {}
    for f in fields:
        alias[f["key"].lower()] = f
        alias[f["label"].lower()] = f
    raw = _read_sheet_rows(path, ["Clients", "Entities"])
    hi = next((i for i, r in enumerate(raw[:12]) if any(str(c or "").strip().lower() in ("id", "entity id", "name", "entity name", "taxable person") for c in r)), 0)
    heads = [alias.get(str(c or "").strip().lower()) for c in raw[hi]]
    out, issues = [], []
    for rn, r in enumerate(raw[hi + 1:], start=hi + 2):
        d = {}
        for f, v in zip(heads, r):
            if not f or v in (None, ""):
                continue
            if f["kind"] == "date":
                v = parse_date(v)
            elif f["kind"] in ("number", "percent"):
                v = parse_num(v)
                if isinstance(v, str):
                    issues.append((rn, "%s is not a number" % f["label"]))
                    continue
            else:
                v = str(v).strip()
            d[f["key"]] = v
        if not d:
            continue
        if not d.get("id") or not d.get("name"):
            issues.append((rn, "ID and name are required"))
            continue
        d["id"] = d["id"].upper()
        out.append(d)
    return out, issues


def write_template(path):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    L = lists()
    hdrfill = PatternFill("solid", fgColor=NAVY)
    sample = {
        "VAT Data": ([h[0] for h in [("Entity ID",), ("VAT period end",), ("Document date",), ("Document no.",), ("Customer / supplier name",), ("Transaction type",),
                                      ("Taxable value excl. VAT (AED)",), ("VAT amount (AED)",), ("Remarks / supporting documents",), ("Customer / supplier TRN",), ("Emirate / place of supply",)]],
                     ["E01", "2026-09-30", "2026-08-15", "INV-0001", "Customer A", "Sale - standard rated", 100000, 5000, "", "", "Dubai"], ("F", "vat_types"), "Emirate"),
    }
    for name, (heads, row, dvspec, _) in sample.items():
        ws = wb.create_sheet(name)
        ws.append(heads)
        ws.append(row)
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = hdrfill
            c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.row_dimensions[1].height = 32
        for i, h in enumerate(heads, 1):
            ws.column_dimensions[get_column_letter(i)].width = max(14, min(34, len(h) + 4))
        ws.freeze_panes = "A2"
        if dvspec:
            col, lk = dvspec
            dv = DataValidation(type="list", formula1='"%s"' % ",".join(L[lk]) if len(",".join(L[lk])) < 250 else None, allow_blank=True)
            if dv.formula1 is None:
                lw = wb.create_sheet("Lists") if "Lists" not in wb.sheetnames else wb["Lists"]
                cidx = lw.max_column + 1 if lw.max_row > 1 or lw["A1"].value else 1
                for k, val in enumerate(L[lk], 1):
                    lw.cell(k, cidx, val)
                dv = DataValidation(type="list", formula1="=Lists!$%s$1:$%s$%d" % (get_column_letter(cidx), get_column_letter(cidx), len(L[lk])), allow_blank=True)
            ws.add_data_validation(dv)
            dv.add("%s2:%s5000" % (col, col))
    # clients sheet
    fields = [f for f in dbm.load_json("fields.json") if not f.get("hidden")]
    ws = wb.create_sheet("Clients", 0)
    ws.append([f["label"] for f in fields if not f["from_upload"]])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = hdrfill; c.alignment = Alignment(wrap_text=True)
    ws.row_dimensions[1].height = 45
    ws.freeze_panes = "C2"
    ws2 = wb.create_sheet("Read me", 0)
    for line in ["VAT-DESK: import template",
                 "Fill one sheet per data type, keep the header row, and use Import data in the app.",
                 "Clients: one row per taxable person (only fields not derived from uploads). Unknown columns are ignored.",
                 "VAT Data: Entity ID must exist in the client list. Dates as DD-MM-YYYY or DD/MM/YYYY.",
                 "Transaction types must match the drop-down list exactly.",
                 "Importing replaces the rows of each entity found in the file (or appends, if you choose that)."]:
        ws2.append([line])
    ws2["A1"].font = Font(bold=True, size=14)
    ws2.column_dimensions["A"].width = 120
    ws2.append(["VAT Data: see the 'VAT box mapping' sheet for where each transaction type goes on the VAT 201."])
    # which transaction type feeds which VAT 201 box
    mp = wb.create_sheet("VAT box mapping", 3)
    mp.append(["Transaction type (VAT Data)", "VAT 201 box", "Column used", "Notes"])
    for c in mp[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = hdrfill; c.alignment = Alignment(wrap_text=True)
    for row in [
        ("Sale - standard rated", "1a to 1g (by Emirate column)", "Taxable value", "Output VAT is computed at the standard rate from the value. Fill the Emirate / place of supply column."),
        ("Sale - zero rated", "4", "Taxable value", ""),
        ("Sale - exempt", "5", "Taxable value", ""),
        ("Sale - designated zone goods", "Not a box", "Taxable value", "Used for the designated zone analysis and ledger reconciliation only."),
        ("Sale - credit note", "1 (adjustment column)", "VAT amount", "Reduces output VAT."),
        ("Bad debt relief", "1 (adjustment column)", "VAT amount", "Reduces output VAT."),
        ("Deemed supply", "1 (adjustment column)", "VAT amount", "Adds to output VAT."),
        ("Tourist refund", "2", "VAT amount", "Deduction from output VAT."),
        ("Purchase - reverse charge", "3 (output) and 10 (input)", "Net value and VAT amount", "Enter the net value and the VAT amount. Box 3 uses the net value you enter; if net is blank or zero it is derived from the VAT (VAT divided by the VAT rate). The same VAT is claimed in box 10 subject to the recovery ratio."),
        ("Import of goods", "6, and 9 (input)", "Taxable value and VAT amount", "Reconcile to customs declarations."),
        ("Import VAT adjustment", "7, and 9 (input)", "VAT amount", ""),
        ("Purchase - standard rated", "9", "VAT amount", "Input VAT, subject to the recovery ratio."),
        ("Purchase - capital asset", "9", "VAT amount", "Input VAT, also tracked as capital assets."),
        ("Purchase - blocked input VAT", "9 (deducted)", "VAT amount", "Not recoverable."),
        ("Purchase - credit note", "9 (deducted)", "VAT amount", "Reduces input VAT."),
        ("Change in use adjustment", "9", "VAT amount", ""),
    ]:
        mp.append(list(row))
    for col, w_ in zip("ABCD", (34, 30, 28, 100)):
        mp.column_dimensions[col].width = w_
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)


# ------------------------------------------------------------------ Excel export
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
HFILL = PatternFill("solid", fgColor=NAVY)
SFILL = PatternFill("solid", fgColor="D9E2F3")
TFILL = PatternFill("solid", fgColor="F2F2F2")
RAG = {"red": "F8CBAD", "amber": "FFE699", "green": "C6E0B4", "grey": "E7E6E6"}
NUM = '#,##0.00;[Red](#,##0.00)'


def _title(ws, title, sub=""):
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=15, color=NAVY)
    if sub:
        ws["A2"] = sub
        ws["A2"].font = Font(italic=True, color="595959")


def _table(ws, r0, heads, rows, widths=None, numcols=(), wrap=()):
    for j, h in enumerate(heads, 1):
        c = ws.cell(r0, j, h)
        c.font = Font(bold=True, color="FFFFFF"); c.fill = HFILL; c.border = BOX
        c.alignment = Alignment(wrap_text=True, vertical="center")
    for i, row in enumerate(rows, r0 + 1):
        for j, v in enumerate(row, 1):
            c = ws.cell(i, j, v)
            c.border = BOX
            if j - 1 in numcols and isinstance(v, (int, float)):
                c.number_format = NUM
            if j - 1 in wrap:
                c.alignment = Alignment(wrap_text=True, vertical="top")
    if widths:
        for j, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(j)].width = w
    return r0 + len(rows) + 1


def _kv(ws, r0, pairs):
    for i, (k, v) in enumerate(pairs, r0):
        a = ws.cell(i, 1, k); a.font = Font(bold=True); a.fill = SFILL; a.border = BOX
        b = ws.cell(i, 2, v); b.border = BOX
        b.alignment = Alignment(horizontal="left")
    return r0 + len(pairs) + 1


def _lines_sheet(ws, lines, r0):
    heads = ["Description", "Box", "Amount (AED)", "VAT (AED)", "Adjustment (AED)", "Basis / note"]
    for j, h in enumerate(heads, 1):
        c = ws.cell(r0, j, h); c.font = Font(bold=True, color="FFFFFF"); c.fill = HFILL; c.border = BOX
    r = r0 + 1
    for l in lines:
        if l["kind"] == "head":
            c = ws.cell(r, 1, l["desc"]); c.font = Font(bold=True, color=NAVY)
            for j in range(1, 7):
                ws.cell(r, j).fill = SFILL
        else:
            vals = [l["desc"], l["box"], l["amount"], l["vat"], l["adj"], l["note"]]
            for j, v in enumerate(vals, 1):
                c = ws.cell(r, j, v); c.border = BOX
                if isinstance(v, (int, float)):
                    c.number_format = NUM
                if l["bold"]:
                    c.font = Font(bold=True)
                    c.fill = TFILL
            ws.cell(r, 1).alignment = Alignment(wrap_text=True, vertical="top")
            ws.cell(r, 6).alignment = Alignment(wrap_text=True, vertical="top")
        r += 1
    for col, w in zip("ABCDEF", (62, 7, 17, 17, 17, 70)):
        ws.column_dimensions[col].width = w
    return r


def entity_bundle(db, eid, res=None, rows=None, default_emirate=None, periods=None):
    """periods: optional (VAT period end, "") to build the return for instead of the client's current period."""
    if periods and periods[0]:
        res, rows = db.compute_period(eid, periods[0] or None, None)
    b = _entity_bundle(db, eid, res, rows, default_emirate)
    from . import recon as RC
    b["recon"] = RC.reconcile(b)
    from . import ftaformat as FF
    b["vat_fta"] = FF.vat201_fta(b["e"], b["v"], b["R"], b["vat201"])
    vpe = db.current_periods(eid)[0]
    if periods and periods[0]:
        vpe = periods[0]
    b["periods"] = (vpe, "")
    b["signoff"] = [db.signoff_get(eid, "VAT", vpe)] if vpe else []
    return b


def _entity_bundle(db, eid, res=None, rows=None, default_emirate=None):
    """Everything needed to render one client's return pack."""
    res = res or db.compute()
    rows = rows or db.rows_by_entity()
    idx = next(i for i, e in enumerate(res["entities"]) if e["id"] == eid)
    e, v, k = res["entities"][idx], res["vat"][idx], res["risk"][idx]
    R = res["R"]
    man = {}
    return dict(
        e=e, v=v, k=k, R=R, today=res["today"],
        vat201=RT.vat201(e, v, R, rows["vat"].get(eid, []), man, default_emirate),
        recon=None, issues=[i for i in res["issues"] if i["id"] == eid], calendar=[d for d in res["calendar"] if d["id"] == eid],
        vat_sched=dbm.load_json("schedules.json")["vat"])


def _kv_pairs(ws, r, pairs, cols=2):
    """Label/value pairs laid out two to a row, as the FTA documents show them."""
    for i in range(0, len(pairs), cols):
        for j, (k, v) in enumerate(pairs[i:i + cols]):
            a = ws.cell(r, 1 + 2 * j, k); a.font = Font(bold=True); a.fill = SFILL; a.border = BOX; a.alignment = Alignment(wrap_text=True, vertical="top")
            c = ws.cell(r, 2 + 2 * j, v); c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top", horizontal="left")
            if isinstance(v, (int, float)):
                c.number_format = NUM
        r += 1
    return r + 1


def fta_vat_sheet(wb, b):
    f, e = b["vat_fta"], b["e"]
    ws = wb.create_sheet("VAT 201 (FTA)")
    _title(ws, f["title"], "Layout of the FTA VAT 201 return document. Working paper, not a filed return.")
    ws.cell(4, 1, "Taxpayer Information").font = Font(bold=True, color=NAVY)
    r = _kv_pairs(ws, 5, f["header"])
    r0, sec = r, None
    for l in f["lines"]:
        if l["section"] != sec:
            sec = l["section"]
            c = ws.cell(r, 1, sec); c.font = Font(bold=True, color=NAVY)
            for j in range(1, 5):
                ws.cell(r, j).fill = SFILL
            r += 1
            if sec != "Net VAT Due":
                for j, h in enumerate(["Description", "Amount (AED)", "VAT Amount (AED)", "Adjustment (AED)"], 1):
                    c = ws.cell(r, j, h); c.font = Font(bold=True, color="FFFFFF"); c.fill = HFILL; c.border = BOX
            else:
                for j, h in enumerate(["Net VAT Due", "Amount (AED)"], 1):
                    c = ws.cell(r, j, h); c.font = Font(bold=True, color="FFFFFF"); c.fill = HFILL; c.border = BOX
            r += 1
        d = ws.cell(r, 1, ("%s %s" % (l["box"], l["desc"])) if l["kind"] != "total" else "%s %s" % (l["box"], l["desc"]))
        d.border = BOX; d.alignment = Alignment(wrap_text=True)
        for j, k in enumerate(("amount", "vat", "adj"), 2):
            c = ws.cell(r, j, l[k]); c.border = BOX
            if isinstance(l[k], (int, float)):
                c.number_format = '#,##0.00;[Red](#,##0.00)'
        if l["bold"]:
            for j in range(1, 5):
                ws.cell(r, j).font = Font(bold=True)
        r += 1
    r += 1
    ws.cell(r, 1, "Profit Margin Scheme").font = Font(bold=True, color=NAVY); r += 1
    r = _kv_pairs(ws, r, [f["margin"]], 1)
    ws.cell(r, 1, "Authorised Signatory").font = Font(bold=True, color=NAVY)
    _kv_pairs(ws, r + 1, f["signatory"])
    for col, w in zip("ABCD", (58, 22, 22, 22)):
        ws.column_dimensions[col].width = w
    ws.column_dimensions["E"].width = 22; ws.column_dimensions["F"].width = 22


def export_fta_periods(db, eid, kind, plist, emirate, path, res=None):
    """One workbook, one sheet per period, in the FTA layout; plist are ISO period ends."""
    from openpyxl import Workbook
    wb = Workbook(); wb.remove(wb.active)
    for p in sorted(plist):
        b = entity_bundle(db, eid, res, None, emirate, (p, None))
        fta_vat_sheet(wb, b)
        wb.worksheets[-1].title = ("%s %s-%s-%s" % (kind, p[8:10], p[5:7], p[0:4]))[:31]
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)
    return path


def export_entity_xlsx(path, b, firm=""):
    e, v, k = b["e"], b["v"], b["k"]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"
    _title(ws, e["name"], "Compliance position as at %s%s" % (Y(b["today"]), ("   |   " + firm) if firm else ""))
    r = _kv(ws, 4, [("Entity ID", e["id"]), ("Location", e.get("location")), ("VAT status", v["vat_status"]), ("VAT period end", v["period_end"]),
                    ("VAT due", v["due"]), ("Net VAT payable / (recoverable)", v["net_vat"]), ("Risk score", "%d (%s)" % (k["risk_score"], k["rag"])), ("Estimated penalty exposure", jr(k["exposure"]))])
    ws.column_dimensions["A"].width = 36; ws.column_dimensions["B"].width = 36
    for row in ws.iter_rows(min_row=4, max_row=r, min_col=2, max_col=2):
        for c_ in row:
            if isinstance(c_.value, (int, float)):
                c_.number_format = NUM
    ws.cell(r + 1, 1, "Open items").font = Font(bold=True, color=NAVY)
    _table(ws, r + 2, ["Area", "Severity", "Issue", "Action"], [[i["area"], i["severity"], i["issue"], i["action"]] for i in b["issues"]], wrap=(2, 3))
    ws.column_dimensions["C"].width = 70; ws.column_dimensions["D"].width = 55
    fta_vat_sheet(wb, b)
    # VAT 201
    ws = wb.create_sheet("VAT 201")
    _title(ws, "VAT return (layout of FTA Form VAT 201)", e["name"])
    r = _kv(ws, 4, b["vat201"]["header"])
    r = _lines_sheet(ws, b["vat201"]["lines"], r)
    ws.cell(r + 1, 1, "Check: net VAT per VAT calculation").font = Font(bold=True); ws.cell(r + 1, 4, b["vat201"]["check_net"]).number_format = NUM
    ws.cell(r + 2, 1, "Difference to box 14").font = Font(bold=True); ws.cell(r + 2, 4, b["vat201"]["diff"]).number_format = NUM
    r = _table(ws, r + 4, ["Ledger reconciliation", "", "Per ledger", "Difference"], [[a, "", bb, cc] for a, bb, cc in b["vat201"]["recon"]], numcols=(2, 3))
    ws.cell(r, 1, "Result: " + str(b["vat201"]["recon_status"])).font = Font(bold=True)
    _sched_sheet(wb, "VAT Schedules", b["vat_sched"], b["vat201"]["sched_flags"], e["name"], ["No.", "Schedule", "Reference", "Needed?"], lambda s: [s["no"], s["name"], s["ref"]])
    # calendar
    ws = wb.create_sheet("Reconciliations")
    _title(ws, "Reconciliations", e["name"])
    rr = _table(ws, 4, ["Area", "Check", "Per ledger", "Per return", "Difference", "Result"],
                [[x["area"], x["check"], x["ledger"], x["ret"], x["diff"], x["status"]] for x in b.get("recon", [])], numcols=(2, 3, 4), wrap=(1,))
    ws.column_dimensions["A"].width = 18; ws.column_dimensions["B"].width = 62
    for col in "CDEF":
        ws.column_dimensions[col].width = 16
    so = b.get("signoff") or []
    if so:
        ws.cell(rr + 1, 1, "Sign-off").font = Font(bold=True, color=NAVY)
        _table(ws, rr + 2, ["Return", "Period end", "Status", "Prepared by", "Reviewed by", "Reviewer note"],
               [[x["kind"], x["period_end"], x["status"], x["prepared_by"], x["reviewed_by"], x["note"]] for x in so], wrap=(5,))
    ws = wb.create_sheet("Calendar")
    _title(ws, "Deadlines", e["name"])
    _table(ws, 3, ["Obligation", "Period end", "Due", "Days left", "Status"],
           [[d["obligation"], d["period_end"], d["due"], d["days_left"], d["status"]] for d in b["calendar"]], widths=(42, 14, 14, 10, 14))
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)


def _sched_sheet(wb, name, sched, flags, ent, heads, pick, purpose=False):
    ws = wb.create_sheet(name)
    _title(ws, name, ent)
    rows = []
    for i, s in enumerate(sched):
        on = i < len(flags) and flags[i] == "1"
        rows.append(pick(s) + ["Required" if on else "Not required"] + ([s["purpose"]] if purpose else []))
    _table(ws, 3, heads, rows, widths=(8, 70, 40, 14, 70))
    ws.cell(len(rows) + 5, 2, "Schedules required in total: %d" % sum(1 for ch in flags if ch == "1")).font = Font(bold=True)
    return ws


def export_portfolio_xlsx(path, res, firm=""):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Client register"
    _title(ws, "Client compliance register", "As at %s%s" % (Y(res["today"]), ("   |   " + firm) if firm else ""))
    rows = []
    for i, e in enumerate(res["entities"]):
        v, k = res["vat"][i], res["risk"][i]
        rows.append([e["id"], e["name"], e.get("location"), v["vat_status"], v["period_end"], v["due"], v["net_vat"], k["risk_score"], k["rag"], jr(k["exposure"])])
    _table(ws, 4, ["ID", "Entity name", "Location", "VAT status", "VAT period end", "VAT due", "Net VAT", "Risk score", "Risk", "Penalty exposure"], rows,
           widths=(7, 34, 15, 20, 13, 13, 14, 10, 9, 15), numcols=(6, 9))
    ws.freeze_panes = "C5"
    ws = wb.create_sheet("Calendar")
    _table(ws, 1, ["ID", "Entity", "Obligation", "Period end", "Due", "Days left", "Status"],
           [[d["id"], d["entity"], d["obligation"], d["period_end"], d["due"], d["days_left"], d["status"]] for d in res["calendar"]], widths=(7, 34, 36, 13, 13, 10, 12))
    ws = wb.create_sheet("Open items")
    _table(ws, 1, ["ID", "Entity", "Area", "Severity", "Issue", "Action"],
           [[i["id"], i["name"], i["area"], i["severity"], i["issue"], i["action"]] for i in res["issues"]], widths=(7, 30, 16, 10, 80, 60), wrap=(4, 5))
    ws = wb.create_sheet("By location")
    _table(ws, 1, ["Scope", "Entities", "Overdue items", "Net VAT", "Penalty exposure", "Average risk", "Red clients"],
           [[z["label"], z["entities"], z["overdue"], z["net_vat"], z["exposure"], z["avg_risk"], z["red_count"]] for z in res["zones"]],
           widths=(20, 10, 14, 15, 16, 13, 12), numcols=(3, 4))
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)


# ------------------------------------------------------------------ PDF export
def export_entity_pdf(path, b, firm=""):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    navy = colors.HexColor("#" + NAVY)
    ss = getSampleStyleSheet()
    H1 = ParagraphStyle("h1", parent=ss["Title"], textColor=navy, fontSize=18, alignment=0, spaceAfter=4)
    H2 = ParagraphStyle("h2", parent=ss["Heading2"], textColor=navy, fontSize=12, spaceBefore=8, spaceAfter=4)
    P = ParagraphStyle("p", parent=ss["BodyText"], fontSize=8, leading=10)
    PB = ParagraphStyle("pb", parent=P, fontName="Helvetica-Bold")
    e = b["e"]

    def fmt(x):
        if x is None or x == "":
            return ""
        if isinstance(x, (int, float)):
            return "{:,.2f}".format(x) if x >= 0 else "({:,.2f})".format(-x)
        return str(x)

    def kv(pairs):
        t = Table([[Paragraph(str(k), PB), Paragraph(fmt(v), P)] for k, v in pairs], colWidths=[55 * mm, 120 * mm])
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#D9E2F3")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t

    def grid(heads, rows, widths, head_rows=(), bold_rows=()):
        data = [[Paragraph(h, ParagraphStyle("hh", parent=PB, textColor=colors.white)) for h in heads]]
        for r in rows:
            data.append([Paragraph(fmt(x), P) for x in r])
        t = Table(data, colWidths=widths, repeatRows=1)
        st = [("BACKGROUND", (0, 0), (-1, 0), navy), ("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("VALIGN", (0, 0), (-1, -1), "TOP")]
        for i in head_rows:
            st += [("BACKGROUND", (0, i + 1), (-1, i + 1), colors.HexColor("#D9E2F3"))]
        for i in bold_rows:
            st += [("BACKGROUND", (0, i + 1), (-1, i + 1), colors.HexColor("#F2F2F2"))]
        t.setStyle(TableStyle(st))
        return t

    def footer(canvas, doc):
        canvas.saveState(); canvas.setFont("Helvetica", 7); canvas.setFillColor(colors.grey)
        canvas.drawString(15 * mm, 8 * mm, "%s | %s | Working paper, not a filed return. Check boxes and thresholds against current FTA guidance." % (firm or "VAT-DESK", e["name"]))
        canvas.drawRightString(195 * mm, 8 * mm, "Page %d" % doc.page)
        canvas.restoreState()

    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=16 * mm, title=e["name"] + " compliance pack")
    S = []
    v, k = b["v"], b["k"]
    S += [Paragraph(e["name"], H1), Paragraph("Tax compliance pack as at %s" % Y(b["today"]), P), Spacer(1, 6)]
    S.append(kv([("Entity ID", e["id"]), ("Location", e.get("location")), ("VAT status", v["vat_status"]), ("VAT period / due", "%s / %s" % (v["period_end"], v["due"])),
                 ("Net VAT payable / (recoverable)", v["net_vat"]),
                 ("Risk", "%d (%s)" % (k["risk_score"], k["rag"])), ("Penalty exposure", jr(k["exposure"]))]))
    S.append(Paragraph("Open items", H2))
    if b["issues"]:
        S.append(grid(["Area", "Severity", "Issue", "Action"], [[i["area"], i["severity"], i["issue"], i["action"]] for i in b["issues"]], [24 * mm, 17 * mm, 80 * mm, 59 * mm]))
    else:
        S.append(Paragraph("No open items.", P))
    if b.get("recon"):
        S.append(Paragraph("Reconciliations", H2))
        S.append(grid(["Area", "Check", "Per ledger", "Per return", "Difference", "Result"],
                      [[x["area"], x["check"], x["ledger"], x["ret"], x["diff"], x["status"]] for x in b["recon"]], [20 * mm, 63 * mm, 22 * mm, 22 * mm, 22 * mm, 26 * mm]))
    if b.get("signoff"):
        S.append(Paragraph("Sign-off", H2))
        S.append(grid(["Return", "Period end", "Status", "Prepared by", "Reviewed by"],
                      [[x["kind"], x["period_end"], x["status"], x["prepared_by"], x["reviewed_by"]] for x in b["signoff"]], [25 * mm, 30 * mm, 30 * mm, 45 * mm, 45 * mm]))
    S.append(PageBreak())
    # FTA format pages
    fv = b["vat_fta"]
    S += [Paragraph(fv["title"], H1), Paragraph("Layout of the FTA VAT 201 return document", P), Spacer(1, 4), Paragraph("Taxpayer Information", H2)]
    S.append(kv(fv["header"]))
    sec, rows_, heads_i, tot_i = None, [], [], []
    def flush():
        if rows_:
            S.append(Paragraph(sec, H2)); S.append(grid(["Description", "Amount (AED)", "VAT Amount (AED)", "Adjustment (AED)"], rows_, [74 * mm, 34 * mm, 34 * mm, 33 * mm], (), tot_i))
    for l in fv["lines"]:
        if l["section"] != sec:
            flush(); sec, rows_, tot_i = l["section"], [], []
        if l["bold"]:
            tot_i.append(len(rows_))
        two = lambda x: "{:,.2f}".format(x) if isinstance(x, (int, float)) else ""
        rows_.append(["%s %s" % (l["box"], l["desc"]), two(l["amount"]), two(l["vat"]), two(l["adj"])])
    flush()
    S += [Paragraph("Profit Margin Scheme", H2), kv([fv["margin"]]), Paragraph("Authorised Signatory", H2), kv(fv["signatory"]), PageBreak()]
    S.append(PageBreak())
    S += [Paragraph("Workings: VAT 201 boxes with basis notes", H1), kv(b["vat201"]["header"]), Spacer(1, 6)]
    rows, heads_i, tot_i = [], [], []
    for i, l in enumerate(b["vat201"]["lines"]):
        rows.append([l["desc"], l["box"], l["amount"], l["vat"], l["adj"]])
        if l["kind"] == "head":
            heads_i.append(i)
        elif l["bold"]:
            tot_i.append(i)
    S.append(grid(["Description", "Box", "Amount", "VAT", "Adjustment"], rows, [86 * mm, 11 * mm, 27 * mm, 27 * mm, 24 * mm], heads_i, tot_i))
    S.append(Paragraph("Reconciliation of ledgers to the return: %s" % b["vat201"]["recon_status"], P))
    S.append(Paragraph("VAT schedules required: %d of 30 (see Excel pack for the list)." % b["vat201"]["schedules_required"], P))
    doc.build(S, onFirstPage=footer, onLaterPages=footer)
