"""The VAT 201 and corporate tax returns laid out as the FTA e-Services return documents show them.

Other compliance work (de minimis and QFZP workings, interest cap, transfer pricing schedules, reconciliations, elections) stays in
core.returns; these builders only reshape figures already calculated there into the FTA layout.
"""
from __future__ import annotations

import calendar
import datetime as dt

from . import engine as E
from .engine import D, Y, jr, n

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def dmy(s):
    d = D(s)
    return d.strftime("%d-%m-%Y") if d else ""


def stagger(period_end, step):
    """(FTA stagger description, tax year end) from the period end month.  Stagger 2 (periods ending Feb, May, Aug, Nov) is as printed on an
    FTA return; Stagger 1 and 3 follow the same pattern."""
    p = D(period_end)
    if not p:
        return "", ""
    if step == 1:
        return "Monthly", dmy(dt.date(p.year, 12, 31))
    m = p.month
    if m % 3 == 0:
        return "Stagger 1 - Quarterly (Jan to Dec)", dmy(dt.date(p.year, 12, 31))
    target = 2 if m % 3 == 2 else 1                     # Stagger 2 ends in February, Stagger 3 in January
    y = p.year if m <= target else p.year + 1
    return ("Stagger 2 - Quarterly (Mar to Feb)" if target == 2 else "Stagger 3 - Quarterly (Feb to Jan)"), dmy(dt.date(y, target, calendar.monthrange(y, target)[1]))


# ------------------------------------------------------------------ VAT 201
# columns shown by the FTA form for each box: (amount, vat, adjustment)
VAT_COLS = {"1a": "AVJ", "1b": "AVJ", "1c": "AVJ", "1d": "AVJ", "1e": "AVJ", "1f": "AVJ", "1g": "AVJ", "2": "AV", "3": "AV", "4": "A", "5": "A", "6": "AV", "7": "AV",
            "8": "AVJ", "9": "AVJ", "10": "AV", "11": "AVJ"}
VAT_TITLES = {"2": "Tax Refunds provided to Tourists under the Tax Refunds for Tourists Scheme", "12": "Total Value of due tax for the period",
              "13": "Total Value of recoverable tax for the period", "14": "Payable tax for the period"}


def vat201_fta(e, v, R, v201):
    """v201 is the dict from returns.vat201."""
    p = D(e.get("vat_period_end"))
    stg, ye = stagger(e.get("vat_period_end"), v["step"])
    start = Y(E.eom(p, -v["step"]) + E.DAY) if p else ""
    header = [("TRN", e.get("vat_trn") or ""), ("VAT Return Period", "%s - %s" % (dmy(start), dmy(p))),
              ("Legal Name of Entity (English)", e.get("name") or ""), ("VAT Stagger", stg),
              ("Legal Name of Entity (Arabic)", e.get("name_ar") or ""), ("VAT Return Due Date", dmy(v["due"])),
              ("Address", ", ".join(x for x in (e.get("address"), e.get("po_box"), e.get("vat_emirate") or "", e.get("landline")) if x)), ("Tax Year End", ye)]
    lines = []
    for l in v201["lines"]:
        if l["kind"] == "head":
            continue
        b = l["box"]
        if b in ("12", "13", "14"):
            lines.append(dict(box=b, desc=VAT_TITLES[b], amount=l["vat"], vat=None, adj=None, bold=b == "14", kind="net"))
            continue
        cols = VAT_COLS[b]
        total = l["kind"] == "total"
        desc = VAT_TITLES.get(b) or l["desc"].replace("Standard rated supplies", "Standard Rated Supplies").replace("Standard rated expenses", "Standard Rated Expenses").replace("Zero rated supplies", "Zero Rated Supplies").replace("Tax refunds", "Tax Refunds").replace("Exempt supplies", "Exempt Supplies").replace(" (input VAT recoverable)", "").replace("Total sales and other outputs", "Totals").replace("Total expenses and other inputs", "Totals")
        lines.append(dict(box=b, desc=desc, amount=(jr(n(l["amount"])) if "A" in cols else None), vat=(jr(n(l["vat"])) if "V" in cols else None),
                          adj=(jr(n(l["adj"])) if "J" in cols else None), bold=total, kind="total" if total else "line"))
    # section break markers: the FTA form groups boxes 1 to 8 and 9 to 11
    for l in lines:
        l["section"] = "VAT on Sales and All Other outputs" if (l["box"].isdigit() and int(l["box"]) <= 8) or l["box"][0] == "1" and not l["box"].isdigit() else (
            "VAT on Expenses and All Other Inputs" if l["box"] in ("9", "10", "11") else "Net VAT Due")
    sig = [("Name in English", e.get("sig_name_en") or ""), ("Name in Arabic", e.get("sig_name_ar") or ""), ("Mobile Number", e.get("sig_mobile") or ""),
           ("Date of Submission", dmy(e.get("vat_sub_date"))), ("Email Address", e.get("sig_email") or "")]
    return dict(title="VAT 201 Return" + (" - %s" % e["vat_ref"] if e.get("vat_ref") else ""), header=header, lines=lines,
                margin=("Did you apply the profit margin scheme in respect of any supplies made during the tax period?", e.get("margin_scheme") or "No"), signatory=sig)


# ------------------------------------------------------------------ Corporate tax return
