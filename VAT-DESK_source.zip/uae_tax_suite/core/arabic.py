"""Arabic text for PDF reports: letter shaping, right-to-left ordering and a font that has the glyphs."""
from __future__ import annotations

import os

from . import db as dbm

AR = {
    "Your UAE tax summary": "ملخص الوضع الضريبي",
    "Where you stand": "موقفك الضريبي",
    "Deadlines": "المواعيد النهائية",
    "What we need from you": "المطلوب منكم",
    "Area": "المجال", "Period": "الفترة", "Position": "الوضع", "Due": "الاستحقاق",
    "Obligation": "الالتزام", "Period end": "نهاية الفترة", "Status": "الحالة", "Penalty so far": "الغرامة حتى الآن",
    "What to do": "الإجراء المطلوب", "Nothing is outstanding.": "لا توجد التزامات معلقة.",
    "Nothing at the moment. Thank you.": "لا شيء حاليا. شكرا لكم.",
    "as at": "كما في", "TRN": "الرقم الضريبي",
    "VAT": "ضريبة القيمة المضافة",
    "Overdue": "متأخر", "Urgent": "عاجل", "Due soon": "يستحق قريبا", "Upcoming": "قادم",
    "Estimates only; the Federal Tax Authority assesses tax and penalties.": "التقديرات استرشادية فقط، والهيئة الاتحادية للضرائب هي التي تحدد الضريبة والغرامات.",
}


def _libs():
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return arabic_reshaper, get_display
    except Exception:
        return None


def available() -> bool:
    return _libs() is not None and os.path.exists(dbm.data_path(os.path.join("fonts", "DejaVuSans.ttf")))


def shape(text: str) -> str:
    """Shaped, visually ordered text ready for a PDF canvas. Returns the text unchanged if the libraries are missing."""
    L = _libs()
    if not L or not text:
        return text or ""
    r, gd = L
    return gd(r.reshape(text))


def ar(key: str) -> str:
    return shape(AR.get(key, ""))


def register_fonts():
    """Register the bundled Arabic-capable font with reportlab. Returns (regular, bold) font names, or Helvetica if unavailable."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    reg, bold = dbm.data_path(os.path.join("fonts", "DejaVuSans.ttf")), dbm.data_path(os.path.join("fonts", "DejaVuSans-Bold.ttf"))
    if not (os.path.exists(reg) and os.path.exists(bold)):
        return "Helvetica", "Helvetica-Bold"
    if "DejaVuSans" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("DejaVuSans", reg))
        pdfmetrics.registerFont(TTFont("DejaVuSans-Bold", bold))
    return "DejaVuSans", "DejaVuSans-Bold"
