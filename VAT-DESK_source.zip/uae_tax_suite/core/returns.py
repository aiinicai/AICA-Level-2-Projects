"""Return builders: VAT 201 boxes, corporate tax return lines, TP disclosure tests, penalty calculators."""
from __future__ import annotations

import datetime as dt

from . import engine as E
from .engine import D, Y, jr, n

EMIRATES = ["Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Umm Al Quwain", "Ras Al Khaimah", "Fujairah"]


def row(desc, box="", amount=None, vat=None, adj=None, note="", bold=False, kind="line", prev=None):
    return dict(desc=desc, box=box, amount=amount, vat=vat, adj=adj, note=note, bold=bold, kind=kind, prev=prev)


def head(title):
    return dict(kind="head", desc=title, box="", amount=None, vat=None, adj=None, note="", bold=True, prev=None)


# ------------------------------------------------------------------ VAT 201
def vat201(e, v, R, vat_rows=None, manual=None, default_emirate=None):
    """e: effective entity, v: vat_calc row, vat_rows: uploaded rows for the entity."""
    manual = manual or {}
    rate = n(R["vat_rate"])
    default_emirate = default_emirate or e.get("vat_emirate") or "Dubai"
    p = D(e.get("vat_period_end"))
    sel = [r for r in (vat_rows or []) if D(r.get("period_end")) == p] if p else []
    reg = v["registered"] == "Yes"
    std_by = {x: 0.0 for x in EMIRATES}
    if sel:
        for r in sel:
            if r["doc_type"] == "Sale - standard rated":
                em = r.get("emirate") if r.get("emirate") in std_by else default_emirate
                std_by[em] += n(r["net"])
    else:
        std_by[default_emirate] += n(e.get("std_supplies"))
    adj_main = jr(-n(e.get("sales_cn_vat")) - n(e.get("bad_debt_vat")) + n(e.get("deemed_supplies_vat")))
    m = lambda k: n(manual.get(k))
    lines = [head("Section 2: VAT on sales and all other outputs")]
    for i, em in enumerate(EMIRATES):
        amt = jr(std_by[em]) if reg else 0
        a = (adj_main if em == default_emirate else 0) + m("1" + "abcdefg"[i])
        lines.append(row("Standard rated supplies in " + em, "1" + "abcdefg"[i], amt, jr(amt * rate), a if reg else 0,
                         "Schedules 1 to 3. Includes credit notes, bad debt relief and deemed supplies in the adjustment (main emirate)." if em == default_emirate else ""))
    rc = v["rc"]
    b2 = -jr(n(e.get("tourist_refund_vat"))) if reg else 0
    b3v = jr(rc)
    # use the actual net value entered on VAT Data; derive from the VAT only if no net was entered
    rc_net = sum(n(r.get("net")) for r in sel if r["doc_type"] == "Purchase - reverse charge")
    b3a = jr(rc_net) if rc_net > 0 else (jr(rc / rate) if rate > 0 else 0)
    b4, b5 = (jr(n(e.get("zero_supplies"))) if reg else 0), (jr(n(e.get("exempt_supplies"))) if reg else 0)
    b6a, b6v = jr(n(e.get("import_goods_value"))) if reg else 0, jr(n(e.get("import_vat"))) if reg else 0
    b7v = jr(n(e.get("import_adjust_vat"))) if reg else 0
    lines += [
        row("Tax refunds provided to tourists under the Tax Refunds for Tourists Scheme", "2", None, b2 + m("2"), None, "Schedule 4. Deduction from output tax."),
        row("Supplies subject to the reverse charge provisions", "3", b3a, b3v + m("3"), None, ("Schedules 5 and 18. Value taken from the net amount entered on VAT Data." if rc_net > 0 else "Schedules 5 and 18. No net value entered, so the value is derived from the reverse charge VAT (VAT / rate).")),
        row("Zero rated supplies", "4", b4, None, None, "Schedules 6 and 19."),
        row("Exempt supplies", "5", b5, None, None, "Schedule 7."),
        row("Goods imported into the UAE", "6", b6a, b6v + m("6"), None, "Schedule 16: reconcile to customs declarations."),
        row("Adjustments to goods imported into the UAE", "7", None, b7v + m("7"), None, "Schedule 17."),
    ]
    out_rows = [x for x in lines if x["kind"] == "line"]
    t_amt = sum(n(x["amount"]) for x in out_rows)
    t_vat = sum(n(x["vat"]) for x in out_rows)
    t_adj = sum(n(x["adj"]) for x in out_rows)
    lines.append(row("Total sales and other outputs", "8", t_amt, t_vat, t_adj, bold=True, kind="total"))
    # inputs
    ratio = v["ratio"]
    base = max(0, n(e.get("input_vat")) - n(e.get("blocked_input_vat")) - n(e.get("purchase_cn_vat")) + n(e.get("change_in_use_vat")) + n(e.get("import_vat")) + n(e.get("import_adjust_vat")))
    b9a = jr(base / rate) if (reg and rate > 0) else 0
    b9v = jr(base * ratio) if reg else 0
    b10v = jr(rc * ratio) if reg else 0
    lines += [head("Section 3: VAT on expenses and all other inputs"),
              row("Standard rated expenses", "9", b9a, b9v, m("9") or 0, "Schedules 9 to 15. Input VAT less blocked VAT and purchase credit notes, plus change-in-use and import VAT, apportioned by the recovery ratio (%.1f%%)." % (ratio * 100)),
              row("Supplies subject to the reverse charge provisions (input VAT recoverable)", "10", b3a, b10v, None, "Schedules 13 and 18.")]
    i_rows = lines[-2:]
    i_amt, i_vat, i_adj = (sum(n(x[k]) for x in i_rows) for k in ("amount", "vat", "adj"))
    lines.append(row("Total expenses and other inputs", "11", i_amt, i_vat, i_adj, bold=True, kind="total"))
    box12 = t_vat + t_adj
    box13 = i_vat + i_adj
    lines += [head("Section 4: Net VAT due"),
              row("Total output tax due for the period", "12", None, box12, None, "Box 8 VAT plus adjustments, including manual adjustments."),
              row("Total recoverable input tax for the period", "13", None, box13, None, "Box 11 VAT plus adjustments."),
              row("Net VAT payable or (recoverable)", "14", None, box12 - box13, None, "Box 12 less box 13. Schedule 29.", bold=True, kind="total")]
    return dict(
        header=[("Taxable person", e.get("name")), ("TRN", e.get("vat_trn") or ""), ("VAT registered", v["registered"]),
                ("Tax period start", Y(E.eom(p, -v["step"]) + dt.timedelta(days=1)) if p else ""), ("Tax period end", Y(p)),
                ("Return and payment due", v["due"]), ("Compliance status", v["vat_status"]), ("Default emirate", default_emirate)],
        lines=lines, box12=box12, box13=box13, net=box12 - box13, check_net=v["net_vat"], diff=jr(box12 - box13 - v["net_vat"]),
        penalty=v["vat_penalty"],
        recon=[("Sales revenue vs the return (schedule 26)", e.get("gl_sales_revenue"), v.get("recon_sales_diff")),
               ("Output VAT account vs total output tax due (schedule 28)", e.get("gl_output_vat"), v.get("recon_output_diff")),
               ("Input VAT account vs gross input VAT (schedule 27)", e.get("gl_input_vat"), v.get("recon_input_diff"))],
        recon_status=v["recon_status"], sched_flags=v["vat_sched_flags"], schedules_required=v["vat_schedules_required"])


# ------------------------------------------------------------------ Corporate tax return
def months_between_part(due: dt.date, paid: dt.date) -> int:
    """Calendar months or part months between two dates (CT basis)."""
    if paid <= due:
        return 0
    return max(1, (paid.year - due.year) * 12 + paid.month - due.month + (1 if paid.day > due.day else 0))


def datedif_m(a: dt.date, b: dt.date) -> int:
    return (b.year - a.year) * 12 + b.month - a.month - (1 if b.day < a.day else 0)


def vat_penalty(R, due, filed, repeat, pay_due, unpaid, paid, req_by, registered, rec_missing, rec_repeat, today):
    d_due, d_filed, d_pd, d_paid = D(due), D(filed) or today, D(pay_due), D(paid) or today
    days = max(0, (d_filed - d_due).days) if d_due else 0
    f = (n(R["vat_late_filing_repeat"]) if repeat else n(R["vat_late_filing_penalty"])) if days > 0 else 0
    months = 0 if (not d_pd or d_paid <= d_pd) else datedif_m(d_pd + E.DAY, d_paid) + 1
    p = jr(n(unpaid) * n(R["vat_late_pay_rate"]) / 12 * months)
    d_req, d_reg = D(req_by), None
    if d_req:
        d_reg = D(registered) or today
    lr = n(R["pen_late_reg"]) if (d_req and d_reg and d_reg > d_req) else 0
    rec = (n(R["pen_records_repeat"]) if rec_repeat else n(R["pen_records_first"])) if rec_missing else 0
    tot = f + p + lr + rec
    return dict(days_late=days, late_filing=f, months=months, late_payment=p, late_registration=lr, records=rec, total=tot, with_tax=tot + n(unpaid))
