"""Excel export of a group return: the FTA layout plus the eliminations behind it."""
from __future__ import annotations

import openpyxl

from . import dataio as DIO


def export(path, kind, group, res, firm=""):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    if True:
        DIO.fta_vat_sheet(wb, dict(e=res["group_entity"], vat_fta=res["fta"]))
        wb["VAT 201 (FTA)"].title = "Group VAT 201 (FTA)"
        ws = wb.create_sheet("Eliminations")
        DIO._title(ws, "Supplies between members left out of the group return", "%s | %s" % (group["name"], firm))
        r = DIO._table(ws, 4, ["Member", "Counterparty member", "Matched by", "Document", "Date", "Party", "Type", "Net (AED)", "VAT (AED)"],
                       [[x["member"], x["counterparty"], x["how"], x["doc_no"], x["doc_date"], x["party"], x["doc_type"], x["net"], x["vat"]] for x in res["eliminations"]],
                       (10, 18, 11, 14, 12, 30, 24, 14, 14), (7, 8))
        ws.cell(r + 1, 1, "Members' net VAT added up: %s. Group net VAT: %s." % ("{:,.2f}".format(res["sum_of_members"]), "{:,.2f}".format(res["net"])))
        ws2 = wb.create_sheet("Members")
        DIO._title(ws2, "Members", group["name"])
        DIO._table(ws2, 4, ["ID", "Name", "Net VAT on its own", "Status"], [[m["id"], m["name"], m["net_vat"], m["vat_status"]] for m in res["members"]], (10, 40, 18, 16), (2,))
    from core.tabexport import dmy_workbook
    dmy_workbook(wb).save(path)
