@echo off
setlocal
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "WORK=C:\uae_build"
title Building VAT-DESK
echo Building. This takes 3 to 8 minutes the first time. Do not close this window.
echo The build runs in a short folder (%WORK%) because Windows fails on very long folder paths.
echo Everything shown here is also saved in build_log.txt next to this file.
echo.
call :main > "%SRC%\build_log.txt" 2>&1
type "%SRC%\build_log.txt"
echo.
if exist "%SRC%\dist\VAT-DESK\VAT-DESK.exe" (
  echo SUCCESS. Your program is in: %SRC%\dist\VAT-DESK
) else (
  echo BUILD FAILED. Read the last lines above, or send build_log.txt to support.
)
echo.
pause
exit /b

:main
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  echo Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" on the first screen of the installer, then run this file again.
  exit /b 1
)
echo Using: %PY%
%PY% --version
if exist "%WORK%\.venv" rmdir /s /q "%WORK%\.venv"
if exist "%WORK%\build" rmdir /s /q "%WORK%\build"
if exist "%WORK%\dist" rmdir /s /q "%WORK%\dist"
robocopy "%SRC%" "%WORK%" /E /XD .venv dist build __pycache__ /XF build_log.txt /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 ( echo Could not copy the project to %WORK%. & exit /b 1 )
cd /d "%WORK%"
%PY% -m venv .venv
if errorlevel 1 ( echo Could not create the virtual environment. & exit /b 1 )
set "VPY=%WORK%\.venv\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 ( echo Package install failed. Check the internet connection. & exit /b 1 )
"%VPY%" tests\test_engine.py
"%VPY%" -m PyInstaller --noconfirm uae_tax_suite.spec
if errorlevel 1 ( echo PyInstaller failed. & exit /b 1 )
robocopy "%WORK%\dist" "%SRC%\dist" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 ( echo Could not copy the finished program back to %SRC%\dist. It is in %WORK%\dist. & exit /b 1 )
exit /b 0
