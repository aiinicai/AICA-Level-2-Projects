"""Web version of the VAT-DESK. Same calculations and database as the desktop app, used from a browser.

Run:  python run_web.py   (see WEB_README.md for office-network and online hosting)
"""
from __future__ import annotations

import datetime as dt
import io
import json
import os
import secrets
import shutil
import sys
import tempfile
import threading

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from flask import Flask, Response, abort, flash, g, redirect, render_template, request, send_file, session, url_for

from core import clientsummary as CS
from core import dataio, filingpack as FP
from core import validate as V
from core import vatgroup as VG
from core import groupexport
from core import db as dbm
from core.db import AuthError, DB, PermissionDenied, ROLES

DATA_DIR = os.environ.get("UAETAX_DATA") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "webdata")
DB_PATH = os.path.join(DATA_DIR, "uae_tax.db")
os.makedirs(DATA_DIR, exist_ok=True)


def _secret():
    p = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(p):
        with open(p, "w") as f:
            f.write(secrets.token_hex(32))
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return open(p).read().strip()


app = Flask(__name__)
app.secret_key = _secret()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=os.environ.get("UAETAX_HTTPS") == "1",
                  PERMANENT_SESSION_LIFETIME=dt.timedelta(hours=12), MAX_CONTENT_LENGTH=30 * 1024 * 1024)
_tl = threading.local()
FIELDS = [f for f in dbm.load_json("fields.json") if not f.get("hidden")]
UPLOADS = [("vat", "VAT data")]


def db() -> DB:
    d = getattr(_tl, "db", None)
    if d is None:
        d = _tl.db = DB(DB_PATH)
    return d


def aed(x, dec=2):
    try:
        return ("{:,.%df}" % dec).format(float(x))
    except (TypeError, ValueError):
        return "" if x is None else str(x)


app.jinja_env.filters["aed"] = aed
from core import tabexport as _TX
def _final(v):
    """Every date the pages print is shown as DD-MM-YYYY (text, date and datetime values)."""
    from markupsafe import Markup
    if isinstance(v, dt.datetime):
        return v.strftime("%d-%m-%Y %H:%M")
    if isinstance(v, dt.date):
        return v.strftime("%d-%m-%Y")
    if isinstance(v, Markup):
        return Markup(_TX.dmy_text(str(v)))
    return _TX.dmy_text(v) if isinstance(v, str) else v


app.jinja_env.finalize = _final


@app.before_request
def _auth():
    d = db(); d.user = None
    if request.endpoint in ("static", "healthz"):
        return
    if request.method == "POST":
        if not secrets.compare_digest(request.form.get("_csrf", ""), session.get("csrf", "x")):
            abort(400, "The form expired. Go back, refresh the page and try again.")
    if not d.has_users():
        if request.endpoint != "setup":
            return redirect(url_for("setup"))
        return
    u = session.get("user")
    if u:
        r = d.c.execute("SELECT * FROM users WHERE username=? AND active=1", (u,)).fetchone()
        if r:
            d.user = dict(id=r["id"], username=r["username"], display_name=r["display_name"], role=r["role"], must_change=bool(r["must_change"]))
        else:
            session.clear()
    if not d.user and request.endpoint not in ("login", "setup"):
        return redirect(url_for("login", next=request.path))
    if d.user and d.user["must_change"] and request.endpoint not in ("password", "logout"):
        return redirect(url_for("password"))


@app.context_processor
def _ctx():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    d = db()
    return dict(csrf=session["csrf"], user=d.user, firm=d.setting("firm", "") if d.user else "", can_edit=d.can_edit() if d.user else False,
                is_admin=(d.role() == "Admin") if d.user else False, UPLOADS=UPLOADS)


@app.errorhandler(PermissionDenied)
def _denied(e):
    flash(str(e), "err")
    return redirect(request.referrer or url_for("dashboard"))


@app.errorhandler(400)
def _bad(e):
    return render_template("error.html", msg=getattr(e, "description", "Bad request")), 400


def need_admin():
    if db().role() != "Admin":
        abort(403)


def client_or_404(eid):
    if eid not in {e["id"] for e in db().entities()}:
        abort(404)
    return eid


def send_bytes(data, name, mime):
    return send_file(io.BytesIO(data), as_attachment=True, download_name=name, mimetype=mime)


def build_file(fn, suffix, *a, **k):
    tmp = tempfile.mkdtemp()
    try:
        p = os.path.join(tmp, "out" + suffix)
        fn(p, *a, **k)
        return open(p, "rb").read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


# ---------------------------------------------------------------- sign in
@app.route("/setup", methods=["GET", "POST"])
def setup():
    d = db()
    if d.has_users():
        return redirect(url_for("login"))
    if request.method == "POST":
        try:
            if request.form["password"] != request.form["password2"]:
                raise ValueError("The two passwords do not match.")
            d.create_user(request.form["username"], request.form["password"], "Admin", request.form.get("display_name", ""))
            d.set_setting("firm", request.form.get("firm", "").strip())
            flash("Administrator created. Sign in.", "ok")
            return redirect(url_for("login"))
        except ValueError as e:
            flash(str(e), "err")
    return render_template("setup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    d = db()
    if request.method == "POST":
        try:
            u = d.login(request.form["username"], request.form["password"])
            session.clear(); session.permanent = True; session["user"] = u["username"]; session["csrf"] = secrets.token_hex(16)
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
        except AuthError as e:
            flash(str(e), "err")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    db().logout(); session.clear()
    return redirect(url_for("login"))


@app.route("/password", methods=["GET", "POST"])
def password():
    d = db()
    if request.method == "POST":
        try:
            if not d.verify_password(d.user["username"], request.form["old"]):
                raise ValueError("The current password is wrong.")
            if request.form["new"] != request.form["new2"]:
                raise ValueError("The two new passwords do not match.")
            d.change_password(d.user["username"], request.form["new"])
            flash("Password changed.", "ok")
            return redirect(url_for("dashboard"))
        except ValueError as e:
            flash(str(e), "err")
    return render_template("password.html")


# ---------------------------------------------------------------- dashboard and calendar
@app.route("/")
def dashboard():
    r = db().compute()
    z = next(x for x in r["zones"] if x["scope"] == "all")
    return render_template("dashboard.html", r=r, z=z)


@app.route("/calendar")
def calendar():
    r = db().compute()
    from core import deadlines as DL
    return render_template("calendar.html", rows=DL.enrich(r), issues=r["issues"], status=DL.status_line(r))


@app.route("/calendar.ics")
def calendar_ics():
    from core import deadlines as DL
    rows = [x for x in DL.enrich(db().compute()) if x["days_left"] is not None and x["days_left"] > -400]
    return Response(DL.to_ics(rows), mimetype="text/calendar", headers={"Content-Disposition": "attachment; filename=tax_deadlines.ics"})


# ---------------------------------------------------------------- clients
def parse_fields(form):
    out, errs = {}, []
    for f in FIELDS:
        txt = (form.get("f_" + f["key"], "") or "").strip()
        if txt == "":
            continue
        if f["kind"] == "date":
            v = dataio.parse_date(txt)
            if str(v).startswith("?"):
                errs.append("%s: use DD-MM-YYYY" % f["label"]); continue
            out[f["key"]] = v
        elif f["kind"] in ("number", "percent"):
            v = dataio.parse_num(txt.rstrip("%"))
            if isinstance(v, str):
                errs.append("%s: not a number" % f["label"]); continue
            out[f["key"]] = v / 100 if (f["kind"] == "percent" and txt.endswith("%")) else v
        else:
            out[f["key"]] = txt
    return out, errs


def pretty(f, v):
    if v in (None, ""):
        return ""
    if f["kind"] == "percent":
        return ("%.4f" % (float(v) * 100)).rstrip("0").rstrip(".") + "%"
    if f["kind"] == "number":
        return "{:,.2f}".format(float(v))
    return str(v)


@app.route("/clients")
def clients():
    r = db().compute()
    q = request.args.get("q", "").lower()
    q = q.strip()
    rows = [k for k in r["risk"] if not q or q in str(k["id"]).lower() or q in str(k["name"]).lower()]
    return render_template("clients.html", rows=rows, q=q)


@app.route("/clients/new", methods=["GET", "POST"])
@app.route("/clients/<eid>/edit", methods=["GET", "POST"])
def client_edit(eid=None):
    d = db()
    ent = {}
    if eid:
        client_or_404(eid); ent = d.entity(eid)
    elif request.method == "GET":
        ent = {"id": d.next_entity_id()}
    if request.method == "POST":
        out, errs = parse_fields(request.form)
        if eid:
            out["id"] = eid
        out["id"] = (out.get("id") or "").upper()
        if not eid and d.entity(out["id"]):
            errs.append("That ID already exists.")
        if errs:
            for e in errs[:10]:
                flash(e, "err")
            ent = dict(out)
        else:
            d.save_entity(out)
            flash("Client saved.", "ok")
            return redirect(url_for("client", eid=out["id"]))
    sections = []
    for f in FIELDS:
        if not sections or sections[-1][0] != f["section"]:
            sections.append((f["section"], []))
        sections[-1][1].append(dict(f, value=pretty(f, ent.get(f["key"]))))
    return render_template("client_form.html", sections=sections, eid=eid)


@app.route("/clients/<eid>")
def client(eid):
    d = db(); client_or_404(eid)
    tab = request.args.get("tab", "summary")
    res = d.compute()
    b = dataio.entity_bundle(d, eid, res)
    vpe = d.current_periods(eid)[0]
    pbar = None
    if tab == "vat":
        pbar = period_bar(d, eid, "VAT")
        if pbar["selected"]:
            b = dataio.entity_bundle(d, eid, None, None, None, (pbar["selected"], None))
    so = [d.signoff_get(eid, "VAT", vpe) if vpe else None]
    counts = {k: len(d.rows(k, eid)) for k, _ in UPLOADS}
    return render_template("client.html", b=b, tab=tab, so=[s for s in so if s], counts=counts, hist=d.signoff_history(eid, 20),
                           readiness=FP.readiness(d, b) if tab == "pack" else None, FPmod=FP, pbar=pbar)


def period_bar(d, eid, kind):
    """From / To range, the periods inside it, and the one picked (defaults to the current period if it is in range)."""
    from fta_assistant import saved
    allp = sorted(saved.periods(d, eid, kind), reverse=True)
    a, b_ = _TX.to_iso(request.args.get("from", "")), _TX.to_iso(request.args.get("to", ""))
    if a and b_ and a > b_:
        a, b_ = b_, a
    inr = [p for p in allp if (not a or p >= a) and (not b_ or p <= b_)]
    cur = d.current_periods(eid)[0]
    sel = _TX.to_iso(request.args.get("p", ""))
    if sel not in inr:
        sel = cur if cur in inr else (inr[0] if inr else "")
    return dict(kind=kind, all=allp, periods=inr, selected=sel, current=cur, frm=a, to=b_)


@app.route("/clients/<eid>/export/fta/<kind>")
def client_export_fta(eid, kind):
    """Excel of the picked period, or (all=1) of every period inside the From/To range - one sheet per period."""
    d = db(); client_or_404(eid)
    kind = kind.upper()
    if kind != "VAT":
        abort(404)
    pb = period_bar(d, eid, kind)
    plist = pb["periods"] if request.args.get("all") == "1" else ([pb["selected"]] if pb["selected"] else [])
    if not plist:
        abort(404)
    em = d.setting("default_emirate", "Dubai")
    d.audit("export.fta_periods", eid, "web")
    nm = "%s_%s_%s.xlsx" % (eid, kind, plist[0] if len(plist) == 1 else "%s_to_%s" % (plist[-1], plist[0]))
    return send_bytes(build_file(lambda p: dataio.export_fta_periods(d, eid, kind, plist, em, p, d.compute()), ".xlsx"), nm, XLSX)


@app.route("/export/table", methods=["POST"])
def export_table():
    """Excel / PDF of whatever the page shows: the browser posts the tables it displays as JSON."""
    import json
    try:
        data = json.loads(request.form.get("payload", "{}"))
    except ValueError:
        abort(400)
    title = str(data.get("title") or "VAT-DESK")[:80]
    blocks = []
    for b in data.get("blocks", [])[:200]:
        if "header" in b:
            blocks.append(dict(title=str(b.get("title", ""))[:120], header=[str(x) for x in b["header"]][:60], rows=[[str(x) for x in r][:60] for r in b.get("rows", [])[:20000]]))
        elif "text" in b:
            blocks.append(dict(title=str(b.get("title", ""))[:120], text=str(b["text"])[:20000]))
    kind = request.form.get("kind", "xlsx")
    safe = "".join(c if c.isalnum() else "_" for c in title).strip("_") or "export"
    stamp = dt.date.today().strftime("%d-%m-%Y")
    if kind == "pdf":
        return send_bytes(build_file(lambda p: _TX.to_pdf(p, title, blocks, "Exported on " + stamp), ".pdf"), "VAT-DESK_%s_%s.pdf" % (safe, stamp), "application/pdf")
    return send_bytes(build_file(lambda p: _TX.to_xlsx(p, title, blocks, "Exported on " + stamp), ".xlsx"), "VAT-DESK_%s_%s.xlsx" % (safe, stamp), XLSX)


@app.route("/clients/<eid>/export/<what>")
def client_export(eid, what):
    d = db(); client_or_404(eid)
    res = d.compute(); b = dataio.entity_bundle(d, eid, res); firm = d.setting("firm", "")
    d.audit("export." + what, eid, "web")
    if what == "xlsx":
        return send_bytes(build_file(dataio.export_entity_xlsx, ".xlsx", b, firm), "%s_tax_pack.xlsx" % eid, XLSX)
    if what == "pdf":
        return send_bytes(build_file(dataio.export_entity_pdf, ".pdf", b, firm), "%s_tax_pack.pdf" % eid, "application/pdf")
    if what == "summary":
        return send_bytes(build_file(lambda p: CS.pdf(p, CS.build(res, eid, firm), arabic=request.args.get("ar", "1") == "1"), ".pdf"), "%s_client_summary.pdf" % eid, "application/pdf")
    if what == "pack":
        return send_bytes(build_file(lambda p: FP.build_zip(p, d, b, firm), ".zip"), "%s_filing_pack.zip" % eid, "application/zip")
    abort(404)


@app.route("/clients/<eid>/signoff", methods=["POST"])
def client_signoff(eid):
    d = db(); client_or_404(eid)
    kind, pe, act, note = request.form["kind"], _TX.to_iso(request.form["period_end"]), request.form["action"], request.form.get("note", "")
    try:
        if act == "submit":
            d.signoff_submit(eid, kind, pe, note)
        elif act == "approve":
            d.signoff_approve(eid, kind, pe, note)
        elif act == "return":
            d.signoff_return(eid, kind, pe, note)
        elif act == "reopen":
            d.signoff_reopen(eid, kind, pe, note)
        flash("Done.", "ok")
    except (ValueError, PermissionDenied) as e:
        flash(str(e), "err")
    return redirect(url_for("client", eid=eid, tab="workflow"))


@app.route("/clients/<eid>/delete", methods=["POST"])
def client_delete(eid):
    need_admin(); client_or_404(eid)
    if request.form.get("confirm", "").upper() != eid:
        flash("Type the client ID to confirm deletion.", "err")
        return redirect(url_for("client", eid=eid))
    db().delete_entity(eid)
    flash("Client deleted.", "ok")
    return redirect(url_for("clients"))


# ---------------------------------------------------------------- uploads
@app.route("/data", methods=["GET", "POST"])
def data():
    d = db(); result = None
    if request.method == "POST":
        d.need_edit()
        f = request.files.get("file"); kind = request.form.get("kind", "")
        if not f or not f.filename:
            flash("Choose a file.", "err")
        else:
            tmp = tempfile.mkdtemp()
            try:
                p = os.path.join(tmp, "".join(ch for ch in os.path.basename(f.filename) if ch.isalnum() or ch in "._- ") or "upload.xlsx")
                f.save(p)
                if kind == "clients":
                    rows, issues = dataio.read_entities(p)
                    n = 0
                    for r in rows:
                        try:
                            old = d.entity(r["id"]); d.save_entity(dict(old, **r) if old else r); n += 1
                        except (ValueError, PermissionDenied) as e:
                            issues.append((0, "%s: %s" % (r["id"], e)))
                    result = dict(imported=n, entities=[r["id"] for r in rows], issues=issues, blocked=False, validation={})
                elif kind in dict(UPLOADS):
                    result = dataio.import_upload(d, p, kind, request.form.get("mode", "replace"), force=request.form.get("force") == "1")
                    result["errs"] = {k: V.summary(v) for k, v in (result.get("validation") or {}).items()}
                    result["detail"] = {k: [x for x in v if x.get("severity") == "Error"][:15] for k, v in (result.get("validation") or {}).items()} if result.get("blocked") else {}
                    d.audit("upload." + kind, ",".join(result.get("entities", [])), "web: %s" % f.filename)
                else:
                    flash("Unknown upload type.", "err")
            except Exception as e:
                flash("Could not read the file: %s" % e, "err")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
    return render_template("data.html", result=result, kinds=UPLOADS + [("clients", "Client list")])


@app.route("/template.xlsx")
def template():
    return send_bytes(build_file(dataio.write_template, ".xlsx"), "VAT-DESK_Import_Template.xlsx", XLSX)


# ---------------------------------------------------------------- tax groups
def group_or_404(gid):
    g_ = next((x for x in db().vat_groups() if x["group_id"] == gid), None)
    if not g_:
        abort(404)
    return g_


@app.route("/groups")
def groups():
    d = db()
    return render_template("groups.html", vat=d.vat_groups("VAT"), ents=d.entities())


@app.route("/groups/save", methods=["POST"])
def group_save():
    d = db()
    members = request.form.getlist("members")
    rep = request.form.get("rep", "")
    try:
        d.vat_group_save(request.form["group_id"].strip().upper(), request.form["name"].strip(), request.form.get("trn", "").strip(), rep, members, "VAT")
        flash("Group saved.", "ok")
        return redirect(url_for("group", gid=request.form["group_id"].strip().upper()))
    except (ValueError, PermissionDenied) as e:
        flash(str(e), "err")
        return redirect(url_for("groups"))


def group_result(g_):
    d = db()
    try:
        return VG.consolidate(d, g_, d.setting("default_emirate", "Dubai")), None
    except VG.GroupError as e:
        return None, str(e)


@app.route("/groups/<gid>")
def group(gid):
    g_ = group_or_404(gid)
    res, err = group_result(g_)
    return render_template("group.html", g=g_, r=res, err=err, tab=request.args.get("tab", "summary"),
                           ents={e["id"]: e["name"] for e in db().entities()})


@app.route("/groups/<gid>/export")
def group_export(gid):
    g_ = group_or_404(gid)
    res, err = group_result(g_)
    if err:
        flash(err, "err"); return redirect(url_for("group", gid=gid))
    db().audit("export.group", gid, "web")
    return send_bytes(build_file(groupexport.export, ".xlsx", "VAT", g_, res, db().setting("firm", "")), "group_vat_%s.xlsx" % gid, XLSX)


@app.route("/groups/<gid>/delete", methods=["POST"])
def group_delete(gid):
    group_or_404(gid)
    try:
        db().vat_group_delete(gid); flash("Group deleted.", "ok")
    except (ValueError, PermissionDenied) as e:
        flash(str(e), "err")
    return redirect(url_for("groups"))


# ---------------------------------------------------------------- administration
@app.route("/admin", methods=["GET", "POST"])
def admin():
    need_admin(); d = db()
    if request.method == "POST":
        act = request.form["action"]
        try:
            if act == "create":
                d.create_user(request.form["username"], request.form["password"], request.form["role"], request.form.get("display_name", ""), must_change=True, actor=d.user["username"])
            elif act == "update":
                d.update_user(request.form["username"], role=request.form["role"], active=request.form.get("active") == "1", display_name=request.form.get("display_name"))
                d.assign_clients(request.form["username"], [x.strip().upper() for x in request.form.get("clients", "").replace(";", ",").split(",") if x.strip()])
            elif act == "reset":
                d.change_password(request.form["username"], request.form["password"], actor=d.user["username"])
                d.c.execute("UPDATE users SET must_change=1 WHERE username=?", (request.form["username"],)); d.c.commit()
            elif act == "firm":
                d.set_setting("firm", request.form["firm"].strip())
            elif act == "selfapprove":
                d.set_setting("allow_self_approval", "Yes" if request.form.get("on") == "1" else "No")
            flash("Saved.", "ok")
        except (ValueError, PermissionDenied) as e:
            flash(str(e), "err")
        return redirect(url_for("admin"))
    users = d.list_users()
    for u in users:
        u["clients"] = ", ".join(d.client_assignments(u["username"]))
    return render_template("admin.html", users=users, roles=ROLES, selfapp=d.self_approval_allowed(), audit=d.audit_log(60), rules=d.rules(), review=d.rules_review_age())


@app.route("/admin/backup")
def backup():
    need_admin(); d = db()
    data_ = build_file(lambda p: d.backup_to(p), ".db")
    d.audit("backup.download", "", "web")
    return send_bytes(data_, "vat-desk_backup_%s.db" % dt.date.today().isoformat(), "application/octet-stream")


@app.route("/healthz")
def healthz():
    return "ok"
