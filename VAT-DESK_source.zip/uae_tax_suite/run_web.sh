#!/bin/sh
cd "$(dirname "$0")"
[ -d .venv-web ] || { python3 -m venv .venv-web && .venv-web/bin/pip install -r requirements-web.txt; }
exec .venv-web/bin/python run_web.py --host 0.0.0.0 --port "${PORT:-8080}"
