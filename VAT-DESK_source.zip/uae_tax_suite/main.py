"""VAT-DESK: entry point."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import QApplication, QFileDialog, QMessageBox

from core.db import DB
from ui.common import STYLE
from ui.login import LoginDialog, PasswordDialog
from ui.main_window import MainWindow


def config_path():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    d = os.path.join(base, "UAETaxSuite")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "config.json")


def load_cfg():
    try:
        with open(config_path()) as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(c):
    with open(config_path(), "w") as f:
        json.dump(c, f)


def default_db_path():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, "UAETaxSuite")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "uae_tax.db")


def main():
    app = QApplication(sys.argv)
    from ui.dates import install_display; install_display()
    app.setStyleSheet(STYLE)
    app.setApplicationName("VAT-DESK")
    cfg = load_cfg()
    path = os.environ.get("UAE_TAX_DB") or cfg.get("db") or default_db_path()
    while True:
        try:
            db = DB(path)
        except Exception as e:
            QMessageBox.critical(None, "Database", "Cannot open the database:\n%s\n\n%s" % (path, e))
            return 1
        dlg = LoginDialog(db, path, change_db_cb=True)
        if not dlg.exec():
            if dlg.switch_db:
                p, _ = QFileDialog.getSaveFileName(None, "Choose or create the database file (a shared network folder lets a team use one database)", path,
                                                   "Database (*.db)", options=QFileDialog.Option.DontConfirmOverwrite)
                if p:
                    path = p
                    cfg["db"] = p
                    save_cfg(cfg)
                db.close()
                continue
            return 0
        if db.user.get("must_change"):
            if not PasswordDialog(db, db.user["username"], forced=True).exec():
                return 0
        w = MainWindow(db)
        w.show()
        app.exec()
        if not w.signed_out:
            return 0
        db.close()


if __name__ == "__main__":
    sys.exit(main())
