"""Template reader and review-pack generator. Never connects to or submits to the FTA."""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
import csv, hashlib, html, json, re, zipfile
from io import StringIO
from openpyxl import load_workbook

EMARATAX_URL = "https://eservices.tax.gov.ae/"
VAT_BOXES = {"1a","1b","1c","1d","1e","1f","1g", "2","3","4","5","6","7","8","9","10","11","12","13","14"}

def dec(v):
    if v is None or v == "": return None
    try: return Decimal(str(v).replace(",", "")).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError): return None

def parse_template(path, kind):
    path = Path(path)
    if kind != "VAT": raise ValueError("Type must be VAT")
    if path.suffix.lower() != ".xlsx": raise ValueError("An .xlsx return template is required")
    if path.stat().st_size > 15_000_000: raise ValueError("File exceeds 15MB safety limit")
    book = load_workbook(path, data_only=True, read_only=True)
    records, metadata, warnings, errors = [], {}, [], []
    if kind == "VAT":
        if "VAT 201 Return" not in book.sheetnames: errors.append("Missing 'VAT 201 Return' worksheet")
        else:
            ws = book["VAT 201 Return"]
            for row in ws.iter_rows(min_row=6, max_col=5, values_only=True):
                box = str(row[0]).strip() if row[0] is not None else ""
                if box not in VAT_BOXES: continue
                records.append({"section":"VAT201", "field":box, "description":str(row[1] or ""),
                                "amount":str(dec(row[2])) if dec(row[2]) is not None else "",
                                "tax":str(dec(row[3])) if dec(row[3]) is not None else "",
                                "adjustment":str(dec(row[4])) if dec(row[4]) is not None else ""})
            missing=VAT_BOXES-set(r["field"] for r in records)
            if missing: errors.append("Missing VAT boxes: "+", ".join(sorted(missing)))
            header=str(ws['A2'].value or '')
            htrn=re.search(r"\b\d{15}\b", header)
            if htrn: metadata['heading_trn']=htrn.group()
            metadata['heading']=header
            metadata['period_header']=str(ws['A3'].value or '')
            vals={r['field']:r for r in records}
            def number(box,col): return dec(vals.get(box,{}).get(col)) or Decimal(0)
            def check(label, observed, calculated):
                if abs(observed-calculated)>Decimal('0.02'): errors.append(label+f": reported {observed}, calculated {calculated}")
            output=["1a","1b","1c","1d","1e","1f","1g","2","3","4","5","6","7"]
            for col in ('amount','tax','adjustment'):
                check('Box 8 '+col,number('8',col),sum((number(b,col) for b in output), Decimal(0)))
                check('Box 11 '+col,number('11',col),number('9',col)+number('10',col))
            check('Box 14 payable',number('14','amount') or number('14','tax'),(number('12','amount') or number('12','tax'))-(number('13','amount') or number('13','tax')))
        if 'Taxpayer and Filing' in book.sheetnames:
            for row in book['Taxpayer and Filing'].iter_rows(min_row=4,max_col=2,values_only=True):
                k=str(row[0] or '').strip(); v=row[1]
                if k and v is not None: metadata[k]=str(v)
            detail_trn=re.search(r'\b\d{15}\b',metadata.get('TRN',''))
            if detail_trn and metadata.get('heading_trn') and detail_trn.group()!=metadata['heading_trn']:
                errors.append('TRN MISMATCH: VAT heading and Taxpayer and Filing sheet differ')
        else: warnings.append('Taxpayer and Filing sheet not found; verify taxpayer/period manually')
        if 'Total Checks' in book.sheetnames:
            for row in book['Total Checks'].iter_rows(min_row=6,max_col=5,values_only=True):
                if len(row)>4 and str(row[4] or '').strip().upper() not in ('','PASS'):
                    errors.append('Source reconciliation failed: '+str(row[0]))
        if 'Date of submission' in metadata or 'Return reference' in metadata:
            warnings.append('VAT source looks like an already-filed return: do not refile without confirmation')
    book.close()
    warnings.append('Human authorization, FTA authentication, portal review, and final submission are mandatory. This module never submits.')
    return {'type':kind,'source_filename':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'created_utc':datetime.now(timezone.utc).isoformat(),'metadata':metadata,
            'records':records,'errors':errors,'warnings':warnings,'ready_for_review':not errors}

def build_pack(parsed, destination):
    dest=Path(destination)
    if dest.suffix.lower()!='.zip': raise ValueError('Output must be ZIP')
    columns=['section','field','value'] if parsed.get('field_mapping') else (['section','field','description','amount','tax','adjustment'])
    csvfile=StringIO(); writer=csv.DictWriter(csvfile, fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(parsed['records'])
    def esc(x): return html.escape(str(x))
    rows=''.join('<tr>'+''.join('<td>'+esc(r.get(k,''))+'</td>' for k in columns)+'</tr>' for r in parsed['records'])
    notes=''.join('<li>'+esc(x)+'</li>' for x in parsed['errors']+parsed['warnings'])
    report="""<!doctype html><html><head><meta charset="utf-8"><title>FTA filing review</title>
<style>body{font:14px Arial;margin:38px;color:#163047}table{border-collapse:collapse;width:100%}td,th{border:1px solid #c9d7e0;padding:6px;text-align:left}th{background:#e8f3f6}li{margin:6px}h1{color:#087c91}footer{margin-top:24px;color:#6b7280}</style></head><body>"""
    report+='<h1>'+esc(parsed['type'])+' Filing Review Pack</h1><p><b>Source:</b> '+esc(parsed['source_filename'])+'</p><p><b>SHA256:</b> '+esc(parsed['sha256'])+'</p>'
    report+='<h2>Review items</h2><ul>'+notes+'</ul><h2>Extracted source fields</h2><table><tr>'+''.join('<th>'+esc(k)+'</th>' for k in columns)+'</tr>'+rows+'</table>'
    report+='<footer>PREPARATION ONLY — not submitted to FTA. Confirm all amounts in EmaraTax before manual filing.</footer></body></html>'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('review.html',report)
        z.writestr('fields.csv',csvfile.getvalue().encode('utf-8-sig'))
        z.writestr('validation.json',json.dumps(parsed,indent=2,ensure_ascii=False))
        z.writestr('READ_ME.txt','This pack is NOT an FTA submission. Log in to EmaraTax, verify all fields, and submit manually.\n')
    return dest
