"""Read saved database inputs or immutable return snapshots. Fetch never writes."""
import hashlib
import json
import re
from datetime import datetime, timezone
from core import dataio


def visible(db, eid):
    if eid not in {e['id'] for e in db.entities()}:
        raise PermissionError('Client is unavailable to this user')


def save(db, eid, emirate=None, periods=None, kinds=('VAT',)):
    db.need_edit()
    visible(db, eid)
    b = dataio.entity_bundle(db, eid, default_emirate=emirate, periods=periods)
    for kind, period in zip(('VAT',), b['periods']):
        if kind not in kinds:
            continue
        if not period:
            continue
        result = from_bundle(db, eid, kind, period, b)
        db.c.execute('INSERT INTO filing_snapshots(entity_id,kind,period_end,saved_at,saved_by,payload) VALUES(?,?,?,?,?,?)',
                     (eid, kind, period, result['created_utc'], db.user['username'], json.dumps(result)))
    db.c.commit()
    db.audit('return.snapshot', eid, 'Saved detailed VAT return fields')


def period_status(db, eid, kind):
    """{period end: 'Saved' (a frozen snapshot exists), 'From data' (rows exist but nothing saved yet)}, newest first as a list of pairs."""
    visible(db, eid)
    snap = {r[0] for r in db.c.execute('SELECT DISTINCT period_end FROM filing_snapshots WHERE entity_id=? AND kind=?', (eid, kind))}
    data = {str(r[0])[:10] for r in db.c.execute('SELECT DISTINCT period_end FROM vat_rows WHERE entity_id=?', (eid,)) if r[0]}
    current = db.current_periods(eid)[0]
    allp = snap | data | ({current} if current else set())
    return [(p, 'Saved' if p in snap else 'From data') for p in sorted(allp, reverse=True)]


def history(db, eid, kind):
    """One row per period (newest first): period, record ('Saved' or 'From data'), saved_at, saved_by, versions, approval status."""
    visible(db, eid)
    snaps = {}
    for r in db.c.execute('SELECT period_end, saved_at, saved_by FROM filing_snapshots WHERE entity_id=? AND kind=? ORDER BY id', (eid, kind)):
        s = snaps.setdefault(r['period_end'], dict(n=0))
        s.update(saved_at=r['saved_at'], saved_by=r['saved_by']); s['n'] += 1
    out = []
    for p, st in period_status(db, eid, kind):
        s = snaps.get(p, {})
        out.append(dict(period=p, record=st, saved_at=str(s.get('saved_at', ''))[:16].replace('T', ' '), saved_by=s.get('saved_by', ''), versions=s.get('n', 0),
                        approval=db.signoff_get(eid, kind, p)['status']))
    return out


def detail_rows(kind, result):
    """Turn the stored field list into display rows: (section, description, value1, value2, value3) and the three column headings."""
    heads = ('Amount (AED)', 'VAT (AED)', 'Adjustment (AED)')
    cols = {'amount': 0, 'vat': 1, 'adj': 2}
    order, rows = [], {}
    for rec in result['records']:
        parts = rec['field'].split(' | ')
        if kind == 'VAT' and len(parts) == 3 and parts[2] in cols:
            key, col = (rec['section'], parts[0] + '  ' + parts[1]), cols[parts[2]]
        else:
            key, col = (rec['section'], rec['field']), 0
        if key not in rows:
            rows[key] = ['', '', '']; order.append(key)
        rows[key][col] = rec['value']
    return heads, [(k[0], k[1]) + tuple(rows[k]) for k in order]


def periods(db, eid, kind):
    return [p for p, _ in period_status(db, eid, kind)]


def fetch(db, eid, kind, period):
    visible(db, eid)
    if kind != 'VAT' or period not in periods(db, eid, kind):
        raise ValueError('No saved return for the selected client/type/period')
    row = db.c.execute('SELECT id,payload,saved_at,saved_by FROM filing_snapshots WHERE entity_id=? AND kind=? AND period_end=? ORDER BY id DESC LIMIT 1', (eid, kind, period)).fetchone()
    if row:
        result = json.loads(row['payload'])
        result['metadata'].update(snapshot_version=row['id'], saved_at=row['saved_at'], saved_by=row['saved_by'])
        result['metadata']['current_approval_status'] = db.signoff_get(eid, kind, period)['status']
        result['warnings'].append('Saved snapshot: later input edits are not included until Returns and workings saves a new snapshot.')
        result['sha256'] = hashlib.sha256(json.dumps({k: v for k, v in result.items() if k != 'sha256'}, sort_keys=True).encode()).hexdigest()
        return result
    # No frozen snapshot: rebuild the return for that period from the rows uploaded for it.
    b = dataio.entity_bundle(db, eid, periods=(period, None))
    result = from_bundle(db, eid, kind, period, b)
    result['warnings'].append('Calculated from the data rows for this period; no frozen snapshot exists. Client record settings are the current ones. Use Save return snapshot (Returns and workings) to keep this version.')
    result['sha256'] = hashlib.sha256(json.dumps({k: v for k, v in result.items() if k != 'sha256'}, sort_keys=True).encode()).hexdigest()
    return result


def from_bundle(db, eid, kind, period, b):
    records, errors = [], []
    def add(section, field, value):
        if value is None:
            return
        records.append(dict(section=section, field=field, value=format(value, '.2f') if isinstance(value, (float, int)) and not isinstance(value, bool) else str(value)))
    f = b['vat_fta']
    if True:
        for key, value in f['header']:
            add('Taxpayer information', key, value)
        for line in f['lines']:
            for col in ('amount', 'vat', 'adj'):
                add(line['section'], line['box'] + ' | ' + line['desc'] + ' | ' + col, line[col])
        for key, value in [f['margin']] + f['signatory']:
            add('Declaration', key, value)
        if abs(b['vat201']['diff']) > .02:
            errors.append('VAT return does not reconcile to VAT calculation')
    trn = b['e'].get('vat_trn') or ''
    if not re.fullmatch(r'\d{15}', str(trn)):
        errors.append('Missing or invalid 15-digit ' + kind + ' TRN')
    status = db.signoff_get(eid, kind, period)['status']
    warnings = ['Manual review and submission in EmaraTax required.',
                'Field labels follow the application return layout; verify current portal fields, elections and conditional schedules manually.',
                'Review required schedules and reconciliations in Returns and workings before filing.']
    if status != 'Approved':
        warnings.append('Return is ' + status + '; it is not approved for filing.')
    result = dict(type=kind, source_filename='Returns and workings / saved database',
                  created_utc=datetime.now(timezone.utc).isoformat(),
                  metadata=dict(client_id=eid, client_name=b['e']['name'], TRN=trn, period_end=period, approval_status=status),
                  records=records, errors=errors, warnings=warnings, ready_for_review=not errors,
                  field_mapping=True)
    result['sha256'] = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
    return result
