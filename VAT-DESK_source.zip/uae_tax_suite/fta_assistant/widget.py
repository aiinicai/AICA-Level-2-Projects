from pathlib import Path
import json, webbrowser
from datetime import datetime, timezone
from PyQt6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton,QFileDialog,QTextEdit,QMessageBox,QLineEdit,QTableWidget,QTableWidgetItem,QApplication,QAbstractItemView)
from . import saved
from .engine import parse_template, build_pack, EMARATAX_URL

class FilingAssistantPage(QWidget):
    def __init__(self, ctx=None):
        super().__init__();self.ctx=ctx;self.result=None;self.path=None
        v=QVBoxLayout(self)
        title=QLabel('FTA Filing Assistant — Manual Review & Filing');title.setStyleSheet('font-size:20px;font-weight:700;');v.addWidget(title)
        v.addWidget(QLabel('Preparation tool only. No FTA API connection, automatic portal data transfer, or submission.'))
        source=QHBoxLayout();v.addLayout(source)
        self.client=QComboBox();source.addWidget(QLabel('Client'));source.addWidget(self.client)
        self.period=QComboBox();source.addWidget(QLabel('Tax period ending'));source.addWidget(self.period)
        fetch=QPushButton('Fetch Return Data');fetch.clicked.connect(self.fetch);source.addWidget(fetch)
        row=QHBoxLayout();v.addLayout(row)
        self.kind=QComboBox(self);self.kind.addItems(['VAT']);self.kind.hide()
        self.file=QLineEdit();self.file.setReadOnly(True);row.addWidget(self.file,1)
        browse=QPushButton('Choose return Excel');browse.clicked.connect(self.browse);row.addWidget(browse)
        actions=QHBoxLayout();v.addLayout(actions)
        for text,callback in [('Validate template',self.validate),('Export filing review pack',self.export),('Open EmaraTax',self.open_portal),('Record filing evidence',self.evidence)]:
            b=QPushButton(text);b.clicked.connect(callback);actions.addWidget(b)
        self.output=QTextEdit();self.output.setReadOnly(True);v.addWidget(self.output)
        self.fields=QTableWidget(0,4);self.fields.setHorizontalHeaderLabels(['Source section','Return field','Value','Copy'])
        self.fields.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers);v.addWidget(self.fields,2)
        self.fields.horizontalHeader().setStretchLastSection(True)
        self.client.currentIndexChanged.connect(self.load_periods)
        self.kind.currentIndexChanged.connect(self.load_periods)
        self.period.currentIndexChanged.connect(self.fetch)
        self._applying=False
        if ctx is not None:
            ctx.changed.connect(self.reload)
            if hasattr(ctx,'selection_changed'):ctx.selection_changed.connect(self.on_sel)
            self.reload()

    def reload(self):
        cur=self.client.currentData();self.client.blockSignals(True);self.client.clear()
        for e in self.ctx.db.entities():self.client.addItem(e['id']+' - '+e['name'],e['id'])
        self.client.setCurrentIndex(max(0,self.client.findData(cur)));self.client.blockSignals(False);self.load_periods()

    def on_sel(self,source):
        """Returns and workings changed the client or tax period: show the same one here."""
        if source is self or self._applying or self.ctx is None:return
        s=self.ctx.sel;self._applying=True
        try:
            if s['client'] and self.client.findData(s['client'])>=0 and self.client.currentData()!=s['client']:
                self.client.blockSignals(True);self.client.setCurrentIndex(self.client.findData(s['client']));self.client.blockSignals(False)
                self.load_periods()
            i=self.period.findData(s.get(self.kind.currentText()) or '')
            if i>=0 and i!=self.period.currentIndex():
                self.period.blockSignals(True);self.period.setCurrentIndex(i);self.period.blockSignals(False);self.fetch()
        finally:self._applying=False

    def clear_result(self):
        self.result=None;self.output.clear();self.fields.setRowCount(0)

    def load_periods(self):
        self.clear_result();self.path=None;self.file.clear()
        old=self.period.currentData();self.period.blockSignals(True);self.period.clear()
        if self.client.currentData():
            for p,st in saved.period_status(self.ctx.db,self.client.currentData(),self.kind.currentText()):self.period.addItem(p+'  ('+st+')',p)
        s=getattr(self.ctx,'sel',{}) if self.ctx is not None else {}
        want=s.get(self.kind.currentText()) if s.get('client')==self.client.currentData() else None
        if want and self.period.findData(want)>=0:self.period.setCurrentIndex(self.period.findData(want))
        elif self.period.findData(old)>=0:self.period.setCurrentIndex(self.period.findData(old))
        self.period.blockSignals(False);self.fetch()

    def fetch(self):
        self.clear_result();self.path=None;self.file.clear()
        if not self.client.currentData() or not self.period.currentData():return
        if not self._applying and hasattr(self.ctx,'set_selection'):
            k=self.kind.currentText();self.ctx.set_selection(self.client.currentData(),self.period.currentData(),self)
        try:
            self.result=saved.fetch(self.ctx.db,self.client.currentData(),self.kind.currentText(),self.period.currentData())
            self.show_result()
        except Exception as exc:self.output.setPlainText('Unable to fetch saved return: '+str(exc))

    def show_result(self):
        r=self.result
        self.output.setPlainText('Return: '+r['type']+' | Source: '+r['source_filename']+'\n'+json.dumps(r['metadata'],indent=2,ensure_ascii=False)+'\n\nERRORS\n'+'\n'.join(r['errors'] or ['None'])+'\n\nREVIEW ITEMS\n'+'\n'.join(r['warnings']))
        values=[]
        for record in r['records']:
            for key in ('value','amount','tax','adjustment'):
                if key in record and record[key] not in (None,''):
                    values.append((record.get('section',''),record['field']+(' | '+key if key!='value' else ''),str(record[key])))
        self.fields.setRowCount(len(values))
        for i,row in enumerate(values):
            for j,value in enumerate(row):self.fields.setItem(i,j,QTableWidgetItem(value))
            button=QPushButton('Copy Value');button.clicked.connect(lambda checked=False,value=row[2]:QApplication.clipboard().setText(value));self.fields.setCellWidget(i,3,button)
        self.fields.resizeColumnsToContents()

    def browse(self):
        path,_=QFileDialog.getOpenFileName(self,'Choose VAT 201 Excel template','','Excel (*.xlsx)')
        if path:self.clear_result();self.path=path;self.file.setText(path);self.validate()
    def validate(self):
        if not self.path:self.fetch();return
        self.clear_result()
        try:
            self.result=parse_template(self.path,self.kind.currentText())
            self.show_result()
        except Exception as e: QMessageBox.critical(self,'Import failed',str(e))
    def export(self):
        if self.result is None:self.validate()
        if self.result is None:return
        name,_=QFileDialog.getSaveFileName(self,'Save review pack',self.result['type']+'_filing_review.zip','ZIP (*.zip)')
        if name:
            try:build_pack(self.result,name);QMessageBox.information(self,'Export complete','Review pack saved. This is not an FTA filing.')
            except Exception as e:QMessageBox.critical(self,'Export failed',str(e))
    def open_portal(self):webbrowser.open(EMARATAX_URL,new=2)
    def evidence(self):
        if self.result is None: QMessageBox.warning(self,'First validate','Validate and review the return first');return
        if self.result['errors']:
            QMessageBox.warning(self,'Unresolved errors','Resolve validation errors before recording filing evidence.');return
        src,_=QFileDialog.getOpenFileName(self,'Select filing acknowledgement obtained from FTA','','PDF, image or HTML (*.pdf *.png *.jpg *.jpeg *.html);;All files (*)')
        if not src:return
        ref,ok=__import__('PyQt6.QtWidgets',fromlist=['QInputDialog']).QInputDialog.getText(self,'FTA filing reference','Enter reference number visible on the FTA acknowledgement:')
        if not ok or not ref.strip():return
        path,_=QFileDialog.getSaveFileName(self,'Save manual filing record','fta_filing_evidence.json','JSON (*.json)')
        if not path:return
        evidence={'source_sha256':self.result['sha256'],'return_type':self.result['type'],'source_metadata':self.result['metadata'],'status':'User-attested submitted (not independently verified)','fta_reference_user_entered':ref.strip(), 'evidence_file':str(Path(src).resolve()),'recorded_utc':datetime.now(timezone.utc).isoformat()}
        Path(path).write_text(json.dumps(evidence,indent=2),encoding='utf-8')
        QMessageBox.information(self,'Evidence recorded','Local record saved. Filing status is user-attested, not portal-verified.')
