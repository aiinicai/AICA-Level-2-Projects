"""Start the web version.  python run_web.py [--host 0.0.0.0] [--port 8080]
Default is this computer only. Use --host 0.0.0.0 to let other computers and phones on the office network reach it."""
import argparse
from web.app import app

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1"); ap.add_argument("--port", type=int, default=8080)
    a = ap.parse_args()
    try:
        from waitress import serve
        print("VAT-DESK (web) on http://%s:%d" % (a.host, a.port))
        serve(app, host=a.host, port=a.port, threads=8)
    except ImportError:
        print("waitress not installed: using the development server (install waitress for real use)")
        app.run(host=a.host, port=a.port, threaded=True)
