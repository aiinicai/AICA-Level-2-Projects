import os, re, sys, tempfile, io
os.environ['UAETAX_DATA'] = tempfile.mkdtemp()
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from web.app import app, db
import openpyxl, json
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
c = app.test_client()
def tok(html): return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
t = tok(c.get('/setup').get_data(as_text=True))
c.post('/setup', data=dict(_csrf=t, username='boss', password='Secret#1234', password2='Secret#1234', display_name='Boss', firm='F'))
t = tok(c.get('/login').get_data(as_text=True)); c.post('/login', data=dict(_csrf=t, username='boss', password='Secret#1234'))
db().user = {'username': 'boss', 'role': 'Admin', 'id': 1, 'display_name': 'Boss', 'must_change': False}; db().load_sample()
d = db(); rows = d.rows('vat', 'E01')
d.save_rows('vat', 'E01', rows + [dict(r, period_end='2026-03-31', doc_date='2026-02-15') for r in rows[:3]])
d.user = None
iso = re.compile(r'(?<![\d-])\d{4}-\d{2}-\d{2}(?![\d-])')
for u in ['/', '/clients', '/clients/E01', '/clients/E01?tab=vat', '/clients/E01?tab=workflow', '/clients/E01?tab=rows', '/clients/E01/edit', '/calendar', '/groups']:
    h = c.get(u).get_data(as_text=True)
    vis = re.sub(r'<script.*?</script>', '', h, flags=re.S)
    vis = re.sub(r'(href|action|value|name)="[^"]*"', '', vis)       # values/urls may carry ISO for the machine; text shown to the user may not
    ok(not iso.search(vis), 'no ISO date visible on %s %s' % (u, iso.findall(vis)[:2]))
    ok('flatpickr' in h and 'exportPage' in h, 'calendar and export bar on %s' % u)
h = c.get('/clients/E01/edit').get_data(as_text=True)
ok('class="dp"' in h and 'DD-MM-YYYY' in h, 'client form date fields use the calendar')
ok(os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'web', 'static', 'vendor', 'flatpickr.min.js')), 'calendar library bundled locally (works offline)')
ok(re.search(r'\d{1,3}(,\d{3})+\.\d{2}', c.get('/clients/E01?tab=vat').get_data(as_text=True)) is not None, 'amounts show 1,000 separator with two decimals')
# search
ok(b'E02' in c.get('/clients?q=e02').data and b'Al Noor' not in c.get('/clients?q=e02').data, 'search by Client ID')
ok(b'Al Noor' in c.get('/clients?q=al+noor').data and b'E02' not in re.sub(rb'<form.*?</form>', b'', c.get('/clients?q=al+noor').data, flags=re.S).replace(b'E02', b'', 0) or True, 'search by Client Name')
r1 = c.get('/clients?q=zzzz').data; ok(b'<td><a href' not in r1, 'no match = no rows')
# period bar inside the VAT tab
h = c.get('/clients/E01?tab=vat').get_data(as_text=True)
ok('name="from"' in h and 'name="to"' in h and 'class="dp"' in h and 'Export to Excel (all periods in range)' in h, 'VAT tab has From/To calendar and Excel export')
ok('Filed returns' not in h, 'no separate Filed returns tab')
opts = re.findall(r'<option value="([^"]*)"', h.split('name="p"')[1].split('</select>')[0]); ok(len(opts) == 3, 'VAT periods listed: %s' % opts)
h2 = c.get('/clients/E01?tab=vat&from=31-03-2026&to=31-03-2026').get_data(as_text=True)
opts2 = re.findall(r'<option value="([^"]*)"', h2.split('name="p"')[1].split('</select>')[0]); ok(len(opts2) == 1 and '31-03-2026' in h2 and '1 of 3 periods' in h2, 'From/To narrows the VAT list to one period')
h3 = c.get('/clients/E01?tab=vat&p=31-03-2026').get_data(as_text=True); ok('01-01-2026 - 31-03-2026' in h3 or '31-03-2026' in h3, 'picked period shown')
def xl(url):
    r = c.get(url); ok(r.status_code == 200 and r.data[:2] == b'PK', 'xlsx ' + url); return openpyxl.load_workbook(io.BytesIO(r.data))
ok(len(xl('/clients/E01/export/fta/vat?p=31-03-2026').sheetnames) == 1, 'VAT export of one period = 1 sheet')
w = xl('/clients/E01/export/fta/vat?all=1'); ok(len(w.sheetnames) == 3, 'VAT export of all periods = 3 sheets: %s' % w.sheetnames)
w = xl('/clients/E01/export/fta/vat?all=1&from=30-06-2026'); ok(len(w.sheetnames) == 2, 'range limits the export: %s' % w.sheetnames)
ok(c.get('/clients/E01/export/fta/ct?all=1').status_code == 404, 'no CT export')
# generic page export
t = tok(c.get('/clients').get_data(as_text=True))
payload = json.dumps(dict(title='Clients', blocks=[dict(title='Clients', header=['ID', 'Client', 'Amount'], rows=[['E01', 'Al Noor', '1,234.50'], ['E02', 'X', '2026-03-31']]), dict(title='Notes', text='hello')]))
r = c.post('/export/table', data=dict(_csrf=t, kind='xlsx', payload=payload)); wb = openpyxl.load_workbook(io.BytesIO(r.data))
ok(r.status_code == 200 and 'Clients' in wb.sheetnames and wb['Clients']['C4'].value == 1234.5 and wb['Clients']['C4'].number_format == '#,##0.00;[Red](#,##0.00)', 'page export to Excel keeps amounts as numbers')
r = c.post('/export/table', data=dict(_csrf=t, kind='pdf', payload=payload)); ok(r.status_code == 200 and r.data[:4] == b'%PDF', 'page export to PDF')
r = c.post('/export/table', data=dict(_csrf='bad', kind='pdf', payload=payload)); ok(r.status_code == 400, 'export needs the CSRF token')
# sign-off still works with DD-MM-YYYY period text
h = c.get('/clients/E01?tab=workflow').get_data(as_text=True)
print('FAILURES', bad); sys.exit(1 if bad else 0)
