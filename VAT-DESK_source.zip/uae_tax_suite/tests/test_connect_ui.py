import os, sys, tempfile, datetime as dt, threading
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['APPDATA'] = tempfile.mkdtemp()
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..')); sys.path.insert(0, here)
import test_connectors as M   # starts mock servers and runs their asserts
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QEventLoop, QTimer
from core.db import DB
from ui.common import STYLE, Ctx
from ui.connect import ConnectDialog
app = QApplication([]); app.setStyleSheet(STYLE)
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('a', 'Admin#12345', 'Admin'); d.login('a', 'Admin#12345'); d.load_sample()
ctx = Ctx(d)
dlg = ConnectDialog(ctx, 'E01'); dlg.show()
dlg.t_url.setText(M.url); dlg.vf.setText('2026-07-01'); dlg.vt.setText('2026-09-30'); dlg.anchor = dt.date(2026, 9, 30); dlg.step = 3
dlg.t_vat()
loop = QEventLoop(); dlg.worker.finished.connect(loop.quit); QTimer.singleShot(8000, loop.quit); loop.exec(); app.processEvents()
print('rows in preview', dlg.table.rowCount(), dlg.status.text()[:70])
dlg.grab().save('/tmp/connect.png')
assert dlg.table.rowCount() == 6
before = len([r for r in d.rows('vat', 'E01')])
from ui import connect as C
C.ask = lambda *a: True; C.info = lambda *a: None
dlg.do_import()
rows = d.rows('vat', 'E01'); print('E01 vat rows', before, '->', len(rows))
assert any(r['doc_no'] == 'S-1' for r in rows)
print('UI OK')
