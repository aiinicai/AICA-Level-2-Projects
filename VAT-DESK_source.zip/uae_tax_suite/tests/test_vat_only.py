"""VAT-DESK is VAT only: nothing about corporate tax, transfer pricing or registers is left in the code, screens, templates or exports,
and an older database that holds such data still opens with that data untouched."""
import os, sys, re, tempfile, json, zipfile
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.insert(0, root)
import openpyxl
from core.db import DB
from core import dataio, engine as E, dataio as DIO
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
# modules are gone
for m in ('ctcats', 'tpsched', 'losses', 'rptracker', 'taxgroup', 'partial', 'variance', 'docs'):
    ok(not os.path.exists(os.path.join(root, 'core', m + '.py')), 'core/%s.py removed' % m)
ok(not os.path.exists(os.path.join(root, 'ui', 'registers.py')) and not os.path.exists(os.path.join(root, 'ui', 'registers2.py')), 'Registers screens removed')
ok(all(not hasattr(E, f) for f in ('ct_calc', 'tp_calc', 'prior_period')), 'engine has no CT / TP functions')
# the name
bad_name = []
for dp, dn, fn in os.walk(root):
    if '__pycache__' in dp or os.sep + 'tests' in dp or 'webdata' in dp or 'vendor' in dp:
        continue
    for f in fn:
        if f.endswith(('.py', '.html', '.md', '.bat', '.spec', '.json', '.css')):
            if 'TAXNEBULA' in open(os.path.join(dp, f), encoding='utf-8', errors='ignore').read():
                bad_name.append(f)
ok(not bad_name, 'the old name appears nowhere in the program files %s' % bad_name)
# template
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('a', 'Admin#12345', 'Admin'); d.login('a', 'Admin#12345'); d.load_sample()
p = os.path.join(tempfile.mkdtemp(), 't.xlsx'); dataio.write_template(p)
names = openpyxl.load_workbook(p).sheetnames
ok(not any(x in names for x in ('CT Data', 'TP Data', 'TP Benchmark', 'Property Data')) and 'VAT Data' in names, 'import template sheets: %s' % names)
hdr = [c.value for c in openpyxl.load_workbook(p)['Clients'][1]]
ok(not any('CT' in str(h) or 'Corporate' in str(h) or 'Transfer' in str(h) for h in hdr), 'Clients sheet has no CT / TP columns')
# portfolio export
x = os.path.join(tempfile.mkdtemp(), 'r.xlsx'); dataio.export_portfolio_xlsx(x, d.compute(), 'Firm')
hh = [c.value for c in openpyxl.load_workbook(x)['Client register'][4]]
ok(not any('CT' in str(h) or 'TP' in str(h) for h in hh), 'register export has no CT / TP columns: %s' % hh)
# rules
keys = [r['key'] for r in d.rules()]
ok(not any(k.startswith(('ct_', 'tp_', 'qfzp', 'sbr', 'small_business')) for k in keys), 'rules page holds VAT rules only: %s' % keys)
# an old database that holds CT / TP rows and hidden client fields
d.c.execute("INSERT INTO ct_rows(entity_id, fy_end, account_name, category, amount) VALUES('E01','2025-12-31','Sales','Operating Revenue',1000)")
d.c.commit()
e = d.entity('E01'); e['ct_trn'] = '100999999900003'; e['audited'] = 'Yes'
d.c.execute("UPDATE entities SET data=? WHERE id='E01'", (json.dumps(e),)); d.c.commit()
res = d.compute()
ok(len(res['entities']) == 6 and 'ct' not in res and 'tp' not in res, 'old database computes VAT only')
new = {k: v for k, v in e.items() if k not in ('ct_trn', 'audited')}
d.save_entity(new)
ok(d.entity('E01').get('ct_trn') == '100999999900003' and d.entity('E01').get('audited') == 'Yes', 'editing a client never loses the hidden CT values')
ok(d.c.execute("SELECT COUNT(*) FROM ct_rows WHERE entity_id='E01'").fetchone()[0] == 1, 'old CT rows are kept in the file')
print('FAILURES', bad); sys.exit(1 if bad else 0)
