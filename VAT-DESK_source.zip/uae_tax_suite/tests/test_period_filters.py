import os, sys, tempfile
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PyQt6.QtWidgets import QLineEdit
from PyQt6.QtWidgets import QApplication, QMessageBox
QMessageBox.information = staticmethod(lambda *a, **k: None); QMessageBox.warning = staticmethod(lambda *a, **k: None)
from core.db import DB
from core import dataio
from ui.common import STYLE
import ui.data as UD
UD.review_issues = lambda *a, **k: True
from ui.main_window import MainWindow
app = QApplication([]); app.setStyleSheet(STYLE)
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('boss', 'Secret#1234', 'Admin'); d.login('boss', 'Secret#1234'); d.load_sample()
# give E01 two VAT periods and two financial years
rows = d.rows('vat', 'E01'); cur = d.current_periods('E01')
old = [dict(r, period_end='2026-03-31', doc_date='2026-02-15') for r in rows[:3]]
d.save_rows('vat', 'E01', rows + old)
w = MainWindow(d); w.show(); app.processEvents()
page = lambda n: [p for p in w.pages if p.__class__.__name__ == n][0]
dp = page('DataPage'); dp.combo.setCurrentIndex(0); dp.pick(); app.processEvents()
g = dp.grids['vat']; n = g.table.rowCount()
pv = sorted({g.row_period(i) for i in range(n)})
ok(len(pv) >= 2 and g.f_from.text() == pv[0] and g.f_to.text() == pv[-1], 'VAT filter From/To default to the data range: %s' % pv)
g.f_from.setText(pv[-1]); g.f_to.setText(pv[-1]); g.apply_filter(); app.processEvents()
vis = g.visible_rows(); ok(0 < len(vis) < n and all(g.row_period(i) == pv[-1] for i in vis) and 'filtered' in g.count.text(), 'VAT rows are filtered to the chosen range (%d of %d)' % (len(vis), n))
g.save(); app.processEvents()
ok(len(d.rows('vat', 'E01')) == n, 'saving while filtered keeps the hidden rows')
g.clear_filter(); ok(len(g.visible_rows()) == g.table.rowCount(), 'Show all restores every row')
ok(list(dp.grids) == ['vat'] and dp.tabs.count() == 1, 'Data page has the VAT grid only')
# returns: choose a past period
rp = page('ReturnsPage'); rp.combo.setCurrentIndex(0); rp.on_client(); app.processEvents()
vals = [rp.vp.itemData(i) for i in range(rp.vp.count())]
ok(len(vals) >= 2 and '(current)' in rp.vp.currentText(), 'VAT period selector lists periods, current preselected: %s' % vals)
cur_net = rp.b['vat201']['net']; past = [v for v in vals if v != cur[0]][0]
rp.vp.setCurrentIndex(rp.vp.findData(past)); app.processEvents()
ok(rp.b['periods'][0] == past and rp.b['e']['vat_period_end'] == past and 'past period' in rp.period_note.text(), 'selecting a past VAT period rebuilds the return for it')
ok(rp.b['vat_fta']['header'] is not None and any(l['box'] == '14' for l in rp.b['vat_fta']['lines']), 'VAT 201 (FTA format) built for the past period')
rp.vp.setCurrentIndex(rp.vp.findData(cur[0])); app.processEvents()
ok(rp.b['vat201']['net'] == cur_net and not rp.period_note.text(), 'back to the current period gives the original figures')
ok(not hasattr(rp, 'cy') and 'CT' not in rp.pbar, 'no CT year selector')
# Filing Assistant: periods with data, status labels, past period rebuilt from its own rows
from fta_assistant import saved
from fta_assistant.widget import FilingAssistantPage
st = dict(saved.period_status(d, 'E01', 'VAT'))
ok(st.get('2026-03-31') == 'From data' and '2026-09-30' in st, 'assistant lists periods that have data: %s' % st)
cur_r = saved.fetch(d, 'E01', 'VAT', '2026-09-30'); past_r = saved.fetch(d, 'E01', 'VAT', '2026-03-31')
ok(past_r['metadata'] != cur_r['metadata'] or past_r['records'] != cur_r['records'], 'past period is rebuilt from its own rows, not the current ones')
ok(any('data rows for this period' in x for x in past_r['warnings']), 'past period carries the from-data note')
fa = FilingAssistantPage(type('C', (), {'db': d, 'changed': type('S', (), {'connect': lambda *a: None})()})()); fa.reload(); app.processEvents()
ok(fa.period.count() >= 3 and '(' in fa.period.itemText(0), 'assistant period box shows status labels')
saved.save(d, 'E01', None, ('2026-03-31', ''))
ok(dict(saved.period_status(d, 'E01', 'VAT')).get('2026-03-31') == 'Saved', 'saving a snapshot for a past period keeps it as a record')
# From / To bars inside the VAT 201 and CT return tabs (no separate Filed returns tab)
import os, tempfile, openpyxl
from PyQt6.QtWidgets import QTabWidget
from ui.periodbar import PeriodBar
from ui.dates import DateField
names = [rp.tabs.tabText(i) for i in range(rp.tabs.count())]
ok(not any('Filed returns' in n for n in names), 'no separate Filed returns tab: %s' % names)
tabs = {rp.tabs.tabText(i): rp.tabs.widget(i) for i in range(rp.tabs.count())}
for nm, kind in (('VAT 201 (FTA format)', 'VAT'),):
    bar = rp.pbar[kind]
    ok(tabs[nm] is rp.ftab[kind] and isinstance(bar, PeriodBar) and isinstance(bar.f_from, DateField) and isinstance(bar.f_to, DateField), '%s tab holds the From/To calendar bar' % nm)
    ok(len(bar.all) >= 2 and bar.combo.count() == len(bar.all), '%s lists all periods (%d)' % (kind, len(bar.all)))
bar = rp.pbar['VAT']; allp = list(bar.all)
bar.f_from.setText(allp[-1]); bar.f_to.setText(allp[-1]); bar.apply(); app.processEvents()
ok(bar.combo.count() == 1 and rp.periods()[0] == allp[-1], 'From/To narrows the list to one period and shows its return')
ok(bar.f_from.text() == allp[-1] and QLineEdit.text(bar.f_from) == '%s-%s-%s' % (allp[-1][8:], allp[-1][5:7], allp[-1][:4]), 'range is displayed as DD-MM-YYYY')
bar.clear(); app.processEvents()
ok(bar.combo.count() == len(allp), 'All periods restores the list')
import ui.returns as UR
d1 = tempfile.mkdtemp()
for whole, expect in ((False, 1), (True, len(allp))):
    UR.QFileDialog.getSaveFileName = staticmethod(lambda *a, _p=os.path.join(d1, 'x%d.xlsx' % whole): (_p, ''))
    UR.info = lambda *a, **k: None
    rp.export_periods('VAT', whole); app.processEvents()
    wb = openpyxl.load_workbook(os.path.join(d1, 'x%d.xlsx' % whole))
    ok(len(wb.sheetnames) == expect, 'VAT Excel export whole_range=%s has %d sheet(s): %s' % (whole, len(wb.sheetnames), wb.sheetnames))
# sync between Returns and workings and the FTA Filing Assistant, tab names and order
fa2 = page('FilingAssistantPage'); fa2.reload(); app.processEvents()
names = [rp.tabs.tabText(i) for i in range(rp.tabs.count())]
ok(names[-2:] == ['Working paper checklists', 'VAT Return basis'] and 'VAT 201 workings' not in names, 'basis tabs renamed and moved to the end: %s' % names)
ok(not rp.pbar['VAT'].combo.isVisible() and not rp.pbar['VAT'].count.isVisible(), 'repeated period box and count are not shown')
ok(rp.pbar['VAT'].findChildren(__import__('PyQt6.QtWidgets', fromlist=['x']).QPushButton) and all(b.text() != 'All periods' for b in rp.pbar['VAT'].findChildren(__import__('PyQt6.QtWidgets', fromlist=['x']).QPushButton)), 'All periods button removed')
bar = rp.pbar['VAT']; allp = list(bar.all)
bar.f_from.setText(allp[-1]); bar.f_to.setText(allp[-1]); bar.apply(); app.processEvents()
fa2.kind.setCurrentText('VAT'); app.processEvents()
ok(rp.combo.currentData() == fa2.client.currentData() and fa2.period.currentData() == allp[-1], 'choosing a VAT period in Returns moves the Filing Assistant to it (%s)' % fa2.period.currentData())
fa2.kind.setCurrentText('VAT'); app.processEvents()
fa2.period.setCurrentIndex(fa2.period.findData(allp[0])); app.processEvents()
ok(rp.periods()[0] == allp[0] and rp.pbar['VAT'].f_to.text() == allp[0], 'choosing a period in the Filing Assistant moves Returns to it')
rp.combo.setCurrentIndex(1); app.processEvents()
ok(fa2.client.currentData() == rp.combo.currentData(), 'changing client in Returns changes it in the Filing Assistant')
fa2.client.setCurrentIndex(0); app.processEvents()
ok(rp.combo.currentData() == fa2.client.currentData(), 'changing client in the Filing Assistant changes it in Returns')
from ui.common import STYLE as _S
ok('QTabBar::tab { background: #1B2A5E; color: white; font-weight: 700' in _S, 'tab bar is navy with bold white text')
print('FAILURES', bad); sys.exit(1 if bad else 0)
