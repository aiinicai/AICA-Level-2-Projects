import os, sys, tempfile, re
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PyQt6.QtWidgets import QApplication, QMessageBox, QLabel, QLineEdit, QTableWidget
QMessageBox.information = staticmethod(lambda *a, **k: None); QMessageBox.warning = staticmethod(lambda *a, **k: None)
from core.db import DB
from ui.common import STYLE, fmt
from ui.main_window import MainWindow
from ui.dates import DateField, install_display
import ui.exporter as EX
import openpyxl
app = QApplication([]); app.setStyleSheet(STYLE); install_display()
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
ok(fmt(1234567.891) == '1,234,567.89' and fmt(0) == '-' or fmt(0) in ('0.00', '-'), 'fmt: %s / %s' % (fmt(1234567.891), fmt(0)))
ok(fmt(-1234.5) in ('(1,234.50)', '-1,234.50'), 'negative amount: %s' % fmt(-1234.5))
from core import engine as E
ok(E.D('31-03-2026') == E.D('2026-03-31') == E.D('31/03/2026'), 'engine accepts DD-MM-YYYY, DD/MM/YYYY and ISO')
f = DateField('2026-03-31'); ok(QLineEdit.text(f) == '31-03-2026' and f.text() == '2026-03-31', 'DateField shows DMY, keeps ISO')
f.setText('1/2/2026'); f._normalise(); ok(QLineEdit.text(f) == '01-02-2026', 'typed date normalised to DD-MM-YYYY')
f.open_calendar(); ok(f._pop.cal.selectedDate().day() == 1 and f._pop.cal.selectedDate().month() == 2, 'calendar popup opens on the field date (month/year selectable)')
f._pop._pick(f._pop.cal.selectedDate().addMonths(1)); ok(QLineEdit.text(f) == '01-03-2026', 'picking from calendar fills the field')
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('boss', 'Secret#1234', 'Admin'); d.login('boss', 'Secret#1234'); d.load_sample()
w = MainWindow(d); w.show(); app.processEvents()
# no ISO date and no un-separated amount visible on any page
iso = re.compile(r'(?<!\d)\d{4}-\d{2}-\d{2}(?!\d)')
for i, p in enumerate(w.pages):
    w.go(i); app.processEvents()
    hits = [x.text() for x in p.findChildren(QLabel) if iso.search(x.text())]
    cells = []
    for t in p.findChildren(QTableWidget):
        for r in range(t.rowCount()):
            for c in range(t.columnCount()):
                it = t.item(r, c)
                if it and iso.search(it.text()):
                    cells.append(it.text())
    ok(not hits and not cells, '%s: no ISO dates on screen%s' % (w.page_names[i], (' ' + str((hits + cells)[:3])) if hits or cells else ''))
# clients search by id or name
cp = [p for p in w.pages if p.__class__.__name__ == 'ClientsPage'][0]; w.go(1)
n = cp.table.rowCount(); first = cp.table.item(0, 0).text(); nm = cp.table.item(0, 1).text()
cp.search.setText(first.lower()); ok(cp.table.rowCount() >= 1 and cp.table.item(0, 0).text() == first, 'search by Client ID')
cp.search.setText(nm.split()[0].upper()); ok(cp.table.rowCount() >= 1 and any(nm == cp.table.item(r, 1).text() for r in range(cp.table.rowCount())), 'search by Client Name')
cp.search.setText('zzzz-none'); ok(cp.table.rowCount() == 0, 'no match shows no rows'); cp.search.setText(''); ok(cp.table.rowCount() == n, 'clear search restores all')
# every page exports to Excel and PDF
tmp = tempfile.mkdtemp()
for i, p in enumerate(w.pages):
    w.go(i); app.processEvents()
    name = w.page_names[i]
    blocks = EX.collect(p, name)
    from core import tabexport as TX
    x = os.path.join(tmp, 'p%d.xlsx' % i); pdf = os.path.join(tmp, 'p%d.pdf' % i)
    TX.to_xlsx(x, name, blocks); TX.to_pdf(pdf, name, blocks)
    wb = openpyxl.load_workbook(x)
    ok(os.path.getsize(pdf) > 800 and len(wb.sheetnames) >= 1 and (len(blocks) > 0), '%s exports (%d blocks, %d sheet(s))' % (name, len(blocks), len(wb.sheetnames)))
# amounts in Excel are real numbers with 2-decimal comma format
rp = [p for p in w.pages if p.__class__.__name__ == 'ReturnsPage'][0]; w.go(3); app.processEvents()
x = os.path.join(tmp, 'ret.xlsx'); TX.to_xlsx(x, 'Returns', EX.collect(rp, 'Returns and workings'))
wb = openpyxl.load_workbook(x); fm = set(); nums = 0
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, (int, float)) and c.number_format != 'General':
                nums += 1; fm.add(c.number_format)
ok(nums > 20 and fm <= {'#,##0.00;[Red](#,##0.00)'}, 'returns Excel: %d amounts, formats %s' % (nums, fm))
# master workbook formats
from core import dataio
ok('0.00' in dataio.NUM, 'workbook amount format has two decimals: %s' % dataio.NUM)
print('FAILURES', bad); sys.exit(1 if bad else 0)
