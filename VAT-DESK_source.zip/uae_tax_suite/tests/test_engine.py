import os
import json, sys, datetime as dt
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core import engine as E
B = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures') + os.sep
o = json.load(open(B + 'calc_out.json'))
ents = json.load(open(B + 'entities.json')); rules = json.load(open(B + 'rules.json'))
res = E.run_all(ents, rules, dt.date(2026, 10, 28))
# VAT-DESK is VAT only: the VAT calculation must equal the workbook exactly; calendar and issues are compared on their VAT rows,
# risk on the VAT fields (the workbook's risk score also counted corporate tax and transfer pricing, which are gone).
o['calendar_vat'] = [d for d in o['deadline_calc'] if d['obligation'].startswith('VAT')]
res['calendar_vat'] = [d for d in res['calendar'] if d['obligation'].startswith('VAT')]
o['issues_vat'] = [d for d in o['issues_calc'] if d['area'] == 'VAT']
res['issues_vat'] = [d for d in res['issues'] if d['area'] == 'VAT']
o['risk_vat'] = [{k: v for k, v in r.items() if k in ('id', 'name', 'location', 'vat_status', 'vat_flag', 'vat_net')} for r in o['risk_calc']]
# issue keys are numbered across all areas in the workbook and the issue text uses the 2-dp amount format added later: compare area, severity and entity only
for L_ in (o['issues_vat'], res['issues_vat']):
    for d in L_:
        for k in ('key', 'issue', 'action'):
            d.pop(k, None)
pairs = [('vat', 'vat_calc'), ('risk', 'risk_vat'), ('issues_vat', 'issues_vat'), ('calendar_vat', 'calendar_vat')]
bad = 0; tot = 0
def eq(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)): return abs(a - b) < 1e-6 * max(1, abs(b))
    if a in (None, '') and b in (None, ''): return True
    return a == b
for mine, ref in pairs:
    A, Bv = res[mine], o[ref]
    if len(A) != len(Bv): print(mine, 'len', len(A), len(Bv)); bad += 1; continue
    for i, (a, b) in enumerate(zip(A, Bv)):
        for k in b:
            tot += 1
            if k not in a: print(mine, i, 'missing', k); bad += 1; continue
            if not eq(a[k], b[k]): print(mine, i, k, a[k], b[k]); bad += 1
print('compared', tot, 'mismatches', bad)
assert not any(k in res for k in ('ct', 'tp'))
assert bad == 0
