import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.db import DB
from core import dataio, ftaformat as FF
import openpyxl
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('a', 'Admin#12345', 'Admin'); d.login('a', 'Admin#12345'); d.load_sample()
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += (not c)
# stagger pattern, as printed on an FTA return for periods ending Aug
ok(FF.stagger('2026-08-31', 3) == ('Stagger 2 - Quarterly (Mar to Feb)', '28-02-2027'), 'stagger 2 and tax year end')
ok(FF.stagger('2026-09-30', 3)[1] == '31-12-2026' and FF.stagger('2026-10-31', 3)[1] == '31-01-2027' and FF.stagger('2026-07-31', 1)[0] == 'Monthly', 'stagger 1, 3, monthly')
res = d.compute()
for e in res['entities']:
    b = dataio.entity_bundle(d, e['id'], res)
    v = b['vat_fta']
    ok('ct_fta' not in b and 'c' not in b and 't' not in b, '%s bundle has no CT / TP parts' % e['id'])
    net = next(l for l in v['lines'] if l['box'] == '14')['amount']
    ok(abs(net - b['vat201']['net']) < 0.5, '%s VAT box 14 agrees' % e['id'])
    ok(next(l for l in v['lines'] if l['box'] == '8')['amount'] == next(l for l in b['vat201']['lines'] if l['box'] == '8')['amount'], '%s VAT box 8' % e['id'])
b = dataio.entity_bundle(d, 'E01')
x = os.path.join(tempfile.mkdtemp(), 'p.xlsx'); dataio.export_entity_xlsx(x, b, 'Firm'); dataio.export_entity_pdf(x.replace('.xlsx', '.pdf'), b, 'Firm')
names = set(openpyxl.load_workbook(x).sheetnames)
ok({'VAT 201 (FTA)', 'VAT 201'} <= names and not any('CT' in n or 'TP' in n for n in names), 'exports carry the VAT sheets only: %s' % sorted(names))
print('FAILURES', bad); sys.exit(1 if bad else 0)
