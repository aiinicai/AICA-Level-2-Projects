import os, re, sys, tempfile, io
os.environ['UAETAX_DATA'] = tempfile.mkdtemp()
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from web.app import app, db
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
c = app.test_client()
def tok(html): return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
r = c.get('/'); ok(r.status_code == 302 and '/setup' in r.location, 'first visit goes to setup')
t = tok(c.get('/setup').get_data(as_text=True))
r = c.post('/setup', data=dict(_csrf=t, username='boss', password='Secret#1234', password2='Secret#1234', display_name='Boss', firm='Test Firm'))
ok(r.status_code == 302, 'administrator created')
r = c.post('/login', data=dict(_csrf='bad', username='boss', password='Secret#1234')); ok(r.status_code == 400, 'bad CSRF token refused')
t = tok(c.get('/login').get_data(as_text=True))
r = c.post('/login', data=dict(_csrf=t, username='boss', password='wrong')); ok(b'Invalid username' in r.data, 'wrong password refused')
r = c.post('/login', data=dict(_csrf=t, username='boss', password='Secret#1234')); ok(r.status_code == 302, 'login works')
db().user = {'username': 'boss', 'role': 'Admin', 'id': 1, 'display_name': 'Boss', 'must_change': False}; db().load_sample(); db().user = None
for url in ['/', '/clients', '/clients/E01', '/clients/E01?tab=vat', '/clients/E01?tab=workflow', '/clients/E01?tab=pack', '/clients/E01?tab=rows',
            '/clients/E01/edit', '/clients/new', '/data', '/groups', '/calendar', '/admin', '/clients/E03?tab=vat']:
    r = c.get(url); ok(r.status_code == 200 and b'Traceback' not in r.data, 'GET %s' % url)
ok(b'Standard Rated' in c.get('/clients/E01?tab=vat').data and b'Operating Revenue' not in c.get('/clients/E01?tab=vat').data, 'VAT 201 tab shows the return lines')
ok(c.get('/clients/E01?tab=ct').status_code == 200 and b'Corporate' not in c.get('/clients/E01?tab=ct').data, 'no CT tab (unknown tab falls back to the data page)')
for pg in ('/', '/clients', '/clients/E01', '/groups', '/data'):
    h_ = c.get(pg).get_data(as_text=True)
    ok('TAXNEBULA' not in h_ and 'VAT-DESK' in h_ and 'Corporate' not in h_ and 'Transfer' not in h_ and 'Registers' not in h_, 'VAT-DESK only, no CT / TP / Registers wording on ' + pg)
for what, mime in [('xlsx', b'PK'), ('pdf', b'%PDF'), ('summary', b'%PDF'), ('pack', b'PK')]:
    r = c.get('/clients/E01/export/' + what); ok(r.status_code == 200 and r.data[:4].startswith(mime), 'export ' + what)
ok(c.get('/template.xlsx').data[:2] == b'PK' and c.get('/calendar.ics').data.startswith(b'BEGIN:VCALENDAR'), 'template and calendar downloads')
ok(c.get('/clients/ZZZ').status_code == 404, 'unknown client is 404')
# edit a client
t = tok(c.get('/clients/E01/edit').get_data(as_text=True))
r = c.post('/clients/E01/edit', data=dict(_csrf=t, f_name='Al Noor Trading LLC', f_location='Mainland', f_vat_period_end='not a date')); ok(b'use DD-MM-YYYY' in r.data, 'bad date rejected')
# groups
t = tok(c.get('/groups').get_data(as_text=True))
r = c.post('/groups/save', data=dict(_csrf=t, kind='VAT', group_id='V1', name='Alpha VAT', trn='100', rep='E01', members=['E01', 'E02'])); ok(r.status_code == 302, 'VAT group saved')
for u in ['/groups/V1', '/groups/V1?tab=elim', '/groups/V1?tab=fta']:
    r = c.get(u); ok(r.status_code == 200 and b'Traceback' not in r.data and b'Cannot build' not in r.data, 'GET ' + u)
for g in ('V1',):
    r = c.get('/groups/%s/export' % g); ok(r.status_code == 200 and r.data[:2] == b'PK', 'group export ' + g)
# upload
tf = tempfile.mkdtemp(); p = os.path.join(tf, 't.xlsx'); from core import dataio; dataio.write_template(p)
t = tok(c.get('/data').get_data(as_text=True))
r = c.post('/data', data=dict(_csrf=t, kind='vat', mode='replace', file=(open(p, 'rb'), 't.xlsx')), content_type='multipart/form-data'); ok(r.status_code == 200 and b'Traceback' not in r.data and (b'Imported' in r.data or b'Blocked' in r.data), 'upload runs')
# admin: new user and viewer cannot edit
t = tok(c.get('/admin').get_data(as_text=True))
r = c.post('/admin', data=dict(_csrf=t, action='create', username='view1', password='Viewer#1234', role='Viewer', display_name='V')); ok(r.status_code == 302, 'viewer created')
v = app.test_client(); t2 = tok(v.get('/login').get_data(as_text=True))
v.post('/login', data=dict(_csrf=t2, username='view1', password='Viewer#1234'))
ok(b'must set a new password' in v.get('/', follow_redirects=True).data, 'new user must change password')
t3 = tok(v.get('/password').get_data(as_text=True)); v.post('/password', data=dict(_csrf=t3, old='Viewer#1234', new='Viewer#5678', new2='Viewer#5678'))
ok(v.get('/admin').status_code == 403, 'viewer cannot open admin')
t4 = tok(v.get('/groups').get_data(as_text=True)); v.post('/groups/save', data=dict(_csrf=t4, kind='VAT', group_id='X', name='x', rep='E03', members=['E03', 'E06']), follow_redirects=True)
ok(not any(g['group_id'] == 'X' for g in db().vat_groups()), 'viewer cannot create a group')
ok(c.get('/admin/backup').data[:6] == b'SQLite', 'backup download')
print('FAILURES', bad); sys.exit(1 if bad else 0)
