import os, sys, tempfile
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import openpyxl
from PyQt6.QtWidgets import QApplication, QFileDialog, QMessageBox
from core.db import DB
from core import vatgroup as VG, groupexport
from ui.common import STYLE
from ui.main_window import MainWindow
app = QApplication([]); app.setStyleSheet(STYLE)
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('boss', 'Secret#1234', 'Admin'); d.login('boss', 'Secret#1234'); d.load_sample()
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1

# ---- VAT: TRN match, name match, warning, period block
trn2 = d.entity('E02')['vat_trn']; pe = d.entity('E01')['vat_period_end']
d.vat_group_save('V1', 'Alpha VAT', '100', 'E01', ['E01', 'E02'], 'VAT')
r0 = VG.consolidate(d, d.vat_groups('VAT')[0])
name2 = d.entity('E02')['name']
d.add_rows('vat', 'E01', [dict(period_end=pe, doc_date=pe, doc_no='T1', party='Other', doc_type='Sale - standard rated', net=100000, vat=5000, trn=trn2, emirate='Dubai')])
r1 = VG.consolidate(d, d.vat_groups('VAT')[0])
ok(r1['intra_excluded_rows'] == 1 and r1['eliminations'][0]['how'] == 'TRN', 'TRN match eliminates the row')
d.add_rows('vat', 'E01', [dict(period_end=pe, doc_date=pe, doc_no='T2', party=name2.upper() + ' ', doc_type='Sale - standard rated', net=50000, vat=2500, trn='', emirate='Dubai')])
r2 = VG.consolidate(d, d.vat_groups('VAT')[0])
ok(r2['intra_excluded_rows'] == 2 and any(e['how'] == 'Name' for e in r2['eliminations']) and r2['warnings'], 'name-only match eliminates and warns')
ok(abs(r0['net'] - r2['net']) < 1, 'internal sales add nothing to the group VAT')
ok(r2['fta'] and r2['group_entity']['vat_trn'] == '100', 'group FTA return is built under the group TRN')
d.vat_group_delete('V1')
d.vat_group_save('V2', 'Mixed', '1', 'E01', ['E01', 'E04'], 'VAT')
try: VG.consolidate(d, d.vat_groups('VAT')[0]); ok(False, 'differing VAT periods blocked')
except VG.GroupError: ok(True, 'differing VAT periods blocked')
d.vat_group_delete('V2')
try: d.vat_group_save('X', 'x', '1', 'E01', ['E01'], 'VAT'); ok(False, 'single member refused')
except ValueError: ok(True, 'single member refused')

d.vat_group_save('V3', 'Alpha VAT', '100', 'E01', ['E01', 'E02'], 'VAT')
ok(len(d.vat_groups()) == 1, 'one VAT group saved')
try: d.vat_group_save('V4', 'Beta', 'T', 'E02', ['E02', 'E05'], 'VAT'); ok(False, 'member in two VAT groups refused')
except ValueError: ok(True, 'member cannot be in two VAT groups')

# ---- export
rv = VG.consolidate(d, d.vat_groups('VAT')[0]); out = os.path.join(tempfile.mkdtemp(), 'v.xlsx')
groupexport.export(out, 'VAT', d.vat_groups('VAT')[0], rv, 'Firm')
ok({'Group VAT 201 (FTA)', 'Eliminations', 'Members'} <= set(openpyxl.load_workbook(out).sheetnames), 'VAT export sheets')

# ---- UI
QMessageBox.information = staticmethod(lambda *a, **k: 0); QMessageBox.warning = staticmethod(lambda *a, **k: 0)
w = MainWindow(d); w.show(); app.processEvents()
gp = [p for p in w.pages if p.__class__.__name__ == 'GroupsPage'][0]
gp.reload(); app.processEvents()
ok(gp.vg.res is not None and gp.fv.res is not None and not hasattr(gp, 'cg') and not hasattr(gp, 'fc'), 'VAT group tabs build; no CT group tabs')
ok([gp.tabs.tabText(i) for i in range(gp.tabs.count())] == ['VAT groups', 'Group VAT 201 (FTA)'], 'group tabs are VAT only')
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (os.path.join(tempfile.mkdtemp(), 'o.xlsx'), ''))
gp.fv.export(); gp.vg.export(); ok(True, 'exports run')
for i in range(2):
    gp.tabs.setCurrentIndex(i); app.processEvents()
gp.grab().save(os.path.join(tempfile.gettempdir(), 'groups.png'))
print('FAILURES', bad); sys.exit(1 if bad else 0)
