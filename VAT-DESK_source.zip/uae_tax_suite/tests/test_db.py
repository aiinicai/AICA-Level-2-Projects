import sys, os, json, datetime as dt, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.db import DB, AuthError, PermissionDenied
p=os.path.join(tempfile.mkdtemp(),'t.db'); d=DB(p)
d.create_user('admin','Admin#12345','Admin'); d.create_user('view','View#12345','Viewer')
try: d.login('admin','wrong'); print('FAIL')
except AuthError: pass
d.login('admin','Admin#12345'); d.load_sample()
res=d.compute(dt.date(2026,10,28)); o=json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'fixtures','calc_out.json')))
for a,b in (('vat','vat_calc'),):
    for x,y in zip(res[a][:5],o[b][:5]):   # E06 differs: its schedules now carry arm's length values
        for k in y:
            if x[k]!=y[k] and not (isinstance(x[k],(int,float)) and abs(x[k]-y[k])<1e-6): print('DIFF',a,k,x[k],y[k])
print('entities',len(res['entities']),'issues',len(res['issues']))
d.login('view','View#12345')
try: d.save_entity({'id':'X','name':'x'}); print('FAIL perm')
except PermissionDenied: print('viewer blocked ok')
for i in range(5):
    try: d.login('view','bad')
    except AuthError: pass
try: d.login('view','View#12345'); print('FAIL lock')
except AuthError as e: print('lock ok')
print('audit rows',len(d.audit_log()))
