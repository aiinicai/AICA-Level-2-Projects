import sys, os, tempfile, datetime as dt, sqlite3
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.db import DB, PermissionDenied
from core import dataio, validate as V, recon as RC
import openpyxl

def mk():
    d = DB(os.path.join(tempfile.mkdtemp(), 't.db'))
    d.create_user('admin', 'Admin#12345', 'Admin'); d.create_user('prep', 'Prep#123456', 'Preparer'); d.create_user('rev', 'Rev#1234567', 'Reviewer')
    d.login('admin', 'Admin#12345'); d.load_sample()
    return d

def ok(c, m):
    print(('ok   ' if c else 'FAIL ') + m)
    if not c: ok.bad += 1
ok.bad = 0

d = mk()
eid = 'E01'
vpe = d.current_periods(eid)[0]

# ---- rules log
try: d.set_rule('vat_rate', 0.06); ok(False, 'rule change without reason refused')
except ValueError: ok(True, 'rule change without reason refused')
rate = next(r for r in d.rules() if r['key'] == 'vat_rate')['value']
d.set_rule('vat_rate', rate, 'same'); ok(len(d.rules_log()) == 0, 'unchanged value not logged')
d.set_rule('vat_rate', 0.06, 'Test decision', '2027-01-01'); lg = d.rules_log()
ok(len(lg) == 1 and lg[0]['reason'] == 'Test decision' and lg[0]['effective_from'] == '2027-01-01', 'rule change logged with reason and date')
d.set_rule('vat_rate', rate, 'revert')
ok(d.rules_review_age() is None, 'never reviewed')
d.mark_rules_reviewed(); ok(d.rules_review_age() == 0 and d.rules_review_age(dt.date.today() + dt.timedelta(days=91)) == 91, 'rules review age')
d.login('prep', 'Prep#123456')
try: d.set_rule('vat_rate', 0.07, 'x y z'); ok(False, 'preparer cannot change rules')
except PermissionDenied: ok(True, 'preparer cannot change rules')

# ---- validation
d.login('admin', 'Admin#12345')
R = d.rules_dict()
bad = [dict(period_end=vpe, doc_date=vpe, doc_no='A1', party='X', doc_type='Sale - zero rated', net=1000, vat=40, trn='123', emirate='Dubai'),
       dict(period_end=vpe, doc_date=vpe, doc_no='A1', party='X', doc_type='Sale - zero rated', net=1000, vat=40, trn='123', emirate='Dubai')]
iss = V.validate('vat', bad, R, d.entity(eid)); e, w = V.summary(iss)
ok(e >= 2 and any('duplicate' in i['message'].lower() for i in iss), 'validation finds wrong VAT and duplicates (%d errors, %d warnings)' % (e, w))
good = [dict(period_end=vpe, doc_date=vpe, doc_no='A2', party='X', doc_type='Sale - standard rated', net=1000, vat=50, trn='100123456700003', emirate='Dubai')]
ok(V.summary(V.validate('vat', good, R, d.entity(eid)))[0] == 0, 'valid VAT row passes')

# ---- import validation
wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'VAT Data'
ws.append(['Entity ID', 'VAT period end', 'Document date', 'Document no.', 'Customer / supplier name', 'Transaction type', 'Taxable value excl. VAT (AED)', 'VAT amount (AED)', 'Remarks / supporting documents', 'Customer / supplier TRN', 'Emirate / place of supply'])
ws.append([eid, vpe, vpe, 'Z1', 'Cust', 'Sale - zero rated', 1000, 40, '', '123', 'Dubai'])
p2 = os.path.join(tempfile.mkdtemp(), 'v.xlsx'); wb.save(p2)
before = len(d.rows('vat', eid))
r = dataio.import_upload(d, p2, 'vat', 'append')
ok(r['blocked'] and r['imported'] == 0 and len(d.rows('vat', eid)) == before, 'import with errors is blocked and writes nothing')
r = dataio.import_upload(d, p2, 'vat', 'append', force=True)
ok(not r['blocked'] and r['imported'] == 1 and len(d.rows('vat', eid)) == before + 1, 'forced import writes')

# ---- reconciliation
res = d.compute(); b = dataio.entity_bundle(d, eid, res)
ok(any(x['area'] == 'VAT' for x in b['recon']) and isinstance(RC.open_differences(b['recon']), int), 'recon rows built (%d)' % len(b['recon']))
b2 = dataio.entity_bundle(d, 'E03', res); ok(isinstance(b2['recon'], list), 'recon for entity without ledger balances')
x = os.path.join(tempfile.mkdtemp(), 'p.xlsx'); dataio.export_entity_xlsx(x, b, 'Firm'); dataio.export_entity_pdf(x.replace('.xlsx', '.pdf'), b, 'Firm')
ok('Reconciliations' in openpyxl.load_workbook(x).sheetnames, 'export has Reconciliations sheet; pdf written')

# ---- sign-off and locking
vrows = d.rows('vat', eid)
d.login('prep', 'Prep#123456')
d.signoff_submit(eid, 'VAT', vpe, 'ready', {'net_vat': 1})
try: d.signoff_approve(eid, 'VAT', vpe, 'ok'); ok(False, 'preparer cannot approve')
except PermissionDenied: ok(True, 'preparer cannot approve (role)')
d.login('admin', 'Admin#12345')
d.signoff_return(eid, 'VAT', vpe, 'fix the Z1 line'); ok(d.signoff_get(eid, 'VAT', vpe)['status'] == 'Draft', 'returned to draft')
d.signoff_submit(eid, 'VAT', vpe, 'resubmit')
try: d.signoff_approve(eid, 'VAT', vpe, 'self'); ok(False, 'four-eyes enforced')
except PermissionDenied: ok(True, 'four-eyes: preparer cannot approve own work')
d.login('rev', 'Rev#1234567')
try: d.signoff_approve(eid, 'VAT', vpe, '', open_differences=2); ok(False, 'open differences need a note')
except ValueError: ok(True, 'approval with open differences needs a note')
d.signoff_approve(eid, 'VAT', vpe, 'differences are timing only', {'net_vat': 5}, 2)
ok(d.is_locked(eid, 'VAT', vpe), 'approved period locked')
d.login('prep', 'Prep#123456')
for name, fn in (('add rows', lambda: d.add_rows('vat', eid, [dict(period_end=vpe, doc_date=vpe, doc_type='Sale - standard rated', net=1, vat=0)])),
                 ('replace rows', lambda: d.add_rows('vat', eid, [], replace=True)),
                 ('delete rows', lambda: d.delete_rows('vat', eid)),
                 ('save grid with change', lambda: d.save_rows('vat', eid, [dict(r, net=(r['net'] or 0) + 1) for r in d.rows('vat', eid)])),
                 ('connector replace', lambda: d.replace_in_range('vat', eid, [], '2000-01-01', '2100-01-01'))):
    try: fn(); ok(False, 'locked: ' + name + ' refused')
    except PermissionDenied: ok(True, 'locked: ' + name + ' refused')
unchanged = [{k: r[k] for k in ('period_end', 'doc_date', 'doc_no', 'party', 'doc_type', 'net', 'vat', 'description', 'trn', 'emirate')} for r in d.rows('vat', eid)]
d.save_rows('vat', eid, unchanged); ok(len(d.rows('vat', eid)) == len(unchanged), 'grid save with locked rows unchanged is allowed')
ent = d.entity(eid)
try: d.save_entity(dict(ent, std_supplies=(ent.get('std_supplies') or 0) + 1)); ok(False, 'locked: client record change refused')
except PermissionDenied: ok(True, 'locked: client record change refused')
d.login('rev', 'Rev#1234567')
try: d.signoff_reopen(eid, 'VAT', vpe, ''); ok(False, 'reopen needs reason')
except ValueError: ok(True, 'reopen needs a reason')
d.signoff_reopen(eid, 'VAT', vpe, 'late credit note'); ok(not d.is_locked(eid, 'VAT', vpe), 'reopened')
hist = [h['action'] for h in d.signoff_history(eid)]
ok(any('Approved' in h for h in hist) and 'Reopened' in hist and any('Returned' in h for h in hist), 'history kept: %s' % hist[:5])
d.login('admin', 'Admin#12345'); d.set_setting('allow_self_approval', 'Yes')
d.signoff_submit(eid, 'VAT', vpe, 'x'); d.signoff_approve(eid, 'VAT', vpe, 'sole practitioner'); ok(d.is_locked(eid, 'VAT', vpe), 'self-approval when allowed')

# ---- backup / restore
bk = os.path.join(tempfile.mkdtemp(), 'b.db'); d.backup_to(bk)
n_before = len(d.entities()); d.delete_entity('E06') if d.entity('E06') else None
ok(len(d.entities()) == n_before - 1, 'entity deleted for the restore test')
safety = d.restore_from(bk); ok(len(d.entities()) == n_before and os.path.exists(safety), 'restore brings data back and keeps a safety copy')
try: d.restore_from(__file__); ok(False, 'non-database refused')
except ValueError: ok(True, 'restore refuses a file that is not a backup')
bd = d.backup_dir(); a = d.auto_backup(dt.date(2026, 1, 1)); ok(a and os.path.exists(a) and d.auto_backup(dt.date(2026, 1, 1)) is None, 'auto backup once a day')
d.set_setting('backup_keep', '3')
for i in range(2, 7): d.auto_backup(dt.date(2026, 1, i))
ok(len([f for f in os.listdir(bd) if f.startswith('uae_tax_auto_')]) == 3, 'auto backups pruned to the newest 3')

# ---- roll forward
d = mk()
vpe = d.current_periods('E01')[0]
try: d.roll_forward('E01', None, False, True); ok(False, 'roll forward needs approval')
except ValueError: ok(True, 'roll forward needs approval of the period')
ch = d.roll_forward('E01', None, False, True, force=True); e = d.entity('E01'); nv = d.current_periods('E01')[0]
ok(nv > vpe and e['vat_filed'] == 'No', 'VAT period advanced: %s -> %s' % (vpe, nv))
print(ch)
print('FAILURES', ok.bad)
sys.exit(1 if ok.bad else 0)
