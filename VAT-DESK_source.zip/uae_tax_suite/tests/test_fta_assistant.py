import unittest, tempfile
from pathlib import Path
from openpyxl import Workbook
from fta_assistant.engine import parse_template, build_pack

class AssistantTests(unittest.TestCase):
    def test_vat_inconsistent_trn(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'vat.xlsx';w=Workbook();s=w.active;s.title='VAT 201 Return';s['A2']='Example | TRN 123456789012345'
            for i,b in enumerate(['1a','1b','1c','1d','1e','1f','1g','2','3','4','5','6','7','8','9','10','11','12','13','14'],6):s.cell(i,1,b);s.cell(i,3,0);s.cell(i,4,0);s.cell(i,5,0)
            d=w.create_sheet('Taxpayer and Filing');d['A4']='TRN';d['B4']='123456789012346';w.save(path)
            result=parse_template(path,'VAT');self.assertTrue(any('TRN MISMATCH' in x for x in result['errors']))
            out=Path(td)/'pack.zip';build_pack(result,out);self.assertTrue(out.exists())
    def test_ct_template_not_supported(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'ct.xlsx';w=Workbook();s=w.active;s.title='Table 1';w.save(path)
            with self.assertRaises(ValueError):parse_template(path,'CT')
if __name__=='__main__':unittest.main()
