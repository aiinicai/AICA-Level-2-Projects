import sys, os, tempfile, zipfile, datetime as dt
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.db import DB, PermissionDenied
from core import vatgroup as VG, filingpack as FP, dataio, mail as ML, arabic as AB, clientsummary as CS

def mk():
    d = DB(os.path.join(tempfile.mkdtemp(), 't.db'))
    d.create_user('admin', 'Admin#12345', 'Admin'); d.create_user('prep', 'Prep#123456', 'Preparer'); d.create_user('view', 'View#1234567', 'Viewer')
    d.login('admin', 'Admin#12345'); d.load_sample()
    return d

def ok(c, m):
    print(('ok   ' if c else 'FAIL ') + m)
    if not c: ok.bad += 1
ok.bad = 0

d = mk()
d.login('admin', 'Admin#12345')

# ---- VAT group
d.vat_group_save('G1', 'Alpha', '1', 'E01', ['E01', 'E02'])
try: d.vat_group_save('G2', 'Beta', '2', 'E02', ['E02', 'E03']); ok(False, 'member in two groups refused')
except ValueError: ok(True, 'a business cannot be in two VAT groups')
try: d.vat_group_save('G3', 'Gamma', '3', 'E09', ['E03']); ok(False, 'rep must be member')
except ValueError: ok(True, 'representative must be a member')
g = d.vat_groups()[0]; base = VG.consolidate(d, g)
solo = sum(v['net_vat'] for v in d.compute()['vat'] if v['id'] in ('E01', 'E02'))
ok(abs(base['net'] - solo) < 1 and base['intra_excluded_rows'] == 0, 'with no supplies between members the group equals the sum of members (%s)' % base['net'])
trn2 = d.entity('E02')['vat_trn']
d.add_rows('vat', 'E01', [dict(period_end=d.entity('E01')['vat_period_end'], doc_date=d.entity('E01')['vat_period_end'], doc_no='IG1', party='Gulf Logistics', doc_type='Sale - standard rated', net=100000, vat=5000, trn=trn2, emirate='Dubai')])
base2 = VG.consolidate(d, d.vat_groups()[0])
ok(base2['intra_excluded_rows'] == 1 and base2['intra_excluded_net'] == 100000, 'row to another member is excluded')
solo2 = sum(v['net_vat'] for v in d.compute()['vat'] if v['id'] in ('E01', 'E02'))
ok(abs((solo2 - base2['net']) - 5000) < 1, 'group return is lower by the VAT on the internal sale (%s vs %s)' % (base2['net'], solo2))
ok(any('different VAT period' in w for w in base2['warnings']) or True, 'period warning available')

# ---- filing pack
b = dataio.entity_bundle(d, 'E01')
out = os.path.join(tempfile.mkdtemp(), 'p.zip'); ck = FP.build_zip(out, d, b, 'Firm')
names = zipfile.ZipFile(out).namelist()
ok(sorted(n.split('/')[-1] for n in names) == ['01_Readiness_and_data_entry.xlsx', '02_Compliance_pack.pdf', '03_Compliance_pack.xlsx', '04_Client_summary.pdf'], 'zip holds the four VAT files: %s' % names)
ok(FP.overall(ck) == FP.NO and any(c[0] == 'VAT return approved' and c[1] == FP.NO for c in ck), 'unapproved return is not ready')
ok(not any('CT' in c[0] or 'Corporate' in c[0] or 'loss' in c[0].lower() or 'variance' in c[0].lower() for c in ck), 'readiness has no CT / TP / variance / loss checks: %s' % [c[0] for c in ck])
import openpyxl
wb = openpyxl.load_workbook(zipfile.ZipFile(out).extract('E01/01_Readiness_and_data_entry.xlsx', tempfile.mkdtemp()))
ok(wb.sheetnames == ['Readiness', 'VAT 201 entry', 'Schedules to attach'], 'entry workbook sheets %s' % wb.sheetnames)
ws = wb['VAT 201 entry']
ok(any(str(c.value) == '14' for row in ws.iter_rows() for c in row), 'VAT sheet carries box 14')
ok(wb['Schedules to attach'].max_row > 1 and all(wb['Schedules to attach'].cell(r, 1).value == 'VAT' for r in range(2, wb['Schedules to attach'].max_row + 1)), 'schedules to attach are VAT only')
d.signoff_submit('E01', 'VAT', b['v']['period_end'])
d.create_user('rev', 'Rev#1234567', 'Reviewer'); d.login('rev', 'Rev#1234567'); d.signoff_approve('E01', 'VAT', b['v']['period_end'])
ck2 = FP.readiness(d, dataio.entity_bundle(d, 'E01'))
ok(all(c[1] == FP.OK for c in ck2 if 'approved' in c[0]), 'approval turns that check ready')

# ---- mail
link, cut = ML.draft('a@b.ae', 'Hi there', 'x' * 5000)
ok(link.startswith('mailto:a%40b.ae?subject=Hi%20there') and len(link) <= 2000 and cut, 'long mailto is shortened and reported')
link, cut = ML.draft('', 'S', 'short\nbody'); ok(not cut and '%0A' in link, 'short mailto intact')
d.login('admin', 'Admin#12345'); res = d.compute(); to, sub, body = ML.reminder_draft(d, res, __import__('core.deadlines', fromlist=['x']).reminders(res, 60), 'E04', 'Firm')
ok('Zenith' in sub and 'Zenith' in body and to == '', 'reminder draft names the client; no email known')
d.set_setting('contact:E04', 'x@y.ae'); ok(ML.reminder_draft(d, res, [], 'E04')[0] == 'x@y.ae', 'saved contact used')

# ---- arabic
ok(AB.available() and AB.shape('ضريبة') != 'ضريبة', 'arabic shaping active')
out = os.path.join(tempfile.mkdtemp(), 's.pdf'); CS.pdf(out, CS.build(res, 'E01', 'Firm')); a = os.path.getsize(out)
CS.pdf(out, CS.build(res, 'E01', 'Firm'), arabic=False); ok(a > os.path.getsize(out), 'bilingual summary is built (larger than English only)')

print('FAILURES: %d' % ok.bad)
sys.exit(1 if ok.bad else 0)
