import os, sys, tempfile
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PyQt6.QtWidgets import QApplication
from core.db import DB
from ui.common import STYLE
from ui.login import LoginDialog
from ui.main_window import MainWindow
from ui.clients import EntityDialog
from ui.data import Grid
app=QApplication([]); app.setStyleSheet(STYLE)
d=DB(os.path.join(tempfile.mkdtemp(),'t.db'))
dlg=LoginDialog(d,d.path,True); dlg.user.setText('boss'); dlg.pw.setText('Secret#1234'); dlg.pw2.setText('Secret#1234'); dlg.firm.setText('Firm X'); dlg.name.setText('Boss'); dlg.go()
print('first login', d.user['role']); dlg.grab().save('/tmp/login.png')
w=MainWindow(d); w.show()
# new client through the dialog
ed=EntityDialog(w.ctx,None)
ed.widgets['name'][1].setText('Test Trading LLC'); ed.widgets['location'][1].setCurrentText('Mainland')
ed.widgets['vat_registered'][1].setCurrentText('Yes'); ed.widgets['vat_frequency'][1].setCurrentText('Quarterly'); ed.widgets['vat_period_end'][1].setText('2026-09-30')
ed.widgets['vat_filed'][1].setCurrentText('No'); ed.widgets['vat_paid'][1].setCurrentText('No')
assert 'ct_registered' not in ed.widgets and 'fy_end' not in ed.widgets, 'client form has no CT fields'
ed.save(); w.ctx.refresh()
print('entities', [e['id'] for e in d.entities()])
# VAT rows through the grid
g=w.pages[2].grids['vat']; w.pages[2].combo.setCurrentIndex(0); 
g.add_row(); 
vals=['2026-09-30','2026-08-01','INV1','Cust','Sale - standard rated','100000','5000','','','']
for j,v in enumerate(vals): g.table.item(0,j).setText(v)
g.add_row()
for j,v in enumerate(['2026-09-30','2026-08-02','B1','Sup','Purchase - standard rated','40000','2000','','','']): g.table.item(1,j).setText(v)
g.save()
r=w.ctx.result(); v=r['vat'][0]; print('net vat',v['net_vat'],'status',v['vat_status'],'taxable',v['taxable_supplies'])
assert v['net_vat']==3000, v
# bad type rejected
g.add_row(); g.table.item(2,4).setText('Nonsense'); rows,errs=g.collect(); print('errs',errs[:1])
# checklist persistence
rp=w.pages[3]; rp.reload()
cl=rp.checks[0]; cl.table.cellWidget(0,3).setCurrentText('Done'); print('check saved', d.checklist('E01')[('VAT',cl.items[0]['item'])]['status'])
# penalties page
pp=[p for p in w.pages if p.__class__.__name__=='PenaltiesPage'][0]; pp.reload(); print('pen total', pp.vat.out.item(4,2).text())
# viewer permissions
d.create_user('view','Viewer#1234','Viewer'); d.logout(); d.login('view','Viewer#1234'); w.ctx.refresh()
assert 'Registers' not in w.page_names and w.windowTitle()=='VAT-DESK', w.page_names
print('viewer edit buttons', w.pages[1].b_new.isEnabled(), w.pages[2].grids['vat'].b_save.isEnabled(), 'delete', w.pages[1].b_del.isEnabled())
