import os, sys, tempfile
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication, QTableWidget, QLabel
from core.db import DB
from ui.common import STYLE
from ui.main_window import MainWindow
from ui.busy import BusyWindow, busy
app = QApplication([]); app.setStyleSheet(STYLE)
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
# busy window: minimise button, no close button, busy cursor set and restored
w = BusyWindow(None, "x"); fl = w.windowFlags()
ok(bool(fl & Qt.WindowType.WindowMinimizeButtonHint) and not (fl & Qt.WindowType.WindowCloseButtonHint), 'busy window can be minimised and has no close button')
w.begin(); ok(QApplication.overrideCursor() is not None and QApplication.overrideCursor().shape() == Qt.CursorShape.WaitCursor, 'busy cursor shown')
w.showMinimized(); app.processEvents(); ok(w.isMinimized(), 'busy window minimises')
w.end(); ok(QApplication.overrideCursor() is None, 'busy cursor restored')
try:
    with busy(None, "t"):
        ok(QApplication.overrideCursor() is not None, 'cursor busy inside with-block')
        raise ValueError('boom')
except ValueError:
    pass
ok(QApplication.overrideCursor() is None, 'cursor restored after an error')
# workings tabs no longer repeat the FTA-format figures
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('boss', 'Secret#1234', 'Admin'); d.login('boss', 'Secret#1234'); d.load_sample()
mw = MainWindow(d); mw.show(); app.processEvents()
rp = [p for p in mw.pages if p.__class__.__name__ == 'ReturnsPage'][0]
rp.combo.setCurrentIndex(0); rp.build(); app.processEvents()
tabs = {rp.tabs.tabText(i): rp.tabs.widget(i) for i in range(rp.tabs.count())}
def texts(tab):
    out = []
    for t in tab.findChildren(QTableWidget):
        for r in range(t.rowCount()):
            for c in range(t.columnCount()):
                it = t.item(r, c)
                if it: out.append(it.text())
    return out
vw = texts(tabs['VAT Return basis'])
ok(not any('Section 2' in x for x in vw) and not any(x.startswith('Taxable person') for x in vw), 'VAT workings do not repeat the return boxes or taxpayer details')
ok(any('Schedules 1 to 3' in x for x in vw) and any('Ledger reconciliation' in x for x in vw), 'VAT workings keep basis notes and checks')
ok(not any('CT' in n or 'TP' in n or 'Corporate' in n or 'Transfer' in n for n in tabs), 'no CT / TP tabs on Returns and workings: %s' % list(tabs))
ok(any('Standard Rated' in x or 'Standard rated' in x for x in texts(tabs['VAT 201 (FTA format)'])), 'FTA format tab still shows every figure')
names = list(tabs)
ok(names[-2:] == ['Working paper checklists', 'VAT Return basis'], 'tab order: %s' % names)
ok('Registers' not in mw.page_names, 'no Registers page')
print('FAILURES', bad); sys.exit(1 if bad else 0)
