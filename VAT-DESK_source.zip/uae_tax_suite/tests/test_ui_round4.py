import os, sys, tempfile, zipfile
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PyQt6.QtWidgets import QApplication, QFileDialog, QMessageBox, QInputDialog
from core.db import DB
from ui.common import STYLE
from ui.main_window import MainWindow
import ui.planner as PL, ui.returns as RTN
app = QApplication([]); app.setStyleSheet(STYLE)
d = DB(os.path.join(tempfile.mkdtemp(), 't.db')); d.create_user('boss', 'Secret#1234', 'Admin'); d.login('boss', 'Secret#1234'); d.load_sample()
w = MainWindow(d); w.show(); app.processEvents()
bad = 0
def ok(c, m):
    global bad
    print(('ok   ' if c else 'FAIL ') + m); bad += 0 if c else 1
page = lambda n: [p for p in w.pages if p.__class__.__name__ == n][0]
ok('RegistersPage' not in [p.__class__.__name__ for p in w.pages], 'no Registers page')
# filing pack button
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
out = os.path.join(tempfile.mkdtemp(), 'f.zip')
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (out, ''))
QMessageBox.information = staticmethod(lambda *a, **k: None)
rp = page('ReturnsPage'); rp.combo.setCurrentIndex(3); rp.build(); rp.exp_f()
ok(os.path.exists(out) and 'E04/02_Compliance_pack.pdf' in zipfile.ZipFile(out).namelist(), 'filing pack button writes the zip')
# email draft
opened = []
PL.QDesktopServices.openUrl = staticmethod(lambda u: opened.append(u.toString()) or True)
QInputDialog.getText = staticmethod(lambda *a, **k: ('client@zenith.ae', True))
pl = page('PlannerPage'); pl.fill_rem(); r = next(i for i, x in enumerate(pl._rem) if x['id'] == 'E04'); pl.rem.selectRow(r); pl.email_client()
ok(opened and opened[0].startswith('mailto:client%40zenith.ae') and d.setting('contact:E04') == 'client@zenith.ae', 'email button opens a draft and remembers the address')
# groups page
gp = page('GroupsPage'); gp.vg.bar.refresh(); ok(gp.vg.bar.combo.count() == 0, 'no groups yet')
d.vat_group_save('G1', 'Alpha', '1', 'E01', ['E01', 'E02']); gp.vg.bar.refresh(); ok(gp.vg.res is not None and gp.vg.t.rowCount() > 10, 'group return builds')
print('FAILURES', bad); sys.exit(1 if bad else 0)
