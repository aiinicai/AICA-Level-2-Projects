import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import json
import tempfile
import unittest
from pathlib import Path
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import QApplication
from core.db import DB, PermissionDenied
from fta_assistant import saved
from fta_assistant.engine import build_pack
from fta_assistant.widget import FilingAssistantPage

app = QApplication.instance() or QApplication([])

class Context(QObject):
    changed = pyqtSignal()
    def __init__(self, db):
        super().__init__()
        self.db = db

class SavedTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = DB(str(Path(self.tmp.name)/'test.db'))
        self.db.create_user('admin', 'Admin#12345', 'Admin')
        self.db.login('admin', 'Admin#12345')
        self.db.load_sample()
        self.eid = self.db.entities()[0]['id']

    def tearDown(self):
        self.db.c.close()
        self.tmp.cleanup()

    def test_current_read_only_vat(self):
        for kind in ('VAT',):
            before = self.db.c.total_changes
            result = saved.fetch(self.db, self.eid, kind, saved.periods(self.db, self.eid, kind)[0])
            self.assertEqual(before, self.db.c.total_changes)
            self.assertGreater(len(result['records']), 20)
            self.assertEqual(result['metadata']['client_id'], self.eid)

    def test_latest_snapshot_and_export(self):
        saved.save(self.db, self.eid)
        saved.save(self.db, self.eid)
        period = saved.periods(self.db, self.eid, 'VAT')[0]
        result = saved.fetch(self.db, self.eid, 'VAT', period)
        self.assertGreaterEqual(result['metadata']['snapshot_version'], 1)
        self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM filing_snapshots WHERE kind='CT'").fetchone()[0], 0)
        build_pack(result, Path(self.tmp.name)/'pack.zip')
        import zipfile
        with zipfile.ZipFile(Path(self.tmp.name)/'pack.zip') as z:
            self.assertIn('value', z.read('fields.csv').decode('utf-8-sig').splitlines()[0])

    def test_historical_frozen(self):
        saved.save(self.db, self.eid)
        old = saved.periods(self.db, self.eid, 'VAT')[0]
        before = saved.fetch(self.db, self.eid, 'VAT', old)['records']
        entity = self.db.entity(self.eid)
        entity['vat_period_end'] = '2030-12-31'
        self.db.save_entity(entity)
        self.assertIn(old, saved.periods(self.db, self.eid, 'VAT'))
        self.assertEqual(before, saved.fetch(self.db, self.eid, 'VAT', old)['records'])

    def test_invalid_selection_and_visibility(self):
        with self.assertRaises(ValueError):
            saved.fetch(self.db, self.eid, 'VAT', '1900-01-01')
        with self.assertRaises(PermissionError):
            saved.periods(self.db, 'unavailable', 'VAT')

    def test_ui_copy_refresh_and_excel_alternative(self):
        ctx = Context(self.db)
        page = FilingAssistantPage(ctx)
        self.assertIsNotNone(page.result)
        self.assertGreater(page.fields.rowCount(), 20)
        page.fields.cellWidget(0, 3).click()
        self.assertEqual(app.clipboard().text(), page.fields.item(0, 2).text())
        self.assertEqual(page.result['type'], 'VAT')
        self.assertEqual([page.kind.itemText(i) for i in range(page.kind.count())], ['VAT'])
        page.client.setCurrentIndex(1)
        self.assertEqual(page.result['metadata']['client_id'], page.client.currentData())
        ctx.changed.emit()
        self.assertTrue(callable(page.browse))
        page.close()

    def test_full_window_and_returns_save_action(self):
        from ui.main_window import MainWindow
        from unittest.mock import patch
        window = MainWindow(self.db)
        returns = window.pages[3]
        with patch('ui.returns.info'):
            returns.save_snapshot()
        self.assertEqual(self.db.c.execute('SELECT COUNT(*) FROM filing_snapshots').fetchone()[0], 1)
        window.pages[4].fetch()
        self.assertIn('snapshot_version', window.pages[4].result['metadata'])
        window.close()

    def test_viewer_cannot_save(self):
        self.db.create_user('viewer', 'Viewer#12345', 'Viewer')
        self.db.login('viewer', 'Viewer#12345')
        with self.assertRaises(PermissionDenied):
            saved.save(self.db, self.eid)

if __name__ == '__main__':
    unittest.main()
