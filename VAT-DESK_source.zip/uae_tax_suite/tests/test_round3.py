import sys, os, tempfile, datetime as dt
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.db import DB, PermissionDenied
from core import deadlines as DL

def mk():
    d = DB(os.path.join(tempfile.mkdtemp(), 't.db'))
    d.create_user('admin', 'Admin#12345', 'Admin'); d.create_user('prep', 'Prep#123456', 'Preparer'); d.create_user('rev', 'Rev#1234567', 'Reviewer')
    d.login('admin', 'Admin#12345'); d.load_sample()
    return d

def ok(c, m):
    print(('ok   ' if c else 'FAIL ') + m)
    if not c: ok.bad += 1
ok.bad = 0

# ---------------- item 6: deadlines
d = mk(); res = d.compute()
en = DL.enrich(res)
ok(len(en) == len(res['calendar']) and all('penalty_now' in r for r in en), 'every calendar row enriched')
od = [r for r in en if r['days_left'] < 0 and r['code'] == 'VAT']
ok(all(r['code'] == 'VAT' for r in en), 'the calendar holds VAT obligations only')
pen = {(x['id']): x for x in res['vat']}
ok(all(r['penalty_now'] >= 0 for r in od), 'penalties are non-negative')
for r in od:
    if r['code'] == 'VAT':
        v = next(x for x in res['vat'] if x['id'] == r['id'])
        ok(r['penalty_now'] == v['vat_penalty'], 'VAT overdue penalty equals the engine figure for %s (%s)' % (r['id'], r['penalty_now'])); break
ok(all(r['penalty_in_30'] >= r['penalty_now'] for r in en), 'penalty never falls as time passes')
rem = DL.reminders(res, 30)
ok(rem == sorted(rem, key=lambda r: r['days_left']) and all(r['days_left'] <= 30 for r in rem), 'reminders sorted and within window')
ics = DL.to_ics(rem)
ok(ics.startswith('BEGIN:VCALENDAR') and ics.count('BEGIN:VEVENT') == len(rem) and ics.count('BEGIN:VALARM') == 2 * len(rem), 'ics has an event and two alarms per reminder')
ok('Client ID' in DL.to_csv(rem).splitlines()[0], 'csv header')
if rem:
    ok(rem[0]['entity'] in DL.client_email(rem[0]['entity'], rem, 'Firm'), 'client email names the client')
ok('overdue' in DL.status_line(res), 'status line')

# ---------------- UAE-wide: client assignment
d = mk(); allc = {e['id'] for e in d.entities()}
d.assign_clients('prep', ['E01', 'E02'])
d.login('prep', 'Prep#123456')
ok({e['id'] for e in d.entities()} == {'E01', 'E02'} and {e['id'] for e in d.compute()['entities']} == {'E01', 'E02'}, 'assigned user sees only their clients everywhere')
try: d.save_entity(dict(d.entity('E03'))); ok(False, 'cannot edit unassigned client')
except PermissionDenied: ok(True, 'cannot edit unassigned client')
d.save_entity(dict(id='E99', name='New client', location='Mainland')); ok('E99' in {e['id'] for e in d.entities()}, 'a restricted user sees a client they create')
d.login('admin', 'Admin#12345'); ok({e['id'] for e in d.entities()} == allc | {'E99'}, 'admin sees all')
d.assign_clients('prep', []); d.login('prep', 'Prep#123456'); ok(len(d.entities()) == len(allc) + 1, 'clearing assignments removes the limit')

# ---------------- wizard + client summary
from ui.wizard import apply_setup
from core import clientsummary as CS
d = DB(os.path.join(tempfile.mkdtemp(), 'w.db')); d.create_user('admin', 'Admin#12345', 'Admin'); d.login('admin', 'Admin#12345')
apply_setup(d, 'Acme Tax', 'Sharjah', 'a@b.ae', '', dict(name='Test LLC', location='Free Zone', vat_registered='No'))
ok(d.setting('firm') == 'Acme Tax' and d.setting('default_emirate') == 'Sharjah' and d.setting('setup_done') == '1', 'wizard saves firm settings')
ok(len(d.entities()) == 1 and d.entities()[0]['location'] == 'Free Zone', 'wizard creates the first client')
r = d.compute(); ok(len(r['entities']) == 1, 'a minimal new client computes without error')
CS.pdf(os.path.join(tempfile.mkdtemp(), 's.pdf'), CS.build(r, d.entities()[0]['id'], 'Acme Tax')); ok(True, 'client summary pdf for a minimal client')
d2 = mk(); res = d2.compute()
for e in res['entities']:
    s_ = CS.build(res, e['id'], 'Firm'); out = os.path.join(tempfile.mkdtemp(), 's.pdf'); CS.pdf(out, s_)
    assert os.path.getsize(out) > 1500
ok(True, 'client summary pdf for all six sample clients')
txt = repr(CS.build(res, 'E01', 'Firm'))
ok('risk' not in txt.lower() and 'Prepared' not in txt, 'summary leaves out internal risk and reviewer detail')
print('FAILURES: %d' % ok.bad)
sys.exit(1 if ok.bad else 0)
