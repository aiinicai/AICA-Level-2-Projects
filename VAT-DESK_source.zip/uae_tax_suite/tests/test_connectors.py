import os, sys, json, threading, http.server, datetime as dt, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from core.connectors import tally, zoho, frappe
from core.connectors.common import period_end_for

# ---------------------------------------------------------------- mock Tally
DAYBOOK = """<ENVELOPE><BODY><DATA><TALLYMESSAGE>
<VOUCHER VCHTYPE="Sales" ACTION="Create"><DATE>20260715</DATE><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME><VOUCHERNUMBER>S-1</VOUCHERNUMBER><PARTYLEDGERNAME>Cust A</PARTYLEDGERNAME>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Cust A</LEDGERNAME><ISPARTYLEDGER>Yes</ISPARTYLEDGER><AMOUNT>-10500</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales</LEDGERNAME><AMOUNT>10000</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Output VAT 5%</LEDGERNAME><AMOUNT>500</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Sales"><DATE>20260801</DATE><VOUCHERNUMBER>S-2</VOUCHERNUMBER><PARTYLEDGERNAME>Overseas</PARTYLEDGERNAME>
 <LEDGERENTRIES.LIST><LEDGERNAME>Overseas</LEDGERNAME><ISPARTYLEDGER>Yes</ISPARTYLEDGER><AMOUNT>-4000</AMOUNT></LEDGERENTRIES.LIST>
 <LEDGERENTRIES.LIST><LEDGERNAME>Export Sales</LEDGERNAME><AMOUNT>4000</AMOUNT></LEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Sales"><DATE>20260802</DATE><VOUCHERNUMBER>S-3</VOUCHERNUMBER><PARTYLEDGERNAME>X</PARTYLEDGERNAME>
 <LEDGERENTRIES.LIST><LEDGERNAME>X</LEDGERNAME><ISPARTYLEDGER>Yes</ISPARTYLEDGER><AMOUNT>-700</AMOUNT></LEDGERENTRIES.LIST>
 <LEDGERENTRIES.LIST><LEDGERNAME>Service income</LEDGERNAME><AMOUNT>700</AMOUNT></LEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Purchase"><DATE>20260820</DATE><VOUCHERNUMBER>P-1</VOUCHERNUMBER><PARTYLEDGERNAME>Sup</PARTYLEDGERNAME>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Sup</LEDGERNAME><ISPARTYLEDGER>Yes</ISPARTYLEDGER><AMOUNT>2100</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Purchases</LEDGERNAME><AMOUNT>-2000</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Input VAT</LEDGERNAME><AMOUNT>-100</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Purchase"><DATE>20260821</DATE><VOUCHERNUMBER>P-2</VOUCHERNUMBER><PARTYLEDGERNAME>Sup</PARTYLEDGERNAME>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Hospitality</LEDGERNAME><AMOUNT>-400</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Input VAT blocked</LEDGERNAME><AMOUNT>-20</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Credit Note"><DATE>20260901</DATE><VOUCHERNUMBER>CN-1</VOUCHERNUMBER><PARTYLEDGERNAME>Cust A</PARTYLEDGERNAME>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales Returns</LEDGERNAME><AMOUNT>-1000</AMOUNT></ALLLEDGERENTRIES.LIST>
 <ALLLEDGERENTRIES.LIST><LEDGERNAME>Output VAT 5%</LEDGERNAME><AMOUNT>-50</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>
<VOUCHER VCHTYPE="Sales"><DATE>20260905</DATE><ISCANCELLED>Yes</ISCANCELLED><VOUCHERNUMBER>S-9</VOUCHERNUMBER></VOUCHER>
<VOUCHER VCHTYPE="Receipt"><DATE>20260906</DATE><VOUCHERNUMBER>R-1</VOUCHERNUMBER></VOUCHER>
</TALLYMESSAGE></DATA></BODY></ENVELOPE>"""
GROUPS = "<ENVELOPE><BODY><DATA><COLLECTION><GROUP NAME=\"Sales Accounts\"><PARENT></PARENT></GROUP><GROUP NAME=\"Indirect Expenses\"><PARENT></PARENT></GROUP><GROUP NAME=\"Marketing\"><PARENT>Indirect Expenses</PARENT></GROUP><GROUP NAME=\"Bank Accounts\"><PARENT>Current Assets</PARENT></GROUP><GROUP NAME=\"Indirect Incomes\"><PARENT></PARENT></GROUP></COLLECTION></DATA></BODY></ENVELOPE>"
LEDGERS = "<ENVELOPE><BODY><DATA><COLLECTION><LEDGER NAME=\"Product Sales\"><PARENT>Sales Accounts</PARENT><CLOSINGBALANCE>1500000.00</CLOSINGBALANCE></LEDGER><LEDGER NAME=\"Ads\"><PARENT>Marketing</PARENT><CLOSINGBALANCE>-200000.00</CLOSINGBALANCE></LEDGER><LEDGER NAME=\"Client entertainment\"><PARENT>Indirect Expenses</PARENT><CLOSINGBALANCE>-40000</CLOSINGBALANCE></LEDGER><LEDGER NAME=\"Bank interest\"><PARENT>Indirect Incomes</PARENT><CLOSINGBALANCE>5000</CLOSINGBALANCE></LEDGER><LEDGER NAME=\"HSBC\"><PARENT>Bank Accounts</PARENT><CLOSINGBALANCE>-99999</CLOSINGBALANCE></LEDGER></COLLECTION></DATA></BODY></ENVELOPE>"
COMPANIES = "<ENVELOPE><BODY><DATA><COLLECTION><COMPANY NAME=\"Al Noor Trading LLC\"></COMPANY></COLLECTION></DATA></BODY></ENVELOPE>"


class TallyH(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        need = getattr(TallyH, "need_key", "")
        if need and (self.headers.get("Authorization") != "Bearer " + need or self.headers.get("X-API-Key") != need):
            self.send_response(401); self.end_headers(); return
        b = self.rfile.read(int(self.headers["Content-Length"])).decode()
        out = DAYBOOK if "<ID>Day Book</ID>" in b else GROUPS if "UAEGroups" in b else LEDGERS if "UAELedgers" in b else COMPANIES
        self.send_response(200); self.end_headers(); self.wfile.write(out.encode())
    def log_message(self, *a): pass


# ---------------------------------------------------------------- mock Zoho
INV = {"invoice_id": "1", "invoice_number": "INV-1", "date": "2026-08-15", "customer_name": "Cust", "status": "sent", "exchange_rate": 1, "place_of_supply": "DU", "tax_total": 200,
       "line_items": [{"item_total": 4000, "tax_percentage": 5, "tax_name": "Standard Rate"}, {"item_total": 1000, "tax_percentage": 0, "tax_name": "Zero Rate"}]}
INV2 = {"invoice_id": "2", "invoice_number": "INV-2", "date": "2026-09-02", "customer_name": "USD cust", "status": "paid", "exchange_rate": 3.6725, "tax_total": 0,
        "line_items": [{"item_total": 100, "tax_percentage": 0, "tax_name": "Exempt"}]}
BILL = {"bill_id": "3", "bill_number": "B-1", "date": "2026-08-20", "vendor_name": "Sup", "status": "open", "exchange_rate": 1, "tax_total": 100,
        "line_items": [{"item_total": 2000, "tax_percentage": 5, "tax_name": "Standard Rate"}]}
CALLS = []


class ZohoH(http.server.BaseHTTPRequestHandler):
    def _send(self, j, code=200):
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps(j).encode())
    def do_POST(self):
        self._send({"access_token": "tok1", "refresh_token": "refresh1", "expires_in": 3600} if "grant_type=authorization_code" in self.path and "code=code1" in self.path else {"access_token": "tok1", "expires_in": 3600})
    def do_GET(self):
        import urllib.parse as up
        u = up.urlparse(self.path); q = up.parse_qs(u.query); CALLS.append(self.path)
        if self.headers.get("Authorization") != "Zoho-oauthtoken tok1":
            return self._send({"code": 57, "message": "bad token"}, 401)
        p = u.path.replace("/books/v3/", "")
        if p == "organizations": return self._send({"code": 0, "organizations": [{"organization_id": "999", "name": "Demo Org"}]})
        if q.get("organization_id") != ["999"]: return self._send({"code": 6, "message": "bad org"}, 400)
        lists = {"invoices": ("invoices", [{"invoice_id": "1", "status": "sent"}, {"invoice_id": "2", "status": "paid"}, {"invoice_id": "9", "status": "draft"}]),
                 "bills": ("bills", [{"bill_id": "3", "status": "open"}]), "creditnotes": ("creditnotes", []), "vendorcredits": ("vendor_credits", [])}
        if p in lists:
            k, rows = lists[p]
            return self._send({"code": 0, k: rows, "page_context": {"has_more_page": False}})
        det = {"invoices/1": ("invoice", INV), "invoices/2": ("invoice", INV2), "bills/3": ("bill", BILL)}
        if p in det: return self._send({"code": 0, det[p][0]: det[p][1]})
        self._send({"code": 5, "message": "nf"}, 404)
    def log_message(self, *a): pass


# ---------------------------------------------------------------- mock ERPNext / Frappe
SI1 = {"name": "SINV-1", "posting_date": "2026-08-15", "customer_name": "Cust", "tax_id": "100123456700003", "conversion_rate": 1, "base_total_taxes_and_charges": 200, "taxes_and_charges": "UAE VAT 5% - AN",
       "taxes": [{"charge_type": "On Net Total", "rate": 5, "description": "VAT 5%", "account_head": "UAE VAT 5% - AN"}],
       "items": [{"base_net_amount": 4000, "item_tax_rate": "{\"UAE VAT 5% - AN\": 5}"}, {"base_net_amount": 1000, "item_tax_rate": "{\"UAE VAT 5% - AN\": 0}", "item_tax_template": "UAE VAT Zero Rated - AN"}]}
SI2 = {"name": "SINV-2", "posting_date": "2026-09-02", "customer_name": "USD cust", "conversion_rate": 3.6725, "base_total_taxes_and_charges": 0, "taxes": [],
       "items": [{"base_net_amount": 367.25, "item_tax_template": "UAE VAT Exempted - AN"}]}
SI3 = {"name": "SINV-3", "posting_date": "2026-09-10", "customer_name": "Cust", "is_return": 1, "conversion_rate": 1, "base_total_taxes_and_charges": -50,
       "taxes": [{"charge_type": "On Net Total", "rate": 5, "description": "VAT 5%", "account_head": "VAT"}], "items": [{"base_net_amount": -1000}]}
PI1 = {"name": "PINV-1", "bill_no": "B-1", "posting_date": "2026-08-20", "supplier_name": "Sup", "conversion_rate": 1, "base_total_taxes_and_charges": 100,
       "taxes": [{"charge_type": "On Net Total", "rate": 5, "description": "Input VAT 5%", "account_head": "VAT"}], "items": [{"base_net_amount": 2000}]}
ACC = [{"name": "Sales - AN", "root_type": "Income", "account_type": "Income Account", "parent_account": "Direct Income - AN"},
       {"name": "Direct Income - AN", "root_type": "Income", "account_type": "", "parent_account": "Income - AN"},
       {"name": "Interest Income - AN", "root_type": "Income", "account_type": "Income Account", "parent_account": "Indirect Income - AN"},
       {"name": "Indirect Income - AN", "root_type": "Income", "account_type": "", "parent_account": "Income - AN"},
       {"name": "Income - AN", "root_type": "Income", "account_type": "", "parent_account": ""},
       {"name": "Cost of Goods Sold - AN", "root_type": "Expense", "account_type": "Cost of Goods Sold", "parent_account": "Expenses - AN"},
       {"name": "Client Entertainment - AN", "root_type": "Expense", "account_type": "Expense Account", "parent_account": "Indirect Expenses - AN"},
       {"name": "Depreciation - AN", "root_type": "Expense", "account_type": "Depreciation", "parent_account": "Indirect Expenses - AN"},
       {"name": "Exchange Gain/Loss - AN", "root_type": "Expense", "account_type": "Exchange Gain/Loss", "parent_account": "Indirect Expenses - AN"},
       {"name": "Indirect Expenses - AN", "root_type": "Expense", "account_type": "", "parent_account": "Expenses - AN"},
       {"name": "Expenses - AN", "root_type": "Expense", "account_type": "", "parent_account": ""},
       {"name": "Debtors - AN", "root_type": "Asset", "account_type": "Receivable", "parent_account": ""}]
GLE = [{"account": "Sales - AN", "debit": 0, "credit": 1500000}, {"account": "Interest Income - AN", "debit": 0, "credit": 5000}, {"account": "Cost of Goods Sold - AN", "debit": 800000, "credit": 0},
       {"account": "Client Entertainment - AN", "debit": 40000, "credit": 0}, {"account": "Depreciation - AN", "debit": 25000, "credit": 0}, {"account": "Exchange Gain/Loss - AN", "debit": 0, "credit": 1200},
       {"account": "Debtors - AN", "debit": 1500000, "credit": 0}]
FCALLS = []


class FrappeH(http.server.BaseHTTPRequestHandler):
    def _send(self, j, code=200):
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps(j).encode())
    def do_GET(self):
        import urllib.parse as up
        u = up.urlparse(self.path); q = {k: json.loads(v[0]) if v[0][:1] in "[{" or v[0].isdigit() else v[0] for k, v in up.parse_qs(u.query).items()}; FCALLS.append((up.unquote(u.path), q))
        if self.headers.get("Authorization") != "token KEY:SEC":
            return self._send({"exc_type": "AuthenticationError"}, 401)
        p = up.unquote(u.path)
        if p == "/api/method/frappe.auth.get_logged_user": return self._send({"message": "api@x.com"})
        if p == "/api/resource/Company": return self._send({"data": [{"name": "Al Noor Trading LLC"}]})
        if p == "/api/resource/Sales Invoice":
            assert ["docstatus", "=", 1] in q["filters"] and ["company", "=", "Al Noor Trading LLC"] in q["filters"]
            return self._send({"data": [{"name": "SINV-1"}, {"name": "SINV-2"}, {"name": "SINV-3"}][q["limit_start"]:q["limit_start"] + q["limit_page_length"]]})
        if p == "/api/resource/Purchase Invoice": return self._send({"data": [{"name": "PINV-1"}][q["limit_start"]:]})
        docs = {"/api/resource/Sales Invoice/SINV-1": SI1, "/api/resource/Sales Invoice/SINV-2": SI2, "/api/resource/Sales Invoice/SINV-3": SI3, "/api/resource/Purchase Invoice/PINV-1": PI1}
        if p in docs: return self._send({"data": docs[p]})
        if p == "/api/resource/Account": return self._send({"data": ACC[q["limit_start"]:q["limit_start"] + q["limit_page_length"]]})
        if p == "/api/resource/GL Entry":
            assert q.get("group_by") == "account" and ["voucher_type", "!=", "Period Closing Voucher"] in q["filters"]
            return self._send({"data": GLE[q["limit_start"]:q["limit_start"] + q["limit_page_length"]]})
        self._send({"exception": "not found"}, 404)
    def log_message(self, *a): pass


def serve(h):
    s = http.server.HTTPServer(("127.0.0.1", 0), h); threading.Thread(target=s.serve_forever, daemon=True).start(); return s, "http://127.0.0.1:%d" % s.server_port


s1, url = serve(TallyH)
TallyH.need_key = "gw-key"
try:
    tally.list_companies(url); raise SystemExit("gateway accepted a request without key")
except tally.TallyError as e:
    assert "refused the access key" in str(e)
tally.set_access_key("gw-key"); assert tally.list_companies(url) == ["Al Noor Trading LLC"]
TallyH.need_key = ""; tally.set_access_key("")
print('companies', tally.list_companies(url))
anchor = dt.date(2026, 9, 30)
f = tally.fetch_vat(url, "", dt.date(2026, 7, 1), dt.date(2026, 9, 30), anchor, 3)
for r in f.vat: print(r['doc_no'], r['doc_type'], r['net'], r['vat'], r['period_end'], '|', r['flag'][:30])
assert [r['doc_type'] for r in f.vat] == ['Sale - standard rated', 'Sale - zero rated', 'Sale - zero rated', 'Purchase - standard rated', 'Purchase - blocked input VAT', 'Sale - credit note'], [r['doc_type'] for r in f.vat]
assert f.vat[0]['net'] == 10000 and f.vat[0]['vat'] == 500 and f.vat[2]['flag'] and f.vat[5]['net'] == 1000 and f.vat[5]['vat'] == 50 and f.skipped >= 1
assert not hasattr(tally, 'fetch_trial_balance') and not hasattr(frappe, 'fetch_trial_balance'), 'trial balance (corporate tax) readers are gone'

# custom voucher types ("Tax Invoice" under Sales) and vouchers dated outside the range
import xml.etree.ElementTree as _ET
_x = _ET.fromstring("<E><VOUCHER VCHTYPE=\"Tax Invoice VAT\"><DATE>20260515</DATE><VOUCHERNUMBER>T-1</VOUCHERNUMBER><PARTYLEDGERNAME>C</PARTYLEDGERNAME>"
  "<ALLLEDGERENTRIES.LIST><LEDGERNAME>C</LEDGERNAME><ISPARTYLEDGER>Yes</ISPARTYLEDGER><AMOUNT>-105</AMOUNT></ALLLEDGERENTRIES.LIST>"
  "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales</LEDGERNAME><AMOUNT>100</AMOUNT></ALLLEDGERENTRIES.LIST>"
  "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Output VAT</LEDGERNAME><AMOUNT>5</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>"
  "<VOUCHER VCHTYPE=\"Tax Invoice VAT\"><DATE>20260807</DATE><VOUCHERNUMBER>T-2</VOUCHERNUMBER></VOUCHER>"
  "<VOUCHER VCHTYPE=\"Mystery\"><DATE>20260516</DATE></VOUCHER></E>")
_st = {}; _o = tally.parse_vouchers(_x, dt.date(2026, 7, 31), 3, vtmap={"tax invoice vat": "sales"}, d1=dt.date(2026, 5, 1), d2=dt.date(2026, 7, 31), stats=_st)
assert len(_o.vat) == 1 and _o.vat[0]["doc_type"] == "Sale - standard rated" and _st["outside"] == 1 and _st["unrecognised"] == {"Mystery": 1}, (_o.vat, _st)
print("custom voucher types OK")
# Tally output with undeclared UDF namespace prefixes must still parse
_u = tally._clean('<ENVELOPE><BODY><VOUCHER VCHTYPE="Sales" UDF:Flag="1"><DATE>20260515</DATE><UDF:EXTRA.LIST><UDF:V>a</UDF:V></UDF:EXTRA.LIST><NARRATION>a : b</NARRATION></VOUCHER></BODY></ENVELOPE>')
_ur = _ET.fromstring(_u); assert _ur.find('.//DATE').text == '20260515' and _ur.find('.//NARRATION').text == 'a : b' and _ur.find('.//EXTRA.LIST') is not None
print("UDF prefixes OK")


s2, base = serve(ZohoH)
c = zoho.Client('com', 'id', 'sec', 'refresh', '', accounts=base, api=base, pause=0)
assert zoho.exchange_grant_code('com', 'id', 'sec', ' code1 ', accounts_override=base) == 'refresh1'
orgs = c.organizations(); assert orgs[0]['organization_id'] == '999'; c.org = '999'
z = zoho.fetch_vat(c, dt.date(2026, 7, 1), dt.date(2026, 9, 30), anchor, 3)
for r in z.vat: print(r['doc_no'], r['doc_type'], r['net'], r['vat'], r['emirate'], '|', r['flag'][:25])
types = [(r['doc_no'], r['doc_type'], r['net'], r['vat']) for r in z.vat]
assert ('INV-1', 'Sale - standard rated', 4000.0, 200.0) in types and ('INV-1', 'Sale - zero rated', 1000.0, 0.0) in types and ('INV-2', 'Sale - exempt', 367.25, 0.0) in types and ('B-1', 'Purchase - standard rated', 2000.0, 100.0) in types, types
assert any("tax total" in n for n in z.notes) is False
print('zoho calls', c.calls)

# ---------------------------------------------------------------- ERPNext / Frappe
s3, fbase = serve(FrappeH)
bad = frappe.Client(fbase, "KEY", "WRONG")
try:
    bad.test(); raise SystemExit("bad key accepted")
except frappe.FrappeError as e:
    assert "refused" in str(e)
fc = frappe.Client(fbase + "/app/home", "KEY", "SEC", pause=0)
assert fc.site == fbase and fc.test() == "api@x.com" and fc.companies() == ["Al Noor Trading LLC"]
fc.company = "Al Noor Trading LLC"
fv = frappe.fetch_vat(fc, dt.date(2026, 7, 1), dt.date(2026, 9, 30), anchor, 3)
for r in fv.vat: print(r['doc_no'], r['doc_type'], r['net'], r['vat'], r['trn'], '|', r['flag'][:25])
ft = [(r['doc_no'], r['doc_type'], r['net'], r['vat']) for r in fv.vat]
assert ('SINV-1', 'Sale - standard rated', 4000.0, 200.0) in ft and ('SINV-1', 'Sale - zero rated', 1000.0, 0.0) in ft and ('SINV-2', 'Sale - exempt', 367.25, 0.0) in ft, ft
assert ('SINV-3', 'Sale - credit note', 1000.0, 50.0) in ft and ('B-1', 'Purchase - standard rated', 2000.0, 100.0) in ft, ft
assert fv.vat[0]['trn'] == '100123456700003' and fv.vat[0]['period_end'] == '2026-09-30' and not any("differs" in n for n in fv.notes), fv.notes
print('frappe calls', fc.calls)

print('ALL OK')
