# VAT-DESK: web version

Same calculations, rules and data model as the desktop app, used from a browser (PC, tablet, phone). Everything is stored in one database folder (`webdata`, or the folder in the `UAETAX_DATA` setting): back it up or use Users and admin > Download a backup.

## What is in the web version
Sign in with roles (Admin, Preparer, Reviewer, Viewer) and per-user client assignment; dashboard; clients (add, edit, import); VAT 201 in the FTA layout; upload of VAT data with validation; review and sign-off with period lock; filing pack ZIP, Excel and PDF packs, English and Arabic client summary; VAT groups with eliminations, the group VAT 201 (FTA) and Excel export; deadlines with penalty estimates and a calendar (.ics); users, backup and audit.

## What is only in the desktop app (for now)
Accounting connectors (Tally, Zoho, Frappe, MCP), tax loss register, related party tracker, variance review, document tracking, partial exemption, penalty calculators, rate editing. Use the desktop app for these; both can share the same database file if you point the desktop app at it (do not run both writing at the same moment on different machines).

## 1. Office network (Windows PC as the server)
1. Install Python 3.10 or newer (tick "Add python.exe to PATH").
2. Double-click `run_web.bat`. The first run installs what it needs.
3. On the server PC open http://localhost:8080 and create the administrator.
4. Other PCs and phones on the same network open `http://<server PC IP>:8080` (run `ipconfig` to find the IPv4 address). Allow Python through the Windows firewall (Private network) when asked.
5. Give the server PC a fixed IP (or a name in the router) so the address does not change. Leave the window open; close it to stop.

## 2. Online (anywhere)
Run the same program on a server you control, and put HTTPS in front of it. Do not expose port 8080 to the internet without HTTPS: sign-in passwords would travel in clear text.
- **Docker on any VPS:** `docker build -t uaetax .` then `docker run -d -p 8080:8080 -v uaetax-data:/data uaetax`. Put a reverse proxy with a certificate (Caddy or nginx) in front, for example Caddy: `tax.yourfirm.com { reverse_proxy localhost:8080 }`.
- **Without a public server:** use a private network tool (Tailscale or a VPN) so your staff reach the office PC securely from outside, with no internet exposure at all. This is the safest option for client data.
- Set `UAETAX_HTTPS=1` when serving over HTTPS so the sign-in cookie is marked secure (the Dockerfile already does).

## Security notes
Passwords are hashed (PBKDF2); accounts lock after repeated failures; forms carry anti-forgery tokens; sessions expire after 12 hours; every change and export is in the audit log. You are responsible for the server, HTTPS, backups and who can reach it. Client data in the UAE may be subject to data protection and client confidentiality rules: keep the server where you are comfortable holding it.

## Limits
One server process with a SQLite database suits a small or mid-sized firm (tens of users). It is not a multi-server cloud service. Mobile use is through the browser (pages are responsive); there is no separate Android or iPhone app.
