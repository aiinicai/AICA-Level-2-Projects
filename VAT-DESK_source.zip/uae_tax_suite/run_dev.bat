@echo off
setlocal
set "WORK=C:\uae_build_dev"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY ( echo Python not found. Install it from python.org and tick "Add python.exe to PATH". & pause & exit /b 1 )
robocopy "%~dp0." "%WORK%" /E /XD .venv dist build __pycache__ /NFL /NDL /NJH /NJS /NP >nul
cd /d "%WORK%"
if not exist .venv\Scripts\python.exe ( %PY% -m venv .venv )
".venv\Scripts\python.exe" -m pip install -r requirements.txt
".venv\Scripts\python.exe" main.py
if errorlevel 1 pause
