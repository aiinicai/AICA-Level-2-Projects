from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QCheckBox, QDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout)

from core.db import AuthError
from ui.common import info, warn


class LoginDialog(QDialog):
    def __init__(self, db, db_path, change_db_cb=None):
        super().__init__()
        self.db = db
        self.setWindowTitle("VAT-DESK")
        self.setMinimumWidth(420)
        self.change_db_cb = change_db_cb
        lay = QVBoxLayout(self); lay.setContentsMargins(28, 24, 28, 20); lay.setSpacing(10)
        t = QLabel("VAT-DESK"); t.setObjectName("h1")
        lay.addWidget(t)
        first = not db.has_users()
        s = QLabel("First start: create the administrator account." if first else "Sign in to continue.")
        s.setObjectName("muted"); lay.addWidget(s)
        form = QFormLayout()
        self.user = QLineEdit(); self.user.setPlaceholderText("Username")
        self.pw = QLineEdit(); self.pw.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Username", self.user); form.addRow("Password", self.pw)
        self.first = first
        if first:
            self.pw2 = QLineEdit(); self.pw2.setEchoMode(QLineEdit.EchoMode.Password)
            self.name = QLineEdit(); self.name.setPlaceholderText("Your name")
            self.firm = QLineEdit(); self.firm.setPlaceholderText("Firm name (appears on reports)")
            self.sample = QCheckBox("Load sample clients so I can look around")
            form.addRow("Confirm", self.pw2); form.addRow("Full name", self.name); form.addRow("Firm", self.firm)
            form.addRow("", self.sample)
            hint = QLabel("Use at least 8 characters. Keep this password safe: administrators can reset other users' passwords.")
            hint.setObjectName("muted"); hint.setWordWrap(True)
        lay.addLayout(form)
        if first:
            lay.addWidget(hint)
        self.msg = QLabel(""); self.msg.setStyleSheet("color:#A61B1B"); lay.addWidget(self.msg)
        row = QHBoxLayout()
        loc = QLabel("Database: " + db_path); loc.setObjectName("muted"); loc.setWordWrap(True)
        lay.addWidget(loc)
        if change_db_cb:
            b = QPushButton("Change database location"); b.clicked.connect(self._change); row.addWidget(b)
        row.addStretch(1)
        ok = QPushButton("Create account" if first else "Sign in"); ok.setObjectName("primary"); ok.setDefault(True)
        ok.clicked.connect(self.go); row.addWidget(ok)
        lay.addLayout(row)
        self.pw.returnPressed.connect(self.go)
        self.result_user = None
        self.switch_db = False

    def _change(self):
        self.switch_db = True
        self.reject()

    def go(self):
        u, p = self.user.text().strip(), self.pw.text()
        try:
            if self.first:
                if p != self.pw2.text():
                    raise ValueError("The two passwords do not match")
                self.db.create_user(u, p, "Admin", self.name.text().strip() or u, actor=u)
                self.db.set_setting("firm", self.firm.text().strip())
                self.result_user = self.db.login(u, p)
                if self.sample.isChecked():
                    self.db.load_sample()
            else:
                self.result_user = self.db.login(u, p)
            self.accept()
        except (AuthError, ValueError) as e:
            self.msg.setText(str(e))


class PasswordDialog(QDialog):
    def __init__(self, db, username, forced=False, parent=None):
        super().__init__(parent)
        self.db, self.username = db, username
        self.setWindowTitle("Change password")
        lay = QVBoxLayout(self)
        if forced:
            lay.addWidget(QLabel("You must choose a new password before continuing."))
        form = QFormLayout()
        self.old = QLineEdit(); self.new = QLineEdit(); self.new2 = QLineEdit()
        for w in (self.old, self.new, self.new2):
            w.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Current password", self.old); form.addRow("New password", self.new); form.addRow("Repeat new password", self.new2)
        lay.addLayout(form)
        b = QPushButton("Save"); b.setObjectName("primary"); b.clicked.connect(self.save)
        lay.addWidget(b)

    def save(self):
        if not self.db.verify_password(self.username, self.old.text()):
            return warn(self, "Password", "Current password is not correct.")
        if self.new.text() != self.new2.text():
            return warn(self, "Password", "The new passwords do not match.")
        try:
            self.db.change_password(self.username, self.new.text(), actor=self.username)
        except ValueError as e:
            return warn(self, "Password", str(e))
        info(self, "Password", "Password changed.")
        self.accept()
