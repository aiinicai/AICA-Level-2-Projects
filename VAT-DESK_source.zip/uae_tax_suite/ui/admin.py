import os
import shutil

from PyQt6.QtCore import Qt
from ui.dates import DateField
from PyQt6.QtWidgets import (QAbstractItemView, QListWidget, QListWidgetItem, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QCheckBox, QTabWidget, QTableWidgetItem,
                             QVBoxLayout, QWidget)

from core import db as dbm
import datetime as _dt
from ui.busy import busy
from ui.common import ask, fill_table, header, info, make_table, page_layout, warn


class RuleChangeDialog(QDialog):
    """A rule change must say why (and optionally from when it applies)."""

    def __init__(self, label, old, new, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Reason for the change")
        self.resize(520, 200)
        lay = QFormLayout(self)
        lay.addRow(QLabel("<b>%s</b>: %s &rarr; %s" % (label, old, new)))
        self.reason = QLineEdit(); self.reason.setPlaceholderText("For example: Cabinet Decision / FTA guide reference, or 'client agreed'")
        self.eff = DateField(placeholder="DD-MM-YYYY (optional)")
        lay.addRow("Reason", self.reason); lay.addRow("Applies from", self.eff)
        b = QPushButton("Save change"); b.setObjectName("primary"); b.clicked.connect(self.go); lay.addRow(b)

    def go(self):
        if len(self.reason.text().strip()) < 3:
            return warn(self, "Reason", "Please give a reason.")
        self.accept()


class RulesLogDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Rules change log")
        self.resize(980, 480)
        lay = QVBoxLayout(self)
        t = make_table(["When", "User", "Rule", "Old", "New", "Applies from", "Reason"])
        fill_table(t, [[str(x["ts"])[:16], x["username"], x["label"], x["old"], x["new"], x["effective_from"], x["reason"]] for x in db.rules_log()], widths=(120, 90, 260, 90, 90, 100, 300))
        lay.addWidget(t)
        b = QPushButton("Close"); b.clicked.connect(self.accept); lay.addWidget(b)


class RulesPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Rules and rates", "Every rate, threshold and deadline the calculations use. Check them against current FTA guidance. Only administrators can change them; each change is logged."))
        bar = QHBoxLayout()
        self.firm = QLineEdit(ctx.firm); self.firm.setPlaceholderText("Firm name shown on reports"); self.firm.setMaximumWidth(320)
        self.sf = QPushButton("Save firm name"); self.sf.clicked.connect(self.save_firm)
        bar.addWidget(QLabel("Firm")); bar.addWidget(self.firm); bar.addWidget(self.sf); bar.addStretch(1)
        self.lg = QPushButton("Change log"); self.lg.clicked.connect(lambda: RulesLogDialog(self.ctx.db, self).exec())
        self.rv = QPushButton("Mark rules reviewed"); self.rv.clicked.connect(self.reviewed)
        bar.addWidget(self.lg); bar.addWidget(self.rv)
        self.rs = QPushButton("Reset all to defaults"); self.rs.setObjectName("danger"); self.rs.clicked.connect(self.reset)
        bar.addWidget(self.rs)
        lay.addLayout(bar)
        self.stale = QLabel(""); self.stale.setWordWrap(True)
        lay.addWidget(self.stale)
        self.table = make_table(["Group", "Rule", "Value", "Unit", "Note"], editable=True)
        lay.addWidget(self.table)
        self.table.itemChanged.connect(self.edited)
        ctx.changed.connect(self.reload)
        self.reload()

    def reload(self):
        self._rules = self.ctx.db.rules()
        self.table.blockSignals(True)
        self.table.setRowCount(len(self._rules))
        admin = self.ctx.is_admin()
        for i, r in enumerate(self._rules):
            v = r["value"]
            txt = ("%g%%" % (v * 100)) if r["unit"] == "pct" else ("" if v in (None, "") else str(v))
            if r["unit"] == "aed" and isinstance(v, (int, float)):
                txt = "{:,.2f}".format(v)
            for j, s in enumerate((r["group"], r["label"], txt, {"pct": "%", "aed": "AED", "days": "days", "months": "months", "date": "date"}.get(r["unit"], r["unit"]), r["note"])):
                it = QTableWidgetItem(s)
                if not (j == 2 and admin):
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.table.setItem(i, j, it)
        for j, w in enumerate((90, 300, 130, 70, 600)):
            self.table.setColumnWidth(j, w)
        self.table.blockSignals(False)
        self.rs.setEnabled(admin); self.sf.setEnabled(admin); self.firm.setEnabled(admin); self.rv.setEnabled(admin)
        age = self.ctx.db.rules_review_age()
        if age is None:
            self.stale.setText("<b>These rates have not been confirmed against FTA guidance yet.</b> Check them, then press Mark rules reviewed.")
        elif age > 90:
            self.stale.setText("<b>The rules were last confirmed %d days ago (%s).</b> Check them against current FTA guidance and press Mark rules reviewed." % (age, self.ctx.db.setting("rules_reviewed_on", "")))
        else:
            self.stale.setText("Rules last confirmed on %s by %s." % (self.ctx.db.setting("rules_reviewed_on", ""), self.ctx.db.setting("rules_reviewed_by", "")))
        self.stale.setStyleSheet("color:#A61B1B" if (age is None or age > 90) else "color:#5F6B7D")

    def edited(self, it):
        if it.column() != 2:
            return
        r = self._rules[it.row()]
        s = it.text().strip().replace(",", "")
        try:
            if r["unit"] == "date":
                from core.dataio import parse_date
                v = parse_date(s) if s else ""
                if v.startswith("?"):
                    raise ValueError("Use DD-MM-YYYY")
            elif r["unit"] == "pct":
                v = float(s.rstrip("%")) / 100 if s.endswith("%") or float(s) > 1 else float(s)
            else:
                v = float(s)
                v = int(v) if v == int(v) else v
            if v != r["value"]:
                dlg = RuleChangeDialog(r["label"], r["value"], v, self)
                if not dlg.exec():
                    return self.ctx.refresh()
                self.ctx.db.set_rule(r["key"], v, dlg.reason.text(), dlg.eff.text().strip())
        except Exception as e:
            warn(self, "Rule", "Not saved: %s" % e)
        self.ctx.refresh()

    def reset(self):
        if ask(self, "Reset", "Reset every rule to the shipped default values?"):
            self.ctx.db.reset_rules(); self.ctx.refresh()

    def reviewed(self):
        if ask(self, "Rules reviewed", "Confirm that you have checked these rates, thresholds and deadlines against current FTA guidance?"):
            self.ctx.db.mark_rules_reviewed(); self.ctx.refresh()

    def save_firm(self):
        self.ctx.db.set_setting("firm", self.firm.text().strip()); self.ctx.db.audit("settings", "firm", self.firm.text())
        info(self, "Firm", "Saved.")


class UserDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("New user")
        lay = QVBoxLayout(self); form = QFormLayout()
        self.u = QLineEdit(); self.n = QLineEdit(); self.p = QLineEdit(); self.p.setEchoMode(QLineEdit.EchoMode.Password)
        self.r = QComboBox(); self.r.addItems(dbm.ROLES); self.r.setCurrentText("Preparer")
        form.addRow("Username", self.u); form.addRow("Full name", self.n); form.addRow("Temporary password", self.p); form.addRow("Role", self.r)
        lay.addLayout(form)
        lay.addWidget(QLabel("The user must change this password at first sign-in."))
        b = QPushButton("Create"); b.setObjectName("primary"); b.clicked.connect(self.go); lay.addWidget(b)

    def go(self):
        try:
            self.db.create_user(self.u.text(), self.p.text(), self.r.currentText(), self.n.text(), must_change=True)
        except ValueError as e:
            return warn(self, "User", str(e))
        self.accept()


class UsersPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Users", "Admin: manage who can sign in. Preparers and reviewers edit data; viewers are read only."))
        bar = QHBoxLayout()
        for txt, fn in (("New user", self.new), ("Change role", self.role), ("Activate / deactivate", self.toggle), ("Reset password", self.reset), ("Assign clients", self.assign)):
            b = QPushButton(txt); b.clicked.connect(fn); bar.addWidget(b)
        bar.addStretch(1); lay.addLayout(bar)
        self.table = make_table(["Username", "Name", "Role", "Active", "Created", "Clients"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.cellDoubleClicked.connect(lambda *_: self.assign())
        lay.addWidget(self.table)
        self.reload()

    def reload(self):
        keep = self.table.currentRow()
        self.users = self.ctx.db.list_users()
        fill_table(self.table, [[u["username"], u["display_name"], u["role"], "Yes" if u["active"] else "No", u["created"],
                                      "All" if (u["role"] == "Admin" or not self.ctx.db.client_assignments(u["username"])) else "%d assigned" % len(self.ctx.db.client_assignments(u["username"]))] for u in self.users], widths=(160, 220, 100, 70, 160, 110))
        if 0 <= keep < len(self.users):
            self.table.selectRow(keep)

    def cur(self):
        r = self.table.currentRow()
        if r < 0 or r >= len(self.users):
            warn(self, "Users", "Click a user in the table first, then press the button.")
            return None
        return self.users[r]

    def new(self):
        if UserDialog(self.ctx.db, self).exec():
            self.reload()

    def role(self):
        u = self.cur()
        if not u:
            return
        from PyQt6.QtWidgets import QInputDialog
        r, ok = QInputDialog.getItem(self, "Role", "Role for %s" % u["username"], dbm.ROLES, dbm.ROLES.index(u["role"]), False)
        if ok:
            try:
                self.ctx.db.update_user(u["username"], role=r)
            except Exception as e:
                warn(self, "User", str(e))
            self.reload()

    def toggle(self):
        u = self.cur()
        if u:
            try:
                self.ctx.db.update_user(u["username"], active=0 if u["active"] else 1)
            except Exception as e:
                warn(self, "User", str(e))
            self.reload()

    def assign(self):
        u = self.cur()
        if not u:
            return
        if u["role"] == "Admin":
            return info(self, "Assign clients", "Administrators always see every client.")
        db = self.ctx.db
        dlg = QDialog(self); dlg.setWindowTitle("Clients for " + u["username"]); dlg.resize(460, 480)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("Tick the clients this user may see and work on. Leave all unticked to let the user see every client."))
        lw = QListWidget(); lay.addWidget(lw)
        have = set(db.client_assignments(u["username"]))
        for e in db.c.execute("SELECT id, data FROM entities ORDER BY id"):
            import json as _j
            it = QListWidgetItem("%s  %s" % (e["id"], _j.loads(e["data"]).get("name", ""))); it.setData(Qt.ItemDataRole.UserRole, e["id"])
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable); it.setCheckState(Qt.CheckState.Checked if e["id"] in have else Qt.CheckState.Unchecked); lw.addItem(it)
        b = QPushButton("Save"); b.setObjectName("primary"); b.clicked.connect(dlg.accept); lay.addWidget(b)
        if dlg.exec():
            ids = [lw.item(i).data(Qt.ItemDataRole.UserRole) for i in range(lw.count()) if lw.item(i).checkState() == Qt.CheckState.Checked]
            try:
                db.assign_clients(u["username"], ids)
            except Exception as ex:
                return warn(self, "Assign clients", str(ex))
            self.reload()
            info(self, "Assign clients", "%s now sees %s." % (u["username"], ("%d client(s)" % len(ids)) if ids else "every client"))

    def reset(self):
        u = self.cur()
        if not u:
            return
        from PyQt6.QtWidgets import QInputDialog
        p, ok = QInputDialog.getText(self, "Reset password", "New temporary password for %s" % u["username"], QLineEdit.EchoMode.Password)
        if ok:
            try:
                self.ctx.db.change_password(u["username"], p, actor=self.ctx.db.user["username"])
                self.ctx.db.c.execute("UPDATE users SET must_change=1 WHERE username=?", (u["username"],)); self.ctx.db.c.commit()
                info(self, "Password", "Password reset. The user must change it at next sign-in.")
            except ValueError as e:
                warn(self, "Password", str(e))


class AuditPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Audit trail and backup", "Who changed what and when. Back up the database file regularly."))
        bar = QHBoxLayout()
        self.q = QLineEdit(); self.q.setPlaceholderText("Filter"); self.q.setMaximumWidth(260); self.q.textChanged.connect(self.reload)
        bar.addWidget(self.q); bar.addStretch(1)
        b = QPushButton("Back up now"); b.clicked.connect(self.backup); bar.addWidget(b)
        self.b_res = QPushButton("Restore from backup"); self.b_res.setObjectName("danger"); self.b_res.clicked.connect(self.restore); bar.addWidget(self.b_res)
        self.b_dir = QPushButton("Backup folder"); self.b_dir.clicked.connect(self.pick_dir); bar.addWidget(self.b_dir)
        r = QPushButton("Refresh"); r.clicked.connect(self.reload); bar.addWidget(r)
        lay.addLayout(bar)
        self.info = QLabel(""); self.info.setObjectName("muted"); self.info.setWordWrap(True)
        lay.addWidget(self.info)
        self.self_ok = QCheckBox("Allow the preparer to approve their own work (for a sole practitioner; otherwise a second person must approve)")
        self.self_ok.setChecked(ctx.db.self_approval_allowed()); self.self_ok.setEnabled(ctx.is_admin())
        self.self_ok.toggled.connect(self.toggle_self)
        lay.addWidget(self.self_ok)
        self.table = make_table(["Time", "User", "Action", "Target", "Detail"])
        lay.addWidget(self.table)
        self.reload(); self.refresh_info()

    def reload(self):
        q = self.q.text().lower()
        rows = [[a["ts"], a["username"], a["action"], a["target"], a["detail"]] for a in self.ctx.db.audit_log(2000) if not q or q in " ".join(str(x) for x in a.values()).lower()]
        fill_table(self.table, rows, widths=(150, 110, 130, 190, 500))

    def refresh_info(self):
        bk = self.ctx.db.list_backups()
        self.info.setText("Backups are saved in %s (a copy is made automatically once a day after sign-in; the newest %s are kept). %d file(s) there%s." % (
            self.ctx.db.backup_dir(), self.ctx.db.setting("backup_keep", "14"), len(bk), "; latest " + bk[0]["modified"] if bk else ""))

    def toggle_self(self, on):
        try:
            self.ctx.db.need("Admin")
            self.ctx.db.set_setting("allow_self_approval", "Yes" if on else "No")
            self.ctx.db.audit("settings", "allow_self_approval", "Yes" if on else "No")
        except Exception as e:
            warn(self, "Setting", str(e))

    def backup(self):
        import datetime as dt
        p, _ = QFileDialog.getSaveFileName(self, "Back up", os.path.join(self.ctx.db.backup_dir(), "uae_tax_backup_%s.db" % dt.datetime.now().strftime("%Y%m%d_%H%M")), "Database (*.db)")
        if p:
            with busy(self, "Backing up the database..."):
                self.ctx.db.backup_to(p)
            self.ctx.db.audit("backup", "database", p)
            info(self, "Backup", "Saved to " + p)
            self.refresh_info()

    def restore(self):
        p, _ = QFileDialog.getOpenFileName(self, "Restore from backup", self.ctx.db.backup_dir(), "Database (*.db)")
        if not p:
            return
        if not ask(self, "Restore", "Replace ALL current data with the contents of this backup?\n\n%s\n\nA copy of the current data is saved first. Everyone else using the database should sign out." % p):
            return
        try:
            with busy(self, "Restoring the database from the backup..."):
                safety = self.ctx.db.restore_from(p)
        except Exception as e:
            return warn(self, "Restore", str(e))
        self.ctx.refresh()
        self.reload(); self.refresh_info()
        info(self, "Restore", "Restored. The data before the restore was saved as\n" + safety)

    def pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Backup folder", self.ctx.db.backup_dir())
        if d:
            try:
                self.ctx.db.need("Admin")
                self.ctx.db.set_setting("backup_dir", d); self.ctx.db.audit("settings", "backup_dir", d)
            except Exception as e:
                return warn(self, "Backup folder", str(e))
            self.refresh_info()
