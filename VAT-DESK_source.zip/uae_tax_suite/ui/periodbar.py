"""From / To period filter shown inside the VAT 201 return tab.

From and To are calendar fields. They narrow the list of periods; the user picks one period and the return
shows it. Excel export gives the picked period, or every period in the range (one sheet each).
"""
from __future__ import annotations

from PyQt6.QtWidgets import QComboBox, QFrame, QHBoxLayout, QLabel, QPushButton, QWidget

from ui.dates import DateField


class PeriodBar(QFrame):
    def __init__(self, kind, page):
        super().__init__()
        self.kind, self.page = kind, page                       # kind: "VAT"
        self.setObjectName("card")
        self.combo = page.vp                                    # the page's own period combo is the selected period
        self.all = []                                           # every period this client has (newest first)
        l = QHBoxLayout(self); l.setContentsMargins(10, 6, 10, 6); l.setSpacing(8)
        l.addWidget(QLabel("<b>VAT period</b>  From"))
        self.f_from = DateField(); l.addWidget(self.f_from)
        l.addWidget(QLabel("To"))
        self.f_to = DateField(); l.addWidget(self.f_to)
        self.combo.setParent(self); self.combo.hide()          # holds the chosen period; the From / To range is what the user sees
        self.count = QLabel("", self); self.count.hide()
        l.addStretch(1)
        self.b_x1 = QPushButton("Export to Excel (this period)")
        self.b_xn = QPushButton("Export to Excel (all periods in range)")
        l.addWidget(self.b_x1); l.addWidget(self.b_xn)
        self.f_from.editingFinished.connect(self.apply); self.f_to.editingFinished.connect(self.apply)
        self.b_x1.clicked.connect(lambda: page.export_periods(kind, False))
        self.b_xn.clicked.connect(lambda: page.export_periods(kind, True))

    def set_periods(self, periods, current, selected=None):
        """periods: all periods for the client. Keeps the From/To range if it still makes sense, else shows everything."""
        self.all = sorted(periods, reverse=True)
        a, b = self.f_from.text(), self.f_to.text()
        if self.all and ((a and a > self.all[0]) or (b and b < self.all[-1])):
            self.f_from.setText(""); self.f_to.setText("")
        self._current = current
        self.fill(selected)

    def in_range(self):
        a, b = self.f_from.text(), self.f_to.text()
        if a and b and a > b:
            a, b = b, a
        return [p for p in self.all if (not a or p >= a) and (not b or p <= b)]

    def fill(self, selected=None):
        sel = selected or self.combo.currentData()
        vals = self.in_range()
        self.combo.blockSignals(True); self.combo.clear()
        for v in vals:
            self.combo.addItem(v + ("  (current)" if v == getattr(self, "_current", "") else ""), v)
        i = self.combo.findData(sel) if sel else -1
        if i < 0:
            i = self.combo.findData(getattr(self, "_current", ""))
        self.combo.setCurrentIndex(max(i, 0) if self.combo.count() else -1)
        self.combo.blockSignals(False)
        self.count.setText("%d of %d periods in range" % (len(vals), len(self.all)) if self.all else "no periods yet")
        self.b_x1.setEnabled(bool(vals)); self.b_xn.setEnabled(bool(vals))

    def pick_for_range(self):
        """The period shown follows the range: the latest period up to To; with only From, the first period from it; with no range, the current one."""
        vals = self.in_range()
        if not vals:
            return None
        a, b = self.f_from.text(), self.f_to.text()
        if b:
            return vals[0]
        if a:
            return vals[-1]
        return getattr(self, "_current", "") if getattr(self, "_current", "") in vals else vals[0]

    def select(self, p):
        """Show exactly this period (used when another screen picks it)."""
        if p and p in self.all and self.combo.currentData() != p:
            self.f_from.setText(p); self.f_to.setText(p)
            self.fill(p)
            return True
        return False

    def apply(self, *_):
        before = self.combo.currentData()
        self.fill(self.pick_for_range())
        if self.combo.currentData() != before:
            self.page.build()                                   # the picked period changed because the range moved

    def clear(self):
        self.f_from.setText(""); self.f_to.setText("")
        self.apply()
