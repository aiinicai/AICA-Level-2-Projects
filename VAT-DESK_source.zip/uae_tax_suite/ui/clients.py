from PyQt6.QtCore import Qt
from ui.dates import DateField
from PyQt6.QtWidgets import (QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QCheckBox,
                             QTabWidget, QVBoxLayout, QWidget)

from core import dataio, db as dbm
from core.engine import n
from ui.busy import busy
from ui.common import ask, fill_table, header, info, make_table, page_layout, warn


class EntityDialog(QDialog):
    """Client editor generated from fields.json, so every field of the workbook's Entities sheet is available."""

    def __init__(self, ctx, entity=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.entity = dict(entity or {})
        self.is_new = entity is None
        self.setWindowTitle("New client" if self.is_new else "Edit client: %s" % entity.get("name"))
        self.resize(760, 640)
        fields = [f for f in dbm.load_json("fields.json") if not f.get("hidden")]
        self.fields = fields
        self.widgets = {}
        lay = QVBoxLayout(self)
        note = QLabel("Fields marked (upload) are derived from the VAT data tab when rows exist for the client. The value typed here is used only when there are no uploaded rows.")
        note.setObjectName("muted"); note.setWordWrap(True); lay.addWidget(note)
        tabs = QTabWidget(); lay.addWidget(tabs)
        for sec in ("Entity", "VAT", "Return details"):
            sc = QScrollArea(); sc.setWidgetResizable(True)
            w = QWidget(); form = QFormLayout(w); form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            for f in [x for x in fields if x["section"] == sec]:
                ed = self._make(f)
                lab = f["label"] + (" (upload)" if f["from_upload"] else "") + (" (selector)" if f["selector"] else "")
                l = QLabel(lab); l.setWordWrap(True); l.setMinimumWidth(250); l.setMaximumWidth(300)
                if f.get("help"):
                    ed.setToolTip(f["help"]); l.setToolTip(f["help"])
                form.addRow(l, ed)
                self.widgets[f["key"]] = (f, ed)
            sc.setWidget(w); tabs.addTab(sc, sec)
        if self.is_new:
            self.widgets["id"][1].setText(ctx.db.next_entity_id())
        else:
            self.widgets["id"][1].setReadOnly(True)
        row = QHBoxLayout(); row.addStretch(1)
        c = QPushButton("Cancel"); c.clicked.connect(self.reject)
        s = QPushButton("Save"); s.setObjectName("primary"); s.clicked.connect(self.save)
        row.addWidget(c); row.addWidget(s); lay.addLayout(row)

    def _make(self, f):
        v = self.entity.get(f["key"])
        if f["kind"] == "choice":
            cb = QComboBox(); cb.addItem("")
            cb.addItems([str(x) for x in f["choices"]])
            if v not in (None, ""):
                i = cb.findText(str(v)); cb.setCurrentIndex(max(i, 0))
            return cb
        e = DateField() if f["kind"] == "date" else QLineEdit()
        if v not in (None, ""):
            if f["kind"] == "percent":
                e.setText(("%.4f" % (float(v) * 100)).rstrip("0").rstrip(".") + "%")
            elif f["kind"] == "number":
                e.setText("{:,.2f}".format(float(v)))
            else:
                e.setText(str(v))
        return e

    def save(self):
        out, errs = {}, []
        for k, (f, w) in self.widgets.items():
            txt = w.currentText() if isinstance(w, QComboBox) else w.text().strip()
            if txt == "":
                continue
            if f["kind"] == "date":
                d = dataio.parse_date(txt)
                if d.startswith("?"):
                    errs.append("%s: use DD-MM-YYYY" % f["label"]); continue
                out[k] = d
            elif f["kind"] in ("number", "percent"):
                x = dataio.parse_num(txt)
                if isinstance(x, str):
                    errs.append("%s: not a number" % f["label"]); continue
                out[k] = x
            else:
                out[k] = txt
        if errs:
            return warn(self, "Check the entries", "\n".join(errs[:12]))
        out["id"] = out.get("id", "").upper()
        if self.is_new and self.ctx.db.entity(out["id"]):
            return warn(self, "Client", "That ID already exists.")
        try:
            self.ctx.db.save_entity(out)
        except Exception as e:
            return warn(self, "Client", str(e))
        self.accept()


class ClientsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Clients", "Each client is a taxable person. Double-click a row to open the full record."))
        bar = QHBoxLayout()
        self.search = QLineEdit(); self.search.setPlaceholderText("Search by Client ID or Client Name"); self.search.setClearButtonEnabled(True); self.search.setMinimumWidth(300)
        self.search.textChanged.connect(self.reload)
        bar.addWidget(self.search); bar.addStretch(1)
        self.b_new = QPushButton("New client"); self.b_new.setObjectName("primary"); self.b_new.clicked.connect(self.new)
        self.b_edit = QPushButton("Edit"); self.b_edit.clicked.connect(self.edit)
        self.b_del = QPushButton("Delete"); self.b_del.setObjectName("danger"); self.b_del.clicked.connect(self.delete)
        self.b_roll = QPushButton("Start next period"); self.b_roll.clicked.connect(self.roll)
        self.b_imp = QPushButton("Import clients"); self.b_imp.clicked.connect(self.import_clients)
        self.b_exp = QPushButton("Export register (Excel)"); self.b_exp.clicked.connect(self.export)
        for b in (self.b_new, self.b_edit, self.b_roll, self.b_del, self.b_imp, self.b_exp):
            bar.addWidget(b)
        lay.addLayout(bar)
        self.table = make_table(["ID", "Client", "Location", "VAT reg.", "VAT period end", "VAT", "Risk"])
        self.table.doubleClicked.connect(self.edit)
        lay.addWidget(self.table)
        ctx.changed.connect(self.reload)
        self.reload()

    def reload(self):
        r = self.ctx.result()
        q = self.search.text().strip().lower()
        rows = []
        for i, e in enumerate(r["entities"]):
            if q and q not in str(e["id"]).lower() and q not in str(e["name"]).lower():
                continue
            rows.append([e["id"], e["name"], e.get("location"), e.get("vat_registered"), r["vat"][i]["period_end"],
                         r["vat"][i]["vat_status"], r["risk"][i]["rag"]])
        fill_table(self.table, rows, status_cols=(5, 6), widths=(50, 260, 120, 80, 120, 160, 70))
        ed = self.ctx.can_edit()
        for b in (self.b_new, self.b_edit, self.b_imp, self.b_roll):
            b.setEnabled(ed)
        self.b_del.setEnabled(self.ctx.is_admin())

    def current_id(self):
        r = self.table.currentRow()
        return self.table.item(r, 0).text() if r >= 0 else None

    def new(self):
        if EntityDialog(self.ctx, None, self).exec():
            self.ctx.refresh()

    def edit(self):
        eid = self.current_id()
        if not eid or not self.ctx.can_edit():
            return
        if EntityDialog(self.ctx, self.ctx.db.entity(eid), self).exec():
            self.ctx.refresh()

    def roll(self):
        eid = self.current_id()
        if not eid or not self.ctx.can_edit():
            return warn(self, "Start next period", "Select a client first.")
        res = self.ctx.result()
        i = next(k for k, e in enumerate(res["entities"]) if e["id"] == eid)
        vpe = self.ctx.db.current_periods(eid)[0]
        dlg = QDialog(self); dlg.setWindowTitle("Start next period: " + eid)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("Moves the client on to the next period. Uploaded data is kept; a backup is taken first."))
        vt = QCheckBox("VAT: period ending %s -> next period" % (vpe or "-")); vt.setEnabled(bool(vpe))
        lay.addWidget(vt)
        lay.addWidget(QLabel("Filing and payment flags are reset to No. One-off adjustments are cleared. Elections and registrations are kept."))
        ok = QPushButton("Start next period"); ok.setObjectName("primary"); ok.clicked.connect(dlg.accept); lay.addWidget(ok)
        if not dlg.exec():
            return
        db, force = self.ctx.db, False
        try:
            try:
                ch = db.roll_forward(eid, None, False, vt.isChecked())
            except ValueError as e:
                if "not approved" not in str(e):
                    raise
                if not ask(self, "Not approved", str(e).replace(" Approve it first (Returns and workings > Sign-off), or roll forward anyway.", "").replace(" Approve it first, or roll forward anyway.", "") + "\n\nRoll forward anyway? This is recorded in the audit trail."):
                    return
                ch = db.roll_forward(eid, None, False, vt.isChecked(), force=True)
        except Exception as e:
            return warn(self, "Start next period", str(e))
        self.ctx.refresh()
        info(self, "Start next period", "\n".join(ch))

    def delete(self):
        eid = self.current_id()
        if eid and ask(self, "Delete client", "Delete %s and all of its uploaded data? This cannot be undone." % eid):
            self.ctx.db.delete_entity(eid)
            self.ctx.refresh()

    def import_clients(self):
        p, _ = QFileDialog.getOpenFileName(self, "Import clients", "", "Excel or CSV (*.xlsx *.csv)")
        if not p:
            return
        done = 0
        with busy(self, "Importing clients into the application..."):
            ents, issues = dataio.read_entities(p)
            for e in ents:
                old = self.ctx.db.entity(e["id"]) or {}
                old.update(e)
                self.ctx.db.save_entity(old)
                done += 1
        self.ctx.refresh()
        info(self, "Import clients", "%d clients imported or updated.%s" % (done, ("\n\nProblems:\n" + "\n".join("Row %s: %s" % i for i in issues[:15])) if issues else ""))

    def export(self):
        p, _ = QFileDialog.getSaveFileName(self, "Export register", "client_register.xlsx", "Excel (*.xlsx)")
        if p:
            with busy(self, "Exporting the client register..."):
                dataio.export_portfolio_xlsx(p, self.ctx.result(), self.ctx.firm)
            self.ctx.db.audit("export", "register", p)
            info(self, "Export", "Saved to " + p)
