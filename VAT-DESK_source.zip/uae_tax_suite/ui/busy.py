"""A small progress window and a busy cursor for slow work (fetching from accounting software, importing, exporting).

The window can be minimised. While it is open the mouse pointer shows the busy cursor. Use it as:

    with busy(self, "Exporting the Excel pack..."):
        do_slow_thing()

or create a BusyWindow yourself for work in a background thread (see ConnectDialog.run).
"""
from __future__ import annotations

import time
from contextlib import contextmanager

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtWidgets import QApplication, QHBoxLayout, QLabel, QProgressBar, QPushButton, QVBoxLayout, QDialog


class BusyWindow(QDialog):
    def __init__(self, parent=None, text="Working...", on_cancel=None, title="VAT-DESK is working"):
        super().__init__(parent)
        self.setWindowTitle(title)
        # a normal top-level window with a minimise button and no close button
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowTitleHint | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.CustomizeWindowHint)
        self.setModal(False)
        self.setFixedWidth(380)
        self._t0 = time.time()
        self._cursor = False
        lay = QVBoxLayout(self)
        self.msg = QLabel(text); self.msg.setWordWrap(True); lay.addWidget(self.msg)
        self.bar = QProgressBar(); self.bar.setRange(0, 0); self.bar.setTextVisible(False); self.bar.setFixedHeight(10); lay.addWidget(self.bar)
        row = QHBoxLayout()
        self.clock = QLabel("0 s"); self.clock.setObjectName("muted"); row.addWidget(self.clock); row.addStretch(1)
        self.cancel = QPushButton("Cancel"); self.cancel.setVisible(on_cancel is not None)
        if on_cancel:
            self.cancel.clicked.connect(lambda: (self.cancel.setEnabled(False), self.set_text("Cancelling..."), on_cancel()))
        row.addWidget(self.cancel); lay.addLayout(row)
        hint = QLabel("You can minimise this window. It closes by itself when the work is done."); hint.setObjectName("muted"); hint.setWordWrap(True); lay.addWidget(hint)
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(500)

    def _tick(self):
        s = int(time.time() - self._t0)
        self.clock.setText("%d s" % s if s < 60 else "%d min %d s" % (s // 60, s % 60))

    def set_text(self, t):
        self.msg.setText(t)

    def begin(self):
        if not self._cursor:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor); self._cursor = True
        p = self.parent()
        if p is not None:
            try:
                g = p.window().frameGeometry(); self.move(g.right() - self.width() - 24, g.bottom() - 190)
            except Exception:
                pass
        self.show(); self.raise_()
        QApplication.processEvents()

    def end(self):
        self.timer.stop()
        if self._cursor:
            QApplication.restoreOverrideCursor(); self._cursor = False
        self.hide(); self.deleteLater()
        QApplication.processEvents()

    def closeEvent(self, e):          # no close button, but ignore Alt+F4 while work is running
        if self._cursor:
            e.ignore()
        else:
            super().closeEvent(e)

    def reject(self):                 # Esc must not hide it either
        pass


@contextmanager
def busy(parent, text="Working..."):
    w = BusyWindow(parent, text)
    w.begin()
    try:
        yield w
    finally:
        w.end()
