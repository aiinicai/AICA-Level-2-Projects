import datetime as dt
import traceback

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from ui.dates import DateField
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from core import db as dbm
from core import engine as E
from core.connectors import frappe, tally, zoho
from core.connectors.common import load_local, save_local
from core.engine import D, Y
from ui.busy import BusyWindow, busy
from ui.common import COL, ask, fmt, info, make_table, warn

L = dbm.load_json("lists.json")


class Worker(QThread):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)
    progress = pyqtSignal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self.cancelled = False

    def run(self):
        try:
            self.done.emit(self.fn(self))
        except (tally.TallyError, zoho.ZohoError, frappe.FrappeError) as e:
            self.failed.emit(str(e))
        except Exception:
            self.failed.emit("Unexpected problem:\n" + traceback.format_exc(limit=3))


class ConnectDialog(QDialog):
    def __init__(self, ctx, entity_id, parent=None):
        super().__init__(parent)
        self.ctx, self.eid = ctx, entity_id
        self.e = ctx.db.entity(entity_id) or {}
        self.setWindowTitle("Connect to accounting software: %s" % self.e.get("name", entity_id))
        self.resize(1180, 860)
        self.cfg = load_local()
        self.kind = None
        self.rows = []
        self.range = (None, None)
        self.worker = None
        lay = QVBoxLayout(self)
        step = 1 if self.e.get("vat_frequency") == "Monthly" else 3
        pe = D(self.e.get("vat_period_end")) or E.eom(dt.date.today().replace(day=1), -1)
        self.anchor, self.step = pe, step
        d2 = pe
        d1 = E.eom(pe, -step) + dt.timedelta(days=1)
        top = QGroupBox("Period to import")
        f = QFormLayout(top)
        self.vf, self.vt = DateField(Y(d1)), DateField(Y(d2))
        self.hist = QCheckBox("Also fetch the 12 months before (needed for the 12-month registration test)")
        self.noVat = QComboBox(); self.noVat.addItems(["Sale - zero rated", "Sale - exempt"])
        r1 = QHBoxLayout(); r1.addWidget(QLabel("From")); r1.addWidget(self.vf); r1.addWidget(QLabel("To")); r1.addWidget(self.vt); r1.addWidget(self.hist)
        w = QWidget(); w.setLayout(r1); f.addRow("VAT documents", w)
        f.addRow("Sales with no VAT are assumed", self.noVat)
        lay.addWidget(top)
        self.tabs = QTabWidget(); lay.addWidget(self.tabs); self.tabs.setMaximumHeight(270)
        self.tabs.addTab(self._tally_tab(), "Tally")
        self.tabs.addTab(self._zoho_tab(), "Zoho Books")
        self.tabs.addTab(self._frappe_tab(), "ERPNext / Frappe")
        self.status = QLabel(""); self.status.setWordWrap(True); lay.addWidget(self.status)
        self.table = make_table(["Use", "Date", "Document", "Party", "Type", "Net", "VAT", "Review"], editable=True)
        lay.addWidget(self.table, 1)
        self.notes = QLabel(""); self.notes.setObjectName("muted"); self.notes.setWordWrap(True); lay.addWidget(self.notes)
        row = QHBoxLayout(); row.addStretch(1)
        c = QPushButton("Close"); c.clicked.connect(self.reject)
        self.imp = QPushButton("Import selected rows"); self.imp.setObjectName("primary"); self.imp.setEnabled(False); self.imp.clicked.connect(self.do_import)
        row.addWidget(c); row.addWidget(self.imp); lay.addLayout(row)

    # ---------------------------------------------------------------- tabs
    def _tally_tab(self):
        w = QWidget(); l = QVBoxLayout(w)
        t = self.cfg.get("tally", {})
        n = QLabel("In Tally: open the client's company, then enable the server (F1 Help > Settings > Connectivity: TallyPrime acts as Server, port 9000). "
                   "The app only reads from Tally; nothing is changed there.")
        n.setWordWrap(True); n.setObjectName("muted"); l.addWidget(n)
        f = QFormLayout()
        self.t_url = QLineEdit(t.get("url", tally.DEFAULT_URL))
        self.t_co = QComboBox(); self.t_co.setEditable(True); self.t_co.setCurrentText(t.get("company", ""))
        self.t_co.lineEdit().setPlaceholderText("Leave blank for the company currently open in Tally")
        b = QPushButton("Find companies"); b.clicked.connect(self.t_find)
        self.t_vw = QLineEdit(t.get("vat_words", "vat"))
        self.t_key = QLineEdit(t.get("access_key", "")); self.t_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.t_key.setPlaceholderText("Only if a gateway or proxy in front of Tally asks for a key")
        f.addRow("Tally address", self.t_url); f.addRow("Company", self.t_co); f.addRow("", b); f.addRow("VAT ledger names contain", self.t_vw); f.addRow("Access key (optional)", self.t_key)
        l.addLayout(f)
        r = QHBoxLayout()
        b1 = QPushButton("Fetch VAT data"); b1.setObjectName("primary"); b1.clicked.connect(self.t_vat)
        r.addWidget(b1); r.addStretch(1); l.addLayout(r)
        return w

    def _zoho_tab(self):
        w = QWidget(); l = QVBoxLayout(w)
        z = self.cfg.get("zoho", {})
        n = QLabel("Easiest (key style): in Zoho's API Console choose Self Client, copy its Client ID and Secret here, open its Generate Code tab with scope  " + zoho.SCOPES +
                   "  (time 10 minutes), paste the code below and press Get token from code. Or use a Server-based Application with redirect address http://localhost:8765/callback and press Sign in with Zoho. "
                   "Secrets are kept only on this PC.")
        n.setWordWrap(True); n.setObjectName("muted"); l.addWidget(n)
        f = QFormLayout()
        self.z_dc = QComboBox(); self.z_dc.addItems(list(zoho.DCS)); self.z_dc.setCurrentText(z.get("dc", "com"))
        self.z_id = QLineEdit(z.get("client_id", "")); self.z_sec = QLineEdit(z.get("client_secret", "")); self.z_sec.setEchoMode(QLineEdit.EchoMode.Password)
        self.z_ref = QLineEdit(z.get("refresh_token", "")); self.z_ref.setEchoMode(QLineEdit.EchoMode.Password)
        self.z_org = QComboBox(); self.z_org.setEditable(True)
        if z.get("org_id"):
            self.z_org.addItem(z.get("org_name", z["org_id"]), z["org_id"])
        f.addRow("Zoho data centre (the ending of your Zoho address)", self.z_dc); f.addRow("Client ID", self.z_id); f.addRow("Client secret", self.z_sec)
        self.z_code = QLineEdit(); self.z_code.setPlaceholderText("Self Client grant code (valid a few minutes)")
        f.addRow("Grant code", self.z_code); f.addRow("Refresh token", self.z_ref); f.addRow("Organisation", self.z_org)
        l.addLayout(f)
        r = QHBoxLayout()
        b0 = QPushButton("Sign in with Zoho"); b0.clicked.connect(self.z_signin)
        b0b = QPushButton("Get token from code"); b0b.clicked.connect(self.z_grant)
        b1 = QPushButton("Load organisations"); b1.clicked.connect(self.z_orgs)
        b2 = QPushButton("Save connection"); b2.clicked.connect(self.z_save)
        self.z_go = QPushButton("Fetch VAT data"); self.z_go.setObjectName("primary"); self.z_go.clicked.connect(self.z_vat)
        self.z_stop = QPushButton("Stop"); self.z_stop.setEnabled(False); self.z_stop.clicked.connect(self.stop)
        for b in (b0b, b0, b1, b2, self.z_go, self.z_stop):
            r.addWidget(b)
        r.addStretch(1); l.addLayout(r)
        return w

    def _frappe_tab(self):
        w = QWidget(); l = QVBoxLayout(w)
        fc = self.cfg.get("frappe", {})
        n = QLabel("In ERPNext: User > open the user for this connection > API Access > Generate Keys, then copy the API key and the secret here. The user needs read access "
                   "(for example the Accounts User role). The app only reads; nothing is changed in ERPNext. Keys are kept only on this PC.")
        n.setWordWrap(True); n.setObjectName("muted"); l.addWidget(n)
        f = QFormLayout()
        self.fr_site = QLineEdit(fc.get("site", "")); self.fr_site.setPlaceholderText("https://mycompany.frappe.cloud")
        self.fr_key = QLineEdit(fc.get("api_key", ""))
        self.fr_sec = QLineEdit(fc.get("api_secret", "")); self.fr_sec.setEchoMode(QLineEdit.EchoMode.Password)
        self.fr_co = QComboBox(); self.fr_co.setEditable(True)
        if fc.get("company"):
            self.fr_co.addItem(fc["company"])
        f.addRow("Site address", self.fr_site); f.addRow("API key", self.fr_key); f.addRow("API secret", self.fr_sec); f.addRow("Company", self.fr_co)
        l.addLayout(f)
        r = QHBoxLayout()
        b1 = QPushButton("Test and load companies"); b1.clicked.connect(self.fr_companies)
        b2 = QPushButton("Save connection"); b2.clicked.connect(self.fr_save)
        b3 = QPushButton("Fetch VAT data"); b3.setObjectName("primary"); b3.clicked.connect(self.fr_vat)
        for b in (b1, b2, b3):
            r.addWidget(b)
        r.addStretch(1); l.addLayout(r)
        return w

    # ---------------------------------------------------------------- helpers
    def dates(self):
        d1, d2 = D(self.vf.text()), D(self.vt.text())
        if not d1 or not d2 or d1 > d2:
            raise ValueError("Enter the VAT from and to dates as DD-MM-YYYY.")
        if self.hist.isChecked():
            d1 = E.add_months(d1, -12)
        return d1, d2

    def run(self, fn, label):
        if self.worker and self.worker.isRunning():
            return
        self.status.setText(label)
        self.imp.setEnabled(False)
        self.worker = Worker(fn)
        self.busy_win = BusyWindow(self, label, on_cancel=self.stop)
        self.worker.progress.connect(self.status.setText)
        self.worker.progress.connect(self.busy_win.set_text)
        self.worker.done.connect(self.got)
        self.worker.failed.connect(self.fail)
        self.busy_win.begin()
        self.worker.start()
        self.z_stop.setEnabled(True)

    def _close_busy(self):
        w = getattr(self, "busy_win", None)
        if w is not None:
            self.busy_win = None
            w.end()

    def stop(self):
        if self.worker:
            self.worker.cancelled = True

    def fail(self, msg):
        self._close_busy()
        self.z_stop.setEnabled(False)
        self.status.setText("")
        warn(self, "Connection", msg)

    def guard(self, fn):
        try:
            return fn()
        except ValueError as e:
            warn(self, "Check the entries", str(e))

    # ---------------------------------------------------------------- Tally
    def t_save(self):
        self.cfg["tally"] = dict(url=self.t_url.text().strip(), company=self.t_co.currentText().strip(), vat_words=self.t_vw.text().strip(), access_key=self.t_key.text().strip())
        tally.set_access_key(self.t_key.text())
        save_local(self.cfg)

    def t_find(self):
        tally.set_access_key(self.t_key.text())
        try:
            with busy(self, "Looking for companies in Tally..."):
                names = tally.list_companies(self.t_url.text().strip())
        except tally.TallyError as e:
            return warn(self, "Tally", str(e))
        self.t_co.clear(); self.t_co.addItems(names)
        info(self, "Tally", "%d companies found." % len(names) if names else "Connected, but no companies are open.")

    def t_vat(self):
        def go():
            d1, d2 = self.dates()
            url, co = self.t_url.text().strip(), self.t_co.currentText().strip()
            words = tuple(x.strip().lower() for x in self.t_vw.text().split(",") if x.strip()) or ("vat",)
            nv = self.noVat.currentText()
            self.t_save()
            self.range = (d1, d2)
            self.run(lambda wk: tally.fetch_vat(url, co, d1, d2, self.anchor, self.step, nv, words, lambda m: wk.progress.emit(m), lambda: wk.cancelled), "Reading vouchers from Tally...")
        self.guard(go)

    # ---------------------------------------------------------------- Zoho
    def z_client(self, need_org=True):
        dc = self.z_dc.currentText()
        org = self.z_org.currentData() or self.z_org.currentText().strip()
        if not (self.z_id.text().strip() and self.z_sec.text().strip() and self.z_ref.text().strip()):
            raise ValueError("Enter the client ID, client secret and refresh token (use Sign in with Zoho to get the token).")
        if need_org and not org:
            raise ValueError("Choose the Zoho organisation (press Load organisations).")
        return zoho.Client(dc, self.z_id.text().strip(), self.z_sec.text().strip(), self.z_ref.text().strip(), org)

    def z_save(self):
        self.cfg["zoho"] = dict(dc=self.z_dc.currentText(), client_id=self.z_id.text().strip(), client_secret=self.z_sec.text().strip(),
                                refresh_token=self.z_ref.text().strip(), org_id=self.z_org.currentData() or self.z_org.currentText().strip(), org_name=self.z_org.currentText())
        save_local(self.cfg)
        self.status.setText("Zoho connection saved on this PC.")

    def z_signin(self):
        if not (self.z_id.text().strip() and self.z_sec.text().strip()):
            return warn(self, "Zoho", "Enter the client ID and client secret first.")
        dc, cid, sec = self.z_dc.currentText(), self.z_id.text().strip(), self.z_sec.text().strip()
        def fn(wk):
            wk.progress.emit("Waiting for you to approve access in the browser...")
            return zoho.browser_sign_in(dc, cid, sec)
        self.run(fn, "Opening Zoho in your browser...")
        self._after = "token"

    def z_grant(self):
        if not (self.z_id.text().strip() and self.z_sec.text().strip() and self.z_code.text().strip()):
            return warn(self, "Zoho", "Enter the client ID, client secret and the grant code first.")
        dc, cid, sec, code = self.z_dc.currentText(), self.z_id.text().strip(), self.z_sec.text().strip(), self.z_code.text().strip()
        self._after = "token"
        self.run(lambda wk: zoho.exchange_grant_code(dc, cid, sec, code), "Getting the token from Zoho...")

    def z_orgs(self):
        def go():
            c = self.z_client(need_org=False)
            self._after = "orgs"
            self.run(lambda wk: c.organizations(), "Loading organisations...")
        self.guard(go)

    def z_vat(self):
        def go():
            d1, d2 = self.dates()
            c = self.z_client()
            nv = self.noVat.currentText()
            self.range = (d1, d2)
            self._after = "vat"
            self.z_save()
            self.run(lambda wk: zoho.fetch_vat(c, d1, d2, self.anchor, self.step, nv, lambda m: wk.progress.emit(m), lambda: wk.cancelled), "Reading documents from Zoho Books...")
        self.guard(go)

    # ---------------------------------------------------------------- ERPNext / Frappe
    def fr_client(self, need_company=True):
        co = self.fr_co.currentText().strip()
        if not (self.fr_site.text().strip() and self.fr_key.text().strip() and self.fr_sec.text().strip()):
            raise ValueError("Enter the site address, API key and API secret.")
        if need_company and not co:
            raise ValueError("Choose the company (press Test and load companies).")
        return frappe.Client(self.fr_site.text(), self.fr_key.text(), self.fr_sec.text(), co)

    def fr_save(self):
        self.cfg["frappe"] = dict(site=self.fr_site.text().strip(), api_key=self.fr_key.text().strip(), api_secret=self.fr_sec.text().strip(), company=self.fr_co.currentText().strip())
        save_local(self.cfg)
        self.status.setText("ERPNext connection saved on this PC.")

    def fr_companies(self):
        def go():
            c = self.fr_client(need_company=False)
            self._after = "fr_companies"
            def fn(wk):
                c.test()
                return c.companies()
            self.run(fn, "Connecting to ERPNext...")
        self.guard(go)

    def fr_vat(self):
        def go():
            d1, d2 = self.dates()
            c = self.fr_client()
            nv = self.noVat.currentText()
            self.range = (d1, d2)
            self._after = "vat"
            self.fr_save()
            self.run(lambda wk: frappe.fetch_vat(c, d1, d2, self.anchor, self.step, nv, lambda m: wk.progress.emit(m), lambda: wk.cancelled), "Reading invoices from ERPNext...")
        self.guard(go)

    # ---------------------------------------------------------------- results
    def got(self, res):
        self._close_busy()
        self.z_stop.setEnabled(False)
        if self.worker is not None and self.worker.cancelled:
            self.status.setText("Cancelled. Nothing was imported.")
            return
        after = getattr(self, "_after", "")
        self._after = ""
        if isinstance(res, str) and after == "token":      # refresh token from sign-in
            self.z_ref.setText(res); self.status.setText("Signed in. Now press Load organisations.")
            return
        if after == "fr_companies" and isinstance(res, list):
            cur = self.fr_co.currentText()
            self.fr_co.clear(); self.fr_co.addItems(res)
            if cur in res:
                self.fr_co.setCurrentText(cur)
            self.status.setText("Connected. %d company(ies) found. Choose one." % len(res))
            return
        if isinstance(res, list):                           # organisations
            self.z_org.clear()
            for o in res:
                self.z_org.addItem(o.get("name", o["organization_id"]), o["organization_id"])
            self.status.setText("%d organisation(s) found. Choose one." % len(res))
            return
        self.show_rows(res)

    def show_rows(self, res):
        self.status.setText("")
        self.kind = "vat" if res.vat else None
        self.rows = res.vat
        t = self.table
        t.blockSignals(True)
        t.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            use = QTableWidgetItem(); use.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            use.setCheckState(Qt.CheckState.Checked)
            t.setItem(i, 0, use)
            ro = lambda s: self._ro(s)
            t.setItem(i, 1, ro(r["doc_date"])); t.setItem(i, 2, ro(r["doc_no"])); t.setItem(i, 3, ro(r["party"]))
            cb = QComboBox(); cb.addItems(L["vat_types"]); cb.setCurrentText(r["doc_type"]); t.setCellWidget(i, 4, cb)
            t.setItem(i, 5, self._num(r["net"])); t.setItem(i, 6, self._num(r["vat"]))
            rv = ro(r["flag"])
            if r["flag"]:
                from PyQt6.QtGui import QBrush, QColor
                rv.setBackground(QBrush(QColor(COL["amber"])))
            t.setItem(i, 7, rv)
        for j, w in enumerate((45, 95, 150, 190, 210, 110, 90, 300)):
            t.setColumnWidth(j, w)
        t.blockSignals(False)
        flagged = sum(1 for r in self.rows if r["flag"])
        tot = sum(r["net"] for r in self.rows)
        self.status.setText("%d rows read (%d to review, %d vouchers skipped). Total %s. Check the highlighted rows and the types, then import." % (len(self.rows), flagged, res.skipped, fmt(tot)))
        self.notes.setText("\n".join("• " + n for n in res.notes))
        self.imp.setEnabled(bool(self.rows))

    @staticmethod
    def _ro(s):
        it = QTableWidgetItem("" if s is None else str(s)); it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable); return it

    @staticmethod
    def _num(v):
        it = QTableWidgetItem("{:,.2f}".format(v)); it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable); return it

    def do_import(self):
        if not self.rows or not self.kind:
            return
        out = []
        for i, r in enumerate(self.rows):
            r = dict(r)
            sel = self.table.cellWidget(i, 4).currentText()
            if self.table.item(i, 0).checkState() != Qt.CheckState.Checked:
                continue
            r["doc_type"] = sel
            out.append(r)
        d1, d2 = (x.isoformat() for x in self.range)
        what = "VAT rows with document dates from %s to %s" % (d1, d2)
        if not out:
            return warn(self, "Import", "No rows are selected.")
        from core import validate as V
        from ui.review import review_issues
        if not review_issues(self, V.validate(self.kind, out, self.ctx.db.rules_dict(), self.ctx.db.entity(self.eid)), "import"):
            return
        if not ask(self, "Import", "Import %d rows? Existing %s for this client will be replaced." % (len(out), what)):
            return
        try:
            with busy(self, "Importing %d rows into the application..." % len(out)):
                self.ctx.db.replace_in_range(self.kind, self.eid, out, d1, d2, "accounting software")
        except Exception as e:
            return warn(self, "Import", str(e))
        self.ctx.refresh()
        info(self, "Import", "%d rows imported. The returns now use them." % len(out))
        self.accept()
