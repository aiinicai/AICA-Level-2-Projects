from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QPushButton, QStyledItemDelegate, QTabWidget, QTableWidgetItem,
                             QTextEdit, QVBoxLayout, QWidget, QRadioButton, QButtonGroup)

from core import dataio
from core import db as dbm
from core.returns import EMIRATES
from core import validate as V
from ui.dates import DateField, DateDelegate, NumDelegate, to_iso
from ui.review import ValidateDialog, review_issues
from ui.busy import busy
from ui.common import ask, fmt, header, info, item, make_table, page_layout, warn

L = dbm.load_json("lists.json")

# kind -> (title, [(key, header, width, type, choices)])
GRIDS = {
    "vat": ("VAT data", [("period_end", "VAT period end", 115, "date", None), ("doc_date", "Document date", 110, "date", None), ("doc_no", "Document no.", 100, "text", None),
                         ("party", "Customer / supplier", 170, "text", None), ("doc_type", "Transaction type", 210, "text", L["vat_types"]),
                         ("net", "Taxable value (AED)", 140, "num", None), ("vat", "VAT (AED)", 100, "num", None), ("description", "Remarks", 160, "text", None),
                         ("trn", "Party TRN", 110, "text", None), ("emirate", "Emirate", 110, "text", [""] + EMIRATES)]),
}


class ComboDelegate(QStyledItemDelegate):
    def __init__(self, choices, parent=None):
        super().__init__(parent)
        self.choices = choices

    def createEditor(self, parent, option, index):
        cb = QComboBox(parent)
        cb.addItems(self.choices)
        cb.setEditable(False)
        return cb

    def setEditorData(self, editor, index):
        i = editor.findText(str(index.data() or ""))
        editor.setCurrentIndex(max(i, 0))

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentText())


class Grid(QWidget):
    def __init__(self, ctx, kind):
        super().__init__()
        self.ctx, self.kind = ctx, kind
        self.title, self.cols = GRIDS[kind]
        self.eid = None
        lay = QVBoxLayout(self); lay.setContentsMargins(8, 8, 8, 8)
        bar = QHBoxLayout()
        self.count = QLabel(""); self.count.setObjectName("muted")
        bar.addWidget(self.count); bar.addStretch(1)
        self.pkey = {"vat": "period_end"}.get(kind)
        if self.pkey:
            bar.addWidget(QLabel("VAT period from"))
            self.f_from = DateField(); bar.addWidget(self.f_from)
            bar.addWidget(QLabel("to"))
            self.f_to = DateField(); bar.addWidget(self.f_to)
            self.f_clear = QPushButton("Show all"); bar.addWidget(self.f_clear)
            self.f_from.editingFinished.connect(self.apply_filter); self.f_to.editingFinished.connect(self.apply_filter)
            self.f_clear.clicked.connect(self.clear_filter)
        self.b_add = QPushButton("Add row"); self.b_add.clicked.connect(self.add_row)
        self.b_del = QPushButton("Delete selected"); self.b_del.clicked.connect(self.del_rows)
        self.b_imp = QPushButton("Import file"); self.b_imp.clicked.connect(self.import_file)
        self.b_save = QPushButton("Save changes"); self.b_save.setObjectName("primary"); self.b_save.clicked.connect(self.save)
        for b in (self.b_add, self.b_del, self.b_imp, self.b_save):
            bar.addWidget(b)
        lay.addLayout(bar)
        self.table = make_table([c[1] for c in self.cols], editable=True)
        for j, c in enumerate(self.cols):
            self.table.setColumnWidth(j, c[2])
            if c[4]:
                self.table.setItemDelegateForColumn(j, ComboDelegate(c[4], self.table))
            elif c[3] == "date":
                self.table.setItemDelegateForColumn(j, DateDelegate(self.table))
            elif c[3] == "num":
                self.table.setItemDelegateForColumn(j, NumDelegate(self.table))
        lay.addWidget(self.table)
        self.dirty = False
        self.table.itemChanged.connect(self._changed)
        self._loading = False

    def _changed(self, *_):
        if not self._loading:
            self.dirty = True
            self.count.setText(self.count.text().split("  |")[0] + "  |  unsaved changes")

    def set_entity(self, eid):
        self.eid = eid
        self.load()

    def load(self):
        self._loading = True
        rows = self.ctx.db.rows(self.kind, self.eid) if self.eid else []
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            for j, c in enumerate(self.cols):
                v = r.get(c[0])
                if c[3] == "num":
                    s = "" if v is None else "{:,.2f}".format(v)
                elif c[3] == "pct":
                    s = "" if v is None else ("%.3f" % (v * 100)).rstrip("0").rstrip(".") + "%"
                else:
                    s = "" if v is None else str(v)
                it = QTableWidgetItem(s)
                if c[3] in ("num", "pct"):
                    it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                self.table.setItem(i, j, it)
        self._loading = False
        self.dirty = False
        self.fill_filter()
        self.show_count()
        ed = self.ctx.can_edit() and bool(self.eid)
        for b in (self.b_add, self.b_del, self.b_imp, self.b_save):
            b.setEnabled(ed)
        self.b_imp.setEnabled(self.ctx.can_edit())

    # ---- period filter: rows outside the chosen range are hidden, not removed, so saving never drops them
    def _pcol(self):
        return next(j for j, c in enumerate(self.cols) if c[0] == self.pkey)

    def row_period(self, i):
        it = self.table.item(i, self._pcol())
        return to_iso(it.text()) if it else ""

    def fill_filter(self):
        """Default range = earliest to latest period in the grid (kept when the same client is reloaded)."""
        if not self.pkey:
            return
        vals = sorted({self.row_period(i) for i in range(self.table.rowCount()) if self.row_period(i)})
        keep = getattr(self, "_sel", None) if getattr(self, "_sel_eid", None) == self.eid else None
        if keep:
            self.f_from.setText(keep[0]); self.f_to.setText(keep[1])
        else:
            self.f_from.setText(vals[0] if vals else ""); self.f_to.setText(vals[-1] if vals else "")
        self.apply_filter()

    def clear_filter(self):
        if self.pkey:
            self.f_from.setText(""); self.f_to.setText("")
            self.apply_filter()

    def apply_filter(self, *_):
        if not self.pkey:
            return
        a, b = self.f_from.text(), self.f_to.text()
        self._sel, self._sel_eid = (a, b), self.eid
        if a and b and a > b:
            a, b = b, a
        for i in range(self.table.rowCount()):
            p = self.row_period(i)
            self.table.setRowHidden(i, bool((a and p and p < a) or (b and p and p > b)))
        self.show_count()

    def visible_rows(self):
        return [i for i in range(self.table.rowCount()) if not self.table.isRowHidden(i)]

    def show_count(self):
        n, vis = self.table.rowCount(), self.visible_rows()
        tot = ""
        if self.kind == "vat":
            j = next(j for j, c in enumerate(self.cols) if c[0] == "net")
            amt = 0.0
            for i in vis:
                it = self.table.item(i, j)
                v = dataio.parse_num(it.text()) if it and it.text().strip() else 0
                amt += v if isinstance(v, (int, float)) else 0
            tot = "  |  total %s" % fmt(amt)
        shown = "%d rows" % n if len(vis) == n else "%d of %d rows (filtered)" % (len(vis), n)
        self.count.setText(shown + tot)

    def add_row(self):
        self._loading = True
        r = self.table.rowCount(); self.table.insertRow(r)
        last = r - 1
        for j, c in enumerate(self.cols):
            v = self.table.item(last, j).text() if last >= 0 and c[0] in ("period_end", "fy_end") else ""
            self.table.setItem(r, j, QTableWidgetItem(v))
        self._loading = False
        self.dirty = True
        self.table.setRowHidden(r, False)
        self.table.setCurrentCell(r, 0)
        self.table.editItem(self.table.item(r, 0))

    def del_rows(self):
        for r in sorted({i.row() for i in self.table.selectedIndexes() if not self.table.isRowHidden(i.row())}, reverse=True):
            self.table.removeRow(r)
        self._changed()

    def collect(self):
        rows, errs = [], []
        for i in range(self.table.rowCount()):
            d, empty = {}, True
            for j, c in enumerate(self.cols):
                it = self.table.item(i, j)
                s = it.text().strip() if it else ""
                if s:
                    empty = False
                if c[3] == "date":
                    v = dataio.parse_date(s) if s else None
                    if isinstance(v, str) and v.startswith("?"):
                        errs.append("Row %d: %s is not a date" % (i + 1, c[1])); v = None
                elif c[3] in ("num", "pct"):
                    v = dataio.parse_num(s) if s else None
                    if isinstance(v, str):
                        errs.append("Row %d: %s is not a number" % (i + 1, c[1])); v = None
                    if c[3] == "pct" and v is not None and "%" not in s and abs(v) > 1:
                        v = v / 100
                else:
                    v = s or None
                    if v and c[4] and v not in c[4]:
                        errs.append("Row %d: '%s' is not an allowed %s" % (i + 1, v, c[1]))
                d[c[0]] = v
            if not empty:
                rows.append(d)
        return rows, errs

    def save(self):
        rows, errs = self.collect()
        if errs:
            return warn(self, "Check the data", "\n".join(errs[:15]) + ("\n..." if len(errs) > 15 else ""))
        issues = V.validate(self.kind, rows, self.ctx.db.rules_dict(), self.ctx.db.entity(self.eid))
        if not review_issues(self, issues, "save"):
            return
        try:
            self.ctx.db.save_rows(self.kind, self.eid, rows)
        except Exception as e:
            return warn(self, "Save", str(e))
        self.dirty = False
        self.ctx.refresh()

    def import_file(self):
        p, _ = QFileDialog.getOpenFileName(self, "Import " + self.title, "", "Excel or CSV (*.xlsx *.csv)")
        if not p:
            return
        dlg = ImportDialog(self)
        if not dlg.exec():
            return
        try:
            with busy(self, "Reading the file and checking the data..."):
                res = dataio.import_upload(self.ctx.db, p, self.kind, dlg.mode())
            if res.get("blocked"):
                allv = [dict(i, message="%s: %s" % (eid, i["message"])) for eid, v in res["validation"].items() for i in v]
                if not review_issues(self, allv, "import"):
                    return
                with busy(self, "Importing the data into the application..."):
                    res = dataio.import_upload(self.ctx.db, p, self.kind, dlg.mode(), force=True)
        except Exception as e:
            return warn(self, "Import", str(e))
        self.ctx.refresh()
        msg = "%d rows imported for %s." % (res["imported"], ", ".join(res["entities"]) or "no clients")
        warns = sum(V.summary(v)[1] for v in res.get("validation", {}).values())
        if warns:
            msg += "\n%d warning(s) - use Validate data to list them." % warns
        if res["issues"]:
            msg += "\n\nProblems (rows with problems were skipped):\n" + "\n".join(("Row %d: %s" % i if i[0] else i[1]) for i in res["issues"][:20])
        info(self, "Import", msg)


class ImportDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Import mode")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("How should the file be combined with the data already held?"))
        self.r1 = QRadioButton("Replace the rows of each client found in the file"); self.r1.setChecked(True)
        self.r2 = QRadioButton("Add to the existing rows")
        lay.addWidget(self.r1); lay.addWidget(self.r2)
        b = QPushButton("Import"); b.setObjectName("primary"); b.clicked.connect(self.accept); lay.addWidget(b)

    def mode(self):
        return "replace" if self.r1.isChecked() else "append"


class DataPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Data", "VAT transactions per client. The VAT returns pick their totals up from these rows."))
        bar = QHBoxLayout()
        bar.addWidget(QLabel("Client"))
        self.combo = QComboBox(); self.combo.setMinimumWidth(340); self.combo.currentIndexChanged.connect(self.pick)
        bar.addWidget(self.combo); bar.addStretch(1)
        self.b_con = QPushButton("Connect to accounting software"); self.b_con.setObjectName("primary"); self.b_con.clicked.connect(self.connect_sw)
        bar.addWidget(self.b_con)
        self.b_val = QPushButton("Validate data"); self.b_val.clicked.connect(self.validate_all)
        bar.addWidget(self.b_val)
        self.b_tpl = QPushButton("Download import template"); self.b_tpl.clicked.connect(self.template)
        bar.addWidget(self.b_tpl)
        lay.addLayout(bar)
        self.tabs = QTabWidget()
        self.grids = {}
        for k in ("vat",):
            g = Grid(ctx, k); self.grids[k] = g
            self.tabs.addTab(g, "VAT data")
        lay.addWidget(self.tabs)
        ctx.changed.connect(self.reload)
        self.reload()

    def reload(self):
        cur = self.combo.currentData()
        self.combo.blockSignals(True)
        self.combo.clear()
        for t, v in [("%s  %s" % (e["id"], e["name"]), e["id"]) for e in self.ctx.result()["entities"]]:
            self.combo.addItem(t, v)
        i = self.combo.findData(cur)
        self.combo.setCurrentIndex(max(i, 0) if self.combo.count() else -1)
        self.combo.blockSignals(False)
        self.pick()

    def pick(self):
        for g in self.grids.values():
            g.set_entity(self.combo.currentData())
        self.b_con.setEnabled(self.ctx.can_edit() and bool(self.combo.currentData()))

    def connect_sw(self):
        eid = self.combo.currentData()
        if not eid or not self.ctx.can_edit():
            return warn(self, "Connect", "Choose a client first (and sign in with an account that can edit data).")
        from ui.connect import ConnectDialog
        ConnectDialog(self.ctx, eid, self).exec()

    def validate_all(self):
        eid = self.combo.currentData()
        if eid:
            ValidateDialog(self.ctx, eid, self).exec()

    def template(self):
        p, _ = QFileDialog.getSaveFileName(self, "Import template", "VAT-DESK_Import_Template.xlsx", "Excel (*.xlsx)")
        if p:
            dataio.write_template(p)
            info(self, "Template", "Saved to " + p)
