"""First-run setup guide: firm profile, default emirate, backup folder and the first client."""
from __future__ import annotations

from PyQt6.QtWidgets import (QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QRadioButton, QStackedWidget, QVBoxLayout, QWidget)

from ui.common import header, info, warn

EMIRATES = ["Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Umm Al Quwain", "Ras Al Khaimah", "Fujairah"]
LOCATIONS = ["Mainland", "Free Zone", "Designated Zone"]


def apply_setup(db, firm="", emirate="Dubai", email="", backup_dir="", client=None, sample=False):
    """Everything the wizard does, kept apart from the screen so it can be tested."""
    db.need("Admin")
    if firm:
        db.set_setting("firm", firm)
    db.set_setting("default_emirate", emirate or "Dubai")
    if email:
        db.set_setting("firm_email", email)
    if backup_dir:
        db.set_setting("backup_dir", backup_dir)
    if sample:
        db.load_sample()
    elif client and client.get("name"):
        d = dict(client)
        d.setdefault("id", db.next_entity_id())
        db.save_entity(d)
    db.set_setting("setup_done", "1")
    db.audit("setup.complete", "wizard", "firm=%s emirate=%s" % (firm, emirate))


class FirstRunWizard(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Welcome: set up your firm")
        self.resize(620, 460)
        lay = QVBoxLayout(self)
        lay.addWidget(header("Set up your firm", "Four quick steps. You can change any of this later."))
        self.stack = QStackedWidget(); lay.addWidget(self.stack, 1)
        # step 1
        w = QWidget(); f = QFormLayout(w)
        self.firm = QLineEdit(db.setting("firm", "")); self.firm.setPlaceholderText("Name shown on every report")
        self.email = QLineEdit(); self.email.setPlaceholderText("Optional, shown in client reminders")
        self.em = QComboBox(); self.em.addItems(EMIRATES); self.em.setCurrentText(db.setting("default_emirate", "Dubai") or "Dubai")
        f.addRow("Firm name", self.firm); f.addRow("Contact email", self.email); f.addRow("Your usual emirate", self.em)
        f.addRow(QLabel("The emirate is the default place of supply on VAT 201. You can override it for any return."))
        self.stack.addWidget(w)
        # step 2
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(QLabel("Where should daily backups be kept? A folder on a different drive, or a synced cloud folder, protects you if this PC fails."))
        r = QHBoxLayout(); self.bk = QLineEdit(); self.bk.setPlaceholderText("Leave blank to use the default folder next to the database")
        b = QPushButton("Browse"); b.clicked.connect(self.browse); r.addWidget(self.bk); r.addWidget(b); v.addLayout(r); v.addStretch(1)
        self.stack.addWidget(w)
        # step 3
        w = QWidget(); v = QVBoxLayout(w)
        self.r_new = QRadioButton("Add my first client now"); self.r_samp = QRadioButton("Load sample clients so I can look around"); self.r_skip = QRadioButton("Skip: I will add clients later")
        self.r_new.setChecked(True)
        for x in (self.r_new, self.r_samp, self.r_skip):
            v.addWidget(x)
        f = QFormLayout()
        self.cn = QLineEdit(); self.cn.setPlaceholderText("Client legal name")
        self.cl = QComboBox(); self.cl.addItems(LOCATIONS)
        self.cv = QComboBox(); self.cv.addItems(["Yes", "No"])
        f.addRow("Client name", self.cn); f.addRow("Location", self.cl); f.addRow("Registered for VAT", self.cv)
        v.addLayout(f)
        v.addWidget(QLabel("Mainland, free zone (qualifying or not) and designated zone clients are all handled. Fill in the rest of the client record from the Clients page."))
        v.addStretch(1); self.stack.addWidget(w)
        # step 4
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(QLabel("<b>You are ready.</b><br><br>Next: add colleagues under Users (and limit them to certain clients with Assign clients), upload each client's data on the Data page or connect to their accounting system, then open Returns and workings."))
        v.addStretch(1); self.stack.addWidget(w)
        row = QHBoxLayout(); row.addStretch(1)
        self.back = QPushButton("Back"); self.back.clicked.connect(lambda: self.go(-1))
        self.nxt = QPushButton("Next"); self.nxt.setObjectName("primary"); self.nxt.clicked.connect(lambda: self.go(1))
        row.addWidget(self.back); row.addWidget(self.nxt); lay.addLayout(row)
        self.show_step()

    def browse(self):
        p = QFileDialog.getExistingDirectory(self, "Backup folder")
        if p:
            self.bk.setText(p)

    def show_step(self):
        i = self.stack.currentIndex()
        self.back.setEnabled(i > 0)
        self.nxt.setText("Finish" if i == self.stack.count() - 1 else "Next")

    def go(self, d):
        i = self.stack.currentIndex() + d
        if d > 0 and i == self.stack.count():
            return self.finish()
        if d > 0 and self.stack.currentIndex() == 0 and not self.firm.text().strip():
            return warn(self, "Setup", "Please enter your firm name.")
        if d > 0 and self.stack.currentIndex() == 2 and self.r_new.isChecked() and not self.cn.text().strip():
            return warn(self, "Setup", "Enter the client's name, or choose Skip.")
        self.stack.setCurrentIndex(max(0, i)); self.show_step()

    def finish(self):
        client = None
        if self.r_new.isChecked():
            client = dict(name=self.cn.text().strip(), location=self.cl.currentText(), vat_registered=self.cv.currentText())
        try:
            apply_setup(self.db, self.firm.text().strip(), self.em.currentText(), self.email.text().strip(), self.bk.text().strip(), client, self.r_samp.isChecked())
        except Exception as e:
            return warn(self, "Setup", str(e))
        self.accept()
