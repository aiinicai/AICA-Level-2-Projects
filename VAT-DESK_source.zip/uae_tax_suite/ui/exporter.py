"""Export whatever a page shows (every table, note and sub-tab) to Excel or PDF."""
from __future__ import annotations

import datetime as dt
import os

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout, QLabel, QListWidget, QPlainTextEdit, QPushButton, QStackedWidget, QTabWidget,
                             QTableWidget, QTextEdit, QWidget, QMessageBox)

from core import tabexport as TX
from ui.busy import busy


def _cell_text(t, r, c):
    w = t.cellWidget(r, c)
    if isinstance(w, QComboBox):
        return w.currentText()
    if w is not None and hasattr(w, "text"):
        try:
            return w.text()
        except Exception:
            pass
    it = t.item(r, c)
    if it is None:
        return ""
    if it.flags() & Qt.ItemFlag.ItemIsUserCheckable and it.checkState() == Qt.CheckState.Checked and not it.text():
        return "Yes"
    return it.text()


def table_block(t, title):
    cols = t.columnCount()
    head = []
    for c in range(cols):
        h = t.horizontalHeaderItem(c)
        head.append(h.text() if h else "")
    rows = [[_cell_text(t, r, c) for c in range(cols)] for r in range(t.rowCount()) if not t.isRowHidden(r)]
    return {"title": title, "header": head, "rows": rows}


def collect(root, name):
    """Walk a page; every QTableWidget -> table block, notes/labels -> text block. Sub-tabs are all included."""
    blocks, notes, seen = [], [], set()

    def walk(w, path):
        if isinstance(w, QTabWidget):
            for i in range(w.count()):
                walk(w.widget(i), path + [w.tabText(i)])
            return
        if isinstance(w, QStackedWidget):
            for i in range(w.count()):
                walk(w.widget(i), path)
            return
        if isinstance(w, QTableWidget):
            if w.rowCount() and id(w) not in seen:
                seen.add(id(w))
                blocks.append(table_block(w, " - ".join([name] + [p for p in path if p]) if path else name))
            return
        if isinstance(w, QListWidget):
            items = [w.item(i).text() for i in range(w.count())]
            if items:
                blocks.append({"title": " - ".join([name] + path), "header": ["Item"], "rows": [[x] for x in items]})
            return
        if isinstance(w, (QTextEdit, QPlainTextEdit)):
            txt = w.toPlainText().strip()
            if txt:
                notes.append("[%s]\n%s" % (" - ".join(path) or name, txt))
            return
        if isinstance(w, QLabel):
            txt = w.text().strip()
            if txt and w.objectName() not in ("nav",):
                import re
                notes.append(re.sub(r"<[^>]+>", "", txt.replace("<br>", "\n").replace("<br/>", "\n")))
            return
        for ch in w.findChildren(QWidget, options=Qt.FindChildOption.FindDirectChildrenOnly):
            walk(ch, path)

    walk(root, [])
    if notes:
        blocks.insert(0, {"title": "Summary and notes", "text": "\n".join(notes)})
    return blocks


def export_page(parent, page, name, kind):
    """kind: 'xlsx' or 'pdf'. Asks where to save, writes the file, returns the path or None."""
    stamp = dt.date.today().strftime("%d-%m-%Y")
    safe = "".join(ch if ch.isalnum() else "_" for ch in name).strip("_")
    ext = "xlsx" if kind == "xlsx" else "pdf"
    p, _ = QFileDialog.getSaveFileName(parent, "Export %s to %s" % (name, "Excel" if kind == "xlsx" else "PDF"), "VAT-DESK_%s_%s.%s" % (safe, stamp, ext),
                                       "Excel (*.xlsx)" if kind == "xlsx" else "PDF (*.pdf)")
    if not p:
        return None
    with busy(parent, "Exporting %s..." % name):
        blocks = collect(page, name)
        sub = "Exported on %s" % stamp
        (TX.to_xlsx if kind == "xlsx" else TX.to_pdf)(p, name, blocks, sub)
    QMessageBox.information(parent, "Export", "Saved:\n%s" % p)
    return p


class ExportBar(QWidget):
    """Thin bar shown above every page: Export to Excel / Export to PDF for what the page shows."""

    def __init__(self, get_page, parent=None):
        super().__init__(parent)
        self.get_page = get_page
        l = QHBoxLayout(self); l.setContentsMargins(22, 6, 22, 0)
        l.addStretch(1)
        self.bx = QPushButton("Export to Excel"); self.bp = QPushButton("Export to PDF")
        self.bx.setToolTip("Download everything shown on this page (all its sub-tabs) as an Excel workbook")
        self.bp.setToolTip("Download everything shown on this page (all its sub-tabs) as a PDF")
        self.bx.clicked.connect(lambda: self.go("xlsx")); self.bp.clicked.connect(lambda: self.go("pdf"))
        l.addWidget(self.bx); l.addWidget(self.bp)

    def go(self, kind):
        page, name = self.get_page()
        try:
            export_page(self.window(), page, name, kind)
        except Exception as e:
            QMessageBox.warning(self, "Export", "The export could not be completed:\n%s" % e)
