from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush, QColor
from PyQt6.QtWidgets import (QFrame, QScrollArea, QComboBox, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QPushButton, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from core import dataio, db as dbm
from core.returns import EMIRATES
from ui.busy import busy
from ui.periodbar import PeriodBar
from ui.common import COL, ask, card, fill_table, fmt, header, info, item, make_table, page_layout, warn

STATUSES = ["Not started", "In progress", "Done", "N/A"]
SCHED = dbm.load_json("schedules.json")


def fixed_height(t, n_rows, header=True):
    h = 26 * n_rows + (30 if header else 2) + 4
    t.setFixedHeight(h + 8)
    t.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    t.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)


def kv_table(pairs):
    t = make_table(["Item", "Value"])
    t.horizontalHeader().setVisible(False)
    fill_table(t, [[k, v] for k, v in pairs], widths=(260, 360))
    for i in range(t.rowCount()):
        f = t.item(i, 0).font(); f.setBold(True); t.item(i, 0).setFont(f)
        t.item(i, 0).setBackground(QBrush(QColor("#D9E2F3")))
    fixed_height(t, len(pairs), header=False)
    return t


def scroll(w):
    sc = QScrollArea(); sc.setWidgetResizable(True); sc.setFrameShape(QFrame.Shape.NoFrame); sc.setWidget(w)
    return sc


def lines_table(lines, heads, keys, widths, num_keys=("amount", "vat", "adj")):
    t = make_table(heads)
    t.setRowCount(len(lines))
    for i, l in enumerate(lines):
        for j, k in enumerate(keys):
            v = l.get(k)
            it = item(v, num=(k in num_keys and isinstance(v, (int, float))), bold=l["bold"] or l["kind"] == "head")
            if l["kind"] == "head":
                it.setBackground(QBrush(QColor("#D9E2F3")))
            elif l["bold"]:
                it.setBackground(QBrush(QColor("#F2F2F2")))
            t.setItem(i, j, it)
    for j, w in enumerate(widths):
        t.setColumnWidth(j, w)
    t.setMinimumHeight(430)
    return t


from ui.review import ReconWidget, SignoffWidget


class Checklist(QWidget):
    def __init__(self, ctx, area, items):
        super().__init__()
        self.ctx, self.area, self.items = ctx, area, items
        lay = QVBoxLayout(self); lay.setContentsMargins(6, 6, 6, 6)
        self.lbl = QLabel(""); self.lbl.setObjectName("muted"); lay.addWidget(self.lbl)
        self.table = make_table(["Group", "Working paper", "Applies when", "Status", "Note"], stretch_last=True)
        lay.addWidget(self.table)
        self.eid = None
        self.cells = {}

    def set_entity(self, eid):
        self.eid = eid
        saved = self.ctx.db.checklist(eid) if eid else {}
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.items))
        self.cells = {}
        for i, it in enumerate(self.items):
            s = saved.get((self.area, it["item"]))
            self.table.setItem(i, 0, item(it["group"])); self.table.setItem(i, 1, item(it["item"])); self.table.setItem(i, 2, item(it.get("applies") or ""))
            cb = QComboBox(); cb.addItems(STATUSES); cb.setCurrentText(s["status"] if s else "Not started")
            cb.setEnabled(self.ctx.can_edit())
            cb.currentTextChanged.connect(lambda txt, i=i: self.save(i))
            self.table.setCellWidget(i, 3, cb)
            n = item(s["note"] if s else "")
            if self.ctx.can_edit():
                n.setFlags(n.flags() | Qt.ItemFlag.ItemIsEditable)
            self.table.setItem(i, 4, n)
        for j, w in enumerate((190, 430, 220, 110, 250)):
            self.table.setColumnWidth(j, w)
        self.table.blockSignals(False)
        try:
            self.table.itemChanged.disconnect()
        except TypeError:
            pass
        self.table.itemChanged.connect(lambda it: self.save(it.row()) if it.column() == 4 else None)
        self.summary()

    def save(self, i):
        if not self.eid:
            return
        st = self.table.cellWidget(i, 3).currentText()
        note = self.table.item(i, 4).text() if self.table.item(i, 4) else ""
        try:
            self.ctx.db.set_check(self.eid, self.area, self.items[i]["item"], st, note)
        except Exception as e:
            return warn(self, "Checklist", str(e))
        self.summary()

    def summary(self):
        st = [self.table.cellWidget(i, 3).currentText() for i in range(self.table.rowCount())]
        appl = sum(1 for s in st if s != "N/A")
        done = sum(1 for s in st if s == "Done")
        self.lbl.setText("%d of %d applicable papers done (%.0f%%)" % (done, appl, (done / appl * 100) if appl else 0))


class ReturnsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.b = None
        lay = page_layout(self)
        lay.addWidget(header("Returns and workings", "VAT 201 return and workings for one client, built from the client record and uploaded data."))
        bar = QHBoxLayout(); bar.setSpacing(10)
        bar.addWidget(QLabel("Client"))
        self.combo = QComboBox(); self.combo.setMinimumWidth(300); self.combo.currentIndexChanged.connect(self.on_client)
        bar.addWidget(self.combo, 3)
        bar.addWidget(QLabel("Emirate"))
        self.em = QComboBox(); self.em.setMinimumWidth(130); self.em.addItems(EMIRATES); self.em.setCurrentText(ctx.db.setting("default_emirate", "Dubai") or "Dubai"); self.em.currentIndexChanged.connect(self.build)
        bar.addWidget(self.em, 1)
        self.vp = QComboBox(); self.vp.currentIndexChanged.connect(self.build)     # shown inside the VAT 201 tab (PeriodBar)
        self.pbar = {"VAT": PeriodBar("VAT", self)}
        self.ftab = {k: self._holder(self.pbar[k]) for k in ("VAT",)}
        lay.addLayout(bar)
        bar2 = QHBoxLayout(); bar2.setSpacing(10)
        self.bx = QPushButton("Export Excel pack"); self.bx.clicked.connect(self.exp_x)
        self.bf = QPushButton("Filing pack (ZIP)"); self.bf.clicked.connect(self.exp_f)
        self.bs = QPushButton("Client summary (PDF)"); self.bs.clicked.connect(self.exp_s)
        self.bp = QPushButton("Export PDF pack"); self.bp.setObjectName("primary"); self.bp.clicked.connect(self.exp_p)
        self.save_snapshot_button = QPushButton('Save return snapshot for Filing Assistant')
        self.save_snapshot_button.clicked.connect(self.save_snapshot)
        for x in (self.bx, self.bs, self.bf, self.bp, self.save_snapshot_button):
            bar2.addWidget(x)
        bar2.addStretch(1)
        lay.addLayout(bar2)
        self.period_note = QLabel(""); self.period_note.setObjectName("muted"); self.period_note.setWordWrap(True); lay.addWidget(self.period_note)
        self.tabs = QTabWidget(); lay.addWidget(self.tabs)
        self._applying = False
        ctx.changed.connect(self.reload)
        ctx.selection_changed.connect(self.on_sel)
        self.reload()

    def on_sel(self, source):
        """The Filing Assistant (or another screen) picked a client or period: follow it."""
        if source is self or self._applying:
            return
        s = self.ctx.sel
        self._applying = True
        try:
            i = self.combo.findData(s["client"]) if s["client"] else -1
            if i >= 0 and self.combo.currentData() != s["client"]:
                self.combo.blockSignals(True); self.combo.setCurrentIndex(i); self.combo.blockSignals(False)
                self.fill_periods(s["client"])
            if s["VAT"]:
                self.pbar["VAT"].select(s["VAT"])
            self.build()
        finally:
            self._applying = False

    def save_snapshot(self):
        if not self.combo.currentData():
            return
        try:
            from fta_assistant.saved import save
            save(self.ctx.db, self.combo.currentData(), self.em.currentText(), self.periods())
            self.ctx.refresh()
            info(self, 'Saved return', 'Detailed return snapshots saved for the Filing Assistant.')
        except Exception as exc:
            warn(self, 'Save return', str(exc))

    def periods(self):
        return (self.vp.currentData() or "", "")

    def fill_periods(self, eid, keep=False):
        """All VAT periods / financial years known for this client (data rows, saved returns, current); the From/To bars narrow them."""
        db = self.ctx.db
        cur = db.current_periods(eid) if eid else ("", "")
        old = self.periods() if keep else ("", "")
        from fta_assistant import saved
        for kind, c, o in (("VAT", cur[0], old[0]),):
            vals = set()
            if eid:
                vals |= set(saved.periods(db, eid, kind))
            vals.discard("")
            if c:
                vals.add(c)
            self.pbar[kind].set_periods(vals, c, o or None)
            if not keep:
                self.pbar[kind].f_from.setText(""); self.pbar[kind].f_to.setText(""); self.pbar[kind].fill(o or None)

    def on_client(self, *_):
        self.fill_periods(self.combo.currentData())
        self.build()

    def reload(self):
        self.save_snapshot_button.setEnabled(self.ctx.can_edit())
        cur = self.combo.currentData()
        self.combo.blockSignals(True)
        self.combo.clear()
        for e in self.ctx.result()["entities"]:
            self.combo.addItem("%s  %s" % (e["id"], e["name"]), e["id"])
        i = self.combo.findData(cur)
        self.combo.setCurrentIndex(max(i, 0) if self.combo.count() else -1)
        self.combo.blockSignals(False)
        self.fill_periods(self.combo.currentData(), keep=(i >= 0))
        self.build()

    def build(self):
        idx = self.tabs.currentIndex()
        self.tabs.clear()
        eid = self.combo.currentData()
        if not eid:
            return
        e0 = self.ctx.db.entity(eid)
        if e0 and e0.get("vat_emirate") and self.sender() not in (self.em, self.vp):
            self.em.blockSignals(True); self.em.setCurrentText(e0["vat_emirate"]); self.em.blockSignals(False)
        b = self.b = dataio.entity_bundle(self.ctx.db, eid, self.ctx.result(), None, self.em.currentText(), self.periods())
        cur = self.ctx.db.current_periods(eid)
        past = [n for n, sel, c in (("VAT period", b["periods"][0], cur[0]),) if sel and sel != c]
        self.period_note.setText("Showing a past period (%s). Figures, exports, sign-off and snapshots all apply to the periods selected above." % " and ".join(past) if past else "")
        if not self._applying:
            self.ctx.set_selection(eid, b["periods"][0], self)
        e, v, k = b["e"], b["v"], b["k"]
        # summary
        w = QWidget(); g = QVBoxLayout(w)
        cards = QGridLayout()
        items = [("VAT", v["vat_status"], "Net %s, due %s" % (fmt(v["net_vat"]), v["due"])), ("Risk", "%d %s" % (k["risk_score"], k["rag"]), "Exposure %s" % fmt(k["exposure"]))]
        for i, (a, bb, cc) in enumerate(items):
            cards.addWidget(card(a, bb, cc), 0, i)
        g.addLayout(cards)
        g.addWidget(QLabel("Open items"))
        it = make_table(["Area", "Severity", "Issue", "Action"])
        fill_table(it, [[i["area"], i["severity"], i["issue"], i["action"]] for i in b["issues"]], status_cols=(1,), widths=(110, 80, 520, 380))
        g.addWidget(it)
        self.tabs.addTab(w, "Summary")
        self.tabs.addTab(self._holder_set("VAT", scroll(self.fta_vat(b))), "VAT 201 (FTA format)")
        # VAT 201 workings: only what is not already in the "VAT 201 (FTA format)" tab (basis and schedule references, and the checks)
        w = QWidget(); g = QVBoxLayout(w)
        v2 = b["vat201"]
        nt = QLabel("Amounts, boxes and taxpayer details are in the VAT 201 (FTA format) tab. This tab (VAT Return basis) keeps the basis of each box, the schedules to attach, and the checks."); nt.setObjectName("muted"); nt.setWordWrap(True); g.addWidget(nt)
        basis = [dict(desc="%s  %s" % (l["box"], l["desc"]), note=l["note"], bold=False, kind="line") for l in v2["lines"] if l.get("kind") != "head" and l.get("note")]
        bt = lines_table(basis, ["Box and description", "Basis and schedule"], ["desc", "note"], (520, 560), num_keys=())
        bt.setMinimumHeight(0); fixed_height(bt, len(basis)); g.addWidget(bt)
        g.addWidget(QLabel("Checks"))
        ck = make_table(["Check", "Result"])
        fill_table(ck, [["Net VAT box 14", fmt(v2["net"])], ["Per VAT calculation", fmt(v2["check_net"])], ["Difference", fmt(v2["diff"])],
                        ["Ledger reconciliation", v2["recon_status"]], ["Penalty estimate if overdue", fmt(v2["penalty"])]], widths=(360, 220))
        fixed_height(ck, 5); g.addWidget(ck)
        g.addStretch(1)
        vat_basis = scroll(w)
        # reconciliations and sign-off
        rw = ReconWidget(self.ctx); rw.set_bundle(b)
        self.tabs.addTab(rw, "Reconciliations")
        sw = SignoffWidget(self.ctx, self.build); sw.set_bundle(b)
        sts = [x["status"] for x in b["signoff"]]
        self.tabs.addTab(sw, "Sign-off" + (" (%s)" % ", ".join("%s %s" % (x["kind"], x["status"]) for x in b["signoff"]) if any(st != "Draft" for st in sts) else ""))
        # schedules required
        sub = QTabWidget()
        for key, nm, flags, cols in (("vat_sched", "VAT: 30 schedules", b["vat201"]["sched_flags"], 3),):
            tb = make_table(["No.", "Schedule", "Reference", "Needed?"])
            rows = []
            for i, s in enumerate(b[key]):
                rows.append([s["no"], s["name"], s["ref"], "Required" if i < len(flags) and flags[i] == "1" else "Not required"])
            fill_table(tb, rows, status_cols=(3,), widths=(60, 520, 280, 100))
            for r in range(tb.rowCount()):
                if tb.item(r, 3).text() == "Required":
                    tb.item(r, 3).setBackground(QBrush(QColor(COL["amber"])))
                else:
                    tb.item(r, 3).setBackground(QBrush(QColor(COL["grey"])))
            sub.addTab(tb, nm)
        self.tabs.addTab(sub, "Schedules required")
        # working paper checklists
        sub = QTabWidget()
        self.checks = []
        for area, key, nm in (("VAT", "vat_check", "VAT checklist"),):
            cl = Checklist(self.ctx, area, SCHED[key]); cl.set_entity(eid); sub.addTab(cl, nm); self.checks.append(cl)
        self.tabs.addTab(sub, "Working paper checklists")
        self.tabs.addTab(vat_basis, "VAT Return basis")
        self.tabs.setCurrentIndex(min(idx, self.tabs.count() - 1) if idx >= 0 else 0)
        self.bx.setEnabled(True); self.bp.setEnabled(True)

    def _holder(self, bar):
        """A tab body with the From/To bar fixed on top and a body that is swapped each time the return is rebuilt."""
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 4, 0, 0); v.setSpacing(6)
        v.addWidget(bar)
        w._v = v; w._body = None
        return w

    def _holder_set(self, kind, body):
        h = self.ftab[kind]
        if h._body is not None:
            h._v.removeWidget(h._body); h._body.setParent(None); h._body.deleteLater()
        h._body = body; h._v.addWidget(body, 1)
        rec = self._record_note(kind)
        self.pbar[kind].count.setToolTip(rec)
        return h

    def _record_note(self, kind):
        try:
            from fta_assistant import saved
            eid = self.combo.currentData(); p = self.periods()[0]
            h = next((x for x in saved.history(self.ctx.db, eid, kind) if x["period"] == p), None)
            return ("Saved record v%s, saved %s by %s. Approval: %s" % (h["versions"], h["saved_at"], h["saved_by"], h["approval"])) if h and h["versions"] else "Not saved yet: rebuilt from the data rows for this period"
        except Exception:
            return ""

    def export_periods(self, kind, whole_range):
        """Excel of the picked period, or of every period in the From/To range (one sheet per period)."""
        eid = self.combo.currentData()
        if not eid:
            return
        bar = self.pbar[kind]
        plist = bar.in_range() if whole_range else [self.periods()[0]]
        plist = [p for p in plist if p]
        if not plist:
            return info(self, "Export", "There are no periods in the selected range.")
        name = "%s_%s_%s.xlsx" % (eid, kind, plist[0] if len(plist) == 1 else "%s_to_%s" % (plist[-1], plist[0]))
        path, _ = QFileDialog.getSaveFileName(self, "Export %s return to Excel" % kind, name, "Excel (*.xlsx)")
        if not path:
            return
        try:
            with busy(self, "Fetching the %s return for %d period(s) and writing Excel..." % (kind, len(plist))):
                dataio.export_fta_periods(self.ctx.db, eid, kind, plist, self.em.currentText(), path, self.ctx.result())
            self.ctx.db.audit("export.fta_periods", eid, path)
        except Exception as ex:
            return warn(self, "Export", str(ex))
        info(self, "Export", "Saved %d period(s) to:\n%s" % (len(plist), path))

    @staticmethod
    def _paired(pairs):
        """Label and value pairs two to a row, as the FTA documents show them."""
        rows = []
        for i in range(0, len(pairs), 2):
            a = pairs[i]; c = pairs[i + 1] if i + 1 < len(pairs) else ("", "")
            rows.append([a[0], a[1], c[0], c[1]])
        t = make_table(["", "", "", ""])
        t.horizontalHeader().setVisible(False)
        fill_table(t, rows, widths=(250, 250, 250, 250))
        for i in range(t.rowCount()):
            for j in (0, 2):
                it = t.item(i, j); f = it.font(); f.setBold(True); it.setFont(f); it.setBackground(QBrush(QColor("#D9E2F3")))
        t.setWordWrap(True); t.resizeRowsToContents()
        t.setFixedHeight(sum(t.rowHeight(i) for i in range(t.rowCount())) + 12)
        t.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff); t.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        return t

    def fta_vat(self, b):
        f = b["vat_fta"]
        w = QWidget(); g = QVBoxLayout(w)
        t = QLabel(f["title"]); t.setObjectName("h2"); g.addWidget(t)
        n_ = QLabel("Laid out as the FTA VAT 201 return document. Workings, notes and reconciliations are in the other tabs."); n_.setObjectName("muted"); g.addWidget(n_)
        g.addWidget(QLabel("Taxpayer Information")); g.addWidget(self._paired(f["header"]))
        sec, chunk = None, []
        def flush():
            if chunk:
                g.addWidget(QLabel(sec))
                net = sec == "Net VAT Due"
                heads = ["Description", "Amount (AED)"] if net else ["Description", "Amount (AED)", "VAT Amount (AED)", "Adjustment (AED)"]
                rows = [dict(desc="%s %s" % (l["box"], l["desc"]), amount=l["amount"], vat=l["vat"], adj=l["adj"], bold=l["bold"], kind="line") for l in chunk]
                tb = lines_table(rows, heads, ["desc", "amount"] if net else ["desc", "amount", "vat", "adj"], (520, 170) if net else (520, 170, 170, 170))
                tb.setMinimumHeight(0); fixed_height(tb, len(rows))
                for i, l in enumerate(chunk):
                    for j in ((1,) if net else (1, 2, 3)):
                        it = tb.item(i, j)
                        if isinstance(l[("amount", "vat", "adj")[j - 1]], (int, float)):
                            it.setText("{:,.2f}".format(l[("amount", "vat", "adj")[j - 1]]))
                g.addWidget(tb)
        for l in f["lines"]:
            if l["section"] != sec:
                flush(); sec, chunk = l["section"], []
            chunk.append(l)
        flush()
        g.addWidget(QLabel("Profit Margin Scheme")); g.addWidget(self._paired([f["margin"]]))
        g.addWidget(QLabel("Authorised Signatory")); g.addWidget(self._paired(f["signatory"]))
        g.addStretch(1)
        return w

    def exp_x(self):
        if not self.b:
            return
        p, _ = QFileDialog.getSaveFileName(self, "Excel pack", "%s_tax_pack.xlsx" % self.b["e"]["id"], "Excel (*.xlsx)")
        if p:
            with busy(self, "Exporting the Excel pack..."):
                dataio.export_entity_xlsx(p, self.b, self.ctx.firm)
            self.ctx.db.audit("export.xlsx", self.b["e"]["id"], p)
            info(self, "Export", "Saved to " + p)

    def exp_p(self):
        if not self.b:
            return
        p, _ = QFileDialog.getSaveFileName(self, "PDF pack", "%s_tax_pack.pdf" % self.b["e"]["id"], "PDF (*.pdf)")
        if p:
            with busy(self, "Exporting the PDF pack..."):
                dataio.export_entity_pdf(p, self.b, self.ctx.firm)
            self.ctx.db.audit("export.pdf", self.b["e"]["id"], p)
            info(self, "Export", "Saved to " + p)

    def exp_s(self):
        if not self.b:
            return
        from core import clientsummary as CS
        if self.period_note.text():
            return info(self, "Client summary", "The client summary covers the client's current periods. Select the current VAT period to create it.")
        p, _ = QFileDialog.getSaveFileName(self, "Client summary", "%s_client_summary.pdf" % self.b["e"]["id"], "PDF (*.pdf)")
        if p:
            with busy(self, "Creating the client summary..."):
                CS.pdf(p, CS.build(self.ctx.result(), self.b["e"]["id"], self.ctx.firm))
            self.ctx.db.audit("export.summary", self.b["e"]["id"], p)
            info(self, "Export", "Saved to " + p)

    def exp_f(self):
        if not self.b:
            return
        from core import filingpack as FP
        checks = FP.readiness(self.ctx.db, self.b)
        ov = FP.overall(checks)
        txt = "\n".join("%s  %s: %s" % ({"Ready": "[OK]  ", "Not ready": "[STOP]", "Check": "[CHECK]"}[r], a, d) for a, r, d in checks)
        if not ask(self, "Filing pack: " + ("ready" if ov == FP.OK else "not ready" if ov == FP.NO else "check the amber items"),
                   txt + "\n\nCreate the filing pack ZIP now?" + ("\n\nThe pack will say it is NOT READY." if ov == FP.NO else "")):
            return
        p, _ = QFileDialog.getSaveFileName(self, "Filing pack", "%s_filing_pack.zip" % self.b["e"]["id"], "ZIP (*.zip)")
        if p:
            with busy(self, "Creating the filing pack..."):
                FP.build_zip(p, self.ctx.db, self.b, self.ctx.firm)
            self.ctx.db.audit("export.filingpack", self.b["e"]["id"], p)
            info(self, "Filing pack", "Saved to " + p)
