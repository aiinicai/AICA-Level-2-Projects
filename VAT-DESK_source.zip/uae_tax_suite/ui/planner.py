from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QInputDialog, QLineEdit, QApplication, QComboBox, QFileDialog, QHBoxLayout, QLabel, QPushButton, QTabWidget, QVBoxLayout, QWidget

from core import deadlines as DL
from core import mail as ML

from ui.common import fill_table, header, info, make_table, page_layout, warn


class PlannerPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Calendar and open items", "Every VAT deadline, and every point that needs attention, across all clients."))
        self.tabs = QTabWidget(); lay.addWidget(self.tabs)
        w = QWidget(); l = QVBoxLayout(w)
        bar = QHBoxLayout()
        self.f_ent = QComboBox(); self.f_obl = QComboBox(); self.f_st = QComboBox()
        for lab, cb in (("Client", self.f_ent), ("Obligation", self.f_obl), ("Status", self.f_st)):
            bar.addWidget(QLabel(lab)); bar.addWidget(cb); cb.currentIndexChanged.connect(self.fill_cal)
        bar.addStretch(1); l.addLayout(bar)
        self.cal = make_table(["ID", "Client", "Location", "Obligation", "Period end", "Due", "Days left", "Status"])
        l.addWidget(self.cal); self.tabs.addTab(w, "Deadlines")
        w = QWidget(); l = QVBoxLayout(w)
        bar = QHBoxLayout()
        self.i_sev = QComboBox(); self.i_area = QComboBox()
        for lab, cb in (("Severity", self.i_sev), ("Area", self.i_area)):
            bar.addWidget(QLabel(lab)); bar.addWidget(cb); cb.currentIndexChanged.connect(self.fill_iss)
        bar.addStretch(1); l.addLayout(bar)
        self.iss = make_table(["ID", "Client", "Area", "Severity", "Issue", "Action"])
        l.addWidget(self.iss); self.tabs.addTab(w, "Open items")
        w = QWidget(); l = QVBoxLayout(w)
        w = QWidget(); l = QVBoxLayout(w)
        self.rem_msg = QLabel(""); self.rem_msg.setWordWrap(True); l.addWidget(self.rem_msg)
        bar = QHBoxLayout()
        self.win = QComboBox()
        for d in (7, 14, 30, 60, 90):
            self.win.addItem("Next %d days" % d, d)
        self.win.setCurrentIndex(2); self.win.currentIndexChanged.connect(self.fill_rem)
        bar.addWidget(QLabel("Show items overdue or due in")); bar.addWidget(self.win); bar.addStretch(1)
        for txt, fn in (("Export to calendar (.ics)", self.export_ics), ("Export list (CSV)", self.export_csv), ("Copy client reminder", self.copy_email), ("Email client", self.email_client)):
            b = QPushButton(txt); b.clicked.connect(fn); bar.addWidget(b)
        l.addLayout(bar)
        self.rem = make_table(["ID", "Client", "Obligation", "Period end", "Due", "Days left", "Level", "Action", "Penalty so far", "If 30 days later"])
        l.addWidget(self.rem); self.tabs.addTab(w, "Reminders and penalties")
        self._rem = []
        w = QWidget(); l = QVBoxLayout(w)
        self.zone = make_table(["Scope", "Clients", "Overdue items", "Net VAT", "Penalty exposure", "Average risk", "High-risk clients"])
        l.addWidget(self.zone); self.tabs.addTab(w, "By location")
        ctx.changed.connect(self.reload)
        self.reload()

    @staticmethod
    def _fill_combo(cb, vals, first="All"):
        cur = cb.currentText()
        cb.blockSignals(True); cb.clear(); cb.addItem(first); cb.addItems(vals)
        i = cb.findText(cur); cb.setCurrentIndex(max(i, 0)); cb.blockSignals(False)

    def reload(self):
        r = self.ctx.result()
        self._fill_combo(self.f_ent, sorted({d["entity"] for d in r["calendar"]}))
        self._fill_combo(self.f_obl, sorted({d["obligation"] for d in r["calendar"]}))
        self._fill_combo(self.f_st, sorted({d["status"] for d in r["calendar"]}))
        self._fill_combo(self.i_sev, ["High", "Medium", "Info"]); self._fill_combo(self.i_area, sorted({i["area"] for i in r["issues"]}))
        self.fill_cal(); self.fill_iss(); self.fill_rem()
        fill_table(self.zone, [[z["label"], z["entities"], z["overdue"], z["net_vat"], z["exposure"], z["avg_risk"], z["red_count"]] for z in r["zones"]],
                   num_cols=tuple(range(1, 7)), widths=(160, 70, 110, 110, 130, 100, 120))

    def fill_cal(self):
        r = self.ctx.result()
        rows = [[d["id"], d["entity"], d["location"], d["obligation"], d["period_end"], d["due"], d["days_left"], d["status"]] for d in r["calendar"]
                if (self.f_ent.currentIndex() <= 0 or d["entity"] == self.f_ent.currentText()) and (self.f_obl.currentIndex() <= 0 or d["obligation"] == self.f_obl.currentText())
                and (self.f_st.currentIndex() <= 0 or d["status"] == self.f_st.currentText())]
        fill_table(self.cal, rows, num_cols=(6,), status_cols=(7,), widths=(55, 240, 110, 230, 100, 100, 80, 90))

    def fill_iss(self):
        r = self.ctx.result()
        rows = [[i["id"], i["name"], i["area"], i["severity"], i["issue"], i["action"]] for i in r["issues"]
                if (self.i_sev.currentIndex() <= 0 or i["severity"] == self.i_sev.currentText()) and (self.i_area.currentIndex() <= 0 or i["area"] == self.i_area.currentText())]
        fill_table(self.iss, rows, status_cols=(3,), widths=(55, 220, 110, 80, 560, 380))

    def fill_rem(self):
        res = self.ctx.result()
        self._rem = DL.reminders(res, self.win.currentData() or 30)
        self.rem_msg.setText(DL.status_line(res) + " Penalty figures are estimates from the Rules page; the FTA assesses penalties.")
        fill_table(self.rem, [[r["id"], r["entity"], r["obligation"], r["period_end"], r["due"], r["days_left"], r["level"], r["action"], r["penalty_now"], r["penalty_in_30"]] for r in self._rem],
                   num_cols=(5, 8, 9), status_cols=(6,), widths=(45, 200, 170, 90, 90, 60, 70, 200, 100, 105))

    def _save(self, name, filt, text, binary=False):
        p, _ = QFileDialog.getSaveFileName(self, "Save", name, filt)
        if p:
            with open(p, "w", encoding="utf-8", newline="") as f:
                f.write(text)
            self.ctx.db.audit("export", "reminders", p)
            info(self, "Saved", "Saved to " + p)

    def export_ics(self):
        if not self._rem:
            return warn(self, "Reminders", "Nothing to export for this window.")
        self._save("tax_deadlines.ics", "Calendar (*.ics)", DL.to_ics(self._rem))

    def export_csv(self):
        if not self._rem:
            return warn(self, "Reminders", "Nothing to export for this window.")
        self._save("tax_reminders.csv", "CSV (*.csv)", DL.to_csv(self._rem))

    def copy_email(self):
        r = self.rem.currentRow()
        if r < 0 or r >= len(self._rem):
            return warn(self, "Reminders", "Select a row first.")
        QApplication.clipboard().setText(DL.client_email(self._rem[r]["entity"], self._rem, self.ctx.firm))
        info(self, "Copied", "A reminder for %s is on the clipboard. Paste it into an email." % self._rem[r]["entity"])

    def email_client(self):
        r = self.rem.currentRow()
        if r < 0 or r >= len(self._rem):
            return warn(self, "Reminders", "Select a row first.")
        res, eid = self.ctx.result(), self._rem[r]["id"]
        to, sub, body = ML.reminder_draft(self.ctx.db, res, self._rem, eid, self.ctx.firm)
        if not to:
            to, ok = QInputDialog.getText(self, "Client email", "Email address for %s (saved for next time)" % self._rem[r]["entity"], QLineEdit.EchoMode.Normal, "")
            if not ok:
                return
            to = to.strip()
            if to and "@" not in to:
                return warn(self, "Email", "That does not look like an email address.")
            if to:
                self.ctx.db.set_setting("contact:" + eid, to)
        link, cut = ML.draft(to, sub, body)
        QDesktopServices.openUrl(QUrl(link))
        self.ctx.db.audit("email.draft", eid, sub)
        info(self, "Email", "A draft has been opened in your mail program. Nothing is sent until you press Send there." + ("\n\nThe text was shortened to fit; use Copy client reminder for the full message." if cut else ""))
