from PyQt6.QtWidgets import QGridLayout, QLabel, QWidget, QVBoxLayout

from ui.common import card, fill_table, header, make_table, page_layout, fmt
from core.engine import Y


class DashboardPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        self.title = header("Dashboard", "")
        lay.addWidget(self.title)
        self.cards = QGridLayout(); self.cards.setSpacing(10)
        lay.addLayout(self.cards)
        lay.addWidget(self._h2("Client position"))
        self.pos = make_table(["ID", "Client", "Location", "VAT", "Risk", "Score", "Net VAT"])
        lay.addWidget(self.pos, 3)
        g = QGridLayout(); g.setSpacing(10)
        g.addWidget(self._h2("Next deadlines"), 0, 0); g.addWidget(self._h2("Priority open items"), 0, 1)
        self.cal = make_table(["Client", "Obligation", "Due", "Days", "Status"])
        self.iss = make_table(["Client", "Area", "Issue"])
        g.addWidget(self.cal, 1, 0); g.addWidget(self.iss, 1, 1)
        lay.addLayout(g, 3)
        ctx.changed.connect(self.reload)
        self.reload()

    def _h2(self, t):
        l = QLabel(t); l.setObjectName("h2"); return l

    def reload(self):
        r = self.ctx.result()
        while self.cards.count():
            w = self.cards.takeAt(0).widget()
            if w:
                w.deleteLater()
        z = next(x for x in r["zones"] if x["scope"] == "all")
        asof = Y(r["today"])
        self.title.findChild(QLabel, "muted").setText("Position as at %s. Change the position date on the Rules page." % asof) if self.title.findChild(QLabel, "muted") else None
        cards = [("Clients", str(z["entities"]), ""), ("Overdue items", str(int(z["overdue"])), "VAT", "#A61B1B" if z["overdue"] else None),
                 ("Net VAT payable", fmt(z["net_vat"]), "AED, open returns"),
                 ("Penalty exposure", fmt(z["exposure"]), "AED estimate", "#A61B1B" if z["exposure"] else None),
                 ("High-risk clients", str(int(z["red_count"])), "risk score 40+", "#A61B1B" if z["red_count"] else None)]
        for i, c in enumerate(cards):
            self.cards.addWidget(card(*c), 0, i)
        rows = [[k["id"], k["name"], k["location"], k["vat_status"], k["rag"], k["risk_score"], k["vat_net"]] for k in r["risk"]]
        fill_table(self.pos, rows, num_cols=(5, 6), status_cols=(3, 4), widths=(50, 260, 110, 160, 70, 60, 110))
        fill_table(self.cal, [[d["entity"], d["obligation"], d["due"], d["days_left"], d["status"]] for d in r["calendar"][:12]], num_cols=(3,), status_cols=(4,), widths=(150, 175, 80, 45, 70))
        fill_table(self.iss, [[i["name"], i["area"], i["issue"]] for i in r["issues"] if i["severity"] == "High"][:12], widths=(150, 90, 400))
