"""Data validation review, reconciliations and the sign-off tab."""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QHBoxLayout, QInputDialog, QLabel, QMessageBox, QPushButton, QTextEdit, QVBoxLayout, QWidget)

from core import recon as RC
from core import validate as V
from ui.common import ask, fill_table, header, info, make_table, warn

KIND_NAMES = {"vat": "VAT data"}


def review_issues(parent, issues, what="save"):
    """Shows the problems found in rows about to be saved or imported. Returns True if the user chooses to go on."""
    if not issues:
        return True
    errs, warns = V.summary(issues)
    box = QMessageBox(parent)
    box.setWindowTitle("Check the data")
    box.setIcon(QMessageBox.Icon.Warning if errs else QMessageBox.Icon.Information)
    box.setText("%d error(s) and %d warning(s) found before the %s." % (errs, warns, what))
    box.setInformativeText("Errors are almost certainly wrong (for example a missing date or category, or VAT on a zero-rated supply). Warnings are worth a look (for example VAT that is not 5% of the value, or a possible duplicate).")
    box.setDetailedText(V.text(issues, 60))
    fix = box.addButton("Go back and fix", QMessageBox.ButtonRole.RejectRole)
    go = box.addButton("%s anyway" % what.capitalize(), QMessageBox.ButtonRole.AcceptRole)
    box.setDefaultButton(fix if errs else go)
    box.exec()
    return box.clickedButton() is go


class ValidateDialog(QDialog):
    """Checks everything held for a client and lists the problems."""

    def __init__(self, ctx, eid, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Validate data: " + eid)
        self.resize(900, 520)
        lay = QVBoxLayout(self)
        R = ctx.db.rules_dict()
        ent = ctx.db.entity(eid)
        rows, tot_e, tot_w = [], 0, 0
        for kind in ("vat",):
            data = ctx.db.rows(kind, eid)
            iss = V.validate(kind, data, R, ent)
            e, w = V.summary(iss)
            tot_e += e; tot_w += w
            for i in sorted(iss, key=lambda x: (x["severity"] != "Error", x["row"])):
                rows.append([KIND_NAMES[kind], i["row"] or "", "Error" if i["severity"] == "Error" else "Warning", i["field"], i["message"]])
        lay.addWidget(QLabel("%d error(s), %d warning(s) across the data held for this client." % (tot_e, tot_w) if rows else "No problems found."))
        t = make_table(["Data", "Row", "Severity", "Field", "Problem"])
        fill_table(t, rows, status_cols=(2,), widths=(120, 50, 80, 130, 520))
        t.item(0, 2) if rows else None
        lay.addWidget(t)
        b = QPushButton("Close"); b.clicked.connect(self.accept); lay.addWidget(b)


class ReconWidget(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = QVBoxLayout(self)
        self.lbl = QLabel(""); self.lbl.setWordWrap(True)
        lay.addWidget(self.lbl)
        self.t = make_table(["Area", "Check", "Per ledger (AED)", "Per return (AED)", "Difference (AED)", "Result"])
        lay.addWidget(self.t)
        n = QLabel("Ledger balances are entered on the client record (VAT control accounts, related party ledger total). A difference needs explaining before filing: timing, errors or an adjustment not yet posted.")
        n.setObjectName("muted"); n.setWordWrap(True)
        lay.addWidget(n)

    def set_bundle(self, b):
        rows = b["recon"]
        fill_table(self.t, [[r["area"], r["check"], r["ledger"], r["ret"], r["diff"], r["status"]] for r in rows], num_cols=(2, 3, 4), status_cols=(5,), widths=(120, 420, 120, 120, 120, 100))
        d = RC.open_differences(rows)
        none = not rows
        self.lbl.setText("No ledger balances to reconcile for this client." if none else
                         ("%d difference(s) still open." % d if d else "All provided ledger balances agree to the returns."))


class SignoffWidget(QWidget):
    """Submit, review, approve and lock a return. The preparer and approver must differ unless self-approval is allowed."""

    def __init__(self, ctx, on_change):
        super().__init__()
        self.ctx, self.on_change, self.b = ctx, on_change, None
        lay = QVBoxLayout(self)
        self.banner = QLabel(""); self.banner.setWordWrap(True)
        lay.addWidget(self.banner)
        self.t = make_table(["Return", "Period end", "Status", "Prepared by", "Prepared on", "Reviewed by", "Reviewed on", "Note"])
        self.t.setMaximumHeight(110)
        self.t.itemSelectionChanged.connect(self.buttons)
        lay.addWidget(self.t)
        self.note = QTextEdit(); self.note.setPlaceholderText("Note for the reviewer, the reason for returning, or the explanation for approving with open differences / for reopening")
        self.note.setMaximumHeight(70)
        lay.addWidget(self.note)
        bar = QHBoxLayout()
        self.bs = QPushButton("Submit for review"); self.bs.clicked.connect(lambda: self.act("submit"))
        self.ba = QPushButton("Approve and lock"); self.ba.setObjectName("primary"); self.ba.clicked.connect(lambda: self.act("approve"))
        self.br = QPushButton("Return to preparer"); self.br.clicked.connect(lambda: self.act("return"))
        self.bo = QPushButton("Reopen"); self.bo.setObjectName("danger"); self.bo.clicked.connect(lambda: self.act("reopen"))
        for x in (self.bs, self.ba, self.br, self.bo):
            bar.addWidget(x)
        bar.addStretch(1)
        lay.addLayout(bar)
        lay.addWidget(QLabel("History"))
        self.h = make_table(["When", "User", "Return", "Period end", "Action", "Note"])
        lay.addWidget(self.h)

    # -- state
    def periods(self):
        e = self.b["e"]
        vpe = (self.b.get("periods") or self.ctx.db.current_periods(e["id"]))[0]
        return [("VAT", vpe)]

    def set_bundle(self, b):
        self.b = b
        eid = b["e"]["id"]
        self.so = [self.ctx.db.signoff_get(eid, k, pe) for k, pe in self.periods() if pe]
        rows = [[s["kind"], s["period_end"], s["status"], s["prepared_by"], str(s["prepared_at"])[:16], s["reviewed_by"], str(s["reviewed_at"])[:16], s["note"]] for s in self.so]
        fill_table(self.t, rows, status_cols=(2,), widths=(70, 100, 90, 110, 120, 110, 120, 300))
        if self.so:
            self.t.selectRow(0)
        self.h_load()
        self.buttons()

    def h_load(self):
        hist = self.ctx.db.signoff_history(self.b["e"]["id"])
        fill_table(self.h, [[str(x["ts"])[:16], x["username"], x["kind"], x["period_end"], x["action"], x["note"]] for x in hist], widths=(120, 100, 70, 100, 170, 400))

    def cur(self):
        r = self.t.currentRow()
        return self.so[r] if 0 <= r < len(self.so) else None

    def snapshot(self, kind):
        v = self.b["v"]
        return dict(net_vat=v.get("net_vat"), vat_due=v.get("due"))

    def open_items(self, kind):
        n = RC.open_differences([r for r in self.b["recon"] if r["area"] == "VAT"])
        areas = ("VAT",)
        return n + sum(1 for i in self.b["issues"] if i["severity"] == "High" and i["area"] in areas)

    def buttons(self):
        s = self.cur()
        ce, rev = self.ctx.can_edit(), self.ctx.db.role() in ("Reviewer", "Admin")
        st = s["status"] if s else ""
        self.bs.setEnabled(bool(s) and ce and st == "Draft")
        self.ba.setEnabled(bool(s) and rev and st == "In review")
        self.br.setEnabled(bool(s) and rev and st == "In review")
        self.bo.setEnabled(bool(s) and rev and st == "Approved")
        if not s:
            self.banner.setText("")
            return
        extra = ""
        if st == "Approved":
            snap, now = s.get("snapshot") or {}, self.snapshot(s["kind"])
            changed = [k for k in now if k in snap and snap[k] is not None and now[k] is not None and abs(float(snap[k]) - float(now[k])) > 0.5]
            extra = " The data for this period is locked." + (" Warning: the figures now differ from those approved (%s), for example because a rate or client setting changed." % ", ".join(changed) if changed else "")
        elif st == "In review":
            extra = " Waiting for a reviewer. The preparer was %s%s." % (s["prepared_by"], "" if self.ctx.db.self_approval_allowed() else "; someone else must approve")
        self.banner.setText("<b>%s return, period ending %s: %s.</b>%s" % (s["kind"], s["period_end"], st, extra))

    def act(self, what):
        s = self.cur()
        if not s:
            return
        db, note = self.ctx.db, self.note.toPlainText().strip()
        try:
            if what == "submit":
                db.signoff_submit(self.b["e"]["id"], s["kind"], s["period_end"], note, self.snapshot(s["kind"]))
            elif what == "approve":
                n = self.open_items(s["kind"])
                if n and len(note) < 3:
                    return warn(self, "Approve", "%d reconciliation difference(s) or high-severity item(s) are open. Write a note explaining why the return is approved, then approve again." % n)
                if not ask(self, "Approve and lock", "Approve the %s return for the period ending %s? Its data will be locked until it is reopened." % (s["kind"], s["period_end"])):
                    return
                db.signoff_approve(self.b["e"]["id"], s["kind"], s["period_end"], note, self.snapshot(s["kind"]), n)
            elif what == "return":
                db.signoff_return(self.b["e"]["id"], s["kind"], s["period_end"], note)
            elif what == "reopen":
                db.signoff_reopen(self.b["e"]["id"], s["kind"], s["period_end"], note)
        except Exception as e:
            return warn(self, "Sign-off", str(e))
        self.note.clear()
        self.ctx.refresh()
