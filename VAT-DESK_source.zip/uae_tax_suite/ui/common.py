"""Shared UI helpers: application context, styling, tables, dialogs."""
from __future__ import annotations

from PyQt6.QtCore import QObject, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor
from PyQt6.QtWidgets import (QAbstractItemView, QFrame, QHBoxLayout, QHeaderView, QLabel, QMessageBox, QTableWidget,
                             QTableWidgetItem, QVBoxLayout, QWidget)

from core import engine as E

NAVY = "#1E3A8A"      # Clean Corporate theme: royal blue
ACCENT = "#1D4ED8"
ORANGE = "#F97316"

STYLE = """
* { font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; font-size: 10pt; color: #1A2433; }
QMainWindow, QDialog { background: #EEF2F7; }
QWidget#page { background: #EEF2F7; }
QFrame#sidebar { background: white; border-right: 1px solid #DCE3EE; }
QFrame#sidebar QLabel { color: %(navy)s; }
QPushButton#nav { color: #334155; background: transparent; border: none; border-left: 4px solid transparent; text-align: left; padding: 10px 18px; font-size: 10.5pt; font-weight: 600; }
QPushButton#nav:hover { background: #F1F5FB; }
QPushButton#nav:checked { background: #EAF0FF; color: %(accent)s; border-left: 4px solid %(orange)s; font-weight: 700; }
QPushButton { background: white; border: 1px solid #B8C4D6; border-radius: 6px; padding: 6px 14px; }
QPushButton:hover { background: #EAF0FF; border-color: %(accent)s; }
QPushButton:disabled { color: #94A3B8; background: #EEF1F6; }
QPushButton#primary { background: %(orange)s; color: white; border: 1px solid %(orange)s; font-weight: 700; }
QPushButton#primary:hover { background: #EA580C; }
QPushButton#primary:disabled { background: #FBC9A0; border-color: #FBC9A0; color: white; }
QPushButton#danger { color: #DC2626; }
QLineEdit, QComboBox, QDateEdit, QTextEdit, QSpinBox, QDoubleSpinBox { background: white; border: 1px solid #B8C4D6; border-radius: 5px; padding: 4px 6px; }
QLineEdit:focus, QComboBox:focus { border: 1px solid %(accent)s; }
QLineEdit:read-only { background: #EEF1F6; }
QTableWidget { background: white; border: 1px solid #DCE3EE; gridline-color: #EDF1F7; selection-background-color: #DBE7FF; selection-color: #0F2A6B; alternate-background-color: #F7F9FD; }
QHeaderView::section { background: #F1F5FB; color: #334155; padding: 6px; border: none; border-bottom: 2px solid #DCE3EE; border-right: 1px solid #E3E9F3; font-weight: 700; }
QTabWidget::pane { border: 1px solid #DCE3EE; background: white; top: -1px; }
QTabBar::tab { background: #1B2A5E; color: white; font-weight: 700; padding: 8px 16px; border: 1px solid #0F1F5C; border-bottom: none; margin-right: 2px; border-top-left-radius: 6px; border-top-right-radius: 6px; }
QTabBar::tab:hover { background: #2B3F85; }
QTabBar::tab:selected { background: #0F1F5C; color: white; font-weight: 700; border-top: 3px solid %(orange)s; }
QFrame#card { background: white; border: 1px solid #DCE3EE; border-left: 5px solid %(accent)s; border-radius: 10px; }
QLabel#h1 { font-size: 17pt; font-weight: 700; color: #0F2A6B; }
QLabel#h2 { font-size: 11.5pt; font-weight: 700; color: %(navy)s; }
QLabel#muted { color: #64748B; }
QLabel#kpi { font-size: 19pt; font-weight: 700; color: #0F2A6B; }
QGroupBox { border: 1px solid #DCE3EE; border-radius: 8px; margin-top: 10px; background: white; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: %(navy)s; font-weight: 700; }
""" % dict(navy=NAVY, accent=ACCENT, orange=ORANGE)

RED = {"Overdue", "Overdue (unpaid)", "Registration required", "Action needed", "Difference", "High", "Red", "Register", "Outside range", "Fails", "Over the limit", "Urgent", "Error"}
AMBER = {"Due soon", "Filed, payment due", "In progress", "Medium", "Amber", "Pending", "Not started", "Review", "In review", "Draft", "Warning", "No benchmark", "Partial", "Check CbC", "Open"}
GREEN = {"Filed", "Filed and paid", "On track", "Compliant", "Green", "Reconciled", "Complete", "Upcoming", "Within range", "Done", "Qualifies", "Approved", "Within"}
COL = {"red": "#F8CBAD", "amber": "#FFE699", "green": "#C6E0B4", "grey": "#E7E6E6"}


def tone(text) -> str | None:
    s = str(text or "")
    if s in RED or s.startswith("Fails"):
        return "red"
    if s in AMBER:
        return "amber"
    if s in GREEN:
        return "green"
    if s in ("Not required", "Not applicable", "Not registered", "Period open", "Info", "N/A", "Voluntary eligible", "Not provided", "Low", "Ledger total not entered"):
        return "grey"
    return None


def fmt(x, dec=2):
    if x is None or x == "":
        return ""
    if isinstance(x, bool):
        return "Yes" if x else "No"
    if isinstance(x, (int, float)):
        v = round(x, dec)
        s = "{:,.{d}f}".format(abs(v), d=dec)
        return "(%s)" % s if v < 0 else s
    return str(x)


class Ctx(QObject):
    """Holds the database, the signed-in user and a cached calculation result."""
    changed = pyqtSignal()
    selection_changed = pyqtSignal(object)      # the client / tax period chosen on Returns and workings or the Filing Assistant (argument: who changed it)

    def __init__(self, db):
        super().__init__()
        self.db = db
        self._res = None
        self.sel = {"client": "", "VAT": ""}

    def set_selection(self, client=None, vat=None, source=None):
        """Remember the client and tax periods in use so Returns and workings and the FTA Filing Assistant always show the same ones."""
        ch = False
        if client and client != self.sel["client"]:
            self.sel.update(client=client, VAT=""); ch = True
        for k, v in (("VAT", vat),):
            if v and v != self.sel[k]:
                self.sel[k] = v; ch = True
        if ch:
            self.selection_changed.emit(source)

    def result(self):
        if self._res is None:
            self._res = self.db.compute()
        return self._res

    def refresh(self):
        self._res = None
        self.changed.emit()

    @property
    def firm(self):
        return self.db.setting("firm", "")

    def can_edit(self):
        return self.db.can_edit()

    def is_admin(self):
        return self.db.role() == "Admin"


def info(parent, title, text):
    QMessageBox.information(parent, title, text)


def warn(parent, title, text):
    QMessageBox.warning(parent, title, text)


def ask(parent, title, text) -> bool:
    return QMessageBox.question(parent, title, text, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes


def make_table(headers, editable=False, stretch_last=True):
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setAlternatingRowColors(True)
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(26)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    if not editable:
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.horizontalHeader().setStretchLastSection(stretch_last)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    return t


def item(v, num=False, status=False, bold=False, wrap=False):
    it = QTableWidgetItem(fmt(v) if num else ("" if v is None else str(v)))
    if num:
        it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    if status:
        tn = tone(v)
        if tn:
            it.setBackground(QBrush(QColor(COL[tn])))
    if bold:
        f = it.font(); f.setBold(True); it.setFont(f)
    return it


def fill_table(t, rows, num_cols=(), status_cols=(), widths=None, keep_widths=False):
    t.setSortingEnabled(False)
    t.setRowCount(len(rows))
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            t.setItem(i, j, item(v, num=j in num_cols, status=j in status_cols))
    if widths and not keep_widths:
        for j, w in enumerate(widths):
            t.setColumnWidth(j, w)


def card(title, value, sub="", color=None):
    f = QFrame(); f.setObjectName("card")
    lay = QVBoxLayout(f); lay.setContentsMargins(14, 10, 14, 10); lay.setSpacing(2)
    a = QLabel(title); a.setObjectName("muted")
    b = QLabel(value); b.setObjectName("kpi")
    if color:
        b.setStyleSheet("color:%s" % color)
    lay.addWidget(a); lay.addWidget(b)
    if sub:
        c = QLabel(sub); c.setObjectName("muted"); lay.addWidget(c)
    return f


def header(title, sub=""):
    w = QWidget()
    lay = QVBoxLayout(w); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
    a = QLabel(title); a.setObjectName("h1"); lay.addWidget(a)
    if sub:
        b = QLabel(sub); b.setObjectName("muted"); b.setWordWrap(True); lay.addWidget(b)
    return w


def hbox(*widgets, stretch_after=None):
    w = QWidget(); l = QHBoxLayout(w); l.setContentsMargins(0, 0, 0, 0)
    for x in widgets:
        if x == "stretch":
            l.addStretch(1)
        else:
            l.addWidget(x)
    return w


def page_layout(page, margins=(22, 18, 22, 14)):
    page.setObjectName("page")
    lay = QVBoxLayout(page)
    lay.setContentsMargins(*margins)
    lay.setSpacing(10)
    return lay


def entity_combo_items(ctx):
    return [("%s  %s" % (e["id"], e["name"]), e["id"]) for e in ctx.result()["entities"]]
