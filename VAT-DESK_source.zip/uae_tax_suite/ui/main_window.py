from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QMenu, QPushButton, QStackedWidget, QVBoxLayout, QWidget, QToolButton)

from ui.admin import AuditPage, RulesPage, UsersPage
from ui.clients import ClientsPage
from ui.common import Ctx
from ui.dashboard import DashboardPage
from ui.data import DataPage
from ui.login import PasswordDialog
from ui.penalties import PenaltiesPage
from ui.planner import PlannerPage
from ui.groups import GroupsPage
from ui.wizard import FirstRunWizard
from ui.exporter import ExportBar
from core import deadlines as DL
from ui.returns import ReturnsPage
from fta_assistant.widget import FilingAssistantPage


class MainWindow(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.ctx = Ctx(db)
        self.setWindowTitle("VAT-DESK")
        self.resize(1360, 820)
        root = QWidget(); self.setCentralWidget(root)
        h = QHBoxLayout(root); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)
        side = QFrame(); side.setObjectName("sidebar"); side.setFixedWidth(220)
        sl = QVBoxLayout(side); sl.setContentsMargins(0, 14, 0, 12); sl.setSpacing(0)
        t = QLabel("VAT-DESK"); t.setStyleSheet("font-size:14pt;font-weight:700;padding:6px 18px 2px 18px;"); sl.addWidget(t)
        self.firm_lbl = QLabel(self.ctx.firm or "")
        self.firm_lbl.setStyleSheet("color:#64748B;padding:0 18px 14px 18px;"); self.firm_lbl.setWordWrap(True); sl.addWidget(self.firm_lbl)
        self.stack = QStackedWidget()
        self.page_names = []
        self.buttons = []
        pages = [("Dashboard", DashboardPage), ("Clients", ClientsPage), ("Data", DataPage), ("Returns and workings", ReturnsPage),
                 ("FTA Filing Assistant", FilingAssistantPage), ("Tax groups", GroupsPage), ("Penalties", PenaltiesPage), ("Calendar and open items", PlannerPage), ("Rules and rates", RulesPage)]
        if self.ctx.is_admin():
            pages += [("Users", UsersPage), ("Audit and backup", AuditPage)]
        self.pages = []
        for name, cls in pages:
            p = cls(self.ctx); self.pages.append(p); self.stack.addWidget(p); self.page_names.append(name)
            b = QPushButton(name); b.setObjectName("nav"); b.setCheckable(True); b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _, i=len(self.buttons): self.go(i)); sl.addWidget(b); self.buttons.append(b)
        sl.addStretch(1)
        u = db.user
        self.who = QLabel("%s\n%s" % (u["display_name"], u["role"])); self.who.setStyleSheet("padding:6px 18px;color:#334155;"); sl.addWidget(self.who)
        acts = [("Change password", self.change_pw), ("Sign out", self.sign_out)]
        if self.ctx.is_admin():
            acts.insert(0, ("Setup guide", self.setup_guide))
        for txt, fn in acts:
            b = QPushButton(txt); b.setObjectName("nav"); b.clicked.connect(fn); sl.addWidget(b)
        self.exportbar = ExportBar(lambda: (self.pages[self.stack.currentIndex()], self.page_names[self.stack.currentIndex()]))
        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(0)
        rl.addWidget(self.exportbar); rl.addWidget(self.stack, 1)
        h.addWidget(side); h.addWidget(right, 1)
        self.signed_out = False
        self.go(0)
        if self.ctx.is_admin() and db.setting("setup_done", "") != "1" and not db.entities():
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(300, self.setup_guide)
        try:
            db.auto_backup()
        except Exception:
            pass                                     # a failed daily copy must never stop someone working
        try:
            tail = "   |   " + DL.status_line(self.ctx.result())
        except Exception:
            tail = ""
        self.statusBar().showMessage("Signed in as %s (%s)   |   Database: %s%s" % (u["username"], u["role"], db.path, tail))

    def go(self, i):
        for j, b in enumerate(self.buttons):
            b.setChecked(j == i)
        self.stack.setCurrentIndex(i)
        p = self.pages[i]
        if hasattr(p, "reload") and isinstance(p, (UsersPage, AuditPage)):
            p.reload()

    def setup_guide(self):
        if FirstRunWizard(self.db, self).exec():
            self.firm_lbl.setText(self.ctx.firm or "")
            self.ctx.refresh()

    def change_pw(self):
        PasswordDialog(self.db, self.db.user["username"], parent=self).exec()

    def sign_out(self):
        self.db.logout()
        self.signed_out = True
        self.close()
