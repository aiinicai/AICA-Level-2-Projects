from ui.dates import DateField
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTabWidget, QVBoxLayout, QWidget)

from core import returns as RT
from core.engine import D, Y, n
from ui.common import fmt, header, make_table, fill_table, page_layout


class Calc(QWidget):
    def __init__(self, ctx, kind="vat"):
        super().__init__()
        self.ctx, self.kind = ctx, kind
        lay = QVBoxLayout(self)
        form = QGroupBox("Inputs (prefilled from the client record: overwrite any to run a different case)")
        g = QGridLayout(form)
        self.f = {}
        def add(r, c, key, label, ph="DD-MM-YYYY"):
            g.addWidget(QLabel(label), r, c * 2)
            e = (QLineEdit() if key == "unpaid" else DateField()); e.setPlaceholderText(ph); e.textChanged.connect(self.calc); g.addWidget(e, r, c * 2 + 1); self.f[key] = e
        add(0, 0, "due", "Filing due date"); add(0, 1, "filed", "Date filed (blank = position date)")
        add(1, 0, "pay_due", "Payment due date"); add(1, 1, "paid", "Date paid (blank = position date)")
        add(2, 0, "unpaid", "Unpaid tax (AED)", "0"); add(2, 1, "req_by", "Registration required by")
        add(3, 0, "registered", "Date registered (blank = unregistered)")
        self.repeat = QCheckBox("Repeat late filing within 24 months"); self.rec = QCheckBox("Required records not kept"); self.rec_rep = QCheckBox("Records: repeat offence")
        for i, c in enumerate((self.repeat, self.rec, self.rec_rep)):
            c.stateChanged.connect(self.calc); g.addWidget(c, 4, i * 2, 1, 2)
        lay.addWidget(form)
        self.out = make_table(["Penalty", "Detail", "Estimate (AED)"])
        lay.addWidget(self.out)
        self.note = QLabel("Estimates only: the FTA assesses penalties, and waivers, instalments and changes to the penalty decisions can alter the outcome. Rates come from the Rules page.")
        self.note.setObjectName("muted"); self.note.setWordWrap(True); lay.addWidget(self.note)
        self.entry = None

    def prefill(self, e, v, R):
        self.entry = (e, v, R)
        for w in self.f.values():
            w.blockSignals(True)
        filed = e.get("vat_filed") == "Yes"
        reg = v["registered"] == "Yes"
        vals = dict(due="" if (filed or not reg) else v["due"], filed="", pay_due=v["due"] if reg else "",
                    unpaid=str(max(0, v["net_vat"])) if (reg and e.get("vat_paid") != "Yes") else "0", paid="", req_by="", registered="")
        for k, w in self.f.items():
            w.setText(vals.get(k, ""))
            w.blockSignals(False)
        self.repeat.setChecked(False); self.rec.setChecked(False); self.rec_rep.setChecked(False)
        self.calc()

    def calc(self, *_):
        if not self.entry:
            return
        e, v, R = self.entry
        today = self.ctx.result()["today"]
        t = {k: w.text().strip() for k, w in self.f.items()}
        for k in ("due", "filed", "pay_due", "paid", "req_by", "registered"):
            if t[k] and str(__import__("core.dataio", fromlist=["x"]).parse_date(t[k])).startswith("?"):
                self.f[k].setStyleSheet("border:1px solid #A61B1B"); return
            self.f[k].setStyleSheet("")
            t[k] = __import__("core.dataio", fromlist=["x"]).parse_date(t[k]) if t[k] else None
        unpaid = n(t["unpaid"].replace(",", "")) if t["unpaid"] else 0
        r = RT.vat_penalty(R, t["due"], t["filed"], self.repeat.isChecked(), t["pay_due"], unpaid, t["paid"], t["req_by"], t["registered"], self.rec.isChecked(), self.rec_rep.isChecked(), today)
        rows = [["Late filing", "%d days late" % r["days_late"], r["late_filing"]], ["Late payment", "%d monthly charges on %s" % (r["months"], fmt(unpaid)), r["late_payment"]]]
        rows += [["Late registration", "", r["late_registration"]], ["Failure to keep records", "", r["records"]],
                 ["Total estimated penalties", "", r["total"]], ["Unpaid tax plus penalties", "", r["with_tax"]]]
        fill_table(self.out, rows, num_cols=(2,), widths=(260, 420, 140))
        for i in (4, 5):
            for j in range(3):
                it = self.out.item(i, j); f = it.font(); f.setBold(True); it.setFont(f)


class PenaltiesPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Penalty calculators", "Late filing, late payment, late registration and record-keeping penalties for VAT."))
        bar = QHBoxLayout()
        bar.addWidget(QLabel("Client"))
        self.combo = QComboBox(); self.combo.setMinimumWidth(340); self.combo.currentIndexChanged.connect(self.pick)
        bar.addWidget(self.combo); bar.addStretch(1)
        rb = QPushButton("Reset from client record"); rb.clicked.connect(self.pick); bar.addWidget(rb)
        lay.addLayout(bar)
        self.tabs = QTabWidget()
        self.vat = Calc(ctx, "vat")
        self.tabs.addTab(self.vat, "VAT penalties")
        lay.addWidget(self.tabs)
        ctx.changed.connect(self.reload)
        self.reload()

    def reload(self):
        cur = self.combo.currentData()
        self.combo.blockSignals(True); self.combo.clear()
        for e in self.ctx.result()["entities"]:
            self.combo.addItem("%s  %s" % (e["id"], e["name"]), e["id"])
        i = self.combo.findData(cur)
        self.combo.setCurrentIndex(max(i, 0) if self.combo.count() else -1)
        self.combo.blockSignals(False)
        self.pick()

    def pick(self):
        r = self.ctx.result()
        i = next((k for k, e in enumerate(r["entities"]) if e["id"] == self.combo.currentData()), None)
        if i is None:
            return
        self.vat.prefill(r["entities"][i], r["vat"][i], r["R"])
