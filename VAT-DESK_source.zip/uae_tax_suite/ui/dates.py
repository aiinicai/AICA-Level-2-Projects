"""Date handling for the desktop app: DD-MM-YYYY on screen, ISO (YYYY-MM-DD) in the database.

DateField is a drop-in QLineEdit with a calendar button; text() returns ISO, the box shows DD-MM-YYYY.
install_display() converts ISO dates inside labels, table cells, combo items and message boxes to DD-MM-YYYY.
"""
from __future__ import annotations

import datetime as dt
import re

from PyQt6.QtCore import QDate, Qt, QPoint
from PyQt6.QtGui import QAction, QColor, QIcon, QPainter, QPixmap, QPen
from PyQt6.QtWidgets import (QAbstractButton, QCalendarWidget, QComboBox, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
                             QStyledItemDelegate, QTableWidgetItem, QTextEdit, QWidget, QVBoxLayout, QFrame)

from core import engine as E

ISO_RE = re.compile(r"(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)")


def to_dmy_text(s):
    """Replace every ISO date inside a string with DD-MM-YYYY (non-strings untouched)."""
    if isinstance(s, str) and "-" in s:
        return ISO_RE.sub(lambda m: "%s-%s-%s" % (m.group(3), m.group(2), m.group(1)), s)
    return s


def to_dmy(v):
    d = E.D(v) if v not in (None, "") else None
    return d.strftime("%d-%m-%Y") if d else ("" if v is None else str(v))


def to_iso(v):
    """Any accepted date text -> ISO; unparseable text is returned unchanged."""
    if v in (None, ""):
        return ""
    d = E.D(v)
    return d.isoformat() if d else str(v).strip()


def _icon():
    pm = QPixmap(16, 16); pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor("#1E3A8A"), 1.4)); p.setBrush(QColor("white"))
    p.drawRoundedRect(1, 3, 14, 12, 2, 2)
    p.setBrush(QColor("#F97316")); p.setPen(Qt.PenStyle.NoPen); p.drawRect(2, 4, 12, 3)
    p.setPen(QPen(QColor("#1E3A8A"), 1.6)); p.drawLine(4, 1, 4, 4); p.drawLine(12, 1, 12, 4)
    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("#1E3A8A"))
    for x in (4, 7, 10):
        for y in (9, 12):
            p.drawRect(x, y, 2, 2)
    p.end()
    return QIcon(pm)


class _Pop(QFrame):
    def __init__(self, field):
        super().__init__(field, Qt.WindowType.Popup)
        self.field = field
        lay = QVBoxLayout(self); lay.setContentsMargins(2, 2, 2, 2)
        self.cal = QCalendarWidget(); self.cal.setGridVisible(True)
        self.cal.setFirstDayOfWeek(Qt.DayOfWeek.Monday)
        self.cal.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader)
        self.cal.setMinimumDate(QDate(1990, 1, 1)); self.cal.setMaximumDate(QDate(2100, 12, 31))
        lay.addWidget(self.cal)
        self.cal.clicked.connect(self._pick)
        self.cal.activated.connect(self._pick)

    def _pick(self, qd):
        self.field.setDate(dt.date(qd.year(), qd.month(), qd.day()))
        self.close()


class DateField(QLineEdit):
    """Date entry box: shows DD-MM-YYYY, text() gives ISO, calendar button to choose day, month and year."""

    def __init__(self, value="", parent=None, placeholder="DD-MM-YYYY"):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setMaxLength(10)
        self.setMinimumWidth(130)
        self._act = QAction(_icon(), "Choose date", self)
        self._act.triggered.connect(self.open_calendar)
        self.addAction(self._act, QLineEdit.ActionPosition.TrailingPosition)
        self.editingFinished.connect(self._normalise)
        if value:
            self.setText(value)

    # --- values
    def setText(self, v):
        super().setText(to_dmy(v) if v else "")

    def text(self):
        t = super().text().strip()
        return to_iso(t) if t else ""

    def date(self):
        return E.D(super().text())

    def setDate(self, d):
        super().setText(d.strftime("%d-%m-%Y") if d else "")
        self.editingFinished.emit()

    def _normalise(self):
        t = super().text().strip()
        d = E.D(t) if t else None
        if d:
            super().setText(d.strftime("%d-%m-%Y"))

    def open_calendar(self):
        pop = _Pop(self)
        d = self.date() or dt.date.today()
        pop.cal.setSelectedDate(QDate(d.year, d.month, d.day))
        pop.move(self.mapToGlobal(QPoint(0, self.height())))
        pop.show()
        self._pop = pop


class DateDelegate(QStyledItemDelegate):
    """Calendar editor for date columns of a table; cells show and keep DD-MM-YYYY."""

    def createEditor(self, parent, option, index):
        return DateField(parent=parent)

    def setEditorData(self, editor, index):
        editor.setText(index.data() or "")

    def setModelData(self, editor, model, index):
        t = QLineEdit.text(editor).strip()
        d = E.D(t) if t else None
        model.setData(index, d.strftime("%d-%m-%Y") if d else t)


class NumDelegate(QStyledItemDelegate):
    """Amount columns: free typing, shown as 1,234.56 once entered."""

    def setModelData(self, editor, model, index):
        from core import dataio
        t = editor.text().strip()
        v = dataio.parse_num(t) if t else None
        model.setData(index, "{:,.2f}".format(v) if isinstance(v, (int, float)) else t)


# --------------------------------------------------------------- display conversion everywhere
_done = False


def install_display():
    """Make every label, table cell, combo item, button and message box show ISO dates as DD-MM-YYYY."""
    global _done
    if _done:
        return
    _done = True

    def wrap_init(cls):
        o = cls.__init__
        def init(self, *a, **k):
            a = [to_dmy_text(x) if isinstance(x, str) else x for x in a]
            o(self, *a, **k)
        cls.__init__ = init

    def wrap_set(cls, name, argpos=0):
        o = getattr(cls, name)
        def f(self, *a, **k):
            a = list(a)
            if len(a) > argpos and isinstance(a[argpos], str):
                a[argpos] = to_dmy_text(a[argpos])
            return o(self, *a, **k)
        setattr(cls, name, f)

    for c in (QLabel, QTableWidgetItem):
        wrap_init(c)
    wrap_set(QLabel, "setText"); wrap_set(QAbstractButton, "setText"); wrap_set(QTableWidgetItem, "setText")
    wrap_set(QMessageBox, "setText"); wrap_set(QMessageBox, "setInformativeText"); wrap_set(QMessageBox, "setDetailedText")
    wrap_set(QTextEdit, "setPlainText"); wrap_set(QTextEdit, "setHtml"); wrap_set(QTextEdit, "setText"); wrap_set(QTextEdit, "append")
    wrap_set(QPlainTextEdit, "setPlainText"); wrap_set(QPlainTextEdit, "appendPlainText")
    wrap_set(QComboBox, "addItem", 0); wrap_set(QComboBox, "setItemText", 1)
    o = QComboBox.addItems
    QComboBox.addItems = lambda self, items: o(self, [to_dmy_text(x) if isinstance(x, str) else x for x in items])
    oi = QComboBox.insertItem
    def ins(self, i, *a, **k):
        a = list(a)
        if a and isinstance(a[0], str):
            a[0] = to_dmy_text(a[0])
        return oi(self, i, *a, **k)
    QComboBox.insertItem = ins
