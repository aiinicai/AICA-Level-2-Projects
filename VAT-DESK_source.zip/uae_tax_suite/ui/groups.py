"""Tax groups: define VAT groups, see what was eliminated, and view the group VAT 201 in the FTA layout."""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea,
                             QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from core import groupexport
from core import vatgroup as VG
from ui.busy import busy
from ui.common import ask, fill_table, fmt, header, info, make_table, page_layout, warn
from ui.returns import ReturnsPage, scroll


class _Host:
    """Stands in for ReturnsPage so its FTA layout renderers can be reused as they are."""
    _paired = staticmethod(ReturnsPage._paired)


class GroupDialog(QDialog):
    def __init__(self, ctx, kind, g=None, parent=None):
        super().__init__(parent)
        self.ctx, self.kind = ctx, kind
        self.setWindowTitle("%s group" % kind); self.resize(560, 560)
        lay = QVBoxLayout(self); f = QFormLayout()
        self.gid = QLineEdit((g or {}).get("group_id", "")); self.gid.setEnabled(g is None)
        self.name = QLineEdit((g or {}).get("name", "")); self.trn = QLineEdit((g or {}).get("trn", ""))
        self.rep = QComboBox()
        f.addRow("Group ID", self.gid); f.addRow("Group name", self.name)
        f.addRow("Group TRN", self.trn)
        f.addRow("Representative member", self.rep)
        lay.addLayout(f)
        lay.addWidget(QLabel("Select two or more members."))
        self.t = QTableWidget(0, 2)
        self.t.setHorizontalHeaderLabels(["Member", "Client"])
        self.t.verticalHeader().setVisible(False)
        self.spins = {}
        have, own = set((g or {}).get("members", [])), (g or {}).get("ownership", {})
        for e in ctx.result()["entities"]:
            i = self.t.rowCount(); self.t.insertRow(i)
            a = QTableWidgetItem(e["id"]); a.setFlags(a.flags() | Qt.ItemFlag.ItemIsUserCheckable); a.setCheckState(Qt.CheckState.Checked if e["id"] in have else Qt.CheckState.Unchecked)
            self.t.setItem(i, 0, a); self.t.setItem(i, 1, QTableWidgetItem(e["name"])); self.t.item(i, 1).setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.rep.addItem(e["id"])
        self.t.setColumnWidth(0, 80); self.t.setColumnWidth(1, 300)
        lay.addWidget(self.t)
        self.rep.setCurrentText((g or {}).get("rep_member", ""))
        b = QPushButton("Save"); b.setObjectName("primary"); b.clicked.connect(self.go); lay.addWidget(b)

    def members(self):
        return [self.t.item(i, 0).text() for i in range(self.t.rowCount()) if self.t.item(i, 0).checkState() == Qt.CheckState.Checked]

    def go(self):
        ms = self.members()
        if len(ms) < 2:
            return warn(self, "Group", "Select at least two members.")
        try:
            self.ctx.db.vat_group_save(self.gid.text().strip(), self.name.text().strip(), self.trn.text().strip(), self.rep.currentText(), ms, self.kind)
        except Exception as ex:
            return warn(self, "Group", str(ex))
        self.accept()


class GroupBar(QWidget):
    """Group chooser with New, Edit and Delete."""

    def __init__(self, ctx, kind, on_change, extra=()):
        super().__init__()
        self.ctx, self.kind, self.on_change = ctx, kind, on_change
        l = QHBoxLayout(self); l.setContentsMargins(0, 0, 0, 0)
        self.combo = QComboBox(); self.combo.setMinimumWidth(300); self.combo.currentIndexChanged.connect(lambda *_: self.on_change())
        l.addWidget(QLabel("Group")); l.addWidget(self.combo)
        for txt, fn in (("New group", self.new), ("Edit group", self.edit), ("Delete group", self.delete)):
            b = QPushButton(txt); b.clicked.connect(fn); l.addWidget(b)
        for txt, fn in extra:
            b = QPushButton(txt); b.clicked.connect(fn); l.addWidget(b)
        l.addStretch(1)
        self.refresh(False)

    def groups(self):
        return self.ctx.db.vat_groups(self.kind)

    def cur(self):
        return next((g for g in self.groups() if g["group_id"] == self.combo.currentData()), None)

    def refresh(self, notify=True):
        cur = self.combo.currentData()
        self.combo.blockSignals(True); self.combo.clear()
        for g in self.groups():
            self.combo.addItem("%s  %s" % (g["group_id"], g["name"]), g["group_id"])
        i = self.combo.findData(cur); self.combo.setCurrentIndex(max(i, 0) if self.combo.count() else -1); self.combo.blockSignals(False)
        if notify:
            self.on_change()

    def new(self):
        if GroupDialog(self.ctx, self.kind, None, self).exec():
            self.refresh()

    def edit(self):
        g = self.cur()
        if g and GroupDialog(self.ctx, self.kind, g, self).exec():
            self.refresh()

    def delete(self):
        g = self.cur()
        if g and ask(self, "Delete group", "Delete group %s? The members' client records are kept." % g["group_id"]):
            try:
                self.ctx.db.vat_group_delete(g["group_id"])
            except Exception as ex:
                return warn(self, "Group", str(ex))
            self.refresh()


class VatGroupTab(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("A VAT group files one return under one TRN. Supplies between members are left out: a row is treated as internal when its counterparty TRN, or (if there is none) its name, is another member's."))
        self.bar = GroupBar(ctx, "VAT", self.build, [("Export to Excel", self.export)]); lay.addWidget(self.bar)
        self.sum = QLabel(""); self.sum.setWordWrap(True); lay.addWidget(self.sum)
        self.mem = make_table(["Member", "Name", "Net VAT on its own", "Status"]); self.mem.setMaximumHeight(120); lay.addWidget(self.mem)
        lay.addWidget(QLabel("Left out of the group return (supplies between members)"))
        self.el = make_table(["Member", "Other member", "Matched by", "Document", "Date", "Party", "Type", "Net", "VAT"]); self.el.setMaximumHeight(180); lay.addWidget(self.el)
        self.t = make_table(["Box", "Description", "Amount", "VAT", "Adjustment"]); lay.addWidget(self.t)
        self.res = None
        self.build()

    def result(self):
        g = self.bar.cur()
        return (g, VG.consolidate(self.ctx.db, g, self.ctx.db.setting("default_emirate", "Dubai"))) if g else (None, None)

    def build(self):
        self.res = None
        for t in (self.t, self.mem, self.el):
            t.setRowCount(0)
        try:
            g, r = self.result()
        except VG.GroupError as ex:
            self.sum.setText("<font color='#A61B1B'><b>Cannot build the group return.</b> %s</font>" % ex); return
        if not g:
            self.sum.setText("No VAT group yet. Click New group.")
            return
        self.res = r
        fill_table(self.mem, [[m["id"], m["name"], m["net_vat"], m["vat_status"]] for m in r["members"]], num_cols=(2,), status_cols=(3,), widths=(80, 300, 140, 120))
        fill_table(self.el, [[x["member"], x["counterparty"], x["how"], x["doc_no"], x["doc_date"], x["party"], x["doc_type"], x["net"], x["vat"]] for x in r["eliminations"]],
                   num_cols=(7, 8), widths=(60, 80, 80, 90, 90, 200, 160, 100, 90))
        fill_table(self.t, [[l["box"], l["desc"], l["amount"], l["vat"], l["adj"]] for l in r["lines"] if l["kind"] != "head"], num_cols=(2, 3, 4), widths=(50, 500, 120, 120, 120))
        self.sum.setText("Group net VAT <b>%s</b>; the members on their own add up to %s. %d row(s) between members (net %s) were left out.%s" % (
            fmt(r["net"]), fmt(r["sum_of_members"]), r["intra_excluded_rows"], fmt(r["intra_excluded_net"]), "".join("<br><font color='#B26A00'>%s</font>" % w for w in r["warnings"])))

    def export(self):
        if not self.res:
            return warn(self, "Export", "There is no group return to export.")
        p, _ = QFileDialog.getSaveFileName(self, "Export", "group_vat_return.xlsx", "Excel (*.xlsx)")
        if p:
            with busy(self, "Exporting the group return..."):
                groupexport.export(p, "VAT", self.bar.cur(), self.res, self.ctx.firm)
            self.ctx.db.audit("export.groupvat", self.bar.combo.currentData(), p)
            info(self, "Export", "Saved to " + p)


class FtaGroupTab(QWidget):
    """The group return in the FTA layout (the same layout as the individual tabs)."""

    def __init__(self, ctx, kind="VAT"):
        super().__init__()
        self.ctx, self.kind = ctx, kind
        lay = QVBoxLayout(self)
        self.bar = GroupBar(ctx, kind, self.build, [("Export to Excel", self.export)]); lay.addWidget(self.bar)
        self.msg = QLabel(""); self.msg.setWordWrap(True); lay.addWidget(self.msg)
        self.holder = QVBoxLayout(); lay.addLayout(self.holder, 1)
        self.res = None
        self.build()

    def build(self):
        while self.holder.count():
            it = self.holder.takeAt(0)
            wd = it.widget()
            if wd:
                wd.hide(); wd.setParent(None); wd.deleteLater()
        self.res = None
        g = self.bar.cur()
        if not g:
            self.msg.setText("Define a %s group first (the %s groups tab)." % (self.kind, self.kind)); return
        try:
            r = VG.consolidate(self.ctx.db, g, self.ctx.db.setting("default_emirate", "Dubai"))
        except VG.GroupError as ex:
            self.msg.setText("<font color='#A61B1B'><b>Cannot build the group return.</b> %s</font>" % ex); return
        self.res = r
        warns = list(r["warnings"])
        self.msg.setText("<b>%s</b> (%d members). Supplies between members are eliminated; see the %s groups tab for what was removed.%s" % (
            g["name"], len(g["members"]), self.kind, "".join("<br><font color='#B26A00'>%s</font>" % w for w in warns[:6])))
        w = ReturnsPage.fta_vat(_Host, dict(vat_fta=r["fta"]))
        self.holder.addWidget(scroll(w))

    def export(self):
        if not self.res:
            return warn(self, "Export", "There is no group return to export.")
        p, _ = QFileDialog.getSaveFileName(self, "Export", "group_%s_fta.xlsx" % self.kind.lower(), "Excel (*.xlsx)")
        if p:
            with busy(self, "Exporting the group return..."):
                groupexport.export(p, self.kind, self.bar.cur(), self.res, self.ctx.firm)
            self.ctx.db.audit("export.group" + self.kind.lower(), self.bar.combo.currentData(), p)
            info(self, "Export", "Saved to " + p)


class GroupsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(header("Tax groups", "Define VAT groups. Select two or more clients and the group return consolidates them and eliminates what passed between members."))
        self.tabs = QTabWidget(); lay.addWidget(self.tabs)
        self.vg = VatGroupTab(ctx)
        self.fv = FtaGroupTab(ctx, "VAT")
        self.tabs.addTab(self.vg, "VAT groups")
        self.tabs.addTab(self.fv, "Group VAT 201 (FTA)")
        self.tabs.currentChanged.connect(lambda i: [t.bar.refresh() for t in (self.vg, self.fv)][i])
        ctx.changed.connect(self.reload)

    def reload(self):
        for t in (self.vg, self.fv):
            t.bar.refresh()
