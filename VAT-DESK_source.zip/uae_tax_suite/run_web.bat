@echo off
rem Starts the web version for THIS computer and for the office network (other PCs, phones on the same Wi-Fi).
setlocal
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY ( echo Python 3.10 or newer is needed: https://www.python.org/downloads/ & pause & exit /b 1 )
if not exist .venv-web ( %PY% -m venv .venv-web && .venv-web\Scripts\python -m pip install -r requirements-web.txt )
echo.
echo Open  http://localhost:8080  on this computer.
echo Other computers and phones on the office network: http://THIS-PC-IP:8080  (find the IP with: ipconfig)
echo If Windows asks, allow Python through the firewall for Private networks.
echo Leave this window open while people are using the system. Close it to stop.
echo.
.venv-web\Scripts\python run_web.py --host 0.0.0.0 --port 8080
pause
