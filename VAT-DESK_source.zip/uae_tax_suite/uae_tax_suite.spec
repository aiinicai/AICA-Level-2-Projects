# PyInstaller spec: run on Windows with:  pyinstaller --noconfirm uae_tax_suite.spec
block_cipher = None
a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=[],
    datas=[('data', 'data')],
    hiddenimports=["arabic_reshaper","bidi",'openpyxl', 'reportlab.pdfbase._fontdata', 'sqlite3'],
    excludes=['tkinter', 'matplotlib', 'numpy', 'pandas'],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name='VAT-DESK',
    console=False,
    disable_windowed_traceback=False,
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='VAT-DESK')
