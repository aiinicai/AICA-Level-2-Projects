"""Synthetic general-ledger generator with deliberately injected audit anomalies.

Produces a reproducible 12-month (FY 2025-26, April-March) INR ledger of 50,000+ journal entries
for a fictional company, plus a separate ground-truth file listing which entries carry which
injected anomaly (the hidden ``_injected_label`` column) so detectors can be tested.

Run:  python data/generate_sample_data.py [--rows 52000] [--seed 42]
"""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src.config import DEFAULT_HOLIDAYS, SAMPLE_CSV, SAMPLE_TRUTH_CSV  # noqa: E402

FY_START, FY_END = "2025-04-01", "2026-03-31"
THRESHOLD = 1_000_000.0


@dataclass(frozen=True)
class Account:
    code: str
    name: str
    median: float
    sigma: float
    weight: float


REGULAR_ACCOUNTS = [
    Account("4001", "Sales - Domestic", 120_000, 1.5, 9), Account("4002", "Sales - Export", 260_000, 1.5, 4),
    Account("4010", "Service Income", 60_000, 1.5, 3), Account("4020", "Other Income", 15_000, 1.6, 1.5),
    Account("5001", "Raw Material Consumed", 90_000, 1.5, 8), Account("5002", "Packing Material", 18_000, 1.5, 3),
    Account("5003", "Freight Inward", 22_000, 1.5, 3), Account("5004", "Direct Labour", 45_000, 1.5, 3),
    Account("5005", "Power & Fuel", 70_000, 1.5, 2.5),
    Account("6001", "Salaries & Wages", 150_000, 1.5, 3), Account("6002", "Rent", 85_000, 1.5, 1.5),
    Account("6003", "Repairs & Maintenance", 14_000, 1.6, 3), Account("6004", "Travel & Conveyance", 6_000, 1.6, 4),
    Account("6005", "Professional Fees", 35_000, 1.6, 2), Account("6006", "Office Expenses", 3_500, 1.6, 4),
    Account("6007", "Advertising", 40_000, 1.6, 1.5), Account("6008", "Insurance", 55_000, 1.5, 1),
    Account("6009", "Telephone & Internet", 5_000, 1.6, 2), Account("6010", "Bank Charges", 1_800, 1.6, 3),
    Account("6011", "Commission", 28_000, 1.6, 1.5), Account("6012", "Printing & Stationery", 2_500, 1.6, 2),
    Account("6013", "Training & Development", 20_000, 1.6, 1),
    Account("1001", "Cash at Bank", 200_000, 1.5, 6), Account("1002", "Trade Receivables", 150_000, 1.5, 6),
    Account("1003", "Inventory", 110_000, 1.5, 4), Account("1004", "Prepaid Expenses", 25_000, 1.6, 1.5),
    Account("1005", "Fixed Assets - Plant", 300_000, 1.5, 1.2), Account("1006", "Advances to Suppliers", 60_000, 1.5, 2),
    Account("2001", "Trade Payables", 130_000, 1.5, 6), Account("2002", "GST Payable", 40_000, 1.5, 3),
    Account("2003", "TDS Payable", 12_000, 1.6, 2), Account("2004", "Accrued Expenses", 30_000, 1.6, 2),
    Account("2005", "Provisions", 50_000, 1.6, 1),
]
DORMANT_ACCOUNTS = [
    Account("7101", "Legal Settlement Provision", 80_000, 1.0, 1), Account("7102", "Intercompany Suspense", 150_000, 1.0, 1),
    Account("7103", "Director Loan Account", 200_000, 1.0, 1), Account("7104", "Donations", 25_000, 1.0, 1),
    Account("7105", "Forex Revaluation", 60_000, 1.0, 1), Account("7106", "Write-off Reserve", 40_000, 1.0, 1),
]
STAFF = ["Aarav Mehta", "Priya Nair", "Rohan Iyer", "Sneha Kulkarni", "Vikram Singh", "Ananya Rao",
         "Karthik Subramanian", "Meera Joshi", "Arjun Reddy", "Divya Menon", "Rahul Verma",
         "Kavya Pillai", "Siddharth Jain", "Neha Gupta", "Amit Desai", "Pooja Shah",
         "Manish Agarwal", "Ritu Kapoor", "Sanjay Patil", "Lakshmi Narayan"]
MANAGERS = ["R. Krishnan (FC)", "S. Banerjee (Controller)", "M. D'Souza (AGM Finance)", "T. Ahmed (Sr Manager)"]
TEMP_USERS = ["TEMP_CONSULTANT_01", "TEMP_CONSULTANT_02", "TEMP_CONSULTANT_03"]
COST_CENTERS = ["CC100-Admin", "CC200-Production", "CC300-Sales", "CC400-Finance", "CC500-HR"]
AUTO_SOURCES = ["SAP-FI", "Payroll", "Inventory", "AP-Module", "AR-Module"]


def _time_str(seconds: np.ndarray) -> np.ndarray:
    s = np.asarray(seconds, dtype=int) % 86_400
    return np.char.add(np.char.add(np.char.zfill((s // 3600).astype(str), 2) + ":",
                                   np.char.zfill(((s % 3600) // 60).astype(str), 2) + ":"),
                       np.char.zfill((s % 60).astype(str), 2))


def _make_block(rng, accts: list[Account], n: int, manual_dates, auto_dates, manual_share=0.45):
    w = np.array([a.weight for a in accts], dtype=float)
    ai = rng.choice(len(accts), size=n, p=w / w.sum())
    mu = np.log(np.array([a.median for a in accts]))[ai]
    sigma = np.array([a.sigma for a in accts])[ai]
    amount = np.clip(np.round(np.exp(rng.normal(mu, sigma)), 2), 10, 5e8)
    near_limit = (amount >= 0.95 * THRESHOLD) & (amount < THRESHOLD)   # normal staff don't hug the limit
    amount = np.where(near_limit, np.round(amount * 0.8, 2), amount)

    etype = rng.choice(["Automated", "Manual", "Adjusting", "Reversal"], size=n,
                       p=[1 - manual_share, manual_share * 0.73, manual_share * 0.16, manual_share * 0.11])
    manual = etype != "Automated"
    posting = np.where(manual, rng.choice(manual_dates, size=n), rng.choice(auto_dates, size=n))
    staff_w = 1 / np.arange(1, len(STAFF) + 1) ** 0.6
    poster = np.where(manual, rng.choice(STAFF, size=n, p=staff_w / staff_w.sum()), "SYS_BATCH")
    approver = np.where(manual, rng.choice(MANAGERS, size=n), "SYSTEM")
    override = np.where(manual & (rng.random(n) < 0.025), "Y", "N")
    seconds = np.where(manual, rng.integers(9 * 3600, 18 * 3600 + 1800, n),
                       np.where(rng.random(n) < 0.7, rng.integers(1800, 3 * 3600 + 1800, n),
                                rng.integers(9 * 3600, 17 * 3600, n)))
    names = np.array([a.name for a in accts])[ai]
    desc = np.char.add(np.char.add(names.astype(str), " - ref "), rng.integers(100_000, 999_999, n).astype(str))
    return pd.DataFrame({
        "posting_date": pd.to_datetime(posting),
        "account_code": np.array([a.code for a in accts])[ai],
        "account_name": names,
        "cost_center": rng.choice(COST_CENTERS, size=n),
        "description": desc,
        "amount": amount,
        "entry_type": etype,
        "posted_by": poster,
        "approved_by": approver,
        "posting_seconds": seconds,
        "source_system": np.where(manual, "Manual JV", rng.choice(AUTO_SOURCES, size=n)),
        "is_manual_override": override,
        "_lag": rng.choice([0, 1, 2, 3, 4, 5], size=n, p=[.55, .2, .1, .08, .04, .03]),
        "_imb": 0.0,
        "_label": "",
    })


def _outlier_amounts(rng, mu_sig: np.ndarray, k_low: float = 3.9, k_high: float = 4.7) -> np.ndarray:
    """exp(mu + k*sigma) outliers, kept below Rs 5 crore with random jitter (no identical capped values)."""
    raw = np.exp(mu_sig[:, 0] + rng.uniform(k_low, k_high, len(mu_sig)) * mu_sig[:, 1])
    capped = np.where(raw > 5e7, rng.uniform(1.5e7, 5e7, len(raw)), raw)
    return np.round(capped + rng.uniform(0.01, 0.99, len(raw)), 2)


def generate_sample(n_rows: int = 52_000, seed: int = 42) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (ledger, ground_truth). Ground truth has columns entry_id, _injected_label."""
    rng = np.random.default_rng(seed)
    days = pd.date_range(FY_START, FY_END)
    holidays = pd.DatetimeIndex(pd.to_datetime(DEFAULT_HOLIDAYS))
    is_off = (days.dayofweek >= 5) | days.isin(holidays)
    business, off_days = days[~is_off], days[is_off]
    days_to_end = (days + pd.offsets.MonthEnd(0) - days).days
    manual_dates = days[(~is_off) & (days_to_end >= 2)]       # normal manual JVs avoid month-end
    period_end_dates = days[(~is_off) & (days_to_end < 2)]
    auto_w = np.where(is_off, 0.3, 1.0)
    auto_dates = rng.choice(days, size=20_000, p=auto_w / auto_w.sum())   # empirical pool

    n_dormant_early, n_extra = 6 * 12, 90 + 70           # dormant history rows + duplicate copies
    base = _make_block(rng, REGULAR_ACCOUNTS, n_rows - n_dormant_early - n_extra, manual_dates, auto_dates)

    early = days[(~is_off) & (days <= pd.Timestamp("2025-06-15"))]
    dorm_rows = []
    for acct in DORMANT_ACCOUNTS:
        blk = _make_block(rng, [acct], 12, early, early[:30])
        dorm_rows.append(blk)
    df = pd.concat([base, *dorm_rows], ignore_index=True)
    used = np.zeros(len(df), dtype=bool)

    def pick(k: int, extra: np.ndarray | None = None) -> np.ndarray:
        ok = ~used if extra is None else (~used & extra)
        idx = rng.choice(np.flatnonzero(ok), size=k, replace=False)
        used[idx] = True
        return idx

    def label(idx: np.ndarray, *names: str) -> None:
        cur = df["_label"].to_numpy()[idx]
        add = "|".join(names)
        df.loc[df.index[idx], "_label"] = np.where(cur == "", add, np.char.add(cur.astype(str), "|" + add))

    manual_mask = (df["entry_type"] != "Automated").to_numpy()
    regular = ~df["account_code"].isin([a.code for a in DORMANT_ACCOUNTS]).to_numpy()

    def office_seconds(k: int) -> np.ndarray:
        return rng.integers(9 * 3600, 18 * 3600, k)

    # 1. Benford violations: two mid-sized accounts get ~45% of entries re-written to lead with digit 9
    for code in ("6007", "6011"):
        rows = np.flatnonzero((df["account_code"] == code).to_numpy() & ~used)
        idx = rng.choice(rows, size=int(len(rows) * 0.45), replace=False)
        used[idx] = True
        amt = df["amount"].to_numpy()[idx]
        df.loc[df.index[idx], "amount"] = np.round((9 + rng.random(len(idx))) * 10 ** np.floor(np.log10(amt)), 2)
        label(idx, "benford")

    # 2. Weekend / public-holiday manual postings
    idx = pick(140, manual_mask & regular)
    df.loc[df.index[idx], "posting_date"] = pd.to_datetime(rng.choice(off_days, size=len(idx)))
    df.loc[df.index[idx], "posting_seconds"] = office_seconds(len(idx))
    label(idx, "weekend_holiday")

    # 3. After-hours manual postings (22:00-04:59)
    idx = pick(110, manual_mask & regular)
    df.loc[df.index[idx], "posting_seconds"] = rng.choice([22, 23, 0, 1, 2, 3, 4], size=len(idx)) * 3600 + rng.integers(0, 3600, len(idx))
    label(idx, "after_hours")

    # 4. Segregation-of-duties: overrides with no approver / self-approval
    idx = pick(100, manual_mask & regular)
    half = len(idx) // 2
    df.loc[df.index[idx], "is_manual_override"] = "Y"
    df.loc[df.index[idx[:half]], "approved_by"] = ""
    df.loc[df.index[idx[half:]], "approved_by"] = df["posted_by"].to_numpy()[idx[half:]]
    label(idx, "sod_override")

    # 5. Just below the Rs 10 lakh approval limit
    idx = pick(90, regular)
    df.loc[df.index[idx], "amount"] = np.round(rng.uniform(0.955, 0.9995, len(idx)) * THRESHOLD, 2)
    label(idx, "below_threshold")

    # 6. Round-figure amounts
    idx = pick(90, regular)
    df.loc[df.index[idx], "amount"] = rng.choice([1, 2, 3, 5, 7, 10, 15, 25, 50], size=len(idx)) * 100_000.0
    label(idx, "round_number")

    # 7. Extreme statistical outliers vs the account's own history (z of roughly 3.9-4.7, capped at Rs 10 crore)
    sig = {a.code: (np.log(a.median), a.sigma) for a in REGULAR_ACCOUNTS}
    idx = pick(80, regular)
    mu_sig = np.array([sig[c] for c in df["account_code"].to_numpy()[idx]])
    df.loc[df.index[idx], "amount"] = _outlier_amounts(rng, mu_sig)
    label(idx, "variance")

    # 8. Period-end manual journals (last 2 days of a month / quarter / year, material amounts)
    idx = pick(100, manual_mask & regular)
    df.loc[df.index[idx], "posting_date"] = pd.to_datetime(rng.choice(period_end_dates, size=len(idx)))
    df.loc[df.index[idx], "posting_seconds"] = office_seconds(len(idx))
    df.loc[df.index[idx], "amount"] = np.round(rng.uniform(5.5e5, 4.5e6, len(idx)), 2)
    label(idx, "period_end")

    # 9. Back-dated (45-200 days) and future-dated (5-30 days) postings
    idx = pick(80, regular)
    df.loc[df.index[idx], "_lag"] = rng.integers(45, 200, len(idx))
    label(idx, "backdated")
    idx = pick(20, regular)
    df.loc[df.index[idx], "_lag"] = -rng.integers(5, 30, len(idx))
    label(idx, "backdated")

    # 10. Unbalanced entries
    idx = pick(40, regular)
    df.loc[df.index[idx], "_imb"] = np.round(rng.uniform(500, 50_000, len(idx)), 2)
    label(idx, "imbalance")

    # 11. Dormant accounts reactivated after ~6 months of silence
    for acct in DORMANT_ACCOUNTS:
        rows = np.flatnonzero((df["account_code"] == acct.code).to_numpy() & ~used)
        idx = rng.choice(rows, size=1)
        used[idx] = True
        df.loc[df.index[idx], "posting_date"] = pd.Timestamp("2025-12-22") + pd.Timedelta(days=int(rng.integers(0, 25)))
        df.loc[df.index[idx], "posting_date"] = df.loc[df.index[idx], "posting_date"].dt.normalize()
        df.loc[df.index[idx], ["entry_type", "approved_by"]] = ["Manual", rng.choice(MANAGERS)]
        df.loc[df.index[idx], "posted_by"] = rng.choice(STAFF)
        df.loc[df.index[idx], "posting_seconds"] = office_seconds(1)
        label(idx, "dormant_rare")

    # 12. Rarely-seen users (temporary consultants) posting manual journals
    idx = pick(8, manual_mask & regular)
    df.loc[df.index[idx], "posted_by"] = np.resize(TEMP_USERS, len(idx)) if len(idx) else []
    label(idx, "dormant_rare")

    # 13. Multi-risk "kitchen sink" entries that should rank Extreme
    idx = pick(30, manual_mask & regular)             # A: override, no approver, weekend, night, below limit
    df.loc[df.index[idx], "is_manual_override"] = "Y"
    df.loc[df.index[idx], "approved_by"] = ""
    df.loc[df.index[idx], "posting_date"] = pd.to_datetime(rng.choice(off_days, size=len(idx)))
    df.loc[df.index[idx], "posting_seconds"] = rng.choice([22, 23, 0, 1, 2, 3], size=len(idx)) * 3600 + rng.integers(0, 3600, len(idx))
    df.loc[df.index[idx], "amount"] = np.round(rng.uniform(0.96, 0.999, len(idx)) * THRESHOLD, 2)
    label(idx, "multi_risk", "sod_override", "weekend_holiday", "after_hours", "below_threshold")
    idx = pick(20, manual_mask & regular)             # B: unbalanced + back-dated + outlier amount
    mu_sig = np.array([sig[c] for c in df["account_code"].to_numpy()[idx]])
    df.loc[df.index[idx], "amount"] = _outlier_amounts(rng, mu_sig)
    df.loc[df.index[idx], "_imb"] = np.round(rng.uniform(5_000, 90_000, len(idx)), 2)
    df.loc[df.index[idx], "_lag"] = rng.integers(40, 120, len(idx))
    label(idx, "multi_risk", "variance", "imbalance", "backdated")
    idx = pick(15, manual_mask & regular)             # C: self-approved outlier, back-dated
    mu_sig = np.array([sig[c] for c in df["account_code"].to_numpy()[idx]])
    df.loc[df.index[idx], "amount"] = _outlier_amounts(rng, mu_sig)
    df.loc[df.index[idx], "is_manual_override"] = "Y"
    df.loc[df.index[idx], "approved_by"] = df["posted_by"].to_numpy()[idx]
    df.loc[df.index[idx], "_lag"] = rng.integers(40, 150, len(idx))
    label(idx, "multi_risk", "variance", "sod_override", "backdated")

    idx = pick(25, manual_mask & regular)             # D: no approver, night posting, round amount -> High
    df.loc[df.index[idx], "is_manual_override"] = "Y"
    df.loc[df.index[idx], "approved_by"] = ""
    df.loc[df.index[idx], "posting_seconds"] = rng.choice([22, 23, 0, 1, 2], size=len(idx)) * 3600 + rng.integers(0, 3600, len(idx))
    df.loc[df.index[idx], "amount"] = rng.choice([2, 3, 5, 8, 12], size=len(idx)) * 100_000.0
    label(idx, "multi_risk", "sod_override", "after_hours", "round_number")
    idx = pick(20, manual_mask & regular)             # E: back-dated outlier journal at month-end -> High
    mu_sig = np.array([sig[c] for c in df["account_code"].to_numpy()[idx]])
    df.loc[df.index[idx], "amount"] = _outlier_amounts(rng, mu_sig)
    df.loc[df.index[idx], "posting_date"] = pd.to_datetime(rng.choice(period_end_dates, size=len(idx)))
    df.loc[df.index[idx], "_lag"] = rng.integers(40, 120, len(idx))
    label(idx, "multi_risk", "variance", "backdated", "period_end")

    # 14. Duplicates: copy 70 existing entries under new IDs (flags both original and copy)
    src = pick(70, regular)
    copies = df.iloc[src].copy()
    copies["posting_seconds"] = (copies["posting_seconds"] + rng.integers(600, 7200, len(copies))) % 86_400
    copies["_label"] = ""
    df = pd.concat([df, copies], ignore_index=True)
    used = np.concatenate([used, np.ones(len(copies), dtype=bool)])
    label(src, "duplicate")
    label(np.arange(len(df) - len(copies), len(df)), "duplicate")

    # finalise
    df["document_date"] = df["posting_date"] - pd.to_timedelta(df["_lag"], unit="D")
    df["debit"] = df["amount"]
    df["credit"] = np.round(df["amount"] - df["_imb"], 2)
    df["currency"] = "INR"
    df["period"] = df["posting_date"].dt.strftime("%Y-%m")
    df["posting_time"] = _time_str(df["posting_seconds"].to_numpy())
    df = df.sort_values(["posting_date", "posting_time"], kind="mergesort").reset_index(drop=True)
    df["entry_id"] = [f"JE-{i:06d}" for i in range(1, len(df) + 1)]
    truth = df.loc[df["_label"] != "", ["entry_id", "_label"]].rename(columns={"_label": "_injected_label"})

    cols = ["entry_id", "posting_date", "document_date", "account_code", "account_name", "cost_center",
            "description", "debit", "credit", "amount", "currency", "entry_type", "posted_by",
            "approved_by", "posting_time", "source_system", "period", "is_manual_override"]
    ledger = df[cols].copy()
    for c in ("posting_date", "document_date"):
        ledger[c] = ledger[c].dt.strftime("%Y-%m-%d")
    return ledger, truth.reset_index(drop=True)


def write_excel_sample(ledger: pd.DataFrame, path: Path, rows: int = 5_000) -> None:
    """Small .xlsx sample with real Excel dates / numbers (for testing Excel upload)."""
    from openpyxl import Workbook
    sample = ledger.head(rows)
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("GL Export")
    ws.append(list(sample.columns))
    for r in sample.itertuples(index=False):
        row = list(r)
        row[1] = pd.Timestamp(row[1]).to_pydatetime()
        row[2] = pd.Timestamp(row[2]).to_pydatetime()
        ws.append(row)
    wb.save(path)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rows", type=int, default=52_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", type=Path, default=SAMPLE_CSV)
    args = parser.parse_args()
    ledger, truth = generate_sample(args.rows, args.seed)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    ledger.to_csv(args.out, index=False, float_format="%.2f")
    truth.to_csv(SAMPLE_TRUTH_CSV if args.out == SAMPLE_CSV else args.out.with_name(args.out.stem + "_ground_truth.csv"),
                 index=False)
    if args.out == SAMPLE_CSV:
        write_excel_sample(ledger, SAMPLE_CSV.with_name("sample_ledger_5k.xlsx"))
    size_mb = args.out.stat().st_size / 1e6
    print(f"Wrote {len(ledger):,} rows ({size_mb:.1f} MB) to {args.out}")
    print(f"Injected anomalies on {len(truth):,} entries; ground truth in {SAMPLE_TRUTH_CSV.name}")


if __name__ == "__main__":
    main()

