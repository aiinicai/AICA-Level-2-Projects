"""Rule-based and statistical anomaly detectors.

Every detector has the signature ``fn(df, cfg) -> (flag, reason)`` where ``flag`` is a boolean
Series and ``reason`` a string Series (empty where not flagged). All logic is vectorised with
Pandas / NumPy; the only per-element Python work is formatting reasons for *flagged* rows.
"""
from __future__ import annotations

import logging
from typing import Callable

import numpy as np
import pandas as pd
from scipy import stats

from .config import DETECTOR_LABELS, DetectorConfig
from .utils import fmt_inr

logger = logging.getLogger(__name__)

DetectorResult = tuple[pd.Series, pd.Series]
DetectorFn = Callable[[pd.DataFrame, DetectorConfig], DetectorResult]

BENFORD_EXPECTED = np.log10(1 + 1 / np.arange(1, 10))   # P(first digit = d), d = 1..9


# --------------------------------------------------------------------------- helpers
def _empty(df: pd.DataFrame) -> DetectorResult:
    return pd.Series(False, index=df.index), pd.Series("", index=df.index, dtype="object")


def _reasons(df: pd.DataFrame, mask: pd.Series, text: pd.Series | str) -> pd.Series:
    """Build a reason column: ``text`` where ``mask`` is True, else ''."""
    out = pd.Series("", index=df.index, dtype="object")
    if mask.any():
        out.loc[mask] = text.loc[mask] if isinstance(text, pd.Series) else text
    return out


def _inr(series: pd.Series) -> pd.Series:
    return series.map(fmt_inr)


def first_digit(values: pd.Series) -> pd.Series:
    """Leading significant digit (1-9) of positive numbers; NaN for values < 1 or non-finite."""
    v = values.where(values >= 1)
    exponent = np.floor(np.log10(v))
    return np.floor(v / np.power(10.0, exponent)).clip(1, 9)


def benford_table(amounts: pd.Series) -> pd.DataFrame:
    """Observed vs expected first-digit frequencies for a set of amounts."""
    digits = first_digit(amounts).dropna().astype(int)
    n = len(digits)
    observed = digits.value_counts().reindex(range(1, 10), fill_value=0).sort_index()
    out = pd.DataFrame({
        "digit": range(1, 10),
        "observed_count": observed.values,
        "observed_pct": observed.values / n if n else np.zeros(9),
        "expected_pct": BENFORD_EXPECTED,
    })
    out["deviation"] = out["observed_pct"] - out["expected_pct"]
    return out


def benford_stats(amounts: pd.Series) -> dict[str, float]:
    """MAD and chi-square p-value of a sample against Benford's first-digit law."""
    table = benford_table(amounts)
    n = int(table["observed_count"].sum())
    if n == 0:
        return {"n": 0, "mad": float("nan"), "chi2": float("nan"), "p_value": float("nan")}
    mad = float(table["deviation"].abs().mean())
    expected_counts = table["expected_pct"] * n
    chi2 = float(((table["observed_count"] - expected_counts) ** 2 / expected_counts).sum())
    return {"n": n, "mad": mad, "chi2": chi2, "p_value": float(stats.chi2.sf(chi2, df=8))}


# --------------------------------------------------------------------------- detectors
def detect_weekend_holiday(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Manual / override postings on Saturday, Sunday or a public holiday."""
    holidays = pd.DatetimeIndex(pd.to_datetime(list(cfg.holidays)))
    dates = df["posting_date"].dt.normalize()
    weekend = dates.dt.dayofweek >= 5
    holiday = dates.isin(holidays)
    flag = df["is_manual_like"] & (weekend | holiday)
    text = np.where(holiday, "Manual posting on a public holiday (",
                    "Manual posting on a weekend (")
    text = pd.Series(text, index=df.index) + df["posting_date"].dt.day_name() + ")"
    return flag, _reasons(df, flag, text)


def detect_after_hours(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Manual / override postings inside the night window (default 22:00-05:00)."""
    hour = df["posting_hour"]
    if cfg.after_hours_start > cfg.after_hours_end:       # window wraps past midnight
        night = (hour >= cfg.after_hours_start) | (hour < cfg.after_hours_end)
    else:
        night = (hour >= cfg.after_hours_start) & (hour < cfg.after_hours_end)
    flag = df["is_manual_like"] & night
    text = "Manual posting at " + df["posting_time"].astype(str).str.slice(0, 5) + " (after hours)"
    return flag, _reasons(df, flag, text)


def detect_sod_override(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Segregation-of-duties breach: manual / override entry with no approver or self-approval."""
    approver = df["approved_by"].astype(str).str.strip()
    poster = df["posted_by"].astype(str).str.strip()
    no_approver = approver.str.lower().isin(["", "nan", "none", "null", "na", "n/a"])
    self_approved = (~no_approver) & (approver.str.lower() == poster.str.lower())
    flag = df["is_manual_like"] & (no_approver | self_approved)
    override = np.where(df["is_manual_override"] == "Y", "System override", "Manual entry")
    text = pd.Series(override, index=df.index) + np.where(
        no_approver, " with no approver", " self-approved by the poster")
    return flag, _reasons(df, flag, text)


def detect_below_threshold(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Amounts just under the approval limit (possible structuring to avoid review)."""
    lower = cfg.threshold_amount * (1 - cfg.threshold_band_pct / 100.0)
    flag = (df["amount"] >= lower) & (df["amount"] < cfg.threshold_amount)
    text = ("Amount " + _inr(df["amount"]) + " is just below the " + fmt_inr(cfg.threshold_amount, 0)
            + " approval limit")
    return flag, _reasons(df, flag, text)


def detect_round_number(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Large amounts that are exact multiples of the round unit (default Rs 1 lakh)."""
    amt = df["amount"].round(2)
    flag = (amt >= cfg.round_min_amount) & (np.mod(amt, cfg.round_unit) == 0)
    return flag, _reasons(df, flag, "Round-figure amount " + _inr(df["amount"]))


def detect_duplicates(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Same account, amount, posting date and description booked under different entry IDs."""
    keys = ["account_code", "amount", "posting_date", "description"]
    grp = df.groupby(keys, sort=False)
    size = grp["entry_id"].transform("size")
    distinct = grp["entry_id"].transform("nunique")
    flag = (size > 1) & (distinct > 1) & (df["amount"] > 0)
    text = "Duplicate of " + (distinct - 1).astype(str) + " other entry(ies): same account, amount, date and description"
    return flag, _reasons(df, flag, text)


def detect_benford(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Accounts whose leading-digit profile fails Benford's law (MAD + chi-square).

    Within a failing account only the entries carrying the most over-represented leading digit
    are flagged, which keeps the exception list focused on the suspected manipulated entries.
    """
    flag, reason = _empty(df)
    digit = first_digit(df["amount"])
    for account, idx in df.groupby("account_code", sort=False).groups.items():
        d = digit.loc[idx].dropna()
        if len(d) < cfg.benford_min_entries:
            continue
        st = benford_stats(df.loc[idx, "amount"])
        if not (st["mad"] > cfg.benford_mad_cutoff and st["p_value"] < cfg.benford_alpha):
            continue
        table = benford_table(df.loc[idx, "amount"])
        worst = int(table.loc[table["deviation"].idxmax(), "digit"])
        hit = d.index[d == worst]
        flag.loc[hit] = True
        reason.loc[hit] = (f"Account {account} fails Benford's law (MAD {st['mad']:.3f}, "
                           f"chi-sq p={st['p_value']:.1e}); leading digit {worst} over-represented")
    return flag, reason


def detect_variance(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Per-account z-score + IQR outliers, plus month-on-month spikes vs a 3-month rolling mean."""
    flag, reason = _empty(df)
    amount = df["amount"].where(df["amount"] > 0)
    series = np.log10(amount) if cfg.use_log_amounts else amount
    grp = series.groupby(df["account_code"])
    count = grp.transform("count")
    mean, std = grp.transform("mean"), grp.transform("std")
    q1, q3 = grp.transform(lambda s: s.quantile(0.25)), grp.transform(lambda s: s.quantile(0.75))
    z = (series - mean) / std.replace(0, np.nan)
    fence = q3 + cfg.iqr_multiplier * (q3 - q1)
    enough = count >= cfg.min_account_entries
    z_hit = enough & (z > cfg.zscore_cutoff)
    iqr_hit = enough & (series > fence) & ((q3 - q1) > 0)
    stat_hit = z_hit | iqr_hit
    tests = np.where(z_hit & iqr_hit, "z-score and IQR", np.where(z_hit, "z-score", "IQR fence"))
    text = ("Amount " + _inr(df["amount"]) + " is an outlier for account " + df["account_code"]
            + " (" + pd.Series(tests, index=df.index) + ", z=" + z.round(1).astype(str) + ")")
    flag |= stat_hit
    reason.loc[stat_hit] = text.loc[stat_hit]

    # month-on-month variance: account-month total vs mean of previous three account-months
    monthly = (df.groupby(["account_code", "period"])["amount"].sum().rename("total").reset_index()
               .sort_values(["account_code", "period"]))
    prior = (monthly.groupby("account_code")["total"]
             .transform(lambda s: s.shift(1).rolling(3, min_periods=3).mean()))
    monthly["prior_mean"] = prior
    monthly["pct"] = (monthly["total"] / monthly["prior_mean"] - 1) * 100
    spike = monthly[(monthly["pct"] > cfg.mom_pct_cutoff) & (monthly["total"] >= cfg.mom_min_total)]
    if not spike.empty:
        merged = df[["account_code", "period", "amount"]].merge(
            spike[["account_code", "period", "total", "pct"]], on=["account_code", "period"],
            how="left")
        merged.index = df.index
        share = merged["amount"] / merged["total"]
        mom_hit = merged["pct"].notna() & (share >= 0.25) & ~stat_hit
        text = ("Account " + df["account_code"] + " " + df["period"] + " total up "
                + merged["pct"].round(0).astype("Float64").astype(str)
                + "% vs prior 3-month mean; this entry is " + (share * 100).round(0).astype("Float64").astype(str)
                + "% of the month")
        flag |= mom_hit
        reason.loc[mom_hit] = text.loc[mom_hit]
    return flag, reason


def detect_period_end(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Material manual journals in the last N days of a month / quarter / financial year."""
    d = df["posting_date"].dt.normalize()
    days_left = (d + pd.offsets.MonthEnd(0) - d).dt.days
    near_end = days_left < cfg.period_end_days
    flag = df["is_manual_like"] & near_end & (df["amount"] >= cfg.period_end_min_amount)
    month = d.dt.month
    kind = np.select([month == 3, month.isin([6, 9, 12])], ["financial year-end", "quarter-end"],
                     default="month-end")
    text = "Manual journal of " + _inr(df["amount"]) + " posted at " + pd.Series(kind, index=df.index)
    return flag, _reasons(df, flag, text)


def detect_backdated(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Posting date far after (back-dated) or before (future-dated) the document date."""
    gap = (df["posting_date"] - df["document_date"]).dt.days
    back = gap > cfg.backdate_days
    future = gap < -cfg.future_days
    flag = back | future
    text = np.where(back, "Back-dated: posted " + gap.astype(str) + " days after document date",
                    "Future-dated: document date is " + (-gap).astype(str) + " days after posting")
    return flag, _reasons(df, flag, pd.Series(text, index=df.index))


def detect_imbalance(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Entries whose total debits and credits do not agree (grouped by entry_id)."""
    grp = df.groupby("entry_id", sort=False)
    diff = grp["debit"].transform("sum") - grp["credit"].transform("sum")
    flag = diff.abs() > cfg.imbalance_tolerance
    text = "Debits and credits differ by " + diff.abs().map(fmt_inr)
    return flag, _reasons(df, flag, text)


def detect_dormant_rare(df: pd.DataFrame, cfg: DetectorConfig) -> DetectorResult:
    """Posting to an account after a long dormant spell, or by a rarely-seen user."""
    flag, reason = _empty(df)
    ordered = df.sort_values(["account_code", "posting_date", "_row_id"])
    gap = ordered.groupby("account_code")["posting_date"].diff().dt.days
    history = ordered.groupby("account_code").cumcount()
    dormant = ((gap >= cfg.dormant_days) & (history >= cfg.dormant_min_history)).reindex(df.index, fill_value=False)
    gap = gap.reindex(df.index)

    per_user = df.groupby("posted_by")["entry_id"].transform("size")
    rare = (per_user <= cfg.rare_user_max_entries) & df["is_manual_like"]

    flag = dormant | rare
    text = pd.Series("", index=df.index, dtype="object")
    text[dormant] = ("Account " + df["account_code"] + " dormant for "
                     + gap.round(0).astype("Float64").astype(str) + " days before this posting")[dormant]
    text[rare & ~dormant] = ("Posted by rarely-seen user " + df["posted_by"]
                             + " (only " + per_user.astype(str) + " entries in the ledger)")[rare & ~dormant]
    text[rare & dormant] = text[rare & dormant] + "; also posted by a rarely-seen user"
    reason.loc[flag] = text.loc[flag]
    return flag, reason


DETECTORS: dict[str, DetectorFn] = {
    "weekend_holiday": detect_weekend_holiday,
    "after_hours": detect_after_hours,
    "sod_override": detect_sod_override,
    "below_threshold": detect_below_threshold,
    "round_number": detect_round_number,
    "duplicate": detect_duplicates,
    "benford": detect_benford,
    "variance": detect_variance,
    "period_end": detect_period_end,
    "backdated": detect_backdated,
    "imbalance": detect_imbalance,
    "dormant_rare": detect_dormant_rare,
}
assert set(DETECTORS) == set(DETECTOR_LABELS)


def run_detectors(
    df: pd.DataFrame,
    cfg: DetectorConfig,
    enabled: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run the enabled detectors; return (flags, reasons) frames aligned to ``df``.

    ``flags`` has one boolean column per detector; ``reasons`` has the matching text.
    Disabled detectors yield all-False / empty columns so downstream code is uniform.
    """
    enabled_set = set(enabled) if enabled is not None else set(DETECTORS)
    flags, reasons = {}, {}
    for name, fn in DETECTORS.items():
        if name in enabled_set:
            flag, reason = fn(df, cfg)
            logger.info("Detector %-16s flagged %s", name, int(flag.sum()))
        else:
            flag, reason = _empty(df)
        flags[name] = flag.astype(bool)
        reasons[name] = reason
    return pd.DataFrame(flags, index=df.index), pd.DataFrame(reasons, index=df.index)
