"""Central configuration: paths, schema, thresholds, weights, holidays.

Everything tunable lives here so the detectors, scoring and UI share one source of truth.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
OUTPUT_DIR = ROOT_DIR / "outputs"
SAMPLE_CSV = DATA_DIR / "sample_ledger.csv"
SAMPLE_TRUTH_CSV = DATA_DIR / "sample_ledger_ground_truth.csv"
SAMPLE_ENTITY = "Meridian Industries Pvt Ltd"

# --------------------------------------------------------------------------- schema
# Columns the pipeline cannot work without. Everything else gets a documented default.
REQUIRED_COLUMNS: list[str] = [
    "entry_id", "posting_date", "account_code", "posted_by", "debit", "credit",
]
OPTIONAL_DEFAULTS: dict[str, object] = {
    "document_date": None,          # defaults to posting_date
    "account_name": None,           # defaults to account_code
    "cost_center": "NA",
    "description": "",
    "amount": None,                 # defaults to max(debit, credit)
    "currency": "INR",
    "entry_type": "Manual",
    "approved_by": "",
    "posting_time": "12:00:00",     # without a time, after-hours test is neutral
    "source_system": "GL",
    "period": None,                 # defaults to YYYY-MM of posting_date
    "is_manual_override": None,     # defaults to N
}
ALL_COLUMNS: list[str] = [
    "entry_id", "posting_date", "document_date", "account_code", "account_name",
    "cost_center", "description", "debit", "credit", "amount", "currency",
    "entry_type", "posted_by", "approved_by", "posting_time", "source_system",
    "period", "is_manual_override",
]
# Header aliases used by the auto column-mapper (normalised: lowercase, alphanumerics only)
COLUMN_ALIASES: dict[str, list[str]] = {
    "entry_id": ["entryid", "jeid", "journalid", "voucherno", "vouchernumber", "documentno", "txnid", "id"],
    "posting_date": ["postingdate", "date", "postdate", "voucherdate", "entrydate", "transactiondate"],
    "document_date": ["documentdate", "docdate", "invoicedate", "billdate"],
    "account_code": ["accountcode", "glcode", "account", "accountno", "ledgercode", "glaccount"],
    "account_name": ["accountname", "glname", "ledgername", "accountdescription"],
    "cost_center": ["costcenter", "costcentre", "cc", "department"],
    "description": ["description", "narration", "memo", "particulars", "text"],
    "debit": ["debit", "dr", "debitamount", "dramount"],
    "credit": ["credit", "cr", "creditamount", "cramount"],
    "amount": ["amount", "value", "amt", "entryvalue"],
    "currency": ["currency", "curr", "ccy"],
    "entry_type": ["entrytype", "type", "jetype", "vouchertype", "doctype"],
    "posted_by": ["postedby", "user", "createdby", "enteredby", "preparer", "userid"],
    "approved_by": ["approvedby", "approver", "authorisedby", "authorizedby", "checkedby"],
    "posting_time": ["postingtime", "time", "entrytime", "createdtime", "timestamp"],
    "source_system": ["sourcesystem", "source", "module", "system"],
    "period": ["period", "fiscalperiod", "month"],
    "is_manual_override": ["ismanualoverride", "manualoverride", "override", "overrideflag"],
}
MANUAL_ENTRY_TYPES = {"MANUAL", "ADJUSTING", "REVERSAL"}

# --------------------------------------------------------------------------- holidays
# Indicative Indian public holidays for FY 2025-26. Edit freely, or pass your own list in the UI.
DEFAULT_HOLIDAYS: list[dt.date] = [
    dt.date(2025, 4, 14), dt.date(2025, 4, 18), dt.date(2025, 5, 1), dt.date(2025, 6, 7),
    dt.date(2025, 8, 15), dt.date(2025, 8, 27), dt.date(2025, 10, 2), dt.date(2025, 10, 20),
    dt.date(2025, 11, 5), dt.date(2025, 12, 25), dt.date(2026, 1, 26), dt.date(2026, 3, 4),
]

# --------------------------------------------------------------------------- detectors
DETECTOR_LABELS: dict[str, str] = {
    "weekend_holiday": "Weekend / holiday posting",
    "after_hours": "After-hours posting",
    "sod_override": "Override without approval / self-approval (SoD)",
    "below_threshold": "Just below approval threshold",
    "round_number": "Round-figure amount",
    "duplicate": "Duplicate entry",
    "benford": "Benford's-law violation",
    "variance": "Variance outlier (z-score / IQR / MoM)",
    "period_end": "Period-end manual journal",
    "backdated": "Back-dated / future-dated",
    "imbalance": "Debit != credit imbalance",
    "dormant_rare": "Dormant account / rare user",
}

DETECTOR_SHORT: dict[str, str] = {
    "weekend_holiday": "Weekend / holiday", "after_hours": "After hours", "sod_override": "No / self approval",
    "below_threshold": "Below approval limit", "round_number": "Round figure", "duplicate": "Duplicate",
    "benford": "Benford", "variance": "Outlier / variance", "period_end": "Period-end",
    "backdated": "Back / future-dated", "imbalance": "Dr != Cr", "dormant_rare": "Dormant / rare user",
}

DETECTOR_DESCRIPTIONS: dict[str, str] = {
    "weekend_holiday": "Manual or override journal posted on a Saturday, Sunday or listed public holiday.",
    "after_hours": "Manual or override journal posted inside the night window (default 22:00-05:00).",
    "sod_override": "Manual or override journal with no approver recorded, or approved by the person who posted it.",
    "below_threshold": "Amount just below the approval limit (possible splitting / structuring to avoid review).",
    "round_number": "Large amounts that are exact multiples of the round unit (default Rs 1 lakh).",
    "duplicate": "Same account, amount, posting date and narration booked under different entry IDs.",
    "benford": "Account whose leading-digit pattern departs from Benford's law (MAD and chi-square test).",
    "variance": "Amount that is a statistical outlier for its account (z-score and IQR) or a month-on-month spike.",
    "period_end": "Material manual journal posted in the last days of a month, quarter or financial year.",
    "backdated": "Posting date far after (back-dated) or before (future-dated) the document date.",
    "imbalance": "Total debits and credits of an entry do not agree.",
    "dormant_rare": "Posting to an account after a long dormant period, or by a rarely-seen user.",
}

# Risk weights (points added to a 0-100 score when a detector fires).
DEFAULT_WEIGHTS: dict[str, float] = {
    "sod_override": 30, "imbalance": 30, "variance": 25, "below_threshold": 20,
    "duplicate": 20, "weekend_holiday": 15, "backdated": 15, "dormant_rare": 15,
    "after_hours": 12, "period_end": 12, "benford": 10, "round_number": 8,
}

SEVERITY_ORDER = ["Low", "Medium", "High", "Extreme"]
SEVERITY_COLORS = {"Low": "#9CA3AF", "Medium": "#F59E0B", "High": "#F97316", "Extreme": "#DC2626"}
SEVERITY_FILLS = {"Low": "F3F4F6", "Medium": "FEF3C7", "High": "FFEDD5", "Extreme": "FECACA"}
PRIMARY_COLOR = "#1F3A5F"


@dataclass(frozen=True)
class DetectorConfig:
    """Tunable thresholds (surfaced as sidebar controls in the app)."""

    holidays: tuple[dt.date, ...] = tuple(DEFAULT_HOLIDAYS)
    after_hours_start: int = 22          # hour (inclusive) the night window begins
    after_hours_end: int = 5             # hour (exclusive) the night window ends
    threshold_amount: float = 1_000_000.0   # approval limit (Rs 10 lakh)
    threshold_band_pct: float = 5.0      # flag amounts within this % below the limit
    round_unit: float = 100_000.0        # amounts that are exact multiples of this
    round_min_amount: float = 100_000.0
    zscore_cutoff: float = 3.5
    iqr_multiplier: float = 3.0
    use_log_amounts: bool = True         # ledger amounts are roughly log-normal
    min_account_entries: int = 30        # minimum sample for per-account statistics
    mom_pct_cutoff: float = 150.0        # month-on-month variance vs 3-month rolling mean
    mom_min_total: float = 1_000_000.0   # ignore tiny account-months
    benford_min_entries: int = 300
    benford_mad_cutoff: float = 0.015    # Nigrini: > 0.015 = non-conformity
    benford_alpha: float = 0.01
    period_end_days: int = 2
    period_end_min_amount: float = 500_000.0
    backdate_days: int = 30
    future_days: int = 3
    imbalance_tolerance: float = 1.0
    dormant_days: int = 180
    dormant_min_history: int = 5
    rare_user_max_entries: int = 5
    weights: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    materiality_percentile: float = 0.99  # top 1% amounts get a score bump
    materiality_bonus: float = 10.0
    extreme_min_score: float = 70.0
    high_min_score: float = 50.0
    medium_min_score: float = 30.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["holidays"] = [h.isoformat() for h in self.holidays]
        return d

    def with_overrides(self, **kwargs) -> "DetectorConfig":
        return replace(self, **kwargs)


# --------------------------------------------------------------------------- agent / LLM
MAX_AGENT_ITERATIONS = 8
DEFAULT_TOP_N_EXTREME = 25
DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-5-5"
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b"
GROQ_BASE_URL = "https://api.groq.com/openai/v1"   # Groq exposes an OpenAI-compatible endpoint
LLM_MAX_TOKENS = 4096
