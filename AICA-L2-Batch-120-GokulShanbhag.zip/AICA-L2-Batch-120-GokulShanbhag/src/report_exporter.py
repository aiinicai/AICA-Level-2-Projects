"""Excel audit report (Openpyxl) plus Markdown-based letter exports (.txt / .docx for edited letters).

The primary Word letter is built from structured data in :mod:`src.letter`; ``letter_to_docx`` here is
the fallback used when a user has hand-edited the Markdown text in the dashboard.
"""
from __future__ import annotations

import datetime as dt
import io
import math
import re

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .config import (
    DEFAULT_WEIGHTS, DETECTOR_DESCRIPTIONS, DETECTOR_LABELS, DETECTOR_SHORT, PRIMARY_COLOR, SEVERITY_FILLS,
    SEVERITY_ORDER, DetectorConfig,
)
from .letter import clean_text, sod_breakdown
from .risk_scoring import detector_counts, kpis
from .utils import fmt_inr

# Indian digit grouping (lakh / crore) via conditional number format
INR_FORMAT = '[>=10000000]"₹"##\\,##\\,##\\,##0.00;[>=100000]"₹"##\\,##\\,##0.00;"₹"##,##0.00'
INR_FORMAT_0 = '[>=10000000]"₹"##\\,##\\,##\\,##0;[>=100000]"₹"##\\,##\\,##0;"₹"##,##0'
DATE_FORMAT = "DD-MMM-YYYY"
NAVY = PRIMARY_COLOR.lstrip("#")
HEADER_FILL = PatternFill("solid", fgColor=NAVY)
HEADER_FONT = Font(bold=True, color="FFFFFF", name="Calibri", size=10)
BASE_FONT = Font(name="Calibri", size=10)
THIN = Side(style="thin", color="D1D5DB")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# key, header, width, kind
ENTRY_COLUMNS: list[tuple[str, str, int, str]] = [
    ("entry_id", "Entry ID", 13, "text"), ("posting_date", "Posting date", 13, "date"),
    ("posting_time", "Time", 9, "text"), ("account_code", "Account", 9, "text"),
    ("account_name", "Account name", 24, "text"), ("description", "Description", 36, "text"),
    ("amount", "Amount (₹)", 18, "inr"), ("entry_type", "Type", 11, "text"),
    ("posted_by", "Posted by", 22, "text"), ("approved_by", "Approved by", 22, "text"),
    ("is_manual_override", "Override", 9, "center"), ("risk_score", "Risk score", 10, "int"),
    ("severity", "Severity", 10, "center"), ("tests", "Tests triggered", 30, "wrap"),
    ("reasons", "Reasons", 95, "wrap"),
]


def _tests_label(keys: str) -> str:
    return "; ".join(DETECTOR_SHORT[k] for k in keys.split(",") if k in DETECTOR_SHORT)


def _style_header(ws, row: int, ncols: int, start_col: int = 1) -> None:
    for c in range(start_col, start_col + ncols):
        cell = ws.cell(row=row, column=c)
        cell.fill, cell.font, cell.border = HEADER_FILL, HEADER_FONT, BOX
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _page_setup(ws, title: str, rows_to_repeat: str | None = None, landscape: bool = True) -> None:
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.6
    ws.oddHeader.center.text = "STRICTLY PRIVATE & CONFIDENTIAL - DRAFT FOR DISCUSSION"
    ws.oddHeader.center.size = 8
    ws.oddFooter.left.text = title
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.left.size = ws.oddFooter.right.size = 8
    if rows_to_repeat:
        ws.print_title_rows = rows_to_repeat


def _write_entries(ws, df: pd.DataFrame, title: str, extra: tuple[str, str, int, str] | None = None) -> None:
    cols = list(ENTRY_COLUMNS)
    if extra:
        cols.insert(len(cols) - 1, extra)
    data = df.copy()
    data["posting_date"] = data["posting_date"].dt.date
    data["severity"] = data["severity"].astype(str)
    data["tests"] = data["detectors_hit"].map(_tests_label)
    ws.append([h for _, h, _, _ in cols])
    _style_header(ws, 1, len(cols))
    ws.row_dimensions[1].height = 30
    keys = [k for k, _, _, _ in cols]
    for row in data[keys].itertuples(index=False):
        ws.append(list(row))
    n = len(data)
    for c, (key, _, width, kind) in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(c)].width = width
        for r in range(2, n + 2):
            cell = ws.cell(row=r, column=c)
            cell.font, cell.border = BASE_FONT, BOX
            cell.alignment = Alignment(vertical="top", wrap_text=(kind == "wrap"),
                                       horizontal="center" if kind == "center" else None)
            if cell.data_type == "f":                      # never let ledger text become a formula
                cell.data_type = "s"
            if kind == "inr":
                cell.number_format = INR_FORMAT
            elif kind == "date":
                cell.number_format = DATE_FORMAT
            elif kind == "int":
                cell.number_format = "0"
    ws.freeze_panes = "B2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{max(n + 1, 2)}"
    sev_col = get_column_letter(keys.index("severity") + 1)
    if n:                                          # colour only the score + severity cells, not whole rows
        rng = f"{get_column_letter(keys.index('risk_score') + 1)}2:{sev_col}{n + 1}"
        for sev, color in SEVERITY_FILLS.items():
            ws.conditional_formatting.add(
                rng, FormulaRule(formula=[f'${sev_col}2="{sev}"'], fill=PatternFill("solid", bgColor=color)))
    _page_setup(ws, title, rows_to_repeat="1:1")


# --------------------------------------------------------------------------- letter sheet
def _plain(text: str) -> str:
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", clean_text(text))
    return re.sub(r"`(.+?)`", r"\1", text).replace("&nbsp;", " ")


def _write_letter_sheet(wb: Workbook, letter: str, letter_mode: str) -> None:
    ws = wb.create_sheet("Management Letter")
    widths = [24, 34, 30, 18, 18, 18, 9]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ncols, total_chars = len(widths), sum(widths) * 1.05
    ws.sheet_view.showGridLines = False

    def para(text: str, *, bold=False, size=10, color: str | None = None, fill: str | None = None) -> None:
        r = ws.max_row + 1
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
        cell = ws.cell(row=r, column=1, value=text)
        if cell.data_type == "f":
            cell.data_type = "s"
        cell.font = Font(name="Calibri", size=size, bold=bold, color=color)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        if fill:
            cell.fill = PatternFill("solid", fgColor=fill)
        ws.row_dimensions[r].height = max(15, math.ceil(len(text) / (total_chars * (10 / size))) * (size + 5))

    title = "Management Letter" + (f"  [{letter_mode}]" if letter_mode else "")
    ws.cell(row=1, column=1, value=title).font = Font(bold=True, size=14, color=NAVY)
    lines = (letter or "(No letter generated yet - use 'Generate Management Letter' in the dashboard.)").splitlines()
    table: list[list[str]] = []

    def flush_table() -> None:
        if not table:
            return
        r0 = ws.max_row + 1
        for ri, row in enumerate(table):
            for ci in range(min(len(row), ncols)):
                cell = ws.cell(row=r0 + ri, column=ci + 1, value=_plain(row[ci]))
                cell.font = HEADER_FONT if ri == 0 else BASE_FONT
                cell.border = BOX
                cell.alignment = Alignment(wrap_text=True, vertical="top")
                if ri == 0:
                    cell.fill = HEADER_FILL
        table.clear()
        ws.append([])

    for raw in lines:
        s = raw.strip()
        if s.startswith("|"):
            if re.fullmatch(r"\|?[\s:|-]+\|?", s):
                continue
            table.append([c.strip() for c in s.strip("|").split("|")])
            continue
        flush_table()
        if not s or re.fullmatch(r"[-*_]{3,}", s):
            ws.append([])
        elif s.startswith("#"):
            level = len(s) - len(s.lstrip("#"))
            ws.append([])
            para(_plain(s.lstrip("# ")), bold=True, size={1: 14, 2: 12}.get(level, 11), color=NAVY)
        elif s.startswith(">"):
            para(_plain(s.lstrip("> ")), size=9, color="6B7280")
        elif s.startswith(("- ", "* ")):
            para("•  " + _plain(s[2:]))
        else:
            para(_plain(s))
    flush_table()
    _page_setup(ws, "Management Letter", landscape=False)


# --------------------------------------------------------------------------- workbook
def build_workbook(
    results: pd.DataFrame, entity: str, period_label: str, letter: str = "", letter_mode: str = "",
    cfg: DetectorConfig | None = None,
) -> bytes:
    """Create the formatted audit workbook and return it as bytes (for st.download_button)."""
    cfg = cfg or DetectorConfig()
    wb = Workbook()
    k = kpis(results)
    counts = detector_counts(results)

    # ---- Summary
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Smart Ledger Anomaly & System-Override Detector"
    ws["A1"].font = Font(bold=True, size=16, color=NAVY)
    ws["A2"] = "Audit report - journal-entry analytics"
    ws["A2"].font = Font(size=11, color="6B7280")
    info = [("Entity", entity), ("Period reviewed", period_label),
            ("Generated", dt.datetime.now().strftime("%d %b %Y %H:%M")),
            ("Scope", "100% of journal entries - automated analytics"),
            ("Status", "Draft for discussion - not an audit conclusion")]
    for i, (a, b) in enumerate(info, start=4):
        ws.cell(row=i, column=1, value=a).font = Font(bold=True, color=NAVY)
        ws.cell(row=i, column=2, value=b)
    r0 = 10
    ws.cell(row=r0, column=1, value="Key metric")
    ws.cell(row=r0, column=2, value="Value")
    _style_header(ws, r0, 2)
    rows = [
        ("Entries scanned", k["total_entries"], "#,##0"), ("Total value of entries", fmt_inr(k["total_value"], 0), "@"),
        ("Flagged entries", k["flagged_entries"], "#,##0"), ("% of entries flagged", k["flagged_pct"] / 100, "0.0%"),
        ("Extreme-risk entries", k["extreme_count"], "#,##0"), ("High-risk entries", k["high_count"], "#,##0"),
        ("Value of High + Extreme entries", fmt_inr(k["value_at_risk"], 0), "@"),
    ]
    for i, (label, value, fmt) in enumerate(rows, start=r0 + 1):
        ws.cell(row=i, column=1, value=label).border = BOX
        c = ws.cell(row=i, column=2, value=value)
        c.number_format, c.border = fmt, BOX
        c.alignment = Alignment(horizontal="right")
    s0 = r0 + len(rows) + 3
    ws.cell(row=s0, column=1, value="Severity")
    ws.cell(row=s0, column=2, value="Entries")
    _style_header(ws, s0, 2)
    sev_counts = results.loc[results["is_flagged"], "severity"].astype(str).value_counts()
    for i, sev in enumerate(SEVERITY_ORDER, start=s0 + 1):
        a = ws.cell(row=i, column=1, value=sev)
        a.fill = PatternFill("solid", fgColor=SEVERITY_FILLS[sev])
        a.border = BOX
        b = ws.cell(row=i, column=2, value=int(sev_counts.get(sev, 0)))
        b.number_format, b.border = "#,##0", BOX
    ws.cell(row=s0 + 5, column=1, value="Severity counts are for flagged entries only.").font = Font(
        italic=True, size=9, color="6B7280")
    chart = BarChart()
    chart.type, chart.style = "col", 10
    chart.title, chart.y_axis.title = "Flagged entries by severity", "Entries"
    chart.add_data(Reference(ws, min_col=2, min_row=s0, max_row=s0 + 4), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=1, min_row=s0 + 1, max_row=s0 + 4))
    chart.legend, chart.height, chart.width = None, 7.5, 13
    chart.x_axis.delete = chart.y_axis.delete = False
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    chart.dataLabels.showSerName = chart.dataLabels.showCatName = chart.dataLabels.showLegendKey = False
    ws.add_chart(chart, "E3")
    # top users by risk
    u0 = s0 + 8
    ws.cell(row=u0 - 1, column=1, value="Top 10 users by total risk score (flagged entries)").font = Font(
        bold=True, color=NAVY)
    for c, h in enumerate(["User", "Flagged entries", "Total risk score", "Value of flagged entries (₹ crore)"], start=1):
        ws.cell(row=u0, column=c, value=h)
    _style_header(ws, u0, 4)
    users = (results[results["is_flagged"]].groupby("posted_by")
             .agg(n=("entry_id", "size"), score=("risk_score", "sum"), amount=("amount", "sum"))
             .sort_values("score", ascending=False).head(10))
    for i, (user, row) in enumerate(users.iterrows(), start=u0 + 1):
        vals = [user, int(row.n), float(row.score), float(row.amount) / 1e7]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.border = BOX
            cell.number_format = {2: "#,##0", 3: "#,##0", 4: "#,##0.00"}.get(c, "General")
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 30
    _page_setup(ws, "Summary", landscape=False)

    # ---- Entry sheets
    ranked = results.sort_values(["risk_score", "amount"], ascending=False)
    _write_entries(wb.create_sheet("Extreme Anomalies"), ranked[ranked["severity"] == "Extreme"], "Extreme anomalies")
    _write_entries(wb.create_sheet("All Flagged Entries"), ranked[ranked["is_flagged"]], "All flagged entries")

    # ---- Detector counts + native chart
    wc = wb.create_sheet("Detector Counts")
    wc.append(["Test", "Flagged entries", "Flagged value (₹ crore)", "Risk weight", "What it checks"])
    _style_header(wc, 1, 5)
    key_by_label = {v: k_ for k_, v in DETECTOR_LABELS.items()}
    for r in counts.itertuples():
        key = key_by_label[r.label]
        wc.append([r.label, r.flagged_entries, r.flagged_value / 1e7, cfg.weights.get(key, DEFAULT_WEIGHTS[key]),
                   DETECTOR_DESCRIPTIONS[key]])
        row = wc.max_row
        wc.cell(row=row, column=3).number_format = "#,##0.00"
        for c in range(1, 6):
            wc.cell(row=row, column=c).border = BOX
            wc.cell(row=row, column=c).alignment = Alignment(wrap_text=(c == 5), vertical="center")
    for col, w in zip("ABCDE", (46, 16, 22, 12, 80)):
        wc.column_dimensions[col].width = w
    chart = BarChart()
    chart.type, chart.style = "bar", 10
    chart.title, chart.y_axis.title = "Flagged entries by test", "Entries"
    chart.add_data(Reference(wc, min_col=2, min_row=1, max_row=len(counts) + 1), titles_from_data=True)
    chart.set_categories(Reference(wc, min_col=1, min_row=2, max_row=len(counts) + 1))
    chart.legend, chart.height, chart.width = None, 9, 22
    chart.x_axis.delete = chart.y_axis.delete = False
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    chart.dataLabels.showSerName = chart.dataLabels.showCatName = chart.dataLabels.showLegendKey = False
    wc.add_chart(chart, f"A{len(counts) + 4}")
    _page_setup(wc, "Detector counts")

    # ---- SoD & overrides
    no_appr, self_appr = sod_breakdown(results)
    issue = pd.Series("", index=results.index, dtype="object")
    for mask, label in ((results["is_manual_override"] == "Y", "Manual override"), (no_appr, "No approver"),
                        (self_appr, "Self-approved"), (results["flag_weekend_holiday"], "Weekend / holiday"),
                        (results["flag_after_hours"], "After hours")):
        issue = issue.where(~mask, issue + label + "; ")
    sod_mask = issue != ""
    sod = ranked[sod_mask.reindex(ranked.index)].copy()
    sod["issue"] = issue.reindex(sod.index).str.rstrip("; ")
    ws_sod = wb.create_sheet("SoD & Overrides")
    _write_entries(ws_sod, sod.assign(issue=sod["issue"]), "Segregation of duties and overrides",
                   extra=("issue", "Control issue", 28, "wrap"))

    # ---- Letter + methodology
    _write_letter_sheet(wb, letter, letter_mode)
    wm = wb.create_sheet("Methodology")
    wm.sheet_view.showGridLines = False
    wm["A1"] = "Methodology, parameters and limitations"
    wm["A1"].font = Font(bold=True, size=14, color=NAVY)
    params = [
        ("Approval limit", fmt_inr(cfg.threshold_amount, 0)),
        ("Just-below band", f"{cfg.threshold_band_pct:g}% below the limit"),
        ("Round-figure unit", fmt_inr(cfg.round_unit, 0)),
        ("After-hours window", f"{cfg.after_hours_start:02d}:00 to {cfg.after_hours_end:02d}:00"),
        ("Back-dated if posted more than", f"{cfg.backdate_days} days after the document date"),
        ("Outlier test", f"z-score above {cfg.zscore_cutoff:g} or beyond the IQR fence (x{cfg.iqr_multiplier:g}) per account, on log-amounts"),
        ("Month-on-month spike", f"above {cfg.mom_pct_cutoff:g}% versus the prior 3-month mean"),
        ("Period-end window", f"last {cfg.period_end_days} day(s) of a month, amounts of {fmt_inr(cfg.period_end_min_amount, 0)} or more"),
        ("Dormant account", f"no posting for {cfg.dormant_days} days or more"),
        ("Severity bands", f"Extreme >= {cfg.extreme_min_score:g}; High >= {cfg.high_min_score:g}; "
                           f"Medium >= {cfg.medium_min_score:g}; otherwise Low (score 0-100, +{cfg.materiality_bonus:g} for the top 1% of amounts)"),
    ]
    wm.append([])
    wm.append(["Parameter", "Value"])
    _style_header(wm, 3, 2)
    for a, b in params:
        wm.append([a, b])
        for c in (1, 2):
            cell = wm.cell(row=wm.max_row, column=c)
            cell.border, cell.alignment = BOX, Alignment(wrap_text=True, vertical="top")
    wm.append([])
    for note in (
        "Each journal entry is tested against twelve rules; the weighted result is a 0-100 risk score (see 'Detector Counts').",
        "Findings are exceptions for follow-up, not audit conclusions. Thresholds should be calibrated to the client.",
        "Relevant frameworks: ICAI SA 240, SA 315, SA 330 and Section 143(3)(i) of the Companies Act, 2013.",
        "All amounts are in Indian rupees. The sample data supplied with the tool is synthetic.",
    ):
        wm.append([note])
        wm.merge_cells(start_row=wm.max_row, start_column=1, end_row=wm.max_row, end_column=2)
        wm.cell(row=wm.max_row, column=1).alignment = Alignment(wrap_text=True, vertical="top")
        wm.row_dimensions[wm.max_row].height = 30
    wm.column_dimensions["A"].width = 34
    wm.column_dimensions["B"].width = 100
    _page_setup(wm, "Methodology", landscape=False)

    wb.properties.title = f"Ledger anomaly audit report - {entity}"
    wb.properties.creator = "Smart Ledger Anomaly Detector"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_template_xlsx() -> bytes:
    """Blank Excel input template: ledger sheet with headers + example rows, and an instructions sheet."""
    from .config import ALL_COLUMNS, OPTIONAL_DEFAULTS, REQUIRED_COLUMNS
    wb = Workbook()
    ws = wb.active
    ws.title = "GL Export"
    ws.append(ALL_COLUMNS)
    _style_header(ws, 1, len(ALL_COLUMNS))
    examples = [
        ["JE-000001", dt.date(2025, 4, 3), dt.date(2025, 4, 2), "6004", "Travel & Conveyance", "CC100", "Staff travel - ref 1001",
         12500.00, 12500.00, 12500.00, "INR", "Manual", "Priya Nair", "R. Krishnan", "11:15:00", "Manual JV", "2025-04", "N"],
        ["JE-000002", dt.date(2025, 4, 6), dt.date(2025, 4, 6), "4001", "Sales - Domestic", "CC300", "Invoice 2045",
         985000.00, 985000.00, 985000.00, "INR", "Manual", "Aarav Mehta", None, "23:40:00", "Manual JV", "2025-04", "Y"],
        ["JE-000003", dt.date(2025, 4, 7), dt.date(2025, 4, 7), "5001", "Raw Material Consumed", "CC200", "Batch posting",
         87500.00, 87500.00, 87500.00, "INR", "Automated", "SYS_BATCH", "SYSTEM", "02:10:00", "SAP-FI", "2025-04", "N"],
    ]
    for row in examples:
        ws.append(row)
        ws.cell(row=ws.max_row, column=2).number_format = DATE_FORMAT
        ws.cell(row=ws.max_row, column=3).number_format = DATE_FORMAT
    for i, name in enumerate(ALL_COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = max(14, len(name) + 4)
    ws.freeze_panes = "A2"
    wi = wb.create_sheet("Instructions")
    wi["A1"] = "How to prepare your file"
    wi["A1"].font = Font(bold=True, size=14, color=NAVY)
    wi.append([])
    wi.append(["Column", "Required?", "If missing"])
    _style_header(wi, 3, 3)
    for col in ALL_COLUMNS:
        required = col in REQUIRED_COLUMNS
        default = OPTIONAL_DEFAULTS.get(col)
        fallback = "-" if required else ("derived automatically" if default is None else f"defaults to '{default}'")
        wi.append([col, "Yes" if required else "No", fallback])
    wi.append([])
    for note in ("Keep the header row; extra columns are ignored and differently named headers can be mapped in the app.",
                 "One row per journal entry (or line). Debits and credits are checked per entry_id.",
                 "Dates may be real Excel dates or text (YYYY-MM-DD or DD-MM-YYYY). posting_time as HH:MM:SS.",
                 "entry_type: Manual / Automated / Adjusting / Reversal. is_manual_override and flags: Y or N.",
                 "Title rows above the header, several worksheets and a totals row at the bottom are handled."):
        wi.append([note])
    wi.column_dimensions["A"].width = 28
    wi.column_dimensions["B"].width = 12
    wi.column_dimensions["C"].width = 40
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def letter_to_plain_text(markdown: str) -> str:
    """Strip Markdown markup for a .txt download."""
    text = re.sub(r"^#{1,6}\s*", "", clean_text(markdown), flags=re.M)
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"^>\s?", "", text, flags=re.M)
    text = re.sub(r"[ ]{2,}$", "", text, flags=re.M)
    return text


# --------------------------------------------------------------------------- Markdown -> Word (edited letters)
_INLINE = re.compile(r"(\*\*.+?\*\*|`.+?`|(?<!\*)\*[^*\s][^*]*?\*(?!\*))")
_NAVY = RGBColor(0x1F, 0x3A, 0x5F)


def _add_inline(paragraph, text: str) -> None:
    """Add text to a paragraph, honouring **bold**, *italic* and `code` Markdown."""
    for part in _INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            paragraph.add_run(part[1:-1]).font.name = "Consolas"
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            paragraph.add_run(part[1:-1]).italic = True
        else:
            paragraph.add_run(part)


def _add_page_number(paragraph) -> None:
    run = paragraph.add_run()
    for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = text
        run._r.append(el)


def letter_to_docx(markdown: str, entity: str = "", period: str = "") -> bytes:
    """Convert Markdown letter text into a formatted Word document (used for hand-edited letters).

    Handles headings, bold / italic, bullet and numbered lists, block quotes and simple pipe tables.
    """
    markdown = clean_text(markdown) if "\n" not in markdown else "\n".join(
        clean_text(x) if x.strip() else x for x in markdown.splitlines())
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.top_margin = sec.bottom_margin = Cm(2.0)
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "Calibri", Pt(10.5)
    normal.paragraph_format.space_after = Pt(5)
    for name, size in (("Heading 1", 14), ("Heading 2", 12), ("Heading 3", 11)):
        st = doc.styles[name]
        st.font.name, st.font.size, st.font.color.rgb = "Calibri", Pt(size), _NAVY

    header = sec.header.paragraphs[0]
    header.text = "DRAFT - for discussion" + (f"  |  {entity}" if entity else "") + (f"  |  {period}" if period else "")
    header.runs[0].font.size, header.runs[0].font.color.rgb = Pt(9), RGBColor(0x6B, 0x72, 0x80)
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("Page ")
    _add_page_number(footer)

    lines = markdown.replace("\r\n", "\n").split("\n")
    i, seen_title = 0, False
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        i += 1
        if not stripped or re.fullmatch(r"[-*_]{3,}", stripped):
            continue
        if stripped.startswith("|"):                                   # pipe table
            block = [stripped]
            while i < len(lines) and lines[i].strip().startswith("|"):
                block.append(lines[i].strip())
                i += 1
            rows = [[c.strip() for c in r.strip("|").split("|")] for r in block
                    if not re.fullmatch(r"\|?[\s:|-]+\|?", r)]
            if rows:
                width = max(len(r) for r in rows)
                table = doc.add_table(rows=len(rows), cols=width)
                table.style = "Table Grid"
                for r_idx, row in enumerate(rows):
                    for c_idx in range(width):
                        cell = table.cell(r_idx, c_idx)
                        cell.text = ""
                        _add_inline(cell.paragraphs[0], row[c_idx] if c_idx < len(row) else "")
                        for run in cell.paragraphs[0].runs:
                            run.font.size = Pt(9)
                            if r_idx == 0:
                                run.bold = True
                doc.add_paragraph()
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level, text = len(m.group(1)), m.group(2).strip().strip("*")
            if level == 1 and not seen_title:
                seen_title = True
                p = doc.add_heading(text, level=0)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                doc.add_heading(text, level=min(max(level - 1, 1), 3))
            continue
        if stripped.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.8)
            _add_inline(p, stripped.lstrip("> ").strip())
            for run in p.runs:
                run.italic = True
            continue
        m = re.match(r"^(\s*)([-*+])\s+(.*)$", line)
        if m:
            style = "List Bullet 2" if len(m.group(1)) >= 2 else "List Bullet"
            _add_inline(doc.add_paragraph(style=style), m.group(3))
            continue
        m = re.match(r"^\s*\d+[.)]\s+(.*)$", line)
        if m:
            _add_inline(doc.add_paragraph(style="List Number"), m.group(1))
            continue
        _add_inline(doc.add_paragraph(), stripped)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
