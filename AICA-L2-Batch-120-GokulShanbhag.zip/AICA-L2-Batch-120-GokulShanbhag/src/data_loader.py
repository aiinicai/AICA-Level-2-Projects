"""Ledger ingestion from CSV or Excel (.xlsx / .xlsm / .xls): chunked reading, header detection,
schema validation / column mapping and cleaning."""
from __future__ import annotations

import datetime as dt
import io
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO, Callable, Iterator

import pandas as pd

from .config import (
    ALL_COLUMNS, COLUMN_ALIASES, MANUAL_ENTRY_TYPES, OPTIONAL_DEFAULTS, REQUIRED_COLUMNS,
)

logger = logging.getLogger(__name__)

Source = str | Path | BinaryIO
ProgressCb = Callable[[int, float | None], None]   # (rows_loaded, fraction 0-1 or None)

SUPPORTED_EXTENSIONS = ("csv", "xlsx", "xlsm", "xls")
_TRUE_VALUES = {"Y", "YES", "TRUE", "1", "T"}
_HEADER_SCAN_ROWS = 40


class SchemaError(ValueError):
    """Raised when required columns are missing; ``missing`` lists them."""

    def __init__(self, missing: list[str], available: list[str]):
        self.missing = missing
        self.available = available
        super().__init__(
            "Missing required column(s): " + ", ".join(missing)
            + ". Columns found in the file: " + ", ".join(available[:40])
        )


@dataclass
class LoadReport:
    rows_read: int = 0
    rows_dropped: int = 0
    mapping: dict[str, str] = field(default_factory=dict)
    defaulted_columns: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    file_kind: str = "csv"
    sheet: str | None = None

    @property
    def rows_loaded(self) -> int:
        return self.rows_read - self.rows_dropped


def _norm(name: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


_KNOWN_HEADERS = {_norm(a) for std in ALL_COLUMNS for a in [std, *COLUMN_ALIASES.get(std, [])]}


# =============================================================================== file kinds
def detect_kind(source: Source) -> str:
    """'csv', 'xlsx' (also .xlsm) or 'xls' - decided by the file's leading bytes, not just its extension."""
    if isinstance(source, (str, Path)):
        with open(source, "rb") as fh:
            head = fh.read(8)
        ext = Path(source).suffix.lower().lstrip(".")
    else:
        pos = source.tell() if hasattr(source, "tell") else 0
        source.seek(0)
        head, ext = source.read(8), ""
        source.seek(pos)
    if head[:2] == b"PK":
        return "xlsx"
    if head[:8] == bytes.fromhex("D0CF11E0A1B11AE1"):
        return "xls"
    return "xlsx" if ext in ("xlsx", "xlsm") else "xls" if ext == "xls" else "csv"


def _open_binary(source: Source) -> tuple[BinaryIO, bool]:
    if isinstance(source, (str, Path)):
        return open(source, "rb"), True
    source.seek(0)
    return source, False


# =============================================================================== Excel helpers
def _cell_to_str(value: object) -> str:
    """Excel cell -> string the CSV-style cleaner understands (dates ISO, whole floats without '.0')."""
    if value is None:
        return ""
    if isinstance(value, dt.datetime):
        return value.strftime("%Y-%m-%d" if value.time() == dt.time(0) else "%Y-%m-%d %H:%M:%S")
    if isinstance(value, dt.date):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, dt.time):
        return value.strftime("%H:%M:%S")
    if isinstance(value, bool):
        return "Y" if value else "N"
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() and abs(value) < 1e15 else repr(value)
    return str(value).strip()


def _header_names(raw: list[object]) -> list[str]:
    names, seen = [], {}
    for i, cell in enumerate(raw):
        name = _cell_to_str(cell) or f"column_{i + 1}"
        seen[name] = seen.get(name, 0) + 1
        names.append(name if seen[name] == 1 else f"{name}_{seen[name]}")
    return names


def _find_header_row(rows: list[list[object]]) -> int:
    """Index of the header row: the row with the most recognisable ledger headers (title rows are skipped)."""
    best, best_score = 0, -1
    for i, row in enumerate(rows):
        cells = [_norm(_cell_to_str(c)) for c in row if _cell_to_str(c)]
        if len(cells) < 3:
            continue
        score = sum(c in _KNOWN_HEADERS for c in cells)
        if score > best_score:
            best, best_score = i, score
    if best_score <= 0:                                  # nothing recognisable: first row with >= 3 filled cells
        for i, row in enumerate(rows):
            if sum(1 for c in row if _cell_to_str(c)) >= 3:
                return i
        return 0
    return best


def _openpyxl_workbook(source: Source):
    from openpyxl import load_workbook
    handle, _ = _open_binary(source)
    return load_workbook(handle, read_only=True, data_only=True)


def _xls_frame(source: Source, sheet: str | int | None) -> pd.DataFrame:
    try:
        handle, close = _open_binary(source)
        try:
            return pd.read_excel(handle, sheet_name=sheet if sheet is not None else 0, header=None, dtype=object,
                                 engine="xlrd")
        finally:
            if close:
                handle.close()
    except ImportError as exc:
        raise ValueError("Reading old .xls files needs the 'xlrd' package (pip install xlrd). "
                         "Alternatively save the file as .xlsx or .csv.") from exc


def list_sheets(source: Source) -> list[str]:
    """Worksheet names of an Excel file (empty list for CSV)."""
    kind = detect_kind(source)
    if kind == "xlsx":
        wb = _openpyxl_workbook(source)
        try:
            return [ws.title for ws in wb.worksheets if ws.sheet_state == "visible"]
        finally:
            wb.close()
    if kind == "xls":
        try:
            handle, close = _open_binary(source)
            try:
                return [str(n) for n in pd.ExcelFile(handle, engine="xlrd").sheet_names]
            finally:
                if close:
                    handle.close()
        except ImportError:
            return []
    return []


def suggest_sheet(source: Source) -> str | None:
    """The worksheet whose header row best matches the ledger schema."""
    best, best_score = None, -1
    for name in list_sheets(source):
        try:
            header = read_header(source, name)
        except Exception:  # noqa: BLE001 - unreadable sheet: skip
            continue
        score = len(suggest_mapping(header))
        if score > best_score:
            best, best_score = name, score
    return best


def _excel_rows(source: Source, sheet: str | None) -> Iterator[list[object]]:
    kind = detect_kind(source)
    if kind == "xlsx":
        wb = _openpyxl_workbook(source)
        try:
            ws = wb[sheet] if sheet else wb.worksheets[0]
            for row in ws.iter_rows(values_only=True):
                yield list(row)
        finally:
            wb.close()
    else:
        frame = _xls_frame(source, sheet)
        for row in frame.itertuples(index=False):
            yield [None if (isinstance(v, float) and pd.isna(v)) else v for v in row]


# =============================================================================== mapping
def read_header(source: Source, sheet: str | None = None) -> list[str]:
    """Column headers of the CSV or of the chosen Excel worksheet (auto-detecting the header row)."""
    kind = detect_kind(source)
    if kind == "csv":
        handle, close = _open_binary(source)
        try:
            return pd.read_csv(handle, nrows=0, dtype=str).columns.tolist()
        finally:
            if close:
                handle.close()
            elif hasattr(source, "seek"):
                source.seek(0)
    head: list[list[object]] = []
    rows = _excel_rows(source, sheet)
    for row in rows:
        head.append(row)
        if len(head) >= _HEADER_SCAN_ROWS:
            break
    rows.close()                                           # releases the workbook handle
    if not head:
        raise ValueError("The selected worksheet is empty.")
    if hasattr(source, "seek"):
        source.seek(0)
    return _header_names(head[_find_header_row(head)])


def suggest_mapping(columns: list[str]) -> dict[str, str]:
    """Auto-map file headers to the standard schema (standard name -> file column)."""
    by_norm = {_norm(c): c for c in columns}
    used: set[str] = set()
    mapping: dict[str, str] = {}
    for std in ALL_COLUMNS:                       # exact (normalised) matches first
        col = by_norm.get(_norm(std))
        if col is not None and col not in used:
            mapping[std] = col
            used.add(col)
    for std in ALL_COLUMNS:                       # then aliases
        if std in mapping:
            continue
        for alias in COLUMN_ALIASES.get(std, []):
            col = by_norm.get(alias)
            if col is not None and col not in used:
                mapping[std] = col
                used.add(col)
                break
    return mapping


def missing_required(mapping: dict[str, str]) -> list[str]:
    return [c for c in REQUIRED_COLUMNS if c not in mapping]


# =============================================================================== cleaning
def _parse_dates(s: pd.Series) -> pd.Series:
    """ISO first (fast path), then Excel serial numbers, then day-first mixed formats."""
    s = s.astype("string").str.strip()
    out = pd.to_datetime(s, format="%Y-%m-%d", errors="coerce")
    bad = out.isna() & s.notna() & (s != "")
    if bad.any():
        serial = bad & s.str.fullmatch(r"\d{5}(\.\d+)?").fillna(False)
        if serial.any():                                   # Excel stored the date as a serial number
            out.loc[serial] = pd.to_datetime(pd.to_numeric(s[serial]), unit="D", origin="1899-12-30")
        rest = bad & ~serial
        if rest.any():
            out.loc[rest] = pd.to_datetime(s[rest], errors="coerce", dayfirst=True, format="mixed")
    return out


def _to_number(s: pd.Series) -> pd.Series:
    cleaned = s.astype("string").str.replace(r"[₹,\s]|Rs\.?|INR", "", regex=True)
    cleaned = cleaned.str.replace(r"^\((.*)\)$", r"-\1", regex=True)   # (1,000) -> -1000
    return pd.to_numeric(cleaned, errors="coerce")


def _fix_times(s: pd.Series) -> pd.Series:
    """Excel time fractions (0.5 = 12:00) -> 'HH:MM:SS'; everything else untouched."""
    frac = s.str.fullmatch(r"0\.\d+").fillna(False)
    if frac.any():
        secs = (pd.to_numeric(s[frac]) * 86400).round().astype(int).clip(0, 86399)
        s = s.copy()
        s.loc[frac] = secs.map(lambda x: f"{x // 3600:02d}:{(x % 3600) // 60:02d}:{x % 60:02d}")
    return s


def _clean_chunk(chunk: pd.DataFrame, mapping: dict[str, str]) -> pd.DataFrame:
    chunk = chunk.rename(columns={src: std for std, src in mapping.items()})
    keep = [c for c in ALL_COLUMNS if c in chunk.columns]
    df = chunk[keep].copy()

    df["posting_date"] = _parse_dates(df["posting_date"])
    if "document_date" in df:
        df["document_date"] = _parse_dates(df["document_date"])
    for col in ("debit", "credit", "amount"):
        if col in df:
            df[col] = _to_number(df[col])
    for col in ("entry_id", "account_code", "posted_by", "approved_by", "entry_type",
                "description", "account_name", "cost_center", "currency", "source_system",
                "period", "posting_time", "is_manual_override"):
        if col in df:
            df[col] = df[col].astype("string").fillna("").str.strip()
    if "posting_time" in df:
        df["posting_time"] = _fix_times(df["posting_time"])
    return df


def _finalise(df: pd.DataFrame, report: LoadReport) -> pd.DataFrame:
    """Apply documented defaults, derive helper columns, drop unusable rows."""
    df = df.dropna(subset=["posting_date"])
    df = df[(df["entry_id"] != "") & (df["account_code"] != "")]
    report.rows_dropped = report.rows_read - len(df)

    df["debit"] = df["debit"].fillna(0.0)
    df["credit"] = df["credit"].fillna(0.0)
    for col, default in OPTIONAL_DEFAULTS.items():
        if col in df.columns:
            continue
        report.defaulted_columns.append(col)
        if col == "document_date":
            df[col] = df["posting_date"]
        elif col == "account_name":
            df[col] = df["account_code"]
        elif col == "amount":
            df[col] = df[["debit", "credit"]].max(axis=1)
        elif col == "period":
            df[col] = df["posting_date"].dt.strftime("%Y-%m")
        elif col == "is_manual_override":
            df[col] = "N"
        else:
            df[col] = default
    df["amount"] = df["amount"].fillna(df[["debit", "credit"]].max(axis=1)).abs()
    df["document_date"] = df["document_date"].fillna(df["posting_date"])
    df["period"] = df["period"].where(df["period"] != "", df["posting_date"].dt.strftime("%Y-%m"))

    df["entry_type"] = df["entry_type"].str.title().replace("", "Manual")
    df["is_manual_override"] = df["is_manual_override"].str.upper().isin(_TRUE_VALUES).map(
        {True: "Y", False: "N"})
    hhmm = df["posting_time"].str.extract(r"(\d{1,2}):(\d{2})").astype(float)
    df["posting_hour"] = hhmm[0].fillna(12.0).astype(int).clip(0, 23)
    df["is_manual_like"] = (
        df["entry_type"].str.upper().isin(MANUAL_ENTRY_TYPES) | (df["is_manual_override"] == "Y")
    )
    df = df.reset_index(drop=True)
    df.insert(0, "_row_id", range(len(df)))
    return df


# =============================================================================== chunk readers
def _csv_chunks(source: Source, wanted: set[str], chunksize: int) -> Iterator[tuple[pd.DataFrame, float | None]]:
    handle, close = _open_binary(source)
    handle.seek(0, io.SEEK_END)
    total = handle.tell()
    handle.seek(0)
    try:
        reader = pd.read_csv(handle, dtype=str, keep_default_na=False, chunksize=chunksize,
                             usecols=lambda c: c in wanted)
        for chunk in reader:
            try:
                frac = min(handle.tell() / total, 1.0) if total else None
            except (OSError, ValueError):
                frac = None
            yield chunk, frac
    finally:
        if close:
            handle.close()


def _excel_chunks(source: Source, sheet: str | None, wanted: set[str],
                  chunksize: int) -> Iterator[tuple[pd.DataFrame, float | None]]:
    rows_iter = _excel_rows(source, sheet)
    head: list[list[object]] = []
    for row in rows_iter:                                  # buffer rows until we can locate the header
        head.append(row)
        if len(head) >= _HEADER_SCAN_ROWS:
            break
    if not head:
        raise ValueError("The selected worksheet is empty.")
    h_idx = _find_header_row(head)
    names = _header_names(head[h_idx])
    keep_idx = [i for i, n in enumerate(names) if n in wanted]
    keep_names = [names[i] for i in keep_idx]

    def to_frame(batch: list[list[object]]) -> pd.DataFrame:
        data = [[_cell_to_str(r[i]) if i < len(r) else "" for i in keep_idx] for r in batch]
        return pd.DataFrame(data, columns=keep_names, dtype=object)

    pending: list[list[object]] = [r for r in head[h_idx + 1:] if any(c not in (None, "") for c in r)]
    while True:
        for row in rows_iter:
            if any(c not in (None, "") for c in row):
                pending.append(row)
            if len(pending) >= chunksize:
                break
        else:                                              # iterator exhausted
            if pending:
                yield to_frame(pending), 1.0
            return
        yield to_frame(pending), None
        pending = []


# =============================================================================== public API
def load_ledger(
    source: Source,
    mapping: dict[str, str] | None = None,
    chunksize: int = 50_000,
    progress_cb: ProgressCb | None = None,
    sheet: str | None = None,
) -> tuple[pd.DataFrame, LoadReport]:
    """Read a ledger from CSV or Excel in chunks, validate the schema and return a clean DataFrame.

    For Excel pass ``sheet`` to choose a worksheet (default: the one that best matches the ledger schema).
    Raises :class:`SchemaError` (listing the missing columns) when required columns cannot be found.
    """
    kind = detect_kind(source)
    if kind != "csv" and sheet is None:
        sheet = suggest_sheet(source)
    header = read_header(source, sheet)
    mapping = {k: v for k, v in (mapping or suggest_mapping(header)).items() if v in header}
    missing = missing_required(mapping)
    if missing:
        raise SchemaError(missing, header)

    report = LoadReport(mapping=mapping, file_kind=kind, sheet=sheet if kind != "csv" else None)
    wanted = set(mapping.values())
    chunks_iter = (_csv_chunks(source, wanted, chunksize) if kind == "csv"
                   else _excel_chunks(source, sheet, wanted, chunksize))
    chunks: list[pd.DataFrame] = []
    for chunk, frac in chunks_iter:
        report.rows_read += len(chunk)
        chunks.append(_clean_chunk(chunk, mapping))
        if progress_cb:
            progress_cb(report.rows_read, frac)

    if not chunks:
        raise ValueError("The file contains no data rows.")
    df = pd.concat(chunks, ignore_index=True)
    df = _finalise(df, report)
    if report.rows_dropped:
        report.warnings.append(
            f"{report.rows_dropped:,} row(s) dropped (unparseable posting_date or blank entry_id / account_code, "
            "e.g. totals or footer rows).")
    if report.defaulted_columns:
        report.warnings.append("Optional columns not found, defaults applied: "
                               + ", ".join(report.defaulted_columns))
    if hasattr(source, "seek"):
        source.seek(0)
    logger.info("Loaded %s rows from %s%s (%s dropped)", report.rows_loaded, kind,
                f" sheet '{sheet}'" if sheet else "", report.rows_dropped)
    if progress_cb:
        progress_cb(report.rows_read, 1.0)
    return df, report
