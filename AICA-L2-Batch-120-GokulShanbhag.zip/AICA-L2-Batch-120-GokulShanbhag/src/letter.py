"""Structured Management Letter: data model, validation and rendering (Markdown + Word).

The LLM (or the offline template) supplies only *narrative*: summary, observation wording, risk,
recommendations and the entry IDs each observation refers to. Every number, date, amount and
user shown in the letter is pulled from the scored ledger by this module, so figures cannot be
mis-stated by the model.
"""
from __future__ import annotations

import datetime as dt
import io
import re
from dataclasses import dataclass, field

import pandas as pd
from docx import Document
from docx.enum.section import WD_ORIENT  # noqa: F401  (kept for easy landscape switch)
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from .config import DETECTOR_LABELS, DetectorConfig
from .privacy import Pseudonymiser
from .risk_scoring import kpis
from .utils import fmt_inr

PRIORITIES = ("High", "Medium", "Low")
PRIORITY_COLORS = {"High": "C00000", "Medium": "C55A11", "Low": "548235"}
NAVY = "1F3A5F"
MAX_OBSERVATIONS = 8
_STYLE_BAD_SA = re.compile(
    r"\b(breach\w*|contraven\w*|violat\w*|infring\w*)\b[^.;]{0,80}?\bSA\s?-?\d{3}", re.I)
_STYLE_UNITS = re.compile(r"\b(million|billion)\b", re.I)
MAX_ENTRIES_PER_OBSERVATION = 8

_CHAR_FIXES = {"‑": "-", "‐": "-", "‒": "-", " ": " ", " ": " ", " ": " ",
               "​": "", "−": "-", "’": "'", "‘": "'", "“": '"', "”": '"'}


def clean_text(value: object) -> str:
    """Normalise typographic oddities (non-breaking hyphens / spaces) that LLMs like to emit."""
    s = "" if value is None else str(value)
    for bad, good in _CHAR_FIXES.items():
        s = s.replace(bad, good)
    s = re.sub(r"[ \t]{2,}", " ", s)
    s = re.sub(r"(?<=\d) %", "%", s)
    s = re.sub(r"\bdetectors\b", "tests", s, flags=re.I)
    s = re.sub(r"\bdetector\b", "test", s, flags=re.I)
    return s.strip()


def _style_check(label: str, text: str) -> None:
    """Reject wording a Board paper must not contain (the model sees the message and fixes it)."""
    if _STYLE_UNITS.search(text):
        raise ValueError(f"{label}: use Indian units (lakh / crore); never 'million' or 'billion'.")
    if _STYLE_BAD_SA.search(text):
        raise ValueError(f"{label}: do not say a matter breaches / contravenes / violates an auditing standard. "
                         "Say it is 'relevant to' ICAI SA 240 / SA 315 / SA 330 or Sec. 143(3)(i) instead.")


# =============================================================================== data model
@dataclass
class Observation:
    title: str
    observation: str
    entry_ids: list[str] = field(default_factory=list)
    risk_implication: str = ""
    recommendations: list[str] = field(default_factory=list)
    priority: str = "Medium"
    tests: list[str] = field(default_factory=list)                  # detector keys this observation relates to
    also_listed: list[tuple[str, int]] = field(default_factory=list)  # (entry ID, earlier observation number)


@dataclass
class LetterData:
    executive_summary: str
    control_conclusion: str
    observations: list[Observation]
    sod_commentary: str = ""
    closing: str = ""
    source: str = "llm"                # "llm" | "template"
    note: str = ""                     # e.g. why the template was used
    model: str = ""


def normalise_payload(payload: dict, known_ids: set[str]) -> tuple[LetterData, list[str]]:
    """Validate the model's ``submit_management_letter`` arguments.

    Returns ``(LetterData, unknown_entry_ids)``; unknown IDs are dropped from the letter.
    Raises ``ValueError`` with a message the model can act on when required content is missing.
    """
    if not isinstance(payload, dict):
        raise ValueError("Arguments must be a JSON object.")
    summary = clean_text(payload.get("executive_summary"))
    conclusion = clean_text(payload.get("control_conclusion"))
    raw_obs = payload.get("observations")
    if not summary:
        raise ValueError("executive_summary is required.")
    if not isinstance(raw_obs, list) or not raw_obs:
        raise ValueError("observations must be a non-empty array of observation objects.")

    unknown: list[str] = []
    observations: list[Observation] = []
    first_seen: dict[str, int] = {}
    for n_obs, raw in enumerate(raw_obs[:MAX_OBSERVATIONS], start=1):
        if not isinstance(raw, dict):
            raise ValueError("Each observation must be an object with title, observation, entry_ids, "
                             "risk_implication, recommendations and priority.")
        title, text = clean_text(raw.get("title")), clean_text(raw.get("observation"))
        if not title or not text:
            raise ValueError("Every observation needs a non-empty 'title' and 'observation'.")
        ids_in = raw.get("entry_ids") or []
        ids_in = [ids_in] if isinstance(ids_in, str) else list(ids_in)
        ids, also = [], []
        for i in (str(x).strip() for x in ids_in):
            if i in known_ids:
                if i in first_seen and first_seen[i] != n_obs:      # listed once, cross-referenced afterwards
                    also.append((i, first_seen[i]))
                elif i not in ids:
                    ids.append(i)
                    first_seen[i] = n_obs
            elif i:
                unknown.append(i)
        recs = raw.get("recommendations", raw.get("recommendation", []))
        recs = [recs] if isinstance(recs, str) else list(recs or [])
        priority = str(raw.get("priority", "Medium")).strip().title()
        tests_in = raw.get("tests") or []
        tests = [t for t in ([tests_in] if isinstance(tests_in, str) else list(tests_in)) if t in DETECTOR_LABELS]
        obs = Observation(
            title=title, observation=text, entry_ids=ids[:MAX_ENTRIES_PER_OBSERVATION],
            risk_implication=clean_text(raw.get("risk_implication")),
            recommendations=[clean_text(r) for r in recs if clean_text(r)],
            priority=priority if priority in PRIORITIES else "Medium", tests=tests, also_listed=also)
        for label, value in ((f"Observation {n_obs} title", obs.title), (f"Observation {n_obs} text", obs.observation),
                             (f"Observation {n_obs} risk_implication", obs.risk_implication),
                             *[(f"Observation {n_obs} recommendation", r) for r in obs.recommendations]):
            _style_check(label, value)
        observations.append(obs)
    narrative = {"executive_summary": summary, "control_conclusion": conclusion,
                 "sod_commentary": clean_text(payload.get("sod_commentary")),
                 "closing": clean_text(payload.get("closing"))}
    for label, value in narrative.items():
        _style_check(label, value)
    return LetterData(
        executive_summary=summary, control_conclusion=conclusion, observations=observations,
        sod_commentary=clean_text(payload.get("sod_commentary")), closing=clean_text(payload.get("closing")),
    ), sorted(set(unknown))


# =============================================================================== context (facts from the ledger)
def sod_breakdown(results: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """Boolean masks: manual entries with no approver / self-approved by the poster."""
    approver = results["approved_by"].astype(str).str.strip()
    no_appr = results["is_manual_like"] & approver.str.lower().isin(["", "nan", "none", "null", "na", "n/a"])
    self_appr = results["is_manual_like"] & ~no_appr & (approver.str.lower() == results["posted_by"].str.lower())
    return no_appr, self_appr


@dataclass
class LetterContext:
    entity: str
    period_label: str
    results: pd.DataFrame
    pseudo: Pseudonymiser
    cfg: DetectorConfig
    reveal: bool = False
    date_str: str = field(default_factory=lambda: f"{dt.date.today():%d %B %Y}")

    # ---- display helpers
    def user(self, name: object) -> str:
        s = "" if name is None else str(name)
        return s if self.reveal else self.pseudo.mask(s)

    def text(self, value: object) -> str:
        s = clean_text(value)
        return self.pseudo.unmask_text(s) if self.reveal else s

    # ---- facts
    @property
    def kpi(self) -> dict:
        return kpis(self.results)

    def sod_rows(self) -> list[tuple[str, int, float]]:
        r = self.results
        no_appr, self_appr = sod_breakdown(r)
        items = [
            ("Entries flagged as manual overrides", r["is_manual_override"] == "Y"),
            ("Manual entries with no approver", no_appr),
            ("Manual entries approved by the person who posted them", self_appr),
            ("Manual postings on weekends / public holidays", r["flag_weekend_holiday"]),
            ("Manual postings after hours", r["flag_after_hours"]),
        ]
        return [(label, int(mask.sum()), float(r.loc[mask, "amount"].sum())) for label, mask in items]

    def sod_top_users(self, n: int = 5) -> list[tuple[str, int, int, float]]:
        r = self.results
        no_appr, self_appr = sod_breakdown(r)
        frame = pd.DataFrame({"user": r["posted_by"], "no": no_appr, "self": self_appr, "amount": r["amount"]})
        frame = frame[frame["no"] | frame["self"]]
        if frame.empty:
            return []
        g = frame.groupby("user").agg(no=("no", "sum"), self_=("self", "sum"), amount=("amount", "sum"))
        g["total"] = g["no"] + g["self_"]
        g = g.sort_values(["total", "amount"], ascending=False).head(n)
        return [(self.user(u), int(row.no), int(row.self_), float(row.amount)) for u, row in g.iterrows()]

    def entry_rows(self, ids: list[str]) -> list[list[str]]:
        """Table rows for entry IDs, taken from the ledger (date / amount / users are never LLM-generated)."""
        r = self.results
        out = []
        for entry_id in ids:
            sub = r[r["entry_id"] == entry_id]
            if sub.empty:
                continue
            row = sub.iloc[0]
            out.append([
                entry_id, f"{pd.Timestamp(row['posting_date']):%d-%b-%Y}",
                f"{row['account_code']} {row['account_name']}", fmt_inr(row["amount"], 0),
                self.user(row["posted_by"]) or "-", self.user(row["approved_by"]) or "(none)",
                f"{row['risk_score']:.0f}"])
        return out

    def tests_summary(self, tests: list[str]) -> tuple[int, float, str] | None:
        """Ledger-wide count / value of entries that trigger any of the given tests (computed, not LLM-written)."""
        keys = [t for t in tests if f"flag_{t}" in self.results.columns]
        if not keys:
            return None
        mask = self.results[[f"flag_{t}" for t in keys]].any(axis=1)
        return int(mask.sum()), float(self.results.loc[mask, "amount"].sum()), "; ".join(DETECTOR_LABELS[t] for t in keys)

    def ledger_wide_line(self, o: "Observation") -> str:
        s = self.tests_summary(o.tests)
        if not s:
            return ""
        return f"{s[0]:,} entries across the whole ledger (value {fmt_inr(s[1], 0)}) triggered: {s[2]}."

    def entries_value(self, ids: list[str]) -> float:
        return float(self.results.loc[self.results["entry_id"].isin(ids), "amount"].sum())


def make_context(results: pd.DataFrame, pseudo: Pseudonymiser, cfg: DetectorConfig, entity: str,
                 period_label: str, reveal: bool = False) -> LetterContext:
    return LetterContext(entity=entity, period_label=period_label, results=results, pseudo=pseudo, cfg=cfg,
                         reveal=reveal)


ENTRY_HEADERS = ["Entry ID", "Posted on", "Account", "Amount", "Posted by", "Approved by", "Score"]
BASIS_STANDARDS = ("The matters in this letter are relevant to ICAI SA 240 (the auditor's responsibilities relating to fraud, "
                   "including management override of controls), SA 315 (identifying and assessing risks), SA 330 "
                   "(responses to assessed risks) and Section 143(3)(i) of the Companies Act, 2013 (internal "
                   "financial controls over financial reporting).")


def _intro(ctx: LetterContext) -> str:
    k = ctx.kpi
    return (f"We have carried out an analytical review of the general-ledger journal entries of {ctx.entity} for "
            f"{ctx.period_label}. Our automated analytics tested 100% of the {k['total_entries']:,} entries "
            f"(total value {fmt_inr(k['total_value'], 0)}) against twelve risk tests. This letter sets out the matters "
            "that, in our view, require management's attention, with our recommendations. It is based on "
            "analytics of the ledger extract provided and is issued for discussion; it is not an audit opinion.")


def _basis_bullets(ctx: LetterContext) -> list[str]:
    c = ctx.cfg
    return [
        "Tests applied: " + "; ".join(DETECTOR_LABELS.values()) + ".",
        f"Key parameters: approval limit {fmt_inr(c.threshold_amount, 0)} (just-below band {c.threshold_band_pct:g}%); "
        f"round-figure unit {fmt_inr(c.round_unit, 0)}; after-hours window {c.after_hours_start:02d}:00-"
        f"{c.after_hours_end:02d}:00; back-dating beyond {c.backdate_days} days; statistical outliers beyond "
        f"{c.zscore_cutoff:g} standard deviations (and the IQR fence) per account.",
        f"Risk scoring: each test carries a weight; the score (0-100) bands are Extreme >= {c.extreme_min_score:g}, "
        f"High >= {c.high_min_score:g}, Medium >= {c.medium_min_score:g}, otherwise Low.",
        BASIS_STANDARDS,
        "All amounts are in Indian rupees. Entry details, dates, amounts and figures in this letter are taken "
        "directly from the ledger by the system; observation wording and recommendations are draft narrative "
        "for the engagement team to review.",
    ]


def _provenance(ld: LetterData) -> str:
    if ld.source == "llm":
        return ("Draft - narrative prepared with AI assistance" + (f" ({ld.model})" if ld.model else "")
                + "; figures and entry details generated from the ledger. To be reviewed before issue.")
    return "Draft - narrative generated from a fixed template without an LLM" + (
        f" ({ld.note})" if ld.note else "") + "; figures and entry details generated from the ledger."


# =============================================================================== Markdown rendering
def _md_table(header: list[str], rows: list[list[str]]) -> list[str]:
    esc = lambda v: str(v).replace("|", "/")  # noqa: E731
    return (["| " + " | ".join(esc(h) for h in header) + " |", "|" + "|".join("---" for _ in header) + "|"]
            + ["| " + " | ".join(esc(c) for c in row) + " |" for row in rows] + [""])


def render_markdown(ld: LetterData, ctx: LetterContext) -> str:
    k = ctx.kpi
    L: list[str] = [
        "# MANAGEMENT LETTER - DRAFT FOR DISCUSSION", "",
        f"**Entity:** {ctx.entity}  ", f"**Period reviewed:** {ctx.period_label}  ", f"**Date:** {ctx.date_str}  ",
        "**Status:** Draft - for discussion with management", "", f"> {_provenance(ld)}", "",
        "To: The Board of Directors and the Audit Committee", "", "Dear Members,", "", _intro(ctx), "",
        "## 1. Executive summary", "", ctx.text(ld.executive_summary), "",
    ]
    L += _md_table(["Key figure", "Value"], [
        ["Journal entries tested", f"{k['total_entries']:,} (100%)"],
        ["Total value of entries", fmt_inr(k["total_value"], 0)],
        ["Entries flagged by at least one test", f"{k['flagged_entries']:,} ({k['flagged_pct']:.1f}%)"],
        ["Extreme-risk entries", f"{k['extreme_count']:,}"], ["High-risk entries", f"{k['high_count']:,}"],
        ["Value of High and Extreme entries", fmt_inr(k["value_at_risk"], 0)],
    ])
    if ld.control_conclusion:
        L += ["**Overall conclusion on controls:** " + ctx.text(ld.control_conclusion), ""]
    L += ["## 2. Summary of observations", ""]
    if ld.observations:
        L += _md_table(["#", "Observation", "Priority", "Entries listed"],
                       [[str(i), ctx.text(o.title), o.priority, str(len(o.entry_ids))]
                        for i, o in enumerate(ld.observations, 1)])
    else:
        L += ["No material exceptions to report.", ""]
    L += ["## 3. Detailed observations", ""]
    for i, o in enumerate(ld.observations, 1):
        L += [f"### Observation {i}: {ctx.text(o.title)}", "", f"**Priority:** {o.priority}", "",
              f"**Observation:** {ctx.text(o.observation)}", ""]
        if ctx.ledger_wide_line(o):
            L += [f"**Ledger-wide result:** {ctx.ledger_wide_line(o)}", ""]
        if o.entry_ids:
            L += [f"**Entries affected** ({len(o.entry_ids)} listed, combined value "
                  f"{fmt_inr(ctx.entries_value(o.entry_ids), 0)}):", ""]
            L += _md_table(ENTRY_HEADERS, ctx.entry_rows(o.entry_ids))
        if o.also_listed:
            L += ["**Also relevant:** " + "; ".join(f"{i} (see Observation {n})" for i, n in o.also_listed), ""]
        if o.risk_implication:
            L += [f"**Risk / implication:** {ctx.text(o.risk_implication)}", ""]
        if o.recommendations:
            L += ["**Recommendation:**", ""] + [f"- {ctx.text(r)}" for r in o.recommendations] + [""]
        L += ["**Management response:** [To be completed by management]  ",
              "**Responsible person / target date:** [To be completed by management]", ""]
    L += ["## 4. Segregation of duties and system-override controls", ""]
    L += _md_table(["Measure", "Entries", "Value"], [[lab, f"{n:,}", fmt_inr(v, 0)] for lab, n, v in ctx.sod_rows()])
    top = ctx.sod_top_users()
    if top:
        L += ["**Users with the most unapproved or self-approved manual entries:**", ""]
        L += _md_table(["User", "No approver", "Self-approved", "Value"],
                       [[u, str(a), str(b), fmt_inr(v, 0)] for u, a, b, v in top])
    if ld.sod_commentary:
        L += [ctx.text(ld.sod_commentary), ""]
    L += ["## 5. Basis of preparation and limitations", ""] + [f"- {b}" for b in _basis_bullets(ctx)] + [""]
    L += ["## 6. Closing", "", ctx.text(ld.closing) or (
        "We would be pleased to discuss these matters with the Board and the Audit Committee and to support "
        "management in implementing the recommendations."), "", "Yours faithfully,  ",
        "[Name and designation - to be completed]  ", "[Internal Audit / Engagement team]", ""]
    return "\n".join(L)


# =============================================================================== Word rendering
def _shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def _table_borders(table, color: str = "BFC5CE") -> None:
    tbl_pr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tbl_pr.append(borders)


def _cell_margins(table, top=40, bottom=40, left=80, right=80) -> None:
    tbl_pr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for side, val in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:w"), str(val))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tbl_pr.append(mar)


def _row_flags(row, header: bool = False) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant = OxmlElement("w:cantSplit")
    cant.set(qn("w:val"), "true")
    tr_pr.append(cant)
    if header:
        th = OxmlElement("w:tblHeader")
        th.set(qn("w:val"), "true")
        tr_pr.append(th)


def _write_cell(cell, text: str, *, bold=False, size=9, color: str | None = None, align=None, italic=False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    if align:
        p.alignment = align
    run = p.add_run(text)
    run.bold, run.italic, run.font.size = bold, italic, Pt(size)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _table(doc, header: list[str], rows: list[list[str]], widths_cm: list[float], *, size=9,
           right_cols: tuple[int, ...] = (), key_col: bool = False):
    table = doc.add_table(rows=1 + len(rows), cols=len(header))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    _table_borders(table)
    _cell_margins(table)
    for c, h in enumerate(header):
        _write_cell(table.cell(0, c), h, bold=True, size=size, color="FFFFFF",
                    align=WD_ALIGN_PARAGRAPH.RIGHT if c in right_cols else None)
        _shade(table.cell(0, c), NAVY)
    _row_flags(table.rows[0], header=True)
    for r, row in enumerate(rows, start=1):
        _row_flags(table.rows[r])
        for c, val in enumerate(row):
            _write_cell(table.cell(r, c), str(val), size=size, bold=(key_col and c == 0),
                        align=WD_ALIGN_PARAGRAPH.RIGHT if c in right_cols else None)
            if r % 2 == 0:
                _shade(table.cell(r, c), "F3F6FA")
    for row in table.rows:
        for c, w in enumerate(widths_cm):
            row.cells[c].width = Cm(w)
    return table


def _kv_table(doc, rows: list[tuple[str, str]], widths_cm=(4.2, 12.8)):
    table = doc.add_table(rows=len(rows), cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    _table_borders(table)
    _cell_margins(table)
    for r, (k, v) in enumerate(rows):
        _write_cell(table.cell(r, 0), k, bold=True, size=10, color=NAVY)
        _shade(table.cell(r, 0), "E8EEF6")
        _write_cell(table.cell(r, 1), v, size=10)
        _row_flags(table.rows[r])
        for c, w in enumerate(widths_cm):
            table.cell(r, c).width = Cm(w)
    return table


def _field(paragraph, instr: str) -> None:
    run = paragraph.add_run()
    for tag, text in (("begin", None), (None, instr), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = text
        run._r.append(el)
    run.font.size = Pt(8.5)


def _bottom_rule(paragraph, color: str = NAVY, size: int = 12) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(size))
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color)
    borders.append(bottom)
    p_pr.append(borders)


def _setup_document(entity: str) -> Document:
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.top_margin, sec.bottom_margin = Cm(2.2), Cm(2.0)
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "Calibri", Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.08
    for name, size, before in (("Heading 1", 14, 16), ("Heading 2", 12, 12), ("Heading 3", 11, 8)):
        st = doc.styles[name]
        st.font.name, st.font.size, st.font.bold = "Calibri", Pt(size), True
        st.font.color.rgb = RGBColor.from_string(NAVY)
        st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
        st.paragraph_format.space_before, st.paragraph_format.space_after = Pt(before), Pt(4)
        st.paragraph_format.keep_with_next = True
    hp = sec.header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = hp.add_run("STRICTLY PRIVATE & CONFIDENTIAL  |  DRAFT FOR DISCUSSION")
    run.font.size, run.bold = Pt(8.5), True
    run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)
    fp = sec.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run(f"{entity}  |  Management Letter  |  Page ")
    r.font.size = Pt(8.5)
    _field(fp, "PAGE")
    r = fp.add_run(" of ")
    r.font.size = Pt(8.5)
    _field(fp, "NUMPAGES")
    return doc


def _para(doc, text: str = "", *, bold_prefix: str = "", size: float | None = None, italic=False,
          color: str | None = None, space_after: float | None = None, align=None):
    p = doc.add_paragraph()
    if bold_prefix:
        r = p.add_run(bold_prefix + " ")
        r.bold = True
        if size:
            r.font.size = Pt(size)
    r = p.add_run(text)
    r.italic = italic
    if size:
        r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    if align:
        p.alignment = align
    return p


def build_letter_docx(ld: LetterData, ctx: LetterContext) -> bytes:
    """Render the structured letter as a formatted, submission-ready Word document."""
    doc = _setup_document(ctx.entity)
    k = ctx.kpi

    # ---- title block
    t = _para(doc, "MANAGEMENT LETTER", size=24, space_after=0)
    t.runs[0].bold = True
    t.runs[0].font.color.rgb = RGBColor.from_string(NAVY)
    sub = _para(doc, "Review of journal entries, anomalies and system overrides", size=12, color="6B7280",
                space_after=8)
    _bottom_rule(sub)
    _kv_table(doc, [
        ("Entity", ctx.entity), ("Period reviewed", ctx.period_label), ("Date", ctx.date_str),
        ("Status", "Draft - for discussion with management"),
        ("Scope", f"100% of journal entries ({k['total_entries']:,} entries) - automated analytics"),
        ("Prepared by", "[Name / designation - to be completed]"),
    ])
    _para(doc, "", space_after=4)
    _para(doc, "The Board of Directors and the Audit Committee", bold_prefix="To:", space_after=2)
    _para(doc, f"Journal-entry anomalies and system-override controls - {ctx.entity}", bold_prefix="Subject:")
    _para(doc, "Dear Members,")
    _para(doc, _intro(ctx))

    # ---- 1. executive summary
    doc.add_heading("1. Executive summary", level=1)
    _para(doc, ctx.text(ld.executive_summary))
    kt = _table(doc, ["Key figure", "Value", "Key figure", "Value"], [
        ["Entries tested", f"{k['total_entries']:,}", "Extreme-risk entries", f"{k['extreme_count']:,}"],
        ["Total value", fmt_inr(k["total_value"], 0), "High-risk entries", f"{k['high_count']:,}"],
        ["Entries flagged", f"{k['flagged_entries']:,} ({k['flagged_pct']:.1f}%)", "High + Extreme value",
         fmt_inr(k["value_at_risk"], 0)],
    ], [3.4, 5.2, 3.9, 4.5], size=9.5)
    for row in kt.rows[1:]:
        for c in (0, 2):
            row.cells[c].paragraphs[0].runs[0].bold = True
    _para(doc, "", space_after=2)
    if ld.control_conclusion:
        _para(doc, ctx.text(ld.control_conclusion), bold_prefix="Overall conclusion on controls:")

    # ---- 2. summary of observations
    doc.add_heading("2. Summary of observations", level=1)
    if ld.observations:
        st = _table(doc, ["#", "Observation", "Priority", "Entries listed"],
                    [[str(i), ctx.text(o.title), o.priority, str(len(o.entry_ids))]
                     for i, o in enumerate(ld.observations, 1)], [1.0, 10.8, 2.6, 2.6], size=9.5)
        for r, o in enumerate(ld.observations, start=1):
            run = st.cell(r, 2).paragraphs[0].runs[0]
            run.bold = True
            run.font.color.rgb = RGBColor.from_string(PRIORITY_COLORS[o.priority])
    else:
        _para(doc, "No material exceptions to report.")

    # ---- 3. detailed observations
    doc.add_heading("3. Detailed observations", level=1)
    for i, o in enumerate(ld.observations, 1):
        doc.add_heading(f"Observation {i}: {ctx.text(o.title)}", level=2)
        pp = _para(doc, o.priority, bold_prefix="Priority:", space_after=4)
        pp.runs[-1].bold = True
        pp.runs[-1].font.color.rgb = RGBColor.from_string(PRIORITY_COLORS[o.priority])
        pp.paragraph_format.keep_with_next = True
        _para(doc, ctx.text(o.observation), bold_prefix="Observation:").paragraph_format.keep_with_next = True
        if ctx.ledger_wide_line(o):
            _para(doc, ctx.ledger_wide_line(o), bold_prefix="Ledger-wide result:").paragraph_format.keep_with_next = True
        if o.entry_ids:
            rows = ctx.entry_rows(o.entry_ids)
            lead = _para(doc, f"{len(rows)} listed; combined value {fmt_inr(ctx.entries_value(o.entry_ids), 0)}",
                         bold_prefix="Entries affected:", space_after=3)
            lead.paragraph_format.keep_with_next = True
            _table(doc, ENTRY_HEADERS, rows, [2.3, 2.2, 4.1, 3.0, 2.2, 2.2, 1.0], size=8.5, right_cols=(3, 6))
            _para(doc, "", space_after=2)
        if o.also_listed:
            _para(doc, "; ".join(f"{i} (see Observation {n})" for i, n in o.also_listed), bold_prefix="Also relevant:",
                  size=9.5)
        if o.risk_implication:
            _para(doc, ctx.text(o.risk_implication), bold_prefix="Risk / implication:")
        if o.recommendations:
            _para(doc, "", bold_prefix="Recommendation:", space_after=2).paragraph_format.keep_with_next = True
            for rec in o.recommendations:
                bp = doc.add_paragraph(style="List Bullet")
                bp.add_run(ctx.text(rec))
                bp.paragraph_format.space_after = Pt(2)
        box = doc.add_table(rows=1, cols=1)
        box.alignment = WD_TABLE_ALIGNMENT.CENTER
        _table_borders(box, "E0B84C")
        _cell_margins(box, 60, 60, 100, 100)
        cell = box.cell(0, 0)
        cell.width = Cm(17.0)
        _shade(cell, "FFF8E1")
        cell.text = ""
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        rr = p.add_run("Management response: ")
        rr.bold, rr.font.size = True, Pt(9.5)
        rr = p.add_run("[To be completed by management]")
        rr.italic, rr.font.size = True, Pt(9.5)
        p2 = cell.add_paragraph()
        p2.paragraph_format.space_after = Pt(0)
        rr = p2.add_run("Responsible person: ____________________      Target date: ____________")
        rr.font.size = Pt(9.5)
        _row_flags(box.rows[0])
        _para(doc, "", space_after=4)

    # ---- 4. SoD & overrides
    doc.add_heading("4. Segregation of duties and system-override controls", level=1)
    _table(doc, ["Measure", "Entries", "Value"],
           [[lab, f"{n:,}", fmt_inr(v, 0)] for lab, n, v in ctx.sod_rows()], [10.2, 2.6, 4.2], size=9.5,
           right_cols=(1, 2))
    _para(doc, "", space_after=4)
    top = ctx.sod_top_users()
    if top:
        _para(doc, "", bold_prefix="Users with the most unapproved or self-approved manual entries:",
              space_after=3).paragraph_format.keep_with_next = True
        _table(doc, ["User", "No approver", "Self-approved", "Value"],
               [[u, str(a), str(b), fmt_inr(v, 0)] for u, a, b, v in top], [6.0, 3.2, 3.6, 4.2], size=9.5,
               right_cols=(1, 2, 3))
        _para(doc, "", space_after=4)
    if ld.sod_commentary:
        _para(doc, ctx.text(ld.sod_commentary))

    # ---- 5. basis
    doc.add_heading("5. Basis of preparation and limitations", level=1)
    for b in _basis_bullets(ctx):
        bp = doc.add_paragraph(style="List Bullet")
        r = bp.add_run(b)
        r.font.size = Pt(9.5)
        bp.paragraph_format.space_after = Pt(2)

    # ---- 6. closing
    doc.add_heading("6. Closing", level=1)
    _para(doc, ctx.text(ld.closing) or (
        "We would be pleased to discuss these matters with the Board and the Audit Committee and to support "
        "management in implementing the recommendations."))
    _para(doc, "Yours faithfully,", space_after=22)
    _para(doc, "[Name and designation - to be completed]", space_after=0)
    _para(doc, "[Internal Audit / Engagement team]", space_after=10)
    _para(doc, _provenance(ld), size=8.5, italic=True, color="6B7280")

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
