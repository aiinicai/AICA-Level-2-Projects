"""Python functions exposed to the LLM as tools, plus their JSON schemas.

The model never sees the raw ledger: it can only ask these tools questions. All personal names
are pseudonymised (USER_nn) on the way out and resolved locally on the way in.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Callable

import numpy as np
import pandas as pd

from .config import DETECTOR_LABELS, DetectorConfig
from .detectors import benford_stats
from .letter import LetterData, normalise_payload
from .privacy import Pseudonymiser
from .risk_scoring import detector_counts, kpis, top_extreme
from .utils import clip_text, fmt_inr

logger = logging.getLogger(__name__)

MAX_ROWS_PER_CALL = 50


class ToolError(Exception):
    """A recoverable problem with a tool call; the message is returned to the model."""


def _py(obj: Any) -> Any:
    """Recursively convert numpy / pandas scalars to JSON-safe Python values."""
    if isinstance(obj, dict):
        return {str(k): _py(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_py(v) for v in obj]
    if isinstance(obj, (pd.Timestamp, np.datetime64)):
        return pd.Timestamp(obj).strftime("%Y-%m-%d")
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, (np.floating, float)):
        return None if np.isnan(obj) else round(float(obj), 2)
    if isinstance(obj, np.bool_):
        return bool(obj)
    if obj is pd.NA or obj is pd.NaT:
        return None
    return obj


TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "summarise_flag_counts",
        "description": ("Headline statistics: entries scanned, total value, flagged entries, count of "
                        "entries per severity band, flag counts per detector and the riskiest users. "
                        "Call this first to understand the overall picture."),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_extreme_anomalies",
        "description": ("The highest-risk journal entries (severity 'Extreme'), ranked by risk score. "
                        "Each item lists amount, user, approver, posting date/time, the detectors that "
                        "fired and the reasons."),
        "input_schema": {
            "type": "object",
            "properties": {"top_n": {"type": "integer", "description": "How many entries to return (1-50).",
                                     "minimum": 1, "maximum": MAX_ROWS_PER_CALL}},
            "required": [],
        },
    },
    {
        "name": "get_entry_details",
        "description": ("Full details of one journal entry by entry_id, including every detector reason "
                        "and how the amount compares with the account's normal range."),
        "input_schema": {
            "type": "object",
            "properties": {"entry_id": {"type": "string", "description": "e.g. JE-000123"}},
            "required": ["entry_id"],
        },
    },
    {
        "name": "get_user_activity_profile",
        "description": ("Posting behaviour of one (pseudonymised) user: volumes, manual / override / "
                        "weekend / night share, self-approvals, flagged and extreme entries, usual accounts."),
        "input_schema": {
            "type": "object",
            "properties": {"user": {"type": "string", "description": "A pseudonym such as USER_07."}},
            "required": ["user"],
        },
    },
    {
        "name": "get_account_statistics",
        "description": ("Statistics for a GL account: count, total, mean, median, 95th percentile, maximum, "
                        "Benford's-law result, flagged entries and monthly totals."),
        "input_schema": {
            "type": "object",
            "properties": {"account_code": {"type": "string", "description": "e.g. 6004"}},
            "required": ["account_code"],
        },
    },
    {
        "name": "compare_to_peer_period",
        "description": ("Compare an account's activity in one period (YYYY-MM) with its other periods: "
                        "total, count, variance vs the prior three months and the largest entries."),
        "input_schema": {
            "type": "object",
            "properties": {"account_code": {"type": "string"},
                           "period": {"type": "string", "description": "Month in YYYY-MM format."}},
            "required": ["account_code", "period"],
        },
    },
]

SUBMIT_LETTER_SCHEMA: dict[str, Any] = {
    "name": "submit_management_letter",
    "description": ("Submit the final Management Letter content. Call this exactly once, after investigating. "
                    "The system fills in all figures, dates, amounts and entry tables from the ledger, so give "
                    "entry IDs only (taken from tool results) and do not quote statistics you did not read from a tool."),
    "input_schema": {
        "type": "object",
        "properties": {
            "executive_summary": {"type": "string", "description": "2-4 sentences for the Board: what was tested "
                                  "and the main matters found. Qualitative; the figures table is added by the system."},
            "control_conclusion": {"type": "string", "description": "1-2 sentences: overall view of the "
                                   "journal-entry control environment."},
            "observations": {
                "type": "array", "description": "4-7 observations, grouping related entries.",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Short title, e.g. 'Manual overrides without independent approval'."},
                        "observation": {"type": "string", "description": "2-4 sentences describing what was found. "
                                        "Use only facts from the tools; amounts in lakh / crore."},
                        "entry_ids": {"type": "array", "items": {"type": "string"},
                                      "description": "Up to 8 entry IDs (from tool results) that illustrate this observation."},
                        "risk_implication": {"type": "string", "description": "1-3 sentences on the risk."},
                        "recommendations": {"type": "array", "items": {"type": "string"},
                                            "description": "2-4 specific, actionable recommendations."},
                        "priority": {"type": "string", "enum": ["High", "Medium", "Low"]},
                        "tests": {"type": "array", "description": "Which tests this observation relates to; the "
                                  "system adds the ledger-wide count and value for them.",
                                  "items": {"type": "string", "enum": list(DETECTOR_LABELS)}},
                    },
                    "required": ["title", "observation", "entry_ids", "risk_implication", "recommendations", "priority", "tests"],
                },
            },
            "sod_commentary": {"type": "string", "description": "2-4 sentences on segregation of duties and "
                               "system-override controls, with recommendations."},
            "closing": {"type": "string", "description": "One short closing paragraph."},
        },
        "required": ["executive_summary", "control_conclusion", "observations", "sod_commentary"],
    },
}
TOOL_SCHEMAS.append(SUBMIT_LETTER_SCHEMA)


class LedgerToolbox:
    """Executes tool calls against the scored ledger DataFrame."""

    def __init__(self, results: pd.DataFrame, cfg: DetectorConfig, pseudo: Pseudonymiser,
                 entity: str = "the Company", default_top_n: int = 25):
        self.results = results
        self.cfg = cfg
        self.pseudo = pseudo
        self.entity = entity
        self.default_top_n = default_top_n
        self.seen_entry_ids: set[str] = set()
        self.submitted: LetterData | None = None          # set when the model calls submit_management_letter
        self.unknown_entry_ids: list[str] = []
        self._dispatch: dict[str, Callable[..., dict]] = {
            "summarise_flag_counts": self.summarise_flag_counts,
            "get_extreme_anomalies": self.get_extreme_anomalies,
            "get_entry_details": self.get_entry_details,
            "get_user_activity_profile": self.get_user_activity_profile,
            "get_account_statistics": self.get_account_statistics,
            "compare_to_peer_period": self.compare_to_peer_period,
            "submit_management_letter": self.submit_management_letter,
        }

    # ------------------------------------------------------------------ dispatch
    @property
    def schemas(self) -> list[dict[str, Any]]:
        return TOOL_SCHEMAS

    def call(self, name: str, arguments: dict[str, Any] | None) -> dict[str, Any]:
        """Run a tool by name. Raises :class:`ToolError` for bad names / arguments / lookups."""
        fn = self._dispatch.get(name)
        if fn is None:
            raise ToolError(f"Unknown tool '{name}'. Available: {', '.join(self._dispatch)}")
        try:
            return _py(fn(**(arguments or {})))
        except TypeError as exc:                         # wrong / missing arguments
            raise ToolError(f"Bad arguments for {name}: {exc}") from exc

    @property
    def period_range(self) -> tuple[str, str]:
        return str(self.results["period"].min()), str(self.results["period"].max())

    @property
    def extreme_count(self) -> int:
        return int((self.results["severity"] == "Extreme").sum())

    # ------------------------------------------------------------------ helpers
    def _entry(self, row: pd.Series, detail: bool = False) -> dict[str, Any]:
        """Compact JSON-ready view of one entry (``detail=True`` adds narration and per-detector reasons)."""
        self.seen_entry_ids.add(str(row["entry_id"]))
        reasons = [f"{DETECTOR_LABELS[d]}: {self.pseudo.mask_text(row[f'why_{d}'])}"
                   for d in DETECTOR_LABELS if row[f"flag_{d}"]]
        item: dict[str, Any] = {
            "entry_id": row["entry_id"],
            "posted": f"{pd.Timestamp(row['posting_date']):%d-%b-%Y (%a)} {str(row['posting_time'])[:5]}",
            "account": f"{row['account_code']} {row['account_name']}",
            "amount_inr": fmt_inr(row["amount"], 0), "type": row["entry_type"],
            "override": row["is_manual_override"],
            "posted_by": self.pseudo.mask(row["posted_by"]),
            "approved_by": self.pseudo.mask(row["approved_by"]) or "(none)",
            "score": row["risk_score"], "severity": str(row["severity"]),
        }
        if detail:
            item["description"] = self.pseudo.mask_text(clip_text(row["description"], 80))
            item["document_date"] = row["document_date"]
            item["debit_inr"], item["credit_inr"] = fmt_inr(row["debit"], 0), fmt_inr(row["credit"], 0)
            item["findings"] = reasons
        else:
            item["findings"] = clip_text("; ".join(reasons), 260)
        return item

    def _account(self, account_code: str) -> pd.DataFrame:
        sub = self.results[self.results["account_code"] == str(account_code).strip()]
        if sub.empty:
            known = ", ".join(sorted(self.results["account_code"].unique())[:25])
            raise ToolError(f"Account '{account_code}' not found. Known accounts include: {known}")
        return sub

    # ------------------------------------------------------------------ tools
    def submit_management_letter(self, **payload: Any) -> dict[str, Any]:
        """Validate and store the structured letter (ends the agent loop)."""
        known = set(self.results["entry_id"].astype(str))
        try:
            letter, unknown = normalise_payload(payload, known)
        except ValueError as exc:
            raise ToolError(str(exc)) from exc
        self.submitted, self.unknown_entry_ids = letter, unknown
        return {"status": "accepted", "observations": len(letter.observations),
                "entry_ids_not_found_and_removed": unknown}

    def summarise_flag_counts(self) -> dict[str, Any]:
        res = self.results
        users = (res[res["is_flagged"]].groupby("posted_by")["risk_score"].sum()
                 .sort_values(ascending=False).head(5))
        counts = detector_counts(res)
        return {
            "entity": self.entity, "period_range": self.period_range, **kpis(res),
            "thresholds": {
                "approval_limit_inr": fmt_inr(self.cfg.threshold_amount, 0),
                "round_figure_unit_inr": fmt_inr(self.cfg.round_unit, 0),
                "after_hours_window": f"{self.cfg.after_hours_start:02d}:00-{self.cfg.after_hours_end:02d}:00",
                "back_dated_after_days": self.cfg.backdate_days,
                "outlier_z_cutoff": self.cfg.zscore_cutoff,
            },
            "total_value_inr": fmt_inr(res["amount"].sum(), 0),
            "value_at_risk_inr": fmt_inr(kpis(res)["value_at_risk"], 0),
            "severity_counts": res["severity"].astype(str).value_counts().to_dict(),
            "detector_counts": {r.label: {"entries": r.flagged_entries, "value_inr": fmt_inr(r.flagged_value, 0)}
                                for r in counts.itertuples() if r.flagged_entries},
            "top_users_by_risk": {self.pseudo.mask(u): float(s) for u, s in users.items()},
        }

    def get_extreme_anomalies(self, top_n: int | None = None) -> dict[str, Any]:
        n = int(top_n or self.default_top_n)
        n = max(1, min(n, MAX_ROWS_PER_CALL))
        ext = top_extreme(self.results, n)
        return {"extreme_total": self.extreme_count, "returned": len(ext),
                "entries": [self._entry(r) for _, r in ext.iterrows()]}

    def get_entry_details(self, entry_id: str) -> dict[str, Any]:
        sub = self.results[self.results["entry_id"] == str(entry_id).strip()]
        if sub.empty:
            raise ToolError(f"Entry '{entry_id}' not found.")
        out = []
        for _, row in sub.head(10).iterrows():
            acct = self.results.loc[self.results["account_code"] == row["account_code"], "amount"]
            item = self._entry(row, detail=True)
            item["account_context"] = {
                "entries": len(acct), "median_inr": fmt_inr(acct.median(), 0),
                "p95_inr": fmt_inr(acct.quantile(0.95), 0),
                "times_median": round(float(row["amount"] / acct.median()), 1) if acct.median() else None,
            }
            out.append(item)
        return {"lines": len(sub), "entries": out}

    def get_user_activity_profile(self, user: str) -> dict[str, Any]:
        real = self.pseudo.resolve(user)
        if real is None:
            raise ToolError(f"Unknown user '{user}'. Use a pseudonym such as USER_01 returned by other tools.")
        sub = self.results[self.results["posted_by"] == real]
        if sub.empty:
            approved = int((self.results["approved_by"] == real).sum())
            if approved:
                raise ToolError(f"{user} posted no entries but approved {approved:,} entries (approver only).")
            raise ToolError(f"No entries posted by '{user}'.")
        weekend = sub["posting_date"].dt.dayofweek >= 5
        night = sub["flag_after_hours"]
        approvers = sub["approved_by"].map(self.pseudo.mask).value_counts().head(5).to_dict()
        ext = sub[sub["severity"] == "Extreme"].sort_values("risk_score", ascending=False)
        return {
            "user": self.pseudo.mask(real), "entries": len(sub), "total_value_inr": fmt_inr(sub["amount"].sum(), 0),
            "manual_entries": int(sub["is_manual_like"].sum()),
            "override_entries": int((sub["is_manual_override"] == "Y").sum()),
            "weekend_entries": int(weekend.sum()), "after_hours_entries": int(night.sum()),
            "no_approver_or_self_approved": int(sub["flag_sod_override"].sum()),
            "flagged_entries": int(sub["is_flagged"].sum()),
            "severity_counts": sub["severity"].astype(str).value_counts().to_dict(),
            "top_accounts": sub["account_code"].value_counts().head(5).to_dict(),
            "approvers_used": approvers,
            "first_posting": sub["posting_date"].min(), "last_posting": sub["posting_date"].max(),
            "extreme_entry_ids": ext["entry_id"].head(10).tolist(),
        }

    def get_account_statistics(self, account_code: str) -> dict[str, Any]:
        sub = self._account(account_code)
        amt = sub["amount"]
        bf = benford_stats(amt)
        monthly = sub.groupby("period")["amount"].sum()
        ext = sub[sub["severity"] == "Extreme"].sort_values("risk_score", ascending=False)
        return {
            "account_code": str(account_code), "account_name": sub["account_name"].iloc[0],
            "entries": len(sub), "total_inr": fmt_inr(amt.sum(), 0), "mean_inr": fmt_inr(amt.mean(), 0),
            "median_inr": fmt_inr(amt.median(), 0), "p95_inr": fmt_inr(amt.quantile(0.95), 0),
            "max_inr": fmt_inr(amt.max(), 0), "std_inr": fmt_inr(amt.std(), 0),
            "flagged_entries": int(sub["is_flagged"].sum()),
            "benford": {"sample": bf["n"], "mad": bf["mad"], "chi_square_p": bf["p_value"],
                        "conforms": bool(bf["mad"] <= self.cfg.benford_mad_cutoff)
                        if bf["n"] >= self.cfg.benford_min_entries else "sample too small"},
            "monthly_totals_inr": {p: fmt_inr(v, 0) for p, v in monthly.items()},
            "extreme_entry_ids": ext["entry_id"].head(10).tolist(),
        }

    def compare_to_peer_period(self, account_code: str, period: str) -> dict[str, Any]:
        sub = self._account(account_code)
        period = str(period).strip()
        if period not in set(sub["period"]):
            raise ToolError(f"No entries for account {account_code} in period {period}. "
                            f"Periods available: {', '.join(sorted(set(sub['period'])))}")
        monthly = sub.groupby("period")["amount"].agg(["sum", "count"]).sort_index()
        current = monthly.loc[period]
        earlier = monthly.loc[monthly.index < period].tail(3)
        others = monthly.drop(index=period)
        prior_mean = float(earlier["sum"].mean()) if len(earlier) else None
        top = sub[sub["period"] == period].nlargest(5, "amount")
        return {
            "account_code": str(account_code), "period": period,
            "period_total_inr": fmt_inr(current["sum"], 0), "period_entries": int(current["count"]),
            "prior_3_month_mean_inr": fmt_inr(prior_mean, 0) if prior_mean else None,
            "variance_vs_prior_pct": round((current["sum"] / prior_mean - 1) * 100, 1) if prior_mean else None,
            "mean_of_other_periods_inr": fmt_inr(others["sum"].mean(), 0) if len(others) else None,
            "largest_entries": [{"entry_id": r.entry_id, "amount_inr": fmt_inr(r.amount, 0),
                                 "severity": str(r.severity),
                                 "posted_by": self.pseudo.mask(r.posted_by)} for r in top.itertuples()],
        }


def to_json(payload: dict[str, Any]) -> str:
    """Compact JSON for a tool_result message."""
    return json.dumps(payload, ensure_ascii=False, default=str)
