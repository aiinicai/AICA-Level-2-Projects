"""Small shared helpers (Indian number formatting, safe conversions)."""
from __future__ import annotations

import math

import pandas as pd


def fmt_inr(value: float | int | None, decimals: int = 2, symbol: bool = True) -> str:
    """Format a number with Indian digit grouping, e.g. 1234567.5 -> '₹12,34,567.50'."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    negative = value < 0
    value = abs(float(value))
    whole, _, frac = f"{value:.{decimals}f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups) + "," + tail
    text = whole + (f".{frac}" if decimals else "")
    return f"{'-' if negative else ''}{'₹' if symbol else ''}{text}"


def fmt_inr_series(series: pd.Series, decimals: int = 2) -> pd.Series:
    """Indian-format a numeric Series (element-wise on the given, usually filtered, subset)."""
    return series.map(lambda v: fmt_inr(v, decimals))


def fmt_crore_lakh(value: float) -> str:
    """Compact Indian units for KPI cards (₹1.25 Cr / ₹8.40 L)."""
    if value is None or math.isnan(value):
        return "-"
    if abs(value) >= 1e7:
        return f"₹{value / 1e7:,.2f} Cr"
    if abs(value) >= 1e5:
        return f"₹{value / 1e5:,.2f} L"
    return fmt_inr(value, 0)


def clip_text(text: object, limit: int = 90) -> str:
    s = "" if text is None else str(text)
    return s if len(s) <= limit else s[: limit - 1] + "…"
