"""LLM provider abstraction (Anthropic Claude / OpenAI / Groq) with retries, timeouts and error mapping.

The agent talks to a provider-neutral message format; each client converts it to the provider's
wire format. Keys come from the environment / .env and are never logged or echoed.

Normalised messages
    {"role": "user", "content": str}
    {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "arguments"}]}
    {"role": "tool_results", "results": [{"id", "name", "content", "is_error"}]}
"""
from __future__ import annotations

import json
import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from dotenv import load_dotenv
from tenacity import (
    before_sleep_log, retry, retry_if_exception, stop_after_attempt, wait_exponential,
)

from .config import (
    DEFAULT_ANTHROPIC_MODEL, DEFAULT_GROQ_MODEL, DEFAULT_OPENAI_MODEL, GROQ_BASE_URL, LLM_MAX_TOKENS,
    ROOT_DIR,
)

logger = logging.getLogger(__name__)

PROVIDERS = ("anthropic", "openai", "groq")
DEFAULT_MODELS = {"anthropic": DEFAULT_ANTHROPIC_MODEL, "openai": DEFAULT_OPENAI_MODEL, "groq": DEFAULT_GROQ_MODEL}
KEY_VARS = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY", "groq": "GROQ_API_KEY"}


class LLMError(Exception):
    """Provider-agnostic failure. ``kind`` is one of: missing_key, auth, rate_limit, network,
    bad_request, server, other."""

    def __init__(self, kind: str, message: str):
        self.kind = kind
        super().__init__(message)


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class LLMResponse:
    text: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = "end_turn"          # "tool_use" | "end_turn" | "max_tokens"


@dataclass
class LLMSettings:
    provider: str = "anthropic"
    model: str = DEFAULT_ANTHROPIC_MODEL
    api_key: str = ""
    timeout: float = 60.0
    max_retries: int = 3

    @classmethod
    def from_env(cls, provider: str | None = None, model: str | None = None,
                 api_key: str | None = None) -> "LLMSettings":
        """Read settings from the environment (.env is loaded once). Arguments override env values."""
        load_dotenv(ROOT_DIR / ".env", override=False)
        provider = (provider or os.getenv("LLM_PROVIDER", "anthropic")).strip().lower()
        if provider not in PROVIDERS:
            raise LLMError("bad_request", f"LLM_PROVIDER must be one of {PROVIDERS}, got '{provider}'.")
        env_provider = os.getenv("LLM_PROVIDER", "anthropic").strip().lower()
        # LLM_MODEL belongs to LLM_PROVIDER; do not apply it when the UI switches provider
        env_model = os.getenv("LLM_MODEL", "").strip() if provider == env_provider else ""
        default_model = DEFAULT_MODELS[provider]
        key_var = KEY_VARS[provider]
        return cls(
            provider=provider,
            model=(model or env_model or default_model),
            api_key=(api_key or os.getenv(key_var, "")).strip(),
            timeout=float(os.getenv("LLM_TIMEOUT", "60")),
            max_retries=int(os.getenv("LLM_MAX_RETRIES", "3")),
        )

    @property
    def has_key(self) -> bool:
        return bool(self.api_key) and not self.api_key.lower().startswith(("your_", "sk-xxx", "paste"))


def _status(exc: Exception) -> int | None:
    return getattr(exc, "status_code", None) or getattr(getattr(exc, "response", None), "status_code", None)


def _is_retryable(exc: BaseException) -> bool:
    """Retry rate limits, 5xx / overloaded, timeouts and connection errors; never auth / bad request."""
    status = _status(exc)  # type: ignore[arg-type]
    if status is not None:
        return status == 429 or status >= 500
    name = type(exc).__name__.lower()
    return "timeout" in name or "connection" in name


def _translate(exc: Exception, secret: str) -> LLMError:
    """Map an SDK exception to :class:`LLMError` with a key-free message."""
    status = _status(exc)
    name = type(exc).__name__
    msg = str(exc)
    if secret:
        msg = msg.replace(secret, "***")
    msg = msg[:300]
    if status == 413:
        return LLMError("rate_limit", "Request too large for the model's token-per-minute limit (413). "
                                       "Lower 'Max Extreme entries' in the sidebar or use a model with a higher limit. " + msg)
    if status in (401, 403):
        return LLMError("auth", f"Authentication failed ({status}). Check the API key. {msg}")
    if status == 429:
        return LLMError("rate_limit", f"Rate limit / quota exceeded (429). {msg}")
    if status == 400 or status == 404 or status == 422:
        return LLMError("bad_request", f"Request rejected ({status}); check the model name. {msg}")
    if status is not None and status >= 500:
        return LLMError("server", f"Provider error ({status}). {msg}")
    if "timeout" in name.lower() or "connection" in name.lower():
        return LLMError("network", f"Network problem ({name}). {msg}")
    return LLMError("other", f"{name}: {msg}")


class BaseClient(ABC):
    def __init__(self, settings: LLMSettings):
        if not settings.has_key:
            raise LLMError("missing_key", f"No API key found for provider '{settings.provider}'. "
                                          "Add it to .env (see .env.example) or enter it in the sidebar.")
        self.settings = settings

    @abstractmethod
    def _call(self, system: str, messages: list[dict], tools: list[dict] | None,
              max_tokens: int) -> LLMResponse: ...

    def complete(self, system: str, messages: list[dict], tools: list[dict] | None = None,
                 max_tokens: int = LLM_MAX_TOKENS) -> LLMResponse:
        """One model turn with exponential-backoff retries; raises :class:`LLMError` on failure."""
        runner = retry(
            retry=retry_if_exception(_is_retryable),
            stop=stop_after_attempt(max(1, self.settings.max_retries)),
            wait=wait_exponential(multiplier=1.5, min=1, max=20),
            before_sleep=before_sleep_log(logger, logging.WARNING),
            reraise=True,
        )(self._call)
        try:
            return runner(system, messages, tools, max_tokens)
        except LLMError:
            raise
        except Exception as exc:                       # SDK exceptions
            raise _translate(exc, self.settings.api_key) from None

    def test_connection(self) -> str:
        """Minimal round-trip to prove the endpoint, key and model work. Returns the model reply."""
        resp = self.complete("You are a connectivity probe.",
                             [{"role": "user", "content": "Reply with the single word: OK"}], None, 16)
        return resp.text.strip() or "(empty reply)"


class AnthropicClient(BaseClient):
    def __init__(self, settings: LLMSettings):
        super().__init__(settings)
        import anthropic
        self._client = anthropic.Anthropic(api_key=settings.api_key, timeout=settings.timeout, max_retries=0)

    @staticmethod
    def _convert(messages: list[dict]) -> list[dict]:
        out: list[dict] = []
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                blocks: list[dict] = []
                if m.get("content"):
                    blocks.append({"type": "text", "text": m["content"]})
                for tc in m.get("tool_calls", []):
                    blocks.append({"type": "tool_use", "id": tc["id"], "name": tc["name"],
                                   "input": tc["arguments"]})
                out.append({"role": "assistant", "content": blocks})
            elif m["role"] == "tool_results":
                out.append({"role": "user", "content": [
                    {"type": "tool_result", "tool_use_id": r["id"], "content": r["content"],
                     "is_error": bool(r.get("is_error"))} for r in m["results"]]})
        return out

    def _call(self, system, messages, tools, max_tokens) -> LLMResponse:
        kwargs: dict[str, Any] = dict(model=self.settings.model, max_tokens=max_tokens, system=system,
                                      messages=self._convert(messages))
        if tools:
            kwargs["tools"] = tools
        resp = self._client.messages.create(**kwargs)
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        calls = [ToolCall(b.id, b.name, dict(b.input or {})) for b in resp.content
                 if getattr(b, "type", "") == "tool_use"]
        stop = "tool_use" if (resp.stop_reason == "tool_use" and calls) else (
            "max_tokens" if resp.stop_reason == "max_tokens" else "end_turn")
        return LLMResponse(text=text, tool_calls=calls, stop_reason=stop)


class OpenAIClient(BaseClient):
    def __init__(self, settings: LLMSettings):
        super().__init__(settings)
        import openai
        self._client = openai.OpenAI(api_key=settings.api_key, timeout=settings.timeout, max_retries=0,
                                     **self._client_kwargs())

    def _client_kwargs(self) -> dict[str, Any]:
        return {}

    def _token_budget(self, max_tokens: int) -> int:
        return max_tokens

    def _extra_kwargs(self) -> dict[str, Any]:
        return {}

    @staticmethod
    def _convert(system: str, messages: list[dict]) -> list[dict]:
        out: list[dict] = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                msg: dict[str, Any] = {"role": "assistant", "content": m.get("content") or None}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"id": tc["id"], "type": "function",
                                          "function": {"name": tc["name"],
                                                       "arguments": json.dumps(tc["arguments"])}}
                                         for tc in m["tool_calls"]]
                out.append(msg)
            elif m["role"] == "tool_results":
                out.extend({"role": "tool", "tool_call_id": r["id"], "content": r["content"]}
                           for r in m["results"])
        return out

    def _call(self, system, messages, tools, max_tokens) -> LLMResponse:
        kwargs: dict[str, Any] = dict(model=self.settings.model, max_completion_tokens=self._token_budget(max_tokens),
                                      messages=self._convert(system, messages))
        if tools:
            kwargs["tools"] = [{"type": "function", "function": {
                "name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
                for t in tools]
            kwargs["tool_choice"] = "auto"
        kwargs.update(self._extra_kwargs())
        resp = self._client.chat.completions.create(**kwargs)
        choice = resp.choices[0]
        calls: list[ToolCall] = []
        for tc in choice.message.tool_calls or []:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            calls.append(ToolCall(tc.id, tc.function.name, args))
        stop = "tool_use" if (calls and choice.finish_reason == "tool_calls") else (
            "max_tokens" if choice.finish_reason == "length" else "end_turn")
        return LLMResponse(text=choice.message.content or "", tool_calls=calls, stop_reason=stop)


class GroqClient(OpenAIClient):
    """Groq (Llama / GPT-OSS models) through its OpenAI-compatible endpoint."""

    def _client_kwargs(self) -> dict[str, Any]:
        return {"base_url": GROQ_BASE_URL}

    def _token_budget(self, max_tokens: int) -> int:
        # gpt-oss / qwen are reasoning models: hidden reasoning tokens count against the limit
        return max(max_tokens * 2, 1024)

    def _extra_kwargs(self) -> dict[str, Any]:
        # keep hidden reasoning short so the tool loop stays fast and inside Groq rate limits
        return {"reasoning_effort": "low"} if "gpt-oss" in self.settings.model else {}


def get_client(settings: LLMSettings) -> BaseClient:
    """Build the client for ``settings.provider``; raises LLMError('missing_key') without a key."""
    if settings.provider == "anthropic":
        return AnthropicClient(settings)
    if settings.provider == "openai":
        return OpenAIClient(settings)
    if settings.provider == "groq":
        return GroqClient(settings)
    raise LLMError("bad_request", f"Unsupported provider '{settings.provider}'.")


def check_connection(settings: LLMSettings) -> tuple[bool, str]:
    """For the sidebar 'Test API connection' button: (success, human-readable message)."""
    try:
        reply = get_client(settings).test_connection()
        return True, f"Connected to {settings.provider} ({settings.model}). Model replied: {reply}"
    except LLMError as exc:
        return False, f"[{exc.kind}] {exc}"
    except Exception as exc:  # noqa: BLE001 - never crash the UI on a probe
        msg = str(exc).replace(settings.api_key, "***") if settings.api_key else str(exc)
        return False, f"[other] {type(exc).__name__}: {msg[:200]}"
