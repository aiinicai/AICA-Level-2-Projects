"""Reversible pseudonymisation of personal names before any data leaves the machine."""
from __future__ import annotations

import re

import pandas as pd

NON_PERSONAL = {"", "SYSTEM", "SYS_BATCH", "NAN", "NONE", "NULL", "NA", "N/A"}
_TOKEN = re.compile(r"USER_\d{2,}")


class Pseudonymiser:
    """Maps real user names to stable tokens (USER_01 ...). The map never leaves this process."""

    def __init__(self, names: pd.Series | list[str]):
        unique = pd.Series(list(names), dtype="object").dropna().astype(str).str.strip()
        counts = unique.value_counts()
        real = [n for n in counts.index if n.upper() not in NON_PERSONAL]
        self.real_to_token = {n: f"USER_{i + 1:02d}" for i, n in enumerate(real)}
        self.token_to_real = {t: n for n, t in self.real_to_token.items()}
        names_longest_first = sorted(self.real_to_token, key=len, reverse=True)
        self._name_re = (re.compile("|".join(re.escape(n) for n in names_longest_first))
                         if names_longest_first else None)

    def mask(self, name: object) -> str:
        """Pseudonym for one name (non-personal system IDs pass through unchanged)."""
        s = "" if name is None else str(name).strip()
        return self.real_to_token.get(s, s)

    def mask_text(self, text: object) -> str:
        """Replace any known real name appearing inside free text."""
        s = "" if text is None else str(text)
        if self._name_re is None:
            return s
        return self._name_re.sub(lambda m: self.real_to_token[m.group(0)], s)

    def resolve(self, token_or_name: str) -> str | None:
        """Real name for a USER_nn token (or the name itself if it is already a real name)."""
        t = str(token_or_name).strip()
        if t in self.token_to_real:
            return self.token_to_real[t]
        if t in self.real_to_token or t.upper() in NON_PERSONAL:
            return t
        return None

    def unmask_text(self, text: str) -> str:
        """Local-only reversal: put real names back into a generated letter."""
        return _TOKEN.sub(lambda m: self.token_to_real.get(m.group(0), m.group(0)), text)

    @property
    def size(self) -> int:
        return len(self.real_to_token)
