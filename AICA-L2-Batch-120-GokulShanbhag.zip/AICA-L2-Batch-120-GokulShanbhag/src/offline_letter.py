"""Deterministic, template-based Management Letter content (no LLM required).

Used when there is no API key, the API fails after retries, the model does not submit a structured
letter, or there are no Extreme anomalies. The narrative is fixed wording; every figure comes
straight from the Python analysis, so the letter always renders cleanly.
"""
from __future__ import annotations

import pandas as pd

from .config import DETECTOR_LABELS
from .letter import LetterData, Observation, make_context, render_markdown
from .risk_scoring import top_extreme
from .tools import LedgerToolbox
from .utils import fmt_inr

# (detectors, title, observation lead, recommendations, priority)
_THEMES: list[tuple[tuple[str, ...], str, str, list[str], str]] = [
    (("sod_override",),
     "Manual overrides posted without independent approval",
     "Entries posted with no approver, or approved by the person who posted them, defeat the maker-checker "
     "control. This is a classic indicator of management override of controls and weakens internal financial "
     "controls over financial reporting.",
     ["Enforce system-level maker-checker for all manual journals and block self-approval in the ERP.",
      "Restrict override rights to named, authorised individuals and log every use with a justification.",
      "Review the listed entries retrospectively against supporting documents."],
     "High"),
    (("weekend_holiday", "after_hours"),
     "Manual postings outside normal working time",
     "Manual journals posted on weekends, public holidays or late at night are unusual and are often used to "
     "avoid supervisory review.",
     ["Restrict manual posting rights to business hours, or require written justification and next-day review "
      "for out-of-hours journals.",
      "Report out-of-hours manual postings to the Finance Controller weekly."],
     "High"),
    (("variance", "benford"),
     "Statistically unusual amounts and digit patterns",
     "Amounts far outside an account's normal range, or accounts whose leading-digit pattern departs from "
     "Benford's law, can reveal errors or manipulation.",
     ["Obtain explanations and source documents for the outlier entries.",
      "Extend analytical review to the affected accounts for the full period."],
     "High"),
    (("imbalance",),
     "Unbalanced journal entries",
     "Entries whose debits and credits do not agree indicate a breakdown of system validation or manual "
     "manipulation of the ledger.",
     ["Investigate how unbalanced entries were accepted and enforce hard balancing validation in the system.",
      "Correct the listed entries and confirm the trial balance impact."],
     "High"),
    (("below_threshold", "round_number"),
     "Amounts just below approval limits or in round figures",
     "Amounts hugging the approval limit suggest splitting or structuring to avoid higher-level authorisation; "
     "large round-figure amounts often indicate estimates or unsupported postings.",
     ["Review delegation-of-authority limits and aggregate related postings for approval purposes.",
      "Obtain supporting documents for the listed entries."],
     "Medium"),
    (("backdated", "period_end"),
     "Back-dated, future-dated and period-end manual journals",
     "Large gaps between document and posting dates, and material manual journals at period-end, create "
     "cut-off and earnings-management risk.",
     ["Lock prior periods after close and require approval for back-dated postings.",
      "Review all material period-end manual journals before the books are closed."],
     "Medium"),
    (("duplicate",),
     "Possible duplicate postings",
     "Identical account, amount, date and narration under different entry IDs may indicate double booking or "
     "duplicate payments.",
     ["Enable duplicate-detection checks at posting.",
      "Reverse confirmed duplicates and recover any duplicate payments."],
     "Medium"),
    (("dormant_rare",),
     "Dormant accounts reactivated and rarely-seen users posting",
     "Sudden activity in long-dormant accounts or postings by users with almost no history are common fraud "
     "indicators.",
     ["Review user-access rights and disable unused accounts.",
      "Obtain support for postings to dormant accounts."],
     "Medium"),
]
_PRIORITY_RANK = {"High": 0, "Medium": 1, "Low": 2}


def build_letter_data(toolbox: LedgerToolbox, top_n: int = 25, reason: str = "") -> LetterData:
    """Template narrative built from the extreme anomalies (no observations if there are none)."""
    res = toolbox.results
    ext = top_extreme(res, top_n)
    if ext.empty:
        return LetterData(
            executive_summary=("No entries reached the Extreme risk band. The lower-priority flags remain "
                               "available in the dashboard for routine follow-up."),
            control_conclusion="No material exceptions were identified at the highest risk level.",
            observations=[], source="template", note=reason or "no Extreme entries")
    ranked: list[tuple[int, Observation]] = []
    for order, (dets, title, lead, recs, priority) in enumerate(_THEMES):
        mask = pd.Series(False, index=ext.index)
        mask_all = pd.Series(False, index=res.index)
        for d in dets:
            mask |= ext[f"flag_{d}"]
            mask_all |= res[f"flag_{d}"]
        sub = ext[mask]
        if sub.empty:
            continue
        toolbox.seen_entry_ids.update(sub["entry_id"].astype(str))
        labels = ", ".join(DETECTOR_LABELS[d] for d in dets)
        text = f"{lead} {len(sub)} of the {len(ext)} highest-risk entries trigger the test(s): {labels}."
        ids = sub.sort_values("amount", ascending=False)["entry_id"].head(8).tolist()
        ranked.append((_PRIORITY_RANK[priority] * 1000 + order, Observation(
            title=title, observation=text, entry_ids=ids,
            risk_implication=("These patterns increase the risk of undetected error or fraud in the financial "
                              "statements and indicate that the related controls are not operating effectively."),
            recommendations=recs, priority=priority, tests=list(dets))))
    ranked.sort(key=lambda t: t[0])
    obs = [o for _, o in ranked]
    k = toolbox.summarise_flag_counts()
    themes = ", ".join(o.title.lower() for o in obs[:3])
    sod_present = any("approval" in o.title.lower() for o in obs)
    return LetterData(
        executive_summary=(f"Our automated tests flagged {k['flagged_entries']:,} entries ({k['flagged_pct']:.1f}% of the "
                           f"ledger), of which {k['extreme_count']:,} are rated Extreme and {k['high_count']:,} High. "
                           f"The most significant matters concern {themes}."),
        control_conclusion=("Controls over manual journal entries and system overrides do not appear sufficient to "
                            "prevent or detect misstatement"
                            + (", in particular segregation of duties." if sod_present else ".")),
        observations=obs,
        sod_commentary=("We recommend enforcing maker-checker in the ERP, restricting override rights to named "
                        "individuals and reporting all override activity to the Audit Committee monthly."),
        source="template", note=reason)


def build_offline(toolbox: LedgerToolbox, entity: str, period_label: str, reason: str = "",
                  top_n: int = 25) -> tuple[LetterData, str]:
    """(structured data, Markdown) for the template letter."""
    ld = build_letter_data(toolbox, top_n, reason)
    ctx = make_context(toolbox.results, toolbox.pseudo, toolbox.cfg, entity, period_label)
    return ld, render_markdown(ld, ctx)


def build_letter(toolbox: LedgerToolbox, entity: str, period_label: str, reason: str = "",
                 top_n: int = 25) -> str:
    return build_offline(toolbox, entity, period_label, reason, top_n)[1]


def build_no_exceptions_letter(toolbox: LedgerToolbox, entity: str, period_label: str) -> str:
    return build_offline(toolbox, entity, period_label, "no Extreme entries", 0)[1]

