"""One-call analysis pipeline: cleaned ledger -> detector flags -> scored results."""
from __future__ import annotations

import pandas as pd

from .config import DetectorConfig
from .detectors import run_detectors
from .risk_scoring import score_entries


def analyse(df: pd.DataFrame, cfg: DetectorConfig, enabled: list[str] | None = None) -> pd.DataFrame:
    """Run the enabled detectors and return the ledger enriched with flags, score and severity."""
    flags, reasons = run_detectors(df, cfg, enabled)
    return score_entries(df, flags, reasons, cfg)
