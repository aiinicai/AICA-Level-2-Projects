"""Combine detector flags into a 0-100 risk score and a severity band."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import DEFAULT_TOP_N_EXTREME, DETECTOR_LABELS, SEVERITY_ORDER, DetectorConfig


def score_entries(
    df: pd.DataFrame, flags: pd.DataFrame, reasons: pd.DataFrame, cfg: DetectorConfig,
) -> pd.DataFrame:
    """Return ``df`` enriched with flag_*/why_* columns, risk_score, severity and reason text."""
    weights = pd.Series({k: cfg.weights.get(k, 0.0) for k in flags.columns})
    score = flags.astype(float).mul(weights, axis=1).sum(axis=1)
    flagged_any = flags.any(axis=1)

    if cfg.materiality_bonus and len(df):
        cutoff = df["amount"].quantile(cfg.materiality_percentile)
        score = score + np.where(flagged_any & (df["amount"] >= cutoff), cfg.materiality_bonus, 0.0)
    score = score.clip(upper=100.0).round(1)

    severity = pd.cut(
        score, bins=[-1, cfg.medium_min_score - 1e-9, cfg.high_min_score - 1e-9,
                     cfg.extreme_min_score - 1e-9, 101],
        labels=SEVERITY_ORDER,
    ).astype(str)
    severity = pd.Series(severity, index=df.index)

    why = pd.Series("", index=df.index, dtype="object")
    names = pd.Series("", index=df.index, dtype="object")
    for name in flags.columns:
        hit = flags[name]
        if hit.any():
            why.loc[hit] = why.loc[hit] + DETECTOR_LABELS[name] + ": " + reasons.loc[hit, name] + " | "
            names.loc[hit] = names.loc[hit] + name + ","
    why = why.str.rstrip(" |")
    names = names.str.rstrip(",")

    out = df.copy()
    for name in flags.columns:
        out[f"flag_{name}"] = flags[name]
        out[f"why_{name}"] = reasons[name]
    out["flag_count"] = flags.sum(axis=1).astype(int)
    out["risk_score"] = score
    out["severity"] = pd.Categorical(severity, categories=SEVERITY_ORDER, ordered=True)
    out["detectors_hit"] = names
    out["reasons"] = why
    out["is_flagged"] = flagged_any
    return out


def top_extreme(results: pd.DataFrame, n: int = DEFAULT_TOP_N_EXTREME) -> pd.DataFrame:
    """The N highest-risk entries in the Extreme band (ranked by score, then amount)."""
    ext = results[results["severity"] == "Extreme"]
    return ext.sort_values(["risk_score", "amount"], ascending=False).head(n)


def detector_counts(results: pd.DataFrame) -> pd.DataFrame:
    rows = [{"detector": name, "label": DETECTOR_LABELS[name],
             "flagged_entries": int(results[f"flag_{name}"].sum()),
             "flagged_value": float(results.loc[results[f"flag_{name}"], "amount"].sum())}
            for name in DETECTOR_LABELS]
    return pd.DataFrame(rows).sort_values("flagged_entries", ascending=False, ignore_index=True)


def kpis(results: pd.DataFrame) -> dict[str, float]:
    """Headline numbers. 'Value at risk' = total amount of High + Extreme entries."""
    total = len(results)
    flagged = int(results["is_flagged"].sum())
    at_risk = results["severity"].isin(["High", "Extreme"])
    return {
        "total_entries": total,
        "total_value": float(results["amount"].sum()),
        "flagged_entries": flagged,
        "flagged_pct": (flagged / total * 100) if total else 0.0,
        "extreme_count": int((results["severity"] == "Extreme").sum()),
        "high_count": int((results["severity"] == "High").sum()),
        "value_at_risk": float(results.loc[at_risk, "amount"].sum()),
    }
