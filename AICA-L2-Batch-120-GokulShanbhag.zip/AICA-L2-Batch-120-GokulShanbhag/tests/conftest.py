"""Shared test helpers: build tiny ledgers through the real CSV loader."""
from __future__ import annotations

import io
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import DetectorConfig  # noqa: E402
from src.data_loader import load_ledger  # noqa: E402

DEFAULT_ROW = {
    "posting_date": "2025-07-15",        # a Tuesday
    "document_date": None,               # defaults to posting_date
    "account_code": "6001", "account_name": "Test account", "cost_center": "CC100",
    "amount": 12345.67, "currency": "INR", "entry_type": "Manual", "posted_by": "Alice",
    "approved_by": "Bob", "posting_time": "11:00:00", "source_system": "Manual JV",
    "is_manual_override": "N",
}


def make_ledger(rows: list[dict]) -> pd.DataFrame:
    """Create a cleaned ledger DataFrame from partial row dicts (missing fields use defaults)."""
    full = []
    for i, r in enumerate(rows, start=1):
        row = {**DEFAULT_ROW, "entry_id": f"T{i:04d}", "description": f"desc {i}", **r}
        row["document_date"] = row["document_date"] or row["posting_date"]
        row.setdefault("debit", row["amount"])
        row.setdefault("credit", row["amount"])
        row["period"] = str(row["posting_date"])[:7]
        full.append(row)
    csv = pd.DataFrame(full).to_csv(index=False).encode()
    df, _ = load_ledger(io.BytesIO(csv))
    return df


@pytest.fixture
def cfg() -> DetectorConfig:
    return DetectorConfig()
