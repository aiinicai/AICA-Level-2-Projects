"""Excel (.xlsx) ingestion: sheets, header detection, typed cells, serial dates, template round-trip."""
from __future__ import annotations

import datetime as dt
import io

import pandas as pd
import pytest
from openpyxl import Workbook

from src.data_loader import (
    SchemaError, detect_kind, list_sheets, load_ledger, read_header, suggest_mapping, suggest_sheet,
)
from src.pipeline import analyse
from src.config import DetectorConfig
from src.report_exporter import build_template_xlsx

HEADER = ["Voucher No", "Date", "GL Code", "Narration", "Dr", "Cr", "User", "Approver", "Time", "Entry Type", "Override"]


def _workbook(rows, title_rows: int = 3, extra_sheet: bool = True, header=HEADER) -> io.BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = "Cover"
    if extra_sheet:
        ws.append(["Notes - this sheet is not the ledger"])
        ws.append(["Prepared by finance"])
    gl = wb.create_sheet("GL Export")
    for i in range(title_rows):
        gl.append([f"Company ledger extract line {i + 1}"] if i != 1 else [])
    gl.append(header)
    for r in rows:
        gl.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


ROWS = [
    ["V1", dt.datetime(2025, 7, 19), 6001, "Weekend payment", 990000.0, 0, "Alice", None, dt.time(23, 30), "Manual", "Y"],
    ["V2", dt.datetime(2025, 7, 15), 6001, "Normal", 5000.5, 0, "Bob", "Carol", dt.time(11, 0), "Manual", "N"],
    ["V3", 45853, 6002, "Serial date", 100, 0, "Bob", "Carol", 0.5, "Automated", "N"],        # 45853 = 2025-07-15
    ["TOTAL", None, None, None, 995000.5, 0, None, None, None, None, None],                    # footer row
]


def test_excel_is_detected_with_sheets_and_header_row_found():
    buf = _workbook(ROWS)
    assert detect_kind(buf) == "xlsx"
    assert list_sheets(buf) == ["Cover", "GL Export"]
    assert suggest_sheet(buf) == "GL Export"
    assert read_header(buf, "GL Export") == HEADER                       # 3 title rows above the header skipped
    assert suggest_mapping(HEADER)["entry_id"] == "Voucher No"


def test_excel_typed_cells_serial_dates_and_footer_rows():
    df, rep = load_ledger(_workbook(ROWS))
    assert rep.file_kind == "xlsx" and rep.sheet == "GL Export"
    assert len(df) == 3 and rep.rows_dropped == 1 and "footer" in " ".join(rep.warnings)
    assert df["posting_date"].dt.strftime("%Y-%m-%d").tolist() == ["2025-07-19", "2025-07-15", "2025-07-15"]
    assert df["account_code"].tolist() == ["6001", "6001", "6002"]       # numeric Excel codes, no '.0'
    assert df["posting_hour"].tolist() == [23, 11, 12]                   # datetime.time and 0.5 day-fraction
    assert df["amount"].tolist() == [990000.0, 5000.5, 100.0]            # derived from Dr / Cr
    assert df["is_manual_override"].tolist() == ["Y", "N", "N"]


def test_excel_results_flow_through_the_detectors():
    df, _ = load_ledger(_workbook(ROWS * 2 if False else ROWS))
    res = analyse(df, DetectorConfig())
    first = res.iloc[0]
    assert first["flag_weekend_holiday"] and first["flag_after_hours"] and first["flag_sod_override"]


def test_excel_missing_columns_raise_schema_error_and_empty_sheet_is_reported():
    buf = _workbook([["A", 1, 2]], header=["foo", "bar", "baz"])
    with pytest.raises(SchemaError) as err:
        load_ledger(buf, sheet="GL Export")
    assert "entry_id" in err.value.missing
    wb = Workbook()
    wb.active.title = "Empty"
    empty = io.BytesIO()
    wb.save(empty)
    with pytest.raises(ValueError, match="empty"):
        read_header(empty, "Empty")


def test_explicit_sheet_choice_and_csv_still_works():
    buf = _workbook(ROWS)
    with pytest.raises(Exception):
        load_ledger(buf, sheet="Cover")                                  # wrong sheet is not a ledger
    csv = "entry_id,posting_date,account_code,posted_by,debit,credit\nE1,2025-07-15,6001,Alice,10,0\n".encode()
    df, rep = load_ledger(io.BytesIO(csv))
    assert rep.file_kind == "csv" and rep.sheet is None and len(df) == 1


def test_template_round_trips_through_the_loader():
    template = io.BytesIO(build_template_xlsx())
    assert list_sheets(template) == ["GL Export", "Instructions"] and suggest_sheet(template) == "GL Export"
    df, rep = load_ledger(template)
    assert len(df) == 3 and not rep.defaulted_columns                    # all 18 columns present
    assert df.loc[1, "is_manual_override"] == "Y" and df.loc[1, "approved_by"] == ""
