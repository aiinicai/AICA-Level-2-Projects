"""Tests for loader, scoring, tools, agent loop (with a fake LLM), privacy and the Excel export."""
from __future__ import annotations

import io

import pandas as pd
import pytest
from openpyxl import load_workbook

from conftest import make_ledger
from src.agent import run_agent
from src.config import DetectorConfig
from src.data_loader import SchemaError, load_ledger, suggest_mapping
from src.llm_client import BaseClient, LLMResponse, LLMSettings, ToolCall
from src.pipeline import analyse
from src.privacy import Pseudonymiser
from src.report_exporter import build_workbook, letter_to_docx
from src.tools import LedgerToolbox, ToolError
from src.utils import fmt_inr


# --------------------------------------------------------------------------- loader / utils
def test_fmt_inr_indian_grouping():
    assert fmt_inr(1234567.5) == "₹12,34,567.50"
    assert fmt_inr(999) == "₹999.00"
    assert fmt_inr(100000, 0) == "₹1,00,000"
    assert fmt_inr(-25000000, 0) == "-₹2,50,00,000"


def test_loader_reports_missing_columns():
    csv = b"entry_id,posting_date,amount\nA1,2025-07-01,100\n"
    with pytest.raises(SchemaError) as err:
        load_ledger(io.BytesIO(csv))
    assert {"account_code", "posted_by", "debit", "credit"} <= set(err.value.missing)


def test_loader_maps_aliases_and_drops_bad_dates():
    csv = (b"Voucher No,Date,GL Code,User,Dr,Cr\n"
           b"V1,01-07-2025,6001,Alice,100,0\nV2,not-a-date,6001,Alice,50,0\n")
    assert suggest_mapping(["Voucher No", "Date", "GL Code", "User", "Dr", "Cr"])["entry_id"] == "Voucher No"
    df, report = load_ledger(io.BytesIO(csv))
    assert len(df) == 1 and report.rows_dropped == 1
    assert df["posting_date"].iloc[0] == pd.Timestamp("2025-07-01")      # day-first fallback
    assert df["amount"].iloc[0] == 100                                   # derived from debit/credit


# --------------------------------------------------------------------------- scoring
def test_risk_scoring_bands():
    rows = [{"posting_date": "2025-07-19", "posting_time": "23:00:00", "is_manual_override": "Y",
             "approved_by": "", "amount": 990_000},                         # SoD+weekend+night+below limit
            *[{"amount": 1000 + i} for i in range(6)]]                      # clean entries (user is not "rare")
    res = analyse(make_ledger(rows), DetectorConfig())
    assert res["risk_score"].iloc[0] >= 70 and str(res["severity"].iloc[0]) == "Extreme"
    assert res["risk_score"].iloc[1] == 0 and not res["is_flagged"].iloc[1]
    assert "Override without approval" in res["reasons"].iloc[0]


# --------------------------------------------------------------------------- tools / privacy
def _toolbox(extreme: bool = True):
    rows = [{"posting_date": "2025-07-19", "posting_time": "23:00:00", "is_manual_override": "Y",
             "approved_by": "", "amount": 990_000, "posted_by": "Alice Real"}] if extreme else []
    rows += [{"amount": 1000 + i * 37, "posted_by": "Carol"} for i in range(20)]
    cfg = DetectorConfig()
    res = analyse(make_ledger(rows), cfg)
    pseudo = Pseudonymiser(pd.concat([res["posted_by"], res["approved_by"]]))
    return LedgerToolbox(res, cfg, pseudo, "Test Co"), pseudo


def test_pseudonymiser_round_trip():
    tb, pseudo = _toolbox()
    token = pseudo.mask("Alice Real")
    assert token.startswith("USER_") and pseudo.resolve(token) == "Alice Real"
    assert pseudo.mask_text("Posted by Alice Real today") == f"Posted by {token} today"
    assert pseudo.unmask_text(f"{token} did it") == "Alice Real did it"
    assert pseudo.mask("SYS_BATCH") == "SYS_BATCH"


def test_tools_mask_names_and_report_errors():
    tb, pseudo = _toolbox()
    out = tb.call("get_extreme_anomalies", {"top_n": 5})
    assert out["extreme_total"] == 1 and "Alice Real" not in str(out)
    assert out["entries"][0]["entry_id"] in tb.seen_entry_ids
    with pytest.raises(ToolError):
        tb.call("get_entry_details", {"entry_id": "NOPE"})
    with pytest.raises(ToolError):
        tb.call("no_such_tool", {})
    with pytest.raises(ToolError):
        tb.call("compare_to_peer_period", {"account_code": "6001"})       # missing argument


# --------------------------------------------------------------------------- agent loop
class ScriptedClient(BaseClient):
    """Fake LLM: replays a script of responses and records what it was sent."""

    def __init__(self, script):
        self.settings = LLMSettings(api_key="test")
        self.script, self.calls = list(script), []

    def _call(self, *a, **k):  # pragma: no cover
        raise NotImplementedError

    def complete(self, system, messages, tools=None, max_tokens=0):
        self.calls.append((list(messages), tools))
        return self.script.pop(0)


def _payload(entry_ids, **over):
    base = {
        "executive_summary": "Automated tests flagged a small number of high-risk manual journals.",
        "control_conclusion": "Controls over manual journals need strengthening.",
        "observations": [{
            "title": "Manual override without approval", "observation": "An override was posted without an approver.",
            "entry_ids": entry_ids, "risk_implication": "Management override risk.",
            "recommendations": ["Enforce maker-checker."], "priority": "High"}],
        "sod_commentary": "Restrict override rights.", "closing": "We would be pleased to discuss.",
    }
    base.update(over)
    return base


def _eid(tb):
    return tb.results.loc[tb.results["severity"] == "Extreme", "entry_id"].iloc[0]


def test_agent_runs_tool_loop_submits_letter_and_feeds_errors_back():
    tb, _ = _toolbox()
    client = ScriptedClient([
        LLMResponse("", [ToolCall("a", "summarise_flag_counts", {}),
                         ToolCall("b", "get_extreme_anomalies", {"top_n": 3})], "tool_use"),
        LLMResponse("", [ToolCall("c", "get_entry_details", {"entry_id": "BAD"})], "tool_use"),
        LLMResponse("", [ToolCall("d", "submit_management_letter", _payload([_eid(tb)]))], "tool_use"),
    ])
    res = run_agent(tb, LLMSettings(api_key="test", model="test-model"), "Test Co", "Jul 2025", client=client)
    assert res.mode == "llm" and res.tool_calls == 4 and res.iterations == 3
    seen_by_model = client.calls[2][0][-1]["results"]                    # what the model saw after the bad call
    assert seen_by_model[0]["is_error"] and "not found" in seen_by_model[0]["content"]
    assert [e.kind for e in res.trace].count("tool_error") == 1
    assert res.letter_data.source == "llm" and res.letter_data.model == "test-model"
    assert _eid(tb) in res.letter                                          # entry table rendered from the ledger
    assert "₹9,90,000" in res.letter                                       # amount comes from the ledger, not the model


def test_submit_rejects_incomplete_letter_and_model_can_retry():
    tb, _ = _toolbox()
    client = ScriptedClient([
        LLMResponse("", [ToolCall("a", "submit_management_letter", {"executive_summary": "x"})], "tool_use"),
        LLMResponse("", [ToolCall("b", "submit_management_letter", _payload([_eid(tb)]))], "tool_use"),
    ])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client)
    assert res.mode == "llm" and [e.kind for e in res.trace].count("tool_error") == 1


def test_agent_drops_invented_entry_ids():
    tb, _ = _toolbox()
    client = ScriptedClient([LLMResponse("", [ToolCall("a", "submit_management_letter",
                                                       _payload([_eid(tb), "T9999"]))], "tool_use")])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client)
    assert res.unverified_ids == ["T9999"] and "T9999" not in res.letter and _eid(tb) in res.letter


def test_agent_prose_reply_is_nudged_then_falls_back_to_template():
    tb, _ = _toolbox()
    client = ScriptedClient([LLMResponse("Here is my letter in prose.", [], "end_turn"),
                             LLMResponse("Still prose.", [], "end_turn")])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client)
    assert res.mode == "offline" and "did not submit" in res.error and len(client.calls) == 2
    client = ScriptedClient([LLMResponse("prose", [], "end_turn"),
                             LLMResponse("", [ToolCall("a", "submit_management_letter", _payload([_eid(tb)]))], "tool_use")])
    assert run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client).mode == "llm"


def test_agent_forces_submission_when_tool_budget_exhausted():
    tb, _ = _toolbox()
    looping = LLMResponse("", [ToolCall("x", "summarise_flag_counts", {})], "tool_use")
    client = ScriptedClient([looping, looping, LLMResponse(
        "", [ToolCall("s", "submit_management_letter", _payload([_eid(tb)]))], "tool_use")])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", max_iterations=2, client=client)
    assert res.mode == "llm" and [t["name"] for t in client.calls[-1][1]] == ["submit_management_letter"]


def test_agent_no_extreme_entries_skips_llm():
    tb, _ = _toolbox(extreme=False)
    client = ScriptedClient([])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client)
    assert res.mode == "no_exceptions" and "No material exceptions" in res.letter and not client.calls


def test_agent_falls_back_offline_without_key_or_on_api_failure():
    tb, _ = _toolbox()
    res = run_agent(tb, LLMSettings(api_key=""), "Test Co", "Jul 2025")
    assert res.mode == "offline" and "without an LLM" in res.letter and res.error

    from src.llm_client import LLMError

    class Broken(ScriptedClient):
        def complete(self, *a, **k):
            raise LLMError("rate_limit", "429 too many requests")

    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=Broken([]))
    assert res.mode == "offline" and "429" in res.error


# --------------------------------------------------------------------------- letter module
def test_clean_text_and_normalise_payload():
    from src.letter import clean_text, normalise_payload
    assert clean_text("100\u202f% of\u2011entries  tested") == "100% of-entries tested"
    ld, unknown = normalise_payload(_payload(["E1", "ZZ"], observations=[{
        "title": "T", "observation": "O", "entry_ids": ["E1", "ZZ", "E1"], "recommendations": "Do it",
        "priority": "urgent"}]), {"E1"})
    assert unknown == ["ZZ"] and ld.observations[0].entry_ids == ["E1"]
    assert ld.observations[0].recommendations == ["Do it"] and ld.observations[0].priority == "Medium"
    with pytest.raises(ValueError):
        normalise_payload({"executive_summary": "x", "observations": []}, set())


def test_style_rules_and_cross_references():
    from src.letter import clean_text, normalise_payload
    obs = lambda title, ids, **kw: {"title": title, "observation": "Findings.", "entry_ids": ids,  # noqa: E731
                                    "risk_implication": "Risk.", "recommendations": ["Fix."], "priority": "High", **kw}
    for bad in ("The approval limit is Rs 10 million.", "These postings breach ICAI SA 240 requirements.",
                "This contravenes the control objectives under SA 315."):
        with pytest.raises(ValueError):
            normalise_payload(_payload(["E1"], executive_summary=bad), {"E1"})
    ok, _ = normalise_payload(_payload(["E1"], executive_summary="Relevant to ICAI SA 240; the detectors ran."), {"E1"})
    assert "tests ran" in ok.executive_summary                        # 'detectors' -> 'tests'
    ld, _ = normalise_payload(_payload([], observations=[obs("One", ["E1", "E2"], tests=["sod_override", "bogus"]),
                                                          obs("Two", ["E2", "E3"])]), {"E1", "E2", "E3"})
    assert ld.observations[0].tests == ["sod_override"]
    assert ld.observations[1].entry_ids == ["E3"] and ld.observations[1].also_listed == [("E2", 1)]


def test_ledger_wide_line_is_computed_from_the_data():
    from src.letter import make_context, render_markdown
    tb, pseudo = _toolbox()
    client = ScriptedClient([LLMResponse("", [ToolCall("a", "submit_management_letter", _payload(
        [_eid(tb)], observations=[{"title": "Overrides", "observation": "Found.", "entry_ids": [_eid(tb)],
                                   "risk_implication": "Risk.", "recommendations": ["Fix."], "priority": "High",
                                   "tests": ["sod_override", "after_hours"]}]))], "tool_use")])
    res = run_agent(tb, LLMSettings(api_key="test"), "Test Co", "Jul 2025", client=client)
    assert "**Ledger-wide result:** 1 entries across the whole ledger" in res.letter


def test_letter_masks_names_and_reveal_restores_them():
    from src.letter import make_context, render_markdown
    tb, pseudo = _toolbox()
    ld = run_agent(tb, LLMSettings(api_key=""), "Test Co", "Jul 2025").letter_data
    masked = render_markdown(ld, make_context(tb.results, pseudo, tb.cfg, "Test Co", "Jul 2025", reveal=False))
    shown = render_markdown(ld, make_context(tb.results, pseudo, tb.cfg, "Test Co", "Jul 2025", reveal=True))
    assert "Alice Real" not in masked and "USER_" in masked and "Alice Real" in shown
    assert "million" not in masked.lower() and "## 4. Segregation of duties" in masked


def test_structured_word_letter_is_well_formed():
    from docx import Document
    from src.letter import build_letter_docx, make_context
    tb, pseudo = _toolbox()
    ld = run_agent(tb, LLMSettings(api_key=""), "Test Co", "Jul 2025").letter_data
    doc = Document(io.BytesIO(build_letter_docx(ld, make_context(tb.results, pseudo, tb.cfg, "Test Co", "Jul 2025"))))
    headings = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading")]
    assert headings[0] == "1. Executive summary" and any(h.startswith("Observation 1") for h in headings)
    assert len(doc.tables) >= 6                                            # info, KPIs, summary, entries, SoD ...
    text = " ".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    assert "₹9,90,000" in text and "Alice Real" not in text
    assert "Page" in doc.sections[0].footer.paragraphs[0].text


# --------------------------------------------------------------------------- Excel export
def test_workbook_has_all_sheets_and_chart():
    rows = [{"posting_date": "2025-07-19", "is_manual_override": "Y", "approved_by": ""},
            *[{"amount": 1000 + i} for i in range(6)]]
    res = analyse(make_ledger(rows), DetectorConfig())
    data = build_workbook(res, "Test Co", "Jul 2025", "# Letter\n\n=cmd()\n\n| A | B |\n|---|---|\n| 1 | 2 |", "offline")
    wb = load_workbook(io.BytesIO(data))
    assert wb.sheetnames == ["Summary", "Extreme Anomalies", "All Flagged Entries", "Detector Counts",
                             "SoD & Overrides", "Management Letter", "Methodology"]
    assert len(wb["Detector Counts"]._charts) == 1 and len(wb["Summary"]._charts) == 1
    flagged = wb["All Flagged Entries"]
    assert flagged.max_row == 2 and flagged.freeze_panes == "B2"
    assert flagged["B2"].number_format == "DD-MMM-YYYY" and "Weekend" in flagged["N2"].value   # friendly test names
    letter_cells = [c for row in wb["Management Letter"].iter_rows() for c in row if c.value is not None]
    assert all(c.data_type != "f" for c in letter_cells)                   # formula injection neutralised
    assert not any(str(c.value).startswith(("'", "#", "**")) for c in letter_cells)   # no stray markdown / apostrophes


# --------------------------------------------------------------------------- providers
def test_groq_provider_settings_and_client(monkeypatch):
    from src.llm_client import GroqClient, get_client
    monkeypatch.setenv("LLM_PROVIDER", "anthropic")
    monkeypatch.setenv("LLM_MODEL", "claude-sonnet-5-5")
    monkeypatch.setenv("GROQ_API_KEY", "gsk_test_key")
    settings = LLMSettings.from_env(provider="groq")
    assert settings.provider == "groq" and settings.has_key
    assert settings.model == "openai/gpt-oss-120b"             # env LLM_MODEL belongs to anthropic
    client = get_client(settings)
    assert isinstance(client, GroqClient) and "api.groq.com" in str(client._client.base_url)


def test_letter_to_docx_structure():
    from docx import Document
    md = ("# MANAGEMENT LETTER - DRAFT\n\n**Entity:** Test Co  \n\n> Generated without LLM\n\n## 1. Summary\n\n"
          "Plain text with **bold** and *italic*.\n\n### Observation 1: SoD\n\n- **Priority:** High\n- item two\n\n"
          "| Entry | Amount |\n|---|---|\n| JE-1 | 1,00,000 |\n")
    doc = Document(io.BytesIO(letter_to_docx(md, "Test Co", "Jul 2025")))
    styles = [p.style.name for p in doc.paragraphs]
    assert "Title" in styles and "Heading 1" in styles and "Heading 2" in styles and "List Bullet" in styles
    assert len(doc.tables) == 1 and doc.tables[0].cell(1, 1).text == "1,00,000"
    bold = [r.text for p in doc.paragraphs for r in p.runs if r.bold]
    assert "bold" in bold and "Priority:" in bold
    assert "DRAFT" in doc.sections[0].header.paragraphs[0].text
