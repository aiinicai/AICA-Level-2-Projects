"""Unit tests for every detector, on tiny hand-built ledgers."""
from __future__ import annotations

import numpy as np
import pytest

from conftest import make_ledger
from src import detectors as d


def flags(fn, rows, cfg):
    df = make_ledger(rows)
    flag, reason = fn(df, cfg)
    assert len(flag) == len(df) and len(reason) == len(df)
    # reason text exists exactly where the flag is set
    assert ((reason != "") == flag).all()
    return flag.tolist()


def test_weekend_holiday(cfg):
    rows = [
        {"posting_date": "2025-07-19"},                                   # Saturday, manual -> flag
        {"posting_date": "2025-07-19", "entry_type": "Automated"},        # batch job on a Saturday -> ok
        {"posting_date": "2025-07-16"},                                   # Wednesday -> ok
        {"posting_date": "2025-08-15"},                                   # Independence Day (Friday) -> flag
    ]
    assert flags(d.detect_weekend_holiday, rows, cfg) == [True, False, False, True]


def test_after_hours(cfg):
    rows = [
        {"posting_time": "23:30:00"},                                     # night, manual -> flag
        {"posting_time": "03:10:00"},                                     # night (wraps midnight) -> flag
        {"posting_time": "14:00:00"},
        {"posting_time": "02:00:00", "entry_type": "Automated"},          # batch -> ok
        {"posting_time": "05:00:00"},                                     # window ends at 05:00 (exclusive)
    ]
    assert flags(d.detect_after_hours, rows, cfg) == [True, True, False, False, False]


def test_sod_override(cfg):
    rows = [
        {"is_manual_override": "Y", "approved_by": ""},                   # override, no approver
        {"approved_by": "Alice"},                                         # self-approved
        {"approved_by": "Bob"},                                           # fine
        {"entry_type": "Automated", "posted_by": "SYS_BATCH", "approved_by": ""},   # system job
    ]
    assert flags(d.detect_sod_override, rows, cfg) == [True, True, False, False]


def test_below_threshold(cfg):
    rows = [{"amount": 990_000}, {"amount": 1_000_000}, {"amount": 940_000}, {"amount": 951_000}]
    assert flags(d.detect_below_threshold, rows, cfg) == [True, False, False, True]


def test_round_number(cfg):
    rows = [{"amount": 500_000.00}, {"amount": 512_345.67}, {"amount": 50_000.00}, {"amount": 3_000_000}]
    assert flags(d.detect_round_number, rows, cfg) == [True, False, False, True]


def test_duplicates(cfg):
    same = {"amount": 77_777.77, "description": "Invoice 42", "posting_date": "2025-07-16"}
    rows = [dict(same), dict(same), {"amount": 77_777.77, "description": "Invoice 43", "posting_date": "2025-07-16"}]
    assert flags(d.detect_duplicates, rows, cfg) == [True, True, False]


def test_benford_flags_only_failing_account(cfg):
    rng = np.random.default_rng(0)
    natural = 10 ** rng.uniform(2, 6, 500)                                # Benford-conforming
    rows = [{"account_code": "A1", "amount": round(float(a), 2)} for a in natural]
    rows += [{"account_code": "B2", "amount": 9000 + i} for i in range(400)]   # every amount leads with 9
    df = make_ledger(rows)
    flag, _ = d.detect_benford(df, cfg)
    assert not flag[df["account_code"] == "A1"].any()
    assert flag[df["account_code"] == "B2"].all()


def test_benford_needs_minimum_sample(cfg):
    df = make_ledger([{"amount": 9000 + i} for i in range(50)])
    flag, _ = d.detect_benford(df, cfg)
    assert not flag.any()


def test_variance_outlier(cfg):
    rng = np.random.default_rng(1)
    normal = np.round(np.exp(rng.normal(np.log(10_000), 0.5, 80)), 2)
    rows = [{"amount": float(a)} for a in normal] + [{"amount": 50_000_000.0}]
    df = make_ledger(rows)
    flag, reason = d.detect_variance(df, cfg)
    assert flag.iloc[-1] and flag.sum() == 1
    assert "outlier" in reason.iloc[-1]


def test_period_end(cfg):
    rows = [
        {"posting_date": "2025-09-30", "amount": 600_000},                # month-end, material, manual -> flag
        {"posting_date": "2025-09-15", "amount": 600_000},                # mid-month
        {"posting_date": "2025-09-30", "amount": 100_000},                # immaterial
        {"posting_date": "2025-09-30", "amount": 600_000, "entry_type": "Automated"},
    ]
    assert flags(d.detect_period_end, rows, cfg) == [True, False, False, False]


def test_backdated_and_future_dated(cfg):
    rows = [
        {"posting_date": "2025-07-15", "document_date": "2025-05-01"},    # 75 days late -> flag
        {"posting_date": "2025-07-15", "document_date": "2025-07-13"},    # 2 days -> ok
        {"posting_date": "2025-07-15", "document_date": "2025-07-25"},    # document 10 days in the future -> flag
    ]
    assert flags(d.detect_backdated, rows, cfg) == [True, False, True]


def test_imbalance_groups_by_entry(cfg):
    rows = [
        {"entry_id": "E1", "debit": 100.0, "credit": 90.0},               # unbalanced single-line entry
        {"entry_id": "E2", "debit": 100.0, "credit": 0.0},                # two-line entry that balances overall
        {"entry_id": "E2", "debit": 0.0, "credit": 100.0},
        {"entry_id": "E3", "debit": 50.0, "credit": 50.0},
    ]
    assert flags(d.detect_imbalance, rows, cfg) == [True, False, False, False]


def test_dormant_account_and_rare_user(cfg):
    rows = [{"account_code": "7101", "posting_date": f"2025-04-0{i}"} for i in range(1, 7)]
    rows.append({"account_code": "7101", "posting_date": "2025-11-10"})   # wakes after ~7 months
    rows += [{"account_code": "6001", "posted_by": "Temp1"}] * 2          # rarely-seen user, manual
    df = make_ledger(rows)
    flag, reason = d.detect_dormant_rare(df, cfg)
    assert flag.tolist() == [False] * 6 + [True, True, True]
    assert "dormant" in reason.iloc[6]
    assert "rarely-seen" in reason.iloc[7]


def test_run_detectors_returns_aligned_frames(cfg):
    df = make_ledger([{"posting_date": "2025-07-19"}, {}])
    f, r = d.run_detectors(df, cfg, enabled=["weekend_holiday"])
    assert list(f.columns) == list(d.DETECTORS) and f["weekend_holiday"].tolist() == [True, False]
    assert not f.drop(columns="weekend_holiday").any().any()              # disabled detectors stay quiet


def test_benford_table_sums_to_one():
    t = d.benford_table(__import__("pandas").Series([1.5, 22.0, 310.0, 9.0, 1000.0]))
    assert t["observed_pct"].sum() == pytest.approx(1.0)
    assert t["expected_pct"].sum() == pytest.approx(1.0)
