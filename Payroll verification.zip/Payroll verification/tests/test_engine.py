import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import make_sample_data  # noqa: E402
from payroll_verify import Config, build_workbook, load_table, reconcile  # noqa: E402

FILES = {"master": "01_employee_master.xlsx", "attendance": "02_attendance_summary.xlsx",
         "salary": "03_salary_sheet.xlsx", "prev_salary": "04_previous_salary_sheet.xlsx",
         "hold_register": "05_previous_hold_register.xlsx", "instructions": "06_client_instructions.xlsx",
         "logs": "07_attendance_detail_log.xlsx"}


@pytest.fixture(scope="module")
def result(tmp_path_factory):
    out = tmp_path_factory.mktemp("sample")
    make_sample_data.OUT = out
    make_sample_data.main()
    data = {k: load_table(out / v) for k, v in FILES.items()}
    cfg = Config(period="2026-10", shift_start="09:30", shift_end="18:30")
    return reconcile(data, cfg)


def status(res, emp):
    return res.employees.set_index("Employee ID").loc[emp, "Verification Status"]


@pytest.mark.parametrize("emp,expected", [
    ("E003", "Salary mismatch"),                       # paid 31 days, attendance supports 28
    ("E004", "Matched with approved adjustment"),      # approved arrears paid exactly
    ("E005", "Arrear/bonus mismatch"),                 # bonus without instruction
    ("E006", "Arrear/bonus mismatch"),                 # arrears in excess of instruction
    ("E007", "Matched with approved adjustment"),      # approved hold
    ("E008", "Matched with approved adjustment"),      # approved release within balance
    ("E009", "Hold/release mismatch"),                 # release > balance
    ("E010", "Employee master mismatch"),              # unapproved designation change
    ("E011", "Matched with approved adjustment"),      # approved designation change
    ("E012", "Employee master mismatch"),              # name mismatch
    ("E013", "Manual review required"),                # duplicate salary row
    ("E014", "Missing attendance or salary record"),
    ("E015", "Matched with approved adjustment"),      # joiner with instruction
    ("E016", "Missing client approval"),               # joiner without instruction
    ("E018", "Salary mismatch"),                       # unexplained rate change
    ("E019", "Salary mismatch"),                       # net miscalculated
    ("E020", "Manual review required"),                # ambiguous bonus instruction
])
def test_status(result, emp, expected):
    assert status(result, emp) == expected


def test_exit_without_instruction(result):
    assert ((result.issues.emp_id == "E017") & (result.issues.check == "Exit without instruction")).any()


def test_log_checks(result):
    i = result.issues
    assert ((i.emp_id == "E001") & (i.check == "Missing punch")).any()
    assert ((i.emp_id == "E002") & (i.check == "Summary vs detailed log")).any()
    assert ((i.emp_id == "E003") & (i.check == "Duplicate punch")).any()
    assert ((i.emp_id == "E001") & (i.check == "Late arrival") & (i.severity == "Info")).any()


def test_hold_carry_forward(result):
    hr = result.hold_register.set_index("Employee ID")
    assert hr.loc["E007", "Closing Hold Balance (carry forward)"] == 15000
    assert hr.loc["E008", "Closing Hold Balance (carry forward)"] == 0


def test_decision_held_and_every_issue_has_source(result):
    assert result.final["Decision"] == "HELD FOR REVIEW"
    assert (result.issues.source_ref.str.len() > 0).all()


def test_override_requires_all_fields(result):
    iid = result.issues[result.issues.emp_id == "E005"].issue_id.iloc[0]
    data = {k: load_table(make_sample_data.OUT / v) for k, v in FILES.items()}
    cfg = Config(period="2026-10")
    partial = pd.DataFrame([dict(issue_id=iid, reason="ok", approved_by="", date="2026-11-01", support_ref="x")])
    full = pd.DataFrame([dict(issue_id=iid, reason="Client confirmed by phone", approved_by="Partner",
                              date="2026-11-01", support_ref="email 01-Nov")])
    assert not reconcile(data, cfg, partial).issues.overridden.any()
    assert reconcile(data, cfg, full).issues.overridden.sum() == 1


def test_contradictory_instructions_flagged_not_assumed(result):
    data = {k: load_table(make_sample_data.OUT / v) for k, v in FILES.items()}
    ins = data["instructions"]
    extra = ins[ins.emp_id == "E004"].copy()
    extra["amount"], extra["_row"] = 9000.0, 99
    data["instructions"] = pd.concat([ins, extra], ignore_index=True)
    data["instructions"].attrs.update(ins.attrs)
    res = reconcile(data, Config(period="2026-10"))
    assert ((res.issues.emp_id == "E004") & (res.issues.check == "Contradictory instructions")).any()


def test_workbook_has_all_reports(result):
    import io
    wb = pd.ExcelFile(io.BytesIO(build_workbook(result)))
    for s in ("A Summary", "B Employee Verification", "C Attendance Exceptions", "D Salary Movement",
              "E Instruction Compliance", "F Final Approval", "All Exceptions", "Hold Register"):
        assert s in wb.sheet_names
