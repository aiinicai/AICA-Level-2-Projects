"""Run the the client payroll check from the command line.

python run_check.py --period 2026-10 --salary <draft salary.xlsx> --attendance <attendance.xlsx> --prev <last month salary.xlsx>
"""
import argparse
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).parent))

from payroll_verify import build_workbook, reconcile  # noqa: E402
from payroll_verify.profiles import client_config, load_client_sheets  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--period", required=True, help="payroll month, YYYY-MM")
ap.add_argument("--salary", required=True)
ap.add_argument("--attendance", required=True)
ap.add_argument("--prev", help="previous month salary sheet (optional)")
ap.add_argument("--prev-basis", type=int, help="day divisor used by the previous sheet (e.g. 31)")
ap.add_argument("--out", default=str(Path(__file__).parent / "output"))
a = ap.parse_args()

data = load_client_sheets(a.salary.strip('"'), a.attendance.strip('"'), a.prev.strip('"') if a.prev else None)
res = reconcile(data, client_config(a.period, prev_days_basis=a.prev_basis))
out = Path(a.out)
out.mkdir(exist_ok=True)
target = out / f"payroll_{a.period}_reconciliation.xlsx"
target.write_bytes(build_workbook(res))
f = res.final
print(f"\n{f['Decision']}: {f['Total exceptions (open)']} open exceptions, "
      f"{f['High-risk discrepancies']} high-risk, {res.summary['Matched employees']} employees matched")
print("Workbook:", target)
