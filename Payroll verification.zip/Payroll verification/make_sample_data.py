"""Generate a realistic sample payroll cycle (Oct-2026) with deliberately seeded errors.

Run:  python make_sample_data.py   ->  sample_data/*.xlsx|csv
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import pandas as pd

OUT = Path(__file__).parent / "sample_data"
DIM, PREV_DIM = 31, 30

# id, name, designation, department, DOJ, basic, hra, special
EMP = [
    ("E001", "Amit Sharma", "Executive", "Operations", "2022-04-01", 20000, 8000, 7000),
    ("E002", "Bhavna Patel", "Executive", "Operations", "2021-06-15", 22000, 8800, 7200),
    ("E003", "Chetan Rao", "Executive", "Sales", "2020-01-10", 25000, 10000, 8000),
    ("E004", "Deepa Nair", "Sr Executive", "Sales", "2019-08-01", 30000, 12000, 10000),
    ("E005", "Eshan Gupta", "Executive", "Finance", "2022-11-01", 21000, 8400, 6600),
    ("E006", "Farah Khan", "Sr Executive", "Finance", "2018-03-12", 32000, 12800, 10200),
    ("E007", "Gaurav Singh", "Executive", "HR", "2021-09-01", 24000, 9600, 7400),
    ("E008", "Hina Mehta", "Executive", "HR", "2020-12-01", 23000, 9200, 7800),
    ("E009", "Irfan Ali", "Executive", "IT", "2022-02-01", 26000, 10400, 8600),
    ("E010", "Jaya Iyer", "Senior Executive", "IT", "2019-05-01", 35000, 14000, 11000),
    ("E011", "Kiran Desai", "Team Lead", "IT", "2018-09-01", 40000, 16000, 14000),
    ("E012", "Sunita Verma", "Executive", "Operations", "2021-01-01", 20000, 8000, 6000),
    ("E013", "Lalit Joshi", "Executive", "Sales", "2020-07-01", 21000, 8400, 6600),
    ("E014", "Manoj Pillai", "Executive", "Sales", "2022-01-01", 22000, 8800, 7200),
    ("E015", "Neha Kapoor", "Executive", "Finance", "2026-10-12", 24000, 9600, 7400),
    ("E016", "Omkar Bhat", "Executive", "Finance", "2026-10-12", 24000, 9600, 7400),
    ("E018", "Pooja Rane", "Executive", "HR", "2019-04-01", 33000, 13200, 9800),
    ("E019", "Qasim Sheikh", "Executive", "IT", "2020-10-01", 27000, 10800, 8200),
    ("E020", "Rhea Thomas", "Executive", "IT", "2021-03-01", 28000, 11200, 8800),
]
PREV_ONLY = ("E017", "Sanjay Menon", "Executive", "Operations", "2019-01-01", 22000, 8800, 7200)
HOLIDAYS_DAYS, WO_DAYS = 2, 4   # Oct-2026: Sundays 4,11,18,25 ; holidays 2 Oct, 20 Oct


def sal_row(emp, payable, dim, extra=None, name=None, desig=None, scale=1.0):
    eid, nm, de, dep, _, b, h, s = emp
    f = payable / dim * scale
    r = dict(eid=eid, name=name or nm, desig=desig or de, dept=dep, pay=payable,
             basic=round(b * f, 2), hra=round(h * f, 2), spl=round(s * f, 2), other=0.0,
             arrears=0.0, bonus=0.0, hold=0.0, release=0.0, other_ded=0.0)
    r.update(extra or {})
    r["gross"] = round(r["basic"] + r["hra"] + r["spl"] + r["other"], 2)
    r["pf"] = round(r["basic"] * 0.12, 2)
    r["pt"] = 200.0
    r["tot_ded"] = round(r["pf"] + r["pt"] + r["other_ded"], 2)
    r["net"] = round(r["gross"] + r["arrears"] + r["bonus"] + r["release"] - r["tot_ded"] - r["hold"], 2)
    if "net_override" in r:
        r["net"] = r.pop("net_override")
    return r


def sal_df(rows):
    cols = {"eid": "Employee ID", "name": "Employee Name", "desig": "Designation", "dept": "Department",
            "pay": "Payable Days", "basic": "Basic", "hra": "HRA", "spl": "Special Allowance",
            "other": "Other Allowance", "gross": "Gross Salary", "pf": "PF", "pt": "PT",
            "other_ded": "Other Deductions", "tot_ded": "Total Deductions", "arrears": "Arrears",
            "bonus": "Bonus", "hold": "Hold", "release": "Release", "net": "Net Salary"}
    return pd.DataFrame(rows)[list(cols)].rename(columns=cols)


def main():
    OUT.mkdir(exist_ok=True)
    # ---- master ----
    master = pd.DataFrame([{"Employee ID": e[0], "Employee Name": e[1], "Designation": e[2],
                            "Department": e[3], "DOJ": dt.datetime.fromisoformat(e[4]),
                            "Status": "Active", "Basic": e[5], "HRA": e[6], "Special Allowance": e[7]}
                           for e in EMP])
    master.to_excel(OUT / "01_employee_master.xlsx", index=False)

    # ---- attendance ----
    att, pay = [], {}
    for e in EMP:
        absent, pl, present = 0, 0, 25
        if e[0] == "E002":
            absent, present = 3, 22
        if e[0] in ("E015", "E016"):
            present, absent = 17, 11
        wo = 2 if e[0] in ("E015", "E016") else WO_DAYS
        hol = 1 if e[0] in ("E015", "E016") else HOLIDAYS_DAYS
        if e[0] == "E003":
            absent, present = 3, 22
        payable = present + pl + wo + hol
        pay[e[0]] = payable
        att.append({"Employee ID": e[0], "Employee Name": e[1], "Present Days": present,
                    "Absent Days": absent, "Paid Leave": pl, "Weekly Off": wo, "Holidays": hol,
                    "Payable Days": payable})
    att = [r for r in att if r["Employee ID"] != "E014"]            # E014 missing from attendance
    pd.DataFrame(att).to_excel(OUT / "02_attendance_summary.xlsx", index=False)

    # ---- current salary ----
    rows = []
    for e in EMP:
        eid = e[0]
        p = pay[eid]
        extra, kw = {}, {}
        if eid == "E003":
            p = 31                                                    # paid full month despite 3 absent
        if eid == "E004":
            extra = {"arrears": 8000.0}
        if eid == "E005":
            extra = {"bonus": 5000.0}                                 # no instruction
        if eid == "E006":
            extra = {"arrears": 7000.0}                               # instructed 5000
        if eid == "E007":
            extra = {"hold": 15000.0}
        if eid == "E008":
            extra = {"release": 10000.0}
        if eid == "E009":
            extra = {"release": 6000.0}                               # balance only 4000
        if eid == "E012":
            kw["name"] = "Sunita Sharma"                              # name differs from master
        if eid == "E019":
            extra = {"net_override": None}
        if eid == "E014":
            pass
        r = sal_row(e, p, DIM, {k: v for k, v in extra.items() if k != "net_override"}, **kw)
        if eid == "E019":
            r["net"] = round(r["net"] + 2000, 2)                      # net overstated
        rows.append(r)
    rows.append(dict(rows[12]))                                       # E013 duplicated row
    pd.DataFrame(sal_df(rows)).to_excel(OUT / "03_salary_sheet.xlsx", index=False)

    # ---- previous month ----
    prev = []
    for e in EMP:
        if e[0] in ("E015", "E016"):
            continue
        desig = "Executive" if e[0] in ("E010", "E011") else None
        scale = 0.9 if e[0] == "E018" else 1.0                        # E018 rate rose 11% w/o revision
        prev.append(sal_row(e, PREV_DIM, PREV_DIM, desig=desig, scale=scale))
    prev.append(sal_row(PREV_ONLY, PREV_DIM, PREV_DIM))
    sal_df(prev).to_excel(OUT / "04_previous_salary_sheet.xlsx", index=False)

    # ---- hold register carried from September ----
    pd.DataFrame([{"Employee ID": "E008", "Employee Name": "Hina Mehta", "Balance": 10000},
                  {"Employee ID": "E009", "Employee Name": "Irfan Ali", "Balance": 4000}]
                 ).to_excel(OUT / "05_previous_hold_register.xlsx", index=False)

    # ---- client instruction register (extracted from emails) ----
    def ins(eid, nm, typ, amt, appr="Approved", ref="", src=""):
        return {"Employee ID": eid, "Employee Name": nm, "Instruction Type": typ, "Amount": amt,
                "Effective Month": "2026-10", "Approval Status": appr, "Approval Ref": ref,
                "Source": src, "Remarks": ""}
    pd.DataFrame([
        ins("E004", "Deepa Nair", "Arrears", 8000, ref="HR head approval", src="Email 03-Oct-26 'Oct arrears'"),
        ins("E006", "Farah Khan", "Arrears", 5000, ref="HR head approval", src="Email 03-Oct-26 'Oct arrears'"),
        ins("E007", "Gaurav Singh", "Salary Hold", 15000, ref="Director", src="Email 05-Oct-26 'Hold - notice period'"),
        ins("E008", "Hina Mehta", "Release of hold", 10000, ref="Director", src="Email 07-Oct-26 'Release'"),
        ins("E009", "Irfan Ali", "Release of hold", 6000, ref="Director", src="Email 07-Oct-26 'Release'"),
        ins("E011", "Kiran Desai", "Designation change", "", ref="HR head", src="Email 01-Oct-26 'Promotion'"),
        ins("E015", "Neha Kapoor", "New joining", "", ref="HR head", src="Email 10-Oct-26 'Joiners'"),
        ins("E020", "Rhea Thomas", "Bonus", "", ref="HR head", src="Email 15-Oct-26 'Bonus - amount TBC'"),
    ]).to_excel(OUT / "06_client_instructions.xlsx", index=False)

    # ---- detailed attendance log (E001, E002, E003 only) ----
    holidays = {dt.date(2026, 10, 2), dt.date(2026, 10, 20)}
    days = [dt.date(2026, 10, d) for d in range(1, 32)
            if dt.date(2026, 10, d).weekday() != 6 and dt.date(2026, 10, d) not in holidays]
    logs = []
    for eid, skip in (("E001", 0), ("E002", 3), ("E003", 3)):
        worked = days[skip:] if eid != "E002" else days[:22] + days[22:24]   # E002 logs show 24 days vs 22
        worked = worked if eid != "E003" else days[:22]
        for i, d in enumerate(worked):
            tin, tout = "09:20", "18:35"
            if eid == "E001" and i == 5:
                tout = ""                                                 # missing out punch
            if eid == "E001" and i == 9:
                tin = "10:05"                                             # late
            if eid == "E001" and i == 12:
                tin, tout = "09:25", "12:10"                              # 2.8 h, early out
            logs.append({"Employee ID": eid, "Date": d, "In Time": tin, "Out Time": tout})
            if eid == "E003" and i == 4:
                logs.append({"Employee ID": eid, "Date": d, "In Time": tin, "Out Time": tout})  # duplicate
    pd.DataFrame(logs).to_excel(OUT / "07_attendance_detail_log.xlsx", index=False)
    print("Sample data written to", OUT)


if __name__ == "__main__":
    main()
