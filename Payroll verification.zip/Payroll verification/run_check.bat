@echo off
cd /d "%~dp0"
echo the client payroll check - drag each file into this window, then press Enter.
set /p PERIOD=Payroll month (YYYY-MM, e.g. 2026-10):
set /p SAL=Draft salary sheet:
set /p ATT=Attendance workbook:
set /p PREV=Previous month salary sheet (Enter to skip):
set /p BASIS=Day divisor used in previous sheet (Enter to skip):
set ARGS=--period %PERIOD% --salary %SAL% --attendance %ATT%
if not "%PREV%"=="" set ARGS=%ARGS% --prev %PREV%
if not "%BASIS%"=="" set ARGS=%ARGS% --prev-basis %BASIS%
python run_check.py %ARGS%
echo.
pause
