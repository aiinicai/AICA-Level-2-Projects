﻿"""Streamlit front-end:  streamlit run app.py"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from payroll_verify import Config, build_workbook, load_table, reconcile
from payroll_verify.report import report_id

SAMPLE = Path(__file__).parent / "sample_data"
INPUTS = [
    ("master", "Employee master", True, "01_employee_master.xlsx"),
    ("attendance", "Attendance summary", True, "02_attendance_summary.xlsx"),
    ("salary", "Monthly salary sheet", True, "03_salary_sheet.xlsx"),
    ("prev_salary", "Previous month approved salary sheet", False, "04_previous_salary_sheet.xlsx"),
    ("hold_register", "Previous hold register", False, "05_previous_hold_register.xlsx"),
    ("instructions", "Client instruction register (from emails)", False, "06_client_instructions.xlsx"),
    ("logs", "Detailed attendance log", False, "07_attendance_detail_log.xlsx"),
]

st.set_page_config(page_title="Payroll Verification", layout="wide")
st.title("Attendance & Payroll Reconciliation")
st.caption("Read-only verification: this tool never changes salary data or releases payment.")

today = dt.date.today()
default_period = (today.replace(day=1) - dt.timedelta(days=1)).strftime("%Y-%m")

with st.sidebar:
    st.header("Payroll cycle")
    period = st.text_input("Payroll month (YYYY-MM)", default_period)
    prepared_by = st.text_input("Prepared by")
    basis = st.selectbox("Day basis for pro-rating", ["Calendar days", "30", "26"])
    tol = st.number_input("Amount tolerance (Rs)", 0.0, 100.0, 1.0)
    rate_pct = st.number_input("Salary-rate change threshold (%)", 0.0, 50.0, 1.0)
    with st.expander("Detailed-log rules (optional)"):
        shift_start = st.text_input("Shift start (HH:MM)", "")
        shift_end = st.text_input("Shift end (HH:MM)", "")
        grace = st.number_input("Late grace (minutes)", 0, 120, 15)
        min_h = st.number_input("Min hours / day", 0.0, 24.0, 4.0)
        max_h = st.number_input("Max hours / day", 0.0, 24.0, 14.0)
    use_sample = st.checkbox("Use sample data (Oct-2026 demo)")

st.subheader("1. Upload inputs (Excel, CSV or PDF)")
cols = st.columns(3)
files = {}
for i, (key, label, required, _) in enumerate(INPUTS):
    files[key] = cols[i % 3].file_uploader(label + (" *" if required else ""), key=key,
                                           type=["xlsx", "xls", "csv", "pdf"])

if "overrides" not in st.session_state:
    st.session_state.overrides = []

if st.button("Run verification", type="primary"):
    try:
        if use_sample:
            period = "2026-10"
            srcs = {k: SAMPLE / fn for k, _, _, fn in INPUTS}
            cfg_extra = dict(shift_start="09:30", shift_end="18:30")
        else:
            srcs = {k: f for k, f in files.items() if f is not None}
            cfg_extra = dict(shift_start=shift_start or None, shift_end=shift_end or None)
        missing = [lbl for k, lbl, req, _ in INPUTS if req and k not in srcs]
        if missing:
            st.error("Missing required input(s): " + ", ".join(missing))
            st.stop()
        data = {k: load_table(v) for k, v in srcs.items()}
        st.session_state.data = data
        st.session_state.cfg = Config(
            period=period, tolerance=tol, rate_change_pct=rate_pct,
            days_basis=None if basis == "Calendar days" else int(basis), grace_minutes=int(grace),
            min_hours=min_h, max_hours=max_h, **cfg_extra)
        st.session_state.overrides = []
        st.session_state.ran = True
    except Exception as exc:  # surface loader/engine errors to the operator
        st.error(f"Could not process inputs: {exc}")
        st.stop()

if st.session_state.get("ran"):
    ov = pd.DataFrame(st.session_state.overrides,
                      columns=["issue_id", "reason", "approved_by", "date", "support_ref"])
    res = reconcile(st.session_state.data, st.session_state.cfg, ov)
    f, s = res.final, res.summary

    st.subheader("2. Result")
    (st.error if f["Decision"] != "READY FOR APPROVAL" else st.success)(
        f"{f['Decision']}  |  open exceptions {f['Total exceptions (open)']}  |  high-risk "
        f"{f['High-risk discrepancies']}  |  pending clarifications {f['Pending client clarifications']}")
    m = st.columns(6)
    for c, (k, v) in zip(m, [("Employees", s["Total employees (all inputs)"]),
                             ("Gross", f"{s['Total gross salary']:,.0f}"),
                             ("Deductions", f"{s['Total deductions']:,.0f}"),
                             ("Net", f"{s['Total net salary']:,.0f}"),
                             ("Matched", s["Matched employees"]),
                             ("Need review", s["Employees requiring review"])]):
        c.metric(k, v)
    m = st.columns(4)
    for c, k in zip(m, ["Total arrears", "Total bonus", "Total salary held", "Total salary released"]):
        c.metric(k, f"{s[k]:,.0f}")

    tabs = st.tabs(["Employee verification", "All exceptions", "Attendance", "Salary movement",
                    "Instruction compliance", "Hold register", "Manual override"])
    with tabs[0]:
        status = st.multiselect("Filter status", sorted(res.employees["Verification Status"].unique()))
        df = res.employees if not status else res.employees[res.employees["Verification Status"].isin(status)]
        st.dataframe(df, width="stretch", hide_index=True)
    with tabs[1]:
        sev = st.multiselect("Severity", ["High", "Medium", "Low", "Info"], default=["High", "Medium", "Low"])
        st.dataframe(res.issues[res.issues.severity.isin(sev)], width="stretch", hide_index=True)
    with tabs[2]:
        st.dataframe(res.issues[res.issues.category == "Attendance mismatch"], width="stretch",
                     hide_index=True)
        if len(res.log_detail):
            st.caption("Day-level detail from the detailed log")
            st.dataframe(res.log_detail, width="stretch", hide_index=True)
    with tabs[3]:
        st.dataframe(res.movement, width="stretch", hide_index=True)
    with tabs[4]:
        st.dataframe(res.compliance, width="stretch", hide_index=True)
    with tabs[5]:
        st.dataframe(res.hold_register, width="stretch", hide_index=True)
        if len(res.hold_register):
            st.download_button("Download closing hold register (CSV) for next month",
                               res.hold_register.iloc[:, [0, 1, 5]].set_axis(
                                   ["Employee ID", "Employee Name", "Balance"], axis=1).to_csv(index=False),
                               f"hold_register_{res.cfg.period}.csv", "text/csv")
    with tabs[6]:
        st.write("Record a manual override. User, date, reason and supporting approval are all mandatory; "
                 "overridden exceptions stay visible in the report.")
        with st.form("ovr", clear_on_submit=True):
            iid = st.selectbox("Exception", res.issues[~res.issues.overridden].issue_id.tolist()
                               if len(res.issues) else [])
            reason = st.text_area("Reason")
            by = st.text_input("Approved by")
            ref = st.text_input("Supporting approval reference (email / document)")
            if st.form_submit_button("Add override"):
                if not (iid and reason.strip() and by.strip() and ref.strip()):
                    st.warning("All fields are required.")
                else:
                    st.session_state.overrides.append(dict(
                        issue_id=iid, reason=reason.strip(), approved_by=by.strip(),
                        date=dt.date.today().isoformat(), support_ref=ref.strip()))
                    st.rerun()
        st.dataframe(ov, width="stretch", hide_index=True)

    xlsx = build_workbook(res, prepared_by, ov)
    st.download_button("Download reconciliation workbook (.xlsx)", xlsx,
                       f"payroll_reconciliation_{report_id(res)}.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary")

