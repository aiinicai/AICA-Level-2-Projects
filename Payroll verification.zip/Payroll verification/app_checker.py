"""Simple screen for the the client monthly check. Started by 'Start Payroll Checker.bat'."""
import datetime as dt
import warnings

import pandas as pd
import streamlit as st

from payroll_verify import build_workbook, reconcile
from payroll_verify.profiles import client_config, load_client_sheets
from payroll_verify.report import report_id

warnings.filterwarnings("ignore")
st.set_page_config(page_title="Payroll Checker", layout="wide")
st.title("Payroll Checker")
st.write("Upload this month's files and click **Check payroll**. Nothing is changed in your files.")

last = (dt.date.today().replace(day=1) - dt.timedelta(days=1))
c1, c2 = st.columns(2)
sal = c1.file_uploader("1. Draft salary sheet (this month)", type=["xlsx"])
att = c2.file_uploader("2. Attendance workbook (this month)", type=["xlsx"])
prev = c1.file_uploader("3. Last month's salary sheet (recommended)", type=["xlsx"])
period = c2.text_input("Payroll month (YYYY-MM)", last.strftime("%Y-%m"))
basis = c2.number_input("Days used to divide salary in LAST month's sheet (30 or 31)", 28, 31, 30)

if st.button("Check payroll", type="primary"):
    if not (sal and att):
        st.error("Please upload the salary sheet and the attendance workbook.")
        st.stop()
    try:
        data = load_client_sheets(sal, att, prev)
        st.session_state.res = reconcile(data, client_config(period, prev_days_basis=int(basis)))
    except Exception as exc:
        st.error(f"Could not read the files: {exc}")
        st.stop()

res = st.session_state.get("res")
if res:
    f, s = res.final, res.summary
    (st.success if f["Decision"] == "READY FOR APPROVAL" else st.error)(
        f"{f['Decision'].replace('HELD FOR REVIEW', 'DO NOT APPROVE YET - needs review')}: "
        f"{f['Total exceptions (open)']} exceptions, {f['High-risk discrepancies']} serious")
    m = st.columns(5)
    m[0].metric("Employees", s["Total employees (all inputs)"])
    m[1].metric("OK", s["Matched employees"])
    m[2].metric("Need review", s["Employees requiring review"])
    m[3].metric("Gross", f"{s['Total gross salary']:,.0f}")
    m[4].metric("Net", f"{s['Total net salary']:,.0f}")
    st.download_button("Download the Excel report", build_workbook(res),
                       f"payroll_{res.cfg.period}_reconciliation.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary")

    st.subheader("Things to check")
    sev = res.issues[~res.issues.overridden & res.issues.severity.isin(["High", "Medium", "Low"])]
    show = sev[["emp_id", "name", "severity", "check", "message"]].rename(columns={
        "emp_id": "Emp Code", "name": "Name", "severity": "Priority", "check": "Issue", "message": "Details"})
    st.dataframe(show, width="stretch", hide_index=True)
    with st.expander("All employees"):
        st.dataframe(res.employees, width="stretch", hide_index=True)
    with st.expander("Salary changes vs last month"):
        st.dataframe(res.movement, width="stretch", hide_index=True)
