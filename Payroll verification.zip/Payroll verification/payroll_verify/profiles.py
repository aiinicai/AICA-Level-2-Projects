"""Client-specific readers for layouts that generic alias matching cannot handle.

the client (Oct-2026 layout)
  * Salary sheet: header row has 'Emp Code'; the columns Basic/HRA/Special/Stipend appear twice -
    the first block is the monthly salary package (master), the second block is the amount earned
    for the month. Gross already includes Bonus, Arrear and Prev. Hold Salary; 'Total Deduction'
    already includes the held amount; Net Pay = Gross - Total Deduction. Month basis = 30 days.
  * Attendance workbook, sheet 'Employee Work Log': one row per employee with Salary Status
    (PAY / HOLD / WITH_ARREAR) and a Comment holding the client's reason / remarks.
"""
from __future__ import annotations

import hashlib
import io
from pathlib import Path

import pandas as pd

from .config import Config
from .loader import canonicalize, to_num

client_config = dict(days_basis=30, gross_includes_adjustments=True, hold_in_deductions=True)


def client_config(period: str, **kw) -> Config:
    return Config(period=period, **{**client_config, **kw})


def _read(src):
    """(file name, bytes) from a path or an uploaded file object."""
    if hasattr(src, "read"):
        src.seek(0)
        return getattr(src, "name", "upload"), src.read()
    p = Path(src)
    return p.name, p.read_bytes()


def _client_salary(path):
    """Parse a client salary sheet (Sep and Oct layouts) -> (salary, master-package) frames."""
    sp, sbytes = _read(path)
    raw = pd.read_excel(io.BytesIO(sbytes), header=None, dtype=object)
    hdr = next(i for i in range(min(20, len(raw)))
               if str(raw.iat[i, 0]).strip().lower() in ("emp code", "employee code"))
    cols = [str(v).strip() if pd.notna(v) else "" for v in raw.iloc[hdr]]
    pos = {}   # lower-case header -> list of column positions (duplicates keep order)
    for i, c in enumerate(cols):
        pos.setdefault(c.lower(), []).append(i)
    body = raw.iloc[hdr + 1:]
    body = body[body.iloc[:, pos["emp name"][0]].notna()]       # drops the totals row

    def g(*names, nth=0):
        for n in names:
            if n.lower() in pos and len(pos[n.lower()]) > nth:
                return body.iloc[:, pos[n.lower()][nth]].values
        return [0] * len(body)                                  # column absent in this month's layout
    rows = body.index + 1
    salary = pd.DataFrame({
        "emp_id": g("Emp Code"), "name": g("Emp Name"), "designation": g("Designation"),
        "payable_days": g("PDays"),
        "basic": g("Basic Salary", nth=1), "hra": g("House Rent Allowance", nth=1),
        "special_allowance": g("Special Allow.", nth=1), "other_allowance": g("Stipend", nth=1),
        "bonus": g("Bonus"),
        # Sept sheet has no Arrear column; Misc Reimbursement is treated as an adjustment too
        "arrears": pd.to_numeric(pd.Series(g("Arrear")), errors="coerce").fillna(0).values
        + pd.to_numeric(pd.Series(g("Misc Reimbursement")), errors="coerce").fillna(0).values,
        "release": g("Prev. Hold Salary", "Previous Hold salary"),
        "gross": g("Gross Salary"), "tds": g("TDS"), "pf": g("PFAmt"), "esi": g("ESIAmt"),
        "pt": g("ProfessionalTax"), "lwf": g("LWF"), "hold": g("Hold Salary"),
        "total_deductions": g("Total Deduction"), "net": g("Net Pay", "Net Payable"), "_row": rows})
    master = pd.DataFrame({
        "emp_id": g("Emp Code"), "name": g("Emp Name"), "designation": g("Designation"),
        "basic": g("Basic Salary", nth=0), "hra": g("House Rent Allowance", nth=0),
        "special_allowance": g("Special Allow.", nth=0), "other_allowance": g("Stipend", nth=0),
        "_row": rows})
    return (canonicalize(salary, sp, sbytes),
            canonicalize(master, sp + " (package columns)", sbytes))


def load_client_prev(prev_salary_path) -> dict:
    """Previous month's sheet plus a hold register derived from its 'Hold Salary' column."""
    name, pbytes = _read(prev_salary_path)
    prev, _ = _client_salary(prev_salary_path)
    hr = prev[prev["hold"] > 0][["emp_id", "name", "hold"]].rename(columns={"hold": "balance"}).copy()
    hr["_row"] = prev.loc[hr.index, "_row"].values
    hr = canonicalize(hr, name + " (derived hold register)", pbytes)
    return {"prev_salary": prev, "hold_register": hr}


def load_client_sheets(salary_path, attendance_path, prev_salary_path=None) -> dict:
    """Return the data dict expected by reconcile()."""
    sdf, mdf = _client_salary(salary_path)    # ---------- attendance workbook ----------
    ap, abytes = _read(attendance_path)
    w = pd.read_excel(io.BytesIO(abytes), sheet_name="Employee Work Log", dtype=object)
    w = w[w["Employee ID"].notna()]
    att = pd.DataFrame({
        "emp_id": w["Employee ID"].values, "name": w["Employee Name"].values,
        "salary_status": w["Salary Status"].values, "total_days": w["Total Working days"].values,
        "payable_days": w["Working Days"].values, "absent": w["Absents"].values,
        "paid_leave": w["Paid Leaves"].values, "unpaid_leave": w["Unpaid Leaves"].values,
        "remarks": w["Comment"].values, "_row": w.index + 2})
    adf = canonicalize(att, ap, abytes)
    adf["comment"] = adf["remarks"]
    out = {"master": mdf, "attendance": adf, "salary": sdf}
    if prev_salary_path:
        out.update(load_client_prev(prev_salary_path))
    return out



