"""Read Excel / CSV / PDF inputs and normalise them to canonical column names."""
from __future__ import annotations

import datetime as dt
import hashlib
import io
import re
from pathlib import Path

import pandas as pd

ALIASES = {
    "emp_id": ["employee id", "emp id", "emp code", "employee code", "empid", "emp no", "employee no",
               "employee number", "code", "id", "staff id", "ecode", "e code"],
    "name": ["employee name", "emp name", "name", "staff name", "full name"],
    "designation": ["designation", "position", "job title", "title", "role"],
    "department": ["department", "dept", "division"],
    "doj": ["doj", "date of joining", "joining date", "date of join"],
    "status": ["status", "employee status", "emp status"],
    "basic": ["basic", "basic salary", "basic pay"],
    "hra": ["hra", "house rent allowance"],
    "special_allowance": ["special allowance", "special allow", "spl allowance", "sp allowance"],
    "other_allowance": ["other allowance", "other allowances", "other allow", "conveyance",
                        "conveyance allowance"],
    "gross": ["gross", "gross salary", "gross pay", "gross earnings", "total earnings", "monthly gross"],
    "present": ["present", "present days", "days present"],
    "absent": ["absent", "absent days", "days absent"],
    "paid_leave": ["paid leave", "paid leaves", "leave", "leaves", "pl", "cl", "leave days", "leave taken"],
    "unpaid_leave": ["unpaid leave", "lwp", "leave without pay"],
    "weekly_off": ["weekly off", "weekly offs", "week off", "wo", "weekoff"],
    "holidays": ["holidays", "holiday", "public holidays", "ph", "paid holidays"],
    "payable_days": ["payable days", "paid days", "days payable", "payable", "net payable days",
                     "total payable days", "pay days"],
    "pf": ["pf", "provident fund", "epf", "pf employee"],
    "esi": ["esi", "esic"],
    "pt": ["pt", "professional tax"],
    "tds": ["tds", "income tax"],
    "lwf": ["lwf", "labour welfare fund"],
    "total_days": ["total working days", "total days"],
    "salary_status": ["salary status"],
    "comment": ["comment"],
    "other_deductions": ["other deductions", "other deduction", "special deduction", "special deductions"],
    "total_deductions": ["total deductions", "deductions", "total deduction"],
    "arrears": ["arrears", "arrear", "salary arrears"],
    "bonus": ["bonus", "incentive", "incentives", "bonus incentive"],
    "hold": ["hold", "salary hold", "held", "hold amount", "amount held"],
    "release": ["release", "released", "hold release", "release of hold", "salary release"],
    "net": ["net", "net salary", "net pay", "net payable", "take home"],
    # client instruction register
    "type": ["type", "instruction type", "nature", "nature of instruction", "category"],
    "amount": ["amount", "amt", "value"],
    "effective_month": ["effective month", "month", "for month", "applicable month"],
    "period": ["applicable period", "period", "for period"],
    "approval_status": ["approval status", "approval", "approved", "status of approval"],
    "approval_ref": ["approval ref", "approval reference", "evidence", "email ref", "reference", "approved by"],
    "source": ["source", "email", "email subject", "email date", "source email"],
    "remarks": ["remarks", "remark", "notes", "comment", "comments", "special conditions", "conditions"],
    # hold register
    "balance": ["balance", "hold balance", "outstanding", "outstanding hold", "closing balance"],
    # detailed logs
    "date": ["date", "punch date", "attendance date"],
    "in_time": ["in time", "in", "login", "punch in", "check in", "first in", "in punch"],
    "out_time": ["out time", "out", "logout", "punch out", "check out", "last out", "out punch"],
}

NUMERIC = {"basic", "hra", "special_allowance", "other_allowance", "gross", "present", "absent",
           "paid_leave", "unpaid_leave", "weekly_off", "holidays", "payable_days", "pf", "esi", "pt",
           "tds", "other_deductions", "total_deductions", "arrears", "bonus", "hold", "release", "net",
           "amount", "balance"}
# numeric columns that are left NaN (not 0) when blank, so "missing" stays distinguishable
KEEP_NAN = {"payable_days", "amount", "gross", "total_deductions", "net"}


def _key(s) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(s).lower()).strip()


_LOOKUP = {_key(a): canon for canon, al in ALIASES.items() for a in al}
_LOOKUP.update({_key(c): c for c in ALIASES})


def _null(v) -> bool:
    try:
        return v is None or bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def norm_id(v) -> str:
    if _null(v):
        return ""
    s = str(v).strip()
    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]
    return s.upper()


def to_num(v) -> float:
    if _null(v):
        return float("nan")
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    neg = "(" in s and ")" in s
    s = re.sub(r"[^0-9.\-]", "", s)
    if s in ("", "-", "."):
        return float("nan")
    try:
        x = float(s)
    except ValueError:
        return float("nan")
    return -abs(x) if neg else x


def norm_month(v) -> str:
    """Return 'YYYY-MM' or '' when blank / unparseable."""
    if _null(v) or str(v).strip() == "":
        return ""
    try:
        d = pd.to_datetime(str(v) if not isinstance(v, (dt.date, dt.datetime)) else v, dayfirst=True)
        return f"{d.year:04d}-{d.month:02d}"
    except (ValueError, TypeError):
        return str(v).strip()


def to_date(v):
    if _null(v) or str(v).strip() == "":
        return pd.NaT
    try:
        return pd.to_datetime(v, dayfirst=True)
    except (ValueError, TypeError):
        return pd.NaT


def to_minutes(v):
    """Time of day -> minutes since midnight (None if blank/unparseable)."""
    if _null(v) or str(v).strip() == "":
        return None
    if isinstance(v, (dt.datetime, pd.Timestamp)):
        return v.hour * 60 + v.minute
    if isinstance(v, dt.time):
        return v.hour * 60 + v.minute
    if isinstance(v, float) and 0 <= v < 1:
        return int(round(v * 1440))
    m = re.search(r"(\d{1,2}):(\d{2})(?::\d{2})?\s*([AaPp][Mm])?", str(v))
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2)), m.group(3)
    if ap:
        h = h % 12 + (12 if ap.lower() == "pm" else 0)
    return h * 60 + mi


def _read_raw(src, name: str) -> pd.DataFrame:
    ext = Path(name).suffix.lower()
    if ext in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(src, header=None, dtype=object)
    if ext in (".csv", ".txt"):
        return pd.read_csv(src, header=None, dtype=str, keep_default_na=False, skipinitialspace=True)
    if ext == ".pdf":
        import pdfplumber

        rows = []
        with pdfplumber.open(src) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    rows.extend(table)
        if not rows:
            raise ValueError(f"No tables could be extracted from PDF '{name}'. "
                             "Scanned PDFs need OCR or an Excel/CSV export.")
        return pd.DataFrame(rows)
    raise ValueError(f"Unsupported file type '{ext}' for '{name}' (use Excel, CSV or PDF).")


def load_table(src, name: str | None = None) -> pd.DataFrame:
    """Load a file path or file-like object into a canonical-column DataFrame.

    Adds `_file` and `_row` (the 1-based row in the source sheet) so every exception can be
    traced to its origin. The SHA-256 of the file is kept in df.attrs["sha256"].
    """
    if isinstance(src, (str, Path)):
        name = name or Path(src).name
        data = Path(src).read_bytes()
    else:
        name = name or getattr(src, "name", "upload")
        src.seek(0)
        data = src.read()
    raw = _read_raw(io.BytesIO(data), name)

    # header row = best match to known aliases within the first 15 rows
    best, best_score = 0, -1
    for i in range(min(15, len(raw))):
        score = sum(1 for v in raw.iloc[i] if not _null(v) and _key(v) in _LOOKUP)
        if score > best_score:
            best, best_score = i, score
    header = raw.iloc[best]
    body = raw.iloc[best + 1:].copy()
    body["_row"] = body.index + 1
    cols, seen = [], set()
    for v in header:
        c = _LOOKUP.get(_key(v)) if not _null(v) else None
        if c and c not in seen:
            seen.add(c)
            cols.append(c)
        else:
            cols.append(None)
    keep = [i for i, c in enumerate(cols) if c]
    df = body.iloc[:, keep].copy()
    df.columns = [cols[i] for i in keep]
    df["_row"] = body["_row"].values
    return canonicalize(df, name, data)


def canonicalize(df: pd.DataFrame, name: str, data: bytes) -> pd.DataFrame:
    """Type-clean a frame that already has canonical column names and a `_row` column."""
    df = df.copy()
    df["_file"] = name
    if "emp_id" not in df:
        df["emp_id"] = ""
    df["emp_id"] = df["emp_id"].map(norm_id)
    if "name" in df:
        df["name"] = df["name"].map(lambda v: "" if _null(v) else re.sub(r"\s+", " ", str(v)).strip())
    for c in ("designation", "department", "status", "type", "approval_status", "approval_ref",
              "source", "remarks", "period", "salary_status", "comment"):
        if c in df:
            df[c] = df[c].map(lambda v: "" if _null(v) else str(v).strip())
    for c in NUMERIC & set(df.columns):
        df[c] = df[c].map(to_num)
        if c not in KEEP_NAN:
            df[c] = df[c].fillna(0.0)
    if "doj" in df:
        df["doj"] = df["doj"].map(to_date)
    if "effective_month" in df:
        df["effective_month"] = df["effective_month"].map(norm_month)
    if "date" in df:
        df["date"] = df["date"].map(to_date)
    for c in ("in_time", "out_time"):
        if c in df:
            df[c] = df[c].map(to_minutes)

    # drop blank / total rows (no id and no name)
    nm = df["name"] if "name" in df else pd.Series("", index=df.index)
    df = df[(df["emp_id"] != "") | (nm != "")].reset_index(drop=True)
    df.attrs.update(file=name, sha256=hashlib.sha256(data).hexdigest())
    return df
