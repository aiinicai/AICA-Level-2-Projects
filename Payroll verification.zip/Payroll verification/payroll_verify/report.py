﻿"""Build the review-ready reconciliation workbook (reports A-F plus supporting registers)."""
from __future__ import annotations

import datetime as dt
import io

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .engine import Result

HEAD = PatternFill("solid", fgColor="1F3864")
FILLS = {"High": "F8CBAD", "Medium": "FFE699", "Low": "DDEBF7", "Info": "EDEDED",
         "Matched": "C6E0B4", "Matched with approved adjustment": "E2EFDA"}


def report_id(res: Result) -> str:
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    h = "".join(s["SHA-256"][:6] for s in res.sources)[:12]
    return f"{res.cfg.period}-{stamp}-{h}"


def _style(ws, status_col: str | None = None):
    ws.freeze_panes = "A2"
    for c in ws[1]:
        c.font, c.fill = Font(bold=True, color="FFFFFF"), HEAD
        c.alignment = Alignment(wrap_text=True, vertical="center")
    heads = [c.value for c in ws[1]]
    for i, h in enumerate(heads, 1):
        width = max([len(str(h))] + [len(str(c.value)) for c in ws[get_column_letter(i)][1:60]
                                      if c.value is not None]) + 2
        ws.column_dimensions[get_column_letter(i)].width = min(max(width, 10), 60)
        long = str(h).lower() in ("message", "remarks", "source_ref", "detail", "approval evidence",
                                  "override_info")
        for c in ws[get_column_letter(i)][1:]:
            if isinstance(c.value, float):
                c.number_format = "#,##0.00"
            if long:
                c.alignment = Alignment(wrap_text=True, vertical="top")
    key = status_col if status_col in heads else None
    if key:
        col = heads.index(key) + 1
        for row in ws.iter_rows(min_row=2, min_col=col, max_col=col):
            c = row[0]
            if c.value in FILLS:
                c.fill = PatternFill("solid", fgColor=FILLS[c.value])
            elif c.value:
                c.fill = PatternFill("solid", fgColor="F8CBAD")
    ws.auto_filter.ref = ws.dimensions


def build_workbook(res: Result, prepared_by: str = "", overrides: pd.DataFrame | None = None) -> bytes:
    rid = report_id(res)
    issues = res.issues
    open_ = issues[~issues.overridden & (issues.severity != "Info")]
    att_ex = issues[issues.category == "Attendance mismatch"]
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as xw:
        # A. Summary
        rows = [("Report ID (version)", rid), ("Payroll period", res.cfg.period),
                ("Prepared by", prepared_by), ("Generated", dt.datetime.now().strftime("%Y-%m-%d %H:%M")),
                ("", "")]
        rows += [(k, v) for k, v in res.summary.items()]
        rows += [("", ""), ("Verification status", "Employees")]
        rows += list(res.final["by_status"].items())
        pd.DataFrame(rows, columns=["Item", "Value"]).to_excel(xw, sheet_name="A Summary", index=False)

        # B. Employee-wise verification
        res.employees.to_excel(xw, sheet_name="B Employee Verification", index=False)

        # C. Attendance exceptions (+ per-day log detail)
        cols = ["issue_id", "emp_id", "name", "severity", "check", "expected", "actual", "difference",
                "message", "source_ref", "overridden", "override_info"]
        att_ex[cols].to_excel(xw, sheet_name="C Attendance Exceptions", index=False)
        if len(res.log_detail):
            res.log_detail.to_excel(xw, sheet_name="C2 Log Detail", index=False)

        # D. Salary movement
        if len(res.movement):
            res.movement.to_excel(xw, sheet_name="D Salary Movement", index=False)
        else:
            pd.DataFrame({"Note": ["No previous-month salary sheet supplied."]}).to_excel(
                xw, sheet_name="D Salary Movement", index=False)

        # E. Email instruction compliance
        if len(res.compliance):
            res.compliance.to_excel(xw, sheet_name="E Instruction Compliance", index=False)
        else:
            pd.DataFrame({"Note": ["No client instructions supplied."]}).to_excel(
                xw, sheet_name="E Instruction Compliance", index=False)

        # F. Final approval
        f = res.final
        frows = [("Decision", f["Decision"]), ("Total exceptions (open)", f["Total exceptions (open)"]),
                 ("High-risk discrepancies", f["High-risk discrepancies"]), ("Medium", f["Medium"]),
                 ("Low", f["Low"]), ("Overridden exceptions", f["Overridden exceptions"]),
                 ("Pending client clarifications", f["Pending client clarifications"]), ("", "")]
        pend = open_[open_.category.isin(["Manual review required", "Missing client approval"])]
        frows.append(("PENDING CLARIFICATIONS", ""))
        frows += [(f"{r.emp_id} {r.name}".strip(), f"{r.check}: {r.message}") for r in pend.itertuples()]
        frows += [("", ""), ("HIGH-RISK DISCREPANCIES", "")]
        frows += [(f"{r.emp_id} {r.name}".strip(), f"{r.check}: {r.message}")
                  for r in open_[open_.severity == "High"].itertuples()]
        frows += [("", ""), ("SIGN-OFF", ""), ("Payroll Executive", "Name / date: "),
                  ("Reviewer / Manager", "Name / date: "), ("Partner / Authorised Approver", "Name / date: "),
                  ("", ""), ("Control note", "This report does not modify salary or release payment; "
                                             "approval is a manual decision.")]
        pd.DataFrame(frows, columns=["Item", "Detail"]).to_excel(xw, sheet_name="F Final Approval", index=False)

        # supporting
        cols_all = ["issue_id", "emp_id", "name", "category", "severity", "check", "expected", "actual",
                    "difference", "message", "source_ref", "overridden", "override_info"]
        issues[cols_all].to_excel(xw, sheet_name="All Exceptions", index=False)
        if len(res.hold_register):
            res.hold_register.to_excel(xw, sheet_name="Hold Register", index=False)
        ov = overrides if overrides is not None and len(overrides) else pd.DataFrame(
            columns=["issue_id", "reason", "approved_by", "date", "support_ref"])
        ov.to_excel(xw, sheet_name="Manual Overrides", index=False)
        pd.DataFrame(res.sources).to_excel(xw, sheet_name="Source Files", index=False)

        for ws in xw.book.worksheets:
            _style(ws, "Verification Status" if "Verification Status" in
                   [c.value for c in ws[1]] else ("severity" if ws.title.startswith(("C ", "All")) else
                                                  ("Result" if ws.title.startswith("E ") else None)))
        xw.book["F Final Approval"].column_dimensions["B"].width = 100
        xw.book["A Summary"].column_dimensions["A"].width = 42
        for r in xw.book["A Summary"].iter_rows(min_row=2, min_col=2, max_col=2):
            r[0].alignment = Alignment(horizontal="left")
    return out.getvalue()


