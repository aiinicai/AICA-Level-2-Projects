﻿"""Run-time configuration for one payroll verification cycle."""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from typing import Optional


@dataclass
class Config:
    period: str                         # payroll month, "YYYY-MM"
    tolerance: float = 1.0              # rupee tolerance for amount comparisons
    day_tolerance: float = 0.01         # tolerance for day counts
    name_match_threshold: float = 0.85  # similarity below which names are flagged
    rate_change_pct: float = 1.0        # per-day gross change (%) treated as a structure change
    days_basis: Optional[int] = None    # fixed divisor (e.g. 26 / 30); None = calendar days
    prev_days_basis: Optional[int] = None   # divisor the previous month's sheet used, if different
    # client sheet conventions
    gross_includes_adjustments: bool = False  # gross already contains arrears + bonus + release
    hold_in_deductions: bool = False          # "Total Deduction" already contains the held amount
    # Phase 3 detail-log rules (optional; blank = rule not applied)
    shift_start: Optional[str] = None   # "09:30"
    shift_end: Optional[str] = None     # "18:30"
    grace_minutes: int = 15
    min_hours: float = 4.0
    max_hours: float = 14.0

    @property
    def days_in_month(self) -> int:
        if self.days_basis:
            return int(self.days_basis)
        y, m = (int(x) for x in self.period.split("-"))
        return calendar.monthrange(y, m)[1]

    @property
    def prev_days_in_month(self) -> int:
        if self.prev_days_basis:
            return int(self.prev_days_basis)
        if self.days_basis:
            return int(self.days_basis)
        y, m = (int(x) for x in self.period.split("-"))
        y, m = (y - 1, 12) if m == 1 else (y, m - 1)
        return calendar.monthrange(y, m)[1]

