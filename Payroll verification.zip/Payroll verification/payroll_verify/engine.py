"""Reconciliation engine: employee-wise attendance, salary, master, adjustment and hold checks.

The engine is read-only: it never alters salary data, it only reports differences.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

import pandas as pd

from .config import Config
from .loader import to_minutes

# ---- statuses / categories -------------------------------------------------------------
MATCHED = "Matched"
MATCHED_ADJ = "Matched with approved adjustment"
ATT = "Attendance mismatch"
SAL = "Salary mismatch"
MST = "Employee master mismatch"
ARR = "Arrear/bonus mismatch"
HLD = "Hold/release mismatch"
APP = "Missing client approval"
MIS = "Missing attendance or salary record"
MAN = "Manual review required"
# worst first: decides the single status shown for an employee with several issues
STATUS_PRIORITY = [MIS, MAN, SAL, ATT, ARR, HLD, MST, APP]
SEVERITY_RANK = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}

COMPONENTS = ["basic", "hra", "special_allowance", "other_allowance"]
DED_PARTS = ["pf", "esi", "pt", "tds", "lwf", "other_deductions"]
AMOUNT_TYPES = ["arrear", "bonus", "release", "hold", "deduction"]
SALARY_COL = {"arrear": "arrears", "bonus": "bonus", "release": "release", "hold": "hold",
              "deduction": "other_deductions"}
TYPE_CATEGORY = {"arrear": ARR, "bonus": ARR, "release": HLD, "hold": HLD, "deduction": SAL}
APPROVED_WORDS = {"approved", "approve", "yes", "y", "confirmed", "ok", "true", "1", "accepted"}
INACTIVE_WORDS = ("exit", "left", "resign", "terminat", "inactive", "absconded", "separat")

_TYPE_RULES = [  # order matters: "release of hold" must hit release before hold
    ("release", ("release",)), ("arrear", ("arrear",)),
    ("bonus", ("bonus", "incentive", "ex gratia", "ex-gratia")),
    ("designation_change", ("designation", "promotion")),
    ("revision", ("revision", "increment", "hike")),
    ("joining", ("join",)), ("exit", ("exit", "resign", "separat", "terminat", "left")),
    ("hold", ("hold", "withhold")), ("deduction", ("deduct", "recover")),
]


def norm_type(t: str) -> str:
    s = str(t).lower()
    for key, pats in _TYPE_RULES:
        if any(p in s for p in pats):
            return key
    return "unknown"


def _name_key(s: str) -> str:
    return " ".join(sorted(re.findall(r"[a-z]+", str(s).lower())))


def name_similarity(a: str, b: str) -> float:
    ta, tb = set(_name_key(a).split()), set(_name_key(b).split())
    if ta and tb and (ta <= tb or tb <= ta):   # "Vishal" vs "Vishal Birwal": abbreviation, not a conflict
        return 1.0
    return difflib.SequenceMatcher(None, _name_key(a), _name_key(b)).ratio()


def _f(v, default=0.0) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    return default if x != x else x


def _close(a, b, tol) -> bool:
    return abs(_f(a) - _f(b)) <= tol


def _inr(x) -> str:
    return f"{_f(x):,.2f}"


@dataclass
class Result:
    cfg: Config
    employees: pd.DataFrame
    issues: pd.DataFrame
    log_detail: pd.DataFrame
    movement: pd.DataFrame
    compliance: pd.DataFrame
    hold_register: pd.DataFrame
    summary: dict
    final: dict
    sources: list = field(default_factory=list)


def _rows(df, label):
    """emp_id -> first row dict (+ list of duplicate emp ids)."""
    if df is None:
        return {}, set(), {}
    d, dups = {}, set()
    for rec in df.to_dict("records"):
        e = rec["emp_id"]
        if e == "":
            continue
        if e in d:
            dups.add(e)
        else:
            d[e] = rec
    return d, dups, {label: len(df)}


def _ref(label, rec):
    if not rec:
        return f"{label}: record not found"
    return f"{label} [{rec.get('_file', '')}] row {rec.get('_row', '?')}"


class _Run:
    def __init__(self, data: dict, cfg: Config):
        self.d, self.cfg = data, cfg
        self.tol = cfg.tolerance
        self.dim = cfg.days_in_month
        self.issues: list[dict] = []
        self.compliance: list[dict] = []
        self.log_rows: list[dict] = []
        self.approved_types: dict[str, set] = {}   # emp -> approved non-amount instruction types
        self.applied_adj: set[str] = set()         # emp with a matched approved adjustment

    # ---- helpers ----
    def add(self, emp, name, cat, sev, check, expected="", actual="", msg="", ref=""):
        diff = ""
        try:
            diff = round(float(actual) - float(expected), 2)
        except (TypeError, ValueError):
            pass
        self.issues.append(dict(emp_id=emp, name=name, category=cat, severity=sev, check=check,
                                expected=expected, actual=actual, difference=diff, message=msg,
                                source_ref=ref))

    # ---- main ----
    def run(self):
        d, cfg = self.d, self.cfg
        self.master, m_dups, _ = _rows(d.get("master"), "master")
        self.att, a_dups, _ = _rows(d.get("attendance"), "attendance")
        self.sal, s_dups, _ = _rows(d.get("salary"), "salary")
        self.prev, p_dups, _ = _rows(d.get("prev_salary"), "prev")
        self.hold_prev = {r["emp_id"]: r for r in d["hold_register"].to_dict("records")} \
            if d.get("hold_register") is not None else {}
        self.has = {k: d.get(k) is not None for k in
                    ("master", "attendance", "salary", "prev_salary", "instructions", "logs",
                     "hold_register")}

        for label, df, dups in (("Employee master", d.get("master"), m_dups),
                                ("Attendance summary", d.get("attendance"), a_dups),
                                ("Salary sheet", d.get("salary"), s_dups),
                                ("Previous salary sheet", d.get("prev_salary"), p_dups)):
            self._identification(label, df, dups)

        self.universe = sorted(set(self.sal) | set(self.att) | set(self.master))
        self.names = {e: (self.master.get(e) or self.sal.get(e) or self.att.get(e) or
                          self.prev.get(e) or {}).get("name", "") for e in
                      set(self.universe) | set(self.prev)}
        self._instructions()          # builds self.ins_by_emp / approved_types / compliance
        for e in self.universe:
            self._employee(e)
        self._prev_only()
        self._logs()
        self._instruction_compare()
        self._hold_register()

    # ---- FR-01 identification ----
    def _identification(self, label, df, dups):
        if df is None:
            return
        for rec in df.to_dict("records"):
            if rec["emp_id"] == "":
                self.add("", rec.get("name", ""), MAN, "High", "Missing employee ID",
                         msg=f"{label}: row has a name but no employee ID, cannot be matched.",
                         ref=_ref(label, rec))
        for e in sorted(dups):
            rows = df[df.emp_id == e]["_row"].tolist()
            nm = df[df.emp_id == e]["name"].iloc[0] if "name" in df else ""
            self.add(e, nm, MAN, "High", "Duplicate employee record",
                     msg=f"{label}: employee ID appears {len(rows)} times (rows {rows}). Only the first "
                         "row was used; the rest need manual review.",
                     ref=f"{label} [{df.attrs.get('file', '')}] rows {rows}")

    # ---- FR-07 instruction intake ----
    def _instructions(self):
        self.ins_by_emp: dict[str, list] = {}
        ins = self.d.get("instructions")
        if ins is None:
            return
        name_to_id: dict[str, set] = {}
        for src in (self.master, self.sal, self.att, self.prev):
            for e, r in src.items():
                name_to_id.setdefault(_name_key(r.get("name", "")), set()).add(e)
        known = set(self.sal) | set(self.att) | set(self.master) | set(self.prev)
        for rec in ins.to_dict("records"):
            rec = dict(rec)
            rec["ref"] = f"INS-{rec['_row']}"
            rec["itype"] = norm_type(rec.get("type", ""))
            rec["approved"] = str(rec.get("approval_status", "")).strip().lower() in APPROVED_WORDS
            rec["evidence"] = " | ".join(x for x in (rec.get("approval_ref", ""), rec.get("source", "")) if x)
            e = rec["emp_id"]
            src_ref = _ref("Instruction register", rec)
            if e == "":
                cand = name_to_id.get(_name_key(rec.get("name", "")), set())
                if len(cand) == 1:
                    e = next(iter(cand))
                    rec["emp_id"] = e
            if e == "":
                self.add("", rec.get("name", ""), MAN, "High", "Instruction employee not identifiable",
                         msg=f"{rec['ref']}: no employee ID and name matches "
                             f"{'several' if len(name_to_id.get(_name_key(rec.get('name','')), ())) > 1 else 'no'}"
                             " employees. Not assumed.", ref=src_ref)
                continue
            if e not in known:
                self.add(e, rec.get("name", ""), MAN, "Medium", "Instruction for unknown employee",
                         msg=f"{rec['ref']}: employee is not in any payroll input.", ref=src_ref)
            if rec["itype"] == "unknown":
                self.add(e, rec.get("name", ""), MAN, "High", "Ambiguous instruction type",
                         msg=f"{rec['ref']}: instruction type '{rec.get('type', '')}' is not recognised; "
                             "not assumed.", ref=src_ref)
            elif rec["itype"] in AMOUNT_TYPES and not (_f(rec.get("amount")) > 0):
                self.add(e, rec.get("name", ""), MAN, "High", "Ambiguous instruction amount",
                         msg=f"{rec['ref']}: {rec['itype']} instruction has no usable amount "
                             f"({'blank' if _f(rec.get('amount'), None) is None else rec.get('amount')}); "
                             "not assumed.", ref=src_ref)
                rec["indeterminate"] = True
            self.ins_by_emp.setdefault(e, []).append(rec)

    def _applicable(self, rec):
        em = rec.get("effective_month", "")
        return em in ("", self.cfg.period)

    # ---- per employee ----
    def _employee(self, e):
        cfg, tol = self.cfg, self.tol
        m, a, s, p = self.master.get(e), self.att.get(e), self.sal.get(e), self.prev.get(e)
        nm = self.names.get(e, "")
        refs = "; ".join(x for x in (_ref("Master", m) if self.has["master"] else "",
                                     _ref("Attendance", a) if self.has["attendance"] else "",
                                     _ref("Salary", s) if self.has["salary"] else "") if x)

        # missing records
        for label, rec, present in (("Employee master", m, self.has["master"]),
                                    ("Attendance summary", a, self.has["attendance"]),
                                    ("Salary sheet", s, self.has["salary"])):
            if present and rec is None:
                cat = MST if label == "Employee master" else MIS
                self.add(e, nm, cat, "High", f"Missing in {label.lower()}",
                         msg=f"Employee found in other inputs but not in the {label.lower()}.", ref=refs)

        # name cross-check
        base = m or s or a
        for label, rec in (("Employee master", m), ("Attendance summary", a), ("Salary sheet", s)):
            if rec and base is not rec and base.get("name") and rec.get("name"):
                sim = name_similarity(base["name"], rec["name"])
                if sim < cfg.name_match_threshold:
                    self.add(e, nm, MST, "Medium", "Name mismatch",
                             expected=base["name"], actual=rec["name"],
                             msg=f"{label} name '{rec['name']}' differs from '{base['name']}' "
                                 f"(similarity {sim:.0%}).", ref=refs)

        # exited in master but paid
        if m and any(w in str(m.get("status", "")).lower() for w in INACTIVE_WORDS) and s \
                and _f(s.get("payable_days")) > 0 and "exit" not in self.approved_types.get(e, set()):
            self.add(e, nm, MST, "High", "Exited employee on salary sheet",
                     msg=f"Master status is '{m.get('status')}' but the employee is paid "
                         f"{_f(s.get('payable_days')):g} days with no approved exit instruction.", ref=refs)

        pd_verified = self._attendance(e, a, s, nm, refs)
        if s:
            self._salary(e, m, s, nm, refs, pd_verified)
            self._master_changes(e, m, s, p, nm, refs)

    # ---- FR-02 attendance (summary only; logs handled separately) ----
    def _attendance(self, e, a, s, nm, refs):
        cfg = self.cfg
        if not a:
            return None
        comps = [c for c in ("present", "paid_leave", "weekly_off", "holidays") if c in a]
        pay_sum = a.get("payable_days")
        pay_sum = None if pay_sum is None or pay_sum != pay_sum else pay_sum
        calc = sum(_f(a.get(c)) for c in comps) if len(comps) >= 2 else None
        if calc is not None and pay_sum is not None and not _close(calc, pay_sum, cfg.day_tolerance):
            self.add(e, nm, ATT, "Medium", "Payable days calculation",
                     expected=calc, actual=pay_sum,
                     msg=f"Summary payable days {pay_sum:g} differ from present+paid leave+weekly off+"
                         f"holidays = {calc:g}.", ref=refs)
        parts = [c for c in ("present", "absent", "paid_leave", "unpaid_leave", "weekly_off", "holidays")
                 if c in a]
        if "total_days" in a and "absent" in a and pay_sum is not None:
            exp = max(0.0, _f(a["total_days"]) - _f(a["absent"]) - _f(a.get("unpaid_leave")))
            if not _close(exp, pay_sum, cfg.day_tolerance):
                self.add(e, nm, ATT, "Medium", "Payable days calculation", expected=exp, actual=pay_sum,
                         msg=f"Working days {pay_sum:g} differ from total days {_f(a['total_days']):g} - "
                             f"absent {_f(a['absent']):g} - unpaid leave {_f(a.get('unpaid_leave')):g} "
                             f"= {exp:g}.", ref=refs)
            if _f(a["absent"]) > _f(a["total_days"]) + cfg.day_tolerance:
                self.add(e, nm, ATT, "Low", "Absent days exceed month", expected=a["total_days"],
                         actual=a["absent"], msg=f"Absent days {_f(a['absent']):g} exceed the "
                                                 f"{_f(a['total_days']):g}-day period.", ref=refs)
        st = str(a.get("salary_status", "")).strip().upper().replace(" ", "_")
        if st and s is not None:
            hold = _f(s.get("hold"))
            cash = _f(s.get("gross")) > cfg.tolerance
            if st == "HOLD" and cash and hold <= cfg.tolerance:
                self.add(e, nm, HLD, "High", "Marked HOLD but not held", expected="hold", actual=hold,
                         msg="Attendance/work log marks salary status HOLD "
                             f"({str(a.get('comment', ''))[:80].strip()}) but the salary sheet shows no hold "
                             "amount.", ref=refs)
            elif st in ("PAY", "WITH_ARREAR", "NEXT_MONTH_ARREAR") and hold > cfg.tolerance:
                self.add(e, nm, HLD, "High", "Held but marked PAY", expected=0, actual=hold,
                         msg=f"Salary sheet holds {_inr(hold)} but the work log status is {st}.", ref=refs)
            elif st == "UNPAID" and _f(s.get("net")) > cfg.tolerance:
                self.add(e, nm, SAL, "High", "Marked UNPAID but paid", actual=s.get("net"),
                         msg="Work log marks the employee UNPAID but net pay is positive.", ref=refs)
            if st == "WITH_ARREAR" and _f(s.get("release")) + _f(s.get("arrears")) <= cfg.tolerance:
                self.add(e, nm, ARR, "High", "WITH_ARREAR not reflected",
                         msg="Work log says salary is released with arrears this month but the salary "
                             "sheet has no arrears / previous-hold release.", ref=refs)
        if len(parts) >= 4:
            total = sum(_f(a.get(c)) for c in parts)
            if not _close(total, self.dim, cfg.day_tolerance):
                self.add(e, nm, ATT, "Low", "Day count does not tie to month",
                         expected=self.dim, actual=total,
                         msg=f"Attendance categories add up to {total:g} days; month has {self.dim}.",
                         ref=refs)
        if pay_sum is not None and pay_sum > self.dim + cfg.day_tolerance:
            self.add(e, nm, ATT, "High", "Payable days exceed month",
                     expected=self.dim, actual=pay_sum,
                     msg=f"Payable days {pay_sum:g} exceed {self.dim} days in the month.", ref=refs)
        if any(_f(a.get(c)) < 0 for c in parts):
            self.add(e, nm, ATT, "Medium", "Negative attendance value",
                     msg="One or more attendance categories are negative.", ref=refs)
        return calc if calc is not None else pay_sum

    # ---- FR-03 salary ----
    def _salary(self, e, m, s, nm, refs, pd_verified):
        cfg, tol = self.cfg, self.tol
        sal_pd = s.get("payable_days")
        sal_pd = None if sal_pd is None or sal_pd != sal_pd else sal_pd
        use_pd = pd_verified if pd_verified is not None else sal_pd
        if pd_verified is not None and sal_pd is not None and not _close(pd_verified, sal_pd, cfg.day_tolerance):
            self.add(e, nm, SAL, "High", "Payable days vs attendance",
                     expected=pd_verified, actual=sal_pd,
                     msg=f"Salary sheet pays {sal_pd:g} days; attendance supports {pd_verified:g}.",
                     ref=refs)

        # components vs master (pro-rated by verified payable days)
        exp_gross = None
        if m and use_pd is not None:
            f = use_pd / self.dim
            comps = [c for c in COMPONENTS if c in m and c in s]
            for c in comps:
                exp = round(_f(m[c]) * f, 2)
                if not _close(exp, s[c], tol):
                    self.add(e, nm, SAL, "High", f"{c.replace('_', ' ').title()} vs master",
                             expected=exp, actual=s[c],
                             msg=f"{c} should be {_inr(exp)} ({_inr(m[c])} x {use_pd:g}/{self.dim}) but "
                                 f"salary sheet has {_inr(s[c])}.", ref=refs)
            if any(c in m for c in COMPONENTS):
                exp_gross = round(sum(_f(m[c]) for c in COMPONENTS if c in m) * f, 2)
            elif "gross" in m:
                exp_gross = round(_f(m["gross"]) * f, 2)

        comp_sum = sum(_f(s[c]) for c in COMPONENTS if c in s)
        has_comp = any(c in s for c in COMPONENTS)
        adj = _f(s.get("arrears")) + _f(s.get("bonus")) + _f(s.get("release"))
        inc = adj if cfg.gross_includes_adjustments else 0.0   # adjustments already inside gross
        gross = s.get("gross")
        gross = None if gross is None or gross != gross else gross
        if gross is not None and has_comp and not _close(gross, comp_sum + inc, tol):
            self.add(e, nm, SAL, "High", "Gross vs components",
                     expected=round(comp_sum + inc, 2), actual=gross,
                     msg=f"Gross {_inr(gross)} does not equal components {_inr(comp_sum)}"
                         f"{' + arrears/bonus/release ' + _inr(inc) if inc else ''}.", ref=refs)
        g_use = gross if gross is not None else (comp_sum + inc if has_comp else None)
        g_base = None if g_use is None else g_use - inc
        if exp_gross is not None and g_base is not None and not _close(exp_gross, g_base, tol):
            if not any("vs master" in i["check"] and i["emp_id"] == e for i in self.issues):
                self.add(e, nm, SAL, "High", "Gross vs master",
                         expected=exp_gross, actual=g_base,
                         msg=f"Regular gross should be {_inr(exp_gross)} per master and payable days, "
                             f"salary sheet has {_inr(g_base)}.", ref=refs)

        # deductions and net
        parts_present = [c for c in DED_PARTS if c in s]
        ded_total = s.get("total_deductions")
        ded_total = None if ded_total is None or ded_total != ded_total else ded_total
        hold_in = _f(s.get("hold")) if cfg.hold_in_deductions else 0.0
        ded_parts = sum(_f(s[c]) for c in parts_present) + hold_in
        if ded_total is not None and parts_present and not _close(ded_total, ded_parts, tol):
            self.add(e, nm, SAL, "Medium", "Deductions total",
                     expected=round(ded_parts, 2), actual=ded_total,
                     msg=f"Total deductions {_inr(ded_total)} differ from sum of listed deductions "
                         f"{_inr(ded_parts)}{' (incl. hold)' if hold_in else ''}.", ref=refs)
        ded = ded_total if ded_total is not None else ded_parts
        net = s.get("net")
        if g_use is not None and net is not None and net == net:
            calc = g_use + (0.0 if cfg.gross_includes_adjustments else adj) - ded \
                - (0.0 if cfg.hold_in_deductions else _f(s.get("hold")))
            if not _close(calc, net, tol):
                self.add(e, nm, SAL, "High", "Net salary recalculation",
                         expected=round(calc, 2), actual=net,
                         msg=f"Net should be {_inr(calc)} (gross - deductions, per the client's sheet "
                             f"convention) but salary sheet has {_inr(net)}.", ref=refs)
        # negative values
        if _f(s.get("net")) < -tol:
            self.add(e, nm, SAL, "High", "Negative net salary", actual=net,
                     msg="Net salary is negative.", ref=refs)

    # ---- FR-04 master changes + movement flags ----
    def _master_changes(self, e, m, s, p, nm, refs):
        appr = self.approved_types.get(e, set())
        cur = {"designation": (s.get("designation") or (m or {}).get("designation", "")),
               "department": (s.get("department") or (m or {}).get("department", ""))}
        if m:
            for fld in ("designation", "department"):
                if s.get(fld) and m.get(fld) and s[fld].strip().lower() != m[fld].strip().lower():
                    self.add(e, nm, MST, "Medium", f"{fld.title()} salary sheet vs master",
                             expected=m[fld], actual=s[fld],
                             msg=f"Salary sheet {fld} '{s[fld]}' differs from master '{m[fld]}'.", ref=refs)
        if p:
            for fld in ("designation", "department"):
                old, new = p.get(fld, ""), cur[fld]
                if old and new and old.strip().lower() != new.strip().lower():
                    if "designation_change" in appr:
                        self.applied_adj.add(e)
                    else:
                        self.add(e, nm, MST, "High", f"{fld.title()} change without approval",
                                 expected=old, actual=new,
                                 msg=f"{fld.title()} changed from '{old}' to '{new}' with no approved "
                                     "client instruction.", ref=refs + "; " + _ref("Previous salary", p))
        else:
            if self.has["prev_salary"]:
                if "joining" in appr:
                    self.applied_adj.add(e)
                else:
                    self.add(e, nm, APP, "Medium", "New employee without joining instruction",
                             msg="Employee is not in the previous month's salary sheet and there is no "
                                 "approved joining instruction.", ref=refs)
                doj = (m or {}).get("doj")
                if m and doj is not None and pd.notna(doj):
                    y, mo = (int(x) for x in self.cfg.period.split("-"))
                    if (doj.year, doj.month) < (y, mo):
                        self.add(e, nm, MST, "Medium", "DOJ earlier than first payroll",
                                 expected=self.cfg.period, actual=doj.strftime("%Y-%m-%d"),
                                 msg="Master DOJ is before this month but the employee was not paid last "
                                     "month.", ref=refs)

    # ---- exits (in previous month, absent now) ----
    def _prev_only(self):
        if not self.has["prev_salary"]:
            return
        for e, p in self.prev.items():
            if e in self.sal:
                continue
            appr = self.approved_types.get(e, set())
            if "exit" in appr:
                self.applied_adj.add(e)
            elif e in self.att or e in self.master:
                pass   # reported as missing salary record in _employee
            else:
                self.add(e, p.get("name", ""), APP, "Medium", "Exit without instruction",
                         msg="Employee was paid last month but is absent from every current input, with "
                             "no approved exit instruction.", ref=_ref("Previous salary", p))

    # ---- logs (FR-02 detail) ----
    def _logs(self):
        lg = self.d.get("logs")
        if lg is None or "date" not in lg:
            return
        cfg = self.cfg
        start = to_minutes(cfg.shift_start) if cfg.shift_start else None
        end = to_minutes(cfg.shift_end) if cfg.shift_end else None
        per_emp: dict[str, dict] = {}
        for (e, day), g in lg.dropna(subset=["date"]).groupby(["emp_id", "date"]):
            recs = g.to_dict("records")
            def _m(v):
                return None if v is None or v != v else int(v)
            for r in recs:
                r["in_time"], r["out_time"] = _m(r.get("in_time")), _m(r.get("out_time"))
            ins_ = [r["in_time"] for r in recs if r["in_time"] is not None]
            outs = [r["out_time"] for r in recs if r["out_time"] is not None]
            rows = g["_row"].tolist()
            ref = f"Detail log [{lg.attrs.get('file', '')}] rows {rows}"
            st = per_emp.setdefault(e, {"present": set(), "x": {}})
            if ins_ or outs:
                st["present"].add(day)

            def ex(kind, detail):
                st["x"].setdefault(kind, []).append(day.strftime("%d-%b"))
                self.log_rows.append(dict(emp_id=e, name=self.names.get(e, ""), date=day.date(),
                                          exception=kind, detail=detail, source_ref=ref))
            pairs = [(r.get("in_time"), r.get("out_time")) for r in recs]
            if len(pairs) > len(set(pairs)):
                ex("Duplicate punch", f"{len(pairs) - len(set(pairs))} duplicate punch row(s)")
            fi, lo = (min(ins_) if ins_ else None), (max(outs) if outs else None)
            if (fi is None) != (lo is None):
                ex("Missing punch", "Only an " + ("IN" if fi is not None else "OUT") + " punch recorded")
                continue
            if fi is None:
                continue
            hrs = (lo - fi) / 60
            if lo <= fi:
                ex("Unusual hours", f"Logout {lo // 60:02d}:{lo % 60:02d} is not after login "
                                    f"{fi // 60:02d}:{fi % 60:02d}")
            elif hrs < cfg.min_hours or hrs > cfg.max_hours:
                ex("Unusual hours", f"{hrs:.1f} hours worked")
            if start is not None and fi > start + cfg.grace_minutes:
                ex("Late arrival", f"IN {fi // 60:02d}:{fi % 60:02d} vs shift {cfg.shift_start} "
                                   f"(+{cfg.grace_minutes} min grace)")
            if end is not None and lo < end:
                ex("Early departure", f"OUT {lo // 60:02d}:{lo % 60:02d} vs shift end {cfg.shift_end}")
        sev = {"Missing punch": "Low", "Duplicate punch": "Low", "Unusual hours": "Low",
               "Late arrival": "Info", "Early departure": "Info"}
        for e, st in per_emp.items():
            a = self.att.get(e)
            nm = self.names.get(e, "")
            ref = f"Detail log [{lg.attrs.get('file', '')}]"
            if a and "present" in a and not _close(len(st["present"]), a["present"], self.cfg.day_tolerance):
                self.add(e, nm, ATT, "Medium", "Summary vs detailed log",
                         expected=a["present"], actual=len(st["present"]),
                         msg=f"Summary shows {a['present']:g} present days; detailed log shows "
                             f"{len(st['present'])} days with punches.", ref=ref + "; " + _ref("Attendance", a))
            for kind, days in st["x"].items():
                self.add(e, nm, ATT, sev[kind], kind, actual=len(days),
                         msg=f"{kind}: {len(days)} day(s) - {', '.join(days[:8])}"
                             f"{' ...' if len(days) > 8 else ''}.", ref=ref)

    # ---- FR-05/06/07 instruction vs salary sheet ----
    def _instruction_compare(self):
        tol = self.tol
        # first pass fills approved_types before employees are checked: done in run() via pre-scan
        for e, recs in self.ins_by_emp.items():
            s = self.sal.get(e)
            nm = self.names.get(e) or next((r.get("name", "") for r in recs), "")
            appl = [r for r in recs if self._applicable(r)]
            for r in recs:
                if not self._applicable(r):
                    self._comp_row(r["ref"], e, nm, r["itype"], r.get("effective_month", ""), 0, 0,
                                   None, "", r["approval_status"], r["evidence"], "Not applicable to this period",
                                   "Effective month differs from the payroll period; ignored.")
            # hold + release contradiction
            appr_hold = [r for r in appl if r["itype"] == "hold" and r["approved"]]
            appr_rel = [r for r in appl if r["itype"] == "release" and r["approved"]]
            if appr_hold and appr_rel:
                self.add(e, nm, MAN, "Medium", "Hold and release both instructed",
                         msg="Approved hold and approved release for the same employee in one period "
                             f"({', '.join(r['ref'] for r in appr_hold + appr_rel)}); treatment not assumed.",
                         ref="; ".join(_ref("Instruction", r) for r in appr_hold + appr_rel))
            for itype in AMOUNT_TYPES:
                grp = [r for r in appl if r["itype"] == itype]
                if not grp:
                    continue
                self._compare_group(e, nm, itype, grp, s)
            for itype in ("designation_change", "revision", "joining", "exit"):
                for r in [x for x in appl if x["itype"] == itype]:
                    self._status_instruction(e, nm, r, s)
            # evidence
            for r in appl:
                if r["approved"] and not r["evidence"]:
                    self.add(e, nm, APP, "Medium", "Approved without evidence",
                             msg=f"{r['ref']}: marked approved but has no approval reference or source "
                                 "email retained.", ref=_ref("Instruction", r))

        # processed amounts with no instruction at all
        for e, s in self.sal.items():
            nm = self.names.get(e, "")
            have = {r["itype"] for r in self.ins_by_emp.get(e, []) if self._applicable(r)}
            for itype in AMOUNT_TYPES:
                col = SALARY_COL[itype]
                if itype in have or col not in s or _f(s[col]) <= tol:
                    continue
                st = str(self.att.get(e, {}).get("salary_status", "")).strip().upper()
                if (itype == "hold" and st == "HOLD") or \
                        (itype in ("release", "arrear") and st == "WITH_ARREAR"):
                    self._comp_row("work log", e, nm, itype, self.cfg.period, 0, 0, s[col], "",
                                   "Client status", str(self.att[e].get("comment", ""))[:150].strip(),
                                   "Supported by work-log status",
                                   "Status/comment in the client work log; amount not independently "
                                   "instructed.")
                    continue
                prev_same = self.prev.get(e) and _close(self.prev[e].get(col), s[col], tol)
                note = " Same amount was also paid last month (possible duplicate)." if prev_same else ""
                self.add(e, nm, TYPE_CATEGORY[itype] if itype != "deduction" else APP, "High",
                         f"Unsupported {itype}", expected=0, actual=s[col],
                         msg=f"{col} of {_inr(s[col])} on the salary sheet has no client instruction.{note}",
                         ref=_ref("Salary", s))
                self._comp_row("-", e, nm, itype, self.cfg.period, 0, 0, s[col], "", "None", "",
                               "Unsupported - no instruction", note.strip())

    def _compare_group(self, e, nm, itype, grp, s):
        tol = self.tol
        col = SALARY_COL[itype]
        cat = TYPE_CATEGORY[itype]
        refs = ", ".join(r["ref"] for r in grp)
        src = "; ".join(_ref("Instruction", r) for r in grp) + ("; " + _ref("Salary", s) if s else "")
        evidence = " || ".join(sorted({r["evidence"] for r in grp if r["evidence"]}))
        status = "Approved" if all(r["approved"] for r in grp) else (
            "Pending" if not any(r["approved"] for r in grp) else "Partly approved")
        em = ", ".join(sorted({r.get("effective_month") or self.cfg.period for r in grp}))
        processed = _f(s.get(col)) if s and col in s else (None if not s else 0.0)

        if any(r.get("indeterminate") for r in grp):
            self._comp_row(refs, e, nm, itype, em, None, 0, processed, "", status, evidence,
                           "Manual review", "Instruction amount missing/ambiguous.")
            return
        appr = [r for r in grp if r["approved"]]
        pend = [r for r in grp if not r["approved"]]
        amounts = sorted({round(_f(r["amount"]), 2) for r in appr})
        if len(amounts) > 1:
            self.add(e, nm, MAN, "High", "Contradictory instructions", actual=processed or 0,
                     msg=f"{itype}: approved instructions give different amounts "
                         f"({', '.join(_inr(a) for a in amounts)}) - {refs}. Treatment not assumed.", ref=src)
            self._comp_row(refs, e, nm, itype, em, None, sum(_f(r['amount']) for r in pend), processed,
                           "", status, evidence, "Manual review", "Contradictory approved amounts.")
            return
        if len(appr) > len(amounts):
            self.add(e, nm, MAN, "Medium", "Duplicate instruction", expected=amounts[0], actual=amounts[0],
                     msg=f"{itype}: the same approved amount {_inr(amounts[0])} was instructed "
                         f"{len(appr)} times ({refs}). Counted once; confirm it is not meant to be paid "
                         "twice.", ref=src)
        approved_amt = amounts[0] if amounts else 0.0
        pending_amt = sum(_f(r["amount"]) for r in pend)
        if processed is None:
            self._comp_row(refs, e, nm, itype, em, approved_amt, pending_amt, 0, "", status, evidence,
                           "Employee not in salary sheet", "")
            return
        diff = round(processed - approved_amt, 2)
        if approved_amt > 0:
            if abs(diff) <= tol:
                result, rem = "Matched", ""
                self.applied_adj.add(e)
            elif processed <= tol:
                result, rem = "Not processed", "Approved amount is missing from the salary sheet."
                self.add(e, nm, cat, "High", f"{itype.title()} not processed", expected=approved_amt,
                         actual=processed, msg=f"Approved {itype} {_inr(approved_amt)} ({refs}) is not "
                                              "reflected in the salary sheet.", ref=src)
            elif diff > 0:
                result, rem = "Excess", f"Paid {_inr(diff)} more than approved."
                self.add(e, nm, cat, "High", f"{itype.title()} excess", expected=approved_amt,
                         actual=processed, msg=f"{col} {_inr(processed)} exceeds approved {_inr(approved_amt)} "
                                               f"({refs}) by {_inr(diff)}.", ref=src)
            else:
                result, rem = "Short", f"Paid {_inr(-diff)} less than approved."
                self.add(e, nm, cat, "High", f"{itype.title()} short", expected=approved_amt,
                         actual=processed, msg=f"{col} {_inr(processed)} is below approved {_inr(approved_amt)} "
                                               f"({refs}) by {_inr(-diff)}.", ref=src)
        elif processed > tol:
            result, rem = "Paid without approval", "Instruction exists but is not approved."
            self.add(e, nm, APP, "High", f"{itype.title()} paid without approval", expected=0,
                     actual=processed, msg=f"{col} {_inr(processed)} paid but instruction(s) {refs} are not "
                                           "approved.", ref=src)
        else:
            result, rem = "Pending approval - not paid", ""
            self.add(e, nm, APP, "Low", f"{itype.title()} awaiting approval", expected=0, actual=0,
                     msg=f"{itype} {_inr(pending_amt)} ({refs}) awaits client approval; correctly not paid.",
                     ref=src)
        # hold/release against outstanding balance checked in _hold_register
        self._comp_row(refs, e, nm, itype, em, approved_amt, pending_amt, processed, diff, status,
                       evidence, result, rem)

    def _status_instruction(self, e, nm, r, s):
        itype = r["itype"]
        label = {"designation_change": "Designation change", "revision": "Salary revision",
                 "joining": "New joining", "exit": "Exit"}[itype]
        src = _ref("Instruction", r)
        if not r["approved"]:
            self._comp_row(r["ref"], e, nm, itype, r.get("effective_month", ""), None, 0, None, "",
                           r.get("approval_status", ""), r["evidence"], "Pending approval",
                           r.get("remarks", ""))
            self.add(e, nm, APP, "Low", f"{label} awaiting approval",
                     msg=f"{r['ref']}: {label.lower()} instruction is not approved.", ref=src)
            return
        p, cur = self.prev.get(e), s
        reflected = None
        if itype == "joining":
            reflected = bool(s) and (p is None or not self.has["prev_salary"])
        elif itype == "exit":
            reflected = s is None or _f(s.get("payable_days")) <= 0
        elif itype == "designation_change" and p and s:
            reflected = bool(s.get("designation")) and s["designation"].strip().lower() != \
                p.get("designation", "").strip().lower()
        elif itype == "revision" and p and s:
            pr, cr = self._rate(p, self.cfg.prev_days_in_month), self._rate(s)
            reflected = pr is not None and cr is not None and abs(cr - pr) / max(pr, 1) * 100 > \
                self.cfg.rate_change_pct
        if itype in ("designation_change", "revision", "joining", "exit"):
            self.approved_types.setdefault(e, set()).add(itype)
        if reflected is False:
            self.add(e, nm, MST if itype != "revision" else SAL, "Medium", f"{label} not reflected",
                     msg=f"{r['ref']}: approved {label.lower()} is not visible in the current salary "
                         "data.", ref=src)
        self._comp_row(r["ref"], e, nm, itype, r.get("effective_month", ""), None, 0, None, "",
                       r.get("approval_status", ""), r["evidence"],
                       "Reflected" if reflected else ("Not reflected" if reflected is False else "Approved"),
                       r.get("remarks", ""))

    def _rate(self, rec, dim=None):
        """Monthly-equivalent gross = gross / payable days x days in that month."""
        pdays = _f(rec.get("payable_days"))
        g = rec.get("gross")
        if g is None or g != g:
            g = sum(_f(rec.get(c)) for c in COMPONENTS)
        if self.cfg.gross_includes_adjustments:
            g -= _f(rec.get("arrears")) + _f(rec.get("bonus")) + _f(rec.get("release"))
        return g / pdays * (dim or self.dim) if pdays > 0 and g else None

    def _comp_row(self, ref, e, nm, itype, month, instructed, pending, processed, diff, appr, evidence,
                  result, remarks):
        self.compliance.append({
            "Instruction Ref": ref, "Employee ID": e, "Name": nm, "Instruction Type": itype,
            "Effective Month": month, "Amount Instructed (approved)": instructed,
            "Pending Amount": pending, "Amount Processed": processed, "Difference": diff,
            "Approval Status": appr, "Approval Evidence": evidence, "Result": result, "Remarks": remarks})

    # ---- FR-06 hold register ----
    def _hold_register(self):
        tol = self.tol
        rows = []
        emps = set(self.hold_prev) | {e for e, s in self.sal.items()
                                      if _f(s.get("hold")) > tol or _f(s.get("release")) > tol}
        for e in sorted(emps):
            s = self.sal.get(e, {})
            opening = _f(self.hold_prev.get(e, {}).get("balance"))
            hold, rel = _f(s.get("hold")), _f(s.get("release"))
            closing = round(opening + hold - rel, 2)
            nm = self.names.get(e) or self.hold_prev.get(e, {}).get("name", "")
            first_salary = str(self.att.get(e, {}).get("salary_status", "")).strip().upper() == "WITH_ARREAR"
            if rel > tol and rel > opening + hold + tol and not first_salary:
                self.add(e, nm, HLD, "High", "Release exceeds hold balance", expected=opening + hold,
                         actual=rel,
                         msg=f"Release {_inr(rel)} exceeds outstanding hold balance {_inr(opening + hold)} "
                             f"(opening {_inr(opening)} + new hold {_inr(hold)}).",
                         ref=_ref("Salary", s) + ("; " + _ref("Hold register", self.hold_prev.get(e))
                                                    if e in self.hold_prev else "; no prior hold on record"))
            if opening > tol and e not in self.sal and self.has["salary"]:
                pass  # missing salary record already raised; balance still carried forward
            rows.append({"Employee ID": e, "Name": nm, "Opening Hold Balance": opening,
                         "Held This Month": hold, "Released This Month": rel,
                         "Closing Hold Balance (carry forward)": closing})
        self.hold_rows = rows


def _apply_overrides(issues: pd.DataFrame, overrides: pd.DataFrame | None) -> pd.DataFrame:
    issues["overridden"] = False
    issues["override_info"] = ""
    if overrides is None or overrides.empty:
        return issues
    for rec in overrides.to_dict("records"):
        req = ("issue_id", "reason", "approved_by", "date", "support_ref")
        if any(not str(rec.get(k, "")).strip() for k in req):
            continue   # an override must carry user, date, reason and supporting approval
        mask = issues.issue_id == rec["issue_id"]
        issues.loc[mask, "overridden"] = True
        issues.loc[mask, "override_info"] = (f"{rec['approved_by']} on {rec['date']}: {rec['reason']} "
                                             f"[support: {rec['support_ref']}]")
    return issues


def reconcile(data: dict, cfg: Config, overrides: pd.DataFrame | None = None) -> Result:
    """data keys: master, attendance, salary, prev_salary, instructions, hold_register, logs."""
    if data.get("salary") is None:
        raise ValueError("A salary sheet is required.")
    run = _Run(data, cfg)
    # pre-scan approved status-type instructions so employee checks can use them
    ins = data.get("instructions")
    if ins is not None:
        for rec in ins.to_dict("records"):
            t = norm_type(rec.get("type", ""))
            if t in ("designation_change", "revision", "joining", "exit") and \
                    str(rec.get("approval_status", "")).strip().lower() in APPROVED_WORDS and \
                    rec.get("emp_id") and rec.get("effective_month", "") in ("", cfg.period):
                run.approved_types.setdefault(rec["emp_id"], set()).add(t)
    run.run()
    movement = _movement(run)   # may add "unexplained rate change" issues, so build before issues

    issues = pd.DataFrame(run.issues, columns=["emp_id", "name", "category", "severity", "check",
                                               "expected", "actual", "difference", "message", "source_ref"])
    issues["_s"] = issues.severity.map(SEVERITY_RANK)
    issues = issues.sort_values(["emp_id", "_s"], kind="stable").drop(columns="_s").reset_index(drop=True)
    issues.insert(0, "issue_id", [f"EX-{i + 1:04d}" for i in range(len(issues))])
    issues = _apply_overrides(issues, overrides)
    open_issues = issues[~issues.overridden & (issues.severity != "Info")]

    # employee-wise sheet
    emp_rows = []
    for e in run.universe:
        s, a, m = run.sal.get(e, {}), run.att.get(e, {}), run.master.get(e, {})
        mine = open_issues[open_issues.emp_id == e]
        if len(mine):
            cats = set(mine.category)
            status = next(c for c in STATUS_PRIORITY if c in cats)
        elif e in run.applied_adj or (issues[(issues.emp_id == e) & issues.overridden].shape[0] > 0):
            status = MATCHED_ADJ
        else:
            status = MATCHED
        hr = ""
        if _f(s.get("hold")) > 0:
            hr += f"Hold {_f(s['hold']):,.2f}"
        if _f(s.get("release")) > 0:
            hr += (" / " if hr else "") + f"Release {_f(s['release']):,.2f}"
        verified = None
        if a:
            comps = [c for c in ("present", "paid_leave", "weekly_off", "holidays") if c in a]
            verified = sum(_f(a[c]) for c in comps) if len(comps) >= 2 else a.get("payable_days")
        emp_rows.append({
            "Employee ID": e, "Name": run.names.get(e, ""),
            "Designation": s.get("designation") or m.get("designation", ""),
            "Attendance (Present Days)": a.get("present", "") if a else "",
            "Payable Days (Verified)": verified if verified is not None else "",
            "Payable Days (Salary Sheet)": s.get("payable_days", "") if s else "",
            "Gross Salary": s.get("gross", "") if s else "",
            "Arrears": s.get("arrears", 0.0) if s else "", "Bonus": s.get("bonus", 0.0) if s else "",
            "Hold/Release": hr, "Net Salary": s.get("net", "") if s else "",
            "Verification Status": status, "Open Issues": len(mine),
            "Remarks": " | ".join(mine.message.head(4)) + (" ..." if len(mine) > 4 else "")})
    employees = pd.DataFrame(emp_rows)

    compliance = pd.DataFrame(run.compliance)
    hold_register = pd.DataFrame(run.hold_rows)
    log_detail = pd.DataFrame(run.log_rows, columns=["emp_id", "name", "date", "exception", "detail",
                                                      "source_ref"])
    sal_df = data["salary"].drop_duplicates("emp_id")
    sal_df = sal_df[sal_df.emp_id != ""]

    def tot(col):
        return float(sal_df[col].sum()) if col in sal_df else 0.0
    ded = (sal_df["total_deductions"].fillna(0).sum() if "total_deductions" in sal_df else
           sum(sal_df[c].sum() for c in DED_PARTS if c in sal_df))
    review = employees[~employees["Verification Status"].isin([MATCHED, MATCHED_ADJ])]
    summary = {
        "Total employees (salary sheet)": int(len(sal_df)),
        "Total employees (all inputs)": int(len(employees)),
        "Total gross salary": tot("gross"), "Total deductions": float(ded), "Total net salary": tot("net"),
        "Matched employees": int(len(employees) - len(review)),
        "Employees requiring review": int(len(review)),
        "Total arrears": tot("arrears"), "Total bonus": tot("bonus"),
        "Total salary held": tot("hold"), "Total salary released": tot("release"),
        "Closing hold balance carried forward": float(hold_register.iloc[:, -1].sum()) if len(hold_register) else 0.0,
    }
    by_status = employees["Verification Status"].value_counts().to_dict()
    pending = open_issues[open_issues.category.isin([MAN, APP])]
    high = open_issues[open_issues.severity == "High"]
    blocking = open_issues[open_issues.severity.isin(["High", "Medium"])]
    final = {
        "Total exceptions (open)": int(len(open_issues)),
        "High-risk discrepancies": int(len(high)),
        "Medium": int((open_issues.severity == "Medium").sum()),
        "Low": int((open_issues.severity == "Low").sum()),
        "Overridden exceptions": int(issues.overridden.sum()),
        "Pending client clarifications": int(len(pending)),
        "Decision": "READY FOR APPROVAL" if len(blocking) == 0 and len(pending) == 0 else
                    "HELD FOR REVIEW",
        "by_status": by_status,
    }
    sources = []
    for k, label in (("master", "Employee master"), ("attendance", "Attendance summary"),
                     ("salary", "Salary sheet"), ("prev_salary", "Previous month salary sheet"),
                     ("instructions", "Client instruction register"),
                     ("hold_register", "Previous hold register"), ("logs", "Detailed attendance log")):
        df = data.get(k)
        if df is not None:
            sources.append({"Input": label, "File": df.attrs.get("file", ""), "Rows": len(df),
                            "SHA-256": df.attrs.get("sha256", "")})
    return Result(cfg, employees, issues, log_detail, movement, compliance, hold_register, summary,
                  final, sources)


def _movement(run: _Run) -> pd.DataFrame:
    rows = []
    if not run.has["prev_salary"]:
        return pd.DataFrame()
    for e in sorted(set(run.sal) | set(run.prev)):
        s, p = run.sal.get(e), run.prev.get(e)
        nm = run.names.get(e, "")
        status = "Continuing" if s and p else ("New" if s else "Exit")
        pr = run._rate(p, run.cfg.prev_days_in_month) if p else None
        cr = run._rate(s) if s else None
        pct = round((cr - pr) / pr * 100, 2) if pr and cr else None
        appr = run.approved_types.get(e, set())
        expl = ""
        if status == "New":
            expl = "Approved joining" if "joining" in appr else "No joining instruction"
        elif status == "Exit":
            expl = "Approved exit" if "exit" in appr else "No exit instruction"
        elif pct is not None and abs(pct) > run.cfg.rate_change_pct:
            expl = "Approved revision" if "revision" in appr else "UNEXPLAINED rate change"
            if "revision" in appr:
                run.applied_adj.add(e)
            else:
                run.add(e, nm, SAL, "High", "Unexplained salary rate change", expected=round(pr, 2),
                        actual=round(cr, 2),
                        msg=f"Monthly-equivalent gross (gross / payable days x days in month) moved "
                            f"{pct:+.2f}% ({pr:,.2f} -> {cr:,.2f}) with no approved revision instruction.", ref=_ref("Salary", s) + "; " + _ref("Previous salary", p))
        else:
            expl = "Rate unchanged"
        d_des = bool(p and s and p.get("designation", "").lower() != (s.get("designation") or "").lower()
                     and s.get("designation"))
        rows.append({"Employee ID": e, "Name": nm, "Movement": status,
                     "Prev Designation": p.get("designation", "") if p else "",
                     "Curr Designation": s.get("designation", "") if s else "",
                     "Designation Changed": "Yes" if d_des else "",
                     "Prev Gross": p.get("gross", "") if p else "", "Curr Gross": s.get("gross", "") if s else "",
                     "Gross Change": round(_f(s.get("gross")) - _f(p.get("gross")), 2) if s and p else "",
                     "Prev Net": p.get("net", "") if p else "", "Curr Net": s.get("net", "") if s else "",
                     "Net Change": round(_f(s.get("net")) - _f(p.get("net")), 2) if s and p else "",
                     "Per-day Rate Change %": pct if pct is not None else "", "Explanation": expl})
    return pd.DataFrame(rows)
