# Attendance & Payroll Reconciliation (Phase 1 MVP + early Phase 2/3)

Read-only verification of client payroll data. It never changes salary data or releases payment.

```powershell
pip install -r requirements.txt
python make_sample_data.py      # demo cycle (Oct-2026) with seeded errors
streamlit run app.py            # tick "Use sample data", then Run verification
python -m pytest                # engine tests
```

## Inputs (Excel / CSV / PDF tables)
Column headers are matched by alias (e.g. "Emp Code", "Employee ID", "ID"), and the header row is
auto-detected. See `ALIASES` in `payroll_verify/loader.py` to add client-specific names.

| Input | Required | Key columns |
|---|---|---|
| Employee master | yes | Employee ID, Name, Designation, Department, DOJ, Status, Basic, HRA, Special/Other Allowance |
| Attendance summary | yes | Employee ID, Present, Absent, Paid Leave, Weekly Off, Holidays, Payable Days |
| Salary sheet | yes | ID, Payable Days, components, Gross, PF/ESI/PT/TDS/Other Deductions, Total Deductions, Arrears, Bonus, Hold, Release, Net |
| Previous salary sheet | recommended | same as salary sheet (enables movement, designation, new/exit checks) |
| Client instruction register | optional | Employee ID, Instruction Type, Amount, Effective Month, Approval Status, Approval Ref, Source |
| Previous hold register | optional | Employee ID, Balance |
| Detailed attendance log | optional | Employee ID, Date, In Time, Out Time |

Email parsing (Phase 2) is not automated yet: instructions are entered in the register, one row per
instruction, with the source email reference kept as evidence.

## Rules worth knowing
* Payable days are recomputed as present + paid leave + weekly off + holidays; components are
  recomputed as master amount x payable days / days in month (calendar, or a fixed 26/30 basis).
* Net = gross + arrears + bonus + release - total deductions - hold.
* Salary-rate movement compares gross / payable days x days-in-month against last month.
* Ambiguous or contradictory instructions (blank amount, unknown type, two different approved amounts)
  are flagged for manual review and never assumed.
* An override needs approver, date, reason and supporting reference; overridden exceptions stay listed.
* Employee status = the worst open category (priority in `STATUS_PRIORITY`); "Info" items such as late
  arrivals are listed but do not change status. Payroll is "READY" only with no open High/Medium items
  and no pending clarifications.
* A "special deduction" (Other Deductions column) is expected to have a client instruction.

## Output
`payroll_reconciliation_<period>-<timestamp>-<hash>.xlsx` with sheets A Summary, B Employee Verification,
C Attendance Exceptions (+ log detail), D Salary Movement, E Instruction Compliance, F Final Approval,
All Exceptions, Hold Register (carry-forward for next month), Manual Overrides, Source Files (SHA-256 of
every input). Every exception carries the source file and row.

## Not yet covered (BRD gaps)
Multi-client segregation, user roles/login, encryption at rest, a persistent history database and
automatic email extraction (Phases 2-4). Run this on an access-controlled machine until then.
