@echo off
cd /d "%~dp0"
echo Starting Payroll Checker... your browser will open. Close this window to stop it.
python -m streamlit run app_checker.py --server.headless false --browser.gatherUsageStats false
pause
