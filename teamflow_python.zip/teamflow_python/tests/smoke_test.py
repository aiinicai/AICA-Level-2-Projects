"""End-to-end smoke test against a running TeamFlow (Flask) instance.

Usage:
    python tests/smoke_test.py [base_url]

Defaults to http://127.0.0.1:5000. Assumes the demo data has already been
seeded (python run_seed.py) - it uses the standard demo accounts and does
not delete/reset any data itself, though it does create and then delete a
scratch task and a scratch team member.
"""
import re
import sys
import time

import requests

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000"
PASSWORD = "Passw0rd!"

failures = []


def check(label, cond, detail=""):
    if cond:
        print(f"  OK   {label}")
    else:
        print(f"  FAIL {label} {detail}")
        failures.append(label)


def get_csrf(html):
    m = re.search(r'name="csrf-token" content="([^"]+)"', html)
    return m.group(1) if m else None


def login(session, username, password=PASSWORD):
    r = session.get(f"{BASE}/login")
    r2 = session.post(f"{BASE}/login", data={"username": username, "password": password}, allow_redirects=True)
    return r2


print("== Auth ==")
s_admin = requests.Session()
r = login(s_admin, "admin")
check("admin login redirects to dashboard", r.url.endswith("/") or r.url == BASE + "/", r.url)
check("admin login status 200", r.status_code == 200, r.status_code)

s_bad = requests.Session()
s_bad.get(f"{BASE}/login")
r_bad = s_bad.post(f"{BASE}/login", data={"username": "admin", "password": "wrong-password"})
check("bad password rejected", "Invalid username or password" in r_bad.text)

r_deact = requests.Session()
r_deact.get(f"{BASE}/login")
r_deact_resp = r_deact.post(f"{BASE}/login", data={"username": "lina", "password": PASSWORD})
check("deactivated account blocked", "deactivated" in r_deact_resp.text.lower())

s_member = requests.Session()
login(s_member, "riya")
r_home_member = s_member.get(f"{BASE}/")
check("member login works", r_home_member.status_code == 200)

print("== CSRF token present for logged-in admin ==")
r_home_admin = s_admin.get(f"{BASE}/")
csrf = get_csrf(r_home_admin.text)
check("csrf token found on dashboard page", bool(csrf), csrf)

print("== Dashboard ==")
check("dashboard shows KPI markup", "Total Tasks" in r_home_admin.text)
r_dash_api = s_admin.get(f"{BASE}/api/dashboard/summary")
check("dashboard summary API 200", r_dash_api.status_code == 200, r_dash_api.text[:200])
summary = r_dash_api.json()
check("summary has totalTasks", "totalTasks" in summary, summary)
r_trends_api = s_admin.get(f"{BASE}/api/dashboard/trends")
check("dashboard trends API 200", r_trends_api.status_code == 200, r_trends_api.text[:200])

print("== Authorization: member blocked from admin pages/APIs ==")
r_all_tasks_member = s_member.get(f"{BASE}/tasks")
check("member gets 403 on /tasks", r_all_tasks_member.status_code == 403, r_all_tasks_member.status_code)
r_settings_member = s_member.get(f"{BASE}/settings")
check("member gets 403 on /settings", r_settings_member.status_code == 403, r_settings_member.status_code)
r_users_create_member = s_member.post(
    f"{BASE}/api/users",
    json={"name": "Hacker", "username": "hacker1", "email": "h@x.com", "password": "Passw0rd!", "role": "member", "department": "Engineering"},
    headers={"X-CSRF-Token": get_csrf(r_home_member.text) or ""},
)
check("member forbidden from creating users", r_users_create_member.status_code == 403, r_users_create_member.status_code)

print("== CSRF enforcement ==")
r_no_csrf = s_admin.put(f"{BASE}/api/settings", json={"appName": "ShouldFail"})
check("mutation without CSRF token rejected", r_no_csrf.status_code == 403, r_no_csrf.status_code)

print("== Team member CRUD (admin) ==")
r_users_list = s_admin.get(f"{BASE}/api/users")
check("list users 200", r_users_list.status_code == 200, r_users_list.status_code)
users = r_users_list.json()
check("at least 8 users seeded", len(users) >= 8, len(users))

unique_suffix = str(int(time.time()))
new_user_payload = {
    "name": "Test Person",
    "username": f"testperson{unique_suffix}",
    "email": f"test.person{unique_suffix}@teamflow.demo",
    "password": "Passw0rd!",
    "role": "member",
    "department": "Engineering",
}
r_create_user = s_admin.post(f"{BASE}/api/users", json=new_user_payload, headers={"X-CSRF-Token": csrf})
check("create user 201", r_create_user.status_code in (200, 201), (r_create_user.status_code, r_create_user.text[:200]))
new_user = r_create_user.json()
new_user_id = new_user.get("id")
check("created user has id", bool(new_user_id), new_user)

r_update_user = s_admin.put(
    f"{BASE}/api/users/{new_user_id}",
    json={"department": "Design"},
    headers={"X-CSRF-Token": csrf},
)
check("update user 200", r_update_user.status_code == 200, r_update_user.text[:200])
check("update user reflects new department", r_update_user.json().get("department") == "Design", r_update_user.text[:200])

r_deactivate_user = s_admin.delete(f"{BASE}/api/users/{new_user_id}", headers={"X-CSRF-Token": csrf})
check("deactivate user 200", r_deactivate_user.status_code == 200, r_deactivate_user.text[:200])

r_self_deactivate = s_admin.delete(f"{BASE}/api/users/u-admin", headers={"X-CSRF-Token": csrf})
check("admin cannot deactivate self", r_self_deactivate.status_code == 400, r_self_deactivate.status_code)

print("== Task CRUD + recurrence (admin) ==")
r_tasks_list = s_admin.get(f"{BASE}/api/tasks")
check("list tasks 200", r_tasks_list.status_code == 200, r_tasks_list.status_code)
tasks = r_tasks_list.json()
check("~20 tasks seeded", len(tasks) == 20, len(tasks))

new_task_payload = {
    "taskName": "Smoke test recurring task",
    "description": "Created by smoke_test.py",
    "assignedUserId": "u-1",
    "frequency": "weekly",
    "startDate": "2026-09-01",
    "dueDate": "2026-09-08",
    "priority": "medium",
    "status": "pending",
    "notes": "",
}
r_create_task = s_admin.post(f"{BASE}/api/tasks", json=new_task_payload, headers={"X-CSRF-Token": csrf})
check("create task 201", r_create_task.status_code in (200, 201), (r_create_task.status_code, r_create_task.text[:300]))
created_task = r_create_task.json()
task_id = created_task.get("id") or created_task.get("TaskID")
check("created task has id", bool(task_id), created_task)

# Complete it -> should recur (reset to pending w/ new due date), not stay completed.
r_complete = s_admin.put(
    f"{BASE}/api/tasks/{task_id}",
    json={"status": "completed", "notes": "done for this cycle"},
    headers={"X-CSRF-Token": csrf},
)
check("complete recurring task 200", r_complete.status_code == 200, r_complete.text[:300])
completed_result = r_complete.json()
result_status = completed_result.get("status") or completed_result.get("Status")
result_due = completed_result.get("dueDate") or completed_result.get("DueDate")
check("recurring task reset to pending after completion", result_status == "pending", completed_result)
check("recurring task got a new (later) due date", result_due and result_due > "2026-09-08", result_due)

# One-time task should stay completed.
one_time_payload = dict(new_task_payload)
one_time_payload.update({"taskName": "Smoke test one-time task", "frequency": "one-time"})
r_create_onetime = s_admin.post(f"{BASE}/api/tasks", json=one_time_payload, headers={"X-CSRF-Token": csrf})
onetime_task = r_create_onetime.json()
onetime_id = onetime_task.get("id") or onetime_task.get("TaskID")
r_complete_onetime = s_admin.put(
    f"{BASE}/api/tasks/{onetime_id}",
    json={"status": "completed", "notes": "final"},
    headers={"X-CSRF-Token": csrf},
)
onetime_result = r_complete_onetime.json()
check(
    "one-time task stays completed",
    (onetime_result.get("status") or onetime_result.get("Status")) == "completed",
    onetime_result,
)

print("== Member field-level authorization on tasks ==")
csrf_member = get_csrf(s_member.get(f"{BASE}/").text)
r_member_update_allowed = s_member.put(
    f"{BASE}/api/tasks/{task_id}",
    json={"status": "in-progress", "notes": "member note"},
    headers={"X-CSRF-Token": csrf_member},
)
check(
    "member can update status/notes on own task (or 403 if not assigned to them)",
    r_member_update_allowed.status_code in (200, 403),
    r_member_update_allowed.status_code,
)
r_member_update_forbidden_field = s_member.put(
    f"{BASE}/api/tasks/{task_id}",
    json={"taskName": "Hacked name"},
    headers={"X-CSRF-Token": csrf_member},
)
check(
    "member forbidden from editing taskName field",
    r_member_update_forbidden_field.status_code == 403,
    r_member_update_forbidden_field.status_code,
)

# Clean up scratch tasks
for tid in (task_id, onetime_id):
    if tid:
        s_admin.delete(f"{BASE}/api/tasks/{tid}", headers={"X-CSRF-Token": csrf})
r_tasks_after_cleanup = s_admin.get(f"{BASE}/api/tasks").json()
check("scratch tasks cleaned up", len(r_tasks_after_cleanup) == 20, len(r_tasks_after_cleanup))

print("== Settings ==")
r_settings_get = s_admin.get(f"{BASE}/api/settings")
check("get settings 200", r_settings_get.status_code == 200, r_settings_get.status_code)
original_app_name = r_settings_get.json().get("appName")
r_settings_put = s_admin.put(f"{BASE}/api/settings", json={"appName": "TeamFlow Test"}, headers={"X-CSRF-Token": csrf})
check("update settings 200", r_settings_put.status_code == 200, r_settings_put.text[:200])
r_home_after = s_admin.get(f"{BASE}/")
check("new app name appears on page", "TeamFlow Test" in r_home_after.text)
# restore
s_admin.put(f"{BASE}/api/settings", json={"appName": original_app_name or "TeamFlow"}, headers={"X-CSRF-Token": csrf})

print("== Server-rendered pages ==")
for path in ("/", "/team", "/my-tasks", "/tasks", "/settings", "/profile"):
    r = s_admin.get(f"{BASE}{path}")
    check(f"admin GET {path} -> 200", r.status_code == 200, r.status_code)
for path in ("/", "/team", "/my-tasks", "/profile"):
    r = s_member.get(f"{BASE}{path}")
    check(f"member GET {path} -> 200", r.status_code == 200, r.status_code)

print("== Logout ==")
r_logout = s_admin.post(f"{BASE}/logout")
r_after_logout = s_admin.get(f"{BASE}/", allow_redirects=False)
check("after logout, dashboard redirects (not 200)", r_after_logout.status_code in (302, 401), r_after_logout.status_code)

print()
if failures:
    print(f"{len(failures)} FAILURE(S): {failures}")
    sys.exit(1)
else:
    print("All checks passed.")
