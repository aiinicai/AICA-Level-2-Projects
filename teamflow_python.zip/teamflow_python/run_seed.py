"""Convenience wrapper so the demo data can be seeded with:
    python run_seed.py
instead of remembering the `python -m teamflow.seed` module syntax.
Safe to re-run - it fully replaces the Users/Tasks/Settings sheets.
"""
from teamflow.seed import main

if __name__ == "__main__":
    main()
