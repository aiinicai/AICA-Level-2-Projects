"""All dates in this app are stored/compared as plain "YYYY-MM-DD" strings
(UTC) to avoid timezone drift between the server, the Excel file, and the
browser. Do not mix these with local-time datetime math elsewhere."""
import re
from datetime import date, datetime, timedelta, timezone

_DATE_ONLY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def today_iso_date() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def now_iso() -> str:
    """Full ISO-8601 timestamp, matching the Node version's `new Date().toISOString()`."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"


def is_valid_date_only(value: str) -> bool:
    if not value or not _DATE_ONLY_RE.match(value):
        return False
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def _parse(date_str: str) -> date:
    return datetime.strptime(date_str, "%Y-%m-%d").date()


def add_days(date_str: str, days: int) -> str:
    d = _parse(date_str) + timedelta(days=days)
    return d.isoformat()


def add_months(date_str: str, months: int) -> str:
    d = _parse(date_str)
    month_index = d.month - 1 + months
    year = d.year + month_index // 12
    month = month_index % 12 + 1
    # Clamp the day for months with fewer days (e.g. Jan 31 + 1 month -> Feb 28/29).
    day = d.day
    while True:
        try:
            return date(year, month, day).isoformat()
        except ValueError:
            day -= 1


def days_between(a_iso_date: str, b_iso_date: str) -> int:
    """b - a, in whole days. Positive when b is after a."""
    return (_parse(b_iso_date) - _parse(a_iso_date)).days


def max_date(a: str, b: str) -> str:
    return b if days_between(a, b) >= 0 else a
