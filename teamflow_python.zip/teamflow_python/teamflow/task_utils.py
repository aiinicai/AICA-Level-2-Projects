"""Status as stored can go stale (a task's due date passes without anyone
touching it). This derives what should actually be shown "right now" without
needing a background job to rewrite every row - mirrors taskUtils.ts."""
from .utils.dates import days_between


def compute_display_status(task: dict, today: str) -> str:
    if task["Status"] == "completed":
        return "completed"
    if task.get("DueDate") and days_between(today, task["DueDate"]) < 0:
        return "overdue"
    if task["Status"] == "overdue":
        return "pending"  # due date has since moved forward
    return task["Status"]


def days_remaining(task: dict, today: str):
    if not task.get("DueDate"):
        return None
    return days_between(today, task["DueDate"])


def with_computed(task: dict, today: str) -> dict:
    return {
        **task,
        "DisplayStatus": compute_display_status(task, today),
        "DaysRemaining": days_remaining(task, today),
    }


def task_summary_for_user(tasks, user_id, today):
    mine = [t for t in tasks if t["AssignedUserID"] == user_id]
    overdue = sum(1 for t in mine if compute_display_status(t, today) == "overdue")
    upcoming = 0
    for t in mine:
        status = compute_display_status(t, today)
        if status in ("completed", "overdue"):
            continue
        remaining = days_remaining(t, today)
        if remaining is not None and 0 <= remaining <= 7:
            upcoming += 1
    return {"assigned": len(mine), "overdue": overdue, "upcoming": upcoming}
