"""Populates data/TeamFlowData.xlsx with demo data: 1 admin, 7 team members,
and ~20 tasks spanning every frequency/status/priority combination.
Safe to re-run - it fully replaces the Users/Tasks/Settings sheets.

Run with:  python -m teamflow.seed
(or the run_seed.py helper script in the project root)
"""
from .excel_db import get_workbook_path, mutate_workbook
from .security import hash_password
from .utils.dates import add_days, now_iso, today_iso_date
from .utils.ids import new_id

DEMO_PASSWORD = "Passw0rd!"


def main():
    password_hash = hash_password(DEMO_PASSWORD)
    now = now_iso()
    today = today_iso_date()

    members = [
        {"ID": "u-admin", "Name": "Avery Patel", "Username": "admin", "Email": "avery.patel@teamflow.demo", "Role": "admin", "Department": "Operations", "Active": True},
        {"ID": "u-1", "Name": "Riya Sharma", "Username": "riya", "Email": "riya.sharma@teamflow.demo", "Role": "member", "Department": "Engineering", "Active": True},
        {"ID": "u-2", "Name": "Daniel Kim", "Username": "daniel", "Email": "daniel.kim@teamflow.demo", "Role": "member", "Department": "Engineering", "Active": True},
        {"ID": "u-3", "Name": "Maria Gonzalez", "Username": "maria", "Email": "maria.gonzalez@teamflow.demo", "Role": "member", "Department": "Design", "Active": True},
        {"ID": "u-4", "Name": "James Okafor", "Username": "james", "Email": "james.okafor@teamflow.demo", "Role": "member", "Department": "Marketing", "Active": True},
        {"ID": "u-5", "Name": "Priya Nair", "Username": "priya", "Email": "priya.nair@teamflow.demo", "Role": "member", "Department": "Finance", "Active": True},
        {"ID": "u-6", "Name": "Tom Becker", "Username": "tom", "Email": "tom.becker@teamflow.demo", "Role": "member", "Department": "Support", "Active": True},
        {"ID": "u-7", "Name": "Lina Haddad", "Username": "lina", "Email": "lina.haddad@teamflow.demo", "Role": "member", "Department": "Engineering", "Active": False},
    ]

    users = [
        {**m, "PasswordHash": password_hash, "CreatedAt": now, "UpdatedAt": now}
        for m in members
    ]

    seed_tasks = [
        {"TaskName": "Weekly status report", "Description": "Compile and send the weekly engineering status report.", "AssignedUserID": "u-1", "Frequency": "weekly", "Status": "pending", "Priority": "medium", "dueInDays": 2},
        {"TaskName": "Server patch rollout", "Description": "Apply the latest security patches to production servers.", "AssignedUserID": "u-2", "Frequency": "monthly", "Status": "in-progress", "Priority": "high", "dueInDays": 2},
        {"TaskName": "Design review - onboarding flow", "Description": "Review updated onboarding mockups with the product team.", "AssignedUserID": "u-3", "Frequency": "one-time", "Status": "pending", "Priority": "medium", "dueInDays": 2},
        {"TaskName": "Payroll reconciliation", "Description": "Reconcile payroll ledger against bank statements.", "AssignedUserID": "u-5", "Frequency": "monthly", "Status": "pending", "Priority": "urgent", "dueInDays": 2},
        {"TaskName": "Daily backup verification", "Description": "Confirm nightly database backups completed successfully.", "AssignedUserID": "u-2", "Frequency": "daily", "Status": "completed", "Priority": "high", "dueInDays": 1, "lastCompletedDaysAgo": 0},
        {"TaskName": "Client renewal call - Acme Corp", "Description": "Quarterly check-in and renewal discussion with Acme Corp.", "AssignedUserID": "u-4", "Frequency": "quarterly", "Status": "overdue", "Priority": "high", "dueInDays": -3},
        {"TaskName": "Expense report submission", "Description": "Submit Q3 department expense report.", "AssignedUserID": "u-5", "Frequency": "quarterly", "Status": "overdue", "Priority": "medium", "dueInDays": -1},
        {"TaskName": "Support ticket backlog triage", "Description": "Triage and prioritize the support ticket backlog.", "AssignedUserID": "u-6", "Frequency": "daily", "Status": "pending", "Priority": "medium", "dueInDays": 0},
        {"TaskName": "Social media content calendar", "Description": "Plan next month's social content calendar.", "AssignedUserID": "u-4", "Frequency": "monthly", "Status": "pending", "Priority": "low", "dueInDays": 5},
        {"TaskName": "Bi-weekly sprint planning", "Description": "Facilitate sprint planning with the engineering team.", "AssignedUserID": "u-1", "Frequency": "biweekly", "Status": "pending", "Priority": "medium", "dueInDays": 4},
        {"TaskName": "Annual security audit", "Description": "Coordinate the annual third-party security audit.", "AssignedUserID": "u-2", "Frequency": "yearly", "Status": "pending", "Priority": "high", "dueInDays": 20},
        {"TaskName": "Half-yearly performance reviews", "Description": "Conduct half-yearly performance reviews for direct reports.", "AssignedUserID": "u-1", "Frequency": "half-yearly", "Status": "pending", "Priority": "medium", "dueInDays": 15},
        {"TaskName": "Design system audit", "Description": "Audit component library for consistency.", "AssignedUserID": "u-3", "Frequency": "custom", "customDays": 45, "Status": "in-progress", "Priority": "low", "dueInDays": 10},
        {"TaskName": "Vendor contract renewal", "Description": "Review and renew the office supplies vendor contract.", "AssignedUserID": "u-5", "Frequency": "yearly", "Status": "pending", "Priority": "low", "dueInDays": 30},
        {"TaskName": "Onboard new hire - Engineering", "Description": "Complete onboarding checklist for the new engineering hire.", "AssignedUserID": "u-1", "Frequency": "one-time", "Status": "completed", "Priority": "medium", "dueInDays": -5, "lastCompletedDaysAgo": 6},
        {"TaskName": "Marketing newsletter", "Description": "Draft and send the monthly marketing newsletter.", "AssignedUserID": "u-4", "Frequency": "monthly", "Status": "completed", "Priority": "low", "dueInDays": -2, "lastCompletedDaysAgo": 3},
        {"TaskName": "Weekly customer health check", "Description": "Review customer health scores and flag at-risk accounts.", "AssignedUserID": "u-6", "Frequency": "weekly", "Status": "in-progress", "Priority": "high", "dueInDays": 3},
        {"TaskName": "Budget variance analysis", "Description": "Analyze budget vs. actuals for the current quarter.", "AssignedUserID": "u-5", "Frequency": "quarterly", "Status": "pending", "Priority": "high", "dueInDays": 7},
        {"TaskName": "Code freeze checklist", "Description": "Run through the release code-freeze checklist.", "AssignedUserID": "u-2", "Frequency": "one-time", "Status": "overdue", "Priority": "urgent", "dueInDays": -1},
        {"TaskName": "Team retro", "Description": "Facilitate the engineering team's monthly retrospective.", "AssignedUserID": "u-1", "Frequency": "monthly", "Status": "pending", "Priority": "medium", "dueInDays": 2},
    ]

    tasks = []
    for t in seed_tasks:
        due_date = add_days(today, t["dueInDays"])
        last_completed_date = (
            add_days(today, -t["lastCompletedDaysAgo"]) if "lastCompletedDaysAgo" in t else ""
        )
        tasks.append({
            "TaskID": new_id("task"),
            "TaskName": t["TaskName"],
            "Description": t["Description"],
            "AssignedUserID": t["AssignedUserID"],
            "Frequency": t["Frequency"],
            "CustomFrequencyDays": t.get("customDays", ""),
            "StartDate": add_days(due_date, -30),
            "DueDate": due_date,
            "Status": t["Status"],
            "Priority": t["Priority"],
            "LastCompletedDate": last_completed_date,
            "NextDueDate": "",
            "Notes": "",
            "CreatedAt": now,
            "UpdatedAt": now,
        })

    def do_seed(ctx):
        ctx.set_users(users)
        ctx.set_tasks(tasks)
        ctx.set_settings({"appName": "TeamFlow", "seededAt": now})

    mutate_workbook(do_seed)

    print(f"Seed complete. Workbook: {get_workbook_path()}")
    print("\nDemo accounts (all use the same password):")
    print(f"{'Username':<10} {'Role':<8} Name")
    for u in users:
        print(f"{u['Username']:<10} {u['Role']:<8} {u['Name']}")
    print(f"\nPassword for every demo account: {DEMO_PASSWORD}\n")


if __name__ == "__main__":
    main()
