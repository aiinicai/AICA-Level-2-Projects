"""Computes the next due date for a recurring task.

Assumption (documented in README "Known limitations / assumptions"): the
next occurrence is scheduled from whichever is later of the task's current
due date or its completion date. This keeps a recurring task on its regular
schedule when completed on time, while avoiding a pile-up of back-to-back
due dates when a task is completed late.
"""
from .utils.dates import add_days, add_months, max_date


def compute_next_due_date(current_due_date, completion_date, frequency, custom_frequency_days=None):
    if frequency == "one-time":
        return None

    base = max_date(current_due_date, completion_date)

    if frequency == "daily":
        return add_days(base, 1)
    if frequency == "weekly":
        return add_days(base, 7)
    if frequency == "biweekly":
        return add_days(base, 14)
    if frequency == "monthly":
        return add_months(base, 1)
    if frequency == "quarterly":
        return add_months(base, 3)
    if frequency == "half-yearly":
        return add_months(base, 6)
    if frequency == "yearly":
        return add_months(base, 12)
    if frequency == "custom":
        days = custom_frequency_days if isinstance(custom_frequency_days, int) and custom_frequency_days > 0 else 30
        return add_days(base, days)
    return None
