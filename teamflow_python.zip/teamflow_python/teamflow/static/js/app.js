/* Shared helpers: toasts, an authenticated fetch wrapper (adds the CSRF
 * header), generic modal open/close, a reusable confirm dialog, and the
 * mobile nav toggle. Loaded on every page via base.html. */

const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || "";

function toast(message, kind = "info") {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  const el = document.createElement("div");
  el.className = `toast toast-${kind}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

async function apiFetch(url, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (options.method && options.method !== "GET") {
    headers["X-CSRF-Token"] = CSRF_TOKEN;
  }
  const res = await fetch(url, { ...options, headers });
  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    data = null;
  }
  if (!res.ok) {
    const message = (data && data.error) || "Something went wrong. Please try again.";
    throw new Error(message);
  }
  return data;
}

function openModal(id) {
  document.getElementById(id)?.classList.add("open");
}

function closeModal(id) {
  document.getElementById(id)?.classList.remove("open");
}

// Generic confirm dialog: confirmAction({ title, message, confirmLabel, danger, onConfirm })
const _confirmState = { onConfirm: null };

function confirmAction({ title, message, confirmLabel = "Confirm", danger = false, onConfirm }) {
  document.getElementById("confirm-title").textContent = title;
  document.getElementById("confirm-message").textContent = message;
  const btn = document.getElementById("confirm-btn");
  btn.textContent = confirmLabel;
  btn.className = danger ? "btn-danger" : "btn-primary";
  btn.disabled = false;
  _confirmState.onConfirm = onConfirm;
  openModal("confirm-dialog");
}

document.addEventListener("DOMContentLoaded", () => {
  const confirmBtn = document.getElementById("confirm-btn");
  const cancelBtn = document.getElementById("confirm-cancel-btn");
  if (confirmBtn) {
    confirmBtn.addEventListener("click", async () => {
      if (!_confirmState.onConfirm) return;
      confirmBtn.disabled = true;
      confirmBtn.textContent = "Please wait...";
      try {
        await _confirmState.onConfirm();
        closeModal("confirm-dialog");
      } catch (err) {
        toast(err.message, "error");
      } finally {
        confirmBtn.disabled = false;
      }
    });
  }
  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => closeModal("confirm-dialog"));
  }

  const mobileToggle = document.getElementById("mobile-nav-toggle");
  const mobileNav = document.getElementById("mobile-nav");
  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener("click", () => mobileNav.classList.toggle("open"));
  }

  // Auto-submit any <form data-autosubmit> when a select/input inside it changes.
  document.querySelectorAll("form[data-autosubmit]").forEach((form) => {
    form.querySelectorAll("select, input[type=date]").forEach((el) => {
      el.addEventListener("change", () => form.submit());
    });
  });
});
