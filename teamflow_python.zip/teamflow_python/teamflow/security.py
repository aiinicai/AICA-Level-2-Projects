"""Password hashing, session/auth helpers, a lightweight CSRF check, and an
in-memory login rate limiter - the Python/Flask equivalents of the original
authService.ts / authMiddleware.ts."""
import secrets
import threading
import time
from functools import wraps

from flask import abort, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from .config import config
from .excel_db import read_workbook

# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------

def hash_password(plain: str) -> str:
    return generate_password_hash(plain, method="pbkdf2:sha256", salt_length=16)


def verify_password(plain: str, hashed: str) -> bool:
    if not hashed:
        return False
    try:
        return check_password_hash(hashed, plain)
    except ValueError:
        return False


# ---------------------------------------------------------------------------
# Session-based "current user". We deliberately re-check the user still
# exists and is Active on every request (one Excel read), so a deactivated
# account's existing session stops working immediately rather than waiting
# for the session cookie to expire.
# ---------------------------------------------------------------------------

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    users = read_workbook(lambda ctx: ctx.get_users())
    user = next((u for u in users if u["ID"] == user_id), None)
    if not user or not user["Active"]:
        return None
    return user


def public_user(user: dict) -> dict:
    return {
        "id": user["ID"],
        "name": user["Name"],
        "username": user["Username"],
        "email": user["Email"],
        "role": user["Role"],
        "department": user["Department"],
        "active": user["Active"],
    }


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not authenticated."}), 401
            from flask import redirect, url_for

            return redirect(url_for("auth.login_page", next=request.path))
        request.current_user = user
        return view(*args, **kwargs)

    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = getattr(request, "current_user", None) or current_user()
        if not user:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not authenticated."}), 401
            abort(401)
        if user["Role"] != "admin":
            if request.path.startswith("/api/"):
                return jsonify({"error": "You do not have permission to perform this action."}), 403
            abort(403)
        request.current_user = user
        return view(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------------------
# CSRF: a per-session token, expected back as the X-CSRF-Token header on
# every mutating fetch() call from the frontend JS. Login/logout forms are
# plain POSTs protected by Flask's SameSite=Lax session cookie instead.
# ---------------------------------------------------------------------------

def get_csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_hex(24)
        session["csrf_token"] = token
    return token


def csrf_protect(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.headers.get("X-CSRF-Token", "")
            expected = session.get("csrf_token", "")
            if not expected or not secrets.compare_digest(sent, expected):
                return jsonify({"error": "Invalid or missing CSRF token. Please refresh the page and try again."}), 403
        return view(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------------------
# Login rate limiting: max N attempts per (username, IP) within a rolling
# window, mirroring express-rate-limit in the original backend.
# ---------------------------------------------------------------------------

_attempts_lock = threading.Lock()
_attempts: dict[str, list[float]] = {}


def check_login_rate_limit(key: str) -> bool:
    """Returns True if this key is allowed to attempt a login right now."""
    window_seconds = config.LOGIN_RATE_LIMIT_WINDOW_MINUTES * 60
    now = time.time()
    with _attempts_lock:
        history = _attempts.setdefault(key, [])
        history[:] = [t for t in history if now - t < window_seconds]
        if len(history) >= config.LOGIN_RATE_LIMIT_MAX_ATTEMPTS:
            return False
        history.append(now)
        return True
