"""Dashboard summary/trend computation, shared by the JSON API and the
server-rendered dashboard page. Mirrors dashboardRoutes.ts."""
from .task_utils import compute_display_status, days_remaining
from .utils.dates import add_days


def _filter_tasks(tasks, users, today, f):
    user_dept = {u["ID"]: u["Department"] for u in users}

    def keep(t):
        if f.get("assignedUserId") and t["AssignedUserID"] != f["assignedUserId"]:
            return False
        if f.get("department") and user_dept.get(t["AssignedUserID"]) != f["department"]:
            return False
        if f.get("status") and compute_display_status(t, today) != f["status"]:
            return False
        if f.get("frequency") and t["Frequency"] != f["frequency"]:
            return False
        if f.get("priority") and t["Priority"] != f["priority"]:
            return False
        if f.get("dueFrom") and (not t.get("DueDate") or t["DueDate"] < f["dueFrom"]):
            return False
        if f.get("dueTo") and (not t.get("DueDate") or t["DueDate"] > f["dueTo"]):
            return False
        return True

    return [t for t in tasks if keep(t)]


def build_summary(tasks, users, today, filters):
    scoped = _filter_tasks(tasks, users, today, filters)
    statuses = [compute_display_status(t, today) for t in scoped]

    total_tasks = len(scoped)
    completed_tasks = statuses.count("completed")
    overdue_tasks = statuses.count("overdue")
    in_progress_tasks = statuses.count("in-progress")
    pending_tasks = statuses.count("pending")

    due_today = sum(
        1 for t in scoped if compute_display_status(t, today) != "completed" and t.get("DueDate") == today
    )

    def _due_soon(t):
        status = compute_display_status(t, today)
        if status in ("completed", "overdue"):
            return False
        remaining = days_remaining(t, today)
        return remaining is not None and 0 <= remaining <= 7

    due_in_7_days = sum(1 for t in scoped if _due_soon(t))

    status_breakdown = [
        {"status": "completed", "count": completed_tasks},
        {"status": "pending", "count": pending_tasks},
        {"status": "in-progress", "count": in_progress_tasks},
        {"status": "overdue", "count": overdue_tasks},
    ]

    by_member = {}
    for t in scoped:
        by_member[t["AssignedUserID"]] = by_member.get(t["AssignedUserID"], 0) + 1
    users_by_id = {u["ID"]: u for u in users}
    tasks_by_team_member = [
        {"userId": uid, "name": users_by_id.get(uid, {}).get("Name", "Unknown"), "count": count}
        for uid, count in by_member.items()
    ]

    upcoming = [t for t in scoped if compute_display_status(t, today) != "completed" and t.get("DueDate")]
    upcoming.sort(key=lambda t: t["DueDate"])
    upcoming_deadlines = [
        {
            "taskId": t["TaskID"],
            "taskName": t["TaskName"],
            "dueDate": t["DueDate"],
            "daysRemaining": days_remaining(t, today),
            "priority": t["Priority"],
            "status": compute_display_status(t, today),
            "assignedUserId": t["AssignedUserID"],
            "assignedUserName": users_by_id.get(t["AssignedUserID"], {}).get("Name", "Unknown"),
        }
        for t in upcoming[:10]
    ]

    return {
        "totalTasks": total_tasks,
        "completedTasks": completed_tasks,
        "pendingTasks": pending_tasks,
        "inProgressTasks": in_progress_tasks,
        "overdueTasks": overdue_tasks,
        "dueToday": due_today,
        "dueIn7Days": due_in_7_days,
        "statusBreakdown": status_breakdown,
        "tasksByTeamMember": tasks_by_team_member,
        "upcomingDeadlines": upcoming_deadlines,
    }


def build_trends(tasks, users, today, filters, days=30):
    scoped = _filter_tasks(tasks, users, today, filters)

    points = []
    for i in range(days - 1, -1, -1):
        date = add_days(today, -i)
        completed = sum(1 for t in scoped if t.get("LastCompletedDate") == date)
        created = sum(1 for t in scoped if t.get("CreatedAt", "")[:10] == date)
        points.append({"date": date, "completed": completed, "created": created})

    cumulative = 0
    cumulative_trend = []
    for p in points:
        cumulative += p["completed"]
        cumulative_trend.append({"date": p["date"], "completed": cumulative})

    return {"daily": points, "cumulativeCompleted": cumulative_trend}
