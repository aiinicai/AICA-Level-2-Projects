from flask import Blueprint, jsonify, request

from ..dashboard_logic import build_summary, build_trends
from ..excel_db import read_workbook
from ..security import login_required
from ..utils.dates import today_iso_date

api_dashboard_bp = Blueprint("api_dashboard", __name__)


def _read_filters(args, current_user):
    filters = {
        "assignedUserId": args.get("assignedUserId"),
        "department": args.get("department"),
        "status": args.get("status"),
        "frequency": args.get("frequency"),
        "priority": args.get("priority"),
        "dueFrom": args.get("dueFrom"),
        "dueTo": args.get("dueTo"),
    }
    # A non-admin can only ever see their own data, no matter what filter is
    # requested - enforced server-side, not just hidden in the UI.
    if current_user["Role"] != "admin":
        filters["assignedUserId"] = current_user["ID"]
    return filters


@api_dashboard_bp.get("/summary")
@login_required
def summary():
    data = read_workbook(lambda ctx: {"tasks": ctx.get_tasks(), "users": ctx.get_users()})
    today = today_iso_date()
    filters = _read_filters(request.args, request.current_user)
    return jsonify(build_summary(data["tasks"], data["users"], today, filters))


@api_dashboard_bp.get("/trends")
@login_required
def trends():
    data = read_workbook(lambda ctx: {"tasks": ctx.get_tasks(), "users": ctx.get_users()})
    today = today_iso_date()
    filters = _read_filters(request.args, request.current_user)
    days = int(request.args.get("days", 30))
    return jsonify(build_trends(data["tasks"], data["users"], today, filters, days))
