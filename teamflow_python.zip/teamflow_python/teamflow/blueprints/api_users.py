import re

from flask import Blueprint, jsonify, request

from ..excel_db import mutate_workbook, read_workbook
from ..security import admin_required, csrf_protect, hash_password, login_required, public_user
from ..task_utils import task_summary_for_user, with_computed
from ..utils.dates import now_iso, today_iso_date
from ..utils.ids import new_id

api_users_bp = Blueprint("api_users", __name__)

USERNAME_RE = re.compile(r"^[a-zA-Z0-9._-]+$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _user_with_counts(user, tasks, today):
    summary = task_summary_for_user(tasks, user["ID"], today)
    return {**public_user(user), "createdAt": user["CreatedAt"], "updatedAt": user["UpdatedAt"], "taskCounts": summary}


@api_users_bp.get("")
@login_required
def list_users():
    data = read_workbook(lambda ctx: {"users": ctx.get_users(), "tasks": ctx.get_tasks()})
    today = today_iso_date()
    return jsonify([_user_with_counts(u, data["tasks"], today) for u in data["users"]])


@api_users_bp.get("/<user_id>")
@login_required
def get_user(user_id):
    data = read_workbook(lambda ctx: {"users": ctx.get_users(), "tasks": ctx.get_tasks()})
    user = next((u for u in data["users"] if u["ID"] == user_id), None)
    if not user:
        return jsonify({"error": "Team member not found."}), 404
    return jsonify(_user_with_counts(user, data["tasks"], today_iso_date()))


@api_users_bp.get("/<user_id>/tasks")
@login_required
def get_user_tasks(user_id):
    current = request.current_user
    if current["Role"] != "admin" and current["ID"] != user_id:
        return jsonify({"error": "You can only view tasks assigned to you."}), 403
    tasks = read_workbook(lambda ctx: ctx.get_tasks())
    today = today_iso_date()
    mine = [with_computed(t, today) for t in tasks if t["AssignedUserID"] == user_id]
    return jsonify(mine)


def _validate_create(payload):
    name = (payload.get("name") or "").strip()
    username = (payload.get("username") or "").strip()
    email = (payload.get("email") or "").strip()
    password = payload.get("password") or ""
    role = payload.get("role")
    department = (payload.get("department") or "").strip()

    if not name:
        return "Full name is required."
    if len(username) < 3 or not USERNAME_RE.match(username):
        return "Username must be at least 3 characters and may only contain letters, numbers, dots, dashes and underscores."
    if not EMAIL_RE.match(email):
        return "A valid email address is required."
    if len(password) < 8:
        return "Password must be at least 8 characters."
    if role not in ("admin", "member"):
        return "Role must be admin or member."
    if not department:
        return "Department is required."
    return None


@api_users_bp.post("")
@login_required
@admin_required
@csrf_protect
def create_user():
    payload = request.get_json(silent=True) or {}
    error = _validate_create(payload)
    if error:
        return jsonify({"error": error}), 400

    username = payload["username"].strip()
    email = payload["email"].strip()

    def _txn(ctx):
        users = ctx.get_users()
        if any(u["Username"].lower() == username.lower() for u in users):
            raise ValueError("USERNAME_TAKEN")
        if any(u["Email"].lower() == email.lower() for u in users):
            raise ValueError("EMAIL_TAKEN")
        now = now_iso()
        new_user = {
            "ID": new_id("u"),
            "Name": payload["name"].strip(),
            "Username": username,
            "PasswordHash": "",
            "Email": email,
            "Role": payload["role"],
            "Department": payload["department"].strip(),
            "Active": bool(payload.get("active", True)),
            "CreatedAt": now,
            "UpdatedAt": now,
        }
        users.append(new_user)
        ctx.set_users(users)
        return new_user

    try:
        created = mutate_workbook(_txn)
    except ValueError as err:
        if str(err) == "USERNAME_TAKEN":
            return jsonify({"error": "That username is already in use."}), 409
        if str(err) == "EMAIL_TAKEN":
            return jsonify({"error": "That email is already in use."}), 409
        raise

    password_hash = hash_password(payload["password"])

    def _set_hash(ctx):
        users = ctx.get_users()
        idx = next((i for i, u in enumerate(users) if u["ID"] == created["ID"]), None)
        if idx is not None:
            users[idx]["PasswordHash"] = password_hash
        ctx.set_users(users)

    mutate_workbook(_set_hash)

    return jsonify(public_user({**created, "PasswordHash": password_hash})), 201


@api_users_bp.put("/<user_id>")
@login_required
@admin_required
@csrf_protect
def update_user(user_id):
    payload = request.get_json(silent=True) or {}

    if "email" in payload and payload["email"] and not EMAIL_RE.match(payload["email"].strip()):
        return jsonify({"error": "A valid email address is required."}), 400
    if "role" in payload and payload["role"] not in ("admin", "member"):
        return jsonify({"error": "Role must be admin or member."}), 400
    if "password" in payload and payload["password"] and len(payload["password"]) < 8:
        return jsonify({"error": "Password must be at least 8 characters."}), 400

    password_hash = hash_password(payload["password"]) if payload.get("password") else None

    def _txn(ctx):
        users = ctx.get_users()
        idx = next((i for i, u in enumerate(users) if u["ID"] == user_id), None)
        if idx is None:
            return None
        user = users[idx]
        users[idx] = {
            **user,
            "Name": payload.get("name", user["Name"]).strip() if payload.get("name") else user["Name"],
            "Email": payload.get("email", user["Email"]).strip() if payload.get("email") else user["Email"],
            "Role": payload.get("role", user["Role"]),
            "Department": payload.get("department", user["Department"]).strip() if payload.get("department") else user["Department"],
            "Active": payload.get("active", user["Active"]),
            "PasswordHash": password_hash or user["PasswordHash"],
            "UpdatedAt": now_iso(),
        }
        ctx.set_users(users)
        return users[idx]

    updated = mutate_workbook(_txn)
    if not updated:
        return jsonify({"error": "Team member not found."}), 404
    return jsonify(public_user(updated))


@api_users_bp.delete("/<user_id>")
@login_required
@admin_required
@csrf_protect
def deactivate_user(user_id):
    current = request.current_user
    if current["ID"] == user_id:
        return jsonify({"error": "You cannot deactivate your own account."}), 400

    def _txn(ctx):
        users = ctx.get_users()
        idx = next((i for i, u in enumerate(users) if u["ID"] == user_id), None)
        if idx is None:
            return None
        users[idx] = {**users[idx], "Active": False, "UpdatedAt": now_iso()}
        ctx.set_users(users)
        return users[idx]

    updated = mutate_workbook(_txn)
    if not updated:
        return jsonify({"error": "Team member not found."}), 404
    return jsonify({"ok": True, "deactivated": True})
