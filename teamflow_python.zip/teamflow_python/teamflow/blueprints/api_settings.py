from flask import Blueprint, jsonify, request

from ..config import config
from ..excel_db import mutate_workbook, read_workbook
from ..security import admin_required, csrf_protect, login_required

api_settings_bp = Blueprint("api_settings", __name__)


@api_settings_bp.get("")
@login_required
@admin_required
def get_settings():
    settings = read_workbook(lambda ctx: ctx.get_settings())
    return jsonify({"appName": settings.get("appName") or config.APP_NAME_DEFAULT})


@api_settings_bp.put("")
@login_required
@admin_required
@csrf_protect
def update_settings():
    payload = request.get_json(silent=True) or {}
    app_name = (payload.get("appName") or "").strip()
    if app_name and (len(app_name) < 1 or len(app_name) > 60):
        return jsonify({"error": "Application name must be between 1 and 60 characters."}), 400

    def _txn(ctx):
        current = ctx.get_settings()
        next_settings = {**current}
        if app_name:
            next_settings["appName"] = app_name
        ctx.set_settings(next_settings)
        return next_settings

    updated = mutate_workbook(_txn)
    return jsonify({"appName": updated.get("appName") or config.APP_NAME_DEFAULT})
