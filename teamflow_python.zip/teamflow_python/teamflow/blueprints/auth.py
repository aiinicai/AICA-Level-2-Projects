from flask import Blueprint, redirect, render_template, request, session, url_for

from ..excel_db import read_workbook
from ..security import check_login_rate_limit, current_user, verify_password

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login_page():
    if current_user():
        return redirect(url_for("pages.dashboard"))

    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        rate_key = f"{request.remote_addr}:{username.lower()}"
        if not username or not password:
            error = "Please enter both your username and password."
        elif not check_login_rate_limit(rate_key):
            error = "Too many login attempts. Please wait a few minutes and try again."
        else:
            users = read_workbook(lambda ctx: ctx.get_users())
            user = next((u for u in users if u["Username"].lower() == username.lower()), None)
            # Same generic error whether the username doesn't exist or the
            # password is wrong, so login can't be used to enumerate users.
            if not user:
                error = "Invalid username or password."
            elif not user["Active"]:
                error = "This account has been deactivated. Contact your administrator."
            elif not verify_password(password, user["PasswordHash"]):
                error = "Invalid username or password."
            else:
                session.clear()
                session["user_id"] = user["ID"]
                session.permanent = True
                next_url = request.args.get("next") or url_for("pages.dashboard")
                return redirect(next_url)

    return render_template("login.html", error=error)


@auth_bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login_page"))
