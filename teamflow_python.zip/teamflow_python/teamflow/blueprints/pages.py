import math

from flask import Blueprint, abort, redirect, render_template, request, url_for

from ..constants import FREQUENCIES, PRIORITIES, TASK_STATUSES
from ..dashboard_logic import build_summary, build_trends
from ..excel_db import read_workbook
from ..security import login_required, public_user
from ..task_utils import task_summary_for_user, with_computed
from ..utils.dates import today_iso_date

pages_bp = Blueprint("pages", __name__)

TEAM_PAGE_SIZE = 8
TASKS_PAGE_SIZE = 10


def _int_arg(name, default):
    try:
        return max(1, int(request.args.get(name, default)))
    except (TypeError, ValueError):
        return default


@pages_bp.route("/")
@login_required
def dashboard():
    user = request.current_user
    is_admin = user["Role"] == "admin"

    data = read_workbook(lambda ctx: {"tasks": ctx.get_tasks(), "users": ctx.get_users()})
    today = today_iso_date()

    filters = {
        "assignedUserId": request.args.get("assignedUserId") or None,
        "department": request.args.get("department") or None,
        "status": request.args.get("status") or None,
        "frequency": request.args.get("frequency") or None,
        "priority": request.args.get("priority") or None,
        "dueFrom": request.args.get("dueFrom") or None,
        "dueTo": request.args.get("dueTo") or None,
    }
    if not is_admin:
        filters = {"assignedUserId": user["ID"]}

    summary = build_summary(data["tasks"], data["users"], today, filters)
    trends = build_trends(data["tasks"], data["users"], today, filters, 30)

    members = [public_user(u) for u in data["users"]] if is_admin else []
    departments = sorted({u["Department"] for u in data["users"]}) if is_admin else []

    return render_template(
        "dashboard.html",
        is_admin=is_admin,
        summary=summary,
        trends=trends,
        members=members,
        departments=departments,
        filters=filters,
        statuses=TASK_STATUSES,
        frequencies=FREQUENCIES,
        priorities=PRIORITIES,
    )


@pages_bp.route("/team")
@login_required
def team_members():
    user = request.current_user
    is_admin = user["Role"] == "admin"

    data = read_workbook(lambda ctx: {"users": ctx.get_users(), "tasks": ctx.get_tasks()})
    today = today_iso_date()

    search = (request.args.get("search") or "").strip().lower()
    department_filter = request.args.get("department") or ""
    role_filter = request.args.get("role") or ""
    sort_key = request.args.get("sort", "name")
    sort_dir = request.args.get("dir", "asc")
    page = _int_arg("page", 1)

    rows = []
    for u in data["users"]:
        summary = task_summary_for_user(data["tasks"], u["ID"], today)
        rows.append({**public_user(u), "createdAt": u["CreatedAt"], "taskCounts": summary})

    def keep(m):
        if search and search not in f"{m['name']} {m['username']} {m['email']}".lower():
            return False
        if department_filter and m["department"] != department_filter:
            return False
        if role_filter and m["role"] != role_filter:
            return False
        return True

    filtered = [m for m in rows if keep(m)]

    key_fn = {
        "name": lambda m: m["name"].lower(),
        "department": lambda m: m["department"].lower(),
        "assigned": lambda m: m["taskCounts"]["assigned"],
        "overdue": lambda m: m["taskCounts"]["overdue"],
    }.get(sort_key, lambda m: m["name"].lower())
    filtered.sort(key=key_fn, reverse=(sort_dir == "desc"))

    total_pages = max(1, math.ceil(len(filtered) / TEAM_PAGE_SIZE))
    page = min(page, total_pages)
    page_items = filtered[(page - 1) * TEAM_PAGE_SIZE : page * TEAM_PAGE_SIZE]

    departments = sorted({m["department"] for m in rows})

    return render_template(
        "team_members.html",
        is_admin=is_admin,
        members=page_items,
        all_members=rows,
        total_members=len(rows),
        departments=departments,
        search=search,
        department_filter=department_filter,
        role_filter=role_filter,
        sort_key=sort_key,
        sort_dir=sort_dir,
        page=page,
        total_pages=total_pages,
    )


@pages_bp.route("/my-tasks")
@login_required
def my_tasks():
    user = request.current_user
    tasks = read_workbook(lambda ctx: ctx.get_tasks())
    today = today_iso_date()

    mine = [with_computed(t, today) for t in tasks if t["AssignedUserID"] == user["ID"]]
    status_filter = request.args.get("status", "")
    if status_filter:
        mine = [t for t in mine if t["DisplayStatus"] == status_filter]
    mine.sort(key=lambda t: t["DueDate"])

    return render_template("my_tasks.html", tasks=mine, status_filter=status_filter)


@pages_bp.route("/tasks")
@login_required
def all_tasks():
    user = request.current_user
    if user["Role"] != "admin":
        abort(403)

    data = read_workbook(lambda ctx: {"tasks": ctx.get_tasks(), "users": ctx.get_users()})
    today = today_iso_date()
    computed = [with_computed(t, today) for t in data["tasks"]]

    search = (request.args.get("search") or "").strip().lower()
    assignee_filter = request.args.get("assignee") or ""
    status_filter = request.args.get("status") or ""
    priority_filter = request.args.get("priority") or ""
    frequency_filter = request.args.get("frequency") or ""
    page = _int_arg("page", 1)

    def keep(t):
        if search and search not in f"{t['TaskName']} {t.get('Description', '')}".lower():
            return False
        if assignee_filter and t["AssignedUserID"] != assignee_filter:
            return False
        if status_filter and t["DisplayStatus"] != status_filter:
            return False
        if priority_filter and t["Priority"] != priority_filter:
            return False
        if frequency_filter and t["Frequency"] != frequency_filter:
            return False
        return True

    filtered = [t for t in computed if keep(t)]
    filtered.sort(key=lambda t: t["DueDate"])

    total_pages = max(1, math.ceil(len(filtered) / TASKS_PAGE_SIZE))
    page = min(page, total_pages)
    page_items = filtered[(page - 1) * TASKS_PAGE_SIZE : page * TASKS_PAGE_SIZE]

    members = [public_user(u) for u in data["users"]]
    members_by_id = {m["id"]: m for m in members}

    return render_template(
        "all_tasks.html",
        tasks=page_items,
        total_tasks=len(data["tasks"]),
        members=members,
        members_by_id=members_by_id,
        search=search,
        assignee_filter=assignee_filter,
        status_filter=status_filter,
        priority_filter=priority_filter,
        frequency_filter=frequency_filter,
        page=page,
        total_pages=total_pages,
        statuses=TASK_STATUSES,
        priorities=PRIORITIES,
        frequencies=FREQUENCIES,
    )


@pages_bp.route("/settings")
@login_required
def settings_page():
    user = request.current_user
    if user["Role"] != "admin":
        abort(403)
    from ..config import config

    settings = read_workbook(lambda ctx: ctx.get_settings())
    app_name = settings.get("appName") or config.APP_NAME_DEFAULT
    return render_template("settings.html", app_name=app_name)


@pages_bp.route("/profile")
@login_required
def profile():
    user = public_user(request.current_user)
    initials = "".join(part[0] for part in user["name"].split(" ") if part)[:2].upper()
    return render_template("profile.html", profile_user=user, initials=initials)
