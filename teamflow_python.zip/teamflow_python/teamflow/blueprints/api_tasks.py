from flask import Blueprint, jsonify, request

from ..constants import ADMIN_EDITABLE_FIELDS, FREQUENCIES, MEMBER_EDITABLE_FIELDS, PRIORITIES, TASK_STATUSES
from ..excel_db import mutate_workbook, read_workbook
from ..recurrence import compute_next_due_date
from ..security import csrf_protect, login_required
from ..task_utils import with_computed
from ..utils.dates import is_valid_date_only, now_iso, today_iso_date
from ..utils.ids import new_id

api_tasks_bp = Blueprint("api_tasks", __name__)


def _apply_filters(tasks, args):
    result = tasks
    assigned_user_id = args.get("assignedUserId")
    status = args.get("status")
    priority = args.get("priority")
    frequency = args.get("frequency")
    search = args.get("search")
    due_from = args.get("dueFrom")
    due_to = args.get("dueTo")

    if assigned_user_id:
        result = [t for t in result if t["AssignedUserID"] == assigned_user_id]
    if status:
        result = [t for t in result if t["DisplayStatus"] == status]
    if priority:
        result = [t for t in result if t["Priority"] == priority]
    if frequency:
        result = [t for t in result if t["Frequency"] == frequency]
    if due_from:
        result = [t for t in result if t.get("DueDate") and t["DueDate"] >= due_from]
    if due_to:
        result = [t for t in result if t.get("DueDate") and t["DueDate"] <= due_to]
    if search:
        s = search.lower()
        result = [t for t in result if s in t["TaskName"].lower() or s in t.get("Description", "").lower()]
    return result


@api_tasks_bp.get("")
@login_required
def list_tasks():
    tasks = read_workbook(lambda ctx: ctx.get_tasks())
    today = today_iso_date()
    computed = [with_computed(t, today) for t in tasks]

    current = request.current_user
    if current["Role"] != "admin":
        computed = [t for t in computed if t["AssignedUserID"] == current["ID"]]

    computed = _apply_filters(computed, request.args)
    return jsonify(computed)


@api_tasks_bp.get("/<task_id>")
@login_required
def get_task(task_id):
    tasks = read_workbook(lambda ctx: ctx.get_tasks())
    task = next((t for t in tasks if t["TaskID"] == task_id), None)
    if not task:
        return jsonify({"error": "Task not found."}), 404
    current = request.current_user
    if current["Role"] != "admin" and task["AssignedUserID"] != current["ID"]:
        return jsonify({"error": "You can only view tasks assigned to you."}), 403
    return jsonify(with_computed(task, today_iso_date()))


def _validate_create(payload):
    if not (payload.get("taskName") or "").strip():
        return "Task name is required."
    if not payload.get("assignedUserId"):
        return "An assignee is required."
    if payload.get("frequency") not in FREQUENCIES:
        return "A valid frequency is required."
    if not is_valid_date_only(payload.get("startDate", "")):
        return "Start date must be in YYYY-MM-DD format."
    if not is_valid_date_only(payload.get("dueDate", "")):
        return "Due date must be in YYYY-MM-DD format."
    if payload.get("priority") not in PRIORITIES:
        return "A valid priority is required."
    if payload.get("status") and payload["status"] not in TASK_STATUSES:
        return "Invalid status."
    if payload.get("frequency") == "custom":
        days = payload.get("customFrequencyDays")
        if not isinstance(days, int) or days <= 0:
            return "Enter how many days between occurrences for a custom frequency."
    return None


@api_tasks_bp.post("")
@login_required
@csrf_protect
def create_task():
    current = request.current_user
    if current["Role"] != "admin":
        return jsonify({"error": "You do not have permission to perform this action."}), 403

    payload = request.get_json(silent=True) or {}
    error = _validate_create(payload)
    if error:
        return jsonify({"error": error}), 400

    def _txn(ctx):
        users = ctx.get_users()
        if not any(u["ID"] == payload["assignedUserId"] for u in users):
            raise ValueError("UNKNOWN_ASSIGNEE")
        now = now_iso()
        task = {
            "TaskID": new_id("task"),
            "TaskName": payload["taskName"].strip(),
            "Description": payload.get("description") or "",
            "AssignedUserID": payload["assignedUserId"],
            "Frequency": payload["frequency"],
            "CustomFrequencyDays": payload.get("customFrequencyDays", ""),
            "StartDate": payload["startDate"],
            "DueDate": payload["dueDate"],
            "Status": payload.get("status") or "pending",
            "Priority": payload["priority"],
            "LastCompletedDate": "",
            "NextDueDate": "",
            "Notes": payload.get("notes") or "",
            "CreatedAt": now,
            "UpdatedAt": now,
        }
        tasks = ctx.get_tasks()
        tasks.append(task)
        ctx.set_tasks(tasks)
        return task

    try:
        created = mutate_workbook(_txn)
    except ValueError as err:
        if str(err) == "UNKNOWN_ASSIGNEE":
            return jsonify({"error": "The selected team member does not exist."}), 400
        raise

    return jsonify(with_computed(created, today_iso_date())), 201


@api_tasks_bp.put("/<task_id>")
@login_required
@csrf_protect
def update_task(task_id):
    current = request.current_user
    payload = request.get_json(silent=True) or {}

    is_admin = current["Role"] == "admin"
    allowed = ADMIN_EDITABLE_FIELDS if is_admin else MEMBER_EDITABLE_FIELDS
    disallowed = [f for f in payload.keys() if f not in allowed]
    if disallowed:
        if is_admin:
            msg = f"Unsupported field(s): {', '.join(disallowed)}"
        else:
            msg = f"You can only update status and notes on your own tasks. Ask an administrator to change: {', '.join(disallowed)}."
        return jsonify({"error": msg}), 403

    if "frequency" in payload and payload["frequency"] not in FREQUENCIES:
        return jsonify({"error": "A valid frequency is required."}), 400
    if "priority" in payload and payload["priority"] not in PRIORITIES:
        return jsonify({"error": "A valid priority is required."}), 400
    if "status" in payload and payload["status"] not in TASK_STATUSES:
        return jsonify({"error": "Invalid status."}), 400
    for date_field in ("startDate", "dueDate"):
        if date_field in payload and not is_valid_date_only(payload[date_field]):
            return jsonify({"error": "Dates must be in YYYY-MM-DD format."}), 400

    def _txn(ctx):
        tasks = ctx.get_tasks()
        idx = next((i for i, t in enumerate(tasks) if t["TaskID"] == task_id), None)
        if idx is None:
            return {"notFound": True}
        task = tasks[idx]

        if not is_admin and task["AssignedUserID"] != current["ID"]:
            return {"forbidden": True}

        if payload.get("assignedUserId"):
            users = ctx.get_users()
            if not any(u["ID"] == payload["assignedUserId"] for u in users):
                return {"badAssignee": True}

        now = now_iso()
        was_completed = task["Status"] == "completed"
        becoming_completed = payload.get("status") == "completed" and not was_completed

        next_task = {
            **task,
            "TaskName": payload.get("taskName", task["TaskName"]),
            "Description": payload.get("description", task["Description"]),
            "AssignedUserID": payload.get("assignedUserId", task["AssignedUserID"]),
            "Frequency": payload.get("frequency", task["Frequency"]),
            "CustomFrequencyDays": payload.get("customFrequencyDays", task["CustomFrequencyDays"]),
            "StartDate": payload.get("startDate", task["StartDate"]),
            "DueDate": payload.get("dueDate", task["DueDate"]),
            "Priority": payload.get("priority", task["Priority"]),
            "Status": payload.get("status", task["Status"]),
            "Notes": payload.get("notes", task["Notes"]),
            "UpdatedAt": now,
        }

        if becoming_completed:
            today = today_iso_date()
            next_task["LastCompletedDate"] = today
            if next_task["Frequency"] == "one-time":
                next_task["Status"] = "completed"
                next_task["NextDueDate"] = ""
            else:
                custom_days = next_task["CustomFrequencyDays"]
                custom_days = custom_days if isinstance(custom_days, int) else None
                next_due = compute_next_due_date(task["DueDate"], today, next_task["Frequency"], custom_days)
                if next_due:
                    next_task["NextDueDate"] = next_due
                    next_task["DueDate"] = next_due
                    next_task["Status"] = "pending"
                else:
                    next_task["Status"] = "completed"

        tasks[idx] = next_task
        ctx.set_tasks(tasks)
        return {"task": next_task}

    result = mutate_workbook(_txn)

    if result.get("notFound"):
        return jsonify({"error": "Task not found."}), 404
    if result.get("forbidden"):
        return jsonify({"error": "You can only edit tasks assigned to you."}), 403
    if result.get("badAssignee"):
        return jsonify({"error": "The selected team member does not exist."}), 400

    return jsonify(with_computed(result["task"], today_iso_date()))


@api_tasks_bp.delete("/<task_id>")
@login_required
@csrf_protect
def delete_task(task_id):
    current = request.current_user
    if current["Role"] != "admin":
        return jsonify({"error": "You do not have permission to perform this action."}), 403

    def _txn(ctx):
        tasks = ctx.get_tasks()
        idx = next((i for i, t in enumerate(tasks) if t["TaskID"] == task_id), None)
        if idx is None:
            return False
        tasks.pop(idx)
        ctx.set_tasks(tasks)
        return True

    if not mutate_workbook(_txn):
        return jsonify({"error": "Task not found."}), 404
    return jsonify({"ok": True})
