"""Shared enums/constants, mirroring the original TeamFlow's excel/types.ts."""

ROLES = ["admin", "member"]

FREQUENCIES = [
    "one-time",
    "daily",
    "weekly",
    "biweekly",
    "monthly",
    "quarterly",
    "half-yearly",
    "yearly",
    "custom",
]

TASK_STATUSES = ["pending", "in-progress", "completed", "overdue"]

PRIORITIES = ["low", "medium", "high", "urgent"]

# Fields a team member may change on their own task.
MEMBER_EDITABLE_FIELDS = {"status", "notes"}
# Fields an admin may change on any task.
ADMIN_EDITABLE_FIELDS = {
    "taskName",
    "description",
    "assignedUserId",
    "frequency",
    "customFrequencyDays",
    "startDate",
    "dueDate",
    "priority",
    "status",
    "notes",
}

USERS_COLUMNS = [
    "ID", "Name", "Username", "PasswordHash", "Email", "Role",
    "Department", "Active", "CreatedAt", "UpdatedAt",
]

TASKS_COLUMNS = [
    "TaskID", "TaskName", "Description", "AssignedUserID", "Frequency",
    "CustomFrequencyDays", "StartDate", "DueDate", "Status", "Priority",
    "LastCompletedDate", "NextDueDate", "Notes", "CreatedAt", "UpdatedAt",
]

SHEET_USERS = "Users"
SHEET_TASKS = "Tasks"
SHEET_SETTINGS = "Settings"
