"""Environment-based configuration. Nothing is hard-coded: every setting can
be overridden with an environment variable, loaded from a .env file in the
project root if one exists (see .env.example)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

env_path = BASE_DIR / ".env"
if env_path.exists():
    load_dotenv(env_path)


def _bool(value, fallback):
    if value is None or value == "":
        return fallback
    return value.lower() in ("1", "true", "yes")


def _int(value, fallback):
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-insecure-secret-change-me")
    PORT = _int(os.environ.get("PORT"), 5000)
    HOST = os.environ.get("HOST", "127.0.0.1")

    # Where the Excel workbook (the persistence layer) lives.
    EXCEL_FILE_PATH = Path(
        os.environ.get("EXCEL_FILE_PATH", str(BASE_DIR / "data" / "TeamFlowData.xlsx"))
    )

    # Session cookie lifetime, in hours.
    SESSION_LIFETIME_HOURS = _int(os.environ.get("SESSION_LIFETIME_HOURS"), 8)

    # Login rate limiting: max attempts per username+IP within the window.
    LOGIN_RATE_LIMIT_WINDOW_MINUTES = _int(os.environ.get("LOGIN_RATE_LIMIT_WINDOW_MINUTES"), 15)
    LOGIN_RATE_LIMIT_MAX_ATTEMPTS = _int(os.environ.get("LOGIN_RATE_LIMIT_MAX_ATTEMPTS"), 10)

    DEBUG = _bool(os.environ.get("FLASK_DEBUG"), True)

    APP_NAME_DEFAULT = "TeamFlow"


config = Config()

if config.SECRET_KEY == "dev-insecure-secret-change-me" and not config.DEBUG:
    import warnings

    warnings.warn(
        "SECURITY WARNING: SECRET_KEY is using the insecure default value. "
        "Set a real SECRET_KEY in your .env file before deploying this anywhere real."
    )
