"""Flask application factory for TeamFlow (Python edition)."""
from datetime import timedelta

from flask import Flask, g

from .config import config
from .excel_db import read_workbook
from .security import current_user, get_csrf_token


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = config.SECRET_KEY
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=config.SESSION_LIFETIME_HOURS)
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_HTTPONLY"] = True

    from .blueprints.auth import auth_bp
    from .blueprints.pages import pages_bp
    from .blueprints.api_users import api_users_bp
    from .blueprints.api_tasks import api_tasks_bp
    from .blueprints.api_dashboard import api_dashboard_bp
    from .blueprints.api_settings import api_settings_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(pages_bp)
    app.register_blueprint(api_users_bp, url_prefix="/api/users")
    app.register_blueprint(api_tasks_bp, url_prefix="/api/tasks")
    app.register_blueprint(api_dashboard_bp, url_prefix="/api/dashboard")
    app.register_blueprint(api_settings_bp, url_prefix="/api/settings")

    @app.before_request
    def _load_user():
        g.user = current_user()

    @app.context_processor
    def _inject_globals():
        app_name = config.APP_NAME_DEFAULT
        try:
            settings = read_workbook(lambda ctx: ctx.get_settings())
            app_name = settings.get("appName") or app_name
        except Exception:  # noqa: BLE001
            pass
        return {
            "current_user": getattr(g, "user", None),
            "csrf_token": get_csrf_token() if getattr(g, "user", None) else "",
            "app_name": app_name,
        }

    @app.errorhandler(404)
    def not_found(_err):
        from flask import jsonify, request

        if request.path.startswith("/api/"):
            return jsonify({"error": "Not found."}), 404
        from flask import render_template

        return render_template("404.html"), 404

    return app
