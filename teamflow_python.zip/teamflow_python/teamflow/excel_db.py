"""Excel-backed persistence layer, using openpyxl.

Concurrency: Excel is not a real database, so there is no row-level locking
or MVCC. Every read/write in this module goes through a single in-process
lock below, which serializes all workbook access so two overlapping requests
(Flask's dev server is single-threaded by default, but a production WSGI
server may use multiple threads) can never interleave reads/writes of the
same file. This fully protects against corruption from concurrent requests
*within this one process*. It does NOT protect against a second process
(e.g. opening TeamFlowData.xlsx directly in Excel while the server is
running, or running two instances of this app against the same file) - see
the README's "Excel concurrency limitations" section.
"""
import os
import shutil
import threading
import time
from datetime import datetime

from openpyxl import Workbook, load_workbook

from .config import config
from .constants import SHEET_SETTINGS, SHEET_TASKS, SHEET_USERS, TASKS_COLUMNS, USERS_COLUMNS

_lock = threading.RLock()

FILE_PATH = config.EXCEL_FILE_PATH


def _ensure_data_dir():
    FILE_PATH.parent.mkdir(parents=True, exist_ok=True)


def _blank_workbook() -> Workbook:
    wb = Workbook()
    users_ws = wb.active
    users_ws.title = SHEET_USERS
    users_ws.append(USERS_COLUMNS)

    tasks_ws = wb.create_sheet(SHEET_TASKS)
    tasks_ws.append(TASKS_COLUMNS)

    settings_ws = wb.create_sheet(SHEET_SETTINGS)
    settings_ws.append(["Key", "Value"])

    return wb


def _save_workbook_atomic(wb: Workbook):
    _ensure_data_dir()
    tmp_path = FILE_PATH.with_suffix(f".tmp-{os.getpid()}-{int(time.time() * 1000)}.xlsx")
    max_retries = 3
    last_err = None
    for attempt in range(1, max_retries + 1):
        try:
            wb.save(tmp_path)
            os.replace(tmp_path, FILE_PATH)
            return
        except Exception as err:  # noqa: BLE001
            last_err = err
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass
            time.sleep(0.15 * attempt)
    raise RuntimeError(
        "Could not save the Excel workbook. It may be open in another program "
        "(e.g. Microsoft Excel) - please close it and retry."
    ) from last_err


def _load_or_create_workbook() -> Workbook:
    _ensure_data_dir()
    if not FILE_PATH.exists():
        wb = _blank_workbook()
        _save_workbook_atomic(wb)
        return wb

    try:
        wb = load_workbook(FILE_PATH)
        for name in (SHEET_USERS, SHEET_TASKS, SHEET_SETTINGS):
            if name not in wb.sheetnames:
                raise ValueError(f'Missing expected worksheet "{name}"')
        return wb
    except Exception:  # noqa: BLE001
        # Quarantine the corrupted/foreign file rather than crashing.
        backup_path = FILE_PATH.with_name(f"{FILE_PATH.name}.corrupted-{int(time.time() * 1000)}.bak")
        try:
            shutil.move(str(FILE_PATH), str(backup_path))
        except OSError:
            pass
        fresh = _blank_workbook()
        _save_workbook_atomic(fresh)
        return fresh


def _normalize_cell_value(value):
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat()
    return value


def _sheet_to_dicts(ws, columns):
    header_row = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
    col_index = {}
    for idx, header in enumerate(header_row):
        if header in columns:
            col_index[header] = idx

    rows = []
    for row in ws.iter_rows(min_row=2):
        obj = {}
        has_any_value = False
        for col in columns:
            idx = col_index.get(col)
            value = _normalize_cell_value(row[idx].value) if idx is not None and idx < len(row) else ""
            if value != "":
                has_any_value = True
            obj[col] = value
        if has_any_value:
            rows.append(obj)
    return rows


def _dicts_to_sheet(ws, columns, rows):
    ws.delete_rows(1, ws.max_row or 1)
    ws.append(columns)
    for row in rows:
        ws.append([row.get(c, "") for c in columns])
    for i, _ in enumerate(columns, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = 20


class WorkbookCtx:
    def __init__(self, wb: Workbook):
        self._wb = wb

    def get_users(self):
        return _sheet_to_dicts(self._wb[SHEET_USERS], USERS_COLUMNS)

    def set_users(self, rows):
        _dicts_to_sheet(self._wb[SHEET_USERS], USERS_COLUMNS, rows)

    def get_tasks(self):
        return _sheet_to_dicts(self._wb[SHEET_TASKS], TASKS_COLUMNS)

    def set_tasks(self, rows):
        _dicts_to_sheet(self._wb[SHEET_TASKS], TASKS_COLUMNS, rows)

    def get_settings(self):
        ws = self._wb[SHEET_SETTINGS]
        result = {}
        for row in ws.iter_rows(min_row=2):
            key = _normalize_cell_value(row[0].value)
            value = _normalize_cell_value(row[1].value) if len(row) > 1 else ""
            if key:
                result[str(key)] = str(value)
        return result

    def set_settings(self, settings: dict):
        ws = self._wb[SHEET_SETTINGS]
        ws.delete_rows(1, ws.max_row or 1)
        ws.append(["Key", "Value"])
        for k, v in settings.items():
            ws.append([k, v])


def read_workbook(fn):
    """Read-only access. Does not write the workbook back to disk."""
    with _lock:
        wb = _load_or_create_workbook()
        return fn(WorkbookCtx(wb))


def mutate_workbook(fn):
    """Read-modify-write access. Persists the workbook after fn() returns."""
    with _lock:
        wb = _load_or_create_workbook()
        ctx = WorkbookCtx(wb)
        result = fn(ctx)
        _save_workbook_atomic(wb)
        return result


def get_workbook_path() -> str:
    return str(FILE_PATH)
