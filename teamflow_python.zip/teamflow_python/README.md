# TeamFlow (Python / Flask edition)

A full rebuild of the TeamFlow team task-management app using Python, Flask,
and an Excel workbook for storage - same design, same features, no Node.js
required.

## Stack

- **Backend:** Flask (application factory + blueprints)
- **Storage:** a single Excel workbook (`data/TeamFlowData.xlsx`), read and
  written with `openpyxl`. No database server to install.
- **Frontend:** server-rendered pages (Flask + Jinja2 templates), vanilla
  JavaScript for modals/toasts/small AJAX calls, and Chart.js (loaded from a
  CDN) for the dashboard charts.
- **Auth:** signed session cookies (Flask's built-in session), passwords
  hashed with Werkzeug's `pbkdf2:sha256`.

This mirrors the original TeamFlow (Node/Express/React) feature-for-feature:
Admin and Member roles, team member management, task CRUD across 9 recurrence
frequencies, a dashboard with KPIs and charts, and a Settings page - with
email/notification features intentionally left out, matching the current
Node version.

## Quick launch (after the one-time setup below)

Once you've done the one-time setup once, just double-click **`Run TeamFlow.bat`**
in this folder. It starts the server in a small minimized window and opens
your browser to the app automatically. To stop the app, close that minimized
"TeamFlow Server" window from your taskbar (or press Ctrl+C inside it).

## Project layout

```
teamflow_python/
  app.py                  # entry point: python app.py
  run_seed.py             # convenience wrapper: python run_seed.py
  requirements.txt
  .env.example            # copy to .env to customize settings
  data/                   # the Excel workbook lives here (created automatically)
  tests/                  # a scripted end-to-end smoke test (see below)
  teamflow/
    __init__.py           # create_app() application factory
    config.py             # all settings, env-var driven
    constants.py          # roles, frequencies, statuses, priorities, field lists
    excel_db.py           # openpyxl persistence layer (read/mutate workbook)
    security.py           # password hashing, sessions, CSRF, rate limiting
    recurrence.py         # next-due-date calculation for recurring tasks
    task_utils.py         # display status / days remaining / per-user summaries
    dashboard_logic.py    # KPI + chart data aggregation, shared by page + API
    seed.py                # demo data generator
    blueprints/
      auth.py             # /login, /logout
      pages.py            # dashboard, team, my-tasks, tasks, settings, profile
      api_users.py        # /api/users - JSON CRUD
      api_tasks.py        # /api/tasks - JSON CRUD + recurrence handling
      api_dashboard.py    # /api/dashboard/summary, /trends
      api_settings.py     # /api/settings
    templates/            # Jinja2 HTML templates
    static/
      css/style.css       # hand-written CSS recreating the original design
      js/app.js           # fetch helper, toasts, modals, confirm dialogs
```

## Setup

1. **Install Python 3.10+** if you don't already have it.

2. **Create a virtual environment and install dependencies** (from this
   folder):

   Windows (Command Prompt):
   ```
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

   macOS/Linux:
   ```
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **(Optional) Create a `.env` file** by copying `.env.example`, if you want
   to change the port, secret key, or file paths. Sensible defaults are used
   if you skip this.

4. **Seed demo data** (creates `data/TeamFlowData.xlsx` with 1 admin, 7 team
   members, and ~20 sample tasks):

   ```
   python run_seed.py
   ```

5. **Run the app:**

   ```
   python app.py
   ```

   Then open **http://127.0.0.1:5000** in your browser.

## Demo accounts

All demo accounts use the password `Passw0rd!`.

| Username | Role   | Name            | Department  |
|----------|--------|-----------------|-------------|
| admin    | admin  | Avery Patel     | Operations  |
| riya     | member | Riya Sharma     | Engineering |
| daniel   | member | Daniel Kim      | Engineering |
| maria    | member | Maria Gonzalez  | Design      |
| james    | member | James Okafor    | Marketing   |
| priya    | member | Priya Nair      | Finance     |
| tom      | member | Tom Becker      | Support     |
| lina     | member | Lina Haddad     | Engineering (deactivated - for testing) |

## Features

- **Login** with rate limiting (10 attempts / 15 minutes per username+IP) and
  generic error messages that don't reveal whether a username exists.
- **Dashboard** - KPIs (total/completed/pending/overdue/due-today/due-in-7-days),
  a status breakdown doughnut chart, a per-team-member workload bar chart, a
  30-day completion trend line chart, and an upcoming-deadlines list. Admins
  can filter by team member, department, status, frequency, priority, and due
  date range; members see only their own tasks.
- **Team Members** (admin) - searchable/sortable/paginated table, add/edit/
  deactivate members, and a per-member task-summary popup.
- **My Tasks** - every user's assigned tasks, filterable by status, with a
  restricted update form (status + notes only).
- **All Tasks** (admin) - full CRUD over every task, with search and filters
  by assignee/status/priority/frequency, and full edit rights over every
  field.
- **Recurring tasks** - one-time, daily, weekly, biweekly, monthly, quarterly,
  half-yearly, yearly, and custom (every N days). Marking a recurring task
  "completed" automatically reopens it as "pending" with a freshly computed
  due date, instead of staying completed.
- **Settings** (admin) - change the application name shown throughout the UI.
- **Profile** - view your own account details.

## Excel concurrency limitations

Excel is not a real database - there's no row-level locking or multi-writer
support. This app protects against corruption from *concurrent requests
within the running Flask process* using an in-process lock around every
workbook read/write, and saves are atomic (written to a temp file, then
swapped into place) so a crash mid-write can't corrupt the file.

What it does **not** protect against:
- Opening `data/TeamFlowData.xlsx` directly in Microsoft Excel while the app
  is running and saving from there - this can overwrite data the app just
  wrote, or the app's save can fail while Excel has the file locked (the app
  retries a few times, then reports a friendly error).
- Running two separate copies of this app against the same workbook file at
  once.

For a single small team using the app from one running server, this is a
non-issue in practice - just avoid having the Excel file open in Excel at
the same time as the app is running.

If the workbook file ever becomes corrupted or unreadable (e.g. edited by
hand into an invalid format), the app automatically renames it to
`TeamFlowData.xlsx.corrupted-<timestamp>.bak` and starts a fresh, empty
workbook rather than crashing - re-run `python run_seed.py` afterwards to
restore demo data, or restore the `.bak` file's data by hand.

## Security notes

- CSRF: a per-session token is required (as an `X-CSRF-Token` header) on
  every mutating API call. It's automatically injected by `static/js/app.js`.
- Passwords are hashed with `pbkdf2:sha256` (Werkzeug's default), never
  stored or logged in plain text.
- Sessions are Flask's signed cookies (`SESSION_COOKIE_HTTPONLY=True`,
  `SameSite=Lax`); set a real `SECRET_KEY` in `.env` before using this
  anywhere beyond your own machine.
- Every request re-checks that the logged-in user still exists and is
  Active, so deactivating a member logs them out immediately rather than
  waiting for their session to expire.

## Running tests

A scripted smoke test exercises the whole app end-to-end (login, dashboard,
task CRUD + recurrence, team CRUD, authorization boundaries, settings). From
this folder, with the virtual environment active:

```
python tests/smoke_test.py
```

It starts its own temporary copy of the app against a scratch Excel file, so
it won't touch your real `data/TeamFlowData.xlsx`.
