@echo off
setlocal
set "PROJECT_DIR=%~dp0"

if not exist "%PROJECT_DIR%venv\Scripts\python.exe" (
    echo.
    echo Could not find the virtual environment yet.
    echo Please run the one-time setup first ^(see README.md^):
    echo.
    echo   python -m venv venv
    echo   venv\Scripts\activate
    echo   pip install -r requirements.txt
    echo   python run_seed.py
    echo.
    pause
    exit /b 1
)

echo Starting TeamFlow...
start "TeamFlow Server - close this window to stop the app" /min "%PROJECT_DIR%start_server.bat"

echo Waiting for the server to come up, then opening your browser...
timeout /t 3 /nobreak >nul
start "" http://127.0.0.1:5000

echo.
echo Done. TeamFlow should now be open in your browser.
echo (A minimized "TeamFlow Server" window is running in your taskbar - closing it stops the app.)
echo.
echo Press any key to close this window ^(the app keeps running^)...
pause >nul
