"""TeamFlow (Python/Flask edition) - development entry point.

Usage:
    python app.py

Reads HOST/PORT/DEBUG from teamflow/config.py (which itself reads from a
.env file in this directory, if present - see .env.example).
"""
from teamflow import create_app
from teamflow.config import config

app = create_app()

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
