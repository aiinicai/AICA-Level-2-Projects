@echo off
cd /d "%~dp0"
echo Starting TeamFlow server...
echo (this window can be minimized - do not close it while using the app)
echo.
"venv\Scripts\python.exe" app.py
echo.
echo ------------------------------------------------------------
echo The TeamFlow server has stopped (exit code %errorlevel%).
echo If that was unexpected, the error above explains why.
echo ------------------------------------------------------------
pause
