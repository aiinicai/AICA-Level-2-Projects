import React, { useState } from 'react';
import {
  Check,
  AlertCircle,
  Building,
  Users,
  Settings2,
  CalendarDays,
  ShieldAlert,
  ChevronRight,
  ChevronDown,
  RotateCcw,
  Plus,
  Trash2,
  Lock,
  Sparkles
} from 'lucide-react';
import {
  Employee,
  LeaveRecord,
  PolicySettings,
  RosterPeriodConfig,
  SeatBlock
} from '../types';
import { DEFAULT_POLICY_SETTINGS } from '../logic/demoData';
import { format, parseISO } from 'date-fns';

interface SetupStepperProps {
  seatCount: number;
  setSeatCount: (count: number) => void;
  employees: Employee[];
  leaves: LeaveRecord[];
  policy: PolicySettings;
  setPolicy: (policy: PolicySettings) => void;
  period: RosterPeriodConfig;
  setPeriod: (period: RosterPeriodConfig) => void;
  seatBlocks: SeatBlock[];
  setSeatBlocks: (blocks: SeatBlock[]) => void;
  onCalculate: () => void;
  onOpenEmployeeMaster: () => void;
  onOpenLeaveCalendar: (empId?: string) => void;
  workingDaysCount: number;
}

export const SetupStepper: React.FC<SetupStepperProps> = ({
  seatCount,
  setSeatCount,
  employees,
  leaves,
  policy,
  setPolicy,
  period,
  setPeriod,
  seatBlocks,
  setSeatBlocks,
  onCalculate,
  onOpenEmployeeMaster,
  onOpenLeaveCalendar,
  workingDaysCount
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [noExceptionsConfirmed, setNoExceptionsConfirmed] = useState<boolean>(true);
  const [newBlockSeat, setNewBlockSeat] = useState<number>(1);
  const [newBlockReason, setNewBlockReason] = useState<string>('Electrical maintenance');

  const activeEmployees = employees.filter((e) => e.active);
  const seniorCount = activeEmployees.filter(
    (e) => e.designation === 'MD' || e.designation === 'ED' || e.designation === 'VP'
  ).length;

  const seatRatio = activeEmployees.length > 0 ? Math.round((seatCount / activeEmployees.length) * 100) : 0;

  // Step Validations
  const step1Valid = seatCount > 0 && seatCount >= seniorCount;
  const step2Valid = activeEmployees.length > 0;
  const step3Valid =
    policy.compliancePercentages.MD >= 0 &&
    policy.compliancePercentages.ED >= 0 &&
    policy.compliancePercentages.VP >= 0 &&
    policy.compliancePercentages.Professional >= 0;
  const step4Valid = Boolean(period.startDate && period.endDate && workingDaysCount > 0);

  const exceptionLeavesCount = leaves.filter((l) => l.isException).length;
  const step5Valid = noExceptionsConfirmed || exceptionLeavesCount > 0 || seatBlocks.length > 0;

  const isAllValid = step1Valid && step2Valid && step3Valid && step4Valid && step5Valid;

  // Validation blocking reasons
  const blockingReasons: string[] = [];
  if (!step1Valid) {
    if (seatCount <= 0) blockingReasons.push('Step 1: Seat count must be greater than 0');
    if (seatCount < seniorCount) blockingReasons.push(`Step 1: Seats (${seatCount}) cannot be fewer than fixed senior seats required (${seniorCount} MD/ED/VP)`);
  }
  if (!step2Valid) blockingReasons.push('Step 2: At least 1 active employee must be in the master');
  if (!step3Valid) blockingReasons.push('Step 3: Compliance percentages must be positive numbers');
  if (!step4Valid) blockingReasons.push('Step 4: Roster period must contain at least 1 working day');
  if (!step5Valid) blockingReasons.push('Step 5: Confirm exceptions or check "No exceptions to record"');

  const handleAddSeatBlock = () => {
    if (newBlockSeat < 1 || newBlockSeat > seatCount) return;
    const newBlock: SeatBlock = {
      id: `block-${Date.now()}`,
      seatNumber: newBlockSeat,
      reason: newBlockReason || 'Maintenance'
    };
    setSeatBlocks([...seatBlocks, newBlock]);
    setNoExceptionsConfirmed(false);
  };

  const handleRemoveSeatBlock = (id: string) => {
    setSeatBlocks(seatBlocks.filter((b) => b.id !== id));
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden mb-4">
      {/* Top Stepper Header */}
      <div className="px-4 py-2.5 bg-slate-50/90 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>Roster Configuration Wizard</span>
            <span className="text-[11px] font-normal text-slate-500">
              (Steps 1–5 to compute deterministic allocation)
            </span>
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Main Action Button */}
          <button
            onClick={onCalculate}
            disabled={!isAllValid}
            title={!isAllValid ? blockingReasons.join(' | ') : 'Generate complete roster & seat allocation'}
            className={`px-3.5 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
              isAllValid
                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20 active:scale-[0.99] cursor-pointer'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>CALCULATE ALLOCATION</span>
          </button>
        </div>
      </div>

      {/* Stepper Tabs Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 border-b border-slate-200 bg-white">
        {[
          { step: 1, name: '1. Seat Inventory', valid: step1Valid, desc: `${seatCount} Seats` },
          { step: 2, name: '2. Employee Master', valid: step2Valid, desc: `${activeEmployees.length} Active` },
          { step: 3, name: '3. Compliance Policy', valid: step3Valid, desc: `${policy.compliancePercentages.Professional}% Prof` },
          { step: 4, name: '4. Period & Leaves', valid: step4Valid, desc: `${workingDaysCount} Work Days` },
          { step: 5, name: '5. Exceptions & Blocks', valid: step5Valid, desc: `${exceptionLeavesCount} Exceptions` }
        ].map((s) => (
          <button
            key={s.step}
            onClick={() => setActiveStep(s.step)}
            className={`text-left p-2.5 border-r border-b md:border-b-0 border-slate-100 transition-colors flex items-center justify-between ${
              activeStep === s.step
                ? 'bg-blue-50/60 border-b-2 md:border-b-2 border-b-blue-600'
                : 'hover:bg-slate-50'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5">
                <span
                  className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                    s.valid
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {s.valid ? <Check className="w-2.5 h-2.5" /> : s.step}
                </span>
                <span className="text-xs font-semibold text-slate-800 tracking-tight truncate">
                  {s.name}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 ml-5 truncate font-mono">{s.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Step Contents */}
      <div className="p-4 bg-white">
        {/* STEP 1: SEAT INVENTORY */}
        {activeStep === 1 && (
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Step 1 — Seat Inventory & Capacity</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Specify the total physical workstation inventory assigned to the team.
                </p>
              </div>
              <span className="text-xs font-medium text-slate-500">
                Senior Fixed Desks: <strong className="text-slate-800 font-mono">{seniorCount}</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Total Seats Available
                </label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={seatCount}
                  onChange={(e) => setSeatCount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md text-xs font-bold font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="bg-white p-2.5 rounded-md border border-slate-200">
                <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-wider">Headcount</span>
                <span className="text-base font-bold font-mono text-slate-900">{activeEmployees.length}</span>
              </div>

              <div className="bg-white p-2.5 rounded-md border border-slate-200">
                <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-wider">Seat Ratio</span>
                <span className={`text-base font-bold font-mono ${seatRatio < 60 ? 'text-amber-600' : 'text-blue-600'}`}>
                  {seatRatio}%
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-md border border-slate-200">
                <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-wider">Fixed / Hot-Desk</span>
                <span className="text-xs font-semibold font-mono text-slate-800">
                  {seniorCount} Fix / {Math.max(0, seatCount - seniorCount)} Hot
                </span>
              </div>
            </div>

            {seatCount < seniorCount && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-xs text-rose-800">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Structurally Infeasible:</strong> Seats ({seatCount}) is less than senior fixed seats ({seniorCount} MD/ED/VP). Increase to at least {seniorCount}.
                </span>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: EMPLOYEE MASTER */}
        {activeStep === 2 && (
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Step 2 — Employee Master Confirmation</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Confirm the active roster of employees, designations, and corporate roles.
                </p>
              </div>
              <button
                onClick={onOpenEmployeeMaster}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Manage Master</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">MD</span>
                <span className="text-sm font-bold font-mono text-slate-900">
                  {activeEmployees.filter((e) => e.designation === 'MD').length}
                </span>
              </div>
              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">ED</span>
                <span className="text-sm font-bold font-mono text-slate-900">
                  {activeEmployees.filter((e) => e.designation === 'ED').length}
                </span>
              </div>
              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">VP</span>
                <span className="text-sm font-bold font-mono text-slate-900">
                  {activeEmployees.filter((e) => e.designation === 'VP').length}
                </span>
              </div>
              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">Professional</span>
                <span className="text-sm font-bold font-mono text-slate-900">
                  {activeEmployees.filter((e) => e.designation === 'Professional').length}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: COMPLIANCE POLICY */}
        {activeStep === 3 && (
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Step 3 — Compliance Policy & Rounding Rules</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Set the minimum required WFO attendance % and mathematical rounding basis.
                </p>
              </div>
              <button
                onClick={() => setPolicy(DEFAULT_POLICY_SETTINGS)}
                className="px-2 py-0.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded border border-slate-200 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Defaults</span>
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  MD Min WFO %
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={policy.compliancePercentages.MD}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      compliancePercentages: {
                        ...policy.compliancePercentages,
                        MD: parseInt(e.target.value) || 0
                      }
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  ED Min WFO %
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={policy.compliancePercentages.ED}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      compliancePercentages: {
                        ...policy.compliancePercentages,
                        ED: parseInt(e.target.value) || 0
                      }
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  VP Min WFO %
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={policy.compliancePercentages.VP}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      compliancePercentages: {
                        ...policy.compliancePercentages,
                        VP: parseInt(e.target.value) || 0
                      }
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Professional Min WFO %
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={policy.compliancePercentages.Professional}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      compliancePercentages: {
                        ...policy.compliancePercentages,
                        Professional: parseInt(e.target.value) || 0
                      }
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono font-semibold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Compliance Basis
                </label>
                <select
                  value={policy.complianceBasis}
                  onChange={(e) =>
                    setPolicy({ ...policy, complianceBasis: e.target.value as 'net' | 'gross' })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                >
                  <option value="net">Net working days after leave (Default)</option>
                  <option value="gross">Gross working days in period</option>
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Net basis deducts approved leave days before calculating required attendance.
                </p>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Rounding Rule
                </label>
                <select
                  value={policy.roundingRule}
                  onChange={(e) =>
                    setPolicy({ ...policy, roundingRule: e.target.value as 'ceil' | 'nearest' })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                >
                  <option value="ceil">Round up (Ceil) — Strict (Default)</option>
                  <option value="nearest">Round to nearest integer</option>
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Ceil ensures employees never fall below the mandated minimum percentage.
                </p>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Team Anchor Day (Optional)
                </label>
                <select
                  value={policy.teamAnchorDay ?? ''}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      teamAnchorDay: e.target.value ? parseInt(e.target.value) : undefined
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                >
                  <option value="">No Anchor Day (Even Spread)</option>
                  <option value="1">Monday (Week Start Sync)</option>
                  <option value="2">Tuesday</option>
                  <option value="3">Wednesday (Mid-Week Anchor)</option>
                  <option value="4">Thursday</option>
                  <option value="5">Friday</option>
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Maximises simultaneous attendance on chosen weekday subject to seat cap.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: ROSTER PERIOD & PLANNED LEAVE */}
        {activeStep === 4 && (
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Step 4 — Roster Period & Planned Leaves</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Select the 2-week fortnightly start date and capture employee leaves.
                </p>
              </div>
              <button
                onClick={() => onOpenLeaveCalendar()}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-semibold flex items-center gap-1.5"
              >
                <CalendarDays className="w-3.5 h-3.5" />
                <span>Open Leave Calendar</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Fortnight Start Date (Monday)
                </label>
                <input
                  type="date"
                  value={period.startDate}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (!val) return;
                    const parsed = parseISO(val);
                    const end = new Date(parsed.getTime() + 13 * 24 * 60 * 60 * 1000);
                    setPeriod({
                      startDate: val,
                      endDate: format(end, 'yyyy-MM-dd')
                    });
                  }}
                  className="w-full px-2.5 py-1 bg-white border border-slate-300 rounded text-xs font-semibold font-mono"
                />
              </div>

              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">Roster Window</span>
                <span className="text-xs font-bold font-mono text-slate-900">
                  {period.startDate} to {period.endDate}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block font-bold uppercase tracking-wider">Net Working Days</span>
                <span className="text-xs font-bold font-mono text-blue-600">
                  {workingDaysCount} Days (Excl. NSE Holidays & Weekends)
                </span>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: EXCEPTIONS & CONFIRMATION */}
        {activeStep === 5 && (
          <div className="space-y-3">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Step 5 — Exceptions & Seat Maintenance Blocks</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Record any urgent exception leaves (sick / maternity / emergency) or physical seat maintenance blocks.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Left: Seat Blocks */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-wider mb-2">
                  Seat Maintenance Blocks
                </h4>
                <div className="flex gap-1.5 mb-2.5">
                  <input
                    type="number"
                    min="1"
                    max={seatCount}
                    placeholder="Seat #"
                    value={newBlockSeat}
                    onChange={(e) => setNewBlockSeat(parseInt(e.target.value) || 1)}
                    className="w-20 px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono"
                  />
                  <input
                    type="text"
                    placeholder="Reason (e.g. IT wiring)"
                    value={newBlockReason}
                    onChange={(e) => setNewBlockReason(e.target.value)}
                    className="flex-1 px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                  />
                  <button
                    onClick={handleAddSeatBlock}
                    className="px-2.5 py-1 bg-slate-800 text-white rounded text-xs font-medium hover:bg-slate-700"
                  >
                    Block
                  </button>
                </div>

                {seatBlocks.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No seats currently blocked.</p>
                ) : (
                  <div className="space-y-1 max-h-24 overflow-y-auto">
                    {seatBlocks.map((b) => (
                      <div key={b.id} className="flex items-center justify-between bg-white px-2 py-1 rounded border border-slate-200 text-xs">
                        <span className="font-semibold font-mono text-slate-800">Seat-{String(b.seatNumber).padStart(2, '0')}:</span>
                        <span className="text-slate-600 truncate max-w-[140px] text-[11px]">{b.reason}</span>
                        <button
                          onClick={() => handleRemoveSeatBlock(b.id)}
                          className="text-rose-600 hover:text-rose-800 p-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right: Exception Leaves & Confirmation Checkbox */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex flex-col justify-between">
                <div>
                  <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                    Exception Leaves: {exceptionLeavesCount}
                  </h4>
                  <p className="text-[11px] text-slate-600 mb-2">
                    Exception leaves can be added via the Leave Calendar at any time.
                  </p>
                </div>

                <label className="flex items-center gap-2 p-2 bg-white rounded border border-slate-300 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={noExceptionsConfirmed}
                    onChange={(e) => setNoExceptionsConfirmed(e.target.checked)}
                    className="w-3.5 h-3.5 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <span className="text-[11px] font-medium text-slate-800">
                    I confirm exceptions and seat blocks are up-to-date.
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Wizard Footer Step Navigation */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={() => setActiveStep(Math.max(1, activeStep - 1))}
            disabled={activeStep === 1}
            className={`px-2.5 py-1 rounded text-xs font-medium ${
              activeStep === 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            ← Previous
          </button>

          <span className="text-[11px] text-slate-400 font-mono">
            Step {activeStep} of 5
          </span>

          <button
            onClick={() => setActiveStep(Math.min(5, activeStep + 1))}
            disabled={activeStep === 5}
            className={`px-2.5 py-1 rounded text-xs font-medium ${
              activeStep === 5 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            Next →
          </button>
        </div>
      </div>
    </div>
  );
};
