import React, { useState } from 'react';
import {
  AllocationResult,
  Employee,
  SeatBlock
} from '../types';
import { getBlockedSeatNumbers } from '../logic/allocator';
import { format, parseISO } from 'date-fns';
import { Building2, User, ShieldAlert, CheckCircle, Info } from 'lucide-react';

interface SeatMapProps {
  result: AllocationResult;
  employees: Employee[];
  seatCount: number;
  seatBlocks: SeatBlock[];
}

export const SeatMap: React.FC<SeatMapProps> = ({
  result,
  employees,
  seatCount,
  seatBlocks
}) => {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);
  const [selectedSeatNumber, setSelectedSeatNumber] = useState<number | null>(null);

  if (result.workingDays.length === 0) {
    return (
      <div className="bg-white p-8 rounded-xl border border-slate-200 text-center text-slate-500">
        No working days in roster period.
      </div>
    );
  }

  const currentDate = result.workingDays[selectedDayIndex] || result.workingDays[0];
  const parsedDate = parseISO(currentDate);
  const blockedSet = getBlockedSeatNumbers(seatBlocks, currentDate);

  // Map seat numbers for currentDate
  interface SeatInfo {
    seatNumber: number;
    occupant?: Employee;
    isFixedSenior: boolean;
    isBackfilled: boolean;
    isBlocked: boolean;
    blockReason?: string;
  }

  const employeeMap = new Map<string, Employee>();
  employees.forEach((e) => employeeMap.set(e.id, e));

  const seats: SeatInfo[] = [];

  for (let s = 1; s <= seatCount; s++) {
    const isBlocked = blockedSet.has(s);
    const blockReason = seatBlocks.find((b) => b.seatNumber === s)?.reason;

    // Find who is occupying this seat on currentDate
    let occupant: Employee | undefined;
    let isFixedSenior = false;
    let isBackfilled = false;

    employees.forEach((emp) => {
      const cell = result.grid[emp.id]?.[currentDate];
      if (cell?.status === 'O' && cell.seatNumber === s) {
        occupant = emp;
        isFixedSenior = cell.isFixedSeat || false;
        isBackfilled = cell.isBackfilled || false;
      }
    });

    seats.push({
      seatNumber: s,
      occupant,
      isFixedSenior,
      isBackfilled,
      isBlocked,
      blockReason
    });
  }

  const occupiedCount = seats.filter((s) => s.occupant).length;
  const vacantCount = seats.filter((s) => !s.occupant && !s.isBlocked).length;
  const selectedSeat = selectedSeatNumber ? seats.find((s) => s.seatNumber === selectedSeatNumber) : null;

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden mb-4">
      {/* Header & Day Selector Bar */}
      <div className="p-2.5 bg-slate-50/90 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Interactive Floor Seat Map — Workstation Allocations</span>
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Physical layout of Seat-01 to Seat-{String(seatCount).padStart(2, '0')} for the selected working day.
          </p>
        </div>

        {/* Quick Stats for this day */}
        <div className="flex items-center gap-1.5 text-[11px]">
          <span className="px-2 py-0.5 bg-slate-200 text-slate-800 rounded font-semibold font-mono">
            {occupiedCount}/{seatCount} Occupied ({Math.round((occupiedCount / seatCount) * 100)}%)
          </span>
          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-medium font-mono">
            {vacantCount} Vacant
          </span>
        </div>
      </div>

      {/* 10-Day Navigation Tabs */}
      <div className="flex overflow-x-auto bg-slate-100/80 border-b border-slate-200 p-1 gap-1">
        {result.workingDays.map((d, idx) => {
          const p = parseISO(d);
          const active = idx === selectedDayIndex;
          return (
            <button
              key={d}
              onClick={() => {
                setSelectedDayIndex(idx);
                setSelectedSeatNumber(null);
              }}
              className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                active
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <span className="font-mono">{format(p, 'EEE, dd-MMM')}</span>
              <span className={`text-[9px] px-1 rounded font-mono ${active ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-500'}`}>
                D{idx + 1}
              </span>
            </button>
          );
        })}
      </div>

      <div className="p-3.5">
        {/* Visual Seat Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-8 gap-2">
          {seats.map((seat) => {
            const isSelected = selectedSeatNumber === seat.seatNumber;

            let bgColor = 'bg-slate-50 border-slate-200 hover:border-slate-300';
            let textColor = 'text-slate-600';
            let tag = 'Vacant';
            let tagColor = 'bg-slate-200 text-slate-600';

            if (seat.isBlocked) {
              bgColor = 'bg-amber-50/70 border-amber-300';
              tag = 'Blocked';
              tagColor = 'bg-amber-200 text-amber-800';
            } else if (seat.occupant) {
              if (seat.isFixedSenior) {
                bgColor = 'bg-indigo-50/80 border-indigo-300 shadow-2xs';
                textColor = 'text-indigo-950';
                tag = 'Senior Fixed';
                tagColor = 'bg-indigo-100 text-indigo-800';
              } else if (seat.isBackfilled) {
                bgColor = 'bg-teal-50/80 border-teal-300 shadow-2xs';
                textColor = 'text-teal-950';
                tag = 'Backfill';
                tagColor = 'bg-teal-100 text-teal-800';
              } else {
                bgColor = 'bg-blue-50/80 border-blue-300 shadow-2xs';
                textColor = 'text-blue-950';
                tag = 'Hot Desk';
                tagColor = 'bg-blue-100 text-blue-800';
              }
            }

            return (
              <button
                key={seat.seatNumber}
                onClick={() => setSelectedSeatNumber(seat.seatNumber)}
                className={`p-2 rounded-lg border text-left transition-all relative flex flex-col justify-between min-h-[76px] ${bgColor} ${
                  isSelected ? 'ring-2 ring-blue-600 ring-offset-1' : ''
                }`}
              >
                {/* Top Row: Seat Number & Tag */}
                <div className="flex items-center justify-between w-full">
                  <span className="font-mono font-bold text-[11px] text-slate-800">
                    S-{String(seat.seatNumber).padStart(2, '0')}
                  </span>
                  <span className={`text-[8px] font-bold px-1 py-0.2 rounded-xs uppercase tracking-tight ${tagColor}`}>
                    {tag}
                  </span>
                </div>

                {/* Occupant Body */}
                <div className="mt-1 w-full">
                  {seat.occupant ? (
                    <div>
                      <p className="text-[11px] font-bold text-slate-900 truncate leading-tight" title={seat.occupant.name}>
                        {seat.occupant.name}
                      </p>
                      <p className="text-[9px] text-slate-500 truncate mt-0.5">
                        {seat.occupant.designation}
                      </p>
                    </div>
                  ) : seat.isBlocked ? (
                    <p className="text-[9px] text-amber-700 italic truncate">
                      {seat.blockReason || 'Maintenance'}
                    </p>
                  ) : (
                    <p className="text-[10px] text-slate-400 font-medium italic">
                      Empty desk
                    </p>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Seat Inspector Card */}
        {selectedSeat && (
          <div className="mt-3.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded bg-blue-600 text-white font-bold flex items-center justify-center font-mono text-xs">
                S-{String(selectedSeat.seatNumber).padStart(2, '0')}
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">
                  {selectedSeat.occupant
                    ? `${selectedSeat.occupant.name} (${selectedSeat.occupant.designation})`
                    : selectedSeat.isBlocked
                    ? `Blocked: ${selectedSeat.blockReason}`
                    : 'Vacant Workstation'}
                </h4>
                <p className="text-[10px] text-slate-500 font-mono">
                  Date: {format(parsedDate, 'dd-MMM-yyyy (EEEE)')} &nbsp;|&nbsp;
                  Type:{' '}
                  {selectedSeat.isFixedSenior
                    ? 'Permanent Senior Seat'
                    : selectedSeat.isBackfilled
                    ? 'Senior Seat Backfilled by Professional'
                    : selectedSeat.isBlocked
                    ? 'Maintenance Block'
                    : 'Hot-Desk Workstation'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setSelectedSeatNumber(null)}
              className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold"
            >
              Close Details
            </button>
          </div>
        )}

        {/* Legend */}
        <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex flex-wrap items-center gap-3.5 text-[10px] text-slate-600">
          <span className="font-bold text-slate-800 uppercase tracking-wider">Seating Legend:</span>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-indigo-100 border border-indigo-300 inline-block" />
            <span>Senior Fixed (MD/ED/VP)</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-teal-100 border border-teal-300 inline-block" />
            <span>Backfilled Fixed</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-blue-100 border border-blue-300 inline-block" />
            <span>Hot-Desk</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-slate-100 border border-slate-300 inline-block" />
            <span>Vacant</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-amber-100 border border-amber-300 inline-block" />
            <span>Blocked</span>
          </div>
        </div>
      </div>
    </div>
  );
};
