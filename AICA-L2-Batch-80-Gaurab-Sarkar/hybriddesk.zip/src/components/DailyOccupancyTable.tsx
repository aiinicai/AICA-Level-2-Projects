import React from 'react';
import { DailyOccupancy } from '../types';
import { format, parseISO } from 'date-fns';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

interface DailyOccupancyTableProps {
  occupancies: DailyOccupancy[];
  totalSeats: number;
}

export const DailyOccupancyTable: React.FC<DailyOccupancyTableProps> = ({
  occupancies,
  totalSeats
}) => {
  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden mb-4">
      <div className="p-3 bg-slate-50/90 border-b border-slate-200 flex items-center justify-between">
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Daily Occupancy & Utilisation Analysis
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Physical seat demand and capacity utilization across all {occupancies.length} working days.
          </p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700 font-semibold text-[11px]">
              <th className="py-1.5 px-2.5">Date</th>
              <th className="py-1.5 px-2.5">Day</th>
              <th className="py-1.5 px-2.5 text-center">Supply</th>
              <th className="py-1.5 px-2.5 text-center">Senior Fixed</th>
              <th className="py-1.5 px-2.5 text-center">Professionals</th>
              <th className="py-1.5 px-2.5 text-center">Total Occupied</th>
              <th className="py-1.5 px-2.5 text-center">Vacant</th>
              <th className="py-1.5 px-2.5 text-center w-36">Utilisation</th>
              <th className="py-1.5 px-2.5 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {occupancies.map((day) => {
              const parsed = parseISO(day.date);
              return (
                <tr
                  key={day.date}
                  className={`hover:bg-slate-50/80 transition-colors ${
                    day.isOverCapacity ? 'bg-rose-50/50' : ''
                  }`}
                >
                  <td className="py-1.5 px-2.5 font-semibold text-slate-900 font-mono text-[11px]">
                    {format(parsed, 'dd-MMM-yyyy')}
                  </td>
                  <td className="py-1.5 px-2.5 text-slate-600 font-medium text-[11px]">
                    {day.dayName}
                  </td>
                  <td className="py-1.5 px-2.5 text-center font-mono text-slate-700 text-[11px]">
                    {day.seatsAvailable}
                  </td>
                  <td className="py-1.5 px-2.5 text-center font-mono text-indigo-700 font-semibold text-[11px]">
                    {day.seniorsPresent}
                  </td>
                  <td className="py-1.5 px-2.5 text-center font-mono text-blue-700 font-semibold text-[11px]">
                    {day.professionalsPresent}
                  </td>
                  <td className="py-1.5 px-2.5 text-center font-mono font-bold text-slate-900 text-[11px]">
                    {day.totalOccupied}
                  </td>
                  <td className="py-1.5 px-2.5 text-center font-mono text-slate-500 text-[11px]">
                    {day.vacantSeats}
                  </td>
                  <td className="py-1.5 px-2.5 text-center">
                    <div className="flex items-center gap-1.5">
                      <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            day.isOverCapacity
                              ? 'bg-rose-600'
                              : day.utilisationPct >= 90
                              ? 'bg-emerald-500'
                              : day.utilisationPct >= 70
                              ? 'bg-blue-500'
                              : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.min(100, day.utilisationPct)}%` }}
                        />
                      </div>
                      <span className="font-mono font-bold text-slate-800 text-[10px] w-8 text-right">
                        {day.utilisationPct}%
                      </span>
                    </div>
                  </td>
                  <td className="py-1.5 px-2.5 text-center">
                    {day.isOverCapacity ? (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                        <AlertTriangle className="w-2.5 h-2.5" />
                        <span>OVER CAP</span>
                      </span>
                    ) : day.utilisationPct >= 90 ? (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        <span>Optimal</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-medium bg-slate-100 text-slate-600">
                        Standard
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
