import React, { useState, useMemo } from 'react';
import {
  SlidersHorizontal,
  TrendingUp,
  TrendingDown,
  AlertOctagon,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Check,
  X,
  ArrowRight,
  Sparkles,
  Users,
  Building2,
  Percent,
  Layers,
  Calendar
} from 'lucide-react';
import {
  AllocationResult,
  Employee,
  Holiday,
  LeaveRecord,
  PolicySettings,
  RosterPeriodConfig,
  SeatBlock
} from '../types';
import { allocateRoster } from '../logic/allocator';
import { format, parseISO } from 'date-fns';

interface WhatIfSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSeatCount: number;
  currentPolicy: PolicySettings;
  currentResult: AllocationResult | null;
  employees: Employee[];
  leaves: LeaveRecord[];
  holidays: Holiday[];
  period: RosterPeriodConfig;
  seatBlocks: SeatBlock[];
  onApplyScenario: (newSeatCount: number, newPolicy: PolicySettings) => void;
}

export const WhatIfSimulatorModal: React.FC<WhatIfSimulatorModalProps> = ({
  isOpen,
  onClose,
  currentSeatCount,
  currentPolicy,
  currentResult,
  employees,
  leaves,
  holidays,
  period,
  seatBlocks,
  onApplyScenario
}) => {
  // Simulator State (initialized with current values)
  const [simSeatCount, setSimSeatCount] = useState<number>(currentSeatCount);
  const [simPolicy, setSimPolicy] = useState<PolicySettings>(currentPolicy);
  const [isGlobalSync, setIsGlobalSync] = useState<boolean>(false);
  const [globalPct, setGlobalPct] = useState<number>(currentPolicy.compliancePercentages.Professional);

  const activeEmployees = employees.filter((e) => e.active);
  const activeCount = activeEmployees.length;

  // Reset local state when modal opens or resets
  const handleResetToCurrent = () => {
    setSimSeatCount(currentSeatCount);
    setSimPolicy(currentPolicy);
    setGlobalPct(currentPolicy.compliancePercentages.Professional);
    setIsGlobalSync(false);
  };

  // Synchronize role percentages if global slider moves
  const handleGlobalPctChange = (newPct: number) => {
    setGlobalPct(newPct);
    setSimPolicy((prev) => ({
      ...prev,
      compliancePercentages: {
        MD: newPct,
        ED: newPct,
        VP: newPct,
        Professional: newPct
      }
    }));
  };

  // Live real-time simulation allocation
  const simResult: AllocationResult = useMemo(() => {
    return allocateRoster({
      seatCount: simSeatCount,
      employees,
      leaves,
      holidays,
      policy: simPolicy,
      period,
      seatBlocks
    });
  }, [simSeatCount, simPolicy, employees, leaves, holidays, period, seatBlocks]);

  if (!isOpen) return null;

  // Comparative Metric Calculations
  const currFullyCompliant = currentResult?.fullyCompliantCount ?? 0;
  const currNonCompliant = currentResult?.nonCompliantCount ?? 0;
  const currUtilisation = currentResult?.avgDailyUtilisationPct ?? 0;
  const currDeficitDays = currentResult?.deficit.deficitSeatDays ?? 0;
  const currSeatsShort = currentResult?.deficit.seatsShort ?? 0;

  const simFullyCompliant = simResult.fullyCompliantCount;
  const simNonCompliant = simResult.nonCompliantCount;
  const simUtilisation = simResult.avgDailyUtilisationPct;
  const simDeficitDays = simResult.deficit.deficitSeatDays;
  const simSeatsShort = simResult.deficit.seatsShort;

  // Deltas
  const deltaCompliant = simFullyCompliant - currFullyCompliant;
  const deltaNonCompliant = simNonCompliant - currNonCompliant;
  const deltaUtilisation = Math.round((simUtilisation - currUtilisation) * 10) / 10;
  const deltaSeatCount = simSeatCount - currentSeatCount;

  // Has changes
  const hasChanges =
    simSeatCount !== currentSeatCount ||
    JSON.stringify(simPolicy) !== JSON.stringify(currentPolicy);

  // Quick preset handlers
  const handleQuickSeat = (seats: number) => {
    const clamped = Math.max(1, Math.min(60, seats));
    setSimSeatCount(clamped);
  };

  const handleApply = () => {
    onApplyScenario(simSeatCount, simPolicy);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center">
              <SlidersHorizontal className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                  'What-If' Roster & Capacity Simulator
                </h3>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40 font-mono">
                  Live Engine
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Test alternative seat counts and hybrid compliance policies in real-time before committing.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Simulation Workspace */}
        <div className="p-3.5 overflow-y-auto flex-1 space-y-3.5">
          {/* Top Comparative Delta Banner */}
          <div className="p-3 bg-slate-900 text-white rounded-lg shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Live Scenario Forecast vs Active Roster
              </span>
              <div className="flex items-center gap-2">
                {simResult.deficit.hasDeficit ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1 font-mono">
                    <AlertOctagon className="w-3 h-3" />
                    Deficit: Short by {simResult.deficit.seatsShort} seat(s)
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 font-mono">
                    <CheckCircle2 className="w-3 h-3" />
                    100% Feasible Capacity
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              {/* Seat Delta */}
              <div className="bg-slate-800/90 p-2 rounded border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Seat Count</div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-base font-bold font-mono text-white">{simSeatCount}</span>
                  <span className="text-[10px] text-slate-400 font-mono">from {currentSeatCount}</span>
                  {deltaSeatCount !== 0 && (
                    <span
                      className={`text-[10px] font-bold font-mono ml-auto ${
                        deltaSeatCount > 0 ? 'text-blue-400' : 'text-amber-400'
                      }`}
                    >
                      {deltaSeatCount > 0 ? `+${deltaSeatCount}` : deltaSeatCount}
                    </span>
                  )}
                </div>
              </div>

              {/* Fully Compliant Delta */}
              <div className="bg-slate-800/90 p-2 rounded border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Fully Compliant</div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-base font-bold font-mono text-emerald-400">{simFullyCompliant}</span>
                  <span className="text-[10px] text-slate-400 font-mono">/ {activeCount}</span>
                  {deltaCompliant !== 0 && (
                    <span
                      className={`text-[10px] font-bold font-mono ml-auto ${
                        deltaCompliant > 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {deltaCompliant > 0 ? `+${deltaCompliant}` : deltaCompliant}
                    </span>
                  )}
                </div>
              </div>

              {/* Non-Compliant Shortfall */}
              <div className="bg-slate-800/90 p-2 rounded border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Employees Shortfall</div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span
                    className={`text-base font-bold font-mono ${
                      simNonCompliant > 0 ? 'text-rose-400' : 'text-slate-300'
                    }`}
                  >
                    {simNonCompliant}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">pax</span>
                  {deltaNonCompliant !== 0 && (
                    <span
                      className={`text-[10px] font-bold font-mono ml-auto ${
                        deltaNonCompliant > 0 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {deltaNonCompliant > 0 ? `+${deltaNonCompliant}` : deltaNonCompliant}
                    </span>
                  )}
                </div>
              </div>

              {/* Avg Utilisation */}
              <div className="bg-slate-800/90 p-2 rounded border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Avg Utilisation</div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-base font-bold font-mono text-white">{simUtilisation}%</span>
                  {deltaUtilisation !== 0 && (
                    <span
                      className={`text-[10px] font-bold font-mono ml-auto ${
                        deltaUtilisation > 0 ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {deltaUtilisation > 0 ? `+${deltaUtilisation}%` : `${deltaUtilisation}%`}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Sliders Panel */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {/* Left Box: Seat Count Slider & Presets */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Physical Seat Count (Inventory)
                  </h4>
                </div>
                <div className="text-right">
                  <span className="text-base font-bold font-mono text-blue-700">{simSeatCount}</span>
                  <span className="text-[10px] text-slate-500 font-mono ml-1">
                    ({Math.round((simSeatCount / (activeCount || 1)) * 100)}% ratio)
                  </span>
                </div>
              </div>

              {/* Slider */}
              <div className="space-y-1">
                <input
                  type="range"
                  min={1}
                  max={Math.max(50, activeCount + 10)}
                  step={1}
                  value={simSeatCount}
                  onChange={(e) => setSimSeatCount(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                  <span>1 Seat</span>
                  <span>Min Feasible: {simResult.deficit.minSeatsForFullCompliance}</span>
                  <span>1:1 Ratio: {activeCount}</span>
                  <span>50+ Seats</span>
                </div>
              </div>

              {/* Quick Preset Buttons */}
              <div>
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Quick Seat Presets:
                </span>
                <div className="flex flex-wrap items-center gap-1">
                  <button
                    onClick={() => handleQuickSeat(simSeatCount - 5)}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    -5
                  </button>
                  <button
                    onClick={() => handleQuickSeat(simSeatCount - 1)}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    -1
                  </button>
                  <button
                    onClick={() => setSimSeatCount(currentSeatCount)}
                    className="px-2 py-0.5 bg-blue-100 border border-blue-300 text-blue-900 rounded text-[10px] font-bold font-mono shadow-2xs"
                  >
                    Current ({currentSeatCount})
                  </button>
                  <button
                    onClick={() => handleQuickSeat(simSeatCount + 1)}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    +1
                  </button>
                  <button
                    onClick={() => handleQuickSeat(simSeatCount + 5)}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    +5
                  </button>
                  <button
                    onClick={() => setSimSeatCount(simResult.deficit.minSeatsForFullCompliance)}
                    className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded text-[10px] font-bold font-mono shadow-2xs"
                    title="Minimum physical seats mathematically required to reach 100% compliance"
                  >
                    Min Feasible ({simResult.deficit.minSeatsForFullCompliance})
                  </button>
                  <button
                    onClick={() => setSimSeatCount(Math.round(activeCount * 0.6))}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    60% Cap ({Math.round(activeCount * 0.6)})
                  </button>
                  <button
                    onClick={() => setSimSeatCount(activeCount)}
                    className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-700 font-mono shadow-2xs"
                  >
                    100% ({activeCount})
                  </button>
                </div>
              </div>

              {/* Demand vs Supply Breakdown */}
              <div className="p-2 bg-white rounded border border-slate-200 text-[10px] space-y-1 font-mono text-slate-600">
                <div className="flex justify-between">
                  <span>Total Seat Demand:</span>
                  <span className="font-bold text-slate-900">{simResult.deficit.demandSeatDays} seat-days</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Seat Supply ({simSeatCount} × {simResult.workingDays.length}d):</span>
                  <span className="font-bold text-slate-900">{simResult.deficit.supplySeatDays} seat-days</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-100 font-bold">
                  <span>Balance / Feasibility:</span>
                  {simResult.deficit.hasDeficit ? (
                    <span className="text-rose-600">Shortfall: -{simResult.deficit.deficitSeatDays}d</span>
                  ) : (
                    <span className="text-emerald-600">Spare: +{simResult.deficit.spareSeatDays}d</span>
                  )}
                </div>
              </div>
            </div>

            {/* Right Box: Compliance % Sliders */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5 text-blue-600" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Hybrid Compliance Policy (%)
                  </h4>
                </div>
                <div className="flex items-center gap-1">
                  <label className="text-[10px] text-slate-600 font-semibold cursor-pointer flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={isGlobalSync}
                      onChange={(e) => setIsGlobalSync(e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    <span>Sync All Roles</span>
                  </label>
                </div>
              </div>

              {isGlobalSync ? (
                /* Global Single Slider */
                <div className="p-2 bg-white rounded border border-slate-200 space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-700">All Roles Compliance Target:</span>
                    <span className="text-blue-700 font-mono">{globalPct}%</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={globalPct}
                    onChange={(e) => handleGlobalPctChange(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                  <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                    <span>20% (1d/wk)</span>
                    <span>40% (2d/wk)</span>
                    <span>60% (3d/wk)</span>
                    <span>80% (4d/wk)</span>
                    <span>100% (5d)</span>
                  </div>
                </div>
              ) : (
                /* Role-Specific Sliders */
                <div className="space-y-1.5">
                  {/* Professional Slider */}
                  <div className="p-1.5 bg-white rounded border border-slate-200">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-800 mb-0.5">
                      <span>Professionals (Hot Desk Pool):</span>
                      <span className="font-mono text-blue-700 font-bold">
                        {simPolicy.compliancePercentages.Professional}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      step={5}
                      value={simPolicy.compliancePercentages.Professional}
                      onChange={(e) =>
                        setSimPolicy((prev) => ({
                          ...prev,
                          compliancePercentages: {
                            ...prev.compliancePercentages,
                            Professional: parseInt(e.target.value)
                          }
                        }))
                      }
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>

                  {/* VP Slider */}
                  <div className="p-1.5 bg-white rounded border border-slate-200">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-800 mb-0.5">
                      <span>Vice Presidents (VP - Fixed Desk):</span>
                      <span className="font-mono text-blue-700 font-bold">{simPolicy.compliancePercentages.VP}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      step={5}
                      value={simPolicy.compliancePercentages.VP}
                      onChange={(e) =>
                        setSimPolicy((prev) => ({
                          ...prev,
                          compliancePercentages: {
                            ...prev.compliancePercentages,
                            VP: parseInt(e.target.value)
                          }
                        }))
                      }
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>

                  {/* ED Slider */}
                  <div className="p-1.5 bg-white rounded border border-slate-200">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-800 mb-0.5">
                      <span>Executive Directors (ED - Fixed Desk):</span>
                      <span className="font-mono text-blue-700 font-bold">{simPolicy.compliancePercentages.ED}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      step={5}
                      value={simPolicy.compliancePercentages.ED}
                      onChange={(e) =>
                        setSimPolicy((prev) => ({
                          ...prev,
                          compliancePercentages: {
                            ...prev.compliancePercentages,
                            ED: parseInt(e.target.value)
                          }
                        }))
                      }
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>

                  {/* MD Slider */}
                  <div className="p-1.5 bg-white rounded border border-slate-200">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-800 mb-0.5">
                      <span>Managing Directors (MD - Fixed Desk):</span>
                      <span className="font-mono text-blue-700 font-bold">{simPolicy.compliancePercentages.MD}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      step={5}
                      value={simPolicy.compliancePercentages.MD}
                      onChange={(e) =>
                        setSimPolicy((prev) => ({
                          ...prev,
                          compliancePercentages: {
                            ...prev.compliancePercentages,
                            MD: parseInt(e.target.value)
                          }
                        }))
                      }
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>
                </div>
              )}

              {/* Policy Calculation Basis & Rounding */}
              <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                <div className="p-1.5 bg-white rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-0.5">Basis:</span>
                  <select
                    value={simPolicy.complianceBasis}
                    onChange={(e) =>
                      setSimPolicy((prev) => ({
                        ...prev,
                        complianceBasis: e.target.value as 'net' | 'gross'
                      }))
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded py-0.5 px-1 text-[11px] text-slate-800"
                  >
                    <option value="net">Net (Excl Leaves)</option>
                    <option value="gross">Gross (10 Days)</option>
                  </select>
                </div>

                <div className="p-1.5 bg-white rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-0.5">Rounding:</span>
                  <select
                    value={simPolicy.roundingRule}
                    onChange={(e) =>
                      setSimPolicy((prev) => ({
                        ...prev,
                        roundingRule: e.target.value as 'ceil' | 'round'
                      }))
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded py-0.5 px-1 text-[11px] text-slate-800"
                  >
                    <option value="ceil">Ceil (Round Up)</option>
                    <option value="round">Round Nearest</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Daily Projected Occupancy Sparklines */}
          <div className="p-3 bg-white border border-slate-200 rounded-lg shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600">
                Simulated Daily Occupancy vs {simSeatCount} Seats Capacity
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Working Days: {simResult.workingDays.length}d
              </span>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
              {simResult.dailyOccupancies.map((occ) => {
                const parsed = parseISO(occ.date);
                const isOver = occ.isOverCapacity;
                const util = occ.utilisationPct;
                const barHeight = Math.min(100, Math.round((occ.totalOccupied / (simSeatCount || 1)) * 100));

                return (
                  <div
                    key={occ.date}
                    className={`p-1.5 rounded border text-center transition-all ${
                      isOver
                        ? 'bg-rose-50 border-rose-300'
                        : util >= 90
                        ? 'bg-emerald-50/60 border-emerald-200'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-[9px] font-bold text-slate-500 font-mono uppercase">
                      {format(parsed, 'dd-MMM')}
                    </div>
                    <div className="text-[10px] font-bold text-slate-700">
                      {format(parsed, 'EEE')}
                    </div>

                    {/* Mini Visual Bar */}
                    <div className="w-full bg-slate-200 h-1.5 rounded-full my-1 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          isOver ? 'bg-rose-600' : util >= 90 ? 'bg-emerald-500' : 'bg-blue-500'
                        }`}
                        style={{ width: `${Math.min(100, barHeight)}%` }}
                      />
                    </div>

                    <div className="font-mono text-[10px] font-bold text-slate-900">
                      {occ.totalOccupied} / {simSeatCount}
                    </div>
                    <div
                      className={`text-[9px] font-mono ${
                        isOver ? 'text-rose-600 font-bold' : util >= 90 ? 'text-emerald-700' : 'text-slate-500'
                      }`}
                    >
                      {util}%
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Affected Employees Summary Table (If any changes in compliance) */}
          <div className="border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="p-2 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 uppercase tracking-wider text-[10px]">
                Projected Employee Compliance Breakdown ({activeCount} Active Members)
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {simFullyCompliant} Compliant • {simNonCompliant} Shortfall
              </span>
            </div>

            <div className="max-h-40 overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[10px] font-bold">
                    <th className="py-1 px-2.5">ID</th>
                    <th className="py-1 px-2.5">Employee</th>
                    <th className="py-1 px-2.5">Role</th>
                    <th className="py-1 px-2.5 text-center">Req Target</th>
                    <th className="py-1 px-2.5 text-center">Sim Allocated</th>
                    <th className="py-1 px-2.5 text-right">Forecast Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {simResult.employeeSummaries.map((s) => {
                    const emp = employees.find((e) => e.id === s.employeeId);
                    return (
                      <tr key={s.employeeId} className="hover:bg-slate-50">
                        <td className="py-1 px-2.5 font-mono text-[10px] text-slate-500">{s.empId}</td>
                        <td className="py-1 px-2.5 font-semibold text-slate-900 text-[11px]">{s.name}</td>
                        <td className="py-1 px-2.5 text-[10px]">
                          <span className="px-1 py-0.2 rounded bg-slate-100 text-slate-700 font-semibold">
                            {s.designation}
                          </span>
                        </td>
                        <td className="py-1 px-2.5 text-center font-mono text-[10px] text-slate-700">
                          {s.requiredOfficeDays}d ({s.requiredPct}%)
                        </td>
                        <td className="py-1 px-2.5 text-center font-mono text-[10px] font-bold text-slate-900">
                          {s.allocatedOfficeDays}d ({s.achievedPct}%)
                        </td>
                        <td className="py-1 px-2.5 text-right">
                          {s.isFullyOnLeave ? (
                            <span className="text-[9px] font-semibold text-slate-400 font-mono">Full Leave</span>
                          ) : s.isCompliant ? (
                            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800">
                              ✓ Met ({s.allocatedOfficeDays}d)
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-800">
                              Shortfall (-{s.shortfallDays}d)
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handleResetToCurrent}
              disabled={!hasChanges}
              className={`px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1 border transition-colors ${
                hasChanges
                  ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                  : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
              }`}
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset to Current</span>
            </button>
            {hasChanges && (
              <span className="text-[11px] text-amber-700 font-medium font-mono">
                Scenario differs from active roster
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Scenario to Roster</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
