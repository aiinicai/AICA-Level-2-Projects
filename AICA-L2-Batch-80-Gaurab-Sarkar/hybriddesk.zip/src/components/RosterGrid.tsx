import React, { useState } from 'react';
import {
  Search,
  Filter,
  Download,
  FileSpreadsheet,
  FileText,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Lock,
  ArrowRightLeft,
  ChevronDown,
  Info,
  Mail,
  SlidersHorizontal
} from 'lucide-react';
import {
  AllocationResult,
  DayAllocation,
  Designation,
  Employee,
  Holiday,
  PolicySettings,
  RosterPeriodConfig,
  SeatBlock
} from '../types';
import { applyManualOverride } from '../logic/allocator';
import { exportRosterPDF, exportRosterSpreadsheet } from '../logic/exporter';
import { format, parseISO } from 'date-fns';

interface RosterGridProps {
  result: AllocationResult;
  setResult: React.Dispatch<React.SetStateAction<AllocationResult | null>>;
  employees: Employee[];
  period: RosterPeriodConfig;
  policy: PolicySettings;
  holidays: Holiday[];
  seatCount: number;
  seatBlocks: SeatBlock[];
  onResetToAuto: () => void;
  onOpenEmailRoster?: () => void;
  onOpenWhatIf?: () => void;
}

export const RosterGrid: React.FC<RosterGridProps> = ({
  result,
  setResult,
  employees,
  period,
  policy,
  holidays,
  seatCount,
  seatBlocks,
  onResetToAuto,
  onOpenEmailRoster,
  onOpenWhatIf
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDesignation, setFilterDesignation] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [activeOverrideCell, setActiveOverrideCell] = useState<{
    empId: string;
    date: string;
  } | null>(null);
  const [overrideWarning, setOverrideWarning] = useState<string | null>(null);

  const activeEmployees = employees.filter((e) => e.active);

  // Filter employees
  const filteredEmployees = activeEmployees.filter((emp) => {
    // Search
    const matchesSearch =
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.empId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.designation.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    // Designation filter
    if (filterDesignation !== 'ALL' && emp.designation !== filterDesignation) {
      return false;
    }

    // Status filter
    if (filterStatus !== 'ALL') {
      const summary = result.employeeSummaries.find((s) => s.employeeId === emp.id);
      if (filterStatus === 'COMPLIANT' && !summary?.isCompliant) return false;
      if (filterStatus === 'SHORTFALL' && (summary?.isCompliant || summary?.isFullyOnLeave)) return false;
      if (filterStatus === 'NA' && !summary?.isFullyOnLeave) return false;
    }

    return true;
  });

  const handleCellClick = (empId: string, date: string) => {
    const cell = result.grid[empId]?.[date];
    if (!cell || cell.status === 'L' || cell.status === 'H' || cell.status === 'X') {
      return;
    }
    setActiveOverrideCell({ empId, date });
  };

  const handleToggleOverride = (targetStatus: 'O' | 'W') => {
    if (!activeOverrideCell) return;
    const { empId, date } = activeOverrideCell;

    const { updatedResult, isBreach, message } = applyManualOverride(
      result,
      empId,
      date,
      targetStatus,
      employees,
      seatCount,
      seatBlocks
    );

    setResult(updatedResult);
    if (isBreach && message) {
      setOverrideWarning(message);
    } else {
      setOverrideWarning(null);
    }
    setActiveOverrideCell(null);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden mb-4">
      {/* Grid Action Toolbar */}
      <div className="p-2.5 bg-slate-50/90 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
        {/* Left: Search & Filters */}
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[160px] max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
            <input
              type="text"
              placeholder="Search employee or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-2.5 py-1 bg-white border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <select
            value={filterDesignation}
            onChange={(e) => setFilterDesignation(e.target.value)}
            className="px-2 py-1 bg-white border border-slate-300 rounded text-xs text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Roles</option>
            <option value="MD">Managing Director (MD)</option>
            <option value="ED">Executive Director (ED)</option>
            <option value="VP">Vice President (VP)</option>
            <option value="Professional">Professional</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2 py-1 bg-white border border-slate-300 rounded text-xs text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Compliance</option>
            <option value="COMPLIANT">Fully Compliant</option>
            <option value="SHORTFALL">Shortfall</option>
            <option value="NA">Full Leave (N/A)</option>
          </select>
        </div>

        {/* Right: Export & Override Controls */}
        <div className="flex items-center gap-1.5">
          {onOpenWhatIf && (
            <button
              onClick={onOpenWhatIf}
              className="px-2 py-1 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded flex items-center gap-1 transition-colors"
              title="Open 'What-If' Simulator"
            >
              <SlidersHorizontal className="w-3 h-3 text-amber-600" />
              <span>What-If</span>
            </button>
          )}

          {result.manualOverridesCount > 0 && (
            <button
              onClick={onResetToAuto}
              className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3 text-slate-500" />
              <span>Reset Auto ({result.manualOverridesCount})</span>
            </button>
          )}

          <div className="relative group">
            <button className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded flex items-center gap-1 shadow-2xs">
              <Download className="w-3 h-3 text-slate-500" />
              <span>Export</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            <div className="hidden group-hover:block absolute right-0 mt-1 w-48 bg-white border border-slate-200 rounded-lg shadow-lg p-1 z-50">
              {onOpenEmailRoster && (
                <button
                  onClick={onOpenEmailRoster}
                  className="w-full text-left px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-50 rounded flex items-center gap-2"
                >
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  <span>Email HTML (Outlook/Gmail)</span>
                </button>
              )}
              <button
                onClick={() =>
                  exportRosterPDF({
                    result,
                    employees,
                    period,
                    policy,
                    holidays,
                    seatCount
                  })
                }
                className="w-full text-left px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded flex items-center gap-2"
              >
                <FileText className="w-3.5 h-3.5 text-rose-600" />
                <span>Export PDF Report (A4)</span>
              </button>
              <button
                onClick={() => exportRosterSpreadsheet(result, employees, period, 'xlsx')}
                className="w-full text-left px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded flex items-center gap-2"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>Export Excel (.xlsx)</span>
              </button>
              <button
                onClick={() => exportRosterSpreadsheet(result, employees, period, 'csv')}
                className="w-full text-left px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded flex items-center gap-2"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
                <span>Export CSV (.csv)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Override Warning Callout */}
      {overrideWarning && (
        <div className="p-2.5 bg-rose-50 border-b border-rose-200 text-xs text-rose-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{overrideWarning}</span>
          </div>
          <button
            onClick={() => setOverrideWarning(null)}
            className="text-rose-600 font-bold hover:underline text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Interactive Manual Override Modal */}
      {activeOverrideCell && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-sm w-full p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2 uppercase tracking-wider">
                <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
                <span>Manual Day Override</span>
              </h4>
              <button
                onClick={() => setActiveOverrideCell(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-1">
              <p>
                <strong>Employee:</strong>{' '}
                {employees.find((e) => e.id === activeOverrideCell.empId)?.name}
              </p>
              <p>
                <strong>Date:</strong> <span className="font-mono">{format(parseISO(activeOverrideCell.date), 'dd-MMM-yyyy (EEEE)')}</span>
              </p>
              <p>
                <strong>Current Status:</strong>{' '}
                {result.grid[activeOverrideCell.empId]?.[activeOverrideCell.date]?.status === 'O'
                  ? 'In Office'
                  : 'Work From Home'}
              </p>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => handleToggleOverride('O')}
                className="flex-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold transition-colors"
              >
                Set to Office
              </button>
              <button
                onClick={() => handleToggleOverride('W')}
                className="flex-1 py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-xs font-bold transition-colors"
              >
                Set to WFH
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Roster Table with Frozen Column */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700">
              {/* Sticky Freeze Header */}
              <th className="sticky left-0 z-20 bg-slate-100 py-2 px-2 w-10 text-center font-bold text-slate-600 border-r border-slate-200 shadow-xs">
                #
              </th>
              <th className="sticky left-10 z-20 bg-slate-100 py-2 px-2.5 w-16 font-bold text-slate-600 border-r border-slate-200 shadow-xs">
                ID
              </th>
              <th className="sticky left-26 z-20 bg-slate-100 py-2 px-2.5 w-40 font-bold text-slate-800 border-r border-slate-200 shadow-xs">
                Employee
              </th>
              <th className="py-2 px-2.5 w-24 font-bold text-slate-600 border-r border-slate-200">
                Role
              </th>
              <th className="py-2 px-2.5 w-20 text-center font-bold text-slate-600 border-r border-slate-200">
                Req/Act
              </th>

              {/* Working Days Columns */}
              {result.workingDays.map((d) => {
                const parsed = parseISO(d);
                const dayName = format(parsed, 'EEE');
                const isAnchor = policy.teamAnchorDay === parsed.getDay();

                return (
                  <th
                    key={d}
                    className={`py-1.5 px-2 min-w-[84px] text-center border-r border-slate-200 ${
                      isAnchor ? 'bg-blue-100/70' : ''
                    }`}
                  >
                    <div className="text-[9px] font-bold uppercase tracking-wider text-slate-500 font-mono">
                      {format(parsed, 'dd-MMM')}
                    </div>
                    <div className="text-xs font-bold text-slate-800 flex items-center justify-center gap-1">
                      <span>{dayName}</span>
                      {isAnchor && (
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-600" title="Team Anchor Day" />
                      )}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-200 bg-white">
            {filteredEmployees.map((emp, index) => {
              const summary = result.employeeSummaries.find((s) => s.employeeId === emp.id);

              return (
                <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                  {/* Sticky Frozen Columns */}
                  <td className="sticky left-0 z-10 bg-white group-hover:bg-slate-50 py-1.5 px-2 text-center text-slate-400 font-mono text-[10px] border-r border-slate-200 shadow-xs">
                    {index + 1}
                  </td>
                  <td className="sticky left-10 z-10 bg-white group-hover:bg-slate-50 py-1.5 px-2 font-mono text-slate-600 text-[10px] border-r border-slate-200 shadow-xs">
                    {emp.empId}
                  </td>
                  <td className="sticky left-26 z-10 bg-white group-hover:bg-slate-50 py-1.5 px-2.5 font-semibold text-slate-900 border-r border-slate-200 shadow-xs">
                    <div className="truncate max-w-[150px] text-[11px]" title={emp.name}>
                      {emp.name}
                    </div>
                  </td>
                  <td className="py-1.5 px-2 border-r border-slate-200">
                    <span
                      className={`inline-flex items-center px-1.5 py-0.2 text-[10px] font-semibold rounded ${
                        emp.designation === 'MD'
                          ? 'bg-purple-100 text-purple-800'
                          : emp.designation === 'ED'
                          ? 'bg-indigo-100 text-indigo-800'
                          : emp.designation === 'VP'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {emp.designation}
                    </span>
                  </td>
                  <td className="py-1.5 px-2 text-center border-r border-slate-200">
                    {summary?.isFullyOnLeave ? (
                      <span className="text-[10px] font-semibold text-slate-400 font-mono">N/A</span>
                    ) : (
                      <div className="flex items-center justify-center gap-0.5 font-mono text-[10px]">
                        <span className={summary?.isCompliant ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                          {summary?.allocatedOfficeDays}
                        </span>
                        <span className="text-slate-400">/</span>
                        <span className="text-slate-600">{summary?.requiredOfficeDays}</span>
                      </div>
                    )}
                  </td>

                  {/* Day Cells */}
                  {result.workingDays.map((d) => {
                    const cell: DayAllocation | undefined = result.grid[emp.id]?.[d];

                    if (!cell) {
                      return (
                        <td key={d} className="py-1 px-1.5 text-center border-r border-slate-200 text-slate-300 font-mono text-[10px]">
                          -
                        </td>
                      );
                    }

                    if (cell.status === 'O') {
                      return (
                        <td
                          key={d}
                          onClick={() => handleCellClick(emp.id, d)}
                          className="py-1 px-1 text-center border-r border-slate-200 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Click to toggle Office <-> WFH"
                        >
                          <div
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold flex flex-col items-center justify-center shadow-2xs ${
                              cell.isFixedSeat
                                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                : cell.isBackfilled
                                ? 'bg-teal-50 text-teal-700 border border-teal-200'
                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                            }`}
                          >
                            <span className="leading-tight font-mono">
                              {cell.seatNumber ? `S-${String(cell.seatNumber).padStart(2, '0')}` : 'Office'}
                            </span>
                            <span className="text-[8px] font-normal leading-tight opacity-75">
                              {cell.isFixedSeat ? 'Fix' : cell.isBackfilled ? 'Backfill' : 'Hot'}
                            </span>
                          </div>
                        </td>
                      );
                    }

                    if (cell.status === 'L') {
                      return (
                        <td
                          key={d}
                          className="py-1 px-1 text-center border-r border-slate-200"
                          title={`Approved Leave: ${cell.leaveType || 'L'} (${cell.note || 'No note'})`}
                        >
                          <div className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-semibold flex flex-col items-center">
                            <span>Leave</span>
                            <span className="text-[8px] text-amber-600 font-mono font-normal uppercase">
                              {cell.leaveType || 'PL'}
                            </span>
                          </div>
                        </td>
                      );
                    }

                    // WFH
                    return (
                      <td
                        key={d}
                        onClick={() => handleCellClick(emp.id, d)}
                        className="py-1 px-1 text-center border-r border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors"
                        title={cell.note || 'Click to toggle Office <-> WFH'}
                      >
                        <div className="px-1.5 py-1 rounded bg-slate-50 text-slate-500 border border-slate-200 text-[10px] font-medium font-mono">
                          {cell.note ? 'Travel' : 'WFH'}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Grid Legend & Status Footer */}
      <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2.5 text-[11px] text-slate-600">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">Legend:</span>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-indigo-100 border border-indigo-300 inline-block" />
            <span>Senior Fixed</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-teal-100 border border-teal-300 inline-block" />
            <span>Backfilled Fixed</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-blue-100 border border-blue-300 inline-block" />
            <span>Hot Desk</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-amber-100 border border-amber-300 inline-block" />
            <span>Leave</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-slate-100 border border-slate-300 inline-block" />
            <span>WFH</span>
          </div>
        </div>

        <div className="text-[10px] text-slate-400">
          Tip: Click cell to toggle Office ↔ WFH
        </div>
      </div>
    </div>
  );
};
