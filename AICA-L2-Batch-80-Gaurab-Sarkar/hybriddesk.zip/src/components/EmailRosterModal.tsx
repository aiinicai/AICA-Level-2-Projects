import React, { useState } from 'react';
import {
  Mail,
  Copy,
  Check,
  Download,
  X,
  Code,
  Eye,
  Info,
  ExternalLink
} from 'lucide-react';
import {
  AllocationResult,
  Employee,
  Holiday,
  PolicySettings,
  RosterPeriodConfig
} from '../types';
import { generateRosterEmailHTML, downloadRosterHTML } from '../logic/exporter';

interface EmailRosterModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: AllocationResult | null;
  employees: Employee[];
  period: RosterPeriodConfig;
  policy: PolicySettings;
  holidays: Holiday[];
  seatCount: number;
}

export const EmailRosterModal: React.FC<EmailRosterModalProps> = ({
  isOpen,
  onClose,
  result,
  employees,
  period,
  policy,
  holidays,
  seatCount
}) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'html'>('preview');
  const [copiedFormatted, setCopiedFormatted] = useState(false);
  const [copiedRaw, setCopiedRaw] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen || !result) return null;

  const emailHtml = generateRosterEmailHTML({
    result,
    employees,
    period,
    policy,
    holidays,
    seatCount
  });

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleCopyFormatted = async () => {
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        const textBlob = new Blob([emailHtml], { type: 'text/html' });
        const plainBlob = new Blob(['HybridDesk Fortnightly Roster (Please view in HTML email client)'], {
          type: 'text/plain'
        });
        await navigator.clipboard.write([
          new ClipboardItem({
            'text/html': textBlob,
            'text/plain': plainBlob
          })
        ]);
        setCopiedFormatted(true);
        showToast('✓ Rich table copied! Paste directly into Gmail, Outlook, or Apple Mail compose window.');
        setTimeout(() => setCopiedFormatted(false), 2500);
      } else {
        // Fallback
        await navigator.clipboard.writeText(emailHtml);
        setCopiedFormatted(true);
        showToast('✓ HTML copied to clipboard.');
        setTimeout(() => setCopiedFormatted(false), 2500);
      }
    } catch (err) {
      console.error('Failed to copy clipboard items:', err);
      await navigator.clipboard.writeText(emailHtml);
      setCopiedFormatted(true);
      showToast('✓ HTML copied to clipboard.');
      setTimeout(() => setCopiedFormatted(false), 2500);
    }
  };

  const handleCopyRaw = async () => {
    try {
      await navigator.clipboard.writeText(emailHtml);
      setCopiedRaw(true);
      showToast('✓ Raw HTML code copied to clipboard!');
      setTimeout(() => setCopiedRaw(false), 2500);
    } catch (err) {
      console.error('Failed to copy raw HTML:', err);
    }
  };

  const handleDownload = () => {
    downloadRosterHTML({
      result,
      employees,
      period,
      policy,
      holidays,
      seatCount
    });
    showToast('✓ Downloaded HTML file.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Email-Ready HTML Fortnightly Roster
              </h3>
              <p className="text-[10px] text-slate-400">
                Self-contained, inline-styled email template formatted for Outlook, Gmail, Apple Mail & Thunderbird.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="p-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          {/* Sub-view switcher */}
          <div className="flex items-center gap-1 bg-slate-200/80 p-0.5 rounded">
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                activeTab === 'preview'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Email Preview</span>
            </button>
            <button
              onClick={() => setActiveTab('html')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                activeTab === 'html'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Code className="w-3 h-3" />
              <span>Raw HTML Source</span>
            </button>
          </div>

          {/* Export & Copy buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyFormatted}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
              title="Copies rich formatted table. Paste directly into email compose window."
            >
              {copiedFormatted ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedFormatted ? 'Copied Formatted!' : 'Copy Formatted Email'}</span>
            </button>

            <button
              onClick={handleCopyRaw}
              className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold flex items-center gap-1 transition-colors"
              title="Copy HTML code for automated mailers"
            >
              {copiedRaw ? <Check className="w-3 h-3 text-emerald-600" /> : <Code className="w-3 h-3 text-slate-500" />}
              <span>{copiedRaw ? 'Copied Code' : 'Copy HTML Code'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Download className="w-3 h-3 text-slate-500" />
              <span>Download .html</span>
            </button>
          </div>
        </div>

        {/* Toast Alert */}
        {toastMsg && (
          <div className="p-2 bg-emerald-600 text-white text-xs font-medium px-3 flex items-center justify-between">
            <span>{toastMsg}</span>
            <button onClick={() => setToastMsg(null)} className="font-bold text-xs ml-2">✕</button>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-3.5 bg-slate-100/70">
          {activeTab === 'preview' ? (
            <div className="bg-white rounded-lg border border-slate-300 shadow-xs overflow-hidden">
              <div className="p-2 bg-slate-200 border-b border-slate-300 text-[10px] font-mono text-slate-600 flex items-center justify-between">
                <span>Subject: [Roster Update] Fortnightly Hybrid Schedule ({period.startDate} to {period.endDate})</span>
                <span className="text-slate-400">100% Inline CSS • Outlook / Gmail Ready</span>
              </div>
              <div className="p-2 sm:p-4 overflow-x-auto max-h-[60vh]">
                <iframe
                  title="Email Roster Preview"
                  srcDoc={emailHtml}
                  className="w-full min-h-[520px] border-0"
                />
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 rounded-lg border border-slate-800 p-3 overflow-x-auto">
              <pre className="text-[11px] font-mono text-slate-200 whitespace-pre-wrap select-all leading-relaxed max-h-[58vh] overflow-y-auto">
                {emailHtml}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
            <Info className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>
              Tip: Click <strong>"Copy Formatted Email"</strong>, then press <code>Ctrl+V</code> (or <code>Cmd+V</code>) inside Outlook or Gmail to paste the styled table directly.
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-bold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
