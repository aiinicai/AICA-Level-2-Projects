import React from 'react';
import {
  Users,
  Building2,
  Calendar,
  Percent,
  CheckCircle2,
  AlertOctagon,
  AlertTriangle,
  Flame,
  Layers,
  ArrowUpRight,
  SlidersHorizontal
} from 'lucide-react';
import { AllocationResult, Employee } from '../types';

interface KpiSummaryCardsProps {
  result: AllocationResult;
  employees: Employee[];
  seatCount: number;
  onRecalculate?: () => void;
  onOpenWhatIf?: () => void;
}

export const KpiSummaryCards: React.FC<KpiSummaryCardsProps> = ({
  result,
  employees,
  seatCount,
  onRecalculate,
  onOpenWhatIf
}) => {
  const activeCount = employees.filter((e) => e.active).length;
  const ratioPct = activeCount > 0 ? Math.round((seatCount / activeCount) * 100) : 0;

  return (
    <div className="space-y-3 mb-4">
      {/* Stale Roster Banner */}
      {result.isStale && (
        <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-lg flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-amber-900">
                Roster is Stale — Employee leaves or configurations were updated.
              </h4>
            </div>
          </div>
          {onRecalculate && (
            <button
              onClick={onRecalculate}
              className="px-2.5 py-1 bg-amber-700 hover:bg-amber-800 text-white rounded text-xs font-semibold whitespace-nowrap transition-colors"
            >
              Re-Calculate
            </button>
          )}
        </div>
      )}

      {/* Prominent Red Deficit Callout */}
      {result.deficit.hasDeficit && (
        <div className="p-3 bg-rose-50 border border-rose-400 rounded-lg text-rose-950 shadow-xs">
          <div className="flex items-start gap-2.5">
            <div className="p-1.5 bg-rose-100 rounded text-rose-700 shrink-0 mt-0.5">
              <AlertOctagon className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-rose-950 uppercase tracking-tight">
                  SEAT DEFICIT: The team is short by {result.deficit.seatsShort} physical desk(s)
                </h3>
                <div className="flex items-center gap-2">
                  {onOpenWhatIf && (
                    <button
                      onClick={onOpenWhatIf}
                      className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-700 hover:bg-rose-800 text-white flex items-center gap-1 shadow-2xs transition-colors"
                    >
                      <SlidersHorizontal className="w-3 h-3" />
                      <span>What-If Simulator</span>
                    </button>
                  )}
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-200 text-rose-900 font-mono">
                    Capacity Infeasible
                  </span>
                </div>
              </div>
              <div className="mt-1.5 text-xs space-y-0.5 text-rose-800 font-medium">
                <p>
                  <strong>Demand:</strong> <span className="font-mono">{result.deficit.demandSeatDays}d</span> &nbsp;|&nbsp;
                  <strong>Supply:</strong> <span className="font-mono">{result.deficit.supplySeatDays}d</span> &nbsp;|&nbsp;
                  <strong>Shortfall:</strong> <span className="font-mono font-bold text-rose-950">{result.deficit.deficitSeatDays} seat-days</span>.
                </p>
                <p className="text-rose-700 text-[11px]">
                  <strong>{result.deficit.affectedEmployeesCount} employee(s)</strong> cannot meet their target due to physical seat limits. Minimum seats for 100% compliance: <strong className="font-mono">{result.deficit.minSeatsForFullCompliance} seats</strong>.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Spare Capacity Banner */}
      {!result.deficit.hasDeficit && result.deficit.spareSeatDays > 0 && (
        <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-lg flex items-center justify-between text-xs text-emerald-950 shadow-2xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="text-[11px]">
              <span className="font-bold">Spare Capacity:</span> {result.deficit.spareSeatDays} seat-days ({result.deficit.spareSeatsEquivalent} seats equiv). Auto-utilized for fairness top-up.
            </div>
          </div>
          <div className="flex items-center gap-2">
            {onOpenWhatIf && (
              <button
                onClick={onOpenWhatIf}
                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-700 hover:bg-emerald-800 text-white flex items-center gap-1 shadow-2xs transition-colors"
              >
                <SlidersHorizontal className="w-3 h-3" />
                <span>Simulate</span>
              </button>
            )}
            <span className="px-2 py-0.5 bg-emerald-200/80 text-emerald-900 rounded font-semibold text-[10px] font-mono">
              100% Compliant
            </span>
          </div>
        </div>
      )}

      {/* 8 Metric KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
        {/* Headcount */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Headcount</span>
            <Users className="w-3 h-3 text-slate-400" />
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 leading-tight">{activeCount}</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Active members</div>
        </div>

        {/* Seat Inventory */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Seats</span>
            <Building2 className="w-3 h-3 text-slate-400" />
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 leading-tight">{seatCount}</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Inventory cap</div>
        </div>

        {/* Seat Ratio % */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Seat Ratio</span>
            <Percent className="w-3 h-3 text-slate-400" />
          </div>
          <div className={`text-lg font-bold font-mono leading-tight ${ratioPct < 70 ? 'text-amber-600' : 'text-blue-600'}`}>
            {ratioPct}%
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Seats/head</div>
        </div>

        {/* Working Days */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Work Days</span>
            <Calendar className="w-3 h-3 text-slate-400" />
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 leading-tight">{result.workingDays.length}</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">14-day window</div>
        </div>

        {/* Avg Utilisation */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Avg Util</span>
            <Layers className="w-3 h-3 text-slate-400" />
          </div>
          <div className="text-lg font-bold font-mono text-emerald-600 leading-tight">{result.avgDailyUtilisationPct}%</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Daily occupancy</div>
        </div>

        {/* Fully Compliant */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Compliant</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
          </div>
          <div className="text-lg font-bold font-mono text-emerald-600 leading-tight">{result.fullyCompliantCount}</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Met targets</div>
        </div>

        {/* Non-Compliant */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Shortfall</span>
            <AlertTriangle className="w-3 h-3 text-rose-500" />
          </div>
          <div className={`text-lg font-bold font-mono leading-tight ${result.nonCompliantCount > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
            {result.nonCompliantCount}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Below policy</div>
        </div>

        {/* Seats Short */}
        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Shortage</span>
            <AlertOctagon className="w-3 h-3 text-rose-600" />
          </div>
          <div className={`text-lg font-bold font-mono leading-tight ${result.deficit.seatsShort > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
            {result.deficit.seatsShort}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">Desks needed</div>
        </div>
      </div>
    </div>
  );
};
