import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  AlertTriangle,
  Info,
  Check,
  Plane,
  X
} from 'lucide-react';
import {
  Employee,
  Holiday,
  LeaveRecord,
  LeaveType,
  RosterPeriodConfig
} from '../types';
import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  isWeekend,
  parseISO,
  startOfMonth,
  startOfWeek,
  subMonths
} from 'date-fns';

interface LeaveCalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  leaves: LeaveRecord[];
  setLeaves: React.Dispatch<React.SetStateAction<LeaveRecord[]>>;
  holidays: Holiday[];
  period: RosterPeriodConfig;
  initialEmployeeId?: string;
  onMarkStale: () => void;
}

const LEAVE_TYPES: { type: LeaveType; label: string; desc: string; isException: boolean; color: string; badgeColor: string }[] = [
  {
    type: 'PL',
    label: 'Planned Leave',
    desc: 'Pre-approved annual/casual leave',
    isException: false,
    color: 'bg-amber-100 text-amber-900 border-amber-300',
    badgeColor: 'bg-amber-100 text-amber-800'
  },
  {
    type: 'SL',
    label: 'Sick Leave',
    desc: 'Medical absence (Exception)',
    isException: true,
    color: 'bg-rose-100 text-rose-900 border-rose-300',
    badgeColor: 'bg-rose-100 text-rose-800'
  },
  {
    type: 'ML',
    label: 'Maternity Leave',
    desc: 'Statutory maternity leave (Exception)',
    isException: true,
    color: 'bg-pink-100 text-pink-900 border-pink-300',
    badgeColor: 'bg-pink-100 text-pink-800'
  },
  {
    type: 'PTL',
    label: 'Paternity Leave',
    desc: 'Statutory paternity leave (Exception)',
    isException: true,
    color: 'bg-cyan-100 text-cyan-900 border-cyan-300',
    badgeColor: 'bg-cyan-100 text-cyan-800'
  },
  {
    type: 'EL',
    label: 'Emergency Leave',
    desc: 'Urgent family / unplanned leave (Exception)',
    isException: true,
    color: 'bg-orange-100 text-orange-900 border-orange-300',
    badgeColor: 'bg-orange-100 text-orange-800'
  },
  {
    type: 'CO',
    label: 'Comp-Off',
    desc: 'Compensatory off for weekend work',
    isException: false,
    color: 'bg-indigo-100 text-indigo-900 border-indigo-300',
    badgeColor: 'bg-indigo-100 text-indigo-800'
  },
  {
    type: 'TRV',
    label: 'Work Travel',
    desc: 'Client visit / conference (WFO-Exempt)',
    isException: false,
    color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    badgeColor: 'bg-emerald-100 text-emerald-800'
  }
];

export const LeaveCalendarModal: React.FC<LeaveCalendarModalProps> = ({
  isOpen,
  onClose,
  employees,
  leaves,
  setLeaves,
  holidays,
  period,
  initialEmployeeId,
  onMarkStale
}) => {
  const activeEmployees = employees.filter((e) => e.active);
  const [selectedEmpId, setSelectedEmpId] = useState<string>(
    initialEmployeeId || activeEmployees[0]?.id || ''
  );
  const [currentMonth, setCurrentMonth] = useState<Date>(
    period.startDate ? parseISO(period.startDate) : new Date()
  );
  const [selectedLeaveType, setSelectedLeaveType] = useState<LeaveType>('PL');
  const [leaveNote, setLeaveNote] = useState<string>('');

  // Range selection state
  const [rangeFrom, setRangeFrom] = useState<string>('');
  const [rangeTo, setRangeTo] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentEmp = employees.find((e) => e.id === selectedEmpId);
  const holidayMap = new Map<string, Holiday>();
  holidays.forEach((h) => holidayMap.set(h.date, h));

  // Calendar dates generation
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 }); // Monday start
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Leaves of current employee
  const currentEmpLeaves = leaves.filter((l) => l.employeeId === selectedEmpId);
  const empLeaveMap = new Map<string, LeaveRecord>();
  currentEmpLeaves.forEach((l) => empLeaveMap.set(l.date, l));

  // Handle single day click
  const handleDayClick = (day: Date) => {
    const dateStr = format(day, 'yyyy-MM-dd');
    const weekend = isWeekend(day);
    const holiday = holidayMap.get(dateStr);

    if (weekend || holiday) {
      setToastMessage(
        `Cannot log leave on ${dateStr} (${weekend ? 'Weekend' : holiday?.name}). Non-working days are automatically excluded.`
      );
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }

    if (empLeaveMap.has(dateStr)) {
      // Remove leave
      setLeaves(leaves.filter((l) => !(l.employeeId === selectedEmpId && l.date === dateStr)));
    } else {
      // Add leave
      const config = LEAVE_TYPES.find((t) => t.type === selectedLeaveType);
      const newRecord: LeaveRecord = {
        id: `leave-${selectedEmpId}-${dateStr}-${Date.now()}`,
        employeeId: selectedEmpId,
        date: dateStr,
        type: selectedLeaveType,
        note: leaveNote || config?.label,
        isException: config?.isException
      };
      setLeaves([...leaves, newRecord]);
    }
    onMarkStale();
  };

  // Handle Range Selection Apply
  const handleApplyRange = () => {
    if (!rangeFrom || !rangeTo) return;
    if (rangeFrom > rangeTo) {
      setToastMessage('Start date cannot be after end date.');
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }

    const start = parseISO(rangeFrom);
    const end = parseISO(rangeTo);
    const days = eachDayOfInterval({ start, end });

    let addedCount = 0;
    const newLeaves = [...leaves];
    const config = LEAVE_TYPES.find((t) => t.type === selectedLeaveType);

    days.forEach((d) => {
      const dateStr = format(d, 'yyyy-MM-dd');
      const weekend = isWeekend(d);
      const holiday = holidayMap.get(dateStr);

      if (!weekend && !holiday) {
        // Remove existing if any
        const existingIdx = newLeaves.findIndex(
          (l) => l.employeeId === selectedEmpId && l.date === dateStr
        );
        if (existingIdx >= 0) {
          newLeaves.splice(existingIdx, 1);
        }

        newLeaves.push({
          id: `leave-${selectedEmpId}-${dateStr}-${Date.now()}`,
          employeeId: selectedEmpId,
          date: dateStr,
          type: selectedLeaveType,
          note: leaveNote || config?.label,
          isException: config?.isException
        });
        addedCount++;
      }
    });

    setLeaves(newLeaves);
    onMarkStale();
    setToastMessage(`Recorded ${addedCount} working days of ${config?.label} for ${currentEmp?.name}.`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Remove all leaves in period
  const handleClearLeaves = () => {
    setLeaves(leaves.filter((l) => l.employeeId !== selectedEmpId));
    onMarkStale();
  };

  const periodLeavesCount = currentEmpLeaves.filter(
    (l) => l.date >= period.startDate && l.date <= period.endDate && l.type !== 'TRV'
  ).length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[88vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Employee Leave & Exception Calendar
              </h3>
              <p className="text-[10px] text-slate-400">
                Log planned leaves, medical exceptions, and travel exemptions.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Employee Switcher Bar */}
        <div className="p-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-700">Select Employee:</label>
            <select
              value={selectedEmpId}
              onChange={(e) => setSelectedEmpId(e.target.value)}
              className="px-2.5 py-1 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900 focus:outline-hidden"
            >
              {activeEmployees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.empId} — {emp.name} ({emp.designation})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded font-semibold font-mono text-[11px]">
              {periodLeavesCount}d in Period
            </span>
            <button
              onClick={handleClearLeaves}
              className="text-[11px] text-rose-600 hover:text-rose-800 font-semibold"
            >
              Clear All
            </button>
          </div>
        </div>

        {/* Toast Notification */}
        {toastMessage && (
          <div className="p-2 bg-blue-600 text-white text-[11px] font-medium px-3 flex items-center justify-between">
            <span>{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="font-bold">✕</button>
          </div>
        )}

        <div className="p-3.5 overflow-y-auto flex-1 space-y-3">
          {/* Leave Type Selector Chips */}
          <div>
            <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              Select Leave / Absence Type:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5">
              {LEAVE_TYPES.map((lt) => (
                <button
                  key={lt.type}
                  onClick={() => setSelectedLeaveType(lt.type)}
                  className={`p-1.5 rounded border text-left transition-all ${
                    selectedLeaveType === lt.type
                      ? `${lt.color} ring-2 ring-blue-600 font-bold shadow-2xs`
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-[11px] font-bold truncate">{lt.label}</div>
                  <div className="text-[9px] opacity-75 font-mono">{lt.type}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Date Range Selection */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="font-semibold text-slate-700 text-[11px]">Range:</span>
              <input
                type="date"
                value={rangeFrom}
                onChange={(e) => setRangeFrom(e.target.value)}
                className="px-2 py-0.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
              <span className="text-slate-400 text-xs">to</span>
              <input
                type="date"
                value={rangeTo}
                onChange={(e) => setRangeTo(e.target.value)}
                className="px-2 py-0.5 bg-white border border-slate-300 rounded text-xs font-mono"
              />
              <input
                type="text"
                placeholder="Reason (Optional)"
                value={leaveNote}
                onChange={(e) => setLeaveNote(e.target.value)}
                className="px-2 py-0.5 bg-white border border-slate-300 rounded text-xs min-w-[130px]"
              />
            </div>
            <button
              onClick={handleApplyRange}
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold transition-colors shadow-2xs"
            >
              Apply Range
            </button>
          </div>

          {/* Monthly Calendar View */}
          <div className="border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            {/* Month Header Nav */}
            <div className="p-2 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                className="p-1 rounded hover:bg-slate-200 text-slate-700"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                {format(currentMonth, 'MMMM yyyy')}
              </h4>
              <button
                onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                className="p-1 rounded hover:bg-slate-200 text-slate-700"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 text-center bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600">
              <div className="py-1.5">Mon</div>
              <div className="py-1.5">Tue</div>
              <div className="py-1.5">Wed</div>
              <div className="py-1.5">Thu</div>
              <div className="py-1.5">Fri</div>
              <div className="py-1.5 text-rose-600">Sat</div>
              <div className="py-1.5 text-rose-600">Sun</div>
            </div>

            <div className="grid grid-cols-7 bg-slate-200 gap-px">
              {calendarDays.map((day) => {
                const dateStr = format(day, 'yyyy-MM-dd');
                const isCurrentMonth = isSameMonth(day, currentMonth);
                const weekend = isWeekend(day);
                const holiday = holidayMap.get(dateStr);
                const leaveRecord = empLeaveMap.get(dateStr);
                const isInPeriod = dateStr >= period.startDate && dateStr <= period.endDate;

                let cellBg = 'bg-white hover:bg-slate-50 cursor-pointer';
                let textColor = isCurrentMonth ? 'text-slate-900' : 'text-slate-400';
                let tooltip = `Click to toggle ${selectedLeaveType} leave`;

                if (weekend) {
                  cellBg = 'bg-slate-100/90 cursor-not-allowed';
                  textColor = 'text-slate-400';
                  tooltip = 'Weekend (Non-working day)';
                } else if (holiday) {
                  cellBg = 'bg-rose-50/70 cursor-not-allowed';
                  textColor = 'text-rose-600 font-bold';
                  tooltip = `NSE Trading Holiday: ${holiday.name}`;
                } else if (leaveRecord) {
                  const conf = LEAVE_TYPES.find((t) => t.type === leaveRecord.type);
                  cellBg = `${conf?.color || 'bg-amber-100 text-amber-900'} cursor-pointer font-bold`;
                  tooltip = `${conf?.label || leaveRecord.type}: ${leaveRecord.note || 'No note'}`;
                }

                return (
                  <div
                    key={dateStr}
                    onClick={() => handleDayClick(day)}
                    title={tooltip}
                    className={`min-h-[58px] p-1.5 flex flex-col justify-between transition-colors relative ${cellBg}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[11px] font-semibold font-mono ${textColor}`}>
                        {format(day, 'd')}
                      </span>
                      {isInPeriod && (
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-600" title="Active Roster Window" />
                      )}
                    </div>

                    <div className="mt-0.5">
                      {holiday && (
                        <span className="block text-[8px] text-rose-700 font-semibold truncate leading-tight">
                          {holiday.name}
                        </span>
                      )}
                      {leaveRecord && (
                        <span className="inline-block text-[8px] px-1 py-0.2 rounded font-bold uppercase truncate max-w-full">
                          {leaveRecord.type}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Note: Weekends and NSE trading holidays are automatically greyed out.
          </span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-bold transition-colors"
          >
            Done & Return
          </button>
        </div>
      </div>
    </div>
  );
};
