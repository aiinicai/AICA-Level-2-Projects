import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertOctagon,
  RotateCcw,
  Sparkles,
  X,
  Code2
} from 'lucide-react';
import {
  AcceptanceTestResult,
  AllocationResult,
  Employee,
  Holiday,
  LeaveRecord,
  PolicySettings,
  RosterPeriodConfig
} from '../types';
import { runAcceptanceTests } from '../logic/allocator';

interface AcceptanceTestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: AllocationResult | null;
  seatCount: number;
  employees: Employee[];
  leaves: LeaveRecord[];
  holidays: Holiday[];
  policy: PolicySettings;
  period: RosterPeriodConfig;
}

export const AcceptanceTestsModal: React.FC<AcceptanceTestsModalProps> = ({
  isOpen,
  onClose,
  result,
  seatCount,
  employees,
  leaves,
  holidays,
  policy,
  period
}) => {
  const [lastRunTime, setLastRunTime] = useState<string>(new Date().toLocaleTimeString());

  if (!isOpen) return null;

  if (!result) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-5 text-center space-y-3">
          <ShieldCheck className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">Acceptance Test Runner</h3>
          <p className="text-xs text-slate-500">
            Please run "Calculate Allocation" first to generate a roster to execute assertions on.
          </p>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 text-white rounded text-xs font-bold"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const tests = runAcceptanceTests(result, {
    seatCount,
    employees,
    leaves,
    holidays,
    policy,
    period
  });

  const passedCount = tests.filter((t) => t.passed).length;
  const isAllPassed = passedCount === tests.length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Acceptance Test Suite (T1 — T8)
              </h3>
              <p className="text-[10px] text-slate-400">
                Automated programmatic assertions validating invariant rules and constraints.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Score Banner */}
        <div
          className={`p-2.5 px-3.5 border-b flex items-center justify-between ${
            isAllPassed
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
              : 'bg-rose-50 border-rose-200 text-rose-950'
          }`}
        >
          <div className="flex items-center gap-2">
            {isAllPassed ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertOctagon className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <div>
              <span className="font-bold text-xs font-mono">
                {passedCount} of {tests.length} Invariant Tests Passed
              </span>
              <span className="text-[10px] opacity-75 ml-2 font-mono">
                (Executed at {lastRunTime})
              </span>
            </div>
          </div>

          <button
            onClick={() => setLastRunTime(new Date().toLocaleTimeString())}
            className="px-2 py-0.5 bg-white border border-slate-300 hover:bg-slate-50 rounded text-xs font-semibold flex items-center gap-1 shadow-2xs text-slate-700"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Re-Run</span>
          </button>
        </div>

        {/* Test List */}
        <div className="p-3.5 overflow-y-auto flex-1 space-y-2">
          {tests.map((test) => (
            <div
              key={test.id}
              className={`p-2.5 rounded-lg border transition-all ${
                test.passed
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : 'bg-rose-50/60 border-rose-300'
              }`}
            >
              <div className="flex items-start justify-between gap-2.5">
                <div className="flex items-start gap-2">
                  <span
                    className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider mt-0.5 font-mono ${
                      test.passed
                        ? 'bg-emerald-200 text-emerald-800'
                        : 'bg-rose-200 text-rose-800'
                    }`}
                  >
                    {test.passed ? 'PASSED' : 'FAILED'}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {test.name}
                    </h4>
                    <p className="text-[11px] text-slate-700 mt-0.5 font-mono leading-relaxed">
                      {test.message}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[10px] text-slate-500 font-mono">
            Source assertions defined in /src/logic/allocator.ts
          </span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-bold"
          >
            Close Runner
          </button>
        </div>
      </div>
    </div>
  );
};
