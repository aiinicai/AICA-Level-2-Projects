import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  Trash2,
  Edit2,
  RotateCcw,
  Upload,
  AlertCircle,
  CheckCircle2,
  X,
  Info
} from 'lucide-react';
import { Holiday } from '../types';
import { DEFAULT_NSE_HOLIDAYS_2026, getInitialHolidays } from '../logic/nseHolidays';
import { format, isWeekend, parseISO } from 'date-fns';
import Papa from 'papaparse';

interface HolidayMasterModalProps {
  isOpen: boolean;
  onClose: () => void;
  holidays: Holiday[];
  setHolidays: React.Dispatch<React.SetStateAction<Holiday[]>>;
  onMarkStale: () => void;
}

export const HolidayMasterModal: React.FC<HolidayMasterModalProps> = ({
  isOpen,
  onClose,
  holidays,
  setHolidays,
  onMarkStale
}) => {
  const [newDate, setNewDate] = useState('');
  const [newName, setNewName] = useState('');
  const [newSource, setNewSource] = useState<'NSE' | 'Custom'>('Custom');
  const [editingHoliday, setEditingHoliday] = useState<Holiday | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddOrEdit = () => {
    if (!newDate || !newName.trim()) {
      setErrorMsg('Date and Holiday Name are required.');
      return;
    }

    const parsed = parseISO(newDate);
    const dayName = format(parsed, 'EEEE');
    const dayWeekend = isWeekend(parsed);

    if (editingHoliday) {
      setHolidays(
        holidays.map((h) =>
          h.id === editingHoliday.id
            ? {
                ...h,
                date: newDate,
                name: newName.trim(),
                day: dayName,
                isWeekend: dayWeekend,
                source: newSource
              }
            : h
        )
      );
      setEditingHoliday(null);
    } else {
      const newHol: Holiday = {
        id: `hol-custom-${Date.now()}`,
        date: newDate,
        day: dayName,
        name: newName.trim(),
        source: newSource,
        isWeekend: dayWeekend
      };
      setHolidays([...holidays, newHol].sort((a, b) => a.date.localeCompare(b.date)));
    }

    setNewDate('');
    setNewName('');
    setErrorMsg(null);
    onMarkStale();
  };

  const handleResetToDefaults = () => {
    setHolidays(getInitialHolidays());
    onMarkStale();
  };

  const handleDelete = (id: string) => {
    setHolidays(holidays.filter((h) => h.id !== id));
    onMarkStale();
  };

  const handleCSVImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows: any[] = results.data;
        const imported: Holiday[] = [...holidays];

        rows.forEach((row, i) => {
          const dateStr = row.Date || row.date;
          const nameStr = row.Name || row['Holiday Name'] || row.name;
          const src = row.Source || 'Custom';

          if (dateStr && nameStr) {
            try {
              const parsed = parseISO(dateStr.trim());
              imported.push({
                id: `hol-imp-${Date.now()}-${i}`,
                date: format(parsed, 'yyyy-MM-dd'),
                day: format(parsed, 'EEEE'),
                name: String(nameStr).trim(),
                source: src === 'NSE' ? 'NSE' : 'Custom',
                isWeekend: isWeekend(parsed)
              });
            } catch (err) {
              // skip invalid date
            }
          }
        });

        // Deduplicate by date
        const uniqueMap = new Map<string, Holiday>();
        imported.forEach((h) => uniqueMap.set(h.date, h));
        const sorted = Array.from(uniqueMap.values()).sort((a, b) => a.date.localeCompare(b.date));

        setHolidays(sorted);
        onMarkStale();
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Holiday Master (NSE Trading Holidays & Custom Offs)
              </h3>
              <p className="text-[10px] text-slate-400">
                Official capital-market exchange holidays that exclude working days from the fortnight.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Regulatory Circular Warning Banner */}
        <div className="p-2 bg-amber-50 border-b border-amber-200 text-amber-900 text-[11px] flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-amber-700 shrink-0" />
          <span>
            <strong>NSE Circular Note:</strong> Verify against the latest NSE trading-holiday circular; the exchange may revise dates by subsequent notification.
          </span>
        </div>

        <div className="p-3.5 overflow-y-auto flex-1 space-y-3">
          {/* Add / Edit Holiday Form */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
            <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-tight">
              {editingHoliday ? 'Edit Holiday Record' : 'Add Holiday / Trading Off'}
            </h4>

            {errorMsg && (
              <div className="text-[11px] text-rose-700 bg-rose-50 p-1.5 rounded border border-rose-200">
                {errorMsg}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <input
                type="date"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono"
              />
              <input
                type="text"
                placeholder="Holiday Name (e.g. Diwali)"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="sm:col-span-2 px-2.5 py-1 bg-white border border-slate-300 rounded text-xs"
              />
              <button
                onClick={handleAddOrEdit}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold transition-colors"
              >
                {editingHoliday ? 'Update' : 'Add Holiday'}
              </button>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider font-mono">
              {holidays.length} Holidays Configured
            </span>
            <div className="flex items-center gap-1.5">
              <label className="px-2 py-1 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded text-xs font-semibold cursor-pointer shadow-2xs flex items-center gap-1">
                <Upload className="w-3 h-3 text-slate-500" />
                <span>Import CSV</span>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleCSVImport}
                  className="hidden"
                />
              </label>
              <button
                onClick={handleResetToDefaults}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold border border-slate-300 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset to NSE 2026</span>
              </button>
            </div>
          </div>

          {/* Holidays Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700 font-semibold text-[11px]">
                  <th className="py-1.5 px-2.5">Date</th>
                  <th className="py-1.5 px-2.5">Day</th>
                  <th className="py-1.5 px-2.5">Holiday Name</th>
                  <th className="py-1.5 px-2.5">Source</th>
                  <th className="py-1.5 px-2.5 text-center">Working Day Impact</th>
                  <th className="py-1.5 px-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {holidays.map((h) => {
                  return (
                    <tr key={h.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-1.5 px-2.5 font-semibold text-slate-900 font-mono text-[11px]">
                        {format(parseISO(h.date), 'dd-MMM-yyyy')}
                      </td>
                      <td className="py-1.5 px-2.5 text-slate-600 text-[11px]">
                        {h.day}
                      </td>
                      <td className="py-1.5 px-2.5 font-medium text-slate-800 text-[11px]">
                        {h.name}
                      </td>
                      <td className="py-1.5 px-2.5">
                        <span className={`inline-flex px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          h.source === 'NSE' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {h.source}
                        </span>
                      </td>
                      <td className="py-1.5 px-2.5 text-center">
                        {h.isWeekend ? (
                          <span className="inline-flex px-1.5 py-0.2 rounded text-[9px] font-medium bg-slate-100 text-slate-500">
                            Weekend (No impact)
                          </span>
                        ) : (
                          <span className="inline-flex px-1.5 py-0.2 rounded text-[9px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                            -1 Working Day
                          </span>
                        )}
                      </td>
                      <td className="py-1.5 px-2.5 text-right">
                        <button
                          onClick={() => {
                            setEditingHoliday(h);
                            setNewDate(h.date);
                            setNewName(h.name);
                            setNewSource(h.source);
                          }}
                          className="p-1 text-slate-400 hover:text-blue-600 mr-0.5"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDelete(h.id)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-bold"
          >
            Close Master
          </button>
        </div>
      </div>
    </div>
  );
};
