import React from 'react';
import {
  Calendar,
  Users,
  Building2,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Download,
  RotateCcw,
  Sparkles,
  HelpCircle,
  ShieldCheck,
  Flame,
  SlidersHorizontal,
  Mail
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'roster' | 'employees' | 'calendar' | 'holidays' | 'map';
  setActiveTab: (tab: 'roster' | 'employees' | 'calendar' | 'holidays' | 'map') => void;
  onOpenHowItWorks: () => void;
  onOpenTests: () => void;
  onOpenWhatIf: () => void;
  onOpenEmailRoster: () => void;
  onLoadDemo: (infeasible?: boolean) => void;
  isStale: boolean;
  hasCalculated: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenHowItWorks,
  onOpenTests,
  onOpenWhatIf,
  onOpenEmailRoster,
  onLoadDemo,
  isStale,
  hasCalculated
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-6 h-12 flex items-center justify-between gap-3">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center font-bold text-xs text-white shadow-inner tracking-tight">
            HD
          </div>
          <span className="font-bold text-sm tracking-tight text-white block">
            HybridDesk
          </span>
          {isStale && hasCalculated && (
            <span className="ml-1.5 inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
              Roster Stale
            </span>
          )}
        </div>

        {/* Navigation Zone */}
        <nav className="flex items-center gap-1 overflow-x-auto py-0.5">
          <button
            onClick={() => setActiveTab('roster')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'roster'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Roster & KPIs
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'map'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Seat Map
          </button>
          <button
            onClick={() => setActiveTab('employees')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'employees'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Employee Master
          </button>
          <button
            onClick={() => setActiveTab('holidays')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'holidays'
                ? 'bg-blue-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Holiday Master
          </button>
        </nav>

        {/* Action Zone */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onOpenWhatIf}
            title="Open 'What-If' Capacity & Compliance Slider Simulator"
            className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold text-amber-300 bg-amber-950/70 hover:bg-amber-900 border border-amber-600/50 rounded transition-colors whitespace-nowrap shadow-2xs"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span>What-If Simulator</span>
          </button>

          <button
            onClick={onOpenEmailRoster}
            title="Export Email-ready HTML roster table"
            className="hidden md:flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors whitespace-nowrap"
          >
            <Mail className="w-3 h-3 text-blue-400" />
            <span>Email HTML</span>
          </button>

          <button
            onClick={onOpenHowItWorks}
            title="Algorithm explanation and formula reference"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenTests}
            title="Run In-Memory Acceptance Tests (T1 - T8)"
            className="flex items-center gap-1.5 px-2 py-1 text-[11px] font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors whitespace-nowrap"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Tests</span>
          </button>

          <div className="relative group">
            <button
              onClick={() => onLoadDemo(false)}
              className="flex items-center gap-1.5 px-2 py-1 text-[11px] font-semibold text-white bg-slate-700 hover:bg-slate-600 rounded transition-colors whitespace-nowrap"
            >
              <RotateCcw className="w-3 h-3 text-blue-400" />
              <span>Demo</span>
            </button>
            <div className="hidden group-hover:block absolute right-0 mt-1 w-52 bg-slate-800 border border-slate-700 rounded-lg shadow-xl p-1 z-50">
              <button
                onClick={() => onLoadDemo(false)}
                className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-700 rounded flex items-center justify-between"
              >
                <span>Standard (20 seats / 25 pax)</span>
                <span className="text-[10px] text-emerald-400 font-bold">80%</span>
              </button>
              <button
                onClick={() => onLoadDemo(true)}
                className="w-full text-left px-2.5 py-1.5 text-xs text-rose-300 hover:bg-slate-700 rounded flex items-center justify-between"
              >
                <span>Infeasible Deficit (10 seats)</span>
                <span className="text-[10px] text-rose-400 font-bold">Deficit</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

