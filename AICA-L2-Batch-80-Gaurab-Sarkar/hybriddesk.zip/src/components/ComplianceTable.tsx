import React, { useState } from 'react';
import { EmployeeComplianceSummary } from '../types';
import { Search, CheckCircle2, AlertTriangle, HelpCircle } from 'lucide-react';

interface ComplianceTableProps {
  summaries: EmployeeComplianceSummary[];
}

export const ComplianceTable: React.FC<ComplianceTableProps> = ({ summaries }) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = summaries.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.empId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.designation.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (filterStatus === 'COMPLIANT' && !s.isCompliant) return false;
    if (filterStatus === 'SHORTFALL' && (s.isCompliant || s.isFullyOnLeave)) return false;
    if (filterStatus === 'NA' && !s.isFullyOnLeave) return false;

    return true;
  });

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden mb-4">
      <div className="p-2.5 bg-slate-50/90 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Employee Compliance Audit Statement
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Audit of mandated vs allocated office attendance percentages.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Search employee..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-2.5 py-1 bg-white border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
          />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2 py-1 bg-white border border-slate-300 rounded text-xs text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Statuses ({summaries.length})</option>
            <option value="COMPLIANT">Compliant Only</option>
            <option value="SHORTFALL">Shortfall Only</option>
            <option value="NA">Full Leave (N/A)</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700 font-semibold text-[11px]">
              <th className="py-1.5 px-2.5">ID</th>
              <th className="py-1.5 px-2.5">Employee Name</th>
              <th className="py-1.5 px-2.5">Role</th>
              <th className="py-1.5 px-2.5 text-center">Mandated %</th>
              <th className="py-1.5 px-2.5 text-center">Work Days</th>
              <th className="py-1.5 px-2.5 text-center">Leave Days</th>
              <th className="py-1.5 px-2.5 text-center">Net Days</th>
              <th className="py-1.5 px-2.5 text-center">Req Days</th>
              <th className="py-1.5 px-2.5 text-center">Alloc Days</th>
              <th className="py-1.5 px-2.5 text-center">Achieved %</th>
              <th className="py-1.5 px-2.5 text-center">Audit Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {filtered.map((s) => (
              <tr
                key={s.employeeId}
                className={`hover:bg-slate-50/80 transition-colors ${
                  !s.isCompliant && !s.isFullyOnLeave ? 'bg-rose-50/40' : ''
                }`}
              >
                <td className="py-1.5 px-2.5 font-mono text-slate-600 text-[10px]">
                  {s.empId}
                </td>
                <td className="py-1.5 px-2.5 font-semibold text-slate-900 text-[11px]">
                  {s.name}
                </td>
                <td className="py-1.5 px-2.5">
                  <span className="inline-flex px-1.5 py-0.2 rounded text-[10px] font-medium bg-slate-100 text-slate-700">
                    {s.designation}
                  </span>
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono font-medium text-slate-700 text-[11px]">
                  {s.requiredPct}%
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono text-slate-600 text-[11px]">
                  {s.totalWorkingDays}
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono text-amber-700 text-[11px]">
                  {s.leaveDaysInPeriod}
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono text-slate-800 font-semibold text-[11px]">
                  {s.availableWorkingDays}
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono text-slate-700 text-[11px]">
                  {s.requiredOfficeDays}
                </td>
                <td className="py-1.5 px-2.5 text-center font-mono font-bold text-slate-900 text-[11px]">
                  {s.allocatedOfficeDays}
                </td>
                <td className="py-1.5 px-2.5 text-center">
                  <span
                    className={`font-mono font-bold text-[11px] ${
                      s.isFullyOnLeave
                        ? 'text-slate-400'
                        : s.isCompliant
                        ? 'text-emerald-600'
                        : 'text-rose-600'
                    }`}
                  >
                    {s.achievedPct}%
                  </span>
                </td>
                <td className="py-1.5 px-2.5 text-center">
                  {s.isFullyOnLeave ? (
                    <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                      N/A (Leave)
                    </span>
                  ) : s.isCompliant ? (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      <span>Compliant</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                      <AlertTriangle className="w-2.5 h-2.5" />
                      <span>Shortfall ({s.shortfallDays}d)</span>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
