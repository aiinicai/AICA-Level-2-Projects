import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Upload,
  Download,
  Trash2,
  Edit2,
  Check,
  X,
  Search,
  AlertTriangle,
  FileSpreadsheet,
  Calendar,
  Eye,
  EyeOff
} from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { Designation, Employee, LeaveRecord, RosterPeriodConfig } from '../types';

interface EmployeeMasterViewProps {
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
  leaves: LeaveRecord[];
  period: RosterPeriodConfig;
  onOpenLeaveCalendar: (empId: string) => void;
  onMarkStale: () => void;
}

export const EmployeeMasterView: React.FC<EmployeeMasterViewProps> = ({
  employees,
  setEmployees,
  leaves,
  period,
  onOpenLeaveCalendar,
  onMarkStale
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDesignation, setFilterDesignation] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Add / Edit form state
  const [formEmpId, setFormEmpId] = useState('');
  const [formName, setFormName] = useState('');
  const [formDesignation, setFormDesignation] = useState<Designation>('Professional');
  const [formEmail, setFormEmail] = useState('');
  const [formActive, setFormActive] = useState(true);
  const [formError, setFormError] = useState<string | null>(null);

  // Import State
  const [importSummary, setImportSummary] = useState<{
    imported: number;
    skipped: number;
    errors: { row: number; reason: string }[];
  } | null>(null);

  const openAddModal = () => {
    setEditingEmployee(null);
    setFormEmpId(`E${1000 + employees.length + 1}`);
    setFormName('');
    setFormDesignation('Professional');
    setFormEmail('');
    setFormActive(true);
    setFormError(null);
    setIsAddModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormEmpId(emp.empId);
    setFormName(emp.name);
    setFormDesignation(emp.designation);
    setFormEmail(emp.email || '');
    setFormActive(emp.active);
    setFormError(null);
    setIsAddModalOpen(true);
  };

  const handleSaveEmployee = () => {
    if (!formEmpId.trim() || !formName.trim()) {
      setFormError('Employee ID and Name are required.');
      return;
    }

    // Check duplicate ID
    const duplicate = employees.find(
      (e) => e.empId.toLowerCase() === formEmpId.trim().toLowerCase() && e.id !== editingEmployee?.id
    );
    if (duplicate) {
      setFormError(`Employee ID "${formEmpId}" is already taken by ${duplicate.name}.`);
      return;
    }

    if (editingEmployee) {
      setEmployees(
        employees.map((e) =>
          e.id === editingEmployee.id
            ? {
                ...e,
                empId: formEmpId.trim(),
                name: formName.trim(),
                designation: formDesignation,
                email: formEmail.trim() || undefined,
                active: formActive
              }
            : e
        )
      );
    } else {
      const newEmp: Employee = {
        id: `emp-${Date.now()}`,
        empId: formEmpId.trim(),
        name: formName.trim(),
        designation: formDesignation,
        email: formEmail.trim() || undefined,
        active: formActive
      };
      setEmployees([...employees, newEmp]);
    }

    onMarkStale();
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string, softDelete = false) => {
    if (softDelete) {
      setEmployees(
        employees.map((e) => (e.id === id ? { ...e, active: false } : e))
      );
    } else {
      setEmployees(employees.filter((e) => e.id !== id));
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
    setDeleteConfirmId(null);
    onMarkStale();
  };

  const handleBulkDelete = () => {
    setEmployees(employees.filter((e) => !selectedIds.has(e.id)));
    setSelectedIds(new Set());
    onMarkStale();
  };

  const handleBulkToggleActive = (active: boolean) => {
    setEmployees(
      employees.map((e) => (selectedIds.has(e.id) ? { ...e, active } : e))
    );
    setSelectedIds(new Set());
    onMarkStale();
  };

  const handleDownloadTemplate = () => {
    const headers = ['Employee ID', 'Name', 'Designation', 'Email', 'Active'];
    const sampleRows = [
      ['E1001', 'Rajesh Mehta', 'MD', 'rajesh.mehta@hybridcorp.com', 'TRUE'],
      ['E1002', 'Ananya Sharma', 'ED', 'ananya.sharma@hybridcorp.com', 'TRUE'],
      ['E1003', 'Vikram Sengupta', 'VP', 'vikram.s@hybridcorp.com', 'TRUE'],
      ['E1004', 'Deepika Rao', 'Professional', 'deepika.rao@hybridcorp.com', 'TRUE']
    ];

    const csvContent = Papa.unparse({
      fields: headers,
      data: sampleRows
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'HybridDesk_Employee_Template.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = evt.target?.result;
      if (!data) return;

      let parsedRows: any[] = [];
      if (file.name.endsWith('.csv')) {
        const text = data as string;
        const result = Papa.parse(text, { header: true, skipEmptyLines: true });
        parsedRows = result.data;
      } else {
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        parsedRows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
      }

      // Process and validate rows
      const validDesignations = ['MD', 'ED', 'VP', 'Professional'];
      let imported = 0;
      let skipped = 0;
      const errors: { row: number; reason: string }[] = [];
      const newEmployees: Employee[] = [...employees];
      const existingIds = new Set(newEmployees.map((e) => e.empId.toLowerCase()));

      parsedRows.forEach((row, idx) => {
        const rowNum = idx + 2; // header is row 1
        const rawEmpId = row['Employee ID'] || row['EmployeeID'] || row['Emp ID'] || row['empId'] || row['ID'];
        const rawName = row['Name'] || row['Employee Name'] || row['name'];
        const rawDesig = row['Designation'] || row['Role'] || row['designation'];
        const rawEmail = row['Email'] || row['email'];
        const rawActive = row['Active'] || row['Status'] || row['active'];

        if (!rawEmpId || !rawName) {
          skipped++;
          errors.push({ row: rowNum, reason: 'Missing required Employee ID or Name' });
          return;
        }

        const empIdStr = String(rawEmpId).trim();
        const nameStr = String(rawName).trim();
        let desigStr = String(rawDesig || 'Professional').trim();

        // Normalize designation
        if (desigStr.toUpperCase() === 'MANAGING DIRECTOR') desigStr = 'MD';
        else if (desigStr.toUpperCase() === 'EXECUTIVE DIRECTOR') desigStr = 'ED';
        else if (desigStr.toUpperCase() === 'VICE PRESIDENT') desigStr = 'VP';
        else if (desigStr.toUpperCase() === 'PROF' || desigStr.toUpperCase() === 'ENGINEER' || desigStr.toUpperCase() === 'ASSOCIATE') {
          desigStr = 'Professional';
        }

        if (!validDesignations.includes(desigStr)) {
          skipped++;
          errors.push({
            row: rowNum,
            reason: `Invalid designation "${desigStr}". Must be MD, ED, VP, or Professional.`
          });
          return;
        }

        if (existingIds.has(empIdStr.toLowerCase())) {
          skipped++;
          errors.push({ row: rowNum, reason: `Duplicate Employee ID "${empIdStr}" skipped.` });
          return;
        }

        const isActive =
          rawActive === undefined ||
          String(rawActive).toLowerCase() === 'true' ||
          String(rawActive).toLowerCase() === 'active' ||
          String(rawActive) === '1';

        existingIds.add(empIdStr.toLowerCase());
        newEmployees.push({
          id: `emp-imp-${Date.now()}-${idx}`,
          empId: empIdStr,
          name: nameStr,
          designation: desigStr as Designation,
          email: rawEmail ? String(rawEmail).trim() : undefined,
          active: isActive
        });
        imported++;
      });

      setEmployees(newEmployees);
      setImportSummary({ imported, skipped, errors });
      onMarkStale();
    };

    if (file.name.endsWith('.csv')) {
      reader.readAsText(file);
    } else {
      reader.readAsBinaryString(file);
    }
  };

  // Filtered List
  const filtered = employees.filter((emp) => {
    const matchesSearch =
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.empId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.designation.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;
    if (filterDesignation !== 'ALL' && emp.designation !== filterDesignation) return false;
    if (filterStatus === 'ACTIVE' && !emp.active) return false;
    if (filterStatus === 'INACTIVE' && emp.active) return false;

    return true;
  });

  return (
    <div className="space-y-3 mb-4">
      {/* Action Header Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-2.5 flex flex-wrap items-center justify-between gap-2.5 shadow-2xs">
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-blue-600" />
            <span>Employee Master Directory</span>
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Manage team members, designations, status, and planned leaves.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={handleDownloadTemplate}
            className="px-2.5 py-1 bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 rounded text-xs font-semibold flex items-center gap-1 shadow-2xs"
          >
            <Download className="w-3 h-3 text-slate-500" />
            <span>Template</span>
          </button>

          <button
            onClick={() => {
              setImportSummary(null);
              setIsImportModalOpen(true);
            }}
            className="px-2.5 py-1 bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 rounded text-xs font-semibold flex items-center gap-1 shadow-2xs"
          >
            <Upload className="w-3 h-3 text-slate-500" />
            <span>Import CSV/XLSX</span>
          </button>

          <button
            onClick={openAddModal}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold flex items-center gap-1 shadow-xs transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Member</span>
          </button>
        </div>
      </div>

      {/* Search & Bulk Operations Toolbar */}
      <div className="bg-white border border-slate-200 rounded-lg p-2.5 flex flex-wrap items-center justify-between gap-2.5 shadow-2xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[180px] max-w-sm">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, name, role..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <select
            value={filterDesignation}
            onChange={(e) => setFilterDesignation(e.target.value)}
            className="px-2 py-1 bg-slate-50 border border-slate-300 rounded text-xs text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Roles</option>
            <option value="MD">Managing Director (MD)</option>
            <option value="ED">Executive Director (ED)</option>
            <option value="VP">Vice President (VP)</option>
            <option value="Professional">Professional</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2 py-1 bg-slate-50 border border-slate-300 rounded text-xs text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Statuses ({employees.length})</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
          </select>
        </div>

        {selectedIds.size > 0 && (
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-500 font-medium font-mono">
              {selectedIds.size} sel
            </span>
            <button
              onClick={() => handleBulkToggleActive(true)}
              className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-xs font-semibold hover:bg-emerald-100"
            >
              Activate
            </button>
            <button
              onClick={() => handleBulkToggleActive(false)}
              className="px-2 py-0.5 bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold hover:bg-slate-200"
            >
              Deactivate
            </button>
            <button
              onClick={handleBulkDelete}
              className="px-2 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded text-xs font-semibold hover:bg-rose-100"
            >
              Delete
            </button>
          </div>
        )}
      </div>

      {/* Employee Master Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700 font-semibold text-[11px]">
                <th className="py-2 px-2.5 w-8 text-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.size > 0 && selectedIds.size === filtered.length}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedIds(new Set(filtered.map((emp) => emp.id)));
                      } else {
                        setSelectedIds(new Set());
                      }
                    }}
                    className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="py-2 px-2 w-10 text-center">#</th>
                <th className="py-2 px-2.5 w-20">Emp ID</th>
                <th className="py-2 px-2.5">Employee Name</th>
                <th className="py-2 px-2.5">Designation</th>
                <th className="py-2 px-2.5">Corporate Email</th>
                <th className="py-2 px-2.5 text-center">Leaves in Fortnight</th>
                <th className="py-2 px-2.5 text-center">Status</th>
                <th className="py-2 px-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {filtered.map((emp, index) => {
                const empLeaves = leaves.filter((l) => l.employeeId === emp.id);
                const leavesInPeriod = empLeaves.filter(
                  (l) => l.date >= period.startDate && l.date <= period.endDate && l.type !== 'TRV'
                ).length;
                const exceptionCount = empLeaves.filter((l) => l.isException).length;

                return (
                  <tr
                    key={emp.id}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      !emp.active ? 'bg-slate-50/50 opacity-60' : ''
                    }`}
                  >
                    <td className="py-1.5 px-2.5 text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(emp.id)}
                        onChange={(e) => {
                          const next = new Set(selectedIds);
                          if (e.target.checked) next.add(emp.id);
                          else next.delete(emp.id);
                          setSelectedIds(next);
                        }}
                        className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-blue-500"
                      />
                    </td>
                    <td className="py-1.5 px-2 text-center text-slate-400 font-mono text-[10px]">
                      {index + 1}
                    </td>
                    <td className="py-1.5 px-2.5 font-mono font-medium text-slate-700 text-[10px]">
                      {emp.empId}
                    </td>
                    <td className="py-1.5 px-2.5 font-semibold text-slate-900 text-[11px]">
                      {emp.name}
                    </td>
                    <td className="py-1.5 px-2.5">
                      <span
                        className={`inline-flex px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                          emp.designation === 'MD'
                            ? 'bg-purple-100 text-purple-800'
                            : emp.designation === 'ED'
                            ? 'bg-indigo-100 text-indigo-800'
                            : emp.designation === 'VP'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {emp.designation}
                      </span>
                    </td>
                    <td className="py-1.5 px-2.5 text-slate-500 truncate max-w-xs font-mono text-[10px]">
                      {emp.email || '-'}
                    </td>
                    <td className="py-1.5 px-2.5 text-center">
                      <button
                        onClick={() => onOpenLeaveCalendar(emp.id)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition-colors"
                        title="Click to view/edit leave dates in calendar"
                      >
                        <Calendar className="w-2.5 h-2.5 text-amber-600" />
                        <span className="font-mono">{leavesInPeriod}d</span>
                        {exceptionCount > 0 && (
                          <span className="text-[9px] text-rose-600 font-bold font-mono">
                            ({exceptionCount} Ex)
                          </span>
                        )}
                      </button>
                    </td>
                    <td className="py-1.5 px-2.5 text-center">
                      <button
                        onClick={() => {
                          setEmployees(
                            employees.map((e) =>
                              e.id === emp.id ? { ...e, active: !e.active } : e
                            )
                          );
                          onMarkStale();
                        }}
                        className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          emp.active
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {emp.active ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="py-1.5 px-2.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEditModal(emp)}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-slate-100 transition-colors"
                          title="Edit employee"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(emp.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors"
                          title="Delete employee"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Employee Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                {editingEmployee ? 'Edit Employee Profile' : 'Add New Joiner'}
              </h4>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-xs"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-2 bg-rose-50 border border-rose-200 rounded text-xs text-rose-800 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                  Employee ID *
                </label>
                <input
                  type="text"
                  placeholder="e.g. E1026"
                  value={formEmpId}
                  onChange={(e) => setFormEmpId(e.target.value)}
                  className="w-full px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Siddhartha Roy"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                  Designation *
                </label>
                <select
                  value={formDesignation}
                  onChange={(e) => setFormDesignation(e.target.value as Designation)}
                  className="w-full px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs"
                >
                  <option value="MD">Managing Director (MD) - Fixed Seat</option>
                  <option value="ED">Executive Director (ED) - Fixed Seat</option>
                  <option value="VP">Vice President (VP) - Fixed Seat</option>
                  <option value="Professional">Professional - Hot Desk Pool</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                  Corporate Email (Optional)
                </label>
                <input
                  type="email"
                  placeholder="siddhartha.roy@hybridcorp.com"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="w-full px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs"
                />
              </div>

              <div className="pt-0.5">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formActive}
                    onChange={(e) => setFormActive(e.target.checked)}
                    className="w-3.5 h-3.5 text-blue-600 rounded"
                  />
                  <span className="text-xs font-medium text-slate-700">
                    Active on Current Roster
                  </span>
                </label>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="flex-1 py-1.5 px-3 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEmployee}
                className="flex-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold"
              >
                {editingEmployee ? 'Save Changes' : 'Add Employee'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-sm w-full p-4 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Confirm Employee Deletion / Attrition
            </h4>
            <p className="text-xs text-slate-600">
              Choose to soft-delete (mark inactive to preserve history) or permanently delete.
            </p>
            <div className="flex flex-col gap-1.5 pt-1">
              <button
                onClick={() => handleDelete(deleteConfirmId, true)}
                className="w-full py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-xs font-semibold"
              >
                Soft-Delete (Mark Inactive)
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId, false)}
                className="w-full py-1.5 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded text-xs font-bold"
              >
                Permanently Delete Record
              </button>
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="w-full py-1 text-xs text-slate-500 hover:text-slate-700"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Upload className="w-3.5 h-3.5 text-blue-600" />
                <span>Import Employees (CSV / XLSX)</span>
              </h4>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2.5">
              <p className="text-xs text-slate-600">
                Upload a CSV or Excel spreadsheet containing: <strong>Employee ID</strong>, <strong>Name</strong>, <strong>Designation</strong> (MD/ED/VP/Professional), and optional <strong>Email</strong>.
              </p>

              <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                <FileSpreadsheet className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                <label className="cursor-pointer">
                  <span className="px-3 py-1 bg-slate-800 text-white rounded text-xs font-semibold hover:bg-slate-700 inline-block">
                    Select CSV or XLSX File
                  </span>
                  <input
                    type="file"
                    accept=".csv, .xlsx, .xls"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-[10px] text-slate-400 mt-1">
                  Supports comma-delimited CSV and Excel files.
                </p>
              </div>

              {/* Import Summary Results */}
              {importSummary && (
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded space-y-1.5 text-xs">
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-emerald-700">
                      ✓ Imported: {importSummary.imported} rows
                    </span>
                    <span className="text-slate-500">
                      Skipped: {importSummary.skipped} rows
                    </span>
                  </div>

                  {importSummary.errors.length > 0 && (
                    <div className="max-h-24 overflow-y-auto space-y-0.5 pt-1 border-t border-slate-200">
                      {importSummary.errors.map((err, i) => (
                        <div key={i} className="text-[10px] text-rose-700">
                          Row {err.row}: {err.reason}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded text-xs font-bold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
