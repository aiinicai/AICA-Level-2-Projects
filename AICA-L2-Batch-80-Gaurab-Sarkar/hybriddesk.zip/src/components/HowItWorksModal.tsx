import React from 'react';
import { HelpCircle, BookOpen, Calculator, CheckCircle2, Shield, X } from 'lucide-react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden">
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                How It Works — Deterministic Roster & Seating Engine
              </h3>
              <p className="text-[10px] text-slate-400">
                Mathematical formulas, compliance policies, and seating optimization pipeline.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3.5 overflow-y-auto flex-1 space-y-2.5 text-xs text-slate-700 leading-relaxed">
          {/* Section 1 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">1</span>
              <span>Working Days & NSE Exchange Holidays</span>
            </h4>
            <p className="text-[11px] text-slate-600">
              A roster window spans 14 calendar days (Week 1 Mon to Week 2 Sun). Active working days <code>|D|</code> comprise Monday through Friday, strictly excluding Saturdays, Sundays, and public trading holidays confirmed in the NSE Holiday Master.
            </p>
          </div>

          {/* Section 2 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">2</span>
              <span>Individual Attendance Requirements (R_e)</span>
            </h4>
            <p className="text-[11px] text-slate-600">
              Let <code>L_e</code> = approved leave days of employee <code>e</code> in the fortnight. Available days <code>A_e = |D| - L_e</code>.
            </p>
            <div className="p-2 bg-white rounded border border-slate-200 font-mono text-[10px] space-y-0.5">
              <div><strong>Basis "Net" (Default):</strong> R_e = ceil( P_d × A_e )</div>
              <div><strong>Basis "Gross":</strong> R_e = min( ceil(P_d × |D|), A_e )</div>
            </div>
            <p className="text-[10px] text-slate-500">
              * Employees on leave for all working days (<code>A_e = 0</code>) are marked <strong>Not Applicable (N/A)</strong> and excluded from seat demand.
            </p>
          </div>

          {/* Section 3 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">3</span>
              <span>Capacity Feasibility & Deficit Formula</span>
            </h4>
            <div className="p-2 bg-white rounded border border-slate-200 font-mono text-[10px] space-y-0.5">
              <div>Demand_seatdays = Σ R_e (over active employees)</div>
              <div>Supply_seatdays = S × |D|</div>
              <div>Deficit_seatdays = max(0, Demand_seatdays - Supply_seatdays)</div>
              <div>Seats_short = ceil( Deficit_seatdays / |D| )</div>
              <div>Min_seats_for_full_compliance = ceil( Demand_seatdays / |D| )</div>
            </div>
            <p className="text-[11px] text-slate-600">
              If a deficit exists, the engine generates the optimal best-effort roster and displays a prominent warning callout with exact shortfall metrics.
            </p>
          </div>

          {/* Section 4 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">4</span>
              <span>Fixed-Seat Hierarchy & Backfill Mechanism</span>
            </h4>
            <p className="text-[11px] text-slate-600">
              Managing Directors (MD), Executive Directors (ED), and Vice Presidents (VP) are permanently assigned the lowest physical seat numbers (<code>Seat-01 .. Seat-k</code>) in hierarchy order.
            </p>
            <p className="text-[11px] text-slate-600">
              On any working day that a senior leader is rostered for WFH or approved leave, their fixed desk is automatically released into the hot-desk pool and backfilled by a Professional.
            </p>
          </div>

          {/* Section 5 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">5</span>
              <span>Hot-Desk Allocation via Urgency Score</span>
            </h4>
            <p className="text-[11px] text-slate-600">
              For each working day, candidate Professionals are ranked using their dynamic urgency score:
            </p>
            <div className="p-2 bg-white rounded border border-slate-200 font-mono text-[10px]">
              urgency = (R_e - allocated_e) / (remaining_available_days_of_e)
            </div>
            <p className="text-[11px] text-slate-600">
              Deterministic tie-breakers: (1) Fewer days allocated so far, (2) Longer current WFH streak, (3) Alphabetical order by name.
            </p>
          </div>

          {/* Section 6 */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[9px] font-mono">6</span>
              <span>Utilisation Top-Up & Fairness</span>
            </h4>
            <p className="text-[11px] text-slate-600">
              Empty workstations after satisfying minimums are allocated to available Professionals below the team average, ensuring physical seat inventory is utilized near 100% without exceeding capacity <code>S</code>.
            </p>
          </div>
        </div>

        <div className="p-2.5 px-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-bold"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
