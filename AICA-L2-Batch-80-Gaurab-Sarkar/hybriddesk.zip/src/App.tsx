/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  AllocationResult,
  Employee,
  Holiday,
  LeaveRecord,
  PolicySettings,
  RosterPeriodConfig,
  SeatBlock
} from './types';
import {
  DEFAULT_POLICY_SETTINGS,
  DEMO_EMPLOYEES,
  generateDemoLeaves,
  getDefaultRosterPeriod
} from './logic/demoData';
import { getInitialHolidays } from './logic/nseHolidays';
import { allocateRoster, calculateWorkingDays } from './logic/allocator';
import { Navbar } from './components/Navbar';
import { SetupStepper } from './components/SetupStepper';
import { KpiSummaryCards } from './components/KpiSummaryCards';
import { RosterGrid } from './components/RosterGrid';
import { DailyOccupancyTable } from './components/DailyOccupancyTable';
import { ComplianceTable } from './components/ComplianceTable';
import { SeatMap } from './components/SeatMap';
import { EmployeeMasterView } from './components/EmployeeMasterView';
import { LeaveCalendarModal } from './components/LeaveCalendarModal';
import { HolidayMasterModal } from './components/HolidayMasterModal';
import { HowItWorksModal } from './components/HowItWorksModal';
import { AcceptanceTestsModal } from './components/AcceptanceTestsModal';
import { WhatIfSimulatorModal } from './components/WhatIfSimulatorModal';
import { EmailRosterModal } from './components/EmailRosterModal';

const STORAGE_KEYS = {
  SEAT_COUNT: 'hybriddesk_seat_count',
  EMPLOYEES: 'hybriddesk_employees',
  LEAVES: 'hybriddesk_leaves',
  HOLIDAYS: 'hybriddesk_holidays',
  POLICY: 'hybriddesk_policy',
  PERIOD: 'hybriddesk_period',
  SEAT_BLOCKS: 'hybriddesk_seat_blocks',
  RESULT: 'hybriddesk_result'
};

export default function App() {
  // State from LocalStorage or Defaults
  const [seatCount, setSeatCount] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SEAT_COUNT);
    return saved ? parseInt(saved) : 20;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
    return saved ? JSON.parse(saved) : DEMO_EMPLOYEES;
  });

  const [period, setPeriod] = useState<RosterPeriodConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PERIOD);
    return saved ? JSON.parse(saved) : getDefaultRosterPeriod();
  });

  const [leaves, setLeaves] = useState<LeaveRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LEAVES);
    return saved ? JSON.parse(saved) : generateDemoLeaves(getDefaultRosterPeriod());
  });

  const [holidays, setHolidays] = useState<Holiday[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HOLIDAYS);
    return saved ? JSON.parse(saved) : getInitialHolidays();
  });

  const [policy, setPolicy] = useState<PolicySettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.POLICY);
    return saved ? JSON.parse(saved) : DEFAULT_POLICY_SETTINGS;
  });

  const [seatBlocks, setSeatBlocks] = useState<SeatBlock[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SEAT_BLOCKS);
    return saved ? JSON.parse(saved) : [];
  });

  const [allocationResult, setAllocationResult] = useState<AllocationResult | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RESULT);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  // Active Main View Tab
  const [activeTab, setActiveTab] = useState<'roster' | 'employees' | 'calendar' | 'holidays' | 'map'>('roster');

  // Modal Visibility States
  const [isLeaveCalendarOpen, setIsLeaveCalendarOpen] = useState(false);
  const [calendarEmpId, setCalendarEmpId] = useState<string | undefined>(undefined);
  const [isHolidayMasterOpen, setIsHolidayMasterOpen] = useState(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const [isAcceptanceTestsOpen, setIsAcceptanceTestsOpen] = useState(false);
  const [isWhatIfOpen, setIsWhatIfOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

  // Sub-view in Roster Tab (Roster Grid vs Occupancy vs Compliance)
  const [rosterSubView, setRosterSubView] = useState<'grid' | 'occupancy' | 'compliance'>('grid');

  // Working days count preview
  const workingDaysInfo = useMemo(() => {
    return calculateWorkingDays(period, holidays);
  }, [period, holidays]);

  // Persist State to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SEAT_COUNT, seatCount.toString());
  }, [seatCount]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PERIOD, JSON.stringify(period));
  }, [period]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LEAVES, JSON.stringify(leaves));
  }, [leaves]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HOLIDAYS, JSON.stringify(holidays));
  }, [holidays]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.POLICY, JSON.stringify(policy));
  }, [policy]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SEAT_BLOCKS, JSON.stringify(seatBlocks));
  }, [seatBlocks]);

  useEffect(() => {
    if (allocationResult) {
      localStorage.setItem(STORAGE_KEYS.RESULT, JSON.stringify(allocationResult));
    }
  }, [allocationResult]);

  // Execute Allocation
  const handleCalculate = () => {
    const res = allocateRoster({
      seatCount,
      employees,
      leaves,
      holidays,
      policy,
      period,
      seatBlocks
    });
    setAllocationResult(res);
    setActiveTab('roster');
  };

  // Apply Simulation Scenario
  const handleApplySimulation = (newSeatCount: number, newPolicy: PolicySettings) => {
    setSeatCount(newSeatCount);
    setPolicy(newPolicy);
    const res = allocateRoster({
      seatCount: newSeatCount,
      employees,
      leaves,
      holidays,
      policy: newPolicy,
      period,
      seatBlocks
    });
    setAllocationResult(res);
    setActiveTab('roster');
  };

  // Mark Roster Stale on data change
  const handleMarkStale = () => {
    if (allocationResult && !allocationResult.isStale) {
      setAllocationResult({ ...allocationResult, isStale: true });
    }
  };

  // Auto-calculate initial roster if not present
  useEffect(() => {
    if (!allocationResult) {
      const initial = allocateRoster({
        seatCount,
        employees,
        leaves,
        holidays,
        policy,
        period,
        seatBlocks
      });
      setAllocationResult(initial);
    }
  }, []);

  // Demo Team Loader
  const handleLoadDemo = (infeasible = false) => {
    const demoPeriod = getDefaultRosterPeriod();
    const demoLeaves = generateDemoLeaves(demoPeriod);
    const demoSeats = infeasible ? 10 : 20; // 10 seats will cause a dramatic deficit for 25 people!

    setEmployees(DEMO_EMPLOYEES);
    setPeriod(demoPeriod);
    setLeaves(demoLeaves);
    setSeatCount(demoSeats);
    setPolicy(DEFAULT_POLICY_SETTINGS);
    setSeatBlocks([]);

    const res = allocateRoster({
      seatCount: demoSeats,
      employees: DEMO_EMPLOYEES,
      leaves: demoLeaves,
      holidays: getInitialHolidays(),
      policy: DEFAULT_POLICY_SETTINGS,
      period: demoPeriod,
      seatBlocks: []
    });

    setAllocationResult(res);
    setActiveTab('roster');
  };

  const handleOpenLeaveCalendar = (empId?: string) => {
    setCalendarEmpId(empId);
    setIsLeaveCalendarOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col">
      {/* 3-Zone Sticky Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'holidays') {
            setIsHolidayMasterOpen(true);
          } else if (tab === 'calendar') {
            setIsLeaveCalendarOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
        onOpenTests={() => setIsAcceptanceTestsOpen(true)}
        onOpenWhatIf={() => setIsWhatIfOpen(true)}
        onOpenEmailRoster={() => setIsEmailModalOpen(true)}
        onLoadDemo={handleLoadDemo}
        isStale={allocationResult?.isStale || false}
        hasCalculated={Boolean(allocationResult)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Guided 5-Step Stepper & Configuration Wizard */}
        <SetupStepper
          seatCount={seatCount}
          setSeatCount={(val) => {
            setSeatCount(val);
            handleMarkStale();
          }}
          employees={employees}
          leaves={leaves}
          policy={policy}
          setPolicy={(pol) => {
            setPolicy(pol);
            handleMarkStale();
          }}
          period={period}
          setPeriod={(per) => {
            setPeriod(per);
            handleMarkStale();
          }}
          seatBlocks={seatBlocks}
          setSeatBlocks={(blocks) => {
            setSeatBlocks(blocks);
            handleMarkStale();
          }}
          onCalculate={handleCalculate}
          onOpenEmployeeMaster={() => setActiveTab('employees')}
          onOpenLeaveCalendar={handleOpenLeaveCalendar}
          workingDaysCount={workingDaysInfo.workingDays.length}
        />

        {/* Dynamic Main View */}
        {activeTab === 'roster' && allocationResult && (
          <div>
            {/* KPI Cards & Deficit Callouts */}
            <KpiSummaryCards
              result={allocationResult}
              employees={employees}
              seatCount={seatCount}
              onRecalculate={handleCalculate}
              onOpenWhatIf={() => setIsWhatIfOpen(true)}
            />

            {/* Sub-view Switcher Tabs */}
            <div className="flex items-center gap-2 mb-4">
              <button
                onClick={() => setRosterSubView('grid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  rosterSubView === 'grid'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                Fortnightly Roster Grid
              </button>
              <button
                onClick={() => setRosterSubView('occupancy')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  rosterSubView === 'occupancy'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                Daily Occupancy & Utilisation
              </button>
              <button
                onClick={() => setRosterSubView('compliance')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  rosterSubView === 'compliance'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                Employee Compliance Audit ({allocationResult.fullyCompliantCount}/{allocationResult.employeeSummaries.length - allocationResult.notApplicableCount} Met)
              </button>
            </div>

            {/* Sub-view Content */}
            {rosterSubView === 'grid' && (
              <RosterGrid
                result={allocationResult}
                setResult={setAllocationResult}
                employees={employees}
                period={period}
                policy={policy}
                holidays={holidays}
                seatCount={seatCount}
                seatBlocks={seatBlocks}
                onResetToAuto={handleCalculate}
                onOpenEmailRoster={() => setIsEmailModalOpen(true)}
                onOpenWhatIf={() => setIsWhatIfOpen(true)}
              />
            )}

            {rosterSubView === 'occupancy' && (
              <DailyOccupancyTable
                occupancies={allocationResult.dailyOccupancies}
                totalSeats={seatCount}
              />
            )}

            {rosterSubView === 'compliance' && (
              <ComplianceTable summaries={allocationResult.employeeSummaries} />
            )}
          </div>
        )}

        {/* Seat Map View */}
        {activeTab === 'map' && allocationResult && (
          <SeatMap
            result={allocationResult}
            employees={employees}
            seatCount={seatCount}
            seatBlocks={seatBlocks}
          />
        )}

        {/* Employee Master View */}
        {activeTab === 'employees' && (
          <EmployeeMasterView
            employees={employees}
            setEmployees={setEmployees}
            leaves={leaves}
            period={period}
            onOpenLeaveCalendar={handleOpenLeaveCalendar}
            onMarkStale={handleMarkStale}
          />
        )}
      </main>

      {/* Global Modals */}
      <LeaveCalendarModal
        isOpen={isLeaveCalendarOpen}
        onClose={() => setIsLeaveCalendarOpen(false)}
        employees={employees}
        leaves={leaves}
        setLeaves={setLeaves}
        holidays={holidays}
        period={period}
        initialEmployeeId={calendarEmpId}
        onMarkStale={handleMarkStale}
      />

      <HolidayMasterModal
        isOpen={isHolidayMasterOpen}
        onClose={() => setIsHolidayMasterOpen(false)}
        holidays={holidays}
        setHolidays={setHolidays}
        onMarkStale={handleMarkStale}
      />

      <HowItWorksModal
        isOpen={isHowItWorksOpen}
        onClose={() => setIsHowItWorksOpen(false)}
      />

      <AcceptanceTestsModal
        isOpen={isAcceptanceTestsOpen}
        onClose={() => setIsAcceptanceTestsOpen(false)}
        result={allocationResult}
        seatCount={seatCount}
        employees={employees}
        leaves={leaves}
        holidays={holidays}
        policy={policy}
        period={period}
      />

      {/* 'What-If' Simulator Modal */}
      <WhatIfSimulatorModal
        isOpen={isWhatIfOpen}
        onClose={() => setIsWhatIfOpen(false)}
        currentSeatCount={seatCount}
        currentPolicy={policy}
        currentResult={allocationResult}
        employees={employees}
        leaves={leaves}
        holidays={holidays}
        period={period}
        seatBlocks={seatBlocks}
        onApplyScenario={handleApplySimulation}
      />

      {/* Email-ready HTML Roster Modal */}
      <EmailRosterModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        result={allocationResult}
        employees={employees}
        period={period}
        policy={policy}
        holidays={holidays}
        seatCount={seatCount}
      />
    </div>
  );
}
