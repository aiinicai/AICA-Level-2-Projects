export type Designation = 'MD' | 'ED' | 'VP' | 'Professional';

export type LeaveType =
  | 'PL'  // Planned Leave
  | 'SL'  // Sick Leave
  | 'ML'  // Maternity Leave
  | 'PTL' // Paternity Leave
  | 'EL'  // Emergency Leave
  | 'CO'  // Comp-Off
  | 'TRV'; // Work-related Travel (WFO-exempt)

export interface LeaveRecord {
  id: string;
  employeeId: string;
  date: string; // YYYY-MM-DD
  type: LeaveType;
  note?: string;
  isException?: boolean;
}

export interface Employee {
  id: string;
  empId: string;
  name: string;
  designation: Designation;
  email?: string;
  active: boolean;
  notes?: string;
  assignedFixedSeat?: number; // Pre-calculated or allocated fixed seat number
}

export interface Holiday {
  id: string;
  date: string; // YYYY-MM-DD
  day: string;  // e.g. "Thursday"
  name: string;
  source: 'NSE' | 'Custom';
  isWeekend?: boolean;
}

export interface PolicySettings {
  compliancePercentages: Record<Designation, number>;
  complianceBasis: 'net' | 'gross';
  roundingRule: 'ceil' | 'nearest';
  teamAnchorDay?: number; // 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, or undefined
  maxConsecutiveWFH: number;
}

export interface SeatBlock {
  id: string;
  seatNumber: number;
  reason: string;
  startDate?: string;
  endDate?: string;
}

export interface RosterPeriodConfig {
  startDate: string; // YYYY-MM-DD (Fortnight start, preferably Monday)
  endDate: string;   // YYYY-MM-DD (Fortnight end, Sunday 13 days later)
}

export type StatusCode = 'O' | 'W' | 'L' | 'H' | 'X';

export interface DayAllocation {
  status: StatusCode;
  seatNumber?: number;
  leaveType?: LeaveType;
  isFixedSeat?: boolean;
  isBackfilled?: boolean;
  isManualOverride?: boolean;
  overridePreviousStatus?: StatusCode;
  note?: string;
}

export interface EmployeeComplianceSummary {
  employeeId: string;
  empId: string;
  name: string;
  designation: Designation;
  requiredPct: number;
  totalWorkingDays: number;
  leaveDaysInPeriod: number;
  availableWorkingDays: number;
  requiredOfficeDays: number;
  allocatedOfficeDays: number;
  achievedPct: number;
  isCompliant: boolean;
  shortfallDays: number;
  isFullyOnLeave: boolean;
  statusText: 'Compliant' | 'Shortfall' | 'Not Applicable';
}

export interface DailyOccupancy {
  date: string;
  dayName: string;
  seatsAvailable: number;
  seniorsPresent: number;
  professionalsPresent: number;
  totalOccupied: number;
  vacantSeats: number;
  utilisationPct: number;
  isOverCapacity: boolean;
  blockedSeatsCount: number;
}

export interface SeatDeficitSummary {
  demandSeatDays: number;
  supplySeatDays: number;
  deficitSeatDays: number;
  seatsShort: number;
  minSeatsForFullCompliance: number;
  spareSeatDays: number;
  spareSeatsEquivalent: number;
  hasDeficit: boolean;
  affectedEmployeesCount: number;
}

export interface AllocationResult {
  workingDays: string[]; // YYYY-MM-DD list of the working days in period (typically 10)
  grid: Record<string, Record<string, DayAllocation>>; // employeeId -> date -> DayAllocation
  employeeSummaries: EmployeeComplianceSummary[];
  dailyOccupancies: DailyOccupancy[];
  deficit: SeatDeficitSummary;
  avgDailyUtilisationPct: number;
  fullyCompliantCount: number;
  nonCompliantCount: number;
  notApplicableCount: number;
  fixedSeatAssignments: Record<string, number>; // employeeId -> permanent seatNumber
  generatedAt: string;
  isStale: boolean;
  manualOverridesCount: number;
}

export interface AcceptanceTestResult {
  id: string;
  name: string;
  passed: boolean;
  message: string;
  details?: string;
}
