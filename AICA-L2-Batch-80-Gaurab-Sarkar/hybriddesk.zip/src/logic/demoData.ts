import { Designation, Employee, LeaveRecord, PolicySettings, RosterPeriodConfig } from '../types';
import { addDays, format, nextMonday, startOfWeek } from 'date-fns';

export function getDefaultRosterPeriod(): RosterPeriodConfig {
  const now = new Date();
  const nextMon = nextMonday(now);
  const endSun = addDays(nextMon, 13);
  return {
    startDate: format(nextMon, 'yyyy-MM-dd'),
    endDate: format(endSun, 'yyyy-MM-dd')
  };
}

export const DEFAULT_POLICY_SETTINGS: PolicySettings = {
  compliancePercentages: {
    MD: 80,
    ED: 80,
    VP: 70,
    Professional: 60
  },
  complianceBasis: 'net',
  roundingRule: 'ceil',
  teamAnchorDay: 3, // Wednesday anchor preference
  maxConsecutiveWFH: 3
};

export const DEMO_EMPLOYEES: Employee[] = [
  // 1 MD
  { id: 'emp-1', empId: 'E1001', name: 'Rajesh Mehta', designation: 'MD', email: 'rajesh.mehta@hybridcorp.com', active: true },
  // 1 ED
  { id: 'emp-2', empId: 'E1002', name: 'Ananya Sharma', designation: 'ED', email: 'ananya.sharma@hybridcorp.com', active: true },
  // 4 VPs
  { id: 'emp-3', empId: 'E1003', name: 'Vikram Sengupta', designation: 'VP', email: 'vikram.sengupta@hybridcorp.com', active: true },
  { id: 'emp-4', empId: 'E1004', name: 'Pooja Iyer', designation: 'VP', email: 'pooja.iyer@hybridcorp.com', active: true },
  { id: 'emp-5', empId: 'E1005', name: 'Rohan Deshmukh', designation: 'VP', email: 'rohan.deshmukh@hybridcorp.com', active: true },
  { id: 'emp-6', empId: 'E1006', name: 'Kavita Nair', designation: 'VP', email: 'kavita.nair@hybridcorp.com', active: true },
  // 19 Professionals
  { id: 'emp-7', empId: 'E1007', name: 'Amitabh Joshi', designation: 'Professional', email: 'amitabh.joshi@hybridcorp.com', active: true },
  { id: 'emp-8', empId: 'E1008', name: 'Bhavna Kulkarni', designation: 'Professional', email: 'bhavna.k@hybridcorp.com', active: true },
  { id: 'emp-9', empId: 'E1009', name: 'Chetan Patel', designation: 'Professional', email: 'chetan.patel@hybridcorp.com', active: true },
  { id: 'emp-10', empId: 'E1010', name: 'Deepika Rao', designation: 'Professional', email: 'deepika.rao@hybridcorp.com', active: true },
  { id: 'emp-11', empId: 'E1011', name: 'Eshaan Verma', designation: 'Professional', email: 'eshaan.v@hybridcorp.com', active: true },
  { id: 'emp-12', empId: 'E1012', name: 'Farhan Qureshi', designation: 'Professional', email: 'farhan.q@hybridcorp.com', active: true },
  { id: 'emp-13', empId: 'E1013', name: 'Gayatri Bhat', designation: 'Professional', email: 'gayatri.bhat@hybridcorp.com', active: true },
  { id: 'emp-14', empId: 'E1014', name: 'Harish Menon', designation: 'Professional', email: 'harish.menon@hybridcorp.com', active: true },
  { id: 'emp-15', empId: 'E1015', name: 'Ishita Banerjee', designation: 'Professional', email: 'ishita.b@hybridcorp.com', active: true },
  { id: 'emp-16', empId: 'E1016', name: 'Jatin Chawla', designation: 'Professional', email: 'jatin.chawla@hybridcorp.com', active: true },
  { id: 'emp-17', empId: 'E1017', name: 'Kunal Malhotra', designation: 'Professional', email: 'kunal.m@hybridcorp.com', active: true },
  { id: 'emp-18', empId: 'E1018', name: 'Lavanya Reddy', designation: 'Professional', email: 'lavanya.r@hybridcorp.com', active: true },
  { id: 'emp-19', empId: 'E1019', name: 'Manish Agarwal', designation: 'Professional', email: 'manish.a@hybridcorp.com', active: true },
  { id: 'emp-20', empId: 'E1020', name: 'Neha Singhania', designation: 'Professional', email: 'neha.s@hybridcorp.com', active: true },
  { id: 'emp-21', empId: 'E1021', name: 'Omkar Gokhale', designation: 'Professional', email: 'omkar.g@hybridcorp.com', active: true },
  { id: 'emp-22', empId: 'E1022', name: 'Prachi Kapoor', designation: 'Professional', email: 'prachi.k@hybridcorp.com', active: true },
  { id: 'emp-23', empId: 'E1023', name: 'Rahul Nambiar', designation: 'Professional', email: 'rahul.n@hybridcorp.com', active: true },
  { id: 'emp-24', empId: 'E1024', name: 'Sneha Venkatesh', designation: 'Professional', email: 'sneha.v@hybridcorp.com', active: true },
  { id: 'emp-25', empId: 'E1025', name: 'Tanmay Saxena', designation: 'Professional', email: 'tanmay.s@hybridcorp.com', active: true }
];

export function generateDemoLeaves(period: RosterPeriodConfig): LeaveRecord[] {
  const start = parseISODate(period.startDate);
  const leaves: LeaveRecord[] = [];

  // Helper to format date offset from start
  const getOffsetDate = (days: number) => format(addDays(start, days), 'yyyy-MM-dd');

  // Rajesh (MD): Planned Leave on Day 4 (Thu)
  leaves.push({
    id: 'leave-1',
    employeeId: 'emp-1',
    date: getOffsetDate(3),
    type: 'PL',
    note: 'Board Review Prep'
  });

  // Pooja Iyer (VP): Sick Leave on Day 2 (Tue)
  leaves.push({
    id: 'leave-2',
    employeeId: 'emp-4',
    date: getOffsetDate(1),
    type: 'SL',
    note: 'Viral fever',
    isException: true
  });

  // Deepika Rao (Professional): Planned Leave Day 7 & 8 (Tue-Wed week 2)
  leaves.push({
    id: 'leave-3',
    employeeId: 'emp-10',
    date: getOffsetDate(8),
    type: 'PL',
    note: 'Family Function'
  });
  leaves.push({
    id: 'leave-4',
    employeeId: 'emp-10',
    date: getOffsetDate(9),
    type: 'PL',
    note: 'Family Function'
  });

  // Farhan Qureshi (Professional): Work Travel Day 3 (Wed week 1) - WFO exempt
  leaves.push({
    id: 'leave-5',
    employeeId: 'emp-12',
    date: getOffsetDate(2),
    type: 'TRV',
    note: 'Client meeting in Bangalore'
  });

  // Kunal Malhotra (Professional): Comp-Off Day 11 (Thu week 2)
  leaves.push({
    id: 'leave-6',
    employeeId: 'emp-17',
    date: getOffsetDate(10),
    type: 'CO',
    note: 'Weekend deployment compensation'
  });

  // Sneha Venkatesh (Professional): Long Maternity Leave entire period (To test N/A handling)
  for (let i = 0; i < 14; i++) {
    leaves.push({
      id: `leave-sneha-${i}`,
      employeeId: 'emp-24',
      date: getOffsetDate(i),
      type: 'ML',
      note: 'Maternity Leave',
      isException: true
    });
  }

  return leaves;
}

function parseISODate(s: string) {
  const parts = s.split('-');
  return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
}
