import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { format, parseISO } from 'date-fns';
import {
  AllocationResult,
  Employee,
  Holiday,
  PolicySettings,
  RosterPeriodConfig
} from '../types';

export function exportRosterPDF(params: {
  result: AllocationResult;
  employees: Employee[];
  period: RosterPeriodConfig;
  policy: PolicySettings;
  holidays: Holiday[];
  seatCount: number;
  teamName?: string;
}) {
  const {
    result,
    employees,
    period,
    policy,
    holidays,
    seatCount,
    teamName = 'Technology & Quant Operations'
  } = params;

  // Create A4 Landscape PDF
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  const startFormatted = format(parseISO(period.startDate), 'dd-MMM-yyyy');
  const endFormatted = format(parseISO(period.endDate), 'dd-MMM-yyyy');
  const genFormatted = format(new Date(), 'dd-MMM-yyyy HH:mm:ss');

  // Helper for footer on every page
  const addFooter = (pageNum: number, totalPages: number) => {
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.setFont('helvetica', 'normal');
    const footerText = 'Confidential — Internal Use Only';
    const pageText = `Page ${pageNum} of ${totalPages}`;
    doc.text(footerText, margin, pageHeight - 8);
    doc.text(pageText, pageWidth - margin - doc.getTextWidth(pageText), pageHeight - 8);
  };

  // Helper for page headers
  const addHeader = (title: string, subtitle?: string) => {
    doc.setFillColor(30, 41, 59); // Slate 800
    doc.rect(margin, margin, pageWidth - margin * 2, 14, 'F');
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('HYBRIDDESK — ROSTER & SEAT ALLOCATION MANAGEMENT', margin + 4, margin + 6);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Period: ${startFormatted} to ${endFormatted} | Team: ${teamName}`, margin + 4, margin + 11);

    if (subtitle) {
      doc.setFontSize(13);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text(title, margin, margin + 22);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(subtitle, margin, margin + 27);
    }
  };

  // ==========================================
  // PAGE 1: COVER & EXECUTIVE SUMMARY
  // ==========================================
  doc.setFillColor(15, 23, 42); // Slate 900
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('HybridDesk — Fortnightly Roster & Seat Allocation Report', margin, 14);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  doc.text(`Team: ${teamName}   |   Roster Window: ${startFormatted} to ${endFormatted}   |   Generated: ${genFormatted}`, margin, 22);

  let curY = 36;

  // KPI Summary Cards (Grid)
  const activeCount = employees.filter((e) => e.active).length;
  const ratioPct = Math.round((seatCount / (activeCount || 1)) * 100);

  const kpiData = [
    { label: 'Active Headcount', value: `${activeCount}` },
    { label: 'Seat Inventory', value: `${seatCount}` },
    { label: 'Seat-to-Headcount', value: `${ratioPct}%` },
    { label: 'Working Days', value: `${result.workingDays.length}` },
    { label: 'Avg Utilisation', value: `${result.avgDailyUtilisationPct}%` },
    { label: 'Compliance Status', value: `${result.fullyCompliantCount}/${result.employeeSummaries.length - result.notApplicableCount} Met` }
  ];

  const cardWidth = (pageWidth - margin * 2 - 25) / 6;
  kpiData.forEach((kpi, idx) => {
    const x = margin + idx * (cardWidth + 5);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(x, curY, cardWidth, 18, 2, 2, 'FD');

    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text(kpi.label.toUpperCase(), x + 3, curY + 6);

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(kpi.value, x + 3, curY + 14);
  });

  curY += 26;

  // Prominent Deficit Callout (If applicable)
  if (result.deficit.hasDeficit) {
    doc.setFillColor(254, 242, 242); // Red-50
    doc.setDrawColor(239, 68, 68); // Red-500
    doc.setLineWidth(0.6);
    doc.roundedRect(margin, curY, pageWidth - margin * 2, 24, 2, 2, 'FD');

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(185, 28, 28); // Red-700
    doc.text(`SEAT DEFICIT WARNING: The team is short by ${result.deficit.seatsShort} seat(s)`, margin + 5, curY + 7);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(127, 29, 29);
    const line1 = `Required: ${result.deficit.demandSeatDays} seat-days  |  Available: ${result.deficit.supplySeatDays} seat-days  |  Shortfall: ${result.deficit.deficitSeatDays} seat-days.`;
    const line2 = `${result.nonCompliantCount} employee(s) cannot meet their minimum WFO requirement due to mathematical capacity limitation.`;
    const line3 = `Seats required to achieve 100% full compliance = ${result.deficit.minSeatsForFullCompliance} seats.`;
    doc.text(line1, margin + 5, curY + 13);
    doc.text(line2, margin + 5, curY + 18);
    doc.text(line3, margin + 5, curY + 23);

    curY += 30;
  } else {
    doc.setFillColor(240, 253, 244); // Green-50
    doc.setDrawColor(34, 197, 94); // Green-500
    doc.roundedRect(margin, curY, pageWidth - margin * 2, 16, 2, 2, 'FD');

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(21, 128, 61);
    doc.text('FEASIBILITY STATUS: SEAT SUPPLY IS SUFFICIENT', margin + 5, curY + 6);
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(22, 101, 52);
    doc.text(
      `Total Demand: ${result.deficit.demandSeatDays} seat-days  |  Total Supply: ${result.deficit.supplySeatDays} seat-days  |  Spare Capacity: ${result.deficit.spareSeatDays} seat-days (equivalent to ${result.deficit.spareSeatsEquivalent} seats).`,
      margin + 5,
      curY + 12
    );

    curY += 22;
  }

  // Two columns on Page 1: Policy Thresholds (Left) & Public Holidays (Right)
  const colWidth = (pageWidth - margin * 2 - 8) / 2;

  // Left: Policy Configuration
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('1. Compliance Policy & Allocation Parameters', margin, curY);

  autoTable(doc, {
    startY: curY + 4,
    margin: { left: margin, right: margin + colWidth + 8 },
    head: [['Parameter / Designation', 'Mandated Value']],
    body: [
      ['Managing Director (MD)', `${policy.compliancePercentages.MD}% (Fixed Seat)`],
      ['Executive Director (ED)', `${policy.compliancePercentages.ED}% (Fixed Seat)`],
      ['Vice President (VP)', `${policy.compliancePercentages.VP}% (Fixed Seat)`],
      ['Professional (Hot-Desk)', `${policy.compliancePercentages.Professional}% (Hot Desk Pool)`],
      ['Compliance Calculation Basis', policy.complianceBasis === 'net' ? 'Net Working Days after Leave' : 'Gross Working Days'],
      ['Rounding Rule Applied', policy.roundingRule === 'ceil' ? 'Round Up (Ceil)' : 'Round to Nearest'],
      ['Senior Seating Hierarchy', 'MD > ED > VP (Released to pool when absent)']
    ],
    theme: 'grid',
    headStyles: { fillColor: [51, 65, 85], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: [30, 41, 59] },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: { 0: { cellWidth: 80 }, 1: { cellWidth: 55 } }
  });

  // Right: NSE Public Holidays Falling in Period
  const holidaysInPeriod = holidays.filter((h) => {
    return h.date >= period.startDate && h.date <= period.endDate;
  });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('2. NSE Trading Holidays in Roster Window', margin + colWidth + 8, curY);

  const holidayRows = holidaysInPeriod.length > 0
    ? holidaysInPeriod.map((h) => [
        format(parseISO(h.date), 'dd-MMM-yyyy'),
        h.day,
        h.name,
        h.isWeekend ? 'Weekend (No impact)' : 'NSE Market Closed'
      ])
    : [['None', '-', 'No public holidays fall in this 2-week window.', 'Full 10 working days']];

  autoTable(doc, {
    startY: curY + 4,
    margin: { left: margin + colWidth + 8, right: margin },
    head: [['Date', 'Day', 'Holiday Name', 'Impact']],
    body: holidayRows,
    theme: 'grid',
    headStyles: { fillColor: [51, 65, 85], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: [30, 41, 59] },
    alternateRowStyles: { fillColor: [248, 250, 252] }
  });

  // Note at bottom of Page 1
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(100, 116, 139);
  doc.text(
    'Note: Working days exclude Saturdays, Sundays and confirmed NSE capital-market trading holidays. Fixed senior seats are released into the hot-desk pool when seniors work from home.',
    margin,
    pageHeight - 14
  );

  // ==========================================
  // PAGE 2: FORTNIGHTLY ROSTER GRID
  // ==========================================
  doc.addPage('a4', 'landscape');
  addHeader('Fortnightly Work-From-Office Roster Grid', 'Employee daily allocation with assigned seat numbers');

  const gridHead = [
    ['Sr.', 'Emp ID', 'Name', 'Role', ...result.workingDays.map((d) => format(parseISO(d), 'dd-MMM (EEE)'))]
  ];

  const gridBody = employees
    .filter((e) => e.active)
    .map((emp, index) => {
      const row = [
        `${index + 1}`,
        emp.empId,
        emp.name,
        emp.designation
      ];

      result.workingDays.forEach((d) => {
        const cell = result.grid[emp.id]?.[d];
        if (!cell) {
          row.push('-');
          return;
        }

        if (cell.status === 'O') {
          const seatLabel = cell.seatNumber ? `S-${String(cell.seatNumber).padStart(2, '0')}` : 'Office';
          const backfillTag = cell.isBackfilled ? ' [BF]' : '';
          row.push(`${seatLabel}${backfillTag}`);
        } else if (cell.status === 'L') {
          row.push(`Leave (${cell.leaveType || 'L'})`);
        } else if (cell.status === 'W') {
          row.push('WFH');
        } else {
          row.push(cell.status);
        }
      });

      return row;
    });

  autoTable(doc, {
    startY: margin + 30,
    head: gridHead,
    body: gridBody,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontSize: 7.5,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 7,
      textColor: [30, 41, 59],
      halign: 'center',
      cellPadding: 1.5
    },
    columnStyles: {
      0: { cellWidth: 9, halign: 'center' },
      1: { cellWidth: 15, halign: 'center' },
      2: { cellWidth: 32, halign: 'left', fontStyle: 'bold' },
      3: { cellWidth: 16, halign: 'center' }
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index >= 4) {
        const text = String(data.cell.raw);
        if (text.startsWith('S-')) {
          data.cell.styles.fillColor = [238, 242, 255]; // Indigo-50
          data.cell.styles.textColor = [55, 48, 163]; // Indigo-800
          data.cell.styles.fontStyle = 'bold';
        } else if (text.startsWith('Leave')) {
          data.cell.styles.fillColor = [254, 243, 199]; // Amber-100
          data.cell.styles.textColor = [146, 64, 14]; // Amber-800
        } else if (text === 'WFH') {
          data.cell.styles.fillColor = [248, 250, 252];
          data.cell.styles.textColor = [100, 116, 139];
        }
      }
    }
  });

  // Legend at bottom of Page 2
  const legendY = pageHeight - 15;
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('Status Legend:', margin, legendY);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('S-xx: Office (with Seat #)   |   [BF]: Senior seat backfilled by Professional   |   WFH: Work From Home   |   Leave: Approved Leave', margin + 25, legendY);

  // ==========================================
  // PAGE 3: DAILY OCCUPANCY & UTILISATION
  // ==========================================
  doc.addPage('a4', 'landscape');
  addHeader('Daily Occupancy & Seat Utilisation Analysis', 'Capacity breakdown across all working days in the fortnight');

  const occHead = [
    ['Date', 'Day', 'Seats Available', 'Seniors Present', 'Professionals Present', 'Total Occupied', 'Vacant Seats', 'Utilisation %', 'Capacity Status']
  ];

  const occBody = result.dailyOccupancies.map((d) => {
    return [
      format(parseISO(d.date), 'dd-MMM-yyyy'),
      d.dayName,
      `${d.seatsAvailable}`,
      `${d.seniorsPresent}`,
      `${d.professionalsPresent}`,
      `${d.totalOccupied}`,
      `${d.vacantSeats}`,
      `${d.utilisationPct}%`,
      d.isOverCapacity ? 'OVER CAPACITY (BREACH)' : (d.utilisationPct >= 90 ? 'Optimal' : 'Standard')
    ];
  });

  autoTable(doc, {
    startY: margin + 30,
    head: occHead,
    body: occBody,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontSize: 8.5,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 8.5,
      textColor: [30, 41, 59],
      halign: 'center',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { halign: 'left', fontStyle: 'bold' },
      1: { halign: 'left' }
    },
    didParseCell: (data) => {
      if (data.section === 'body') {
        const row = result.dailyOccupancies[data.row.index];
        if (data.column.index === 7) {
          if (row.utilisationPct >= 90) {
            data.cell.styles.fillColor = [220, 252, 231];
            data.cell.styles.textColor = [22, 101, 52];
            data.cell.styles.fontStyle = 'bold';
          }
        }
        if (data.column.index === 8 && row.isOverCapacity) {
          data.cell.styles.fillColor = [254, 226, 226];
          data.cell.styles.textColor = [185, 28, 28];
          data.cell.styles.fontStyle = 'bold';
        }
      }
    }
  });

  // ==========================================
  // PAGE 4: EMPLOYEE COMPLIANCE AUDIT STATEMENT
  // ==========================================
  doc.addPage('a4', 'landscape');
  addHeader('Employee Compliance Statement', 'Audit of mandated vs allocated office attendance percentages');

  const compHead = [
    ['Emp ID', 'Name', 'Role', 'Mandated %', 'Working Days', 'Leave Days', 'Net Available', 'Req. Days', 'Allocated Days', 'Achieved %', 'Compliance Status']
  ];

  const compBody = result.employeeSummaries.map((s) => {
    return [
      s.empId,
      s.name,
      s.designation,
      `${s.requiredPct}%`,
      `${s.totalWorkingDays}`,
      `${s.leaveDaysInPeriod}`,
      `${s.availableWorkingDays}`,
      `${s.requiredOfficeDays}`,
      `${s.allocatedOfficeDays}`,
      `${s.achievedPct}%`,
      s.isFullyOnLeave ? 'Not Applicable (Full Leave)' : (s.isCompliant ? 'Compliant' : `Shortfall by ${s.shortfallDays} day(s)`)
    ];
  });

  autoTable(doc, {
    startY: margin + 30,
    head: compHead,
    body: compBody,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [30, 41, 59],
      halign: 'center',
      cellPadding: 1.8
    },
    columnStyles: {
      0: { cellWidth: 16 },
      1: { cellWidth: 36, halign: 'left', fontStyle: 'bold' },
      2: { cellWidth: 20 }
    },
    didParseCell: (data) => {
      if (data.section === 'body') {
        const item = result.employeeSummaries[data.row.index];
        if (data.column.index === 10) {
          if (item.isFullyOnLeave) {
            data.cell.styles.fillColor = [241, 245, 249];
            data.cell.styles.textColor = [100, 116, 139];
          } else if (!item.isCompliant) {
            data.cell.styles.fillColor = [254, 226, 226];
            data.cell.styles.textColor = [185, 28, 28];
            data.cell.styles.fontStyle = 'bold';
          } else {
            data.cell.styles.fillColor = [220, 252, 231];
            data.cell.styles.textColor = [22, 101, 52];
          }
        }
      }
    }
  });

  // Closing Compliance Statement on Page 4
  const closingY = pageHeight - 16;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  if (result.deficit.hasDeficit) {
    doc.setTextColor(185, 28, 28);
    doc.text(`Seats required to achieve 100% full team compliance: ${result.deficit.minSeatsForFullCompliance} seats.`, margin, closingY);
  } else {
    doc.setTextColor(21, 128, 61);
    doc.text('All active employees have achieved 100% of their mandated hybrid attendance threshold.', margin, closingY);
  }

  // Stamp footer on all 4 pages
  const totalPages = doc.internal.pages.length - 1;
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    addFooter(p, totalPages);
  }

  // Save PDF
  const filename = `HybridDesk_Roster_${period.startDate}_to_${period.endDate}.pdf`;
  doc.save(filename);
}

/**
 * Export Roster Grid as CSV / Excel
 */
export function exportRosterSpreadsheet(
  result: AllocationResult,
  employees: Employee[],
  period: RosterPeriodConfig,
  formatType: 'xlsx' | 'csv' = 'xlsx'
) {
  const headers = [
    'Employee ID',
    'Name',
    'Designation',
    'Required %',
    'Working Days',
    'Leave Days',
    'Net Available Days',
    'Required Days',
    'Allocated Office Days',
    'Compliance Status',
    ...result.workingDays.map((d) => `${format(parseISO(d), 'yyyy-MM-dd')} (${format(parseISO(d), 'EEE')})`)
  ];

  const rows = employees
    .filter((e) => e.active)
    .map((emp) => {
      const summary = result.employeeSummaries.find((s) => s.employeeId === emp.id);
      const rowData: (string | number)[] = [
        emp.empId,
        emp.name,
        emp.designation,
        summary ? `${summary.requiredPct}%` : '60%',
        summary ? summary.totalWorkingDays : result.workingDays.length,
        summary ? summary.leaveDaysInPeriod : 0,
        summary ? summary.availableWorkingDays : 0,
        summary ? summary.requiredOfficeDays : 0,
        summary ? summary.allocatedOfficeDays : 0,
        summary ? summary.statusText : 'Compliant'
      ];

      result.workingDays.forEach((d) => {
        const cell = result.grid[emp.id]?.[d];
        if (!cell) {
          rowData.push('WFH');
        } else if (cell.status === 'O') {
          rowData.push(cell.seatNumber ? `Seat-${String(cell.seatNumber).padStart(2, '0')}` : 'Office');
        } else if (cell.status === 'L') {
          rowData.push(`Leave (${cell.leaveType || 'L'})`);
        } else {
          rowData.push('WFH');
        }
      });

      return rowData;
    });

  if (formatType === 'csv') {
    const csvContent = Papa.unparse({
      fields: headers,
      data: rows
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `HybridDesk_Roster_${period.startDate}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  } else {
    const wsData = [headers, ...rows];
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    XLSX.utils.book_append_sheet(wb, ws, 'Roster Grid');

    // Daily occupancy sheet
    const occHeaders = ['Date', 'Day', 'Seats Available', 'Seniors Present', 'Professionals Present', 'Total Occupied', 'Vacant Seats', 'Utilisation %'];
    const occRows = result.dailyOccupancies.map((d) => [
      d.date,
      d.dayName,
      d.seatsAvailable,
      d.seniorsPresent,
      d.professionalsPresent,
      d.totalOccupied,
      d.vacantSeats,
      `${d.utilisationPct}%`
    ]);
    const wsOcc = XLSX.utils.aoa_to_sheet([occHeaders, ...occRows]);
    XLSX.utils.book_append_sheet(wb, wsOcc, 'Daily Occupancy');

    XLSX.writeFile(wb, `HybridDesk_Roster_${period.startDate}.xlsx`);
  }
}

/**
 * Generate Email-Ready, bulletproof inline-styled HTML for Outlook, Gmail, Apple Mail
 */
export function generateRosterEmailHTML(params: {
  result: AllocationResult;
  employees: Employee[];
  period: RosterPeriodConfig;
  policy: PolicySettings;
  holidays: Holiday[];
  seatCount: number;
  teamName?: string;
}): string {
  const {
    result,
    employees,
    period,
    policy,
    holidays,
    seatCount,
    teamName = 'Technology & Quant Operations'
  } = params;

  const startFormatted = format(parseISO(period.startDate), 'dd-MMM-yyyy');
  const endFormatted = format(parseISO(period.endDate), 'dd-MMM-yyyy');
  const genFormatted = format(new Date(), 'dd-MMM-yyyy HH:mm');
  const activeEmployees = employees.filter((e) => e.active);
  const activeCount = activeEmployees.length;
  const ratioPct = activeCount > 0 ? Math.round((seatCount / activeCount) * 100) : 0;

  // Build Day Headers
  const dayHeaderCells = result.workingDays
    .map((d) => {
      const parsed = parseISO(d);
      const dayDate = format(parsed, 'dd-MMM');
      const dayName = format(parsed, 'EEE');
      const isAnchor = policy.teamAnchorDay === parsed.getDay();
      return `
        <th style="padding: 6px 4px; border: 1px solid #cbd5e1; background-color: ${isAnchor ? '#e0e7ff' : '#f1f5f9'}; color: #1e293b; font-size: 11px; text-align: center; min-width: 62px; font-weight: 700;">
          <div style="font-size: 9px; color: #64748b; text-transform: uppercase;">${dayDate}</div>
          <div style="font-size: 11px; color: ${isAnchor ? '#3730a3' : '#1e293b'};">${dayName}${isAnchor ? ' •' : ''}</div>
        </th>
      `;
    })
    .join('');

  // Build Employee Rows
  const employeeRows = activeEmployees
    .map((emp, idx) => {
      const summary = result.employeeSummaries.find((s) => s.employeeId === emp.id);
      const isEven = idx % 2 === 0;
      const rowBg = isEven ? '#ffffff' : '#f8fafc';

      const dayCells = result.workingDays
        .map((d) => {
          const cell = result.grid[emp.id]?.[d];
          if (!cell) {
            return `<td style="padding: 5px 3px; border: 1px solid #e2e8f0; text-align: center; color: #94a3b8; font-size: 10px; background-color: ${rowBg};">-</td>`;
          }

          if (cell.status === 'O') {
            const seatText = cell.seatNumber ? `S-${String(cell.seatNumber).padStart(2, '0')}` : 'Office';
            let bg = '#eef2ff';
            let fg = '#3730a3';
            let border = '#c7d2fe';
            let tag = cell.isFixedSeat ? 'Fix' : cell.isBackfilled ? 'Backfill' : 'Hot';

            if (cell.isBackfilled) {
              bg = '#f0fdfa';
              fg = '#0f766e';
              border = '#99f6e4';
            } else if (cell.isFixedSeat) {
              bg = '#faf5ff';
              fg = '#6b21a8';
              border = '#e9d5ff';
            }

            return `
              <td style="padding: 4px 2px; border: 1px solid #e2e8f0; text-align: center; background-color: ${rowBg};">
                <div style="display: inline-block; padding: 2px 4px; border-radius: 3px; background-color: ${bg}; color: ${fg}; border: 1px solid ${border}; font-size: 10px; font-weight: bold; line-height: 1.2;">
                  <div>${seatText}</div>
                  <div style="font-size: 8px; font-weight: normal; opacity: 0.8;">${tag}</div>
                </div>
              </td>
            `;
          }

          if (cell.status === 'L') {
            return `
              <td style="padding: 4px 2px; border: 1px solid #e2e8f0; text-align: center; background-color: ${rowBg};">
                <div style="display: inline-block; padding: 2px 4px; border-radius: 3px; background-color: #fef3c7; color: #92400e; border: 1px solid #fde68a; font-size: 10px; font-weight: 600; line-height: 1.2;">
                  <div>Leave</div>
                  <div style="font-size: 8px; text-transform: uppercase;">${cell.leaveType || 'PL'}</div>
                </div>
              </td>
            `;
          }

          // WFH
          return `
            <td style="padding: 4px 2px; border: 1px solid #e2e8f0; text-align: center; background-color: ${rowBg};">
              <div style="display: inline-block; padding: 2px 5px; border-radius: 3px; background-color: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; font-size: 10px;">
                WFH
              </div>
            </td>
          `;
        })
        .join('');

      const reqOffice = summary?.requiredOfficeDays ?? 0;
      const allocOffice = summary?.allocatedOfficeDays ?? 0;
      const isCompliant = summary?.isCompliant ?? true;
      const isNA = summary?.isFullyOnLeave ?? false;

      const compBadge = isNA
        ? '<span style="color: #94a3b8; font-size: 10px;">N/A</span>'
        : `<span style="font-weight: bold; color: ${isCompliant ? '#15803d' : '#b91c1c'}; font-size: 10px;">${allocOffice}/${reqOffice}</span>`;

      return `
        <tr style="background-color: ${rowBg};">
          <td style="padding: 5px 4px; border: 1px solid #e2e8f0; text-align: center; font-size: 10px; color: #94a3b8; font-family: monospace;">${idx + 1}</td>
          <td style="padding: 5px 6px; border: 1px solid #e2e8f0; font-size: 10px; font-family: monospace; color: #475569;">${emp.empId}</td>
          <td style="padding: 5px 6px; border: 1px solid #e2e8f0; font-size: 11px; font-weight: bold; color: #0f172a; white-space: nowrap;">${emp.name}</td>
          <td style="padding: 5px 4px; border: 1px solid #e2e8f0; font-size: 10px; text-align: center; color: #334155;">
            <span style="display: inline-block; padding: 1px 4px; border-radius: 3px; background-color: #f1f5f9; font-weight: 600;">${emp.designation}</span>
          </td>
          <td style="padding: 5px 4px; border: 1px solid #e2e8f0; text-align: center; font-size: 10px; font-family: monospace;">${compBadge}</td>
          ${dayCells}
        </tr>
      `;
    })
    .join('');

  // Daily Occupancy Summary Footer Row
  const dailyOccupancyCells = result.workingDays
    .map((d) => {
      const occ = result.dailyOccupancies.find((o) => o.date === d);
      const count = occ ? occ.totalOccupied : 0;
      const util = occ ? occ.utilisationPct : 0;
      const isOver = occ?.isOverCapacity;

      return `
        <td style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; font-size: 10px; background-color: ${isOver ? '#fef2f2' : '#f8fafc'}; color: ${isOver ? '#b91c1c' : '#1e293b'}; font-weight: bold; font-family: monospace;">
          <div>${count}/${seatCount}</div>
          <div style="font-size: 9px; font-weight: normal; color: ${util >= 90 ? '#15803d' : '#64748b'};">${util}%</div>
        </td>
      `;
    })
    .join('');

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HybridDesk Fortnightly Roster - ${startFormatted} to ${endFormatted}</title>
</head>
<body style="margin: 0; padding: 16px; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b; -webkit-text-size-adjust: 100%;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width: 960px; margin: 0 auto; background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08);">
    <!-- Header Zone -->
    <tr>
      <td style="background-color: #0f172a; padding: 18px 24px; color: #ffffff;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <div style="font-size: 18px; font-weight: bold; letter-spacing: -0.5px; color: #ffffff;">HybridDesk — Fortnightly Roster & Seat Allocation</div>
              <div style="font-size: 12px; color: #94a3b8; margin-top: 4px;">
                <strong>Team:</strong> ${teamName} &nbsp;|&nbsp; <strong>Period:</strong> ${startFormatted} to ${endFormatted} &nbsp;|&nbsp; <strong>Generated:</strong> ${genFormatted}
              </div>
            </td>
            <td align="right" style="vertical-align: middle;">
              <span style="display: inline-block; padding: 4px 10px; border-radius: 4px; background-color: #1e293b; border: 1px solid #334155; font-size: 11px; font-weight: bold; color: #38bdf8;">
                Fortnightly Cycle
              </span>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- KPI Summary Cards -->
    <tr>
      <td style="padding: 16px 24px; background-color: #f8fafc; border-bottom: 1px solid #e2e8f0;">
        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: separate; border-spacing: 8px 0;">
          <tr>
            <td width="20%" style="background-color: #ffffff; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center;">
              <div style="font-size: 9px; font-weight: bold; color: #64748b; text-transform: uppercase;">Active Headcount</div>
              <div style="font-size: 16px; font-weight: bold; color: #0f172a; font-family: monospace; margin-top: 2px;">${activeCount}</div>
            </td>
            <td width="20%" style="background-color: #ffffff; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center;">
              <div style="font-size: 9px; font-weight: bold; color: #64748b; text-transform: uppercase;">Seat Inventory</div>
              <div style="font-size: 16px; font-weight: bold; color: #0f172a; font-family: monospace; margin-top: 2px;">${seatCount} <span style="font-size: 10px; color: #64748b;">(${ratioPct}%)</span></div>
            </td>
            <td width="20%" style="background-color: #ffffff; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center;">
              <div style="font-size: 9px; font-weight: bold; color: #64748b; text-transform: uppercase;">Working Days</div>
              <div style="font-size: 16px; font-weight: bold; color: #0f172a; font-family: monospace; margin-top: 2px;">${result.workingDays.length}d</div>
            </td>
            <td width="20%" style="background-color: #ffffff; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center;">
              <div style="font-size: 9px; font-weight: bold; color: #64748b; text-transform: uppercase;">Avg Utilisation</div>
              <div style="font-size: 16px; font-weight: bold; color: #15803d; font-family: monospace; margin-top: 2px;">${result.avgDailyUtilisationPct}%</div>
            </td>
            <td width="20%" style="background-color: #ffffff; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center;">
              <div style="font-size: 9px; font-weight: bold; color: #64748b; text-transform: uppercase;">Compliance Status</div>
              <div style="font-size: 16px; font-weight: bold; color: ${result.deficit.hasDeficit ? '#b91c1c' : '#15803d'}; font-family: monospace; margin-top: 2px;">
                ${result.fullyCompliantCount}/${result.employeeSummaries.length - result.notApplicableCount} Met
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    ${
      result.deficit.hasDeficit
        ? `
    <!-- Deficit Alert -->
    <tr>
      <td style="padding: 12px 24px; background-color: #fef2f2; border-bottom: 1px solid #fecaca;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="font-size: 12px; color: #991b1b; font-weight: bold;">
              ⚠️ CAPACITY DEFICIT WARNING: Team is short by ${result.deficit.seatsShort} physical seat(s)
            </td>
          </tr>
          <tr>
            <td style="font-size: 11px; color: #b91c1c; margin-top: 2px;">
              Total Demand: <strong>${result.deficit.demandSeatDays} seat-days</strong> | Total Supply: <strong>${result.deficit.supplySeatDays} seat-days</strong> | Shortfall: <strong>${result.deficit.deficitSeatDays} seat-days</strong>. Min seats for full compliance: <strong>${result.deficit.minSeatsForFullCompliance}</strong>.
            </td>
          </tr>
        </table>
      </td>
    </tr>
    `
        : ''
    }

    <!-- Roster Grid Section -->
    <tr>
      <td style="padding: 20px 24px;">
        <div style="font-size: 13px; font-weight: bold; color: #0f172a; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px;">
          Fortnightly Office Attendance Schedule
        </div>

        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse; width: 100%; border: 1px solid #cbd5e1; font-size: 11px;">
          <thead>
            <tr style="background-color: #0f172a; color: #ffffff;">
              <th style="padding: 7px 4px; border: 1px solid #cbd5e1; font-size: 10px; text-align: center; width: 24px; font-weight: 700;">#</th>
              <th style="padding: 7px 6px; border: 1px solid #cbd5e1; font-size: 10px; text-align: left; width: 50px; font-weight: 700;">ID</th>
              <th style="padding: 7px 8px; border: 1px solid #cbd5e1; font-size: 11px; text-align: left; font-weight: 700;">Employee</th>
              <th style="padding: 7px 4px; border: 1px solid #cbd5e1; font-size: 10px; text-align: center; width: 60px; font-weight: 700;">Role</th>
              <th style="padding: 7px 4px; border: 1px solid #cbd5e1; font-size: 10px; text-align: center; width: 54px; font-weight: 700;">Req/Act</th>
              ${dayHeaderCells}
            </tr>
          </thead>
          <tbody>
            ${employeeRows}
          </tbody>
          <tfoot>
            <tr style="background-color: #f1f5f9; font-weight: bold; border-top: 2px solid #94a3b8;">
              <td colspan="5" style="padding: 6px 8px; border: 1px solid #cbd5e1; font-size: 11px; color: #0f172a; text-align: right;">
                Daily Occupancy / Utilisation:
              </td>
              ${dailyOccupancyCells}
            </tr>
          </tfoot>
        </table>
      </td>
    </tr>

    <!-- Legend & Notes Footer -->
    <tr>
      <td style="padding: 14px 24px 20px 24px; background-color: #f8fafc; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="font-size: 11px; line-height: 1.5;">
              <strong style="color: #334155;">Legend:</strong>&nbsp;
              <span style="display: inline-block; padding: 1px 5px; background-color: #faf5ff; border: 1px solid #e9d5ff; color: #6b21a8; font-weight: bold; border-radius: 3px; font-size: 10px;">S-xx (Fix)</span> Senior Fixed Desk &nbsp;|&nbsp;
              <span style="display: inline-block; padding: 1px 5px; background-color: #f0fdfa; border: 1px solid #99f6e4; color: #0f766e; font-weight: bold; border-radius: 3px; font-size: 10px;">S-xx (Backfill)</span> Backfilled Senior Desk &nbsp;|&nbsp;
              <span style="display: inline-block; padding: 1px 5px; background-color: #eef2ff; border: 1px solid #c7d2fe; color: #3730a3; font-weight: bold; border-radius: 3px; font-size: 10px;">S-xx (Hot)</span> Hot Desk Pool &nbsp;|&nbsp;
              <span style="display: inline-block; padding: 1px 5px; background-color: #fef3c7; border: 1px solid #fde68a; color: #92400e; font-weight: bold; border-radius: 3px; font-size: 10px;">Leave</span> Approved Leave &nbsp;|&nbsp;
              <span style="display: inline-block; padding: 1px 5px; background-color: #f1f5f9; border: 1px solid #e2e8f0; color: #64748b; border-radius: 3px; font-size: 10px;">WFH</span> Work From Home
            </td>
          </tr>
          <tr>
            <td style="font-size: 10px; color: #94a3b8; margin-top: 8px; padding-top: 8px; border-top: 1px dashed #cbd5e1;">
              * Confidential. Generated deterministically by HybridDesk Roster & Seat Optimization Engine. Working days exclude weekends and confirmed NSE trading holidays.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

/**
 * Download raw HTML file of the roster
 */
export function downloadRosterHTML(params: {
  result: AllocationResult;
  employees: Employee[];
  period: RosterPeriodConfig;
  policy: PolicySettings;
  holidays: Holiday[];
  seatCount: number;
  teamName?: string;
}) {
  const html = generateRosterEmailHTML(params);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `HybridDesk_Roster_${params.period.startDate}_to_${params.period.endDate}.html`;
  link.click();
  URL.revokeObjectURL(url);
}

