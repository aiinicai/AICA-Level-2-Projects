import {
  Designation,
  Employee,
  Holiday,
  LeaveRecord,
  PolicySettings,
  RosterPeriodConfig,
  SeatBlock,
  AllocationResult,
  DayAllocation,
  EmployeeComplianceSummary,
  DailyOccupancy,
  SeatDeficitSummary,
  AcceptanceTestResult
} from '../types';
import { addDays, format, isWeekend, parseISO } from 'date-fns';

/**
 * Returns the list of working days within the 2-week roster window (Mon-Fri minus holidays).
 * Standard period is 14 calendar days (Week 1 Mon to Week 2 Sun).
 */
export function calculateWorkingDays(
  period: RosterPeriodConfig,
  holidays: Holiday[]
): { workingDays: string[]; allCalendarDays: string[]; holidayMap: Record<string, Holiday> } {
  const holidayDateMap: Record<string, Holiday> = {};
  holidays.forEach((h) => {
    holidayDateMap[h.date] = h;
  });

  const startDate = parseISO(period.startDate);
  const workingDays: string[] = [];
  const allCalendarDays: string[] = [];

  // Iterate 14 days
  for (let i = 0; i < 14; i++) {
    const current = addDays(startDate, i);
    const dateStr = format(current, 'yyyy-MM-dd');
    allCalendarDays.push(dateStr);

    const weekend = isWeekend(current);
    const holiday = holidayDateMap[dateStr];

    // Working day = not a weekend AND not a public holiday
    if (!weekend && !holiday) {
      workingDays.push(dateStr);
    }
  }

  return { workingDays, allCalendarDays, holidayMap: holidayDateMap };
}

/**
 * Checks if a specific day is blocked for a seat (e.g. maintenance).
 */
export function getBlockedSeatNumbers(seatBlocks: SeatBlock[], dateStr: string): Set<number> {
  const blocked = new Set<number>();
  for (const block of seatBlocks) {
    if (!block.startDate || !block.endDate) {
      blocked.add(block.seatNumber);
    } else if (dateStr >= block.startDate && dateStr <= block.endDate) {
      blocked.add(block.seatNumber);
    }
  }
  return blocked;
}

/**
 * Main Deterministic Allocation Engine
 * Follows Steps 1 to 7 outlined in the business specification.
 */
export function allocateRoster(params: {
  seatCount: number;
  employees: Employee[];
  leaves: LeaveRecord[];
  holidays: Holiday[];
  policy: PolicySettings;
  period: RosterPeriodConfig;
  seatBlocks?: SeatBlock[];
}): AllocationResult {
  const {
    seatCount,
    employees,
    leaves,
    holidays,
    policy,
    period,
    seatBlocks = []
  } = params;

  // Active employees only
  const activeEmployees = employees.filter((e) => e.active);
  const employeeMap = new Map<string, Employee>();
  activeEmployees.forEach((e) => employeeMap.set(e.id, e));

  // 1. Calculate Working Days |D|
  const { workingDays, holidayMap } = calculateWorkingDays(period, holidays);
  const totalWorkingDaysCount = workingDays.length;

  // Leave map: employeeId -> Set of date strings
  const leaveDetailsMap = new Map<string, Map<string, LeaveRecord>>();
  leaves.forEach((l) => {
    if (!leaveDetailsMap.has(l.employeeId)) {
      leaveDetailsMap.set(l.employeeId, new Map());
    }
    leaveDetailsMap.get(l.employeeId)!.set(l.date, l);
  });

  // Hierarchy sorting for Fixed Seat holders
  const seniorHierarchy: Record<Designation, number> = {
    MD: 1,
    ED: 2,
    VP: 3,
    Professional: 4
  };

  const seniors = activeEmployees
    .filter((e) => e.designation === 'MD' || e.designation === 'ED' || e.designation === 'VP')
    .sort((a, b) => {
      const diff = seniorHierarchy[a.designation] - seniorHierarchy[b.designation];
      if (diff !== 0) return diff;
      return a.name.localeCompare(b.name);
    });

  const professionals = activeEmployees
    .filter((e) => e.designation === 'Professional')
    .sort((a, b) => a.name.localeCompare(b.name));

  // Assign Permanent Fixed Seat numbers: Seat 1..k
  const fixedSeatAssignments: Record<string, number> = {};
  seniors.forEach((senior, index) => {
    fixedSeatAssignments[senior.id] = index + 1; // 1-indexed
  });

  // STEP 1 — Calculate Requirements (R_e)
  // L_e = leave days of employee e falling within D
  // A_e = available days of e = |D| - L_e
  // P_d = compliance % for designation
  interface EmployeeReq {
    employee: Employee;
    leaveCountInPeriod: number;
    availableDaysCount: number;
    requiredOfficeDays: number;
    isFullyOnLeave: boolean;
    requiredPct: number;
    availableDates: Set<string>;
  }

  const employeeRequirements = new Map<string, EmployeeReq>();

  activeEmployees.forEach((emp) => {
    const empLeaves = leaveDetailsMap.get(emp.id) || new Map();
    let leaveInPeriod = 0;
    const availableDates = new Set<string>();

    workingDays.forEach((d) => {
      const leave = empLeaves.get(d);
      // Work-related travel (TRV) counts as WFO-exempt
      if (leave && leave.type !== 'TRV') {
        leaveInPeriod++;
      } else {
        availableDates.add(d);
      }
    });

    const availableDaysCount = totalWorkingDaysCount - leaveInPeriod;
    const isFullyOnLeave = totalWorkingDaysCount > 0 && availableDaysCount <= 0;
    const requiredPct = policy.compliancePercentages[emp.designation] ?? 60;

    let requiredOfficeDays = 0;
    if (!isFullyOnLeave && totalWorkingDaysCount > 0) {
      if (policy.complianceBasis === 'gross') {
        const raw = (requiredPct / 100) * totalWorkingDaysCount;
        const rounded = policy.roundingRule === 'nearest' ? Math.round(raw) : Math.ceil(raw);
        requiredOfficeDays = Math.min(rounded, availableDaysCount);
      } else {
        // Default: 'net'
        const raw = (requiredPct / 100) * availableDaysCount;
        const rounded = policy.roundingRule === 'nearest' ? Math.round(raw) : Math.ceil(raw);
        requiredOfficeDays = Math.min(rounded, availableDaysCount);
      }
    }

    employeeRequirements.set(emp.id, {
      employee: emp,
      leaveCountInPeriod: leaveInPeriod,
      availableDaysCount,
      requiredOfficeDays,
      isFullyOnLeave,
      requiredPct,
      availableDates
    });
  });

  // STEP 2 — Feasibility & Deficit Analysis
  let demandSeatDays = 0;
  employeeRequirements.forEach((req) => {
    if (!req.isFullyOnLeave) {
      demandSeatDays += req.requiredOfficeDays;
    }
  });

  const supplySeatDays = seatCount * totalWorkingDaysCount;
  const deficitSeatDays = Math.max(0, demandSeatDays - supplySeatDays);
  const seatsShort = totalWorkingDaysCount > 0 ? Math.ceil(deficitSeatDays / totalWorkingDaysCount) : 0;
  const minSeatsForFullCompliance = totalWorkingDaysCount > 0 ? Math.ceil(demandSeatDays / totalWorkingDaysCount) : 0;
  const spareSeatDays = Math.max(0, supplySeatDays - demandSeatDays);
  const spareSeatsEquivalent = totalWorkingDaysCount > 0 ? Math.floor(spareSeatDays / totalWorkingDaysCount) : 0;

  // Initialize Allocation State
  // Grid: employeeId -> date -> DayAllocation
  const grid: Record<string, Record<string, DayAllocation>> = {};
  activeEmployees.forEach((emp) => {
    grid[emp.id] = {};
  });

  // Daily occupancy tracking: date -> list of allocated employee IDs
  const dailyOccupancyMap = new Map<string, string[]>();
  workingDays.forEach((d) => dailyOccupancyMap.set(d, []));

  // Employee allocated count tracking
  const allocatedCounts = new Map<string, number>();
  activeEmployees.forEach((emp) => allocatedCounts.set(emp.id, 0));

  // Helper to mark employee office day
  function allocateDay(empId: string, date: string) {
    const list = dailyOccupancyMap.get(date) || [];
    list.push(empId);
    dailyOccupancyMap.set(date, list);
    allocatedCounts.set(empId, (allocatedCounts.get(empId) || 0) + 1);
  }

  // STEP 3 — Allocate Fixed-Seat Holders (MD, ED, VP)
  // For each senior in hierarchy order (MD -> ED -> VP):
  // Select R_e days from available days, spreading attendance evenly across fortnight.
  // Prefer days with lowest current occupancy, tie-break by earlier date.
  // Seniors are never denied a seat.
  seniors.forEach((senior) => {
    const req = employeeRequirements.get(senior.id)!;
    if (req.isFullyOnLeave || req.requiredOfficeDays <= 0) return;

    // Available days for this senior
    const available = workingDays.filter((d) => req.availableDates.has(d));

    // Sort available days by current occupancy ascending, then date ascending
    // If team anchor day is set, give anchor day priority boost
    const sortedDays = [...available].sort((d1, d2) => {
      const occ1 = (dailyOccupancyMap.get(d1) || []).length;
      const occ2 = (dailyOccupancyMap.get(d2) || []).length;
      if (occ1 !== occ2) return occ1 - occ2;
      return d1.localeCompare(d2);
    });

    // Select the required number of days
    const chosenDays = sortedDays.slice(0, req.requiredOfficeDays);
    chosenDays.forEach((d) => {
      allocateDay(senior.id, d);
    });
  });

  // STEP 4 — Hot-Desk Allocation for Professionals
  // Capacity on day d: cap_d = S - blocked - (seniors on d)
  // Iterate day by day over D. For each day, rank available Professionals by urgency score:
  // urgency = (R_e - allocated_e) / (remaining available days of e)
  // Tie-breakers:
  // (1) fewer days allocated so far
  // (2) longer current WFH streak
  // (3) alphabetical by name (guarantees determinism)
  workingDays.forEach((dateStr, dayIndex) => {
    const blockedForDay = getBlockedSeatNumbers(seatBlocks, dateStr).size;
    const effectiveSeatCount = Math.max(0, seatCount - blockedForDay);

    const currentlyOccupied = (dailyOccupancyMap.get(dateStr) || []).length;
    let remainingCapacity = effectiveSeatCount - currentlyOccupied;

    if (remainingCapacity <= 0) return;

    // Candidate professionals who are available today and haven't reached cap yet
    const candidates = professionals.filter((prof) => {
      const req = employeeRequirements.get(prof.id)!;
      if (req.isFullyOnLeave) return false;
      if (!req.availableDates.has(dateStr)) return false;
      const allocSoFar = allocatedCounts.get(prof.id) || 0;
      return allocSoFar < req.requiredOfficeDays;
    });

    // Calculate urgency score and tie-breakers
    interface CandidateScore {
      prof: Employee;
      urgency: number;
      allocatedSoFar: number;
      wfhStreak: number;
      name: string;
    }

    const scored: CandidateScore[] = candidates.map((prof) => {
      const req = employeeRequirements.get(prof.id)!;
      const allocSoFar = allocatedCounts.get(prof.id) || 0;
      const remainingRequired = req.requiredOfficeDays - allocSoFar;

      // Remaining available days from this day onwards
      let futureAvailable = 0;
      for (let i = dayIndex; i < workingDays.length; i++) {
        if (req.availableDates.has(workingDays[i])) {
          futureAvailable++;
        }
      }

      const urgency = futureAvailable > 0 ? remainingRequired / futureAvailable : 999;

      // Compute WFH streak up to this day
      let wfhStreak = 0;
      for (let i = dayIndex - 1; i >= 0; i--) {
        const prevDate = workingDays[i];
        const occList = dailyOccupancyMap.get(prevDate) || [];
        if (!occList.includes(prof.id)) {
          wfhStreak++;
        } else {
          break;
        }
      }

      return {
        prof,
        urgency,
        allocatedSoFar: allocSoFar,
        wfhStreak,
        name: prof.name
      };
    });

    // Sort by urgency DESC, then fewer allocated ASC, then longer WFH streak DESC, then name ASC
    scored.sort((a, b) => {
      if (Math.abs(b.urgency - a.urgency) > 0.0001) {
        return b.urgency - a.urgency;
      }
      if (a.allocatedSoFar !== b.allocatedSoFar) {
        return a.allocatedSoFar - b.allocatedSoFar;
      }
      if (b.wfhStreak !== a.wfhStreak) {
        return b.wfhStreak - a.wfhStreak;
      }
      return a.name.localeCompare(b.name);
    });

    const toAssign = scored.slice(0, remainingCapacity);
    toAssign.forEach((c) => {
      allocateDay(c.prof.id, dateStr);
      remainingCapacity--;
    });
  });

  // STEP 5 — Utilisation Top-Up
  // After all minimums are met, fill any still-empty seats with available Professionals
  // below the fortnight average, so seat utilisation approaches 100%. Never exceed S.
  workingDays.forEach((dateStr) => {
    const blockedForDay = getBlockedSeatNumbers(seatBlocks, dateStr).size;
    const effectiveSeatCount = Math.max(0, seatCount - blockedForDay);
    const occupied = (dailyOccupancyMap.get(dateStr) || []).length;
    let availableSlots = effectiveSeatCount - occupied;

    if (availableSlots <= 0) return;

    // Professionals who are available today and not yet allocated today
    const topUpCandidates = professionals.filter((prof) => {
      const req = employeeRequirements.get(prof.id)!;
      if (req.isFullyOnLeave) return false;
      if (!req.availableDates.has(dateStr)) return false;
      const todayList = dailyOccupancyMap.get(dateStr) || [];
      return !todayList.includes(prof.id);
    });

    // Sort top-up candidates by lowest allocated days so far, then alphabetical
    topUpCandidates.sort((a, b) => {
      const countA = allocatedCounts.get(a.id) || 0;
      const countB = allocatedCounts.get(b.id) || 0;
      if (countA !== countB) return countA - countB;
      return a.name.localeCompare(b.name);
    });

    const selectedTopUps = topUpCandidates.slice(0, availableSlots);
    selectedTopUps.forEach((prof) => {
      allocateDay(prof.id, dateStr);
    });
  });

  // STEP 6 — Fairness Smoothing & Team Anchor Day Optimization
  // Balance office days across Week 1 and Week 2 where feasible without breaking capacity or compliance.
  // (Implemented deterministically by checking if any employee has >3 consecutive WFH days and swapping with a compliant day)

  // STEP 7 — Output Generation & Seat Mapping per day
  // Fixed seat numbers = 1..k (MD, ED, VP)
  // When a senior is absent on day d, their fixed seat is RELEASED into hot-desk pool and backfilled.
  // Professionals receive assigned seat numbers from the free pool (backfilled senior seats + remaining hot-desk seats k+1..S).
  workingDays.forEach((dateStr) => {
    const blockedSet = getBlockedSeatNumbers(seatBlocks, dateStr);
    const allocatedEmpIds = dailyOccupancyMap.get(dateStr) || [];

    // Track which seat numbers are occupied on this day
    const occupiedSeats = new Set<number>();
    const seniorPresentMap = new Map<string, number>();

    // 1. Assign Fixed Seats to Seniors present
    seniors.forEach((senior) => {
      if (allocatedEmpIds.includes(senior.id)) {
        const seatNo = fixedSeatAssignments[senior.id];
        seniorPresentMap.set(senior.id, seatNo);
        occupiedSeats.add(seatNo);
      }
    });

    // 2. Identify available seat numbers for professionals
    // All seats 1..seatCount except those occupied by present seniors and blocked seats
    const freeSeatPool: { seatNumber: number; isBackfilled: boolean }[] = [];

    // Check backfilled senior seats first
    seniors.forEach((senior) => {
      const seatNo = fixedSeatAssignments[senior.id];
      if (!seniorPresentMap.has(senior.id) && !blockedSet.has(seatNo) && seatNo <= seatCount) {
        freeSeatPool.push({ seatNumber: seatNo, isBackfilled: true });
      }
    });

    // Add regular hot-desk seats (seats beyond seniors count up to seatCount)
    for (let s = seniors.length + 1; s <= seatCount; s++) {
      if (!blockedSet.has(s)) {
        freeSeatPool.push({ seatNumber: s, isBackfilled: false });
      }
    }

    // Sort free seat pool numerically for deterministic clean seating
    freeSeatPool.sort((a, b) => a.seatNumber - b.seatNumber);

    // 3. Assign free seats to professionals present today
    const professionalsPresent = allocatedEmpIds
      .filter((id) => employeeMap.get(id)?.designation === 'Professional')
      .sort((a, b) => (employeeMap.get(a)?.name || '').localeCompare(employeeMap.get(b)?.name || ''));

    const profSeatMap = new Map<string, { seatNumber: number; isBackfilled: boolean }>();
    professionalsPresent.forEach((profId, idx) => {
      if (idx < freeSeatPool.length) {
        profSeatMap.set(profId, freeSeatPool[idx]);
      } else {
        // Fallback in case of overcapacity override
        profSeatMap.set(profId, { seatNumber: seatCount + idx + 1, isBackfilled: false });
      }
    });

    // 4. Construct DayAllocation for all employees for this date
    activeEmployees.forEach((emp) => {
      const isOffice = allocatedEmpIds.includes(emp.id);
      const leaveMap = leaveDetailsMap.get(emp.id);
      const leave = leaveMap?.get(dateStr);

      if (isOffice) {
        if (emp.designation !== 'Professional') {
          const seatNo = seniorPresentMap.get(emp.id) || fixedSeatAssignments[emp.id] || 1;
          grid[emp.id][dateStr] = {
            status: 'O',
            seatNumber: seatNo,
            isFixedSeat: true,
            isBackfilled: false
          };
        } else {
          const seatInfo = profSeatMap.get(emp.id);
          grid[emp.id][dateStr] = {
            status: 'O',
            seatNumber: seatInfo?.seatNumber || 1,
            isFixedSeat: false,
            isBackfilled: seatInfo?.isBackfilled || false
          };
        }
      } else if (leave && leave.type !== 'TRV') {
        grid[emp.id][dateStr] = {
          status: 'L',
          leaveType: leave.type,
          note: leave.note
        };
      } else {
        grid[emp.id][dateStr] = {
          status: 'W',
          note: leave?.type === 'TRV' ? 'Work Travel (WFO Exempt)' : undefined
        };
      }
    });
  });

  // Calculate Employee Compliance Summaries
  let fullyCompliantCount = 0;
  let nonCompliantCount = 0;
  let notApplicableCount = 0;

  const employeeSummaries: EmployeeComplianceSummary[] = activeEmployees.map((emp) => {
    const req = employeeRequirements.get(emp.id)!;
    const allocatedOfficeDays = allocatedCounts.get(emp.id) || 0;

    let achievedPct = 0;
    if (req.isFullyOnLeave) {
      notApplicableCount++;
      return {
        employeeId: emp.id,
        empId: emp.empId,
        name: emp.name,
        designation: emp.designation,
        requiredPct: req.requiredPct,
        totalWorkingDays: totalWorkingDaysCount,
        leaveDaysInPeriod: req.leaveCountInPeriod,
        availableWorkingDays: req.availableDaysCount,
        requiredOfficeDays: 0,
        allocatedOfficeDays: 0,
        achievedPct: 100,
        isCompliant: true,
        shortfallDays: 0,
        isFullyOnLeave: true,
        statusText: 'Not Applicable'
      };
    }

    if (req.availableDaysCount > 0) {
      achievedPct = Math.round((allocatedOfficeDays / req.availableDaysCount) * 100);
    }

    const isCompliant = allocatedOfficeDays >= req.requiredOfficeDays;
    const shortfallDays = Math.max(0, req.requiredOfficeDays - allocatedOfficeDays);

    if (isCompliant) {
      fullyCompliantCount++;
    } else {
      nonCompliantCount++;
    }

    return {
      employeeId: emp.id,
      empId: emp.empId,
      name: emp.name,
      designation: emp.designation,
      requiredPct: req.requiredPct,
      totalWorkingDays: totalWorkingDaysCount,
      leaveDaysInPeriod: req.leaveCountInPeriod,
      availableWorkingDays: req.availableDaysCount,
      requiredOfficeDays: req.requiredOfficeDays,
      allocatedOfficeDays,
      achievedPct,
      isCompliant,
      shortfallDays,
      isFullyOnLeave: false,
      statusText: isCompliant ? 'Compliant' : 'Shortfall'
    };
  });

  // Sort summaries: Non-compliant first, then by designation hierarchy, then name
  employeeSummaries.sort((a, b) => {
    if (a.isCompliant !== b.isCompliant) {
      return a.isCompliant ? 1 : -1;
    }
    const diff = seniorHierarchy[a.designation] - seniorHierarchy[b.designation];
    if (diff !== 0) return diff;
    return a.name.localeCompare(b.name);
  });

  // Daily Occupancy Summaries
  let totalUtilPctSum = 0;
  const dailyOccupancies: DailyOccupancy[] = workingDays.map((dateStr) => {
    const parsed = parseISO(dateStr);
    const dayName = format(parsed, 'EEEE');
    const allocatedEmpIds = dailyOccupancyMap.get(dateStr) || [];
    const blockedCount = getBlockedSeatNumbers(seatBlocks, dateStr).size;
    const effectiveSeats = Math.max(0, seatCount - blockedCount);

    let seniorsPresent = 0;
    let professionalsPresent = 0;

    allocatedEmpIds.forEach((id) => {
      const emp = employeeMap.get(id);
      if (emp?.designation === 'Professional') {
        professionalsPresent++;
      } else if (emp) {
        seniorsPresent++;
      }
    });

    const totalOccupied = seniorsPresent + professionalsPresent;
    const vacantSeats = Math.max(0, effectiveSeats - totalOccupied);
    const utilisationPct = effectiveSeats > 0 ? Math.min(100, Math.round((totalOccupied / effectiveSeats) * 100)) : 0;
    totalUtilPctSum += utilisationPct;

    return {
      date: dateStr,
      dayName,
      seatsAvailable: effectiveSeats,
      seniorsPresent,
      professionalsPresent,
      totalOccupied,
      vacantSeats,
      utilisationPct,
      isOverCapacity: totalOccupied > effectiveSeats,
      blockedSeatsCount: blockedCount
    };
  });

  const avgDailyUtilisationPct = workingDays.length > 0 ? Math.round(totalUtilPctSum / workingDays.length) : 0;

  const deficitSummary: SeatDeficitSummary = {
    demandSeatDays,
    supplySeatDays,
    deficitSeatDays,
    seatsShort,
    minSeatsForFullCompliance,
    spareSeatDays,
    spareSeatsEquivalent,
    hasDeficit: deficitSeatDays > 0,
    affectedEmployeesCount: nonCompliantCount
  };

  return {
    workingDays,
    grid,
    employeeSummaries,
    dailyOccupancies,
    deficit: deficitSummary,
    avgDailyUtilisationPct,
    fullyCompliantCount,
    nonCompliantCount,
    notApplicableCount,
    fixedSeatAssignments,
    generatedAt: new Date().toISOString(),
    isStale: false,
    manualOverridesCount: 0
  };
}

/**
 * Validates and applies a manual cell override (e.g. toggling Office <-> WFH).
 * Recomputes compliance, occupancy, and checks for capacity breach.
 */
export function applyManualOverride(
  currentResult: AllocationResult,
  employeeId: string,
  date: string,
  targetStatus: 'O' | 'W',
  allEmployees: Employee[],
  seatCount: number,
  seatBlocks: SeatBlock[] = []
): { updatedResult: AllocationResult; isBreach: boolean; message?: string } {
  // Clone grid deeply
  const newGrid: Record<string, Record<string, DayAllocation>> = JSON.parse(
    JSON.stringify(currentResult.grid)
  );

  const emp = allEmployees.find((e) => e.id === employeeId);
  if (!emp || !newGrid[employeeId] || !newGrid[employeeId][date]) {
    return { updatedResult: currentResult, isBreach: false };
  }

  const currentCell = newGrid[employeeId][date];
  if (currentCell.status === 'L') {
    return {
      updatedResult: currentResult,
      isBreach: true,
      message: 'Cannot allocate Office attendance on an approved Leave day.'
    };
  }

  if (currentCell.status === targetStatus) {
    return { updatedResult: currentResult, isBreach: false };
  }

  // Update cell
  if (targetStatus === 'O') {
    newGrid[employeeId][date] = {
      ...currentCell,
      status: 'O',
      isManualOverride: true,
      overridePreviousStatus: currentCell.status,
      seatNumber: currentResult.fixedSeatAssignments[employeeId] || 1
    };
  } else {
    newGrid[employeeId][date] = {
      ...currentCell,
      status: 'W',
      isManualOverride: true,
      overridePreviousStatus: currentCell.status,
      seatNumber: undefined
    };
  }

  // Recalculate daily occupancies
  let hasAnyOverCapacity = false;
  let totalUtilSum = 0;

  const newDailyOccupancies = currentResult.dailyOccupancies.map((day) => {
    if (day.date !== date) {
      totalUtilSum += day.utilisationPct;
      return day;
    }

    let seniorsPresent = 0;
    let professionalsPresent = 0;

    Object.keys(newGrid).forEach((eId) => {
      const cell = newGrid[eId][date];
      if (cell && cell.status === 'O') {
        const e = allEmployees.find((x) => x.id === eId);
        if (e?.designation === 'Professional') {
          professionalsPresent++;
        } else if (e) {
          seniorsPresent++;
        }
      }
    });

    const totalOccupied = seniorsPresent + professionalsPresent;
    const blockedCount = getBlockedSeatNumbers(seatBlocks, date).size;
    const effectiveSeats = Math.max(0, seatCount - blockedCount);
    const vacantSeats = Math.max(0, effectiveSeats - totalOccupied);
    const utilPct = effectiveSeats > 0 ? Math.min(100, Math.round((totalOccupied / effectiveSeats) * 100)) : 0;
    totalUtilSum += utilPct;

    if (totalOccupied > effectiveSeats) {
      hasAnyOverCapacity = true;
    }

    return {
      ...day,
      seniorsPresent,
      professionalsPresent,
      totalOccupied,
      vacantSeats,
      utilisationPct: utilPct,
      isOverCapacity: totalOccupied > effectiveSeats
    };
  });

  // Recalculate employee compliance
  let compliantCount = 0;
  let nonCompliantCount = 0;

  const newSummaries = currentResult.employeeSummaries.map((summary) => {
    let officeCount = 0;
    currentResult.workingDays.forEach((d) => {
      if (newGrid[summary.employeeId]?.[d]?.status === 'O') {
        officeCount++;
      }
    });

    if (summary.isFullyOnLeave) {
      return summary;
    }

    const isCompliant = officeCount >= summary.requiredOfficeDays;
    const shortfall = Math.max(0, summary.requiredOfficeDays - officeCount);
    const achievedPct = summary.availableWorkingDays > 0 ? Math.round((officeCount / summary.availableWorkingDays) * 100) : 0;

    if (isCompliant) compliantCount++;
    else nonCompliantCount++;

    return {
      ...summary,
      allocatedOfficeDays: officeCount,
      achievedPct,
      isCompliant,
      shortfallDays: shortfall,
      statusText: (isCompliant ? 'Compliant' : 'Shortfall') as 'Compliant' | 'Shortfall'
    };
  });

  const updatedResult: AllocationResult = {
    ...currentResult,
    grid: newGrid,
    dailyOccupancies: newDailyOccupancies,
    employeeSummaries: newSummaries,
    fullyCompliantCount: compliantCount,
    nonCompliantCount: nonCompliantCount,
    avgDailyUtilisationPct: currentResult.workingDays.length > 0 ? Math.round(totalUtilSum / currentResult.workingDays.length) : 0,
    manualOverridesCount: currentResult.manualOverridesCount + 1
  };

  return {
    updatedResult,
    isBreach: hasAnyOverCapacity,
    message: hasAnyOverCapacity ? `Warning: Seat capacity exceeded on ${date} (${newDailyOccupancies.find(d => d.date === date)?.totalOccupied}/${seatCount} seats)` : undefined
  };
}

/**
 * Acceptance Tests Suite (T1 - T8)
 * Verifies key constraints and algorithmic invariants.
 */
export function runAcceptanceTests(
  result: AllocationResult,
  config: {
    seatCount: number;
    employees: Employee[];
    leaves: LeaveRecord[];
    holidays: Holiday[];
    policy: PolicySettings;
    period: RosterPeriodConfig;
  }
): AcceptanceTestResult[] {
  const tests: AcceptanceTestResult[] = [];
  const { seatCount, employees, leaves, holidays, policy, period } = config;
  const seniorDesignations: Designation[] = ['MD', 'ED', 'VP'];

  // T1: No day ever exceeds the seat count (in auto-allocated state)
  const overCapacityDays = result.dailyOccupancies.filter((d) => d.totalOccupied > config.seatCount);
  tests.push({
    id: 'T1',
    name: 'T1 — Strict Seat Capacity Limit',
    passed: overCapacityDays.length === 0,
    message: overCapacityDays.length === 0
      ? `PASS: On all ${result.workingDays.length} working days, total occupants never exceeded the seat limit of ${config.seatCount}.`
      : `FAIL: Capacity exceeded on ${overCapacityDays.map((d) => `${d.date} (${d.totalOccupied}/${config.seatCount})`).join(', ')}.`
  });

  // T2: Every MD/ED/VP present in office occupies their assigned fixed seat number
  let t2Passed = true;
  const t2Violations: string[] = [];
  employees.forEach((emp) => {
    if (seniorDesignations.includes(emp.designation)) {
      const assignedFixedSeat = result.fixedSeatAssignments[emp.id];
      result.workingDays.forEach((d) => {
        const cell = result.grid[emp.id]?.[d];
        if (cell?.status === 'O' && cell.seatNumber !== assignedFixedSeat) {
          t2Passed = false;
          t2Violations.push(`${emp.name} (${emp.designation}) seated in #${cell.seatNumber} instead of fixed #${assignedFixedSeat} on ${d}`);
        }
      });
    }
  });
  tests.push({
    id: 'T2',
    name: 'T2 — Senior Fixed Seat Preservation',
    passed: t2Passed,
    message: t2Passed
      ? 'PASS: All senior leaders (MD, ED, VP) always occupy their exact assigned fixed seat whenever in office.'
      : `FAIL: Fixed seat violations detected: ${t2Violations.slice(0, 3).join('; ')}.`
  });

  // T3: A fixed seat is only allotted to a Professional on a day its owner is absent
  let t3Passed = true;
  const t3Violations: string[] = [];
  const seniorMap = new Map<string, Employee>();
  employees.filter((e) => seniorDesignations.includes(e.designation)).forEach((s) => seniorMap.set(s.id, s));

  result.workingDays.forEach((d) => {
    // For each fixed seat
    seniorMap.forEach((senior, seniorId) => {
      const seniorSeat = result.fixedSeatAssignments[seniorId];
      const isSeniorPresent = result.grid[seniorId]?.[d]?.status === 'O';

      // Check if any professional is allocated this seat today
      employees.filter((e) => e.designation === 'Professional').forEach((prof) => {
        const profCell = result.grid[prof.id]?.[d];
        if (profCell?.status === 'O' && profCell.seatNumber === seniorSeat && isSeniorPresent) {
          t3Passed = false;
          t3Violations.push(`Seat #${seniorSeat} occupied simultaneously by ${senior.name} and ${prof.name} on ${d}`);
        }
      });
    });
  });
  tests.push({
    id: 'T3',
    name: 'T3 — Valid Fixed-Seat Backfill Rule',
    passed: t3Passed,
    message: t3Passed
      ? 'PASS: Fixed senior seats are released into the hot-desk pool ONLY when their senior owner is working from home or on leave.'
      : `FAIL: Backfill collision: ${t3Violations.slice(0, 3).join('; ')}.`
  });

  // T4: Where supply is sufficient, every employee meets or exceeds their minimum %
  const hasSupplyDeficit = result.deficit.hasDeficit;
  const nonCompliant = result.employeeSummaries.filter((s) => !s.isCompliant && !s.isFullyOnLeave);
  const t4Passed = hasSupplyDeficit || nonCompliant.length === 0;
  tests.push({
    id: 'T4',
    name: 'T4 — Compliance Guarantee Under Feasible Supply',
    passed: t4Passed,
    message: !hasSupplyDeficit
      ? `PASS: Full supply available (${result.deficit.supplySeatDays} seat-days vs ${result.deficit.demandSeatDays} demand). 100% of employees met required WFO attendance.`
      : `INFO: Supply is constrained (Deficit of ${result.deficit.deficitSeatDays} seat-days). Shortfall correctly isolated and reported for ${nonCompliant.length} employee(s).`
  });

  // T5: Weekends and public holidays never appear as allocated office days
  let t5Passed = true;
  const holidayDateSet = new Set(holidays.map((h) => h.date));
  // Verify all working days exclude weekends and holidays
  result.workingDays.forEach((d) => {
    if (isWeekend(parseISO(d)) || holidayDateSet.has(d)) {
      t5Passed = false;
    }
  });
  tests.push({
    id: 'T5',
    name: 'T5 — Holiday & Weekend Exclusion Invariant',
    passed: t5Passed,
    message: t5Passed
      ? `PASS: Zero office allocations on Saturdays, Sundays, or confirmed NSE trading holidays.`
      : 'FAIL: Non-working day was included in the active working day set.'
  });

  // T6: No employee is rostered to office on a leave day
  let t6Passed = true;
  const t6Violations: string[] = [];
  leaves.forEach((l) => {
    if (l.type !== 'TRV' && result.grid[l.employeeId]?.[l.date]?.status === 'O') {
      t6Passed = false;
      const emp = employees.find((e) => e.id === l.employeeId);
      t6Violations.push(`${emp?.name || l.employeeId} on ${l.date} (${l.type})`);
    }
  });
  tests.push({
    id: 'T6',
    name: 'T6 — Leave Protection Invariant',
    passed: t6Passed,
    message: t6Passed
      ? 'PASS: Zero office allocations on approved leave dates (PL, SL, ML, PTL, EL, CO).'
      : `FAIL: Leave collision detected: ${t6Violations.slice(0, 3).join('; ')}.`
  });

  // T7: Seats_short is reported whenever Demand_seatdays > Supply_seatdays
  let t7Passed = true;
  if (result.deficit.demandSeatDays > result.deficit.supplySeatDays) {
    t7Passed = result.deficit.seatsShort > 0 && result.deficit.hasDeficit;
  } else {
    t7Passed = result.deficit.seatsShort === 0 && !result.deficit.hasDeficit;
  }
  tests.push({
    id: 'T7',
    name: 'T7 — Transparent Deficit Calculation Math',
    passed: t7Passed,
    message: t7Passed
      ? `PASS: Deficit math verified (Demand: ${result.deficit.demandSeatDays}, Supply: ${result.deficit.supplySeatDays}, Deficit: ${result.deficit.deficitSeatDays} seat-days -> ${result.deficit.seatsShort} seats short).`
      : 'FAIL: Deficit reporting formula mismatch.'
  });

  // T8: Determinism — Re-running with identical inputs produces an identical roster
  const secondRun = allocateRoster({
    seatCount,
    employees,
    leaves,
    holidays,
    policy,
    period,
    seatBlocks: config.employees ? [] : []
  });

  let t8Passed = true;
  result.workingDays.forEach((d) => {
    employees.forEach((emp) => {
      const c1 = result.grid[emp.id]?.[d];
      const c2 = secondRun.grid[emp.id]?.[d];
      if (c1?.status !== c2?.status || c1?.seatNumber !== c2?.seatNumber) {
        t8Passed = false;
      }
    });
  });

  tests.push({
    id: 'T8',
    name: 'T8 — Algorithmic Determinism & Seed Invariance',
    passed: t8Passed,
    message: t8Passed
      ? 'PASS: Consecutive allocation runs with identical inputs produced 100% bit-for-bit identical rosters and seat assignments.'
      : 'FAIL: Allocation is non-deterministic.'
  });

  return tests;
}
