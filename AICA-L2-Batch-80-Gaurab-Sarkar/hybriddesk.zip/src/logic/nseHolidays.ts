import { Holiday } from '../types';
import { format, isWeekend, parseISO } from 'date-fns';

/**
 * Standard NSE Capital-Market Trading Holidays (2026).
 * Administrators can edit, delete, add custom holidays, or reset to this list.
 */
export const DEFAULT_NSE_HOLIDAYS_2026: Omit<Holiday, 'id'>[] = [
  { date: '2026-01-26', day: 'Monday', name: 'Republic Day', source: 'NSE' },
  { date: '2026-02-17', day: 'Tuesday', name: 'Mahashivratri', source: 'NSE' },
  { date: '2026-03-03', day: 'Tuesday', name: 'Holi', source: 'NSE' },
  { date: '2026-03-26', day: 'Thursday', name: 'Shri Ram Navami', source: 'NSE' },
  { date: '2026-03-31', day: 'Tuesday', name: 'Mahavir Jayanti', source: 'NSE' },
  { date: '2026-04-03', day: 'Friday', name: 'Good Friday', source: 'NSE' },
  { date: '2026-04-14', day: 'Tuesday', name: 'Dr. Baba Saheb Ambedkar Jayanti', source: 'NSE' },
  { date: '2026-05-01', day: 'Friday', name: 'Maharashtra Day', source: 'NSE' },
  { date: '2026-05-28', day: 'Thursday', name: 'Bakri Id (Id-Ul-Adha)', source: 'NSE' },
  { date: '2026-06-26', day: 'Friday', name: 'Muharram', source: 'NSE' },
  { date: '2026-08-15', day: 'Saturday', name: 'Independence Day', source: 'NSE' },
  { date: '2026-09-14', day: 'Monday', name: 'Ganesh Chaturthi', source: 'NSE' },
  { date: '2026-10-02', day: 'Friday', name: 'Mahatma Gandhi Jayanti', source: 'NSE' },
  { date: '2026-10-20', day: 'Tuesday', name: 'Dussehra', source: 'NSE' },
  { date: '2026-11-08', day: 'Sunday', name: 'Diwali Laxmi Pujan (Muhurat Session)', source: 'NSE' },
  { date: '2026-11-10', day: 'Tuesday', name: 'Diwali Balipratipada', source: 'NSE' },
  { date: '2026-11-24', day: 'Tuesday', name: 'Guru Nanak Jayanti', source: 'NSE' },
  { date: '2026-12-25', day: 'Friday', name: 'Christmas', source: 'NSE' }
];

export function getInitialHolidays(): Holiday[] {
  return DEFAULT_NSE_HOLIDAYS_2026.map((item, index) => {
    const parsedDate = parseISO(item.date);
    const dayWeekend = isWeekend(parsedDate);
    return {
      id: `hol-${index + 1}-${item.date}`,
      ...item,
      day: format(parsedDate, 'EEEE'),
      isWeekend: dayWeekend
    };
  });
}
