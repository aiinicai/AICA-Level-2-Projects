# Tax Audit Financial Statement Analyser

**Financial Statement Review & Risk Identification System**

A Windows desktop application for Chartered Accountants carrying out
preliminary analytical review of financial statements in connection with tax
audit work under India's direct tax law.

The application reads uploaded financial statements, maps the line items to
canonical financial heads, re-performs the arithmetic of the accounts,
computes year-on-year movements and ratios, identifies matters requiring
professional examination, drafts client queries, and produces a formatted Word
report.

---

## Disclaimer

> This application is an **analytical assistant**. It is **not** a substitute
> for professional judgement.
>
> Every report it produces carries the following statement, which governs the
> use of its output:
>
> *"This report is an automated preliminary analytical report based solely
> upon documents uploaded into the application. Observations represent matters
> requiring professional examination and do not constitute a final tax audit
> opinion, legal opinion, assessment of tax liability or determination of
> statutory non-compliance. The Chartered Accountant / tax professional must
> independently verify the underlying records and the law applicable to the
> relevant assessment year."*

The application never asserts that a statutory provision has been breached. It
identifies areas for verification, using cautious language throughout, and
records against every finding whether it is a **FACT**, a **CALCULATION**, an
**OBSERVATION**, a **POTENTIAL TAX ISSUE** or a matter where **VERIFICATION
[IS] REQUIRED**.

Any reference to a Form 3CD reporting area is **indicative only** and carries
the warning that it *"must be independently verified against the Income-tax
Act, Income-tax Rules and Form 3CD applicable for the relevant assessment
year."*

### Privacy

All processing happens on the computer running the application. No financial
data is transmitted anywhere. The Settings screen allows an API key to be
stored for a possible future AI-assisted feature, but **this version makes no
network calls of any kind** and the analysis is entirely rule-based and
deterministic.

---

## What it does

| Stage | What happens |
|---|---|
| **Create case** | Assessee particulars, PAN, constitution, year, turnover. Case IDs are allocated as `TAXAUDIT-2026-0001`. |
| **Upload** | Drag and drop PDF, Excel, Word, CSV or image files, categorised by document type. |
| **Extract** | Text and ruled tables are read per page. Pages with no extractable text are treated as scanned and passed to OCR. |
| **Map** | Messy real-world headings ("Sundry Debtors", "Gross Receipts") are matched to canonical heads by exact, phrase, token-overlap and fuzzy matching, each with a High/Medium/Low confidence grade. |
| **Verify** | Every figure is presented for the CA to check and correct. Low-confidence rows are highlighted in yellow. |
| **Validate** | Total Assets vs Total Equity & Liabilities; the asset schedule is re-cast; revenue less expenses is re-performed against reported Profit Before Tax. |
| **Analyse** | Year-on-year movement with configurable materiality bands, and twelve ratios across both years with plain-language commentary. |
| **Risk** | Seventeen review areas produce classified findings, each with its source document and page, why it was flagged, its tax audit relevance, the recommended verification and the documents required. |
| **Query** | Professional client queries are drafted from the findings and exported to Word. |
| **Report** | A fourteen-section Word report on A4, with header, footer, page numbers and the mandatory disclaimer. |

### Risk review areas

Turnover and revenue - cash transactions - loans and deposits - trade
receivables - trade payables and MSME dues - statutory dues - expense analysis
- tax deduction at source - allowability of specific heads - capital versus
revenue expenditure - personal and non-business expenditure - related party
review - depreciation and fixed assets - provisions and contingent liabilities
- accounting validation - data quality - tax audit applicability.

Statutory references are confined to the provisions the application is
configured to mention, and are always framed as matters for verification:
Sections 40A(3), 269SS, 269ST, 269T, 68, 43B, 40(a)(ia) and 40A(2)(b).

---

## Folder structure

```
tax_audit_analyser/
  main.py                  Application entry point
  paths.py                 Path resolution (works in dev and frozen builds)
  ui/
    dashboard.py           Home screen with the five action cards
    new_case.py            Case particulars form
    upload.py              Drag-and-drop upload + background analysis
    verification.py        Editable "Verify Extracted Financial Data" table
    analysis_dashboard.py  Risk tiles, findings table, detailed findings
    reports.py             Generated report browser
    settings.py            Firm details, thresholds, AI/API settings
    case_management.py     Existing cases: open/edit/duplicate/delete
    main_window.py         Window shell and navigation wiring
    theme.py               Shared palette and style sheet
  core/
    pdf_extractor.py       pdfplumber + PyMuPDF text and table extraction
    ocr_engine.py          Optional pytesseract OCR, degrades gracefully
    doc_extractor.py       Word / Excel / CSV / image routing
    financial_mapper.py    Synonym dictionary and fuzzy heading matching
    analysis_engine.py     Consolidation, validation, year-on-year analysis
    ratio_engine.py        Twelve ratios with commentary
    tax_risk_engine.py     Risk identification (the core value-add)
    query_generator.py     Draft client queries
    report_generator.py    Word report generation
    pipeline.py            End-to-end orchestration
    ai_provider.py         Provider interface + key storage (no network calls)
    logging_setup.py       Rotating log configuration
  database/
    schema.sql             SQLite schema
    db.py                  Connection handling, migration, typed CRUD
    models.py              Dataclasses mirroring the tables
  config/                  Editable JSON: thresholds, Form 3CD mapping
  reports/                 Generated Word reports
  uploads/                 Uploaded documents, organised per case
  assets/                  Application icon
  tests/                   pytest suite + sample statement generator
requirements.txt
README.md
USER_MANUAL.md
build_exe.bat
TaxAuditAnalyser.spec
```

---

## Running from source

Requires **Python 3.11 or later**.

```bash
# 1. Install the dependencies
pip install -r requirements.txt

# 2. Run the application
python tax_audit_analyser/main.py
```

Alternatively, from the project root:

```bash
python -m tax_audit_analyser.main
```

### Optional: OCR for scanned documents

To read scanned (image-only) PDFs, install the Tesseract OCR engine:

- **Windows:** <https://github.com/UB-Mannheim/tesseract/wiki>
- **Debian / Ubuntu:** `sudo apt install tesseract-ocr`
- **macOS:** `brew install tesseract`

Tesseract is entirely optional. Without it the application runs normally; any
scanned page is simply reported as requiring manual entry, and the Settings
screen shows the current OCR status.

---

## Running the tests

```bash
# The whole suite (Qt runs headless automatically)
python -m pytest

# A single area
python -m pytest tax_audit_analyser/tests/test_risk_engine.py -v
```

The suite generates its own sample financial statements with deliberately
planted risk scenarios, then exercises extraction, mapping, validation
arithmetic, ratios, risk flag generation, database round-trips, Word report
production and every GUI screen.

### End-to-end smoke test

```bash
python -m tax_audit_analyser.tests.smoke_test
```

This runs the complete journey — create case, upload sample PDFs, extract,
map, simulate a CA's correction on the verification screen, re-analyse,
risk-flag and generate a real Word report — and prints a step-by-step trace.
It exits non-zero if anything fails, so it doubles as a post-install check.

---

## Building the Windows executable

On a Windows machine with Python 3.11+ installed and added to `PATH`:

```bat
build_exe.bat
```

The script creates a virtual environment, installs the dependencies, runs the
test suite, and builds a one-folder distribution using `TaxAuditAnalyser.spec`.
The finished application is placed in `TaxAuditAnalyser_Windows\`.

To build manually:

```bat
python -m venv build_venv
build_venv\Scripts\activate
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --clean TaxAuditAnalyser.spec
```

**Distribute the whole `TaxAuditAnalyser_Windows` folder**, not just the
`.exe`. The executable depends on the `_internal` folder beside it.

### Where data is stored

When running from source, the database, uploads, reports and logs live inside
the `tax_audit_analyser/` folder. In a frozen build they are written to the
user's profile (`%LOCALAPPDATA%\TaxAuditAnalyser`), because a PyInstaller
bundle's own folder is temporary and may not be writable.

Setting the `TAXAUDIT_DATA_DIR` environment variable overrides the location in
both cases.

---

## Licence and professional responsibility

The output of this application is a working paper, not an opinion. The
Chartered Accountant remains wholly responsible for the audit, for verifying
the underlying records, and for determining the law applicable to the relevant
assessment year.
