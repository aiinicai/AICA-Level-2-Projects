"""Plain dataclasses mirroring the SQLite tables.

These are deliberately dependency-free (no ORM) so the core engines can be
unit-tested without a database and the GUI can pass typed objects around.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional

# --------------------------------------------------------------- vocabularies

CONSTITUTIONS = [
    "Individual",
    "HUF",
    "Partnership Firm",
    "LLP",
    "Private Limited Company",
    "Public Limited Company",
    "Trust",
    "Society",
    "Section 8 Company",
    "AOP",
    "BOI",
    "Others",
]

TAX_AUDIT_APPLICABILITY = ["To be determined", "Yes", "No"]

DOCUMENT_TYPES = [
    "Profit & Loss Account",
    "Balance Sheet",
    "Notes to Accounts",
    "Schedules",
    "Trial Balance",
    "Previous Year Financial Statements",
    "Form 3CD",
    "Income Tax Computation",
    "GST Annual Return",
    "Other Documents",
]

DOCUMENT_STATUSES = ["Uploaded", "Processing", "Extracted", "Error", "Analysed"]

CASE_STATUSES = [
    "Draft",
    "Documents Uploaded",
    "Extraction Completed",
    "Verified",
    "Analysis Completed",
    "Report Generated",
]

# Risk levels, highest severity first (used for sorting throughout the app).
RISK_LEVELS = ["HIGH", "MEDIUM", "REVIEW REQUIRED", "INFORMATIONAL"]
RISK_LEVEL_ORDER = {level: index for index, level in enumerate(RISK_LEVELS)}

# The finding_type field keeps statements of fact separate from cautious
# tax observations. This distinction is a hard requirement of the app's
# legal-accuracy rule and must never be collapsed.
FINDING_TYPES = [
    "FACT",
    "CALCULATION",
    "OBSERVATION",
    "POTENTIAL TAX ISSUE",
    "VERIFICATION REQUIRED",
]

CONFIDENCE_LEVELS = ["High", "Medium", "Low"]


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------- records


@dataclass
class Case:
    case_id: str = ""
    assessee_name: str = ""
    pan: str = ""
    assessment_year: str = ""
    financial_year: str = ""
    constitution: str = "Individual"
    nature_of_business: str = ""
    gstin: str = ""
    turnover: Optional[float] = None
    tax_audit_applicable: str = "To be determined"
    auditor_name: str = ""
    remarks: str = ""
    status: str = "Draft"
    date_created: str = field(default_factory=_now)
    date_modified: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Document:
    case_id: str = ""
    file_name: str = ""
    stored_path: str = ""
    document_type: str = "Other Documents"
    file_type: str = ""
    pages: int = 0
    status: str = "Uploaded"
    ocr_used: bool = False
    error_message: str = ""
    date_uploaded: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["ocr_used"] = int(bool(self.ocr_used))
        return data


@dataclass
class ExtractedFigure:
    """One financial figure recovered from a source document.

    Always carries its provenance (document + page) and a confidence grade so
    the verification screen can surface weak matches to the Chartered
    Accountant before any analysis is relied upon.
    """

    case_id: str = ""
    canonical_head: str = ""
    raw_heading: str = ""
    current_year_amount: Optional[float] = None
    previous_year_amount: Optional[float] = None
    source_document: str = ""
    source_page: Optional[int] = None
    confidence: str = "Medium"
    match_score: float = 0.0
    statement_type: str = "OTHER"
    document_id: Optional[int] = None
    is_verified: bool = False
    is_manual_entry: bool = False
    date_created: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["is_verified"] = int(bool(self.is_verified))
        data["is_manual_entry"] = int(bool(self.is_manual_entry))
        return data


@dataclass
class AnalysisResult:
    case_id: str = ""
    result_type: str = "YOY"
    label: str = ""
    current_year: Optional[float] = None
    previous_year: Optional[float] = None
    change_amount: Optional[float] = None
    change_percent: Optional[float] = None
    materiality: str = ""
    explanation: str = ""
    finding_type: str = "CALCULATION"
    date_created: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RiskFlag:
    """A matter requiring professional examination.

    Wording rule: an observation must never assert a concluded statutory
    violation. Use cautious formulations such as "requires verification for
    possible applicability of ...".
    """

    case_id: str = ""
    risk_level: str = "REVIEW REQUIRED"
    area: str = ""
    observation: str = ""
    amount: Optional[float] = None
    previous_year_amount: Optional[float] = None
    change_percent: Optional[float] = None
    source_document: str = ""
    source_page: Optional[int] = None
    recommended_verification: str = ""
    finding_type: str = "OBSERVATION"
    tax_audit_relevance: str = ""
    documents_to_verify: List[str] = field(default_factory=list)
    potential_3cd_clause: str = ""
    why_flagged: str = ""
    date_created: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["documents_to_verify"] = json.dumps(self.documents_to_verify)
        return data

    @property
    def source(self) -> str:
        """Human-readable provenance string used in tables and reports."""
        if self.source_document and self.source_page:
            return f"{self.source_document}, p.{self.source_page}"
        if self.source_document:
            return self.source_document
        return "Derived from extracted financial data"

    @property
    def sort_key(self) -> int:
        return RISK_LEVEL_ORDER.get(self.risk_level, 99)


@dataclass
class AuditQuery:
    case_id: str = ""
    risk_flag_id: Optional[int] = None
    query_number: int = 0
    area: str = ""
    query_text: str = ""
    documents_sought: str = ""
    status: str = "Open"
    date_created: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ReportRecord:
    case_id: str = ""
    report_type: str = "Main Analysis Report"
    file_path: str = ""
    file_size: int = 0
    date_generated: str = field(default_factory=_now)
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def risk_flag_from_row(row: Dict[str, Any]) -> RiskFlag:
    """Rehydrate a RiskFlag from a sqlite row mapping."""
    data = dict(row)
    raw_docs = data.get("documents_to_verify") or "[]"
    try:
        docs = json.loads(raw_docs) if isinstance(raw_docs, str) else list(raw_docs)
    except (ValueError, TypeError):
        docs = [raw_docs] if raw_docs else []
    data["documents_to_verify"] = docs
    valid = {f for f in RiskFlag.__dataclass_fields__}
    return RiskFlag(**{k: v for k, v in data.items() if k in valid})


def extracted_figure_from_row(row: Dict[str, Any]) -> ExtractedFigure:
    data = dict(row)
    data["is_verified"] = bool(data.get("is_verified"))
    data["is_manual_entry"] = bool(data.get("is_manual_entry"))
    valid = {f for f in ExtractedFigure.__dataclass_fields__}
    return ExtractedFigure(**{k: v for k, v in data.items() if k in valid})


def case_from_row(row: Dict[str, Any]) -> Case:
    valid = {f for f in Case.__dataclass_fields__}
    return Case(**{k: v for k, v in dict(row).items() if k in valid})
