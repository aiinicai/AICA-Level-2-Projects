-- Tax Audit Financial Statement Analyser -- SQLite schema
-- Applied on first run and idempotently on every start-up (CREATE IF NOT EXISTS).

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- Cases ----
CREATE TABLE IF NOT EXISTS Cases (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id             TEXT    NOT NULL UNIQUE,   -- TAXAUDIT-2026-0001
    assessee_name       TEXT    NOT NULL,
    pan                 TEXT,
    assessment_year     TEXT,
    financial_year      TEXT,
    constitution        TEXT,
    nature_of_business  TEXT,
    gstin               TEXT,
    turnover            REAL,
    tax_audit_applicable TEXT,                     -- Yes / No / To be determined
    auditor_name        TEXT,
    remarks             TEXT,
    status              TEXT    NOT NULL DEFAULT 'Draft',
    date_created        TEXT    NOT NULL,
    date_modified       TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cases_case_id ON Cases(case_id);
CREATE INDEX IF NOT EXISTS idx_cases_pan     ON Cases(pan);

-- ------------------------------------------------------------ Documents ----
CREATE TABLE IF NOT EXISTS Documents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id         TEXT    NOT NULL,
    file_name       TEXT    NOT NULL,
    stored_path     TEXT    NOT NULL,
    document_type   TEXT    NOT NULL,
    file_type       TEXT,
    pages           INTEGER DEFAULT 0,
    status          TEXT    NOT NULL DEFAULT 'Uploaded',
    ocr_used        INTEGER DEFAULT 0,
    error_message   TEXT,
    date_uploaded   TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_documents_case ON Documents(case_id);

-- --------------------------------------------- ExtractedFinancialData ----
CREATE TABLE IF NOT EXISTS ExtractedFinancialData (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id             TEXT    NOT NULL,
    document_id         INTEGER,
    statement_type      TEXT,              -- PL / BS / OTHER
    canonical_head      TEXT    NOT NULL,  -- mapped financial head
    raw_heading         TEXT,              -- heading exactly as found in the document
    current_year_amount REAL,
    previous_year_amount REAL,
    source_document     TEXT,
    source_page         INTEGER,
    confidence          TEXT    DEFAULT 'Medium',   -- High / Medium / Low
    match_score         REAL,
    is_verified         INTEGER DEFAULT 0,
    is_manual_entry     INTEGER DEFAULT 0,
    date_created        TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE,
    FOREIGN KEY (document_id) REFERENCES Documents(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_efd_case ON ExtractedFinancialData(case_id);
CREATE INDEX IF NOT EXISTS idx_efd_head ON ExtractedFinancialData(canonical_head);

-- ------------------------------------------------------ AnalysisResults ----
CREATE TABLE IF NOT EXISTS AnalysisResults (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id         TEXT    NOT NULL,
    result_type     TEXT    NOT NULL,   -- YOY / RATIO / VALIDATION / SNAPSHOT
    label           TEXT    NOT NULL,
    current_year    REAL,
    previous_year   REAL,
    change_amount   REAL,
    change_percent  REAL,
    materiality     TEXT,               -- Normal / Review / Significant / High Movement
    explanation     TEXT,
    finding_type    TEXT DEFAULT 'CALCULATION',
    date_created    TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ar_case ON AnalysisResults(case_id);
CREATE INDEX IF NOT EXISTS idx_ar_type ON AnalysisResults(result_type);

-- ------------------------------------------------------------ RiskFlags ----
CREATE TABLE IF NOT EXISTS RiskFlags (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id                  TEXT    NOT NULL,
    risk_level               TEXT    NOT NULL,  -- HIGH / MEDIUM / REVIEW REQUIRED / INFORMATIONAL
    area                     TEXT    NOT NULL,
    observation              TEXT    NOT NULL,
    amount                   REAL,
    previous_year_amount     REAL,
    change_percent           REAL,
    source_document          TEXT,
    source_page              INTEGER,
    recommended_verification TEXT,
    finding_type             TEXT    NOT NULL DEFAULT 'OBSERVATION',
    tax_audit_relevance      TEXT,
    documents_to_verify      TEXT,              -- JSON list
    potential_3cd_clause     TEXT,
    why_flagged              TEXT,
    date_created             TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_rf_case  ON RiskFlags(case_id);
CREATE INDEX IF NOT EXISTS idx_rf_level ON RiskFlags(risk_level);

-- --------------------------------------------------------- AuditQueries ----
CREATE TABLE IF NOT EXISTS AuditQueries (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id         TEXT    NOT NULL,
    risk_flag_id    INTEGER,
    query_number    INTEGER,
    area            TEXT,
    query_text      TEXT    NOT NULL,
    documents_sought TEXT,
    status          TEXT DEFAULT 'Open',
    date_created    TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE,
    FOREIGN KEY (risk_flag_id) REFERENCES RiskFlags(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_aq_case ON AuditQueries(case_id);

-- -------------------------------------------------------------- Reports ----
CREATE TABLE IF NOT EXISTS Reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id         TEXT    NOT NULL,
    report_type     TEXT    NOT NULL DEFAULT 'Main Analysis Report',
    file_path       TEXT    NOT NULL,
    file_size       INTEGER,
    date_generated  TEXT    NOT NULL,
    FOREIGN KEY (case_id) REFERENCES Cases(case_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_rep_case ON Reports(case_id);

-- -------------------------------------------------- ApplicationSettings ----
CREATE TABLE IF NOT EXISTS ApplicationSettings (
    key           TEXT PRIMARY KEY,
    value         TEXT,
    date_modified TEXT
);

-- Schema version marker used by the migration helper in db.py.
CREATE TABLE IF NOT EXISTS SchemaVersion (
    version    INTEGER PRIMARY KEY,
    applied_on TEXT
);
