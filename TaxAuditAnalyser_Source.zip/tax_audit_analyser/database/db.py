"""SQLite connection handling, first-run migration and typed CRUD helpers.

Design notes
------------
* One module-level :class:`Database` instance is used by the GUI, obtained via
  :func:`get_database`. Tests build their own instance against a temp path.
* ``sqlite3`` connections are created per-operation through a context manager,
  which keeps the code safe when Qt calls in from different threads.
* Every public method wraps failures and logs them; callers get either a
  sensible empty value or a :class:`DatabaseError` with a friendly message.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional

from ..core.logging_setup import get_logger
from ..paths import database_path, schema_path
from .models import (
    AnalysisResult,
    AuditQuery,
    Case,
    Document,
    ExtractedFigure,
    ReportRecord,
    RiskFlag,
    case_from_row,
    extracted_figure_from_row,
    risk_flag_from_row,
)

log = get_logger(__name__)

SCHEMA_VERSION = 1


class DatabaseError(Exception):
    """Raised with a message suitable for direct display to the user."""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Database:
    """Thin, explicit data-access layer over SQLite."""

    def __init__(self, db_path: Optional[Path] = None) -> None:
        self.db_path = Path(db_path) if db_path else database_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialise()

    # ------------------------------------------------------------ plumbing

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Yield a connection with row access by name and FKs enforced."""
        conn = None
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=30.0)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            yield conn
            conn.commit()
        except sqlite3.Error as exc:
            if conn is not None:
                conn.rollback()
            log.exception("Database operation failed: %s", exc)
            raise DatabaseError(
                "A database error occurred. Please check logs/app.log for details.\n"
                f"Technical detail: {exc}"
            ) from exc
        finally:
            if conn is not None:
                conn.close()

    def initialise(self) -> None:
        """Create the schema on first run; safe to call on every start-up."""
        try:
            sql_file = schema_path()
            if not sql_file.exists():
                raise DatabaseError(
                    f"Database schema file not found at {sql_file}. "
                    "The installation appears incomplete."
                )
            script = sql_file.read_text(encoding="utf-8")
            with self.connect() as conn:
                conn.executescript(script)
                row = conn.execute(
                    "SELECT MAX(version) AS v FROM SchemaVersion"
                ).fetchone()
                current = row["v"] if row and row["v"] is not None else 0
                if current < SCHEMA_VERSION:
                    self._migrate(conn, current)
                    conn.execute(
                        "INSERT OR REPLACE INTO SchemaVersion (version, applied_on) "
                        "VALUES (?, ?)",
                        (SCHEMA_VERSION, _now()),
                    )
                    log.info(
                        "Database migrated from version %s to %s at %s",
                        current,
                        SCHEMA_VERSION,
                        self.db_path,
                    )
        except DatabaseError:
            raise
        except Exception as exc:
            log.exception("Database initialisation failed")
            raise DatabaseError(f"Could not initialise the database: {exc}") from exc

    def _migrate(self, conn: sqlite3.Connection, from_version: int) -> None:
        """Apply incremental migrations.

        Version 0 -> 1 is the initial creation, already handled by schema.sql.
        Future versions add their ALTER TABLE steps here, guarded by
        ``_column_exists`` so re-running is harmless.
        """
        if from_version < 1:
            self._seed_default_settings(conn)

    @staticmethod
    def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
        rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
        return any(r["name"] == column for r in rows)

    def _seed_default_settings(self, conn: sqlite3.Connection) -> None:
        defaults = {
            "firm_name": "",
            "report_font": "Book Antiqua",
            "report_body_size": "11",
            "threshold_review": "10",
            "threshold_significant": "20",
            "threshold_high": "50",
            "ai_provider": "None",
            "ai_consent_given": "0",
        }
        for key, value in defaults.items():
            conn.execute(
                "INSERT OR IGNORE INTO ApplicationSettings (key, value, date_modified) "
                "VALUES (?, ?, ?)",
                (key, value, _now()),
            )

    # ---------------------------------------------------------------- cases

    def generate_case_id(self, year: Optional[int] = None) -> str:
        """Produce the next sequential case id, e.g. ``TAXAUDIT-2026-0001``."""
        year = year or datetime.now().year
        prefix = f"TAXAUDIT-{year}-"
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT case_id FROM Cases WHERE case_id LIKE ?", (prefix + "%",)
            ).fetchall()
        highest = 0
        for row in rows:
            tail = str(row["case_id"]).rsplit("-", 1)[-1]
            if tail.isdigit():
                highest = max(highest, int(tail))
        return f"{prefix}{highest + 1:04d}"

    def create_case(self, case: Case) -> str:
        """Insert a case, allocating a case_id when one is not supplied."""
        if not case.assessee_name.strip():
            raise DatabaseError("Assessee Name is required to create a case.")
        if not case.case_id:
            case.case_id = self.generate_case_id()
        case.date_created = case.date_created or _now()
        case.date_modified = _now()
        data = case.to_dict()
        data.pop("id", None)
        columns = ", ".join(data)
        placeholders = ", ".join("?" for _ in data)
        try:
            with self.connect() as conn:
                conn.execute(
                    f"INSERT INTO Cases ({columns}) VALUES ({placeholders})",
                    tuple(data.values()),
                )
        except DatabaseError as exc:
            if "UNIQUE" in str(exc):
                raise DatabaseError(
                    f"Case ID {case.case_id} already exists. Please retry."
                ) from exc
            raise
        log.info("Created case %s for %s", case.case_id, case.assessee_name)
        return case.case_id

    def update_case(self, case: Case) -> None:
        data = case.to_dict()
        data.pop("id", None)
        data.pop("case_id", None)
        data["date_modified"] = _now()
        assignments = ", ".join(f"{k} = ?" for k in data)
        with self.connect() as conn:
            conn.execute(
                f"UPDATE Cases SET {assignments} WHERE case_id = ?",
                tuple(data.values()) + (case.case_id,),
            )

    def update_case_status(self, case_id: str, status: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE Cases SET status = ?, date_modified = ? WHERE case_id = ?",
                (status, _now(), case_id),
            )

    def get_case(self, case_id: str) -> Optional[Case]:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM Cases WHERE case_id = ?", (case_id,)
            ).fetchone()
        return case_from_row(dict(row)) if row else None

    def list_cases(self) -> List[Case]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM Cases ORDER BY datetime(date_created) DESC, id DESC"
            ).fetchall()
        return [case_from_row(dict(r)) for r in rows]

    def delete_case(self, case_id: str) -> None:
        """Remove a case and every dependent record (cascade)."""
        with self.connect() as conn:
            conn.execute("DELETE FROM Cases WHERE case_id = ?", (case_id,))
        log.info("Deleted case %s", case_id)

    def duplicate_case(self, case_id: str) -> Optional[str]:
        """Copy a case's particulars into a fresh Draft case (no documents)."""
        original = self.get_case(case_id)
        if original is None:
            return None
        clone = Case(**original.to_dict())
        clone.id = None
        clone.case_id = self.generate_case_id()
        clone.assessee_name = f"{original.assessee_name} (Copy)"
        clone.status = "Draft"
        clone.date_created = _now()
        clone.date_modified = _now()
        return self.create_case(clone)

    # ------------------------------------------------------------ documents

    def add_document(self, document: Document) -> int:
        data = document.to_dict()
        data.pop("id", None)
        columns = ", ".join(data)
        placeholders = ", ".join("?" for _ in data)
        with self.connect() as conn:
            cursor = conn.execute(
                f"INSERT INTO Documents ({columns}) VALUES ({placeholders})",
                tuple(data.values()),
            )
            return int(cursor.lastrowid)

    def update_document_status(
        self,
        document_id: int,
        status: str,
        pages: Optional[int] = None,
        error_message: str = "",
        ocr_used: Optional[bool] = None,
    ) -> None:
        sets = ["status = ?"]
        values: List[Any] = [status]
        if pages is not None:
            sets.append("pages = ?")
            values.append(pages)
        if error_message:
            sets.append("error_message = ?")
            values.append(error_message)
        if ocr_used is not None:
            sets.append("ocr_used = ?")
            values.append(int(ocr_used))
        values.append(document_id)
        with self.connect() as conn:
            conn.execute(
                f"UPDATE Documents SET {', '.join(sets)} WHERE id = ?", tuple(values)
            )

    def list_documents(self, case_id: str) -> List[Document]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM Documents WHERE case_id = ? ORDER BY id", (case_id,)
            ).fetchall()
        documents: List[Document] = []
        for row in rows:
            data = dict(row)
            data["ocr_used"] = bool(data.get("ocr_used"))
            valid = set(Document.__dataclass_fields__)
            documents.append(Document(**{k: v for k, v in data.items() if k in valid}))
        return documents

    def delete_document(self, document_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM Documents WHERE id = ?", (document_id,))

    # ------------------------------------------------------ extracted data

    def save_extracted_figures(
        self, case_id: str, figures: Iterable[ExtractedFigure], replace: bool = True
    ) -> int:
        """Persist extracted figures; by default replaces the case's prior set."""
        figures = list(figures)
        with self.connect() as conn:
            if replace:
                conn.execute(
                    "DELETE FROM ExtractedFinancialData WHERE case_id = ?", (case_id,)
                )
            count = 0
            for figure in figures:
                figure.case_id = case_id
                data = figure.to_dict()
                data.pop("id", None)
                columns = ", ".join(data)
                placeholders = ", ".join("?" for _ in data)
                conn.execute(
                    f"INSERT INTO ExtractedFinancialData ({columns}) "
                    f"VALUES ({placeholders})",
                    tuple(data.values()),
                )
                count += 1
        log.info("Saved %d extracted figures for case %s", count, case_id)
        return count

    def list_extracted_figures(self, case_id: str) -> List[ExtractedFigure]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM ExtractedFinancialData WHERE case_id = ? "
                "ORDER BY statement_type, id",
                (case_id,),
            ).fetchall()
        return [extracted_figure_from_row(dict(r)) for r in rows]

    def update_extracted_figure(self, figure: ExtractedFigure) -> None:
        if figure.id is None:
            raise DatabaseError("Cannot update a figure that has no database id.")
        data = figure.to_dict()
        data.pop("id", None)
        assignments = ", ".join(f"{k} = ?" for k in data)
        with self.connect() as conn:
            conn.execute(
                f"UPDATE ExtractedFinancialData SET {assignments} WHERE id = ?",
                tuple(data.values()) + (figure.id,),
            )

    # ---------------------------------------------------- analysis results

    def save_analysis_results(
        self, case_id: str, results: Iterable[AnalysisResult], replace: bool = True
    ) -> int:
        results = list(results)
        with self.connect() as conn:
            if replace:
                conn.execute("DELETE FROM AnalysisResults WHERE case_id = ?", (case_id,))
            for result in results:
                result.case_id = case_id
                data = result.to_dict()
                data.pop("id", None)
                columns = ", ".join(data)
                placeholders = ", ".join("?" for _ in data)
                conn.execute(
                    f"INSERT INTO AnalysisResults ({columns}) VALUES ({placeholders})",
                    tuple(data.values()),
                )
        return len(results)

    def list_analysis_results(
        self, case_id: str, result_type: Optional[str] = None
    ) -> List[AnalysisResult]:
        query = "SELECT * FROM AnalysisResults WHERE case_id = ?"
        params: List[Any] = [case_id]
        if result_type:
            query += " AND result_type = ?"
            params.append(result_type)
        query += " ORDER BY id"
        with self.connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()
        valid = set(AnalysisResult.__dataclass_fields__)
        return [
            AnalysisResult(**{k: v for k, v in dict(r).items() if k in valid})
            for r in rows
        ]

    # ------------------------------------------------------------ risk flags

    def save_risk_flags(
        self, case_id: str, flags: Iterable[RiskFlag], replace: bool = True
    ) -> int:
        flags = list(flags)
        with self.connect() as conn:
            if replace:
                conn.execute("DELETE FROM RiskFlags WHERE case_id = ?", (case_id,))
            for flag in flags:
                flag.case_id = case_id
                data = flag.to_dict()
                data.pop("id", None)
                columns = ", ".join(data)
                placeholders = ", ".join("?" for _ in data)
                cursor = conn.execute(
                    f"INSERT INTO RiskFlags ({columns}) VALUES ({placeholders})",
                    tuple(data.values()),
                )
                flag.id = int(cursor.lastrowid)
        log.info("Saved %d risk flags for case %s", len(flags), case_id)
        return len(flags)

    def list_risk_flags(
        self, case_id: str, risk_level: Optional[str] = None
    ) -> List[RiskFlag]:
        query = "SELECT * FROM RiskFlags WHERE case_id = ?"
        params: List[Any] = [case_id]
        if risk_level and risk_level.upper() != "ALL":
            query += " AND risk_level = ?"
            params.append(risk_level.upper())
        query += " ORDER BY id"
        with self.connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()
        flags = [risk_flag_from_row(dict(r)) for r in rows]
        flags.sort(key=lambda f: f.sort_key)
        return flags

    def risk_counts(self, case_id: str) -> Dict[str, int]:
        """Counts per risk level for the dashboard tiles."""
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT risk_level, COUNT(*) AS n FROM RiskFlags "
                "WHERE case_id = ? GROUP BY risk_level",
                (case_id,),
            ).fetchall()
        counts = {"HIGH": 0, "MEDIUM": 0, "REVIEW REQUIRED": 0, "INFORMATIONAL": 0}
        for row in rows:
            counts[str(row["risk_level"])] = int(row["n"])
        return counts

    # --------------------------------------------------------- audit queries

    def save_audit_queries(
        self, case_id: str, queries: Iterable[AuditQuery], replace: bool = True
    ) -> int:
        queries = list(queries)
        with self.connect() as conn:
            if replace:
                conn.execute("DELETE FROM AuditQueries WHERE case_id = ?", (case_id,))
            for query in queries:
                query.case_id = case_id
                data = query.to_dict()
                data.pop("id", None)
                columns = ", ".join(data)
                placeholders = ", ".join("?" for _ in data)
                conn.execute(
                    f"INSERT INTO AuditQueries ({columns}) VALUES ({placeholders})",
                    tuple(data.values()),
                )
        return len(queries)

    def list_audit_queries(self, case_id: str) -> List[AuditQuery]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM AuditQueries WHERE case_id = ? ORDER BY query_number, id",
                (case_id,),
            ).fetchall()
        valid = set(AuditQuery.__dataclass_fields__)
        return [
            AuditQuery(**{k: v for k, v in dict(r).items() if k in valid}) for r in rows
        ]

    # --------------------------------------------------------------- reports

    def add_report(self, report: ReportRecord) -> int:
        data = report.to_dict()
        data.pop("id", None)
        columns = ", ".join(data)
        placeholders = ", ".join("?" for _ in data)
        with self.connect() as conn:
            cursor = conn.execute(
                f"INSERT INTO Reports ({columns}) VALUES ({placeholders})",
                tuple(data.values()),
            )
            return int(cursor.lastrowid)

    def list_reports(self, case_id: Optional[str] = None) -> List[ReportRecord]:
        query = "SELECT * FROM Reports"
        params: tuple = ()
        if case_id:
            query += " WHERE case_id = ?"
            params = (case_id,)
        query += " ORDER BY datetime(date_generated) DESC, id DESC"
        with self.connect() as conn:
            rows = conn.execute(query, params).fetchall()
        valid = set(ReportRecord.__dataclass_fields__)
        return [
            ReportRecord(**{k: v for k, v in dict(r).items() if k in valid})
            for r in rows
        ]

    # -------------------------------------------------------------- settings

    def get_setting(self, key: str, default: str = "") -> str:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT value FROM ApplicationSettings WHERE key = ?", (key,)
            ).fetchone()
        return str(row["value"]) if row and row["value"] is not None else default

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO ApplicationSettings (key, value, date_modified) "
                "VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, "
                "date_modified = excluded.date_modified",
                (key, value, _now()),
            )

    def all_settings(self) -> Dict[str, str]:
        with self.connect() as conn:
            rows = conn.execute("SELECT key, value FROM ApplicationSettings").fetchall()
        return {str(r["key"]): str(r["value"] or "") for r in rows}


_DB_INSTANCE: Optional[Database] = None


def get_database() -> Database:
    """Return the process-wide database instance, creating it on first call."""
    global _DB_INSTANCE
    if _DB_INSTANCE is None:
        _DB_INSTANCE = Database()
    return _DB_INSTANCE


def reset_database_instance() -> None:
    """Drop the cached instance (used by tests that redirect the data dir)."""
    global _DB_INSTANCE
    _DB_INSTANCE = None
