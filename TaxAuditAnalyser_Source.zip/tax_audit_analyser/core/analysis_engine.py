"""Consolidate extracted lines, validate the accounts and run YoY analysis.

Pipeline position: this module sits between extraction/mapping and the ratio
and risk engines. It turns raw candidate lines into a clean, de-duplicated
:class:`FinancialDataset` keyed by canonical head, checks the internal
arithmetic of the statements, and computes year-on-year movement with
configurable materiality bands.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from ..database.models import AnalysisResult, ExtractedFigure
from .financial_mapper import (
    BS_ASSET,
    BS_LIABILITY,
    EXPENSE_HEADS,
    PL,
    TOTAL_HEADS,
    map_heading,
    statement_type_of,
)
from .logging_setup import get_logger
from .pdf_extractor import ExtractionResult, RawLine

log = get_logger(__name__)

# ------------------------------------------------------- materiality bands

DEFAULT_THRESHOLDS = {
    "review": 10.0,       # >= 10%  -> Review
    "significant": 20.0,  # >= 20%  -> Significant
    "high": 50.0,         # >= 50%  -> High Movement
}

MATERIALITY_NORMAL = "Normal"
MATERIALITY_REVIEW = "Review"
MATERIALITY_SIGNIFICANT = "Significant"
MATERIALITY_HIGH = "High Movement"

# Tolerance for accounting identity checks: the larger of an absolute floor
# (rounding in thousands) and a small relative share of the total.
VALIDATION_ABSOLUTE_TOLERANCE = 1000.0
VALIDATION_RELATIVE_TOLERANCE = 0.005  # 0.5%


def format_indian(value: Optional[float]) -> str:
    """Format an amount using the lakh/crore digit grouping.

    Validation messages are read by Indian practitioners and quoted directly
    into working papers, so 1,23,45,678.90 is the expected presentation rather
    than the western 12,345,678.90.
    """
    if value is None:
        return "not available"
    integer, decimal = f"{abs(value):.2f}".split(".")
    if len(integer) > 3:
        head, tail = integer[:-3], integer[-3:]
        parts: List[str] = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        integer = ",".join(parts + [tail])
    text = f"{integer}.{decimal}"
    return f"({text})" if value < 0 else text


def classify_materiality(
    change_percent: Optional[float], thresholds: Optional[Dict[str, float]] = None
) -> str:
    """Band an absolute percentage movement."""
    if change_percent is None:
        return MATERIALITY_NORMAL
    limits = {**DEFAULT_THRESHOLDS, **(thresholds or {})}
    magnitude = abs(change_percent)
    if magnitude >= limits["high"]:
        return MATERIALITY_HIGH
    if magnitude >= limits["significant"]:
        return MATERIALITY_SIGNIFICANT
    if magnitude >= limits["review"]:
        return MATERIALITY_REVIEW
    return MATERIALITY_NORMAL


def percentage_change(
    current: Optional[float], previous: Optional[float]
) -> Optional[float]:
    """Percentage movement from previous to current year.

    Returns ``None`` when a meaningful percentage cannot be expressed (missing
    figures, or a zero prior-year base). Callers must treat ``None`` as "not
    computable" rather than as zero movement.
    """
    if current is None or previous is None:
        return None
    if previous == 0:
        return None
    return ((current - previous) / abs(previous)) * 100.0


# ------------------------------------------------------------ the dataset


@dataclass
class FinancialDataset:
    """All figures for one case, keyed by canonical financial head.

    ``components`` records the individual statement lines that were summed to
    produce each head, so the verification screen and the report can always
    show the auditor exactly which raw headings contributed to a figure.
    """

    figures: Dict[str, ExtractedFigure] = field(default_factory=dict)
    components: Dict[str, List[ExtractedFigure]] = field(default_factory=dict)
    unmapped: List[RawLine] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def components_of(self, head: str) -> List[ExtractedFigure]:
        return self.components.get(head, [])

    def component_amount(self, head: str, *keywords: str) -> Optional[float]:
        """Current-year total of components whose raw heading matches a keyword.

        Lets the risk engine interrogate a specific line (say foreign travel)
        that was aggregated into a broader canonical head.
        """
        from .financial_mapper import normalise

        wanted = [normalise(k) for k in keywords if k]
        total: Optional[float] = None
        for component in self.components_of(head):
            heading = normalise(component.raw_heading)
            if any(w and w in heading for w in wanted):
                if component.current_year_amount is not None:
                    total = (total or 0.0) + component.current_year_amount
        return total

    # ------------------------------------------------------------ accessors

    def get(self, head: str) -> Optional[ExtractedFigure]:
        return self.figures.get(head)

    def cy(self, head: str, default: Optional[float] = None) -> Optional[float]:
        figure = self.figures.get(head)
        if figure is None or figure.current_year_amount is None:
            return default
        return figure.current_year_amount

    def py(self, head: str, default: Optional[float] = None) -> Optional[float]:
        figure = self.figures.get(head)
        if figure is None or figure.previous_year_amount is None:
            return default
        return figure.previous_year_amount

    def has(self, head: str) -> bool:
        return head in self.figures

    def source_of(self, head: str) -> Tuple[str, Optional[int]]:
        figure = self.figures.get(head)
        if figure is None:
            return "", None
        return figure.source_document, figure.source_page

    def heads(self, statement_type: Optional[str] = None) -> List[str]:
        if statement_type is None:
            return list(self.figures)
        return [
            head
            for head in self.figures
            if statement_type_of(head) == statement_type
        ]

    def line_items(self, statement_type: Optional[str] = None) -> List[str]:
        """Heads excluding subtotal/total rows."""
        return [h for h in self.heads(statement_type) if h not in TOTAL_HEADS]

    def as_list(self) -> List[ExtractedFigure]:
        return list(self.figures.values())

    @property
    def low_confidence_heads(self) -> List[str]:
        return [h for h, f in self.figures.items() if f.confidence == "Low"]


# ------------------------------------------------------------ consolidation

_CONFIDENCE_RANK = {"High": 3, "Medium": 2, "Low": 1}


def _figure_quality(figure: ExtractedFigure) -> tuple:
    """Sort key deciding which duplicate mapping to keep."""
    return (
        _CONFIDENCE_RANK.get(figure.confidence, 0),
        figure.match_score,
        1 if figure.previous_year_amount is not None else 0,
        1 if figure.current_year_amount is not None else 0,
    )


def build_dataset(
    extraction_results: Sequence[Tuple[str, ExtractionResult]],
    case_id: str = "",
) -> FinancialDataset:
    """Map every extracted line and consolidate into canonical heads.

    ``extraction_results`` is a sequence of ``(document_name, result)`` pairs.
    When two documents (say a P&L and a Trial Balance) both yield the same
    head, the higher-confidence extraction wins; ties keep the one that also
    carries a previous-year figure.
    """
    from .financial_mapper import normalise

    dataset = FinancialDataset()
    # canonical head -> normalised raw heading -> best candidate for that line
    candidates: Dict[str, Dict[str, ExtractedFigure]] = {}

    for document_name, result in extraction_results:
        if result is None:
            continue
        if result.error:
            dataset.warnings.append(f"{document_name}: {result.error}")
            continue
        dataset.warnings.extend(f"{document_name}: {w}" for w in result.warnings)

        for line in result.lines:
            mapping = map_heading(line.heading, line.statement_hint)
            if mapping is None:
                dataset.unmapped.append(line)
                continue

            figure = ExtractedFigure(
                case_id=case_id,
                canonical_head=mapping.canonical_head,
                raw_heading=line.heading,
                current_year_amount=line.current_year,
                previous_year_amount=line.previous_year,
                source_document=document_name,
                source_page=line.page,
                confidence=mapping.confidence,
                match_score=mapping.score,
                statement_type=mapping.statement_type,
            )
            # OCR-derived figures are inherently less certain; never let one
            # be presented as High confidence to the auditor.
            if line.source == "ocr" and figure.confidence == "High":
                figure.confidence = "Medium"

            bucket = candidates.setdefault(mapping.canonical_head, {})
            key = normalise(line.heading)
            existing = bucket.get(key)
            # The same heading seen twice (e.g. in both the P&L and the trial
            # balance) is one line item, so keep only the better extraction.
            if existing is None or _figure_quality(figure) > _figure_quality(existing):
                bucket[key] = figure

    for head, bucket in candidates.items():
        parts = list(bucket.values())
        dataset.components[head] = parts
        if len(parts) == 1 or head in TOTAL_HEADS:
            # Totals are never summed: two documents both reporting "Total
            # Assets" state the same total, they are not two components of it.
            best = max(parts, key=_figure_quality)
            dataset.figures[head] = best
            continue
        dataset.figures[head] = _aggregate_components(head, parts)

    log.info(
        "Dataset built: %d canonical heads, %d unmapped lines",
        len(dataset.figures),
        len(dataset.unmapped),
    )
    return dataset


def _aggregate_components(head: str, parts: List[ExtractedFigure]) -> ExtractedFigure:
    """Sum several statement lines that share one canonical head.

    "Salaries and Wages" and "Staff Welfare" are separate lines of the same
    Employee Cost category; keeping only one of them would understate the head
    and quietly drop a figure from the analysis. The aggregate inherits the
    weakest confidence of its parts, because the total is only as reliable as
    its least certain component.
    """
    def _sum(attribute: str) -> Optional[float]:
        values = [
            getattr(p, attribute)
            for p in parts
            if getattr(p, attribute) is not None
        ]
        return sum(values) if values else None

    primary = max(parts, key=_figure_quality)
    weakest = min(
        (p.confidence for p in parts), key=lambda c: _CONFIDENCE_RANK.get(c, 0)
    )
    headings = "; ".join(dict.fromkeys(p.raw_heading for p in parts))
    return ExtractedFigure(
        case_id=primary.case_id,
        canonical_head=head,
        raw_heading=headings,
        current_year_amount=_sum("current_year_amount"),
        previous_year_amount=_sum("previous_year_amount"),
        source_document=primary.source_document,
        source_page=primary.source_page,
        confidence=weakest,
        match_score=min(p.match_score for p in parts),
        statement_type=primary.statement_type,
    )


def dataset_from_figures(figures: Iterable[ExtractedFigure]) -> FinancialDataset:
    """Rebuild a dataset from stored (and possibly CA-corrected) figures."""
    dataset = FinancialDataset()
    for figure in figures:
        existing = dataset.figures.get(figure.canonical_head)
        # Verified figures always win: the auditor's correction is definitive.
        if existing is None or figure.is_verified or _figure_quality(figure) > _figure_quality(existing):
            if existing is not None and existing.is_verified and not figure.is_verified:
                continue
            dataset.figures[figure.canonical_head] = figure
    return dataset


# -------------------------------------------------------------- validation


@dataclass
class ValidationCheck:
    """Result of one accounting-identity check."""

    name: str
    passed: bool
    expected: Optional[float] = None
    reported: Optional[float] = None
    difference: Optional[float] = None
    message: str = ""
    applicable: bool = True

    @property
    def status(self) -> str:
        if not self.applicable:
            return "Not Applicable"
        return "Balanced" if self.passed else "Mismatch"


def _tolerance_for(magnitude: float) -> float:
    return max(
        VALIDATION_ABSOLUTE_TOLERANCE, abs(magnitude) * VALIDATION_RELATIVE_TOLERANCE
    )


def validate_balance_sheet(dataset: FinancialDataset) -> ValidationCheck:
    """Total Assets vs Total Equity & Liabilities.

    Prefers the totals reported in the statement. When only one side reports a
    total, the other side is summed from its components.
    """
    reported_assets = dataset.cy("Total Assets")
    reported_liabilities = dataset.cy("Total Equity & Liabilities")

    def _sum_side(statement_type: str) -> Optional[float]:
        values = [
            dataset.cy(head)
            for head in dataset.line_items(statement_type)
            if dataset.cy(head) is not None
        ]
        return sum(values) if values else None

    assets = reported_assets if reported_assets is not None else _sum_side(BS_ASSET)
    liabilities = (
        reported_liabilities
        if reported_liabilities is not None
        else _sum_side(BS_LIABILITY)
    )

    if assets is None or liabilities is None:
        return ValidationCheck(
            name="Balance Sheet Equation",
            passed=False,
            applicable=False,
            message=(
                "Balance Sheet totals could not be established from the documents "
                "uploaded. Please verify that a complete Balance Sheet has been "
                "provided, or enter the missing figures on the verification screen."
            ),
        )

    difference = assets - liabilities
    tolerance = _tolerance_for(max(abs(assets), abs(liabilities)))
    passed = abs(difference) <= tolerance
    if passed:
        message = (
            "Total Assets agree with Total Equity and Liabilities within the "
            "rounding tolerance applied."
        )
    else:
        message = (
            f"Total Assets ({format_indian(assets)}) do not agree with Total Equity "
            f"and Liabilities ({format_indian(liabilities)}). Difference of "
            f"{format_indian(difference)} "
            "requires examination of the underlying records before the figures "
            "are relied upon."
        )
    return ValidationCheck(
        name="Balance Sheet Equation",
        passed=passed,
        expected=liabilities,
        reported=assets,
        difference=difference,
        message=message,
    )


def validate_balance_sheet_components(dataset: FinancialDataset) -> ValidationCheck:
    """Reported Total Assets vs the sum of the individual asset lines."""
    reported = dataset.cy("Total Assets")
    components = [
        dataset.cy(head)
        for head in dataset.line_items(BS_ASSET)
        if dataset.cy(head) is not None
    ]
    if reported is None or not components:
        return ValidationCheck(
            name="Asset Schedule Casting",
            passed=False,
            applicable=False,
            message="Insufficient asset detail to re-cast the asset side.",
        )
    computed = sum(components)
    difference = computed - reported
    tolerance = _tolerance_for(reported)
    passed = abs(difference) <= tolerance
    if passed:
        message = "The individual asset balances cast to the reported total."
    else:
        message = (
            f"The individual asset balances total {format_indian(computed)} against "
            f"a reported Total Assets figure of {format_indian(reported)}, a "
            f"difference of {format_indian(difference)}. This may indicate that "
            "one or more asset lines "
            "were not captured from the document, or a casting difference in the "
            "statement itself. Verification against the audited accounts is "
            "recommended."
        )
    return ValidationCheck(
        name="Asset Schedule Casting",
        passed=passed,
        expected=reported,
        reported=computed,
        difference=difference,
        message=message,
    )


def validate_profit_and_loss(dataset: FinancialDataset) -> ValidationCheck:
    """Revenue less expenses against the reported Profit Before Tax.

    Cost of goods sold is derived as Opening Stock + Purchases - Closing Stock
    where those components are present, which is how Indian trading and
    manufacturing accounts are normally cast.
    """
    turnover = dataset.cy("Turnover / Revenue")
    reported_pbt = dataset.cy("Profit Before Tax")
    if turnover is None or reported_pbt is None:
        return ValidationCheck(
            name="Profit & Loss Arithmetic",
            passed=False,
            applicable=False,
            message=(
                "Turnover or Profit Before Tax could not be established from the "
                "documents uploaded, so the Profit and Loss arithmetic could not "
                "be re-performed."
            ),
        )

    other_income = dataset.cy("Other Income", 0.0) or 0.0
    opening_stock = dataset.cy("Opening Stock", 0.0) or 0.0
    purchases = dataset.cy("Purchases", 0.0) or 0.0
    closing_stock = dataset.cy("Closing Stock", 0.0) or 0.0
    cost_of_goods = opening_stock + purchases - closing_stock

    other_expense_heads = [
        head
        for head in EXPENSE_HEADS
        if head != "Purchases" and dataset.cy(head) is not None
    ]
    other_expenses = sum(dataset.cy(head) or 0.0 for head in other_expense_heads)

    computed_pbt = turnover + other_income - cost_of_goods - other_expenses
    difference = computed_pbt - reported_pbt
    tolerance = _tolerance_for(max(abs(turnover) * 0.01, abs(reported_pbt)))
    passed = abs(difference) <= tolerance

    if passed:
        message = (
            "Revenue less expenses re-performs to the reported Profit Before Tax "
            "within the tolerance applied."
        )
    else:
        message = (
            f"Revenue less expenses computes to {format_indian(computed_pbt)} against "
            f"a reported Profit Before Tax of {format_indian(reported_pbt)}, a "
            f"difference of {format_indian(difference)}. The difference may arise "
            "from expense heads not "
            "captured from the uploaded documents, and should be reconciled "
            "against the audited Profit and Loss Account."
        )
    return ValidationCheck(
        name="Profit & Loss Arithmetic",
        passed=passed,
        expected=reported_pbt,
        reported=computed_pbt,
        difference=difference,
        message=message,
    )


def run_validations(dataset: FinancialDataset) -> List[ValidationCheck]:
    """All accounting-identity checks, in report order."""
    return [
        validate_balance_sheet(dataset),
        validate_balance_sheet_components(dataset),
        validate_profit_and_loss(dataset),
    ]


# ---------------------------------------------------------- YoY analysis


def _explain_movement(head: str, change: float, percent: Optional[float]) -> str:
    """Plain-language sentence describing one movement."""
    direction = "increased" if change > 0 else "decreased"
    if percent is None:
        return (
            f"{head} {direction} by {format_indian(abs(change))} during the year. A "
            "percentage comparison is not meaningful because the previous year "
            "figure is nil."
        )
    return (
        f"{head} {direction} by {format_indian(abs(change))} ({abs(percent):,.1f}%) "
        "compared with the previous year."
    )


def year_on_year_analysis(
    dataset: FinancialDataset, thresholds: Optional[Dict[str, float]] = None
) -> List[AnalysisResult]:
    """Absolute and percentage movement for every head with both years."""
    results: List[AnalysisResult] = []
    for head, figure in dataset.figures.items():
        current = figure.current_year_amount
        previous = figure.previous_year_amount
        if current is None or previous is None:
            continue
        change = current - previous
        percent = percentage_change(current, previous)
        materiality = classify_materiality(percent, thresholds)
        results.append(
            AnalysisResult(
                case_id=figure.case_id,
                result_type="YOY",
                label=head,
                current_year=current,
                previous_year=previous,
                change_amount=change,
                change_percent=percent,
                materiality=materiality,
                explanation=_explain_movement(head, change, percent),
                finding_type="CALCULATION",
            )
        )
    order = {
        MATERIALITY_HIGH: 0,
        MATERIALITY_SIGNIFICANT: 1,
        MATERIALITY_REVIEW: 2,
        MATERIALITY_NORMAL: 3,
    }
    results.sort(
        key=lambda r: (order.get(r.materiality, 9), -abs(r.change_amount or 0.0))
    )
    return results


def financial_snapshot(dataset: FinancialDataset) -> List[AnalysisResult]:
    """Headline figures for the report's Financial Snapshot section."""
    snapshot_heads = [
        "Turnover / Revenue",
        "Other Income",
        "Profit Before Tax",
        "Profit After Tax",
        "Total Assets",
        "Total Equity & Liabilities",
        "Trade Receivables",
        "Trade Payables",
        "Cash in Hand",
        "Bank Balances",
        "Secured Loans",
        "Unsecured Loans",
    ]
    results: List[AnalysisResult] = []
    for head in snapshot_heads:
        if not dataset.has(head):
            continue
        current = dataset.cy(head)
        previous = dataset.py(head)
        change = (
            current - previous if current is not None and previous is not None else None
        )
        results.append(
            AnalysisResult(
                case_id=dataset.figures[head].case_id,
                result_type="SNAPSHOT",
                label=head,
                current_year=current,
                previous_year=previous,
                change_amount=change,
                change_percent=percentage_change(current, previous),
                materiality="",
                explanation="",
                finding_type="FACT",
            )
        )
    return results


def validations_to_results(
    checks: Sequence[ValidationCheck], case_id: str = ""
) -> List[AnalysisResult]:
    """Persist validation checks alongside the other analysis results."""
    results: List[AnalysisResult] = []
    for check in checks:
        results.append(
            AnalysisResult(
                case_id=case_id,
                result_type="VALIDATION",
                label=check.name,
                current_year=check.reported,
                previous_year=check.expected,
                change_amount=check.difference,
                change_percent=None,
                materiality=check.status,
                explanation=check.message,
                finding_type="CALCULATION" if check.applicable else "VERIFICATION REQUIRED",
            )
        )
    return results
