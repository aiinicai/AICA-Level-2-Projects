"""Optional OCR support for scanned PDFs and image documents.

The whole module is defensive: pytesseract and the ``tesseract`` binary are
frequently absent on end-user Windows machines. Nothing here may raise on
import or on use -- when OCR is unavailable the caller receives an empty
string plus a clear "OCR unavailable" explanation which is surfaced to the
Chartered Accountant rather than crashing the analysis run.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from .logging_setup import get_logger

log = get_logger(__name__)

# Below this many characters a PDF page is treated as scanned/image-only.
SCANNED_PAGE_TEXT_THRESHOLD = 25

# Rendering DPI for rasterising a PDF page before OCR. 300 is the usual
# accuracy/speed sweet spot for financial statements.
OCR_RENDER_DPI = 300

_AVAILABILITY: Optional[Tuple[bool, str]] = None


@dataclass
class OCRResult:
    """Outcome of an OCR attempt."""

    text: str = ""
    success: bool = False
    message: str = ""
    engine: str = "tesseract"

    def __bool__(self) -> bool:
        return self.success and bool(self.text.strip())


def _probe_availability() -> Tuple[bool, str]:
    """Check that both the python binding and the binary are present."""
    try:
        import pytesseract  # noqa: F401
    except Exception as exc:
        return False, (
            "OCR unavailable: the 'pytesseract' Python package is not installed. "
            "Scanned documents cannot be read automatically. "
            f"({exc})"
        )

    try:
        import pytesseract

        configured = getattr(pytesseract.pytesseract, "tesseract_cmd", "tesseract")
        if not (shutil.which(configured) or shutil.which("tesseract")):
            return False, (
                "OCR unavailable: the Tesseract OCR engine is not installed on this "
                "computer. Install Tesseract-OCR and restart the application to "
                "enable reading of scanned documents."
            )
        version = pytesseract.get_tesseract_version()
        return True, f"OCR available (Tesseract {version})."
    except Exception as exc:
        return False, (
            "OCR unavailable: the Tesseract OCR engine could not be started. "
            f"({exc})"
        )


def ocr_available() -> bool:
    """True when scanned documents can be read. Result is cached."""
    return availability()[0]


def availability() -> Tuple[bool, str]:
    """``(available, human_readable_message)``, probed once and cached."""
    global _AVAILABILITY
    if _AVAILABILITY is None:
        _AVAILABILITY = _probe_availability()
        log.info("OCR probe: %s", _AVAILABILITY[1])
    return _AVAILABILITY


def reset_availability_cache() -> None:
    """Force a re-probe (used by tests and by the Settings screen)."""
    global _AVAILABILITY
    _AVAILABILITY = None


def is_scanned_text(text: str, threshold: int = SCANNED_PAGE_TEXT_THRESHOLD) -> bool:
    """Heuristic: near-zero extractable text means an image-only page."""
    return len((text or "").strip()) < threshold


def ocr_image_file(image_path: str | Path) -> OCRResult:
    """Run OCR over an image file on disk."""
    available, message = availability()
    if not available:
        return OCRResult(success=False, message=message)
    try:
        import pytesseract
        from PIL import Image

        with Image.open(str(image_path)) as img:
            text = pytesseract.image_to_string(img)
        return OCRResult(text=text or "", success=True, message="OCR completed.")
    except Exception as exc:
        log.warning("OCR failed for image %s: %s", image_path, exc)
        return OCRResult(
            success=False, message=f"OCR could not read this image: {exc}"
        )


def ocr_pdf_page(pdf_path: str | Path, page_number: int, dpi: int = OCR_RENDER_DPI) -> OCRResult:
    """Rasterise one PDF page with PyMuPDF and OCR it.

    ``page_number`` is 1-based to match the page numbers shown to the user.
    """
    available, message = availability()
    if not available:
        return OCRResult(success=False, message=message)

    try:
        import pymupdf
    except Exception:
        try:
            import fitz as pymupdf  # type: ignore
        except Exception as exc:
            return OCRResult(
                success=False,
                message=f"OCR unavailable: PyMuPDF could not be loaded ({exc}).",
            )

    try:
        import io

        import pytesseract
        from PIL import Image

        with pymupdf.open(str(pdf_path)) as doc:
            index = page_number - 1
            if index < 0 or index >= doc.page_count:
                return OCRResult(
                    success=False,
                    message=f"Page {page_number} does not exist in this document.",
                )
            page = doc.load_page(index)
            zoom = dpi / 72.0
            matrix = pymupdf.Matrix(zoom, zoom)
            pixmap = page.get_pixmap(matrix=matrix)
            image_bytes = pixmap.tobytes("png")

        with Image.open(io.BytesIO(image_bytes)) as img:
            text = pytesseract.image_to_string(img)
        log.info(
            "OCR read %d characters from page %d of %s",
            len(text or ""),
            page_number,
            Path(pdf_path).name,
        )
        return OCRResult(text=text or "", success=True, message="OCR completed.")
    except Exception as exc:
        log.warning("OCR failed for %s page %s: %s", pdf_path, page_number, exc)
        return OCRResult(
            success=False,
            message=(
                f"OCR could not read page {page_number}. This page may need to be "
                f"reviewed manually. ({exc})"
            ),
        )
