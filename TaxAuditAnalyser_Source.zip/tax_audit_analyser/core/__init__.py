"""Core analysis engines (no GUI dependencies)."""
