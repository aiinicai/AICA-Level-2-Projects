"""Financial ratio computation with plain-language commentary.

Every ratio is computed for both the current and previous year where the
inputs allow it, and each carries an explanation written for a reader who
wants to know *why* a movement matters rather than just the number. A ratio
whose inputs are missing is reported as not computable rather than as zero --
silently showing 0.00 for an unavailable ratio would be misleading in an audit
working paper.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from ..database.models import AnalysisResult
from .analysis_engine import FinancialDataset, percentage_change
from .logging_setup import get_logger

log = get_logger(__name__)

# A ratio moving by more than this many percentage points (relative) is called
# out as a material change in the narrative.
MATERIAL_RATIO_SHIFT_PERCENT = 15.0


@dataclass
class Ratio:
    """One computed ratio across two years."""

    name: str
    current: Optional[float]
    previous: Optional[float]
    unit: str = "%"
    basis: str = ""
    explanation: str = ""
    note: str = ""

    @property
    def computable(self) -> bool:
        return self.current is not None or self.previous is not None

    @property
    def change(self) -> Optional[float]:
        if self.current is None or self.previous is None:
            return None
        return self.current - self.previous

    @property
    def change_percent(self) -> Optional[float]:
        return percentage_change(self.current, self.previous)

    def format_value(self, value: Optional[float]) -> str:
        if value is None:
            return "Not computable"
        if self.unit == "%":
            return f"{value:,.2f}%"
        if self.unit == "times":
            return f"{value:,.2f} times"
        if self.unit == "days":
            return f"{value:,.0f} days"
        return f"{value:,.2f}"

    @property
    def current_display(self) -> str:
        return self.format_value(self.current)

    @property
    def previous_display(self) -> str:
        return self.format_value(self.previous)

    @property
    def is_material_change(self) -> bool:
        shift = self.change_percent
        return shift is not None and abs(shift) >= MATERIAL_RATIO_SHIFT_PERCENT


def _safe_divide(
    numerator: Optional[float], denominator: Optional[float]
) -> Optional[float]:
    """Divide, returning None when the result would be meaningless."""
    if numerator is None or denominator is None:
        return None
    if denominator == 0:
        return None
    return numerator / denominator


def _pct(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    value = _safe_divide(numerator, denominator)
    return value * 100.0 if value is not None else None


def _sum_optional(*values: Optional[float]) -> Optional[float]:
    present = [v for v in values if v is not None]
    return sum(present) if present else None


# ------------------------------------------------------------- derived bases


def _cost_of_goods_sold(dataset: FinancialDataset, year: str) -> Optional[float]:
    """Opening stock + purchases - closing stock for the requested year."""
    pick = dataset.cy if year == "cy" else dataset.py
    purchases = pick("Purchases")
    if purchases is None:
        return None
    opening = pick("Opening Stock") or 0.0
    closing = pick("Closing Stock") or 0.0
    return opening + purchases - closing


def _current_assets(dataset: FinancialDataset, year: str) -> Optional[float]:
    pick = dataset.cy if year == "cy" else dataset.py
    return _sum_optional(
        pick("Trade Receivables"),
        pick("Inventories"),
        pick("Cash in Hand"),
        pick("Bank Balances"),
        pick("Loans & Advances"),
        pick("GST Receivable"),
        pick("TDS Receivable"),
        pick("Other Current Assets"),
    )


def _quick_assets(dataset: FinancialDataset, year: str) -> Optional[float]:
    """Current assets excluding inventory."""
    pick = dataset.cy if year == "cy" else dataset.py
    return _sum_optional(
        pick("Trade Receivables"),
        pick("Cash in Hand"),
        pick("Bank Balances"),
        pick("Loans & Advances"),
        pick("GST Receivable"),
        pick("TDS Receivable"),
        pick("Other Current Assets"),
    )


def _current_liabilities(dataset: FinancialDataset, year: str) -> Optional[float]:
    pick = dataset.cy if year == "cy" else dataset.py
    return _sum_optional(
        pick("Trade Payables"),
        pick("MSME Payables"),
        pick("Statutory Liabilities"),
        pick("Other Current Liabilities"),
        pick("Provisions (Liability)"),
    )


def _total_debt(dataset: FinancialDataset, year: str) -> Optional[float]:
    pick = dataset.cy if year == "cy" else dataset.py
    return _sum_optional(pick("Secured Loans"), pick("Unsecured Loans"))


def _equity(dataset: FinancialDataset, year: str) -> Optional[float]:
    """Owners' funds, however the entity's constitution expresses them."""
    pick = dataset.cy if year == "cy" else dataset.py
    return _sum_optional(
        pick("Share Capital"), pick("Reserves & Surplus"), pick("Partners Capital")
    )


def _gross_profit(dataset: FinancialDataset, year: str) -> Optional[float]:
    pick = dataset.cy if year == "cy" else dataset.py
    turnover = pick("Turnover / Revenue")
    cogs = _cost_of_goods_sold(dataset, year)
    if turnover is None or cogs is None:
        return None
    return turnover - cogs


def _total_expenses(dataset: FinancialDataset, year: str) -> Optional[float]:
    """Reported total expenses, else the sum of the recognised expense heads."""
    from .financial_mapper import EXPENSE_HEADS

    pick = dataset.cy if year == "cy" else dataset.py
    reported = pick("Total Expenses")
    if reported is not None:
        return reported
    values = [pick(head) for head in EXPENSE_HEADS if pick(head) is not None]
    if not values:
        return None
    total = sum(values)
    # Purchases are already inside the expense list; adjust for stock movement
    # so the figure reflects cost of goods sold rather than gross purchases.
    opening = pick("Opening Stock")
    closing = pick("Closing Stock")
    if opening is not None:
        total += opening
    if closing is not None:
        total -= closing
    return total


# ---------------------------------------------------------------- narrative


def _direction_word(change: Optional[float]) -> str:
    if change is None:
        return "moved"
    return "improved to" if change > 0 else "declined to"


def _explain(ratio: Ratio, higher_is_better: bool = True) -> str:
    """Compose the plain-language commentary for one ratio."""
    if ratio.current is None and ratio.previous is None:
        return (
            f"{ratio.name} could not be computed because the required figures "
            "were not available in the documents uploaded."
        )
    if ratio.previous is None:
        return (
            f"{ratio.name} for the current year is {ratio.current_display}. No "
            "comparative figure was available, so no trend can be commented upon."
        )
    if ratio.current is None:
        return (
            f"{ratio.name} could not be computed for the current year. The "
            f"previous year figure was {ratio.previous_display}."
        )

    change = ratio.change or 0.0
    if abs(change) < 1e-9:
        return f"{ratio.name} is unchanged at {ratio.current_display}."

    rose = change > 0
    favourable = rose if higher_is_better else not rose
    sentiment = "a favourable movement" if favourable else "an adverse movement"
    magnitude = "materially" if ratio.is_material_change else "marginally"

    text = (
        f"{ratio.name} {magnitude} {'increased' if rose else 'decreased'} from "
        f"{ratio.previous_display} to {ratio.current_display}, which is "
        f"{sentiment} in isolation."
    )
    if ratio.is_material_change:
        text += (
            " A movement of this size ordinarily warrants enquiry into the "
            "underlying cause and confirmation that the comparative figures are "
            "stated on a consistent basis."
        )
    return text


# ------------------------------------------------------------- the ratio set


def compute_ratios(dataset: FinancialDataset) -> List[Ratio]:
    """Compute the full ratio set for both years."""
    ratios: List[Ratio] = []

    def add(
        name: str,
        cy: Optional[float],
        py: Optional[float],
        unit: str,
        basis: str,
        higher_is_better: bool = True,
        note: str = "",
    ) -> None:
        ratio = Ratio(name=name, current=cy, previous=py, unit=unit, basis=basis, note=note)
        ratio.explanation = _explain(ratio, higher_is_better)
        ratios.append(ratio)

    turnover_cy = dataset.cy("Turnover / Revenue")
    turnover_py = dataset.py("Turnover / Revenue")

    # -- Profitability -----------------------------------------------------
    add(
        "Gross Profit Ratio",
        _pct(_gross_profit(dataset, "cy"), turnover_cy),
        _pct(_gross_profit(dataset, "py"), turnover_py),
        "%",
        "Gross Profit / Turnover",
    )
    add(
        "Net Profit Ratio",
        _pct(dataset.cy("Profit Before Tax"), turnover_cy),
        _pct(dataset.py("Profit Before Tax"), turnover_py),
        "%",
        "Profit Before Tax / Turnover",
    )
    add(
        "Expense to Turnover Ratio",
        _pct(_total_expenses(dataset, "cy"), turnover_cy),
        _pct(_total_expenses(dataset, "py"), turnover_py),
        "%",
        "Total Expenses / Turnover",
        higher_is_better=False,
    )

    # -- Liquidity ---------------------------------------------------------
    add(
        "Current Ratio",
        _safe_divide(_current_assets(dataset, "cy"), _current_liabilities(dataset, "cy")),
        _safe_divide(_current_assets(dataset, "py"), _current_liabilities(dataset, "py")),
        "times",
        "Current Assets / Current Liabilities",
    )
    add(
        "Quick Ratio",
        _safe_divide(_quick_assets(dataset, "cy"), _current_liabilities(dataset, "cy")),
        _safe_divide(_quick_assets(dataset, "py"), _current_liabilities(dataset, "py")),
        "times",
        "(Current Assets less Inventories) / Current Liabilities",
    )

    # -- Leverage ----------------------------------------------------------
    add(
        "Debt Equity Ratio",
        _safe_divide(_total_debt(dataset, "cy"), _equity(dataset, "cy")),
        _safe_divide(_total_debt(dataset, "py"), _equity(dataset, "py")),
        "times",
        "(Secured plus Unsecured Loans) / Owners' Funds",
        higher_is_better=False,
    )

    # -- Activity ----------------------------------------------------------
    add(
        "Inventory Turnover Ratio",
        _safe_divide(_cost_of_goods_sold(dataset, "cy"), dataset.cy("Inventories")),
        _safe_divide(_cost_of_goods_sold(dataset, "py"), dataset.py("Inventories")),
        "times",
        "Cost of Goods Sold / Closing Inventory",
    )
    add(
        "Debtor Turnover Ratio",
        _safe_divide(turnover_cy, dataset.cy("Trade Receivables")),
        _safe_divide(turnover_py, dataset.py("Trade Receivables")),
        "times",
        "Turnover / Trade Receivables",
    )
    add(
        "Creditor Turnover Ratio",
        _safe_divide(
            _cost_of_goods_sold(dataset, "cy"),
            _sum_optional(dataset.cy("Trade Payables"), dataset.cy("MSME Payables")),
        ),
        _safe_divide(
            _cost_of_goods_sold(dataset, "py"),
            _sum_optional(dataset.py("Trade Payables"), dataset.py("MSME Payables")),
        ),
        "times",
        "Cost of Goods Sold / Trade Payables",
    )

    # -- Cost structure ----------------------------------------------------
    employee_cy = _sum_optional(
        dataset.cy("Employee Cost"), dataset.cy("Director / Partner Remuneration")
    )
    employee_py = _sum_optional(
        dataset.py("Employee Cost"), dataset.py("Director / Partner Remuneration")
    )
    add(
        "Employee Cost Ratio",
        _pct(employee_cy, turnover_cy),
        _pct(employee_py, turnover_py),
        "%",
        "Employee Cost including Director/Partner Remuneration / Turnover",
        higher_is_better=False,
    )
    add(
        "Finance Cost Ratio",
        _pct(dataset.cy("Finance Cost"), turnover_cy),
        _pct(dataset.py("Finance Cost"), turnover_py),
        "%",
        "Finance Cost / Turnover",
        higher_is_better=False,
    )

    # -- Related party -----------------------------------------------------
    # Only the identifiable proxies are used. Where a Notes to Accounts
    # related-party schedule has not been provided, this is reported as not
    # determinable rather than assumed to be nil.
    related_cy = _sum_optional(
        dataset.cy("Director / Partner Remuneration"), dataset.cy("Unsecured Loans")
    )
    related_py = _sum_optional(
        dataset.py("Director / Partner Remuneration"), dataset.py("Unsecured Loans")
    )
    add(
        "Related Party Ratio (identifiable items)",
        _pct(related_cy, turnover_cy),
        _pct(related_py, turnover_py),
        "%",
        "Director/Partner Remuneration plus Unsecured Loans / Turnover",
        higher_is_better=False,
        note=(
            "Computed only from items identifiable as related-party in nature from "
            "the documents uploaded. A complete related-party position can be "
            "determined only from the Notes to Accounts and management "
            "representations, which require separate examination."
        ),
    )

    return ratios


def ratios_to_results(ratios: List[Ratio], case_id: str = "") -> List[AnalysisResult]:
    """Convert ratios into persistable AnalysisResult rows."""
    results: List[AnalysisResult] = []
    for ratio in ratios:
        results.append(
            AnalysisResult(
                case_id=case_id,
                result_type="RATIO",
                label=ratio.name,
                current_year=ratio.current,
                previous_year=ratio.previous,
                change_amount=ratio.change,
                change_percent=ratio.change_percent,
                materiality="Material" if ratio.is_material_change else "Normal",
                explanation=(ratio.explanation + (" " + ratio.note if ratio.note else "")).strip(),
                finding_type="CALCULATION",
            )
        )
    return results


def material_ratio_movements(ratios: List[Ratio]) -> List[Ratio]:
    """Ratios whose movement is large enough to comment on in the report."""
    return [r for r in ratios if r.is_material_change]
