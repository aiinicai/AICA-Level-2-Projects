"""Tax audit risk identification engine.

This is the analytical heart of the application. It reads the consolidated
financial dataset and produces :class:`~..database.models.RiskFlag` records
describing matters that a Chartered Accountant should examine.

Language rule (non-negotiable)
------------------------------
Nothing produced here may assert that a statutory violation has occurred. The
engine identifies *matters requiring verification*. Every observation touching
a statutory provision is phrased as a possible applicability requiring
professional verification, and carries ``finding_type`` of
``POTENTIAL TAX ISSUE`` or ``VERIFICATION REQUIRED`` so the distinction from a
statement of fact is preserved in the data model itself.

Statutory references are limited to the provisions the application is
configured to mention. The engine never invents a section or a Form 3CD
clause; where the position is uncertain it says
"Potential applicability - professional verification required."
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence

from ..database.models import Case, RiskFlag
from ..paths import config_dir
from .analysis_engine import (
    FinancialDataset,
    ValidationCheck,
    percentage_change,
)
from .financial_mapper import EXPENSE_HEADS
from .logging_setup import get_logger
from .ratio_engine import Ratio

log = get_logger(__name__)

# --------------------------------------------------------------- disclaimers

CLAUSE_MAPPING_DISCLAIMER = (
    "Clause mapping is indicative and must be independently verified against "
    "the Income-tax Act, Income-tax Rules and Form 3CD applicable for the "
    "relevant assessment year."
)

UNCERTAIN_POSITION = "Potential applicability - professional verification required."

# ------------------------------------------------------------- risk levels

HIGH = "HIGH"
MEDIUM = "MEDIUM"
REVIEW = "REVIEW REQUIRED"
INFORMATIONAL = "INFORMATIONAL"

# ----------------------------------------------------------- finding types

FACT = "FACT"
CALCULATION = "CALCULATION"
OBSERVATION = "OBSERVATION"
POTENTIAL_TAX_ISSUE = "POTENTIAL TAX ISSUE"
VERIFICATION_REQUIRED = "VERIFICATION REQUIRED"

# ------------------------------------------------------------- thresholds
# All tunable from the Settings screen; these are the shipped defaults.

DEFAULT_RISK_THRESHOLDS: Dict[str, float] = {
    # Year-on-year expense movement (%) at which an expense head is queried.
    "expense_spike_percent": 40.0,
    "expense_high_spike_percent": 75.0,
    # An expense head exceeding this share of turnover (%) is queried.
    "expense_to_turnover_percent": 10.0,
    # Miscellaneous/unclassified spend above this share of turnover (%).
    "misc_expense_to_turnover_percent": 2.0,
    # Cash in hand above this share of turnover (%) is queried.
    "cash_to_turnover_percent": 2.0,
    # Absolute cash balance (Rs.) above which cash is always queried.
    "cash_absolute": 20_00_000.0,
    # Receivable/payable movement (%) considered disproportionate.
    "receivable_spike_percent": 40.0,
    "payable_spike_percent": 40.0,
    # New borrowing movement (%) considered material.
    "loan_movement_percent": 25.0,
    # Turnover movement (%) considered unusual.
    "turnover_movement_percent": 25.0,
    # Other income exceeding this share of turnover (%).
    "other_income_to_turnover_percent": 10.0,
    # Amounts at or above this value are examined for round-number patterns.
    "round_number_floor": 1_00_000.0,
    # Minimum amount for a head to be worth raising at all (Rs.).
    "de_minimis_amount": 50_000.0,
}

# ------------------------------------------------- Form 3CD mapping (config)
# Indicative only. Stored as JSON in the config folder on first run so that a
# firm can maintain its own mapping without editing the application code.

DEFAULT_FORM_3CD_MAPPING: Dict[str, Dict[str, str]] = {
    "cash_payments": {
        "issue": "Cash payments and cash expenditure",
        "clause": "Indicative: reporting of amounts inadmissible in respect of "
                  "cash payments (Section 40A(3) considerations)",
        "note": UNCERTAIN_POSITION,
    },
    "loans_deposits": {
        "issue": "Acceptance and repayment of loans and deposits",
        "clause": "Indicative: reporting of particulars of loans/deposits "
                  "accepted or repaid (Sections 269SS / 269T considerations)",
        "note": UNCERTAIN_POSITION,
    },
    "section_43b": {
        "issue": "Sums payable allowable only on actual payment",
        "clause": "Indicative: reporting of sums referred to in Section 43B",
        "note": UNCERTAIN_POSITION,
    },
    "tds_disallowance": {
        "issue": "Expenditure on which tax was deductible at source",
        "clause": "Indicative: reporting of amounts inadmissible under "
                  "Section 40(a)(ia), and of tax deduction and collection "
                  "compliance particulars",
        "note": UNCERTAIN_POSITION,
    },
    "related_party": {
        "issue": "Payments to specified persons",
        "clause": "Indicative: reporting of payments to persons specified "
                  "under Section 40A(2)(b)",
        "note": UNCERTAIN_POSITION,
    },
    "inadmissible_expenditure": {
        "issue": "Penalties, fines and expenditure of a non-business nature",
        "clause": "Indicative: reporting of amounts debited to the Profit and "
                  "Loss Account that are inadmissible or of a personal nature",
        "note": UNCERTAIN_POSITION,
    },
    "depreciation": {
        "issue": "Depreciation on assets",
        "clause": "Indicative: reporting of particulars of depreciation "
                  "allowable under the Income-tax Act",
        "note": UNCERTAIN_POSITION,
    },
    "unexplained_credits": {
        "issue": "Credits requiring explanation as to nature and source",
        "clause": "No specific mapping asserted (Section 68 considerations)",
        "note": UNCERTAIN_POSITION,
    },
    "capital_expenditure": {
        "issue": "Capital expenditure debited to the Profit and Loss Account",
        "clause": "Indicative: reporting of capital expenditure debited to the "
                  "Profit and Loss Account",
        "note": UNCERTAIN_POSITION,
    },
    "msme_dues": {
        "issue": "Dues to micro and small enterprises",
        "clause": "Indicative: reporting of sums payable to micro and small "
                  "enterprises (Section 43B considerations)",
        "note": UNCERTAIN_POSITION,
    },
    "provisions_contingent": {
        "issue": "Provisions and contingent liabilities",
        "clause": "Indicative: examination of allowability of provisions "
                  "debited to the Profit and Loss Account",
        "note": UNCERTAIN_POSITION,
    },
    "turnover_reconciliation": {
        "issue": "Turnover reconciliation with indirect tax returns",
        "clause": "No specific mapping asserted",
        "note": UNCERTAIN_POSITION,
    },
}

FORM_3CD_MAPPING_FILENAME = "form_3cd_mapping.json"
RISK_THRESHOLDS_FILENAME = "risk_thresholds.json"


def load_form_3cd_mapping() -> Dict[str, Dict[str, str]]:
    """Load the (user-editable) Form 3CD mapping, seeding it on first run."""
    path = config_dir() / FORM_3CD_MAPPING_FILENAME
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data:
                merged = dict(DEFAULT_FORM_3CD_MAPPING)
                merged.update({k: v for k, v in data.items() if isinstance(v, dict)})
                return merged
        path.write_text(
            json.dumps(DEFAULT_FORM_3CD_MAPPING, indent=2), encoding="utf-8"
        )
    except Exception as exc:
        log.warning("Could not load Form 3CD mapping (%s); using defaults.", exc)
    return dict(DEFAULT_FORM_3CD_MAPPING)


def load_risk_thresholds() -> Dict[str, float]:
    """Load tunable risk thresholds, seeding the file on first run."""
    path = config_dir() / RISK_THRESHOLDS_FILENAME
    thresholds = dict(DEFAULT_RISK_THRESHOLDS)
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key, value in data.items():
                    if key in thresholds:
                        thresholds[key] = float(value)
            return thresholds
        path.write_text(json.dumps(DEFAULT_RISK_THRESHOLDS, indent=2), encoding="utf-8")
    except Exception as exc:
        log.warning("Could not load risk thresholds (%s); using defaults.", exc)
    return thresholds


def clause_for(key: str, mapping: Optional[Dict[str, Dict[str, str]]] = None) -> str:
    """Indicative Form 3CD reference for an issue key."""
    table = mapping or DEFAULT_FORM_3CD_MAPPING
    entry = table.get(key)
    if not entry:
        return UNCERTAIN_POSITION
    return entry.get("clause", UNCERTAIN_POSITION)


# ---------------------------------------------------------------- helpers


def _money(value: Optional[float]) -> str:
    """Format an amount in the Indian grouping convention."""
    if value is None:
        return "not available"
    negative = value < 0
    whole = f"{abs(value):,.2f}"
    # Convert the western grouping produced by format() into lakh/crore groups.
    integer, decimal = f"{abs(value):.2f}".split(".")
    if len(integer) > 3:
        head, tail = integer[:-3], integer[-3:]
        parts: List[str] = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        integer = ",".join(parts + [tail])
    whole = f"{integer}.{decimal}"
    return f"Rs. ({whole})" if negative else f"Rs. {whole}"


def _is_round_number(value: Optional[float], floor: float) -> bool:
    """Detect suspiciously round amounts (exact lakhs / exact 50,000 steps)."""
    if value is None or abs(value) < floor:
        return False
    magnitude = abs(value)
    if magnitude != int(magnitude):
        return False
    return int(magnitude) % 1_00_000 == 0 or int(magnitude) % 50_000 == 0


def _pct_of(value: Optional[float], base: Optional[float]) -> Optional[float]:
    if value is None or base in (None, 0):
        return None
    return (value / base) * 100.0


@dataclass
class RiskContext:
    """Everything the individual checks need, assembled once."""

    dataset: FinancialDataset
    case: Optional[Case] = None
    validations: Sequence[ValidationCheck] = ()
    ratios: Sequence[Ratio] = ()
    thresholds: Dict[str, float] = None  # type: ignore[assignment]
    mapping: Dict[str, Dict[str, str]] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.thresholds is None:
            self.thresholds = dict(DEFAULT_RISK_THRESHOLDS)
        if self.mapping is None:
            self.mapping = dict(DEFAULT_FORM_3CD_MAPPING)

    @property
    def turnover(self) -> Optional[float]:
        return self.dataset.cy("Turnover / Revenue")

    @property
    def constitution(self) -> str:
        return (self.case.constitution if self.case else "") or ""

    @property
    def is_firm_or_proprietor(self) -> bool:
        """Constitutions where personal expenditure needs specific attention."""
        return self.constitution in {
            "Individual",
            "HUF",
            "Partnership Firm",
            "LLP",
            "AOP",
            "BOI",
            "Proprietorship",
        }

    def threshold(self, key: str) -> float:
        return float(self.thresholds.get(key, DEFAULT_RISK_THRESHOLDS.get(key, 0.0)))

    def flag(
        self,
        *,
        level: str,
        area: str,
        observation: str,
        finding_type: str,
        recommended_verification: str,
        head: Optional[str] = None,
        amount: Optional[float] = None,
        previous: Optional[float] = None,
        change: Optional[float] = None,
        relevance: str = "",
        documents: Optional[List[str]] = None,
        clause_key: str = "",
        why: str = "",
    ) -> RiskFlag:
        """Construct a RiskFlag, filling provenance from the dataset."""
        source_doc, source_page = ("", None)
        if head:
            source_doc, source_page = self.dataset.source_of(head)
        return RiskFlag(
            risk_level=level,
            area=area,
            observation=observation,
            amount=amount,
            previous_year_amount=previous,
            change_percent=change,
            source_document=source_doc,
            source_page=source_page,
            recommended_verification=recommended_verification,
            finding_type=finding_type,
            tax_audit_relevance=relevance,
            documents_to_verify=documents or [],
            potential_3cd_clause=clause_for(clause_key, self.mapping) if clause_key else "",
            why_flagged=why,
        )


# =========================================================== the check suite


def check_turnover(ctx: RiskContext) -> List[RiskFlag]:
    """Turnover movement, negative sales and the composition of income."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    cy = dataset.cy("Turnover / Revenue")
    py = dataset.py("Turnover / Revenue")

    if cy is None:
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Turnover / Revenue",
                observation=(
                    "Turnover for the current year could not be established from "
                    "the documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                recommended_verification=(
                    "Obtain the audited Profit and Loss Account and confirm the "
                    "turnover figure, which governs the applicability of tax audit."
                ),
                documents=["Audited Profit and Loss Account", "Trial Balance"],
                why="No turnover figure was recognised in the uploaded documents.",
            )
        )
        return flags

    if cy < 0:
        flags.append(
            ctx.flag(
                level=HIGH,
                area="Turnover / Revenue",
                observation=(
                    f"Turnover is reported as a negative figure of {_money(cy)}. A "
                    "negative revenue balance is unusual and requires examination."
                ),
                finding_type=OBSERVATION,
                head="Turnover / Revenue",
                amount=cy,
                recommended_verification=(
                    "Examine the revenue ledger for the treatment of sales returns, "
                    "rate differences and credit notes, and confirm the presentation "
                    "of net revenue."
                ),
                documents=["Sales ledger", "Credit note register", "Audited P&L"],
                why="A negative turnover balance was extracted.",
            )
        )

    change = percentage_change(cy, py)
    if change is not None and abs(change) >= ctx.threshold("turnover_movement_percent"):
        direction = "increase" if change > 0 else "decrease"
        flags.append(
            ctx.flag(
                level=MEDIUM if abs(change) < 50 else HIGH,
                area="Turnover / Revenue",
                observation=(
                    f"Turnover shows a {direction} of {abs(change):,.1f}%, moving "
                    f"from {_money(py)} to {_money(cy)}. A movement of this order "
                    "warrants understanding of the underlying business reasons."
                ),
                finding_type=OBSERVATION,
                head="Turnover / Revenue",
                amount=cy,
                previous=py,
                change=change,
                recommended_verification=(
                    "Obtain management's explanation for the movement, perform "
                    "cut-off testing around the year end, and review the monthly "
                    "sales trend for unusual concentration in the closing period."
                ),
                relevance=(
                    "Turnover determines the applicability of tax audit and is a "
                    "reported particular in the tax audit report."
                ),
                documents=[
                    "Monthly sales summary",
                    "Sales ledger",
                    "Cut-off documentation around year end",
                ],
                why=f"Year-on-year turnover movement of {change:,.1f}%.",
            )
        )

    # Other income forming a material part of total income.
    other_income = dataset.cy("Other Income")
    share = _pct_of(other_income, cy)
    if share is not None and share >= ctx.threshold("other_income_to_turnover_percent"):
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Turnover / Revenue",
                observation=(
                    f"Other Income of {_money(other_income)} represents "
                    f"{share:,.1f}% of turnover. Income of this magnitude outside "
                    "operating revenue requires examination of its nature and of "
                    "the head under which it is assessable."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Other Income",
                amount=other_income,
                previous=dataset.py("Other Income"),
                change=percentage_change(other_income, dataset.py("Other Income")),
                recommended_verification=(
                    "Obtain a break-up of Other Income and examine the nature of "
                    "each component, the head of income under which it falls, and "
                    "whether it has been correctly included in the computation of "
                    "total income. " + UNCERTAIN_POSITION
                ),
                relevance=(
                    "The classification of income between business income and other "
                    "heads affects the computation of total income and the turnover "
                    "reported for tax audit purposes."
                ),
                documents=["Break-up of Other Income", "Ledger accounts of each component"],
                why=f"Other Income is {share:,.1f}% of turnover.",
            )
        )

    # GST turnover reconciliation is always worth stating as a required step.
    flags.append(
        ctx.flag(
            level=REVIEW,
            area="Turnover / Revenue",
            observation=(
                f"Turnover per the financial statements is {_money(cy)}. This has "
                "not been reconciled with the turnover declared in the goods and "
                "services tax returns, which were not available to this analysis."
            ),
            finding_type=VERIFICATION_REQUIRED,
            head="Turnover / Revenue",
            amount=cy,
            recommended_verification=(
                "Reconcile turnover as per the books with the turnover declared in "
                "the GST returns for the corresponding period, and document the "
                "reasons for any difference."
            ),
            relevance=(
                "A reconciliation between books and indirect tax returns is a "
                "standard element of tax audit documentation."
            ),
            documents=[
                "GST Annual Return",
                "Monthly GST returns for the year",
                "Reconciliation statement between books and GST turnover",
            ],
            clause_key="turnover_reconciliation",
            why="No GST return data was available to reconcile against.",
        )
    )
    return flags


def check_cash(ctx: RiskContext) -> List[RiskFlag]:
    """Cash balances and the possible relevance of the cash-transaction rules."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    cash = dataset.cy("Cash in Hand")
    if cash is None:
        return flags

    previous = dataset.py("Cash in Hand")
    change = percentage_change(cash, previous)
    share = _pct_of(cash, ctx.turnover)

    if cash < 0:
        flags.append(
            ctx.flag(
                level=HIGH,
                area="Cash and Cash Transactions",
                observation=(
                    f"Cash in hand shows a credit (negative) balance of "
                    f"{_money(cash)}. A negative cash balance is not physically "
                    "possible and indicates unrecorded receipts or posting errors."
                ),
                finding_type=OBSERVATION,
                head="Cash in Hand",
                amount=cash,
                previous=previous,
                recommended_verification=(
                    "Examine the cash book for the period, identify the dates on "
                    "which the balance became negative, and obtain explanations "
                    "for the entries concerned."
                ),
                documents=["Cash book", "Cash denomination certificate at year end"],
                why="A negative cash balance was extracted.",
                clause_key="unexplained_credits",
            )
        )
        return flags

    material_by_share = share is not None and share >= ctx.threshold("cash_to_turnover_percent")
    material_by_amount = cash >= ctx.threshold("cash_absolute")

    if material_by_share or material_by_amount:
        share_text = f" representing {share:,.1f}% of turnover" if share is not None else ""
        flags.append(
            ctx.flag(
                level=HIGH if (material_by_share and material_by_amount) else MEDIUM,
                area="Cash and Cash Transactions",
                observation=(
                    f"Cash in hand at the year end is {_money(cash)}{share_text}. "
                    "A cash balance of this size indicates a significant volume of "
                    "cash dealings, which requires examination for the possible "
                    "applicability of the provisions governing cash transactions."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Cash in Hand",
                amount=cash,
                previous=previous,
                change=change,
                recommended_verification=(
                    "Obtain the cash book and examine the pattern and size of cash "
                    "receipts and payments during the year. Requires verification "
                    "for possible applicability of Section 40A(3) in respect of "
                    "cash expenditure, and of Sections 269SS, 269ST and 269T in "
                    "respect of cash receipts, loans and deposits. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Cash expenditure above the prescribed limits may attract "
                    "disallowance under Section 40A(3), and cash receipts, loans and "
                    "repayments may engage Sections 269SS, 269ST and 269T. Whether "
                    "any of these provisions in fact apply can be determined only "
                    "from the underlying transactions."
                ),
                documents=[
                    "Cash book for the full year",
                    "Cash denomination certificate as at the year end",
                    "Details of individual cash receipts and payments above the "
                    "prescribed limits",
                    "Confirmation of cash loans accepted or repaid during the year",
                ],
                clause_key="cash_payments",
                why=(
                    f"Cash in hand of {_money(cash)}"
                    + (f" is {share:,.1f}% of turnover" if share is not None else "")
                    + "."
                ),
            )
        )

    if change is not None and change >= 100.0 and cash >= ctx.threshold("de_minimis_amount"):
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Cash and Cash Transactions",
                observation=(
                    f"Cash in hand increased by {change:,.1f}%, from {_money(previous)} "
                    f"to {_money(cash)}. A movement of this order in the closing cash "
                    "balance requires examination."
                ),
                finding_type=OBSERVATION,
                head="Cash in Hand",
                amount=cash,
                previous=previous,
                change=change,
                recommended_verification=(
                    "Examine cash receipts in the closing weeks of the year and "
                    "confirm the year-end balance against a physical cash "
                    "verification certificate."
                ),
                documents=["Cash book", "Physical cash verification certificate"],
                why=f"Cash balance rose {change:,.1f}% year on year.",
            )
        )
    return flags


def check_loans_and_deposits(ctx: RiskContext) -> List[RiskFlag]:
    """Secured and unsecured borrowings, and related-party lending."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    threshold = ctx.threshold("loan_movement_percent")

    for head, descriptor in (
        ("Secured Loans", "secured borrowings"),
        ("Unsecured Loans", "unsecured borrowings"),
    ):
        cy = dataset.cy(head)
        if cy is None:
            continue
        py = dataset.py(head)
        change = percentage_change(cy, py)

        if cy < 0:
            flags.append(
                ctx.flag(
                    level=MEDIUM,
                    area="Loans and Deposits",
                    observation=(
                        f"{head} shows a debit (negative) balance of {_money(cy)}, "
                        "which is unusual for a liability account."
                    ),
                    finding_type=OBSERVATION,
                    head=head,
                    amount=cy,
                    previous=py,
                    recommended_verification=(
                        "Examine the loan ledger and reconcile with lender "
                        "statements to establish the correct classification."
                    ),
                    documents=["Loan ledger", "Lender confirmation"],
                    why=f"{head} carries a negative balance.",
                )
            )
            continue

        if change is None:
            continue

        if change >= threshold:
            increase = cy - (py or 0.0)
            is_unsecured = head == "Unsecured Loans"
            flags.append(
                ctx.flag(
                    level=HIGH if (is_unsecured and change >= 100) else MEDIUM,
                    area="Loans and Deposits",
                    observation=(
                        f"{head} increased by {change:,.1f}%, from {_money(py)} to "
                        f"{_money(cy)}, an increase of {_money(increase)}. New "
                        f"{descriptor} of this magnitude require examination of the "
                        "identity of the lenders, the mode in which the amounts were "
                        "received, and the genuineness of the credits."
                    ),
                    finding_type=POTENTIAL_TAX_ISSUE,
                    head=head,
                    amount=cy,
                    previous=py,
                    change=change,
                    recommended_verification=(
                        "Obtain a party-wise schedule of loans accepted during the "
                        "year with names, addresses and permanent account numbers, "
                        "together with confirmations and bank statements evidencing "
                        "the mode of receipt. Requires verification for possible "
                        "applicability of Section 68 as to the nature and source of "
                        "the credits, and of Sections 269SS and 269T as to the mode "
                        "of acceptance and repayment. " + UNCERTAIN_POSITION
                    ),
                    relevance=(
                        "Loans and deposits accepted or repaid otherwise than "
                        "through the prescribed banking modes may engage Sections "
                        "269SS and 269T, and unexplained credits may engage Section "
                        "68. Whether these provisions apply is a matter for "
                        "examination of the underlying evidence."
                    ),
                    documents=[
                        "Party-wise schedule of loans accepted and repaid",
                        "Loan confirmations from lenders",
                        "Bank statements evidencing receipt and repayment",
                        "Loan agreements and PAN of lenders",
                    ],
                    clause_key="loans_deposits",
                    why=f"{head} rose {change:,.1f}% year on year.",
                )
            )
        elif change <= -threshold and py:
            flags.append(
                ctx.flag(
                    level=MEDIUM,
                    area="Loans and Deposits",
                    observation=(
                        f"{head} reduced by {abs(change):,.1f}%, from {_money(py)} "
                        f"to {_money(cy)}. Repayments of this magnitude require "
                        "examination of the mode of repayment."
                    ),
                    finding_type=POTENTIAL_TAX_ISSUE,
                    head=head,
                    amount=cy,
                    previous=py,
                    change=change,
                    recommended_verification=(
                        "Obtain a party-wise schedule of repayments with supporting "
                        "bank statements. Requires verification for possible "
                        "applicability of Section 269T in respect of the mode of "
                        "repayment. " + UNCERTAIN_POSITION
                    ),
                    documents=[
                        "Party-wise schedule of loan repayments",
                        "Bank statements evidencing repayment",
                    ],
                    clause_key="loans_deposits",
                    why=f"{head} fell {abs(change):,.1f}% year on year.",
                )
            )

    # Related-party lending is not separately identifiable without the notes.
    if dataset.has("Unsecured Loans"):
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Loans and Deposits",
                observation=(
                    "Whether any part of the unsecured loans represents borrowings "
                    "from directors, partners or other related parties could not be "
                    "determined from the documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                head="Unsecured Loans",
                amount=dataset.cy("Unsecured Loans"),
                recommended_verification=(
                    "Obtain the schedule of unsecured loans identifying loans from "
                    "directors, partners, relatives and other related parties, "
                    "together with confirmations and the rate of interest applied."
                ),
                relevance=(
                    "Borrowings from and payments to specified persons require "
                    "separate consideration, including for the purposes of Section "
                    "40A(2)(b)."
                ),
                documents=[
                    "Schedule of unsecured loans with lender relationship",
                    "Related party disclosures in the Notes to Accounts",
                ],
                clause_key="related_party",
                why="No related-party break-up of unsecured loans was available.",
            )
        )
    return flags


def check_receivables(ctx: RiskContext) -> List[RiskFlag]:
    """Trade receivables movement, negative balances and bad debt write-offs."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    cy = dataset.cy("Trade Receivables")
    py = dataset.py("Trade Receivables")

    if cy is not None and cy < 0:
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Trade Receivables",
                observation=(
                    f"Trade Receivables show a net credit balance of {_money(cy)}, "
                    "which is unusual for an asset account and may indicate advances "
                    "from customers classified incorrectly."
                ),
                finding_type=OBSERVATION,
                head="Trade Receivables",
                amount=cy,
                previous=py,
                recommended_verification=(
                    "Obtain the party-wise ageing and identify accounts with credit "
                    "balances for reclassification to advances from customers."
                ),
                documents=["Party-wise debtors ageing", "Debtors ledger"],
                why="Trade Receivables carry a negative balance.",
            )
        )

    change = percentage_change(cy, py)
    turnover_change = percentage_change(
        dataset.cy("Turnover / Revenue"), dataset.py("Turnover / Revenue")
    )
    if change is not None and change >= ctx.threshold("receivable_spike_percent"):
        comparison = ""
        if turnover_change is not None:
            comparison = (
                f" over the same period turnover moved by {turnover_change:,.1f}%, "
                "so the receivable movement is disproportionate to the change in "
                "business volume"
            )
        flags.append(
            ctx.flag(
                level=HIGH if change >= 75 else MEDIUM,
                area="Trade Receivables",
                observation=(
                    f"Trade Receivables increased by {change:,.1f}%, from "
                    f"{_money(py)} to {_money(cy)};{comparison}."
                ),
                finding_type=OBSERVATION,
                head="Trade Receivables",
                amount=cy,
                previous=py,
                change=change,
                recommended_verification=(
                    "Obtain the party-wise ageing of receivables, examine balances "
                    "outstanding beyond the normal credit period, review subsequent "
                    "realisation after the year end, and obtain external "
                    "confirmations for material balances."
                ),
                relevance=(
                    "A disproportionate increase in receivables may indicate revenue "
                    "cut-off issues or recoverability concerns requiring examination."
                ),
                documents=[
                    "Party-wise debtors ageing schedule",
                    "Subsequent realisation details after the year end",
                    "Balance confirmations from major debtors",
                ],
                why=f"Receivables rose {change:,.1f}% year on year.",
            )
        )

    bad_debts = dataset.cy("Bad Debts")
    if bad_debts is not None and bad_debts >= ctx.threshold("de_minimis_amount"):
        bd_prev = dataset.py("Bad Debts")
        bd_change = percentage_change(bad_debts, bd_prev)
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Trade Receivables",
                observation=(
                    f"Bad debts of {_money(bad_debts)} have been written off during "
                    "the year"
                    + (f", against {_money(bd_prev)} in the previous year" if bd_prev is not None else "")
                    + ". The basis of the write-off requires examination."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Bad Debts",
                amount=bad_debts,
                previous=bd_prev,
                change=bd_change,
                recommended_verification=(
                    "Obtain a party-wise list of the debts written off, confirm that "
                    "the amounts were taken into account in computing income of the "
                    "current or an earlier year, and confirm that the debts have "
                    "actually been written off in the books. " + UNCERTAIN_POSITION
                ),
                relevance=(
                    "The deductibility of bad debts depends on conditions that must "
                    "be verified against the underlying records."
                ),
                documents=[
                    "Party-wise details of debts written off",
                    "Evidence of recovery efforts",
                    "Board or partner approval for the write-off",
                ],
                why="Bad debts were charged to the Profit and Loss Account.",
            )
        )
    return flags


def check_payables(ctx: RiskContext) -> List[RiskFlag]:
    """Trade payables, MSME dues and statutory liabilities."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset

    cy = dataset.cy("Trade Payables")
    py = dataset.py("Trade Payables")
    change = percentage_change(cy, py)

    if cy is not None and cy < 0:
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Trade Payables",
                observation=(
                    f"Trade Payables show a net debit balance of {_money(cy)}, which "
                    "is unusual for a liability account and may indicate advances to "
                    "suppliers classified incorrectly."
                ),
                finding_type=OBSERVATION,
                head="Trade Payables",
                amount=cy,
                previous=py,
                recommended_verification=(
                    "Obtain the party-wise creditors listing and identify debit "
                    "balances for reclassification to advances to suppliers."
                ),
                documents=["Party-wise creditors listing"],
                why="Trade Payables carry a negative balance.",
            )
        )

    if change is not None and change >= ctx.threshold("payable_spike_percent"):
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Trade Payables",
                observation=(
                    f"Trade Payables increased by {change:,.1f}%, from {_money(py)} "
                    f"to {_money(cy)}. The composition and ageing of the increase "
                    "requires examination."
                ),
                finding_type=OBSERVATION,
                head="Trade Payables",
                amount=cy,
                previous=py,
                change=change,
                recommended_verification=(
                    "Obtain the party-wise creditors ageing, identify balances "
                    "outstanding for extended periods, and obtain confirmations for "
                    "material balances."
                ),
                documents=[
                    "Party-wise creditors ageing schedule",
                    "Balance confirmations from major creditors",
                ],
                why=f"Payables rose {change:,.1f}% year on year.",
            )
        )

    if cy is not None:
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Trade Payables",
                observation=(
                    "The ageing of trade payables and the existence of long "
                    "outstanding creditor balances could not be determined from the "
                    "documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                head="Trade Payables",
                amount=cy,
                recommended_verification=(
                    "Obtain the creditors ageing schedule and examine balances "
                    "outstanding beyond a reasonable period, including whether any "
                    "liabilities have ceased to exist."
                ),
                documents=["Creditors ageing schedule", "Party confirmations"],
                why="No ageing information was available for trade payables.",
            )
        )

    msme = dataset.cy("MSME Payables")
    if msme is not None and msme > 0:
        msme_prev = dataset.py("MSME Payables")
        flags.append(
            ctx.flag(
                level=HIGH,
                area="Statutory and Tax Audit Review",
                observation=(
                    f"Amounts payable to micro and small enterprises of "
                    f"{_money(msme)} are outstanding at the year end"
                    + (f", against {_money(msme_prev)} in the previous year" if msme_prev is not None else "")
                    + ". The period for which these dues have remained outstanding "
                    "requires examination."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="MSME Payables",
                amount=msme,
                previous=msme_prev,
                change=percentage_change(msme, msme_prev),
                recommended_verification=(
                    "Obtain the party-wise listing of dues to micro and small "
                    "enterprises together with the registration particulars of each "
                    "supplier and the due date and actual date of payment. Requires "
                    "verification for possible applicability of Section 43B in "
                    "respect of sums payable to micro and small enterprises. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Sums payable to micro and small enterprises beyond the "
                    "prescribed period may be allowable only on actual payment under "
                    "Section 43B. Whether the provision applies depends on the "
                    "supplier's registration status and the agreed credit terms."
                ),
                documents=[
                    "Party-wise MSME dues with registration certificates",
                    "Ageing of MSME dues with due dates and payment dates",
                    "Management representation on MSME classification",
                ],
                clause_key="msme_dues",
                why="Outstanding dues to micro and small enterprises were identified.",
            )
        )
    else:
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Statutory and Tax Audit Review",
                observation=(
                    "No separate disclosure of dues to micro and small enterprises "
                    "was identified in the documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                recommended_verification=(
                    "Confirm whether any creditors are registered as micro or small "
                    "enterprises and obtain the required disclosure, since Section "
                    "43B considerations may arise. " + UNCERTAIN_POSITION
                ),
                documents=[
                    "Supplier master with MSME registration status",
                    "Management representation on MSME dues",
                ],
                clause_key="msme_dues",
                why="MSME payable disclosure was not identified.",
            )
        )
    return flags


def check_statutory_dues(ctx: RiskContext) -> List[RiskFlag]:
    """Statutory liabilities outstanding at the year end (Section 43B areas)."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    statutory = dataset.cy("Statutory Liabilities")
    if statutory is None or statutory <= 0:
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Statutory and Tax Audit Review",
                observation=(
                    "Statutory dues outstanding at the year end could not be "
                    "separately identified from the documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                recommended_verification=(
                    "Obtain a schedule of statutory dues outstanding at the year end "
                    "showing the nature, amount, due date and date of actual payment "
                    "for each item. Requires verification for possible applicability "
                    "of Section 43B. " + UNCERTAIN_POSITION
                ),
                documents=[
                    "Schedule of statutory dues outstanding at the year end",
                    "Challans evidencing payment after the year end",
                ],
                clause_key="section_43b",
                why="No statutory dues balance was identified.",
            )
        )
        return flags

    previous = dataset.py("Statutory Liabilities")
    flags.append(
        ctx.flag(
            level=HIGH,
            area="Statutory and Tax Audit Review",
            observation=(
                f"Statutory dues of {_money(statutory)} are outstanding at the year "
                "end. The nature of each due, the date on which it became payable "
                "and the date of actual payment require examination."
            ),
            finding_type=POTENTIAL_TAX_ISSUE,
            head="Statutory Liabilities",
            amount=statutory,
            previous=previous,
            change=percentage_change(statutory, previous),
            recommended_verification=(
                "Obtain an item-wise schedule of statutory dues covering taxes, "
                "duties and cess, provident fund and employees' state insurance "
                "contributions, bonus, leave encashment and interest payable to "
                "specified institutions, showing for each the nature, the amount, "
                "the reason for non-payment and the date of payment if paid before "
                "the due date for furnishing the return. Requires verification for "
                "possible applicability of Section 43B. " + UNCERTAIN_POSITION
            ),
            relevance=(
                "Sums referred to in Section 43B are allowable only on actual "
                "payment within the prescribed time. Whether any amount is "
                "disallowable depends on the nature of the due and the date of "
                "payment, which must be verified from the records."
            ),
            documents=[
                "Item-wise schedule of statutory dues with due dates",
                "Challans and payment evidence for dues paid after the year end",
                "Provident fund and employees' state insurance returns",
                "Details of interest payable to banks and financial institutions",
            ],
            clause_key="section_43b",
            why="Statutory dues were outstanding at the balance sheet date.",
        )
    )
    return flags


# --------------------------------------------------------- expense analysis

# Expense heads on which tax is commonly deductible at source. Used only to
# recommend verification; no conclusion on deductibility is drawn.
TDS_SENSITIVE_HEADS: Dict[str, str] = {
    "Finance Cost": "interest payments",
    "Professional Fees": "fees for professional or technical services",
    "Legal Expenses": "legal and professional payments",
    "Commission & Brokerage": "commission and brokerage",
    "Rent": "rent",
    "Employee Cost": "salaries and wages",
    "Director / Partner Remuneration": "remuneration to directors or partners",
    "Advertisement & Publicity": "advertising and contract payments",
    "Freight & Carriage": "payments to transporters and contractors",
    "Repairs & Maintenance": "contract payments for repairs and maintenance",
}

# Heads where the expenditure may be capital rather than revenue in nature.
CAPITAL_REVIEW_HEADS = {
    "Repairs & Maintenance": "repairs, renovation and refurbishment",
    "Miscellaneous Expenses": "items grouped under miscellaneous expenditure",
}

# Heads whose allowability is restricted or requires specific examination.
ALLOWABILITY_HEADS: Dict[str, str] = {
    "Penalties & Fines": (
        "Expenditure in the nature of penalties and fines requires examination as "
        "to whether it is compensatory or penal in character, since expenditure "
        "incurred for a purpose which is an offence or prohibited by law is not "
        "allowable."
    ),
    "Donations": (
        "Donations charged to the Profit and Loss Account require examination, "
        "since a donation is ordinarily not allowable as business expenditure and "
        "any deduction available is claimed separately in the computation of total "
        "income."
    ),
    "CSR Expenditure": (
        "Expenditure on corporate social responsibility requires examination, "
        "since such expenditure is ordinarily not treated as expenditure incurred "
        "for the purposes of the business."
    ),
    "Prior Period Items": (
        "Prior period items charged to the current year's Profit and Loss Account "
        "require examination as to the year to which the expenditure relates."
    ),
    "Provisions": (
        "Provisions charged to the Profit and Loss Account require examination as "
        "to whether they represent an ascertained liability."
    ),
}


def check_expenses(ctx: RiskContext) -> List[RiskFlag]:
    """Year-on-year spikes, ratio anomalies, round numbers and negatives."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    turnover = ctx.turnover
    spike = ctx.threshold("expense_spike_percent")
    high_spike = ctx.threshold("expense_high_spike_percent")
    de_minimis = ctx.threshold("de_minimis_amount")

    for head in EXPENSE_HEADS:
        cy = dataset.cy(head)
        if cy is None:
            continue
        py = dataset.py(head)
        change = percentage_change(cy, py)

        # Negative expense balances.
        if cy < 0:
            flags.append(
                ctx.flag(
                    level=MEDIUM,
                    area="Expense Analysis",
                    observation=(
                        f"{head} shows a net credit (negative) balance of "
                        f"{_money(cy)}, which is unusual for an expense head."
                    ),
                    finding_type=OBSERVATION,
                    head=head,
                    amount=cy,
                    previous=py,
                    recommended_verification=(
                        f"Examine the {head} ledger for credits, reversals and "
                        "reclassification entries passed during the year."
                    ),
                    documents=[f"{head} ledger account"],
                    why=f"{head} carries a negative balance.",
                )
            )
            continue

        if cy < de_minimis:
            continue

        # Year-on-year spike.
        if change is not None and change >= spike:
            flags.append(
                ctx.flag(
                    level=HIGH if change >= high_spike else MEDIUM,
                    area="Expense Analysis",
                    observation=(
                        f"{head} increased by {change:,.1f}%, from {_money(py)} to "
                        f"{_money(cy)}. An increase of this order in a single "
                        "expense head requires examination of the underlying "
                        "vouchers and the business purpose of the expenditure."
                    ),
                    finding_type=OBSERVATION,
                    head=head,
                    amount=cy,
                    previous=py,
                    change=change,
                    recommended_verification=(
                        f"Obtain the ledger account of {head} together with a "
                        "break-up of major items, examine supporting vouchers for "
                        "the significant additions, and obtain management's "
                        "explanation for the increase."
                    ),
                    relevance=(
                        "Material movements in expense heads require examination as "
                        "to the nature, business purpose and allowability of the "
                        "expenditure."
                    ),
                    documents=[
                        f"{head} ledger account",
                        "Supporting invoices and vouchers for major items",
                        "Management explanation for the movement",
                    ],
                    why=f"{head} rose {change:,.1f}% year on year.",
                )
            )

        # Disproportionate ratio to turnover.
        share = _pct_of(cy, turnover)
        limit = (
            ctx.threshold("misc_expense_to_turnover_percent")
            if head == "Miscellaneous Expenses"
            else ctx.threshold("expense_to_turnover_percent")
        )
        if share is not None and share >= limit and head not in {"Purchases", "Employee Cost"}:
            flags.append(
                ctx.flag(
                    level=MEDIUM,
                    area="Expense Analysis",
                    observation=(
                        f"{head} of {_money(cy)} represents {share:,.1f}% of "
                        "turnover, which is a significant proportion for this head "
                        "and requires examination of its composition."
                    ),
                    finding_type=OBSERVATION,
                    head=head,
                    amount=cy,
                    previous=py,
                    change=change,
                    recommended_verification=(
                        f"Obtain a detailed break-up of {head} and examine the "
                        "nature and business purpose of the principal items."
                    ),
                    documents=[f"Detailed break-up of {head}", "Sample vouchers"],
                    why=f"{head} is {share:,.1f}% of turnover.",
                )
            )

        # Round-number amounts.
        if _is_round_number(cy, ctx.threshold("round_number_floor")):
            flags.append(
                ctx.flag(
                    level=REVIEW,
                    area="Expense Analysis",
                    observation=(
                        f"{head} is recorded at the exactly round figure of "
                        f"{_money(cy)}. Round-sum amounts may indicate estimated or "
                        "provisional entries rather than amounts supported by "
                        "individual invoices."
                    ),
                    finding_type=VERIFICATION_REQUIRED,
                    head=head,
                    amount=cy,
                    previous=py,
                    recommended_verification=(
                        f"Examine whether the {head} charge represents actual "
                        "invoiced expenditure or a round-sum provision, and obtain "
                        "the supporting computation."
                    ),
                    documents=[f"{head} ledger account", "Supporting invoices"],
                    why=f"{head} is an exactly round amount.",
                )
            )

    return flags


def check_tds_areas(ctx: RiskContext) -> List[RiskFlag]:
    """Expense heads on which tax deduction at source needs verification."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    de_minimis = ctx.threshold("de_minimis_amount")

    present: List[str] = []
    total = 0.0
    for head in TDS_SENSITIVE_HEADS:
        amount = dataset.cy(head)
        if amount is not None and amount >= de_minimis:
            present.append(head)
            total += amount

    if not present:
        return flags

    descriptions = ", ".join(
        f"{head} ({_money(dataset.cy(head))})" for head in present
    )
    flags.append(
        ctx.flag(
            level=HIGH,
            area="Tax Deduction at Source",
            observation=(
                "The Profit and Loss Account includes expense heads on which tax is "
                f"commonly deductible at source, aggregating {_money(total)}: "
                f"{descriptions}. Whether tax has been deducted and paid within the "
                "prescribed time on each of these payments requires verification."
            ),
            finding_type=POTENTIAL_TAX_ISSUE,
            amount=total,
            recommended_verification=(
                "For each of these heads, obtain a reconciliation between the "
                "expenditure charged and the payments on which tax was deducted, "
                "together with the quarterly statements of tax deducted at source "
                "and the challans evidencing payment. Requires verification for "
                "possible applicability of Section 40(a)(ia) in respect of any "
                "payment on which tax was deductible but not deducted or not paid "
                "within the prescribed time. " + UNCERTAIN_POSITION
            ),
            relevance=(
                "Expenditure on which tax was deductible at source but was not "
                "deducted, or was deducted but not paid within the prescribed time, "
                "may attract disallowance under Section 40(a)(ia). Whether any "
                "disallowance arises can be determined only from the payment-wise "
                "records."
            ),
            documents=[
                "Quarterly statements of tax deducted at source for all quarters",
                "Reconciliation of expenses with the TDS statements",
                "Challans evidencing payment of tax deducted",
                "Party-wise details of payments and tax deducted for each head",
                "Certificates for lower or nil deduction, where applicable",
            ],
            clause_key="tds_disallowance",
            why="Expense heads commonly attracting TDS are present in the accounts.",
        )
    )

    for head in present:
        amount = dataset.cy(head)
        descriptor = TDS_SENSITIVE_HEADS[head]
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Tax Deduction at Source",
                observation=(
                    f"{head} of {_money(amount)} has been charged, being in the "
                    f"nature of {descriptor}. TDS verification is recommended for "
                    "this head."
                ),
                finding_type=VERIFICATION_REQUIRED,
                head=head,
                amount=amount,
                previous=dataset.py(head),
                change=percentage_change(amount, dataset.py(head)),
                recommended_verification=(
                    f"Verify that tax has been deducted at the applicable rate on "
                    f"the payments comprising {head}, and that the tax deducted has "
                    "been paid within the prescribed time. " + UNCERTAIN_POSITION
                ),
                documents=[
                    f"Party-wise break-up of {head}",
                    "TDS statements and challans for the related payments",
                ],
                clause_key="tds_disallowance",
                why=f"{head} is a head on which tax is commonly deductible at source.",
            )
        )
    return flags


def check_allowability(ctx: RiskContext) -> List[RiskFlag]:
    """Heads whose allowability requires specific examination."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    for head, relevance in ALLOWABILITY_HEADS.items():
        amount = dataset.cy(head)
        if amount is None or abs(amount) < 1:
            continue
        flags.append(
            ctx.flag(
                level=HIGH if head in {"Penalties & Fines"} else MEDIUM,
                area="Expense Analysis",
                observation=(
                    f"{head} of {_money(amount)} has been debited to the Profit and "
                    "Loss Account. The allowability of this expenditure requires "
                    "examination."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head=head,
                amount=amount,
                previous=dataset.py(head),
                change=percentage_change(amount, dataset.py(head)),
                recommended_verification=(
                    f"Obtain a break-up of {head} with supporting documents and "
                    "examine the nature of each item and its allowability in "
                    "computing business income. " + UNCERTAIN_POSITION
                ),
                relevance=relevance,
                documents=[
                    f"{head} ledger account",
                    f"Supporting documents for each item of {head}",
                ],
                clause_key="inadmissible_expenditure",
                why=f"{head} was charged to the Profit and Loss Account.",
            )
        )
    return flags


def check_capital_vs_revenue(ctx: RiskContext) -> List[RiskFlag]:
    """Expenditure that may be capital rather than revenue in nature."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    de_minimis = ctx.threshold("de_minimis_amount")

    for head, descriptor in CAPITAL_REVIEW_HEADS.items():
        amount = dataset.cy(head)
        if amount is None or amount < de_minimis:
            continue
        previous = dataset.py(head)
        change = percentage_change(amount, previous)
        # Only raise where the amount is material or has moved sharply.
        share = _pct_of(amount, ctx.turnover)
        material = (share is not None and share >= 1.0) or (
            change is not None and change >= ctx.threshold("expense_spike_percent")
        )
        if not material:
            continue
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Capital versus Revenue Expenditure",
                observation=(
                    f"{head} of {_money(amount)} has been charged to revenue. "
                    f"Expenditure of this nature, covering {descriptor}, requires "
                    "examination as to whether any part represents capital "
                    "expenditure giving enduring benefit."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head=head,
                amount=amount,
                previous=previous,
                change=change,
                recommended_verification=(
                    f"Obtain an item-wise break-up of {head} and examine whether any "
                    "item represents expenditure on computers, software, furniture, "
                    "vehicles, renovation or improvement that ought to be "
                    "capitalised and depreciated rather than charged to revenue. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Capital expenditure debited to the Profit and Loss Account is a "
                    "matter for reporting and requires adjustment in computing "
                    "business income."
                ),
                documents=[
                    f"Item-wise break-up of {head}",
                    "Major invoices to establish the nature of the expenditure",
                    "Fixed asset additions register",
                ],
                clause_key="capital_expenditure",
                why=f"{head} is material or has moved sharply.",
            )
        )
    return flags


def check_personal_expenditure(ctx: RiskContext) -> List[RiskFlag]:
    """Possible personal or non-business expenditure.

    Raised only for constitutions where the proprietor's or partners' personal
    expenditure can realistically be routed through the business accounts.
    """
    flags: List[RiskFlag] = []
    if not ctx.is_firm_or_proprietor:
        return flags

    dataset = ctx.dataset
    candidates = [
        ("Travelling & Conveyance", "travelling, conveyance and vehicle running"),
        ("Communication Expenses", "telephone and communication"),
        ("Insurance", "insurance premia"),
        ("Miscellaneous Expenses", "miscellaneous and general expenditure"),
    ]
    present = [
        (head, descriptor)
        for head, descriptor in candidates
        if dataset.cy(head) is not None
        and dataset.cy(head) >= ctx.threshold("de_minimis_amount")
    ]
    if not present:
        return flags

    listing = ", ".join(
        f"{head} ({_money(dataset.cy(head))})" for head, _ in present
    )
    flags.append(
        ctx.flag(
            level=MEDIUM,
            area="Personal and Non-Business Expenditure",
            observation=(
                f"The assessee is constituted as a {ctx.constitution or 'non-corporate entity'}. "
                "The Profit and Loss Account includes heads of the kind that can "
                f"contain an element of personal expenditure: {listing}. Whether any "
                "part of this expenditure is personal in nature requires examination."
            ),
            finding_type=POTENTIAL_TAX_ISSUE,
            amount=sum(dataset.cy(h) or 0.0 for h, _ in present),
            recommended_verification=(
                "Examine whether any part of these expenses relates to personal "
                "vehicle use, personal travel, household expenditure, life insurance "
                "premia, personal telephone use or drawings, and whether an "
                "appropriate disallowance for the personal element has been made in "
                "the computation of income. " + UNCERTAIN_POSITION
            ),
            relevance=(
                "Expenditure of a personal nature is not allowable as business "
                "expenditure. The extent of any personal element is a matter of "
                "fact requiring examination of the underlying vouchers."
            ),
            documents=[
                "Ledger accounts of the heads listed",
                "Sample vouchers for significant items",
                "Details of the proprietor's or partners' drawings",
                "Management representation on the personal element of expenditure",
            ],
            clause_key="inadmissible_expenditure",
            why=(
                "The constitution of the assessee makes personal expenditure through "
                "the business accounts a realistic possibility."
            ),
        )
    )
    return flags


def check_related_party(ctx: RiskContext) -> List[RiskFlag]:
    """Payments to persons who may be specified persons."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset
    remuneration = dataset.cy("Director / Partner Remuneration")

    if remuneration is not None and remuneration > 0:
        previous = dataset.py("Director / Partner Remuneration")
        change = percentage_change(remuneration, previous)
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Related Party Review",
                observation=(
                    f"Remuneration to directors or partners of {_money(remuneration)} "
                    "has been charged"
                    + (f", against {_money(previous)} in the previous year" if previous is not None else "")
                    + ". Payments to persons connected with the assessee require "
                    "examination as to reasonableness."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Director / Partner Remuneration",
                amount=remuneration,
                previous=previous,
                change=change,
                recommended_verification=(
                    "Obtain the particulars of remuneration paid to each director or "
                    "partner, together with the authorising resolution or partnership "
                    "deed, and examine whether the payments are reasonable having "
                    "regard to the services rendered and the fair market value. "
                    "Requires verification for possible applicability of Section "
                    "40A(2)(b) in respect of payments to specified persons. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Payments to specified persons that are excessive or "
                    "unreasonable having regard to the fair market value may attract "
                    "disallowance under Section 40A(2)(b). For a firm, the "
                    "deductibility of partner remuneration is additionally governed "
                    "by the terms of the partnership deed."
                ),
                documents=[
                    "Person-wise details of remuneration paid",
                    "Board resolution or partnership deed authorising the payment",
                    "Related party disclosures in the Notes to Accounts",
                ],
                clause_key="related_party",
                why="Remuneration to directors or partners was identified.",
            )
        )

    flags.append(
        ctx.flag(
            level=REVIEW,
            area="Related Party Review",
            observation=(
                "A complete schedule of transactions with specified persons could "
                "not be compiled, as the Notes to Accounts containing the related "
                "party disclosures were not available to this analysis."
            ),
            finding_type=VERIFICATION_REQUIRED,
            recommended_verification=(
                "Obtain the related party disclosures from the Notes to Accounts and "
                "a party-wise schedule of all transactions with specified persons, "
                "covering purchases, sales, services, remuneration, interest, rent "
                "and loans. Requires verification for possible applicability of "
                "Section 40A(2)(b). " + UNCERTAIN_POSITION
            ),
            documents=[
                "Notes to Accounts including related party disclosures",
                "List of specified persons with relationship",
                "Party-wise schedule of related party transactions",
            ],
            clause_key="related_party",
            why="Related party disclosures were not available.",
        )
    )
    return flags


def check_depreciation_and_assets(ctx: RiskContext) -> List[RiskFlag]:
    """Depreciation, asset movements and capital work in progress."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset

    depreciation = dataset.cy("Depreciation")
    if depreciation is not None:
        flags.append(
            ctx.flag(
                level=REVIEW,
                area="Depreciation Review",
                observation=(
                    f"Depreciation of {_money(depreciation)} has been charged in the "
                    "books. Depreciation allowable under the Income-tax Act could "
                    "not be computed, because asset-wise particulars including the "
                    "block of assets, the date of put to use and the rate applicable "
                    "were not available in the documents uploaded."
                ),
                finding_type=VERIFICATION_REQUIRED,
                head="Depreciation",
                amount=depreciation,
                previous=dataset.py("Depreciation"),
                change=percentage_change(depreciation, dataset.py("Depreciation")),
                recommended_verification=(
                    "Obtain the depreciation schedule under the Income-tax Act "
                    "showing, for each block of assets, the opening written down "
                    "value, additions with dates of put to use, deletions, the rate "
                    "applied and the closing written down value, and reconcile the "
                    "tax depreciation with the depreciation charged in the books. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Depreciation allowable under the Income-tax Act is computed on "
                    "the block of assets basis and commonly differs from book "
                    "depreciation. The difference requires adjustment in computing "
                    "total income."
                ),
                documents=[
                    "Depreciation schedule as per the Income-tax Act",
                    "Fixed asset register with dates of put to use",
                    "Invoices for additions made during the year",
                    "Details of assets sold or discarded during the year",
                ],
                clause_key="depreciation",
                why="Asset-level particulars needed for tax depreciation were absent.",
            )
        )

    ppe_cy = dataset.cy("Property Plant & Equipment")
    ppe_py = dataset.py("Property Plant & Equipment")
    ppe_change = percentage_change(ppe_cy, ppe_py)
    if ppe_change is not None and abs(ppe_change) >= 20.0:
        movement = "additions" if ppe_change > 0 else "disposals or write-downs"
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Depreciation Review",
                observation=(
                    f"Property, plant and equipment moved by {ppe_change:,.1f}%, "
                    f"from {_money(ppe_py)} to {_money(ppe_cy)}, indicating "
                    f"significant {movement} during the year."
                ),
                finding_type=OBSERVATION,
                head="Property Plant & Equipment",
                amount=ppe_cy,
                previous=ppe_py,
                change=ppe_change,
                recommended_verification=(
                    "Obtain the fixed asset movement schedule and examine the "
                    "additions and deletions, including the dates on which assets "
                    "were put to use, since assets put to use for less than the "
                    "prescribed period in the year attract a restricted rate of "
                    "depreciation. Examine the computation of profit or loss on "
                    "assets disposed of. " + UNCERTAIN_POSITION
                ),
                documents=[
                    "Fixed asset movement schedule",
                    "Invoices for additions with dates of put to use",
                    "Sale documents for assets disposed of",
                ],
                clause_key="depreciation",
                why=f"Fixed assets moved {ppe_change:,.1f}% year on year.",
            )
        )

    cwip_cy = dataset.cy("Capital Work in Progress")
    cwip_py = dataset.py("Capital Work in Progress")
    cwip_change = percentage_change(cwip_cy, cwip_py)
    if cwip_cy is not None and cwip_cy > 0 and (cwip_change is None or cwip_change >= 25.0):
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Depreciation Review",
                observation=(
                    f"Capital work in progress stands at {_money(cwip_cy)}"
                    + (f", against {_money(cwip_py)} in the previous year" if cwip_py is not None else "")
                    + ". Assets under construction do not qualify for depreciation "
                    "until put to use, and the capitalisation of related costs "
                    "requires examination."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Capital Work in Progress",
                amount=cwip_cy,
                previous=cwip_py,
                change=cwip_change,
                recommended_verification=(
                    "Obtain the composition of capital work in progress, examine the "
                    "nature of the costs capitalised including any borrowing costs, "
                    "and confirm the date on which each asset was put to use. "
                    + UNCERTAIN_POSITION
                ),
                documents=[
                    "Composition of capital work in progress",
                    "Details of costs capitalised including interest",
                    "Completion certificates and dates of put to use",
                ],
                clause_key="depreciation",
                why="Capital work in progress is material or has grown sharply.",
            )
        )
    return flags


def check_provisions_and_contingencies(ctx: RiskContext) -> List[RiskFlag]:
    """Provisions on either side of the accounts, and contingent liabilities."""
    flags: List[RiskFlag] = []
    dataset = ctx.dataset

    liability_provision = dataset.cy("Provisions (Liability)")
    if liability_provision is not None and liability_provision > 0:
        flags.append(
            ctx.flag(
                level=MEDIUM,
                area="Provisions and Contingent Liabilities",
                observation=(
                    f"Provisions of {_money(liability_provision)} are carried in the "
                    "Balance Sheet. The nature of each provision and whether it "
                    "represents an ascertained liability requires examination."
                ),
                finding_type=POTENTIAL_TAX_ISSUE,
                head="Provisions (Liability)",
                amount=liability_provision,
                previous=dataset.py("Provisions (Liability)"),
                change=percentage_change(
                    liability_provision, dataset.py("Provisions (Liability)")
                ),
                recommended_verification=(
                    "Obtain an item-wise break-up of the provisions with the basis "
                    "of computation, and examine whether each represents an "
                    "ascertained liability allowable in computing business income or "
                    "an unascertained provision requiring adjustment. "
                    + UNCERTAIN_POSITION
                ),
                relevance=(
                    "Provisions for unascertained liabilities are ordinarily not "
                    "allowable in computing business income."
                ),
                documents=[
                    "Item-wise break-up of provisions with basis of computation",
                    "Actuarial valuation report, where applicable",
                    "Movement in each provision during the year",
                ],
                clause_key="provisions_contingent",
                why="Provisions are carried in the Balance Sheet.",
            )
        )

    flags.append(
        ctx.flag(
            level=REVIEW,
            area="Provisions and Contingent Liabilities",
            observation=(
                "Contingent liabilities and commitments could not be examined, as "
                "the Notes to Accounts were not available to this analysis."
            ),
            finding_type=VERIFICATION_REQUIRED,
            recommended_verification=(
                "Obtain the Notes to Accounts setting out contingent liabilities and "
                "commitments, together with the status of any pending litigation and "
                "demands under any law, and examine the adequacy of the disclosure."
            ),
            documents=[
                "Notes to Accounts including contingent liabilities",
                "Details of pending litigation and statutory demands",
                "Legal counsel confirmations, where applicable",
            ],
            clause_key="provisions_contingent",
            why="Notes to Accounts were not available.",
        )
    )
    return flags


def check_validation_failures(ctx: RiskContext) -> List[RiskFlag]:
    """Turn failed accounting-identity checks into risk flags."""
    flags: List[RiskFlag] = []
    for check in ctx.validations:
        if not check.applicable:
            flags.append(
                ctx.flag(
                    level=REVIEW,
                    area="Accounting Validation",
                    observation=check.message,
                    finding_type=VERIFICATION_REQUIRED,
                    recommended_verification=(
                        "Upload the complete financial statements, or enter the "
                        "missing figures on the verification screen, so that the "
                        "arithmetical accuracy of the statements can be confirmed."
                    ),
                    documents=["Complete audited financial statements"],
                    why=f"{check.name} could not be performed.",
                )
            )
            continue
        if check.passed:
            continue
        flags.append(
            ctx.flag(
                level=HIGH,
                area="Accounting Validation",
                observation=check.message,
                finding_type=CALCULATION,
                amount=check.reported,
                previous=check.expected,
                recommended_verification=(
                    "Reconcile the figures against the audited financial statements "
                    "and the trial balance, and confirm that all line items have "
                    "been captured. Where the difference persists in the audited "
                    "accounts themselves, obtain management's explanation."
                ),
                relevance=(
                    "The arithmetical accuracy of the financial statements underpins "
                    "every figure reported in the tax audit."
                ),
                documents=[
                    "Audited financial statements",
                    "Trial balance as at the year end",
                    "Reconciliation of the difference",
                ],
                why=f"{check.name} did not agree within the tolerance applied.",
            )
        )
    return flags


def check_low_confidence_extractions(ctx: RiskContext) -> List[RiskFlag]:
    """Surface figures the extraction engine was not confident about."""
    flags: List[RiskFlag] = []
    weak = [
        figure
        for figure in ctx.dataset.figures.values()
        if figure.confidence == "Low"
    ]
    if not weak:
        return flags
    listing = ", ".join(
        f"{f.canonical_head} (read as '{f.raw_heading}')" for f in weak[:10]
    )
    flags.append(
        ctx.flag(
            level=REVIEW,
            area="Data Quality",
            observation=(
                f"{len(weak)} financial head(s) were extracted with low confidence "
                f"and may have been read or classified incorrectly: {listing}."
            ),
            finding_type=VERIFICATION_REQUIRED,
            recommended_verification=(
                "Review these figures on the verification screen against the source "
                "documents and correct them before the analysis is relied upon."
            ),
            documents=["Source financial statements"],
            why="One or more figures were matched with low confidence.",
        )
    )
    return flags


def check_tax_audit_applicability(ctx: RiskContext) -> List[RiskFlag]:
    """State the turnover position without concluding on applicability."""
    flags: List[RiskFlag] = []
    turnover = ctx.turnover
    if turnover is None:
        return flags
    declared = (ctx.case.tax_audit_applicable if ctx.case else "") or "To be determined"
    flags.append(
        ctx.flag(
            level=INFORMATIONAL,
            area="Tax Audit Applicability",
            observation=(
                f"Turnover as extracted from the financial statements is "
                f"{_money(turnover)}. The applicability of tax audit has been "
                f"recorded in this case as '{declared}'."
            ),
            finding_type=FACT,
            head="Turnover / Revenue",
            amount=turnover,
            recommended_verification=(
                "Determine the applicability of tax audit for the relevant "
                "assessment year with reference to the turnover, the nature of the "
                "business or profession, the constitution of the assessee and the "
                "proportion of receipts and payments made otherwise than in cash. "
                + UNCERTAIN_POSITION
            ),
            relevance=(
                "The threshold for tax audit depends on the provisions applicable "
                "for the relevant assessment year and on the facts of the case."
            ),
            documents=[
                "Computation of turnover for tax audit purposes",
                "Details of the proportion of cash receipts and cash payments",
            ],
            why="Turnover governs the applicability of tax audit.",
        )
    )
    return flags


# ------------------------------------------------------------- orchestration

CHECKS: List[Callable[[RiskContext], List[RiskFlag]]] = [
    check_validation_failures,
    check_turnover,
    check_cash,
    check_loans_and_deposits,
    check_receivables,
    check_payables,
    check_statutory_dues,
    check_expenses,
    check_tds_areas,
    check_allowability,
    check_capital_vs_revenue,
    check_personal_expenditure,
    check_related_party,
    check_depreciation_and_assets,
    check_provisions_and_contingencies,
    check_low_confidence_extractions,
    check_tax_audit_applicability,
]


def run_risk_analysis(
    dataset: FinancialDataset,
    case: Optional[Case] = None,
    validations: Sequence[ValidationCheck] = (),
    ratios: Sequence[Ratio] = (),
    thresholds: Optional[Dict[str, float]] = None,
    mapping: Optional[Dict[str, Dict[str, str]]] = None,
) -> List[RiskFlag]:
    """Run every check and return the flags, most severe first.

    A failure inside any single check is logged and skipped rather than
    aborting the whole analysis, so one unexpected data shape can never
    deprive the auditor of the remaining findings.
    """
    context = RiskContext(
        dataset=dataset,
        case=case,
        validations=list(validations),
        ratios=list(ratios),
        thresholds=thresholds or load_risk_thresholds(),
        mapping=mapping or load_form_3cd_mapping(),
    )

    flags: List[RiskFlag] = []
    for check in CHECKS:
        try:
            flags.extend(check(context) or [])
        except Exception as exc:
            log.exception("Risk check %s failed: %s", check.__name__, exc)
            flags.append(
                RiskFlag(
                    risk_level=REVIEW,
                    area="Analysis Engine",
                    observation=(
                        f"The '{check.__name__}' review could not be completed due "
                        "to an unexpected condition in the data. The matters it "
                        "covers should be examined manually."
                    ),
                    finding_type=VERIFICATION_REQUIRED,
                    recommended_verification=(
                        "Review this area manually and check logs/app.log for "
                        "technical details."
                    ),
                    why_flagged=f"Internal error: {exc}",
                )
            )

    if case is not None:
        for flag in flags:
            flag.case_id = case.case_id

    flags.sort(key=lambda f: f.sort_key)
    log.info(
        "Risk analysis produced %d flag(s): %s",
        len(flags),
        {level: sum(1 for f in flags if f.risk_level == level)
         for level in (HIGH, MEDIUM, REVIEW, INFORMATIONAL)},
    )
    return flags


def summarise_by_level(flags: Sequence[RiskFlag]) -> Dict[str, int]:
    """Counts per risk level for the dashboard tiles."""
    return {
        HIGH: sum(1 for f in flags if f.risk_level == HIGH),
        MEDIUM: sum(1 for f in flags if f.risk_level == MEDIUM),
        REVIEW: sum(1 for f in flags if f.risk_level == REVIEW),
        INFORMATIONAL: sum(1 for f in flags if f.risk_level == INFORMATIONAL),
    }


def flags_by_area(flags: Sequence[RiskFlag]) -> Dict[str, List[RiskFlag]]:
    """Group flags by area, preserving severity order within each area."""
    grouped: Dict[str, List[RiskFlag]] = {}
    for flag in flags:
        grouped.setdefault(flag.area, []).append(flag)
    for items in grouped.values():
        items.sort(key=lambda f: f.sort_key)
    return grouped


def form_3cd_reporting_areas(
    flags: Sequence[RiskFlag],
) -> List[Dict[str, str]]:
    """Rows for the report's potential Form 3CD reporting areas table."""
    rows: List[Dict[str, str]] = []
    seen: set = set()
    for flag in flags:
        if not flag.potential_3cd_clause:
            continue
        key = (flag.area, flag.potential_3cd_clause)
        if key in seen:
            continue
        seen.add(key)
        rows.append(
            {
                "issue": flag.area,
                "clause": flag.potential_3cd_clause,
                "fs_reference": flag.source or "Financial statements",
                "amount": _money(flag.amount) if flag.amount is not None else "Not quantified",
                "verification": flag.recommended_verification,
            }
        )
    return rows
