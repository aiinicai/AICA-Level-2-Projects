"""Map messy real-world financial statement headings to canonical heads.

Indian financial statements phrase the same line item in many ways -- "Revenue
from Operations", "Sales", "Gross Receipts" and "Turnover" all mean the same
thing to a tax auditor. This module normalises a raw heading and resolves it to
one canonical head, returning a confidence grade the verification screen uses
to decide what the Chartered Accountant must eyeball.

Matching strategy, in order of decreasing certainty:

1. Exact match on the normalised synonym  -> High confidence
2. Full containment of a distinctive synonym phrase -> High / Medium
3. Token-overlap (Jaccard-style) scoring  -> Medium
4. ``difflib.SequenceMatcher`` similarity  -> Medium / Low

Anything below :data:`MIN_ACCEPT_SCORE` is rejected as unmapped rather than
guessed at, because a wrong mapping is more dangerous to an auditor than a
missing one.
"""

from __future__ import annotations

import difflib
import re
import unicodedata
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .logging_setup import get_logger

log = get_logger(__name__)

# ------------------------------------------------------------- statement types

PL = "PL"
BS_LIABILITY = "BS_LIABILITY"
BS_ASSET = "BS_ASSET"

# Score thresholds
MIN_ACCEPT_SCORE = 0.62
HIGH_CONFIDENCE_SCORE = 0.93
MEDIUM_CONFIDENCE_SCORE = 0.75

# --------------------------------------------------------------- P&L synonyms

PL_SYNONYMS: Dict[str, List[str]] = {
    "Turnover / Revenue": [
        "turnover",
        "revenue",
        "sales",
        "gross sales",
        "net sales",
        "revenue from operations",
        "gross receipts",
        "receipts from operations",
        "income from operations",
        "sale of products",
        "sale of goods",
        "sale of services",
        "operating revenue",
        "gross turnover",
        "net turnover",
        "sales turnover",
        "contract receipts",
        "professional receipts",
        "fees earned",
    ],
    "Other Income": [
        "other income",
        "non operating income",
        "misc income",
        "miscellaneous income",
        "other operating income",
        "interest income",
        "dividend income",
        "rental income",
        "income from other sources",
        "other receipts",
        "profit on sale of asset",
        "foreign exchange gain",
    ],
    "Opening Stock": [
        "opening stock",
        "opening inventory",
        "stock at commencement",
        "inventory at beginning of year",
        "opening balance of stock",
        "stock at the beginning of the year",
    ],
    "Purchases": [
        "purchases",
        "purchase",
        "purchase of goods",
        "purchases of stock in trade",
        "cost of materials consumed",
        "raw material consumed",
        "material cost",
        "direct purchases",
        "cost of goods purchased",
        "trading purchases",
    ],
    "Closing Stock": [
        "closing stock",
        "closing inventory",
        "stock at close",
        "inventory at end of year",
        "stock at the end of the year",
        "changes in inventories",
    ],
    "Employee Cost": [
        "employee cost",
        "employee benefit expense",
        "employee benefits expenses",
        "salary",
        "salaries",
        "salaries and wages",
        "salary and wages",
        "wages",
        "staff cost",
        "staff welfare",
        "payroll cost",
        "bonus",
        "gratuity",
        "provident fund contribution",
        "esi contribution",
        "leave encashment",
    ],
    # Kept separate from general Employee Cost: remuneration to directors and
    # partners attracts its own tax-audit considerations (deductibility limits
    # for firms, related-party examination, and a different TDS treatment), so
    # collapsing it into staff cost would hide it from the reviewer.
    "Director / Partner Remuneration": [
        "directors remuneration",
        "director remuneration",
        "managerial remuneration",
        "remuneration to directors",
        "partner remuneration",
        "partners remuneration",
        "remuneration to partners",
        "salary to partners",
        "salary to directors",
        "interest on partners capital",
        "interest to partners",
        "working partner salary",
    ],
    "Finance Cost": [
        "finance cost",
        "finance costs",
        "interest",
        "interest expense",
        "interest paid",
        "interest on loan",
        "interest and finance charges",
        "bank interest",
        "borrowing cost",
        "interest to bank",
        "interest on unsecured loan",
        "bank charges",
    ],
    "Depreciation": [
        "depreciation",
        "depreciation and amortisation",
        "depreciation and amortization",
        "depreciation expense",
        "amortisation",
        "amortization",
        "depreciation on fixed assets",
        "depreciation charged",
    ],
    "Repairs & Maintenance": [
        "repairs",
        "repairs and maintenance",
        "repair and maintenance",
        "maintenance",
        "repairs to building",
        "repairs to machinery",
        "renovation",
        "building repairs",
        "plant repairs",
    ],
    "Travelling & Conveyance": [
        "travelling",
        "travel",
        "travelling expenses",
        "travel expenses",
        "conveyance",
        "travelling and conveyance",
        "foreign travel",
        "foreign travelling expenses",
        "vehicle running expenses",
        "car expenses",
        "petrol and diesel",
    ],
    "Advertisement & Publicity": [
        "advertisement",
        "advertising",
        "publicity",
        "advertisement and publicity",
        "sales promotion",
        "business promotion",
        "marketing expenses",
    ],
    "Commission & Brokerage": [
        "commission",
        "brokerage",
        "commission and brokerage",
        "commission paid",
        "sales commission",
        "commission on sales",
        "brokerage paid",
    ],
    "Professional Fees": [
        "professional fees",
        "professional charges",
        "consultancy charges",
        "consultancy fees",
        "technical fees",
        "audit fees",
        "auditors remuneration",
        "retainership fees",
        "professional and consultancy",
    ],
    "Legal Expenses": [
        "legal expenses",
        "legal charges",
        "legal and professional",
        "legal fees",
        "litigation expenses",
        "court fees",
    ],
    "Rent": [
        "rent",
        "rent paid",
        "rent expenses",
        "office rent",
        "godown rent",
        "lease rent",
        "rent rates and taxes",
        "premises rent",
    ],
    "Electricity & Power": [
        "electricity",
        "power and fuel",
        "electricity charges",
        "power",
        "fuel",
        "electricity expenses",
        "power and electricity",
    ],
    "CSR Expenditure": [
        "csr",
        "csr expenditure",
        "corporate social responsibility",
        "corporate social responsibility expenditure",
        "csr expenses",
    ],
    "Donations": [
        "donation",
        "donations",
        "charity",
        "charitable donation",
        "donation and charity",
        "contribution to charitable trust",
    ],
    "Penalties & Fines": [
        "penalty",
        "penalties",
        "fine",
        "fines",
        "fines and penalties",
        "penalty paid",
        "late fees",
        "interest on late payment of taxes",
        "penal interest",
    ],
    "Bad Debts": [
        "bad debts",
        "bad debt",
        "bad debts written off",
        "sundry balances written off",
        "irrecoverable balances",
        "debts written off",
    ],
    "Provisions": [
        "provision",
        "provisions",
        "provision for doubtful debts",
        "provision for expenses",
        "provision for gratuity",
        "provision for warranty",
        "provision for bad debts",
    ],
    "Miscellaneous Expenses": [
        "miscellaneous expenses",
        "misc expenses",
        "sundry expenses",
        "general expenses",
        "other expenses",
        "office expenses",
        "administrative expenses",
        "other administrative expenses",
    ],
    "Communication Expenses": [
        "communication expenses",
        "telephone",
        "telephone charges",
        "telephone and internet charges",
        "internet charges",
        "mobile expenses",
        "postage and telegram",
        "postage and courier",
        "courier charges",
    ],
    "Insurance": [
        "insurance",
        "insurance charges",
        "insurance premium",
        "keyman insurance",
    ],
    "Freight & Carriage": [
        "freight",
        "carriage",
        "freight outward",
        "freight inward",
        "carriage inward",
        "carriage outward",
        "transportation charges",
        "cartage",
    ],
    "Rates & Taxes": [
        "rates and taxes",
        "taxes and duties",
        "municipal taxes",
        "property tax",
        "duties and taxes",
        "cess",
        "gst expense",
    ],
    "Prior Period Items": [
        "prior period",
        "prior period items",
        "prior period expenses",
        "prior period adjustment",
        "earlier year expenses",
    ],
    "Total Expenses": [
        "total expenses",
        "total expenditure",
        "total of expenses",
        "aggregate expenses",
    ],
    "Profit Before Tax": [
        "profit before tax",
        "pbt",
        "profit before taxation",
        "net profit before tax",
        "profit loss before tax",
        "earnings before tax",
        "net profit before taxation",
    ],
    "Tax Expense": [
        "tax expense",
        "provision for tax",
        "provision for taxation",
        "current tax",
        "income tax",
        "deferred tax expense",
        "tax expenses",
    ],
    "Profit After Tax": [
        "profit after tax",
        "pat",
        "net profit",
        "net profit after tax",
        "profit for the year",
        "net profit for the year",
        "profit loss for the period",
        "surplus for the year",
    ],
}

# ------------------------------------------------- Balance sheet: liabilities

BS_LIABILITY_SYNONYMS: Dict[str, List[str]] = {
    "Share Capital": [
        "share capital",
        "equity share capital",
        "paid up capital",
        "issued capital",
        "subscribed capital",
        "capital",
        "preference share capital",
    ],
    "Reserves & Surplus": [
        "reserves and surplus",
        "reserves",
        "surplus",
        "retained earnings",
        "general reserve",
        "profit and loss account balance",
        "securities premium",
        "other equity",
        "accumulated profit",
    ],
    "Partners Capital": [
        "partners capital",
        "partner capital",
        "partners capital account",
        "capital account",
        "proprietors capital",
        "proprietor capital account",
        "members capital",
        "partners current account",
    ],
    "Secured Loans": [
        "secured loans",
        "secured loan",
        "term loan",
        "term loans",
        "cash credit",
        "bank borrowings",
        "secured borrowings",
        "vehicle loan",
        "working capital loan",
        "loan against property",
    ],
    "Unsecured Loans": [
        "unsecured loans",
        "unsecured loan",
        "unsecured borrowings",
        "loan from directors",
        "loans from directors",
        "loan from partners",
        "loan from relatives",
        "loans and advances from related parties",
        "deposits from members",
        "inter corporate deposits",
    ],
    "Trade Payables": [
        "trade payables",
        "trade payable",
        "sundry creditors",
        "creditors",
        "creditors for goods",
        "accounts payable",
        "payables for supplies",
        "creditors for expenses",
    ],
    "MSME Payables": [
        "msme payables",
        "dues to micro and small enterprises",
        "micro small and medium enterprises",
        "msme dues",
        "amount due to micro enterprises",
        "msme creditors",
    ],
    "Statutory Liabilities": [
        "statutory liabilities",
        "statutory dues",
        "tds payable",
        "gst payable",
        "pf payable",
        "esi payable",
        "duties and taxes payable",
        "professional tax payable",
        "tcs payable",
    ],
    "Other Current Liabilities": [
        "other current liabilities",
        "current liabilities",
        "outstanding expenses",
        "expenses payable",
        "advance from customers",
        "other payables",
        "other liabilities",
        "sundry liabilities",
    ],
    "Provisions (Liability)": [
        "provisions",
        "short term provisions",
        "long term provisions",
        "provision for tax liability",
        "provision for employee benefits",
        "provision for expenses payable",
    ],
    "Total Equity & Liabilities": [
        "total equity and liabilities",
        "total liabilities",
        "total of liabilities",
        "total capital and liabilities",
        "total liabilities and equity",
        "total",
    ],
}

# ----------------------------------------------------- Balance sheet: assets

BS_ASSET_SYNONYMS: Dict[str, List[str]] = {
    "Property Plant & Equipment": [
        "property plant and equipment",
        "fixed assets",
        "tangible assets",
        "gross block",
        "net block",
        "plant and machinery",
        "land and building",
        "furniture and fixtures",
        "office equipment",
        "vehicles",
        "computers",
    ],
    "Capital Work in Progress": [
        "capital work in progress",
        "cwip",
        "work in progress capital",
        "capital wip",
        "assets under construction",
        "building under construction",
    ],
    "Investments": [
        "investments",
        "investment",
        "non current investments",
        "current investments",
        "investment in shares",
        "investment in mutual funds",
        "long term investments",
    ],
    "Loans & Advances": [
        "loans and advances",
        "advances",
        "short term loans and advances",
        "long term loans and advances",
        "advance to suppliers",
        "loans given",
        "advances recoverable",
        "security deposits",
    ],
    "Trade Receivables": [
        "trade receivables",
        "trade receivable",
        "sundry debtors",
        "debtors",
        "accounts receivable",
        "receivables",
        "book debts",
        "outstanding debtors",
    ],
    "Inventories": [
        "inventories",
        "inventory",
        "stock in trade",
        "stock in hand",
        "closing stock asset",
        "raw material stock",
        "finished goods",
        "work in progress",
    ],
    "Cash in Hand": [
        "cash",
        "cash in hand",
        "cash on hand",
        "cash balance",
        "petty cash",
        "cash at office",
    ],
    "Bank Balances": [
        "bank",
        "bank balance",
        "bank balances",
        "balance with banks",
        "cash and cash equivalents",
        "bank accounts",
        "current account with bank",
        "fixed deposits with bank",
    ],
    "GST Receivable": [
        "gst receivable",
        "input tax credit",
        "gst input",
        "itc receivable",
        "cgst receivable",
        "sgst receivable",
        "igst receivable",
        "gst refund receivable",
    ],
    "TDS Receivable": [
        "tds receivable",
        "tds",
        "advance tax",
        "tax deducted at source receivable",
        "income tax refund receivable",
        "advance income tax",
        "tcs receivable",
    ],
    "Other Current Assets": [
        "other current assets",
        "current assets",
        "prepaid expenses",
        "accrued income",
        "other assets",
        "sundry assets",
    ],
    "Deferred Tax Asset": [
        "deferred tax asset",
        "dta",
        "deferred tax assets net",
    ],
    "Deferred Tax Liability": [
        "deferred tax liability",
        "dtl",
        "deferred tax liabilities net",
    ],
    "Total Assets": [
        "total assets",
        "total of assets",
        "grand total assets",
    ],
}

# Combined lookup with the statement type each head belongs to.
CANONICAL_HEADS: Dict[str, Tuple[str, List[str]]] = {}
for _head, _syn in PL_SYNONYMS.items():
    CANONICAL_HEADS[_head] = (PL, _syn)
for _head, _syn in BS_LIABILITY_SYNONYMS.items():
    CANONICAL_HEADS[_head] = (BS_LIABILITY, _syn)
for _head, _syn in BS_ASSET_SYNONYMS.items():
    CANONICAL_HEADS[_head] = (BS_ASSET, _syn)

# Heads that represent totals/subtotals rather than individual line items.
TOTAL_HEADS = {"Total Expenses", "Total Equity & Liabilities", "Total Assets"}

# Expense heads used repeatedly by the risk engine.
EXPENSE_HEADS = [
    "Purchases",
    "Employee Cost",
    "Director / Partner Remuneration",
    "Finance Cost",
    "Depreciation",
    "Repairs & Maintenance",
    "Travelling & Conveyance",
    "Advertisement & Publicity",
    "Commission & Brokerage",
    "Professional Fees",
    "Legal Expenses",
    "Rent",
    "Electricity & Power",
    "CSR Expenditure",
    "Donations",
    "Penalties & Fines",
    "Bad Debts",
    "Provisions",
    "Miscellaneous Expenses",
    "Insurance",
    "Communication Expenses",
    "Freight & Carriage",
    "Rates & Taxes",
    "Prior Period Items",
]

# ------------------------------------------------------------- normalisation

_PUNCT_RE = re.compile(r"[^a-z0-9\s]")
_WS_RE = re.compile(r"\s+")

# Words that carry no discriminating meaning in a heading.
STOPWORDS = {
    "the", "a", "an", "of", "for", "to", "and", "or", "on", "in", "at", "by",
    "as", "is", "are", "was", "were", "with", "from", "rs", "inr", "amount",
    "amounts", "account", "accounts", "particulars", "total", "note", "notes",
    "schedule", "sch", "no", "figures", "year", "current", "previous", "cy",
    "py", "less", "add", "during", "period", "ended", "ending",
}


def normalise(text: str) -> str:
    """Lower-case, strip accents/punctuation and collapse whitespace."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKD", str(text))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    # Drop leading numbering such as "3." / "(b)" / "iv)" / "A." commonly used
    # to label lines in schedules and notes. Covers arabic numerals, roman
    # numerals and a single bracketed letter.
    text = re.sub(
        r"^\s*[\(\[]?(?:\d+|[ivxlcdm]+|[a-z])[\)\].]\s*", " ", text
    )
    text = _PUNCT_RE.sub(" ", text)
    text = _WS_RE.sub(" ", text)
    return text.strip()


def tokens(text: str) -> List[str]:
    """Meaningful tokens of a normalised heading."""
    return [t for t in normalise(text).split() if t and t not in STOPWORDS]


def _token_overlap(a: Sequence[str], b: Sequence[str]) -> float:
    """Overlap weighted toward covering the synonym's tokens."""
    set_a, set_b = set(a), set(b)
    if not set_a or not set_b:
        return 0.0
    intersection = set_a & set_b
    if not intersection:
        return 0.0
    # Coverage of the shorter phrase matters most: "salary" inside
    # "salary and wages to staff" should score highly.
    return len(intersection) / min(len(set_a), len(set_b))


def _sequence_similarity(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b).ratio()


# ---------------------------------------------------------------- public API


@dataclass
class MappingResult:
    """Outcome of resolving one raw heading."""

    canonical_head: str
    statement_type: str
    score: float
    confidence: str
    raw_heading: str
    matched_synonym: str = ""

    @property
    def is_total(self) -> bool:
        return self.canonical_head in TOTAL_HEADS


def score_to_confidence(score: float) -> str:
    """Grade a match score as High / Medium / Low."""
    if score >= HIGH_CONFIDENCE_SCORE:
        return "High"
    if score >= MEDIUM_CONFIDENCE_SCORE:
        return "Medium"
    return "Low"


def _contains_phrase(haystack: str, needle: str) -> bool:
    """Whole-word phrase containment.

    Plain ``in`` is unsafe here: "secured loans" is a raw substring of
    "unsecured loans", which would map an unsecured loan to the Secured Loans
    head -- an error with real audit consequences. Anchoring on word
    boundaries prevents that whole class of mistake.
    """
    if not needle:
        return False
    return re.search(rf"(?<![a-z0-9]){re.escape(needle)}(?![a-z0-9])", haystack) is not None


def _score_against_synonym(
    raw_norm: str, raw_tokens: List[str], synonym: str
) -> float:
    """Best score for one raw heading against one synonym phrase."""
    syn_norm = normalise(synonym)
    if not syn_norm:
        return 0.0

    # 1. Exact normalised equality.
    if raw_norm == syn_norm:
        return 1.0

    syn_tokens = [t for t in syn_norm.split() if t not in STOPWORDS] or syn_norm.split()

    # 2. Whole-phrase containment. Require the synonym to be reasonably
    #    specific (>=2 tokens, or a long single word) so that "cash" does not
    #    swallow "cash credit".
    if _contains_phrase(raw_norm, syn_norm):
        if len(syn_tokens) >= 2:
            return 0.97
        if len(syn_norm) >= 6:
            return 0.94
        # Short single word: only if it is a standalone token in the heading.
        if syn_norm in raw_tokens:
            return 0.90

    overlap = _token_overlap(raw_tokens, syn_tokens)
    sequence = _sequence_similarity(raw_norm, syn_norm)

    # 3/4. Blend the two signals, letting a strong single signal carry.
    blended = (0.65 * overlap) + (0.35 * sequence)
    return max(blended, overlap * 0.92, sequence * 0.88)


def map_heading(
    raw_heading: str,
    statement_hint: Optional[str] = None,
    min_score: float = MIN_ACCEPT_SCORE,
) -> Optional[MappingResult]:
    """Resolve one raw heading to a canonical head.

    ``statement_hint`` (``PL``/``BS_LIABILITY``/``BS_ASSET``) narrows the
    candidate set when the caller already knows which statement it is reading,
    which materially improves accuracy for ambiguous words like "Provisions".
    Returns ``None`` when nothing scores above ``min_score``.
    """
    raw_norm = normalise(raw_heading)
    if not raw_norm or len(raw_norm) < 2:
        return None
    raw_tokens = tokens(raw_heading) or raw_norm.split()

    best: Optional[MappingResult] = None
    for head, (stype, synonyms) in CANONICAL_HEADS.items():
        # Apply the hint as a strong preference rather than a hard filter, so a
        # mis-detected section heading cannot silently drop real data.
        hint_penalty = 1.0
        if statement_hint:
            if statement_hint == PL and stype != PL:
                hint_penalty = 0.80
            elif statement_hint in (BS_LIABILITY, BS_ASSET):
                if stype == PL:
                    hint_penalty = 0.80
                elif stype != statement_hint:
                    hint_penalty = 0.93

        for synonym in synonyms:
            raw_score = _score_against_synonym(raw_norm, raw_tokens, synonym)
            score = raw_score * hint_penalty
            if best is None or score > best.score:
                best = MappingResult(
                    canonical_head=head,
                    statement_type=stype,
                    score=round(score, 4),
                    confidence=score_to_confidence(score),
                    raw_heading=str(raw_heading).strip(),
                    matched_synonym=synonym,
                )

    if best is None or best.score < min_score:
        if best is not None:
            log.debug(
                "Heading %r not mapped (best %s @ %.2f, below %.2f)",
                raw_heading,
                best.canonical_head,
                best.score,
                min_score,
            )
        return None
    return best


def map_headings(
    headings: Sequence[str], statement_hint: Optional[str] = None
) -> Dict[str, Optional[MappingResult]]:
    """Convenience wrapper mapping many headings at once."""
    return {h: map_heading(h, statement_hint) for h in headings}


def detect_statement_type(text: str) -> Optional[str]:
    """Guess which statement a block of text belongs to from its wording."""
    norm = normalise(text)
    if not norm:
        return None
    pl_markers = [
        "profit and loss",
        "profit loss",
        "statement of profit",
        "income and expenditure",
        "trading and profit",
        "revenue from operations",
    ]
    bs_markers = ["balance sheet", "statement of assets", "assets and liabilities"]
    for marker in bs_markers:
        if marker in norm:
            return BS_ASSET
    for marker in pl_markers:
        if marker in norm:
            return PL
    return None


def detect_bs_section(text: str) -> Optional[str]:
    """Within a balance sheet, detect whether we are in assets or liabilities."""
    norm = normalise(text)
    if not norm:
        return None
    if re.search(r"\b(equity and liabilities|liabilities|capital and liabilities|sources of funds)\b", norm):
        return BS_LIABILITY
    if re.search(r"\b(assets|application of funds)\b", norm):
        return BS_ASSET
    return None


def statement_type_of(canonical_head: str) -> str:
    """Statement type for an already-canonical head."""
    entry = CANONICAL_HEADS.get(canonical_head)
    return entry[0] if entry else "OTHER"


def all_canonical_heads(statement_type: Optional[str] = None) -> List[str]:
    """List canonical heads, optionally filtered by statement type."""
    if statement_type is None:
        return list(CANONICAL_HEADS)
    return [h for h, (s, _) in CANONICAL_HEADS.items() if s == statement_type]
