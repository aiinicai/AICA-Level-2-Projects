"""Word report generation using python-docx.

Produces the full analytical report: A4, Book Antiqua where available (falling
back to Times New Roman), justified body text at 11pt, bold headings, a page
header and footer, and automatic page numbers.

Every generated report ends with the mandatory disclaimer reproduced verbatim.
No sentence in this module asserts a concluded statutory violation.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from ..database.models import (
    AnalysisResult,
    AuditQuery,
    Case,
    Document,
    RiskFlag,
)
from ..paths import reports_dir
from .analysis_engine import FinancialDataset, ValidationCheck
from .logging_setup import get_logger
from .ratio_engine import Ratio
from .tax_risk_engine import (
    CLAUSE_MAPPING_DISCLAIMER,
    HIGH,
    INFORMATIONAL,
    MEDIUM,
    REVIEW,
    form_3cd_reporting_areas,
)

log = get_logger(__name__)

APP_TITLE = "Tax Audit Financial Statement Analyser"
HEADER_TEXT = APP_TITLE
FOOTER_TEXT = "Confidential – For Professional Review Only"

PREFERRED_FONT = "Book Antiqua"
FALLBACK_FONT = "Times New Roman"

BODY_SIZE = 11
H1_SIZE = 14
H2_SIZE = 12

# Reproduced verbatim; this text must not be reworded.
MANDATORY_DISCLAIMER = (
    "This report is an automated preliminary analytical report based solely "
    "upon documents uploaded into the application. Observations represent "
    "matters requiring professional examination and do not constitute a final "
    "tax audit opinion, legal opinion, assessment of tax liability or "
    "determination of statutory non-compliance. The Chartered Accountant / tax "
    "professional must independently verify the underlying records and the law "
    "applicable to the relevant assessment year."
)


class ReportError(Exception):
    """Raised with a message suitable for display to the user."""


# ------------------------------------------------------------- formatting


def _money(value: Optional[float]) -> str:
    """Indian-grouped currency string."""
    if value is None:
        return "-"
    integer, decimal = f"{abs(value):.2f}".split(".")
    if len(integer) > 3:
        head, tail = integer[:-3], integer[-3:]
        parts: List[str] = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        integer = ",".join(parts + [tail])
    text = f"{integer}.{decimal}"
    return f"({text})" if value < 0 else text


def _percent(value: Optional[float]) -> str:
    return "-" if value is None else f"{value:,.1f}%"


def _available_font(document) -> str:
    """Book Antiqua where the platform is likely to have it.

    python-docx cannot enumerate installed fonts, so the font name is written
    into the document with an explicit fallback recorded in the style. Word
    substitutes automatically if the font is absent.
    """
    return PREFERRED_FONT


# ---------------------------------------------------------------- builder


class ReportBuilder:
    """Assembles the Word document section by section."""

    def __init__(self, firm_name: str = "", font_name: Optional[str] = None) -> None:
        try:
            import docx
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise ReportError(
                "Word report generation requires the 'python-docx' package."
            ) from exc

        self.docx = docx
        self.document = docx.Document()
        self.firm_name = firm_name
        self.font_name = font_name or PREFERRED_FONT
        self._configure_page()
        self._configure_styles()
        self._configure_header_footer()

    # -------------------------------------------------------- page set-up

    def _configure_page(self) -> None:
        from docx.shared import Cm

        for section in self.document.sections:
            # A4
            section.page_width = Cm(21.0)
            section.page_height = Cm(29.7)
            section.left_margin = Cm(2.5)
            section.right_margin = Cm(2.0)
            section.top_margin = Cm(2.0)
            section.bottom_margin = Cm(2.0)

    def _configure_styles(self) -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.shared import Pt

        style = self.document.styles["Normal"]
        style.font.name = self.font_name
        style.font.size = Pt(BODY_SIZE)
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        style.paragraph_format.space_after = Pt(6)
        # Ensure the font applies to complex/east-asian runs too, otherwise
        # Word silently falls back for some characters.
        rpr = style.element.get_or_add_rPr()
        rfonts = rpr.get_or_add_rFonts()
        for attribute in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rfonts.set(qn(attribute), self.font_name)

    def _configure_header_footer(self) -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt

        for section in self.document.sections:
            header = section.header.paragraphs[0]
            header.text = HEADER_TEXT
            header.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in header.runs:
                run.font.size = Pt(9)
                run.font.name = self.font_name
                run.bold = True

            footer = section.footer.paragraphs[0]
            footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = footer.add_run(FOOTER_TEXT + "    |    Page ")
            run.font.size = Pt(8)
            run.font.name = self.font_name
            self._add_page_number_field(footer)

    def _add_page_number_field(self, paragraph) -> None:
        """Insert a live PAGE field so Word numbers the pages itself."""
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.shared import Pt

        run = paragraph.add_run()
        run.font.size = Pt(8)
        run.font.name = self.font_name

        begin = OxmlElement("w:fldChar")
        begin.set(qn("w:fldCharType"), "begin")
        instr = OxmlElement("w:instrText")
        instr.set(qn("xml:space"), "preserve")
        instr.text = "PAGE"
        end = OxmlElement("w:fldChar")
        end.set(qn("w:fldCharType"), "end")

        run._r.append(begin)
        run._r.append(instr)
        run._r.append(end)

    # ---------------------------------------------------------- primitives

    def heading(self, text: str, level: int = 1) -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt

        paragraph = self.document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        paragraph.paragraph_format.space_before = Pt(12 if level == 1 else 8)
        paragraph.paragraph_format.space_after = Pt(4)
        paragraph.paragraph_format.keep_with_next = True
        run = paragraph.add_run(text)
        run.bold = True
        run.font.size = Pt(H1_SIZE if level == 1 else H2_SIZE)
        run.font.name = self.font_name

    def body(self, text: str, italic: bool = False, bold: bool = False) -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt

        paragraph = self.document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        run = paragraph.add_run(text)
        run.italic = italic
        run.bold = bold
        run.font.size = Pt(BODY_SIZE)
        run.font.name = self.font_name

    def bullet(self, text: str) -> None:
        from docx.shared import Pt

        paragraph = self.document.add_paragraph(style="List Bullet")
        run = paragraph.add_run(text)
        run.font.size = Pt(BODY_SIZE)
        run.font.name = self.font_name

    def table(
        self,
        headers: Sequence[str],
        rows: Sequence[Sequence[str]],
        widths: Optional[Sequence[float]] = None,
        font_size: int = 9,
    ) -> None:
        """Add a bordered table with a bold header row."""
        from docx.shared import Cm, Pt

        if not rows:
            self.body("No items to report under this head.", italic=True)
            return

        table = self.document.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        header_cells = table.rows[0].cells
        for index, title in enumerate(headers):
            header_cells[index].text = ""
            paragraph = header_cells[index].paragraphs[0]
            run = paragraph.add_run(str(title))
            run.bold = True
            run.font.size = Pt(font_size)
            run.font.name = self.font_name

        for row in rows:
            cells = table.add_row().cells
            for index, value in enumerate(row):
                if index >= len(cells):
                    break
                cells[index].text = ""
                paragraph = cells[index].paragraphs[0]
                run = paragraph.add_run("" if value is None else str(value))
                run.font.size = Pt(font_size)
                run.font.name = self.font_name

        if widths:
            for row in table.rows:
                for index, width in enumerate(widths):
                    if index < len(row.cells):
                        row.cells[index].width = Cm(width)

    def page_break(self) -> None:
        self.document.add_page_break()

    def save(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.document.save(str(path))
        return path


# ------------------------------------------------------------- the report


def _cover_page(builder: ReportBuilder, case: Case, firm_name: str) -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt

    def centred(text: str, size: int, bold: bool = False, space_after: int = 6) -> None:
        paragraph = builder.document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.space_after = Pt(space_after)
        run = paragraph.add_run(text)
        run.bold = bold
        run.font.size = Pt(size)
        run.font.name = builder.font_name

    for _ in range(3):
        builder.document.add_paragraph()

    centred(APP_TITLE, 18, bold=True, space_after=2)
    centred("Financial Statement Review & Risk Identification System", 11)
    builder.document.add_paragraph()
    centred("PRELIMINARY ANALYTICAL REPORT", 14, bold=True)
    builder.document.add_paragraph()

    rows = [
        ("Case ID", case.case_id),
        ("Name of Assessee", case.assessee_name),
        ("Permanent Account Number", case.pan or "Not provided"),
        ("Constitution", case.constitution or "Not provided"),
        ("Nature of Business", case.nature_of_business or "Not provided"),
        ("GSTIN", case.gstin or "Not provided"),
        ("Financial Year", case.financial_year or "Not provided"),
        ("Assessment Year", case.assessment_year or "Not provided"),
        ("Turnover as recorded", _money(case.turnover) if case.turnover else "Not provided"),
        ("Tax Audit Applicable", case.tax_audit_applicable or "To be determined"),
        ("Auditor / Firm", case.auditor_name or firm_name or "Not provided"),
        ("Report Generated On", datetime.now().strftime("%d %B %Y at %H:%M")),
    ]
    builder.table(["Particulars", "Details"], rows, widths=[6.0, 10.5], font_size=10)

    builder.document.add_paragraph()
    centred(
        "This report is confidential and is intended solely for professional review.",
        9,
    )
    builder.page_break()


def _executive_summary(
    builder: ReportBuilder,
    case: Case,
    dataset: FinancialDataset,
    flags: Sequence[RiskFlag],
    validations: Sequence[ValidationCheck],
    documents: Sequence[Document],
) -> None:
    builder.heading("1. Executive Summary")

    counts = {
        HIGH: sum(1 for f in flags if f.risk_level == HIGH),
        MEDIUM: sum(1 for f in flags if f.risk_level == MEDIUM),
        REVIEW: sum(1 for f in flags if f.risk_level == REVIEW),
        INFORMATIONAL: sum(1 for f in flags if f.risk_level == INFORMATIONAL),
    }

    turnover = dataset.cy("Turnover / Revenue")
    pbt = dataset.cy("Profit Before Tax")

    builder.body(
        f"This report sets out the results of a preliminary analytical review of "
        f"the financial statements of {case.assessee_name} for the financial year "
        f"{case.financial_year or 'under review'}. The review was performed by the "
        f"{APP_TITLE} on the basis of {len(documents)} document(s) uploaded into "
        "the application. The analysis is rule-based and arithmetical; it does not "
        "involve the exercise of professional judgement."
    )

    if turnover is not None:
        profit_text = (
            f" Profit before tax as extracted is {_money(pbt)}."
            if pbt is not None
            else ""
        )
        builder.body(
            f"Turnover as extracted from the financial statements is "
            f"{_money(turnover)}.{profit_text}"
        )

    builder.body(
        f"The review identified {len(flags)} matter(s) for attention, comprising "
        f"{counts[HIGH]} classified as High Risk, {counts[MEDIUM]} as Medium Risk, "
        f"{counts[REVIEW]} as Review Required and {counts[INFORMATIONAL]} as "
        "Informational. These classifications indicate the priority for "
        "professional examination and do not represent any conclusion as to the "
        "correctness of the accounts or as to compliance with any provision of law."
    )

    failed = [c for c in validations if c.applicable and not c.passed]
    if failed:
        builder.body(
            f"The arithmetical validation of the statements identified "
            f"{len(failed)} matter(s) that did not agree within the tolerance "
            "applied. These are set out in section 3 and require reconciliation "
            "against the audited financial statements before the analysis in this "
            "report is relied upon.",
            bold=True,
        )
    else:
        builder.body(
            "The arithmetical validations performed on the statements agreed "
            "within the tolerance applied."
        )

    top = [f for f in flags if f.risk_level == HIGH][:5]
    if top:
        builder.heading("Principal matters identified", level=2)
        for flag in top:
            builder.bullet(f"{flag.area}: {flag.observation}")


def _documents_analysed(
    builder: ReportBuilder, documents: Sequence[Document], dataset: FinancialDataset
) -> None:
    builder.heading("2. Documents Analysed")
    if not documents:
        builder.body(
            "No document records were available. The analysis was performed on "
            "figures supplied directly to the analysis engine.",
            italic=True,
        )
    else:
        rows = [
            (
                document.file_name,
                document.document_type,
                str(document.pages or "-"),
                document.status,
                "Yes" if document.ocr_used else "No",
            )
            for document in documents
        ]
        builder.table(
            ["File Name", "Document Type", "Pages", "Status", "OCR Used"],
            rows,
            widths=[5.5, 4.2, 1.6, 2.6, 1.8],
        )

    builder.body(
        f"A total of {len(dataset.figures)} financial head(s) were recognised from "
        "the documents uploaded. Where a figure could not be recognised with "
        "confidence, it is identified in this report as requiring verification."
    )

    weak = dataset.low_confidence_heads
    if weak:
        builder.body(
            "The following heads were extracted with low confidence and should be "
            "checked against the source documents: " + ", ".join(weak) + ".",
            italic=True,
        )

    if dataset.warnings:
        builder.heading("Extraction notes", level=2)
        for warning in dataset.warnings[:15]:
            builder.bullet(warning)


def _financial_snapshot(
    builder: ReportBuilder,
    dataset: FinancialDataset,
    snapshot: Sequence[AnalysisResult],
    validations: Sequence[ValidationCheck],
) -> None:
    builder.heading("3. Financial Snapshot")
    rows = [
        (
            item.label,
            _money(item.current_year),
            _money(item.previous_year),
            _money(item.change_amount),
            _percent(item.change_percent),
        )
        for item in snapshot
    ]
    builder.table(
        ["Particulars", "Current Year", "Previous Year", "Change", "Change %"],
        rows,
        widths=[5.2, 3.1, 3.1, 3.1, 2.0],
    )

    builder.heading("Accounting validation", level=2)
    validation_rows = [
        (check.name, check.status, _money(check.difference), check.message)
        for check in validations
    ]
    builder.table(
        ["Check", "Result", "Difference", "Observation"],
        validation_rows,
        widths=[3.4, 2.0, 2.4, 8.7],
        font_size=8,
    )


def _year_on_year(
    builder: ReportBuilder, yoy: Sequence[AnalysisResult]
) -> None:
    builder.heading("4. Year-on-Year Analysis")
    builder.body(
        "The table below sets out the movement in each financial head recognised "
        "from the documents uploaded. The materiality band is derived from the "
        "percentage movement using the thresholds configured in the application "
        "and is an aid to prioritisation only."
    )
    rows = [
        (
            item.label,
            _money(item.current_year),
            _money(item.previous_year),
            _money(item.change_amount),
            _percent(item.change_percent),
            item.materiality,
        )
        for item in yoy
    ]
    builder.table(
        [
            "Financial Head",
            "Current Year",
            "Previous Year",
            "Change",
            "Change %",
            "Materiality",
        ],
        rows,
        widths=[4.4, 2.8, 2.8, 2.8, 1.7, 2.0],
        font_size=8,
    )


def _key_ratios(builder: ReportBuilder, ratios: Sequence[Ratio]) -> None:
    builder.heading("5. Key Ratios")
    rows = [
        (ratio.name, ratio.basis, ratio.current_display, ratio.previous_display)
        for ratio in ratios
    ]
    builder.table(
        ["Ratio", "Basis of Computation", "Current Year", "Previous Year"],
        rows,
        widths=[4.4, 6.0, 3.0, 3.0],
        font_size=8,
    )

    material = [r for r in ratios if r.is_material_change]
    builder.heading("Commentary on material movements", level=2)
    if not material:
        builder.body(
            "No ratio recorded a movement large enough to require specific "
            "commentary under the threshold applied."
        )
    else:
        for ratio in material:
            builder.body(f"{ratio.name}. {ratio.explanation}")
            if ratio.note:
                builder.body(ratio.note, italic=True)


def _risk_section(
    builder: ReportBuilder,
    title: str,
    flags: Sequence[RiskFlag],
    empty_message: str,
    number: str = "",
) -> None:
    builder.heading(title)
    if not flags:
        builder.body(empty_message, italic=True)
        return
    for index, flag in enumerate(flags, start=1):
        # Number sub-findings against their parent section (6.1, 6.2, ...) so
        # they can be cited unambiguously in correspondence.
        label = f"{number}.{index}" if number else str(index)
        builder.heading(f"{label} {flag.area}", level=2)
        builder.body(flag.observation)
        if flag.amount is not None:
            comparative = (
                f" Previous year: {_money(flag.previous_year_amount)}."
                if flag.previous_year_amount is not None
                else ""
            )
            change = (
                f" Change: {_percent(flag.change_percent)}."
                if flag.change_percent is not None
                else ""
            )
            builder.body(
                f"Amount: {_money(flag.amount)}.{comparative}{change}"
            )
        builder.body(f"Nature of finding: {flag.finding_type}.")
        if flag.why_flagged:
            builder.body(f"Why flagged: {flag.why_flagged}")
        if flag.tax_audit_relevance:
            builder.body(f"Tax audit relevance: {flag.tax_audit_relevance}")
        builder.body(f"Recommended verification: {flag.recommended_verification}")
        if flag.documents_to_verify:
            builder.body("Documents to verify:")
            for document in flag.documents_to_verify:
                builder.bullet(document)
        builder.body(f"Source: {flag.source}", italic=True)


def _area_section(
    builder: ReportBuilder,
    title: str,
    flags: Sequence[RiskFlag],
    areas: Sequence[str],
    empty_message: str,
) -> None:
    """A report section drawn from one or more risk areas."""
    selected = [f for f in flags if f.area in areas]
    builder.heading(title)
    if not selected:
        builder.body(empty_message, italic=True)
        return
    rows = [
        (
            flag.risk_level,
            flag.observation,
            _money(flag.amount),
            flag.recommended_verification,
        )
        for flag in selected
    ]
    builder.table(
        ["Risk Level", "Observation", "Amount", "Recommended Verification"],
        rows,
        widths=[2.2, 6.4, 2.4, 5.4],
        font_size=8,
    )


def _form_3cd_section(builder: ReportBuilder, flags: Sequence[RiskFlag]) -> None:
    builder.heading("11. Potential Form 3CD Reporting Areas")
    builder.body(
        "The table below maps the matters identified in this report to the areas "
        "of the tax audit report in which they may require consideration. The "
        "mapping is indicative only."
    )
    rows = form_3cd_reporting_areas(flags)
    builder.table(
        [
            "Issue",
            "Potential Form 3CD Reporting Area",
            "Financial Statement Reference",
            "Amount",
        ],
        [
            (row["issue"], row["clause"], row["fs_reference"], row["amount"])
            for row in rows
        ],
        widths=[3.2, 6.4, 4.0, 2.8],
        font_size=8,
    )
    builder.body(CLAUSE_MAPPING_DISCLAIMER, bold=True, italic=True)


def _documents_required(builder: ReportBuilder, flags: Sequence[RiskFlag]) -> None:
    builder.heading("12. Documents and Information Required")
    builder.body(
        "The following documents and information are required in order to "
        "complete the examination of the matters identified in this report."
    )
    seen: List[str] = []
    for flag in flags:
        for document in flag.documents_to_verify:
            if document not in seen:
                seen.append(document)
    if not seen:
        builder.body("No additional documents were identified.", italic=True)
        return
    for document in seen:
        builder.bullet(document)


def _queries_section(builder: ReportBuilder, queries: Sequence[AuditQuery]) -> None:
    builder.heading("13. Auditor Queries")
    if not queries:
        builder.body("No queries were generated.", italic=True)
        return
    builder.body(
        "The following draft queries have been prepared for issue to the client. "
        "They should be reviewed and amended as considered appropriate before "
        "being issued."
    )
    for query in queries:
        builder.heading(f"Query {query.query_number}: {query.area}", level=2)
        for paragraph in query.query_text.split("\n\n"):
            text = paragraph.strip()
            if not text:
                continue
            builder.body(text)


def _conclusion(
    builder: ReportBuilder, case: Case, flags: Sequence[RiskFlag]
) -> None:
    builder.heading("14. Conclusion")
    high = sum(1 for f in flags if f.risk_level == HIGH)
    builder.body(
        f"This preliminary analytical review of the financial statements of "
        f"{case.assessee_name} has identified {len(flags)} matter(s) for "
        f"professional attention, of which {high} have been classified as High "
        "Risk. Each matter identified represents an area requiring examination of "
        "the underlying records; none of them represents a conclusion that any "
        "amount is or is not allowable, or that any provision of law does or does "
        "not apply."
    )
    builder.body(
        "The observations in this report have been generated by applying "
        "arithmetical tests and configured thresholds to the figures extracted "
        "from the documents uploaded. They are not a substitute for the audit "
        "procedures required to be performed, for the examination of the books of "
        "account and supporting records, or for the professional judgement of the "
        "Chartered Accountant conducting the tax audit."
    )
    builder.body(
        "The matters set out in section 12 should be obtained and examined, and "
        "the queries in section 13 issued and resolved, before any conclusion is "
        "reached on the matters identified."
    )

    builder.heading("Disclaimer", level=2)
    builder.body(MANDATORY_DISCLAIMER, italic=True)


# ---------------------------------------------------------------- entry point


def generate_report(
    case: Case,
    dataset: FinancialDataset,
    flags: Sequence[RiskFlag],
    ratios: Sequence[Ratio],
    yoy: Sequence[AnalysisResult],
    snapshot: Sequence[AnalysisResult],
    validations: Sequence[ValidationCheck],
    queries: Sequence[AuditQuery] = (),
    documents: Sequence[Document] = (),
    output_path: Optional[Path] = None,
    firm_name: str = "",
) -> Path:
    """Build and save the complete Word report.

    Returns the path to the saved ``.docx``. Raises :class:`ReportError` with a
    user-readable message if the document cannot be written.
    """
    try:
        builder = ReportBuilder(firm_name=firm_name)

        _cover_page(builder, case, firm_name)
        _executive_summary(builder, case, dataset, flags, validations, documents)
        _documents_analysed(builder, documents, dataset)
        _financial_snapshot(builder, dataset, snapshot, validations)
        builder.page_break()
        _year_on_year(builder, yoy)
        builder.page_break()
        _key_ratios(builder, ratios)
        builder.page_break()

        _risk_section(
            builder,
            "6. High-Risk Areas",
            [f for f in flags if f.risk_level == HIGH],
            "No matters were classified as High Risk.",
            number="6",
        )
        builder.page_break()
        _risk_section(
            builder,
            "7. Medium-Risk Areas",
            [f for f in flags if f.risk_level == MEDIUM],
            "No matters were classified as Medium Risk.",
            number="7",
        )
        builder.page_break()

        _area_section(
            builder,
            "8. Expense Analysis",
            flags,
            [
                "Expense Analysis",
                "Capital versus Revenue Expenditure",
                "Personal and Non-Business Expenditure",
            ],
            "No matters were identified in relation to expenses.",
        )
        _area_section(
            builder,
            "9. Loans and Deposits Review",
            flags,
            ["Loans and Deposits", "Cash and Cash Transactions"],
            "No matters were identified in relation to loans and deposits.",
        )
        _area_section(
            builder,
            "10. Statutory and Tax Audit Review",
            flags,
            [
                "Statutory and Tax Audit Review",
                "Tax Deduction at Source",
                "Related Party Review",
                "Depreciation Review",
                "Provisions and Contingent Liabilities",
                "Tax Audit Applicability",
            ],
            "No statutory matters were identified.",
        )
        builder.page_break()

        _form_3cd_section(builder, flags)
        builder.page_break()
        _documents_required(builder, flags)
        builder.page_break()
        _queries_section(builder, queries)
        builder.page_break()
        _conclusion(builder, case, flags)

        path = output_path or default_report_path(case)
        builder.save(Path(path))
        size = Path(path).stat().st_size
        log.info("Report written to %s (%d bytes)", path, size)
        return Path(path)

    except ReportError:
        raise
    except Exception as exc:
        log.exception("Report generation failed for case %s", case.case_id)
        raise ReportError(
            "The Word report could not be generated. Please ensure the report is "
            f"not already open in another application. Technical detail: {exc}"
        ) from exc


def default_report_path(case: Case) -> Path:
    """Standard output location and file name for a case's report."""
    safe_name = "".join(
        ch for ch in (case.assessee_name or "Report") if ch.isalnum() or ch in " -_"
    ).strip().replace(" ", "_")[:60]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{case.case_id}_{safe_name}_{stamp}.docx"
    return reports_dir() / filename


def generate_queries_document(
    case: Case, queries: Sequence[AuditQuery], output_path: Optional[Path] = None,
    firm_name: str = "",
) -> Path:
    """Export just the auditor queries as a standalone Word document."""
    try:
        builder = ReportBuilder(firm_name=firm_name)
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt

        title = builder.document.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run("AUDITOR QUERIES")
        run.bold = True
        run.font.size = Pt(H1_SIZE)
        run.font.name = builder.font_name

        builder.table(
            ["Particulars", "Details"],
            [
                ("Case ID", case.case_id),
                ("Name of Assessee", case.assessee_name),
                ("Permanent Account Number", case.pan or "Not provided"),
                ("Financial Year", case.financial_year or "Not provided"),
                ("Assessment Year", case.assessment_year or "Not provided"),
                ("Prepared On", datetime.now().strftime("%d %B %Y")),
            ],
            widths=[6.0, 10.5],
            font_size=10,
        )
        builder.document.add_paragraph()

        if not queries:
            builder.body("No queries were generated for this case.", italic=True)
        for query in queries:
            builder.heading(f"Query {query.query_number}: {query.area}", level=2)
            for paragraph in query.query_text.split("\n\n"):
                text = paragraph.strip()
                if text:
                    builder.body(text)

        builder.document.add_paragraph()
        builder.body(MANDATORY_DISCLAIMER, italic=True)

        if output_path is None:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = reports_dir() / f"{case.case_id}_Auditor_Queries_{stamp}.docx"
        builder.save(Path(output_path))
        log.info("Queries document written to %s", output_path)
        return Path(output_path)
    except Exception as exc:
        log.exception("Query document generation failed")
        raise ReportError(
            f"The auditor queries document could not be generated: {exc}"
        ) from exc
