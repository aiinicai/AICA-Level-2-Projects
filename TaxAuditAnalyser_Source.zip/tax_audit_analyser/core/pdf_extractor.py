"""PDF text and table extraction with scanned-page fallback.

pdfplumber is the primary engine because it recovers ruled tables well, which
is how most Indian financial statements are laid out. PyMuPDF is used as the
backup text engine and to detect image-only (scanned) pages, which are then
routed to :mod:`ocr_engine`.

The output of this module is a list of :class:`RawLine` records -- a heading
plus up to two numeric columns (current year, previous year) -- each tagged
with the page it came from and how it was recovered. Mapping those headings to
canonical financial heads is the separate job of :mod:`financial_mapper`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

from . import ocr_engine
from .logging_setup import get_logger

log = get_logger(__name__)


@dataclass
class RawLine:
    """A candidate financial statement line recovered from a document."""

    heading: str
    amounts: List[float] = field(default_factory=list)
    page: int = 1
    source: str = "text"           # text | table | ocr
    statement_hint: Optional[str] = None
    raw_text: str = ""

    @property
    def current_year(self) -> Optional[float]:
        return self.amounts[0] if len(self.amounts) >= 1 else None

    @property
    def previous_year(self) -> Optional[float]:
        return self.amounts[1] if len(self.amounts) >= 2 else None


@dataclass
class PageContent:
    """Everything recovered from a single page."""

    page_number: int
    text: str = ""
    tables: List[List[List[Optional[str]]]] = field(default_factory=list)
    is_scanned: bool = False
    ocr_used: bool = False
    ocr_message: str = ""


@dataclass
class ExtractionResult:
    """Aggregate result for one document."""

    file_path: str
    page_count: int = 0
    pages: List[PageContent] = field(default_factory=list)
    lines: List[RawLine] = field(default_factory=list)
    ocr_used: bool = False
    warnings: List[str] = field(default_factory=list)
    error: str = ""

    @property
    def success(self) -> bool:
        return not self.error

    @property
    def full_text(self) -> str:
        return "\n".join(page.text for page in self.pages)


# ------------------------------------------------------------ number parsing

# Indian statements use lakh/crore grouping (1,23,45,678.90), parentheses or a
# trailing minus for negatives, and sometimes a leading Rs./INR symbol.
_NUMBER_RE = re.compile(
    r"""
    (?<![\w.])
    (?P<neg_open>\()?              # ( for negative
    (?:Rs\.?|INR|₹)?\s*
    (?P<body>\d{1,3}(?:,\d{2,3})*(?:\.\d{1,4})?|\d+(?:\.\d{1,4})?)
    (?P<neg_close>\))?
    (?P<trail_minus>-)?
    (?![\w])
    """,
    re.VERBOSE | re.IGNORECASE,
)

# Tokens that look numeric but are never amounts.
_NOTE_REF_RE = re.compile(r"^\d{1,2}$")


def parse_amount(token: str) -> Optional[float]:
    """Parse a single numeric token into a float, or None if not a number."""
    if token is None:
        return None
    text = str(token).strip()
    if not text:
        return None
    negative = False
    if text.startswith("(") and text.endswith(")"):
        negative = True
        text = text[1:-1].strip()
    if text.endswith("-") and len(text) > 1:
        negative = True
        text = text[:-1].strip()
    if text.startswith("-"):
        negative = True
        text = text[1:].strip()
    text = re.sub(r"(?i)^(rs\.?|inr|₹)\s*", "", text).strip()
    text = text.replace(",", "").replace(" ", "")
    if not text or not re.fullmatch(r"\d+(?:\.\d+)?", text):
        return None
    try:
        value = float(text)
    except ValueError:
        return None
    return -value if negative else value


def extract_amounts_from_text(text: str, max_amounts: int = 4) -> List[float]:
    """Pull the trailing numeric columns out of a statement line.

    Financial statement rows put the label first and the figures last, so the
    right-most numbers are the amounts. A bare 1-2 digit number is treated as
    a note reference and skipped unless nothing else is available.
    """
    if not text:
        return []
    amounts: List[float] = []
    note_refs: List[float] = []
    for match in _NUMBER_RE.finditer(text):
        raw = match.group(0).strip()
        value = parse_amount(raw)
        if value is None:
            continue
        body = match.group("body")
        # A short bare integer with no grouping/decimal is probably a note number.
        if _NOTE_REF_RE.match(body) and "," not in body and "." not in body:
            note_refs.append(value)
            continue
        amounts.append(value)
    if not amounts and note_refs:
        amounts = note_refs
    return amounts[:max_amounts]


def split_heading_and_amounts(text: str) -> Tuple[str, List[float]]:
    """Separate the label part of a line from its numeric columns."""
    if not text:
        return "", []
    amounts = extract_amounts_from_text(text)
    # The heading is everything before the first numeric token that we accepted.
    heading = text
    for match in _NUMBER_RE.finditer(text):
        body = match.group("body")
        if _NOTE_REF_RE.match(body) and "," not in body and "." not in body:
            continue
        value = parse_amount(match.group(0))
        if value is None:
            continue
        heading = text[: match.start()]
        break
    heading = re.sub(r"[\.\s_·…]{2,}$", " ", heading)        # dot leaders
    heading = re.sub(r"\s*[:|]\s*$", "", heading.strip())
    heading = re.sub(r"\s{2,}", " ", heading).strip(" .:-|\t")
    return heading.strip(), amounts


# ------------------------------------------------------------ page extraction


def _extract_with_pdfplumber(file_path: Path) -> Tuple[List[PageContent], List[str]]:
    """Primary extraction path: text plus ruled tables, per page."""
    pages: List[PageContent] = []
    warnings: List[str] = []
    import pdfplumber

    with pdfplumber.open(str(file_path)) as pdf:
        for index, page in enumerate(pdf.pages, start=1):
            content = PageContent(page_number=index)
            try:
                content.text = page.extract_text() or ""
            except Exception as exc:
                warnings.append(f"Page {index}: text extraction failed ({exc}).")
                content.text = ""
            try:
                tables = page.extract_tables() or []
                content.tables = [t for t in tables if t]
            except Exception as exc:
                warnings.append(f"Page {index}: table extraction failed ({exc}).")
            content.is_scanned = ocr_engine.is_scanned_text(content.text)
            pages.append(content)
    return pages, warnings


def _extract_with_pymupdf(file_path: Path) -> Tuple[List[PageContent], List[str]]:
    """Backup text extraction when pdfplumber fails or returns nothing."""
    pages: List[PageContent] = []
    warnings: List[str] = []
    try:
        import pymupdf
    except Exception:
        import fitz as pymupdf  # type: ignore

    with pymupdf.open(str(file_path)) as doc:
        for index in range(doc.page_count):
            content = PageContent(page_number=index + 1)
            try:
                content.text = doc.load_page(index).get_text() or ""
            except Exception as exc:
                warnings.append(f"Page {index + 1}: PyMuPDF text failed ({exc}).")
            content.is_scanned = ocr_engine.is_scanned_text(content.text)
            pages.append(content)
    return pages, warnings


def _apply_ocr_fallback(
    file_path: Path, pages: Sequence[PageContent], enable_ocr: bool
) -> Tuple[bool, List[str]]:
    """OCR any page that looks scanned. Never raises."""
    warnings: List[str] = []
    ocr_used = False
    scanned = [p for p in pages if p.is_scanned]
    if not scanned:
        return False, warnings

    if not enable_ocr:
        warnings.append(
            f"{len(scanned)} page(s) appear to be scanned images. OCR was disabled, "
            "so figures on those pages must be entered manually."
        )
        return False, warnings

    available, message = ocr_engine.availability()
    if not available:
        warnings.append(
            f"{len(scanned)} page(s) appear to be scanned images. {message} "
            "Figures on those pages must be entered manually on the verification screen."
        )
        return False, warnings

    for page in scanned:
        result = ocr_engine.ocr_pdf_page(file_path, page.page_number)
        page.ocr_message = result.message
        if result:
            page.text = result.text
            page.ocr_used = True
            ocr_used = True
        else:
            warnings.append(f"Page {page.page_number}: {result.message}")
    return ocr_used, warnings


# -------------------------------------------------------------- line building


def _statement_hint_for_page(text: str) -> Optional[str]:
    from .financial_mapper import detect_statement_type

    return detect_statement_type(text[:1200])


def _lines_from_text(page: PageContent, hint: Optional[str]) -> List[RawLine]:
    """Turn a page's plain text into candidate financial lines."""
    from .financial_mapper import detect_bs_section

    lines: List[RawLine] = []
    section_hint = hint
    for raw in (page.text or "").splitlines():
        stripped = raw.strip()
        if not stripped:
            continue
        # A section header updates the hint for the lines that follow it.
        section = detect_bs_section(stripped)
        if section and len(stripped) < 60 and not extract_amounts_from_text(stripped):
            section_hint = section
            continue
        heading, amounts = split_heading_and_amounts(stripped)
        if not heading or len(heading) < 3:
            continue
        if not amounts:
            continue
        lines.append(
            RawLine(
                heading=heading,
                amounts=amounts,
                page=page.page_number,
                source="ocr" if page.ocr_used else "text",
                statement_hint=section_hint,
                raw_text=stripped,
            )
        )
    return lines


def _section_headers_in_page_text(page: PageContent) -> List[str]:
    """Section markers ("EQUITY AND LIABILITIES", "ASSETS") in reading order.

    Balance sheets print these as free-standing captions above each table, so
    they never appear inside the table cells themselves. Recovering them from
    the page text lets each table inherit the correct section.
    """
    from .financial_mapper import detect_bs_section

    headers: List[str] = []
    for raw in (page.text or "").splitlines():
        stripped = raw.strip()
        if not stripped or len(stripped) > 60:
            continue
        if extract_amounts_from_text(stripped):
            continue
        section = detect_bs_section(stripped)
        if section and (not headers or headers[-1] != section):
            headers.append(section)
    return headers


def _lines_from_tables(page: PageContent, hint: Optional[str]) -> List[RawLine]:
    """Turn extracted table rows into candidate financial lines."""
    from .financial_mapper import detect_bs_section

    lines: List[RawLine] = []
    section_hint = hint
    # Captions appear in the page text in the same order as the tables they
    # head, so the n-th caption belongs to the n-th table.
    captions = _section_headers_in_page_text(page)
    for table_index, table in enumerate(page.tables):
        if table_index < len(captions):
            section_hint = captions[table_index]
        for row in table:
            cells = [str(c).strip() if c is not None else "" for c in row]
            if not any(cells):
                continue
            label = ""
            amounts: List[float] = []
            for cell in cells:
                if not cell:
                    continue
                value = parse_amount(cell)
                if value is not None:
                    amounts.append(value)
                elif not label:
                    label = cell
                elif len(cell) > len(label) and not label.strip():
                    label = cell
            if not label:
                continue
            label = re.sub(r"\s+", " ", label).strip(" .:-|\t")
            section = detect_bs_section(label)
            if section and not amounts and len(label) < 60:
                section_hint = section
                continue
            if not amounts or len(label) < 3:
                continue
            lines.append(
                RawLine(
                    heading=label,
                    amounts=amounts[:4],
                    page=page.page_number,
                    source="table",
                    statement_hint=section_hint,
                    raw_text=" | ".join(c for c in cells if c),
                )
            )
    return lines


def build_raw_lines(pages: Sequence[PageContent]) -> List[RawLine]:
    """Build candidate lines from every page, preferring table rows.

    When a page yields both table rows and text rows the table rows are kept
    and the text rows are used only to fill headings the tables missed, since
    duplicated figures would otherwise double-count in the analysis.
    """
    lines: List[RawLine] = []
    for page in pages:
        hint = _statement_hint_for_page(page.text or "")
        table_lines = _lines_from_tables(page, hint)
        text_lines = _lines_from_text(page, hint)
        if table_lines:
            seen = {_dedupe_key(line) for line in table_lines}
            lines.extend(table_lines)
            lines.extend(l for l in text_lines if _dedupe_key(l) not in seen)
        else:
            lines.extend(text_lines)
    return lines


def _dedupe_key(line: RawLine) -> str:
    from .financial_mapper import normalise

    amounts = ",".join(f"{a:.2f}" for a in line.amounts[:2])
    return f"{normalise(line.heading)}|{amounts}"


# ----------------------------------------------------------------- public API


def extract_pdf(
    file_path: str | Path, enable_ocr: bool = True
) -> ExtractionResult:
    """Extract text, tables and candidate financial lines from a PDF.

    Never raises: any failure is reported through ``result.error`` so the
    upload screen can mark the document "Error" with a readable message and
    carry on with the remaining documents.
    """
    path = Path(file_path)
    result = ExtractionResult(file_path=str(path))

    if not path.exists():
        result.error = f"File not found: {path.name}"
        log.error(result.error)
        return result

    pages: List[PageContent] = []
    warnings: List[str] = []

    try:
        pages, warnings = _extract_with_pdfplumber(path)
    except Exception as exc:
        log.warning("pdfplumber failed on %s (%s); trying PyMuPDF.", path.name, exc)
        warnings.append(f"Primary PDF reader failed ({exc}); used backup reader.")

    # Fall back to PyMuPDF when pdfplumber produced nothing usable.
    if not pages or all(not p.text.strip() and not p.tables for p in pages):
        try:
            backup_pages, backup_warnings = _extract_with_pymupdf(path)
            if backup_pages and any(p.text.strip() for p in backup_pages):
                # Preserve any tables pdfplumber did find.
                if pages and len(pages) == len(backup_pages):
                    for original, backup in zip(pages, backup_pages):
                        if not original.text.strip():
                            original.text = backup.text
                            original.is_scanned = backup.is_scanned
                else:
                    pages = backup_pages
            elif not pages:
                pages = backup_pages
            warnings.extend(backup_warnings)
        except Exception as exc:
            if not pages:
                result.error = (
                    f"Could not read '{path.name}'. The file may be corrupted or "
                    f"password protected. ({exc})"
                )
                log.exception("Both PDF readers failed for %s", path)
                return result
            warnings.append(f"Backup PDF reader failed ({exc}).")

    if not pages:
        result.error = f"No readable pages found in '{path.name}'."
        return result

    try:
        ocr_used, ocr_warnings = _apply_ocr_fallback(path, pages, enable_ocr)
        result.ocr_used = ocr_used
        warnings.extend(ocr_warnings)
    except Exception as exc:  # defensive: OCR must never break extraction
        log.warning("OCR fallback raised unexpectedly for %s: %s", path.name, exc)
        warnings.append(f"OCR step skipped due to an unexpected error ({exc}).")

    result.pages = list(pages)
    result.page_count = len(pages)
    try:
        result.lines = build_raw_lines(pages)
    except Exception as exc:
        log.exception("Line building failed for %s", path)
        warnings.append(f"Could not interpret line items ({exc}).")
    result.warnings = warnings

    log.info(
        "Extracted %s: %d page(s), %d candidate line(s), OCR=%s",
        path.name,
        result.page_count,
        len(result.lines),
        result.ocr_used,
    )
    return result


def count_pdf_pages(file_path: str | Path) -> int:
    """Page count for the upload table; 0 when unreadable."""
    try:
        import pdfplumber

        with pdfplumber.open(str(file_path)) as pdf:
            return len(pdf.pages)
    except Exception:
        try:
            try:
                import pymupdf
            except Exception:
                import fitz as pymupdf  # type: ignore
            with pymupdf.open(str(file_path)) as doc:
                return int(doc.page_count)
        except Exception as exc:
            log.warning("Could not count pages for %s: %s", file_path, exc)
            return 0
