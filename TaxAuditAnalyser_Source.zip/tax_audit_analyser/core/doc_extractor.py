"""Route an uploaded file to the right extractor and normalise the result.

Supported inputs: PDF, Excel (.xlsx/.xlsm/.xls), Word (.docx), CSV/TSV and
images (.png/.jpg/.tiff via OCR). Every path returns the same
:class:`~.pdf_extractor.ExtractionResult` shape so the rest of the pipeline
does not care what the source file was.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import List, Optional

from . import ocr_engine
from .logging_setup import get_logger
from .pdf_extractor import (
    ExtractionResult,
    PageContent,
    RawLine,
    build_raw_lines,
    extract_pdf,
    parse_amount,
)

log = get_logger(__name__)

PDF_EXTENSIONS = {".pdf"}
EXCEL_EXTENSIONS = {".xlsx", ".xlsm", ".xltx", ".xls"}
WORD_EXTENSIONS = {".docx"}
CSV_EXTENSIONS = {".csv", ".tsv", ".txt"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif"}

SUPPORTED_EXTENSIONS = (
    PDF_EXTENSIONS
    | EXCEL_EXTENSIONS
    | WORD_EXTENSIONS
    | CSV_EXTENSIONS
    | IMAGE_EXTENSIONS
)

# Qt file-dialog filter string, kept beside the extension lists it mirrors.
FILE_DIALOG_FILTER = (
    "Financial documents (*.pdf *.xlsx *.xlsm *.xls *.docx *.csv *.tsv "
    "*.png *.jpg *.jpeg *.tif *.tiff);;"
    "PDF files (*.pdf);;"
    "Excel files (*.xlsx *.xlsm *.xls);;"
    "Word files (*.docx);;"
    "CSV files (*.csv *.tsv);;"
    "Images (*.png *.jpg *.jpeg *.tif *.tiff);;"
    "All files (*)"
)


def is_supported(file_path: str | Path) -> bool:
    return Path(file_path).suffix.lower() in SUPPORTED_EXTENSIONS


def file_kind(file_path: str | Path) -> str:
    """Coarse category used for display and routing."""
    suffix = Path(file_path).suffix.lower()
    if suffix in PDF_EXTENSIONS:
        return "PDF"
    if suffix in EXCEL_EXTENSIONS:
        return "Excel"
    if suffix in WORD_EXTENSIONS:
        return "Word"
    if suffix in CSV_EXTENSIONS:
        return "CSV"
    if suffix in IMAGE_EXTENSIONS:
        return "Image"
    return "Unknown"


# ----------------------------------------------------------------- tabular


def _rows_to_page(rows: List[List[str]], page_number: int, label: str) -> PageContent:
    """Wrap raw cell rows as a PageContent carrying one table."""
    page = PageContent(page_number=page_number)
    page.tables = [[[cell for cell in row] for row in rows]] if rows else []
    text_lines = [label] if label else []
    text_lines.extend(" ".join(str(c) for c in row if c) for row in rows)
    page.text = "\n".join(text_lines)
    return page


def extract_excel(file_path: str | Path) -> ExtractionResult:
    """Read every worksheet; each sheet becomes one 'page'."""
    path = Path(file_path)
    result = ExtractionResult(file_path=str(path))
    try:
        import pandas as pd

        sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    except ImportError as exc:
        result.error = (
            "Excel support requires the 'pandas' and 'openpyxl' packages. "
            f"({exc})"
        )
        return result
    except Exception as exc:
        result.error = (
            f"Could not read the Excel file '{path.name}'. It may be corrupted "
            f"or in an unsupported format. ({exc})"
        )
        log.warning("Excel read failed for %s: %s", path, exc)
        return result

    pages: List[PageContent] = []
    for index, (sheet_name, frame) in enumerate(sheets.items(), start=1):
        rows: List[List[str]] = []
        for _, series in frame.iterrows():
            row = ["" if _is_blank(v) else str(v).strip() for v in series.tolist()]
            if any(row):
                rows.append(row)
        pages.append(_rows_to_page(rows, index, f"Sheet: {sheet_name}"))

    result.pages = pages
    result.page_count = len(pages)
    result.lines = build_raw_lines(pages)
    if not result.lines:
        result.warnings.append(
            f"No recognisable financial line items were found in '{path.name}'."
        )
    return result


def _is_blank(value: object) -> bool:
    if value is None:
        return True
    text = str(value).strip()
    return text == "" or text.lower() in {"nan", "nat", "none"}


def extract_csv(file_path: str | Path) -> ExtractionResult:
    """Read a delimited text file, sniffing the delimiter."""
    path = Path(file_path)
    result = ExtractionResult(file_path=str(path))
    try:
        raw = path.read_text(encoding="utf-8-sig", errors="replace")
    except Exception as exc:
        result.error = f"Could not read '{path.name}'. ({exc})"
        return result

    if not raw.strip():
        result.error = f"'{path.name}' is empty."
        return result

    delimiter = ","
    try:
        dialect = csv.Sniffer().sniff(raw[:4096], delimiters=",;\t|")
        delimiter = dialect.delimiter
    except Exception:
        if path.suffix.lower() == ".tsv" or "\t" in raw[:4096]:
            delimiter = "\t"

    rows: List[List[str]] = []
    try:
        for row in csv.reader(raw.splitlines(), delimiter=delimiter):
            cleaned = [str(c).strip() for c in row]
            if any(cleaned):
                rows.append(cleaned)
    except Exception as exc:
        result.error = f"Could not parse '{path.name}' as a table. ({exc})"
        return result

    page = _rows_to_page(rows, 1, path.name)
    result.pages = [page]
    result.page_count = 1
    result.lines = build_raw_lines([page])
    if not result.lines:
        result.warnings.append(
            f"No recognisable financial line items were found in '{path.name}'."
        )
    return result


# -------------------------------------------------------------------- Word


def extract_word(file_path: str | Path) -> ExtractionResult:
    """Read paragraphs and tables from a .docx file."""
    path = Path(file_path)
    result = ExtractionResult(file_path=str(path))
    try:
        import docx
    except ImportError as exc:
        result.error = f"Word support requires the 'python-docx' package. ({exc})"
        return result

    try:
        document = docx.Document(str(path))
    except Exception as exc:
        result.error = (
            f"Could not open the Word file '{path.name}'. Note that legacy .doc "
            f"files are not supported -- please save as .docx. ({exc})"
        )
        log.warning("Word read failed for %s: %s", path, exc)
        return result

    page = PageContent(page_number=1)
    paragraphs = [p.text.strip() for p in document.paragraphs if p.text.strip()]
    page.text = "\n".join(paragraphs)

    tables: List[List[List[Optional[str]]]] = []
    try:
        for table in document.tables:
            rows: List[List[Optional[str]]] = []
            for row in table.rows:
                rows.append([cell.text.strip() for cell in row.cells])
            if rows:
                tables.append(rows)
    except Exception as exc:
        result.warnings.append(f"Some tables in '{path.name}' could not be read ({exc}).")
    page.tables = tables

    result.pages = [page]
    result.page_count = 1
    result.lines = build_raw_lines([page])
    if not result.lines:
        result.warnings.append(
            f"No recognisable financial line items were found in '{path.name}'."
        )
    return result


# ------------------------------------------------------------------- images


def extract_image(file_path: str | Path, enable_ocr: bool = True) -> ExtractionResult:
    """OCR an image document. Degrades gracefully when OCR is unavailable."""
    path = Path(file_path)
    result = ExtractionResult(file_path=str(path))
    result.page_count = 1

    if not enable_ocr:
        result.warnings.append(
            f"'{path.name}' is an image and OCR is switched off. Any figures in "
            "this document must be entered manually."
        )
        result.pages = [PageContent(page_number=1, is_scanned=True)]
        return result

    available, message = ocr_engine.availability()
    if not available:
        result.warnings.append(
            f"'{path.name}' is an image. {message} Figures in this document must "
            "be entered manually on the verification screen."
        )
        result.pages = [PageContent(page_number=1, is_scanned=True, ocr_message=message)]
        return result

    ocr_result = ocr_engine.ocr_image_file(path)
    page = PageContent(
        page_number=1,
        text=ocr_result.text,
        is_scanned=True,
        ocr_used=bool(ocr_result),
        ocr_message=ocr_result.message,
    )
    result.pages = [page]
    result.ocr_used = bool(ocr_result)
    if not ocr_result:
        result.warnings.append(f"'{path.name}': {ocr_result.message}")
        return result
    result.lines = build_raw_lines([page])
    if not result.lines:
        result.warnings.append(
            f"OCR read '{path.name}' but no financial line items were recognised. "
            "Please verify this document manually."
        )
    return result


# --------------------------------------------------------------- public API


def extract_document(
    file_path: str | Path, enable_ocr: bool = True
) -> ExtractionResult:
    """Extract from any supported document type.

    Never raises -- unreadable files come back with ``result.error`` set to a
    message that can be shown to the user verbatim.
    """
    path = Path(file_path)
    if not path.exists():
        result = ExtractionResult(file_path=str(path))
        result.error = f"File not found: {path}"
        return result

    suffix = path.suffix.lower()
    try:
        if suffix in PDF_EXTENSIONS:
            return extract_pdf(path, enable_ocr=enable_ocr)
        if suffix in EXCEL_EXTENSIONS:
            return extract_excel(path)
        if suffix in WORD_EXTENSIONS:
            return extract_word(path)
        if suffix in CSV_EXTENSIONS:
            return extract_csv(path)
        if suffix in IMAGE_EXTENSIONS:
            return extract_image(path, enable_ocr=enable_ocr)
    except Exception as exc:  # last-resort guard
        log.exception("Unexpected extraction failure for %s", path)
        result = ExtractionResult(file_path=str(path))
        result.error = (
            f"An unexpected problem occurred while reading '{path.name}': {exc}"
        )
        return result

    result = ExtractionResult(file_path=str(path))
    result.error = (
        f"'{path.suffix or path.name}' is not a supported file type. Please upload "
        "a PDF, Excel, Word, CSV or image file."
    )
    return result


def count_pages(file_path: str | Path) -> int:
    """Best-effort page/sheet count for the upload table."""
    path = Path(file_path)
    suffix = path.suffix.lower()
    try:
        if suffix in PDF_EXTENSIONS:
            from .pdf_extractor import count_pdf_pages

            return count_pdf_pages(path)
        if suffix in EXCEL_EXTENSIONS:
            import openpyxl

            workbook = openpyxl.load_workbook(str(path), read_only=True)
            try:
                return len(workbook.sheetnames)
            finally:
                workbook.close()
        if suffix in WORD_EXTENSIONS or suffix in CSV_EXTENSIONS:
            return 1
        if suffix in IMAGE_EXTENSIONS:
            return 1
    except Exception as exc:
        log.warning("Page count failed for %s: %s", path, exc)
    return 0
