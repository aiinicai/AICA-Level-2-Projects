"""Draft professional client queries from the risk flags.

The queries are written as an audit team would address them to a client:
courteous, specific about the document required, and phrased as requests for
information rather than as accusations. The same cautious-language rule that
governs the risk engine applies here.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence

from ..database.models import AuditQuery, Case, RiskFlag
from .logging_setup import get_logger

log = get_logger(__name__)

# Risk levels that warrant a written query to the client. Informational items
# are recorded in the report but do not need a client response.
QUERY_WORTHY_LEVELS = {"HIGH", "MEDIUM", "REVIEW REQUIRED"}

# Areas whose queries are best merged into a single consolidated request, to
# avoid sending the client fifteen near-identical TDS letters.
CONSOLIDATED_AREAS = {
    "Tax Deduction at Source",
    "Expense Analysis",
}

MAX_DOCUMENTS_LISTED = 6


def _opening(area: str) -> str:
    return f"With reference to our review of the financial statements, in relation to {area.lower()}:"


def _compose_query_text(flag: RiskFlag) -> str:
    """Turn one risk flag into a client-facing request."""
    parts: List[str] = [flag.observation.strip()]

    if flag.recommended_verification:
        parts.append(
            "We should be grateful if you would " + _to_request(flag.recommended_verification)
        )

    if flag.documents_to_verify:
        listed = flag.documents_to_verify[:MAX_DOCUMENTS_LISTED]
        bullets = "".join(f"\n    ({chr(97 + i)}) {doc}" for i, doc in enumerate(listed))
        parts.append("In particular, please provide:" + bullets)

    return "\n\n".join(p for p in parts if p)


# Auditor-facing verbs and the client-facing request they become. Applied to
# every sentence, not just the first, because a verification instruction often
# chains several actions ("Obtain the ageing, examine balances, review ...").
_VERB_REPLACEMENTS = [
    ("For each of these heads, obtain ", "for each of these heads provide "),
    ("Obtain a ", "provide a "),
    ("Obtain an ", "provide an "),
    ("Obtain the ", "provide the "),
    ("Obtain ", "provide "),
    ("Examine whether ", "confirm whether "),
    ("Examine the ", "let us have the "),
    ("Examine ", "let us have details of "),
    ("Verify that ", "confirm that "),
    ("Verify ", "confirm "),
    ("Reconcile ", "provide a reconciliation of "),
    ("Confirm whether ", "confirm whether "),
    ("Confirm that ", "confirm that "),
    ("Confirm ", "confirm "),
    ("Determine ", "confirm "),
    ("Review the ", "provide the "),
    ("Review ", "provide "),
    ("Perform ", "provide the results of "),
    ("Upload the ", "provide the "),
]

# Sentences addressed to the auditor's own judgement rather than to the
# client. These are retained in the report but never sent out in a letter.
_INTERNAL_SENTENCE_PREFIXES = (
    "requires verification for possible applicability",
    "potential applicability",
)


def _split_sentences(text: str) -> List[str]:
    """Split on sentence boundaries, keeping it simple and predictable."""
    import re

    parts = re.split(r"(?<=\.)\s+(?=[A-Z])", text.strip())
    return [p.strip() for p in parts if p.strip()]


def _recast_sentence(sentence: str) -> str:
    """Convert one auditor instruction sentence into a client request."""
    for prefix, replacement in _VERB_REPLACEMENTS:
        if sentence.startswith(prefix):
            return replacement + sentence[len(prefix):]
    # Not a recognised instruction verb: lower-case the opening word so the
    # sentence continues the "we should be grateful if you would ..." clause.
    return sentence[0].lower() + sentence[1:] if sentence else sentence


def _to_request(text: str) -> str:
    """Recast a verification instruction as a polite request to the client.

    Internal caution sentences are dropped: telling a client that a matter
    "requires verification for possible applicability of Section 68" reads as
    an allegation, whereas asking for the supporting documents does not.
    """
    sentences = _split_sentences(text)
    kept: List[str] = []
    for index, sentence in enumerate(sentences):
        lowered = sentence.lower()
        if any(lowered.startswith(p) for p in _INTERNAL_SENTENCE_PREFIXES):
            continue
        kept.append(_recast_sentence(sentence) if index == 0 else _continue(sentence))

    request = " ".join(kept).strip()
    if not request:
        request = "provide the supporting records for our examination."
    if not request.endswith("."):
        request += "."
    return request


def _continue(sentence: str) -> str:
    """Recast a follow-on sentence, keeping it inside the same request."""
    for prefix, replacement in _VERB_REPLACEMENTS:
        if sentence.startswith(prefix):
            return "Please " + replacement + sentence[len(prefix):]
    return sentence


def generate_queries(
    flags: Sequence[RiskFlag], case: Optional[Case] = None
) -> List[AuditQuery]:
    """Draft one query per matter requiring a client response.

    Flags in consolidated areas are grouped so the client receives a single
    request per area rather than one per line item.
    """
    relevant = [f for f in flags if f.risk_level in QUERY_WORTHY_LEVELS]
    queries: List[AuditQuery] = []
    consolidated: Dict[str, List[RiskFlag]] = {}

    for flag in relevant:
        if flag.area in CONSOLIDATED_AREAS:
            consolidated.setdefault(flag.area, []).append(flag)
        else:
            queries.append(
                AuditQuery(
                    case_id=case.case_id if case else flag.case_id,
                    risk_flag_id=flag.id,
                    area=flag.area,
                    query_text=_compose_query_text(flag),
                    documents_sought="; ".join(flag.documents_to_verify),
                )
            )

    for area, area_flags in consolidated.items():
        queries.append(_consolidate(area, area_flags, case))

    # Number the queries in severity order so the client sees the most
    # significant requests first.
    level_order = {"HIGH": 0, "MEDIUM": 1, "REVIEW REQUIRED": 2}
    flag_level: Dict[int, str] = {}
    for index, query in enumerate(queries):
        source_level = "REVIEW REQUIRED"
        for flag in relevant:
            if flag.area == query.area:
                source_level = min(
                    source_level,
                    flag.risk_level,
                    key=lambda l: level_order.get(l, 9),
                )
        flag_level[index] = source_level

    order = sorted(
        range(len(queries)), key=lambda i: (level_order.get(flag_level[i], 9), i)
    )
    ordered = [queries[i] for i in order]
    for number, query in enumerate(ordered, start=1):
        query.query_number = number

    log.info("Generated %d auditor quer(ies) from %d flag(s)", len(ordered), len(relevant))
    return ordered


def _consolidate(
    area: str, flags: Sequence[RiskFlag], case: Optional[Case]
) -> AuditQuery:
    """Merge several flags in one area into a single client request."""
    observations = []
    documents: List[str] = []
    for flag in flags:
        observations.append(f"- {flag.observation.strip()}")
        for doc in flag.documents_to_verify:
            if doc not in documents:
                documents.append(doc)

    listed = documents[:MAX_DOCUMENTS_LISTED]
    bullets = "".join(f"\n    ({chr(97 + i)}) {doc}" for i, doc in enumerate(listed))
    text = (
        f"{_opening(area)}\n\n"
        + "\n".join(observations)
        + "\n\nWe should be grateful if you would provide the following in respect "
        "of the matters set out above:"
        + bullets
    )
    return AuditQuery(
        case_id=case.case_id if case else (flags[0].case_id if flags else ""),
        risk_flag_id=None,
        area=area,
        query_text=text,
        documents_sought="; ".join(documents),
    )


def queries_to_plain_text(
    queries: Sequence[AuditQuery], case: Optional[Case] = None
) -> str:
    """Render the query list as plain text (used for copy-to-clipboard)."""
    lines: List[str] = []
    if case:
        lines.append(f"AUDITOR QUERIES - {case.assessee_name}")
        lines.append(f"Case: {case.case_id}   Financial Year: {case.financial_year}")
        lines.append("")
    for query in queries:
        lines.append(f"Query {query.query_number}: {query.area}")
        lines.append(query.query_text)
        lines.append("")
    return "\n".join(lines)
