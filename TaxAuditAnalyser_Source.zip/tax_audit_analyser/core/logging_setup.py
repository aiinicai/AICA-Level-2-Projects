"""Application-wide logging configuration.

All modules obtain loggers via :func:`get_logger`. Logging is configured once,
writing to ``<data_root>/logs/app.log`` with rotation plus a console stream.
"""

from __future__ import annotations

import logging
import logging.handlers
import sys
from typing import Optional

from ..paths import logs_dir

_CONFIGURED = False
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-38s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(level: int = logging.INFO, console: bool = True) -> logging.Logger:
    """Configure root logging exactly once. Safe to call repeatedly."""
    global _CONFIGURED
    root = logging.getLogger("tax_audit_analyser")
    if _CONFIGURED:
        return root

    root.setLevel(level)
    root.propagate = False
    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    try:
        log_file = logs_dir() / "app.log"
        file_handler = logging.handlers.RotatingFileHandler(
            log_file, maxBytes=2_000_000, backupCount=5, encoding="utf-8"
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(level)
        root.addHandler(file_handler)
    except Exception as exc:  # pragma: no cover - filesystem edge case
        # Never let logging setup break the application.
        print(f"Warning: could not open log file ({exc}). Logging to console only.")

    if console:
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(formatter)
        stream.setLevel(max(level, logging.WARNING))
        root.addHandler(stream)

    _CONFIGURED = True
    root.debug("Logging initialised.")
    return root


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Return a namespaced logger, configuring logging on first use."""
    setup_logging()
    if not name:
        return logging.getLogger("tax_audit_analyser")
    if name.startswith("tax_audit_analyser"):
        return logging.getLogger(name)
    return logging.getLogger(f"tax_audit_analyser.{name}")
