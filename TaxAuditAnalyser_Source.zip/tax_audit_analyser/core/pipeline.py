"""End-to-end orchestration: documents in, analysed case out.

The GUI and the tests both drive the analysis through this module, so the
sequence of steps is defined in exactly one place. Each stage persists its
output, which is what lets a case be closed and reopened at any point.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from ..database.db import Database, DatabaseError, get_database
from ..database.models import (
    AnalysisResult,
    AuditQuery,
    Case,
    Document,
    ExtractedFigure,
    ReportRecord,
    RiskFlag,
)
from ..paths import case_upload_dir
from . import doc_extractor
from .analysis_engine import (
    FinancialDataset,
    ValidationCheck,
    build_dataset,
    dataset_from_figures,
    financial_snapshot,
    run_validations,
    validations_to_results,
    year_on_year_analysis,
)
from .logging_setup import get_logger
from .query_generator import generate_queries
from .ratio_engine import Ratio, compute_ratios, ratios_to_results
from .report_generator import ReportError, generate_report
from .tax_risk_engine import load_risk_thresholds, run_risk_analysis

log = get_logger(__name__)

ProgressCallback = Optional[Callable[[str, int], None]]


@dataclass
class AnalysisOutcome:
    """Everything produced by a full analysis run."""

    case: Case
    dataset: FinancialDataset
    validations: List[ValidationCheck] = field(default_factory=list)
    ratios: List[Ratio] = field(default_factory=list)
    yoy: List[AnalysisResult] = field(default_factory=list)
    snapshot: List[AnalysisResult] = field(default_factory=list)
    flags: List[RiskFlag] = field(default_factory=list)
    queries: List[AuditQuery] = field(default_factory=list)
    documents: List[Document] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def risk_counts(self) -> Dict[str, int]:
        from .tax_risk_engine import summarise_by_level

        return summarise_by_level(self.flags)


def _report(callback: ProgressCallback, message: str, percent: int) -> None:
    if callback:
        try:
            callback(message, percent)
        except Exception:  # a failing progress bar must never stop the analysis
            log.debug("Progress callback raised; continuing.", exc_info=True)


# ------------------------------------------------------------------ uploads


def store_uploaded_file(
    case_id: str, source_path: str | Path, document_type: str, db: Optional[Database] = None
) -> Document:
    """Copy a file into the case's upload folder and register it.

    The original is never moved, so the CA's own copy stays where it was.
    """
    database = db or get_database()
    source = Path(source_path)
    if not source.exists():
        raise FileNotFoundError(f"The file '{source}' could not be found.")

    target_dir = case_upload_dir(case_id)
    target = target_dir / source.name
    # Never silently overwrite a previously uploaded file of the same name.
    counter = 1
    while target.exists():
        target = target_dir / f"{source.stem}_{counter}{source.suffix}"
        counter += 1

    shutil.copy2(source, target)
    document = Document(
        case_id=case_id,
        file_name=source.name,
        stored_path=str(target),
        document_type=document_type,
        file_type=doc_extractor.file_kind(source),
        pages=doc_extractor.count_pages(target),
        status="Uploaded",
    )
    document.id = database.add_document(document)
    log.info("Stored %s for case %s as %s", source.name, case_id, target)
    return document


# ---------------------------------------------------------------- extraction


def extract_documents(
    case_id: str,
    documents: Sequence[Document],
    db: Optional[Database] = None,
    enable_ocr: bool = True,
    progress: ProgressCallback = None,
) -> Tuple[FinancialDataset, List[str]]:
    """Extract and map every document, persisting the resulting figures."""
    database = db or get_database()
    results: List[Tuple[str, object]] = []
    errors: List[str] = []
    total = max(len(documents), 1)

    for index, document in enumerate(documents, start=1):
        _report(
            progress,
            f"Reading {document.file_name} ({index} of {len(documents)})",
            int(10 + (index / total) * 40),
        )
        if document.id:
            database.update_document_status(document.id, "Processing")
        try:
            result = doc_extractor.extract_document(
                document.stored_path, enable_ocr=enable_ocr
            )
        except Exception as exc:
            message = f"{document.file_name}: unexpected error while reading ({exc})"
            errors.append(message)
            log.exception("Extraction crashed for %s", document.file_name)
            if document.id:
                database.update_document_status(
                    document.id, "Error", error_message=str(exc)
                )
            continue

        if result.error:
            errors.append(f"{document.file_name}: {result.error}")
            if document.id:
                database.update_document_status(
                    document.id, "Error", error_message=result.error
                )
            continue

        results.append((document.file_name, result))
        if document.id:
            database.update_document_status(
                document.id,
                "Extracted",
                pages=result.page_count,
                ocr_used=result.ocr_used,
            )

    _report(progress, "Mapping financial headings", 55)
    dataset = build_dataset(results, case_id=case_id)

    try:
        database.save_extracted_figures(case_id, dataset.as_list())
    except DatabaseError as exc:
        errors.append(str(exc))

    if results:
        database.update_case_status(case_id, "Extraction Completed")
    return dataset, errors


# ------------------------------------------------------------------ analysis


def analyse_case(
    case: Case,
    dataset: Optional[FinancialDataset] = None,
    db: Optional[Database] = None,
    progress: ProgressCallback = None,
) -> AnalysisOutcome:
    """Run validations, ratios, YoY, risk flags and queries; persist them all.

    When ``dataset`` is omitted the stored (and possibly CA-corrected) figures
    are reloaded from the database, which is what makes the verification screen
    meaningful: corrections made there flow into the analysis.
    """
    database = db or get_database()
    if dataset is None:
        _report(progress, "Loading verified figures", 55)
        dataset = dataset_from_figures(database.list_extracted_figures(case.case_id))

    outcome = AnalysisOutcome(case=case, dataset=dataset)
    outcome.documents = database.list_documents(case.case_id)

    _report(progress, "Validating the accounts", 62)
    outcome.validations = run_validations(dataset)

    _report(progress, "Computing year-on-year movements", 70)
    outcome.yoy = year_on_year_analysis(dataset)
    outcome.snapshot = financial_snapshot(dataset)

    _report(progress, "Computing ratios", 78)
    outcome.ratios = compute_ratios(dataset)

    _report(progress, "Identifying tax audit risk areas", 86)
    outcome.flags = run_risk_analysis(
        dataset,
        case=case,
        validations=outcome.validations,
        ratios=outcome.ratios,
        thresholds=load_risk_thresholds(),
    )

    _report(progress, "Drafting auditor queries", 92)
    outcome.queries = generate_queries(outcome.flags, case)

    _report(progress, "Saving results", 96)
    try:
        combined: List[AnalysisResult] = []
        combined.extend(outcome.yoy)
        combined.extend(outcome.snapshot)
        combined.extend(ratios_to_results(outcome.ratios, case.case_id))
        combined.extend(validations_to_results(outcome.validations, case.case_id))
        for result in combined:
            result.case_id = case.case_id
        database.save_analysis_results(case.case_id, combined)
        database.save_risk_flags(case.case_id, outcome.flags)
        database.save_audit_queries(case.case_id, outcome.queries)
        database.update_case_status(case.case_id, "Analysis Completed")
    except DatabaseError as exc:
        outcome.errors.append(str(exc))

    _report(progress, "Analysis complete", 100)
    return outcome


# -------------------------------------------------------------------- report


def build_report(
    outcome: AnalysisOutcome,
    db: Optional[Database] = None,
    output_path: Optional[Path] = None,
    firm_name: str = "",
) -> Path:
    """Generate the Word report and record it against the case."""
    database = db or get_database()
    path = generate_report(
        case=outcome.case,
        dataset=outcome.dataset,
        flags=outcome.flags,
        ratios=outcome.ratios,
        yoy=outcome.yoy,
        snapshot=outcome.snapshot,
        validations=outcome.validations,
        queries=outcome.queries,
        documents=outcome.documents,
        output_path=output_path,
        firm_name=firm_name or database.get_setting("firm_name", ""),
    )
    try:
        database.add_report(
            ReportRecord(
                case_id=outcome.case.case_id,
                report_type="Main Analysis Report",
                file_path=str(path),
                file_size=path.stat().st_size,
            )
        )
        database.update_case_status(outcome.case.case_id, "Report Generated")
    except DatabaseError as exc:
        log.warning("Report generated but not recorded: %s", exc)
    return path


def run_full_pipeline(
    case: Case,
    file_paths: Sequence[Tuple[str, str]],
    db: Optional[Database] = None,
    enable_ocr: bool = True,
    generate_word_report: bool = True,
    progress: ProgressCallback = None,
) -> Tuple[AnalysisOutcome, Optional[Path]]:
    """Create/refresh a case from files and run everything end to end.

    ``file_paths`` is a sequence of ``(path, document_type)`` pairs. Used by
    the smoke test and available to the GUI for a one-click re-run.
    """
    database = db or get_database()

    if database.get_case(case.case_id) is None:
        case.case_id = database.create_case(case)

    _report(progress, "Storing uploaded documents", 5)
    documents: List[Document] = []
    errors: List[str] = []
    for path, document_type in file_paths:
        try:
            documents.append(
                store_uploaded_file(case.case_id, path, document_type, db=database)
            )
        except Exception as exc:
            errors.append(f"{Path(path).name}: {exc}")
            log.exception("Could not store %s", path)

    if documents:
        database.update_case_status(case.case_id, "Documents Uploaded")

    dataset, extraction_errors = extract_documents(
        case.case_id, documents, db=database, enable_ocr=enable_ocr, progress=progress
    )
    errors.extend(extraction_errors)

    outcome = analyse_case(case, dataset=dataset, db=database, progress=progress)
    outcome.errors = errors + outcome.errors

    report_path: Optional[Path] = None
    if generate_word_report:
        _report(progress, "Generating the Word report", 98)
        try:
            report_path = build_report(outcome, db=database)
        except ReportError as exc:
            outcome.errors.append(str(exc))

    return outcome, report_path
