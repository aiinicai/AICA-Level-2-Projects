"""Central path resolution.

Works identically when running from source and when frozen by PyInstaller.
Never use bare cwd-relative paths anywhere else in the application.

Two distinct roots are needed:

``resource_root()``
    Read-only files shipped *with* the application (assets, schema.sql).
    Under PyInstaller one-folder/one-file builds these live in ``sys._MEIPASS``.

``data_root()``
    Writable user data (database, uploads, reports, logs). Never inside
    ``_MEIPASS`` because that is a temp dir wiped on exit.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

APP_DIR_NAME = "TaxAuditAnalyser"


def is_frozen() -> bool:
    """True when running inside a PyInstaller bundle."""
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def resource_root() -> Path:
    """Root for read-only bundled resources."""
    if is_frozen():
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


def data_root() -> Path:
    """Root for writable application data.

    Honours the ``TAXAUDIT_DATA_DIR`` environment variable, which the test
    suite uses to redirect all state into a temporary directory.
    """
    override = os.environ.get("TAXAUDIT_DATA_DIR")
    if override:
        root = Path(override).expanduser().resolve()
    elif is_frozen():
        # Frozen: keep user data beside the user's profile, not in _MEIPASS.
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if base:
            root = Path(base) / APP_DIR_NAME
        else:
            root = Path.home() / f".{APP_DIR_NAME.lower()}"
    else:
        root = Path(__file__).resolve().parent
    root.mkdir(parents=True, exist_ok=True)
    return root


def resource_path(*parts: str) -> Path:
    """Absolute path to a bundled read-only resource."""
    return resource_root().joinpath(*parts)


def _writable_dir(name: str) -> Path:
    path = data_root() / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def uploads_dir() -> Path:
    return _writable_dir("uploads")


def reports_dir() -> Path:
    return _writable_dir("reports")


def logs_dir() -> Path:
    return _writable_dir("logs")


def config_dir() -> Path:
    return _writable_dir("config")


def assets_dir() -> Path:
    """Assets are read-only resources, but fall back to a writable dir."""
    path = resource_path("assets")
    if path.exists():
        return path
    return _writable_dir("assets")


def database_path() -> Path:
    return data_root() / "tax_audit.db"


def schema_path() -> Path:
    """Locate schema.sql in both source and frozen layouts."""
    candidates = [
        resource_path("database", "schema.sql"),
        Path(__file__).resolve().parent / "database" / "schema.sql",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


def case_upload_dir(case_id: str) -> Path:
    """Per-case upload folder; case_id is sanitised for filesystem safety."""
    safe = "".join(ch for ch in str(case_id) if ch.isalnum() or ch in "-_")
    path = uploads_dir() / (safe or "unknown_case")
    path.mkdir(parents=True, exist_ok=True)
    return path
