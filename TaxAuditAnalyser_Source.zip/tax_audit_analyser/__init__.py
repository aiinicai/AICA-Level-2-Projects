"""Tax Audit Financial Statement Analyser."""

__version__ = "1.0.0"
__app_name__ = "Tax Audit Financial Statement Analyser"
__app_subtitle__ = "Financial Statement Review & Risk Identification System"
