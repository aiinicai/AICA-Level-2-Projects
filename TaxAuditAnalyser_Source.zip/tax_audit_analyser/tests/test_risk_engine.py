"""Risk flag generation, and the cautious-language guarantees."""

from __future__ import annotations

import re

import pytest

from tax_audit_analyser.core.analysis_engine import run_validations
from tax_audit_analyser.core.query_generator import generate_queries
from tax_audit_analyser.core.ratio_engine import compute_ratios
from tax_audit_analyser.core.tax_risk_engine import (
    DEFAULT_FORM_3CD_MAPPING,
    FACT,
    HIGH,
    INFORMATIONAL,
    MEDIUM,
    POTENTIAL_TAX_ISSUE,
    REVIEW,
    VERIFICATION_REQUIRED,
    form_3cd_reporting_areas,
    run_risk_analysis,
    summarise_by_level,
)
from tax_audit_analyser.database.models import FINDING_TYPES, RISK_LEVELS, Case
from .test_analysis import make_dataset


def analyse(dataset, case: Case):
    return run_risk_analysis(
        dataset,
        case=case,
        validations=run_validations(dataset),
        ratios=compute_ratios(dataset),
    )


@pytest.fixture()
def sunrise_flags(sunrise_dataset, sample_case):
    return analyse(sunrise_dataset, sample_case)


@pytest.fixture()
def meridian_flags(meridian_dataset):
    case = Case(
        case_id="TEST-0002",
        assessee_name="Meridian Enterprises",
        constitution="Partnership Firm",
    )
    return analyse(meridian_dataset, case)


class TestFlagGeneration:
    def test_flags_are_produced(self, sunrise_flags):
        assert len(sunrise_flags) > 10

    def test_every_flag_is_well_formed(self, sunrise_flags):
        for flag in sunrise_flags:
            assert flag.risk_level in RISK_LEVELS
            assert flag.finding_type in FINDING_TYPES
            assert flag.area
            assert flag.observation
            assert flag.recommended_verification
            assert isinstance(flag.documents_to_verify, list)

    def test_flags_are_sorted_most_severe_first(self, sunrise_flags):
        keys = [flag.sort_key for flag in sunrise_flags]
        assert keys == sorted(keys)

    def test_summary_counts_match_the_flags(self, sunrise_flags):
        counts = summarise_by_level(sunrise_flags)
        assert sum(counts.values()) == len(sunrise_flags)
        assert counts[HIGH] > 0


class TestPlantedScenarios:
    """Each fixture carries deliberate scenarios the engine must catch."""

    def _areas(self, flags):
        return {flag.area for flag in flags}

    def test_large_unsecured_loan_increase_is_caught(self, sunrise_flags):
        loans = [
            f
            for f in sunrise_flags
            if f.area == "Loans and Deposits" and "Unsecured" in f.observation
        ]
        assert loans, "the 460% unsecured loan increase was not flagged"
        flag = loans[0]
        assert flag.risk_level == HIGH
        assert "269SS" in flag.recommended_verification
        assert "68" in flag.recommended_verification

    def test_receivables_spike_is_caught(self, sunrise_flags):
        receivables = [f for f in sunrise_flags if f.area == "Trade Receivables"]
        assert any("79" in f.observation for f in receivables)

    def test_professional_fees_spike_is_caught(self, meridian_flags):
        """Meridian's professional fees rise 76% year on year."""
        expenses = [f for f in meridian_flags if f.area == "Expense Analysis"]
        assert any("Professional Fees" in f.observation for f in expenses)

    def test_balance_sheet_mismatch_becomes_a_high_risk_flag(self, meridian_flags):
        validation = [f for f in meridian_flags if f.area == "Accounting Validation"]
        assert validation
        assert any(f.risk_level == HIGH for f in validation)

    def test_large_cash_balance_is_caught(self, meridian_flags):
        cash = [f for f in meridian_flags if f.area == "Cash and Cash Transactions"]
        assert cash
        text = " ".join(f.recommended_verification for f in cash)
        for section in ("40A(3)", "269SS", "269ST", "269T"):
            assert section in text, f"{section} was not mentioned"

    def test_msme_dues_are_caught_with_43b_reference(self, sunrise_flags):
        msme = [f for f in sunrise_flags if "micro and small" in f.observation.lower()]
        assert msme
        assert any("43B" in f.recommended_verification for f in msme)

    def test_tds_areas_are_raised(self, sunrise_flags):
        tds = [f for f in sunrise_flags if f.area == "Tax Deduction at Source"]
        assert tds
        assert any("40(a)(ia)" in f.recommended_verification for f in tds)
        assert any("TDS verification is recommended" in f.observation for f in tds)

    def test_penalties_are_raised_for_allowability(self, meridian_flags):
        penalties = [f for f in meridian_flags if "Penalties" in f.observation]
        assert penalties

    def test_personal_expenditure_only_for_non_corporates(
        self, meridian_flags, sunrise_flags
    ):
        assert "Personal and Non-Business Expenditure" in self._areas(meridian_flags)
        # Sunrise is a private limited company: the personal-expenditure check
        # must not be raised against it.
        assert "Personal and Non-Business Expenditure" not in self._areas(sunrise_flags)

    def test_depreciation_gap_is_reported_as_missing_information(self, sunrise_flags):
        depreciation = [f for f in sunrise_flags if f.area == "Depreciation Review"]
        assert depreciation
        # The engine must say it lacks the asset-level data rather than
        # inventing a tax depreciation figure it cannot compute.
        gap = [f for f in depreciation if "could not be computed" in f.observation]
        assert gap, "the missing tax depreciation data was not reported"
        assert gap[0].finding_type == VERIFICATION_REQUIRED
        assert "block of assets" in gap[0].recommended_verification

    def test_related_party_review_is_raised(self, sunrise_flags):
        related = [f for f in sunrise_flags if f.area == "Related Party Review"]
        assert related
        assert any("40A(2)(b)" in f.recommended_verification for f in related)

    def test_gst_reconciliation_is_always_noted(self, sunrise_flags):
        assert any("GST" in f.observation or "goods and services tax" in f.observation
                   for f in sunrise_flags)

    def test_clean_accounts_generate_far_fewer_high_risks(
        self, sample_pdfs, sunrise_flags
    ):
        """Clearview is a deliberately clean fixture."""
        from tax_audit_analyser.core.analysis_engine import build_dataset
        from tax_audit_analyser.core.doc_extractor import extract_document

        pairs = [
            ("clearview_pl.pdf", extract_document(sample_pdfs["clearview_pl"])),
            ("clearview_bs.pdf", extract_document(sample_pdfs["clearview_bs"])),
        ]
        dataset = build_dataset(pairs, case_id="TEST-0003")
        case = Case(
            case_id="TEST-0003",
            assessee_name="Clearview Textiles Limited",
            constitution="Public Limited Company",
        )
        clean_flags = analyse(dataset, case)
        clean_high = summarise_by_level(clean_flags)[HIGH]
        dirty_high = summarise_by_level(sunrise_flags)[HIGH]
        assert clean_high < dirty_high, (
            "the engine does not discriminate between clean and problematic accounts"
        )


class TestNegativeAndEdgeValues:
    def test_negative_cash_is_flagged_high(self, sample_case):
        dataset = make_dataset(
            {
                "Turnover / Revenue": (1_00_00_000.0, 90_00_000.0),
                "Cash in Hand": (-5_00_000.0, 2_00_000.0),
            }
        )
        flags = analyse(dataset, sample_case)
        cash = [f for f in flags if f.area == "Cash and Cash Transactions"]
        assert cash and cash[0].risk_level == HIGH
        assert "negative" in cash[0].observation.lower()

    def test_negative_turnover_is_flagged(self, sample_case):
        dataset = make_dataset({"Turnover / Revenue": (-50_00_000.0, 90_00_000.0)})
        flags = analyse(dataset, sample_case)
        assert any(
            f.risk_level == HIGH and "negative" in f.observation.lower()
            for f in flags
        )

    def test_round_number_expense_is_queried(self, sample_case):
        dataset = make_dataset(
            {
                "Turnover / Revenue": (5_00_00_000.0, 5_00_00_000.0),
                "Commission & Brokerage": (10_00_000.0, 10_00_000.0),
            }
        )
        flags = analyse(dataset, sample_case)
        assert any("round figure" in f.observation for f in flags)

    def test_empty_dataset_does_not_crash(self, sample_case):
        from tax_audit_analyser.core.analysis_engine import FinancialDataset

        flags = run_risk_analysis(FinancialDataset(), case=sample_case)
        assert isinstance(flags, list)   # no findings, but no exception either

    def test_a_failing_check_does_not_lose_the_other_findings(
        self, sunrise_dataset, sample_case, monkeypatch
    ):
        from tax_audit_analyser.core import tax_risk_engine

        def exploding_check(ctx):
            raise ValueError("simulated failure")

        exploding_check.__name__ = "check_exploding"
        monkeypatch.setattr(
            tax_risk_engine,
            "CHECKS",
            [exploding_check] + tax_risk_engine.CHECKS[:3],
        )
        flags = run_risk_analysis(sunrise_dataset, case=sample_case)
        assert any(f.area == "Analysis Engine" for f in flags)
        assert len(flags) > 1   # the surviving checks still ran


class TestLegalLanguageDiscipline:
    """The application must never assert a concluded statutory violation."""

    FORBIDDEN = re.compile(
        r"\b(violat\w*|non-compliant|noncompliant|illegal|unlawful|has evaded|"
        r"is guilty|contravene\w*|must be disallowed|is disallowed|"
        r"is not allowable under section)\b",
        re.IGNORECASE,
    )

    def _all_text(self, flags):
        parts = []
        for flag in flags:
            parts.extend(
                [
                    flag.observation,
                    flag.recommended_verification,
                    flag.tax_audit_relevance,
                    flag.why_flagged,
                    flag.potential_3cd_clause,
                ]
            )
        return [p for p in parts if p]

    def test_no_conclusive_violation_language(self, sunrise_flags, meridian_flags):
        for text in self._all_text(sunrise_flags) + self._all_text(meridian_flags):
            match = self.FORBIDDEN.search(text)
            assert match is None, f"forbidden phrase {match.group(0)!r} in: {text}"

    def test_statutory_findings_are_typed_cautiously(self, sunrise_flags):
        """A flag citing a section must be a potential issue, never a FACT."""
        sections = ("40A(3)", "269SS", "269ST", "269T", "43B", "40(a)(ia)", "40A(2)(b)")
        for flag in sunrise_flags:
            text = f"{flag.observation} {flag.recommended_verification}"
            if any(section in text for section in sections):
                assert flag.finding_type in (
                    POTENTIAL_TAX_ISSUE,
                    VERIFICATION_REQUIRED,
                ), f"{flag.area} cites a section but is typed {flag.finding_type}"

    def test_only_the_permitted_sections_are_cited(self, sunrise_flags, meridian_flags):
        """Guards against the engine inventing section numbers."""
        permitted = {
            "40A(3)", "269SS", "269ST", "269T", "68", "43B", "40(a)(ia)", "40A(2)(b)",
        }
        pattern = re.compile(r"Section[s]?\s+([0-9A-Za-z()/\s,and]+?)(?:[.;]|\s+in\b|\s+as\b|\s+of\b)")
        for flag in sunrise_flags + meridian_flags:
            text = f"{flag.observation} {flag.recommended_verification} {flag.tax_audit_relevance}"
            for match in pattern.finditer(text):
                citation = match.group(1)
                found = re.findall(r"\d+[A-Z]*(?:\([0-9a-z]+\))*(?:\([a-z]+\))?", citation)
                for reference in found:
                    assert reference in permitted, (
                        f"unexpected statutory reference {reference!r} in {flag.area}"
                    )

    def test_uncertain_positions_use_the_standard_formula(self, sunrise_flags):
        potential = [f for f in sunrise_flags if f.finding_type == POTENTIAL_TAX_ISSUE]
        assert potential
        assert any(
            "professional verification required" in f.recommended_verification.lower()
            or "requires verification for possible applicability"
            in f.recommended_verification.lower()
            for f in potential
        )

    def test_facts_are_distinguished_from_opinions(self, sunrise_flags):
        types = {f.finding_type for f in sunrise_flags}
        # The model must actually use the distinction, not collapse everything
        # into one bucket.
        assert len(types) >= 3
        assert VERIFICATION_REQUIRED in types


class TestForm3cdMapping:
    def test_mapping_is_marked_indicative(self):
        for entry in DEFAULT_FORM_3CD_MAPPING.values():
            assert "clause" in entry
            text = entry["clause"].lower()
            assert "indicative" in text or "no specific mapping" in text

    def test_reporting_rows_are_produced(self, sunrise_flags):
        rows = form_3cd_reporting_areas(sunrise_flags)
        assert rows
        for row in rows:
            assert row["issue"]
            assert row["clause"]
            assert row["verification"]

    def test_mapping_file_round_trips(self, data_dir):
        from tax_audit_analyser.core.tax_risk_engine import (
            FORM_3CD_MAPPING_FILENAME,
            load_form_3cd_mapping,
        )
        from tax_audit_analyser.paths import config_dir

        mapping = load_form_3cd_mapping()
        assert mapping
        assert (config_dir() / FORM_3CD_MAPPING_FILENAME).exists()


class TestThresholdConfiguration:
    def test_thresholds_file_is_seeded(self, data_dir):
        from tax_audit_analyser.core.tax_risk_engine import (
            RISK_THRESHOLDS_FILENAME,
            load_risk_thresholds,
        )
        from tax_audit_analyser.paths import config_dir

        thresholds = load_risk_thresholds()
        assert thresholds["expense_spike_percent"] > 0
        assert (config_dir() / RISK_THRESHOLDS_FILENAME).exists()

    def test_lowering_a_threshold_produces_more_findings(
        self, sunrise_dataset, sample_case
    ):
        from tax_audit_analyser.core.tax_risk_engine import DEFAULT_RISK_THRESHOLDS

        strict = dict(DEFAULT_RISK_THRESHOLDS)
        strict["expense_spike_percent"] = 5.0
        lenient = dict(DEFAULT_RISK_THRESHOLDS)
        lenient["expense_spike_percent"] = 500.0

        many = run_risk_analysis(sunrise_dataset, sample_case, thresholds=strict)
        few = run_risk_analysis(sunrise_dataset, sample_case, thresholds=lenient)
        assert len(many) > len(few)


class TestQueryGeneration:
    def test_queries_are_generated(self, sunrise_flags, sample_case):
        queries = generate_queries(sunrise_flags, sample_case)
        assert queries
        for query in queries:
            assert query.query_text
            assert query.query_number > 0
            assert query.area

    def test_queries_are_numbered_sequentially(self, sunrise_flags, sample_case):
        queries = generate_queries(sunrise_flags, sample_case)
        assert [q.query_number for q in queries] == list(range(1, len(queries) + 1))

    def test_informational_flags_do_not_produce_queries(self, sample_case):
        from tax_audit_analyser.database.models import RiskFlag

        flags = [
            RiskFlag(
                risk_level=INFORMATIONAL,
                area="Tax Audit Applicability",
                observation="Turnover is Rs. 1,00,00,000.",
                finding_type=FACT,
                recommended_verification="Determine applicability.",
            )
        ]
        assert generate_queries(flags, sample_case) == []

    def test_client_letters_omit_internal_caution_sentences(
        self, sunrise_flags, sample_case
    ):
        """'Requires verification for possible applicability' is internal."""
        queries = generate_queries(sunrise_flags, sample_case)
        for query in queries:
            assert "Potential applicability - professional verification required" not in (
                query.query_text
            )

    def test_queries_carry_no_accusatory_language(self, sunrise_flags, sample_case):
        for query in generate_queries(sunrise_flags, sample_case):
            assert TestLegalLanguageDiscipline.FORBIDDEN.search(query.query_text) is None
