"""Consolidation, accounting validation, year-on-year analysis and ratios."""

from __future__ import annotations

import pytest

from tax_audit_analyser.core.analysis_engine import (
    FinancialDataset,
    build_dataset,
    classify_materiality,
    percentage_change,
    run_validations,
    validate_balance_sheet,
    validate_balance_sheet_components,
    validate_profit_and_loss,
    year_on_year_analysis,
)
from tax_audit_analyser.core.ratio_engine import compute_ratios
from tax_audit_analyser.database.models import ExtractedFigure


def make_dataset(values: dict) -> FinancialDataset:
    """Build a dataset directly from {head: (cy, py)} for focused tests."""
    from tax_audit_analyser.core.financial_mapper import statement_type_of

    dataset = FinancialDataset()
    for head, (cy, py) in values.items():
        dataset.figures[head] = ExtractedFigure(
            canonical_head=head,
            current_year_amount=cy,
            previous_year_amount=py,
            statement_type=statement_type_of(head),
            confidence="High",
            source_document="test.pdf",
            source_page=1,
        )
    return dataset


class TestPercentageAndMateriality:
    @pytest.mark.parametrize(
        "cy,py,expected",
        [
            (110, 100, 10.0),
            (50, 100, -50.0),
            (100, 100, 0.0),
            (100, 0, None),        # no meaningful base
            (None, 100, None),
            (100, None, None),
        ],
    )
    def test_percentage_change(self, cy, py, expected):
        result = percentage_change(cy, py)
        if expected is None:
            assert result is None
        else:
            assert result == pytest.approx(expected)

    @pytest.mark.parametrize(
        "percent,band",
        [
            (5.0, "Normal"),
            (-5.0, "Normal"),
            (10.0, "Review"),
            (15.0, "Review"),
            (20.0, "Significant"),
            (-35.0, "Significant"),
            (50.0, "High Movement"),
            (460.7, "High Movement"),
            (None, "Normal"),
        ],
    )
    def test_materiality_bands(self, percent, band):
        assert classify_materiality(percent) == band

    def test_thresholds_are_configurable(self):
        custom = {"review": 5.0, "significant": 8.0, "high": 12.0}
        assert classify_materiality(6.0, custom) == "Review"
        assert classify_materiality(9.0, custom) == "Significant"
        assert classify_materiality(15.0, custom) == "High Movement"


class TestConsolidation:
    def test_extracts_the_expected_number_of_heads(self, sunrise_dataset):
        assert len(sunrise_dataset.figures) >= 30

    def test_known_figures_survive_the_pipeline(self, sunrise_dataset):
        assert sunrise_dataset.cy("Turnover / Revenue") == pytest.approx(84_50_00_000)
        assert sunrise_dataset.py("Turnover / Revenue") == pytest.approx(78_20_00_000)
        assert sunrise_dataset.cy("Trade Receivables") == pytest.approx(16_85_00_000)

    def test_separate_lines_sharing_a_head_are_summed_not_overwritten(self, sunrise_dataset):
        """Salaries and Staff Cost are components, not duplicates.

        The Sunrise fixture charges Salaries and Wages (5,82,00,000) and, on a
        separate line, Directors Remuneration. Those now map to distinct heads,
        so Employee Cost must equal exactly the salaries line.
        """
        assert sunrise_dataset.cy("Employee Cost") == pytest.approx(5_82_00_000)
        assert sunrise_dataset.cy("Director / Partner Remuneration") == pytest.approx(
            1_20_00_000
        )

    def test_components_are_recorded(self, sunrise_dataset):
        components = sunrise_dataset.components_of("Turnover / Revenue")
        assert components
        assert all(c.source_document for c in components)

    def test_totals_are_never_double_counted(self, sunrise_dataset):
        # Total Assets appears once in the balance sheet; two documents must
        # not cause it to be summed with itself.
        assert sunrise_dataset.cy("Total Assets") == pytest.approx(54_39_00_000)

    def test_provenance_is_retained(self, sunrise_dataset):
        document, page = sunrise_dataset.source_of("Turnover / Revenue")
        assert document.endswith(".pdf")
        assert page == 1


class TestBalanceSheetValidation:
    def test_balanced_sheet_passes(self, sunrise_dataset):
        check = validate_balance_sheet(sunrise_dataset)
        assert check.applicable
        assert check.passed, check.message

    def test_planted_mismatch_is_detected(self, meridian_dataset):
        """The Meridian fixture understates its asset schedule by 58,00,000."""
        check = validate_balance_sheet_components(meridian_dataset)
        assert check.applicable
        assert not check.passed
        assert check.difference == pytest.approx(-58_00_000)
        assert "difference" in check.message.lower()

    def test_mismatch_is_reported_in_rupees_the_user_can_check(self, meridian_dataset):
        check = validate_balance_sheet_components(meridian_dataset)
        assert "12,10,00,000" in check.message.replace(",", "") or "121000000" in check.message.replace(",", "")

    def test_missing_totals_are_not_applicable_rather_than_failed(self):
        dataset = make_dataset({"Turnover / Revenue": (100.0, 90.0)})
        check = validate_balance_sheet(dataset)
        assert not check.applicable
        assert check.status == "Not Applicable"

    def test_small_rounding_difference_is_tolerated(self):
        dataset = make_dataset(
            {
                "Total Assets": (10_000_000.0, None),
                "Total Equity & Liabilities": (10_000_500.0, None),
            }
        )
        check = validate_balance_sheet(dataset)
        assert check.passed


class TestProfitAndLossValidation:
    def test_correctly_cast_accounts_pass(self, sunrise_dataset):
        check = validate_profit_and_loss(sunrise_dataset)
        assert check.applicable
        assert check.passed, check.message

    def test_arithmetic_is_reperformed_not_assumed(self):
        # Figures are at realistic statement magnitudes because the validation
        # tolerates rounding of up to Rs. 1,000 by design.
        # 1,00,00,000 revenue - (10,00,000 + 50,00,000 - 20,00,000 COGS)
        #   - 30,00,000 salary = 30,00,000, but 50,00,000 is reported.
        dataset = make_dataset(
            {
                "Turnover / Revenue": (1_00_00_000.0, None),
                "Opening Stock": (10_00_000.0, None),
                "Purchases": (50_00_000.0, None),
                "Closing Stock": (20_00_000.0, None),
                "Employee Cost": (30_00_000.0, None),
                "Profit Before Tax": (50_00_000.0, None),
            }
        )
        check = validate_profit_and_loss(dataset)
        assert not check.passed
        assert check.reported == pytest.approx(30_00_000.0)
        assert check.difference == pytest.approx(-20_00_000.0)

    def test_rounding_within_tolerance_is_not_reported_as_a_mismatch(self):
        """Statements rounded to the nearest rupee must not raise a false alarm."""
        dataset = make_dataset(
            {
                "Turnover / Revenue": (1_00_00_000.0, None),
                "Employee Cost": (30_00_000.0, None),
                "Profit Before Tax": (70_00_400.0, None),   # 400 rupees out
            }
        )
        check = validate_profit_and_loss(dataset)
        assert check.passed

    def test_all_three_checks_run(self, sunrise_dataset):
        checks = run_validations(sunrise_dataset)
        assert len(checks) == 3
        assert {c.name for c in checks} == {
            "Balance Sheet Equation",
            "Asset Schedule Casting",
            "Profit & Loss Arithmetic",
        }


class TestYearOnYear:
    def test_computes_change_for_every_two_year_head(self, sunrise_dataset):
        results = year_on_year_analysis(sunrise_dataset)
        assert results
        for result in results:
            assert result.current_year is not None
            assert result.previous_year is not None

    def test_change_arithmetic(self, sunrise_dataset):
        results = {r.label: r for r in year_on_year_analysis(sunrise_dataset)}
        receivables = results["Trade Receivables"]
        assert receivables.change_amount == pytest.approx(7_45_00_000)
        assert receivables.change_percent == pytest.approx(79.26, abs=0.05)
        assert receivables.materiality == "High Movement"

    def test_results_are_ordered_by_materiality(self, sunrise_dataset):
        results = year_on_year_analysis(sunrise_dataset)
        order = ["High Movement", "Significant", "Review", "Normal"]
        indices = [order.index(r.materiality) for r in results]
        assert indices == sorted(indices)

    def test_explanations_are_plain_language(self, sunrise_dataset):
        for result in year_on_year_analysis(sunrise_dataset):
            assert result.explanation
            assert "increased" in result.explanation or "decreased" in result.explanation


class TestRatios:
    def test_full_ratio_set_is_produced(self, sunrise_dataset):
        ratios = {r.name for r in compute_ratios(sunrise_dataset)}
        for expected in [
            "Gross Profit Ratio",
            "Net Profit Ratio",
            "Expense to Turnover Ratio",
            "Current Ratio",
            "Quick Ratio",
            "Debt Equity Ratio",
            "Inventory Turnover Ratio",
            "Debtor Turnover Ratio",
            "Creditor Turnover Ratio",
            "Employee Cost Ratio",
            "Finance Cost Ratio",
        ]:
            assert expected in ratios, expected
        assert any("Related Party" in name for name in ratios)

    def test_gross_profit_ratio_arithmetic(self):
        # Revenue 1000, COGS = 100 + 500 - 200 = 400, GP = 600 -> 60%
        dataset = make_dataset(
            {
                "Turnover / Revenue": (1000.0, 1000.0),
                "Opening Stock": (100.0, 100.0),
                "Purchases": (500.0, 500.0),
                "Closing Stock": (200.0, 200.0),
            }
        )
        ratio = next(r for r in compute_ratios(dataset) if r.name == "Gross Profit Ratio")
        assert ratio.current == pytest.approx(60.0)

    def test_current_ratio_arithmetic(self):
        dataset = make_dataset(
            {
                "Trade Receivables": (600.0, None),
                "Inventories": (200.0, None),
                "Cash in Hand": (200.0, None),
                "Trade Payables": (500.0, None),
            }
        )
        ratio = next(r for r in compute_ratios(dataset) if r.name == "Current Ratio")
        assert ratio.current == pytest.approx(2.0)

    def test_debt_equity_arithmetic(self):
        dataset = make_dataset(
            {
                "Secured Loans": (300.0, None),
                "Unsecured Loans": (200.0, None),
                "Share Capital": (400.0, None),
                "Reserves & Surplus": (600.0, None),
            }
        )
        ratio = next(r for r in compute_ratios(dataset) if r.name == "Debt Equity Ratio")
        assert ratio.current == pytest.approx(0.5)

    def test_missing_inputs_report_not_computable_not_zero(self):
        """A missing ratio must never be presented as 0.00 in a working paper."""
        dataset = make_dataset({"Turnover / Revenue": (1000.0, 900.0)})
        ratio = next(r for r in compute_ratios(dataset) if r.name == "Current Ratio")
        assert ratio.current is None
        assert ratio.current_display == "Not computable"

    def test_zero_denominator_does_not_raise(self):
        dataset = make_dataset(
            {"Turnover / Revenue": (0.0, 0.0), "Profit Before Tax": (100.0, 100.0)}
        )
        ratios = compute_ratios(dataset)   # must not raise ZeroDivisionError
        net_profit = next(r for r in ratios if r.name == "Net Profit Ratio")
        assert net_profit.current is None

    def test_every_ratio_has_an_explanation(self, sunrise_dataset):
        for ratio in compute_ratios(sunrise_dataset):
            assert ratio.explanation
            assert ratio.basis
