"""Database round-trips, case lifecycle and settings."""

from __future__ import annotations

import pytest

from tax_audit_analyser.database.db import Database, DatabaseError
from tax_audit_analyser.database.models import (
    AnalysisResult,
    AuditQuery,
    Case,
    Document,
    ExtractedFigure,
    ReportRecord,
    RiskFlag,
)


class TestSchemaAndMigration:
    def test_first_run_creates_every_table(self, database):
        with database.connect() as conn:
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        tables = {row["name"] for row in rows}
        for expected in [
            "Cases",
            "Documents",
            "ExtractedFinancialData",
            "AnalysisResults",
            "RiskFlags",
            "AuditQueries",
            "Reports",
            "ApplicationSettings",
        ]:
            assert expected in tables, expected

    def test_initialising_twice_is_harmless(self, data_dir):
        path = data_dir / "twice.db"
        first = Database(path)
        first.create_case(Case(assessee_name="Test"))
        second = Database(path)          # simulates a second application start
        assert len(second.list_cases()) == 1

    def test_default_settings_are_seeded(self, database):
        assert database.get_setting("report_font") == "Book Antiqua"
        assert database.get_setting("threshold_review") == "10"


class TestCaseLifecycle:
    def test_case_ids_are_sequential_and_padded(self, database):
        first = database.create_case(Case(assessee_name="A", ))
        second = database.create_case(Case(assessee_name="B"))
        assert first.startswith("TAXAUDIT-")
        assert first.endswith("-0001")
        assert second.endswith("-0002")

    def test_create_and_read_back(self, database, sample_case):
        case_id = database.create_case(sample_case)
        loaded = database.get_case(case_id)
        assert loaded is not None
        assert loaded.assessee_name == sample_case.assessee_name
        assert loaded.pan == sample_case.pan
        assert loaded.constitution == "Private Limited Company"
        assert loaded.turnover == pytest.approx(84_50_00_000)
        assert loaded.status == "Draft"

    def test_assessee_name_is_required(self, database):
        with pytest.raises(DatabaseError):
            database.create_case(Case(assessee_name="   "))

    def test_update_case(self, database, sample_case):
        case_id = database.create_case(sample_case)
        case = database.get_case(case_id)
        case.assessee_name = "Renamed Traders"
        case.nature_of_business = "Manufacturing"
        database.update_case(case)
        assert database.get_case(case_id).assessee_name == "Renamed Traders"

    def test_status_transitions(self, database, sample_case):
        case_id = database.create_case(sample_case)
        for status in [
            "Documents Uploaded",
            "Extraction Completed",
            "Verified",
            "Analysis Completed",
            "Report Generated",
        ]:
            database.update_case_status(case_id, status)
            assert database.get_case(case_id).status == status

    def test_duplicate_case(self, database, sample_case):
        original = database.create_case(sample_case)
        copy_id = database.duplicate_case(original)
        assert copy_id != original
        copy = database.get_case(copy_id)
        assert "(Copy)" in copy.assessee_name
        assert copy.status == "Draft"
        assert copy.pan == sample_case.pan

    def test_delete_cascades_to_children(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.add_document(
            Document(case_id=case_id, file_name="a.pdf", stored_path="/tmp/a.pdf")
        )
        database.save_risk_flags(
            case_id, [RiskFlag(risk_level="HIGH", area="Cash", observation="x")]
        )
        database.delete_case(case_id)
        assert database.get_case(case_id) is None
        assert database.list_documents(case_id) == []
        assert database.list_risk_flags(case_id) == []

    def test_reopening_a_saved_case(self, database, sample_case):
        """The core 'close the app and come back tomorrow' guarantee."""
        case_id = database.create_case(sample_case)
        database.save_extracted_figures(
            case_id,
            [
                ExtractedFigure(
                    canonical_head="Turnover / Revenue",
                    current_year_amount=84_50_00_000,
                    previous_year_amount=78_20_00_000,
                    source_document="pl.pdf",
                    source_page=1,
                    confidence="High",
                )
            ],
        )
        database.update_case_status(case_id, "Extraction Completed")

        # A completely fresh connection, as if the application had restarted.
        reopened = Database(database.db_path)
        case = reopened.get_case(case_id)
        figures = reopened.list_extracted_figures(case_id)
        assert case.status == "Extraction Completed"
        assert len(figures) == 1
        assert figures[0].current_year_amount == pytest.approx(84_50_00_000)


class TestDocuments:
    def test_add_and_list(self, database, sample_case):
        case_id = database.create_case(sample_case)
        document_id = database.add_document(
            Document(
                case_id=case_id,
                file_name="pl.pdf",
                stored_path="/tmp/pl.pdf",
                document_type="Profit & Loss Account",
                pages=3,
            )
        )
        documents = database.list_documents(case_id)
        assert len(documents) == 1
        assert documents[0].id == document_id
        assert documents[0].pages == 3

    def test_status_update_records_ocr_and_errors(self, database, sample_case):
        case_id = database.create_case(sample_case)
        document_id = database.add_document(
            Document(case_id=case_id, file_name="scan.pdf", stored_path="/tmp/s.pdf")
        )
        database.update_document_status(
            document_id, "Extracted", pages=5, ocr_used=True
        )
        document = database.list_documents(case_id)[0]
        assert document.status == "Extracted"
        assert document.pages == 5
        assert document.ocr_used is True

        database.update_document_status(document_id, "Error", error_message="boom")
        assert database.list_documents(case_id)[0].error_message == "boom"


class TestExtractedFigures:
    def test_round_trip_preserves_provenance_and_confidence(self, database, sample_case):
        case_id = database.create_case(sample_case)
        original = ExtractedFigure(
            canonical_head="Trade Receivables",
            raw_heading="Sundry Debtors",
            current_year_amount=16_85_00_000,
            previous_year_amount=9_40_00_000,
            source_document="bs.pdf",
            source_page=2,
            confidence="Low",
            match_score=0.71,
            statement_type="BS_ASSET",
        )
        database.save_extracted_figures(case_id, [original])
        loaded = database.list_extracted_figures(case_id)[0]
        assert loaded.raw_heading == "Sundry Debtors"
        assert loaded.source_page == 2
        assert loaded.confidence == "Low"
        assert loaded.match_score == pytest.approx(0.71)

    def test_ca_correction_persists(self, database, sample_case):
        """A corrected figure must survive, and be marked verified."""
        case_id = database.create_case(sample_case)
        database.save_extracted_figures(
            case_id,
            [ExtractedFigure(canonical_head="Cash in Hand", current_year_amount=100.0)],
        )
        figure = database.list_extracted_figures(case_id)[0]
        figure.current_year_amount = 999.0
        figure.is_verified = True
        figure.confidence = "High"
        database.update_extracted_figure(figure)

        reloaded = database.list_extracted_figures(case_id)[0]
        assert reloaded.current_year_amount == pytest.approx(999.0)
        assert reloaded.is_verified is True
        assert reloaded.confidence == "High"

    def test_saving_replaces_the_previous_set(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_extracted_figures(
            case_id, [ExtractedFigure(canonical_head="A", current_year_amount=1.0)]
        )
        database.save_extracted_figures(
            case_id, [ExtractedFigure(canonical_head="B", current_year_amount=2.0)]
        )
        heads = {f.canonical_head for f in database.list_extracted_figures(case_id)}
        assert heads == {"B"}


class TestRiskFlagsAndQueries:
    def test_documents_to_verify_survives_as_a_list(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_risk_flags(
            case_id,
            [
                RiskFlag(
                    risk_level="HIGH",
                    area="Loans and Deposits",
                    observation="Unsecured loans increased sharply.",
                    amount=7_85_00_000,
                    documents_to_verify=["Loan confirmations", "Bank statements"],
                    finding_type="POTENTIAL TAX ISSUE",
                )
            ],
        )
        flag = database.list_risk_flags(case_id)[0]
        assert flag.documents_to_verify == ["Loan confirmations", "Bank statements"]
        assert flag.finding_type == "POTENTIAL TAX ISSUE"
        assert flag.amount == pytest.approx(7_85_00_000)

    def test_filtering_and_counts(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_risk_flags(
            case_id,
            [
                RiskFlag(risk_level="HIGH", area="A", observation="x"),
                RiskFlag(risk_level="HIGH", area="B", observation="y"),
                RiskFlag(risk_level="MEDIUM", area="C", observation="z"),
                RiskFlag(risk_level="INFORMATIONAL", area="D", observation="w"),
            ],
        )
        assert len(database.list_risk_flags(case_id, "HIGH")) == 2
        assert len(database.list_risk_flags(case_id, "ALL")) == 4
        counts = database.risk_counts(case_id)
        assert counts["HIGH"] == 2
        assert counts["MEDIUM"] == 1
        assert counts["REVIEW REQUIRED"] == 0

    def test_flags_come_back_severity_sorted(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_risk_flags(
            case_id,
            [
                RiskFlag(risk_level="INFORMATIONAL", area="D", observation="w"),
                RiskFlag(risk_level="HIGH", area="A", observation="x"),
                RiskFlag(risk_level="REVIEW REQUIRED", area="C", observation="z"),
                RiskFlag(risk_level="MEDIUM", area="B", observation="y"),
            ],
        )
        levels = [f.risk_level for f in database.list_risk_flags(case_id)]
        assert levels == ["HIGH", "MEDIUM", "REVIEW REQUIRED", "INFORMATIONAL"]

    def test_audit_queries_round_trip(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_audit_queries(
            case_id,
            [
                AuditQuery(
                    query_number=1,
                    area="Cash",
                    query_text="Please provide the cash book.",
                    documents_sought="Cash book",
                )
            ],
        )
        query = database.list_audit_queries(case_id)[0]
        assert query.query_number == 1
        assert "cash book" in query.query_text.lower()


class TestAnalysisResultsAndReports:
    def test_analysis_results_filtered_by_type(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.save_analysis_results(
            case_id,
            [
                AnalysisResult(result_type="YOY", label="Turnover", current_year=100.0),
                AnalysisResult(result_type="RATIO", label="GP Ratio", current_year=25.0),
                AnalysisResult(result_type="RATIO", label="NP Ratio", current_year=10.0),
            ],
        )
        assert len(database.list_analysis_results(case_id)) == 3
        assert len(database.list_analysis_results(case_id, "RATIO")) == 2

    def test_reports_are_recorded(self, database, sample_case):
        case_id = database.create_case(sample_case)
        database.add_report(
            ReportRecord(
                case_id=case_id, file_path="/tmp/report.docx", file_size=54321
            )
        )
        reports = database.list_reports(case_id)
        assert len(reports) == 1
        assert reports[0].file_size == 54321


class TestSettings:
    def test_set_and_get(self, database):
        database.set_setting("firm_name", "Sharma & Associates")
        assert database.get_setting("firm_name") == "Sharma & Associates"

    def test_upsert_overwrites(self, database):
        database.set_setting("firm_name", "First")
        database.set_setting("firm_name", "Second")
        assert database.get_setting("firm_name") == "Second"

    def test_default_is_returned_for_unknown_key(self, database):
        assert database.get_setting("nope", "fallback") == "fallback"
