"""Shared pytest fixtures.

Every test runs against a temporary data directory, so the suite never touches
a real user's database, uploads or reports.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# Make the project importable when pytest is invoked from the repository root.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Qt must be told to run headless before any Qt import happens.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(scope="session")
def sample_pdfs(tmp_path_factory) -> dict:
    """Generate the sample financial statements once for the whole session."""
    from tax_audit_analyser.tests.sample_generator import generate_sample_pdfs

    output = tmp_path_factory.mktemp("sample_data")
    return generate_sample_pdfs(output)


@pytest.fixture()
def data_dir(tmp_path, monkeypatch) -> Path:
    """Redirect all application state into a per-test temporary directory."""
    monkeypatch.setenv("TAXAUDIT_DATA_DIR", str(tmp_path))
    from tax_audit_analyser.database import db as db_module

    db_module.reset_database_instance()
    yield tmp_path
    db_module.reset_database_instance()


@pytest.fixture()
def database(data_dir):
    """A fresh Database bound to the temporary data directory."""
    from tax_audit_analyser.database.db import Database

    return Database(data_dir / "test.db")


@pytest.fixture()
def sample_case():
    """An unsaved Case object with realistic particulars."""
    from tax_audit_analyser.database.models import Case

    return Case(
        assessee_name="Sunrise Traders Private Limited",
        pan="AACCS1234K",
        assessment_year="2025-26",
        financial_year="2024-25",
        constitution="Private Limited Company",
        nature_of_business="Wholesale trading",
        turnover=84_50_00_000,
        auditor_name="Sample & Associates",
    )


@pytest.fixture()
def sunrise_dataset(sample_pdfs):
    """The consolidated dataset for the Sunrise fixture."""
    from tax_audit_analyser.core.analysis_engine import build_dataset
    from tax_audit_analyser.core.doc_extractor import extract_document

    pairs = [
        ("sunrise_profit_and_loss.pdf", extract_document(sample_pdfs["sunrise_pl"])),
        ("sunrise_balance_sheet.pdf", extract_document(sample_pdfs["sunrise_bs"])),
    ]
    return build_dataset(pairs, case_id="TEST-0001")


@pytest.fixture()
def meridian_dataset(sample_pdfs):
    """The Meridian fixture, which carries a deliberate balance sheet mismatch."""
    from tax_audit_analyser.core.analysis_engine import build_dataset
    from tax_audit_analyser.core.doc_extractor import extract_document

    pairs = [
        ("meridian_profit_and_loss.pdf", extract_document(sample_pdfs["meridian_pl"])),
        ("meridian_balance_sheet.pdf", extract_document(sample_pdfs["meridian_bs"])),
    ]
    return build_dataset(pairs, case_id="TEST-0002")


@pytest.fixture(scope="session")
def qapp():
    """A single QApplication for the whole session (Qt allows only one)."""
    from PySide6.QtWidgets import QApplication

    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app
