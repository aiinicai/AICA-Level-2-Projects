"""Headless GUI tests.

Every screen is imported and instantiated under an offscreen QApplication, so
import errors, style-sheet mistakes and constructor bugs are caught by the
suite rather than by the user. Navigation wiring is exercised at unit level.
"""

from __future__ import annotations

import importlib

import pytest

pytest.importorskip("PySide6")

UI_MODULES = [
    "tax_audit_analyser.ui.theme",
    "tax_audit_analyser.ui.dashboard",
    "tax_audit_analyser.ui.new_case",
    "tax_audit_analyser.ui.upload",
    "tax_audit_analyser.ui.verification",
    "tax_audit_analyser.ui.analysis_dashboard",
    "tax_audit_analyser.ui.reports",
    "tax_audit_analyser.ui.settings",
    "tax_audit_analyser.ui.case_management",
    "tax_audit_analyser.ui.main_window",
]


class TestImports:
    @pytest.mark.parametrize("module_name", UI_MODULES)
    def test_every_ui_module_imports(self, module_name):
        assert importlib.import_module(module_name) is not None

    def test_main_module_imports(self):
        assert importlib.import_module("tax_audit_analyser.main") is not None

    def test_stylesheet_is_valid_text(self, qapp):
        from tax_audit_analyser.ui.theme import app_stylesheet

        sheet = app_stylesheet()
        assert "QPushButton" in sheet
        qapp.setStyleSheet(sheet)     # Qt would warn loudly on malformed CSS


class TestScreenConstruction:
    """Each screen must construct without a case loaded."""

    def test_dashboard(self, qapp):
        from tax_audit_analyser.ui.dashboard import DashboardScreen

        screen = DashboardScreen()
        assert screen.findChildren(type(screen.button_exit_requested))

    def test_new_case(self, qapp, database):
        from tax_audit_analyser.ui.new_case import NewCaseScreen

        screen = NewCaseScreen(database)
        assert screen.constitution.count() >= 12

    def test_upload(self, qapp, database):
        from tax_audit_analyser.ui.upload import UploadScreen

        screen = UploadScreen(database)
        assert screen.table.columnCount() == 5
        assert not screen.analyse_button.isEnabled()

    def test_verification(self, qapp, database):
        from tax_audit_analyser.ui.verification import VerificationScreen

        screen = VerificationScreen(database)
        assert screen.table.columnCount() == 6

    def test_analysis_dashboard(self, qapp, database):
        from tax_audit_analyser.ui.analysis_dashboard import AnalysisDashboardScreen

        screen = AnalysisDashboardScreen(database)
        assert set(screen.tiles) == {
            "HIGH",
            "MEDIUM",
            "REVIEW REQUIRED",
            "INFORMATIONAL",
        }

    def test_reports(self, qapp, database):
        from tax_audit_analyser.ui.reports import ReportsScreen

        screen = ReportsScreen(database)
        screen.reload()
        assert screen.table.columnCount() == 6

    def test_settings(self, qapp, database):
        from tax_audit_analyser.ui.settings import SettingsScreen

        screen = SettingsScreen(database)
        assert screen.ai_provider_combo.count() == 4

    def test_case_management(self, qapp, database):
        from tax_audit_analyser.ui.case_management import CaseManagementScreen

        screen = CaseManagementScreen(database)
        screen.reload()
        assert screen.table.columnCount() == 6

    def test_main_window_holds_every_screen(self, qapp, database):
        from tax_audit_analyser.ui.main_window import MainWindow

        window = MainWindow(database)
        assert window.stack.count() == 8
        assert window.windowTitle()


class TestNavigationWiring:
    @pytest.fixture()
    def window(self, qapp, database):
        from tax_audit_analyser.ui.main_window import MainWindow

        return MainWindow(database)

    def test_home_cards_navigate(self, window):
        from tax_audit_analyser.ui.main_window import (
            SCREEN_CASES,
            SCREEN_NEW_CASE,
            SCREEN_REPORTS,
            SCREEN_SETTINGS,
        )

        window.dashboard.button_new_analysis_requested.click()
        assert window.stack.currentIndex() == SCREEN_NEW_CASE

        window.dashboard.button_existing_cases_requested.click()
        assert window.stack.currentIndex() == SCREEN_CASES

        window.dashboard.button_reports_requested.click()
        assert window.stack.currentIndex() == SCREEN_REPORTS

        window.dashboard.button_settings_requested.click()
        assert window.stack.currentIndex() == SCREEN_SETTINGS

    def test_back_buttons_return_home(self, window):
        from tax_audit_analyser.ui.main_window import SCREEN_DASHBOARD

        for screen in (window.new_case, window.upload, window.reports, window.settings):
            window.stack.setCurrentWidget(screen)
            screen.back_button.click()
            assert window.stack.currentIndex() == SCREEN_DASHBOARD

    def test_saving_a_case_moves_to_upload(self, window, database):
        from tax_audit_analyser.ui.main_window import SCREEN_UPLOAD

        case_id = database.create_case(
            __import__(
                "tax_audit_analyser.database.models", fromlist=["Case"]
            ).Case(assessee_name="Wired Traders")
        )
        window.on_case_saved(case_id)
        assert window.stack.currentIndex() == SCREEN_UPLOAD
        assert window.current_case.case_id == case_id


class TestNewCaseForm:
    @pytest.fixture()
    def screen(self, qapp, database):
        from tax_audit_analyser.ui.new_case import NewCaseScreen

        return NewCaseScreen(database)

    def test_pan_is_upper_cased_as_typed(self, screen):
        screen.pan.setText("aabct1234z")
        assert screen.pan.text() == "AABCT1234Z"

    def test_assessment_year_is_derived(self, screen):
        screen.financial_year.setText("2024-25")
        screen._derive_assessment_year()
        assert screen.assessment_year.text() == "2025-26"

    def test_assessee_name_is_required(self, screen):
        screen.clear_form()
        assert "Assessee Name" in (screen._validate() or "")

    def test_invalid_pan_is_rejected(self, screen):
        screen.assessee_name.setText("Test")
        screen.pan.setText("BADPAN")
        assert "PAN" in (screen._validate() or "")

    def test_valid_form_passes(self, screen):
        screen.assessee_name.setText("Test Traders LLP")
        screen.pan.setText("AABCT1234Z")
        screen.financial_year.setText("2024-25")
        assert screen._validate() is None

    def test_blank_optional_fields_are_accepted(self, screen):
        screen.clear_form()
        screen.assessee_name.setText("Only A Name")
        assert screen._validate() is None

    def test_collect_builds_a_case(self, screen):
        screen.assessee_name.setText("Collected Traders")
        screen.pan.setText("AABCT1234Z")
        screen.constitution.setCurrentText("LLP")
        case = screen.collect()
        assert case.assessee_name == "Collected Traders"
        assert case.constitution == "LLP"

    def test_load_case_populates_the_form(self, screen, database, sample_case):
        case_id = database.create_case(sample_case)
        assert screen.load_case(case_id)
        assert screen.assessee_name.text() == sample_case.assessee_name
        assert screen.editing_case_id == case_id


class TestUploadScreen:
    @pytest.fixture()
    def screen(self, qapp, database, sample_case):
        from tax_audit_analyser.ui.upload import UploadScreen

        case_id = database.create_case(sample_case)
        screen = UploadScreen(database)
        screen.set_case(database.get_case(case_id))
        return screen

    def test_files_can_be_added(self, screen, sample_pdfs):
        screen.add_files([str(sample_pdfs["sunrise_pl"]), str(sample_pdfs["sunrise_bs"])])
        assert screen.table.rowCount() == 2
        assert screen.analyse_button.isEnabled()

    def test_document_type_is_guessed_from_the_file_name(self, screen, sample_pdfs):
        screen.add_files([str(sample_pdfs["sunrise_pl"]), str(sample_pdfs["sunrise_bs"])])
        types = [screen.table.cellWidget(row, 1).currentText() for row in range(2)]
        assert "Profit & Loss Account" in types
        assert "Balance Sheet" in types

    def test_drop_area_accepts_urls(self, screen):
        from PySide6.QtCore import QMimeData, QUrl
        from PySide6.QtGui import QDragEnterEvent

        mime = QMimeData()
        mime.setUrls([QUrl.fromLocalFile("/tmp/example.pdf")])
        assert mime.hasUrls()   # the condition dragEnterEvent tests

    def test_page_counts_are_shown(self, screen, sample_pdfs):
        screen.add_files([str(sample_pdfs["sunrise_pl"])])
        assert screen.table.item(0, 2).text() not in ("", "0")


class TestVerificationScreen:
    @pytest.fixture()
    def screen(self, qapp, database, sample_case, sample_pdfs):
        from tax_audit_analyser.core.pipeline import run_full_pipeline
        from tax_audit_analyser.ui.verification import VerificationScreen

        run_full_pipeline(
            sample_case,
            [(str(sample_pdfs["sunrise_pl"]), "Profit & Loss Account")],
            db=database,
            generate_word_report=False,
        )
        screen = VerificationScreen(database)
        screen.set_case(database.get_case(sample_case.case_id))
        return screen

    def test_figures_are_listed(self, screen):
        assert screen.table.rowCount() > 10

    def test_amounts_are_shown_in_indian_grouping(self, screen):
        from tax_audit_analyser.ui.verification import format_amount

        assert format_amount(84_50_00_000) == "84,50,00,000.00"
        assert format_amount(-5000) == "(5,000.00)"
        assert format_amount(None) == ""

    @pytest.mark.parametrize(
        "text,expected",
        [
            ("1,00,000", 100000.0),
            ("(5,000)", -5000.0),
            ("2500.50", 2500.5),
            ("", None),
            ("Rs. 1,000", 1000.0),
        ],
    )
    def test_user_typed_amounts_are_parsed(self, text, expected):
        from tax_audit_analyser.ui.verification import parse_user_amount

        assert parse_user_amount(text) == expected

    def test_invalid_amount_raises_for_the_ui_to_catch(self):
        from tax_audit_analyser.ui.verification import parse_user_amount

        with pytest.raises(ValueError):
            parse_user_amount("not a number")

    def test_editing_a_cell_marks_the_figure_verified(self, screen):
        item = screen.table.item(0, screen.COL_CY)
        figure = screen._row_figures[0]
        assert not figure.is_verified
        item.setText("1,23,456.00")
        assert figure.is_verified
        assert figure.current_year_amount == pytest.approx(123456.0)
        assert figure.confidence == "High"

    def test_saving_persists_edits(self, screen, database):
        figure = screen._row_figures[0]
        screen.table.item(0, screen.COL_CY).setText("9,99,999.00")
        assert screen.save()
        reloaded = database.list_extracted_figures(screen.case.case_id)
        match = next(f for f in reloaded if f.canonical_head == figure.canonical_head)
        assert match.current_year_amount == pytest.approx(999999.0)
        assert database.get_case(screen.case.case_id).status == "Verified"

    def test_low_confidence_rows_are_highlighted(self, qapp, database, sample_case):
        """Low-confidence figures must be visually distinct from the rest."""
        from tax_audit_analyser.database.models import ExtractedFigure
        from tax_audit_analyser.ui.theme import CONFIDENCE_BACKGROUNDS
        from tax_audit_analyser.ui.verification import VerificationScreen

        case_id = database.create_case(sample_case)
        database.save_extracted_figures(
            case_id,
            [
                ExtractedFigure(canonical_head="Cash in Hand", current_year_amount=1.0,
                                confidence="Low"),
                ExtractedFigure(canonical_head="Turnover / Revenue",
                                current_year_amount=2.0, confidence="High"),
            ],
        )
        screen = VerificationScreen(database)
        screen.set_case(database.get_case(case_id))

        colours = {
            screen.table.item(row, 0).text(): screen.table.item(row, 0)
            .background()
            .color()
            .name()
            .upper()
            for row in range(screen.table.rowCount())
        }
        assert colours["Cash in Hand"] == CONFIDENCE_BACKGROUNDS["Low"].upper()
        assert colours["Cash in Hand"] != colours["Turnover / Revenue"]


class TestAnalysisDashboardScreen:
    @pytest.fixture()
    def screen(self, qapp, database, sample_case, sample_pdfs):
        from tax_audit_analyser.core.pipeline import run_full_pipeline
        from tax_audit_analyser.ui.analysis_dashboard import AnalysisDashboardScreen

        outcome, _ = run_full_pipeline(
            sample_case,
            [
                (str(sample_pdfs["sunrise_pl"]), "Profit & Loss Account"),
                (str(sample_pdfs["sunrise_bs"]), "Balance Sheet"),
            ],
            db=database,
            generate_word_report=False,
        )
        screen = AnalysisDashboardScreen(database)
        screen.set_outcome(outcome)
        return screen

    def test_tiles_show_the_counts(self, screen):
        total = sum(int(tile.count_label.text()) for tile in screen.tiles.values())
        assert total == len(screen.flags)
        assert int(screen.tiles["HIGH"].count_label.text()) > 0

    def test_table_lists_the_findings(self, screen):
        assert screen.table.rowCount() == len(screen.flags)
        assert screen.table.columnCount() == 6

    def test_filtering_by_level(self, screen):
        screen.filter_combo.setCurrentText("High")
        expected = sum(1 for f in screen.flags if f.risk_level == "HIGH")
        assert screen.table.rowCount() == expected

        screen.filter_combo.setCurrentText("All")
        assert screen.table.rowCount() == len(screen.flags)

    def test_clicking_a_tile_filters(self, screen):
        screen.tiles["HIGH"].clicked.emit("HIGH")
        assert screen.filter_combo.currentText() == "High"

    def test_detail_view_shows_every_required_field(self, screen):
        screen.detail_list.selectRow(0)
        html = screen.detail_view.toHtml()
        for label in (
            "Issue",
            "Why Flagged",
            "Tax Audit Relevance",
            "Recommended Verification",
            "Documents to Verify",
        ):
            assert label in html, label

    def test_ratios_are_displayed(self, screen):
        assert screen.ratio_table.rowCount() >= 10
        assert screen.validation_table.rowCount() == 3

    def test_loading_a_stored_case_repopulates(self, screen, database):
        case = database.get_case(screen.case.case_id)
        screen.load_case(case)
        assert screen.table.rowCount() == len(database.list_risk_flags(case.case_id))


class TestCaseManagementScreen:
    @pytest.fixture()
    def screen(self, qapp, database, sample_case):
        from tax_audit_analyser.ui.case_management import CaseManagementScreen

        database.create_case(sample_case)
        from tax_audit_analyser.database.models import Case

        database.create_case(Case(assessee_name="Second Assessee", pan="AAAPB5678C"))
        screen = CaseManagementScreen(database)
        screen.reload()
        return screen

    def test_cases_are_listed(self, screen):
        assert screen.table.rowCount() == 2

    def test_search_filters_the_list(self, screen):
        screen.search_box.setText("Second")
        assert screen.table.rowCount() == 1
        screen.search_box.setText("")
        assert screen.table.rowCount() == 2

    def test_search_matches_pan(self, screen):
        screen.search_box.setText("AAAPB5678C")
        assert screen.table.rowCount() == 1

    def test_selection_drives_the_buttons(self, screen):
        screen.table.selectRow(0)
        assert screen.selected_case() is not None
        assert screen.open_button.isEnabled()

    def test_open_emits_the_case_id(self, screen):
        received = []
        screen.open_case_requested.connect(received.append)
        screen.table.selectRow(0)
        screen.open_selected()
        assert received and received[0].startswith("TAXAUDIT-")


class TestSettingsScreen:
    @pytest.fixture()
    def screen(self, qapp, database):
        from tax_audit_analyser.ui.settings import SettingsScreen

        return SettingsScreen(database)

    def test_settings_round_trip(self, screen, database):
        screen.firm_name.setText("Sharma & Associates")
        screen.threshold_review.setValue(12.0)
        assert screen.apply_settings() is None
        assert database.get_setting("firm_name") == "Sharma & Associates"
        assert float(database.get_setting("threshold_review")) == 12.0

    def test_thresholds_are_written_to_the_config_file(self, screen, data_dir):
        from tax_audit_analyser.core.tax_risk_engine import (
            RISK_THRESHOLDS_FILENAME,
            load_risk_thresholds,
        )
        from tax_audit_analyser.paths import config_dir

        screen.expense_spike.setValue(33.0)
        assert screen.apply_settings() is None
        assert (config_dir() / RISK_THRESHOLDS_FILENAME).exists()
        assert load_risk_thresholds()["expense_spike_percent"] == 33.0

    def test_the_data_transfer_warning_is_shown(self, screen):
        from tax_audit_analyser.core.ai_provider import DATA_TRANSFER_WARNING
        from PySide6.QtWidgets import QLabel

        texts = [label.text() for label in screen.findChildren(QLabel)]
        assert any(DATA_TRANSFER_WARNING in text for text in texts)

    def test_consent_is_required_before_storing_a_key(self, screen):
        assert not screen.ai_consent.isChecked()


class TestAiProviderStub:
    def test_generation_is_disabled(self):
        from tax_audit_analyser.core.ai_provider import (
            AIProviderDisabled,
            AIRequest,
            get_provider,
            is_ai_enabled,
        )

        assert not is_ai_enabled()
        for name in ("None", "Gemini", "OpenAI", "Claude"):
            provider = get_provider(name, "fake-key")
            with pytest.raises(AIProviderDisabled):
                provider.generate(AIRequest(prompt="summarise"))

    def test_key_storage_round_trip(self, data_dir, monkeypatch):
        """Falls back to the encrypted file when no keyring is available."""
        import tax_audit_analyser.core.ai_provider as ai

        monkeypatch.setitem(__import__("sys").modules, "keyring", None)
        ai.save_api_key("Gemini", "secret-value-1234")
        assert ai.load_api_key("Gemini") == "secret-value-1234"
        ai.delete_api_key("Gemini")

    def test_keys_are_masked_for_display(self):
        from tax_audit_analyser.core.ai_provider import mask_key

        assert mask_key("abcdefghijkl").endswith("ijkl")
        assert "abcdefgh" not in mask_key("abcdefghijkl")
        assert mask_key(None) == "Not set"
