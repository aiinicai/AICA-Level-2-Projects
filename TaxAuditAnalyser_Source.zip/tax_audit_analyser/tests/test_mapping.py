"""Financial term mapping and synonym recognition."""

from __future__ import annotations

import pytest

from tax_audit_analyser.core.financial_mapper import (
    BS_ASSET,
    BS_LIABILITY,
    PL,
    detect_bs_section,
    detect_statement_type,
    map_heading,
    normalise,
    score_to_confidence,
    statement_type_of,
    tokens,
)


class TestNormalisation:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("Revenue from Operations", "revenue from operations"),
            ("REPAIRS & MAINTENANCE", "repairs maintenance"),
            ("Trade  Receivables ", "trade receivables"),
            ("(a) Share Capital", "share capital"),
            ("3. Sundry Debtors", "sundry debtors"),
            ("Salaries / Wages", "salaries wages"),
        ],
    )
    def test_normalise(self, raw, expected):
        assert normalise(raw) == expected

    def test_stopwords_are_dropped_from_tokens(self):
        assert "the" not in tokens("Profit for the year")
        assert "profit" in tokens("Profit for the year")


class TestSynonymMapping:
    @pytest.mark.parametrize(
        "heading,expected",
        [
            ("Sales", "Turnover / Revenue"),
            ("Revenue from Operations", "Turnover / Revenue"),
            ("Gross Receipts", "Turnover / Revenue"),
            ("Turnover", "Turnover / Revenue"),
            ("Sale of Products", "Turnover / Revenue"),
            ("Salaries and Wages", "Employee Cost"),
            ("Staff Cost", "Employee Cost"),
            ("Employee Benefit Expense", "Employee Cost"),
            ("Directors Remuneration", "Director / Partner Remuneration"),
            ("Remuneration to Partners", "Director / Partner Remuneration"),
            ("Finance Costs", "Finance Cost"),
            ("Interest and Finance Charges", "Finance Cost"),
            ("Depreciation and Amortisation", "Depreciation"),
            ("Repairs to Machinery", "Repairs & Maintenance"),
            ("Foreign Travelling Expenses", "Travelling & Conveyance"),
            ("Commission and Brokerage", "Commission & Brokerage"),
            ("Corporate Social Responsibility Expenditure", "CSR Expenditure"),
            ("Bad Debts Written Off", "Bad Debts"),
            ("Profit Before Tax", "Profit Before Tax"),
            ("Net Profit for the Year", "Profit After Tax"),
        ],
    )
    def test_profit_and_loss_headings(self, heading, expected):
        result = map_heading(heading, PL)
        assert result is not None, f"{heading} did not map"
        assert result.canonical_head == expected

    @pytest.mark.parametrize(
        "heading,expected",
        [
            ("Sundry Debtors", "Trade Receivables"),
            ("Book Debts", "Trade Receivables"),
            ("Cash in Hand", "Cash in Hand"),
            ("Balance with Banks", "Bank Balances"),
            ("Stock in Trade", "Inventories"),
            ("Fixed Assets", "Property Plant & Equipment"),
            ("Capital Work in Progress", "Capital Work in Progress"),
            ("Input Tax Credit", "GST Receivable"),
            ("Advance Tax", "TDS Receivable"),
            ("Total Assets", "Total Assets"),
        ],
    )
    def test_asset_headings(self, heading, expected):
        result = map_heading(heading, BS_ASSET)
        assert result is not None, f"{heading} did not map"
        assert result.canonical_head == expected

    @pytest.mark.parametrize(
        "heading,expected",
        [
            ("Sundry Creditors", "Trade Payables"),
            ("Trade Payables", "Trade Payables"),
            ("Secured Loans", "Secured Loans"),
            ("Cash Credit", "Secured Loans"),
            ("Unsecured Loans", "Unsecured Loans"),
            ("Loan from Partners", "Unsecured Loans"),
            ("Dues to Micro and Small Enterprises", "MSME Payables"),
            ("Statutory Dues Payable", "Statutory Liabilities"),
            ("Reserves and Surplus", "Reserves & Surplus"),
            ("Partners Capital Account", "Partners Capital"),
        ],
    )
    def test_liability_headings(self, heading, expected):
        result = map_heading(heading, BS_LIABILITY)
        assert result is not None, f"{heading} did not map"
        assert result.canonical_head == expected

    def test_unsecured_is_never_confused_with_secured(self):
        """'secured loans' is a substring of 'unsecured loans' -- a real trap."""
        for heading in (
            "Unsecured Loans",
            "Unsecured Loans from Directors",
            "Unsecured Borrowings",
        ):
            result = map_heading(heading, BS_LIABILITY)
            assert result is not None
            assert result.canonical_head == "Unsecured Loans", heading

    def test_nonsense_is_rejected_rather_than_guessed(self):
        for heading in ("Qwerty Zxcvbn Plugh", "xyzzy", "!!!"):
            assert map_heading(heading) is None, heading

    def test_exact_match_scores_high_confidence(self):
        result = map_heading("Trade Receivables", BS_ASSET)
        assert result.confidence == "High"
        assert result.score == pytest.approx(1.0)

    def test_confidence_grading(self):
        assert score_to_confidence(0.99) == "High"
        assert score_to_confidence(0.80) == "Medium"
        assert score_to_confidence(0.65) == "Low"

    def test_statement_hint_disambiguates_provisions(self):
        """'Provisions' exists on both the P&L and the liability side."""
        pl_result = map_heading("Provision for Doubtful Debts", PL)
        bs_result = map_heading("Short Term Provisions", BS_LIABILITY)
        assert pl_result.canonical_head == "Provisions"
        assert bs_result.canonical_head == "Provisions (Liability)"


class TestStatementDetection:
    def test_detect_statement_type(self):
        assert detect_statement_type("Statement of Profit and Loss") == PL
        assert detect_statement_type("Balance Sheet as at 31 March 2025") == BS_ASSET
        assert detect_statement_type("Random heading") is None

    def test_detect_bs_section(self):
        assert detect_bs_section("EQUITY AND LIABILITIES") == BS_LIABILITY
        assert detect_bs_section("ASSETS") == BS_ASSET
        assert detect_bs_section("Sources of Funds") == BS_LIABILITY

    def test_statement_type_of_canonical_head(self):
        assert statement_type_of("Turnover / Revenue") == PL
        assert statement_type_of("Trade Receivables") == BS_ASSET
        assert statement_type_of("Trade Payables") == BS_LIABILITY
