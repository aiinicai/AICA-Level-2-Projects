"""Word report generation and the end-to-end pipeline."""

from __future__ import annotations

import re

import pytest

from tax_audit_analyser.core.analysis_engine import (
    financial_snapshot,
    run_validations,
    year_on_year_analysis,
)
from tax_audit_analyser.core.query_generator import generate_queries
from tax_audit_analyser.core.ratio_engine import compute_ratios
from tax_audit_analyser.core.report_generator import (
    MANDATORY_DISCLAIMER,
    ReportError,
    generate_queries_document,
    generate_report,
)
from tax_audit_analyser.core.tax_risk_engine import (
    CLAUSE_MAPPING_DISCLAIMER,
    run_risk_analysis,
)


@pytest.fixture()
def report_inputs(sunrise_dataset, sample_case):
    validations = run_validations(sunrise_dataset)
    ratios = compute_ratios(sunrise_dataset)
    flags = run_risk_analysis(
        sunrise_dataset, case=sample_case, validations=validations, ratios=ratios
    )
    return {
        "case": sample_case,
        "dataset": sunrise_dataset,
        "flags": flags,
        "ratios": ratios,
        "yoy": year_on_year_analysis(sunrise_dataset),
        "snapshot": financial_snapshot(sunrise_dataset),
        "validations": validations,
        "queries": generate_queries(flags, sample_case),
    }


@pytest.fixture()
def report_path(report_inputs, data_dir):
    return generate_report(output_path=data_dir / "report.docx", **report_inputs)


def document_text(path) -> str:
    """All text in the document, including tables."""
    import docx

    document = docx.Document(str(path))
    parts = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            parts.extend(cell.text for cell in row.cells)
    return "\n".join(parts)


class TestReportFile:
    def test_a_real_non_empty_docx_is_produced(self, report_path):
        assert report_path.exists()
        assert report_path.suffix == ".docx"
        assert report_path.stat().st_size > 10_000

    def test_it_is_a_valid_openable_docx(self, report_path):
        import docx

        document = docx.Document(str(report_path))
        assert len(document.paragraphs) > 100
        assert len(document.tables) >= 5

    def test_page_is_a4_with_header_and_footer(self, report_path):
        import docx
        from docx.shared import Cm

        document = docx.Document(str(report_path))
        section = document.sections[0]
        assert abs(section.page_width - Cm(21.0)) < Cm(0.2)
        assert abs(section.page_height - Cm(29.7)) < Cm(0.2)
        assert "Tax Audit Financial Statement Analyser" in section.header.paragraphs[0].text
        footer = " ".join(p.text for p in section.footer.paragraphs)
        assert "Confidential" in footer

    def test_body_font_and_size(self, report_path):
        import docx
        from docx.shared import Pt

        document = docx.Document(str(report_path))
        style = document.styles["Normal"]
        assert style.font.name == "Book Antiqua"
        assert style.font.size == Pt(11)


class TestReportContent:
    def test_every_required_section_is_present(self, report_path):
        text = document_text(report_path)
        for section in [
            "Executive Summary",
            "Documents Analysed",
            "Financial Snapshot",
            "Year-on-Year Analysis",
            "Key Ratios",
            "High-Risk Areas",
            "Medium-Risk Areas",
            "Expense Analysis",
            "Loans and Deposits Review",
            "Statutory and Tax Audit Review",
            "Potential Form 3CD Reporting Areas",
            "Documents and Information Required",
            "Auditor Queries",
            "Conclusion",
        ]:
            assert section in text, f"missing section: {section}"

    def test_mandatory_disclaimer_appears_verbatim(self, report_path):
        assert MANDATORY_DISCLAIMER in document_text(report_path)

    def test_form_3cd_disclaimer_appears_verbatim(self, report_path):
        assert CLAUSE_MAPPING_DISCLAIMER in document_text(report_path)

    def test_case_particulars_appear_on_the_cover(self, report_path, sample_case):
        text = document_text(report_path)
        assert sample_case.assessee_name in text
        assert sample_case.pan in text
        assert sample_case.financial_year in text

    def test_figures_are_reported(self, report_path):
        text = document_text(report_path)
        assert "84,50,00,000" in text        # turnover, Indian grouping

    def test_findings_reach_the_report(self, report_path, report_inputs):
        text = document_text(report_path)
        high = [f for f in report_inputs["flags"] if f.risk_level == "HIGH"]
        assert high
        assert high[0].area in text

    def test_no_conclusive_violation_language_in_the_whole_report(self, report_path):
        """The single most important guarantee of the generated document."""
        forbidden = re.compile(
            r"\b(violat\w*|non-compliant|noncompliant|illegal|unlawful|"
            r"has evaded|is guilty|contravene\w*|must be disallowed)\b",
            re.IGNORECASE,
        )
        text = document_text(report_path)
        # The mandatory disclaimer itself contains the phrase "statutory
        # non-compliance", which is permitted because it is a denial.
        text = text.replace(MANDATORY_DISCLAIMER, "")
        match = forbidden.search(text)
        assert match is None, f"forbidden phrase in report: {match.group(0)!r}"

    def test_report_states_it_is_preliminary(self, report_path):
        text = document_text(report_path).lower()
        assert "preliminary" in text
        assert "professional" in text


class TestQueriesDocument:
    def test_queries_document_is_produced(self, report_inputs, data_dir):
        path = generate_queries_document(
            report_inputs["case"],
            report_inputs["queries"],
            output_path=data_dir / "queries.docx",
        )
        assert path.exists()
        assert path.stat().st_size > 5_000
        text = document_text(path)
        assert "AUDITOR QUERIES" in text
        assert MANDATORY_DISCLAIMER in text

    def test_empty_query_list_still_produces_a_document(self, sample_case, data_dir):
        path = generate_queries_document(
            sample_case, [], output_path=data_dir / "none.docx"
        )
        assert path.exists()
        assert "No queries were generated" in document_text(path)


class TestReportErrorHandling:
    def test_unwritable_path_raises_a_readable_error(self, report_inputs, data_dir):
        target = data_dir / "no_such_folder" / "sub" / "x.docx"
        # The builder creates parent folders, so use a path that cannot exist:
        # a file used as though it were a directory.
        blocker = data_dir / "blocker"
        blocker.write_text("not a directory", encoding="utf-8")
        with pytest.raises(ReportError) as exc:
            generate_report(output_path=blocker / "report.docx", **report_inputs)
        assert "could not be generated" in str(exc.value).lower()


class TestFullPipeline:
    def test_end_to_end_produces_a_report(self, database, sample_pdfs, sample_case):
        """create case -> upload -> extract -> analyse -> risk -> report."""
        from tax_audit_analyser.core.pipeline import build_report, run_full_pipeline

        files = [
            (str(sample_pdfs["sunrise_pl"]), "Profit & Loss Account"),
            (str(sample_pdfs["sunrise_bs"]), "Balance Sheet"),
        ]
        outcome, _ = run_full_pipeline(
            sample_case, files, db=database, generate_word_report=False
        )

        assert len(outcome.documents) == 2
        assert len(outcome.dataset.figures) >= 30
        assert outcome.flags
        assert outcome.queries
        assert outcome.risk_counts["HIGH"] > 0

        path = build_report(outcome, db=database)
        assert path.exists()
        assert path.stat().st_size > 10_000
        assert MANDATORY_DISCLAIMER in document_text(path)

        # The case must be left in a state that can be reopened.
        case = database.get_case(sample_case.case_id)
        assert case.status == "Report Generated"
        assert len(database.list_risk_flags(case.case_id)) == len(outcome.flags)
        assert len(database.list_reports(case.case_id)) == 1

    def test_verification_corrections_flow_into_the_analysis(
        self, database, sample_pdfs, sample_case
    ):
        """The whole point of the verification screen."""
        from tax_audit_analyser.core.pipeline import analyse_case, run_full_pipeline

        files = [(str(sample_pdfs["sunrise_pl"]), "Profit & Loss Account")]
        run_full_pipeline(
            sample_case, files, db=database, generate_word_report=False
        )

        figures = database.list_extracted_figures(sample_case.case_id)
        target = next(f for f in figures if f.canonical_head == "Turnover / Revenue")
        target.current_year_amount = 10_00_00_000.0    # a large correction
        target.is_verified = True
        database.update_extracted_figure(target)

        case = database.get_case(sample_case.case_id)
        outcome = analyse_case(case, db=database)
        assert outcome.dataset.cy("Turnover / Revenue") == pytest.approx(10_00_00_000.0)

    def test_unreadable_document_does_not_abort_the_run(
        self, database, sample_pdfs, sample_case, tmp_path
    ):
        from tax_audit_analyser.core.pipeline import run_full_pipeline

        broken = tmp_path / "broken.pdf"
        broken.write_bytes(b"not a pdf at all")
        files = [
            (str(sample_pdfs["sunrise_pl"]), "Profit & Loss Account"),
            (str(broken), "Other Documents"),
        ]
        outcome, _ = run_full_pipeline(
            sample_case, files, db=database, generate_word_report=False
        )
        # The good document still produced figures and findings.
        assert outcome.dataset.figures
        assert outcome.flags
