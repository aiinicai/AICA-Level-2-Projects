"""Generate realistic dummy financial statement PDFs for testing.

Three fictitious assessees are produced, each with a Profit & Loss Account and
a Balance Sheet showing Current Year and Previous Year columns. Risk scenarios
are planted deliberately so the risk engine has genuine findings to catch:

* **Sunrise Traders Private Limited** -- a 74% jump in professional fees, a
  large new unsecured loan, heavy cash in hand, a sharp receivables increase
  and round-number commission payments.
* **Meridian Enterprises (Partnership Firm)** -- a *deliberate balance sheet
  mismatch*, partner remuneration growth, personal-looking expenditure and
  penalties charged to the P&L.
* **Clearview Textiles Limited** -- a comparatively clean set of accounts used
  to confirm the engine does not manufacture findings where none exist.

All figures are invented. Nothing here represents a real taxpayer.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Sequence, Tuple

SAMPLE_DIR = Path(__file__).resolve().parent / "sample_data"

# ----------------------------------------------------------------- datasets
# Each row: (heading, current_year, previous_year)
Row = Tuple[str, float, float]

# Headings treated as revenue rather than expense when casting the P&L.
_INCOME_HEADINGS = {
    "revenue from operations", "sales", "other income",
}
# Headings that form part of cost of goods sold.
_OPENING_HEADINGS = {"opening stock"}
_CLOSING_HEADINGS = {"closing stock"}


def _cast_profit_and_loss(rows: Sequence[Row], tax: Tuple[float, float] | None) -> List[Row]:
    """Append arithmetically correct PBT (and tax/PAT) to a set of P&L rows.

    The sample statements must cast correctly, otherwise the Profit & Loss
    validation check would report a mismatch on every fixture and the test
    would lose its ability to distinguish a genuine problem from a fixture
    defect. Closing stock is credited, opening stock and every other head is
    debited.
    """
    income_cy = income_py = 0.0
    expense_cy = expense_py = 0.0

    for heading, current, previous in rows:
        key = heading.lower()
        if key in _INCOME_HEADINGS or key in _CLOSING_HEADINGS:
            income_cy += current
            income_py += previous
        else:
            expense_cy += current
            expense_py += previous

    pbt_cy = income_cy - expense_cy
    pbt_py = income_py - expense_py
    result = list(rows) + [("Profit Before Tax", pbt_cy, pbt_py)]
    if tax is not None:
        tax_cy, tax_py = tax
        result.append(("Provision for Taxation", tax_cy, tax_py))
        result.append(("Profit After Tax", pbt_cy - tax_cy, pbt_py - tax_py))
    return result


def _sunrise_pl() -> List[Row]:
    rows: List[Row] = [
        ("Revenue from Operations", 84_50_00_000, 78_20_00_000),
        ("Other Income", 1_25_00_000, 42_00_000),
        ("Opening Stock", 6_40_00_000, 5_90_00_000),
        ("Purchases of Stock in Trade", 61_20_00_000, 57_80_00_000),
        ("Closing Stock", 7_10_00_000, 6_40_00_000),
        ("Salaries and Wages", 5_82_00_000, 5_15_00_000),
        ("Directors Remuneration", 1_20_00_000, 96_00_000),
        ("Professional Fees", 1_74_00_000, 1_00_00_000),
        ("Legal Expenses", 38_50_000, 22_10_000),
        ("Commission and Brokerage", 50_00_000, 30_00_000),
        ("Rent", 96_00_000, 90_00_000),
        ("Interest and Finance Charges", 2_38_00_000, 1_44_00_000),
        ("Depreciation and Amortisation", 1_92_00_000, 1_78_00_000),
        ("Repairs and Maintenance", 82_40_000, 31_20_000),
        ("Travelling and Conveyance", 64_30_000, 38_90_000),
        ("Advertisement and Publicity", 45_00_000, 42_50_000),
        ("Electricity Charges", 38_20_000, 35_80_000),
        ("Insurance", 14_60_000, 13_90_000),
        ("Freight Outward", 72_10_000, 68_40_000),
        ("Donations", 12_00_000, 2_50_000),
        ("Corporate Social Responsibility Expenditure", 18_50_000, 16_00_000),
        ("Bad Debts Written Off", 46_80_000, 8_20_000),
        ("Miscellaneous Expenses", 88_70_000, 41_30_000),
    ]
    return _cast_profit_and_loss(rows, tax=(2_10_00_000, 1_95_00_000))


def _sunrise_bs() -> Tuple[List[Row], List[Row]]:
    liabilities: List[Row] = [
        ("Share Capital", 2_00_00_000, 2_00_00_000),
        ("Reserves and Surplus", 18_42_00_000, 12_49_90_000),
        ("Secured Loans", 9_60_00_000, 8_20_00_000),
        ("Unsecured Loans", 7_85_00_000, 1_40_00_000),
        ("Sundry Creditors", 11_20_00_000, 9_60_00_000),
        ("Dues to Micro and Small Enterprises", 1_84_00_000, 62_00_000),
        ("Statutory Dues Payable", 1_16_00_000, 78_00_000),
        ("Other Current Liabilities", 94_00_000, 86_10_000),
        ("Short Term Provisions", 1_38_00_000, 1_12_00_000),
        ("Total Equity and Liabilities", 54_39_00_000, 37_08_00_000),
    ]
    assets: List[Row] = [
        ("Property Plant and Equipment", 16_40_00_000, 14_90_00_000),
        ("Capital Work in Progress", 3_20_00_000, 40_00_000),
        ("Investments", 1_50_00_000, 1_50_00_000),
        ("Long Term Loans and Advances", 2_46_00_000, 1_18_00_000),
        ("Sundry Debtors", 16_85_00_000, 9_40_00_000),
        ("Inventories", 7_10_00_000, 6_40_00_000),
        ("Cash in Hand", 1_42_00_000, 18_00_000),
        ("Balance with Banks", 2_86_00_000, 1_64_00_000),
        ("GST Receivable", 1_48_00_000, 92_00_000),
        ("TDS Receivable", 62_00_000, 48_00_000),
        ("Other Current Assets", 50_00_000, 8_00_000),
        ("Total Assets", 54_39_00_000, 37_08_00_000),
    ]
    return liabilities, assets


def _meridian_pl() -> List[Row]:
    rows: List[Row] = [
        ("Sales", 12_40_00_000, 11_85_00_000),
        ("Other Income", 18_50_000, 16_20_000),
        ("Opening Stock", 1_20_00_000, 1_10_00_000),
        ("Purchases", 8_60_00_000, 8_30_00_000),
        ("Closing Stock", 1_35_00_000, 1_20_00_000),
        ("Salary and Wages", 84_00_000, 76_00_000),
        ("Remuneration to Partners", 72_00_000, 48_00_000),
        ("Interest on Partners Capital", 24_00_000, 18_00_000),
        ("Rent Paid", 36_00_000, 36_00_000),
        ("Travelling Expenses", 28_40_000, 14_80_000),
        ("Vehicle Running Expenses", 18_60_000, 11_20_000),
        ("Telephone and Internet Charges", 6_40_000, 5_80_000),
        ("Legal and Professional Charges", 22_00_000, 12_50_000),
        ("Repairs to Building", 34_00_000, 6_00_000),
        ("Penalty and Late Fees", 4_80_000, 60_000),
        ("Donations", 3_00_000, 1_00_000),
        ("Depreciation", 42_00_000, 39_00_000),
        ("Miscellaneous Expenses", 26_50_000, 12_10_000),
    ]
    # A partnership firm: profit is not taxed in the firm's own P&L here.
    return _cast_profit_and_loss(rows, tax=None)


def _meridian_bs() -> Tuple[List[Row], List[Row]]:
    # NOTE: totals below are deliberately inconsistent with the components on
    # the assets side, to exercise the balance sheet validation check.
    liabilities: List[Row] = [
        ("Partners Capital Account", 4_86_00_000, 4_32_00_000),
        ("Secured Loans", 1_90_00_000, 2_20_00_000),
        ("Unsecured Loans from Relatives", 2_40_00_000, 60_00_000),
        ("Sundry Creditors", 2_18_00_000, 1_96_00_000),
        ("Statutory Dues Payable", 34_00_000, 28_00_000),
        ("Other Current Liabilities", 42_00_000, 38_00_000),
        ("Total Equity and Liabilities", 12_10_00_000, 9_74_00_000),
    ]
    assets: List[Row] = [
        ("Fixed Assets", 4_20_00_000, 4_05_00_000),
        ("Sundry Debtors", 3_64_00_000, 2_58_00_000),
        ("Inventories", 1_35_00_000, 1_20_00_000),
        ("Cash in Hand", 68_00_000, 12_00_000),
        ("Balance with Banks", 46_00_000, 62_00_000),
        ("Loans and Advances", 92_00_000, 74_00_000),
        ("Other Current Assets", 27_00_000, 21_00_000),
        # Sum of the above is 11,52,00,000 -- not the 12,10,00,000 reported.
        ("Total Assets", 12_10_00_000, 9_74_00_000),
    ]
    return liabilities, assets


def _clearview_pl() -> List[Row]:
    rows: List[Row] = [
        ("Revenue from Operations", 46_80_00_000, 44_20_00_000),
        ("Other Income", 62_00_000, 58_00_000),
        ("Opening Stock", 4_20_00_000, 3_95_00_000),
        ("Cost of Materials Consumed", 31_40_00_000, 29_80_00_000),
        ("Closing Stock", 4_48_00_000, 4_20_00_000),
        ("Employee Benefit Expense", 4_62_00_000, 4_38_00_000),
        ("Finance Costs", 1_08_00_000, 1_02_00_000),
        ("Depreciation and Amortisation", 1_86_00_000, 1_79_00_000),
        ("Power and Fuel", 1_24_00_000, 1_18_00_000),
        ("Repairs and Maintenance", 48_00_000, 45_00_000),
        ("Professional Fees", 32_00_000, 30_00_000),
        ("Travelling and Conveyance", 26_00_000, 24_50_000),
        ("Insurance", 18_00_000, 17_20_000),
        ("Miscellaneous Expenses", 34_00_000, 32_00_000),
    ]
    return _cast_profit_and_loss(rows, tax=(1_28_00_000, 1_19_00_000))


def _clearview_bs() -> Tuple[List[Row], List[Row]]:
    liabilities: List[Row] = [
        ("Equity Share Capital", 5_00_00_000, 5_00_00_000),
        ("Reserves and Surplus", 14_28_00_000, 10_64_00_000),
        ("Secured Loans", 6_40_00_000, 6_80_00_000),
        ("Trade Payables", 5_92_00_000, 5_46_00_000),
        ("Statutory Dues Payable", 68_00_000, 62_00_000),
        ("Short Term Provisions", 84_00_000, 78_00_000),
        ("Total Equity and Liabilities", 33_12_00_000, 29_30_00_000),
    ]
    assets: List[Row] = [
        ("Property Plant and Equipment", 18_60_00_000, 17_90_00_000),
        ("Investments", 2_40_00_000, 2_40_00_000),
        ("Trade Receivables", 5_18_00_000, 4_86_00_000),
        ("Inventories", 4_48_00_000, 4_20_00_000),
        ("Cash in Hand", 6_00_000, 5_50_000),
        ("Balance with Banks", 1_84_00_000, 1_46_00_000),
        ("Other Current Assets", 56_00_000, 42_50_000),
        ("Total Assets", 33_12_00_000, 29_30_00_000),
    ]
    return liabilities, assets


# ------------------------------------------------------------- PDF rendering


def _format_amount(value: float) -> str:
    """Format using the Indian lakh/crore digit grouping."""
    negative = value < 0
    whole = f"{abs(value):.2f}"
    integer, decimal = whole.split(".")
    if len(integer) > 3:
        head, tail = integer[:-3], integer[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        integer = ",".join(parts + [tail])
    formatted = f"{integer}.{decimal}"
    return f"({formatted})" if negative else formatted


def _build_pdf(
    output_path: Path,
    entity_name: str,
    constitution_line: str,
    statement_title: str,
    period_line: str,
    sections: Sequence[Tuple[str, Sequence[Row]]],
    cy_label: str,
    py_label: str,
) -> Path:
    """Render one statement as a ruled-table PDF using reportlab."""
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "EntityTitle", parent=styles["Title"], fontSize=14, alignment=TA_CENTER,
        spaceAfter=2,
    )
    sub_style = ParagraphStyle(
        "Sub", parent=styles["Normal"], fontSize=9.5, alignment=TA_CENTER,
    )
    section_style = ParagraphStyle(
        "Section", parent=styles["Normal"], fontSize=10, spaceBefore=6,
        spaceAfter=2, fontName="Helvetica-Bold",
    )

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title=f"{entity_name} - {statement_title}",
    )

    story: List[object] = [
        Paragraph(entity_name, title_style),
        Paragraph(constitution_line, sub_style),
        Paragraph(statement_title, sub_style),
        Paragraph(period_line, sub_style),
        Paragraph("(All amounts in Indian Rupees)", sub_style),
        Spacer(1, 6 * mm),
    ]

    for section_name, rows in sections:
        if section_name:
            story.append(Paragraph(section_name, section_style))
        data: List[List[str]] = [["Particulars", cy_label, py_label]]
        for heading, current, previous in rows:
            data.append([heading, _format_amount(current), _format_amount(previous)])
        table = Table(
            data,
            colWidths=[95 * mm, 39 * mm, 39 * mm],
            repeatRows=1,
        )
        style_commands = [
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
            ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.90, 0.90, 0.90)),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
        ]
        # Bold any total row.
        for index, row in enumerate(data[1:], start=1):
            if row[0].lower().startswith("total"):
                style_commands.append(
                    ("FONTNAME", (0, index), (-1, index), "Helvetica-Bold")
                )
        table.setStyle(TableStyle(style_commands))
        story.append(table)
        story.append(Spacer(1, 4 * mm))

    doc.build(story)
    return output_path


# ------------------------------------------------------------------ builders

SAMPLE_CASES: Dict[str, Dict[str, str]] = {
    "sunrise": {
        "name": "Sunrise Traders Private Limited",
        "constitution": "Private Limited Company",
        "pan": "AACCS1234K",
        "fy": "2024-25",
        "ay": "2025-26",
    },
    "meridian": {
        "name": "Meridian Enterprises",
        "constitution": "Partnership Firm",
        "pan": "AAFFM5678L",
        "fy": "2024-25",
        "ay": "2025-26",
    },
    "clearview": {
        "name": "Clearview Textiles Limited",
        "constitution": "Public Limited Company",
        "pan": "AABCC9012M",
        "fy": "2024-25",
        "ay": "2025-26",
    },
}

_BUILDERS = {
    "sunrise": (_sunrise_pl, _sunrise_bs),
    "meridian": (_meridian_pl, _meridian_bs),
    "clearview": (_clearview_pl, _clearview_bs),
}


def generate_sample_pdfs(output_dir: Path | str | None = None) -> Dict[str, Path]:
    """Generate all sample PDFs, returning ``{key: path}``.

    Existing files are overwritten so the fixtures always match this module.
    """
    out = Path(output_dir) if output_dir else SAMPLE_DIR
    out.mkdir(parents=True, exist_ok=True)
    generated: Dict[str, Path] = {}

    for key, meta in SAMPLE_CASES.items():
        pl_builder, bs_builder = _BUILDERS[key]
        cy_label = "Year ended 31.03.2025"
        py_label = "Year ended 31.03.2024"

        pl_path = out / f"{key}_profit_and_loss.pdf"
        _build_pdf(
            pl_path,
            meta["name"],
            f"({meta['constitution']})   PAN: {meta['pan']}",
            "Statement of Profit and Loss",
            f"For the year ended 31st March 2025 (FY {meta['fy']})",
            [("", pl_builder())],
            cy_label,
            py_label,
        )
        generated[f"{key}_pl"] = pl_path

        liabilities, assets = bs_builder()
        bs_path = out / f"{key}_balance_sheet.pdf"
        _build_pdf(
            bs_path,
            meta["name"],
            f"({meta['constitution']})   PAN: {meta['pan']}",
            "Balance Sheet",
            f"As at 31st March 2025 (FY {meta['fy']})",
            [
                ("EQUITY AND LIABILITIES", liabilities),
                ("ASSETS", assets),
            ],
            "As at 31.03.2025",
            "As at 31.03.2024",
        )
        generated[f"{key}_bs"] = bs_path

    return generated


def expected_values(key: str) -> Dict[str, Tuple[float, float]]:
    """Ground-truth CY/PY figures keyed by raw heading, for assertions."""
    pl_builder, bs_builder = _BUILDERS[key]
    values: Dict[str, Tuple[float, float]] = {}
    for heading, current, previous in pl_builder():
        values[heading] = (current, previous)
    liabilities, assets = bs_builder()
    for heading, current, previous in list(liabilities) + list(assets):
        values[heading] = (current, previous)
    return values


if __name__ == "__main__":  # pragma: no cover - manual invocation helper
    files = generate_sample_pdfs()
    for name, path in sorted(files.items()):
        print(f"{name:16s} {path}  ({path.stat().st_size:,} bytes)")
