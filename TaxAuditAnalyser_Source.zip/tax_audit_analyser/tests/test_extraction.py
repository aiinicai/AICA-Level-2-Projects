"""PDF, Excel, Word, CSV and image extraction."""

from __future__ import annotations

import pytest

from tax_audit_analyser.core import ocr_engine
from tax_audit_analyser.core.doc_extractor import (
    count_pages,
    extract_document,
    file_kind,
    is_supported,
)
from tax_audit_analyser.core.pdf_extractor import (
    extract_amounts_from_text,
    extract_pdf,
    parse_amount,
    split_heading_and_amounts,
)


class TestAmountParsing:
    @pytest.mark.parametrize(
        "text,expected",
        [
            ("1000", 1000.0),
            ("1,000.50", 1000.5),
            ("1,23,45,678.90", 12345678.90),      # Indian grouping
            ("(5,000.00)", -5000.0),              # brackets mean negative
            ("-2500", -2500.0),
            ("5000-", -5000.0),                   # trailing minus
            ("Rs. 1,00,000.00", 100000.0),
            ("₹ 2,500", 2500.0),
            ("", None),
            ("Particulars", None),
            ("N/A", None),
        ],
    )
    def test_parse_amount(self, text, expected):
        assert parse_amount(text) == expected

    def test_extracts_two_columns_from_a_statement_line(self):
        amounts = extract_amounts_from_text(
            "Revenue from Operations   84,50,00,000.00   78,20,00,000.00"
        )
        assert amounts[:2] == [845000000.0, 782000000.0]

    def test_separates_heading_from_amounts(self):
        heading, amounts = split_heading_and_amounts(
            "Salaries and Wages .......  5,82,00,000.00  5,15,00,000.00"
        )
        assert "Salaries and Wages" in heading
        assert amounts[:2] == [58200000.0, 51500000.0]

    def test_short_bare_integer_is_treated_as_a_note_reference(self):
        # "3" is a note number, not an amount; the real figures follow it.
        heading, amounts = split_heading_and_amounts(
            "Trade Receivables  3  16,85,00,000.00  9,40,00,000.00"
        )
        assert amounts[:2] == [168500000.0, 94000000.0]


class TestPdfExtraction:
    def test_extracts_pages_and_lines(self, sample_pdfs):
        result = extract_pdf(sample_pdfs["sunrise_pl"])
        assert result.success, result.error
        assert result.page_count >= 1
        assert len(result.lines) >= 20

    def test_recovers_known_figures(self, sample_pdfs):
        result = extract_pdf(sample_pdfs["sunrise_pl"])
        by_heading = {line.heading.strip(): line for line in result.lines}
        revenue = by_heading.get("Revenue from Operations")
        assert revenue is not None
        assert revenue.current_year == pytest.approx(84_50_00_000)
        assert revenue.previous_year == pytest.approx(78_20_00_000)

    def test_detects_balance_sheet_sections(self, sample_pdfs):
        result = extract_pdf(sample_pdfs["sunrise_bs"])
        hints = {line.heading.strip(): line.statement_hint for line in result.lines}
        assert hints.get("Share Capital") == "BS_LIABILITY"
        assert hints.get("Cash in Hand") == "BS_ASSET"

    def test_missing_file_reports_an_error_rather_than_raising(self, tmp_path):
        result = extract_pdf(tmp_path / "nope.pdf")
        assert not result.success
        assert "not found" in result.error.lower()

    def test_corrupt_pdf_is_handled_gracefully(self, tmp_path):
        broken = tmp_path / "broken.pdf"
        broken.write_bytes(b"%PDF-1.4\nthis is not a real pdf\n")
        result = extract_pdf(broken)
        # Either an error message or simply no usable lines -- never a crash.
        assert result.error or not result.lines

    def test_page_count(self, sample_pdfs):
        assert count_pages(sample_pdfs["sunrise_pl"]) >= 1


class TestOtherFormats:
    def test_excel(self, tmp_path):
        import pandas as pd

        path = tmp_path / "tb.xlsx"
        pd.DataFrame(
            [
                ["Particulars", "Current Year", "Previous Year"],
                ["Sales", 12500000, 11000000],
                ["Sundry Debtors", 3400000, 2100000],
            ]
        ).to_excel(path, header=False, index=False)

        result = extract_document(path)
        assert result.success, result.error
        headings = {line.heading for line in result.lines}
        assert "Sales" in headings
        assert count_pages(path) == 1

    def test_csv(self, tmp_path):
        path = tmp_path / "data.csv"
        path.write_text(
            "Particulars,Current Year,Previous Year\n"
            "Revenue from Operations,9000000,8000000\n"
            "Rent Paid,240000,240000\n",
            encoding="utf-8",
        )
        result = extract_document(path)
        assert result.success, result.error
        assert any(line.heading == "Rent Paid" for line in result.lines)

    def test_word(self, tmp_path):
        import docx

        path = tmp_path / "accounts.docx"
        document = docx.Document()
        document.add_paragraph("Statement of Profit and Loss")
        table = document.add_table(rows=3, cols=3)
        rows = [
            ["Particulars", "CY", "PY"],
            ["Purchases", "5500000", "5000000"],
            ["Professional Fees", "700000", "400000"],
        ]
        for row_index, row in enumerate(rows):
            for col_index, value in enumerate(row):
                table.cell(row_index, col_index).text = value
        document.save(path)

        result = extract_document(path)
        assert result.success, result.error
        headings = {line.heading for line in result.lines}
        assert "Professional Fees" in headings

    def test_unsupported_type_is_reported_clearly(self, tmp_path):
        path = tmp_path / "notes.xyz"
        path.write_text("hello", encoding="utf-8")
        result = extract_document(path)
        assert not result.success
        assert "not a supported file type" in result.error

    @pytest.mark.parametrize(
        "name,kind",
        [
            ("a.pdf", "PDF"),
            ("a.xlsx", "Excel"),
            ("a.docx", "Word"),
            ("a.csv", "CSV"),
            ("a.png", "Image"),
        ],
    )
    def test_file_kind(self, name, kind):
        assert file_kind(name) == kind
        assert is_supported(name)


class TestOcrDegradation:
    def test_availability_never_raises(self):
        available, message = ocr_engine.availability()
        assert isinstance(available, bool)
        assert message

    def test_scanned_detection(self):
        assert ocr_engine.is_scanned_text("")
        assert ocr_engine.is_scanned_text("  \n ")
        assert not ocr_engine.is_scanned_text("Revenue from Operations 84,50,00,000.00")

    def test_missing_tesseract_degrades_without_crashing(self, monkeypatch, sample_pdfs):
        """Simulate an end-user machine with no OCR engine installed."""
        monkeypatch.setattr(
            ocr_engine, "_probe_availability", lambda: (False, "OCR unavailable: test")
        )
        ocr_engine.reset_availability_cache()
        try:
            result = ocr_engine.ocr_pdf_page(sample_pdfs["sunrise_pl"], 1)
            assert not result.success
            assert "OCR unavailable" in result.message
            # A text PDF must still extract perfectly well without OCR.
            extraction = extract_document(sample_pdfs["sunrise_pl"])
            assert extraction.success
            assert extraction.lines
        finally:
            ocr_engine.reset_availability_cache()

    def test_image_without_ocr_gives_a_readable_warning(self, tmp_path, monkeypatch):
        from PIL import Image

        path = tmp_path / "scan.png"
        Image.new("RGB", (60, 30), "white").save(path)

        monkeypatch.setattr(
            ocr_engine, "_probe_availability", lambda: (False, "OCR unavailable: test")
        )
        ocr_engine.reset_availability_cache()
        try:
            result = extract_document(path)
            assert result.success          # not an error, just nothing extracted
            assert any("OCR unavailable" in w for w in result.warnings)
        finally:
            ocr_engine.reset_availability_cache()
