"""Home dashboard: the five primary actions."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .. import __app_name__, __app_subtitle__, __version__
from .theme import DISCLAIMER_SHORT


class DashboardScreen(QWidget):
    """Landing screen with the five large navigation cards."""

    new_analysis_requested = Signal()
    existing_cases_requested = Signal()
    reports_requested = Signal()
    settings_requested = Signal()
    exit_requested = Signal()

    CARDS = [
        ("NEW ANALYSIS", "Create a case and upload financial statements", "new_analysis_requested"),
        ("EXISTING CASES", "Open, edit or delete a saved case", "existing_cases_requested"),
        ("REPORTS", "Browse and open generated reports", "reports_requested"),
        ("SETTINGS", "Firm details, thresholds and preferences", "settings_requested"),
        ("EXIT", "Close the application", "exit_requested"),
    ]

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build()

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(48, 40, 48, 32)
        layout.setSpacing(10)

        title = QLabel(__app_name__)
        title.setObjectName("AppTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel(__app_subtitle__)
        subtitle.setObjectName("AppSubtitle")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitle)

        separator = QFrame()
        separator.setObjectName("Separator")
        separator.setFrameShape(QFrame.HLine)
        layout.addSpacing(14)
        layout.addWidget(separator)
        layout.addSpacing(26)

        grid = QGridLayout()
        grid.setSpacing(18)
        # Three across on the first row, two centred on the second.
        positions = [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1)]
        for (label, description, signal_name), (row, column) in zip(
            self.CARDS, positions
        ):
            grid.addWidget(self._make_card(label, description, signal_name), row, column)
        layout.addLayout(grid)

        layout.addStretch(1)

        disclaimer = QLabel(DISCLAIMER_SHORT)
        disclaimer.setObjectName("Muted")
        disclaimer.setAlignment(Qt.AlignCenter)
        disclaimer.setWordWrap(True)
        layout.addWidget(disclaimer)

        version = QLabel(f"Version {__version__}")
        version.setObjectName("Muted")
        version.setAlignment(Qt.AlignCenter)
        layout.addWidget(version)

    def _make_card(self, label: str, description: str, signal_name: str) -> QPushButton:
        button = QPushButton(f"{label}\n\n{description}")
        button.setObjectName("HomeCard")
        button.setMinimumHeight(140)
        button.setCursor(Qt.PointingHandCursor)
        button.setToolTip(description)
        signal = getattr(self, signal_name)
        button.clicked.connect(signal.emit)
        # Expose the button for tests and for keyboard shortcut wiring.
        setattr(self, f"button_{signal_name}", button)
        return button
