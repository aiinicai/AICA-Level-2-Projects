"""Main window: holds every screen and wires the navigation between them."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QMessageBox,
    QStackedWidget,
    QWidget,
)

from .. import __app_name__, __app_subtitle__
from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import Case
from .analysis_dashboard import AnalysisDashboardScreen
from .case_management import CaseManagementScreen
from .dashboard import DashboardScreen
from .new_case import NewCaseScreen
from .reports import ReportsScreen, open_in_system_viewer
from .settings import SettingsScreen
from .upload import UploadScreen
from .verification import VerificationScreen

log = get_logger(__name__)

# Indices into the stacked widget.
SCREEN_DASHBOARD = 0
SCREEN_NEW_CASE = 1
SCREEN_UPLOAD = 2
SCREEN_VERIFICATION = 3
SCREEN_ANALYSIS = 4
SCREEN_REPORTS = 5
SCREEN_SETTINGS = 6
SCREEN_CASES = 7


class MainWindow(QMainWindow):
    """The application shell."""

    def __init__(self, db: Optional[Database] = None) -> None:
        super().__init__()
        self.db = db or get_database()
        self.current_case: Optional[Case] = None
        self.current_outcome = None

        self.setWindowTitle(f"{__app_name__} - {__app_subtitle__}")
        self.resize(1280, 820)
        self.setMinimumSize(1024, 680)

        self._build_screens()
        self._connect_navigation()
        self._build_menu()

        self.statusBar().showMessage("Ready")
        self.go_to(SCREEN_DASHBOARD)

    # ------------------------------------------------------------- assembly

    def _build_screens(self) -> None:
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.dashboard = DashboardScreen()
        self.new_case = NewCaseScreen(self.db)
        self.upload = UploadScreen(self.db)
        self.verification = VerificationScreen(self.db)
        self.analysis = AnalysisDashboardScreen(self.db)
        self.reports = ReportsScreen(self.db)
        self.settings = SettingsScreen(self.db)
        self.cases = CaseManagementScreen(self.db)

        for screen in (
            self.dashboard,
            self.new_case,
            self.upload,
            self.verification,
            self.analysis,
            self.reports,
            self.settings,
            self.cases,
        ):
            self.stack.addWidget(screen)

    def _connect_navigation(self) -> None:
        # Home
        self.dashboard.new_analysis_requested.connect(self.start_new_analysis)
        self.dashboard.existing_cases_requested.connect(self.show_cases)
        self.dashboard.reports_requested.connect(self.show_reports)
        self.dashboard.settings_requested.connect(self.show_settings)
        self.dashboard.exit_requested.connect(self.close)

        # New case
        self.new_case.case_saved.connect(self.on_case_saved)
        self.new_case.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))

        # Upload
        self.upload.analysis_completed.connect(self.on_analysis_completed)
        self.upload.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))

        # Verification
        self.verification.verified.connect(self.reanalyse_after_verification)
        self.verification.back_requested.connect(lambda: self.go_to(SCREEN_ANALYSIS))

        # Analysis dashboard
        self.analysis.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))
        self.analysis.verify_requested.connect(self.show_verification)
        self.analysis.generate_report_requested.connect(self.generate_report)
        self.analysis.generate_queries_requested.connect(self.generate_queries)

        # Reports / settings / cases
        self.reports.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))
        self.settings.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))
        self.cases.back_requested.connect(lambda: self.go_to(SCREEN_DASHBOARD))
        self.cases.open_case_requested.connect(self.open_case)
        self.cases.edit_case_requested.connect(self.edit_case)
        self.cases.report_requested.connect(self.generate_report_for_case)

    def _build_menu(self) -> None:
        menu = self.menuBar()

        file_menu = menu.addMenu("&File")
        new_action = QAction("&New Case", self)
        new_action.setShortcut(QKeySequence.New)
        new_action.triggered.connect(self.start_new_analysis)
        file_menu.addAction(new_action)

        cases_action = QAction("&Existing Cases", self)
        cases_action.setShortcut("Ctrl+E")
        cases_action.triggered.connect(self.show_cases)
        file_menu.addAction(cases_action)

        reports_action = QAction("&Reports", self)
        reports_action.setShortcut("Ctrl+R")
        reports_action.triggered.connect(self.show_reports)
        file_menu.addAction(reports_action)

        file_menu.addSeparator()
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        tools_menu = menu.addMenu("&Tools")
        settings_action = QAction("&Settings", self)
        settings_action.triggered.connect(self.show_settings)
        tools_menu.addAction(settings_action)

        home_action = QAction("&Home", self)
        home_action.setShortcut("Ctrl+H")
        home_action.triggered.connect(lambda: self.go_to(SCREEN_DASHBOARD))
        tools_menu.addAction(home_action)

        help_menu = menu.addMenu("&Help")
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    # ----------------------------------------------------------- navigation

    def go_to(self, index: int) -> None:
        self.stack.setCurrentIndex(index)

    def start_new_analysis(self) -> None:
        self.new_case.clear_form()
        self.go_to(SCREEN_NEW_CASE)

    def show_cases(self) -> None:
        self.cases.reload()
        self.go_to(SCREEN_CASES)

    def show_reports(self) -> None:
        self.reports.reload()
        self.go_to(SCREEN_REPORTS)

    def show_settings(self) -> None:
        self.settings.reload()
        self.go_to(SCREEN_SETTINGS)

    def show_verification(self) -> None:
        if self.current_case is None:
            QMessageBox.information(
                self, "No case open", "Open a case before verifying figures."
            )
            return
        self.verification.set_case(self.current_case)
        self.go_to(SCREEN_VERIFICATION)

    # -------------------------------------------------------------- actions

    def on_case_saved(self, case_id: str) -> None:
        case = self.db.get_case(case_id)
        if case is None:
            QMessageBox.warning(self, "Case not found", f"Case {case_id} is missing.")
            return
        self.current_case = case
        self.upload.set_case(case)
        self.statusBar().showMessage(f"Case {case_id} - upload the financial statements")
        self.go_to(SCREEN_UPLOAD)

    def on_analysis_completed(self, outcome) -> None:
        self.current_outcome = outcome
        self.current_case = outcome.case
        self.analysis.set_outcome(outcome)
        counts = outcome.risk_counts
        self.statusBar().showMessage(
            f"Analysis complete - {counts['HIGH']} high, {counts['MEDIUM']} medium, "
            f"{counts['REVIEW REQUIRED']} review required"
        )
        self.go_to(SCREEN_ANALYSIS)

    def open_case(self, case_id: str) -> None:
        """Open a saved case at the most useful screen for its status."""
        case = self.db.get_case(case_id)
        if case is None:
            QMessageBox.warning(self, "Case not found", f"Case {case_id} is missing.")
            return
        self.current_case = case
        self.statusBar().showMessage(f"Opened {case.case_id} ({case.status})")

        if case.status in ("Analysis Completed", "Report Generated", "Verified"):
            self.analysis.load_case(case)
            self.go_to(SCREEN_ANALYSIS)
        else:
            self.upload.set_case(case)
            self.go_to(SCREEN_UPLOAD)

    def edit_case(self, case_id: str) -> None:
        if self.new_case.load_case(case_id):
            self.go_to(SCREEN_NEW_CASE)

    def reanalyse_after_verification(self) -> None:
        """Re-run the analysis using the figures the CA has just corrected."""
        if self.current_case is None:
            return
        from ..core.pipeline import analyse_case

        self.statusBar().showMessage("Re-analysing with the verified figures...")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            outcome = analyse_case(self.current_case, db=self.db)
        except Exception as exc:
            log.exception("Re-analysis failed")
            QMessageBox.critical(
                self,
                "Re-analysis failed",
                f"The analysis could not be re-run.\n\n{exc}",
            )
            return
        finally:
            QApplication.restoreOverrideCursor()

        self.on_analysis_completed(outcome)

    def _ensure_outcome(self):
        """Return an outcome for the current case, recomputing if necessary."""
        if self.current_outcome is not None and self.current_case is not None:
            if self.current_outcome.case.case_id == self.current_case.case_id:
                return self.current_outcome
        if self.current_case is None:
            return None
        from ..core.pipeline import analyse_case

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.current_outcome = analyse_case(self.current_case, db=self.db)
        finally:
            QApplication.restoreOverrideCursor()
        return self.current_outcome

    def generate_report(self) -> None:
        if self.current_case is None:
            QMessageBox.information(
                self, "No case open", "Open a case before generating a report."
            )
            return
        from ..core.pipeline import build_report
        from ..core.report_generator import ReportError

        outcome = self._ensure_outcome()
        if outcome is None:
            return

        self.statusBar().showMessage("Generating the Word report...")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            path = build_report(outcome, db=self.db)
        except ReportError as exc:
            QMessageBox.critical(self, "Could not generate the report", str(exc))
            return
        except Exception as exc:
            log.exception("Unexpected report failure")
            QMessageBox.critical(
                self, "Could not generate the report", f"An unexpected error occurred: {exc}"
            )
            return
        finally:
            QApplication.restoreOverrideCursor()

        self.statusBar().showMessage(f"Report saved to {path}")
        answer = QMessageBox.question(
            self,
            "Report generated",
            f"The report has been saved to:\n{path}\n\nOpen it now?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            open_in_system_viewer(Path(path))

    def generate_report_for_case(self, case_id: str) -> None:
        case = self.db.get_case(case_id)
        if case is None:
            return
        self.current_case = case
        self.current_outcome = None
        self.generate_report()

    def generate_queries(self) -> None:
        if self.current_case is None:
            return
        from ..core.report_generator import ReportError, generate_queries_document

        outcome = self._ensure_outcome()
        if outcome is None:
            return
        if not outcome.queries:
            QMessageBox.information(
                self,
                "No queries",
                "No matters requiring a client response were identified.",
            )
            return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            path = generate_queries_document(self.current_case, outcome.queries)
        except ReportError as exc:
            QMessageBox.critical(self, "Could not generate the queries", str(exc))
            return
        finally:
            QApplication.restoreOverrideCursor()

        answer = QMessageBox.question(
            self,
            "Auditor queries generated",
            f"{len(outcome.queries)} quer(ies) were drafted and saved to:\n{path}\n\n"
            "Open the document now?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            open_in_system_viewer(Path(path))

    def show_about(self) -> None:
        from .. import __version__

        QMessageBox.about(
            self,
            f"About {__app_name__}",
            f"<b>{__app_name__}</b><br>{__app_subtitle__}<br><br>"
            f"Version {__version__}<br><br>"
            "This application is an analytical assistant for preliminary tax "
            "audit review. It does not provide a tax audit opinion, a legal "
            "opinion or an assessment of tax liability, and it is not a "
            "substitute for professional judgement. All analysis is rule-based "
            "and is performed entirely on this computer.",
        )

    def closeEvent(self, event) -> None:
        answer = QMessageBox.question(
            self,
            "Exit",
            "Close the application?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            log.info("Application closed by the user.")
            event.accept()
        else:
            event.ignore()
