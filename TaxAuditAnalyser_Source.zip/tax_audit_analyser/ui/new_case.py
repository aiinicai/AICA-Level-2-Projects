"""New / edit case screen."""

from __future__ import annotations

import re
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import CONSTITUTIONS, TAX_AUDIT_APPLICABILITY, Case

log = get_logger(__name__)

# PAN: five letters, four digits, one letter.
PAN_PATTERN = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
# GSTIN: 2-digit state code, PAN, entity code, 'Z', checksum.
GSTIN_PATTERN = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][0-9A-Z]Z[0-9A-Z]$")


class NewCaseScreen(QWidget):
    """Capture the particulars of the assessee and create the case."""

    case_saved = Signal(str)      # emits case_id
    back_requested = Signal()

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self.editing_case_id: Optional[str] = None
        self._build()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(30, 22, 30, 22)
        outer.setSpacing(12)

        header = QHBoxLayout()
        self.title_label = QLabel("NEW CASE")
        self.title_label.setObjectName("ScreenTitle")
        header.addWidget(self.title_label)
        header.addStretch(1)
        self.case_id_label = QLabel("")
        self.case_id_label.setObjectName("Muted")
        header.addWidget(self.case_id_label)
        outer.addLayout(header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        scroll.setWidget(container)
        outer.addWidget(scroll, 1)

        body = QVBoxLayout(container)
        body.setSpacing(14)

        # -- assessee particulars ------------------------------------------
        assessee_box = QGroupBox("Assessee Particulars")
        assessee_form = QFormLayout(assessee_box)
        assessee_form.setLabelAlignment(Qt.AlignRight)
        assessee_form.setSpacing(10)

        self.assessee_name = QLineEdit()
        self.assessee_name.setPlaceholderText("Full name of the assessee (required)")
        assessee_form.addRow("Assessee Name *", self.assessee_name)

        self.pan = QLineEdit()
        self.pan.setPlaceholderText("AAAPA1234A")
        self.pan.setMaxLength(10)
        self.pan.textChanged.connect(self._uppercase_pan)
        assessee_form.addRow("PAN", self.pan)

        self.constitution = QComboBox()
        self.constitution.addItems(CONSTITUTIONS)
        assessee_form.addRow("Constitution", self.constitution)

        self.nature_of_business = QLineEdit()
        self.nature_of_business.setPlaceholderText(
            "e.g. Wholesale trading in textiles"
        )
        assessee_form.addRow("Nature of Business", self.nature_of_business)

        self.gstin = QLineEdit()
        self.gstin.setPlaceholderText("Optional, e.g. 27AAAPA1234A1ZP")
        self.gstin.setMaxLength(15)
        self.gstin.textChanged.connect(self._uppercase_gstin)
        assessee_form.addRow("GSTIN", self.gstin)

        body.addWidget(assessee_box)

        # -- period and audit ----------------------------------------------
        period_box = QGroupBox("Period and Audit Particulars")
        period_form = QFormLayout(period_box)
        period_form.setLabelAlignment(Qt.AlignRight)
        period_form.setSpacing(10)

        self.financial_year = QLineEdit()
        self.financial_year.setPlaceholderText("e.g. 2024-25")
        self.financial_year.editingFinished.connect(self._derive_assessment_year)
        period_form.addRow("Financial Year", self.financial_year)

        self.assessment_year = QLineEdit()
        self.assessment_year.setPlaceholderText("e.g. 2025-26")
        period_form.addRow("Assessment Year", self.assessment_year)

        self.turnover = QDoubleSpinBox()
        self.turnover.setRange(0.0, 9_999_999_999_999.0)
        self.turnover.setDecimals(2)
        self.turnover.setGroupSeparatorShown(True)
        self.turnover.setPrefix("Rs. ")
        self.turnover.setSpecialValueText("Not stated")
        period_form.addRow("Turnover", self.turnover)

        self.tax_audit_applicable = QComboBox()
        self.tax_audit_applicable.addItems(TAX_AUDIT_APPLICABILITY)
        period_form.addRow("Tax Audit Applicable", self.tax_audit_applicable)

        self.auditor_name = QLineEdit()
        self.auditor_name.setPlaceholderText("Auditor or firm name")
        period_form.addRow("Auditor / Firm Name", self.auditor_name)

        body.addWidget(period_box)

        # -- remarks --------------------------------------------------------
        remarks_box = QGroupBox("Remarks")
        remarks_layout = QVBoxLayout(remarks_box)
        self.remarks = QTextEdit()
        self.remarks.setPlaceholderText(
            "Any background notes on the engagement (optional)"
        )
        self.remarks.setMaximumHeight(110)
        remarks_layout.addWidget(self.remarks)
        body.addWidget(remarks_box)

        note = QLabel(
            "The applicability of tax audit is recorded here for reference only. "
            "It is determined by the Chartered Accountant with reference to the "
            "law applicable for the relevant assessment year."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        body.addWidget(note)
        body.addStretch(1)

        # -- actions --------------------------------------------------------
        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)
        actions.addStretch(1)

        self.clear_button = QPushButton("CLEAR")
        self.clear_button.setObjectName("Secondary")
        self.clear_button.clicked.connect(self.clear_form)
        actions.addWidget(self.clear_button)

        self.save_button = QPushButton("SAVE AND CONTINUE")
        self.save_button.clicked.connect(self.save_case)
        actions.addWidget(self.save_button)
        outer.addLayout(actions)

    # -------------------------------------------------------------- helpers

    def _uppercase_pan(self, text: str) -> None:
        upper = text.upper()
        if upper != text:
            position = self.pan.cursorPosition()
            self.pan.setText(upper)
            self.pan.setCursorPosition(position)

    def _uppercase_gstin(self, text: str) -> None:
        upper = text.upper()
        if upper != text:
            position = self.gstin.cursorPosition()
            self.gstin.setText(upper)
            self.gstin.setCursorPosition(position)

    def _derive_assessment_year(self) -> None:
        """Offer the assessment year that follows the financial year entered."""
        if self.assessment_year.text().strip():
            return
        text = self.financial_year.text().strip()
        match = re.match(r"^(\d{4})\s*[-/]\s*(\d{2,4})$", text)
        if not match:
            return
        start = int(match.group(1))
        self.assessment_year.setText(f"{start + 1}-{str(start + 2)[-2:]}")

    def clear_form(self) -> None:
        self.editing_case_id = None
        self.title_label.setText("NEW CASE")
        self.case_id_label.setText("")
        self.assessee_name.clear()
        self.pan.clear()
        self.constitution.setCurrentIndex(0)
        self.nature_of_business.clear()
        self.gstin.clear()
        self.financial_year.clear()
        self.assessment_year.clear()
        self.turnover.setValue(0.0)
        self.tax_audit_applicable.setCurrentIndex(0)
        self.auditor_name.clear()
        self.remarks.clear()
        self._prefill_auditor()

    def _prefill_auditor(self) -> None:
        try:
            firm = self.db.get_setting("firm_name", "")
            if firm and not self.auditor_name.text().strip():
                self.auditor_name.setText(firm)
        except DatabaseError:
            log.debug("Could not read the firm name setting.", exc_info=True)

    # ----------------------------------------------------------- validation

    def _validate(self) -> Optional[str]:
        """Return an error message, or None when the form is acceptable."""
        if not self.assessee_name.text().strip():
            return "Assessee Name is required."

        pan = self.pan.text().strip()
        if pan and not PAN_PATTERN.match(pan):
            return (
                "PAN does not appear to be valid. A PAN is ten characters in the "
                "form AAAPA1234A. Leave it blank if it is not available."
            )

        gstin = self.gstin.text().strip()
        if gstin and not GSTIN_PATTERN.match(gstin):
            return (
                "GSTIN does not appear to be valid. A GSTIN is fifteen characters "
                "in the form 27AAAPA1234A1ZP. Leave it blank if not applicable."
            )

        financial_year = self.financial_year.text().strip()
        if financial_year and not re.match(r"^\d{4}\s*[-/]\s*\d{2,4}$", financial_year):
            return "Financial Year should be in the form 2024-25."
        return None

    # ---------------------------------------------------------------- state

    def load_case(self, case_id: str) -> bool:
        """Populate the form from an existing case for editing."""
        try:
            case = self.db.get_case(case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not open case", str(exc))
            return False
        if case is None:
            QMessageBox.warning(
                self, "Case not found", f"Case {case_id} could not be found."
            )
            return False

        self.editing_case_id = case.case_id
        self.title_label.setText("EDIT CASE")
        self.case_id_label.setText(f"Case ID: {case.case_id}")
        self.assessee_name.setText(case.assessee_name)
        self.pan.setText(case.pan or "")
        index = self.constitution.findText(case.constitution or "")
        self.constitution.setCurrentIndex(max(index, 0))
        self.nature_of_business.setText(case.nature_of_business or "")
        self.gstin.setText(case.gstin or "")
        self.financial_year.setText(case.financial_year or "")
        self.assessment_year.setText(case.assessment_year or "")
        self.turnover.setValue(float(case.turnover or 0.0))
        index = self.tax_audit_applicable.findText(case.tax_audit_applicable or "")
        self.tax_audit_applicable.setCurrentIndex(max(index, 0))
        self.auditor_name.setText(case.auditor_name or "")
        self.remarks.setPlainText(case.remarks or "")
        return True

    def collect(self) -> Case:
        """Build a Case object from the current form values."""
        return Case(
            case_id=self.editing_case_id or "",
            assessee_name=self.assessee_name.text().strip(),
            pan=self.pan.text().strip(),
            assessment_year=self.assessment_year.text().strip(),
            financial_year=self.financial_year.text().strip(),
            constitution=self.constitution.currentText(),
            nature_of_business=self.nature_of_business.text().strip(),
            gstin=self.gstin.text().strip(),
            turnover=self.turnover.value() or None,
            tax_audit_applicable=self.tax_audit_applicable.currentText(),
            auditor_name=self.auditor_name.text().strip(),
            remarks=self.remarks.toPlainText().strip(),
        )

    def save_case(self) -> None:
        """Validate, persist and announce the case."""
        error = self._validate()
        if error:
            QMessageBox.warning(self, "Please check the details entered", error)
            return

        case = self.collect()
        try:
            if self.editing_case_id:
                existing = self.db.get_case(self.editing_case_id)
                if existing is not None:
                    case.status = existing.status
                    case.date_created = existing.date_created
                self.db.update_case(case)
                case_id = self.editing_case_id
                log.info("Updated case %s", case_id)
            else:
                case_id = self.db.create_case(case)
                log.info("Created case %s", case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not save the case", str(exc))
            return

        QMessageBox.information(
            self,
            "Case saved",
            f"Case {case_id} has been saved for {case.assessee_name}.\n\n"
            "You can now upload the financial statements for analysis.",
        )
        self.case_saved.emit(case_id)
