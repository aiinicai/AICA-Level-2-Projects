"""Shared visual language for the application.

A plain, corporate look: a restrained navy/slate palette, generous spacing and
no decorative colour. Colour is reserved for meaning -- risk levels and
confidence grades -- so that where it does appear it carries information.
"""

from __future__ import annotations

# ------------------------------------------------------------------ palette

NAVY = "#1F3A5F"
NAVY_DARK = "#152B47"
SLATE = "#42556B"
LIGHT_BG = "#F4F6F8"
CARD_BG = "#FFFFFF"
BORDER = "#D3DAE2"
TEXT = "#1B2733"
MUTED = "#6B7A8C"

# Risk level colours (also used for the dashboard tiles).
RISK_COLOURS = {
    "HIGH": "#B3261E",
    "MEDIUM": "#B26A00",
    "REVIEW REQUIRED": "#1F5F8B",
    "INFORMATIONAL": "#4A6572",
}

RISK_BACKGROUNDS = {
    "HIGH": "#FBE9E7",
    "MEDIUM": "#FFF4E5",
    "REVIEW REQUIRED": "#E8F1F8",
    "INFORMATIONAL": "#EFF2F5",
}

# Confidence highlighting on the verification screen.
CONFIDENCE_BACKGROUNDS = {
    "High": "#FFFFFF",
    "Medium": "#FFFDF0",
    "Low": "#FFF6C2",       # yellow: must be reviewed by the CA
}

MATERIALITY_COLOURS = {
    "High Movement": "#B3261E",
    "Significant": "#B26A00",
    "Review": "#1F5F8B",
    "Normal": "#4A6572",
}


def app_stylesheet() -> str:
    """Application-wide Qt style sheet."""
    return f"""
    QWidget {{
        background-color: {LIGHT_BG};
        color: {TEXT};
        font-family: 'Segoe UI', 'Noto Sans', Arial, sans-serif;
        font-size: 13px;
    }}
    QLabel#AppTitle {{
        font-size: 26px;
        font-weight: bold;
        color: {NAVY};
    }}
    QLabel#AppSubtitle {{
        font-size: 14px;
        color: {SLATE};
    }}
    QLabel#ScreenTitle {{
        font-size: 19px;
        font-weight: bold;
        color: {NAVY};
    }}
    QLabel#SectionTitle {{
        font-size: 14px;
        font-weight: bold;
        color: {NAVY};
    }}
    QLabel#Muted {{
        color: {MUTED};
    }}
    QFrame#Card {{
        background-color: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 6px;
    }}
    QFrame#Separator {{
        background-color: {BORDER};
        max-height: 1px;
        border: none;
    }}
    QPushButton {{
        background-color: {NAVY};
        color: #FFFFFF;
        border: none;
        border-radius: 4px;
        padding: 8px 18px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: {NAVY_DARK};
    }}
    QPushButton:disabled {{
        background-color: #A9B4C0;
        color: #EDEFF2;
    }}
    QPushButton#Secondary {{
        background-color: #FFFFFF;
        color: {NAVY};
        border: 1px solid {NAVY};
    }}
    QPushButton#Secondary:hover {{
        background-color: #E8EEF5;
    }}
    QPushButton#Danger {{
        background-color: {RISK_COLOURS['HIGH']};
    }}
    QPushButton#Danger:hover {{
        background-color: #8E1D18;
    }}
    QPushButton#HomeCard {{
        background-color: {CARD_BG};
        color: {NAVY};
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 26px 14px;
        font-size: 15px;
        font-weight: bold;
        text-align: center;
    }}
    QPushButton#HomeCard:hover {{
        background-color: #E8EEF5;
        border: 1px solid {NAVY};
    }}
    QLineEdit, QComboBox, QTextEdit, QSpinBox, QDoubleSpinBox, QPlainTextEdit {{
        background-color: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 4px;
        padding: 6px 8px;
        selection-background-color: {NAVY};
    }}
    QLineEdit:focus, QComboBox:focus, QTextEdit:focus {{
        border: 1px solid {NAVY};
    }}
    QTableWidget {{
        background-color: {CARD_BG};
        border: 1px solid {BORDER};
        gridline-color: {BORDER};
        selection-background-color: #DCE6F1;
        selection-color: {TEXT};
    }}
    QHeaderView::section {{
        background-color: #E7EBF0;
        color: {NAVY};
        padding: 7px;
        border: none;
        border-right: 1px solid {BORDER};
        border-bottom: 1px solid {BORDER};
        font-weight: bold;
    }}
    QTableWidget::item {{
        padding: 4px;
    }}
    QGroupBox {{
        background-color: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 6px;
        margin-top: 14px;
        padding-top: 10px;
        font-weight: bold;
        color: {NAVY};
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 12px;
        padding: 0 5px;
    }}
    QScrollArea {{
        border: none;
        background-color: {LIGHT_BG};
    }}
    QProgressBar {{
        border: 1px solid {BORDER};
        border-radius: 4px;
        background-color: {CARD_BG};
        text-align: center;
        height: 20px;
    }}
    QProgressBar::chunk {{
        background-color: {NAVY};
        border-radius: 3px;
    }}
    QStatusBar {{
        background-color: #E7EBF0;
        color: {SLATE};
    }}
    QMenuBar {{
        background-color: {NAVY};
        color: #FFFFFF;
    }}
    QMenuBar::item:selected {{
        background-color: {NAVY_DARK};
    }}
    QMenu {{
        background-color: {CARD_BG};
        border: 1px solid {BORDER};
    }}
    QMenu::item:selected {{
        background-color: #DCE6F1;
    }}
    QTabWidget::pane {{
        border: 1px solid {BORDER};
        background-color: {CARD_BG};
    }}
    QTabBar::tab {{
        background-color: #E7EBF0;
        padding: 8px 18px;
        border: 1px solid {BORDER};
        border-bottom: none;
    }}
    QTabBar::tab:selected {{
        background-color: {CARD_BG};
        color: {NAVY};
        font-weight: bold;
    }}
    """


DISCLAIMER_SHORT = (
    "This application is an analytical assistant. It does not provide a tax "
    "audit opinion and is not a substitute for professional judgement."
)
