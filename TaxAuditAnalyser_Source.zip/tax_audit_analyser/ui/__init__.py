"""PySide6 user interface screens."""
