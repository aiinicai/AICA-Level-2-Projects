"""Risk dashboard: tiles, filterable findings table and detailed view."""

from __future__ import annotations

from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import Case, RiskFlag
from .theme import MUTED, NAVY, RISK_BACKGROUNDS, RISK_COLOURS
from .verification import format_amount

log = get_logger(__name__)

RISK_LEVELS = ["HIGH", "MEDIUM", "REVIEW REQUIRED", "INFORMATIONAL"]
TILE_LABELS = {
    "HIGH": "HIGH RISK",
    "MEDIUM": "MEDIUM RISK",
    "REVIEW REQUIRED": "REVIEW REQUIRED",
    "INFORMATIONAL": "INFORMATIONAL",
}


class RiskTile(QFrame):
    """A clickable count tile that also acts as a filter."""

    clicked = Signal(str)

    def __init__(self, level: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.level = level
        self.setObjectName("Card")
        self.setMinimumHeight(92)
        self.setCursor(Qt.PointingHandCursor)
        colour = RISK_COLOURS.get(level, NAVY)
        background = RISK_BACKGROUNDS.get(level, "#FFFFFF")
        self.setStyleSheet(
            f"QFrame {{ background-color: {background}; border: 1px solid {colour}; "
            f"border-radius: 6px; }}"
        )

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(2)

        self.count_label = QLabel("0")
        self.count_label.setAlignment(Qt.AlignCenter)
        self.count_label.setStyleSheet(
            f"font-size: 30px; font-weight: bold; color: {colour}; border: none;"
        )
        layout.addWidget(self.count_label)

        name = QLabel(TILE_LABELS.get(level, level))
        name.setAlignment(Qt.AlignCenter)
        name.setStyleSheet(
            f"font-size: 11px; font-weight: bold; color: {colour}; border: none;"
        )
        layout.addWidget(name)

    def set_count(self, count: int) -> None:
        self.count_label.setText(str(count))

    def mousePressEvent(self, event) -> None:
        self.clicked.emit(self.level)
        super().mousePressEvent(event)


class AnalysisDashboardScreen(QWidget):
    """Presents the risk flags, the detailed findings and the ratios."""

    generate_report_requested = Signal()
    generate_queries_requested = Signal()
    verify_requested = Signal()
    back_requested = Signal()

    COLUMNS = [
        "Risk Level",
        "Area",
        "Observation",
        "Amount",
        "Source",
        "Recommended Verification",
    ]

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self.case: Optional[Case] = None
        self.outcome = None
        self.flags: List[RiskFlag] = []
        self._filtered: List[RiskFlag] = []
        self.tiles: Dict[str, RiskTile] = {}
        self._build()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 18, 24, 18)
        layout.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("RISK DASHBOARD")
        title.setObjectName("ScreenTitle")
        header.addWidget(title)
        header.addStretch(1)
        self.case_label = QLabel("")
        self.case_label.setObjectName("Muted")
        header.addWidget(self.case_label)
        layout.addLayout(header)

        tiles = QGridLayout()
        tiles.setSpacing(12)
        for column, level in enumerate(RISK_LEVELS):
            tile = RiskTile(level)
            tile.clicked.connect(self._filter_from_tile)
            self.tiles[level] = tile
            tiles.addWidget(tile, 0, column)
        layout.addLayout(tiles)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_findings_tab(), "Risk Findings")
        self.tabs.addTab(self._build_detail_tab(), "Detailed Findings")
        self.tabs.addTab(self._build_ratio_tab(), "Ratios and Validation")
        layout.addWidget(self.tabs, 1)

        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)

        self.verify_button = QPushButton("VERIFY FIGURES")
        self.verify_button.setObjectName("Secondary")
        self.verify_button.clicked.connect(self.verify_requested.emit)
        actions.addWidget(self.verify_button)

        actions.addStretch(1)

        self.queries_button = QPushButton("GENERATE AUDIT QUERIES")
        self.queries_button.setObjectName("Secondary")
        self.queries_button.clicked.connect(self.generate_queries_requested.emit)
        actions.addWidget(self.queries_button)

        self.report_button = QPushButton("GENERATE WORD REPORT")
        self.report_button.clicked.connect(self.generate_report_requested.emit)
        actions.addWidget(self.report_button)
        layout.addLayout(actions)

    def _build_findings_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(8, 10, 8, 8)

        controls = QHBoxLayout()
        controls.addWidget(QLabel("Show:"))
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(
            ["All", "High", "Medium", "Review Required", "Informational"]
        )
        self.filter_combo.currentTextChanged.connect(lambda _: self.apply_filter())
        self.filter_combo.setMaximumWidth(200)
        controls.addWidget(self.filter_combo)
        controls.addStretch(1)
        self.count_label = QLabel("")
        self.count_label.setObjectName("Muted")
        controls.addWidget(self.count_label)
        layout.addLayout(controls)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setWordWrap(True)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self._show_selected_detail)
        layout.addWidget(self.table)
        return widget

    def _build_detail_tab(self) -> QWidget:
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(8, 10, 8, 8)

        splitter = QSplitter(Qt.Horizontal)

        self.detail_list = QTableWidget(0, 2)
        self.detail_list.setHorizontalHeaderLabels(["Level", "Area"])
        self.detail_list.verticalHeader().setVisible(False)
        self.detail_list.setSelectionBehavior(QTableWidget.SelectRows)
        self.detail_list.setEditTriggers(QTableWidget.NoEditTriggers)
        self.detail_list.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch
        )
        self.detail_list.itemSelectionChanged.connect(self._show_detail_from_list)
        splitter.addWidget(self.detail_list)

        self.detail_view = QTextBrowser()
        self.detail_view.setOpenExternalLinks(False)
        self.detail_view.setStyleSheet(
            "QTextBrowser { background-color: #FFFFFF; border: 1px solid #D3DAE2; "
            "padding: 12px; }"
        )
        splitter.addWidget(self.detail_view)
        splitter.setSizes([320, 700])
        layout.addWidget(splitter)
        return widget

    def _build_ratio_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(8, 10, 8, 8)

        layout.addWidget(QLabel("Key Ratios"))
        self.ratio_table = QTableWidget(0, 5)
        self.ratio_table.setHorizontalHeaderLabels(
            ["Ratio", "Basis", "Current Year", "Previous Year", "Movement"]
        )
        self.ratio_table.verticalHeader().setVisible(False)
        self.ratio_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.ratio_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch
        )
        layout.addWidget(self.ratio_table, 2)

        layout.addWidget(QLabel("Accounting Validation"))
        self.validation_table = QTableWidget(0, 4)
        self.validation_table.setHorizontalHeaderLabels(
            ["Check", "Result", "Difference", "Observation"]
        )
        self.validation_table.verticalHeader().setVisible(False)
        self.validation_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.validation_table.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.Stretch
        )
        layout.addWidget(self.validation_table, 1)
        return widget

    # ---------------------------------------------------------------- state

    def set_outcome(self, outcome) -> None:
        """Display a freshly computed analysis outcome."""
        self.outcome = outcome
        self.case = outcome.case
        self.flags = list(outcome.flags)
        self.case_label.setText(
            f"{outcome.case.case_id}  |  {outcome.case.assessee_name}"
        )
        self._refresh_tiles()
        self.apply_filter()
        self._populate_ratios()

    def load_case(self, case: Case) -> None:
        """Display a previously analysed case straight from the database."""
        self.case = case
        self.case_label.setText(f"{case.case_id}  |  {case.assessee_name}")
        try:
            self.flags = self.db.list_risk_flags(case.case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not load findings", str(exc))
            self.flags = []
        self.outcome = None
        self._refresh_tiles()
        self.apply_filter()
        self._populate_stored_ratios(case)

    def _refresh_tiles(self) -> None:
        for level, tile in self.tiles.items():
            tile.set_count(sum(1 for f in self.flags if f.risk_level == level))

    def _filter_from_tile(self, level: str) -> None:
        mapping = {
            "HIGH": "High",
            "MEDIUM": "Medium",
            "REVIEW REQUIRED": "Review Required",
            "INFORMATIONAL": "Informational",
        }
        self.filter_combo.setCurrentText(mapping.get(level, "All"))
        self.tabs.setCurrentIndex(0)

    def apply_filter(self) -> None:
        choice = self.filter_combo.currentText().upper()
        if choice == "ALL":
            self._filtered = list(self.flags)
        else:
            self._filtered = [f for f in self.flags if f.risk_level == choice]
        self._populate_table()
        self._populate_detail_list()
        self.count_label.setText(
            f"Showing {len(self._filtered)} of {len(self.flags)} finding(s)"
        )

    def _populate_table(self) -> None:
        self.table.setRowCount(0)
        for flag in self._filtered:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                flag.risk_level,
                flag.area,
                flag.observation,
                format_amount(flag.amount) if flag.amount is not None else "-",
                flag.source,
                flag.recommended_verification,
            ]
            colour = QColor(RISK_BACKGROUNDS.get(flag.risk_level, "#FFFFFF"))
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                if column == 0:
                    item.setForeground(
                        QBrush(QColor(RISK_COLOURS.get(flag.risk_level, "#000000")))
                    )
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                if column == 3:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                item.setBackground(QBrush(colour))
                self.table.setItem(row, column, item)
        self.table.resizeRowsToContents()

    def _populate_detail_list(self) -> None:
        self.detail_list.setRowCount(0)
        for flag in self._filtered:
            row = self.detail_list.rowCount()
            self.detail_list.insertRow(row)
            level_item = QTableWidgetItem(flag.risk_level)
            level_item.setForeground(
                QBrush(QColor(RISK_COLOURS.get(flag.risk_level, "#000000")))
            )
            self.detail_list.setItem(row, 0, level_item)
            self.detail_list.setItem(row, 1, QTableWidgetItem(flag.area))
        if self._filtered:
            self.detail_list.selectRow(0)

    # --------------------------------------------------------------- detail

    def _show_selected_detail(self) -> None:
        rows = {index.row() for index in self.table.selectedIndexes()}
        if not rows:
            return
        row = min(rows)
        if 0 <= row < len(self._filtered):
            self.detail_view.setHtml(self._detail_html(self._filtered[row]))

    def _show_detail_from_list(self) -> None:
        rows = {index.row() for index in self.detail_list.selectedIndexes()}
        if not rows:
            return
        row = min(rows)
        if 0 <= row < len(self._filtered):
            self.detail_view.setHtml(self._detail_html(self._filtered[row]))

    def _detail_html(self, flag: RiskFlag) -> str:
        """Render one finding as the detailed findings view."""
        colour = RISK_COLOURS.get(flag.risk_level, NAVY)

        def row(label: str, value: str) -> str:
            if not value:
                return ""
            return (
                f"<tr><td style='padding:4px 10px 4px 0; vertical-align:top; "
                f"color:#6B7A8C; white-space:nowrap;'><b>{label}</b></td>"
                f"<td style='padding:4px 0;'>{value}</td></tr>"
            )

        change = (
            f"{flag.change_percent:,.1f}%" if flag.change_percent is not None else "-"
        )
        documents = "".join(
            f"<li>{doc}</li>" for doc in (flag.documents_to_verify or [])
        )
        documents_html = f"<ul style='margin:4px 0 0 16px;'>{documents}</ul>" if documents else "-"

        return f"""
        <div style="font-family: Segoe UI, Arial, sans-serif; font-size: 13px;">
          <div style="background:{colour}; color:#FFFFFF; padding:8px 12px;
                      border-radius:4px; font-weight:bold;">
            {flag.risk_level} &nbsp;|&nbsp; {flag.area}
          </div>
          <h3 style="margin:14px 0 6px 0; color:#1F3A5F;">Issue</h3>
          <div style="text-align:justify;">{flag.observation}</div>
          <table style="margin-top:12px; border-collapse:collapse; width:100%;">
            {row("Current Year", format_amount(flag.amount) if flag.amount is not None else "-")}
            {row("Previous Year", format_amount(flag.previous_year_amount) if flag.previous_year_amount is not None else "-")}
            {row("Change %", change)}
            {row("Nature of Finding", flag.finding_type)}
            {row("Source", flag.source)}
          </table>
          <h3 style="margin:14px 0 6px 0; color:#1F3A5F;">Why Flagged</h3>
          <div style="text-align:justify;">{flag.why_flagged or "-"}</div>
          <h3 style="margin:14px 0 6px 0; color:#1F3A5F;">Tax Audit Relevance</h3>
          <div style="text-align:justify;">{flag.tax_audit_relevance or "-"}</div>
          <h3 style="margin:14px 0 6px 0; color:#1F3A5F;">Recommended Verification</h3>
          <div style="text-align:justify;">{flag.recommended_verification or "-"}</div>
          <h3 style="margin:14px 0 6px 0; color:#1F3A5F;">Documents to Verify</h3>
          {documents_html}
          {"<h3 style='margin:14px 0 6px 0; color:#1F3A5F;'>Potential Form 3CD Reporting Area</h3>"
           f"<div style='text-align:justify;'>{flag.potential_3cd_clause}</div>"
           if flag.potential_3cd_clause else ""}
        </div>
        """

    # --------------------------------------------------------------- ratios

    def _populate_ratios(self) -> None:
        if self.outcome is None:
            return
        self.ratio_table.setRowCount(0)
        for ratio in self.outcome.ratios:
            row = self.ratio_table.rowCount()
            self.ratio_table.insertRow(row)
            movement = "Material" if ratio.is_material_change else "-"
            for column, value in enumerate(
                [
                    ratio.name,
                    ratio.basis,
                    ratio.current_display,
                    ratio.previous_display,
                    movement,
                ]
            ):
                item = QTableWidgetItem(str(value))
                item.setToolTip(ratio.explanation)
                self.ratio_table.setItem(row, column, item)

        self.validation_table.setRowCount(0)
        for check in self.outcome.validations:
            row = self.validation_table.rowCount()
            self.validation_table.insertRow(row)
            values = [
                check.name,
                check.status,
                format_amount(check.difference) if check.difference is not None else "-",
                check.message,
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                if column == 1 and check.applicable and not check.passed:
                    item.setForeground(QBrush(QColor(RISK_COLOURS["HIGH"])))
                self.validation_table.setItem(row, column, item)

    def _populate_stored_ratios(self, case: Case) -> None:
        """Rebuild the ratio and validation tables from stored results."""
        try:
            ratios = self.db.list_analysis_results(case.case_id, "RATIO")
            validations = self.db.list_analysis_results(case.case_id, "VALIDATION")
        except DatabaseError:
            return

        self.ratio_table.setRowCount(0)
        for result in ratios:
            row = self.ratio_table.rowCount()
            self.ratio_table.insertRow(row)
            current = (
                f"{result.current_year:,.2f}" if result.current_year is not None else "-"
            )
            previous = (
                f"{result.previous_year:,.2f}"
                if result.previous_year is not None
                else "-"
            )
            for column, value in enumerate(
                [result.label, "", current, previous, result.materiality]
            ):
                item = QTableWidgetItem(str(value))
                item.setToolTip(result.explanation)
                self.ratio_table.setItem(row, column, item)

        self.validation_table.setRowCount(0)
        for result in validations:
            row = self.validation_table.rowCount()
            self.validation_table.insertRow(row)
            difference = (
                format_amount(result.change_amount)
                if result.change_amount is not None
                else "-"
            )
            for column, value in enumerate(
                [result.label, result.materiality, difference, result.explanation]
            ):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.validation_table.setItem(row, column, item)
