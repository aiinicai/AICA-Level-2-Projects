"""Existing cases screen: open, edit, duplicate, delete, generate report."""

from __future__ import annotations

import shutil
from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import Case
from ..paths import case_upload_dir
from .theme import MUTED, NAVY

log = get_logger(__name__)

STATUS_COLOURS = {
    "Draft": "#6B7A8C",
    "Documents Uploaded": "#1F5F8B",
    "Extraction Completed": "#1F5F8B",
    "Verified": "#B26A00",
    "Analysis Completed": "#2E7D32",
    "Report Generated": "#1B5E20",
}


class CaseManagementScreen(QWidget):
    """Table of every saved case with the actions available on each."""

    open_case_requested = Signal(str)
    edit_case_requested = Signal(str)
    report_requested = Signal(str)
    back_requested = Signal()

    COLUMNS = [
        "Case ID",
        "Assessee",
        "PAN",
        "Financial Year",
        "Date Created",
        "Status",
    ]

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self.cases: List[Case] = []
        self._filtered: List[Case] = []
        self._build()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 22, 30, 22)
        layout.setSpacing(12)

        header = QHBoxLayout()
        title = QLabel("EXISTING CASES")
        title.setObjectName("ScreenTitle")
        header.addWidget(title)
        header.addStretch(1)
        self.count_label = QLabel("")
        self.count_label.setObjectName("Muted")
        header.addWidget(self.count_label)
        layout.addLayout(header)

        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Search:"))
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(
            "Filter by case ID, assessee name, PAN or financial year"
        )
        self.search_box.textChanged.connect(self._apply_search)
        search_row.addWidget(self.search_box, 1)
        layout.addLayout(search_row)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.doubleClicked.connect(lambda _: self.open_selected())
        layout.addWidget(self.table, 1)

        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)
        actions.addStretch(1)

        self.open_button = QPushButton("OPEN")
        self.open_button.clicked.connect(self.open_selected)
        actions.addWidget(self.open_button)

        self.edit_button = QPushButton("EDIT")
        self.edit_button.setObjectName("Secondary")
        self.edit_button.clicked.connect(self.edit_selected)
        actions.addWidget(self.edit_button)

        self.duplicate_button = QPushButton("DUPLICATE")
        self.duplicate_button.setObjectName("Secondary")
        self.duplicate_button.clicked.connect(self.duplicate_selected)
        actions.addWidget(self.duplicate_button)

        self.report_button = QPushButton("GENERATE REPORT")
        self.report_button.setObjectName("Secondary")
        self.report_button.clicked.connect(self.generate_report_for_selected)
        actions.addWidget(self.report_button)

        self.delete_button = QPushButton("DELETE")
        self.delete_button.setObjectName("Danger")
        self.delete_button.clicked.connect(self.delete_selected)
        actions.addWidget(self.delete_button)
        layout.addLayout(actions)

    # ---------------------------------------------------------------- state

    def reload(self) -> None:
        try:
            self.cases = self.db.list_cases()
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not load cases", str(exc))
            self.cases = []
        self._apply_search()

    def _apply_search(self) -> None:
        term = self.search_box.text().strip().lower()
        if not term:
            self._filtered = list(self.cases)
        else:
            self._filtered = [
                case
                for case in self.cases
                if term in (case.case_id or "").lower()
                or term in (case.assessee_name or "").lower()
                or term in (case.pan or "").lower()
                or term in (case.financial_year or "").lower()
            ]
        self._populate()

    def _populate(self) -> None:
        self.table.setRowCount(0)
        for case in self._filtered:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                case.case_id,
                case.assessee_name,
                case.pan or "-",
                case.financial_year or "-",
                case.date_created,
                case.status,
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                if column == 5:
                    item.setForeground(
                        QBrush(QColor(STATUS_COLOURS.get(case.status, "#000000")))
                    )
                self.table.setItem(row, column, item)
        self.count_label.setText(
            f"{len(self._filtered)} of {len(self.cases)} case(s)"
        )
        if self._filtered:
            self.table.selectRow(0)
        self._update_buttons()

    def _update_buttons(self) -> None:
        has_selection = self.selected_case() is not None
        for button in (
            self.open_button,
            self.edit_button,
            self.duplicate_button,
            self.report_button,
            self.delete_button,
        ):
            button.setEnabled(has_selection)

    def selected_case(self) -> Optional[Case]:
        rows = {index.row() for index in self.table.selectedIndexes()}
        if not rows:
            return None
        row = min(rows)
        if 0 <= row < len(self._filtered):
            return self._filtered[row]
        return None

    # -------------------------------------------------------------- actions

    def _require_selection(self) -> Optional[Case]:
        case = self.selected_case()
        if case is None:
            QMessageBox.information(
                self, "No case selected", "Please select a case from the list first."
            )
        return case

    def open_selected(self) -> None:
        case = self._require_selection()
        if case:
            self.open_case_requested.emit(case.case_id)

    def edit_selected(self) -> None:
        case = self._require_selection()
        if case:
            self.edit_case_requested.emit(case.case_id)

    def duplicate_selected(self) -> None:
        case = self._require_selection()
        if not case:
            return
        confirm = QMessageBox.question(
            self,
            "Duplicate case",
            f"Create a new case using the particulars of {case.assessee_name}?\n\n"
            "The new case starts as a Draft. Documents and analysis results are "
            "not copied.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if confirm != QMessageBox.Yes:
            return
        try:
            new_case_id = self.db.duplicate_case(case.case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not duplicate the case", str(exc))
            return
        self.reload()
        QMessageBox.information(
            self, "Case duplicated", f"The new case {new_case_id} has been created."
        )

    def delete_selected(self) -> None:
        case = self._require_selection()
        if not case:
            return
        confirm = QMessageBox.warning(
            self,
            "Delete case",
            f"Permanently delete case {case.case_id} ({case.assessee_name})?\n\n"
            "This removes the case, its uploaded documents, extracted figures, "
            "findings and queries. Generated reports already saved to disk are "
            "not deleted.\n\nThis cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return

        try:
            self.db.delete_case(case.case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not delete the case", str(exc))
            return

        # Remove the case's uploaded copies; failure here is not fatal.
        try:
            folder = case_upload_dir(case.case_id)
            if folder.exists():
                shutil.rmtree(folder, ignore_errors=True)
        except OSError as exc:
            log.warning("Could not remove upload folder for %s: %s", case.case_id, exc)

        self.reload()
        QMessageBox.information(
            self, "Case deleted", f"Case {case.case_id} has been deleted."
        )

    def generate_report_for_selected(self) -> None:
        case = self._require_selection()
        if case:
            self.report_requested.emit(case.case_id)
