"""Settings screen: firm details, thresholds and AI provider configuration."""

from __future__ import annotations

import json
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ..core import ai_provider, ocr_engine
from ..core.logging_setup import get_logger
from ..core.tax_risk_engine import (
    DEFAULT_RISK_THRESHOLDS,
    RISK_THRESHOLDS_FILENAME,
    load_risk_thresholds,
)
from ..database.db import Database, DatabaseError, get_database
from ..paths import config_dir, data_root, logs_dir, reports_dir
from .theme import RISK_COLOURS

log = get_logger(__name__)


class SettingsScreen(QWidget):
    """Application preferences, persisted to ApplicationSettings and JSON."""

    back_requested = Signal()

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self._build()
        self.reload()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(30, 22, 30, 22)
        outer.setSpacing(12)

        title = QLabel("SETTINGS")
        title.setObjectName("ScreenTitle")
        outer.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        scroll.setWidget(container)
        outer.addWidget(scroll, 1)

        body = QVBoxLayout(container)
        body.setSpacing(14)

        body.addWidget(self._firm_box())
        body.addWidget(self._report_box())
        body.addWidget(self._threshold_box())
        body.addWidget(self._ai_box())
        body.addWidget(self._system_box())
        body.addStretch(1)

        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)
        actions.addStretch(1)

        self.reset_button = QPushButton("RESTORE DEFAULTS")
        self.reset_button.setObjectName("Secondary")
        self.reset_button.clicked.connect(self.restore_defaults)
        actions.addWidget(self.reset_button)

        self.save_button = QPushButton("SAVE SETTINGS")
        self.save_button.clicked.connect(self.save)
        actions.addWidget(self.save_button)
        outer.addLayout(actions)

    def _firm_box(self) -> QGroupBox:
        box = QGroupBox("Firm Details")
        form = QFormLayout(box)
        form.setLabelAlignment(Qt.AlignRight)
        self.firm_name = QLineEdit()
        self.firm_name.setPlaceholderText("e.g. Sharma & Associates, Chartered Accountants")
        form.addRow("Firm Name", self.firm_name)
        note = QLabel(
            "The firm name is used on new cases and appears on the report cover page."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        form.addRow("", note)
        return box

    def _report_box(self) -> QGroupBox:
        box = QGroupBox("Report Defaults")
        form = QFormLayout(box)
        form.setLabelAlignment(Qt.AlignRight)

        self.report_font = QComboBox()
        self.report_font.addItems(["Book Antiqua", "Times New Roman", "Georgia", "Cambria"])
        form.addRow("Report Font", self.report_font)

        self.report_body_size = QDoubleSpinBox()
        self.report_body_size.setRange(8.0, 14.0)
        self.report_body_size.setSingleStep(0.5)
        self.report_body_size.setDecimals(1)
        self.report_body_size.setSuffix(" pt")
        form.addRow("Body Text Size", self.report_body_size)

        note = QLabel(
            "Reports are produced on A4 with justified body text, a page header "
            "and a confidentiality footer. If the chosen font is not installed, "
            "Word substitutes Times New Roman automatically."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        form.addRow("", note)
        return box

    def _threshold_box(self) -> QGroupBox:
        box = QGroupBox("Materiality and Risk Thresholds")
        form = QFormLayout(box)
        form.setLabelAlignment(Qt.AlignRight)

        def spin(suffix: str = " %") -> QDoubleSpinBox:
            widget = QDoubleSpinBox()
            widget.setRange(0.0, 100000.0)
            widget.setDecimals(1)
            widget.setSuffix(suffix)
            return widget

        self.threshold_review = spin()
        self.threshold_significant = spin()
        self.threshold_high = spin()
        form.addRow("Movement treated as 'Review'", self.threshold_review)
        form.addRow("Movement treated as 'Significant'", self.threshold_significant)
        form.addRow("Movement treated as 'High Movement'", self.threshold_high)

        self.expense_spike = spin()
        self.expense_high_spike = spin()
        form.addRow("Expense spike queried at", self.expense_spike)
        form.addRow("Expense spike treated as High Risk at", self.expense_high_spike)

        self.cash_to_turnover = spin()
        self.cash_absolute = spin(" Rs.")
        self.cash_absolute.setRange(0.0, 10_000_000_000.0)
        self.cash_absolute.setGroupSeparatorShown(True)
        form.addRow("Cash queried above (% of turnover)", self.cash_to_turnover)
        form.addRow("Cash always queried above", self.cash_absolute)

        note = QLabel(
            "These thresholds control how movements are banded and when a matter "
            "is raised. They affect prioritisation only and have no bearing on "
            "the correctness of any figure."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        form.addRow("", note)
        return box

    def _ai_box(self) -> QGroupBox:
        box = QGroupBox("AI / API Settings")
        layout = QVBoxLayout(box)

        warning = QLabel(ai_provider.DATA_TRANSFER_WARNING)
        warning.setWordWrap(True)
        warning.setStyleSheet(
            f"color: {RISK_COLOURS['HIGH']}; background-color: #FBE9E7; "
            f"border: 1px solid {RISK_COLOURS['HIGH']}; border-radius: 4px; "
            "padding: 10px;"
        )
        layout.addWidget(warning)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)

        self.ai_provider_combo = QComboBox()
        self.ai_provider_combo.addItems(ai_provider.available_providers())
        form.addRow("Provider", self.ai_provider_combo)

        key_row = QHBoxLayout()
        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.Password)
        self.api_key.setPlaceholderText("Paste the API key here")
        key_row.addWidget(self.api_key, 1)

        self.save_key_button = QPushButton("Save Key")
        self.save_key_button.setObjectName("Secondary")
        self.save_key_button.clicked.connect(self.save_api_key)
        key_row.addWidget(self.save_key_button)

        self.delete_key_button = QPushButton("Remove Key")
        self.delete_key_button.setObjectName("Secondary")
        self.delete_key_button.clicked.connect(self.delete_api_key)
        key_row.addWidget(self.delete_key_button)
        form.addRow("API Key", key_row)

        self.key_status = QLabel("")
        self.key_status.setObjectName("Muted")
        form.addRow("", self.key_status)

        self.ai_consent = QCheckBox(
            "I understand that enabling an external AI provider in a future "
            "version would transmit data outside this computer, and I consent."
        )
        self.ai_consent.setStyleSheet("padding: 6px 0;")
        form.addRow("", self.ai_consent)

        layout.addLayout(form)

        status = QLabel(
            "Status: AI-assisted narrative is NOT active. Every observation in "
            "this application is produced by deterministic, rule-based analysis "
            "running on this computer."
        )
        status.setWordWrap(True)
        status.setStyleSheet("font-weight: bold; padding-top: 6px;")
        layout.addWidget(status)
        return box

    def _system_box(self) -> QGroupBox:
        box = QGroupBox("System Information")
        form = QFormLayout(box)
        form.setLabelAlignment(Qt.AlignRight)

        available, message = ocr_engine.availability()
        ocr_label = QLabel(message)
        ocr_label.setWordWrap(True)
        if not available:
            ocr_label.setStyleSheet(f"color: {RISK_COLOURS['MEDIUM']};")
        form.addRow("OCR (scanned documents)", ocr_label)

        for label, path in (
            ("Data folder", data_root()),
            ("Reports folder", reports_dir()),
            ("Configuration folder", config_dir()),
            ("Log file", logs_dir() / "app.log"),
        ):
            value = QLabel(str(path))
            value.setObjectName("Muted")
            value.setTextInteractionFlags(Qt.TextSelectableByMouse)
            value.setWordWrap(True)
            form.addRow(label, value)
        return box

    # ---------------------------------------------------------------- state

    def reload(self) -> None:
        """Load persisted settings into the form."""
        try:
            settings = self.db.all_settings()
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not load settings", str(exc))
            settings = {}

        self.firm_name.setText(settings.get("firm_name", ""))
        font = settings.get("report_font", "Book Antiqua")
        index = self.report_font.findText(font)
        self.report_font.setCurrentIndex(max(index, 0))
        self.report_body_size.setValue(float(settings.get("report_body_size", 11) or 11))

        self.threshold_review.setValue(float(settings.get("threshold_review", 10) or 10))
        self.threshold_significant.setValue(
            float(settings.get("threshold_significant", 20) or 20)
        )
        self.threshold_high.setValue(float(settings.get("threshold_high", 50) or 50))

        thresholds = load_risk_thresholds()
        self.expense_spike.setValue(thresholds["expense_spike_percent"])
        self.expense_high_spike.setValue(thresholds["expense_high_spike_percent"])
        self.cash_to_turnover.setValue(thresholds["cash_to_turnover_percent"])
        self.cash_absolute.setValue(thresholds["cash_absolute"])

        provider = settings.get("ai_provider", "None")
        index = self.ai_provider_combo.findText(provider)
        self.ai_provider_combo.setCurrentIndex(max(index, 0))
        self.ai_consent.setChecked(settings.get("ai_consent_given", "0") == "1")
        self._refresh_key_status()

    def _refresh_key_status(self) -> None:
        provider = self.ai_provider_combo.currentText()
        try:
            key = ai_provider.load_api_key(provider)
        except Exception as exc:
            log.warning("Could not read the stored API key: %s", exc)
            key = None
        if key:
            self.key_status.setText(
                f"A key is stored for {provider}: {ai_provider.mask_key(key)}"
            )
        else:
            self.key_status.setText(f"No API key is stored for {provider}.")

    # -------------------------------------------------------------- actions

    def apply_settings(self) -> Optional[str]:
        """Persist every setting. Returns an error message, or None on success.

        Kept free of dialogs so that the persistence logic can be exercised
        directly by the test suite and reused without user interaction.
        """
        try:
            self.db.set_setting("firm_name", self.firm_name.text().strip())
            self.db.set_setting("report_font", self.report_font.currentText())
            self.db.set_setting(
                "report_body_size", str(self.report_body_size.value())
            )
            self.db.set_setting("threshold_review", str(self.threshold_review.value()))
            self.db.set_setting(
                "threshold_significant", str(self.threshold_significant.value())
            )
            self.db.set_setting("threshold_high", str(self.threshold_high.value()))
            self.db.set_setting("ai_provider", self.ai_provider_combo.currentText())
            self.db.set_setting(
                "ai_consent_given", "1" if self.ai_consent.isChecked() else "0"
            )
        except DatabaseError as exc:
            return f"The settings could not be saved: {exc}"

        thresholds = load_risk_thresholds()
        thresholds["expense_spike_percent"] = self.expense_spike.value()
        thresholds["expense_high_spike_percent"] = self.expense_high_spike.value()
        thresholds["cash_to_turnover_percent"] = self.cash_to_turnover.value()
        thresholds["cash_absolute"] = self.cash_absolute.value()
        try:
            (config_dir() / RISK_THRESHOLDS_FILENAME).write_text(
                json.dumps(thresholds, indent=2), encoding="utf-8"
            )
        except OSError as exc:
            return f"The risk thresholds could not be written to disk: {exc}"
        return None

    def save(self) -> None:
        """Persist the settings and tell the user what happened."""
        error = self.apply_settings()
        if error:
            QMessageBox.critical(self, "Could not save settings", error)
            return
        QMessageBox.information(self, "Settings saved", "Your settings have been saved.")

    def restore_defaults(self) -> None:
        confirm = QMessageBox.question(
            self,
            "Restore defaults",
            "Restore all thresholds and report defaults to their original values?\n\n"
            "Your firm name and any stored API key are not affected.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return

        self.report_font.setCurrentText("Book Antiqua")
        self.report_body_size.setValue(11.0)
        self.threshold_review.setValue(10.0)
        self.threshold_significant.setValue(20.0)
        self.threshold_high.setValue(50.0)
        self.expense_spike.setValue(DEFAULT_RISK_THRESHOLDS["expense_spike_percent"])
        self.expense_high_spike.setValue(
            DEFAULT_RISK_THRESHOLDS["expense_high_spike_percent"]
        )
        self.cash_to_turnover.setValue(
            DEFAULT_RISK_THRESHOLDS["cash_to_turnover_percent"]
        )
        self.cash_absolute.setValue(DEFAULT_RISK_THRESHOLDS["cash_absolute"])
        self.save()

    def save_api_key(self) -> None:
        provider = self.ai_provider_combo.currentText()
        key = self.api_key.text().strip()
        if provider == "None":
            QMessageBox.information(
                self,
                "No provider selected",
                "Select a provider before saving an API key.",
            )
            return
        if not key:
            QMessageBox.information(
                self, "No key entered", "Please paste the API key before saving."
            )
            return
        if not self.ai_consent.isChecked():
            QMessageBox.warning(
                self,
                "Consent required",
                "Please read the warning above and tick the consent box before "
                "storing an API key.",
            )
            return
        try:
            location = ai_provider.save_api_key(provider, key)
        except Exception as exc:
            QMessageBox.critical(self, "Could not save the key", str(exc))
            return
        self.api_key.clear()
        self._refresh_key_status()
        QMessageBox.information(
            self,
            "API key saved",
            f"The key has been stored in {location}.\n\n"
            "No data is transmitted by this version of the application.",
        )

    def delete_api_key(self) -> None:
        provider = self.ai_provider_combo.currentText()
        try:
            ai_provider.delete_api_key(provider)
        except Exception as exc:
            QMessageBox.warning(self, "Could not remove the key", str(exc))
            return
        self._refresh_key_status()
        QMessageBox.information(
            self, "API key removed", f"Any stored key for {provider} has been removed."
        )
