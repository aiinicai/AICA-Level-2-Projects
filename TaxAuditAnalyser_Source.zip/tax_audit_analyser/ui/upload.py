"""Document upload screen with drag-and-drop and background analysis."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtGui import QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core import doc_extractor
from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import DOCUMENT_TYPES, Case, Document
from .theme import BORDER, MUTED, NAVY

log = get_logger(__name__)


class DropArea(QFrame):
    """The dashed drop target. Emits the paths of files dropped onto it."""

    files_dropped = Signal(list)
    browse_requested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setMinimumHeight(130)
        self._set_style(active=False)

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        title = QLabel("Drag and drop financial statements here")
        title.setAlignment(Qt.AlignCenter)
        title.setObjectName("SectionTitle")
        layout.addWidget(title)

        subtitle = QLabel(
            "PDF, Excel, Word, CSV or image files  -  you may drop several at once"
        )
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setObjectName("Muted")
        layout.addWidget(subtitle)

        button = QPushButton("BROWSE FILES")
        button.setObjectName("Secondary")
        button.setMaximumWidth(180)
        button.clicked.connect(self.browse_requested.emit)
        holder = QHBoxLayout()
        holder.addStretch(1)
        holder.addWidget(button)
        holder.addStretch(1)
        layout.addLayout(holder)

    def _set_style(self, active: bool) -> None:
        colour = NAVY if active else BORDER
        background = "#E8EEF5" if active else "#FFFFFF"
        self.setStyleSheet(
            f"QFrame {{ border: 2px dashed {colour}; border-radius: 8px; "
            f"background-color: {background}; }}"
        )

    # ------------------------------------------------------- drag and drop

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self._set_style(active=True)
        else:
            event.ignore()

    def dragLeaveEvent(self, event) -> None:
        self._set_style(active=False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event: QDropEvent) -> None:
        self._set_style(active=False)
        paths: List[str] = []
        for url in event.mimeData().urls():
            local = url.toLocalFile()
            if local:
                paths.append(local)
        if paths:
            self.files_dropped.emit(paths)
            event.acceptProposedAction()
        else:
            event.ignore()


class AnalysisWorker(QObject):
    """Runs extraction and analysis off the GUI thread."""

    progress = Signal(str, int)
    finished = Signal(object)     # AnalysisOutcome
    failed = Signal(str)

    def __init__(self, case: Case, documents: List[Document], db: Database) -> None:
        super().__init__()
        self.case = case
        self.documents = documents
        self.db = db

    def run(self) -> None:
        try:
            from ..core.pipeline import analyse_case, extract_documents

            dataset, errors = extract_documents(
                self.case.case_id,
                self.documents,
                db=self.db,
                progress=lambda message, percent: self.progress.emit(message, percent),
            )
            outcome = analyse_case(
                self.case,
                dataset=dataset,
                db=self.db,
                progress=lambda message, percent: self.progress.emit(message, percent),
            )
            outcome.errors = errors + outcome.errors
            self.finished.emit(outcome)
        except Exception as exc:
            log.exception("Analysis failed for case %s", self.case.case_id)
            self.failed.emit(
                "The analysis could not be completed.\n\n"
                f"{exc}\n\nPlease check logs/app.log for details."
            )


class UploadScreen(QWidget):
    """Upload documents, categorise them and start the analysis."""

    analysis_completed = Signal(object)   # AnalysisOutcome
    back_requested = Signal()

    COLUMNS = ["File Name", "Document Type", "Pages", "Status", "Remove"]

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self.case: Optional[Case] = None
        self.documents: List[Document] = []
        self._thread: Optional[QThread] = None
        self._worker: Optional[AnalysisWorker] = None
        self._build()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 22, 30, 22)
        layout.setSpacing(12)

        header = QHBoxLayout()
        title = QLabel("UPLOAD FINANCIAL STATEMENTS")
        title.setObjectName("ScreenTitle")
        header.addWidget(title)
        header.addStretch(1)
        self.case_label = QLabel("")
        self.case_label.setObjectName("Muted")
        header.addWidget(self.case_label)
        layout.addLayout(header)

        self.drop_area = DropArea()
        self.drop_area.files_dropped.connect(self.add_files)
        self.drop_area.browse_requested.connect(self.browse_for_files)
        layout.addWidget(self.drop_area)

        hint = QLabel(
            "Set the correct document type for each file before starting the "
            "analysis. The document type helps the application interpret the "
            "figures correctly."
        )
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(0, QHeaderView.Stretch)
        header_view.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        layout.addWidget(self.table, 1)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("")
        self.status_label.setObjectName("Muted")
        layout.addWidget(self.status_label)

        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)
        actions.addStretch(1)

        self.analyse_button = QPushButton("START ANALYSIS")
        self.analyse_button.setEnabled(False)
        self.analyse_button.clicked.connect(self.start_analysis)
        actions.addWidget(self.analyse_button)
        layout.addLayout(actions)

    # ---------------------------------------------------------------- state

    def set_case(self, case: Case) -> None:
        """Point the screen at a case and load any documents already uploaded."""
        self.case = case
        self.case_label.setText(f"{case.case_id}  |  {case.assessee_name}")
        try:
            self.documents = self.db.list_documents(case.case_id)
        except DatabaseError as exc:
            QMessageBox.warning(self, "Could not load documents", str(exc))
            self.documents = []
        self.refresh_table()

    def refresh_table(self) -> None:
        self.table.setRowCount(0)
        for document in self.documents:
            self._append_row(document)
        self.analyse_button.setEnabled(bool(self.documents))
        self.status_label.setText(
            f"{len(self.documents)} document(s) ready for analysis."
            if self.documents
            else "No documents have been uploaded yet."
        )

    def _append_row(self, document: Document) -> None:
        row = self.table.rowCount()
        self.table.insertRow(row)

        name_item = QTableWidgetItem(document.file_name)
        name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
        name_item.setToolTip(document.stored_path)
        self.table.setItem(row, 0, name_item)

        type_combo = QComboBox()
        type_combo.addItems(DOCUMENT_TYPES)
        index = type_combo.findText(document.document_type)
        type_combo.setCurrentIndex(max(index, 0))
        type_combo.currentTextChanged.connect(
            lambda text, doc=document: self._change_type(doc, text)
        )
        self.table.setCellWidget(row, 1, type_combo)

        pages_item = QTableWidgetItem(str(document.pages or "-"))
        pages_item.setTextAlignment(Qt.AlignCenter)
        pages_item.setFlags(pages_item.flags() & ~Qt.ItemIsEditable)
        self.table.setItem(row, 2, pages_item)

        status_item = QTableWidgetItem(document.status)
        status_item.setTextAlignment(Qt.AlignCenter)
        status_item.setFlags(status_item.flags() & ~Qt.ItemIsEditable)
        if document.status == "Error":
            status_item.setToolTip(document.error_message or "Extraction failed.")
        self.table.setItem(row, 3, status_item)

        remove = QPushButton("Remove")
        remove.setObjectName("Secondary")
        remove.clicked.connect(lambda _=False, doc=document: self.remove_document(doc))
        self.table.setCellWidget(row, 4, remove)

    def _change_type(self, document: Document, document_type: str) -> None:
        document.document_type = document_type
        if document.id:
            try:
                with self.db.connect() as conn:
                    conn.execute(
                        "UPDATE Documents SET document_type = ? WHERE id = ?",
                        (document_type, document.id),
                    )
            except DatabaseError as exc:
                log.warning("Could not update document type: %s", exc)

    # -------------------------------------------------------------- actions

    def browse_for_files(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Select financial statements",
            "",
            doc_extractor.FILE_DIALOG_FILTER,
        )
        if paths:
            self.add_files(paths)

    def add_files(self, paths: List[str]) -> None:
        """Store each dropped or selected file against the current case."""
        if self.case is None:
            QMessageBox.warning(
                self,
                "No case selected",
                "Please create or open a case before uploading documents.",
            )
            return

        from ..core.pipeline import store_uploaded_file

        skipped: List[str] = []
        added = 0
        for path in paths:
            file_path = Path(path)
            if file_path.is_dir():
                skipped.append(f"{file_path.name} (folders are not supported)")
                continue
            if not doc_extractor.is_supported(file_path):
                skipped.append(f"{file_path.name} (unsupported file type)")
                continue
            try:
                document = store_uploaded_file(
                    self.case.case_id,
                    file_path,
                    self._guess_document_type(file_path),
                    db=self.db,
                )
                self.documents.append(document)
                added += 1
            except Exception as exc:
                log.exception("Could not add %s", path)
                skipped.append(f"{file_path.name} ({exc})")

        if added:
            try:
                self.db.update_case_status(self.case.case_id, "Documents Uploaded")
            except DatabaseError:
                log.debug("Could not update case status.", exc_info=True)
        self.refresh_table()

        if skipped:
            QMessageBox.warning(
                self,
                "Some files were not added",
                "The following files could not be added:\n\n- " + "\n- ".join(skipped),
            )

    @staticmethod
    def _guess_document_type(path: Path) -> str:
        """Pre-select a sensible document type from the file name."""
        name = path.stem.lower().replace("_", " ").replace("-", " ")
        candidates = [
            ("balance sheet", "Balance Sheet"),
            ("profit", "Profit & Loss Account"),
            ("p&l", "Profit & Loss Account"),
            ("pl ", "Profit & Loss Account"),
            ("income", "Profit & Loss Account"),
            ("trial", "Trial Balance"),
            ("3cd", "Form 3CD"),
            ("notes", "Notes to Accounts"),
            ("schedule", "Schedules"),
            ("computation", "Income Tax Computation"),
            ("gst", "GST Annual Return"),
            ("previous", "Previous Year Financial Statements"),
        ]
        for marker, document_type in candidates:
            if marker in name:
                return document_type
        return "Other Documents"

    def remove_document(self, document: Document) -> None:
        confirm = QMessageBox.question(
            self,
            "Remove document",
            f"Remove '{document.file_name}' from this case?\n\n"
            "The uploaded copy will be deleted. Your original file is not affected.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return

        if document.id:
            try:
                self.db.delete_document(document.id)
            except DatabaseError as exc:
                QMessageBox.warning(self, "Could not remove document", str(exc))
                return
        try:
            stored = Path(document.stored_path)
            if stored.exists():
                stored.unlink()
        except OSError as exc:
            log.warning("Could not delete stored file %s: %s", document.stored_path, exc)

        self.documents = [d for d in self.documents if d is not document]
        self.refresh_table()

    # ------------------------------------------------------------- analysis

    def start_analysis(self) -> None:
        if self.case is None or not self.documents:
            return

        self.analyse_button.setEnabled(False)
        self.back_button.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_label.setText("Starting analysis...")

        self._thread = QThread(self)
        self._worker = AnalysisWorker(self.case, list(self.documents), self.db)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.failed.connect(self._on_failed)
        self._thread.start()

    def _on_progress(self, message: str, percent: int) -> None:
        self.status_label.setText(message)
        self.progress_bar.setValue(max(0, min(100, percent)))

    def _cleanup_thread(self) -> None:
        if self._thread is not None:
            self._thread.quit()
            self._thread.wait(5000)
            self._thread = None
        self._worker = None
        self.analyse_button.setEnabled(True)
        self.back_button.setEnabled(True)
        self.progress_bar.setVisible(False)

    def _on_finished(self, outcome) -> None:
        self._cleanup_thread()
        try:
            self.documents = self.db.list_documents(self.case.case_id)
        except DatabaseError:
            log.debug("Could not refresh documents.", exc_info=True)
        self.refresh_table()

        if outcome.errors:
            QMessageBox.warning(
                self,
                "Analysis completed with warnings",
                "The analysis finished, but the following matters were noted:\n\n- "
                + "\n- ".join(outcome.errors[:10]),
            )
        self.status_label.setText(
            f"Analysis complete. {len(outcome.flags)} matter(s) identified."
        )
        self.analysis_completed.emit(outcome)

    def _on_failed(self, message: str) -> None:
        self._cleanup_thread()
        self.status_label.setText("Analysis failed.")
        QMessageBox.critical(self, "Analysis failed", message)
