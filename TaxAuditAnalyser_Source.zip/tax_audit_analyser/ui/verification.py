"""Verification screen: the CA checks and corrects extracted figures."""

from __future__ import annotations

from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.logging_setup import get_logger
from ..database.db import Database, DatabaseError, get_database
from ..database.models import Case, ExtractedFigure
from .theme import CONFIDENCE_BACKGROUNDS, MUTED

log = get_logger(__name__)


def parse_user_amount(text: str) -> Optional[float]:
    """Parse an amount typed by the user, tolerating Indian grouping.

    Accepts "1,23,45,678.90", "(5000)" for negatives, a bare number, or an
    empty string meaning "not available".
    """
    if text is None:
        return None
    cleaned = str(text).strip()
    if not cleaned or cleaned == "-":
        return None
    negative = False
    if cleaned.startswith("(") and cleaned.endswith(")"):
        negative = True
        cleaned = cleaned[1:-1]
    cleaned = cleaned.replace(",", "").replace(" ", "")
    cleaned = cleaned.lstrip("₹").replace("Rs.", "").replace("Rs", "").strip()
    if cleaned.startswith("-"):
        negative = True
        cleaned = cleaned[1:]
    if not cleaned:
        return None
    try:
        value = float(cleaned)
    except ValueError as exc:
        raise ValueError(f"'{text}' is not a valid amount.") from exc
    return -value if negative else value


def format_amount(value: Optional[float]) -> str:
    """Indian-grouped display string."""
    if value is None:
        return ""
    integer, decimal = f"{abs(value):.2f}".split(".")
    if len(integer) > 3:
        head, tail = integer[:-3], integer[-3:]
        parts: List[str] = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        integer = ",".join(parts + [tail])
    text = f"{integer}.{decimal}"
    return f"({text})" if value < 0 else text


class VerificationScreen(QWidget):
    """Editable table of every extracted figure, with provenance."""

    verified = Signal()
    back_requested = Signal()

    COLUMNS = [
        "Financial Head",
        "Current Year",
        "Previous Year",
        "Source Page",
        "Confidence",
        "Edit",
    ]
    COL_HEAD, COL_CY, COL_PY, COL_SOURCE, COL_CONFIDENCE, COL_EDIT = range(6)

    def __init__(
        self, db: Optional[Database] = None, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.db = db or get_database()
        self.case: Optional[Case] = None
        self.figures: List[ExtractedFigure] = []
        self._row_figures: Dict[int, ExtractedFigure] = {}
        self._loading = False
        self._build()

    # ------------------------------------------------------------ interface

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 22, 30, 22)
        layout.setSpacing(12)

        header = QHBoxLayout()
        title = QLabel("VERIFY EXTRACTED FINANCIAL DATA")
        title.setObjectName("ScreenTitle")
        header.addWidget(title)
        header.addStretch(1)
        self.case_label = QLabel("")
        self.case_label.setObjectName("Muted")
        header.addWidget(self.case_label)
        layout.addLayout(header)

        instruction = QLabel(
            "Check each figure against the source document and correct it where "
            "necessary. Rows shaded yellow were extracted with low confidence and "
            "should be checked first. Amounts may be typed with or without commas; "
            "enclose a negative figure in brackets."
        )
        instruction.setObjectName("Muted")
        instruction.setWordWrap(True)
        layout.addWidget(instruction)

        self.summary_label = QLabel("")
        layout.addWidget(self.summary_label)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(False)
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(self.COL_HEAD, QHeaderView.Stretch)
        for column in (
            self.COL_CY,
            self.COL_PY,
            self.COL_SOURCE,
            self.COL_CONFIDENCE,
            self.COL_EDIT,
        ):
            header_view.setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self.table.itemChanged.connect(self._on_item_changed)
        layout.addWidget(self.table, 1)

        actions = QHBoxLayout()
        self.back_button = QPushButton("BACK")
        self.back_button.setObjectName("Secondary")
        self.back_button.clicked.connect(self.back_requested.emit)
        actions.addWidget(self.back_button)
        actions.addStretch(1)

        self.reload_button = QPushButton("RELOAD")
        self.reload_button.setObjectName("Secondary")
        self.reload_button.clicked.connect(self.reload)
        actions.addWidget(self.reload_button)

        self.save_button = QPushButton("SAVE AND RE-ANALYSE")
        self.save_button.clicked.connect(self.save_and_continue)
        actions.addWidget(self.save_button)
        layout.addLayout(actions)

    # ---------------------------------------------------------------- state

    def set_case(self, case: Case) -> None:
        self.case = case
        self.case_label.setText(f"{case.case_id}  |  {case.assessee_name}")
        self.reload()

    def reload(self) -> None:
        if self.case is None:
            return
        try:
            self.figures = self.db.list_extracted_figures(self.case.case_id)
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not load figures", str(exc))
            return
        self._populate()

    def _populate(self) -> None:
        self._loading = True
        try:
            self.table.setRowCount(0)
            self._row_figures.clear()
            for figure in self.figures:
                self._append_row(figure)
        finally:
            self._loading = False

        low = sum(1 for f in self.figures if f.confidence == "Low")
        verified = sum(1 for f in self.figures if f.is_verified)
        message = (
            f"{len(self.figures)} financial head(s) extracted. "
            f"{low} low-confidence. {verified} confirmed by you."
        )
        if low:
            message += "  Please review the highlighted rows before proceeding."
        self.summary_label.setText(message)

    def _append_row(self, figure: ExtractedFigure) -> None:
        row = self.table.rowCount()
        self.table.insertRow(row)
        self._row_figures[row] = figure

        background = QColor(
            CONFIDENCE_BACKGROUNDS.get(figure.confidence, "#FFFFFF")
        )

        head_item = QTableWidgetItem(figure.canonical_head)
        head_item.setFlags(head_item.flags() & ~Qt.ItemIsEditable)
        head_item.setToolTip(
            f"Read from the document as: '{figure.raw_heading}'\n"
            f"Match score: {figure.match_score:.2f}"
        )
        self.table.setItem(row, self.COL_HEAD, head_item)

        cy_item = QTableWidgetItem(format_amount(figure.current_year_amount))
        cy_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table.setItem(row, self.COL_CY, cy_item)

        py_item = QTableWidgetItem(format_amount(figure.previous_year_amount))
        py_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table.setItem(row, self.COL_PY, py_item)

        source = figure.source_document or "Manual entry"
        if figure.source_page:
            source += f", p.{figure.source_page}"
        source_item = QTableWidgetItem(source)
        source_item.setFlags(source_item.flags() & ~Qt.ItemIsEditable)
        source_item.setToolTip(source)
        self.table.setItem(row, self.COL_SOURCE, source_item)

        confidence_combo = QComboBox()
        confidence_combo.addItems(["High", "Medium", "Low"])
        confidence_combo.setCurrentText(figure.confidence or "Medium")
        confidence_combo.currentTextChanged.connect(
            lambda text, f=figure: self._set_confidence(f, text)
        )
        self.table.setCellWidget(row, self.COL_CONFIDENCE, confidence_combo)

        confirm = QPushButton("Confirm" if not figure.is_verified else "Confirmed")
        confirm.setObjectName("Secondary")
        confirm.setEnabled(not figure.is_verified)
        confirm.clicked.connect(
            lambda _=False, f=figure, r=row: self._confirm_row(f, r)
        )
        self.table.setCellWidget(row, self.COL_EDIT, confirm)

        for column in (self.COL_HEAD, self.COL_CY, self.COL_PY, self.COL_SOURCE):
            item = self.table.item(row, column)
            if item is not None:
                item.setBackground(QBrush(background))

    # -------------------------------------------------------------- editing

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        """Validate and store an edited amount, reverting on bad input."""
        if self._loading:
            return
        row = item.row()
        column = item.column()
        if column not in (self.COL_CY, self.COL_PY):
            return
        figure = self._row_figures.get(row)
        if figure is None:
            return

        try:
            value = parse_user_amount(item.text())
        except ValueError as exc:
            QMessageBox.warning(self, "Invalid amount", str(exc))
            self._loading = True
            try:
                original = (
                    figure.current_year_amount
                    if column == self.COL_CY
                    else figure.previous_year_amount
                )
                item.setText(format_amount(original))
            finally:
                self._loading = False
            return

        if column == self.COL_CY:
            figure.current_year_amount = value
        else:
            figure.previous_year_amount = value
        # An amount the auditor has typed is definitive.
        figure.is_verified = True
        figure.confidence = "High"

        self._loading = True
        try:
            item.setText(format_amount(value))
            combo = self.table.cellWidget(row, self.COL_CONFIDENCE)
            if isinstance(combo, QComboBox):
                combo.setCurrentText("High")
            button = self.table.cellWidget(row, self.COL_EDIT)
            if isinstance(button, QPushButton):
                button.setText("Confirmed")
                button.setEnabled(False)
            for col in (self.COL_HEAD, self.COL_CY, self.COL_PY, self.COL_SOURCE):
                cell = self.table.item(row, col)
                if cell is not None:
                    cell.setBackground(QBrush(QColor(CONFIDENCE_BACKGROUNDS["High"])))
        finally:
            self._loading = False

    def _set_confidence(self, figure: ExtractedFigure, confidence: str) -> None:
        figure.confidence = confidence

    def _confirm_row(self, figure: ExtractedFigure, row: int) -> None:
        figure.is_verified = True
        button = self.table.cellWidget(row, self.COL_EDIT)
        if isinstance(button, QPushButton):
            button.setText("Confirmed")
            button.setEnabled(False)

    # -------------------------------------------------------------- actions

    def save(self) -> bool:
        """Persist every edited figure. Returns True on success."""
        if self.case is None:
            return False
        try:
            for figure in self.figures:
                self.db.update_extracted_figure(figure)
            self.db.update_case_status(self.case.case_id, "Verified")
        except DatabaseError as exc:
            QMessageBox.critical(self, "Could not save the figures", str(exc))
            return False
        log.info(
            "Saved %d verified figures for case %s",
            len(self.figures),
            self.case.case_id,
        )
        return True

    def save_and_continue(self) -> None:
        if not self.save():
            return
        low = [f for f in self.figures if f.confidence == "Low"]
        if low:
            proceed = QMessageBox.question(
                self,
                "Low-confidence figures remain",
                f"{len(low)} figure(s) are still marked as low confidence:\n\n"
                + "\n".join(f"  -  {f.canonical_head}" for f in low[:8])
                + "\n\nThe analysis can proceed, but these figures should be "
                "checked against the source documents.\n\nContinue anyway?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if proceed != QMessageBox.Yes:
                return
        self.verified.emit()
