"""Application entry point.

Run from source with::

    python main.py

All paths are resolved through :mod:`tax_audit_analyser.paths`, so the same
entry point works unchanged when frozen by PyInstaller.
"""

from __future__ import annotations

import sys
import traceback
from pathlib import Path

# Allow both `python main.py` from inside the package folder and
# `python -m tax_audit_analyser.main` from the project root.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tax_audit_analyser import __app_name__, __version__  # noqa: E402
from tax_audit_analyser.core.logging_setup import get_logger, setup_logging  # noqa: E402


def _fatal(title: str, message: str) -> int:
    """Report a start-up failure, with a GUI dialog where one is possible."""
    print(f"{title}: {message}", file=sys.stderr)
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox

        app = QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(None, title, message)
    except Exception:
        pass
    return 1


def main() -> int:
    setup_logging()
    log = get_logger(__name__)
    log.info("Starting %s version %s", __app_name__, __version__)

    try:
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication
    except ImportError as exc:
        return _fatal(
            "Missing components",
            "The graphical components (PySide6) could not be loaded.\n\n"
            "Please reinstall the application, or run:\n"
            "    pip install -r requirements.txt\n\n"
            f"Technical detail: {exc}",
        )

    try:
        from tax_audit_analyser.database.db import get_database
        from tax_audit_analyser.paths import assets_dir
        from tax_audit_analyser.ui.main_window import MainWindow
        from tax_audit_analyser.ui.theme import app_stylesheet
    except Exception as exc:
        log.exception("Import failure during start-up")
        return _fatal(
            "Could not start the application",
            f"A required component could not be loaded.\n\nTechnical detail: {exc}",
        )

    app = QApplication(sys.argv)
    app.setApplicationName(__app_name__)
    app.setApplicationVersion(__version__)
    app.setOrganizationName("Tax Audit Analyser")
    app.setStyleSheet(app_stylesheet())

    icon_path = assets_dir() / "app_icon.png"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    try:
        database = get_database()
        log.info("Database ready at %s", database.db_path)
    except Exception as exc:
        log.exception("Database initialisation failed")
        return _fatal(
            "Database error",
            "The application database could not be opened or created.\n\n"
            "Check that you have permission to write to the application data "
            f"folder.\n\nTechnical detail: {exc}",
        )

    try:
        window = MainWindow(database)
        window.show()
    except Exception as exc:
        log.exception("Main window could not be created")
        return _fatal(
            "Could not open the application window",
            f"An unexpected error occurred while starting.\n\nTechnical detail: {exc}",
        )

    return app.exec()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception:
        traceback.print_exc()
        sys.exit(_fatal("Unexpected error", traceback.format_exc()))
