@echo off
REM ===========================================================================
REM  Tax Audit Financial Statement Analyser - Windows build script
REM
REM  Creates a virtual environment, installs the dependencies, and builds a
REM  one-folder Windows distribution with PyInstaller.
REM
REM  Requirements on the build machine:
REM    - Windows 10 or later (64-bit)
REM    - Python 3.11 or later, ticked "Add Python to PATH" during install
REM
REM  Usage: double-click this file, or run it from a Command Prompt opened in
REM  this folder.
REM ===========================================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

set APP_NAME=TaxAuditAnalyser
set VENV_DIR=build_venv
set OUTPUT_DIR=TaxAuditAnalyser_Windows

echo.
echo ============================================================
echo   Building %APP_NAME%
echo ============================================================
echo.

REM --------------------------------------------------------- 1. check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on the PATH.
    echo.
    echo Install Python 3.11 or later from https://www.python.org/downloads/
    echo and be sure to tick "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version') do echo Found %%v

REM ------------------------------------------------- 2. virtual environment
if exist "%VENV_DIR%" (
    echo Reusing the existing build environment in %VENV_DIR%.
) else (
    echo Creating the build environment...
    python -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
)

call "%VENV_DIR%\Scripts\activate.bat"
if errorlevel 1 (
    echo [ERROR] Could not activate the virtual environment.
    pause
    exit /b 1
)

REM ------------------------------------------------------- 3. dependencies
echo.
echo Installing dependencies. This may take several minutes...
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Dependency installation failed. Check your internet connection.
    pause
    exit /b 1
)

python -m pip install pyinstaller
if errorlevel 1 (
    echo [ERROR] PyInstaller could not be installed.
    pause
    exit /b 1
)

REM ------------------------------------------------ 4. run the test suite
echo.
echo Running the test suite before building...
set QT_QPA_PLATFORM=offscreen
python -m pytest tax_audit_analyser\tests -q
if errorlevel 1 (
    echo.
    echo [WARNING] Some tests did not pass.
    set /p CONTINUE="Continue with the build anyway? (Y/N): "
    if /i not "!CONTINUE!"=="Y" (
        echo Build cancelled.
        pause
        exit /b 1
    )
)
set QT_QPA_PLATFORM=

REM ------------------------------------------------------ 5. clean previous
echo.
echo Cleaning previous build output...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "%OUTPUT_DIR%" rmdir /s /q "%OUTPUT_DIR%"

REM ------------------------------------------------------------ 6. build
echo.
echo Building the application with PyInstaller...
echo.

REM The .spec file is authoritative: it lists the bundled data files, the
REM hidden imports and the excluded packages. Use it when present.
if exist "%APP_NAME%.spec" (
    pyinstaller --noconfirm --clean "%APP_NAME%.spec"
) else (
    pyinstaller --noconfirm --clean ^
        --name %APP_NAME% ^
        --windowed ^
        --onedir ^
        --add-data "tax_audit_analyser\database\schema.sql;tax_audit_analyser\database" ^
        --add-data "tax_audit_analyser\assets;tax_audit_analyser\assets" ^
        --hidden-import pdfplumber ^
        --hidden-import pymupdf ^
        --hidden-import pytesseract ^
        --hidden-import docx ^
        --hidden-import openpyxl ^
        --hidden-import keyring.backends.Windows ^
        --exclude-module tkinter ^
        --exclude-module matplotlib ^
        tax_audit_analyser\main.py
)

if errorlevel 1 (
    echo.
    echo [ERROR] The build failed. Review the messages above.
    pause
    exit /b 1
)

REM -------------------------------------------------- 7. collect the output
echo.
echo Copying the build output to %OUTPUT_DIR%...

if not exist "dist\%APP_NAME%" (
    echo [ERROR] Expected build output was not found in dist\%APP_NAME%.
    pause
    exit /b 1
)

xcopy /e /i /y /q "dist\%APP_NAME%" "%OUTPUT_DIR%" >nul
copy /y "README.md" "%OUTPUT_DIR%\README.md" >nul 2>&1
copy /y "USER_MANUAL.md" "%OUTPUT_DIR%\USER_MANUAL.md" >nul 2>&1

echo.
echo ============================================================
echo   BUILD COMPLETED SUCCESSFULLY
echo ============================================================
echo.
echo   Application folder : %CD%\%OUTPUT_DIR%
echo   Program to run     : %OUTPUT_DIR%\%APP_NAME%.exe
echo.
echo   Distribute the WHOLE %OUTPUT_DIR% folder, not just the .exe.
echo.
echo   Optional: to read scanned PDFs, install Tesseract-OCR on the
echo   computer that will run the application:
echo     https://github.com/UB-Mannheim/tesseract/wiki
echo   Without it the application still runs; scanned pages are simply
echo   reported as needing manual entry.
echo.
pause
endlocal
