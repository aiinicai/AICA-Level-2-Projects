# User Manual

## Tax Audit Financial Statement Analyser
### Financial Statement Review & Risk Identification System

---

## Before you begin

This manual is written for a Chartered Accountant using the application for
the first time. **You do not need to know anything about computers beyond
opening a program and clicking buttons.**

You will **never** need to:

- open a command prompt or a "terminal",
- install or understand Python,
- open or edit the database,
- write any code.

Everything is done through the application's own screens.

### What this application is

It is an **analytical assistant**. It reads the financial statements you give
it, checks their arithmetic, compares this year with last year, works out the
usual ratios, and produces a list of matters that deserve your professional
attention — together with a Word report and a set of draft client queries.

### What this application is not

It does **not** give a tax audit opinion. It does **not** decide whether any
provision of law applies. It does **not** compute anyone's tax liability. It
points at things worth looking at; **you** decide what they mean.

Every report it produces says so in writing, in a disclaimer that cannot be
removed.

### Your data stays on your computer

Nothing is uploaded to the internet. Every figure, every client name and every
report stays on the machine you are using.

---

## Contents

1. [Opening the application](#1-opening-the-application)
2. [Creating a case](#2-creating-a-case)
3. [Uploading the financial statements](#3-uploading-the-financial-statements)
4. [Running the analysis](#4-running-the-analysis)
5. [Verifying the figures](#5-verifying-the-figures)
6. [Reviewing the risks](#6-reviewing-the-risks)
7. [Generating auditor queries](#7-generating-auditor-queries)
8. [Downloading the Word report](#8-downloading-the-word-report)
9. [Returning to a saved case](#9-returning-to-a-saved-case)
10. [Settings](#10-settings)
11. [If something goes wrong](#11-if-something-goes-wrong)

---

## 1. Opening the application

Double-click **TaxAuditAnalyser.exe** in the application folder.

> **Tip:** right-click it once and choose *Send to → Desktop (create
> shortcut)*, so that in future you can start it from your desktop.

The home screen appears, with five large buttons:

| Button | What it does |
|---|---|
| **NEW ANALYSIS** | Start work on a new client. |
| **EXISTING CASES** | Go back to a client you have worked on before. |
| **REPORTS** | Open any report the application has produced. |
| **SETTINGS** | Your firm name, and the thresholds used to flag matters. |
| **EXIT** | Close the application. |

The first time you use it, go to **SETTINGS** and type your firm's name. It
will then appear automatically on new cases and on your reports.

---

## 2. Creating a case

A **case** is one client, for one financial year.

Click **NEW ANALYSIS**. Fill in what you know:

| Field | Notes |
|---|---|
| **Assessee Name** | The only compulsory field. |
| **PAN** | Ten characters, e.g. `AACCS1234K`. Typed in lower case, it converts itself to capitals. Leave blank if you do not have it. |
| **Constitution** | Choose from the list — Individual, HUF, Partnership Firm, LLP, Private Limited Company, and so on. This matters: for a firm or a proprietor the application additionally looks for possible personal expenditure. |
| **Nature of Business** | Free text, e.g. "Wholesale trading in textiles". |
| **GSTIN** | Optional. |
| **Financial Year** | Type it as `2024-25`. |
| **Assessment Year** | Fills in by itself once you enter the financial year. |
| **Turnover** | Optional. The application will read the real figure from the accounts. |
| **Tax Audit Applicable** | Yes / No / To be determined. This is only a note to yourself — the application does not decide applicability for you. |
| **Auditor / Firm Name** | Pre-filled from Settings. |
| **Remarks** | Any background notes on the engagement. |

Click **SAVE AND CONTINUE**.

The application allocates a case number such as **TAXAUDIT-2026-0001** and
takes you straight to the upload screen.

> If a field is wrong, a message explains exactly what to correct. Nothing is
> lost — fix it and click save again.

---

## 3. Uploading the financial statements

You can add files in either of two ways:

- **Drag and drop** them from a Windows Explorer window onto the dashed box, or
- click **BROWSE FILES** and pick them.

You can add several at once.

**Accepted files:** PDF, Excel (`.xlsx`, `.xls`), Word (`.docx`), CSV, and
images (`.png`, `.jpg`, `.tiff`) of scanned pages.

Each file appears in the table below:

| Column | Meaning |
|---|---|
| **File Name** | The file you added. Your original file is untouched; the application works on its own copy. |
| **Document Type** | What the file is. |
| **Pages** | How many pages or worksheets were found. |
| **Status** | Uploaded → Processing → Extracted (or Error). |
| **Remove** | Takes the file out of this case. |

### Set the document type

The application guesses the type from the file name, but **please check it**.
Getting it right helps the application read the figures correctly. Click the
drop-down in the *Document Type* column and choose:

Profit & Loss Account · Balance Sheet · Notes to Accounts · Schedules · Trial
Balance · Previous Year Financial Statements · Form 3CD · Income Tax
Computation · GST Annual Return · Other Documents

### What to upload

At a minimum, the **Profit & Loss Account** and the **Balance Sheet**, ideally
showing both the current year and the previous year side by side. The more you
give it — notes, schedules, trial balance — the more it can check.

> **Scanned documents:** if a page is a photograph or a scan with no
> selectable text, the application tries to read it using OCR. If OCR is not
> installed on the computer it will say so plainly and ask you to type those
> figures in yourself on the verification screen. It will not crash, and it
> will not guess.

---

## 4. Running the analysis

Click **START ANALYSIS**.

A progress bar shows what is happening — reading each document, mapping the
headings, checking the accounts, computing ratios, identifying risk areas and
drafting queries. A typical set of accounts takes a few seconds.

The application stays usable throughout; the work happens in the background.

When it finishes you are taken to the **Risk Dashboard**.

If any document could not be read, a message lists which ones and why. The
analysis still proceeds using the documents it *could* read.

---

## 5. Verifying the figures

**This is the most important step. Please do not skip it.**

From the Risk Dashboard, click **VERIFY FIGURES**. You will see the screen
headed **VERIFY EXTRACTED FINANCIAL DATA**.

Every figure the application found is listed:

| Column | Meaning |
|---|---|
| **Financial Head** | What the application decided the line is. Hover your mouse over it to see the exact wording it read from the document. |
| **Current Year** | The figure for this year. **You can type over it.** |
| **Previous Year** | Last year's figure. **You can type over it.** |
| **Source Page** | Which document and page it came from. |
| **Confidence** | How sure the application is: High, Medium or Low. |
| **Edit** | Click *Confirm* to mark a row as checked. |

### Rows shaded yellow

A **yellow row means low confidence** — the application is not sure it read
that line correctly. **Check every yellow row against the original document
first.**

### Correcting a figure

Click on the amount, type the correct one and press Enter.

- Commas are optional: `1,23,45,678.90` and `12345678.90` both work.
- For a negative figure, put it in brackets: `(5,000)`.
- Leave it empty if the figure is not available.

As soon as you type a figure, that row is marked as confirmed by you and its
confidence becomes High — because a figure you have entered is definitive.

### When you are finished

Click **SAVE AND RE-ANALYSE**. The entire analysis runs again using your
corrected figures, and you are returned to the Risk Dashboard.

If any low-confidence rows remain, the application asks whether you still wish
to proceed. You may — but the report will note that those figures were not
verified.

---

## 6. Reviewing the risks

The Risk Dashboard has four coloured tiles at the top:

| Tile | Meaning |
|---|---|
| **HIGH RISK** | Look at these first. |
| **MEDIUM RISK** | Matters that need examination. |
| **REVIEW REQUIRED** | Usually information the application does not have and needs from the client. |
| **INFORMATIONAL** | Statements of fact, for context. |

**Click any tile** to see only those items.

These are priorities for *your* attention. A "High Risk" item does **not**
mean anything is wrong — it means it is the first thing worth looking at.

### The three tabs

**Risk Findings** — one row per matter, showing the risk level, the area, the
observation, the amount, the source document and page, and what verification
is recommended. Use the **Show** drop-down to filter.

**Detailed Findings** — pick any item from the list on the left and the panel
on the right sets out, in full:

- **Issue** — what was noticed
- **Current Year / Previous Year / Change %** — the figures behind it
- **Nature of Finding** — whether it is a fact, a calculation, an observation,
  a potential tax issue, or a matter requiring verification
- **Why Flagged** — the reason the application raised it
- **Tax Audit Relevance** — why it matters for a tax audit
- **Recommended Verification** — the procedure suggested
- **Documents to Verify** — exactly what to ask the client for
- **Potential Form 3CD Reporting Area** — indicative only

**Ratios and Validation** — the twelve ratios for both years, and the results
of the arithmetical checks on the accounts. Hover over any ratio for a
plain-English explanation of what moved and why it may matter.

> **A note on language.** The application never says that a law has been
> broken. It says a matter "requires verification for possible applicability
> of..." That is deliberate. Whether a provision applies is a matter for your
> judgement on the facts, not for a computer.

---

## 7. Generating auditor queries

Click **GENERATE AUDIT QUERIES**.

The application drafts a numbered set of professional queries addressed to the
client, based on the matters it identified — most significant first — each
listing the specific documents to be provided.

They are saved as a Word document, and the application offers to open it. Edit
them as you see fit before sending: they are a first draft prepared for you,
not a letter to be issued unread.

---

## 8. Downloading the Word report

Click **GENERATE WORD REPORT**.

The report is saved as a Word document and the application offers to open it
straight away.

It is set on A4 in Book Antiqua, with justified text, a header, a
confidentiality footer and page numbers, and contains fourteen sections:

1. Executive Summary
2. Documents Analysed
3. Financial Snapshot
4. Year-on-Year Analysis
5. Key Ratios
6. High-Risk Areas
7. Medium-Risk Areas
8. Expense Analysis
9. Loans and Deposits Review
10. Statutory and Tax Audit Review
11. Potential Form 3CD Reporting Areas
12. Documents and Information Required
13. Auditor Queries
14. Conclusion, followed by the mandatory disclaimer

It is an ordinary Word file. Edit it, put it on your letterhead, add your own
observations, delete what does not apply — it is your working paper.

> **The disclaimer must remain.** It records that the report is a preliminary
> analytical document and not an audit opinion.

To find reports later, use **REPORTS** on the home screen, which lists every
report with its client, date and size. Select one and click **Open**.

---

## 9. Returning to a saved case

Everything is saved automatically as you go. You can close the application at
any point and pick up where you left off.

Click **EXISTING CASES** on the home screen. You will see every case with its
number, client, PAN, financial year, date and status:

| Status | Meaning |
|---|---|
| **Draft** | Created, nothing uploaded yet. |
| **Documents Uploaded** | Files added, not yet analysed. |
| **Extraction Completed** | Figures read from the documents. |
| **Verified** | You have checked the figures. |
| **Analysis Completed** | Findings are ready. |
| **Report Generated** | A report has been produced. |

Use the **Search** box to find a case by name, PAN, case number or year.

Select a case, then:

| Button | What it does |
|---|---|
| **OPEN** | Reopens it at the most useful screen for its status. |
| **EDIT** | Change the client's particulars. |
| **DUPLICATE** | Create a new case with the same particulars — useful for the next year's audit. Documents and findings are not copied. |
| **GENERATE REPORT** | Produce a fresh report without reopening the case. |
| **DELETE** | Removes the case and its documents permanently. You are asked to confirm. Reports already saved are not deleted. |

Double-clicking a row opens it.

---

## 10. Settings

**Firm Details** — your firm's name, used on new cases and on report covers.

**Report Defaults** — the font and body text size for reports. If the font is
not installed on your computer, Word substitutes Times New Roman.

**Materiality and Risk Thresholds** — how big a movement has to be before the
application comments on it:

| Setting | Default | Meaning |
|---|---|---|
| Movement treated as 'Review' | 10% | Year-on-year change worth noting |
| Movement treated as 'Significant' | 20% | |
| Movement treated as 'High Movement' | 50% | |
| Expense spike queried at | 40% | An expense head rising this much is raised |
| Expense spike treated as High Risk at | 75% | |
| Cash queried above (% of turnover) | 2% | |
| Cash always queried above | Rs. 20,00,000 | |

Lower these to see more matters; raise them to see fewer. They affect
prioritisation only — never the correctness of any figure. **RESTORE
DEFAULTS** puts them all back.

**AI / API Settings** — for a possible future version. **This version never
sends your data anywhere.** The screen carries a warning to that effect, and
requires you to tick a consent box before any key can even be stored. You may
ignore this section entirely.

**System Information** — whether OCR is available on this computer, and where
your data, reports, configuration and log file are kept.

---

## 11. If something goes wrong

**A document shows "Error"** — hover over the word to see why. The usual
causes are a password-protected PDF, a corrupted file, or an old `.doc` file
(save it as `.docx` and try again). Remove the file and carry on; the other
documents are unaffected.

**Figures are missing or wrong** — this is exactly what the verification
screen is for. Go to **VERIFY FIGURES** and type in the correct amounts. If a
head is missing entirely, the application did not recognise that line; enter
the figure against the nearest correct head.

**"OCR unavailable"** — the computer cannot read scanned pages. Either type
those figures in manually, or ask your IT support to install *Tesseract-OCR*.
The application works perfectly well without it for ordinary digital PDFs.

**The Balance Sheet shows a mismatch** — the application is telling you that
Total Assets and Total Equity & Liabilities do not agree, or that the
individual balances do not add up to the reported total. Check first whether
some lines were misread (verification screen); if the figures are right, the
difference exists in the accounts themselves and needs to be resolved.

**The report will not open** — make sure a previous copy of the same report is
not already open in Word. The **REPORTS** screen shows where each file is
saved.

**Something else** — the application keeps a log. Its exact location is shown
at the bottom of the **SETTINGS** screen under *Log file*. If you need
technical help, send that file.

---

## A closing reminder

This application reads what you give it and applies arithmetic and
configured thresholds. It has not seen the books of account, the vouchers, the
agreements or the client. It cannot exercise judgement.

Its findings are the **beginning** of your review, not the end of it. The
audit, and the responsibility for it, remain entirely yours.
