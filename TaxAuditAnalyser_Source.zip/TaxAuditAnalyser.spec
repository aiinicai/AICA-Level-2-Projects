# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller specification for the Tax Audit Financial Statement Analyser.

Build a one-folder distribution with:

    pyinstaller --noconfirm TaxAuditAnalyser.spec

The application resolves every path through ``tax_audit_analyser/paths.py``,
which uses ``sys._MEIPASS`` when frozen. Read-only resources (the SQL schema
and the assets folder) are bundled here; writable data (database, uploads,
reports, logs) is created under the user's LOCALAPPDATA at run time.
"""

import os
from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

PACKAGE = "tax_audit_analyser"

# Read-only resources that must ship inside the bundle. The destination paths
# mirror the source layout so paths.resource_path() finds them unchanged.
datas = [
    (os.path.join(PACKAGE, "database", "schema.sql"), os.path.join(PACKAGE, "database")),
    (os.path.join(PACKAGE, "assets"), os.path.join(PACKAGE, "assets")),
]

# Modules imported lazily (inside functions) that PyInstaller's static analysis
# can miss, plus the keyring backends chosen at run time on Windows.
hiddenimports = [
    "pdfplumber",
    "pymupdf",
    "fitz",
    "pytesseract",
    "PIL",
    "PIL.Image",
    "docx",
    "openpyxl",
    "pandas",
    "keyring",
    "keyring.backends",
    "keyring.backends.Windows",
    "sqlite3",
]
hiddenimports += collect_submodules("keyring.backends")

# Trim the bundle: these are pulled in transitively but never used.
excludes = [
    "tkinter",
    "matplotlib",
    "notebook",
    "IPython",
    "pytest",
    "reportlab",       # only needed to generate test fixtures
    "PySide6.QtWebEngineCore",
    "PySide6.QtWebEngineWidgets",
    "PySide6.Qt3DCore",
    "PySide6.QtMultimedia",
    "PySide6.QtQuick",
    "PySide6.QtQml",
]

a = Analysis(
    [os.path.join(PACKAGE, "main.py")],
    pathex=[os.path.abspath(".")],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

_icon = os.path.join(PACKAGE, "assets", "app_icon.ico")

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="TaxAuditAnalyser",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,              # windowed application, no console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=_icon if os.path.exists(_icon) else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="TaxAuditAnalyser",
)
