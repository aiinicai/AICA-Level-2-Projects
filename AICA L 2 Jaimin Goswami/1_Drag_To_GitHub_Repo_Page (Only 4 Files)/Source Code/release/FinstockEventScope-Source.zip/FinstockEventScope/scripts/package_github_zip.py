import os
import shutil
import zipfile
from pathlib import Path

source_app = Path(r"c:\Users\ADMIN\Desktop\Capstone\Application\FinstockEventScope-TradingView")
github_dir = Path(r"C:\Users\ADMIN\Desktop\Capstone\Github")
github_dir.mkdir(parents=True, exist_ok=True)

zip_path = github_dir / "FinstockEventScope_Windows_Portable.zip"

instructions_content = """================================================================================
FINSTOCK EVENTSCOPE - FINANCIAL EVENT INTELLIGENCE TERMINAL
ICAI Capstone Project Submission
================================================================================

HOW TO RUN ON ANY WINDOWS PC (NO INSTALLATION / NO PYTHON REQUIRED):
--------------------------------------------------------------------------------
1. Extract all files from this ZIP archive to any folder (e.g. Desktop).
2. Open the extracted "FinstockEventScope" folder.
3. Double-click "FinstockEventScope.exe".
4. The terminal will start immediately with the complete multi-asset calendar,
   all 2,787 audited live records (RBI MPC, SEBI, NSE, US Fed), and full offline access!

SYSTEM REQUIREMENTS:
--------------------------------------------------------------------------------
- Operating System: Windows 10 or Windows 11 (64-bit)
- Python Required: NO (Embedded standalone runtime - zero installation needed)
- Internet Required: NO for viewing, searching and analyzing existing 2,787 events;
                     YES only when fetching new live feeds or using Gemini AI.

KEY TERMINAL SECTIONS:
--------------------------------------------------------------------------------
- Dashboard: Executive terminal overview and market metrics
- Unified Calendar: 2026 interactive calendar grid (Month / Week / Day view)
- Economic Events: RBI MPC decisions, MoSPI GDP, CPI, IIP, WPI & Global G20 rates
- Corporate Announcements: NSE earnings, board meetings, dividends, IPO listings
- Regulatory Updates: Official SEBI Master Circulars, RBI notifications & NSE orders
- Historical Database: Search archived historical records and audit revisions
================================================================================
"""

# Also write HOW_TO_RUN.txt directly into the Github directory for immediate reading
(github_dir / "HOW_TO_RUN.txt").write_text(instructions_content, encoding="utf-8")

print(f"Creating portable standalone ZIP: {zip_path}...")
base_folder = "FinstockEventScope"

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    # 1. Add instructions
    zf.writestr(f"{base_folder}/HOW_TO_RUN.txt", instructions_content)
    
    # 2. Add executable
    exe = source_app / "FinstockEventScope.exe"
    if exe.exists():
        zf.write(exe, f"{base_folder}/{exe.name}")
        print("Added FinstockEventScope.exe")
        
    # 3. Add Sample files
    for sample_file in ["Sample_Financial_Events.xlsx", "Sample_Financial_Events.csv", "README.md"]:
        p = source_app / sample_file
        if p.exists():
            zf.write(p, f"{base_folder}/{p.name}")
            print(f"Added {p.name}")
            
    # 4. Add data/eventscope.db
    db_file = source_app / "data" / "eventscope.db"
    if db_file.exists():
        zf.write(db_file, f"{base_folder}/data/eventscope.db")
        print(f"Added data/eventscope.db ({db_file.stat().st_size:,} bytes)")
        
    # 5. Add docs/
    docs_dir = source_app / "docs"
    if docs_dir.exists():
        for item in docs_dir.rglob("*"):
            if item.is_file():
                rel = item.relative_to(source_app)
                zf.write(item, f"{base_folder}/{rel.as_posix()}")
        print("Added docs/")
        
    # 6. Add _internal/
    internal_dir = source_app / "_internal"
    if internal_dir.exists():
        count = 0
        for item in internal_dir.rglob("*"):
            if item.is_file() and "__pycache__" not in item.parts:
                rel = item.relative_to(source_app)
                zf.write(item, f"{base_folder}/{rel.as_posix()}")
                count += 1
        print(f"Added _internal/ ({count} files)")

print(f"ZIP archive created successfully! Size: {zip_path.stat().st_size:,} bytes")

# 7. Copy Source Code ZIP as well
src_zip = Path(r"c:\Users\ADMIN\Desktop\Capstone\Application\FinstockEventScope-Source.zip")
if src_zip.exists():
    shutil.copy2(src_zip, github_dir / "FinstockEventScope_Source_Code.zip")
    print(f"Copied FinstockEventScope_Source_Code.zip to {github_dir}")

# Verify ZIP integrity
with zipfile.ZipFile(zip_path, "r") as zf:
    bad = zf.testzip()
    if bad is None:
        print("ZIP integrity test PASSED: 100% clean archive.")
    else:
        print(f"ZIP corrupted at: {bad}")
