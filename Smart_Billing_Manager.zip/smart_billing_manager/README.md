# Smart Billing Manager

Simple desktop billing software for creating, storing, printing and exporting invoices professionally.

## Features

- Create invoices with customer details, item details, discount, tax and status.
- Store invoices locally using SQLite database.
- Print invoices through generated PDF.
- Export invoices to PDF.
- Export billing reports to CSV and Excel.
- Dashboard showing today's, weekly, monthly and yearly billing.
- Customer master and invoice search.
- Business settings: name, address, currency, VAT/tax rate, bank details and footer note.

## Installation

1. Install Python 3.10 or later.
2. Open this folder in Command Prompt / Terminal.
3. Install optional dependencies:

```bash
pip install -r requirements.txt
```

4. Run the software:

```bash
python app.py
```

## Windows Shortcut

Double-click `run_smart_billing_manager.bat` after Python is installed.

## Build Windows EXE Optional

Install PyInstaller:

```bash
pip install pyinstaller reportlab openpyxl
pyinstaller --onefile --windowed --name "Smart Billing Manager" app.py
```

The EXE will be created in the `dist` folder.

## Notes

- The database file is created automatically in the same folder as `app.py`.
- Keep backup of `smart_billing_manager.db` regularly.
- PDF export requires ReportLab.
- Excel export requires OpenPyXL.
