@echo off
cd /d "%~dp0"
pip install pyinstaller reportlab openpyxl
pyinstaller --onefile --windowed --name "Smart Billing Manager" app.py
pause
