const g0 = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
const g2 = new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const g3 = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 3 });
const M = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const ok = (v: unknown): v is number => typeof v === "number" && isFinite(v);
const sg = (v: number) => (v < 0 ? "−" : "");

export const inr = (v?: number | null) => (!ok(v) ? "—" : sg(v) + "₹" + g0.format(Math.abs(Math.round(v))));
export const sinr = (v?: number | null) => (ok(v) && v > 0 ? "+" : "") + inr(v);
export const px = (v?: number | null) => (!ok(v) ? "—" : sg(v) + "₹" + g2.format(Math.abs(v)));
export const short = (v?: number | null) => {
  if (!ok(v)) return "—";
  const a = Math.abs(v);
  if (a >= 1e7) return sg(v) + "₹" + (a / 1e7).toFixed(2) + " Cr";
  if (a >= 1e5) return sg(v) + "₹" + (a / 1e5).toFixed(2) + " L";
  return inr(v);
};
export const sshort = (v?: number | null) => (ok(v) && v > 0 ? "+" : "") + short(v);
export const pct = (v?: number | null, d = 1) =>
  !ok(v) ? "—" : (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v * 100).toFixed(d) + "%";
export const share = (v?: number | null, d = 1) => (!ok(v) ? "—" : (v * 100).toFixed(d) + "%");
export const qty = (v?: number | null) => (!ok(v) ? "—" : g3.format(v));
export const num2 = (v?: number | null) => (!ok(v) ? "—" : g2.format(v));
export const day = (s?: string | null) => (s ? `${+s.slice(8, 10)} ${M[+s.slice(5, 7) - 1]} ${s.slice(0, 4)}` : "—");
export const mon = (s: string) => `${M[+s.slice(5, 7) - 1]} ${s.slice(2, 4)}`;
export const isoText = (t: string) => t.replace(/\d{4}-\d{2}-\d{2}/g, (m) => day(m));

export const CLASSES = ["Mutual funds", "Equity shares", "Bank balances", "Term deposits"] as const;
export const CLS_COLOR: Record<string, string> = {
  "Mutual funds": "var(--mf)", "Equity shares": "var(--eq)", "Bank balances": "var(--bank)", "Term deposits": "var(--fd)",
};
export const CCY_COLOR: Record<string, string> = { INR: "var(--inr)", USD: "var(--usd)" };
export const KIND_COLOR: Record<string, string> = {
  SIP: "var(--mf)", Insurance: "var(--bank)", "House tax and maintenance": "var(--fd)",
};
