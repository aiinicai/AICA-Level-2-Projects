/* eslint-disable @typescript-eslint/no-explicit-any */
import Engine from "@/lib/engine.js";
import Life from "@/lib/life.js";
import { data } from "./data";

export const E: any = new (Engine as any)(data);
export const L: any = new (Life as any)(data);
export const LifeStatic: any = Life;
export const EngineStatic: any = Engine;

export type FKey = "account" | "bank" | "fh" | "sector" | "category" | "ccy" | "cls" | "key" | "atype";
export type Filters = Partial<Record<FKey, string>>;
export type Line = {
  cls: string; account: string; key: string; name: string; fh: string | null; sector: string | null;
  category: string | null; ccy: string; fx: number; qty?: number; avg?: number; cost: number; value: number;
  price?: number | null; pdate?: string | null; bank: string | null; kind?: string; local?: number;
  principal?: number; start?: string; maturity?: string; rate?: number; matured?: boolean; daysLeft?: number; atype: string;
};
export type Sum = { value: number; cost: number; gain: number; pct: number | null };
export type Ctx = {
  on: string; setOn: (d: string) => void; F: Filters; setF: (f: Filters) => void; toggle: (k: FKey, v: string) => void;
};

export const lines = (on: string, F: Filters): Line[] => E.filtered(on, F);
export const sum = (ls: Line[]): Sum => E.sum(ls);

/** Groups lines and lets the engine total each group. */
export function groupSum(ls: Line[], by: (l: Line) => string | null | undefined) {
  const m = new Map<string, Line[]>();
  ls.forEach((l) => {
    const k = by(l);
    if (k == null) return;
    const a = m.get(k) ?? [];
    a.push(l);
    m.set(k, a);
  });
  return [...m].map(([k, v]) => ({ k, name: v[0]!.name, lines: v, ...sum(v) })).sort((a, b) => b.value - a.value);
}

export const isHolding = (l: Line) => l.cls === "Mutual funds" || l.cls === "Equity shares";

export type Sheet = { name: string; cols: { h: string; num?: boolean }[]; rows: (string | number | null)[][] };
export const sheetsRef: { current: Sheet[] } = { current: [] };
export const extraRef: { current: [string, string | number][] } = { current: [] };
