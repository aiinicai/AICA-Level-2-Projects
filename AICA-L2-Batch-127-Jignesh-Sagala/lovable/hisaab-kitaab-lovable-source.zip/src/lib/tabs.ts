export const TABS = [
  { name: "Overview", what: "Your whole portfolio in one view", slicers: true },
  { name: "Mutual Funds", what: "Your mutual fund holdings", slicers: true },
  { name: "Equity shares", what: "Your shares across demat accounts", slicers: true },
  { name: "Bank and Deposits", what: "Bank balances and term deposits", slicers: true },
  { name: "Property and Rent", what: "Your property and rent received", slicers: false },
  { name: "Insurance", what: "Your insurance policies", slicers: false },
  { name: "Cash Calendar", what: "Money you have committed over the next 12 months", slicers: false },
  { name: "Data checks", what: "Checks on the data file", slicers: true },
  { name: "NRI DTAA", what: "Tax treaty notes for non-residents", slicers: false },
] as const;
