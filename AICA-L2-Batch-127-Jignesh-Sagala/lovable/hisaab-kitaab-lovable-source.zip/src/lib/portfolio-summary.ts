import { CLASSES } from "./format";
import { E, sum, type Line, type Sum } from "./store";

export type PortfolioSnapshot = {
  on: string;
  previousOn: string | null;
  filtered: boolean;
  count: number;
  current: Sum;
  previous: Sum | null;
  classes: { name: typeof CLASSES[number]; value: number; sharePercent: number | null }[];
  change: { value: number; pct: number | null } | null;
};

/** All amounts come from the engine; ratios describe those amounts without inference. */
export function buildPortfolioSnapshot(on: string, previousOn: string | null, currentLines: Line[], previousLines: Line[], filtered: boolean): PortfolioSnapshot {
  const current = sum(currentLines);
  const previous = previousOn ? sum(previousLines) : null;
  const byClass = E.byClass(currentLines) as Record<string, { value: number; cost: number }>;
  const change = previous ? current.value - previous.value : null;
  return {
    on, previousOn, filtered, count: currentLines.length, current, previous,
    classes: CLASSES.map((name) => {
      const value = byClass[name]?.value ?? 0;
      return { name, value, sharePercent: current.value > 0 ? value / current.value * 100 : null };
    }),
    change: change === null || previous === null ? null : { value: change, pct: previous.value > 0 ? change / previous.value : null },
  };
}
