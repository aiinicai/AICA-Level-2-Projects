import type { Sheet } from "./store";

export async function exportXlsx(page: string, on: string, label: string, filters: string, sheets: Sheet[], extra: [string, string | number][]) {
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const s = wb.addWorksheet("Summary");
  const rows: [string, string | number][] = [["Hisaab Kitaab", ""], ["Page", page], ["As on", on], ["Data", label], ["Filters", filters], ...extra];
  rows.forEach((r) => s.addRow(r));
  s.getColumn(1).font = { bold: true, name: "Arial" };
  s.getColumn(1).width = 18;
  s.getColumn(2).width = 60;
  rows.forEach((r, i) => { if (typeof r[1] === "number") s.getCell(i + 1, 2).numFmt = "#,##0.00"; });
  const used = new Set<string>(["Summary"]);
  sheets.forEach((sh) => {
    let n = sh.name.slice(0, 31);
    while (used.has(n)) n = n.slice(0, 28) + used.size;
    used.add(n);
    const ws = wb.addWorksheet(n);
    ws.addRow(sh.cols.map((c) => c.h));
    ws.getRow(1).font = { bold: true, name: "Arial" };
    sh.rows.forEach((r) => ws.addRow(r));
    sh.cols.forEach((c, i) => {
      const col = ws.getColumn(i + 1);
      col.width = c.num ? 16 : 30;
      col.alignment = { horizontal: c.num ? "right" : "left" };
      if (c.num) col.numFmt = "#,##0.00";
    });
  });
  const buf = await wb.xlsx.writeBuffer();
  const url = URL.createObjectURL(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `Hisaab-Kitaab_${page.replace(/\s+/g, "-")}_${on}.xlsx`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportPdf(page: string, date: string) {
  const t = document.title;
  document.title = `Hisaab Kitaab - ${page} - ${date}`;
  window.print();
  document.title = t;
}
