import raw from "@/data/hisaab.json";

type Cell = string | boolean;
type Table = { cols: string[]; rows: Cell[][] };
type Row = Record<string, Cell>;

const expand = (t: Table): Row[] =>
  t.rows.map((r) => Object.fromEntries(t.cols.map((c, i) => [c, r[i] as Cell])));

const R = raw as unknown as Record<string, Table> & {
  meta: { label: string; latest: string; built: string; open: string };
  owner: string;
  pan: string;
  birth: string;
};

export const data = {
  meta: R.meta,
  owner: R.owner,
  pan: R.pan,
  birth: R.birth,
  instruments: expand(R["instruments"]!),
  tx: expand(R["tx"]!),
  prices: expand(R["prices"]!),
  bank: expand(R["bank"]!),
  fd: expand(R["fd"]!),
  cash: expand(R["cash"]!),
  checks: expand(R["checks"]!),
  sip: expand(R["sip"]!),
  props: expand(R["props"]!),
  rent: expand(R["rent"]!),
  ins: expand(R["ins"]!),
};
export type Data = typeof data;
