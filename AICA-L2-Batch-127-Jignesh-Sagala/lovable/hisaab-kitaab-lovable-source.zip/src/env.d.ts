declare module "*.html?raw" { const s: string; export default s; }
declare module "@/lib/engine.js" { const E: any; export default E; }
declare module "@/lib/life.js" { const L: any; export default L; }
