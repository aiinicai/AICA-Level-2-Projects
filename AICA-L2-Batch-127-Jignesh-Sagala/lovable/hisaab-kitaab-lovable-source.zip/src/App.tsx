import { useCallback, useEffect, useState } from "react";
import { LayoutDashboard, PieChart, LineChart, Landmark, Home, ShieldCheck, CalendarDays, ListChecks, Globe2, Moon, Sun, FileSpreadsheet, FileText } from "lucide-react";
import { TABS } from "@/lib/tabs";
import { data } from "@/lib/data";
import { day } from "@/lib/format";
import { E, extraRef, sheetsRef, type Ctx, type Filters, type FKey } from "@/lib/store";
import { exportPdf, exportXlsx } from "@/lib/exporter";
import Overview from "@/components/Overview";
import { Equity, MutualFunds } from "@/components/Holdings";
import Bank from "@/components/Bank";
import { CashCalendar, Insurance, Property } from "@/components/LifePages";
import { Checks, Dtaa } from "@/components/Misc";
import Slicers, { filterText } from "@/components/Slicers";

const ICONS = [LayoutDashboard, PieChart, LineChart, Landmark, Home, ShieldCheck, CalendarDays, ListChecks, Globe2];
const DATES = E.timeline(E.latest) as string[];

export default function Index() {
  const [tab, setTab] = useState(0);
  const [on, setOn] = useState<string>(data.meta.latest);
  const [F, setF] = useState<Filters>({});
  const [dark, setDark] = useState(false);
  useEffect(() => { try { setDark(localStorage.getItem("hk-theme") === "dark"); } catch { /* ignore */ } }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try { localStorage.setItem("hk-theme", dark ? "dark" : "light"); } catch { /* ignore */ }
    const before = () => document.documentElement.classList.remove("dark");
    const after = () => document.documentElement.classList.toggle("dark", dark);
    window.addEventListener("beforeprint", before);
    window.addEventListener("afterprint", after);
    return () => { window.removeEventListener("beforeprint", before); window.removeEventListener("afterprint", after); };
  }, [dark]);
  const toggle = useCallback((k: FKey, v: string) => setF((f) => {
    const n = { ...f };
    if (n[k] === v) delete n[k];
    else { n[k] = v; if (k === "bank") delete n.account; if (k === "account") delete n.bank; }
    return n;
  }), []);
  const t = TABS[tab]!;
  const ctx: Ctx = { on, setOn, F, setF, toggle };
  sheetsRef.current = [];
  extraRef.current = [];
  const page = [<Overview key={0} {...ctx} />, <MutualFunds key={1} {...ctx} />, <Equity key={2} {...ctx} />, <Bank key={3} {...ctx} />, <Property key={4} {...ctx} />, <Insurance key={5} {...ctx} />, <CashCalendar key={6} {...ctx} />, <Checks key={7} />, <Dtaa key={8} />][tab];
  const btn = "inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-accent";

  return (
    <div className="flex min-h-screen flex-col bg-background md:flex-row">
      <aside className="no-print flex shrink-0 flex-col bg-sidebar text-sidebar-foreground md:sticky md:top-0 md:h-screen md:w-60">
        <div className="border-b border-sidebar-border px-5 py-5">
          <div className="text-lg font-extrabold tracking-tight text-sidebar-accent-foreground">Hisaab Kitaab</div>
          <div className="mt-1 text-xs"><span className="font-semibold text-sidebar-primary">{data.owner}</span> · PAN {data.pan}</div>
        </div>
        <nav aria-label="Pages" className="flex gap-1 overflow-x-auto p-2 md:flex-col md:overflow-visible">
          {TABS.map((x, i) => {
            const I = ICONS[i]!;
            const act = i === tab;
            return (
              <button key={x.name} onClick={() => setTab(i)} aria-current={act ? "page" : undefined}
                className={`flex shrink-0 items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${act ? "bg-sidebar-accent text-sidebar-accent-foreground" : "hover:bg-sidebar-accent/60"}`}>
                <I className={`h-4 w-4 ${act ? "text-sidebar-primary" : ""}`} strokeWidth={1.75} aria-hidden />{x.name}
              </button>
            );
          })}
        </nav>
      </aside>

      <main className="min-w-0 flex-1 p-4 md:p-8">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h1 className="text-2xl font-extrabold tracking-tight md:text-3xl">{t.name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{tab === 8 ? "Bonus for non-resident Indians. Sample data, all fictional." : `${t.what}. ${data.meta.label}. Values in INR.`}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {tab === 8 ? (
              <span className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold">Sample page</span>
            ) : (
              <label className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold">
                <span className="text-muted-foreground">As on</span>
                <select aria-label="As-on date" value={on} onChange={(e) => setOn(e.target.value)} className="bg-transparent font-semibold">
                  {DATES.map((d) => <option key={d} value={d}>{day(d)}</option>)}
                </select>
              </label>
            )}
            <button className={`no-print ${btn}`} onClick={() => void exportXlsx(t.name, on, data.meta.label, filterText(F), sheetsRef.current, extraRef.current)}>
              <FileSpreadsheet className="h-4 w-4" aria-hidden /> Export Excel (.xlsx)
            </button>
            <button className={`no-print ${btn}`} onClick={() => exportPdf(t.name, day(on))}><FileText className="h-4 w-4" aria-hidden /> Export PDF</button>
            <button onClick={() => setDark((d) => !d)} aria-label={dark ? "Switch to light theme" : "Switch to dark theme"} className="no-print rounded-lg border border-border bg-card p-2 hover:bg-accent">
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </header>
        {t.slicers && <Slicers {...ctx} />}
        <div className="mt-6">{page}</div>
      </main>
    </div>
  );
}
