/* eslint-disable @typescript-eslint/no-explicit-any */
import { useReducedMotion } from "framer-motion";
import { CartesianGrid, Legend, Line as RLine, LineChart, ResponsiveContainer, Tooltip, Treemap, XAxis, YAxis } from "recharts";
import { day, inr, mon, pct, px, qty, short, sshort } from "@/lib/format";
import { E, groupSum, lines, sheetsRef, sum, type Ctx, type Line } from "@/lib/store";
import { axisTick, type Col, DataTable, Delta, Empty, Grid, HBars, Kpi, KpiRow, Panel, Tip, toSheet, VBars } from "./kit";

const gainCell = (v: number | null) => <Delta v={v} text={pct(v)} />;

function buys(on: string, F: any, kind: string) {
  const o = E.buysByMonth(on, F, kind) as Record<string, number>;
  return Object.keys(o).sort().map((m) => ({ label: mon(m + "-01"), Amount: o[m] }));
}

function ValueCost({ on, F, cls }: { on: string; F: any; cls: string }) {
  const rm = useReducedMotion();
  const ts = E.timeSeries(on, { ...F, cls }) as { date: string; value: number; cost: number }[];
  return (
    <div className="h-64">
      <ResponsiveContainer>
        <LineChart data={ts} margin={{ left: 0, right: 8, top: 8, bottom: 0 }} accessibilityLayer>
          <CartesianGrid vertical={false} stroke="var(--border)" strokeDasharray="3 3" />
          <XAxis dataKey="date" tickFormatter={mon} tick={axisTick} axisLine={false} tickLine={false} />
          <YAxis tickFormatter={short} tick={axisTick} axisLine={false} tickLine={false} width={64} domain={["auto", "auto"]} />
          <Tooltip content={<Tip fmt={inr} lf={day} />} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <RLine type="monotone" dataKey="value" name="Value" stroke="var(--mf)" strokeWidth={2} dot={false} isAnimationActive={!rm} />
          <RLine type="monotone" dataKey="cost" name="Cost" stroke="var(--muted-foreground)" strokeDasharray="5 4" strokeWidth={2} dot={false} isAnimationActive={!rm} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MutualFunds({ on, F, toggle }: Ctx) {
  const ls = lines(on, F).filter((l) => l.cls === "Mutual funds");
  const s = sum(ls);
  const xirr = E.xirrFor(on, F) as number | null;
  const cols: Col<Line>[] = [
    { h: "Fund", v: (l) => l.name.replace(" - Direct Growth", "") },
    { h: "Fund house", v: (l) => l.fh },
    { h: "Category", v: (l) => l.category },
    { h: "Folio", v: (l) => l.account },
    { h: "Units", v: (l) => l.qty, f: qty, num: true },
    { h: "Average cost", v: (l) => l.avg, f: px, num: true },
    { h: "Price", v: (l) => l.price, f: px, num: true },
    { h: "Cost", v: (l) => l.cost, f: inr, num: true },
    { h: "Value", v: (l) => l.value, f: inr, num: true },
    { h: "Gain %", v: (l) => sum([l]).pct, f: gainCell, num: true },
  ];
  const sel = F.key ? ls.find((l) => l.key === F.key) : undefined;
  const led = sel ? (E.ledger(sel.account, sel.key, on) as any[]) : [];
  const lcols: Col<any>[] = [
    { h: "Date", v: (e) => e.date, f: day },
    { h: "Action", v: (e) => e.action },
    { h: "Units", v: (e) => e.qty, f: qty, num: true },
    { h: "Price", v: (e) => e.price, f: px, num: true },
    { h: "Units after", v: (e) => e.units, f: qty, num: true },
    { h: "Average cost after", v: (e) => e.avg, f: px, num: true },
  ];
  sheetsRef.current = [toSheet("Funds", cols, ls), ...(sel ? [toSheet("Ledger", lcols, led)] : [])];
  return (
    <div className="space-y-5">
      <KpiRow>
        <Kpi label="Value" value={s.value} fmt={short} sub={inr(s.value)} />
        <Kpi label="Cost" value={s.cost} fmt={short} sub={inr(s.cost)} />
        <Kpi label="Gain or loss"><Delta v={s.gain} text={sshort(s.gain)} /></Kpi>
        <Kpi label="Return per year (XIRR)" sub={xirr == null ? `Needs 6 months from ${day(E.openDate())}` : "Includes buys, SIPs and sales"}>{xirr == null ? "Not yet" : <Delta v={xirr} text={pct(xirr, 2)} />}</Kpi>
      </KpiRow>
      <Grid>
        <Panel title="Value by category" sub="Fund value grouped by type of fund. Click a bar to filter.">
          <HBars data={groupSum(ls, (l) => l.category).map((g) => ({ k: g.k, value: g.value }))} fmt={short} color="var(--mf)" onPick={(k) => toggle("category", k)} active={F.category} />
        </Panel>
        <Panel title="Value by fund house" sub="Fund value grouped by fund company. Click a bar to filter.">
          <HBars data={groupSum(ls, (l) => l.fh).map((g) => ({ k: g.k, value: g.value }))} fmt={short} color="var(--mf)" onPick={(k) => toggle("fh", k)} active={F.fh} />
        </Panel>
      </Grid>
      <Panel title="SIP money added each month" sub="Money put into funds each month through SIPs and one-off buys. Hover for the amount.">
        <VBars data={buys(on, F, "MF")} fmt={short} keys={[{ k: "Amount", color: "var(--mf)" }]} />
      </Panel>
      <Panel title="Funds" sub="Click a heading to sort. Click a row to filter to that fund and show its ledger.">
        <DataTable label="Funds" cols={cols} rows={ls} onRow={(l) => toggle("key", l.key)} active={(l) => l.key === F.key} />
      </Panel>
      <Panel title="Ledger of the fund shown above" sub={sel ? `${sel.name} in ${sel.account}: units and average cost after each transaction.` : "Click a fund in the table above to see its ledger."}>
        {sel ? <DataTable label="Ledger" cols={lcols} rows={led} /> : <Empty text="No fund chosen yet." />}
      </Panel>
      <Panel title="Value and cost, month by month" sub="Fund value against money put in, at each month end. Hover for exact figures.">
        <ValueCost on={on} F={F} cls="Mutual funds" />
      </Panel>
    </div>
  );
}

function TreeCell(props: any) {
  const { x, y, width, height, name, depth, onPick, active } = props;
  if (depth !== 2 || width < 2 || height < 2) return null;
  const dim = active && active !== props.k;
  return (
    <g onClick={() => onPick(props.k)} style={{ cursor: "pointer" }}>
      <rect x={x} y={y} width={width} height={height} rx={4} fill="var(--eq)" fillOpacity={dim ? 0.3 : 0.55 + 0.45 * (props.share ?? 0)} stroke="var(--card)" strokeWidth={2} />
      {width > 60 && height > 22 && <text x={x + 6} y={y + 16} fontSize={11} fill="var(--card)" fontWeight={600}>{String(name).slice(0, Math.floor(width / 7))}</text>}
    </g>
  );
}

export function Equity({ on, F, toggle }: Ctx) {
  const rm = useReducedMotion();
  const ls = lines(on, F).filter((l) => l.cls === "Equity shares");
  const s = sum(ls);
  const byKey = groupSum(ls, (l) => l.key);
  const ranked = byKey.filter((g) => g.cost > 0).sort((a, b) => (b.pct ?? 0) - (a.pct ?? 0));
  const best = ranked[0], worst = ranked[ranked.length - 1];
  const sectors = groupSum(ls, (l) => l.sector);
  const top = byKey[0]?.value || 1;
  const tree = sectors.map((sec) => ({
    name: sec.k,
    children: groupSum(sec.lines, (l) => l.key).map((g) => ({ name: g.name, k: g.k, size: g.value, share: g.value / top })),
  }));
  const cols: Col<Line>[] = [
    { h: "Company", v: (l) => l.name },
    { h: "Sector", v: (l) => l.sector },
    { h: "Demat account", v: (l) => l.account },
    { h: "Quantity", v: (l) => l.qty, f: qty, num: true },
    { h: "Average cost", v: (l) => l.avg, f: px, num: true },
    { h: "Price", v: (l) => l.price, f: px, num: true },
    { h: "Cost", v: (l) => l.cost, f: inr, num: true },
    { h: "Value", v: (l) => l.value, f: inr, num: true },
    { h: "Gain %", v: (l) => sum([l]).pct, f: gainCell, num: true },
  ];
  sheetsRef.current = [toSheet("Equity shares", cols, ls)];
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Kpi label="Value" value={s.value} fmt={short} sub={inr(s.value)} />
        <Kpi label="Cost with brokerage" value={s.cost} fmt={short} sub={inr(s.cost)} />
        <Kpi label="Gain or loss" sub={pct(s.pct, 2) + " on cost"}><Delta v={s.gain} text={sshort(s.gain)} /></Kpi>
        <Kpi label="Best share" sub={best?.name ?? "—"}>{best ? <Delta v={best.pct} text={pct(best.pct)} /> : "—"}</Kpi>
        <Kpi label="Weakest share" sub={worst?.name ?? "—"}>{worst ? <Delta v={worst.pct} text={pct(worst.pct)} /> : "—"}</Kpi>
      </div>
      <Panel title="Sector, then company" sub="Box size is value. Click a company to filter to it, or a sector name below to filter by sector.">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {sectors.map((sec) => (
            <button key={sec.k} onClick={() => toggle("sector", sec.k)} aria-pressed={F.sector === sec.k}
              className={`rounded-full border px-2.5 py-1 text-xs ${F.sector === sec.k ? "border-eq bg-eq/15 font-semibold" : "border-border hover:bg-accent"}`}>
              {sec.k} <span className="num text-muted-foreground">{short(sec.value)}</span>
            </button>
          ))}
        </div>
        {tree.length ? (
          <div className="h-72">
            <ResponsiveContainer>
              <Treemap data={tree} dataKey="size" isAnimationActive={false} content={<TreeCell onPick={(k: string) => toggle("key", k)} active={F.key} />}>
                <Tooltip content={<Tip fmt={inr} />} />
              </Treemap>
            </ResponsiveContainer>
          </div>
        ) : <Empty text="Nothing to show for this view." />}
      </Panel>
      <Grid>
        <Panel title="Gain or loss by share" sub="Return on cost for each company, best first. Click a bar to filter.">
          <HBars data={ranked.map((g) => ({ k: g.k, label: g.name, value: g.pct ?? 0, fill: (g.pct ?? 0) >= 0 ? "var(--gain)" : "var(--loss)" }))} fmt={(v) => pct(v)} name="Return on cost" onPick={(k) => toggle("key", k)} active={F.key} />
        </Panel>
        <Panel title="Buys over time" sub="Money spent buying shares each month. Hover for the amount.">
          <VBars data={buys(on, F, "SHARE")} fmt={short} keys={[{ k: "Amount", color: "var(--eq)" }]} />
        </Panel>
      </Grid>
      <Panel title="Equity shares" sub="Click a heading to sort. Click a row to filter to that company.">
        <DataTable label="Equity shares" cols={cols} rows={ls} onRow={(l) => toggle("key", l.key)} active={(l) => l.key === F.key} />
        <p className="mt-2 text-xs text-muted-foreground">Cost per share includes brokerage. Price comes from the prices file for the chosen date.</p>
      </Panel>
    </div>
  );
}
