/* eslint-disable @typescript-eslint/no-explicit-any */
import { animate, useReducedMotion } from "framer-motion";
import { useEffect, useMemo, useRef, useState, type ReactNode, type ButtonHTMLAttributes } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Sheet } from "@/lib/store";

export function Button({ className = "", type = "button", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type={type} className={`inline-flex min-h-9 items-center justify-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-accent focus-visible:outline-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-50 ${className}`} {...props} />;
}

export function Panel({ title, sub, children, className = "", action }: { title: string; sub?: string; children: ReactNode; className?: string; action?: ReactNode }) {
  return (
    <section className={`card-surface lift min-w-0 p-4 md:p-5 ${className}`}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="text-sm font-bold tracking-tight">{title}</h3>
          {sub && <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function CountUp({ value, fmt }: { value: number | null | undefined; fmt: (v: number) => string }) {
  const rm = useReducedMotion();
  const [v, setV] = useState(value ?? 0);
  const prev = useRef(value ?? 0);
  useEffect(() => {
    if (value == null) return;
    if (rm) { setV(value); prev.current = value; return; }
    const c = animate(prev.current, value, { duration: 0.7, ease: "easeOut", onUpdate: setV });
    prev.current = value;
    return () => c.stop();
  }, [value, rm]);
  return <span className="num">{value == null ? "—" : fmt(v)}</span>;
}

export function Delta({ v, text, hero }: { v: number | null | undefined; text: string; hero?: boolean }) {
  if (v == null || !isFinite(v)) return <span className="opacity-70">—</span>;
  const up = v >= 0;
  const c = hero ? (up ? "text-hero-gain" : "text-hero-loss") : up ? "text-gain" : "text-loss";
  return (
    <span className={`num font-semibold ${c}`}>
      <span aria-hidden>{up ? "▲" : "▼"}</span> {text}
    </span>
  );
}

export function Kpi({ label, value, fmt, sub, children }: { label: string; value?: number | null; fmt?: (v: number) => string; sub?: ReactNode; children?: ReactNode }) {
  return (
    <div className="card-surface lift min-w-0 p-4">
      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 truncate text-2xl font-extrabold tracking-tight">{children ?? <CountUp value={value} fmt={fmt ?? String} />}</div>
      {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}

export const KpiRow = ({ children }: { children: ReactNode }) => (
  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">{children}</div>
);
export const Grid = ({ children }: { children: ReactNode }) => (
  <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">{children}</div>
);
export const Empty = ({ text }: { text: string }) => <p className="py-8 text-center text-sm text-muted-foreground">{text}</p>;

export type Col<T> = { h: string; v: (r: T) => string | number | null | undefined; f?: (v: any, r: T) => ReactNode; num?: boolean };

export function DataTable<T>({ cols, rows, onRow, active, label }: { cols: Col<T>[]; rows: T[]; onRow?: (r: T) => void; active?: (r: T) => boolean; label: string }) {
  const [sort, setSort] = useState<{ i: number; d: 1 | -1 } | null>(null);
  const sorted = useMemo(() => {
    if (!sort) return rows;
    const c = cols[sort.i]!;
    return [...rows].sort((a, b) => {
      const x = c.v(a), y = c.v(b);
      if (x == null) return 1;
      if (y == null) return -1;
      return (x < y ? -1 : x > y ? 1 : 0) * sort.d;
    });
  }, [rows, sort, cols]);
  if (!rows.length) return <Empty text="Nothing to show for this view." />;
  return (
    <div className="max-h-[440px] overflow-auto rounded-lg border border-border">
      <table className="w-full min-w-max text-sm" aria-label={label}>
        <thead className="sticky top-0 z-10 bg-muted">
          <tr>
            {cols.map((c, i) => (
              <th key={c.h} scope="col" className={`px-3 py-2 text-xs font-semibold text-muted-foreground ${c.num ? "text-right" : "text-left"}`}
                aria-sort={sort?.i === i ? (sort.d === 1 ? "ascending" : "descending") : "none"}>
                <button className="rounded hover:text-foreground" onClick={() => setSort((s) => ({ i, d: s?.i === i && s.d === -1 ? 1 : -1 }))}>
                  {c.h}{sort?.i === i ? (sort.d === 1 ? " ↑" : " ↓") : ""}
                </button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sorted.map((r, ri) => {
            const on = active?.(r);
            return (
              <tr key={ri} tabIndex={onRow ? 0 : undefined} onClick={onRow ? () => onRow(r) : undefined}
                onKeyDown={onRow ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onRow(r); } } : undefined}
                className={`border-t border-border ${onRow ? "cursor-pointer hover:bg-accent/60" : ""} ${on ? "bg-accent font-semibold" : ""}`}>
                {cols.map((c) => {
                  const v = c.v(r);
                  return <td key={c.h} className={`px-3 py-2 ${c.num ? "num text-right" : "text-left"}`}>{c.f ? c.f(v, r) : (v ?? "—")}</td>;
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function toSheet<T>(name: string, cols: Col<T>[], rows: T[]): Sheet {
  return { name, cols: cols.map((c) => (c.num ? { h: c.h, num: true } : { h: c.h })), rows: rows.map((r) => cols.map((c) => c.v(r) ?? null)) };
}

export function Tip({ active, payload, label, fmt, lf }: any) {
  if (!active || !payload?.length) return null;
  const items = payload.filter((p: any) => p.dataKey !== "base");
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-lg">
      <div className="mb-1 font-semibold">{lf ? lf(label) : label ?? items[0]?.payload?.label}</div>
      {items.map((p: any) => (
        <div key={String(p.dataKey) + p.name} className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: p.color || p.payload?.fill }} />
          <span className="text-muted-foreground">{p.name}</span>
          <span className="num ml-auto pl-3 font-semibold">{fmt(p.value, p.payload)}</span>
        </div>
      ))}
    </div>
  );
}

export const axisTick = { fontSize: 11, fill: "var(--muted-foreground)" };
const cut = (s: string, n = 22) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

export type BarDatum = { k: string; label?: string | undefined; value: number; fill?: string | undefined };
export function HBars({ data, onPick, active, fmt, color, name = "Value" }: { data: BarDatum[]; onPick?: ((k: string) => void) | undefined; active?: string | undefined; fmt: (v: number) => string; color?: string | undefined; name?: string }) {
  const rm = useReducedMotion();
  if (!data.length) return <Empty text="Nothing to show for this view." />;
  const d = data.map((x) => ({ ...x, label: x.label ?? x.k }));
  return (
    <div style={{ height: Math.max(120, d.length * 30 + 30) }}>
      <ResponsiveContainer>
        <BarChart data={d} layout="vertical" margin={{ left: 0, right: 16, top: 4, bottom: 4 }} accessibilityLayer>
          <CartesianGrid horizontal={false} stroke="var(--border)" strokeDasharray="3 3" />
          <XAxis type="number" tickFormatter={fmt} tick={axisTick} axisLine={false} tickLine={false} />
          <YAxis type="category" dataKey="label" width={128} tick={{ ...axisTick, fill: "var(--foreground)" }} tickFormatter={(s: string) => cut(s, 20)} axisLine={false} tickLine={false} interval={0} />
          <Tooltip cursor={{ fill: "var(--accent)", opacity: 0.5 }} content={<Tip fmt={fmt} />} />
          <Bar dataKey="value" name={name} radius={[0, 6, 6, 0]} barSize={14} isAnimationActive={!rm} onClick={(x: any) => onPick?.(x.k)} cursor={onPick ? "pointer" : undefined}>
            {d.map((x) => <Cell key={x.k} fill={x.fill ?? color ?? "var(--primary)"} opacity={active && active !== x.k ? 0.35 : 1} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function VBars({ data, fmt, keys, onPick }: { data: Record<string, any>[]; fmt: (v: number) => string; keys: { k: string; color: string }[]; onPick?: (label: string) => void }) {
  const rm = useReducedMotion();
  if (!data.length) return <Empty text="Nothing to show for this view." />;
  return (
    <div className="h-64">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ left: 0, right: 8, top: 8, bottom: 0 }} accessibilityLayer>
          <CartesianGrid vertical={false} stroke="var(--border)" strokeDasharray="3 3" />
          <XAxis dataKey="label" tick={axisTick} axisLine={false} tickLine={false} />
          <YAxis tickFormatter={fmt} tick={axisTick} axisLine={false} tickLine={false} width={64} />
          <Tooltip cursor={{ fill: "var(--accent)", opacity: 0.5 }} content={<Tip fmt={fmt} />} />
          {keys.length > 1 && <Legend wrapperStyle={{ fontSize: 12 }} />}
          {keys.map((k, i) => (
            <Bar key={k.k} dataKey={k.k} name={k.k} stackId="s" fill={k.color} maxBarSize={28} isAnimationActive={!rm}
              radius={i === keys.length - 1 ? [6, 6, 0, 0] : [0, 0, 0, 0]} onClick={(x: any) => onPick?.(x.label)} cursor={onPick ? "pointer" : undefined} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
