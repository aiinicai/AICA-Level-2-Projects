import { useEffect, useRef, useState } from "react";
import dtaaHtml from "@/assets/dtaa.html?raw";
import { data } from "@/lib/data";
import { day } from "@/lib/format";
import { E, sheetsRef } from "@/lib/store";
import { Panel } from "./kit";

const RULES = [
  "Holdings on a date = opening units plus buys and SIPs up to that date, less sales.",
  "Average cost = total cost divided by total units. A sale removes units at the average cost.",
  "Value on a date = units on that date times the latest price on or before that date.",
  "Deposit value = principal plus simple interest up to the date; it stops growing at maturity.",
  "Foreign currency = amount times the USD/INR rate on or before the date.",
  "Return per year (XIRR) is shown only when the opening date is at least 180 days before the chosen date.",
  "Property, rent and insurance are not added to the consolidated total.",
  "Cash calendar = the 12 months after the latest data date: SIPs on their day, premiums on their due day in each year of the policy, house tax and maintenance every year.",
];

export function Checks() {
  const checks = data.checks as { name: string; ok: boolean; detail: string }[];
  const failed = checks.filter((c) => !c.ok).length;
  const counts: [string, number][] = [["Instruments", data.instruments.length], ["Transactions", data.tx.length], ["Prices", data.prices.length], ["Bank balances", data.bank.length], ["Term deposits", data.fd.length], ["Broker cash", data.cash.length], ["SIP plan", data.sip.length], ["Properties", data.props.length], ["Rent receipts", data.rent.length], ["Insurance policies", data.ins.length]];
  sheetsRef.current = [{ name: "Checks", cols: [{ h: "Check" }, { h: "Result" }, { h: "Detail" }], rows: checks.map((c) => [c.name, c.ok ? "Pass" : "Fail", c.detail]) }];
  return (
    <div className="space-y-5">
      <Panel title="Checks on the data file" sub="Each rule the data must meet, with the result." action={<span className={`rounded-full px-3 py-1 text-xs font-bold ${failed ? "bg-loss/15 text-loss" : "bg-gain/15 text-gain"}`}>{failed ? `✕ ${failed} failed` : "✓ All checks pass"}</span>}>
        <ul className="divide-y divide-border">
          {checks.map((c) => (
            <li key={c.name} className="flex flex-col gap-1 py-2.5 sm:flex-row sm:items-center sm:gap-3">
              <span className={`w-fit shrink-0 rounded-full px-2.5 py-0.5 text-xs font-bold ${c.ok ? "bg-gain/15 text-gain" : "bg-loss/15 text-loss"}`}>{c.ok ? "✓ Pass" : "✕ Fail"}</span>
              <span className="min-w-0 flex-1 text-sm">{c.name}</span>
              <span className="text-xs text-muted-foreground">{c.detail}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Data in this file" sub="Row counts for each table.">
          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {counts.map(([k, v]) => <div key={k} className="flex justify-between border-b border-border py-1"><dt className="text-muted-foreground">{k}</dt><dd className="num font-semibold">{v}</dd></div>)}
          </dl>
          <p className="mt-3 text-xs text-muted-foreground">Latest price date {day(E.latest)} · {data.meta.label} · built {day(data.meta.built)}</p>
        </Panel>
        <Panel title="How the numbers are worked out" sub="The rules the calculation files follow, in plain words.">
          <ul className="list-disc space-y-1.5 pl-5 text-sm">{RULES.map((r) => <li key={r}>{r}</li>)}</ul>
        </Panel>
      </div>
    </div>
  );
}

export function Dtaa() {
  const [height, setHeight] = useState(600);
  const ref = useRef<HTMLIFrameElement>(null);
  const observer = useRef<ResizeObserver | null>(null);
  sheetsRef.current = [];
  const fit = () => {
    const frame = ref.current;
    const d = frame?.contentDocument;
    if (!d || !frame) return;
    // Measure natural content height rather than the iframe's current viewport,
    // which would otherwise add eight pixels on every observation.
    frame.style.height = "0px";
    const nextHeight = d.documentElement.scrollHeight + 8;
    frame.style.height = `${nextHeight}px`;
    setHeight(nextHeight);
  };
  const loaded = () => {
    observer.current?.disconnect();
    fit();
    const body = ref.current?.contentDocument?.body;
    if (body && typeof ResizeObserver !== "undefined") {
      observer.current = new ResizeObserver(fit);
      observer.current.observe(body);
    }
  };
  useEffect(() => {
    window.addEventListener("resize", fit);
    return () => {
      window.removeEventListener("resize", fit);
      observer.current?.disconnect();
    };
  }, []);
  return <iframe ref={ref} title="NRI DTAA worked example" srcDoc={dtaaHtml} sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" onLoad={loaded} scrolling="no" className="dtaa-frame w-full border-0 rounded-lg" style={{ height }} />;
}
