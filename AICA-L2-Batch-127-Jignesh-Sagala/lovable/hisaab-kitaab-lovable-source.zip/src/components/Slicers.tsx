import { X } from "lucide-react";
import { E, type Ctx, type FKey, type Line } from "@/lib/store";

const LABEL: Record<FKey, string> = { account: "Account", bank: "Bank", fh: "Fund house", sector: "Sector", category: "Category", ccy: "Currency", cls: "Asset class", key: "Holding", atype: "Held in" };
const uniq = (a: (string | null | undefined)[]) => [...new Set(a.filter((x): x is string => !!x))].sort();
const sel = "h-9 min-w-0 rounded-lg border border-input bg-card px-2 text-sm";

export function filterText(F: Ctx["F"]) {
  const parts = (Object.keys(F) as FKey[]).filter((k) => F[k]).map((k) => `${LABEL[k]}: ${keyName(k, F[k]!)}`);
  return parts.length ? parts.join("; ") : "None";
}
function keyName(k: FKey, v: string) {
  return k === "key" ? (E.ins[v]?.name ?? v) : v;
}

export default function Slicers({ on, F, setF }: Ctx) {
  const ls = E.lines(on) as Line[];
  const banks = uniq(ls.map((l) => l.bank));
  const accts = uniq(ls.map((l) => l.account));
  const set = (k: FKey, v: string) => { const n = { ...F }; if (v) n[k] = v; else delete n[k]; setF(n); };
  const acc = (v: string) => {
    const n = { ...F };
    delete n.bank; delete n.account;
    if (v.startsWith("bank:")) n.bank = v.slice(5); else if (v) n.account = v;
    setF(n);
  };
  const active = (Object.keys(F) as FKey[]).filter((k) => F[k]);
  return (
    <div className="no-print mt-4 space-y-2">
      <div className="grid grid-cols-2 gap-2 md:flex md:flex-wrap md:items-end">
        <label className="col-span-2 flex flex-col gap-1 text-xs font-semibold text-muted-foreground md:w-64">Account
          <select className={sel} value={F.bank ? "bank:" + F.bank : (F.account ?? "")} onChange={(e) => acc(e.target.value)}>
            <option value="">All accounts</option>
            {banks.map((b) => (
              <optgroup key={b} label={b}>
                <option value={"bank:" + b}>All {b} accounts</option>
                {uniq(ls.filter((l) => l.bank === b).map((l) => l.account)).map((a) => <option key={a} value={a}>{a}</option>)}
              </optgroup>
            ))}
            <optgroup label="Demat accounts">{accts.filter((a) => a.startsWith("Demat")).map((a) => <option key={a} value={a}>{a}</option>)}</optgroup>
            <optgroup label="Fund folios">{accts.filter((a) => a.startsWith("Folio")).map((a) => <option key={a} value={a}>{a}</option>)}</optgroup>
          </select>
        </label>
        {([["sector", "Sector", uniq(ls.map((l) => l.sector))], ["category", "Category", uniq(ls.map((l) => l.category))], ["ccy", "Currency", uniq(ls.map((l) => l.ccy))]] as const).map(([k, lab, opts]) => (
          <label key={k} className="flex min-w-0 flex-col gap-1 text-xs font-semibold text-muted-foreground md:w-44">{lab}
            <select className={sel} value={F[k] ?? ""} onChange={(e) => set(k, e.target.value)}>
              <option value="">All</option>
              {opts.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </label>
        ))}
        {active.length > 0 && <button onClick={() => setF({})} className="h-9 text-sm font-semibold text-primary underline-offset-2 hover:underline">Clear filters</button>}
      </div>
      {active.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {active.map((k) => (
            <button key={k} onClick={() => set(k, "")} className="pulse-once inline-flex items-center gap-1 rounded-full border border-ring bg-accent px-2.5 py-1 text-xs font-medium" aria-label={`Remove filter ${LABEL[k]} ${F[k]}`}>
              {LABEL[k]}: {keyName(k, F[k]!)} <X className="h-3 w-3" aria-hidden />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
