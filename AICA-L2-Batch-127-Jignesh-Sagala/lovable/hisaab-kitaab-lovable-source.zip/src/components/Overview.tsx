/* eslint-disable @typescript-eslint/no-explicit-any */
import { useReducedMotion } from "framer-motion";
import { Pause, Play } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line as RLine, LineChart, Pie, PieChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CCY_COLOR, CLASSES, CLS_COLOR, day, inr, isoText, mon, pct, share, short, sinr, sshort } from "@/lib/format";
import { E, EngineStatic, extraRef, groupSum, isHolding, lines, sheetsRef, sum, type Ctx, type Line } from "@/lib/store";
import { axisTick, CountUp, Delta, Empty, HBars, Panel, Tip } from "./kit";
import PortfolioSummary from "./PortfolioSummary";
import { buildPortfolioSnapshot } from "@/lib/portfolio-summary";

type Pt = { date: string; value: number; cost: number };

export default function Overview({ on, setOn, F, toggle }: Ctx) {
  const rm = useReducedMotion();
  const ls = useMemo(() => lines(on, F), [on, F]);
  const s = sum(ls);
  const tl = useMemo(() => E.timeline(E.latest) as string[], []);
  const ts = useMemo(() => E.timeSeries(E.latest, F) as Pt[], [F]);
  const [prev, setPrev] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const idxRef = useRef(0);
  const timer = useRef<number | undefined>(undefined);
  const idx = prev ?? Math.max(0, tl.indexOf(on));
  idxRef.current = idx;
  const pd = tl[idx] ?? on;
  const ps = prev == null ? s : sum(lines(pd, F));
  const xirr = E.xirrFor(pd, F) as number | null;
  const open = E.openDate() as string | null;
  const young = open ? EngineStatic.dn(pd) - EngineStatic.dn(open) < 180 : true;
  const summarySnapshot = useMemo(() => {
    const dates = E.timeline(pd) as string[];
    const previousOn = dates.filter((date) => date < pd).at(-1) ?? null;
    return buildPortfolioSnapshot(pd, previousOn, lines(pd, F), previousOn ? lines(previousOn, F) : [], Object.values(F).some(Boolean));
  }, [pd, F]);

  const commit = (i: number) => { setOn(tl[i] ?? on); setPrev(null); };
  const stop = () => { window.clearInterval(timer.current); setPlaying(false); commit(idxRef.current); };
  const play = () => {
    let i = 0;
    setPrev(0);
    setPlaying(true);
    timer.current = window.setInterval(() => {
      i++;
      if (i >= tl.length - 1) { window.clearInterval(timer.current); setPlaying(false); commit(tl.length - 1); }
      else setPrev(i);
    }, rm ? 300 : 650);
  };
  useEffect(() => {
    if (!playing) return;
    const h = () => stop();
    const t = window.setTimeout(() => document.addEventListener("pointerdown", h, { once: true }), 0);
    return () => { window.clearTimeout(t); document.removeEventListener("pointerdown", h); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);
  useEffect(() => () => window.clearInterval(timer.current), []);

  // asset class cards ignore F.cls
  const baseF = useMemo(() => { const n = { ...F }; delete n.cls; return n; }, [F]);
  const base = useMemo(() => lines(on, baseF), [on, baseF]);
  const baseTotal = sum(base).value;
  const sparks = useMemo(() => Object.fromEntries(CLASSES.map((c) => [c, E.timeSeries(E.latest, { ...baseF, cls: c }) as Pt[]])), [baseF]);

  const byClass = E.byClass(ls) as Record<string, { value: number; cost: number }>;
  const donut = CLASSES.map((c) => ({ k: c, value: byClass[c]!.value })).filter((d) => d.value > 0);
  const atype = groupSum(ls, (l) => l.atype);
  const ccy = groupSum(ls, (l) => l.ccy);
  const hold = groupSum(ls.filter(isHolding), (l) => l.key);
  const ranked = hold.filter((h) => h.cost > 0).sort((a, b) => (b.pct ?? 0) - (a.pct ?? 0));
  const best = ranked.slice(0, 5);
  const worst = ranked.slice(5).slice(-5).reverse();
  const gl = [...best, ...worst.slice().reverse()].map((h) => ({ k: h.k, label: h.name, value: h.pct ?? 0, fill: (h.pct ?? 0) >= 0 ? "var(--gain)" : "var(--loss)" }));

  // waterfall
  const steps = CLASSES.map((c) => ({ c, g: sum(ls.filter((l) => l.cls === c)).gain })).filter((x) => Math.abs(x.g) > 0.5);
  let run = 0;
  const wf: any[] = steps.map((x) => { const b = Math.min(run, run + x.g); run += x.g; return { k: x.c, label: x.c, base: b, size: Math.abs(x.g), g: x.g, fill: x.g >= 0 ? "var(--gain)" : "var(--loss)" }; });
  if (steps.length) wf.push({ k: "Total", label: "Total gain", base: Math.min(0, s.gain), size: Math.abs(s.gain), g: s.gain, fill: "var(--primary)" });

  // heatmap
  const months = E.timeline(on) as string[];
  const top10 = hold.slice(0, 10);
  const heat = top10.map((h) => ({
    h,
    cells: months.slice(1).map((d, i) => {
      const a = E.priceOn(h.k, months[i]!), b = E.priceOn(h.k, d);
      return a && b ? b.p / a.p - 1 : null;
    }),
  }));
  const att = E.attention(on, F) as { kind: string; text: string; key: string }[];
  const pdates = ls.filter(isHolding).map((l) => l.pdate ?? "").sort();

  sheetsRef.current = [{
    name: "Holdings",
    cols: [{ h: "Asset class" }, { h: "Name" }, { h: "Account" }, { h: "Quantity", num: true }, { h: "Cost INR", num: true }, { h: "Value INR", num: true }, { h: "Gain or loss INR", num: true }, { h: "Price date" }],
    rows: ls.map((l: Line) => [l.cls, l.name, l.account, l.qty ?? l.local ?? null, l.cost, l.value, sum([l]).gain, l.pdate ?? null]),
  }];
  extraRef.current = [["Total value", s.value]];

  return (
    <div className="space-y-5">
      {/* HERO */}
      <section className="hero-surface grid gap-6 p-5 md:p-7 xl:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div className="min-w-0">
          <div className="text-xs font-semibold uppercase tracking-widest opacity-75">Total value on {day(pd)}</div>
          <div className="mt-2 text-4xl font-extrabold tracking-tight md:text-5xl"><CountUp value={ps.value} fmt={short} /></div>
          <div className="mt-1 text-sm opacity-75 num">{inr(ps.value)}</div>
          <div className="mt-3 inline-flex flex-wrap items-center gap-1 rounded-full bg-black/0 text-sm">
            <Delta hero v={ps.gain} text={`${sshort(ps.gain)} (${pct(ps.pct, 2)}) on cost, as on ${day(pd)}`} />
          </div>
          <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-3">
            <div className="hero-tile p-3"><div className="text-[11px] uppercase tracking-wide opacity-75">Total cost</div><div className="mt-1 text-lg font-bold"><CountUp value={ps.cost} fmt={short} /></div></div>
            <div className="hero-tile p-3"><div className="text-[11px] uppercase tracking-wide opacity-75">Gain or loss</div><div className="mt-1 text-lg font-bold"><Delta hero v={ps.gain} text={sshort(ps.gain)} /></div></div>
            <div className="hero-tile p-3"><div className="text-[11px] uppercase tracking-wide opacity-75">Fund return per year (XIRR)</div>
              <div className="mt-1 text-lg font-bold">{xirr == null ? "Not yet" : <Delta hero v={xirr} text={pct(xirr, 2)} />}</div>
              {xirr == null && <div className="text-[11px] opacity-75">{young && open ? `Needs 6 months from ${day(open)}` : "Not enough fund data for this view"}</div>}
            </div>
          </div>
        </div>
        <div className="min-w-0">
          <div className="text-xs opacity-75">Value (solid) and cost (dashed) at each month end. Hover for exact figures.</div>
          <div className="mt-2 h-56">
            <ResponsiveContainer>
              <AreaChart data={ts} margin={{ left: 0, right: 8, top: 8, bottom: 0 }} accessibilityLayer>
                <defs>
                  <linearGradient id="hv" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--hero-accent)" stopOpacity={0.45} /><stop offset="100%" stopColor="var(--hero-accent)" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="oklch(1 0 0 / 10%)" />
                <XAxis dataKey="date" tickFormatter={mon} tick={{ fontSize: 11, fill: "var(--hero-foreground)", opacity: 0.75 }} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={short} tick={{ fontSize: 11, fill: "var(--hero-foreground)", opacity: 0.75 }} axisLine={false} tickLine={false} width={72} domain={["auto", "auto"]} />
                <Tooltip content={<Tip fmt={inr} lf={day} />} cursor={{ stroke: "var(--hero-foreground)", strokeOpacity: 0.4 }} />
                <Area type="monotone" dataKey="value" name="Value" stroke="var(--hero-accent)" strokeWidth={2} fill="url(#hv)" isAnimationActive={!rm} />
                <Area type="monotone" dataKey="cost" name="Cost" stroke="var(--hero-foreground)" strokeOpacity={0.7} strokeDasharray="5 4" strokeWidth={1.5} fill="none" isAnimationActive={!rm} />
                <ReferenceLine x={pd} stroke="var(--hero-accent)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="no-print mt-3 flex items-center gap-3">
            <button onClick={(e) => { e.stopPropagation(); if (playing) stop(); else play(); }} className="hero-tile inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold" aria-label={playing ? "Stop replay" : "Replay month by month"}>
              {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />} {playing ? "Stop" : "Replay"}
            </button>
            <label className="sr-only" htmlFor="scrub">Time scrubber</label>
            <input id="scrub" type="range" className="scrubber" min={0} max={tl.length - 1} step={1} value={idx}
              aria-valuetext={day(pd)}
              onChange={(e) => setPrev(+e.target.value)}
              onPointerUp={(e) => commit(+(e.target as HTMLInputElement).value)}
              onKeyUp={(e) => commit(+(e.target as HTMLInputElement).value)} />
          </div>
          <div className="no-print mt-1 flex justify-between text-[11px] opacity-75"><span>{day(tl[0])}</span><span>Dragging previews. Release to apply.</span><span>{day(tl[tl.length - 1])}</span></div>
        </div>
      </section>

      <PortfolioSummary snapshot={summarySnapshot} />

      {/* CLASS CARDS */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {CLASSES.map((c) => {
          const cs = sum(base.filter((l) => l.cls === c));
          const act = F.cls === c;
          return (
            <button key={c + String(act)} onClick={() => toggle("cls", c)} aria-pressed={act}
              className={`card-surface lift min-w-0 p-4 text-left ${act ? "pulse-once ring-2 ring-ring" : ""}`}>
              <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><span className="h-2.5 w-2.5 rounded-full" style={{ background: CLS_COLOR[c] }} />{c}</div>
              <div className="mt-1 flex items-end justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xl font-extrabold"><CountUp value={cs.value} fmt={short} /></div>
                  <div className="text-xs text-muted-foreground num">{share(baseTotal ? cs.value / baseTotal : null)} of total</div>
                  <div className="text-xs"><Delta v={cs.gain} text={sshort(cs.gain)} /></div>
                </div>
                <div className="h-12 w-24 shrink-0">
                  <ResponsiveContainer>
                    <LineChart data={sparks[c] ?? []}><RLine type="monotone" dataKey="value" stroke={CLS_COLOR[c]} strokeWidth={2} dot={false} isAnimationActive={!rm} /></LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
        <Panel title="Where it sits" sub="Value by asset class. Click a slice to filter.">
          {donut.length ? (
            <div className="relative h-60">
              <ResponsiveContainer>
                <PieChart accessibilityLayer>
                  <Pie data={donut} dataKey="value" nameKey="k" innerRadius="62%" outerRadius="90%" paddingAngle={2} cornerRadius={4} isAnimationActive={!rm}
                    onClick={(d: any) => toggle("cls", d.k)} cursor="pointer" stroke="var(--card)">
                    {donut.map((d) => <Cell key={d.k} fill={CLS_COLOR[d.k]} opacity={F.cls && F.cls !== d.k ? 0.35 : 1} />)}
                  </Pie>
                  <Tooltip content={<Tip fmt={(v: number) => `${short(v)} · ${share(s.value ? v / s.value : null)}`} />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center"><div className="text-xs text-muted-foreground">Total</div><div className="font-extrabold num">{short(s.value)}</div></div>
            </div>
          ) : <Empty text="Nothing to show for this view." />}
          <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs">
            {donut.map((d) => <li key={d.k} className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: CLS_COLOR[d.k] }} />{d.k} <span className="num text-muted-foreground">{share(s.value ? d.value / s.value : null)}</span></li>)}
          </ul>
        </Panel>
        <Panel title="Where the money is held" sub="Value by account type. Click a bar to filter.">
          <HBars data={atype.map((a) => ({ k: a.k, value: a.value }))} fmt={short} onPick={(k) => toggle("atype", k)} active={F.atype} />
        </Panel>
        <Panel title="Currency split" sub="Value by the currency it is held in, shown in INR. Click a bar to filter.">
          <HBars data={ccy.map((a) => ({ k: a.k, value: a.value, fill: CCY_COLOR[a.k] }))} fmt={short} onPick={(k) => toggle("ccy", k)} active={F.ccy} />
        </Panel>
        <Panel title="Top 10 funds and shares" sub="Largest holdings by value. Click a bar to filter to it.">
          <HBars data={hold.slice(0, 10).map((h) => ({ k: h.k, label: h.name, value: h.value, fill: CLS_COLOR[h.lines[0]!.cls] }))} fmt={short} onPick={(k) => toggle("key", k)} active={F.key} />
        </Panel>
        <Panel title="Biggest gainers and losers" sub="Return on cost, five best and five worst. Click a bar to filter.">
          <HBars data={gl} fmt={(v) => pct(v)} name="Return on cost" onPick={(k) => toggle("key", k)} active={F.key} />
        </Panel>
        <Panel title="Where the gain came from" sub="Gain or loss by asset class, adding up to the total. Click a step to filter.">
          {wf.length ? (
            <div className="h-60">
              <ResponsiveContainer>
                <BarChart data={wf} margin={{ left: 0, right: 8, top: 8, bottom: 0 }} accessibilityLayer>
                  <CartesianGrid vertical={false} stroke="var(--border)" strokeDasharray="3 3" />
                  <XAxis dataKey="label" tick={axisTick} tickFormatter={(x: string) => x.split(" ")[0]!} axisLine={false} tickLine={false} interval={0} />
                  <YAxis tickFormatter={short} tick={axisTick} axisLine={false} tickLine={false} width={64} />
                  <Tooltip cursor={{ fill: "var(--accent)", opacity: 0.5 }} content={<Tip fmt={(_v: number, p: any) => sinr(p.g)} />} />
                  <Bar dataKey="base" stackId="w" fill="transparent" isAnimationActive={false} />
                  <Bar dataKey="size" name="Gain or loss" stackId="w" radius={[4, 4, 4, 4]} isAnimationActive={!rm} onClick={(d: any) => d.k !== "Total" && toggle("cls", d.k)} cursor="pointer">
                    {wf.map((d) => <Cell key={d.k} fill={d.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <Empty text="No gain or loss to show for this view." />}
        </Panel>
      </div>

      <Panel title="Month by month: price change" sub="Price change from one month end to the next for the ten largest funds and shares. Click a name to filter.">
        {heat.length ? (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full min-w-max text-xs" aria-label="Monthly price change">
              <thead><tr className="bg-muted"><th className="sticky left-0 z-10 bg-muted px-3 py-2 text-left">Holding</th>{months.slice(1).map((m) => <th key={m} className="px-2 py-2 text-right font-semibold">{mon(m)}</th>)}</tr></thead>
              <tbody>
                {heat.map(({ h, cells }) => (
                  <tr key={h.k} className="border-t border-border">
                    <th scope="row" className="sticky left-0 z-10 bg-card px-3 py-1.5 text-left font-medium">
                      <button onClick={() => toggle("key", h.k)} className={`max-w-[180px] truncate text-left hover:underline ${F.key === h.k ? "font-bold text-primary" : ""}`}>{h.name.replace(" - Direct Growth", "")}</button>
                    </th>
                    {cells.map((c, i) => {
                      const p = c == null ? 0 : Math.min(1, Math.abs(c) / 0.1) * 55;
                      return <td key={i} className="num px-2 py-1.5 text-right" style={{ background: c == null ? undefined : `color-mix(in oklch, ${c >= 0 ? "var(--gain)" : "var(--loss)"} ${p}%, var(--card))` }}>{pct(c)}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <Empty text="Nothing to show for this view." />}
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Needs attention" sub="Deposits maturing soon and holdings down more than 10%. Click an item to filter." className="lg:col-span-2">
          {att.length ? (
            <ul className="space-y-2">
              {att.map((a, i) => (
                <li key={i}>
                  <button onClick={() => toggle("key", a.key)} className={`flex w-full items-start gap-2 rounded-lg border px-3 py-2 text-left text-sm ${a.kind === "bad" ? "border-loss/40 bg-loss/10" : "border-fd/50 bg-fd/10"}`}>
                    <span aria-hidden className={a.kind === "bad" ? "text-loss" : "text-fd"}>{a.kind === "bad" ? "●" : "▲"}</span>
                    <span><span className="sr-only">{a.kind === "bad" ? "Problem: " : "Warning: "}</span>{isoText(a.text)}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : <Empty text="Nothing needs attention for this view." />}
        </Panel>
        <Panel title="At a glance" sub="Counts for the current view.">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-xs text-muted-foreground">Holdings</dt><dd className="text-xl font-bold num">{ls.filter(isHolding).length}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Accounts</dt><dd className="text-xl font-bold num">{new Set(ls.map((l) => l.account)).size}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Currencies</dt><dd className="text-xl font-bold num">{new Set(ls.map((l) => l.ccy)).size}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Latest price date</dt><dd className="font-bold">{day(pdates[pdates.length - 1] || null)}</dd></div>
          </dl>
        </Panel>
      </div>
    </div>
  );
}
