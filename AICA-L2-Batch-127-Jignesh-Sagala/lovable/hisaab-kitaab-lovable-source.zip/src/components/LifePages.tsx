/* eslint-disable @typescript-eslint/no-explicit-any */
import { day, inr, KIND_COLOR, mon, short } from "@/lib/format";
import { E, L, LifeStatic, sheetsRef, type Ctx } from "@/lib/store";
import { type Col, DataTable, Delta, Grid, Kpi, KpiRow, Panel, toSheet, VBars } from "./kit";

const Muted = ({ children }: { children: string }) => <p className="text-xs text-muted-foreground">{children}</p>;

export function Property({ on }: Ctx) {
  const props = L.props as any[];
  const yearAgo = LifeStatic.addMonths(on, -12);
  const recent = props.flatMap((p) => (L.rentOf(p.id) as any[]).filter((r) => r.date > yearAgo && r.date <= on));
  const rentYear = recent.reduce((a, r) => a + r.amount, 0);
  const rentMonth = props.reduce((a, p) => a + p.rent, 0);
  const tax = props.reduce((a, p) => a + p.tax, 0);
  const p0 = props[0];
  const rcols: Col<any>[] = [
    { h: "Date", v: (r) => r.date, f: day },
    { h: "Property", v: (r) => props.find((p) => p.id === r.property)?.name ?? r.property },
    { h: "Amount", v: (r) => r.amount, f: inr, num: true },
  ];
  const receipts = props.flatMap((p) => L.rentOf(p.id) as any[]).filter((r) => r.date <= on);
  sheetsRef.current = [toSheet("Rent receipts", rcols, receipts)];
  return (
    <div className="space-y-5">
      <Muted>Property is not included in the consolidated total.</Muted>
      <KpiRow>
        <Kpi label="Rent per month" value={rentMonth} fmt={inr} />
        <Kpi label="Rent received, last 12 months" value={rentYear} fmt={inr} sub={`${recent.length} receipts`} />
        <Kpi label="House tax and maintenance per year" value={tax} fmt={inr} />
        <Kpi label="Current value versus cost" sub={p0 ? `Cost ${short(p0.cost)} in ${p0.costDate.slice(0, 4)}` : undefined}>
          {p0 ? <span>{short(p0.value)} <span className="text-sm"><Delta v={p0.value - p0.cost} text={short(p0.value - p0.cost)} /></span></span> : "—"}
        </Kpi>
      </KpiRow>
      {props.map((p) => {
        const nextTax = (L.taxDates(p, on, LifeStatic.addMonths(on, 12)) as string[])[0];
        const rents = (L.rentOf(p.id) as any[]).filter((r) => r.date <= on);
        return (
          <div key={p.id} className="space-y-4">
            <Grid>
              <Panel title={`${p.name}, ${p.city}`} sub="Property details as given in the data file.">
                <dl className="grid grid-cols-2 gap-3 text-sm">
                  <div><dt className="text-xs text-muted-foreground">Tenant</dt><dd className="font-semibold">{p.tenant}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Rent paid into</dt><dd className="font-semibold">{p.account}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Bought</dt><dd className="font-semibold num">{inr(p.cost)} on {day(p.costDate)}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Value</dt><dd className="font-semibold num">{inr(p.value)} on {day(p.valueDate)}</dd></div>
                </dl>
              </Panel>
              <Panel title="Lease, house tax and maintenance" sub="Lease dates and the next house tax and maintenance payment.">
                <dl className="grid grid-cols-2 gap-3 text-sm">
                  <div><dt className="text-xs text-muted-foreground">Lease</dt><dd className="font-semibold">{day(p.leaseStart)} to {day(p.leaseEnd)}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Rent due</dt><dd className="font-semibold">Day {p.rentDay} of each month</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Next house tax and maintenance</dt><dd className="font-semibold">{day(nextTax)} · {inr(p.tax)}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Last paid</dt><dd className="font-semibold">{day(p.taxPaid)}</dd></div>
                </dl>
              </Panel>
            </Grid>
            <Grid>
              <Panel title="Rent received, month by month" sub="Each rent receipt up to the chosen date. Hover for the amount.">
                <VBars data={rents.map((r) => ({ label: mon(r.date), Rent: r.amount }))} fmt={short} keys={[{ k: "Rent", color: "var(--eq)" }]} />
              </Panel>
              <Panel title="Rent receipts" sub="Click a heading to sort.">
                <DataTable label="Rent receipts" cols={rcols} rows={rents} />
              </Panel>
            </Grid>
          </div>
        );
      })}
    </div>
  );
}

export function Insurance({ on }: Ctx) {
  const ins = L.ins as any[];
  const life = ins.filter((p) => p.type === "Term life").reduce((a, p) => a + (p.cover ?? 0), 0);
  const med = ins.filter((p) => p.type === "Health").reduce((a, p) => a + (p.cover ?? 0), 0);
  const dues = ins.map((p) => ({ p, d: L.nextDue(p, on) as string | null })).filter((x) => x.d).sort((a, b) => (a.d! < b.d! ? -1 : 1));
  const next = dues[0];
  sheetsRef.current = [];
  return (
    <div className="space-y-5">
      <Muted>Insurance cover is not an asset and is not included in the consolidated total.</Muted>
      <KpiRow>
        <Kpi label="Life cover" value={life} fmt={short} sub={inr(life)} />
        <Kpi label="Medical cover" value={med} fmt={short} sub={inr(med)} />
        <Kpi label={`Insurance premiums in ${on.slice(0, 4)}`} value={L.yearPremiums(on)} fmt={inr} />
        <Kpi label="Next premium" sub={next ? `${next.p.name} · ${inr(next.p.premium)}` : undefined}>{next ? day(next.d) : "None"}</Kpi>
      </KpiRow>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {ins.map((p) => {
          const paid = L.paid(p, on) as number | null, total = L.total(p) as number | null;
          return (
            <Panel key={p.id} title={p.name} sub={`${p.type}${p.coverNote ? " · " + p.coverNote : ""}`}>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Cover</dt><dd className="num font-semibold">{p.cover ? inr(p.cover) : "—"}</dd></div>
                <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Premium</dt><dd className="num font-semibold">{inr(p.premium)} a year</dd></div>
                <div className="flex justify-between gap-2"><dt className="text-muted-foreground">Next due</dt><dd className="font-semibold">{day(L.nextDue(p, on))}</dd></div>
              </dl>
              {paid != null && total != null ? (
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-muted-foreground"><span>Years paid of total</span><span className="num">{paid} of {total}</span></div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuemin={0} aria-valuemax={total} aria-valuenow={paid} aria-label="Years paid">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${(paid / total) * 100}%` }} />
                  </div>
                </div>
              ) : <p className="mt-3 text-xs text-muted-foreground">Renews every year.</p>}
              {p.payout ? <p className="mt-3 rounded-lg bg-accent px-3 py-2 text-xs">Pays {inr(p.payout)} a month from {day(p.payoutStart)} to {day(p.payoutEnd)} ({L.payments(p)} payments).</p> : null}
            </Panel>
          );
        })}
      </div>
    </div>
  );
}

export function CashCalendar(_: Ctx) {
  const cal = L.calendar(E.latest, 12) as { date: string; kind: string; label: string; amount: number }[];
  const kinds = ["SIP", "Insurance", "House tax and maintenance"];
  const tot = (k?: string) => cal.filter((c) => !k || c.kind === k).reduce((a, c) => a + c.amount, 0);
  const byM = new Map<string, Record<string, any>>();
  cal.forEach((c) => {
    const m = c.date.slice(0, 7);
    const r = byM.get(m) ?? { label: mon(c.date), SIP: 0, Insurance: 0, "House tax and maintenance": 0 };
    r[c.kind] += c.amount;
    byM.set(m, r);
  });
  const cols: Col<(typeof cal)[number]>[] = [
    { h: "Date", v: (c) => c.date, f: day },
    { h: "Kind", v: (c) => c.kind },
    { h: "What", v: (c) => c.label },
    { h: "Amount", v: (c) => c.amount, f: inr, num: true },
  ];
  sheetsRef.current = [toSheet("Commitments", cols, cal)];
  const next = cal[0];
  return (
    <div className="space-y-5">
      <Muted>{`Money already committed in the 12 months after ${day(E.latest)}. Rent and deposit maturities are money coming in, so they are not listed.`}</Muted>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Kpi label="Next 12 months total" value={tot()} fmt={short} sub={inr(tot())} />
        <Kpi label="SIP" value={tot("SIP")} fmt={short} />
        <Kpi label="Insurance premiums" value={tot("Insurance")} fmt={short} />
        <Kpi label="House tax and maintenance" value={tot("House tax and maintenance")} fmt={short} />
        <Kpi label="Next commitment" sub={next ? `${next.label} · ${inr(next.amount)}` : undefined}>{next ? day(next.date) : "None"}</Kpi>
      </div>
      <Grid>
        <Panel title="Commitments by month" sub="Money going out each month, split by kind. Hover for amounts.">
          <VBars data={[...byM.values()]} fmt={short} keys={kinds.map((k) => ({ k, color: KIND_COLOR[k]! }))} />
        </Panel>
        <Panel title="SIP plan" sub="Monthly SIPs from the plan in the data file.">
          <ul className="divide-y divide-border text-sm">
            {(L.sip as any[]).map((s) => (
              <li key={s.key} className="flex items-center justify-between gap-3 py-2"><span className="min-w-0"><span className="block truncate font-medium">{s.name}</span><span className="text-xs text-muted-foreground">{s.folio} · day {s.day}</span></span><span className="num font-semibold">{inr(s.amount)}</span></li>
            ))}
            <li className="flex justify-between py-2 font-bold"><span>Total each month</span><span className="num">{inr(L.sipTotal)}</span></li>
          </ul>
        </Panel>
      </Grid>
      <Panel title="All commitments, next 12 months" sub="Sorted by date. Click a heading to sort differently.">
        <DataTable label="Commitments" cols={cols} rows={cal} />
      </Panel>
    </div>
  );
}
