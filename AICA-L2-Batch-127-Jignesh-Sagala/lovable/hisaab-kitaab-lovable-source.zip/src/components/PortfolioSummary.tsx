import { day, share, short } from "@/lib/format";
import type { PortfolioSnapshot } from "@/lib/portfolio-summary";

export default function PortfolioSummary({ snapshot }: { snapshot: PortfolioSnapshot }) {
  const { current, change } = snapshot;
  const allocation = snapshot.classes.filter((entry) => entry.value !== 0).map((entry) => `${entry.name.toLowerCase()} ${entry.sharePercent === null ? "—" : entry.sharePercent.toFixed(1) + "%"}`).join(", ");
  return (
    <section aria-label="Portfolio summary" className="border-y border-border py-5">
      <h2 className="text-sm font-bold">Portfolio in plain English</h2>
      <p className="mt-1 text-xs text-muted-foreground">{snapshot.filtered ? "Filtered view" : "Whole portfolio"} · {day(snapshot.on)}{snapshot.previousOn ? ` vs ${day(snapshot.previousOn)}` : " · No earlier snapshot"}</p>
      <div aria-live="polite" className="mt-3 max-w-4xl space-y-1 text-sm leading-relaxed">
        {snapshot.count ? <>
          <p>On {day(snapshot.on)}, the portfolio is worth {short(current.value)}.</p>
          <p>That is {short(Math.abs(current.gain))} {current.gain < 0 ? "below" : "above"} cost, {share(current.pct === null ? null : Math.abs(current.pct), 2)} {current.gain < 0 ? "loss" : "gain"} on cost.</p>
          <p>By value: {allocation}.</p>
          {snapshot.previousOn && change && <p>Since {day(snapshot.previousOn)}, the value is {change.value < 0 ? "down" : "up"} by {short(Math.abs(change.value))} ({share(change.pct === null ? null : Math.abs(change.pct), 2)}).</p>}
        </> : <p className="text-muted-foreground">No holdings match these filters.</p>}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">Calculated from the data in this file. No AI. Dummy data. Not investment advice.</p>
    </section>
  );
}
