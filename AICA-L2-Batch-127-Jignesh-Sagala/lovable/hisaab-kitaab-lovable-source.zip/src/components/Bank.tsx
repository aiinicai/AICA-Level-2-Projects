import { CCY_COLOR, day, inr, mon, num2, pct, short, sshort } from "@/lib/format";
import { E, groupSum, lines, sheetsRef, sum, type Ctx, type Line } from "@/lib/store";
import { type Col, DataTable, Delta, Grid, HBars, Kpi, KpiRow, Panel, toSheet, VBars } from "./kit";

export default function Bank({ on, F, toggle }: Ctx) {
  const all = lines(on, F);
  const bl = all.filter((l) => l.cls === "Bank balances");
  const fl = all.filter((l) => l.cls === "Term deposits");
  const both = [...bl, ...fl];
  const fx = both.filter((l) => l.ccy !== "INR");
  const usd = fx.filter((l) => l.ccy === "USD");
  const usdLocal = usd.reduce((a, l) => a + (l.local ?? 0), 0);
  const rate = E.fxOn("USD", on) as number | null;
  const next = fl.filter((l) => !l.matured).sort((a, b) => (a.daysLeft ?? 0) - (b.daysLeft ?? 0))[0];
  const matM = groupSum(fl, (l) => l.maturity?.slice(0, 7)).sort((a, b) => (a.k < b.k ? -1 : 1));
  const acols: Col<Line>[] = [
    { h: "Account", v: (l) => l.name },
    { h: "Bank or broker", v: (l) => l.bank },
    { h: "Type", v: (l) => l.kind },
    { h: "Currency", v: (l) => l.ccy },
    { h: "Balance in currency", v: (l) => l.local, f: num2, num: true },
    { h: "Value in INR", v: (l) => l.value, f: inr, num: true },
    { h: "As of", v: (l) => l.pdate, f: day },
  ];
  const fcols: Col<Line>[] = [
    { h: "Bank", v: (l) => l.bank },
    { h: "Kind", v: (l) => l.kind },
    { h: "Start", v: (l) => l.start, f: day },
    { h: "Maturity", v: (l) => l.maturity, f: day },
    { h: "Rate %", v: (l) => l.rate, f: num2, num: true },
    { h: "Principal", v: (l) => l.principal, f: num2, num: true },
    { h: "Value on the date (INR)", v: (l) => l.value, f: inr, num: true },
    { h: "Days left", v: (l) => (l.matured ? 0 : l.daysLeft), f: (v, l) => (l.matured ? "Matured" : v), num: true },
    { h: "Currency", v: (l) => l.ccy },
  ];
  sheetsRef.current = [toSheet("Accounts", acols, bl), toSheet("Term deposits", fcols, fl)];
  return (
    <div className="space-y-5">
      <KpiRow>
        <Kpi label="Bank balances" value={sum(bl).value} fmt={short} sub={inr(sum(bl).value)} />
        <Kpi label="Term deposits" value={sum(fl).value} fmt={short} sub={<Delta v={sum(fl).gain} text={`${sshort(sum(fl).gain)} interest so far`} />} />
        <Kpi label="Foreign currency in INR" value={sum(fx).value} fmt={short} sub={usd.length ? `USD ${num2(usdLocal)} at ${num2(rate)}` : "None held"} />
        <Kpi label="Next maturity" sub={next ? `${inr(next.value)} · ${next.daysLeft} days left` : undefined}>{next ? day(next.maturity) : "None"}</Kpi>
      </KpiRow>
      <Grid>
        <Panel title="Balance by account" sub="Each bank and broker cash account in INR (foreign currency converted). Click a bar to filter.">
          <HBars data={groupSum(bl, (l) => l.account).map((g) => ({ k: g.k, value: g.value, fill: CCY_COLOR[g.lines[0]!.ccy] }))} fmt={short} onPick={(k) => toggle("account", k)} active={F.account} />
        </Panel>
        <Panel title="Deposits by maturity month" sub="Value of deposits grouped by the month they mature. Hover for the amount.">
          <VBars data={matM.map((g) => ({ label: mon(g.k + "-01"), Value: g.value }))} fmt={short} keys={[{ k: "Value", color: "var(--fd)" }]} />
        </Panel>
      </Grid>
      <Panel title="Currency split" sub="Bank and deposit value by currency, in INR. Click a bar to filter.">
        <HBars data={groupSum(both, (l) => l.ccy).map((g) => ({ k: g.k, value: g.value, fill: CCY_COLOR[g.k] }))} fmt={short} onPick={(k) => toggle("ccy", k)} active={F.ccy} />
      </Panel>
      <Panel title="Accounts" sub="Click a heading to sort. Click a row to filter to that account.">
        <DataTable label="Accounts" cols={acols} rows={bl} onRow={(l) => toggle("account", l.account)} active={(l) => l.account === F.account} />
      </Panel>
      <Panel title="Term deposits" sub={`Value includes simple interest up to the chosen date. Rates shown as given${fl.length ? ", e.g. " + pct((fl[0]!.rate ?? 0) / 100, 2) : ""}.`}>
        <DataTable label="Term deposits" cols={fcols} rows={fl} onRow={(l) => toggle("key", l.key)} active={(l) => l.key === F.key} />
        <p className="mt-2 text-xs text-muted-foreground">US dollar deposits are held in USD and shown in INR at the last USD/INR rate on or before the chosen date. Their cost is converted at the same rate, so gain or loss here excludes currency movement since the deposit date.</p>
      </Panel>
    </div>
  );
}
