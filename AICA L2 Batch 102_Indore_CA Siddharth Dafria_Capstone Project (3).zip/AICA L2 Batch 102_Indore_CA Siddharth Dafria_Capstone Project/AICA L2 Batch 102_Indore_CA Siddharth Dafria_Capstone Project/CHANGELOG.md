# QuarterIQ — Changelog
## Evolution from Prototype to Production Institutional Platform

### [Version 3.2.0] — 2026-10-22 (Concall NLP, 5-Pillar Scorecard, Trendlyne, Consensus Polls & Auto-PDF Export)

#### Added
- **Management Commentary & Concall Transcript NLP Intelligence (`src/analyzers/concall_nlp_engine.py`):**
  - Quantitative lexicon analysis scoring management tone and sentiment (0–100) and classifying tone shift vs prior quarters.
  - Management Credibility Index & Headwinds-to-Tailwinds Ratio tracking forward guidance commitments against realized results.
  - Buy-side institutional investor perspective takeaways emphasizing capital allocation, balance sheet durability, and operational leverage.
  - Strategic keywords frequency ledger and institutional Q&A scrutiny table tracking inquiries from tier-1 brokers (Kotak, Morgan Stanley, Motilal Oswal, Goldman Sachs).
- **Multi-Quarter Side-by-Side Analytical KPI Matrix (`src/reports/html_generator.py`):**
  - 8-quarter horizontal progression matrix across Core KPIs (Revenue, EBITDA, OPM%, PBT, PAT, Net Margin%, Diluted EPS, CFO).
  - Strict conditional color formatting: Emerald Green (`#10b981`) for expansion (>+2%), Rose Red (`#f43f5e`) for compression (<-2%), and Slate for stability, with YoY & QoQ variance calculations.
- **Automated Research PDF Dossier Compilation & Auto-Open (`src/services/pdf_export_service.py`):**
  - Headless Chromium/Edge print-to-pdf engine generating vector PDF dossiers directly in `11_Research_Reports/`.
  - Automatically launches the generated PDF in the user's default Windows PDF viewer and opens ChatGPT in browser with prompt copied to clipboard.
- **Statutory LODR Reg 33 Red-Flagging for Unavailable Results:**
  - Dynamic inspection of SEBI (LODR) Regulation 33 45-day window. Prominent Crimson Red alert banner generated when quarterly results are pending filing.
  - Injects a critical `REGULATORY_LODR_FILING` forensic audit finding and updates recommendation badges to "CONDITIONALLY RESTRICTED".
- **Trendlyne.com Integration (`src/providers/auto_harvester.py`):**
  - Added `Trendlyne.com` to `TRUSTED_SOURCES`. Harvester automatically pulls concall transcripts, investor presentations, and analyst consensus targets from Trendlyne.
- **Institutional 5-Pillar Scorecard & Analyst Consensus Targets (`src/analyzers/institutional_scores_engine.py`):**
  - Pillar 1: Surprise Earning / Forecast Score (0–100).
  - Pillar 2: Durability Score (0–100, cash conversion + leverage + Beneish/Altman/Piotroski).
  - Pillar 3: Valuation Score (0–100, multiple vs historical spread).
  - Pillar 4: Momentum Score (0–100, post-earnings drift + alpha vs Nifty).
  - Pillar 5: Average Analyst Target Price (INR, upside %, consensus recommendation, broker rating distribution).
- **Consensus Estimates Comparison with Tier-1 Polls (`src/analyzers/surprise_engine.py`):**
  - Granular forecast variance table comparing reported figures against **CNBC Awaaz Poll**, **Reuters / Refinitiv Consensus**, **Kotak Institutional Equities**, **Motilal Oswal Financial Services**, and **ICICI Direct Research**.
- **Unremovable CA Siddharth Dafria Branding (`src/core/branding.py`):**
  - Cryptographically protected branding for **Siddharth Dafria, Chartered Accountant** (M: 9977822290 | Email: sdafria@icai.org).
  - Integrated SVG CA seal, floating tamper-guard watermark pill, and DOM mutation observer tamper detection.
- **Expanded Test Suite (`tests/test_v31_enhancements.py`):**
  - Added unit and integration tests for all 7 enhancements, bringing the suite to 46 passing tests (100% PASS).

### [Version 3.1.0] — 2026-10-21 (Institutional Research Report & Multi-Quarter Engine Upgrade)

#### Added
- **13-to-20 Quarter Financial Trends & Inflection Engine (`src/analyzers/historical_engine.py`):**
  - Ingests and processes multi-year quarterly historical financial statements (Sales, Expenses, Operating Profit, OPM %, Depreciation, PBT, Tax, PAT, EPS).
  - Calculates sequential (QoQ), year-on-year (YoY), and rolling Trailing Twelve Month (TTM) fundamental growth trajectories.
  - Algorithmic turning-point and inflection detection identifying growth acceleration/deceleration, operating leverage, margin expansion/compression, and cash conversion health with confidence ratings and falsification tests.
- **Earnings Surprise Intelligence Engine (`src/analyzers/surprise_engine.py`):**
  - Systematic comparison of reported results against institutional street consensus (Kotak, Motilal Oswal, ICICI Direct), prior quarters, and seasonal benchmarks.
  - Transparent Earnings Surprise Score out of 100 with granular score components (Revenue, Margins, PAT, EPS, Cash Conversion).
- **IT Services Sector Operating Intelligence (`src/analyzers/sector_intelligence.py`):**
  - Specialized operational model for Indian IT Services (TCS, Infosys, HCLTech, Wipro, LTIMindtree, Tech Mahindra).
  - Tracks constant-currency (CC) growth, USD revenue, vertical industry segment performance and margins (BFSI, Consumer, CMT, Life Sciences, Manufacturing), deal TCV, annualized AI monetization, headcount, and attrition.
- **Historical Analogue Matching Engine (`src/analyzers/historical_analogue.py`):**
  - Multi-factor configuration matcher backtesting past cycles with matching growth, margin, and TCV dynamics (Q2 FY24, Q2 FY21, Q2 FY17) and evaluating subsequent 12-month returns and win rates.
- **Forward EPS & Valuation Engine (`src/analyzers/valuation_engine.py`):**
  - Probability-weighted 3-scenario forecasts (Bull, Base, Bear) for FY27 and FY28.
  - Discounted Cash Flow (DCF) intrinsic value modeling with explicit WACC and terminal growth assumptions.
  - 4x4 Valuation Sensitivity Matrix mapping Revenue Growth against EBIT Margin to compute target share prices.
- **Share-Price Post-Earnings Reaction Engine (`src/analyzers/reaction_engine.py`):**
  - Empirical drift analysis across T+1, T+3, T+5, T+20, and T+60 session horizons.
  - Win-rate statistics, median returns, drawdowns, and relative performance vs Nifty 50 and Nifty IT.
- **Macro, Behavioural & Cycle Perspective Overlays (`src/analyzers/cycle_macro_engine.py`):**
  - Institutional flow dynamics (FII/DII positioning), USD/INR foreign exchange sensitivity (+100 bps INR = ~38 bps EBIT margin), and enterprise tech spending cycle.
  - Strictly segregated experimental timing hypotheses clearly demarcated from fundamental accounting evidence.
- **17-Section Institutional Terminal Interface (`src/reports/html_generator.py`):**
  - Interactive SVG trend charts with dynamic 4Q/8Q/12Q/All quarters toggle buttons.
  - Real-time client-side JavaScript tooltips for data point inspection.
  - Complete executive scorecard answering the 7 Core Institutional Research Questions.
  - Full Ind AS audited financial statements, vertical segment tables, and evidence ledger.
  - Seamless Light/Dark theme switcher and print-ready A4 PDF export CSS.
- **Expanded Test Suite (`tests/test_v3_engines.py`):**
  - Added unit tests for all 7 new analytical engines and banking sector ratio isolation, bringing test suite to 32 passing tests (100% PASS).

### [Version 2.1.0] — 2026-10-20 (Full Automation & Multi-Source Harvest Update)

#### Added
- **Multi-Source Automated Harvester (`src/providers/auto_harvester.py`):**
  - Direct scraping from Screener.in (`/company/{SYMBOL}/consolidated/`) to resolve direct BSE/NSE announcement and filing PDFs (`AnnPdfOpen.aspx`, `AttachHis`).
  - Company IR website crawler automatically querying discovered corporate domains for quarterly investor portals (`/investors`, `/financials.html`) and direct PDF reports.
  - SEBI regulatory disclosures crawler monitoring draft offer documents, buyback notices, and takeover filings.
  - Automatic category classification and priority-based downloading into designated workspace folders.
- **User Document Attachment Capability:**
  - Multi-file attachment module on New Research tab allowing analysts to inject broker research, custom financial models, management notes, or supplementary filings into the automated pipeline.
  - Automatic SHA-256 computation, manifest registration, and workspace routing.
- **End-to-End One-Click Auto-Pilot (`AutoPilotWorker`):**
  - Seamless 8-stage automated pipeline:
    1. Workspace initialization & directory provisioning.
    2. User-attached document ingestion.
    3. Multi-source harvesting & downloading across Screener, Company IR, and SEBI.
    4. PyMuPDF cryptographic validation and entity matching.
    5. Ind AS financial data extraction and deterministic ratio computation.
    6. CA Forensic Intelligence audit (Beneish M-Score, Altman Z, Piotroski F, CFO/EBITDA divergence).
    7. Dual-mode reconciliation and audit ledger synchronization.
    8. Interactive HTML dashboard generation and ChatGPT prompt clipboard preparation.
  - One-click trigger buttons on New Research tab and Dashboard.
- **Expanded Test Suite (`tests/test_auto_harvester.py`):**
  - 4 new unit tests covering multi-source harvesting and downloading logic, bringing total automated test suite to 25 passing tests.

### [Version 2.0.0] — 2026-10-19 (ICAI AI Level 2 Capstone Deliverable)

#### Added
- **Native PySide6 Desktop GUI:**
  - Transitioned from standard tkinter to high-performance PySide6 financial research terminal.
  - Full modern dark theme (`#0b0f19`) and light theme (`#f8fafc`) with dynamic stylesheet switcher.
  - Tab navigation across 10 specialized functional modules.
  - Asynchronous background worker threads (`QThread`) ensuring zero GUI freezing during network operations and PDF parsing.
- **Indian Fiscal Year & Calendar Logic Engine:**
  - Standardized calculation of Indian fiscal quarters (Q1 April–June, Q2 July–September, Q3 October–December, Q4 January–March).
  - Built-in SEBI LODR Regulation 33 deadline tracking (45-day window for Q1–Q3, 60-day for Q4).
  - Integrated 500+ Listed Indian Company Master with autocomplete search and ticker resolution.
- **12-Folder Hierarchical Workspace Manager:**
  - Generates standardized research folders (`01_Financial_Results` through `12_Audit_Logs`).
  - Implements atomic JSON writing for `source_manifest.json`, `research_config.json`, and `document_checklist.json`.
  - Generates `source_manifest.csv` and timestamped `download_log.txt`.
  - Integrated SHA-256 cryptographic digest computation and duplicate detection.
- **Document Discovery & Direct Downloader:**
  - Real discovery adapters for NSE India Integrated Filings, BSE India, Screener.in, Trendlyne, and Company IR search.
  - Direct HTTPS streaming downloader with exponential backoff (3 attempts), 100 MB safety cap, and magic-byte inspection (`%PDF`, `PK\x03\x04`). Rejects HTML login/captcha pages.
- **Document Content & Authenticity Validator:**
  - Uses `pymupdf` to verify company name/ticker, quarter-end date, and statutory auditor report signatures ("Limited Review Report", "Chartered Accountants").
  - Emits granular verification states: `VERIFIED`, `SUSPECT_PERIOD_MISMATCH`, `SUSPECT_ENTITY_MISMATCH`, and `UNVERIFIED`.
- **Ind AS Financial Data Engine:**
  - Extracts statement line items from PDFs and spreadsheets.
  - Normalizes reported units (Lakhs, Crores, Millions, Thousands) to INR Crore (`INR Cr`).
  - Implements deterministic Python ratio calculations (Revenue YoY/QoQ, EBITDA margin, PAT margin, Debt/EBITDA, Interest Coverage, CFO/EBITDA, and Working Capital Days DSO, DIO, DPO, CCC).
  - Statement arithmetic reconciliation audit testing total income, PBT, and PAT equations.
- **CA-Grade Forensic Intelligence Engine:**
  - Revenue vs. Receivables growth divergence alert (>15% spread).
  - Operating cash realization test (CFO / EBITDA < 0.8x flag).
  - Beneish M-Score (earnings manipulation risk).
  - Altman Z-Score (solvency & bankruptcy distress zones).
  - Piotroski F-Score (0 to 9 fundamental health metric).
- **Prompt Engineering & AI Integration:**
  - Dual-mode workflow: Mode A Browser-Assisted (zero API key) and Mode B (Official OpenAI/Anthropic API).
  - Dynamic runtime context injection embedding document inventory, extracted metrics, and forensic flags.
  - Integrated Windows system clipboard synchronization.
- **Self-Contained Interactive HTML Research Dashboard:**
  - Fully offline-compatible single-file deliverable.
  - Responsive sticky header, TOC navigation, dark/light theme, and print-ready A4 CSS.
  - Embedded inline SVG dual-axis trend charts, KPI cards, and comprehensive audit citation register.
- **SQLite Multi-Company Research Database:**
  - Persistent SQLite storage (`quarteriq_master.db`) tracking companies, sessions, documents, and historical ratings.
- **Automated Testing Suite:**
  - 21 automated unit, integration, and UI smoke tests executed via pytest.
- **Windows Executable Packaging:**
  - Automated PyInstaller build script producing `release/QuarterIQ/QuarterIQ.exe`.

#### Changed
- Upgraded architecture from single-file script to modular production-grade structure (`src/core`, `src/providers`, `src/analyzers`, `src/services`, `src/reports`, `src/ui`).
- Enhanced prompt integration with strict non-negotiable compliance rules against hallucination.
