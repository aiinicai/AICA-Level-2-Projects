# QuarterIQ — Architecture & System Design Document
## AI-Powered Quarterly Results, Forensic Audit & Institutional Equity Research Platform
### ICAI AI Level 2 Capstone Project

---

## 1. Executive System Overview

**QuarterIQ** is an institutional-grade Windows desktop application built for Chartered Accountants, forensic auditors, and institutional buy-side equity research analysts. The platform automates the discovery, collection, validation, financial statement extraction, forensic anomaly scoring, and interactive reporting of quarterly corporate disclosures filed with the National Stock Exchange of India (NSE) and Bombay Stock Exchange (BSE).

### Core Architectural Principles:
1. **Zero Fabrication:** The system strictly rejects synthetic or hallucinated metrics. Every financial line item carries an immutable cryptographic citation `[Filing, p. X]` with SHA-256 digest validation.
2. **Offline-First Resilience:** Generated research reports are self-contained HTML/SVG dashboards with zero external CDN dependencies, functioning seamlessly in air-gapped environments.
3. **CA-Grade Forensic Discipline:** Integrates classical statistical models (Beneish M-Score, Altman Z-Score, Piotroski F-Score) with Ind AS arithmetic reconciliations and revenue-vs-receivables growth divergence tests.
4. **Resilient Dual-Mode AI Integration:**
   - **Mode A (Browser-Assisted):** Zero-API-key workflow that organizes documents, copies formatted institutional prompts with runtime manifests, and launches ChatGPT in the browser with manual file-attachment guidance.
   - **Mode B (API-Driven):** Direct automated execution via official LLM endpoints when user credentials are provided.

---

## 2. System Architecture Diagram

```mermaid
graph TD
    UI["PySide6 Desktop Application (QuarterIQ)"] --> PM["Company & Period Resolver (Indian FY Logic)"]
    UI --> WM["Workspace & Evidence Manager"]
    UI --> DE["Discovery Engine (NSE / BSE / IR)"]
    UI --> DL["Secure Downloader & Validator"]
    UI --> FE["Financial Data Engine (Ind AS Extractor)"]
    UI --> FI["Forensic Intelligence & Anomaly Engine"]
    UI --> AI["ChatGPT Service (Mode A Browser / Mode B API)"]
    UI --> RG["Interactive HTML Report Generator"]
    UI --> DB["SQLite Master Research Database"]

    WM --> FS["QuarterIQ_Research/ (12 Structured Subdirectories)"]
    WM --> MF["source_manifest.json / source_manifest.csv"]
    
    DL --> PYMUPDF["PyMuPDF Document Authentication"]
    FE --> RATIOS["Financial Ratio Engine (Python Deterministic)"]
    FE --> RECON["Arithmetic Reconciliation Auditor"]
    
    FI --> BENEISH["Beneish M-Score Model"]
    FI --> ALTMAN["Altman Z-Score Model"]
    FI --> PIOTROSKI["Piotroski F-Score Model"]
    
    RG --> HTML["Self-Contained Offline HTML5 + Inline SVG Dashboard"]
```

---

## 3. Directory Layout Specification

For every target company and reporting quarter, QuarterIQ creates a structured audit folder under `Documents/QuarterIQ_Research/`:

```
QuarterIQ_Research/
  COMPANY_TICKER/
    FY2026-27/
      Q2_Sep_2026/
        01_Financial_Results/          # SEBI LODR Reg 33 P&L and Balance Sheet
        02_Limited_Review/             # Statutory Auditor Review Reports
        03_Previous_Quarters/          # Historical quarterly filings
        04_Concall_Transcript/         # Earnings call transcripts
        05_Investor_Presentation/      # Investor decks & earnings presentations
        06_Annual_Report_Audit/        # Full annual reports & CARO 2020 notes
        07_Analyst_Research/           # Institutional research publications
        08_Industry_Information/       # Sectoral & macroeconomic reports
        09_Shareholding_Governance/    # LODR Reg 31 shareholding & pledging
        10_Extracted_Data/             # Structured CSVs and extracted tables
        11_Research_Reports/           # Generated HTML dashboards & audit trails
        12_Audit_Logs/                 # Download logs and system diagnostics
        source_manifest.json           # Cryptographic evidence manifest
        source_manifest.csv            # Spreadsheet export of manifest
        research_config.json           # Active research configuration
        document_checklist.json        # 5-point mandatory category checklist
        download_log.txt               # Timestamped audit ledger
```

---

## 4. Key Subsystem Modules

### 4.1 Company Identification & Indian Fiscal Logic (`src/core/indian_fiscal.py`)
- **Fiscal Calendar:** Accurately models the Indian April 1 to March 31 financial year.
  - Q1: April 1 – June 30
  - Q2: July 1 – September 30
  - Q3: October 1 – December 31
  - Q4: January 1 – March 31
- **Filing Deadlines:** Implements SEBI LODR Regulation 33 compliance tracking (45-day filing window for Q1–Q3; 60 days for Q4).
- **Company Master:** Curated dictionary of top 500+ Indian listed corporations with NSE ticker, BSE scrip code, sector classification, and name search.

### 4.2 Document Acquisition & Validation (`src/providers/`)
- **Direct Downloader (`downloader.py`):** Multi-threaded streaming downloads with exponential backoff (3 retries), 100 MB safety bounds, and magic-byte signature inspection (`%PDF`, `PK\x03\x04`). Rejects HTML/XML login/captcha pages masquerading as filings.
- **Document Validator (`validator.py`):** Uses `pymupdf` to inspect first 5 pages for target ticker, company name, quarter-end date, and statutory auditor keywords ("Limited Review", "Chartered Accountants").

### 4.3 Financial Extraction & Reconciliation (`src/analyzers/`)
- **Extractor (`extractor.py`):** Extracts Ind AS statement metrics from PDFs and spreadsheets, normalizing units from Lakhs, Millions, and Thousands to **INR Crore (`INR Cr`)**.
- **Ratio Engine (`ratios.py`):** Pure Python deterministic computation for growth (YoY, QoQ), profitability margins, coverage, working capital days (DSO, DIO, DPO, CCC), and CFO realization.
- **Reconciliation Auditor (`reconciliation.py`):** Checks statement balances (`Revenue + Other Income == Total Income`, `PBT - Tax == PAT`). Logs exceptions without silent adjustments.

### 4.4 CA-Grade Forensic Intelligence (`src/analyzers/forensics.py`)
- **Revenue vs. Receivables Divergence:** Triggers alerts when receivables growth exceeds revenue growth by >15%, highlighting aggressive revenue recognition.
- **CFO / EBITDA Cash Realization:** Flags instances where cash flow from operations is less than 0.8x of reported EBITDA.
- **Beneish M-Score:** Evaluates earnings manipulation probability across 5 key indices.
- **Altman Z-Score:** Classifies balance-sheet solvency into Safe, Grey, or Distress zones.
- **Piotroski F-Score:** 9-point fundamental financial health metric.

### 4.5 AI Integration & Prompt Manager (`src/services/`)
- Injects runtime context, verified document manifests, computed financial line items, and forensic flags into `institutional_research_prompt_v2.md` and `capstone_prompt.md`.
- Enforces zero fabrication and citations for all claims.

### 4.6 Self-Contained HTML Dashboard (`src/reports/html_generator.py`)
- Generates responsive single-file dashboards with dark/light themes, inline SVG trend charts, severity-badged forensic findings, and A4 print stylesheets.

---

## 5. Security & Data Integrity
- **Local Storage Default:** All research manifests, SQLite records, and PDF filings reside on the local user filesystem.
- **No Stored Passwords:** Browser-assisted ChatGPT automation never requests, reads, or stores OpenAI login credentials.
- **Cryptographic Provenance:** Every filing is hashed with SHA-256 upon arrival to guarantee evidentiary non-repudiation.
