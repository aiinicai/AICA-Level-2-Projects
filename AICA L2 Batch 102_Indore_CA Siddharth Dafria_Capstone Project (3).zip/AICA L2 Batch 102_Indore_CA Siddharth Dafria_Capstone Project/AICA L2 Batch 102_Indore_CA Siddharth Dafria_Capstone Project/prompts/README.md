# QuarterIQ — ICAI AI Level 2 Capstone (Starter Kit)

**Purpose:** A practical, no-API desktop tool for collecting an Indian listed company's quarterly disclosures, creating an auditable source folder and running an AI research prompt through ChatGPT's website, culminating in an HTML report. This is a **working starter**, not a fully automated browser agent or a working institutional valuation engine.

## Windows setup (typically no third-party libraries required)
1. Install Python 3.10 or newer from python.org; include tkinter (normal Windows installer includes it).
2. Extract this ZIP into a regular folder, e.g. `D:\ICAI_Capstone\QuarterIQ`.
3. Double-click **run_windows.bat**. Alternatively open Command Prompt inside the folder and type `py -3 quarteriq.py`.
4. Fill **Company name**, **NSE symbol**, and **Quarter**. Enter the target quarter explicitly, e.g. `Q2 FY2026-27`. Then press **Create / Open Workspace**.
5. Press **Open Official Filing Sources**. NSE and BSE pages plus company IR search open in your default browser. Select the company and exact quarter. Note: for quarters ending March 2025 onwards, NSE says results may be in **Integrated Filing – Financials**, not its older financial-results tab.
6. Download the verified results/limited-review report, at least two historical quarters, concall transcript, presentation and latest annual report/auditor report. Where you have the direct HTTPS PDF URL, choose the document category and press **Download URL**; if the website blocks direct access or needs interactive search, download in your browser and press **Import Downloaded Files** (set correct document category first).
7. Press **Check Evidence** and verify the actual PDF company, quarter, consolidated/standalone basis, PDF page labels and revisions. The manifest's hash ensures file integrity; it **does not** validate the filing.
8. Press **Copy ChatGPT Prompt**. It creates `prompt_ready_to_paste.txt` and copies the prompt to clipboard.
9. Press **Open ChatGPT**. Attach relevant source documents in the chat (manual step). Paste the prompt. Ask ChatGPT to return an actual **downloadable self-contained HTML** research report and check the cited figures against source PDFs.
10. Download the HTML report and save it manually into `10_Output_Report`. Use **Generate HTML Report Shell** if you want a local evidence/readiness page before analysis. The shell intentionally has **NO invented data** and is not the final research report.

## Folder structure
```
QuarterIQ_Research/
  TICKER/
    Q2_FY2026-27/
      01_Financial_Results/
      02_Prior_Quarters/
      03_Concall_Transcript/
      04_Investor_Presentation/
      05_Annual_Reports_Audit/
      06_Broker_Research/
      07_Industry_Macro/
      08_Ownership_Governance/
      09_Other_Evidence/
      10_Output_Report/
      source_manifest.json
      source_manifest.csv
      prompt_ready_to_paste.txt
```

## Choosing the prompt
- Default **capstone_prompt.md**: concise enough for a course demo; extraction first, verdict later.
- **institutional_research_prompt_v2.md**: the user's supplied 15-section advanced prompt, unchanged. Its many analytics and 8-quarter chart requirements cannot be completed correctly from 4–6 attachments; missing data must be flagged or sections omitted, not invented.

## Evidence discipline
- Authoritative: NSE/BSE filings and company investor relations. Prioritize signed financial results and limited-review/annual audit reports over investor presentations.
- Research analyst notes may be paid/licensed; use only documents you are entitled to download and upload.
- As of Oct 2026, the quarter ending Sep 2026 is not necessarily *filed* for every company. The application does **not** falsely claim to know the latest filed quarter automatically.
- Neither a file's name nor its digest proves authenticity. Verify source, content, exact quarter, basis, revisions, and page references.
- For Q1/Q3, full quarterly balance sheet/cash flow data may be missing; avoid false quarter-level CFO metrics.
- Projections and advice: if sharing externally, independently review current SEBI Research Analyst and investment-advice compliance, including Oct 2026 amendments. Capstone private classroom demonstration is not itself a license to publish buy/sell calls.

## What IS automated, what is NOT
| Feature | Status |
|---|---|
| Create company/quarter folder | Automated |
| Create category directories | Automated |
| Download a document from user-pasted direct HTTPS link | Automated when permitted; HTTP redirects, errors or login can defeat it |
| Import PDFs and record hashes/sources/timestamps | Automated |
| Launch official search pages | Automated browser launch; discovery is manual |
| Locate the newest genuine quarterly report across all companies | NOT automated |
| Browser ChatGPT file attachments and prompt submission | Manual (deliberate: stable, safer, no brittle UI scripting) |
| HTML readiness shell | Automated; no financial values invented |
| Full financial research HTML | Generated by ChatGPT after manual upload; factual quality needs review |

## Suggested 5-minute ICAI demo
1. Enter `TATASTEEL`, create the workspace. Show the folder hierarchy (45 seconds).
2. Import 3–5 previously downloaded public PDFs in correct categories (60 seconds).
3. Check evidence, open source manifest and discuss SHA-256, missing categories (60 seconds).
4. Copy prompt and open ChatGPT; use a report prepared in advance from these same documents for time certainty (60 seconds).
5. Open the final HTML report, show KPI, forensic flags, cites and dark/light mode; explain deliberate NO-TRADE when inputs are missing (75 seconds).

## Capstone novelty, measurable acceptance tests
- **Traceability:** For 10 sampled numbers in the final report, all 10 must point back to the source filing/page. Missing page is NOT VERIFIED.
- **Numerical accuracy:** Recompute 10 randomly chosen YoY/QoQ figures; tolerance defined for display rounding only.
- **Data separation:** Verify no standalone figures enter consolidated growth calculations.
- **Missing source:** Remove concall file; application flags missing document. Generated report may NOT quote management concall.
- **Changed quarter:** Compare source PDF quarter vs requested quarter; manually record wrong-quarter case.
- **No invention:** Remove current market price/consensus; report must mark NOT VERIFIED rather than invent a target.

## Source portals
- [NSE — Financial Results](https://www.nseindia.com/companies-listing/corporate-filings-financial-results)
- [NSE — Corporate Announcements](https://www.nseindia.com/companies-listing/corporate-filings-announcements)
- [BSE — Financial Results](https://www.bseindia.com/corporates/Comp_Resultsnew.aspx)
- Company website's Investor Relations section

## Security / limitations
Do not upload client confidential files, material non-public information, or licensed research without permission. Direct URL downloads use ordinary HTTPS and do not bypass authentication. Browser automation of ChatGPT UI is purposefully excluded; manual attachment is necessary in this version. The tool and its generated shell are educational, and are **not** SEBI-regulated research advisory services.
