# QuarterIQ — Build, Packaging & Execution Instructions
## Windows 10/11 x64 Platform

---

## 1. System Requirements & Prerequisites
- **Operating System:** Windows 10 or Windows 11 (x64)
- **Python Runtime:** Python 3.10 to Python 3.14 (64-bit)
- **Minimum Disk Space:** 500 MB for source & dependencies, 1 GB for compiled release
- **Required Libraries:**
  - `PySide6` (GUI)
  - `pandas`, `openpyxl` (Tabular data & Excel reading)
  - `pymupdf` (PDF text and layout validation)
  - `pdfplumber` (Table extraction)
  - `requests`, `beautifulsoup4` (Network discovery and streaming downloads)
  - `pyinstaller` (Executable compilation)
  - `pytest` (Automated quality control)

---

## 2. Setting Up Development Environment

Open PowerShell in the QuarterIQ root folder:

```powershell
# 1. Install dependencies
python -m pip install -r requirements.txt

# 2. Verify PySide6 and PyMuPDF imports
python -c "from PySide6.QtWidgets import QApplication; import pymupdf; print('All core libraries verified!')"
```

---

## 3. Running QuarterIQ from Source

### Via Python:
```powershell
python quarteriq.py
```

### Self-Test Mode (Headless / Automated):
```powershell
python quarteriq.py --test-mode
```

### Via Windows Batch Launcher:
Double-click `run_windows.bat` in the application directory.

---

## 4. Executing Automated Test Suite

QuarterIQ includes 21 comprehensive unit, integration, and UI smoke tests:

```powershell
python -m pytest
```

Expected output:
```
============================= test session starts =============================
collected 21 items
tests/test_financial_ratios.py::test_financial_ratios_calculation PASSED
tests/test_forensics.py::test_forensic_receivables_divergence PASSED
tests/test_forensics.py::test_forensic_cfo_ebitda_warning PASSED
tests/test_forensics.py::test_beneish_and_altman_scores PASSED
tests/test_html_generator.py::test_html_report_generation PASSED
tests/test_indian_fiscal.py::test_parse_quarter_str PASSED
tests/test_indian_fiscal.py::test_quarter_date_bounds PASSED
tests/test_indian_fiscal.py::test_format_folder_period_name PASSED
tests/test_indian_fiscal.py::test_indian_currency_formatting PASSED
tests/test_indian_fiscal.py::test_normalize_to_inr_crore PASSED
tests/test_indian_fiscal.py::test_search_and_resolve_company PASSED
tests/test_indian_fiscal.py::test_filing_status PASSED
tests/test_prompt_manager.py::test_prompt_generation PASSED
tests/test_reconciliation.py::test_reconciliation_pass PASSED
tests/test_reconciliation.py::test_reconciliation_discrepancy_detection PASSED
tests/test_ui_smoke.py::test_main_window_instantiation PASSED
tests/test_validator.py::test_validator_with_synthetic_pdf PASSED
tests/test_validator.py::test_validator_detects_entity_mismatch PASSED
tests/test_validator.py::test_validator_detects_period_mismatch PASSED
tests/test_workspace.py::test_workspace_creation PASSED
tests/test_workspace.py::test_add_document_and_sha256 PASSED
============================= 21 passed in 1.96s ==============================
```

---

## 5. Compiling the Windows Executable (`QuarterIQ.exe`)

Run the automated PyInstaller build and verification script:

```powershell
python scripts/build_exe.py
```

### What this script does:
1. Gathers all application source code, assets, and prompt templates.
2. Invokes PyInstaller targeting Windows x64.
3. Automatically excludes unused heavy machine learning frameworks to maintain a fast, lean distribution.
4. Generates the standalone folder at `release/QuarterIQ/`.
5. The primary Windows executable is produced at:
   `release/QuarterIQ/QuarterIQ.exe`
6. Runs an automated smoke test on the freshly built executable (`QuarterIQ.exe --test-mode`) to verify startup and return code 0 before concluding.

---

## 6. Creating a Standalone Zip Distribution

To distribute QuarterIQ to another Windows workstation without requiring Python:
```powershell
Compress-Archive -Path release\QuarterIQ -DestinationPath release\QuarterIQ_Windows_x64.zip -Force
```

The user simply extracts `QuarterIQ_Windows_x64.zip` and double-clicks `QuarterIQ.exe`.
