"""Tests for Browser Launcher & Automated Report Opening."""
from pathlib import Path
import pytest
from src.utils.browser_launcher import get_browser_binaries, open_html_report_in_browser


def test_get_browser_binaries():
    """Verifies browser binary discovery doesn't crash."""
    binaries = get_browser_binaries()
    assert isinstance(binaries, list)


def test_open_html_report_non_existent():
    """Verifies non-existent path returns False cleanly."""
    assert open_html_report_in_browser("non_existent_file_xyz_123.html") is False


def test_open_html_report_mocked(tmp_path, monkeypatch):
    """Verifies that open_html_report_in_browser invokes OS launcher."""
    test_html = tmp_path / "test_report.html"
    test_html.write_text("<h1>Test</h1>", encoding="utf-8")
    
    launched = []
    monkeypatch.setattr("os.startfile", lambda p: launched.append(p))
    
    success = open_html_report_in_browser(test_html)
    assert success is True
    assert len(launched) >= 1
    assert any("test_report.html" in str(p) for p in launched)
