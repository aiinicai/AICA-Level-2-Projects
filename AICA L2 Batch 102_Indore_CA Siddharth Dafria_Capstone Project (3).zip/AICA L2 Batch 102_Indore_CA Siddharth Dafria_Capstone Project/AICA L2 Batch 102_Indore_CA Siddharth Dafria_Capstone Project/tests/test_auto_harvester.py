"""Unit tests for the Automated Multi-Source Harvester (Screener.in, Company IR, SEBI)."""
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from src.core.models import DocumentRecord, ResearchConfig
from src.core.workspace import WorkspaceManager
from src.providers.auto_harvester import AutoDocumentHarvester


def test_harvester_init():
    harvester = AutoDocumentHarvester()
    assert "Mozilla" in harvester.user_agent
    assert "Accept" in harvester.session.headers


def test_harvest_screener_mock():
    harvester = AutoDocumentHarvester()

    mock_html = """
    <html>
      <body>
        <a class="company-website" href="https://www.infosys.com">Official Website</a>
        <div class="documents concalls">
          <a href="https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=concall_transcript.pdf">Transcript Q2 FY27</a>
          <a href="/concall/ppt.pdf">Earnings Presentation PPT</a>
        </div>
        <div class="documents annual-reports">
          <a href="https://www.bseindia.com/AttachHis/ar2026.pdf">Annual Report 2026</a>
        </div>
        <div class="documents">
          <a href="/announcement/results.pdf">Unaudited Financial Results for Q2 ended Sep 2026</a>
        </div>
      </body>
    </html>
    """

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = mock_html

    with patch.object(harvester.session, "get", return_value=mock_response):
        website, docs = harvester.harvest_screener("INFY")

    assert website == "https://www.infosys.com"
    assert len(docs) >= 3

    categories = [d["category"] for d in docs]
    assert "Concall Transcript" in categories
    assert "Investor Presentation" in categories
    assert "Annual Report / Audit" in categories


def test_harvest_company_website_mock():
    harvester = AutoDocumentHarvester()

    mock_ir_html = """
    <html>
      <body>
        <h2>Quarterly Results</h2>
        <a href="/investors/q2-2027-financial-results.pdf">Q2 2027 Financial Results</a>
        <a href="/investors/investor-presentation-q2.pdf">Investor Presentation</a>
        <a href="/investors/concall-transcript-q2.pdf">Concall Transcript</a>
      </body>
    </html>
    """

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.headers = {"Content-Type": "text/html"}
    mock_response.text = mock_ir_html

    with patch.object(harvester.session, "get", return_value=mock_response):
        docs = harvester.harvest_company_website("https://www.example.com", "TEST", "Test Ltd")

    assert len(docs) == 3
    cats = {d["category"] for d in docs}
    assert "Financial Results" in cats
    assert "Investor Presentation" in cats
    assert "Concall Transcript" in cats


def test_auto_download_documents_mock(tmp_path):
    cfg = ResearchConfig(
        company_symbol="INFY",
        company_name="Infosys Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        output_base_dir=str(tmp_path)
    )
    ws = WorkspaceManager(cfg)
    ws.create_structure()

    harvester = AutoDocumentHarvester()

    mock_docs = [
        {"title": "Financial Results Q2", "url": "https://example.com/res.pdf", "category": "Financial Results", "source": "Screener"},
        {"title": "Concall Transcript Q2", "url": "https://example.com/concall.pdf", "category": "Concall Transcript", "source": "Screener"},
    ]

    mock_record = DocumentRecord(
        file_name="res.pdf",
        category="Financial Results",
        file_path="01_Financial_Results/res.pdf",
        file_size_bytes=1024,
        sha256="abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
        source_origin="https://example.com/res.pdf",
        source_type="auto_crawler",
        collected_at="2026-10-20 14:00:00 IST",
        verification_status="VERIFIED"
    )

    with patch.object(harvester.downloader, "download_file", return_value=mock_record):
        results = harvester.auto_download_documents(ws, mock_docs, max_per_category=1)

    assert len(results) == 2
    # Verify manifest documents
    assert len(ws.get_manifest()["documents"]) == 2
