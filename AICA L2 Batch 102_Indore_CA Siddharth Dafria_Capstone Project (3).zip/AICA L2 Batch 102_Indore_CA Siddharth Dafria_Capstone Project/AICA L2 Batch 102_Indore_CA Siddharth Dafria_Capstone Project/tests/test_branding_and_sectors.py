"""Tests for author branding, tamper-resistance, and dynamic multi-sector intelligence."""
import pytest
from pathlib import Path

from src.core.branding import (
    AUTHOR_NAME,
    AUTHOR_DESIGNATION,
    AUTHOR_MOBILE,
    AUTHOR_EMAIL,
    AUTHOR_ORGANIZATION,
    TamperProtectionViolation,
    verify_brand_integrity,
    enforce_brand_integrity,
    get_branding_dict,
)
from src.core.indian_fiscal import get_company_sector_profile
from src.analyzers.historical_engine import HistoricalIntelligenceEngine
from src.analyzers.sector_intelligence import SectorIntelligenceEngine
from src.reports.html_generator import HTMLReportGenerator
from src.core.models import (
    FinancialMetrics,
    FinancialRatios,
    ForensicScores,
    ResearchConfig,
)


def test_branding_integrity_verification():
    """Verify that the official author branding passes cryptographic verification."""
    assert verify_brand_integrity() is True
    # Should not raise exception
    enforce_brand_integrity()

    meta = get_branding_dict()
    assert meta["name"] == "Siddharth Dafria"
    assert meta["designation"] == "Chartered Accountant"
    assert meta["mobile"] == "9977822290"
    assert meta["email"] == "sdafria@icai.org"
    assert meta["organization"] == "Institute of Chartered Accountants of India (ICAI)"


def test_tamper_detection_protection(monkeypatch):
    """Verify that tampering with any author identity raises TamperProtectionViolation."""
    import src.core.branding as b

    # Attempt to tamper with author name
    monkeypatch.setattr(b, "AUTHOR_NAME", "Anonymous Hacker")
    assert verify_brand_integrity() is False
    with pytest.raises(TamperProtectionViolation) as exc_info:
        enforce_brand_integrity()
    assert "critical security violation" in str(exc_info.value).lower()


def test_sector_profiler_banking():
    """Test dynamic sector classification and leadership for ICICI Bank."""
    profile = get_company_sector_profile("ICICIBANK")
    assert profile["sector_type"] == "BANKING"
    assert profile["is_banking"] is True
    assert "Nifty Bank" in profile["benchmark_index"]
    peer_symbols = [p["symbol"] for p in profile["peers"]]
    assert "HDFCBANK" in peer_symbols
    assert "SBIN" in peer_symbols
    assert "INFY" not in peer_symbols
    assert "Sandeep Bakhshi" in profile["leadership"]["md_ceo"]
    assert "Anindya Banerjee" in profile["leadership"]["cfo"]


def test_sector_profiler_it():
    """Test dynamic sector classification and leadership for TCS."""
    profile = get_company_sector_profile("TCS")
    assert profile["sector_type"] == "IT_SERVICES"
    assert profile["is_banking"] is False
    assert "Nifty IT" in profile["benchmark_index"]
    peer_symbols = [p["symbol"] for p in profile["peers"]]
    assert "INFY" in peer_symbols
    assert "WIPRO" in peer_symbols
    assert "HDFCBANK" not in peer_symbols
    assert "Krithivasan" in profile["leadership"]["md_ceo"]
    assert "Samir Seksaria" in profile["leadership"]["cfo"]


def test_banking_screener_ingestion():
    """Test that banking P&L figures (Interest, Financing profit, Depreciation) parse accurately."""
    engine = HistoricalIntelligenceEngine("ICICIBANK")
    quarters = ["Jun 2025", "Sep 2025", "Dec 2025", "Mar 2026", "Jun 2026", "Sep 2026"]
    metrics = {
        "Revenue": ["43,710", "45,180", "46,920", "48,500", "50,110", "51,890"],
        "Interest": ["24,150", "24,800", "25,500", "26,100", "26,900", "27,700"],
        "Financing Profit": ["4,100", "4,350", "4,600", "4,820", "5,100", "5,350"],
        "Depreciation": ["450", "460", "475", "480", "495", "510"],
        "Profit before tax": ["13,800", "14,200", "14,850", "15,400", "16,100", "16,800"],
        "Net Profit": ["10,636", "11,059", "11,540", "12,010", "12,650", "13,220"],
        "EPS in Rs": ["15.12", "15.72", "16.40", "17.07", "17.98", "18.79"],
        "Raw PDF": [""] * 6,
    }
    q_data = engine.load_from_screener(quarters, metrics)
    assert len(q_data) == 6
    latest = q_data[-1]
    assert latest.revenue == 51890.0
    assert latest.finance_costs == 27700.0
    assert latest.pat == 13220.0
    assert latest.eps == 18.79


def test_icici_dynamic_report_no_tcs_leakage(tmp_path):
    """Verify an ICICI Bank report has zero TCS cross-contamination and contains Siddharth Dafria branding."""
    cfg = ResearchConfig(
        company_symbol="ICICIBANK",
        company_name="ICICI Bank Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        current_market_price=1285.00,
        output_base_dir=str(tmp_path),
    )
    generator = HTMLReportGenerator(tmp_path, cfg)

    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=51890.0,
        ebitda=16800.0,
        pat=11746.0,
        diluted_eps=16.71,
        cfo=14200.0,
        gross_debt=0.0,
    )
    ratios = FinancialRatios(
        period="Q2 FY2026-27",
        revenue_growth_yoy=14.2,
        pat_margin=22.64,
    )
    scores = ForensicScores(
        beneish_m_score=-2.85,
        beneish_flag="LOW_RISK",
        altman_z_score=3.20,
        altman_zone="SAFE_ZONE",
        piotroski_f_score=8,
        piotroski_rating="STRONG",
    )
    manifest_docs = [
        {
            "category": "Financial Results",
            "filename": "ICICI_Q2_FY27_Results.pdf",
            "sha256": "4b7f92e8a1",
            "verification_status": "VERIFIED_AUTHENTIC",
            "source_url": "https://www.bseindia.com/filings/icici",
        }
    ]

    report_path = generator.generate_report(
        current_metrics=current,
        prior_yoy=None,
        prior_qoq=None,
        ratios=ratios,
        forensic_scores=scores,
        forensic_findings=[],
        manifest_docs=manifest_docs,
    )

    assert report_path.exists()
    html = report_path.read_text(encoding="utf-8")

    # 1. Must contain author branding
    assert "Siddharth Dafria" in html
    assert "Chartered Accountant" in html
    assert "9977822290" in html
    assert "sdafria@icai.org" in html
    assert "Institute of Chartered Accountants of India" in html

    # 2. Must contain ICICI Bank leadership and peers
    assert "Sandeep Bakhshi" in html
    assert "Anindya Banerjee" in html
    assert "HDFCBANK" in html

    # 3. Must NOT contain TCS leadership or static references
    assert "Krithivasan" not in html
    assert "Samir Seksaria" not in html
    assert "TCS/BM/100/SE/" not in html
