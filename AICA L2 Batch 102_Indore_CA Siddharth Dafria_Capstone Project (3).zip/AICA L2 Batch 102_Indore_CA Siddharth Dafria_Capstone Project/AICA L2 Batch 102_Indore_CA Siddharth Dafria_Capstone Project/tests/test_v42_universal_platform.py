"""Cross-Sector Golden Test Suite & Adversarial Integrity Verification for QuarterIQ v4.2.
Tests all 15 specialized sector adapters, Universal Metric Registry, 4-Pillar Scoring,
Guidance Audit, Hidden Deltas, Red-Team Stress-Testing, and Excel Model Export.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from decimal import Decimal
from pathlib import Path
import pytest

from src.analyzers.guidance_audit_engine import GuidanceAuditEngine
from src.analyzers.hidden_delta_engine import HiddenDeltaEngine
from src.analyzers.market_microstructure_engine import MarketMicrostructureEngine
from src.analyzers.red_team_engine import RedTeamEngine
from src.analyzers.reverse_valuation_engine import ReverseValuationEngine
from src.analyzers.scoring_engine import ScoringEngine
from src.analyzers.sector_adapters import get_adapter_for_company, SECTOR_ADAPTER_REGISTRY
from src.core.metric_registry import UniversalMetricRegistry, StatementType
from src.core.models import FinancialMetrics, ResearchConfig
from src.core.provenance_engine import ProvenanceEngine
from src.reports.workpaper_generator import WorkpaperGenerator
from src.services.excel_export_service import ExcelExportService


def test_all_15_sector_adapters():
    """Verify that all 15 specialized sector adapters build valid models with explicit KPI benchmarks."""
    sector_symbols = [
        ("TCS", "IT_SERVICES"),
        ("ICICIBANK", "BANKS"),
        ("BAJFINANCE", "NBFCS"),
        ("HDFCLIFE", "INSURANCE"),
        ("DLF", "REAL_ESTATE"),
        ("HAVELLS", "MANUFACTURING"),
        ("TATASTEEL", "METALS_MINING"),
        ("RELIANCE", "OIL_GAS"),
        ("NTPC", "POWER_UTILITIES"),
        ("LT", "INFRASTRUCTURE"),
        ("BEL", "DEFENCE"),
        ("SUNPHARMA", "PHARMA"),
        ("SRF", "CHEMICALS"),
        ("HINDUNILVR", "FMCG"),
        ("BHARTIARTL", "TELECOM"),
    ]

    metrics = FinancialMetrics(period="Q2 FY2026-27", revenue=50000.0, ebit=12000.0, pat=9500.0)

    for sym, expected_sec_id in sector_symbols:
        adapter_cls = get_adapter_for_company(sym)
        assert adapter_cls is not None, f"Failed to resolve adapter for {sym}"
        model = adapter_cls.build_operating_model(sym, "Q2 FY2026-27", metrics)

        assert model.company_symbol == sym
        assert len(model.kpis) >= 5, f"Adapter for {sym} must provide at least 5 specialized operating KPIs"
        assert len(model.earnings_drivers) >= 2
        assert len(model.inapplicable_metrics) >= 1
        assert len(model.appropriate_valuation_methods) >= 2

        # Verify Banking & Insurance exclude industrial metrics
        if expected_sec_id in ("BANKS", "INSURANCE"):
            assert any("EBITDA" in m or "Altman" in m or "Inventory" in m for m in model.inapplicable_metrics)


def test_universal_metric_registry_and_reconciliation():
    """Verify canonical metric definitions, fixed-precision Decimal conversion, and PBT/PAT equations."""
    rev_def = UniversalMetricRegistry.get("REV_OPS")
    assert rev_def is not None
    assert rev_def.statement_type == StatementType.INCOME_STATEMENT

    # Test PBT reconciliation with tolerance
    passed, calc_pbt, var, note = UniversalMetricRegistry.reconcile_pbt(
        ebit=15000.0,
        finance_costs=500.0,
        other_income=800.0,
        exceptional_items=0.0,
        reported_pbt=14500.0
    )
    assert passed is True
    assert var <= 1.0

    # Test intentional PBT discrepancy rejection
    failed, calc_pbt_bad, var_bad, note_bad = UniversalMetricRegistry.reconcile_pbt(
        ebit=15000.0,
        finance_costs=500.0,
        other_income=800.0,
        exceptional_items=0.0,
        reported_pbt=12000.0  # Intentional discrepancy of ₹2,500 Cr
    )
    assert failed is False
    assert var_bad > 2000.0


def test_provenance_and_claim_lineage():
    """Verify document provenance registration and two-way claim lineage graph."""
    prov = ProvenanceEngine()
    doc = prov.register_document(
        title="Q2 FY2026-27 Financial Results Filing",
        category="01_Financial_Results",
        file_name="TCS_Q2_Results.pdf",
        relative_path="01_Financial_Results/TCS_Q2_Results.pdf",
        sha256="abc1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
        file_size_bytes=1024500,
        original_url="https://www.bseindia.com/filing/results.pdf"
    )
    assert doc.doc_id == "DOC-01"

    claim = prov.register_claim(
        section_id="sec-kpis",
        metric_label="Revenue from Operations",
        value_str="₹73,188 Cr",
        doc_id=doc.doc_id,
        page_or_table="Page 4, Table 1",
        exact_line="Line 1(a) Revenue"
    )
    assert claim.claim_id == "CLM-001"

    badge_html = prov.render_citation_badge(claim.claim_id)
    assert "DOC-01" in badge_html
    assert "Page 4" in badge_html
    assert "TCS_Q2_Results.pdf" in badge_html

    lineage = prov.get_lineage_graph(claim.claim_id)
    assert lineage["metric"] == "Revenue from Operations"
    assert lineage["source_document"]["doc_id"] == "DOC-01"


def test_four_pillar_scoring_engine():
    """Verify that Score A, B, C, and D are calculated independently without conflation."""
    from src.analyzers.reconciliation import ReconciliationItem

    mock_recs = [
        ReconciliationItem("Total Income", 75000.0, 75000.0, 0.0, True, "Equation", "Verified"),
        ReconciliationItem("PBT", 18500.0, 18500.0, 0.0, True, "Equation", "Verified"),
        ReconciliationItem("PAT", 14000.0, 14000.0, 0.0, True, "Equation", "Verified")
    ]

    scores = ScoringEngine.compute_scores(
        doc_count=6,
        verified_doc_count=5,
        reconciliations=mock_recs,
        forensic_flags_count=1,
        has_valuation=True,
        has_market_data=True,
        current_market_price=4150.0
    )

    assert scores.score_a_readiness >= 85
    assert scores.readiness_rating == "INSTITUTIONAL GRADE"
    assert scores.score_b_fundamental >= 75
    assert scores.fundamental_direction == "ATTRACTIVE LONG"
    assert scores.score_c_tactical == 78
    assert scores.tactical_verdict == "CONFIRMED LONG"
    assert scores.score_d_reliability >= 85


def test_guidance_audit_hit_rate():
    """Verify multi-quarter guidance tracking and historical hit-rate calculation."""
    audit = GuidanceAuditEngine.audit_guidance_history("TCS", "Q2 FY2026-27")
    assert audit.total_commitments_audited >= 4
    assert audit.historical_hit_rate_pct >= 70.0
    assert audit.management_credibility_tier in ("HIGH CONSERVATISM & ACCRETIVE", "PRUDENT COMMITTED")


def test_hidden_deltas_engine():
    """Verify hidden operating delta identification and causal EPS quantification."""
    deltas = HiddenDeltaEngine.analyze_company_deltas("ICICIBANK", "BANKING", 55000.0, 17000.0)
    assert len(deltas) >= 2
    assert any("Credit Cost" in d.driver for d in deltas)
    assert any(d.eps_impact_inr > 0 for d in deltas)


def test_reverse_valuation_expectations():
    """Verify reverse valuation calculates what implied revenue CAGR is priced in."""
    rev_val = ReverseValuationEngine.reverse_engineer_expectations(
        symbol="TCS",
        current_price=4150.0,
        revenue_cr=73188.0,
        pat_cr=13944.0
    )
    assert rev_val.implied_revenue_cagr_5y_pct > 0.0
    assert rev_val.implied_terminal_ebit_margin_pct > 20.0
    assert "Hurdle" in rev_val.growth_verdict or "PRICED IN" in rev_val.growth_verdict


def test_red_team_stress_testing():
    """Verify Red Team generates at least 5 independent adversarial failure scenarios."""
    red_team = RedTeamEngine.execute_red_team_review("TCS", "IT_SERVICES", "ACCUMULATE")
    assert len(red_team.scenarios) >= 5
    for s in red_team.scenarios:
        assert s.potential_price_drawdown_pct > 0
        assert len(s.invalidation_criteria) > 10


def test_workpaper_generator_governance():
    """Verify that Forensic Review Workpaper WP-01 adheres to ICAI review standards."""
    cfg = ResearchConfig(
        company_symbol="INFY",
        company_name="Infosys Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27"
    )
    cur = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=41000.0,
        other_income=800.0,
        total_income=41800.0,
        ebitda=10200.0,
        depreciation=1200.0,
        ebit=9000.0,
        pbt=9800.0,
        tax_expense=2500.0,
        pat=7300.0
    )
    from src.analyzers.reconciliation import ReconciliationAuditor
    recs = ReconciliationAuditor().audit_metrics(cur)

    wp = WorkpaperGenerator.generate_workpaper(cfg, cur, [], recs)
    assert "Awaiting Professional Review" in wp.review_status
    assert wp.total_checks_run >= 1
    assert "Siddharth Dafria" in WorkpaperGenerator.render_workpaper_html(wp)


def test_excel_export_service_with_working_formulas(tmp_path):
    """Verify Excel Financial Model .xlsx workbook generation with live Excel formulas."""
    cfg = ResearchConfig(
        company_symbol="TCS",
        company_name="Tata Consultancy Services Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        current_market_price=4150.0
    )
    cur = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=73188.0,
        other_income=1320.0,
        total_income=74508.0,
        ebitda=19200.0,
        depreciation=2200.0,
        ebit=17000.0,
        pbt=18000.0,
        tax_expense=4056.0,
        pat=13944.0
    )

    excel_path = ExcelExportService.export_financial_model(tmp_path, cfg, cur)
    assert excel_path.exists()
    assert excel_path.suffix == ".xlsx"

    # Open with openpyxl and verify live formulas
    import openpyxl
    wb = openpyxl.load_workbook(excel_path, data_only=False)
    assert "Executive Summary" in wb.sheetnames
    assert "Income Statement Model" in wb.sheetnames
    assert "DCF Valuation Model" in wb.sheetnames

    ws_fin = wb["Income Statement Model"]
    # Check that live formulas are written
    assert ws_fin["C8"].value == "=C6+C7"
    assert ws_fin["C12"].value == "=SUM(C9:C11)"
    assert ws_fin["C13"].value == "=C6-C12"
    assert ws_fin["C15"].value == "=C13-C14"
    assert ws_fin["C19"].value == "=C17-C18"


def test_sector_kpi_pack_single_pack_governance():
    """Verify that SECTOR KPI PACK strictly returns only the single fitting pack for the company."""
    from src.analyzers.sector_intelligence import build_sector_kpi_pack
    from src.reports.report_sections import ReportSectionBuilders

    # 1. Real Estate (DLF)
    dlf_pack = build_sector_kpi_pack("DLF", "Q2 FY2026-27")
    assert dlf_pack.sector_category == "REAL_ESTATE"
    dlf_kpis = [k.kpi_name for k in dlf_pack.kpis]
    assert any("Pre-Sales" in k for k in dlf_kpis)
    assert any("Collections" in k for k in dlf_kpis)
    assert any("Launches" in k for k in dlf_kpis)
    assert any("Land Bank" in k for k in dlf_kpis)
    assert any("Rental" in k for k in dlf_kpis)
    assert any("Net Cash" in k for k in dlf_kpis)
    assert any("NAV" in k for k in dlf_kpis)
    # Ensure no cross-contamination from other sectors
    assert not any("NII" in k for k in dlf_kpis)
    assert not any("TCV" in k for k in dlf_kpis)

    # 2. IT (TCS)
    tcs_pack = build_sector_kpi_pack("TCS", "Q2 FY2026-27")
    assert tcs_pack.sector_category == "IT"
    tcs_kpis = [k.kpi_name for k in tcs_pack.kpis]
    assert any("Deal TCV" in k for k in tcs_kpis)
    assert any("Attrition" in k for k in tcs_kpis)
    assert any("Utilisation" in k for k in tcs_kpis)
    assert any("Constant-Currency" in k for k in tcs_kpis)
    assert any("Top-Client" in k for k in tcs_kpis)
    assert not any("Pre-Sales" in k for k in tcs_kpis)

    # 3. Banks/NBFC (ICICIBANK)
    icici_pack = build_sector_kpi_pack("ICICIBANK", "Q2 FY2026-27")
    assert icici_pack.sector_category == "BANKS_NBFC"
    icici_kpis = [k.kpi_name for k in icici_pack.kpis]
    assert any("NII" in k for k in icici_kpis)
    assert any("NIM" in k for k in icici_kpis)
    assert any("GNPA / NNPA" in k for k in icici_kpis)
    assert any("PCR" in k for k in icici_kpis)
    assert any("CASA" in k for k in icici_kpis)
    assert any("Credit Cost" in k for k in icici_kpis)
    assert any("Capital Adequacy" in k for k in icici_kpis)

    # 4. Manufacturing (TATASTEEL)
    steel_pack = build_sector_kpi_pack("TATASTEEL", "Q2 FY2026-27")
    assert steel_pack.sector_category == "MANUFACTURING"
    steel_kpis = [k.kpi_name for k in steel_pack.kpis]
    assert any("Volume" in k for k in steel_kpis)
    assert any("Realisation" in k for k in steel_kpis)
    assert any("EBITDA / Tonne" in k for k in steel_kpis)
    assert any("Capacity Utilisation" in k for k in steel_kpis)
    assert any("Capex" in k for k in steel_kpis)

    # 5. Other Sectors / Company's Own Investor Presentation (HAVELLS)
    havells_pack = build_sector_kpi_pack("HAVELLS", "Q2 FY2026-27")
    assert havells_pack.sector_category == "OTHER"
    havells_kpis = [k.kpi_name for k in havells_pack.kpis]
    assert any("Volume Growth" in k for k in havells_kpis)
    assert any("Retail Reach" in k for k in havells_kpis)
    assert any("Ad & Promotion" in k for k in havells_kpis)
    assert any("Working Capital" in k for k in havells_kpis)
    assert any("Cash Conversion" in k for k in havells_kpis)
    assert any("ROCE" in k for k in havells_kpis)

    # Test HTML renderer
    rendered_html = ReportSectionBuilders.render_sector_kpi_pack(havells_pack)
    assert "sec-sector-kpi-pack" in rendered_html
    assert "HAVELLS" in rendered_html
    assert "Dedicated Pack" in rendered_html


def test_momentum_score_pillar_d():
    """Verify that Pillar D calculates Momentum Score with backward compatibility."""
    from src.analyzers.scoring_engine import ScoringEngine
    from src.analyzers.reconciliation import ReconciliationItem

    mock_recs = [
        ReconciliationItem("Total Income", 75000.0, 75000.0, 0.0, True, "Equation", "Verified"),
    ]
    scores = ScoringEngine.compute_scores(
        doc_count=5,
        verified_doc_count=5,
        reconciliations=mock_recs,
        forensic_flags_count=0,
        has_valuation=True,
        has_market_data=True,
        current_market_price=4200.0
    )

    assert scores.score_d_momentum >= 85
    assert scores.momentum_tier in ["HIGH MOMENTUM (TOP DECILE)", "BULLISH ACCUMULATION"]
    assert scores.relative_strength_rating >= 80
    assert "GOLDEN STACK" in scores.moving_average_alignment
    assert scores.volume_expansion_ratio >= 1.2
    # Verify backward compatibility alias
    assert scores.score_d_reliability == scores.score_d_momentum


def test_executive_master_pointer_summary_all_31_sections():
    """Verify that Executive Master Summary generates structured bullet pointers covering all 31 sections."""
    from src.reports.report_sections import ReportSectionBuilders
    from src.analyzers.sector_intelligence import build_sector_kpi_pack
    from src.analyzers.scoring_engine import ScoringEngine

    pack = build_sector_kpi_pack("TCS", "Q2 FY2026-27")
    scores = ScoringEngine.compute_scores(
        doc_count=5,
        verified_doc_count=5,
        reconciliations=[],
        forensic_flags_count=0,
        has_valuation=True,
        has_market_data=True,
        current_market_price=4150.0
    )

    class Dummy:
        pass

    metrics = Dummy()
    metrics.revenue = 73188.0
    metrics.ebitda = 19200.0
    metrics.pat = 13944.0
    metrics.eps = 38.6
    metrics.revenue_growth_yoy = 11.2

    ratios = Dummy()
    ratios.ebitda_margin_pct = 26.2
    ratios.pat_margin_pct = 19.0
    ratios.roce_pct = 48.5
    ratios.roe_pct = 52.0
    ratios.cfo_to_pat_pct = 102.2

    valuation = Dummy()
    valuation.blended_target_price_inr = 4850.0
    valuation.blended_upside_pct = 16.9

    summary_html = ReportSectionBuilders.render_executive_master_pointer_summary(
        symbol="TCS",
        company_name="Tata Consultancy Services",
        quarter="Q2 FY2026-27",
        verdict="CONVICTION ACCUMULATE",
        metrics=metrics,
        ratios=ratios,
        valuation=valuation,
        scores=scores,
        sector_kpi_pack=pack
    )

    assert "sec-executive-pointer-summary" in summary_html
    assert "31-SECTION INSTITUTIONAL POINTER BRIEFING" in summary_html
    assert "Four-Pillar Scorecard" in summary_html
    assert "Dedicated Sector KPI Pack" in summary_html
    assert "Siddharth Dafria, Chartered Accountant" in summary_html
