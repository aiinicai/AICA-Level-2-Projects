"""Unit tests for QuarterIQ v4.2 Compliance, Intelligence and Probabilistic Scenario requirements.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
import pytest
from pathlib import Path
from src.core.models import FinancialMetrics, ResearchConfig, ForensicFinding
from src.reports.html_generator import HTMLReportGenerator
from src.reports.pdf_report_builder import PDFReportBuilder
from src.analyzers.scoring_engine import ScoringEngine, FourPillarScores


def test_compliance_and_governance_labels(tmp_path):
    """Verify strictly:
    - 'Automated Draft – Pending CA Review' is prominently displayed.
    - No 'CA CERTIFIED' or 'Auditor Certified' seals remain.
    - Evidence deduplication works and preserves honest verification.
    """
    cfg = ResearchConfig(company_symbol="HAVELLS", financial_year="FY2026-27", reporting_quarter="Q2 FY2026-27", company_name="Havells India Ltd")
    cur_m = FinancialMetrics(period="Q2 FY2026-27", revenue=4533.0, ebitda=375.0, pat=268.0, diluted_eps=4.28)
    
    docs = [
        {"file_name": "Filing_A.pdf", "sha256": "abcdef1234567890abcdef", "verified": True, "category": "Results"},
        {"file_name": "Filing_A.pdf", "sha256": "abcdef1234567890abcdef", "verified": True, "category": "Results"}, # Duplicate!
        {"file_name": "Unverified_Poll.pdf", "sha256": "—", "verified": False, "category": "Broker Note"}
    ]
    
    gen = HTMLReportGenerator(tmp_path, cfg)
    html_path = gen.generate_report(
        current_metrics=cur_m,
        prior_yoy=None,
        prior_qoq=None,
        ratios=None,
        forensic_scores=None,
        forensic_findings=[],
        manifest_docs=docs,
        auto_open=False
    )
    html_content = html_path.read_text(encoding="utf-8")
    
    # 1. Compliance Labels
    assert "AUTOMATED DRAFT – PENDING CA REVIEW" in html_content
    assert "CA CERTIFIED" not in html_content
    assert "Auditor Certified Engagement" not in html_content
    
    # 2. Missing Intelligence: Cash Flows
    assert "Consolidated Statement of Cash Flows &amp; Capital Allocation" in html_content
    assert "Cash from Operations (CFO)" in html_content
    assert "Free Cash Flow (FCF)" in html_content
    
    # 3. Missing Intelligence: Hidden Risks & Non-Consensus Opportunities
    assert "Forensic Hidden Risks &amp; Operational Blindspots" in html_content
    assert "Non-Consensus Opportunities &amp; Unpriced Optionalities" in html_content
    
    # 4. Probabilistic Scenarios (Never single-point)
    assert "Bull (25%):" in html_content
    assert "Base (50%):" in html_content
    assert "Bear (25%):" in html_content
    assert "Blended Prob-Weighted Target:" in html_content
    
    # 5. Evidence Deduplication: Filing_A.pdf must only appear once in evidence rows
    assert html_content.count("<td><strong>Filing_A.pdf</strong></td>") == 1
    assert "UNVERIFIED" in html_content


def test_verdict_strictly_matches_fundamental_score_band(tmp_path):
    """Verify headline verdict derivation strictly matches Score B fundamental conviction."""
    scores = ScoringEngine.compute_scores(
        doc_count=5,
        verified_doc_count=5,
        reconciliations=[],
        forensic_flags_count=0,
        has_valuation=True,
        has_market_data=True,
        current_market_price=1820.0
    )
    assert scores.score_b_fundamental >= 80
    
    cfg = ResearchConfig(company_symbol="TCS", financial_year="FY2026-27", reporting_quarter="Q2 FY2026-27", company_name="Tata Consultancy Services Ltd")
    cur_m = FinancialMetrics(period="Q2 FY2026-27", revenue=64259.0, ebitda=17890.0, pat=11909.0, diluted_eps=32.8)
    
    gen = HTMLReportGenerator(tmp_path, cfg)
    html_path = gen.generate_report(
        current_metrics=cur_m,
        prior_yoy=None,
        prior_qoq=None,
        ratios=None,
        forensic_scores=None,
        forensic_findings=[],
        manifest_docs=[],
        auto_open=False
    )
    html_content = html_path.read_text(encoding="utf-8")
    
    # Headline verdict must match Score B band (>=80 is STRONG BUY / CONVICTION ACCUMULATE)
    assert "STRONG BUY / CONVICTION ACCUMULATE" in html_content


def test_pdf_report_builder_contains_cash_flows_and_scenarios(tmp_path):
    """Verify 11-page Vector PDF includes Ind AS 7 Cash Flows, Hidden Risks, Scenarios, and Draft labels."""
    cfg = ResearchConfig(company_symbol="HAVELLS", financial_year="FY2026-27", reporting_quarter="Q2 FY2026-27", company_name="Havells India Ltd")
    cur_m = FinancialMetrics(period="Q2 FY2026-27", revenue=4533.0, ebitda=375.0, pat=268.0, diluted_eps=4.28)
    pdf_out = tmp_path / "test_havells.pdf"
    
    PDFReportBuilder.build_institutional_pdf(
        output_pdf_path=pdf_out,
        config=cfg,
        metrics=cur_m,
        manifest_docs=[{"file_name": "Doc1.pdf", "verified": True, "sha256": "1234567890abcdef1234"}]
    )
    assert pdf_out.exists()
    assert pdf_out.stat().st_size > 10000
