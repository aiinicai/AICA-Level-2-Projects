"""Unit tests for Forensic Intelligence, Anomaly Detection & Statistical Models."""
import pytest
from src.analyzers.forensics import ForensicIntelligenceEngine
from src.core.models import FinancialMetrics, FinancialRatios


def test_forensic_receivables_divergence():
    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=10000.0,
        receivables=3000.0,
        ebitda=2000.0,
        cfo=1800.0,
        pat=1200.0
    )
    prior = FinancialMetrics(
        period="Q2 FY2025-26",
        revenue=9500.0,     # Revenue grew +5.26%
        receivables=2000.0  # Receivables grew +50.0% (Massive divergence!)
    )

    scores, findings = ForensicIntelligenceEngine.evaluate_forensics(current, prior)

    # Check that divergence is detected
    assert scores.revenue_receivables_divergence is not None
    assert scores.revenue_receivables_divergence > 40.0
    
    red_flags = [f for f in findings if f.severity == "RED_FLAG"]
    assert any("Revenue Recognition" in f.title for f in red_flags)


def test_forensic_cfo_ebitda_warning():
    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=10000.0,
        ebitda=3000.0,
        cfo=1200.0,  # CFO / EBITDA = 0.40x (< 0.80x benchmark!)
        pat=1800.0
    )
    scores, findings = ForensicIntelligenceEngine.evaluate_forensics(current)
    assert scores.cfo_ebitda_warning is True
    assert any("CFO / EBITDA < 0.8x" in f.title for f in findings)


def test_beneish_and_altman_scores():
    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=12000.0,
        receivables=2200.0,
        cogs=6000.0,
        ebitda=3000.0,
        ebit=2500.0,
        cfo=2800.0,
        pat=1800.0
    )
    prior = FinancialMetrics(
        period="Q2 FY2025-26",
        revenue=10000.0,
        receivables=2000.0,
        cogs=5000.0
    )
    total_assets = 25000.0
    scores, findings = ForensicIntelligenceEngine.evaluate_forensics(
        current=current,
        prior_yoy=prior,
        total_assets=total_assets,
        retained_earnings=10000.0,
        market_cap=40000.0,
        total_liabilities=8000.0
    )

    assert scores.beneish_m_score is not None
    assert scores.beneish_flag in ("LOW_RISK", "HIGH_RISK_MANIPULATION")
    assert scores.altman_z_score is not None
    assert scores.altman_zone in ("SAFE", "GREY_ZONE", "DISTRESS")
