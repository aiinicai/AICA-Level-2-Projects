"""End-to-end integration test for AutoPilotWorker execution and automated HTML generation."""
from pathlib import Path
import pytest
from src.core.models import ResearchConfig
from src.core.workspace import WorkspaceManager
from src.ui.workers import AutoPilotWorker


def test_autopilot_worker_generates_report_automatically(tmp_path, monkeypatch):
    """Verify that AutoPilotWorker completes all 8 steps and automatically produces the HTML dashboard."""
    # Prevent webbrowser.open from actually launching a real browser window during automated tests
    opened_urls = []
    monkeypatch.setattr("webbrowser.open", lambda *args, **kwargs: opened_urls.append(args[0] if args else ""))

    # Mock online harvesting to avoid slow external network calls to Indian government portals
    from src.providers.auto_harvester import AutoDocumentHarvester
    monkeypatch.setattr(AutoDocumentHarvester, "harvest_all", lambda *args, **kwargs: ("", []))

    cfg = ResearchConfig(
        company_symbol="ICICIBANK",
        company_name="ICICI Bank Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        accounting_basis="Consolidated",
        current_market_price=1285.00,
        output_base_dir=str(tmp_path)
    )
    ws = WorkspaceManager(cfg)
    ws.create_structure()

    worker = AutoPilotWorker(
        workspace=ws,
        config=cfg,
        attached_files=[],
        bse_code="532174"
    )

    steps_recorded = []
    reports_ready = []
    errors_recorded = []
    pipeline_finished_data = []

    worker.step_progress.connect(lambda pct, text: steps_recorded.append((pct, text)))
    worker.report_ready.connect(lambda path: reports_ready.append(path))
    worker.error_occurred.connect(lambda err: errors_recorded.append(err))
    worker.pipeline_finished.connect(
        lambda m, r, s, f, recon, rep_p: pipeline_finished_data.append((m, rep_p))
    )

    # Execute worker logic synchronously
    worker.run()

    # Must NOT record any errors (specifically not 'ForensicFinding' has no attribute 'observation')
    assert len(errors_recorded) == 0, f"Auto-Pilot encountered errors: {errors_recorded}"

    # Must complete all steps up to 100%
    assert len(steps_recorded) > 0
    final_step = steps_recorded[-1]
    assert final_step[0] == 100

    # Must emit report_ready
    assert len(reports_ready) == 1
    generated_report_path = Path(reports_ready[0])
    assert generated_report_path.exists()
    assert generated_report_path.stat().st_size > 5000  # Non-trivial HTML

    # Must emit pipeline_finished
    assert len(pipeline_finished_data) == 1

    # Verify that the browser was triggered automatically for both ChatGPT and the HTML report
    assert len(opened_urls) >= 1
    assert any(str(generated_report_path.name) in url for url in opened_urls)
    assert any("chatgpt.com" in url for url in opened_urls)

    # Verify HTML contents
    html_content = generated_report_path.read_text(encoding="utf-8")
    assert "Siddharth Dafria" in html_content
    assert "Chartered Accountant" in html_content
    assert "ICICI Bank Limited" in html_content
    assert "BENEISH M-SCORE" in html_content
    assert "Surprise / Forecast" in html_content
    assert "Durability Score" in html_content
    assert "Multi-Quarter Analytical KPI Matrix" in html_content
    assert "CNBC Awaaz" in html_content
    assert "Concall" in html_content
    assert "Primary Signal:" in html_content
