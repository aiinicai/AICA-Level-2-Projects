"""Unit tests for Self-Contained Offline HTML Report Generator."""
from pathlib import Path
import pytest
from src.core.models import (
    FinancialMetrics,
    FinancialRatios,
    ForensicScores,
    ResearchConfig,
)
from src.reports.html_generator import HTMLReportGenerator


def test_html_report_generation(tmp_path):
    cfg = ResearchConfig(
        company_symbol="TATASTEEL",
        company_name="Tata Steel Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        current_market_price=162.50,
        output_base_dir=str(tmp_path)
    )
    generator = HTMLReportGenerator(tmp_path, cfg)

    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=58000.0,
        ebitda=6200.0,
        pat=1800.0,
        diluted_eps=1.45,
        cfo=5900.0,
        gross_debt=72000.0
    )
    ratios = FinancialRatios(
        period="Q2 FY2026-27",
        revenue_growth_yoy=8.5,
        ebitda_margin=10.69,
        pat_margin=3.10
    )
    scores = ForensicScores(
        beneish_m_score=-2.65,
        beneish_flag="LOW_RISK",
        altman_z_score=2.85,
        altman_zone="GREY_ZONE",
        piotroski_f_score=7,
        piotroski_rating="STRONG"
    )

    manifest_docs = [
        {
            "category": "Financial Results",
            "file_name": "Tata_Steel_Results_Q2_FY27.pdf",
            "file_size_bytes": 1450200,
            "sha256": "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
            "verified": True,
            "collected_at": "2026-10-19 22:30:00 IST"
        }
    ]

    report_path = generator.generate_report(
        current_metrics=current,
        prior_yoy=None,
        prior_qoq=None,
        ratios=ratios,
        forensic_scores=scores,
        forensic_findings=[],
        manifest_docs=manifest_docs,
        verdict="ACCUMULATE",
        conviction_score=78
    )

    assert report_path.exists()
    content = report_path.read_text(encoding="utf-8")

    # Offline-first assertions: no external CDN dependencies
    assert "googleapis.com" not in content
    assert "cdnjs.cloudflare.com" not in content
    assert "unpkg.com" not in content
    assert "cdn.jsdelivr.net" not in content

    # Content assertions
    assert "Tata Steel Limited" in content
    assert "TATASTEEL" in content
    assert "Q2 FY2026-27" in content
    assert "<svg" in content
    assert "ACCUMULATE" in content
    assert "Toggle Light/Dark" in content
    assert "@media print" in content
    assert "Tata_Steel_Results_Q2_FY27.pdf" in content


def test_html_report_with_real_forensic_findings(tmp_path):
    """Verify that ForensicFinding objects with observation attribute are safely rendered without AttributeError."""
    from src.core.models import ForensicFinding
    from src.analyzers.forensics import ForensicIntelligenceEngine

    cfg = ResearchConfig(
        company_symbol="ICICIBANK",
        company_name="ICICI Bank Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        current_market_price=1285.00,
        output_base_dir=str(tmp_path)
    )
    generator = HTMLReportGenerator(tmp_path, cfg)

    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=51890.0,
        ebitda=16800.0,
        pat=11746.0,
        diluted_eps=16.71,
        cfo=14200.0
    )
    prior_yoy = FinancialMetrics(
        period="Q2 FY2025-26",
        revenue=45180.0,
        ebitda=14200.0,
        pat=10200.0,
        diluted_eps=14.50,
        cfo=12000.0
    )

    scores, findings = ForensicIntelligenceEngine.evaluate_forensics(
        current=current,
        prior_yoy=prior_yoy,
        ratios=FinancialRatios(period="Q2 FY2026-27"),
        total_assets=120000.0,
        retained_earnings=60000.0,
        market_cap=900000.0,
        total_liabilities=50000.0
    )

    assert len(findings) > 0
    # Every finding must have observation attribute
    for f in findings:
        assert hasattr(f, "observation")
        assert f.observation != ""

    # Generate report with non-empty findings list - must not raise AttributeError: 'ForensicFinding' object has no attribute 'observation'
    report_path = generator.generate_report(
        current_metrics=current,
        prior_yoy=prior_yoy,
        prior_qoq=None,
        ratios=FinancialRatios(period="Q2 FY2026-27"),
        forensic_scores=scores,
        forensic_findings=findings,
        manifest_docs=[]
    )

    assert report_path.exists()
    content = report_path.read_text(encoding="utf-8")
    assert "BENEISH M-SCORE" in content
    assert "ALTMAN Z-SCORE" in content
    assert "Primary Signal:" in content
