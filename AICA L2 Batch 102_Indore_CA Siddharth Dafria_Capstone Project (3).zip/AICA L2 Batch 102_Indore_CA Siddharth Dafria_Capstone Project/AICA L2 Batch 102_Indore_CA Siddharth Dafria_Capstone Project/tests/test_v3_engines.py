"""Comprehensive Regression & Quality Assurance Tests for v3.1 Institutional Engines."""
import pytest

from src.analyzers.cycle_macro_engine import CycleMacroEngine
from src.analyzers.historical_analogue import HistoricalAnalogueEngine
from src.analyzers.historical_engine import HistoricalIntelligenceEngine
from src.analyzers.reaction_engine import SharePriceReactionEngine
from src.analyzers.sector_intelligence import SectorIntelligenceEngine
from src.analyzers.surprise_engine import EarningsSurpriseEngine
from src.analyzers.valuation_engine import ForwardValuationEngine


def test_historical_intelligence_engine():
    engine = HistoricalIntelligenceEngine("TCS")
    quarters = ["Jun 2025", "Sep 2025", "Dec 2025", "Mar 2026", "Jun 2026", "Sep 2026"]
    metrics = {
        "Sales": ["63,437", "65,799", "67,087", "70,698", "72,275", "73,188"],
        "Operating Profit": ["16,875", "17,978", "18,269", "19,276", "18,556", "18,815"],
        "Depreciation": ["1,361", "1,413", "1,380", "1,406", "1,239", "1,262"],
        "Profit before tax": ["16,979", "16,068", "14,078", "18,362", "17,944", "18,638"],
        "Net Profit": ["12,819", "12,131", "10,720", "13,784", "13,420", "13,934"],
        "EPS in Rs": ["35.27", "33.37", "29.45", "37.92", "36.90", "38.37"],
        "Raw PDF": [""] * 6
    }
    q_data = engine.load_from_screener(quarters, metrics)
    assert len(q_data) == 6

    latest = q_data[-1]
    assert latest.revenue == 73188.0
    assert latest.pat == 13934.0
    assert latest.eps == 38.37
    assert latest.ebit == 18815.0 - 1262.0  # 17553.0

    # YoY growth: (73,188 - 65,799) / 65,799 = +11.23%
    assert latest.revenue_yoy_pct is not None
    assert round(latest.revenue_yoy_pct, 1) == 11.2

    # Inflection detection
    signals = engine.detect_inflections()
    assert len(signals) >= 2
    types = [s.signal_type for s in signals]
    assert "CASH_CONVERSION" in types


def test_earnings_surprise_engine():
    engine = EarningsSurpriseEngine()
    res = engine.evaluate_tcs_q2_surprise(
        actual_revenue=73188.0,
        actual_ebit=17301.0,
        actual_pat=13934.0,
        actual_eps=38.37
    )
    assert res.total_surprise_score >= 80
    assert res.overall_classification in ("SIGNIFICANT_BEAT", "MODERATE_BEAT")
    assert len(res.metrics) == 5

    rev_metric = [m for m in res.metrics if "Revenue" in m.metric_name][0]
    assert rev_metric.verdict == "BEAT"
    assert rev_metric.reported_val == 73188.0


def test_sector_intelligence_tcs():
    intel = SectorIntelligenceEngine.get_tcs_q2_intelligence()
    assert intel.company_symbol == "TCS"
    assert intel.cc_growth_qoq_pct == 0.50
    assert intel.cc_growth_yoy_pct == 2.80
    assert intel.inr_revenue_cr == 73188.0
    assert intel.tcv_deal_wins_billion_usd == 8.6
    assert intel.annualized_ai_revenue_billion_usd == 3.1
    assert len(intel.verticals) == 6

    bfsi = [v for v in intel.verticals if "BFSI" in v.segment_name][0]
    assert bfsi.revenue_inr_cr == 28882.0
    assert bfsi.segment_margin_pct == 25.45


def test_forward_valuation_engine():
    res = ForwardValuationEngine.evaluate_tcs_valuation(reference_price=4150.0)
    assert res.ttm_eps_inr == 142.64
    assert res.trailing_pe > 25.0
    assert res.blended_target_price_inr > 4500.0
    assert res.blended_upside_pct > 10.0
    assert len(res.scenarios) == 3
    assert res.dcf_intrinsic_value_inr == 4680.0


def test_reaction_engine():
    res = SharePriceReactionEngine.evaluate_tcs_reaction_history()
    assert res.sample_size == 12
    assert len(res.horizon_statistics) == 5

    t5 = [h for h in res.horizon_statistics if "T+5" in h.horizon_label][0]
    assert t5.win_rate_pct >= 70.0
    assert t5.median_return_pct > 1.5


def test_cycle_macro_engine():
    res = CycleMacroEngine.evaluate_tcs_overlays()
    assert len(res.modules) >= 4
    categories = [m.category for m in res.modules]
    assert "FUNDAMENTAL_MACRO" in categories
    assert "EXPERIMENTAL_CYCLE" in categories

    exp_mod = [m for m in res.modules if m.category == "EXPERIMENTAL_CYCLE"][0]
    assert exp_mod.evidence_status == "EXPERIMENTAL_HYPOTHESIS"
    assert exp_mod.disclaimer is not None
