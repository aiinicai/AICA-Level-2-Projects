"""Smoke test for PySide6 QuarterIQMainWindow and Navigation."""
import pytest
from PySide6.QtWidgets import QApplication
from src.ui.main_window import QuarterIQMainWindow


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_main_window_instantiation(qapp):
    win = QuarterIQMainWindow()
    assert win is not None
    assert win.tabs.count() == 10
    
    # Test switching tabs
    for idx in range(win.tabs.count()):
        win.tabs.setCurrentIndex(idx)
        assert win.tabs.currentIndex() == idx

    # Check that initial target is set
    assert "INFY" in win.active_session_label.text()
    win.close()
