"""Unit tests for Research Workspace Directory and Manifest Management."""
import json
from pathlib import Path
import pytest
from src.core.constants import RESEARCH_FOLDERS
from src.core.models import DocumentRecord, ResearchConfig
from src.core.workspace import WorkspaceManager, compute_sha256


def test_workspace_creation(tmp_path):
    cfg = ResearchConfig(
        company_symbol="TCS",
        company_name="Tata Consultancy Services Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        output_base_dir=str(tmp_path)
    )
    ws = WorkspaceManager(cfg)
    root = ws.create_structure()

    assert root.exists()
    assert (root / "01_Financial_Results").exists()
    assert (root / "11_Research_Reports").exists()
    assert (root / "12_Audit_Logs").exists()
    assert len(list(root.iterdir())) >= 12

    # Verify manifest files exist
    assert ws.manifest_json_path.exists()
    assert ws.manifest_csv_path.exists()
    assert ws.config_json_path.exists()
    assert ws.checklist_json_path.exists()
    assert ws.download_log_path.exists()


def test_add_document_and_sha256(tmp_path):
    cfg = ResearchConfig(
        company_symbol="INFY",
        company_name="Infosys Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        output_base_dir=str(tmp_path)
    )
    ws = WorkspaceManager(cfg)
    root = ws.create_structure()

    # Create synthetic test file
    cat_folder = ws.get_destination_folder("Financial Results")
    test_file = cat_folder / "test_results.pdf"
    test_file.write_bytes(b"%PDF-1.4 Synthetic test filing content")

    sha = compute_sha256(test_file)
    rec = DocumentRecord(
        category="Financial Results",
        file_path=str(test_file.relative_to(root)),
        file_name=test_file.name,
        file_size_bytes=test_file.stat().st_size,
        sha256=sha,
        source_origin="https://example.com/results.pdf",
        source_type="direct_download",
        collected_at="2026-10-19 22:30:00 IST"
    )

    doc_dict = ws.add_document(rec)
    assert doc_dict["sha256"] == sha

    manifest = ws.get_manifest()
    assert len(manifest["documents"]) == 1
    assert manifest["documents"][0]["file_name"] == "test_results.pdf"

    # Update verification
    ws.update_document_verification(sha, verified=True, status="VERIFIED", notes="Audited")
    manifest_updated = ws.get_manifest()
    assert manifest_updated["documents"][0]["verified"] is True
    assert manifest_updated["documents"][0]["verification_status"] == "VERIFIED"
