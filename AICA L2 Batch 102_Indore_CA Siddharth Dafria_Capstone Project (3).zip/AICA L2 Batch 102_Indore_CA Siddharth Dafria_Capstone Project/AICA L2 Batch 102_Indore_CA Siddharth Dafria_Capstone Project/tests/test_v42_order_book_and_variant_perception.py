"""Test Suite for QuarterIQ v4.2 Order Book Dynamics & Variant Perception Engine.
Verifies backlog conversion, margin spreads, Ind AS 115 contract assets, and unpriced market blindspots.
"""
from pathlib import Path
import pytest
from src.core.models import FinancialMetrics, ResearchConfig
from src.core.metric_registry import UniversalMetricRegistry
from src.analyzers.order_book_engine import OrderBookEngine
from src.analyzers.reverse_valuation_engine import ReverseValuationEngine
from src.analyzers.variant_perception_engine import VariantPerceptionEngine
from src.services.excel_export_service import ExcelExportService
from src.services.pdf_export_service import PDFExportService


def test_metric_registry_order_book_extensions():
    """Confirms new canonical metrics are registered."""
    ob_total = UniversalMetricRegistry.get("ORDER_BOOK_TOTAL")
    assert ob_total is not None
    assert ob_total.standard_label == "Total Order Book / Backlog"
    
    spread = UniversalMetricRegistry.get("ORDER_MARGIN_DELTA_BPS")
    assert spread is not None
    assert spread.unit == "bps"


def test_order_book_engine_it_services():
    """Tests order book and deal TCV analysis for IT services (e.g. TCS)."""
    metrics = FinancialMetrics(period="Q2 FY2026-27", revenue=64259.0, ebit=15437.0, pat=11909.0)
    ob = OrderBookEngine.analyze_order_book("TCS", "Q2 FY2026-27", "IT_SERVICES", metrics, current_market_price=4150.0)
    
    assert ob.company_symbol == "TCS"
    assert ob.total_order_book_cr > 100000.0
    assert ob.book_to_bill_ratio >= 1.1
    assert "EXPANDING" in ob.book_to_bill_verdict
    assert ob.margin_spread_bps > 0
    assert "ACCRETIVE" in ob.margin_inflection_verdict
    assert ob.annualized_ebitda_impact_cr > 0
    assert ob.unbilled_contract_assets_cr > 0
    assert len(ob.growth_catalysts) >= 2


def test_order_book_engine_infrastructure():
    """Tests order backlog for Infrastructure / EPC (e.g. L&T)."""
    metrics = FinancialMetrics(period="Q2 FY2026-27", revenue=61555.0, ebit=5540.0, pat=3395.0)
    ob = OrderBookEngine.analyze_order_book("LT", "Q2 FY2026-27", "INFRASTRUCTURE", metrics, current_market_price=3650.0)
    
    assert ob.company_symbol == "LT"
    assert ob.book_to_bill_ratio >= 1.2
    assert ob.implied_execution_duration_years >= 2.0
    assert ob.customer_advances_cr > 0
    assert len(ob.execution_risks) >= 2


def test_variant_perception_unpriced_factors():
    """Tests detection of points NOT discounted by the market."""
    metrics = FinancialMetrics(period="Q2 FY2026-27", revenue=64259.0, ebit=15437.0, pat=11909.0)
    ob = OrderBookEngine.analyze_order_book("TCS", "Q2 FY2026-27", "IT_SERVICES", metrics, current_market_price=4150.0)
    rev_val = ReverseValuationEngine.reverse_engineer_expectations("TCS", 4150.0, 64259.0, 11909.0)
    
    rep = VariantPerceptionEngine.evaluate_unpriced_factors(
        symbol="TCS",
        quarter="Q2 FY2026-27",
        sector_id="IT_SERVICES",
        metrics=metrics,
        reverse_val=rev_val,
        order_book=ob,
        current_market_price=4150.0
    )
    
    assert rep.company_symbol == "TCS"
    assert rep.quarteriq_forensic_forward_eps_inr > rep.consensus_forward_eps_inr
    assert rep.eps_surprise_potential_pct > 0.0
    assert rep.quarteriq_unpriced_fair_value_inr > 0.0
    assert len(rep.unpriced_catalysts) >= 3
    assert any("Margin Accretion" in c.factor_name for c in rep.unpriced_catalysts)
    assert any("Velocity" in c.factor_name for c in rep.unpriced_catalysts)


def test_excel_export_service_order_book_tab():
    """Verifies that Excel financial model includes Tab 4 with live order book formulas."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_str:
        tmp_path = Path(tmp_str)
        cfg = ResearchConfig(
            company_symbol="TCS",
            company_name="Tata Consultancy Services",
            reporting_quarter="Q2 FY2026-27",
            financial_year="FY2026-27"
        )
        metrics = FinancialMetrics(period="Q2 FY2026-27", revenue=64259.0, ebit=15437.0, pat=11909.0)
        ob = OrderBookEngine.analyze_order_book("TCS", "Q2 FY2026-27", "IT_SERVICES", metrics, 4150.0)
        rev_val = ReverseValuationEngine.reverse_engineer_expectations("TCS", 4150.0, 64259.0, 11909.0)
        rep = VariantPerceptionEngine.evaluate_unpriced_factors("TCS", "Q2 FY2026-27", "IT_SERVICES", metrics, rev_val, ob, 4150.0)
        
        xlsx_file = ExcelExportService.export_financial_model(
            workspace_root=tmp_path,
            config=cfg,
            metrics=metrics,
            order_book=ob,
            variant_report=rep
        )
        
        assert xlsx_file.exists()
        import openpyxl
        wb = openpyxl.load_workbook(xlsx_file, data_only=False)
        assert "Order Book & Variant Perception" in wb.sheetnames
        ws = wb["Order Book & Variant Perception"]
        
        # Check that live formulas are present
        assert ws["D7"].value == "=D7/C6" or ws["D8"].value == "=D7/C6"
        assert "C11" in str(ws["E11"].value)
