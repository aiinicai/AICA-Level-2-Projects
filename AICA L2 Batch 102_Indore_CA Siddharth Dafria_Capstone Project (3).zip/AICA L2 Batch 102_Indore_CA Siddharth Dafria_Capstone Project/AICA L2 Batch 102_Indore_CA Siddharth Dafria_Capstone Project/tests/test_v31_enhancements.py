"""Comprehensive unit & integration tests for QuarterIQ v3.1 Institutional Enhancements:
1. Management Commentary & Concall Transcript NLP Intelligence
2. Multi-Quarter Side-by-Side Analytical KPI Matrix
3. Automated PDF Export & ChatGPT Workflow
4. Red-Flagging of Unfiled / Pending LODR 33 Quarterly Results
5. Trendlyne.com Source Integration
6. 5-Pillar Scorecard & Average Analyst Target Price
7. Institutional Consensus Polls Comparison (CNBC Awaaz, Reuters, Kotak, Motilal Oswal, ICICI Direct)
"""
from pathlib import Path
import pytest

from src.analyzers.concall_nlp_engine import ConcallNLPEngine
from src.analyzers.institutional_scores_engine import InstitutionalScoresEngine
from src.analyzers.surprise_engine import EarningsSurpriseEngine
from src.core.constants import TRUSTED_SOURCES
from src.core.indian_fiscal import get_results_filing_status
from src.core.models import (
    ConcallNLPAnalysis,
    FinancialMetrics,
    FinancialRatios,
    ForensicFinding,
    ForensicScores,
    InstitutionalScores,
    ResearchConfig,
)
from src.core.workspace import WorkspaceManager
from src.providers.auto_harvester import AutoDocumentHarvester
from src.reports.html_generator import HTMLReportGenerator
from src.services.pdf_export_service import PDFExportService


def test_concall_nlp_engine():
    """Verify ConcallNLPEngine computes sentiment, tone shift, investor takeaways, and Q&A scrutiny."""
    cur = FinancialMetrics(period="Q2 FY2026-27", revenue=73188.0, pat=13934.0, diluted_eps=38.37)
    nlp = ConcallNLPEngine.analyze_concall("TCS", "Q2 FY2026-27", None, cur)

    assert isinstance(nlp, ConcallNLPAnalysis)
    assert nlp.sentiment_score >= 50
    assert nlp.credibility_index >= 70
    assert "shift" in nlp.tone_shift_vs_prior.lower() or "pts" in nlp.tone_shift_vs_prior.lower()
    assert len(nlp.investor_perspective_takeaways) >= 3
    assert len(nlp.top_keywords) >= 4
    assert len(nlp.institutional_qa_highlights) >= 2

    # Check that tier-1 institutional broker analysts are present
    brokerages = [qa.get("broker", qa.get("brokerage", "")) for qa in nlp.institutional_qa_highlights]
    assert any("Kotak" in b or "Morgan Stanley" in b or "Motilal" in b or "Goldman" in b for b in brokerages)


def test_institutional_5_pillar_scores():
    """Verify InstitutionalScoresEngine evaluates all 5 pillars and consensus price target."""
    cur = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=52000.0,
        ebitda=17000.0,
        pat=11800.0,
        diluted_eps=16.80,
        gross_debt=0.0,
        cfo=12500.0
    )
    scores = InstitutionalScoresEngine.evaluate_scores(
        symbol="ICICIBANK",
        quarter="Q2 FY2026-27",
        current_metrics=cur,
        surprise_score=85,
        reference_price=1285.0
    )

    assert isinstance(scores, InstitutionalScores)
    assert 0 <= scores.surprise_forecast_score <= 100
    assert 0 <= scores.durability_score <= 100
    assert 0 <= scores.valuation_score <= 100
    assert 0 <= scores.momentum_score <= 100
    assert scores.average_analyst_target_price > 1285.0
    assert scores.consensus_upside_pct > 0
    assert scores.consensus_recommendation in ("BUY", "ACCUMULATE", "HOLD")
    assert scores.total_analyst_coverage >= 20
    assert scores.buy_ratings > scores.sell_ratings


def test_consensus_polls_breakdown():
    """Verify EarningsSurpriseEngine provides polls for CNBC Awaaz, Reuters, Kotak, Motilal Oswal, ICICI Direct."""
    engine = EarningsSurpriseEngine()
    cur = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=73188.0,
        ebit=17301.0,
        pat=13934.0,
        diluted_eps=38.37
    )
    res = engine.evaluate_surprise("TCS", "Q2 FY2026-27", cur)

    assert len(res.poll_estimates) >= 5
    poll_names = [p.source_name for p in res.poll_estimates]
    assert any("CNBC Awaaz" in p for p in poll_names)
    assert any("Reuters" in p for p in poll_names)
    assert any("Kotak" in p for p in poll_names)
    assert any("Motilal Oswal" in p for p in poll_names)
    assert any("ICICI Direct" in p for p in poll_names)

    for p in res.poll_estimates:
        assert p.revenue_est_cr > 0
        assert p.overall_verdict in ("BEAT", "IN_LINE", "MISS")


def test_results_unavailable_red_flag(tmp_path):
    """Verify that unfiled/pending quarter results trigger the critical red-flag banner and restricted verdict."""
    cfg = ResearchConfig(
        company_symbol="TCS",
        company_name="Tata Consultancy Services Limited",
        reporting_quarter="Q4 FY2026-27",  # Future / unfiled quarter
        financial_year="FY2026-27",
        accounting_basis="Consolidated",
        output_base_dir=str(tmp_path),
        is_results_unavailable=True,
        unavailability_reason="Pending Q4 annual results board meeting scheduled in April 2027"
    )
    gen = HTMLReportGenerator(tmp_path, cfg)
    cur = FinancialMetrics(period="Q4 FY2026-27", revenue=75000.0, pat=14200.0, diluted_eps=39.0)
    
    findings = []
    report_path = gen.generate_report(
        current_metrics=cur,
        prior_yoy=None,
        prior_qoq=None,
        ratios=FinancialRatios(period="Q4 FY2026-27"),
        forensic_scores=ForensicScores(),
        forensic_findings=findings,
        manifest_docs=[],
        is_results_unavailable=True
    )

    html = report_path.read_text(encoding="utf-8")
    assert "CRITICAL AUDIT RED-FLAG" in html
    assert "STATUTORY RESULTS UNAVAILABLE" in html
    assert "Pending Q4 annual results board meeting" in html
    assert "RESTRICTED" in html

    # Verify that a critical ForensicFinding was injected
    assert any(f.category == "REGULATORY_LODR_FILING" and f.severity in ("RED_FLAG", "CRITICAL") for f in findings)


def test_trendlyne_trusted_source():
    """Verify Trendlyne.com is registered in trusted sources and harvester includes it."""
    assert any("trendlyne.com" in s.lower() for s in TRUSTED_SOURCES)

    harvester = AutoDocumentHarvester()
    logs = []
    docs = harvester.harvest_trendlyne("TCS", "Tata Consultancy Services", "532540", log_callback=logs.append)
    assert len(docs) >= 1
    assert any("trendlyne.com" in d["url"] for d in docs)


def test_pdf_export_service(tmp_path):
    """Verify PDFExportService generates a valid PDF from an HTML research report."""
    test_html = tmp_path / "test_report.html"
    test_html.write_text("<!DOCTYPE html><html><body><h1>QuarterIQ Research Dossier</h1><p>Auditor: Siddharth Dafria, CA</p></body></html>", encoding="utf-8")

    out_pdf = tmp_path / "test_report.pdf"
    res_path = PDFExportService.export_html_to_pdf(test_html, out_pdf, auto_open=False)

    assert res_path.exists()
    assert res_path.stat().st_size > 100
    # Must start with standard PDF header %PDF
    assert res_path.read_bytes().startswith(b"%PDF")
