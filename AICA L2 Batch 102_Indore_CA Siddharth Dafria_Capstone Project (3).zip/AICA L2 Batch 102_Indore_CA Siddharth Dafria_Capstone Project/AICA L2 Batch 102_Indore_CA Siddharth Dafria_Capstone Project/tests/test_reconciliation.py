"""Unit tests for Financial Statement Arithmetic Reconciliation."""
import pytest
from src.analyzers.reconciliation import ReconciliationAuditor
from src.core.models import FinancialMetrics


def test_reconciliation_pass():
    m = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=10000.0,
        other_income=250.0,
        total_income=10250.0,
        total_expenses=8000.0,
        exceptional_items=0.0,
        pbt=2250.0,
        tax_expense=550.0,
        pat=1700.0,
        ebitda=2650.0,
        depreciation=400.0,
        ebit=2250.0
    )
    auditor = ReconciliationAuditor()
    results = auditor.audit_metrics(m)

    for item in results:
        assert item.passed is True, f"Failed check: {item.check_name} - {item.notes}"


def test_reconciliation_discrepancy_detection():
    # Intentionally corrupted PAT equation
    m = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=10000.0,
        other_income=250.0,
        total_income=10250.0,
        total_expenses=8000.0,
        pbt=2250.0,
        tax_expense=550.0,
        pat=2000.0  # Mismatch: 2250 - 550 should be 1700!
    )
    auditor = ReconciliationAuditor()
    results = auditor.audit_metrics(m)

    pat_check = [r for r in results if r.check_name == "Net Profit (PAT) Equation"][0]
    assert pat_check.passed is False
    assert pat_check.variance == 300.0
    assert "PAT mismatch" in pat_check.notes
