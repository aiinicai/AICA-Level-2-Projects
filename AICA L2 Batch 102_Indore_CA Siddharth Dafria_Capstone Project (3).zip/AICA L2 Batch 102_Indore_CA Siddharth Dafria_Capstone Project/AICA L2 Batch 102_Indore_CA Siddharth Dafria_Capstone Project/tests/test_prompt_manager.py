"""Unit tests for Research Prompt Engineering & Context Injection."""
import pytest
from src.core.models import (
    FinancialMetrics,
    FinancialRatios,
    ForensicScores,
    ResearchConfig,
)
from src.services.prompt_manager import PromptManager


def test_prompt_generation():
    pm = PromptManager()
    prompts = pm.list_available_prompts()
    assert len(prompts) >= 2

    cfg = ResearchConfig(
        company_symbol="RELIANCE",
        company_name="Reliance Industries Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        current_market_price=2950.0
    )

    manifest_docs = [
        {
            "category": "Financial Results",
            "file_name": "RIL_Results_Q2_FY27.pdf",
            "file_size_bytes": 2450000,
            "sha256": "1234567890abcdef1234567890abcdef",
            "verification_status": "VERIFIED"
        }
    ]

    metrics = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=240000.0,
        ebitda=42000.0,
        pat=19500.0,
        diluted_eps=28.8
    )

    ratios = FinancialRatios(
        period="Q2 FY2026-27",
        revenue_growth_yoy=11.2,
        ebitda_margin=17.5
    )

    forensic = ForensicScores(
        beneish_m_score=-2.80,
        beneish_flag="LOW_RISK"
    )

    prompt = pm.build_prompt(
        prompt_id="institutional_v2",
        config=cfg,
        manifest_docs=manifest_docs,
        metrics=metrics,
        ratios=ratios,
        forensic_scores=forensic
    )

    assert "Reliance Industries Limited" in prompt
    assert "RELIANCE" in prompt
    assert "Q2 FY2026-27" in prompt
    assert "RIL_Results_Q2_FY27.pdf" in prompt
    assert "ZERO FABRICATION" in prompt
    assert "2,40,000.00 Cr" in prompt or "240000" in prompt
