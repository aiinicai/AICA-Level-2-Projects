"""Unit tests for Deterministic Financial Ratio Calculations."""
import pytest
from src.analyzers.ratios import FinancialRatioEngine
from src.core.models import FinancialMetrics


def test_financial_ratios_calculation():
    current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=10000.0,
        cogs=5000.0,
        ebitda=2500.0,
        depreciation=400.0,
        ebit=2100.0,
        finance_costs=300.0,
        pbt=1800.0,
        tax_expense=450.0,
        pat=1350.0,
        diluted_eps=15.0,
        cfo=2000.0,
        gross_debt=3000.0,
        receivables=2000.0,
        inventory=1000.0,
        payables=1000.0
    )

    prior_yoy = FinancialMetrics(
        period="Q2 FY2025-26",
        revenue=8000.0,
        cogs=4200.0,
        diluted_eps=12.0
    )

    prior_qoq = FinancialMetrics(
        period="Q1 FY2026-27",
        revenue=9500.0
    )

    ratios = FinancialRatioEngine.calculate_ratios(current, prior_yoy, prior_qoq)

    # 1. Growth
    # YoY: (10000 - 8000)/8000 = +25.0%
    assert ratios.revenue_growth_yoy == 25.0
    # QoQ: (10000 - 9500)/9500 = +5.26%
    assert ratios.revenue_growth_qoq == 5.26
    # EPS YoY: (15 - 12)/12 = +25.0%
    assert ratios.eps_growth_yoy == 25.0

    # 2. Margins
    # EBITDA Margin: 2500 / 10000 = 25.0%
    assert ratios.ebitda_margin == 25.0
    # PAT Margin: 1350 / 10000 = 13.5%
    assert ratios.pat_margin == 13.5
    # Gross Margin: (10000 - 5000) / 10000 = 50.0%
    assert ratios.gross_margin == 50.0

    # 3. Coverage & Leverage
    # Debt / EBITDA (annualized): 3000 / (2500 * 4) = 0.30x
    assert ratios.debt_to_ebitda == 0.30
    # Interest Coverage: 2100 / 300 = 7.0x
    assert ratios.interest_coverage == 7.0

    # 4. Cash Realization
    # CFO / EBITDA: 2000 / 2500 = 0.80x
    assert ratios.cfo_to_ebitda == 0.80
    # CFO / PAT: 2000 / 1350 = 1.48x
    assert ratios.cfo_to_pat == 1.48

    # 5. Working Capital Days (Quarterly 90 days)
    # DSO: (2000 / 10000) * 90 = 18.0 days
    assert ratios.dso == 18.0
    # DIO: (1000 / 5000) * 90 = 18.0 days
    assert ratios.dio == 18.0
    # DPO: (1000 / 5000) * 90 = 18.0 days
    assert ratios.dpo == 18.0
    # CCC: 18 + 18 - 18 = 18.0 days
    assert ratios.ccc == 18.0

    # 6. Effective Tax Rate: 450 / 1800 = 25.0%
    assert ratios.effective_tax_rate == 25.0


def test_banking_ratios_omits_industrial_metrics():
    """Confirms that commercial banking analysis does not compute inappropriate industrial ratios."""
    bank_current = FinancialMetrics(
        period="Q2 FY2026-27",
        revenue=32000.0,  # Total Income
        pat=4800.0,
        diluted_eps=9.25,
        cfo=5100.0,
        gross_debt=0.0  # Deposits are operating liabilities, not gross debt
    )

    ratios = FinancialRatioEngine.calculate_ratios(bank_current, sector="Banking / Public Sector")

    # Inapplicable industrial metrics must be None for banks
    assert ratios.debt_to_ebitda is None
    assert ratios.dio is None
    assert ratios.ccc is None
    assert ratios.gross_margin is None
    assert ratios.pat_margin == 15.0
