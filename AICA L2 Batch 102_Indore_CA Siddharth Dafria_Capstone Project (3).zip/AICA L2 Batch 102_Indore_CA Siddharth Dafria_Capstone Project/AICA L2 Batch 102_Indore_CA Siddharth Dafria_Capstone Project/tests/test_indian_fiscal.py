"""Unit tests for Indian Fiscal Year logic and Company Master lookup."""
from datetime import date
import pytest
from src.core.indian_fiscal import (
    format_inr,
    format_quarter_label,
    format_folder_period_name,
    get_quarter_date_bounds,
    get_results_filing_status,
    normalize_to_inr_crore,
    parse_quarter_str,
    resolve_company,
    search_companies,
)


def test_parse_quarter_str():
    assert parse_quarter_str("Q2 FY2026-27") == (2, 2026, 2027)
    assert parse_quarter_str("Q1 FY27") == (1, 2026, 2027)
    assert parse_quarter_str("Q4 FY2025-26") == (4, 2025, 2026)


def test_quarter_date_bounds():
    start, end = get_quarter_date_bounds("Q2 FY2026-27")
    assert start == date(2026, 7, 1)
    assert end == date(2026, 9, 30)

    start_q4, end_q4 = get_quarter_date_bounds("Q4 FY2025-26")
    assert start_q4 == date(2026, 1, 1)
    assert end_q4 == date(2026, 3, 31)


def test_format_folder_period_name():
    fy, q = format_folder_period_name("Q2 FY2026-27")
    assert fy == "FY2026-27"
    assert q == "Q2_Sep_2026"

    fy4, q4 = format_folder_period_name("Q4 FY2025-26")
    assert fy4 == "FY2025-26"
    assert q4 == "Q4_Mar_2026"


def test_indian_currency_formatting():
    assert format_inr(123456.78, unit="Cr") == "1,23,456.78 Cr"
    assert format_inr(-4500.5, unit="Cr") == "-4,500.50 Cr"
    assert format_inr(100.0, unit="") == "100.00"
    assert format_inr(None) == "N/A"


def test_normalize_to_inr_crore():
    # 10,000 Lakhs = 100 Crores
    assert normalize_to_inr_crore("10,000", reported_unit="lakh") == 100.0
    # 50 Crores = 50 Crores
    assert normalize_to_inr_crore("50.5", reported_unit="crore") == 50.5
    # 100 Millions = 10 Crores
    assert normalize_to_inr_crore("100", reported_unit="million") == 10.0


def test_search_and_resolve_company():
    matches = search_companies("INFY")
    assert len(matches) > 0
    assert matches[0]["symbol"] == "INFY"

    res = resolve_company("TATASTEEL")
    assert res is not None
    assert res["symbol"] == "TATASTEEL"
    assert "Tata Steel" in res["name"]


def test_filing_status():
    status = get_results_filing_status("Q2 FY2026-27", as_of=date(2026, 10, 19))
    assert status["ended"] is True
    assert status["status"] == "IN_EARNINGS_SEASON"
