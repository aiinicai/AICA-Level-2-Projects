"""Unit tests for Document Content & Authenticity Validator."""
from pathlib import Path
import pytest
import pymupdf
from src.providers.validator import DocumentValidator


def test_validator_with_synthetic_pdf(tmp_path):
    validator = DocumentValidator("INFY", "Infosys Limited", "Q2 FY2026-27")

    # 1. Create a matching PDF
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((50, 100), "INFOSYS LIMITED (INFY)\nStatement of Consolidated Financial Results\nfor the Quarter and Half Year Ended September 30, 2026\nLimited Review Report by Statutory Auditors", fontsize=12)
    pdf_path = tmp_path / "valid_results.pdf"
    doc.save(str(pdf_path))
    doc.close()

    res = validator.validate_pdf(pdf_path)
    assert res["is_valid_pdf"] is True
    assert res["entity_match"] is True
    assert res["period_match"] is True
    assert res["has_auditor_report"] is True
    assert res["verification_status"] == "VERIFIED"


def test_validator_detects_entity_mismatch(tmp_path):
    validator = DocumentValidator("INFY", "Infosys Limited", "Q2 FY2026-27")

    # Create a PDF for a completely different company (e.g. Wipro)
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((50, 100), "WIPRO LIMITED\nQuarter ended September 30, 2026", fontsize=12)
    wrong_entity_pdf = tmp_path / "wipro_results.pdf"
    doc.save(str(wrong_entity_pdf))
    doc.close()

    res = validator.validate_pdf(wrong_entity_pdf)
    assert res["entity_match"] is False
    assert res["verification_status"] == "SUSPECT_ENTITY_MISMATCH"


def test_validator_detects_period_mismatch(tmp_path):
    validator = DocumentValidator("INFY", "Infosys Limited", "Q2 FY2026-27")

    # Create a PDF for a different quarter (e.g. March 31, 2024)
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((50, 100), "INFOSYS LIMITED\nFinancial Results for the Quarter Ended March 31, 2024", fontsize=12)
    wrong_period_pdf = tmp_path / "infy_old_results.pdf"
    doc.save(str(wrong_period_pdf))
    doc.close()

    res = validator.validate_pdf(wrong_period_pdf)
    assert res["entity_match"] is True
    assert res["period_match"] is False
    assert res["verification_status"] == "SUSPECT_PERIOD_MISMATCH"
