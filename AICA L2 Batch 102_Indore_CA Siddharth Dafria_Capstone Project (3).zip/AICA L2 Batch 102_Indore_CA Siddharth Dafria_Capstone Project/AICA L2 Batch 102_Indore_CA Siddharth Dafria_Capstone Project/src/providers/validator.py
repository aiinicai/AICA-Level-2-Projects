"""Document Content & Authenticity Validator using PyMuPDF."""
import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import pymupdf

from src.core.indian_fiscal import get_quarter_date_bounds, parse_quarter_str


class DocumentValidator:
    """Inspects PDF files to verify company identity, reporting period, accounting basis and auditor indicators."""

    def __init__(self, target_symbol: str, target_company_name: str, target_quarter: str):
        self.target_symbol = target_symbol.strip().upper()
        self.target_company_name = target_company_name.strip()
        self.target_quarter = target_quarter.strip()
        self.start_date, self.end_date = get_quarter_date_bounds(target_quarter)

    def validate_pdf(self, file_path: Path) -> Dict[str, Any]:
        """Validates a PDF file on disk.
        
        Returns a dictionary with:
            - is_valid_pdf (bool)
            - page_count (int)
            - entity_match (bool)
            - period_match (bool)
            - accounting_basis ('Consolidated' / 'Standalone' / 'Unknown')
            - has_auditor_report (bool)
            - verification_status ('VERIFIED', 'SUSPECT_PERIOD_MISMATCH', 'SUSPECT_ENTITY_MISMATCH', 'UNVERIFIED')
            - notes (str)
        """
        if not file_path.exists():
            return {
                "is_valid_pdf": False,
                "verification_status": "UNVERIFIED",
                "notes": "File not found on disk."
            }

        if file_path.suffix.lower() != ".pdf":
            # Non-PDF files (e.g. XLSX, CSV)
            return {
                "is_valid_pdf": True,
                "page_count": 1,
                "entity_match": True,
                "period_match": True,
                "accounting_basis": "Unknown",
                "has_auditor_report": False,
                "verification_status": "VERIFIED",
                "notes": f"Spreadsheet / data file ({file_path.suffix}). Content accepted."
            }

        try:
            doc = pymupdf.open(str(file_path))
            page_count = len(doc)
            if page_count == 0:
                return {
                    "is_valid_pdf": False,
                    "verification_status": "UNVERIFIED",
                    "notes": "Corrupted or empty PDF (0 pages)."
                }

            # Inspect up to first 5 pages
            sample_text = ""
            for p_idx in range(min(5, page_count)):
                sample_text += doc[p_idx].get_text() + "\n"

            doc.close()
        except Exception as e:
            return {
                "is_valid_pdf": False,
                "verification_status": "UNVERIFIED",
                "notes": f"PyMuPDF error reading PDF: {e}"
            }

        clean_text = sample_text.upper()

        # 1. Entity Match
        # Check symbol and words from company name
        sym_match = self.target_symbol in clean_text
        name_words = [w for w in re.findall(r'[A-Za-z]{3,}', self.target_company_name.upper()) if w not in ("LIMITED", "LTD", "INDIA", "INDUSTRIES")]
        name_match = any(word in clean_text for word in name_words) if name_words else False
        entity_match = sym_match or name_match

        # 2. Period Match
        # Generate expected date representations
        end_day = str(self.end_date.day)
        end_month_name = self.end_date.strftime("%B").upper()
        end_month_abbr = self.end_date.strftime("%b").upper()
        end_year = str(self.end_date.year)
        
        period_indicators = [
            f"{end_month_name} {end_day}, {end_year}",
            f"{end_day} {end_month_name} {end_year}",
            f"{end_day}TH {end_month_name} {end_year}",
            f"{end_day}-{end_month_abbr}-{end_year}",
            f"{end_day}/{self.end_date.month:02d}/{end_year}",
            f"QUARTER ENDED {end_month_name} {end_year}",
            f"QUARTER ENDED {end_month_abbr} {end_year}",
            f"HALF YEAR ENDED {end_month_name} {end_year}" if self.end_date.month == 9 else "",
            f"NINE MONTHS ENDED {end_month_name} {end_year}" if self.end_date.month == 12 else "",
            f"YEAR ENDED {end_month_name} {end_year}" if self.end_date.month == 3 else "",
        ]
        period_match = any(p in clean_text for p in period_indicators if p)

        # 3. Accounting Basis
        if "CONSOLIDATED" in clean_text and "STANDALONE" in clean_text:
            accounting_basis = "Consolidated & Standalone"
        elif "CONSOLIDATED" in clean_text:
            accounting_basis = "Consolidated"
        elif "STANDALONE" in clean_text:
            accounting_basis = "Standalone"
        else:
            accounting_basis = "Unknown"

        # 4. Auditor Report Indicators
        auditor_patterns = [
            "LIMITED REVIEW", "INDEPENDENT AUDITOR'S REVIEW", "STATUTORY AUDITOR",
            "CHARTERED ACCOUNTANTS", "TRUE AND FAIR VIEW", "REPORT ON REVIEW OF INTERIM"
        ]
        has_auditor_report = any(pat in clean_text for pat in auditor_patterns)

        # Final Verification Status
        if not entity_match:
            status = "SUSPECT_ENTITY_MISMATCH"
            notes = f"Warning: Neither ticker '{self.target_symbol}' nor company name found in the document header."
        elif not period_match:
            status = "SUSPECT_PERIOD_MISMATCH"
            notes = f"Warning: Quarter period '{self.end_date.strftime('%B %Y')}' was not recognized in header text. Please verify file."
        else:
            status = "VERIFIED"
            notes = f"Verified: Entity '{self.target_symbol}' and period ending '{self.end_date.strftime('%d-%b-%Y')}' confirmed. Basis: {accounting_basis}."

        return {
            "is_valid_pdf": True,
            "page_count": page_count,
            "entity_match": entity_match,
            "period_match": period_match,
            "accounting_basis": accounting_basis,
            "has_auditor_report": has_auditor_report,
            "verification_status": status,
            "notes": notes
        }
