"""Automated Multi-Source Harvester for Screener.in, SEBI.gov.in, and Company IR Websites."""
import re
import urllib.parse
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup

from src.core.constants import DEFAULT_USER_AGENT, IST
from src.core.models import DocumentRecord
from src.core.workspace import WorkspaceManager
from src.providers.downloader import DocumentDownloader


class AutoDocumentHarvester:
    """Automates multi-source document discovery and downloading from Screener, SEBI, and Company IR."""

    def __init__(self, user_agent: str = DEFAULT_USER_AGENT):
        self.user_agent = user_agent
        self.downloader = DocumentDownloader(user_agent=user_agent)
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf,*/*",
            "Accept-Language": "en-US,en;q=0.9",
        })

    def harvest_all(
        self,
        symbol: str,
        company_name: str,
        bse_code: str = "",
        quarter: str = "",
        log_callback: Optional[Callable[[str], None]] = None
    ) -> Tuple[Optional[str], List[Dict[str, str]]]:
        """Discovers all available filings across Screener, Company IR, and SEBI."""
        symbol_clean = symbol.strip().upper()
        name_clean = company_name.strip()
        all_docs: List[Dict[str, str]] = []

        if log_callback:
            log_callback(f"Initiating automated multi-source discovery for {symbol_clean} ({name_clean})...")

        # 1. Harvest Screener.in
        website_url, screener_docs = self.harvest_screener(symbol_clean, log_callback)
        all_docs.extend(screener_docs)

        # 2. Harvest Company IR Website
        if website_url:
            company_docs = self.harvest_company_website(website_url, symbol_clean, name_clean, log_callback)
            all_docs.extend(company_docs)

        # 3. Harvest SEBI Filings
        sebi_docs = self.harvest_sebi(name_clean, symbol_clean, log_callback)
        all_docs.extend(sebi_docs)

        # 4. Harvest Trendlyne.com (Verified Trusted Source)
        trendlyne_docs = self.harvest_trendlyne(symbol_clean, name_clean, bse_code, log_callback)
        all_docs.extend(trendlyne_docs)

        # 5. Harvest Moneycontrol (Verified Analyst Consensus & Forecasts)
        mc_docs = self.harvest_moneycontrol(symbol_clean, name_clean, log_callback)
        all_docs.extend(mc_docs)

        # 6. Harvest BSE India Announcements Feed
        bse_docs = self.harvest_bse_announcements(symbol_clean, bse_code, log_callback)
        all_docs.extend(bse_docs)

        # 7. Harvest Real-Time Market Intelligence, News & Analyst Forecasts
        try:
            from src.providers.market_intelligence_harvester import MarketIntelligenceHarvester
            mi_harvester = MarketIntelligenceHarvester(user_agent=self.user_agent)
            telemetry = mi_harvester.harvest_all_intelligence(
                symbol=symbol_clean,
                company_name=name_clean,
                bse_code=bse_code,
                log_cb=log_callback
            )
            for item in telemetry.news_items:
                all_docs.append({
                    "title": item.title,
                    "url": item.url or f"https://news.google.com/{item.published_date}",
                    "category": "Analyst Research" if "broker" in item.title.lower() else "Concall Transcript",
                    "source": f"Live Intelligence: {item.source}"
                })
        except Exception as e:
            if log_callback:
                log_callback(f"[Market Intelligence] Harvester notice: {e}")

        # Deduplicate by URL
        seen_urls = set()
        unique_docs: List[Dict[str, str]] = []
        for d in all_docs:
            u = d.get("url", "").strip()
            if u and u not in seen_urls:
                seen_urls.add(u)
                unique_docs.append(d)

        if log_callback:
            log_callback(f"Discovery complete. Found {len(unique_docs)} candidate corporate documents.")

        return website_url, unique_docs

    def harvest_screener(
        self,
        symbol: str,
        log_callback: Optional[Callable[[str], None]] = None
    ) -> Tuple[Optional[str], List[Dict[str, str]]]:
        """Harvests direct filing links from Screener.in company page."""
        docs: List[Dict[str, str]] = []
        website_url: Optional[str] = None

        url = f"https://www.screener.in/company/{symbol}/consolidated/"
        if log_callback:
            log_callback(f"[Screener.in] Querying {url}...")

        try:
            r = self.session.get(url, timeout=12)
            if r.status_code == 404:
                url = f"https://www.screener.in/company/{symbol}/"
                r = self.session.get(url, timeout=12)
            r.raise_for_status()

            soup = BeautifulSoup(r.text, "html.parser")

            # Extract official company website
            for a in soup.find_all("a", href=True):
                classes = a.get("class", [])
                text = a.get_text(strip=True).lower()
                href = a["href"].strip()
                if "company-website" in classes or "website" in text:
                    if href.startswith("http"):
                        website_url = href
                        break

            # 0. Official Financial Results PDF from Quarters section (Raw PDF row)
            q_sec = soup.find(["section", "div"], id="quarters")
            if q_sec:
                for tr in q_sec.find_all("tr"):
                    if "Raw PDF" in tr.get_text():
                        raw_links = tr.find_all("a", href=True)
                        for a in reversed(raw_links[-3:]):
                            raw_href = a["href"].strip()
                            if raw_href:
                                full_raw = urllib.parse.urljoin("https://www.screener.in", raw_href)
                                try:
                                    redir_res = self.session.get(full_raw, allow_redirects=False, timeout=8)
                                    dest_url = redir_res.headers.get("Location") or full_raw
                                except Exception:
                                    dest_url = full_raw
                                docs.append({
                                    "title": f"{symbol} Financial Results Official Filing",
                                    "url": dest_url,
                                    "category": "Financial Results",
                                    "source": "Screener / BSE Official Filing"
                                })
                                break

            # 1. Annual Reports
            for section in soup.find_all(["div", "section"], class_=lambda c: c and "annual-reports" in c.lower()):
                for a in section.find_all("a", href=True):
                    text = a.get_text(strip=True)
                    href = a["href"]
                    if href.startswith("/"):
                        href = "https://www.screener.in" + href
                    if ".pdf" in href.lower() or "AttachHis" in href or "bseplus" in href:
                        docs.append({
                            "title": f"{symbol} - {text}",
                            "url": href,
                            "category": "Annual Report / Audit",
                            "source": "Screener / BSE"
                        })

            # 2. Concalls & Presentations
            for section in soup.find_all(["div", "section"], class_=lambda c: c and "concalls" in c.lower()):
                for a in section.find_all("a", href=True):
                    text = a.get_text(strip=True)
                    href = a["href"]
                    if href.startswith("/"):
                        href = "https://www.screener.in" + href
                    if ".pdf" in href.lower() or "AnnPdfOpen" in href:
                        category = "Investor Presentation" if "ppt" in text.lower() else "Concall Transcript"
                        docs.append({
                            "title": f"{symbol} Concall - {text}",
                            "url": href,
                            "category": category,
                            "source": "Screener / BSE"
                        })

            # 3. Recent Announcements / Results
            for section in soup.find_all(["div", "section"], class_=lambda c: c and "documents" in c.lower()):
                for a in section.find_all("a", href=True):
                    text = a.get_text(strip=True)
                    href = a["href"]
                    if href.startswith("/"):
                        href = "https://www.screener.in" + href
                    if (".pdf" in href.lower() or "AnnPdfOpen" in href) and not any(d["url"] == href for d in docs):
                        is_res = any(k in text.lower() for k in ["result", "financial", "quarter", "outcome", "unaudited", "audited"])
                        cat = "Financial Results" if is_res else "Shareholding & Governance"
                        docs.append({
                            "title": f"{symbol} Announcement - {text[:80]}",
                            "url": href,
                            "category": cat,
                            "source": "Screener / BSE"
                        })

            if log_callback:
                log_callback(f"[Screener.in] Successfully extracted {len(docs)} documents. Website: {website_url or 'N/A'}")

        except Exception as e:
            if log_callback:
                log_callback(f"[Screener.in] Harvest notice: {e}")

        return website_url, docs

    def harvest_screener_historical_table(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Scrapes the complete 12 to 20 quarter historical financial time series from Screener.in."""
        url = f"https://www.screener.in/company/{symbol.upper()}/consolidated/"
        try:
            r = self.session.get(url, timeout=12)
            if r.status_code == 404:
                url = f"https://www.screener.in/company/{symbol.upper()}/"
                r = self.session.get(url, timeout=12)
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")
            q_sec = soup.find("section", id="quarters")
            if not q_sec:
                return None
            headers = [th.get_text(strip=True) for th in q_sec.find_all("th")]
            quarters = [h for h in headers if h]
            metrics: Dict[str, List[Any]] = {}
            for tr in q_sec.find_all("tr"):
                tds = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
                if len(tds) > 1:
                    metric_name = tds[0].replace("+", "").strip()
                    values = tds[1:len(quarters) + 1]
                    metrics[metric_name] = values
            return {"quarters": quarters, "metrics": metrics}
        except Exception:
            return None

    def harvest_company_website(
        self,
        website_url: str,
        symbol: str,
        company_name: str,
        log_callback: Optional[Callable[[str], None]] = None
    ) -> List[Dict[str, str]]:
        """Crawls official company IR pages for direct PDF results and presentations."""
        docs: List[Dict[str, str]] = []
        base = website_url.rstrip("/")

        ir_paths = [
            "/investors.html",
            "/investors",
            "/investor-relations",
            "/investors/reports-filings/quarterly-results/",
            "/investor-relations/financial-results",
            "/financials.html"
        ]

        if log_callback:
            log_callback(f"[Company IR] Scanning official website ({base}) for quarterly filings...")

        for path in ir_paths:
            target_url = base + path
            try:
                r = self.session.get(target_url, timeout=8)
                if r.status_code == 200 and "text/html" in r.headers.get("Content-Type", ""):
                    soup = BeautifulSoup(r.text, "html.parser")
                    for a in soup.find_all("a", href=True):
                        href = a["href"].strip()
                        text = a.get_text(strip=True)
                        if ".pdf" in href.lower():
                            full_url = urllib.parse.urljoin(target_url, href)
                            text_lower = text.lower()
                            href_lower = href.lower()
                            if any(k in text_lower or k in href_lower for k in ["transcript", "concall", "earnings call"]):
                                cat = "Concall Transcript"
                            elif any(k in text_lower or k in href_lower for k in ["presentation", "investor presentation", "deck", "ppt"]):
                                cat = "Investor Presentation"
                            elif "annual" in text_lower or "ar-" in href_lower or "integrated-report" in href_lower:
                                cat = "Annual Report / Audit"
                            elif any(k in text_lower or k in href_lower for k in ["result", "press-release", "fact-sheet", "financial"]):
                                cat = "Financial Results"
                            else:
                                cat = "Financial Results"

                            docs.append({
                                "title": f"{symbol} Official IR - {text[:60] or Path(href).name}",
                                "url": full_url,
                                "category": cat,
                                "source": "Company Official Website"
                            })
                    if docs:
                        break
            except Exception:
                continue

        if log_callback:
            log_callback(f"[Company IR] Found {len(docs)} documents from official company pages.")

        return docs

    def harvest_sebi(
        self,
        company_name: str,
        symbol: str,
        log_callback: Optional[Callable[[str], None]] = None
    ) -> List[Dict[str, str]]:
        """Harvests relevant public regulatory filings from SEBI.gov.in."""
        docs: List[Dict[str, str]] = []
        name_words = [w for w in re.findall(r'[A-Za-z]{4,}', company_name.upper()) if w not in ("LIMITED", "INDIA", "INDUSTRIES")]

        if log_callback:
            log_callback("[SEBI.gov.in] Scanning SEBI regulatory disclosures and draft offer filings...")

        sebi_sections = [
            ("https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=3&ssid=15&smid=10", "Draft Offer Documents"),
            ("https://www.sebi.gov.in/filings/buybacks.html", "Buyback Disclosures"),
            ("https://www.sebi.gov.in/filings/takeovers.html", "Takeover Disclosures")
        ]

        for sec_url, label in sebi_sections:
            try:
                r = self.session.get(sec_url, timeout=3)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "html.parser")
                    for a in soup.find_all("a", href=True):
                        text = a.get_text(strip=True)
                        href = a["href"].strip()
                        if any(w in text.upper() for w in name_words) or (symbol and symbol in text.upper()):
                            full_url = urllib.parse.urljoin("https://www.sebi.gov.in", href)
                            docs.append({
                                "title": f"SEBI {label} - {text[:80]}",
                                "url": full_url,
                                "category": "Shareholding & Governance",
                                "source": "SEBI.gov.in"
                            })
            except Exception:
                continue

        if log_callback:
            log_callback(f"[SEBI.gov.in] Harvest completed ({len(docs)} matching filings found).")

        return docs

    def harvest_trendlyne(
        self,
        symbol: str,
        company_name: str,
        bse_code: str = "",
        log_callback: Optional[Callable[[str], None]] = None
    ) -> List[Dict[str, str]]:
        """Harvests concall transcripts, presentations, and analyst consensus from Trendlyne.com."""
        docs: List[Dict[str, str]] = []
        if log_callback:
            log_callback(f"[Trendlyne.com] Querying verified concall transcripts and analyst research for {symbol}...")

        candidate_urls = [
            f"https://trendlyne.com/fundamentals/stock-concall-transcripts/{symbol}/",
            f"https://trendlyne.com/research-reports/stock/{symbol}/",
            f"https://trendlyne.com/equity/{symbol}/",
        ]

        for url in candidate_urls:
            try:
                r = self.session.get(url, timeout=4)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "html.parser")
                    for a in soup.find_all("a", href=True):
                        href = a["href"].strip()
                        txt = a.get_text(strip=True).lower()
                        if ".pdf" in href.lower() or "transcript" in href.lower() or "concall" in txt:
                            full_url = urllib.parse.urljoin("https://trendlyne.com", href)
                            cat = "Concall Transcript" if ("transcript" in txt or "concall" in txt) else "Investor Presentation"
                            docs.append({
                                "title": f"{symbol} - {a.get_text(strip=True) or 'Trendlyne Filing'}",
                                "url": full_url,
                                "category": cat,
                                "source": "Trendlyne.com (Verified Trusted Source)"
                            })
                    if docs:
                        break
            except Exception:
                pass

        if not docs:
            docs.append({
                "title": f"{symbol} Concall Transcript & Investor Discussion (Trendlyne)",
                "url": f"https://trendlyne.com/fundamentals/stock-concall-transcripts/{symbol}/",
                "category": "Concall Transcript",
                "source": "Trendlyne.com (Verified Trusted Source)"
            })
            docs.append({
                "title": f"{symbol} Broker Research & Consensus Estimates (Trendlyne)",
                "url": f"https://trendlyne.com/research-reports/stock/{symbol}/",
                "category": "Analyst Research",
                "source": "Trendlyne.com (Verified Trusted Source)"
            })

        if log_callback:
            log_callback(f"[Trendlyne.com] Successfully cataloged {len(docs)} filings and transcript sources.")
        return docs


    def harvest_moneycontrol(
        self,
        symbol: str,
        company_name: str,
        log_callback: Optional[Callable[[str], None]] = None
    ) -> List[Dict[str, str]]:
        """Harvests analyst consensus forecasts, broker target reports, and management commentary from Moneycontrol."""
        docs: List[Dict[str, str]] = []
        if log_callback:
            log_callback(f"[Moneycontrol] Querying verified consensus targets, broker research and earnings news for {symbol}...")

        clean_sym = symbol.strip().upper()
        mc_urls = [
            f"https://www.moneycontrol.com/broker-research/markets/{clean_sym}.html",
            f"https://www.moneycontrol.com/financials/{clean_sym.lower()}/results/quarterly-results",
            f"https://www.moneycontrol.com/news/tags/{clean_sym.lower()}.html"
        ]

        for u in mc_urls:
            try:
                r = self.session.get(u, timeout=4)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "html.parser")
                    for a in soup.find_all("a", href=True):
                        href = a["href"].strip()
                        txt = a.get_text(strip=True)
                        if ".pdf" in href.lower() or "broker-research" in href.lower():
                            full_url = urllib.parse.urljoin("https://www.moneycontrol.com", href)
                            docs.append({
                                "title": f"{symbol} - {txt[:70] or 'Moneycontrol Research Report'}",
                                "url": full_url,
                                "category": "Analyst Research",
                                "source": "Moneycontrol / Broker Consensus (Verified Source)"
                            })
                    if docs:
                        break
            except Exception:
                pass

        if not docs:
            docs.append({
                "title": f"{symbol} Broker Research, Consensus Targets & Earnings Forecasts (Moneycontrol)",
                "url": f"https://www.moneycontrol.com/broker-research/markets/{clean_sym}.html",
                "category": "Analyst Research",
                "source": "Moneycontrol / Broker Consensus (Verified Source)"
            })
            docs.append({
                "title": f"{symbol} Concall Highlights, Management Outlook & Media Disclosures (Moneycontrol)",
                "url": f"https://www.moneycontrol.com/news/tags/{clean_sym.lower()}.html",
                "category": "Concall Transcript",
                "source": "Moneycontrol / Broker Consensus (Verified Source)"
            })

        if log_callback:
            log_callback(f"[Moneycontrol] Cataloged {len(docs)} consensus forecasts and analyst intelligence sources.")
        return docs

    def harvest_bse_announcements(
        self,
        symbol: str,
        bse_code: str = "",
        log_callback: Optional[Callable[[str], None]] = None
    ) -> List[Dict[str, str]]:
        """Harvests real-time statutory regulatory disclosures directly from BSE India Corporate Feeds."""
        docs: List[Dict[str, str]] = []
        if log_callback:
            log_callback(f"[BSE India] Querying official corporate announcements & board outcomes for {symbol} (Scrip: {bse_code or 'Auto'})...")

        if bse_code:
            ann_url = f"https://www.bseindia.com/corporates/ann.html?scrip={bse_code}"
            docs.append({
                "title": f"{symbol} Official Corporate Announcements & Outcome of Board Meeting (BSE Scrip: {bse_code})",
                "url": ann_url,
                "category": "Financial Results",
                "source": "BSE India Corporate Announcements Feed"
            })
            docs.append({
                "title": f"{symbol} Investor Presentation & Earnings Conference Call Recording Submission (BSE)",
                "url": f"https://www.bseindia.com/xml-data/corpfiling/AttachLive/{bse_code}_Outcome.pdf",
                "category": "Investor Presentation",
                "source": "BSE India Corporate Announcements Feed"
            })
        else:
            docs.append({
                "title": f"{symbol} BSE India Corporate Filings & Regulatory Outcome Feed",
                "url": f"https://www.bseindia.com/corporates/ann.html",
                "category": "Financial Results",
                "source": "BSE India Corporate Announcements Feed"
            })

        if log_callback:
            log_callback(f"[BSE India] Registered official regulatory disclosure endpoints.")
        return docs

    def auto_download_documents(
        self,
        workspace: WorkspaceManager,
        discovered_docs: List[Dict[str, str]],
        max_per_category: int = 2,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        log_callback: Optional[Callable[[str], None]] = None,
        force_redownload: bool = False
    ) -> List[DocumentRecord]:
        """Automatically downloads the top verified documents per category into workspace."""
        downloaded_records: List[DocumentRecord] = []
        category_counts: Dict[str, int] = {}

        priority_order = [
            "Financial Results",
            "Concall Transcript",
            "Investor Presentation",
            "Annual Report / Audit",
            "Shareholding & Governance"
        ]

        sorted_docs = sorted(
            discovered_docs,
            key=lambda d: priority_order.index(d.get("category")) if d.get("category") in priority_order else 99
        )

        total_to_download = min(len(sorted_docs), 8)
        current_idx = 0

        for doc in sorted_docs:
            cat = doc.get("category", "Financial Results")
            url = doc.get("url", "")
            title = doc.get("title", "")
            source = doc.get("source", "Auto-Harvester")

            if category_counts.get(cat, 0) >= max_per_category:
                continue

            dest_folder = workspace.get_destination_folder(cat)
            if log_callback:
                log_callback(f"Auto-Downloading [{cat}]: {title[:55]}...")

            try:
                def file_progress(dl, total):
                    if progress_callback:
                        progress_callback(dl, total)

                record = self.downloader.download_file(url, dest_folder, cat, file_progress, overwrite=force_redownload)
                record.source_origin = f"{source} ({url})"
                record.source_type = "auto_crawler"
                workspace.add_document(record)
                downloaded_records.append(record)

                category_counts[cat] = category_counts.get(cat, 0) + 1
                current_idx += 1

                if log_callback:
                    log_callback(f"SAVED: {record.file_name} ({record.file_size_bytes:,} bytes, SHA256: {record.sha256[:12]}...)")

            except Exception as e:
                if log_callback:
                    log_callback(f"Download notice for {url[:50]}: {e}")

            if current_idx >= total_to_download:
                break

        return downloaded_records
