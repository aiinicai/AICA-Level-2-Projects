"""Secure Document Downloader with validation, retries, and integrity checks."""
import re
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

import requests

from src.core.constants import (
    ACCEPTED_EXTENSIONS,
    DEFAULT_TIMEOUT_SEC,
    DEFAULT_USER_AGENT,
    IST,
    MAX_DOWNLOAD_BYTES,
    MAX_DOWNLOAD_RETRIES,
)
from src.core.models import DocumentRecord
from src.core.workspace import compute_sha256, safe_filename


class DocumentDownloader:
    """Handles direct file downloads with safety, progress updates, and file integrity validation."""

    def __init__(self, timeout: int = DEFAULT_TIMEOUT_SEC, user_agent: str = DEFAULT_USER_AGENT):
        self.timeout = timeout
        self.user_agent = user_agent
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/octet-stream,*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive"
        })

    def download_file(
        self,
        url: str,
        dest_folder: Path,
        category: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        overwrite: bool = False
    ) -> DocumentRecord:
        """Downloads a document from a direct HTTPS URL with retries and content validation.
        
        Args:
            url: Direct document URL
            dest_folder: Target directory
            category: Document classification category
            progress_callback: Optional callback receiving (bytes_downloaded, total_bytes)
            overwrite: If True, replaces existing file with same name rather than appending suffix.
            
        Returns:
            DocumentRecord containing file metadata and hash.
        """
        parsed = urllib.parse.urlparse(url.strip())
        if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
            raise ValueError("Enter a valid direct HTTP/HTTPS document URL.")

        last_error = None
        for attempt in range(1, MAX_DOWNLOAD_RETRIES + 1):
            try:
                return self._execute_download(url, dest_folder, category, progress_callback, overwrite=overwrite)
            except Exception as e:
                last_error = e
                if attempt < MAX_DOWNLOAD_RETRIES:
                    time.sleep(1.5 * attempt)  # Exponential backoff

        raise RuntimeError(f"Download failed after {MAX_DOWNLOAD_RETRIES} attempts: {last_error}")

    def _execute_download(
        self,
        url: str,
        dest_folder: Path,
        category: str,
        progress_callback: Optional[Callable[[int, int], None]],
        overwrite: bool = False
    ) -> DocumentRecord:
        with self.session.get(url, stream=True, timeout=self.timeout) as resp:
            resp.raise_for_status()

            # Determine filename from Content-Disposition or URL path
            filename = ""
            cd = resp.headers.get("Content-Disposition", "")
            if cd:
                m = re.search(r'filename\*?=(?:UTF-8\'\')?["\']?([^";\r\n]+)["\']?', cd, re.IGNORECASE)
                if m:
                    filename = urllib.parse.unquote(m.group(1))

            if not filename:
                path_part = urllib.parse.urlparse(resp.url).path
                filename = urllib.parse.unquote(Path(path_part).name) or "downloaded_document.pdf"

            base_name = safe_filename(Path(filename).stem)
            ext = Path(filename).suffix.lower()

            content_type = resp.headers.get("Content-Type", "").lower()
            if ext not in ACCEPTED_EXTENSIONS:
                if "pdf" in content_type:
                    ext = ".pdf"
                elif "sheet" in content_type or "excel" in content_type:
                    ext = ".xlsx"
                else:
                    ext = ".pdf"

            # Unique destination file
            target_file = dest_folder / f"{base_name}{ext}"
            if not overwrite:
                counter = 2
                while target_file.exists():
                    target_file = dest_folder / f"{base_name}_{counter}{ext}"
                    counter += 1

            total_size = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            first_chunk = b""

            try:
                with open(target_file, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=64 * 1024):
                        if not chunk:
                            continue
                        if not first_chunk:
                            first_chunk = chunk[:2048]
                        downloaded += len(chunk)
                        if downloaded > MAX_DOWNLOAD_BYTES:
                            raise ValueError(f"File size exceeds safety cap of {MAX_DOWNLOAD_BYTES // (1024*1024)} MB.")
                        f.write(chunk)
                        if progress_callback:
                            progress_callback(downloaded, total_size)

                # Validate magic bytes
                lower_first = first_chunk.lstrip().lower()
                if lower_first.startswith((b"<!doctype html", b"<html", b"<?xml")):
                    raise ValueError("The server returned a web page (HTML/XML login or captcha) instead of a binary document.")

                if ext == ".pdf" and not (b"%PDF" in first_chunk[:1024]):
                    raise ValueError("File does not start with valid PDF signature (%PDF). May be a protected or invalid download.")

                if ext in (".xlsx", ".docx") and not first_chunk.startswith(b"PK\x03\x04"):
                    raise ValueError(f"File does not have a valid Office OpenXML signature ({ext}).")

                # Compute SHA-256 hash
                sha256 = compute_sha256(target_file)
                now_ist = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

                return DocumentRecord(
                    category=category,
                    file_path=str(target_file.relative_to(dest_folder.parent.parent.parent)),
                    file_name=target_file.name,
                    file_size_bytes=target_file.stat().st_size,
                    sha256=sha256,
                    source_origin=url,
                    source_type="direct_download",
                    collected_at=now_ist,
                    verified=False,
                    verification_status="UNVERIFIED",
                    verification_notes="Cryptographic hash computed; requires entity and period verification."
                )
            except Exception:
                target_file.unlink(missing_ok=True)
                raise
