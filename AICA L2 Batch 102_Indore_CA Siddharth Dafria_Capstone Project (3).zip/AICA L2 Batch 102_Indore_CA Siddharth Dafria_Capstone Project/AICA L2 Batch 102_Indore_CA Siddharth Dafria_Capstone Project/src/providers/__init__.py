"""QuarterIQ Providers Module for Document Discovery, Downloading and Validation."""
