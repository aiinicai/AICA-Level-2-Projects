"""Document Discovery Engine for Indian Listed Companies."""
import urllib.parse
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class DiscoveredSource:
    title: str
    category: str
    url: str
    source_type: str  # 'OFFICIAL_EXCHANGE', 'COMPANY_IR', 'PUBLIC_REPOSITORY'
    description: str


class DocumentDiscoveryEngine:
    """Generates official source discovery links and searches for company filings."""

    def __init__(self, symbol: str, company_name: str, quarter: str, bse_code: str = ""):
        self.symbol = symbol.strip().upper()
        self.company_name = company_name.strip()
        self.quarter = quarter.strip()
        self.bse_code = bse_code.strip()

    def get_official_exchange_links(self) -> List[DiscoveredSource]:
        """Returns direct official exchange and search URLs."""
        sources = []
        sym_encoded = urllib.parse.quote(self.symbol)
        
        # 1. NSE Financial Results & Integrated Filings
        sources.append(DiscoveredSource(
            title=f"NSE India — Corporate Filings ({self.symbol})",
            category="Financial Results",
            url=f"https://www.nseindia.com/companies-listing/corporate-filings-financial-results",
            source_type="OFFICIAL_EXCHANGE",
            description="NSE quarterly financial results and limited review reports. Check 'Integrated Filing - Financials' for recent quarters."
        ))

        # 2. NSE Corporate Announcements
        sources.append(DiscoveredSource(
            title=f"NSE India — Announcements & Presentations ({self.symbol})",
            category="Investor Presentation",
            url=f"https://www.nseindia.com/companies-listing/corporate-filings-announcements",
            source_type="OFFICIAL_EXCHANGE",
            description="NSE corporate announcements containing investor presentations, press releases and board meeting outcome."
        ))

        # 3. BSE Financial Results
        bse_results_url = f"https://www.bseindia.com/corporates/Comp_Resultsnew.aspx"
        if self.bse_code:
            bse_results_url += f"?scrip_cd={self.bse_code}"
        sources.append(DiscoveredSource(
            title=f"BSE India — Financial Results ({self.symbol})",
            category="Financial Results",
            url=bse_results_url,
            source_type="OFFICIAL_EXCHANGE",
            description="BSE XBRL and PDF quarterly submissions with Limited Review Reports."
        ))

        # 4. BSE Corporate Announcements
        bse_ann_url = f"https://www.bseindia.com/corporates/ann.html"
        if self.bse_code:
            bse_ann_url += f"?scrip={self.bse_code}"
        sources.append(DiscoveredSource(
            title=f"BSE India — Corporate Announcements ({self.symbol})",
            category="Concall Transcript",
            url=bse_ann_url,
            source_type="OFFICIAL_EXCHANGE",
            description="BSE announcements containing concall transcripts and audio recordings links."
        ))

        # 5. Screener.in Direct Repository
        sources.append(DiscoveredSource(
            title=f"Screener.in — {self.symbol} Disclosures",
            category="Financial Results",
            url=f"https://www.screener.in/company/{self.symbol}/consolidated/",
            source_type="PUBLIC_REPOSITORY",
            description="Aggregated historical quarterly results, concall links, investor presentations, and annual reports."
        ))

        # 6. Trendlyne Research & Concalls
        sources.append(DiscoveredSource(
            title=f"Trendlyne — {self.symbol} Concall & Results",
            category="Concall Transcript",
            url=f"https://trendlyne.com/equity/{self.symbol}/",
            source_type="PUBLIC_REPOSITORY",
            description="Public concall transcripts, audio links, broker consensus and shareholding trends."
        ))

        # 7. Moneycontrol Research & Consensus
        sources.append(DiscoveredSource(
            title=f"Moneycontrol — {self.symbol} Analyst Targets & Broker Research",
            category="Financial Results",
            url=f"https://www.moneycontrol.com/broker-research/markets/{self.symbol}.html",
            source_type="PUBLIC_REPOSITORY",
            description="Institutional broker research notes, consensus forecasts, and target price distribution."
        ))

        # 8. Economic Times Markets & Financials
        sources.append(DiscoveredSource(
            title=f"Economic Times — {self.symbol} Corporate Disclosures & Financial News",
            category="Financial Results",
            url=f"https://economictimes.indiatimes.com/markets",
            source_type="PUBLIC_REPOSITORY",
            description="Live business news, board announcements, and quarterly peer comparisons."
        ))

        # 9. Targeted Google IR Search
        query = f'"{self.company_name}" "{self.quarter}" (financial results OR "investor presentation" OR transcript) filetype:pdf'
        google_url = "https://www.google.com/search?q=" + urllib.parse.quote(query)
        sources.append(DiscoveredSource(
            title=f"Google Search — Official IR PDF Disclosures",
            category="Financial Results",
            url=google_url,
            source_type="COMPANY_IR",
            description="Targeted search for official company IR disclosures and PDFs."
        ))

        return sources

    def get_filing_checklist(self) -> List[Dict[str, str]]:
        """Returns standard document checklist items with recommended file sources."""
        return [
            {
                "document": "Quarterly Financial Results",
                "category": "Financial Results",
                "source": "NSE / BSE LODR Reg 33 filing",
                "recommended_for": "Core P&L, Segment Revenues, EPS, and Notes to Accounts"
            },
            {
                "document": "Limited Review / Auditor Report",
                "category": "Limited Review Report",
                "source": "Statutory Auditor signed annexure to results",
                "recommended_for": "Auditor opinion, Emphasis of Matter, and Qualifications"
            },
            {
                "document": "Earnings Conference Call Transcript",
                "category": "Concall Transcript",
                "source": "Exchange disclosure / Company IR",
                "recommended_for": "Management guidance, capacity utilization, pricing commentary"
            },
            {
                "document": "Investor Presentation / Earnings Deck",
                "category": "Investor Presentation",
                "source": "Exchange filing / Company IR",
                "recommended_for": "Operational KPIs, sector breakdown, order book, debt bridges"
            },
            {
                "document": "Latest Annual Report (with CARO 2020)",
                "category": "Annual Report / Audit",
                "source": "BSE / NSE / Company IR",
                "recommended_for": "Related-party transactions, contingent liabilities, CARO remarks"
            },
            {
                "document": "Shareholding Pattern (LODR Reg 31)",
                "category": "Shareholding & Governance",
                "source": "NSE / BSE Shareholding page",
                "recommended_for": "Promoter pledging, FII/DII movement, insider changes"
            }
        ]
