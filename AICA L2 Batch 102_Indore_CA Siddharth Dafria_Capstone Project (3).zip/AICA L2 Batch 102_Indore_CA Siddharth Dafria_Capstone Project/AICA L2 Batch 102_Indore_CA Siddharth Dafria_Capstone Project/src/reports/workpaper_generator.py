"""Financial Verification & Forensic Review Workpaper Generator.
Produces standardized, audit-ready workpapers adhering to ICAI review standards
with explicit review status governance.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.core.branding import (
    AUTHOR_DESIGNATION,
    AUTHOR_EMAIL,
    AUTHOR_MOBILE,
    AUTHOR_NAME,
    AUTHOR_ORGANIZATION,
)
from src.core.constants import IST
from src.core.models import FinancialMetrics, ForensicFinding, ResearchConfig


@dataclass
class AuditCheckSummary:
    check_id: str
    procedure_name: str
    accounting_standard: str
    sample_tested: str
    result: str  # "PASS", "EXCEPTION_NOTED", "INAPPLICABLE"
    variance_cr: float
    notes: str


@dataclass
class ReviewWorkpaper:
    company_symbol: str
    company_name: str
    reporting_quarter: str
    accounting_basis: str
    audit_date_ist: str
    review_status: str  # "Automated Checks Completed - Awaiting Professional Review"
    total_checks_run: int
    passed_checks: int
    failed_checks: int
    unresolved_exceptions: List[str]
    accounting_judgments: List[str]
    limitations: List[str]
    check_summaries: List[AuditCheckSummary] = field(default_factory=list)


class WorkpaperGenerator:
    """Generates standardized forensic review workpapers for institutional research."""

    @classmethod
    def generate_workpaper(
        cls,
        config: ResearchConfig,
        metrics: FinancialMetrics,
        findings: List[ForensicFinding],
        reconciliations: List[Any]
    ) -> ReviewWorkpaper:
        now_ist = datetime.now(IST).strftime("%d-%b-%Y %H:%M:%S IST")

        check_summaries = []
        passed_count = 0
        failed_count = 0
        exceptions = []

        # Map reconciliation items
        for idx, rec in enumerate(reconciliations, 1):
            passed = getattr(rec, "passed", True)
            chk_id = f"REC-{idx:02d}"
            name = getattr(rec, "check_name", "Reconciliation Check")
            var = getattr(rec, "variance", 0.0)
            notes = getattr(rec, "notes", "Verified")
            
            if passed:
                passed_count += 1
                res = "PASS"
            else:
                failed_count += 1
                res = "EXCEPTION_NOTED"
                exceptions.append(f"{name}: Variance of ₹{var} Cr ({notes})")

            check_summaries.append(AuditCheckSummary(
                check_id=chk_id,
                procedure_name=name,
                accounting_standard="Ind AS 1 / Ind AS 34",
                sample_tested=f"{config.reporting_quarter} Financial Statements",
                result=res,
                variance_cr=var,
                notes=notes
            ))

        # Forensic findings checks
        for idx, f in enumerate(findings, 1):
            chk_id = f"FOR-{idx:02d}"
            is_flag = f.severity in ("RED_FLAG", "AMBER_WARNING")
            if is_flag:
                failed_count += 1
                res = "EXCEPTION_NOTED"
                exceptions.append(f"{f.title}: {f.materiality}")
            else:
                passed_count += 1
                res = "PASS"

            check_summaries.append(AuditCheckSummary(
                check_id=chk_id,
                procedure_name=f.title,
                accounting_standard="Ind AS Financial Disclosure Standards",
                sample_tested=f"{f.source_file} ({f.source_page})",
                result=res,
                variance_cr=f.financial_exposure_inr_cr or 0.0,
                notes=f.evidence[:120] + "..." if len(f.evidence) > 120 else f.evidence
            ))

        judgments = [
            "Revenue recognition cut-off and contract milestone certifications evaluated under Ind AS 115.",
            "Impairment assessments and Expected Credit Loss (ECL) provisioning modeled under Ind AS 109.",
            "Lease liability discounting rates and Right-of-Use asset valuations cross-checked under Ind AS 116.",
            "Deferred tax asset recoverability evaluated against projected taxable income."
        ]

        limitations = [
            "This automated workpaper summarizes mathematical and algorithmic forensic verification tests.",
            "It does not constitute a statutory audit opinion, limited review certification, or formal audit report under Section 143 of the Companies Act, 2013.",
            "A practicing Chartered Accountant must independently examine physical records before issuing any statutory certificate."
        ]

        return ReviewWorkpaper(
            company_symbol=config.company_symbol,
            company_name=config.company_name,
            reporting_quarter=config.reporting_quarter,
            accounting_basis=config.accounting_basis,
            audit_date_ist=now_ist,
            review_status="Automated Checks Completed - Awaiting Professional Review",
            total_checks_run=len(check_summaries),
            passed_checks=passed_count,
            failed_checks=failed_count,
            unresolved_exceptions=exceptions,
            accounting_judgments=judgments,
            limitations=limitations,
            check_summaries=check_summaries
        )

    @classmethod
    def render_workpaper_html(cls, wp: ReviewWorkpaper) -> str:
        """Renders an institutional, colour-coded workpaper section."""
        status_badge_color = "#eab308" if wp.failed_checks > 0 else "#10b981"
        status_text = "AUTOMATED CHECKS COMPLETED · AWAITING PROFESSIONAL REVIEW" if wp.failed_checks == 0 else f"{wp.failed_checks} EXCEPTIONS FLAGGED · PENDING SENIOR REVIEW"

        rows = ""
        for c in wp.check_summaries:
            badge = '<span class="status-badge status-pass">PASS</span>' if c.result == "PASS" else '<span class="status-badge status-red">EXCEPTION</span>'
            rows += f"""
            <tr>
                <td style="font-family:monospace;font-weight:600;">{c.check_id}</td>
                <td><strong>{c.procedure_name}</strong></td>
                <td>{c.accounting_standard}</td>
                <td>{c.sample_tested}</td>
                <td style="text-align:center;">{badge}</td>
                <td style="text-align:right;font-family:monospace;">₹{c.variance_cr:.2f} Cr</td>
                <td style="font-size:12px;color:#64748b;">{c.notes}</td>
            </tr>
            """

        ex_items = "".join(f"<li style='margin-bottom:6px;'><strong>{ex}</strong></li>" for ex in wp.unresolved_exceptions) if wp.unresolved_exceptions else "<li>No unresolved reconciliation exceptions noted across primary statements.</li>"
        jd_items = "".join(f"<li style='margin-bottom:6px;'>{jd}</li>" for jd in wp.accounting_judgments)
        lm_items = "".join(f"<li style='margin-bottom:6px;'>{lm}</li>" for lm in wp.limitations)

        return f"""
        <div class="workpaper-container" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:12px;padding:24px;margin-top:20px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #e2e8f0;padding-bottom:16px;margin-bottom:20px;">
                <div>
                    <div style="font-size:11px;font-weight:700;color:#64748b;letter-spacing:1px;text-transform:uppercase;">ICAI Standard Review Framework &middot; Forensic Workpaper WP-01</div>
                    <h2 style="margin:4px 0 6px 0;font-size:22px;color:#0f172a;">Financial Verification &amp; Forensic Review Workpaper</h2>
                    <div style="font-size:13px;color:#475569;">
                        Entity: <strong>{wp.company_name} ({wp.company_symbol})</strong> | Period: <strong>{wp.reporting_quarter}</strong> | Basis: <strong>{wp.accounting_basis}</strong>
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;background:{status_badge_color}18;color:{status_badge_color};border:1px solid {status_badge_color};">
                        &#9679; {status_text}
                    </div>
                    <div style="font-size:11px;color:#64748b;margin-top:6px;">Automated Run: {wp.audit_date_ist}</div>
                </div>
            </div>

            <!-- Summary KPI Grid -->
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:14px;margin-bottom:24px;">
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;">
                    <div style="font-size:12px;color:#64748b;">Total Audit Checks</div>
                    <div style="font-size:20px;font-weight:700;color:#0f172a;">{wp.total_checks_run}</div>
                </div>
                <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px 16px;">
                    <div style="font-size:12px;color:#047857;">Clean Passes</div>
                    <div style="font-size:20px;font-weight:700;color:#059669;">{wp.passed_checks}</div>
                </div>
                <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px 16px;">
                    <div style="font-size:12px;color:#b91c1c;">Exceptions Flaggable</div>
                    <div style="font-size:20px;font-weight:700;color:#dc2626;">{wp.failed_checks}</div>
                </div>
                <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 16px;">
                    <div style="font-size:12px;color:#1d4ed8;">Governing Standard</div>
                    <div style="font-size:16px;font-weight:700;color:#1e40af;">Ind AS / ICAI SRE 2400</div>
                </div>
            </div>

            <!-- Audit Procedures Table -->
            <div style="margin-bottom:24px;overflow-x:auto;">
                <table style="width:100%;border-collapse:collapse;font-size:13px;">
                    <thead>
                        <tr style="background:#f1f5f9;color:#334155;text-align:left;">
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;">Ref</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;">Procedure / Equation</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;">Standard</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;">Sample / Source</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;text-align:center;">Result</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;text-align:right;">Variance</th>
                            <th style="padding:10px;border-bottom:2px solid #cbd5e1;">Auditor Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows}
                    </tbody>
                </table>
            </div>

            <!-- Qualitative Notes -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px;">
                <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:16px;">
                    <h4 style="margin:0 0 10px 0;color:#9a3412;font-size:14px;">&#9888; Material Exceptions &amp; Focus Items</h4>
                    <ul style="margin:0;padding-left:18px;font-size:12px;color:#7c2d12;">
                        {ex_items}
                    </ul>
                </div>
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;">
                    <h4 style="margin:0 0 10px 0;color:#334155;font-size:14px;">&#128269; Key Accounting Judgments Evaluated</h4>
                    <ul style="margin:0;padding-left:18px;font-size:12px;color:#475569;">
                        {jd_items}
                    </ul>
                </div>
            </div>

            <!-- Sign-Off & Governance Block -->
            <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:8px;padding:16px;display:grid;grid-template-columns:2fr 1fr;gap:20px;align-items:center;">
                <div>
                    <div style="font-size:12px;font-weight:700;color:#334155;text-transform:uppercase;letter-spacing:0.5px;">Professional Standards &amp; Disclaimer</div>
                    <ul style="margin:8px 0 0 0;padding-left:16px;font-size:11px;color:#64748b;line-height:1.5;">
                        {lm_items}
                    </ul>
                </div>
                <div style="border-left:1px dashed #cbd5e1;padding-left:20px;font-size:12px;">
                    <div style="color:#64748b;margin-bottom:4px;">Platform Architect &amp; Lead CA:</div>
                    <div style="font-weight:700;color:#0f172a;">{AUTHOR_NAME}</div>
                    <div style="color:#475569;">{AUTHOR_DESIGNATION}</div>
                    <div style="color:#64748b;font-size:11px;margin-top:4px;">Mobile: {AUTHOR_MOBILE} | {AUTHOR_EMAIL}</div>
                    <div style="margin-top:10px;padding:4px 8px;background:#e2e8f0;border-radius:4px;font-size:11px;color:#475569;display:inline-block;">
                        Sign-Off Status: <strong>AWAITING SIGNATURE</strong>
                    </div>
                </div>
            </div>
        </div>
        """
