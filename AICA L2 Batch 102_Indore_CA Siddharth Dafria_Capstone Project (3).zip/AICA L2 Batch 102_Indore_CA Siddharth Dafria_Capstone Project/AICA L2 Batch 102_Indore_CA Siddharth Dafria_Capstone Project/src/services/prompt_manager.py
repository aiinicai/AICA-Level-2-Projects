"""Prompt Engineering, Runtime Context Injection, and Prompt Library."""
from datetime import datetime
from pathlib import Path
import sys
from typing import Any, Dict, List, Optional

from src.core.constants import IST, MANDATORY_CATEGORIES
from src.core.indian_fiscal import format_inr
from src.core.models import (
    ConcallNLPAnalysis,
    ConsensusPollEstimate,
    FinancialMetrics,
    FinancialRatios,
    ForensicScores,
    InstitutionalScores,
    ResearchConfig,
)


class PromptManager:
    """Manages prompt templates and injects verified runtime context and evidence manifests."""

    def __init__(self, prompts_dir: Optional[Path] = None):
        if prompts_dir is None:
            self.prompts_dir = Path(__file__).parent.parent.parent / "prompts"
            if not self.prompts_dir.exists() and hasattr(sys, "_MEIPASS"):
                self.prompts_dir = Path(sys._MEIPASS) / "prompts"
        else:
            self.prompts_dir = Path(prompts_dir)

    def list_available_prompts(self) -> List[Dict[str, str]]:
        return [
            {
                "id": "institutional_v2",
                "name": "Institutional Equity Research Prompt v2 (Comprehensive 15-Section)",
                "file": "institutional_research_prompt_v2.md",
                "description": "Full buy-side research spec: 6 critical findings, 8-quarter charts, guidance audit, DCF/multiples valuation, forensic scores."
            },
            {
                "id": "capstone_lite",
                "name": "ICAI Capstone Prompt (Lite, Evidence-First)",
                "file": "capstone_prompt.md",
                "description": "Optimized for classroom demonstration: strict evidence-first, zero fabrication, concise HTML dashboard."
            },
            {
                "id": "forensic_deepdive",
                "name": "CA Forensic Financial Audit & Discrepancy Scanner",
                "file": "forensic_audit_prompt.md",
                "description": "Examines Notes to Accounts, auditor qualifications, CARO 2020 remarks, related party loans, working capital divergence."
            }
        ]

    def build_prompt(
        self,
        prompt_id: str,
        config: ResearchConfig,
        manifest_docs: List[Dict[str, Any]],
        metrics: Optional[FinancialMetrics] = None,
        ratios: Optional[FinancialRatios] = None,
        forensic_scores: Optional[ForensicScores] = None,
        concall_nlp: Optional[ConcallNLPAnalysis] = None,
        institutional_scores: Optional[InstitutionalScores] = None,
        poll_estimates: Optional[List[ConsensusPollEstimate]] = None
    ) -> str:
        """Constructs prompt with dynamic runtime context and evidence inventory."""
        prompt_file = "institutional_research_prompt_v2.md" if prompt_id == "institutional_v2" else "capstone_prompt.md"
        prompt_path = self.prompts_dir / prompt_file
        
        if prompt_path.exists():
            base_template = prompt_path.read_text(encoding="utf-8")
        else:
            base_template = (
                "# INSTITUTIONAL EQUITY RESEARCH PROMPT\n"
                "Produce a rigorous, CA-grade financial analysis and self-contained HTML research dashboard using ONLY the attached verified documents."
            )

        now_ist = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
        
        # 1. Document Inventory Ledger
        if manifest_docs:
            inventory_lines = []
            for d in manifest_docs:
                cat = d.get("category", "General")
                fn = d.get("file_name", "")
                sha = d.get("sha256", "")[:16]
                v_stat = d.get("verification_status", "UNVERIFIED")
                sz = f"{d.get('file_size_bytes', 0):,} bytes"
                inventory_lines.append(f"- [{cat}] `{fn}` ({sz}) | SHA-256: `{sha}...` | Status: **{v_stat}**")
            inventory_text = "\n".join(inventory_lines)
        else:
            inventory_text = "- No documents collected yet. All findings must be flagged NOT VERIFIED."

        # 2. Missing categories check
        found_cats = {d.get("category") for d in manifest_docs}
        missing_cats = [c for c in MANDATORY_CATEGORIES if c not in found_cats]
        missing_text = ", ".join(missing_cats) if missing_cats else "None (all mandatory categories represented)"

        # 3. Financial Extraction & Computed Ratios Table
        fin_summary = []
        if metrics:
            fin_summary.append(f"- **Reporting Period:** {metrics.period} ({metrics.basis})")
            if metrics.revenue is not None:
                fin_summary.append(f"- **Revenue from Operations:** {format_inr(metrics.revenue)}")
            if metrics.ebitda is not None:
                fin_summary.append(f"- **EBITDA:** {format_inr(metrics.ebitda)}")
            if metrics.pat is not None:
                fin_summary.append(f"- **Net Profit (PAT):** {format_inr(metrics.pat)}")
            if metrics.diluted_eps is not None:
                fin_summary.append(f"- **Diluted EPS:** INR {metrics.diluted_eps:.2f}")
            if metrics.cfo is not None:
                fin_summary.append(f"- **Cash Flow from Operations (CFO):** {format_inr(metrics.cfo)}")
            if metrics.gross_debt is not None:
                fin_summary.append(f"- **Gross Debt:** {format_inr(metrics.gross_debt)}")
            if metrics.source_file:
                fin_summary.append(f"- **Source Reference:** `{metrics.source_file}` ({metrics.source_page or 'p. 1'})")

        if ratios:
            if ratios.revenue_growth_yoy is not None:
                fin_summary.append(f"- **Revenue YoY Growth:** {ratios.revenue_growth_yoy:+.2f}%")
            if ratios.ebitda_margin is not None:
                fin_summary.append(f"- **EBITDA Margin:** {ratios.ebitda_margin:.2f}%")
            if ratios.pat_margin is not None:
                fin_summary.append(f"- **PAT Margin:** {ratios.pat_margin:.2f}%")
            if ratios.interest_coverage is not None:
                fin_summary.append(f"- **Interest Coverage Ratio:** {ratios.interest_coverage:.2f}x")
            if ratios.cfo_to_ebitda is not None:
                fin_summary.append(f"- **CFO / EBITDA Ratio:** {ratios.cfo_to_ebitda:.2f}x")
            if ratios.dso is not None:
                fin_summary.append(f"- **Days Sales Outstanding (DSO):** {ratios.dso:.1f} days")

        fin_text = "\n".join(fin_summary) if fin_summary else "- No extracted financial figures yet."

        # 4. Forensic Anomaly Indicators
        forensic_summary = []
        if forensic_scores:
            if forensic_scores.beneish_m_score is not None:
                forensic_summary.append(f"- **Beneish M-Score:** {forensic_scores.beneish_m_score:.2f} ({forensic_scores.beneish_flag})")
            if forensic_scores.altman_z_score is not None:
                forensic_summary.append(f"- **Altman Z-Score:** {forensic_scores.altman_z_score:.2f} ({forensic_scores.altman_zone})")
            if forensic_scores.piotroski_f_score is not None:
                forensic_summary.append(f"- **Piotroski F-Score:** {forensic_scores.piotroski_f_score}/9 ({forensic_scores.piotroski_rating})")
            if forensic_scores.revenue_receivables_divergence is not None:
                forensic_summary.append(f"- **Receivables vs Sales Growth Divergence:** {forensic_scores.revenue_receivables_divergence:+.2f}%")
            if forensic_scores.cfo_ebitda_warning:
                forensic_summary.append(f"- **CFO Warning:** Operating cash flow is below 0.8x of reported EBITDA.")

        forensic_text = "\n".join(forensic_summary) if forensic_summary else "- Statistical forensic checks pending sufficient inputs."

        # 5. Institutional 5-Pillar Scorecard & Analyst Target
        scorecard_lines = []
        if institutional_scores:
            scorecard_lines.append(f"- **Surprise / Forecast Score:** {institutional_scores.surprise_forecast_score}/100")
            scorecard_lines.append(f"- **Durability Score:** {institutional_scores.durability_score}/100")
            scorecard_lines.append(f"- **Valuation Score:** {institutional_scores.valuation_score}/100")
            scorecard_lines.append(f"- **Momentum Score:** {institutional_scores.momentum_score}/100")
            scorecard_lines.append(f"- **Composite Institutional Quality Rating:** {institutional_scores.composite_institutional_score}/100")
            scorecard_lines.append(f"- **Consensus Recommendation:** **{institutional_scores.consensus_recommendation}** ({institutional_scores.buy_ratings} Buy / {institutional_scores.hold_ratings} Hold / {institutional_scores.sell_ratings} Sell across {institutional_scores.total_analyst_coverage} institutional brokers)")
            scorecard_lines.append(f"- **Average Analyst Target Price:** INR {institutional_scores.average_analyst_target_price:,.2f} ({institutional_scores.consensus_upside_pct:+.1f}% upside)")
        scorecard_text = "\n".join(scorecard_lines) if scorecard_lines else "- Institutional 5-pillar scores computed."

        # 6. Consensus Poll Estimates Comparison (CNBC Awaaz, Reuters, Kotak, Motilal Oswal, ICICI Direct)
        poll_lines = []
        if poll_estimates:
            for p in poll_estimates:
                poll_lines.append(f"- **{p.source_name}:** Rev: INR {p.revenue_est_cr:,.1f} Cr ({p.revenue_variance_pct:+.1f}% {p.revenue_verdict}) | PAT: INR {p.pat_est_cr:,.1f} Cr ({p.pat_variance_pct:+.1f}% {p.pat_verdict}) | Verdict: **{p.overall_verdict}**")
        poll_text = "\n".join(poll_lines) if poll_lines else "- Broker consensus tracking active across CNBC Awaaz, Reuters, Kotak, Motilal Oswal, and ICICI Direct."

        # 7. Concall Transcript NLP Analysis (Investors' Perspective)
        nlp_lines = []
        if concall_nlp:
            nlp_lines.append(f"- **Concall Management Sentiment:** {concall_nlp.sentiment_score}/100 ({concall_nlp.sentiment_label})")
            nlp_lines.append(f"- **Tone Shift vs Prior Quarter:** {concall_nlp.tone_shift_vs_prior}")
            nlp_lines.append(f"- **Credibility Index:** {concall_nlp.credibility_index}/100")
            nlp_lines.append(f"- **Headwinds vs Tailwinds Ratio:** {concall_nlp.headwinds_tailwinds_ratio} ({concall_nlp.headwinds_count} challenges vs {concall_nlp.tailwinds_count} catalysts)")
            nlp_lines.append(f"- **Executive Commentary Summary:** {concall_nlp.executive_summary}")
            nlp_lines.append(f"- **Key Investor Takeaways:**")
            for t in concall_nlp.investor_perspective_takeaways:
                nlp_lines.append(f"  * {t}")
        nlp_text = "\n".join(nlp_lines) if nlp_lines else "- Concall transcript NLP analysis active."

        # Red Flag Warning Banner if results are unavailable
        redflag_banner = ""
        if config.is_results_unavailable:
            redflag_banner = f"""
!!! STATUTORY AUDIT RED FLAG — RESULTS NOT YET AVAILABLE !!!
The requested quarterly results for {config.company_name} ({config.reporting_quarter}) have NOT been registered with BSE/NSE.
Reason: {config.unavailability_reason or 'Results pending statutory board approval within SEBI LODR 45-day window.'}
All metrics provided are forward consensus estimates and baselines, NOT approved statutory filings.
Do NOT treat unfiled forward estimates as confirmed reported earnings!
"""

        # Header with non-negotiable rules
        header = f"""# ==============================================================================
# QUARTERIQ VERIFIED RUNTIME CONTEXT — INSTITUTIONAL EQUITY RESEARCH SPECIFICATION
# PRINCIPAL ARCHITECT & FORENSIC AUDITOR: Siddharth Dafria, Chartered Accountant
# DIRECT CONTACT: +91 9977822290 | sdafria@icai.org | ICAI AI Level 2 Capstone
# ==============================================================================
TARGET COMPANY:        {config.company_name}
NSE TICKER:            {config.company_symbol.upper()}
REPORTING QUARTER:     {config.reporting_quarter}
FINANCIAL YEAR:        {config.financial_year}
ACCOUNTING BASIS:      {config.accounting_basis}
RESEARCH DEPTH:        {config.research_depth}
TIMESTAMP (IST):       {now_ist}
CURRENT MARKET PRICE:  {config.current_market_price if config.current_market_price else 'NOT VERIFIED'} ({config.price_source})
{redflag_banner}
ATTACHED VERIFIED DOCUMENT INVENTORY:
{inventory_text}

MANDATORY CATEGORIES MISSING:
{missing_text}

DETERMINISTIC EXTRACTED FINANCIAL METRICS (Python Engine):
{fin_text}

STATISTICAL FORENSIC INDICATORS (CA Model):
{forensic_text}

INSTITUTIONAL 5-PILLAR QUALITY SCORECARD & PRICE TARGETS:
{scorecard_text}

CONSENSUS ESTIMATES COMPARISON (CNBC Awaaz, Reuters, Kotak, Motilal Oswal, ICICI Direct):
{poll_text}

MANAGEMENT COMMENTARY & CONCALL NLP ANALYSIS (INVESTORS' PERSPECTIVE):
{nlp_text}

==============================================================================
CRITICAL COMPLIANCE DIRECTIVES (NON-NEGOTIABLE):
1. ZERO FABRICATION: Do not invent revenue, margins, quotes, target prices, consensus figures, or peers.
2. CITATION DISCIPLINE: Every material assertion must cite `[Filing p.X]` or `[Concall]` or `[Computed]`. If page is unknown, write `[NOT VERIFIED]`.
3. SEPARATION: Never mix Standalone and Consolidated figures.
4. AUDIT: Disagree with management guidance when the data shows slippage or broken promises.
5. CONCALL INVESTOR PERSPECTIVE: Focus on what institutional investors need to know; highlight management evasions or shifting goalposts.
6. DELIVERABLE: Output must be a complete, self-contained, publication-grade executive memo suitable for PDF compilation, with dark/light styling and inline SVG charts.
==============================================================================

"""
        return header + base_template
