"""ChatGPT Browser-Assisted and Optional API-Driven Research Orchestrator."""
import json
import os
import subprocess
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from src.core.models import ResearchConfig


class ChatGPTService:
    """Manages ChatGPT browser interactions, prompt delivery, and API integrations."""

    def __init__(self, workspace_root: Path, config: ResearchConfig):
        self.workspace_root = workspace_root
        self.config = config
        self.prompt_file_path = workspace_root / "prompt_ready_to_paste.txt"
        self.reports_dir = workspace_root / "11_Research_Reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    def prepare_and_copy_prompt(self, prompt_text: str) -> Path:
        """Saves prompt text to disk and copies to Windows system clipboard."""
        self.prompt_file_path.write_text(prompt_text, encoding="utf-8")
        
        # Copy to clipboard via PowerShell or ctypes
        try:
            cmd = f"Set-Clipboard -Value (Get-Content -LiteralPath '{str(self.prompt_file_path)}' -Raw)"
            subprocess.run(["powershell", "-NoProfile", "-Command", cmd], check=True, timeout=5)
        except Exception:
            # Fallback clipboard method using Python
            try:
                import PySide6.QtGui as QtGui
                cb = QtGui.QGuiApplication.clipboard()
                if cb:
                    cb.setText(prompt_text)
            except Exception:
                pass

        return self.prompt_file_path

    def launch_browser_session(self):
        """Opens ChatGPT in the default browser."""
        try:
            webbrowser.open("https://chatgpt.com/")
        except Exception:
            pass

    def export_pdf_and_open(self, html_path: Optional[Path] = None) -> Optional[Path]:
        """Compiles HTML research report to a PDF dossier and opens it in default viewer."""
        from src.services.pdf_export_service import PDFExportService
        if html_path is None:
            sym = self.config.company_symbol.upper()
            q = self.config.reporting_quarter.replace(" ", "_")
            html_path = self.reports_dir / f"{sym}_{q}_Research.html"
            if not html_path.exists():
                candidates = list(self.reports_dir.glob("*.html"))
                if candidates:
                    html_path = candidates[0]
                else:
                    return None
        return PDFExportService.export_html_to_pdf(html_path, auto_open=True)

    def open_document_folder(self):
        """Opens Windows File Explorer directly to the research workspace folder."""
        if os.name == "nt":
            os.startfile(str(self.workspace_root))
        else:
            webbrowser.open(self.workspace_root.as_uri())

    def import_generated_html_report(self, source_path: Path) -> Path:
        """Imports user's generated HTML research dashboard into 11_Research_Reports."""
        if not source_path.exists():
            raise FileNotFoundError(f"File not found: {source_path}")

        sym = self.config.company_symbol.upper()
        q = self.config.reporting_quarter.replace(" ", "_")
        target_name = f"{sym}_{q}_Research.html"
        target_path = self.reports_dir / target_name

        # Copy content
        content = source_path.read_text(encoding="utf-8", errors="replace")
        target_path.write_text(content, encoding="utf-8")
        return target_path

    def execute_api_pipeline(
        self,
        prompt_text: str,
        api_key: str,
        model: str = "gpt-4o",
        api_base: str = "https://api.openai.com/v1"
    ) -> str:
        """Optional Mode B: Executes prompt via official API if user configured an API key."""
        if not api_key:
            raise ValueError("No API key provided. Use Mode A (Browser-assisted) or configure an API key.")

        url = f"{api_base.rstrip('/')}/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are Buy-Side Head of Research and Senior Forensic Financial Analyst. Output only valid, complete, self-contained HTML research dashboard."
                },
                {
                    "role": "user",
                    "content": prompt_text
                }
            ],
            "temperature": 0.2
        }

        resp = requests.post(url, headers=headers, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        output_content = data["choices"][0]["message"]["content"]

        # Save HTML
        sym = self.config.company_symbol.upper()
        q = self.config.reporting_quarter.replace(" ", "_")
        target_path = self.reports_dir / f"{sym}_{q}_Research.html"
        target_path.write_text(output_content, encoding="utf-8")

        return str(target_path)
