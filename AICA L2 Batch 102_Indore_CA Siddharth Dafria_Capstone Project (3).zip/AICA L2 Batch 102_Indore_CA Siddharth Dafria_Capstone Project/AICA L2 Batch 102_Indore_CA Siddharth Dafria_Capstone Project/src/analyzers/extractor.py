"""Financial Data Extraction Engine for Indian Corporate Filings (PDF / XLSX / CSV)."""
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import pymupdf

from src.core.constants import IST
from src.core.indian_fiscal import normalize_to_inr_crore
from src.core.models import FinancialMetrics


class FinancialExtractor:
    """Extracts line items from Ind AS financial statements in quarterly results PDFs or tables."""

    PATTERNS = {
        "revenue": [
            r"revenue\s+from\s+operations",
            r"income\s+from\s+operations",
            r"total\s+revenue\s+from\s+operations",
            r"net\s+sales"
        ],
        "other_income": [
            r"other\s+income",
            r"other\s+operating\s+revenue"
        ],
        "total_income": [
            r"total\s+income",
            r"total\s+revenue"
        ],
        "cogs": [
            r"cost\s+of\s+materials\s+consumed",
            r"purchase\s+of\s+stock-in-trade",
            r"changes\s+in\s+inventories"
        ],
        "employee_cost": [
            r"employee\s+benefits?\s+expense",
            r"staff\s+cost"
        ],
        "other_expenses": [
            r"other\s+expenses",
            r"manufacturing\s+expenses"
        ],
        "total_expenses": [
            r"total\s+expenses"
        ],
        "depreciation": [
            r"depreciation\s+and\s+amorti[sz]ation",
            r"depreciation"
        ],
        "finance_costs": [
            r"finance\s+costs?",
            r"interest\s+expense"
        ],
        "pbt": [
            r"profit\s+before\s+tax",
            r"profit\s+/\s+\(loss\)\s+before\s+tax"
        ],
        "tax_expense": [
            r"total\s+tax\s+expense",
            r"tax\s+expense",
            r"provision\s+for\s+tax"
        ],
        "pat": [
            r"profit\s+for\s+the\s+period",
            r"net\s+profit\s+after\s+tax",
            r"profit\s+/\s+\(loss\)\s+for\s+the\s+period\s+after\s+tax",
            r"profit\s+after\s+tax"
        ],
        "diluted_eps": [
            r"diluted\s+(?:\(in\s+rs\.\)|\(rs\.\))?",
            r"earnings\s+per\s+equity\s+share\s+diluted",
            r"diluted\s+eps"
        ],
        "basic_eps": [
            r"basic\s+(?:\(in\s+rs\.\)|\(rs\.\))?",
            r"earnings\s+per\s+equity\s+share\s+basic",
            r"basic\s+eps"
        ],
        "receivables": [
            r"trade\s+receivables"
        ],
        "inventory": [
            r"inventories?"
        ],
        "gross_debt": [
            r"total\s+borrowings",
            r"borrowings\s+\(non-current\s+\+\s+current\)"
        ],
        "cash_and_equivalents": [
            r"cash\s+and\s+cash\s+equivalents",
            r"bank\s+balances"
        ],
        "cfo": [
            r"net\s+cash\s+flow\s+from\s+operating\s+activities",
            r"cash\s+generated\s+from\s+operations"
        ],
        "capex": [
            r"purchase\s+of\s+property,\s+plant\s+and\s+equipment",
            r"capital\s+expenditure"
        ]
    }

    def __init__(self, target_quarter: str, basis: str = "Consolidated"):
        self.target_quarter = target_quarter
        self.basis = basis

    def extract_from_pdf(self, pdf_path: Path) -> FinancialMetrics:
        """Parses PDF text and tables to populate FinancialMetrics."""
        metrics = FinancialMetrics(
            period=self.target_quarter,
            basis=self.basis,
            source_file=pdf_path.name,
            extraction_timestamp=datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
        )

        if not pdf_path.exists():
            return metrics

        doc = pymupdf.open(str(pdf_path))
        full_text = ""
        found_unit = "crore"  # Default assumption for Indian corporate filings

        for page_idx in range(len(doc)):
            page_text = doc[page_idx].get_text()
            full_text += page_text + "\n"

            # Detect reporting unit
            lower_text = page_text.lower()
            if "in lakhs" in lower_text or "in lac" in lower_text or "₹ in lakhs" in lower_text:
                found_unit = "lakh"
            elif "in crores" in lower_text or "₹ in crores" in lower_text:
                found_unit = "crore"
            elif "in millions" in lower_text:
                found_unit = "million"

            # Check if this page contains statement of financial results
            if any(h in lower_text for h in ["statement of financial results", "statement of standalone", "statement of consolidated"]):
                metrics.source_page = f"p. {page_idx + 1}"
                if "audited" in lower_text and "unaudited" not in lower_text:
                    metrics.is_audited = True

        doc.close()

        lines = full_text.splitlines()
        extracted_raw: Dict[str, float] = {}

        for line in lines:
            line_clean = line.strip()
            if not line_clean:
                continue

            # Look for number patterns at end of line (e.g., "12,456.78" or "(345.20)")
            numbers = re.findall(r'\(?\b\d{1,3}(?:,\d{2,3})*(?:\.\d+)?\)?', line_clean)
            if not numbers:
                continue

            # The first number column in quarterly results is typically current quarter ended
            first_num_str = numbers[0].replace("(", "-").replace(")", "").replace(",", "")
            try:
                raw_num = float(first_num_str)
            except ValueError:
                continue

            line_lower = line_clean.lower()
            for key, patterns in self.PATTERNS.items():
                if key in extracted_raw:
                    continue
                for pat in patterns:
                    if re.search(pat, line_lower):
                        extracted_raw[key] = raw_num
                        break

        # Map to metrics and normalize to INR Crore
        for field_name, raw_val in extracted_raw.items():
            if hasattr(metrics, field_name):
                # EPS does not get divided by lakhs/crores
                if "eps" in field_name:
                    setattr(metrics, field_name, round(raw_val, 2))
                else:
                    norm_val = normalize_to_inr_crore(raw_val, reported_unit=found_unit)
                    setattr(metrics, field_name, norm_val)

        # Derive EBITDA if not explicitly reported: Revenue - (Total Expenses - Depreciation - Finance Costs)
        if metrics.revenue and metrics.total_expenses and metrics.ebitda is None:
            depr = metrics.depreciation or 0.0
            fin = metrics.finance_costs or 0.0
            operating_expenses = metrics.total_expenses - depr - fin
            metrics.ebitda = round(metrics.revenue - operating_expenses, 2)

        # Derive EBIT: EBITDA - Depreciation
        if metrics.ebitda is not None and metrics.depreciation is not None and metrics.ebit is None:
            metrics.ebit = round(metrics.ebitda - metrics.depreciation, 2)

        # Derive Net Debt: Gross Debt - Cash
        if metrics.gross_debt is not None and metrics.cash_and_equivalents is not None:
            metrics.net_debt = round(metrics.gross_debt - metrics.cash_and_equivalents, 2)

        # Derive Free Cash Flow: CFO - Capex
        if metrics.cfo is not None and metrics.capex is not None:
            metrics.fcf = round(metrics.cfo - metrics.capex, 2)

        return metrics

    def extract_from_excel(self, excel_path: Path) -> FinancialMetrics:
        """Parses Excel or CSV financial tables."""
        metrics = FinancialMetrics(
            period=self.target_quarter,
            basis=self.basis,
            source_file=excel_path.name,
            extraction_timestamp=datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
        )

        try:
            if excel_path.suffix.lower() == ".csv":
                df = pd.read_csv(excel_path)
            else:
                df = pd.read_excel(excel_path)

            # Iterate rows and match first column to patterns
            for idx, row in df.iterrows():
                row_str = " ".join([str(x) for x in row.values]).lower()
                for key, patterns in self.PATTERNS.items():
                    if getattr(metrics, key, None) is not None:
                        continue
                    for pat in patterns:
                        if re.search(pat, row_str):
                            # Find first numeric value in row
                            for val in row.values:
                                if isinstance(val, (int, float)) and not pd.isna(val):
                                    norm_val = val if "eps" in key else normalize_to_inr_crore(val, "crore")
                                    setattr(metrics, key, norm_val)
                                    break
                            break
        except Exception:
            pass

        return metrics
