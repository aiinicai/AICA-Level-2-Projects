"""Deterministic Financial Ratio Calculations and Unit Tested Formulas."""
from typing import Optional

from src.core.models import FinancialMetrics, FinancialRatios


class FinancialRatioEngine:
    """Computes verified institutional financial ratios with zero LLM hallucination."""

    @staticmethod
    def calculate_ratios(
        current: FinancialMetrics,
        prior_yoy: Optional[FinancialMetrics] = None,
        prior_qoq: Optional[FinancialMetrics] = None,
        sector: str = "General Industry"
    ) -> FinancialRatios:
        """Calculates institutional financial ratios based on current and historical quarters.
        
        Args:
            current: Current reporting period metrics
            prior_yoy: Same quarter previous financial year (e.g. Q2 FY26 vs Q2 FY25)
            prior_qoq: Sequentially previous quarter (e.g. Q2 FY26 vs Q1 FY26)
            sector: Sector of the target company (e.g. 'Banking', 'Information Technology', 'Steel')
        """
        ratios = FinancialRatios(period=current.period)
        is_banking = any(b in sector.lower() for b in ["bank", "financial services", "nbfc"])

        # 1. Growth Rates
        if current.revenue is not None and prior_yoy is not None and prior_yoy.revenue:
            ratios.revenue_growth_yoy = round(((current.revenue - prior_yoy.revenue) / prior_yoy.revenue) * 100.0, 2)

        if current.revenue is not None and prior_qoq is not None and prior_qoq.revenue:
            ratios.revenue_growth_qoq = round(((current.revenue - prior_qoq.revenue) / prior_qoq.revenue) * 100.0, 2)

        if current.diluted_eps is not None and prior_yoy is not None and prior_yoy.diluted_eps:
            ratios.eps_growth_yoy = round(((current.diluted_eps - prior_yoy.diluted_eps) / abs(prior_yoy.diluted_eps)) * 100.0, 2)

        # 2. Profitability Margins
        if current.revenue and current.revenue > 0:
            if current.ebitda is not None and not is_banking:
                ratios.ebitda_margin = round((current.ebitda / current.revenue) * 100.0, 2)
            if current.pat is not None:
                ratios.pat_margin = round((current.pat / current.revenue) * 100.0, 2)
            if current.cogs is not None and not is_banking:
                ratios.gross_margin = round(((current.revenue - current.cogs) / current.revenue) * 100.0, 2)

        # 3. Leverage & Coverage Ratios (Inapplicable to commercial banks)
        if not is_banking:
            if current.ebitda and current.ebitda > 0:
                if current.gross_debt is not None:
                    # Annualize quarterly EBITDA (* 4)
                    ratios.debt_to_ebitda = round(current.gross_debt / (current.ebitda * 4.0), 2)

            if current.ebit is not None and current.finance_costs and current.finance_costs > 0:
                ratios.interest_coverage = round(current.ebit / current.finance_costs, 2)

        # 4. Cash Flow & Quality of Earnings
        if current.cfo is not None:
            if current.pat and current.pat != 0:
                ratios.cfo_to_pat = round(current.cfo / current.pat, 2)
            if current.ebitda and current.ebitda != 0 and not is_banking:
                ratios.cfo_to_ebitda = round(current.cfo / current.ebitda, 2)
            if current.fcf is not None and current.pat and current.pat > 0:
                ratios.fcf_conversion = round((current.fcf / current.pat) * 100.0, 2)

        # 5. Working Capital Days (Quarterly: 90 days, omitted for Banks)
        if not is_banking and current.revenue and current.revenue > 0:
            if current.receivables is not None:
                ratios.dso = round((current.receivables / current.revenue) * 90.0, 1)

            cogs_base = current.cogs if (current.cogs and current.cogs > 0) else current.revenue
            if current.inventory is not None:
                ratios.dio = round((current.inventory / cogs_base) * 90.0, 1)

            payables_base = current.cogs if (current.cogs and current.cogs > 0) else (current.total_expenses or current.revenue)
            if current.payables is not None:
                ratios.dpo = round((current.payables / payables_base) * 90.0, 1)

            if ratios.dso is not None and ratios.dio is not None and ratios.dpo is not None:
                ratios.ccc = round(ratios.dso + ratios.dio - ratios.dpo, 1)

        # 6. Effective Tax Rate
        if current.pbt and current.pbt > 0 and current.tax_expense is not None:
            ratios.effective_tax_rate = round((current.tax_expense / current.pbt) * 100.0, 2)

        return ratios
