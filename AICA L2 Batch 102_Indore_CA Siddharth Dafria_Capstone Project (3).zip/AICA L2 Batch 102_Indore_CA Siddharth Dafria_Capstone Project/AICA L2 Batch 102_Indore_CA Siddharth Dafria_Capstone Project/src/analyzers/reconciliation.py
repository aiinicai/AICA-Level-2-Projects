"""Financial Statement Reconciliation and Discrepancy Audit Engine.
Uses UniversalMetricRegistry and fixed-precision arithmetic to verify
Ind AS statement integrity and record exceptions.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, List, Optional

from src.core.metric_registry import UniversalMetricRegistry
from src.core.models import FinancialMetrics


@dataclass
class ReconciliationItem:
    check_name: str
    expected_value: float
    actual_value: float
    variance: float
    passed: bool
    formula: str
    notes: str


class ReconciliationAuditor:
    """Audits arithmetic integrity across financial statements and records exceptions."""

    def __init__(self, tolerance_pct: float = 1.0, abs_tolerance_cr: float = 2.0):
        self.tolerance_pct = tolerance_pct
        self.abs_tolerance_cr = abs_tolerance_cr

    def audit_metrics(self, m: FinancialMetrics) -> List[ReconciliationItem]:
        """Runs Ind AS arithmetic reconciliation tests."""
        results = []

        # 1. Total Income Check: Revenue + Other Income == Total Income
        if m.revenue is not None and m.other_income is not None and m.total_income is not None:
            d_rev = UniversalMetricRegistry.to_decimal(m.revenue) or Decimal("0")
            d_oi = UniversalMetricRegistry.to_decimal(m.other_income) or Decimal("0")
            d_tot = UniversalMetricRegistry.to_decimal(m.total_income) or Decimal("0")
            
            calc = d_rev + d_oi
            var = abs(calc - d_tot)
            var_flt = float(var)
            pct = (var_flt / float(d_tot) * 100) if d_tot > 0 else 0
            passed = var_flt <= self.abs_tolerance_cr or pct <= self.tolerance_pct
            results.append(ReconciliationItem(
                check_name="Total Income Equation",
                expected_value=float(calc),
                actual_value=float(d_tot),
                variance=round(var_flt, 2),
                passed=passed,
                formula="Revenue + Other Income == Total Income",
                notes="Verified" if passed else f"Discrepancy of INR {var_flt:.2f} Cr ({pct:.2f}%) between components and reported total income."
            ))

        # 2. PBT Check: Total Income - Total Expenses (+/- Exceptional) == PBT
        if m.total_income is not None and m.total_expenses is not None and m.pbt is not None:
            d_tot = UniversalMetricRegistry.to_decimal(m.total_income) or Decimal("0")
            d_exp = UniversalMetricRegistry.to_decimal(m.total_expenses) or Decimal("0")
            d_exc = UniversalMetricRegistry.to_decimal(m.exceptional_items) or Decimal("0")
            d_pbt = UniversalMetricRegistry.to_decimal(m.pbt) or Decimal("0")
            
            calc = d_tot - d_exp + d_exc
            var = abs(calc - d_pbt)
            var_flt = float(var)
            pct = (var_flt / abs(float(d_pbt)) * 100) if d_pbt != 0 else 0
            passed = var_flt <= self.abs_tolerance_cr or pct <= self.tolerance_pct
            results.append(ReconciliationItem(
                check_name="Profit Before Tax (PBT)",
                expected_value=float(calc),
                actual_value=float(d_pbt),
                variance=round(var_flt, 2),
                passed=passed,
                formula="Total Income - Total Expenses + Exceptional Items == PBT",
                notes="Verified" if passed else f"PBT mismatch of INR {var_flt:.2f} Cr. Check finance costs or share of JV profits."
            ))

        # 3. PAT Check: PBT - Tax Expense == PAT
        if m.pbt is not None and m.tax_expense is not None and m.pat is not None:
            d_pbt = UniversalMetricRegistry.to_decimal(m.pbt) or Decimal("0")
            d_tax = UniversalMetricRegistry.to_decimal(m.tax_expense) or Decimal("0")
            d_pat = UniversalMetricRegistry.to_decimal(m.pat) or Decimal("0")
            
            calc = d_pbt - d_tax
            var = abs(calc - d_pat)
            var_flt = float(var)
            pct = (var_flt / abs(float(d_pat)) * 100) if d_pat != 0 else 0
            passed = var_flt <= self.abs_tolerance_cr or pct <= self.tolerance_pct
            results.append(ReconciliationItem(
                check_name="Net Profit (PAT) Equation",
                expected_value=float(calc),
                actual_value=float(d_pat),
                variance=round(var_flt, 2),
                passed=passed,
                formula="PBT - Tax Expense == PAT",
                notes="Verified" if passed else f"PAT mismatch of INR {var_flt:.2f} Cr. Check for discontinued operations or minority interest."
            ))

        # 4. Operating Profit Check: EBITDA - Depreciation == EBIT
        if m.ebitda is not None and m.depreciation is not None and m.ebit is not None:
            d_ebitda = UniversalMetricRegistry.to_decimal(m.ebitda) or Decimal("0")
            d_dep = UniversalMetricRegistry.to_decimal(m.depreciation) or Decimal("0")
            d_ebit = UniversalMetricRegistry.to_decimal(m.ebit) or Decimal("0")
            
            calc = d_ebitda - d_dep
            var = abs(calc - d_ebit)
            var_flt = float(var)
            passed = var_flt <= self.abs_tolerance_cr
            results.append(ReconciliationItem(
                check_name="EBIT / Operating Profit",
                expected_value=float(calc),
                actual_value=float(d_ebit),
                variance=round(var_flt, 2),
                passed=passed,
                formula="EBITDA - Depreciation == EBIT",
                notes="Verified" if passed else f"Operating profit variance of INR {var_flt:.2f} Cr."
            ))

        # 5. Segment Revenue Check
        if m.segments and m.revenue:
            seg_sum = sum(float(s.get("revenue", 0.0)) for s in m.segments if s.get("revenue") is not None)
            d_seg = UniversalMetricRegistry.to_decimal(seg_sum) or Decimal("0")
            d_rev = UniversalMetricRegistry.to_decimal(m.revenue) or Decimal("0")
            var = abs(d_seg - d_rev)
            var_flt = float(var)
            pct = (var_flt / float(d_rev) * 100) if d_rev > 0 else 0
            passed = var_flt <= (self.abs_tolerance_cr * 5) or pct <= 5.0
            results.append(ReconciliationItem(
                check_name="Segment Revenue Summation",
                expected_value=float(d_rev),
                actual_value=float(d_seg),
                variance=round(var_flt, 2),
                passed=passed,
                formula="Sum(Segment Revenues) == Total Revenue",
                notes="Verified" if passed else f"Segment revenue variance of INR {var_flt:.2f} Cr ({pct:.2f}%). Check unallocated revenue or inter-segment eliminations."
            ))

        return results
