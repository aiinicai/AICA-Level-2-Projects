"""Sector Adapters Registry & Unified Resolution Engine for QuarterIQ v4.2.
Maps Indian listed companies across all 15 specialized sector models.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from typing import Any, Dict, List, Optional, Type

from src.analyzers.sector_adapters.base_adapter import (
    BaseSectorAdapter,
    SectorKPI,
    SectorOperatingModel,
)
from src.analyzers.sector_adapters.adapters_part1 import (
    ITServicesAdapter,
    BankingAdapter,
    NBFCAdapter,
    InsuranceAdapter,
    RealEstateAdapter,
)
from src.analyzers.sector_adapters.adapters_part2 import (
    ManufacturingAdapter,
    MetalsMiningAdapter,
    OilGasAdapter,
    PowerUtilitiesAdapter,
    InfrastructureAdapter,
)
from src.analyzers.sector_adapters.adapters_part3 import (
    DefenceAdapter,
    PharmaAdapter,
    ChemicalsAdapter,
    FMCGAdapter,
    TelecomAdapter,
)
from src.core.indian_fiscal import get_company_sector_profile


SECTOR_ADAPTER_REGISTRY: Dict[str, Type[BaseSectorAdapter]] = {
    # 1. IT & Technology
    "IT_SERVICES": ITServicesAdapter,
    "IT": ITServicesAdapter,
    "TECHNOLOGY": ITServicesAdapter,

    # 2. Banking
    "BANKING": BankingAdapter,
    "BANKS": BankingAdapter,
    "BANK": BankingAdapter,

    # 3. NBFCs
    "NBFCS": NBFCAdapter,
    "NBFC": NBFCAdapter,
    "FINANCIAL_SERVICES": NBFCAdapter,

    # 4. Insurance
    "INSURANCE": InsuranceAdapter,
    "LIFE_INSURANCE": InsuranceAdapter,
    "GENERAL_INSURANCE": InsuranceAdapter,

    # 5. Real Estate
    "REAL_ESTATE": RealEstateAdapter,
    "REALTY": RealEstateAdapter,
    "CONSTRUCTION_REAL_ESTATE": RealEstateAdapter,

    # 6. Manufacturing
    "MANUFACTURING": ManufacturingAdapter,
    "GENERAL": ManufacturingAdapter,
    "CONSUMER_DURABLES": ManufacturingAdapter,
    "AUTOMOBILE": ManufacturingAdapter,
    "AUTO": ManufacturingAdapter,

    # 7. Metals & Mining
    "METALS_MINING": MetalsMiningAdapter,
    "METALS": MetalsMiningAdapter,
    "STEEL": MetalsMiningAdapter,
    "MINING": MetalsMiningAdapter,

    # 8. Oil & Gas
    "OIL_GAS": OilGasAdapter,
    "OIL_AND_GAS": OilGasAdapter,
    "ENERGY_OIL": OilGasAdapter,

    # 9. Power & Utilities
    "POWER_UTILITIES": PowerUtilitiesAdapter,
    "POWER": PowerUtilitiesAdapter,
    "UTILITIES": PowerUtilitiesAdapter,

    # 10. Infrastructure & Capital Goods
    "INFRASTRUCTURE": InfrastructureAdapter,
    "INFRA": InfrastructureAdapter,
    "CAPITAL_GOODS": InfrastructureAdapter,
    "EPC": InfrastructureAdapter,

    # 11. Defence & Aerospace
    "DEFENCE": DefenceAdapter,
    "AEROSPACE": DefenceAdapter,

    # 12. Pharma & Healthcare
    "PHARMA": PharmaAdapter,
    "PHARMACEUTICALS": PharmaAdapter,
    "HEALTHCARE": PharmaAdapter,

    # 13. Chemicals
    "CHEMICALS": ChemicalsAdapter,
    "SPECIALTY_CHEMICALS": ChemicalsAdapter,
    "AGROCHEMICALS": ChemicalsAdapter,

    # 14. FMCG
    "FMCG": FMCGAdapter,
    "CONSUMER_STAPLES": FMCGAdapter,
    "FOOD_BEVERAGE": FMCGAdapter,

    # 15. Telecom
    "TELECOM": TelecomAdapter,
    "TELECOMMUNICATIONS": TelecomAdapter,
    "DIGITAL_INFRA": TelecomAdapter,
}

# Explicit Symbol to Sector Overrides
SYMBOL_SECTOR_MAP: Dict[str, str] = {
    # IT
    "TCS": "IT_SERVICES", "INFY": "IT_SERVICES", "HCLTECH": "IT_SERVICES", "WIPRO": "IT_SERVICES", "TECHM": "IT_SERVICES", "LTIM": "IT_SERVICES", "PERSISTENT": "IT_SERVICES", "COFORGE": "IT_SERVICES", "MPHASIS": "IT_SERVICES",
    # Banks
    "HDFCBANK": "BANKING", "ICICIBANK": "BANKING", "SBIN": "BANKING", "KOTAKBANK": "BANKING", "AXISBANK": "BANKING", "INDUSINDBK": "BANKING", "BANKBARODA": "BANKING", "PNB": "BANKING", "FEDERALBNK": "BANKING",
    # NBFCs
    "BAJFINANCE": "NBFCS", "CHOLAFIN": "NBFCS", "SHRIRAMFIN": "NBFCS", "MUTHOOTFIN": "NBFCS", "M&MFIN": "NBFCS", "SUNDARMFIN": "NBFCS", "POONAWALLA": "NBFCS",
    # Insurance
    "HDFCLIFE": "INSURANCE", "SBILIFE": "INSURANCE", "ICICIPRULI": "INSURANCE", "ICICIGI": "INSURANCE", "STARHEALTH": "INSURANCE", "GICRE": "INSURANCE",
    # Real Estate
    "DLF": "REAL_ESTATE", "LODHA": "REAL_ESTATE", "MACROTECH": "REAL_ESTATE", "GODREJPROP": "REAL_ESTATE", "OBEROIRLTY": "REAL_ESTATE", "PRESTIGE": "REAL_ESTATE", "BRIGADE": "REAL_ESTATE", "SOBHA": "REAL_ESTATE",
    # Manufacturing / Consumer Durables
    "HAVELLS": "MANUFACTURING", "VOLTAS": "MANUFACTURING", "SIEMENS": "MANUFACTURING", "ABB": "MANUFACTURING", "CUMMINSIND": "MANUFACTURING", "POLYCAB": "MANUFACTURING", "DIXON": "MANUFACTURING", "CROMPTON": "MANUFACTURING",
    # Metals & Mining
    "TATASTEEL": "METALS_MINING", "JSWSTEEL": "METALS_MINING", "HINDALCO": "METALS_MINING", "JINDALSTEL": "METALS_MINING", "NMDC": "METALS_MINING", "VEDL": "METALS_MINING", "NATIONALUM": "METALS_MINING",
    # Oil & Gas
    "RELIANCE": "OIL_GAS", "ONGC": "OIL_GAS", "BPCL": "OIL_GAS", "IOC": "OIL_GAS", "GAIL": "OIL_GAS", "GUJGASLTD": "OIL_GAS", "PETRONET": "OIL_GAS", "OIL": "OIL_GAS",
    # Power & Utilities
    "NTPC": "POWER_UTILITIES", "POWERGRID": "POWER_UTILITIES", "TATAPOWER": "POWER_UTILITIES", "ADANIPOWER": "POWER_UTILITIES", "JSWENERGY": "POWER_UTILITIES", "NHPC": "POWER_UTILITIES", "SJVN": "POWER_UTILITIES",
    # Infrastructure & EPC
    "LT": "INFRASTRUCTURE", "BHEL": "INFRASTRUCTURE", "KNRCON": "INFRASTRUCTURE", "PNCINFRA": "INFRASTRUCTURE", "GMRINFRA": "INFRASTRUCTURE", "IRB": "INFRASTRUCTURE", "NCC": "INFRASTRUCTURE",
    # Defence
    "HAL": "DEFENCE", "BEL": "DEFENCE", "BDL": "DEFENCE", "MAZDOCK": "DEFENCE", "COCHINSHIP": "DEFENCE", "SOLARINDS": "DEFENCE", "DATACHEM": "DEFENCE",
    # Pharma
    "SUNPHARMA": "PHARMA", "DRREDDY": "PHARMA", "CIPLA": "PHARMA", "LUPIN": "PHARMA", "TORNTPHARM": "PHARMA", "DIVISLAB": "PHARMA", "ZYDUSLIFE": "PHARMA", "AUROPHARMA": "PHARMA",
    # Chemicals
    "SRF": "CHEMICALS", "PIIND": "CHEMICALS", "NAVINFLUOR": "CHEMICALS", "AARTIIND": "CHEMICALS", "DEEPAKNTR": "CHEMICALS", "ATUL": "CHEMICALS", "FINEORG": "CHEMICALS", "GUJALKALI": "CHEMICALS",
    # FMCG
    "HINDUNILVR": "FMCG", "ITC": "FMCG", "NESTLEIND": "FMCG", "BRITANNIA": "FMCG", "DABUR": "FMCG", "MARICO": "FMCG", "COLPAL": "FMCG", "GODREJCP": "FMCG", "TATACONSUM": "FMCG",
    # Telecom
    "BHARTIARTL": "TELECOM", "IDEA": "TELECOM", "TATACOMM": "TELECOM", "INDUSTOWER": "TELECOM", "TEJASNET": "TELECOM", "HFCL": "TELECOM",
}


def get_adapter_for_company(symbol: str) -> Type[BaseSectorAdapter]:
    """Resolves and returns the appropriate Sector Adapter class for a given symbol."""
    sym = symbol.upper().strip()
    
    # 1. Check explicit symbol override
    if sym in SYMBOL_SECTOR_MAP:
        sector_key = SYMBOL_SECTOR_MAP[sym]
        if sector_key in SECTOR_ADAPTER_REGISTRY:
            return SECTOR_ADAPTER_REGISTRY[sector_key]

    # 2. Check sector profile from indian_fiscal
    profile = get_company_sector_profile(sym)
    sector_type = profile.get("sector_type", "GENERAL").upper()
    if sector_type in SECTOR_ADAPTER_REGISTRY:
        return SECTOR_ADAPTER_REGISTRY[sector_type]

    # Fallback to ManufacturingAdapter as general industry
    return ManufacturingAdapter
