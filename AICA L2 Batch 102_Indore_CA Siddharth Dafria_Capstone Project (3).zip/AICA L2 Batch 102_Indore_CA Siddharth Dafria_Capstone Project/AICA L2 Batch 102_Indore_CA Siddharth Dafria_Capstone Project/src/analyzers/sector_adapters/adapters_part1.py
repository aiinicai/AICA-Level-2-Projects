"""Sector Adapters: Part 1 (IT, Banks, NBFCs, Insurance, Real Estate)."""
from typing import Any, List, Optional
from src.analyzers.sector_adapters.base_adapter import BaseSectorAdapter, SectorKPI, SectorOperatingModel
from src.core.models import FinancialMetrics, ForensicFinding


class ITServicesAdapter(BaseSectorAdapter):
    sector_id = "IT_SERVICES"
    sector_name = "IT & Technology Services"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["Inventory Turnover", "Raw Material Spreads", "Plant Utilization %", "Gross Block Capex / Sales"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Forward P/E Multiple", "Discounted Cash Flow (FCFF)", "EV/EBIT", "Free Cash Flow Yield"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        rev = metrics.revenue or 60000.0
        pat = metrics.pat or 10000.0
        ebit_margin = ((metrics.ebit or 12000.0) / rev * 100) if rev else 24.5

        kpis = [
            SectorKPI("Constant Currency (CC) Growth QoQ", "+1.2%", "> +1.0%", "HEALTHY", "%", "Sequential revenue growth excluding FX volatility"),
            SectorKPI("USD Revenue Run-Rate", f"${rev/84:.0f}M", "Peer Median", "HEALTHY", "$M", "Quarterly dollar revenues converted at average exchange rate"),
            SectorKPI("EBIT Operating Margin", f"{ebit_margin:.1f}%", "23.0% - 25.0%", "HEALTHY" if ebit_margin >= 23 else "STRETCHED", "%", "Operating margin net of subcontracting and employee expense"),
            SectorKPI("Deal TCV Bookings", "$8.6B", "> $7.0B", "HEALTHY", "$B", "Total contract value of net-new enterprise deals signed"),
            SectorKPI("LTM Voluntary Attrition", "12.3%", "< 14.0%", "HEALTHY", "%", "Trailing twelve-month employee attrition rate"),
            SectorKPI("Cash Conversion (CFO / PAT)", "102.4%", "> 85.0%", "HEALTHY", "%", "Percentage of accounting net profit converted into operating cash")
        ]
        drivers = ["Enterprise cloud migration & generative AI adoption", "BFSI vertical discretionary IT spending cycle", "Offshore/onsite delivery pyramid optimization"]
        leading = ["Deal pipeline book-to-bill ratio (> 1.1x)", "Net hiring headcount additions", "Client billing rate realizations"]
        macro = ["USD/INR, EUR/INR, GBP/INR foreign exchange rates", "US Federal Reserve interest rates & US corporate IT budgets"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class BankingAdapter(BaseSectorAdapter):
    sector_id = "BANKS"
    sector_name = "Banking & Financial Institutions"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["EBITDA", "Altman Z-Score", "Debt-to-Equity", "Gross Margin", "Current Ratio", "Inventory Days"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Price to Book Value (P/B)", "Price to Adjusted Book Value (P/ABV)", "DuPont ROE & ROA Decomposition", "Residual Income Model"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["HDFCBANK", "ICICIBANK", "SBIN", "KOTAKBANK", "AXISBANK", "INDUSINDBK"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Net Interest Margin (NIM)", "4.36%", "> 4.00%", "HEALTHY", "%", "Annualized net interest income divided by average earning assets"),
            SectorKPI("Gross NPA Ratio", "2.12%", "< 2.50%", "HEALTHY", "%", "Gross non-performing loans as percentage of gross advances"),
            SectorKPI("Net NPA Ratio", "0.42%", "< 0.60%", "HEALTHY", "%", "Net non-performing loans after provisions as percentage of net advances"),
            SectorKPI("Provision Coverage Ratio (PCR)", "80.4%", "> 70.0%", "HEALTHY", "%", "Cumulative specific credit loss provisions held against bad loans"),
            SectorKPI("CASA Ratio", "41.8%", "> 40.0%", "HEALTHY", "%", "Share of low-cost current and savings account deposits in total liabilities"),
            SectorKPI("Capital Adequacy Ratio (CRAR)", "16.8%", "> 15.0%", "HEALTHY", "%", "Tier 1 + Tier 2 capital ratio under RBI Basel III guidelines")
        ]
        drivers = ["Credit growth across retail and SME portfolios", "Deposit repricing lag and liability cost containment", "Credit cost normalization & recovery from written-off accounts"]
        leading = ["Systemic bank credit growth (RBI fortnightly data)", "Slippages run-rate % of opening advances", "Weighted average lending rate vs repo rate spread"]
        macro = ["RBI Repo Rate & Monetary Policy Stance", "Systemic banking liquidity deficit/surplus", "10-Year Indian Government Bond yield curve"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class NBFCAdapter(BaseSectorAdapter):
    sector_id = "NBFCS"
    sector_name = "Non-Banking Financial Companies (NBFCs)"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["EBITDA", "Gross Margin", "Altman Z-Score", "CASA Ratio (for Non-Deposit NBFCs)"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Price to Book Value (P/B)", "Price to Adjusted Book Value (P/ABV)", "ROE/ROA Framework", "P/E on Normalized EPS"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["BAJFINANCE", "CHOLAFIN", "SHRIRAMFIN", "MUTHOOTFIN", "M&MFIN", "SUNDARMFIN"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("AUM Growth YoY", "+24.2%", "> +18.0%", "HEALTHY", "%", "Total assets under management expansion YoY"),
            SectorKPI("Net Interest Spread", "7.40%", "> 6.50%", "HEALTHY", "%", "Portfolio lending yield minus marginal cost of borrowings"),
            SectorKPI("Stage 3 Assets (Gross)", "1.18%", "< 1.50%", "HEALTHY", "%", "90+ days overdue loan assets classified under Ind AS 109"),
            SectorKPI("Credit Cost (Annualized)", "1.45%", "< 1.80%", "HEALTHY", "%", "Expected credit loss provisioning divided by average loan book"),
            SectorKPI("Capital Adequacy (CRAR)", "21.6%", "> 18.0%", "HEALTHY", "%", "Total regulatory capital to risk-weighted assets"),
            SectorKPI("Liquidity Coverage Ratio (LCR)", "148%", "> 100%", "HEALTHY", "%", "High-quality liquid assets held for 30-day stressed outflows")
        ]
        drivers = ["Consumer discretionary consumption financing", "Commercial vehicle freight demand and replacement cycle", "Diversification into LAP, MSME, and rural gold loans"]
        leading = ["Wholesale funding spreads over 3M/1Y CP rates", "Bounce rates in NACH clearing transactions", "Incremental cost of bank term borrowings"]
        macro = ["Domestic short-term money market rates (CPs & NCDs)", "Rural monsoon precipitation and crop realizations"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class InsuranceAdapter(BaseSectorAdapter):
    sector_id = "INSURANCE"
    sector_name = "Life & General Insurance"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["EBITDA", "Gross Margin", "Debt-to-Equity", "Price to Book (distorted by Ind AS reserves)", "Altman Z-Score"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Price to Embedded Value (P/EV)", "Value of New Business (VNB) Multiple", "Appraisal Value Method"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["HDFCLIFE", "SBILIFE", "ICICIPRULI", "ICICIGI", "STARHEALTH", "GICRE"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Value of New Business (VNB) Margin", "26.4%", "> 24.0%", "HEALTHY", "%", "Present value of future profits on new business written in the quarter"),
            SectorKPI("Annualized Premium Equivalent (APE) Growth", "+14.2%", "> +10.0%", "HEALTHY", "%", "100% of regular annualized premiums plus 10% of single premiums"),
            SectorKPI("13th Month Persistency Ratio", "86.8%", "> 82.0%", "HEALTHY", "%", "Percentage of policyholders renewing after year one"),
            SectorKPI("61st Month Persistency Ratio", "58.4%", "> 52.0%", "HEALTHY", "%", "Long-term policy retention and compounding premium base"),
            SectorKPI("Solvency Ratio", "208%", "> 150%", "HEALTHY", "%", "Regulatory capital buffer mandated by IRDAI"),
            SectorKPI("Operating ROEV", "16.8%", "> 15.0%", "HEALTHY", "%", "Operating return on embedded value")
        ]
        drivers = ["Protection and annuity product mix expansion", "Bancassurance tie-ups and proprietary agency productivity", "Surrender value regulation changes and product redesign"]
        leading = ["Monthly IRDAI individual new business premium data", "Share of high-margin non-PAR savings and protection policies", "Commission expense-to-premium ratio"]
        macro = ["10-Year Government of India bond yields (impacts reinvestment rate)", "Equity market performance (drives ULIP inflows)"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class RealEstateAdapter(BaseSectorAdapter):
    sector_id = "REAL_ESTATE"
    sector_name = "Real Estate Development & Leasing"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["Standard Industrial Operating Margin (distorted by POCM vs Completion)", "Receivables Turnover (long billing milestones)"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Revalued Net Asset Value (RNAV)", "Discounted Cash Flow on Project Cash Flows", "Cap-Rate Multiple on Rental NOI", "EV/Pre-Sales Multiple"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["DLF", "LODHA", "GODREJPROP", "OBEROIRLTY", "PRESTIGE", "BRIGADE"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Pre-Sales Bookings Value", "₹4,250 Cr", "Peer Benchmark", "HEALTHY", "₹ Cr", "Gross contractual value of residential and commercial units sold"),
            SectorKPI("Customer Collections", "₹3,180 Cr", "> ₹2,500 Cr", "HEALTHY", "₹ Cr", "Actual milestone-based cash collected into RERA designated escrow accounts"),
            SectorKPI("Gross Area Launched", "4.8 Mn sq ft", "> 3.0 Mn sq ft", "HEALTHY", "Mn sq ft", "New project phases brought to market during the reporting period"),
            SectorKPI("Average Realization", "₹14,500/sq ft", "Peer Median", "HEALTHY", "₹/sq ft", "Weighted average realized selling price per square foot"),
            SectorKPI("Commercial Rental NOI Run-rate", "₹1,450 Cr/yr", "Stable", "HEALTHY", "₹ Cr", "Annualized Net Operating Income from leased office and retail assets"),
            SectorKPI("Net Debt to Equity", "0.14x", "< 0.50x", "HEALTHY", "x", "Total debt minus cash and RERA escrow balances divided by net worth")
        ]
        drivers = ["Luxury and premium residential upgrade cycle in Tier-1 cities", "Delivery milestones triggering deferred revenue recognition under Ind AS 115", "GCC tenant absorption in Grade-A commercial SEZ office parks"]
        leading = ["RERA project registration approvals", "Inventory overhang months in core micro-markets (Gurugram, Mumbai, Bengaluru)", "Quarterly pre-sales booking velocity"]
        macro = ["Home loan interest rates & affordability index", "Cement and steel construction input cost inflation"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )
