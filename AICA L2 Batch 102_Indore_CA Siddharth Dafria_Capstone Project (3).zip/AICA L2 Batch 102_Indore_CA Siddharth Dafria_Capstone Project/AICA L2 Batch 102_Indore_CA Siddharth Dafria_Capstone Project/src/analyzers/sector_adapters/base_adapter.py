"""Base Sector Adapter Architecture for QuarterIQ v4.2.
Defines the contract for sector-specialized accounting statements, operating KPIs,
forensic anomaly tests, valuation methods, and inapplicable metric exclusions.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from src.core.models import FinancialMetrics, ForensicFinding


@dataclass
class SectorKPI:
    name: str
    value_str: str
    benchmark: str
    assessment: str  # "HEALTHY", "NEUTRAL", "STRETCHED", "CRITICAL"
    unit: str = ""
    description: str = ""


@dataclass
class SectorOperatingModel:
    sector_id: str
    sector_name: str
    reporting_quarter: str
    company_symbol: str
    kpis: List[SectorKPI] = field(default_factory=list)
    earnings_drivers: List[str] = field(default_factory=list)
    leading_indicators: List[str] = field(default_factory=list)
    inapplicable_metrics: List[str] = field(default_factory=list)
    appropriate_valuation_methods: List[str] = field(default_factory=list)
    sector_anomalies: List[ForensicFinding] = field(default_factory=list)
    peer_symbols: List[str] = field(default_factory=list)
    macro_sensitivities: List[str] = field(default_factory=list)


class BaseSectorAdapter(ABC):
    """Abstract base class for all 15 industry sector adapters."""

    sector_id: str = "BASE"
    sector_name: str = "General Industry"

    @classmethod
    @abstractmethod
    def build_operating_model(
        cls,
        symbol: str,
        quarter: str,
        metrics: FinancialMetrics,
        hist_quarters: Optional[List[Any]] = None
    ) -> SectorOperatingModel:
        """Constructs the sector-specialized operating model and KPIs."""
        pass

    @classmethod
    @abstractmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        """Returns financial metrics and ratios that are economically meaningless or
        invalid for this sector (e.g. Altman Z or EBITDA for Banks/Insurance)."""
        pass

    @classmethod
    @abstractmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        """Returns the primary valuation methodologies suitable for this sector."""
        pass

    @classmethod
    @abstractmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        """Returns standard institutional peer group symbols."""
        pass
