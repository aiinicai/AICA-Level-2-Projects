"""Sector Adapters: Part 3 (Defence, Pharma, Chemicals, FMCG, Telecom)."""
from typing import Any, List, Optional
from src.analyzers.sector_adapters.base_adapter import BaseSectorAdapter, SectorKPI, SectorOperatingModel
from src.core.models import FinancialMetrics, ForensicFinding


class DefenceAdapter(BaseSectorAdapter):
    sector_id = "DEFENCE"
    sector_name = "Defence, Aerospace & Strategic Technologies"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Forward P/E", "EV/EBITDA", "DCF on Order Book Execution", "P/Sales"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["HAL", "BEL", "BDL", "MAZDOCK", "COCHINSHIP", "SOLARINDS"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Defence Order Book Multiplier", "4.2x", "> 3.0x", "HEALTHY", "x", "Total firm order book divided by trailing annual revenue"),
            SectorKPI("Indigenization Content Share", "76.4%", "> 65.0%", "HEALTHY", "%", "Percentage of components produced under Make in India / IDDM"),
            SectorKPI("EBITDA Operating Margin", "25.8%", "> 22.0%", "HEALTHY", "%", "Operating margin on defense electronics and manufacturing systems"),
            SectorKPI("Export Revenue Contribution", "11.2%", "> 8.0%", "HEALTHY", "%", "Direct defense equipment exports to friendly foreign nations"),
            SectorKPI("R&D Spend as % of Sales", "7.8%", "> 6.0%", "HEALTHY", "%", "Internal research expenditure on proprietary radar and missile IP"),
            SectorKPI("Cash & Sovereign Receivables", "₹12,400 Cr", "Zero Debt", "HEALTHY", "₹ Cr", "Liquid cash balances plus receivables from MoD / Armed Forces")
        ]
        drivers = ["Defense Acquisition Council (DAC) Acceptance of Necessity (AoN) clearances", "Positive Indigenization Lists (PIL) barring foreign imports", "Platform modernization (Tejas MK1A, Sukhoi upgrades, naval frigates)"]
        leading = ["Union Budget Capital Outlay for Defence Services allocation", "Request for Proposal (RFP) commercial bids opened", "MoD milestone payment release cycles"]
        macro = ["National defense budgetary spending as % of GDP", "Geopolitical tensions and military export agreements"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class PharmaAdapter(BaseSectorAdapter):
    sector_id = "PHARMA"
    sector_name = "Pharmaceuticals & Healthcare"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Forward P/E", "EV/EBITDA", "DCF with Patent Expiry Cliffs", "Sum of the Parts (Domestic + US Generics + API)"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["SUNPHARMA", "DRREDDY", "CIPLA", "LUPIN", "TORNTPHARM", "DIVISLAB"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("US Generics Revenue Run-Rate", "$410M", "Peer Median", "HEALTHY", "$M", "Quarterly sales from US formulations and complex generics"),
            SectorKPI("Domestic Formulations Growth", "+11.4% YoY", "> IPM (+8%)", "HEALTHY", "%", "Growth in Indian domestic branded prescription market"),
            SectorKPI("R&D Expenditure as % of Sales", "6.8%", "6.0% - 8.0%", "HEALTHY", "%", "Investment in biosimilars, injectables, and NCE pipeline"),
            SectorKPI("US FDA Inspection Status", "Zero OAI / EIR Received", "Zero Warning Letters", "HEALTHY", "Status", "Regulatory compliance clearance across manufacturing plants"),
            SectorKPI("Gross Margin on Formulations", "68.4%", "> 65.0%", "HEALTHY", "%", "Realization spread over active pharmaceutical ingredients (API)"),
            SectorKPI("Complex Generics Pipeline", "42 ANDAs Pending", "> 30 Filings", "HEALTHY", "Filings", "Abbreviated New Drug Applications pending US FDA approval")
        ]
        drivers = ["First-to-file (FTF) 180-day generic exclusivity launches", "Domestic chronic therapies (cardiac, anti-diabetes) outperforming acute", "API backward integration reducing reliance on Chinese intermediates"]
        leading = ["Monthly AIOCD-AWACS domestic pharmaceutical market sales data", "US FDA Form 483 inspection observations and CRLs issued", "Price erosion rate in US base generics portfolio"]
        macro = ["US dollar strength (USD/INR realization)", "National List of Essential Medicines (NLEM) price control revisions"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class ChemicalsAdapter(BaseSectorAdapter):
    sector_id = "CHEMICALS"
    sector_name = "Specialty Chemicals & Agro-Intermediates"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA", "Forward P/E", "DCF on Contract Manufacturing (CSM)", "Price to Sales"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["SRF", "PIIND", "NAVINFLUOR", "AARTIIND", "DEEPAKNTR", "ATUL"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("EBITDA Margin on Specialty Molecules", "22.8%", "> 20.0%", "HEALTHY", "%", "Operating margin on patented and proprietary chemistry"),
            SectorKPI("Contract Manufacturing (CSM) Share", "62.4%", "> 50.0%", "HEALTHY", "%", "Long-term take-or-pay custom synthesis volume share"),
            SectorKPI("Export Revenue Contribution", "58.2%", "> 50.0%", "HEALTHY", "%", "Direct exports to global agrochemical and pharmaceutical innovators"),
            SectorKPI("Fluorination / Specialization Capex", "₹1,250 Cr", "On-Track", "HEALTHY", "₹ Cr", "Active capital expenditure on new multipurpose chemical plants"),
            SectorKPI("Gross Margin Spread over Key Feedstock", "46.2%", "> 42.0%", "HEALTHY", "%", "Realization over toluene, benzene, sulphur, and fluorspar"),
            SectorKPI("Inventory Destocking Status", "Normalized", "End of Destocking", "HEALTHY", "Status", "Global channel inventory normalization across customer markets")
        ]
        drivers = ["China+1 diversification and global innovator vendor consolidation", "Commercialization of patented fluorochemical and specialty molecules", "Multi-year take-or-pay CSM contracts with global Tier-1 innovators"]
        leading = ["Global agrochemical channel inventory destocking cycle", "Chinese chemical spot export prices (agrochemical technicals)", "Environmental clearances and timeline on greenfield plant commissioning"]
        macro = ["Feedstock crude derivatives (benzene, toluene, ethylene) prices", "EUR/INR and USD/INR foreign currency realizations"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class FMCGAdapter(BaseSectorAdapter):
    sector_id = "FMCG"
    sector_name = "FMCG, Consumer Goods & Retail"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Forward P/E", "EV/EBITDA", "DCF on Steady-State Brand Cash Flows", "Price to Sales"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["HINDUNILVR", "ITC", "NESTLEIND", "BRITANNIA", "DABUR", "MARICO"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Underlying Volume Growth (UVG)", "+4.8%", "> +4.0%", "HEALTHY", "%", "True consumer unit volume growth excluding price changes"),
            SectorKPI("Gross Margin Expansion", "51.4%", "+180 bps YoY", "HEALTHY", "%", "Gross margin improvement driven by stable palm oil and crude inputs"),
            SectorKPI("A&P Spend as % of Sales", "10.4%", "> 9.0%", "HEALTHY", "%", "Advertising and brand promotion reinvestment rate"),
            SectorKPI("Rural Growth vs Urban Premiumization", "Rural Outpacing", "Balanced", "HEALTHY", "Trend", "Recovery in rural FMCG demand vs quick-commerce urban boom"),
            SectorKPI("EBITDA Operating Margin", "23.6%", "> 22.0%", "HEALTHY", "%", "Core operating profitability net of distribution commissions"),
            SectorKPI("Cash Conversion Cycle", "Negative 24 days", "Negative CCC", "HEALTHY", "days", "Negative working capital model powered by supplier credit")
        ]
        drivers = ["Rural wage recovery and kharif crop cash inflows", "Premiumization in beauty, personal care, and packaged foods", "Quick-commerce (Blinkit, Zepto, Instamart) direct-to-consumer expansion"]
        leading = ["Rural FMCG volume data (Nielsen / Kantar Worldpanel)", "Crude palm oil (CPO), wheat, and packaging polymer cost movements", "General trade wholesale distributor inventory levels"]
        macro = ["Southwest monsoon rainfall distribution across agricultural belts", "Retail consumer price inflation (CPI) and food inflation rates"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class TelecomAdapter(BaseSectorAdapter):
    sector_id = "TELECOM"
    sector_name = "Telecom & Digital Infrastructure"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Gross Margin", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA", "DCF on Operating Cash Flows", "SOTP (Wireless + Enterprise + DTH + Digital)", "ARPU Multiple"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["BHARTIARTL", "IDEA", "TATACOMM", "INDUSTOWER", "TEJASNET"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Average Revenue Per User (ARPU)", "₹238/month", "> ₹220/mo", "HEALTHY", "₹/mo", "Monthly blended revenue per mobile subscriber"),
            SectorKPI("4G/5G Data Usage per Customer", "24.2 GB/month", "+14% YoY", "HEALTHY", "GB/mo", "Average monthly mobile broadband data consumption"),
            SectorKPI("Mobile Subscriber Net Additions", "+3.8 Million", "Positive", "HEALTHY", "Mn Subs", "Net-new active subscriber additions during the quarter"),
            SectorKPI("India Wireless EBITDA Margin", "54.2%", "> 50.0%", "HEALTHY", "%", "Operating EBITDA margin of core domestic mobile network"),
            SectorKPI("Capex to Sales Ratio", "21.4%", "< 25.0%", "HEALTHY", "%", "5G network rollout capital expenditure intensity"),
            SectorKPI("Return on Capital Employed (ROCE)", "11.8%", "> 10.0%", "HEALTHY", "%", "Consolidated ROCE improving post headline tariff hikes")
        ]
        drivers = ["Industry-wide headline mobile tariff hikes", "Prepaid-to-postpaid subscriber upgrades and 2G-to-4G/5G transitions", "Enterprise cloud connectivity and FWA (Fixed Wireless Access) broadband"]
        leading = ["TRAI monthly wireless subscriber market share and VLR data", "5G device penetration among smartphone installed base", "Industry ARPU gap vs global emerging market averages"]
        macro = ["DoT AGR (Adjusted Gross Revenue) statutory dues and spectrum pricing", "Interest rate environment on heavy tower lease and spectrum liabilities"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )
