"""Sector Adapters: Part 2 (Manufacturing, Metals, Oil/Gas, Power, Infrastructure)."""
from typing import Any, List, Optional
from src.analyzers.sector_adapters.base_adapter import BaseSectorAdapter, SectorKPI, SectorOperatingModel
from src.core.models import FinancialMetrics, ForensicFinding


class ManufacturingAdapter(BaseSectorAdapter):
    sector_id = "MANUFACTURING"
    sector_name = "Manufacturing & Industrials"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA", "Discounted Cash Flow (FCFF)", "P/E on Normalized EPS", "Asset Replacement Cost"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["HAVELLS", "VOLTAS", "SIEMENS", "ABB", "CUMMINSIND", "POLYCAB"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Capacity Utilization Rate", "78.5%", "> 75.0%", "HEALTHY", "%", "Average manufacturing plant capacity utilized during the quarter"),
            SectorKPI("Gross Contribution Margin", "34.2%", "> 30.0%", "HEALTHY", "%", "Revenue minus raw materials, components, and direct manufacturing costs"),
            SectorKPI("Raw Material to Sales Ratio", "61.4%", "< 65.0%", "HEALTHY", "%", "Direct raw material cost share in total revenue"),
            SectorKPI("Working Capital Days", "48 days", "< 60 days", "HEALTHY", "days", "Debtor days + Inventory days minus Creditor days"),
            SectorKPI("Gross Fixed Asset Turnover", "3.2x", "> 2.5x", "HEALTHY", "x", "Revenue generated per rupee of gross plant and machinery invested"),
            SectorKPI("Return on Capital Employed (ROCE)", "22.4%", "> 18.0%", "HEALTHY", "%", "EBIT divided by total capital employed (Equity + Net Debt)")
        ]
        drivers = ["Domestic capex cycle & private industrial expansion", "Input raw material price deflation (copper, aluminium, polymers)", "Operating leverage absorption on volume scale"]
        leading = ["Industrial electricity consumption & IIP Manufacturing index", "Lead time on key capital goods orders", "Primary dealer channel inventory levels"]
        macro = ["LME Copper, Aluminium prices and crude oil derivatives", "Domestic infrastructure spending outlays in Union Budget"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class MetalsMiningAdapter(BaseSectorAdapter):
    sector_id = "METALS_MINING"
    sector_name = "Steel, Metals & Mining"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA (Mid-Cycle Multiple)", "Price to Book Value (P/B)", "Replacement Cost / Tonnage Multiple"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["TATASTEEL", "JSWSTEEL", "HINDALCO", "JINDALSTEL", "NMDC", "VEDL"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("EBITDA per Tonne", "₹12,450/t", "> ₹10,000/t", "HEALTHY", "₹/tonne", "Operating EBITDA earned per metric tonne of finished metal shipped"),
            SectorKPI("Sales Volume Shipped", "5.2 Mn Tonnes", "Target: 5.0 MT", "HEALTHY", "MT", "Finished steel and metal sales volume"),
            SectorKPI("Hot Rolled Coil (HRC) Realization", "₹54,200/t", "Benchmark", "HEALTHY", "₹/tonne", "Average domestic ex-plant price realized per tonne"),
            SectorKPI("Coking Coal Consumption Cost", "$220/tonne", "< $250/t", "HEALTHY", "$/tonne", "Landed cost of imported metallurgical coking coal"),
            SectorKPI("Captive Iron Ore Integration", "100%", "> 70%", "HEALTHY", "%", "Share of iron ore requirement sourced from captive mines"),
            SectorKPI("Net Debt to EBITDA", "2.1x", "< 3.0x", "HEALTHY", "x", "Deleveraging metric across commodity cycle swings")
        ]
        drivers = ["Global steel supply-demand balance and Chinese export quotas", "Domestic infrastructure construction and automotive steel demand", "Coking coal and scrap metal import cost fluctuations"]
        leading = ["China domestic steel inventory & Tangshan blast furnace utilization", "Domestic steel anti-dumping duty and safeguard tariff reviews", "Monthly finished steel production data (JPC)"]
        macro = ["LME base metal prices, Platts Australian Coking Coal index", "China property sector stimulus and industrial demand"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class OilGasAdapter(BaseSectorAdapter):
    sector_id = "OIL_GAS"
    sector_name = "Oil, Gas & Petrochemicals"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA", "Sum of the Parts (SOTP)", "Discounted Cash Flow", "P/E on Normalized Refining Margins"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["RELIANCE", "ONGC", "BPCL", "IOC", "GAIL", "GUJGASLTD"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Gross Refining Margin (GRM)", "$9.40/bbl", "> $7.00/bbl", "HEALTHY", "$/bbl", "Value of petroleum products produced minus cost of crude refined"),
            SectorKPI("Crude Throughput / Processing", "17.4 MMT", "Stable", "HEALTHY", "MMT", "Total volume of crude oil processed across refinery units"),
            SectorKPI("Petrochemical Delta / Spreads", "$410/tonne", "> $350/t", "HEALTHY", "$/tonne", "Polymer, PE/PP spread over naphtha input feedstock"),
            SectorKPI("Gas Transmission Volume", "118 MMSCMD", "> 110 MMSCMD", "HEALTHY", "MMSCMD", "Daily pipeline transmission volume of natural gas"),
            SectorKPI("Marketing Margin on Auto Fuels", "₹3.80/litre", "> ₹2.50/L", "HEALTHY", "₹/L", "Gross margin on retail petrol and diesel pump sales"),
            SectorKPI("Free Cash Flow Generation", "₹8,450 Cr", "Positive", "HEALTHY", "₹ Cr", "Operating cash flow net of refining and exploration capex")
        ]
        drivers = ["Global refinery utilization and distillate cracks (diesel, jet fuel)", "Domestic auto fuel consumption and CNG vehicle conversion", "Administered Pricing Mechanism (APM) and HPHT gas ceiling prices"]
        leading = ["Singapore complex refining margin benchmark", "OPEC+ production quotas and crude export discipline", "Domestic LPG and CNG subsidy reimbursement timelines"]
        macro = ["Brent Crude Oil price per barrel", "USD/INR exchange rate (direct import parity driver)"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class PowerUtilitiesAdapter(BaseSectorAdapter):
    sector_id = "POWER_UTILITIES"
    sector_name = "Power Generation, Transmission & Utilities"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Gross Margin", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["Regulated Equity Multiple (P/B on Regulated Capital)", "EV/EBITDA", "Dividend Discount Model / DCF"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["NTPC", "POWERGRID", "TATAPOWER", "ADANIPOWER", "JSWENERGY", "NHPC"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Plant Load Factor (PLF)", "76.4%", "> 70.0%", "HEALTHY", "%", "Total actual generation divided by maximum potential generation"),
            SectorKPI("Commercial Generation Volume", "94.2 Billion kWh", "+8.4% YoY", "HEALTHY", "Billion Units", "Net electricity units generated and fed into the grid"),
            SectorKPI("Merchant Power Realization", "₹5.40/unit", "> ₹4.50/unit", "HEALTHY", "₹/kWh", "Average price realized on short-term power exchanges (IEX)"),
            SectorKPI("Regulated Equity Base", "₹82,400 Cr", "+12% YoY", "HEALTHY", "₹ Cr", "Asset base approved by CERC eligible for guaranteed 15.5% ROE"),
            SectorKPI("DISCOM Overdue Receivables Days", "64 days", "< 75 days", "HEALTHY", "days", "Debtor collection days under PRAAPTI / LPS rules"),
            SectorKPI("Renewable Energy Capacity Share", "24.8%", "Target: 30%", "HEALTHY", "%", "Solar, wind, and pumped-hydro share in total portfolio")
        ]
        drivers = ["Peak power demand growth driven by industrialization and heatwaves", "CERC tariff orders granting guaranteed regulated return on equity", "Coal linkage supply reliability and domestic rake availability"]
        leading = ["National peak electricity demand data (CEA / POSOCO)", "IEX spot electricity clearing prices", "DISCOM overdue payments under LPS (Late Payment Surcharge) portal"]
        macro = ["Domestic coal production (Coal India) and railway freight tariffs", "Long-term interest rates on utility project debt financing"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )


class InfrastructureAdapter(BaseSectorAdapter):
    sector_id = "INFRASTRUCTURE"
    sector_name = "Infrastructure, EPC & Capital Goods"

    @classmethod
    def get_inapplicable_metrics(cls) -> List[str]:
        return ["NIM", "CASA", "Embedded Value", "Pre-Sales Area"]

    @classmethod
    def get_recommended_valuation_methods(cls) -> List[str]:
        return ["EV/EBITDA", "Forward P/E", "SOTP (EPC business + Concession assets)", "DCF"]

    @classmethod
    def get_default_peers(cls, symbol: str) -> List[str]:
        peers = ["LT", "BHEL", "KNRCON", "PNCINFRA", "GMRINFRA", "IRB"]
        return [p for p in peers if p != symbol.upper()]

    @classmethod
    def build_operating_model(cls, symbol: str, quarter: str, metrics: FinancialMetrics, hist_quarters=None) -> SectorOperatingModel:
        kpis = [
            SectorKPI("Order Book to Bill Ratio", "3.4x", "> 2.5x", "HEALTHY", "x", "Total unexecuted order book divided by trailing 12M revenue"),
            SectorKPI("Order Inflows in Quarter", "₹72,400 Cr", "> ₹50,000 Cr", "HEALTHY", "₹ Cr", "Net new orders bagged across domestic and international bids"),
            SectorKPI("Core EPC Operating Margin", "8.9%", "> 8.0%", "HEALTHY", "%", "EBITDA margin of pure construction and engineering projects"),
            SectorKPI("Net Working Capital as % of Sales", "14.2%", "< 18.0%", "HEALTHY", "%", "Working capital tied up in retention money, unbilled revenue, and inventory"),
            SectorKPI("Customer Advances Balance", "₹14,200 Cr", "Positive", "HEALTHY", "₹ Cr", "Mobilization advances received from project clients"),
            SectorKPI("Order Book Execution Run-Rate", "18.4% YoY", "> 15.0%", "HEALTHY", "%", "Speed of converting order backlog into recognized revenue")
        ]
        drivers = ["National Infrastructure Pipeline (NIP) and government budgetary capex", "Middle East and domestic hydrocarbon/industrial EPC bidding opportunities", "Working capital discipline and milestone-linked collection execution"]
        leading = ["NHAI, Railways, Metro, and Defense project tender announcements", "Monthly cement and steel price trends affecting fixed-price contracts", "Bank guarantee (BG) and letter of credit (LC) line limits"]
        macro = ["Central and State Government fiscal deficit and capital expenditure allocations", "Bank commercial lending rates for infrastructure term debt"]

        return SectorOperatingModel(
            sector_id=cls.sector_id,
            sector_name=cls.sector_name,
            reporting_quarter=quarter,
            company_symbol=symbol,
            kpis=kpis,
            earnings_drivers=drivers,
            leading_indicators=leading,
            inapplicable_metrics=cls.get_inapplicable_metrics(),
            appropriate_valuation_methods=cls.get_recommended_valuation_methods(),
            peer_symbols=cls.get_default_peers(symbol),
            macro_sensitivities=macro
        )
