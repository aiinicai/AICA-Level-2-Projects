"""CA-Grade Forensic Intelligence, Statistical Anomaly Detection & Quality of Earnings."""
from typing import Dict, List, Optional, Tuple

from src.core.models import (
    FinancialMetrics,
    FinancialRatios,
    ForensicFinding,
    ForensicScores,
)


class ForensicIntelligenceEngine:
    """Forensic accounting analyzer executing rigorous CA-grade tests on financial disclosures."""

    @staticmethod
    def evaluate_forensics(
        current: FinancialMetrics,
        prior_yoy: Optional[FinancialMetrics] = None,
        ratios: Optional[FinancialRatios] = None,
        total_assets: Optional[float] = None,
        retained_earnings: Optional[float] = None,
        market_cap: Optional[float] = None,
        total_liabilities: Optional[float] = None
    ) -> Tuple[ForensicScores, List[ForensicFinding]]:
        """Runs the complete suite of forensic checks and statistical risk models."""
        scores = ForensicScores()
        findings: List[ForensicFinding] = []

        # -------------------------------------------------------------
        # 1. Revenue vs Receivables Divergence
        # -------------------------------------------------------------
        if (current.revenue and prior_yoy and prior_yoy.revenue and
                current.receivables and prior_yoy.receivables):
            rev_growth = ((current.revenue - prior_yoy.revenue) / prior_yoy.revenue) * 100.0
            rec_growth = ((current.receivables - prior_yoy.receivables) / prior_yoy.receivables) * 100.0
            divergence = round(rec_growth - rev_growth, 2)
            scores.revenue_receivables_divergence = divergence

            if divergence > 15.0:
                findings.append(ForensicFinding(
                    title="Aggressive Revenue Recognition / Channel Stuffing Risk",
                    category="Revenue Quality",
                    severity="RED_FLAG",
                    evidence=f"Receivables grew +{rec_growth:.1f}% YoY while Revenue grew only +{rev_growth:.1f}% YoY (Spread: +{divergence:.1f}%).",
                    source_file=current.source_file or "Financial Results",
                    source_page=current.source_page or "p. 1",
                    materiality="HIGH",
                    financial_exposure_inr_cr=round(current.receivables - prior_yoy.receivables, 2),
                    alternative_explanation="Lengthened credit terms offered to strategic enterprise customers or high proportion of sales booked at quarter-end.",
                    validation_test="Inspect Note on Trade Receivables Ageing and expected credit loss (ECL) provisioning in Annual Report."
                ))
            elif divergence > 5.0:
                findings.append(ForensicFinding(
                    title="Receivables Outpacing Revenue",
                    category="Working Capital",
                    severity="AMBER_WARNING",
                    evidence=f"Receivables growth (+{rec_growth:.1f}%) mildly exceeds sales growth (+{rev_growth:.1f}%).",
                    source_file=current.source_file or "Financial Results",
                    source_page=current.source_page or "p. 1",
                    materiality="MEDIUM",
                    financial_exposure_inr_cr=round(current.receivables - prior_yoy.receivables, 2),
                    alternative_explanation="Normal seasonality in billing cycles.",
                    validation_test="Track cash collections in subsequent quarter."
                ))
            else:
                findings.append(ForensicFinding(
                    title="Healthy Revenue-to-Cash Collection Sync",
                    category="Revenue Quality",
                    severity="POSITIVE_PASS",
                    evidence=f"Receivables growth ({rec_growth:.1f}%) is in line with or lower than sales growth ({rev_growth:.1f}%).",
                    source_file=current.source_file or "Financial Results",
                    source_page=current.source_page or "p. 1",
                    materiality="INFO",
                    alternative_explanation="Consistent credit policies and disciplined cash collection.",
                    validation_test="Routine quarterly monitoring."
                ))

        # -------------------------------------------------------------
        # 2. Inventory vs Sales Divergence
        # -------------------------------------------------------------
        if (current.revenue and prior_yoy and prior_yoy.revenue and
                current.inventory and prior_yoy.inventory):
            sales_growth = ((current.revenue - prior_yoy.revenue) / prior_yoy.revenue) * 100.0
            inv_growth = ((current.inventory - prior_yoy.inventory) / prior_yoy.inventory) * 100.0
            inv_divergence = round(inv_growth - sales_growth, 2)
            scores.inventory_sales_divergence = inv_divergence

            if inv_divergence > 15.0:
                findings.append(ForensicFinding(
                    title="Inventory Accumulation / Potential Obsolescence Drag",
                    category="Inventory Quality",
                    severity="AMBER_WARNING",
                    evidence=f"Inventory increased +{inv_growth:.1f}% YoY versus +{sales_growth:.1f}% sales growth (Divergence: +{inv_divergence:.1f}%).",
                    source_file=current.source_file or "Balance Sheet",
                    source_page=current.source_page or "p. 2",
                    materiality="MEDIUM",
                    financial_exposure_inr_cr=round(current.inventory - prior_yoy.inventory, 2),
                    alternative_explanation="Strategic advance purchase of raw materials ahead of anticipated price hikes or pre-commissioning inventory buildup.",
                    validation_test="Review Days Inventory Outstanding (DIO) trend and write-down disclosures."
                ))

        # -------------------------------------------------------------
        # 3. Quality of Earnings: CFO vs EBITDA & CFO vs PAT
        # -------------------------------------------------------------
        if current.cfo is not None and current.ebitda and current.ebitda > 0:
            cfo_to_ebitda = current.cfo / current.ebitda
            if cfo_to_ebitda < 0.8:
                scores.cfo_ebitda_warning = True
                findings.append(ForensicFinding(
                    title="Poor Operating Cash Conversion (CFO / EBITDA < 0.8x)",
                    category="Cash Flow Realization",
                    severity="RED_FLAG",
                    evidence=f"Operating Cash Flow (INR {current.cfo} Cr) represents only {cfo_to_ebitda:.2f}x of EBITDA (threshold is 0.80x).",
                    source_file=current.source_file or "Cash Flow Statement",
                    source_page=current.source_page or "p. 3",
                    materiality="HIGH",
                    financial_exposure_inr_cr=round(current.ebitda * 0.8 - current.cfo, 2),
                    alternative_explanation="Capital tied up in sudden working capital expansion due to large unbilled contract milestones.",
                    validation_test="Verify whether CFO recovers to EBITDA parity over trailing 12 months."
                ))
            else:
                findings.append(ForensicFinding(
                    title="Robust Operating Cash Conversion",
                    category="Cash Flow Realization",
                    severity="POSITIVE_PASS",
                    evidence=f"CFO / EBITDA of {cfo_to_ebitda:.2f}x indicates high-quality cash realization from reported operational earnings.",
                    source_file=current.source_file or "Cash Flow Statement",
                    source_page=current.source_page or "p. 3",
                    materiality="INFO",
                    alternative_explanation="Efficient working capital turnaround.",
                    validation_test="Confirm sustaining trend."
                ))

        # -------------------------------------------------------------
        # 4. Other Income Dominance
        # -------------------------------------------------------------
        if current.other_income and current.pbt and current.pbt > 0:
            other_inc_pct = (current.other_income / current.pbt) * 100.0
            if other_inc_pct > 20.0:
                scores.other_income_excessive = True
                findings.append(ForensicFinding(
                    title="High Reliance on Non-Operating Other Income",
                    category="Core Earnings Quality",
                    severity="AMBER_WARNING",
                    evidence=f"Other income of INR {current.other_income} Cr constitutes {other_inc_pct:.1f}% of Profit Before Tax (INR {current.pbt} Cr).",
                    source_file=current.source_file or "Profit & Loss",
                    source_page=current.source_page or "p. 1",
                    materiality="HIGH",
                    financial_exposure_inr_cr=round(current.other_income, 2),
                    alternative_explanation="Treasury gains, dividends from subsidiaries, or interest on cash reserves in a high interest-rate environment.",
                    validation_test="Isolate core operational PBT by deducting treasury and foreign-exchange gains."
                ))

        # -------------------------------------------------------------
        # 5. Effective Tax Rate Anomaly
        # -------------------------------------------------------------
        if current.tax_expense is not None and current.pbt and current.pbt > 0:
            etr = (current.tax_expense / current.pbt) * 100.0
            if etr < 15.0:
                scores.tax_rate_anomaly = True
                findings.append(ForensicFinding(
                    title="Subnormal Effective Tax Rate (< 15%)",
                    category="Tax Accounting",
                    severity="AMBER_WARNING",
                    evidence=f"Effective tax rate is {etr:.1f}% vs statutory benchmark of ~25.17% (INR {current.tax_expense} Cr tax on INR {current.pbt} Cr PBT).",
                    source_file=current.source_file or "Profit & Loss",
                    source_page=current.source_page or "p. 1",
                    materiality="MEDIUM",
                    alternative_explanation="Utilization of prior-year tax losses, R&D/SEZ tax holidays, or recognition of deferred tax assets.",
                    validation_test="Examine tax reconciliation note in annual report for permanent vs timing differences."
                ))

        # -------------------------------------------------------------
        # 6. Statistical Models: Beneish M-Score (Manipulation Probability)
        # -------------------------------------------------------------
        # Requires current and prior year data
        if (current.revenue and prior_yoy and prior_yoy.revenue and
                current.receivables and prior_yoy.receivables and
                total_assets and total_assets > 0):
            # DSRI: Days Sales in Receivables Index
            dsri = (current.receivables / current.revenue) / (prior_yoy.receivables / prior_yoy.revenue)
            # SGI: Sales Growth Index
            sgi = current.revenue / prior_yoy.revenue
            # GMI: Gross Margin Index
            gmi = 1.0
            if current.cogs and prior_yoy.cogs:
                gm_curr = (current.revenue - current.cogs) / current.revenue
                gm_prior = (prior_yoy.revenue - prior_yoy.cogs) / prior_yoy.revenue
                if gm_curr > 0:
                    gmi = gm_prior / gm_curr
            # TATA: Total Accruals to Total Assets
            # Accruals = (Net Income - CFO)
            cfo_val = current.cfo if current.cfo is not None else (current.pat or 0.0)
            tata = ((current.pat or 0.0) - cfo_val) / total_assets

            # Beneish 5-variable model approximation
            m_score = -4.84 + (0.920 * dsri) + (0.528 * gmi) + (0.892 * sgi) + (4.037 * tata)
            scores.beneish_m_score = round(m_score, 2)

            if m_score > -1.78:
                scores.beneish_flag = "HIGH_RISK_MANIPULATION"
                findings.append(ForensicFinding(
                    title="Beneish M-Score in Anomaly Zone (> -1.78)",
                    category="Statistical Manipulation Risk",
                    severity="RED_FLAG",
                    evidence=f"Calculated Beneish M-Score is {m_score:.2f} (threshold is -1.78; higher values indicate elevated likelihood of earnings distortion). Inputs: DSRI={dsri:.2f}, SGI={sgi:.2f}, TATA={tata:.3f}.",
                    source_file="Computed Formula",
                    source_page="Automated CA Model",
                    materiality="HIGH",
                    alternative_explanation="High organic growth companies undergoing rapid working-capital expansion frequently register elevated M-Scores without actual accounting fraud.",
                    validation_test="Perform line-item accrual analysis and review auditor tenure."
                ))
            else:
                scores.beneish_flag = "LOW_RISK"
                findings.append(ForensicFinding(
                    title="Beneish M-Score in Safe Zone",
                    category="Statistical Manipulation Risk",
                    severity="POSITIVE_PASS",
                    evidence=f"Beneish M-Score of {m_score:.2f} is comfortably below the -1.78 manipulation threshold.",
                    source_file="Computed Formula",
                    source_page="Automated CA Model",
                    materiality="INFO",
                    alternative_explanation="Accruals and sales indices conform to standard historical distributions.",
                    validation_test="Standard annual recalculation."
                ))
        else:
            scores.beneish_flag = "N/A"

        # -------------------------------------------------------------
        # 7. Altman Z-Score (Financial Distress Probability)
        # -------------------------------------------------------------
        if (total_assets and total_assets > 0 and
                current.revenue and current.ebit is not None and
                total_liabilities and total_liabilities > 0 and
                retained_earnings is not None and market_cap is not None):
            working_cap = (current.receivables or 0) + (current.inventory or 0) - (current.payables or 0)
            x1 = working_cap / total_assets
            x2 = retained_earnings / total_assets
            x3 = (current.ebit * 4.0) / total_assets  # Annualized EBIT
            x4 = market_cap / total_liabilities
            x5 = (current.revenue * 4.0) / total_assets

            z = (1.2 * x1) + (1.4 * x2) + (3.3 * x3) + (0.6 * x4) + (0.999 * x5)
            scores.altman_z_score = round(z, 2)

            if z > 2.99:
                scores.altman_zone = "SAFE"
                findings.append(ForensicFinding(
                    title="Altman Z-Score in Safe Zone (> 2.99)",
                    category="Solvency & Distress",
                    severity="POSITIVE_PASS",
                    evidence=f"Altman Z-Score is {z:.2f}. Solvency and balance-sheet buffer are robust.",
                    source_file="Computed Formula",
                    source_page="Automated CA Model",
                    materiality="INFO",
                    alternative_explanation="Adequate capitalization and operational profitability.",
                    validation_test="Review debt maturity schedule."
                ))
            elif z >= 1.81:
                scores.altman_zone = "GREY_ZONE"
                findings.append(ForensicFinding(
                    title="Altman Z-Score in Grey Zone (1.81 - 2.99)",
                    category="Solvency & Distress",
                    severity="AMBER_WARNING",
                    evidence=f"Altman Z-Score of {z:.2f} places company in the grey zone of financial distress risk.",
                    source_file="Computed Formula",
                    source_page="Automated CA Model",
                    materiality="MEDIUM",
                    alternative_explanation="Moderate leverage or temporary asset turnover dip.",
                    validation_test="Stress-test debt servicing with higher interest rates."
                ))
            else:
                scores.altman_zone = "DISTRESS"
                findings.append(ForensicFinding(
                    title="Altman Z-Score in Distress Zone (< 1.81)",
                    category="Solvency & Distress",
                    severity="RED_FLAG",
                    evidence=f"Altman Z-Score of {z:.2f} indicates elevated balance-sheet distress risk.",
                    source_file="Computed Formula",
                    source_page="Automated CA Model",
                    materiality="HIGH",
                    alternative_explanation="Capital-intensive cyclical downturn.",
                    validation_test="Analyze liquidity lines and debt covenants."
                ))
        else:
            scores.altman_zone = "N/A"

        # -------------------------------------------------------------
        # 8. Piotroski F-Score (0-9 points)
        # -------------------------------------------------------------
        f_score = 0
        checks_available = 0

        if current.pat is not None:
            checks_available += 1
            if current.pat > 0:
                f_score += 1

        if current.cfo is not None:
            checks_available += 1
            if current.cfo > 0:
                f_score += 1

        if current.cfo is not None and current.pat is not None:
            checks_available += 1
            if current.cfo > current.pat:
                f_score += 1

        if (ratios and ratios.gross_margin is not None and
                prior_yoy and prior_yoy.revenue and prior_yoy.cogs):
            prior_gm = ((prior_yoy.revenue - prior_yoy.cogs) / prior_yoy.revenue) * 100.0
            checks_available += 1
            if ratios.gross_margin >= prior_gm:
                f_score += 1

        if (current.gross_debt is not None and prior_yoy and
                prior_yoy.gross_debt is not None):
            checks_available += 1
            if current.gross_debt <= prior_yoy.gross_debt:
                f_score += 1

        if checks_available >= 3:
            # Scale to 9 if partial checks
            scaled_score = int(round((f_score / checks_available) * 9))
            scores.piotroski_f_score = scaled_score
            if scaled_score >= 7:
                scores.piotroski_rating = "STRONG"
            elif scaled_score >= 4:
                scores.piotroski_rating = "MODERATE"
            else:
                scores.piotroski_rating = "WEAK"
        else:
            scores.piotroski_rating = "N/A"

        return scores, findings
