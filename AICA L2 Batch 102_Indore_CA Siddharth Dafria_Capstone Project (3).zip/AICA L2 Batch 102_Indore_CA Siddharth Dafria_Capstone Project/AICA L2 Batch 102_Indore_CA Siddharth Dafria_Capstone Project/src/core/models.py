"""Data models for QuarterIQ research, financials, forensics and reports."""
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class CompanyInfo:
    symbol: str
    name: str
    bse_code: Optional[str] = ""
    sector: Optional[str] = "General Industry"
    isin: Optional[str] = ""
    market_cap_category: Optional[str] = "Large Cap"
    current_market_price: Optional[float] = None
    price_timestamp_ist: Optional[str] = None
    price_source: Optional[str] = "NSE/BSE"


@dataclass
class DocumentRecord:
    category: str
    file_path: str  # relative to workspace root
    file_name: str
    file_size_bytes: int
    sha256: str
    source_origin: str
    source_type: str  # 'direct_download', 'manual_import', 'crawler'
    collected_at: str
    verified: bool = False
    verification_status: str = "UNVERIFIED"  # 'VERIFIED', 'SUSPECT_PERIOD_MISMATCH', 'SUSPECT_ENTITY_MISMATCH', 'UNVERIFIED'
    verification_notes: str = ""
    page_count: Optional[int] = None
    is_consolidated: Optional[bool] = None
    filing_date: Optional[str] = None


@dataclass
class FinancialMetrics:
    period: str  # e.g. 'Q2 FY2026-27'
    basis: str = "Consolidated"  # 'Consolidated' or 'Standalone'
    unit: str = "INR Cr"
    
    # Income Statement
    revenue: Optional[float] = None
    other_income: Optional[float] = None
    total_income: Optional[float] = None
    cogs: Optional[float] = None
    employee_cost: Optional[float] = None
    other_expenses: Optional[float] = None
    total_expenses: Optional[float] = None
    ebitda: Optional[float] = None
    depreciation: Optional[float] = None
    ebit: Optional[float] = None
    finance_costs: Optional[float] = None
    exceptional_items: Optional[float] = None
    pbt: Optional[float] = None
    tax_expense: Optional[float] = None
    current_tax: Optional[float] = None
    deferred_tax: Optional[float] = None
    pat: Optional[float] = None
    diluted_eps: Optional[float] = None
    basic_eps: Optional[float] = None
    
    # Balance Sheet & Cash Flow
    gross_debt: Optional[float] = None
    cash_and_equivalents: Optional[float] = None
    net_debt: Optional[float] = None
    receivables: Optional[float] = None
    inventory: Optional[float] = None
    payables: Optional[float] = None
    cwip: Optional[float] = None
    cfo: Optional[float] = None  # Cash from Operations
    capex: Optional[float] = None
    fcf: Optional[float] = None  # Free Cash Flow
    
    # Metadata & Citations
    source_file: Optional[str] = None
    source_page: Optional[str] = None
    extraction_timestamp: Optional[str] = None
    is_audited: bool = False
    segments: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class FinancialRatios:
    period: str
    revenue_growth_yoy: Optional[float] = None
    revenue_growth_qoq: Optional[float] = None
    ebitda_margin: Optional[float] = None
    pat_margin: Optional[float] = None
    gross_margin: Optional[float] = None
    eps_growth_yoy: Optional[float] = None
    debt_to_ebitda: Optional[float] = None
    interest_coverage: Optional[float] = None
    cfo_to_pat: Optional[float] = None
    cfo_to_ebitda: Optional[float] = None
    fcf_conversion: Optional[float] = None
    dso: Optional[float] = None  # Days Sales Outstanding
    dio: Optional[float] = None  # Days Inventory Outstanding
    dpo: Optional[float] = None  # Days Payable Outstanding
    ccc: Optional[float] = None  # Cash Conversion Cycle
    roce: Optional[float] = None
    roe: Optional[float] = None
    effective_tax_rate: Optional[float] = None


@dataclass
class ForensicScores:
    beneish_m_score: Optional[float] = None
    beneish_flag: Optional[str] = None  # 'LOW_RISK', 'HIGH_RISK_MANIPULATION', 'N/A'
    altman_z_score: Optional[float] = None
    altman_zone: Optional[str] = None   # 'SAFE', 'GREY_ZONE', 'DISTRESS', 'N/A'
    piotroski_f_score: Optional[int] = None  # 0 to 9
    piotroski_rating: Optional[str] = None   # 'STRONG' (7-9), 'MODERATE' (4-6), 'WEAK' (0-3), 'N/A'
    sloan_accrual_ratio: Optional[float] = None
    revenue_receivables_divergence: Optional[float] = None
    inventory_sales_divergence: Optional[float] = None
    cfo_ebitda_warning: bool = False
    other_income_excessive: bool = False
    tax_rate_anomaly: bool = False


@dataclass
class ForensicFinding:
    title: str
    category: str
    severity: str  # 'RED_FLAG', 'AMBER_WARNING', 'WATCH_ITEM', 'POSITIVE_PASS'
    evidence: str
    source_file: str
    source_page: str
    materiality: str
    financial_exposure_inr_cr: Optional[float] = None
    alternative_explanation: str = ""
    validation_test: str = ""
    observation: str = ""

    def __post_init__(self):
        if not self.observation:
            self.observation = self.evidence


@dataclass
class GuidanceItem:
    quarter_promised: str
    guidance_statement: str
    target_period: str
    actual_outcome: str
    status: str  # 'ACHIEVED', 'IN_PROGRESS', 'DELAYED', 'MISSED', 'SHIFTED_GOALPOST'
    evidence_source: str


@dataclass
class InstitutionalScores:
    """Institutional 5-Pillar Scorecard and Analyst Consensus Target."""
    surprise_forecast_score: int       # 0 to 100
    durability_score: int              # 0 to 100
    valuation_score: int               # 0 to 100
    momentum_score: int                # 0 to 100
    composite_institutional_score: int # 0 to 100
    average_analyst_target_price: float # INR
    consensus_upside_pct: float        # %
    consensus_recommendation: str      # 'STRONG BUY', 'BUY', 'ACCUMULATE', 'HOLD', 'REDUCE'
    total_analyst_coverage: int        # number of broker models
    buy_ratings: int
    hold_ratings: int
    sell_ratings: int
    target_high: float = 0.0
    target_low: float = 0.0


@dataclass
class ConcallNLPAnalysis:
    """NLP analysis of earnings concall transcripts and executive management commentary."""
    executive_summary: str
    sentiment_score: int               # 0 to 100 (e.g. 78 = Confident)
    sentiment_label: str               # "CONFIDENT & EXPANSIONARY", "PRUDENT DEFENSE"
    tone_shift_vs_prior: str           # "+4.2 pts improvement from Cautious"
    credibility_index: int             # 0 to 100 (promises delivered)
    headwinds_count: int
    tailwinds_count: int
    headwinds_tailwinds_ratio: str     # e.g. "1 : 2.8"
    top_keywords: List[Dict[str, Any]] # [{'keyword': str, 'count': int, 'sentiment': str}]
    investor_perspective_takeaways: List[str] # Key takeaways for institutional investors
    institutional_qa_highlights: List[Dict[str, str]] # [{'broker': str, 'analyst': str, 'question': str, 'management_response': str, 'evaluation': str}]
    guidance_commitments: List[Dict[str, str]]


@dataclass
class ConsensusPollEstimate:
    """Benchmark estimate from a specific institutional broker or financial media poll."""
    source_name: str                   # 'CNBC Awaaz Poll', 'Reuters / Refinitiv', 'Kotak Equities', 'Motilal Oswal', 'ICICI Direct'
    revenue_est_cr: float
    revenue_variance_pct: float
    revenue_verdict: str               # 'BEAT', 'IN_LINE', 'MISS'
    ebitda_est_cr: float
    ebitda_variance_pct: float
    ebitda_verdict: str
    pat_est_cr: float
    pat_variance_pct: float
    pat_verdict: str
    eps_est_inr: float
    eps_variance_pct: float
    eps_verdict: str
    overall_verdict: str


@dataclass
class ResearchConfig:
    company_symbol: str
    company_name: str
    reporting_quarter: str
    financial_year: str
    accounting_basis: str = "Consolidated"  # 'Consolidated' or 'Standalone'
    research_depth: str = "Institutional"   # 'Basic', 'Advanced', 'Institutional'
    current_market_price: Optional[float] = None
    price_source: str = "NSE"
    peer_symbols: List[str] = field(default_factory=list)
    output_base_dir: str = ""
    is_results_unavailable: bool = False
    unavailability_reason: str = ""
