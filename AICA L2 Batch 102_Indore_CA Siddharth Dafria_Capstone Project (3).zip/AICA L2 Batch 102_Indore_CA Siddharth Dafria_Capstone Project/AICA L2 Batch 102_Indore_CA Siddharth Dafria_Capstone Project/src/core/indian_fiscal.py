"""Indian Fiscal Year logic, currency formatting, and Company Master Directory."""
import re
from datetime import date, datetime
from typing import Dict, List, Optional, Tuple

from src.core.constants import IST


def parse_quarter_str(quarter_str: str) -> Tuple[int, int, int]:
    """Parse string like 'Q2 FY2026-27' or 'Q2 FY27' or 'Q1 2026' into (quarter_num, start_year, end_year).
    Returns (q_num, fy_start_year, fy_end_year).
    Example: 'Q2 FY2026-27' -> (2, 2026, 2027).
    """
    clean = quarter_str.strip().upper()
    m = re.search(r'Q([1-4])\s*(?:FY)?\s*(\d{2,4})(?:-(\d{2,4}))?', clean)
    if not m:
        raise ValueError(f"Invalid quarter format: '{quarter_str}'. Expected format like 'Q2 FY2026-27'.")
    
    q_num = int(m.group(1))
    yr1 = int(m.group(2))
    yr2 = int(m.group(3)) if m.group(3) else None

    # Handle 2-digit years
    if yr1 < 100:
        yr1 += 2000
    if yr2 is not None and yr2 < 100:
        yr2 += 2000

    if yr2 is None:
        # e.g. Q2 FY2027 means FY ending March 2027 -> start 2026, end 2027
        start_year = yr1 - 1
        end_year = yr1
    else:
        start_year = yr1
        end_year = yr2 if yr2 > yr1 else yr1 + 1

    return q_num, start_year, end_year


def get_quarter_date_bounds(quarter_str: str) -> Tuple[date, date]:
    """Returns the (start_date, end_date) for the given Indian fiscal quarter."""
    q_num, start_year, end_year = parse_quarter_str(quarter_str)
    
    if q_num == 1:
        return date(start_year, 4, 1), date(start_year, 6, 30)
    elif q_num == 2:
        return date(start_year, 7, 1), date(start_year, 9, 30)
    elif q_num == 3:
        return date(start_year, 10, 1), date(start_year, 12, 31)
    elif q_num == 4:
        return date(end_year, 1, 1), date(end_year, 3, 31)
    else:
        raise ValueError("Invalid quarter number")


def format_quarter_label(q_num: int, start_year: int, end_year: int) -> str:
    """Standardized format: Q2_Sep_2026 or Q2 FY2026-27."""
    return f"Q{q_num} FY{start_year}-{str(end_year)[-2:]}"


def format_folder_period_name(quarter_str: str) -> Tuple[str, str]:
    """Returns (fy_folder, quarter_folder)
    Example: 'Q2 FY2026-27' -> ('FY2026-27', 'Q2_Sep_2026')
    """
    q_num, start_year, end_year = parse_quarter_str(quarter_str)
    fy_folder = f"FY{start_year}-{str(end_year)[-2:]}"
    
    month_names = {1: "Jun", 2: "Sep", 3: "Dec", 4: "Mar"}
    yr = start_year if q_num in (1, 2, 3) else end_year
    q_folder = f"Q{q_num}_{month_names[q_num]}_{yr}"
    return fy_folder, q_folder


def is_quarter_ended(quarter_str: str, as_of: Optional[date] = None) -> bool:
    """Checks whether the specified quarter's reporting period has completed."""
    if as_of is None:
        as_of = datetime.now(IST).date()
    _, end_date = get_quarter_date_bounds(quarter_str)
    return as_of >= end_date


def get_results_filing_status(quarter_str: str, as_of: Optional[date] = None) -> Dict[str, any]:
    """Determines publication window status under SEBI LODR Regulation 33.
    Unlisted/Listed entities have 45 days for Q1-Q3, 60 days for Q4.
    """
    if as_of is None:
        as_of = datetime.now(IST).date()
    start_date, end_date = get_quarter_date_bounds(quarter_str)
    q_num, _, _ = parse_quarter_str(quarter_str)
    
    deadline_days = 60 if q_num == 4 else 45
    expected_deadline = date.fromordinal(end_date.toordinal() + deadline_days)
    
    ended = as_of >= end_date
    past_deadline = as_of >= expected_deadline
    
    if not ended:
        status = "FUTURE_OR_IN_PROGRESS"
        explanation = f"Reporting period ends on {end_date.strftime('%d-%b-%Y')}. Results cannot be published yet."
    elif past_deadline:
        status = "PUBLICATION_WINDOW_CLOSED"
        explanation = f"Quarter ended {end_date.strftime('%d-%b-%Y')}. SEBI LODR deadline was {expected_deadline.strftime('%d-%b-%Y')}; results should be fully filed."
    else:
        status = "IN_EARNINGS_SEASON"
        explanation = f"Quarter ended {end_date.strftime('%d-%b-%Y')}. Currently within the 45-day filing window (ends {expected_deadline.strftime('%d-%b-%Y')}). Check company board meeting schedule."

    return {
        "quarter": quarter_str,
        "start_date": start_date.strftime("%Y-%m-%d"),
        "end_date": end_date.strftime("%Y-%m-%d"),
        "ended": ended,
        "filing_deadline": expected_deadline.strftime("%Y-%m-%d"),
        "status": status,
        "explanation": explanation
    }


def get_recent_quarters(count: int = 12, as_of: Optional[date] = None) -> List[str]:
    """Returns a list of recent and current quarters formatted as 'Q2 FY2026-27'."""
    if as_of is None:
        as_of = datetime.now(IST).date()
    
    # Determine current quarter
    m = as_of.month
    y = as_of.year
    if 4 <= m <= 6:
        current_q, fy_start = 1, y
    elif 7 <= m <= 9:
        current_q, fy_start = 2, y
    elif 10 <= m <= 12:
        current_q, fy_start = 3, y
    else:
        current_q, fy_start = 4, y - 1

    quarters = []
    q = current_q
    fy = fy_start
    for _ in range(count):
        quarters.append(f"Q{q} FY{fy}-{str(fy + 1)[-2:]}")
        q -= 1
        if q == 0:
            q = 4
            fy -= 1

    return quarters


def format_inr(value: Optional[float], decimals: int = 2, unit: str = "Cr") -> str:
    """Formats a number using the Indian grouping convention (e.g. 1,23,456.78 Cr)."""
    if value is None:
        return "N/A"
    
    is_neg = value < 0
    val = abs(value)
    
    parts = f"{val:.{decimals}f}".split(".")
    integer_part = parts[0]
    decimal_part = f".{parts[1]}" if len(parts) > 1 and decimals > 0 else ""
    
    if len(integer_part) <= 3:
        formatted_int = integer_part
    else:
        last3 = integer_part[-3:]
        remaining = integer_part[:-3]
        groups = []
        while remaining:
            groups.insert(0, remaining[-2:])
            remaining = remaining[:-2]
        formatted_int = ",".join(groups) + "," + last3

    sign = "-" if is_neg else ""
    suffix = f" {unit}" if unit else ""
    return f"{sign}{formatted_int}{decimal_part}{suffix}"


def normalize_to_inr_crore(val_str_or_num: any, reported_unit: str = "crore") -> Optional[float]:
    """Converts a reported figure in Lakhs, Thousands, Millions or Crores to normalized INR Crore."""
    if val_str_or_num is None:
        return None
    if isinstance(val_str_or_num, (int, float)):
        val = float(val_str_or_num)
    else:
        clean = re.sub(r'[^0-9.-]', '', str(val_str_or_num).strip())
        if not clean or clean == '-' or clean == '.':
            return None
        try:
            val = float(clean)
        except ValueError:
            return None

    unit = reported_unit.lower().strip()
    if "lakh" in unit or "lac" in unit:
        return round(val / 100.0, 4)
    elif "million" in unit or "mn" in unit:
        return round(val * 0.1, 4)  # 1 Million = 10 Lakhs = 0.10 Crore
    elif "billion" in unit or "bn" in unit:
        return round(val * 100.0, 4)  # 1 Billion = 100 Crore
    elif "thousand" in unit or "th" in unit:
        return round(val / 10000.0, 4)
    else:
        # Default is already in Crores
        return round(val, 4)


# Comprehensive Curated Listed Company Master for Fast Lookup and Suggestions
COMPANY_MASTER: List[Dict[str, str]] = [
    {"symbol": "RELIANCE", "bse": "500325", "name": "Reliance Industries Limited", "sector": "Oil & Gas / Telecom / Retail"},
    {"symbol": "TCS", "bse": "532540", "name": "Tata Consultancy Services Limited", "sector": "Information Technology"},
    {"symbol": "HDFCBANK", "bse": "500180", "name": "HDFC Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "ICICIBANK", "bse": "532174", "name": "ICICI Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "INFY", "bse": "500209", "name": "Infosys Limited", "sector": "Information Technology"},
    {"symbol": "BHARTIARTL", "bse": "532454", "name": "Bharti Airtel Limited", "sector": "Telecommunications"},
    {"symbol": "SBIN", "bse": "500112", "name": "State Bank of India", "sector": "Public Sector Banking"},
    {"symbol": "ITC", "bse": "500875", "name": "ITC Limited", "sector": "FMCG / Cigarettes / Hotels"},
    {"symbol": "HINDUNILVR", "bse": "500696", "name": "Hindustan Unilever Limited", "sector": "FMCG / Personal Care"},
    {"symbol": "LT", "bse": "500510", "name": "Larsen & Toubro Limited", "sector": "Infrastructure & EPC"},
    {"symbol": "BAJFINANCE", "bse": "500034", "name": "Bajaj Finance Limited", "sector": "NBFC / Lending"},
    {"symbol": "HCLTECH", "bse": "532281", "name": "HCL Technologies Limited", "sector": "Information Technology"},
    {"symbol": "MARUTI", "bse": "532500", "name": "Maruti Suzuki India Limited", "sector": "Automobiles"},
    {"symbol": "SUNPHARMA", "bse": "524715", "name": "Sun Pharmaceutical Industries Limited", "sector": "Pharmaceuticals"},
    {"symbol": "TATAMOTORS", "bse": "500570", "name": "Tata Motors Limited", "sector": "Automobiles"},
    {"symbol": "KOTAKBANK", "bse": "500247", "name": "Kotak Mahindra Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "AXISBANK", "bse": "532215", "name": "Axis Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "NTPC", "bse": "532555", "name": "NTPC Limited", "sector": "Power Generation"},
    {"symbol": "ONGC", "bse": "500312", "name": "Oil and Natural Gas Corporation Limited", "sector": "Oil & Gas Exploration"},
    {"symbol": "POWERGRID", "bse": "532898", "name": "Power Grid Corporation of India Limited", "sector": "Power Transmission"},
    {"symbol": "TITAN", "bse": "500114", "name": "Titan Company Limited", "sector": "Consumer Discretionary / Jewellery"},
    {"symbol": "TATASTEEL", "bse": "500470", "name": "Tata Steel Limited", "sector": "Metals & Mining"},
    {"symbol": "ASIANPAINT", "bse": "500820", "name": "Asian Paints Limited", "sector": "Paints & Chemicals"},
    {"symbol": "ADANIENT", "bse": "512599", "name": "Adani Enterprises Limited", "sector": "Diversified Conglomerate"},
    {"symbol": "ADANIPORTS", "bse": "532921", "name": "Adani Ports and Special Economic Zone Limited", "sector": "Ports & Logistics"},
    {"symbol": "COALINDIA", "bse": "533278", "name": "Coal India Limited", "sector": "Metals & Mining / Coal"},
    {"symbol": "BAJAJFINSV", "bse": "532978", "name": "Bajaj Finserv Limited", "sector": "Financial Services / Insurance"},
    {"symbol": "ULTRACEMCO", "bse": "532538", "name": "UltraTech Cement Limited", "sector": "Cement & Building Materials"},
    {"symbol": "WIPRO", "bse": "507685", "name": "Wipro Limited", "sector": "Information Technology"},
    {"symbol": "JSWSTEEL", "bse": "500228", "name": "JSW Steel Limited", "sector": "Metals & Mining"},
    {"symbol": "M&M", "bse": "500520", "name": "Mahindra & Mahindra Limited", "sector": "Automobiles & Farm Equipment"},
    {"symbol": "NESTLEIND", "bse": "500790", "name": "Nestle India Limited", "sector": "FMCG / Food Products"},
    {"symbol": "GRASIM", "bse": "500300", "name": "Grasim Industries Limited", "sector": "Diversified / Chemicals / Cement"},
    {"symbol": "TECHM", "bse": "532755", "name": "Tech Mahindra Limited", "sector": "Information Technology"},
    {"symbol": "HINDALCO", "bse": "500440", "name": "Hindalco Industries Limited", "sector": "Metals / Aluminium & Copper"},
    {"symbol": "DRREDDY", "bse": "500124", "name": "Dr. Reddy's Laboratories Limited", "sector": "Pharmaceuticals"},
    {"symbol": "CIPLA", "bse": "500087", "name": "Cipla Limited", "sector": "Pharmaceuticals"},
    {"symbol": "LTIM", "bse": "540005", "name": "LTIMindtree Limited", "sector": "Information Technology"},
    {"symbol": "INDUSINDBK", "bse": "532187", "name": "IndusInd Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "DIVISLAB", "bse": "532488", "name": "Divi's Laboratories Limited", "sector": "Pharma / Active Pharmaceutical Ingredients"},
    {"symbol": "EICHERMOT", "bse": "505200", "name": "Eicher Motors Limited", "sector": "Automobiles / Two-Wheelers"},
    {"symbol": "HEROMOTOCO", "bse": "500182", "name": "Hero MotoCorp Limited", "sector": "Automobiles / Two-Wheelers"},
    {"symbol": "BRITANNIA", "bse": "500825", "name": "Britannia Industries Limited", "sector": "FMCG / Biscuits & Dairy"},
    {"symbol": "TATACONSUM", "bse": "500800", "name": "Tata Consumer Products Limited", "sector": "FMCG / Beverages & Foods"},
    {"symbol": "BAJAJ-AUTO", "bse": "532977", "name": "Bajaj Auto Limited", "sector": "Automobiles / Two & Three Wheelers"},
    {"symbol": "APOLLOHOSP", "bse": "508869", "name": "Apollo Hospitals Enterprise Limited", "sector": "Healthcare Services"},
    {"symbol": "BPCL", "bse": "500547", "name": "Bharat Petroleum Corporation Limited", "sector": "Oil Refining & Marketing"},
    {"symbol": "SHRIRAMFIN", "bse": "511218", "name": "Shriram Finance Limited", "sector": "NBFC / Commercial Vehicle Finance"},
    {"symbol": "BEL", "bse": "500049", "name": "Bharat Electronics Limited", "sector": "Aerospace & Defence"},
    {"symbol": "HAL", "bse": "541154", "name": "Hindustan Aeronautics Limited", "sector": "Aerospace & Defence"},
    {"symbol": "ZOMATO", "bse": "543320", "name": "Zomato Limited", "sector": "Internet / Food Delivery / Quick Commerce"},
    {"symbol": "TRENT", "bse": "500251", "name": "Trent Limited", "sector": "Retail / Apparel / Westside / Zudio"},
    {"symbol": "JIOFIN", "bse": "543940", "name": "Jio Financial Services Limited", "sector": "Financial Services / NBFC"},
    {"symbol": "VBL", "bse": "540180", "name": "Varun Beverages Limited", "sector": "FMCG / Bottling"},
    {"symbol": "DLF", "bse": "532868", "name": "DLF Limited", "sector": "Real Estate Development"},
    {"symbol": "PIDILITIND", "bse": "500331", "name": "Pidilite Industries Limited", "sector": "Chemicals / Adhesives (Fevicol)"},
    {"symbol": "POLYCAB", "bse": "542652", "name": "Polycab India Limited", "sector": "Cables & Fast Moving Electrical Goods"},
    {"symbol": "CHOLAFIN", "bse": "511243", "name": "Cholamandalam Investment and Finance Company", "sector": "NBFC / Vehicle Finance"},
    {"symbol": "ABB", "bse": "500002", "name": "ABB India Limited", "sector": "Capital Goods / Industrial Automation"},
    {"symbol": "SIEMENS", "bse": "500550", "name": "Siemens Limited", "sector": "Capital Goods / Electrical Equipment"},
    {"symbol": "HAVELLS", "bse": "517354", "name": "Havells India Limited", "sector": "Electrical Consumer Goods"},
    {"symbol": "INDIGO", "bse": "539448", "name": "InterGlobe Aviation Limited (IndiGo)", "sector": "Aviation / Airlines"},
    {"symbol": "LODHA", "bse": "543287", "name": "Macrotech Developers Limited (Lodha)", "sector": "Real Estate"},
    {"symbol": "GODREJPROP", "bse": "533150", "name": "Godrej Properties Limited", "sector": "Real Estate"},
    {"symbol": "BERGEPAINT", "bse": "509480", "name": "Berger Paints India Limited", "sector": "Paints & Coatings"},
    {"symbol": "TVSMOTOR", "bse": "532343", "name": "TVS Motor Company Limited", "sector": "Automobiles / Two-Wheelers"},
    {"symbol": "PERSISTENT", "bse": "533179", "name": "Persistent Systems Limited", "sector": "Information Technology"},
    {"symbol": "COFORGE", "bse": "532541", "name": "Coforge Limited", "sector": "Information Technology"},
    {"symbol": "FEDERALBNK", "bse": "500469", "name": "The Federal Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "IDFCFIRSTB", "bse": "539437", "name": "IDFC First Bank Limited", "sector": "Banking & Financial Services"},
    {"symbol": "CANBK", "bse": "532483", "name": "Canara Bank", "sector": "Public Sector Banking"},
    {"symbol": "BANKBARODA", "bse": "532134", "name": "Bank of Baroda", "sector": "Public Sector Banking"},
    {"symbol": "PNB", "bse": "532461", "name": "Punjab National Bank", "sector": "Public Sector Banking"},
    {"symbol": "PFC", "bse": "532810", "name": "Power Finance Corporation Limited", "sector": "NBFC / Power Financing"},
    {"symbol": "RECLTD", "bse": "532955", "name": "REC Limited", "sector": "NBFC / Infrastructure & Power"},
    {"symbol": "IRCTC", "bse": "542830", "name": "Indian Railway Catering and Tourism Corp", "sector": "Railways / Travel & Tourism"},
    {"symbol": "IRFC", "bse": "543257", "name": "Indian Railway Finance Corporation", "sector": "NBFC / Railway Financing"},
    {"symbol": "BOSCHLTD", "bse": "500530", "name": "Bosch Limited", "sector": "Auto Ancillary"},
    {"symbol": "MOTHERSON", "bse": "517334", "name": "Samvardhana Motherson International Limited", "sector": "Auto Ancillary"},
    {"symbol": "DIXON", "bse": "540699", "name": "Dixon Technologies (India) Limited", "sector": "Electronics Manufacturing Services"},
    {"symbol": "KAYNES", "bse": "543667", "name": "Kaynes Technology India Limited", "sector": "Electronics Manufacturing Services"},
    {"symbol": "SOLARINDS", "bse": "532725", "name": "Solar Industries India Limited", "sector": "Industrial Explosives & Defence"},
    {"symbol": "ASTRAL", "bse": "532830", "name": "Astral Limited", "sector": "Pipes & Building Materials"},
    {"symbol": "SUPREMEIND", "bse": "509930", "name": "The Supreme Industries Limited", "sector": "Plastics & Pipes"},
    {"symbol": "JUBLFOOD", "bse": "533155", "name": "Jubilant FoodWorks Limited (Domino's)", "sector": "Quick Service Restaurants"},
    {"symbol": "DEVYANI", "bse": "543330", "name": "Devyani International Limited (KFC/Pizza Hut)", "sector": "Quick Service Restaurants"},
    {"symbol": "MAXHEALTH", "bse": "543220", "name": "Max Healthcare Institute Limited", "sector": "Healthcare Services"},
    {"symbol": "FORTIS", "bse": "532848", "name": "Fortis Healthcare Limited", "sector": "Healthcare Services"},
    {"symbol": "LALPATHLAB", "bse": "539524", "name": "Dr. Lal PathLabs Limited", "sector": "Diagnostics"},
    {"symbol": "METROPOLIS", "bse": "542650", "name": "Metropolis Healthcare Limited", "sector": "Diagnostics"},
    {"symbol": "PAGEIND", "bse": "532827", "name": "Page Industries Limited (Jockey)", "sector": "Textiles & Apparel"},
    {"symbol": "MANYAVAR", "bse": "543463", "name": "Vedant Fashions Limited (Manyavar)", "sector": "Apparel / Ethnic Wear"},
    {"symbol": "NYKAA", "bse": "543384", "name": "FSN E-Commerce Ventures Limited (Nykaa)", "sector": "E-Commerce / Beauty & Fashion"},
    {"symbol": "POLICYBZR", "bse": "543390", "name": "PB Fintech Limited (PolicyBazaar)", "sector": "Fintech / Online Insurance"},
    {"symbol": "PAYTM", "bse": "543396", "name": "One 97 Communications Limited (Paytm)", "sector": "Fintech / Payments"},
    {"symbol": "DELHIVERY", "bse": "543529", "name": "Delhivery Limited", "sector": "Logistics & Express Delivery"},
    {"symbol": "SUZLON", "bse": "532667", "name": "Suzlon Energy Limited", "sector": "Renewable Energy / Wind"},
    {"symbol": "TATAPOWER", "bse": "500400", "name": "Tata Power Company Limited", "sector": "Integrated Power & Renewables"},
    {"symbol": "ADANIGREEN", "bse": "541450", "name": "Adani Green Energy Limited", "sector": "Renewable Energy"},
    {"symbol": "ADANIPOWER", "bse": "533096", "name": "Adani Power Limited", "sector": "Thermal Power Generation"},
    {"symbol": "TORNTPOWER", "bse": "532779", "name": "Torrent Power Limited", "sector": "Power Generation & Distribution"},
    {"symbol": "PIIND", "bse": "523642", "name": "PI Industries Limited", "sector": "Agro Chemicals / CSM"},
    {"symbol": "UPL", "bse": "512070", "name": "UPL Limited", "sector": "Agro Chemicals & Crop Protection"},
    {"symbol": "DEEPAKNTR", "bse": "506401", "name": "Deepak Nitrite Limited", "sector": "Specialty Chemicals"},
    {"symbol": "TATACHEM", "bse": "500770", "name": "Tata Chemicals Limited", "sector": "Chemicals / Soda Ash"},
    {"symbol": "SRF", "bse": "503806", "name": "SRF Limited", "sector": "Specialty Chemicals & Technical Textiles"},
    {"symbol": "GUJGASLTD", "bse": "539336", "name": "Gujarat Gas Limited", "sector": "City Gas Distribution"},
    {"symbol": "IGL", "bse": "532514", "name": "Indraprastha Gas Limited", "sector": "City Gas Distribution"},
    {"symbol": "MGL", "bse": "539957", "name": "Mahanagar Gas Limited", "sector": "City Gas Distribution"},
    {"symbol": "CONCOR", "bse": "531349", "name": "Container Corporation of India Limited", "sector": "Logistics / Rail Freight"},
]


def search_companies(query: str, limit: int = 10) -> List[Dict[str, str]]:
    """Searches company master by symbol or name with ranking."""
    q = query.strip().upper()
    if not q:
        return COMPANY_MASTER[:limit]
    
    exact_sym = []
    starts_sym = []
    contains_sym = []
    contains_name = []
    
    for c in COMPANY_MASTER:
        sym = c["symbol"].upper()
        name = c["name"].upper()
        if sym == q:
            exact_sym.append(c)
        elif sym.startswith(q):
            starts_sym.append(c)
        elif q in sym:
            contains_sym.append(c)
        elif q in name:
            contains_name.append(c)
            
    results = exact_sym + starts_sym + contains_sym + contains_name
    return results[:limit]


def resolve_company(symbol_or_name: str) -> Optional[Dict[str, str]]:
    """Resolves an input string to a company record.
    Matches exact symbol first, then tries substring matches.
    """
    clean = symbol_or_name.strip().upper()
    for c in COMPANY_MASTER:
        if c["symbol"].upper() == clean or c["bse"] == clean:
            return c
    for c in COMPANY_MASTER:
        if clean in c["symbol"].upper() or clean in c["name"].upper():
            return c
    # If not in master list, synthesize a valid entry
    return {
        "symbol": re.sub(r'[^A-Z0-9]', '', clean),
        "bse": "",
        "name": symbol_or_name.strip(),
        "sector": "Indian Listed Entity"
    }


def get_company_sector_profile(symbol_or_name: str) -> Dict[str, Any]:
    """Returns an institutional sector profile, leadership directory, relevant peers,
    and appropriate benchmark indices for the target company.
    """
    comp = resolve_company(symbol_or_name)
    sym = comp["symbol"].upper()
    sec_raw = comp.get("sector", "").upper()
    comp_name = comp.get("name", sym)

    # 1. Determine core sector classification
    if any(k in sec_raw or k in sym for k in ["BANK", "FINAN", "NBFC", "LENDING", "CREDIT"]) or sym in ["ICICIBANK", "HDFCBANK", "SBIN", "KOTAKBANK", "AXISBANK", "INDUSINDBK", "BANKBARODA", "CANBK", "PNB", "FEDERALBNK", "IDFCFIRSTB", "BAJFINANCE", "CHOLAFIN", "SHRIRAMFIN"]:
        sector_type = "BANKING"
        benchmark_index = "Nifty Bank (NSE: BANKNIFTY)"
        is_banking = True
    elif any(k in sec_raw or k in sym for k in ["TECHNOLOGY", "IT", "SOFTWARE", "DIGITAL"]) or sym in ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "PERSISTENT", "COFORGE", "MPHASIS"]:
        sector_type = "IT_SERVICES"
        benchmark_index = "Nifty IT (NSE: NIFTYIT)"
        is_banking = False
    elif any(k in sec_raw for k in ["AUTO", "VEHICLE", "MOTOR"]) or sym in ["MARUTI", "TATAMOTORS", "M&M", "BAJAJ-AUTO", "EICHERMOT", "HEROMOTOCO", "TVSMOTOR"]:
        sector_type = "AUTOMOBILE"
        benchmark_index = "Nifty Auto (NSE: NIFTYAUTO)"
        is_banking = False
    elif any(k in sec_raw for k in ["PHARMA", "HEALTH", "DRUG", "HOSPITAL"]) or sym in ["SUNPHARMA", "DRREDDY", "CIPLA", "DIVISLAB", "LUPIN", "APOLLOHOSP", "MAXHEALTH"]:
        sector_type = "PHARMACEUTICALS"
        benchmark_index = "Nifty Pharma (NSE: NIFTYPHARMA)"
        is_banking = False
    elif any(k in sec_raw for k in ["FMCG", "FOOD", "BEVERAGE", "PERSONAL", "CONSUMER"]) or sym in ["HINDUNILVR", "ITC", "NESTLEIND", "BRITANNIA", "TATACONSUM", "VBL", "DABUR", "MARICO"]:
        sector_type = "FMCG"
        benchmark_index = "Nifty FMCG (NSE: NIFTYFMCG)"
        is_banking = False
    elif any(k in sec_raw for k in ["STEEL", "METAL", "MINING", "ALUMINIUM", "COPPER", "COAL"]) or sym in ["TATASTEEL", "JSWSTEEL", "HINDALCO", "COALINDIA", "JINDALSTEL", "VEDL", "NMDC"]:
        sector_type = "METALS"
        benchmark_index = "Nifty Metal (NSE: NIFTYMETAL)"
        is_banking = False
    elif any(k in sec_raw for k in ["OIL", "GAS", "ENERGY", "REFIN"]) or sym in ["RELIANCE", "ONGC", "BPCL", "IOC", "GAIL"]:
        sector_type = "OIL_GAS"
        benchmark_index = "Nifty Oil & Gas (NSE: NIFTYOILGAS)"
        is_banking = False
    elif any(k in sec_raw for k in ["REALTY", "REAL ESTATE", "PROPERTY", "DEVELOPER"]) or sym in ["DLF", "LODHA", "GODREJPROP", "OBEROIRLTY", "PRESTIGE", "BRIGADE", "SOBHA", "MACROTECH"]:
        sector_type = "REAL_ESTATE"
        benchmark_index = "Nifty Realty (NSE: NIFTYREALTY)"
        is_banking = False
    elif any(k in sec_raw for k in ["INFRA", "POWER", "CAPITAL GOODS", "ENGINEERING", "PORT"]) or sym in ["LT", "NTPC", "POWERGRID", "ABB", "SIEMENS", "BHEL", "ADANIPORTS", "ADANIENT"]:
        sector_type = "INFRASTRUCTURE"
        benchmark_index = "Nifty Infrastructure (NSE: NIFTYINFRA)"
        is_banking = False
    else:
        sector_type = "GENERAL"
        benchmark_index = "Nifty 50 (NSE: NIFTY50)"
        is_banking = False

    # 2. Executive Leadership Directory
    leadership_map = {
        "ICICIBANK": {"md_ceo": "Sandeep Bakhshi (Managing Director & CEO)", "cfo": "Anindya Banerjee (Chief Financial Officer)"},
        "HDFCBANK": {"md_ceo": "Sashidhar Jagdishan (Managing Director & CEO)", "cfo": "Srinivasan Vaidyanathan (Chief Financial Officer)"},
        "SBIN": {"md_ceo": "Challa Sreenivasulu Setty (Chairman)", "cfo": "Kameshwar Rao Kodavanti (CFO)"},
        "KOTAKBANK": {"md_ceo": "Ashok Vaswani (Managing Director & CEO)", "cfo": "Devang Gheewalla (President & Group CFO)"},
        "AXISBANK": {"md_ceo": "Amitabh Chaudhry (Managing Director & CEO)", "cfo": "Puneet Sharma (Chief Financial Officer)"},
        "INDUSINDBK": {"md_ceo": "Sumant Kathpalia (Managing Director & CEO)", "cfo": "Gobind Jain (Chief Financial Officer)"},
        "TCS": {"md_ceo": "K. Krithivasan (CEO & Managing Director)", "cfo": "Samir Seksaria (Chief Financial Officer)"},
        "INFY": {"md_ceo": "Salil Parekh (CEO & Managing Director)", "cfo": "Jayesh Sanghrajka (Chief Financial Officer)"},
        "HCLTECH": {"md_ceo": "C Vijayakumar (CEO & Managing Director)", "cfo": "Shiv Walia (Chief Financial Officer)"},
        "WIPRO": {"md_ceo": "Srini Pallia (CEO & Managing Director)", "cfo": "Aparna Iyer (Chief Financial Officer)"},
        "TECHM": {"md_ceo": "Mohit Joshi (Managing Director & CEO)", "cfo": "Rohit Anand (Chief Financial Officer)"},
        "LTIM": {"md_ceo": "Debashis Chatterjee (CEO & Managing Director)", "cfo": "Vipul Chandra (Chief Financial Officer)"},
        "RELIANCE": {"md_ceo": "Mukesh D. Ambani (Chairman & Managing Director)", "cfo": "Srikanth Venkatachari (Chief Financial Officer)"},
        "TATAMOTORS": {"md_ceo": "Shailesh Chandra (Managing Director, TMPV)", "cfo": "P. B. Balaji (Group Chief Financial Officer)"},
        "MARUTI": {"md_ceo": "Hisashi Takeuchi (Managing Director & CEO)", "cfo": "Arnab Roy (Chief Financial Officer)"},
        "M&M": {"md_ceo": "Anish Shah (Managing Director & CEO)", "cfo": "Manoj Bhat (Group Chief Financial Officer)"},
        "SUNPHARMA": {"md_ceo": "Dilip Shanghvi (Managing Director)", "cfo": "C. S. Muralidharan (Chief Financial Officer)"},
        "DRREDDY": {"md_ceo": "Erez Israeli (Chief Executive Officer)", "cfo": "Parag Agarwal (Chief Financial Officer)"},
        "CIPLA": {"md_ceo": "Umang Vohra (Managing Director & Global CEO)", "cfo": "Ashish Adukia (Global Chief Financial Officer)"},
        "HINDUNILVR": {"md_ceo": "Rohit Jawa (CEO & Managing Director)", "cfo": "Ritesh Tiwari (Executive Director, Finance & IT / CFO)"},
        "ITC": {"md_ceo": "Sanjiv Puri (Chairman & Managing Director)", "cfo": "Supratim Dutta (Executive Director & CFO)"},
        "TATASTEEL": {"md_ceo": "T. V. Narendran (CEO & Managing Director)", "cfo": "Koushik Chatterjee (Executive Director & CFO)"},
        "JSWSTEEL": {"md_ceo": "Jayant Acharya (Joint Managing Director & CEO)", "cfo": "Rajeev Pai (Chief Financial Officer)"},
        "LT": {"md_ceo": "S. N. Subrahmanyan (Chairman & Managing Director)", "cfo": "R. Shankar Raman (Whole-time Director & CFO)"},
        "BHARTIARTL": {"md_ceo": "Gopal Vittal (Managing Director & Vice Chairman)", "cfo": "Soumen Ray (Chief Financial Officer)"},
        "DLF": {"md_ceo": "Ashok Kumar Tyagi & Devinder Singh (Managing Directors)", "cfo": "Vivek Anand (Group Chief Financial Officer)"},
        "HAVELLS": {"md_ceo": "Anil Rai Gupta (Chairman & Managing Director)", "cfo": "Rajesh Kumar Gupta (Whole-time Director (Finance) & Group CFO)"},
    }

    leader_info = leadership_map.get(sym, {
        "md_ceo": f"{comp_name} Executive Leadership & Board",
        "cfo": "Chief Financial Officer & Executive Committee"
    })

    # 3. Curated Peer Groups by Sector
    peer_groups = {
        "BANKING": [
            {"symbol": "ICICIBANK", "name": "ICICI Bank Limited", "metric": "₹ 55,992 Cr", "sub_metric": "GNPA: 2.15%", "growth": "+12.8%", "multiple": "2.9x P/B", "roe": "18.2%"},
            {"symbol": "HDFCBANK", "name": "HDFC Bank Limited", "metric": "₹ 85,500 Cr", "sub_metric": "GNPA: 1.33%", "growth": "+14.5%", "multiple": "2.7x P/B", "roe": "16.5%"},
            {"symbol": "SBIN", "name": "State Bank of India", "metric": "₹ 1,12,000 Cr", "sub_metric": "GNPA: 2.21%", "growth": "+11.2%", "multiple": "1.3x P/B", "roe": "16.8%"},
            {"symbol": "KOTAKBANK", "name": "Kotak Mahindra Bank", "metric": "₹ 15,900 Cr", "sub_metric": "GNPA: 1.39%", "growth": "+15.0%", "multiple": "2.5x P/B", "roe": "14.2%"},
            {"symbol": "AXISBANK", "name": "Axis Bank Limited", "metric": "₹ 35,400 Cr", "sub_metric": "GNPA: 1.44%", "growth": "+13.1%", "multiple": "1.9x P/B", "roe": "15.6%"}
        ],
        "IT_SERVICES": [
            {"symbol": "TCS", "name": "Tata Consultancy Services", "metric": "₹ 73,188 Cr", "sub_metric": "OPM: 24.0%", "growth": "+11.2%", "multiple": "29.1x P/E", "roe": "48.5%"},
            {"symbol": "INFY", "name": "Infosys Limited", "metric": "₹ 41,200 Cr", "sub_metric": "OPM: 21.1%", "growth": "+8.5%", "multiple": "27.4x P/E", "roe": "31.2%"},
            {"symbol": "HCLTECH", "name": "HCL Technologies Limited", "metric": "₹ 29,800 Cr", "sub_metric": "OPM: 18.6%", "growth": "+8.0%", "multiple": "26.2x P/E", "roe": "24.5%"},
            {"symbol": "WIPRO", "name": "Wipro Limited", "metric": "₹ 22,500 Cr", "sub_metric": "OPM: 16.4%", "growth": "+1.5%", "multiple": "22.8x P/E", "roe": "16.2%"},
            {"symbol": "LTIM", "name": "LTIMindtree Limited", "metric": "₹ 9,450 Cr", "sub_metric": "OPM: 15.2%", "growth": "+6.8%", "multiple": "28.5x P/E", "roe": "22.4%"}
        ],
        "AUTOMOBILE": [
            {"symbol": "MARUTI", "name": "Maruti Suzuki India Limited", "metric": "₹ 38,200 Cr", "sub_metric": "EBITDA: 11.5%", "growth": "+9.4%", "multiple": "26.8x P/E", "roe": "16.8%"},
            {"symbol": "TATAMOTORS", "name": "Tata Motors Limited", "metric": "₹ 1,08,000 Cr", "sub_metric": "EBITDA: 13.8%", "growth": "+12.1%", "multiple": "14.5x P/E", "roe": "28.4%"},
            {"symbol": "M&M", "name": "Mahindra & Mahindra Limited", "metric": "₹ 37,500 Cr", "sub_metric": "EBITDA: 14.2%", "growth": "+16.8%", "multiple": "28.2x P/E", "roe": "21.5%"},
            {"symbol": "BAJAJ-AUTO", "name": "Bajaj Auto Limited", "metric": "₹ 13,200 Cr", "sub_metric": "EBITDA: 20.1%", "growth": "+21.4%", "multiple": "32.0x P/E", "roe": "29.8%"}
        ],
        "PHARMACEUTICALS": [
            {"symbol": "SUNPHARMA", "name": "Sun Pharma Industries", "metric": "₹ 13,800 Cr", "sub_metric": "EBITDA: 27.5%", "growth": "+10.2%", "multiple": "34.5x P/E", "roe": "17.4%"},
            {"symbol": "DRREDDY", "name": "Dr. Reddy's Laboratories", "metric": "₹ 8,100 Cr", "sub_metric": "EBITDA: 28.2%", "growth": "+11.8%", "multiple": "20.1x P/E", "roe": "21.6%"},
            {"symbol": "CIPLA", "name": "Cipla Limited", "metric": "₹ 7,200 Cr", "sub_metric": "EBITDA: 25.1%", "growth": "+9.0%", "multiple": "26.8x P/E", "roe": "16.8%"},
            {"symbol": "DIVISLAB", "name": "Divi's Laboratories Limited", "metric": "₹ 2,400 Cr", "sub_metric": "EBITDA: 31.5%", "growth": "+18.2%", "multiple": "65.0x P/E", "roe": "13.2%"}
        ],
        "FMCG": [
            {"symbol": "HINDUNILVR", "name": "Hindustan Unilever Limited", "metric": "₹ 16,100 Cr", "sub_metric": "EBITDA: 23.8%", "growth": "+3.5%", "multiple": "52.0x P/E", "roe": "20.1%"},
            {"symbol": "ITC", "name": "ITC Limited", "metric": "₹ 19,800 Cr", "sub_metric": "EBITDA: 36.2%", "growth": "+6.8%", "multiple": "27.5x P/E", "roe": "28.6%"},
            {"symbol": "NESTLEIND", "name": "Nestle India Limited", "metric": "₹ 5,300 Cr", "sub_metric": "EBITDA: 24.5%", "growth": "+7.2%", "multiple": "68.0x P/E", "roe": "95.0%"},
            {"symbol": "BRITANNIA", "name": "Britannia Industries", "metric": "₹ 4,700 Cr", "sub_metric": "EBITDA: 19.5%", "growth": "+5.8%", "multiple": "54.0x P/E", "roe": "44.2%"}
        ],
        "METALS": [
            {"symbol": "TATASTEEL", "name": "Tata Steel Limited", "metric": "₹ 58,200 Cr", "sub_metric": "EBITDA: 11.2%", "growth": "+4.2%", "multiple": "18.0x P/E", "roe": "9.5%"},
            {"symbol": "JSWSTEEL", "name": "JSW Steel Limited", "metric": "₹ 44,500 Cr", "sub_metric": "EBITDA: 14.5%", "growth": "+6.5%", "multiple": "22.5x P/E", "roe": "12.8%"},
            {"symbol": "HINDALCO", "name": "Hindalco Industries Limited", "metric": "₹ 58,000 Cr", "sub_metric": "EBITDA: 13.8%", "growth": "+7.8%", "multiple": "14.2x P/E", "roe": "13.5%"}
        ],
        "OIL_GAS": [
            {"symbol": "RELIANCE", "name": "Reliance Industries Limited", "metric": "₹ 2,42,000 Cr", "sub_metric": "EBITDA: 18.2%", "growth": "+8.5%", "multiple": "26.5x P/E", "roe": "9.8%"},
            {"symbol": "ONGC", "name": "Oil & Natural Gas Corp", "metric": "₹ 1,60,000 Cr", "sub_metric": "EBITDA: 42.0%", "growth": "+5.2%", "multiple": "8.5x P/E", "roe": "14.5%"},
            {"symbol": "BPCL", "name": "Bharat Petroleum Corp", "metric": "₹ 1,22,000 Cr", "sub_metric": "GRM: $6.5/bbl", "growth": "+3.1%", "multiple": "9.2x P/E", "roe": "21.0%"}
        ],
        "REAL_ESTATE": [
            {"symbol": "DLF", "name": "DLF Limited", "metric": "₹ 4,250 Cr", "sub_metric": "Pre-Sales", "growth": "+18.4%", "multiple": "2.4x NAV", "roe": "14.2%"},
            {"symbol": "GODREJPROP", "name": "Godrej Properties Limited", "metric": "₹ 5,100 Cr", "sub_metric": "Pre-Sales", "growth": "+28.1%", "multiple": "2.8x NAV", "roe": "12.5%"},
            {"symbol": "LODHA", "name": "Macrotech Developers (Lodha)", "metric": "₹ 3,900 Cr", "sub_metric": "Pre-Sales", "growth": "+19.0%", "multiple": "2.6x NAV", "roe": "15.0%"},
            {"symbol": "OBEROIRLTY", "name": "Oberoi Realty Limited", "metric": "₹ 1,850 Cr", "sub_metric": "Pre-Sales", "growth": "+22.5%", "multiple": "2.1x NAV", "roe": "18.4%"},
            {"symbol": "PRESTIGE", "name": "Prestige Estates Projects", "metric": "₹ 3,600 Cr", "sub_metric": "Pre-Sales", "growth": "+16.2%", "multiple": "2.2x NAV", "roe": "13.8%"}
        ],
        "INFRASTRUCTURE": [
            {"symbol": "LT", "name": "Larsen & Toubro Limited", "metric": "₹ 62,500 Cr", "sub_metric": "EBITDA: 10.5%", "growth": "+15.2%", "multiple": "32.0x P/E", "roe": "16.2%"},
            {"symbol": "SIEMENS", "name": "Siemens Limited", "metric": "₹ 5,800 Cr", "sub_metric": "EBITDA: 12.8%", "growth": "+18.5%", "multiple": "72.0x P/E", "roe": "18.5%"},
            {"symbol": "ABB", "name": "ABB India Limited", "metric": "₹ 3,200 Cr", "sub_metric": "EBITDA: 14.2%", "growth": "+22.0%", "multiple": "84.0x P/E", "roe": "22.1%"}
        ]
    }

    # Selected peers or fallback
    peers = peer_groups.get(sector_type, [
        {"symbol": sym, "name": comp_name, "metric": "Statutory Reported", "sub_metric": "Consolidated", "growth": "Reported", "multiple": "Sector", "roe": "Reported"}
    ])

    # Ensure the target company is highlighted at top if in peers, or prepended
    target_in_peer = False
    for p in peers:
        if p["symbol"] == sym:
            target_in_peer = True
            break
    if not target_in_peer and peers:
        peers = [{"symbol": sym, "name": comp_name, "metric": "Current Reported", "sub_metric": "Subject Entity", "growth": "Current Q", "multiple": "Market", "roe": "Statutory"}] + peers[:4]

    return {
        "symbol": sym,
        "name": comp_name,
        "sector_name": comp.get("sector", "Indian Listed Entity"),
        "sector_type": sector_type,
        "is_banking": is_banking,
        "benchmark_index": benchmark_index,
        "leadership": leader_info,
        "peers": peers
    }

