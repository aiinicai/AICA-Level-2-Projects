"""QuarterIQ constants and configuration settings."""
from datetime import timedelta, timezone
from pathlib import Path

APP_NAME = "QuarterIQ"
APP_SUBTITLE = "AI-Powered Quarterly Results, Forensic Audit & Institutional Equity Research Platform"
APP_VERSION = "4.2.0"

IST = timezone(timedelta(hours=5, minutes=30))
MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024  # 100 MB safety limit
DEFAULT_TIMEOUT_SEC = 30
MAX_DOWNLOAD_RETRIES = 3

# Required 12 standard research workspace directories
RESEARCH_FOLDERS = {
    "01_Financial_Results": "01_Financial_Results",
    "02_Limited_Review": "02_Limited_Review",
    "03_Previous_Quarters": "03_Previous_Quarters",
    "04_Concall_Transcript": "04_Concall_Transcript",
    "05_Investor_Presentation": "05_Investor_Presentation",
    "06_Annual_Report_Audit": "06_Annual_Report_Audit",
    "07_Analyst_Research": "07_Analyst_Research",
    "08_Industry_Information": "08_Industry_Information",
    "09_Shareholding_Governance": "09_Shareholding_Governance",
    "10_Extracted_Data": "10_Extracted_Data",
    "11_Research_Reports": "11_Research_Reports",
    "12_Audit_Logs": "12_Audit_Logs",
}

# Category name to directory mapping
CATEGORY_DIR_MAP = {
    "Financial Results": "01_Financial_Results",
    "Limited Review Report": "02_Limited_Review",
    "Previous Quarters": "03_Previous_Quarters",
    "Concall Transcript": "04_Concall_Transcript",
    "Investor Presentation": "05_Investor_Presentation",
    "Annual Report / Audit": "06_Annual_Report_Audit",
    "Analyst Research": "07_Analyst_Research",
    "Industry / Macro": "08_Industry_Information",
    "Shareholding & Governance": "09_Shareholding_Governance",
    "Extracted Data": "10_Extracted_Data",
    "Research Reports": "11_Research_Reports",
    "Audit Logs": "12_Audit_Logs",
}

# Mandatory categories for minimum research readiness
MANDATORY_CATEGORIES = [
    "Financial Results",
    "Limited Review Report",
    "Concall Transcript",
    "Investor Presentation",
    "Annual Report / Audit"
]

ACCEPTED_EXTENSIONS = {
    ".pdf", ".xlsx", ".xls", ".csv", ".docx", ".txt", ".pptx", ".html", ".json"
}

# Semantic Color Palette
COLORS_DARK = {
    "bg_primary": "#0b0f19",
    "bg_secondary": "#111827",
    "bg_card": "#151d2b",
    "bg_hover": "#1f293d",
    "border": "#283548",
    "border_light": "#374151",
    "text_primary": "#f8fafc",
    "text_secondary": "#94a3b8",
    "text_muted": "#64748b",
    "emerald": "#10b981",  # Verified positive / beat / safe
    "emerald_bg": "rgba(16, 185, 129, 0.15)",
    "rose": "#f43f5e",     # Red flag / miss / anomaly
    "rose_bg": "rgba(244, 63, 94, 0.15)",
    "amber": "#f59e0b",    # Caution / missing / risk
    "amber_bg": "rgba(245, 158, 11, 0.15)",
    "indigo": "#6366f1",   # Insight / variant perception
    "indigo_bg": "rgba(99, 102, 241, 0.15)",
    "blue": "#3b82f6",     # Navigation / structure
    "cyan": "#06b6d4",
}

COLORS_LIGHT = {
    "bg_primary": "#f8fafc",
    "bg_secondary": "#ffffff",
    "bg_card": "#ffffff",
    "bg_hover": "#f1f5f9",
    "border": "#e2e8f0",
    "border_light": "#cbd5e1",
    "text_primary": "#0f172a",
    "text_secondary": "#475569",
    "text_muted": "#94a3b8",
    "emerald": "#059669",
    "emerald_bg": "rgba(5, 150, 105, 0.1)",
    "rose": "#dc2626",
    "rose_bg": "rgba(220, 38, 38, 0.1)",
    "amber": "#d97706",
    "amber_bg": "rgba(217, 119, 6, 0.1)",
    "indigo": "#4f46e5",
    "indigo_bg": "rgba(79, 70, 229, 0.1)",
    "blue": "#2563eb",
    "cyan": "#0891b2",
}

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 QuarterIQ-Research/2.0"

# Official Trusted Regulatory & Financial Data Sources
TRUSTED_SOURCES = [
    "Screener.in (Financial Database & Official Filings)",
    "Trendlyne.com (Concall Transcripts, Disclosures & Analyst Consensus)",
    "BSE India (bseindia.com - Reg 33 Disclosures)",
    "NSE India (nseindia.com - Exchange Announcements)",
    "SEBI (sebi.gov.in - Regulatory Filings)",
    "Official Corporate Investor Relations Portals"
]
