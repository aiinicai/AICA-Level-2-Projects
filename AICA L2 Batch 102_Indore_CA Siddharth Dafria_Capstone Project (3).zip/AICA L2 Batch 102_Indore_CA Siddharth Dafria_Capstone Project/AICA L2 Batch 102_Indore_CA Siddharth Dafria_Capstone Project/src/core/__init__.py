"""QuarterIQ Core Module."""
