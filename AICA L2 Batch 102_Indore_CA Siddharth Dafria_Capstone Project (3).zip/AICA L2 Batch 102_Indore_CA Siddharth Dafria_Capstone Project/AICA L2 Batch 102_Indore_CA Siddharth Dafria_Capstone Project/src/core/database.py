"""SQLite Database Manager for Multi-Company Research History and Analytics."""
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.core.constants import IST


class DatabaseManager:
    """Thread-safe SQLite manager for QuarterIQ research sessions and metrics."""

    def __init__(self, db_path: Optional[Path] = None):
        if db_path is None:
            # Default to user's AppData or Documents
            app_dir = Path.home() / "Documents" / "QuarterIQ_Research"
            app_dir.mkdir(parents=True, exist_ok=True)
            self.db_path = app_dir / "quarteriq_master.db"
        else:
            self.db_path = Path(db_path)
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Initializes database tables."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Companies
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS companies (
                symbol TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                bse_code TEXT,
                sector TEXT,
                created_at TEXT
            )
            """)

            # Research Sessions
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS research_sessions (
                session_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                company_name TEXT NOT NULL,
                quarter TEXT NOT NULL,
                financial_year TEXT NOT NULL,
                basis TEXT NOT NULL,
                workspace_dir TEXT NOT NULL,
                cmp REAL,
                cmp_timestamp TEXT,
                status TEXT,
                conviction_score INTEGER,
                verdict TEXT,
                created_at TEXT,
                updated_at TEXT,
                FOREIGN KEY (symbol) REFERENCES companies(symbol)
            )
            """)

            # Documents
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                category TEXT NOT NULL,
                file_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                file_size INTEGER,
                source_origin TEXT,
                source_type TEXT,
                verified INTEGER DEFAULT 0,
                verification_status TEXT,
                verification_notes TEXT,
                collected_at TEXT,
                FOREIGN KEY (session_id) REFERENCES research_sessions(session_id)
            )
            """)

            # Financial Metrics
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS financial_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                period TEXT NOT NULL,
                basis TEXT NOT NULL,
                revenue REAL,
                ebitda REAL,
                ebit REAL,
                pbt REAL,
                pat REAL,
                diluted_eps REAL,
                cfo REAL,
                capex REAL,
                fcf REAL,
                gross_debt REAL,
                cash_equivalents REAL,
                receivables REAL,
                inventory REAL,
                payables REAL,
                metrics_json TEXT,
                updated_at TEXT,
                FOREIGN KEY (session_id) REFERENCES research_sessions(session_id)
            )
            """)

            # Forensic Flags
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS forensic_flags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                severity TEXT NOT NULL,
                evidence TEXT,
                source_file TEXT,
                source_page TEXT,
                materiality TEXT,
                exposure_cr REAL,
                created_at TEXT,
                FOREIGN KEY (session_id) REFERENCES research_sessions(session_id)
            )
            """)

            # Guidance Items
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS guidance_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                quarter_promised TEXT NOT NULL,
                guidance_statement TEXT NOT NULL,
                target_period TEXT,
                actual_outcome TEXT,
                status TEXT,
                evidence_source TEXT,
                created_at TEXT
            )
            """)

            # Generated Reports
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS generated_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                report_path TEXT NOT NULL,
                report_type TEXT NOT NULL,
                generated_at TEXT,
                file_size INTEGER,
                FOREIGN KEY (session_id) REFERENCES research_sessions(session_id)
            )
            """)

            conn.commit()

    def record_company(self, symbol: str, name: str, bse: str = "", sector: str = ""):
        with self._get_connection() as conn:
            conn.execute("""
            INSERT INTO companies (symbol, name, bse_code, sector, created_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(symbol) DO UPDATE SET
                name=excluded.name,
                bse_code=excluded.bse_code,
                sector=excluded.sector
            """, (symbol.upper(), name, bse, sector, datetime.now(IST).isoformat()))
            conn.commit()

    def create_or_update_session(self, session_data: Dict[str, Any]) -> str:
        session_id = session_data.get("session_id") or f"{session_data['symbol']}_{session_data['quarter']}"
        now = datetime.now(IST).isoformat()
        with self._get_connection() as conn:
            conn.execute("""
            INSERT INTO research_sessions (
                session_id, symbol, company_name, quarter, financial_year, basis,
                workspace_dir, cmp, cmp_timestamp, status, conviction_score, verdict,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
                cmp=excluded.cmp,
                cmp_timestamp=excluded.cmp_timestamp,
                status=excluded.status,
                conviction_score=excluded.conviction_score,
                verdict=excluded.verdict,
                updated_at=excluded.updated_at
            """, (
                session_id,
                session_data["symbol"].upper(),
                session_data["company_name"],
                session_data["quarter"],
                session_data.get("financial_year", ""),
                session_data.get("basis", "Consolidated"),
                str(session_data["workspace_dir"]),
                session_data.get("cmp"),
                session_data.get("cmp_timestamp"),
                session_data.get("status", "INITIALIZED"),
                session_data.get("conviction_score"),
                session_data.get("verdict", "PENDING_RESEARCH"),
                now,
                now
            ))
            conn.commit()
        return session_id

    def add_document(self, session_id: str, doc_data: Dict[str, Any]):
        with self._get_connection() as conn:
            conn.execute("""
            INSERT INTO documents (
                session_id, category, file_name, file_path, sha256,
                file_size, source_origin, source_type, verified,
                verification_status, verification_notes, collected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session_id,
                doc_data["category"],
                doc_data["file_name"],
                doc_data["file_path"],
                doc_data["sha256"],
                doc_data.get("file_size_bytes", 0),
                doc_data.get("source_origin", ""),
                doc_data.get("source_type", "manual_import"),
                1 if doc_data.get("verified") else 0,
                doc_data.get("verification_status", "UNVERIFIED"),
                doc_data.get("verification_notes", ""),
                doc_data.get("collected_at", datetime.now(IST).isoformat())
            ))
            conn.commit()

    def get_recent_sessions(self, limit: int = 15) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            SELECT * FROM research_sessions
            ORDER BY updated_at DESC LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_session_documents(self, session_id: str) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            SELECT * FROM documents WHERE session_id = ? ORDER BY id DESC
            """, (session_id,))
            return [dict(row) for row in cursor.fetchall()]
