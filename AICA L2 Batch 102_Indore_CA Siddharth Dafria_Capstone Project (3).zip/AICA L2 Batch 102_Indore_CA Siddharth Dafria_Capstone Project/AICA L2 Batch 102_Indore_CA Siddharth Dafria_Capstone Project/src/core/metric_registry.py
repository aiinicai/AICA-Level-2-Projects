"""Universal Financial Metric Registry & Definition Dictionary.
Enforces deterministic financial calculations, standard accounting definitions,
fixed-precision decimal operations, and classification controls across Indian listed entities.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple


class StatementType(str, Enum):
    INCOME_STATEMENT = "INCOME_STATEMENT"
    BALANCE_SHEET = "BALANCE_SHEET"
    CASH_FLOW = "CASH_FLOW"
    OPERATING_KPIS = "OPERATING_KPIS"
    FORENSIC_RATIOS = "FORENSIC_RATIOS"
    VALUATION = "VALUATION"


class ConsolidationBasis(str, Enum):
    CONSOLIDATED = "Consolidated"
    STANDALONE = "Standalone"
    EITHER = "Either"


@dataclass
class MetricDefinition:
    canonical_id: str
    standard_label: str
    statement_type: StatementType
    accounting_standard: str = "Ind AS"
    definition: str = ""
    is_derived: bool = False
    formula_description: str = ""
    unit: str = "INR Cr"
    is_non_recurring: bool = False
    is_gaap: bool = True
    consolidation_default: ConsolidationBasis = ConsolidationBasis.CONSOLIDATED
    validation_rule: Optional[str] = None


class UniversalMetricRegistry:
    """Central governing dictionary for financial metrics, reconciliation equations,
    and precision math."""

    _REGISTRY: Dict[str, MetricDefinition] = {}

    @classmethod
    def register(cls, definition: MetricDefinition) -> None:
        cls._REGISTRY[definition.canonical_id] = definition

    @classmethod
    def get(cls, canonical_id: str) -> Optional[MetricDefinition]:
        return cls._REGISTRY.get(canonical_id)

    @classmethod
    def list_all(cls) -> List[MetricDefinition]:
        return list(cls._REGISTRY.values())

    @staticmethod
    def to_decimal(val: Any) -> Optional[Decimal]:
        """Converts float/int/str safely to Decimal with fixed precision."""
        if val is None:
            return None
        try:
            # Strip formatting commas, spaces
            s = str(val).replace(",", "").strip()
            if not s or s.lower() in ("nan", "none", "n/a", "-"):
                return None
            return Decimal(s)
        except Exception:
            return None

    @staticmethod
    def round_cr(val: Optional[Decimal], decimals: int = 2) -> Optional[float]:
        """Rounds decimal safely for reporting."""
        if val is None:
            return None
        quant = Decimal("10") ** -decimals
        return float(val.quantize(quant, rounding=ROUND_HALF_UP))

    @classmethod
    def reconcile_pbt(
        cls,
        ebit: Optional[float],
        finance_costs: Optional[float],
        other_income: Optional[float],
        exceptional_items: Optional[float],
        reported_pbt: Optional[float],
        tolerance_pct: float = 1.0
    ) -> Tuple[bool, Optional[float], float, str]:
        """Strict Ind AS reconciliation:
        Calculated PBT = EBIT - Finance Costs + Other Income + Exceptional Items
        (or Operating Profit + Other Income - Finance Costs - Exceptional Expenses)
        Returns: (is_passed, calculated_pbt, variance_cr, notes)
        """
        d_ebit = cls.to_decimal(ebit)
        d_fin = cls.to_decimal(finance_costs) or Decimal("0.0")
        d_oi = cls.to_decimal(other_income) or Decimal("0.0")
        d_exc = cls.to_decimal(exceptional_items) or Decimal("0.0")
        d_pbt = cls.to_decimal(reported_pbt)

        if d_ebit is None or d_pbt is None:
            return False, None, 0.0, "Missing EBIT or reported PBT data for reconciliation"

        calc_pbt = d_ebit - d_fin + d_exc
        diff = abs(calc_pbt - d_pbt)
        var_cr = float(diff)

        # Allow percentage tolerance or 2.0 Cr rounding tolerance
        base = max(abs(float(d_pbt)), 1.0)
        pct_diff = (var_cr / base) * 100.0

        passed = pct_diff <= tolerance_pct or var_cr <= 2.0
        note = f"Calculated PBT: ₹{calc_pbt:.2f} Cr vs Reported: ₹{d_pbt:.2f} Cr (Diff: ₹{var_cr:.2f} Cr, {pct_diff:.2f}%)"
        return passed, float(calc_pbt), var_cr, note

    @classmethod
    def reconcile_pat(
        cls,
        pbt: Optional[float],
        tax_expense: Optional[float],
        reported_pat: Optional[float],
        tolerance_pct: float = 1.0
    ) -> Tuple[bool, Optional[float], float, str]:
        """Calculated PAT = PBT - Tax Expense.
        Returns: (is_passed, calculated_pat, variance_cr, notes)
        """
        d_pbt = cls.to_decimal(pbt)
        d_tax = cls.to_decimal(tax_expense)
        d_pat = cls.to_decimal(reported_pat)

        if d_pbt is None or d_tax is None or d_pat is None:
            return False, None, 0.0, "Missing PBT, Tax, or reported PAT"

        calc_pat = d_pbt - d_tax
        diff = abs(calc_pat - d_pat)
        var_cr = float(diff)

        base = max(abs(float(d_pat)), 1.0)
        pct_diff = (var_cr / base) * 100.0

        passed = pct_diff <= tolerance_pct or var_cr <= 2.0
        note = f"Calculated PAT: ₹{calc_pat:.2f} Cr vs Reported: ₹{d_pat:.2f} Cr (Diff: ₹{var_cr:.2f} Cr, {pct_diff:.2f}%)"
        return passed, float(calc_pat), var_cr, note

    @classmethod
    def normalize_adjusted_ebitda(
        cls,
        reported_ebitda: Optional[float],
        other_income: Optional[float],
        exceptional_items: Optional[float]
    ) -> Tuple[float, str]:
        """Computes true Operational EBITDA by removing non-operating other income
        and exceptional items. Never mixes non-operating items into core operations.
        """
        d_ebitda = cls.to_decimal(reported_ebitda) or Decimal("0.0")
        d_oi = cls.to_decimal(other_income) or Decimal("0.0")
        d_exc = cls.to_decimal(exceptional_items) or Decimal("0.0")

        # Operational EBITDA excludes other non-operating income and non-recurring exceptionals
        # Note: If reported_ebitda already includes other income, deduct it
        op_ebitda = d_ebitda - d_exc
        note = "Adjusted for exceptional items and non-operational income"
        return float(op_ebitda), note


# Initialize Canonical Metric Definitions
def _init_canonical_metrics():
    # Income Statement
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="REV_OPS",
        standard_label="Revenue from Operations",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Revenue generated from the sale of goods and rendering of primary business services, net of GST and trade discounts.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="OTHER_INC",
        standard_label="Other Income",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Non-operating income including interest, dividend, gain on sale of investments, and net foreign exchange gain.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="TOTAL_INC",
        standard_label="Total Income",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Sum of Revenue from Operations and Other Income.",
        is_derived=True,
        formula_description="REV_OPS + OTHER_INC",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="OP_EXP",
        standard_label="Total Operating Expenses",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Sum of cost of raw materials, employee benefit expenses, and other operating expenses.",
        is_derived=True,
        formula_description="COGS + EMPLOYEE_COST + OTHER_EXP",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="EBITDA_REP",
        standard_label="Reported EBITDA",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Earnings before interest, taxes, depreciation and amortization as reported by the entity.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="EBITDA_ADJ",
        standard_label="Operating EBITDA (Adjusted)",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Operational earnings strictly from core operations, excluding non-operating other income and exceptional items.",
        is_derived=True,
        formula_description="EBITDA_REP - EXCEPTIONAL_ITEMS",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="EBIT",
        standard_label="Operating Profit (EBIT)",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Earnings Before Interest and Taxes; core operating earnings after depreciation.",
        is_derived=True,
        formula_description="EBITDA - DEPRECIATION",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="FIN_COST",
        standard_label="Finance Costs",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Interest expense on term loans, working capital borrowings, and lease liabilities under Ind AS 116.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="EXCEPTIONAL",
        standard_label="Exceptional Items",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Income or expenses that arise from events or transactions that are clearly distinct from ordinary activities.",
        is_derived=False,
        is_non_recurring=True,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="PBT",
        standard_label="Profit Before Tax (PBT)",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Profit before deducting current and deferred tax expenses.",
        is_derived=True,
        formula_description="EBIT - FIN_COST + EXCEPTIONAL",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="TAX_EXP",
        standard_label="Tax Expense",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Total current tax plus deferred tax charge or credit.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="PAT",
        standard_label="Profit After Tax (PAT)",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Net profit after tax attributable to equity shareholders of the parent entity.",
        is_derived=True,
        formula_description="PBT - TAX_EXP",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="EPS_DILUTED",
        standard_label="Diluted EPS",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Earnings per share adjusted for potential dilution from stock options, warrants, and convertible debt.",
        is_derived=False,
        unit="INR"
    ))

    # Cash Flow & Balance Sheet
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="CFO",
        standard_label="Cash Flow from Operations (CFO)",
        statement_type=StatementType.CASH_FLOW,
        definition="Net cash generated from operating activities after working capital adjustments and taxes paid.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="CAPEX",
        standard_label="Capital Expenditure",
        statement_type=StatementType.CASH_FLOW,
        definition="Cash outflow for purchase of property, plant, equipment, and intangible assets.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="FCF",
        standard_label="Free Cash Flow to Firm (FCF)",
        statement_type=StatementType.CASH_FLOW,
        definition="Operating cash flow remaining after capital expenditures.",
        is_derived=True,
        formula_description="CFO - CAPEX",
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="NET_DEBT",
        standard_label="Net Debt",
        statement_type=StatementType.BALANCE_SHEET,
        definition="Total gross borrowings (short-term + long-term + lease liabilities) minus unrestricted cash and liquid investments.",
        is_derived=True,
        formula_description="GROSS_DEBT - CASH_EQUIVALENTS",
        unit="INR Cr"
    ))

    # Banking & NBFC Specific
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="NII",
        standard_label="Net Interest Income",
        statement_type=StatementType.INCOME_STATEMENT,
        definition="Interest earned on advances and investments minus interest expended on deposits and borrowings.",
        is_derived=True,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="NIM",
        standard_label="Net Interest Margin",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Net interest income expressed as an annualized percentage of average interest-earning assets.",
        is_derived=False,
        unit="%"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="GNPA_PCT",
        standard_label="Gross NPA Ratio",
        statement_type=StatementType.FORENSIC_RATIOS,
        definition="Gross non-performing advances as a percentage of gross total advances.",
        is_derived=False,
        unit="%"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="NNPA_PCT",
        standard_label="Net NPA Ratio",
        statement_type=StatementType.FORENSIC_RATIOS,
        definition="Net non-performing advances after deducting provisions as a percentage of net total advances.",
        is_derived=False,
        unit="%"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="PCR_PCT",
        standard_label="Provision Coverage Ratio",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Total cumulative provisions held against gross NPAs as a percentage of gross NPAs.",
        is_derived=False,
        unit="%"
    ))

    # Real Estate Specific
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="PRE_SALES",
        standard_label="Pre-Sales Bookings",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Total gross sales value of residential and commercial units booked during the period.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="COLLECTIONS",
        standard_label="Customer Collections",
        statement_type=StatementType.CASH_FLOW,
        definition="Actual cash collected from customers against pre-sales milestones during the period.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="COMPLETION_WIP",
        standard_label="Construction Work-in-Progress",
        statement_type=StatementType.BALANCE_SHEET,
        definition="Carrying value of ongoing real estate projects under development.",
        is_derived=False,
        unit="INR Cr"
    ))

    # Order Book, Contract Margins & Variant Perception
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="ORDER_BOOK_TOTAL",
        standard_label="Total Order Book / Backlog",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Cumulative unexecuted contract value or firm customer commitments.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="ORDER_INFLOW_QTR",
        standard_label="Quarterly Order Inflow / Bookings",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Net-new contract bookings, deal TCV, or purchase orders booked during the reporting quarter.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="BOOK_TO_BILL",
        standard_label="Book-to-Bill Ratio",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Ratio of quarterly order intake to recognized revenue; >1.0x indicates expanding future backlog.",
        is_derived=True,
        formula_description="ORDER_INFLOW_QTR / REV_OPS",
        unit="x"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="ORDER_BOOK_MARGIN",
        standard_label="Expected Order Book Operating Margin",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Weighted average projected operating / EBITDA margin across unexecuted backlog orders.",
        is_derived=False,
        unit="%"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="ORDER_MARGIN_DELTA_BPS",
        standard_label="Order Book Margin Spread",
        statement_type=StatementType.OPERATING_KPIS,
        definition="Spread between expected order book margin and trailing blended margin in basis points.",
        is_derived=True,
        formula_description="(ORDER_BOOK_MARGIN - BLENDED_MARGIN) * 100",
        unit="bps"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="UNBILLED_REVENUE",
        standard_label="Unbilled Revenue (Contract Assets)",
        statement_type=StatementType.BALANCE_SHEET,
        definition="Contract assets under Ind AS 115 representing performance obligations satisfied but not yet invoiced.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="CUSTOMER_ADVANCES",
        standard_label="Customer Advances (Contract Liabilities)",
        statement_type=StatementType.BALANCE_SHEET,
        definition="Contract liabilities under Ind AS 115 representing mobilization advances and deposits received.",
        is_derived=False,
        unit="INR Cr"
    ))
    UniversalMetricRegistry.register(MetricDefinition(
        canonical_id="VARIANT_FAIR_VALUE",
        standard_label="Forensically Adjusted Fair Value",
        statement_type=StatementType.VALUATION,
        definition="Intrinsic fair value per share reflecting unpriced order conversion and backlog margin spreads.",
        is_derived=True,
        formula_description="RECONCILED_FWD_EPS * FAIR_MULTIPLE",
        unit="INR"
    ))

_init_canonical_metrics()
