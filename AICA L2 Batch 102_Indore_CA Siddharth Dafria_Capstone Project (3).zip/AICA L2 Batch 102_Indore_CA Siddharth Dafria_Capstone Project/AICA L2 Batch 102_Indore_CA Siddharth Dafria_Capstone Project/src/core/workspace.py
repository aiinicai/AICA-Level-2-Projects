"""Research Workspace Directory, Manifest, and Evidence Management."""
import csv
import hashlib
import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.core.constants import (
    ACCEPTED_EXTENSIONS,
    CATEGORY_DIR_MAP,
    IST,
    MANDATORY_CATEGORIES,
    RESEARCH_FOLDERS,
)
from src.core.indian_fiscal import format_folder_period_name, parse_quarter_str
from src.core.models import DocumentRecord, ResearchConfig


def safe_filename(name: str) -> str:
    """Sanitizes filename for Windows compatibility and safety."""
    clean = re.sub(r'[^A-Za-z0-9._-]+', '_', name.strip()).strip('._-')
    return clean[:100] or "UNNAMED_FILE"


def compute_sha256(file_path: Path) -> str:
    """Computes SHA-256 hex digest in chunks."""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_write_json(target_path: Path, data: Any):
    """Writes JSON atomically via temporary file."""
    temp_path = target_path.with_suffix(".tmp")
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    temp_path.replace(target_path)


class WorkspaceManager:
    """Manages the structured file system workspace for a company and reporting period."""

    def __init__(self, config: ResearchConfig):
        self.config = config
        self.symbol = safe_filename(config.company_symbol.upper())
        self.company_name = config.company_name
        self.quarter = config.reporting_quarter
        
        # Base folder: e.g. Documents/QuarterIQ_Research
        if config.output_base_dir:
            self.base_dir = Path(config.output_base_dir)
        else:
            self.base_dir = Path.home() / "Documents" / "QuarterIQ_Research"
            
        fy_folder, q_folder = format_folder_period_name(self.quarter)
        self.workspace_root = self.base_dir / self.symbol / fy_folder / q_folder
        self.manifest_json_path = self.workspace_root / "source_manifest.json"
        self.manifest_csv_path = self.workspace_root / "source_manifest.csv"
        self.config_json_path = self.workspace_root / "research_config.json"
        self.checklist_json_path = self.workspace_root / "document_checklist.json"
        self.download_log_path = self.workspace_root / "download_log.txt"

    def create_structure(self) -> Path:
        """Creates the full 12-folder directory hierarchy and initializes manifest files."""
        self.workspace_root.mkdir(parents=True, exist_ok=True)
        
        for folder_name in RESEARCH_FOLDERS.values():
            (self.workspace_root / folder_name).mkdir(exist_ok=True)

        now_ist = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

        # 1. research_config.json
        if not self.config_json_path.exists():
            cfg_dict = {
                "company_symbol": self.symbol,
                "company_name": self.company_name,
                "reporting_quarter": self.quarter,
                "accounting_basis": self.config.accounting_basis,
                "research_depth": self.config.research_depth,
                "current_market_price": self.config.current_market_price,
                "price_source": self.config.price_source,
                "peer_symbols": self.config.peer_symbols,
                "created_at_ist": now_ist
            }
            atomic_write_json(self.config_json_path, cfg_dict)

        # 2. source_manifest.json
        if not self.manifest_json_path.exists():
            manifest_dict = {
                "company_symbol": self.symbol,
                "company_name": self.company_name,
                "reporting_quarter": self.quarter,
                "created_at_ist": now_ist,
                "disclaimer": "Local audit ledger; verifies file presence and cryptographic digest, NOT accuracy of underlying disclosures.",
                "documents": []
            }
            atomic_write_json(self.manifest_json_path, manifest_dict)
            self._write_csv_manifest([])

        # 3. document_checklist.json
        self.update_checklist()

        # 4. download_log.txt
        if not self.download_log_path.exists():
            with open(self.download_log_path, "w", encoding="utf-8") as f:
                f.write(f"[{now_ist}] Workspace initialized for {self.company_name} ({self.symbol}) - {self.quarter}\n")

        return self.workspace_root

    def log(self, message: str):
        """Appends entry to download_log.txt."""
        now_ist = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
        with open(self.download_log_path, "a", encoding="utf-8") as f:
            f.write(f"[{now_ist}] {message}\n")

    def get_manifest(self) -> Dict[str, Any]:
        """Reads current source_manifest.json."""
        if not self.manifest_json_path.exists():
            self.create_structure()
        with open(self.manifest_json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write_csv_manifest(self, documents: List[Dict[str, Any]]):
        """Synchronizes source_manifest.csv."""
        fieldnames = [
            "category", "file_name", "file_path", "file_size_bytes", "sha256",
            "source_origin", "source_type", "collected_at", "verified",
            "verification_status", "verification_notes"
        ]
        with open(self.manifest_csv_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for doc in documents:
                row = {k: doc.get(k, "") for k in fieldnames}
                writer.writerow(row)

    def add_document(self, record: DocumentRecord) -> Dict[str, Any]:
        """Adds or updates a document in manifest and CSV, and logs the action."""
        manifest = self.get_manifest()
        
        # Check for duplicate sha256
        existing = [d for d in manifest["documents"] if d["sha256"] == record.sha256]
        if existing:
            self.log(f"NOTICE: Identical content hash already registered: {existing[0]['file_name']}")

        doc_dict = {
            "category": record.category,
            "file_name": record.file_name,
            "file_path": record.file_path,
            "file_size_bytes": record.file_size_bytes,
            "sha256": record.sha256,
            "source_origin": record.source_origin,
            "source_type": record.source_type,
            "collected_at": record.collected_at,
            "verified": record.verified,
            "verification_status": record.verification_status,
            "verification_notes": record.verification_notes,
            "page_count": record.page_count,
            "is_consolidated": record.is_consolidated
        }
        
        manifest["documents"].append(doc_dict)
        manifest["updated_at_ist"] = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
        atomic_write_json(self.manifest_json_path, manifest)
        self._write_csv_manifest(manifest["documents"])
        self.update_checklist()

        self.log(f"SAVED: [{record.category}] {record.file_name} ({record.file_size_bytes:,} bytes, SHA256: {record.sha256[:12]}...)")
        return doc_dict

    def update_document_verification(self, sha256: str, verified: bool, status: str, notes: str):
        """Updates verification status of a document."""
        manifest = self.get_manifest()
        for doc in manifest["documents"]:
            if doc["sha256"] == sha256:
                doc["verified"] = verified
                doc["verification_status"] = status
                doc["verification_notes"] = notes
                break
        atomic_write_json(self.manifest_json_path, manifest)
        self._write_csv_manifest(manifest["documents"])
        self.update_checklist()
        self.log(f"VERIFICATION: SHA {sha256[:12]} marked as {status} - {notes}")

    def update_checklist(self) -> Dict[str, Any]:
        """Evaluates completeness across mandatory categories."""
        manifest = self.get_manifest()
        found_categories = set()
        
        for doc in manifest.get("documents", []):
            rel_path = doc.get("file_path", "")
            full_path = self.workspace_root / rel_path
            if full_path.is_file():
                found_categories.add(doc.get("category"))

        checklist = {
            "total_mandatory": len(MANDATORY_CATEGORIES),
            "completed_count": len(found_categories.intersection(set(MANDATORY_CATEGORIES))),
            "is_ready_for_ai": len(found_categories.intersection(set(MANDATORY_CATEGORIES))) >= 3,
            "categories": {}
        }

        for cat in MANDATORY_CATEGORIES:
            checklist["categories"][cat] = {
                "found": cat in found_categories,
                "status": "COLLECTED" if cat in found_categories else "MISSING"
            }

        atomic_write_json(self.checklist_json_path, checklist)
        return checklist

    def get_destination_folder(self, category: str) -> Path:
        """Returns the appropriate subfolder path for a given document category."""
        folder_name = CATEGORY_DIR_MAP.get(category, "09_Other_Evidence")
        dest = self.workspace_root / folder_name
        dest.mkdir(parents=True, exist_ok=True)
        return dest

    def get_unique_destination_path(self, folder: Path, raw_name: str) -> Path:
        """Ensures unique safe filename without overwriting existing files."""
        safe_base = safe_filename(Path(raw_name).stem)
        ext = Path(raw_name).suffix.lower()
        if ext not in ACCEPTED_EXTENSIONS:
            ext = ".pdf"
            
        candidate = folder / f"{safe_base}{ext}"
        if not candidate.exists():
            return candidate

        count = 2
        while True:
            candidate = folder / f"{safe_base}_{count}{ext}"
            if not candidate.exists():
                return candidate
            count += 1

    def prune_empty_folders(self) -> List[str]:
        """Prunes unused empty directories in the workspace to keep only necessary folders with actual files."""
        pruned = []
        if not self.workspace_root or not self.workspace_root.exists():
            return pruned

        for child in sorted(self.workspace_root.iterdir()):
            if child.is_dir():
                # Never prune the primary output reports folder or extracted data folder
                if child.name in ("11_Research_Reports", "10_Extracted_Data"):
                    continue
                # Check if directory has any files (or non-empty subdirectories)
                items = list(child.rglob("*"))
                files = [it for it in items if it.is_file()]
                if len(files) == 0:
                    try:
                        shutil.rmtree(child)
                        pruned.append(child.name)
                    except Exception:
                        pass
        return pruned
