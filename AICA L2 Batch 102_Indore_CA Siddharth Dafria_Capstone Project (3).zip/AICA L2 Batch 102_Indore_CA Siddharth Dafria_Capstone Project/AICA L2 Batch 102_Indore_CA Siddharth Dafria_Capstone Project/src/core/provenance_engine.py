"""Document Provenance & Two-Way Claim Lineage Engine for QuarterIQ.
Maintains an immutable audit ledger connecting every material number, table,
claim, and recommendation directly to original corporate filings and verifiable pages.

Lead Forensic Auditor & Principal Architect:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import urllib.parse

from src.core.constants import IST


@dataclass
class SourceDocumentRecord:
    doc_id: str                      # e.g. "DOC-01"
    title: str                       # e.g. "Q2 FY2026-27 Financial Results & Limited Review"
    category: str                    # "01_Financial_Results", "02_Concall_Transcripts", etc.
    publisher: str                   # "BSE / NSE Corporate Filings"
    file_name: str                   # "TCS_Q2_FY2026-27_Financial_Results.pdf"
    relative_path: str               # "01_Financial_Results/TCS_Q2_FY2026-27_Financial_Results.pdf"
    sha256: str
    file_size_bytes: int
    original_url: str
    publication_timestamp: str
    retrieval_timestamp_ist: str
    file_type: str = "PDF"
    consolidation_basis: str = "Consolidated"
    validation_status: str = "VERIFIED" # "VERIFIED", "REVISED", "FLAGGED_MISMATCH"
    source_reliability: str = "PRIMARY_STATUTORY" # "PRIMARY_STATUTORY", "OFFICIAL_IR", "SECONDARY_ANALYST"
    pages_available: int = 1


@dataclass
class ClaimEvidenceLink:
    claim_id: str                    # e.g. "CLM-REV-01"
    section_id: str                  # e.g. "sec-kpis", "sec-forensics"
    metric_label: str                # e.g. "Revenue from Operations"
    reported_value_str: str          # e.g. "₹73,188 Cr"
    source_doc_id: str               # e.g. "DOC-01"
    source_page_or_table: str        # e.g. "Page 4, Table 1 (Statement of Unaudited Financial Results)"
    exact_line_item: str             # e.g. "Line 1(a) - Revenue from Operations"
    calculation_formula: Optional[str] = None
    derived_from_claims: List[str] = field(default_factory=list)
    confidence: str = "HIGH_VERIFIED" # "HIGH_VERIFIED", "ESTIMATED", "UNRECONCILED"
    verification_notes: str = ""


class ProvenanceEngine:
    """Manages document provenance, two-way claim lineage graph, and generates
    clickable relative citations for interactive offline HTML reports."""

    def __init__(self, workspace_root: Optional[Path] = None):
        self.workspace_root = workspace_root
        self.documents: Dict[str, SourceDocumentRecord] = {}
        self.claims: Dict[str, ClaimEvidenceLink] = {}
        self._doc_counter = 0
        self._claim_counter = 0

    def register_document(
        self,
        title: str,
        category: str,
        file_name: str,
        relative_path: str,
        sha256: str,
        file_size_bytes: int,
        original_url: str = "",
        publisher: str = "NSE/BSE Corporate Filings",
        publication_date: str = "",
        pages: int = 1,
        consolidation: str = "Consolidated",
        reliability: str = "PRIMARY_STATUTORY"
    ) -> SourceDocumentRecord:
        """Registers a verified document in the provenance registry."""
        self._doc_counter += 1
        doc_id = f"DOC-{self._doc_counter:02d}"
        now_ist = datetime.now(IST).strftime("%d-%b-%Y %H:%M:%S IST")
        
        doc = SourceDocumentRecord(
            doc_id=doc_id,
            title=title,
            category=category,
            publisher=publisher,
            file_name=file_name,
            relative_path=relative_path,
            sha256=sha256,
            file_size_bytes=file_size_bytes,
            original_url=original_url or f"https://www.nseindia.com/companies-listing/corporate-filings",
            publication_timestamp=publication_date or now_ist,
            retrieval_timestamp_ist=now_ist,
            file_type="PDF" if file_name.lower().endswith(".pdf") else "XLSX" if file_name.lower().endswith(".xlsx") else "DOC",
            consolidation_basis=consolidation,
            validation_status="VERIFIED",
            source_reliability=reliability,
            pages_available=pages
        )
        self.documents[doc_id] = doc
        return doc

    def register_claim(
        self,
        section_id: str,
        metric_label: str,
        value_str: str,
        doc_id: str,
        page_or_table: str,
        exact_line: str,
        formula: Optional[str] = None,
        confidence: str = "HIGH_VERIFIED"
    ) -> ClaimEvidenceLink:
        """Creates an auditable claim-to-evidence link."""
        self._claim_counter += 1
        claim_id = f"CLM-{self._claim_counter:03d}"
        
        claim = ClaimEvidenceLink(
            claim_id=claim_id,
            section_id=section_id,
            metric_label=metric_label,
            reported_value_str=value_str,
            source_doc_id=doc_id,
            source_page_or_table=page_or_table,
            exact_line_item=exact_line,
            calculation_formula=formula,
            confidence=confidence
        )
        self.claims[claim_id] = claim
        return claim

    def render_citation_badge(self, claim_id: str) -> str:
        """Renders an interactive, clickable HTML citation badge for a specific claim.
        Clicking opens the local PDF at the referenced page, or displays verifiable metadata."""
        claim = self.claims.get(claim_id)
        if not claim:
            return ""
        
        doc = self.documents.get(claim.source_doc_id)
        if not doc:
            return f'<span class="cite-badge-unresolved" title="Unresolved Source">[{claim.claim_id}]</span>'

        # Relative link from 11_Research_Reports/ to the document folder
        # e.g., "../01_Financial_Results/filing.pdf"
        rel_link = f"../{doc.relative_path}".replace("\\", "/")
        encoded_link = urllib.parse.quote(rel_link, safe="/#?&=")

        tooltip = (
            f"Source: {doc.title}&#10;"
            f"Publisher: {doc.publisher}&#10;"
            f"Filing Reference: {claim.source_page_or_table}&#10;"
            f"Line Item: {claim.exact_line_item}&#10;"
            f"SHA-256: {doc.sha256[:16]}...&#10;"
            f"Verified At: {doc.retrieval_timestamp_ist}"
        )

        return (
            f'<a href="{encoded_link}" target="_blank" class="cite-badge" '
            f'data-docid="{doc.doc_id}" data-claimid="{claim.claim_id}" '
            f'title="{tooltip}">'
            f'&#128196; {doc.doc_id}: {claim.source_page_or_table}'
            f'</a>'
        )

    def get_lineage_graph(self, claim_id: str) -> Dict[str, Any]:
        """Returns the full two-way lineage for a claim."""
        claim = self.claims.get(claim_id)
        if not claim:
            return {}
        doc = self.documents.get(claim.source_doc_id)
        return {
            "claim_id": claim.claim_id,
            "metric": claim.metric_label,
            "value": claim.reported_value_str,
            "formula": claim.calculation_formula,
            "source_document": {
                "doc_id": doc.doc_id if doc else "UNKNOWN",
                "title": doc.title if doc else "UNKNOWN",
                "sha256": doc.sha256 if doc else "UNKNOWN",
                "url": doc.original_url if doc else "UNKNOWN",
                "page_table": claim.source_page_or_table,
                "line_item": claim.exact_line_item
            }
        }
