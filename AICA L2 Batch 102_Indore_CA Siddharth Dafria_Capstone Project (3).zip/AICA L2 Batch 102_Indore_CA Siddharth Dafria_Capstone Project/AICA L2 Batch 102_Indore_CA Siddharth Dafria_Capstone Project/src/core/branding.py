from src.assets.ca_logo_data import CA_LOGO_BASE64_WHITE, CA_LOGO_PNG_PATH
"""Tamper-Resistant Author Identity, Branding & Integrity Verification Module for QuarterIQ.
Principal Architect & Lead Forensic Auditor:
Siddharth Dafria, Chartered Accountant
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)

This module provides cryptographic integrity verification, multi-layer DOM watermarking,
and tamper-evident anti-piracy protections across both the desktop terminal and generated reports.
"""
import hashlib
import html
from typing import Dict, Any


# Immutable Author Identity Attributes
AUTHOR_NAME = "Siddharth Dafria"
AUTHOR_DESIGNATION = "Chartered Accountant"
AUTHOR_QUALIFICATION = "Chartered Accountant (ICAI)"
AUTHOR_MOBILE = "9977822290"
AUTHOR_MOBILE_INTL = "+91 9977822290"
AUTHOR_EMAIL = "sdafria@icai.org"
AUTHOR_ORGANIZATION = "Institute of Chartered Accountants of India (ICAI)"
AUTHOR_TITLE = "Principal Architect & Lead Forensic Auditor"
AUTHOR_FULL_SIGNATURE = "Siddharth Dafria, Chartered Accountant · Dafria & Co · M: 9977822290 · E: sdafria@icai.org"

# Official Firm Identity
FIRM_NAME = "Dafria & Co"
FIRM_TITLE = "DAFRIA & CO"
FIRM_SUBTITLE = "CHARTERED ACCOUNTANTS & INSTITUTIONAL EQUITY RESEARCH"

# Cryptographic Integrity Digest (SHA-256)
AUTHOR_SECURITY_TOKEN = "4027d339461c953a6f2ef97df35ce0e3d99c911af4170fe20f03319bc753f29d"


class TamperProtectionViolation(Exception):
    """Raised when an attempt to remove, modify, or obfuscate author branding is detected."""
    pass


def verify_brand_integrity() -> bool:
    """Cryptographically verifies that author identity parameters have not been altered."""
    payload = (
        f"{AUTHOR_NAME.upper().replace(' ', '_')}_"
        f"{AUTHOR_DESIGNATION.upper().replace(' ', '_')}_"
        f"{AUTHOR_MOBILE}_"
        f"{AUTHOR_EMAIL.upper()}_"
        f"QUARTERIQ_CAPSTONE_2026"
    )
    computed_digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return computed_digest == AUTHOR_SECURITY_TOKEN


def enforce_brand_integrity():
    """Enforces cryptographic author identity. Aborts execution if tampered."""
    if not verify_brand_integrity():
        raise TamperProtectionViolation(
            "CRITICAL SECURITY VIOLATION: Unauthorized alteration or removal of author branding detected.\n"
            "QuarterIQ is the exclusive intellectual property and ICAI Capstone project of:\n"
            "SIDDHARTH DAFRIA, CHARTERED ACCOUNTANT\n"
            "Mobile: 9977822290 | Email: sdafria@icai.org\n"
            "Operation has been terminated to preserve audit integrity."
        )


def get_branding_dict() -> Dict[str, str]:
    """Returns verified author metadata dictionary."""
    enforce_brand_integrity()
    return {
        "name": AUTHOR_NAME,
        "designation": AUTHOR_DESIGNATION,
        "qualification": AUTHOR_QUALIFICATION,
        "mobile": AUTHOR_MOBILE,
        "mobile_intl": AUTHOR_MOBILE_INTL,
        "email": AUTHOR_EMAIL,
        "organization": AUTHOR_ORGANIZATION,
        "firm_name": FIRM_NAME,
        "firm_title": FIRM_TITLE,
        "title": AUTHOR_TITLE,
        "signature": AUTHOR_FULL_SIGNATURE,
        "token": AUTHOR_SECURITY_TOKEN,
    }


def render_brand_top_bar_html() -> str:
    """Renders the top executive header branding bar for institutional reports."""
    enforce_brand_integrity()
    return f"""
    <div id="ca-brand-header-bar" class="ca-brand-header" style="background:linear-gradient(135deg, #090d16 0%, #111827 50%, #0d1e38 100%); border-bottom:2px solid #2563eb; padding:12px 24px; display:flex; justify-content:space-between; align-items:center; color:#f8fafc; font-family:system-ui,-apple-system,sans-serif; position:sticky; top:0; z-index:99999; box-shadow:0 4px 20px rgba(0,0,0,0.5);">
        <div style="display:flex; align-items:center; gap:16px;">
            <div style="width:48px; height:38px; border-radius:6px; background:#ffffff; display:flex; align-items:center; justify-content:center; padding:2px 4px; box-shadow:0 0 10px rgba(56,189,248,0.4); border:1.5px solid #60a5fa; flex-shrink:0;">
                <img src="data:image/png;base64,{CA_LOGO_BASE64_WHITE}" style="max-width:100%; max-height:100%; object-fit:contain;" alt="CA INDIA" />
            </div>
            <div>
                <div style="font-size:15px; font-weight:800; letter-spacing:0.5px; color:#f8fafc; display:flex; align-items:center; gap:8px;">
                    <span id="ca-author-name">{html.escape(AUTHOR_NAME)}</span>
                    <span style="font-size:12px; color:#38bdf8; font-weight:700;">(Dafria &amp; Co)</span>
                    <span style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid #f59e0b; border-radius:4px; font-size:10px; font-weight:800; padding:2px 8px; letter-spacing:0.5px;">AUTOMATED DRAFT – PENDING CA REVIEW</span>
                </div>
                <div style="font-size:12px; color:#94a3b8; margin-top:2px;">
                    <strong>Dafria &amp; Co</strong>, Chartered Accountants · {html.escape(AUTHOR_ORGANIZATION)} · ICAI Capstone Platform
                </div>
            </div>
        </div>
        <div style="display:flex; align-items:center; gap:20px; font-size:12px;">
            <div style="display:flex; align-items:center; gap:6px; background:rgba(30,41,59,0.7); padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                <span style="color:#38bdf8;">📞 Mobile:</span>
                <a href="tel:{AUTHOR_MOBILE}" id="ca-author-mobile" style="color:#f8fafc; text-decoration:none; font-weight:700;">{AUTHOR_MOBILE_INTL}</a>
            </div>
            <div style="display:flex; align-items:center; gap:6px; background:rgba(30,41,59,0.7); padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                <span style="color:#38bdf8;">✉ Email:</span>
                <a href="mailto:{AUTHOR_EMAIL}" id="ca-author-email" style="color:#38bdf8; text-decoration:none; font-weight:700;">{AUTHOR_EMAIL}</a>
            </div>
            <div style="background:linear-gradient(135deg, #1e3a8a 0%, #1e1b4b 100%); color:#93c5fd; font-weight:800; padding:5px 12px; border-radius:6px; font-size:11px; border:1px solid #3b82f6; box-shadow:0 0 10px rgba(59,130,246,0.3); display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:6px; height:6px; border-radius:50%; background:#10b981; box-shadow:0 0 6px #10b981;"></span>
                QuarterIQ v4.2 Universal Institutional Terminal
            </div>
        </div>
    </div>
    """


def render_brand_ca_seal_svg() -> str:
    """Renders a tamper-evident high-resolution SVG seal of the Chartered Accountant."""
    enforce_brand_integrity()
    return f"""
    <svg id="ca-signature-seal" class="ca-official-seal" width="180" height="180" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" style="display:inline-block; vertical-align:middle;">
        <defs>
            <linearGradient id="goldRing" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#f59e0b" />
                <stop offset="50%" stop-color="#fbbf24" />
                <stop offset="100%" stop-color="#d97706" />
            </linearGradient>
            <linearGradient id="blueCore" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#1e3a8a" />
                <stop offset="100%" stop-color="#0f172a" />
            </linearGradient>
            <path id="textCircleOuter" d="M 100, 100 m -75, 0 a 75,75 0 1,1 150,0 a 75,75 0 1,1 -150,0" />
            <path id="textCircleInner" d="M 100, 100 m -58, 0 a 58,58 0 1,1 116,0 a 58,58 0 1,1 -116,0" />
        </defs>
        <!-- Outer Golden Starburst / Teeth -->
        <circle cx="100" cy="100" r="94" fill="none" stroke="url(#goldRing)" stroke-width="3" stroke-dasharray="4,2" />
        <circle cx="100" cy="100" r="88" fill="url(#blueCore)" stroke="url(#goldRing)" stroke-width="2.5" />
        <circle cx="100" cy="100" r="68" fill="none" stroke="#38bdf8" stroke-width="1.2" stroke-dasharray="3,3" />
        
        <!-- Curved Circular Text: SIDDHARTH DAFRIA · CHARTERED ACCOUNTANT -->
        <text font-size="8.5" font-family="Arial, sans-serif" font-weight="900" fill="#fbbf24" letter-spacing="1.8">
            <textPath href="#textCircleOuter" startOffset="50%" text-anchor="middle">
                SIDDHARTH DAFRIA · CHARTERED ACCOUNTANT
            </textPath>
        </text>
        
        <!-- Curved Circular Text: ICAI · M: 9977822290 · sdafria@icai.org -->
        <text font-size="7" font-family="Arial, sans-serif" font-weight="700" fill="#38bdf8" letter-spacing="1.2">
            <textPath href="#textCircleInner" startOffset="50%" text-anchor="middle">
                ICAI · M: 9977822290 · sdafria@icai.org
            </textPath>
        </text>
        
        <!-- Center Shield & Emblem -->
        <circle cx="100" cy="100" r="46" fill="#0b1329" stroke="url(#goldRing)" stroke-width="1.8" />
        <path d="M 100,66 L 126,80 L 126,106 Q 126,128 100,136 Q 74,128 74,106 L 74,80 Z" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5" />
        <text x="100" y="96" font-family="Arial, sans-serif" font-size="14" font-weight="900" fill="#ffffff" text-anchor="middle">CA</text>
        <text x="100" y="112" font-family="Arial, sans-serif" font-size="6.5" font-weight="800" fill="#fbbf24" text-anchor="middle">PENDING REVIEW</text>
        <text x="100" y="122" font-family="Courier New, monospace" font-size="5" font-weight="700" fill="#94a3b8" text-anchor="middle">4027D339</text>
    </svg>
    """


def render_brand_certification_card_html() -> str:
    """Renders the formal Chartered Accountant Engagement & Professional Opinion Certification card."""
    enforce_brand_integrity()
    return f"""
    <div id="ca-certification-block" class="ca-certification-card" style="background:linear-gradient(135deg, #0b1329 0%, #131d38 100%); border:2px solid #2563eb; border-radius:12px; padding:24px; margin-top:30px; margin-bottom:20px; box-shadow:0 8px 30px rgba(0,0,0,0.6); position:relative; overflow:hidden;">
        <div style="position:absolute; right:-20px; bottom:-20px; opacity:0.12; pointer-events:none;">
            {render_brand_ca_seal_svg()}
        </div>
        <div style="display:flex; flex-wrap:wrap; gap:24px; align-items:center;">
            <div>
                {render_brand_ca_seal_svg()}
            </div>
            <div style="flex:1; min-width:320px;">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;">
                    <span style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid #f59e0b; font-size:11px; font-weight:900; padding:3px 8px; border-radius:4px; text-transform:uppercase; letter-spacing:0.8px;">Automated Draft – Pending CA Review</span>
                    <span style="color:#94a3b8; font-size:12px;">ICAI AI Level 2 Capstone Deliverable</span>
                </div>
                <h3 style="font-size:20px; font-weight:800; color:#f8fafc; margin:0 0 4px 0;">
                    {html.escape(AUTHOR_NAME)}
                </h3>
                <div style="font-size:14px; font-weight:700; color:#38bdf8; margin-bottom:8px;">
                    {html.escape(AUTHOR_DESIGNATION)} · {html.escape(AUTHOR_ORGANIZATION)}
                </div>
                <p style="font-size:13px; color:#cbd5e1; line-height:1.6; margin-bottom:12px;">
                    This institutional research report, quantitative earnings surprise model, Ind AS arithmetic reconciliation, and forensic anomaly detection engine were designed and engineered by <strong>{html.escape(AUTHOR_NAME)}, Chartered Accountant</strong>. <em>COMPLIANCE NOTICE:</em> This document is an automated analytical draft generated by algorithmic software. It is strictly <strong>Pending Formal Review and Sign-Off by a practicing Chartered Accountant</strong> prior to professional reliance. All financial metrics and historical trend series have been extracted directly from statutory BSE/NSE filings.
                </p>
                <div style="display:flex; flex-wrap:wrap; gap:14px; font-size:12px;">
                    <div style="background:#1e293b; padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                        <span style="color:#94a3b8;">Direct Mobile:</span>
                        <strong style="color:#f8fafc; margin-left:4px;">{AUTHOR_MOBILE_INTL}</strong>
                    </div>
                    <div style="background:#1e293b; padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                        <span style="color:#94a3b8;">Official Email:</span>
                        <strong style="color:#38bdf8; margin-left:4px;">{AUTHOR_EMAIL}</strong>
                    </div>
                    <div style="background:#1e293b; padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                        <span style="color:#94a3b8;">Cryptographic Token:</span>
                        <code style="color:#10b981; margin-left:4px;">SHA256:{AUTHOR_SECURITY_TOKEN[:16]}...</code>
                    </div>
                </div>
            </div>
        </div>
    </div>
    """


def render_institutional_letterhead_html(
    company_name: str,
    symbol: str,
    quarter: str,
    sector: str = "",
    bse_code: str = "",
    isin: str = "",
    now_ist: str = ""
) -> str:
    """Renders the executive institutional research letterhead for QuarterIQ dossiers."""
    enforce_brand_integrity()
    bse_str = f" · BSE: {html.escape(bse_code)}" if bse_code else ""
    isin_str = f" · ISIN: {html.escape(isin)}" if isin else ""
    clean_sym = symbol.upper().strip()
    clean_q = quarter.strip()
    
    return f"""
    <div id="ca-institutional-letterhead" class="institutional-letterhead">
        <!-- Top Band: CA Emblem & Firm Credentials -->
        <div class="letterhead-header">
            <div class="letterhead-crest-box">
                <div class="ca-crest-emblem ca-official-emblem-badge">
                    <img src="data:image/png;base64,{CA_LOGO_BASE64_WHITE}" alt="CA INDIA Official Emblem" class="ca-india-logo-img" />
                </div>
                <div class="crest-details">
                    <h1 class="firm-title">DAFRIA &amp; CO</h1>
                    <div class="firm-subtitle">CHARTERED ACCOUNTANTS &amp; INSTITUTIONAL EQUITY RESEARCH</div>
                    <div class="firm-affiliations">
                        <span><strong>Siddharth Dafria</strong>, Chartered Accountant (ICAI)</span>
                        <span class="sep">·</span>
                        <span>{html.escape(AUTHOR_ORGANIZATION)}</span>
                        <span class="sep">·</span>
                        <span>Research Desk: QIQ-IR-2026-CA</span>
                    </div>
                </div>
            </div>
            <div class="letterhead-contacts">
                <div class="contact-item"><strong>Principal:</strong> Siddharth Dafria, CA</div>
                <div class="contact-item"><strong>Firm:</strong> Dafria &amp; Co</div>
                <div class="contact-item"><strong>Direct:</strong> {AUTHOR_MOBILE_INTL}</div>
                <div class="contact-item"><strong>Official:</strong> {html.escape(AUTHOR_EMAIL)}</div>
            </div>
        </div>

        <!-- Architectural Gradient Rule -->
        <div class="letterhead-divider"></div>

        <!-- Metadata Grid -->
        <div class="letterhead-meta-grid">
            <div class="meta-col">
                <div class="meta-row"><span class="m-lbl">DOSSIER TYPE:</span> <span class="m-val">Institutional Forensic &amp; Fundamental Equity Research Dossier</span></div>
                <div class="meta-row"><span class="m-lbl">TARGET ENTITY:</span> <span class="m-val"><strong>{html.escape(company_name)}</strong> (NSE: {clean_sym}{bse_str}{isin_str})</span></div>
                <div class="meta-row"><span class="m-lbl">SECTOR:</span> <span class="m-val">{html.escape(sector or 'Equity Research Benchmark')}</span></div>
            </div>
            <div class="meta-col">
                <div class="meta-row"><span class="m-lbl">FILING PERIOD:</span> <span class="m-val"><strong>{clean_q}</strong> (Ind AS Statutory Filings)</span></div>
                <div class="meta-row"><span class="m-lbl">WORKPAPER REF:</span> <span class="m-val monospace">QIQ/EQ-RES/2026/{clean_sym}-{clean_q.replace(' ', '_')}-AUDIT</span></div>
                <div class="meta-row"><span class="m-lbl">GENERATED AT:</span> <span class="m-val">{html.escape(now_ist)} IST</span></div>
            </div>
            <div class="meta-col compliance-col">
                <div class="compliance-badge">AUTOMATED DRAFT – PENDING CA REVIEW</div>
                <div class="compliance-note">Algorithmically synthesized research paper under Ind AS / SEBI ICDR parameters. Requires formal review and sign-off by practicing CA prior to commercial reliance.</div>
            </div>
        </div>
    </div>
    """


def render_brand_css() -> str:
    """Renders CSS with pseudo-elements to lock in branding across screen and print media."""
    enforce_brand_integrity()
    return f"""
    /* Anti-Tamper Author Watermark & Print Headers */
    @media print {{
        @page {{
            size: A4 portrait;
            margin: 10mm 10mm 12mm 10mm;
            @top-right {{
                content: "Research Lead: {AUTHOR_NAME}, Chartered Accountant (M: {AUTHOR_MOBILE}, E: {AUTHOR_EMAIL})";
                font-size: 7.5pt;
                color: #64748b;
                font-family: Arial, sans-serif;
            }}
            @bottom-left {{
                content: "QuarterIQ v4.2 Universal Terminal · Automated Draft – Pending CA Review · Lead Architect: {AUTHOR_NAME}, CA";
                font-size: 7.5pt;
                color: #64748b;
                font-family: Arial, sans-serif;
            }}
            @bottom-right {{
                content: "Page " counter(page) " of " counter(pages);
                font-size: 7.5pt;
                color: #64748b;
            }}
        }}
        #ca-brand-header-bar,
        .brand-watermark-pill,
        #ca-author-badge {{
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            width: 0 !important;
            position: static !important;
        }}
        body::before {{
            display: none !important;
        }}
        body::after {{
            content: "Automated Draft – Pending CA Review · Lead Architect: {AUTHOR_NAME}, Chartered Accountant (M: {AUTHOR_MOBILE}, E: {AUTHOR_EMAIL}) · ICAI AI Level 2 Capstone Deliverable";
            display: block;
            text-align: center;
            font-size: 7.5pt;
            color: #475569;
            margin-top: 15px;
            border-top: 1px solid #cbd5e1;
            padding-top: 8px;
        }}
    }}
    
    /* Screen Watermark & Background Ribbon */
    .brand-watermark-pill {{
        position: fixed;
        bottom: 16px;
        right: 16px;
        background: rgba(11, 19, 41, 0.94);
        border: 1.5px solid #2563eb;
        border-radius: 30px;
        padding: 8px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #f8fafc;
        font-size: 11px;
        font-family: system-ui, sans-serif;
        box-shadow: 0 4px 18px rgba(0,0,0,0.6);
        z-index: 99998;
        backdrop-filter: blur(6px);
    }}
    """


def render_brand_tamper_guard_js() -> str:
    """Renders client-side anti-tamper JavaScript with MutationObserver to block unauthorized removal."""
    enforce_brand_integrity()
    return f"""
    (function() {{
        const AUTHOR_DATA = {{
            name: "{AUTHOR_NAME}",
            mobile: "{AUTHOR_MOBILE}",
            email: "{AUTHOR_EMAIL}",
            token: "{AUTHOR_SECURITY_TOKEN}"
        }};
        
        function verifyAttribution() {{
            const header = document.getElementById("ca-brand-header-bar");
            const certBlock = document.getElementById("ca-certification-block");
            const authorSpan = document.getElementById("ca-author-name");
            
            let tampered = false;
            if (!header || !certBlock || !authorSpan) {{
                tampered = true;
            }} else {{
                if (!header.innerText.includes(AUTHOR_DATA.name) || 
                    !header.innerText.includes(AUTHOR_DATA.mobile) || 
                    !header.innerText.includes(AUTHOR_DATA.email)) {{
                    tampered = true;
                }}
            }}
            
            if (tampered) {{
                document.body.innerHTML = `
                    <div style="background:#090d16; color:#ffffff; font-family:system-ui,sans-serif; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:30px; text-align:center;">
                        <div style="max-width:680px; background:#1e1b4b; border:3px solid #ef4444; border-radius:16px; padding:36px; box-shadow:0 0 50px rgba(239,68,68,0.5);">
                            <div style="font-size:54px; margin-bottom:12px;">🛡️</div>
                            <h1 style="color:#ef4444; font-size:24px; margin-bottom:12px; font-weight:900;">UNAUTHORIZED MODIFICATION DETECTED</h1>
                            <p style="font-size:15px; color:#cbd5e1; line-height:1.7; margin-bottom:20px;">
                                This institutional equity research platform and its analytical algorithms are the protected intellectual property of:
                            </p>
                            <div style="background:#0f172a; border:2px solid #38bdf8; border-radius:10px; padding:18px; margin-bottom:22px; text-align:left;">
                                <div style="font-size:18px; font-weight:900; color:#38bdf8; margin-bottom:4px;">${{AUTHOR_DATA.name}}</div>
                                <div style="font-size:13px; font-weight:700; color:#10b981; margin-bottom:8px;">Chartered Accountant · Institute of Chartered Accountants of India</div>
                                <div style="font-size:13px; color:#f8fafc;">📞 Mobile: <strong>+91 ${{AUTHOR_DATA.mobile}}</strong></div>
                                <div style="font-size:13px; color:#f8fafc;">✉ Email: <strong>${{AUTHOR_DATA.email}}</strong></div>
                                <div style="font-size:11px; color:#94a3b8; margin-top:6px;">Security Token: <code>${{AUTHOR_DATA.token}}</code></div>
                            </div>
                            <p style="font-size:13px; color:#94a3b8;">
                                Tampering with certified Chartered Accountant research signatures violates ICAI ethical codes and intellectual property statutes.
                            </p>
                        </div>
                    </div>
                `;
            }}
        }}

        // Run attribution check on load and attach MutationObserver to catch programmer edits
        if (typeof window !== "undefined") {{
            window.addEventListener("DOMContentLoaded", verifyAttribution);
            setTimeout(verifyAttribution, 1000);
            setInterval(verifyAttribution, 4000);
            
            if (window.MutationObserver) {{
                const observer = new MutationObserver(function() {{
                    verifyAttribution();
                }});
                observer.observe(document.documentElement, {{ childList: true, subtree: true, attributes: true }});
            }}
        }}
    }})();
    """
