"""Robust Browser & Document Launcher for QuarterIQ v4.2.
Guarantees that generated HTML reports launch automatically in the user's default browser
on Windows exactly once (preventing duplicate tab opens), and provides dedicated openers
for the research PDF dossier and document folders.

Principal Architect & Lead Forensic Auditor:
Siddharth Dafria, Chartered Accountant
Dafria & Co, Chartered Accountants
Mobile: 9977822290 | Email: sdafria@icai.org
Institute of Chartered Accountants of India (ICAI)
"""
import os
from pathlib import Path
import subprocess
import time
from typing import Dict, List, Optional, Union
import webbrowser

# Timestamp cache for debouncing opens across UI events
_LAST_OPENED_PATHS: Dict[str, float] = {}


def get_browser_binaries() -> List[str]:
    """Discovers available Chromium-based browser binaries on Windows."""
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files\Mozilla Firefox\firefox.exe",
    ]
    return [p for p in candidates if os.path.isfile(p)]


def open_html_report_in_browser(report_path: Union[str, Path], debounce_seconds: float = 4.0) -> bool:
    """Launches an HTML research report automatically in the user's default browser EXACTLY ONCE.
    Debounces duplicate calls from background workers, file generators, and UI signal handlers.
    """
    path_obj = Path(report_path).resolve()
    if not path_obj.exists():
        return False

    str_path = str(path_obj)
    now = time.time()
    last_time = _LAST_OPENED_PATHS.get(str_path, 0.0)
    if (now - last_time) < debounce_seconds:
        # Already launched in default browser within debounce window; prevent multiple tabs
        return True
    _LAST_OPENED_PATHS[str_path] = now

    file_uri = path_obj.as_uri()

    # Priority 1: Python standard library webbrowser module (delegates to os.startfile on Windows)
    try:
        res = webbrowser.open(file_uri)
        if res is not False:
            return True
    except Exception:
        pass

    # Priority 2: Fallback to native Windows ShellExecute
    if os.name == "nt":
        try:
            os.startfile(str_path)
            return True
        except Exception:
            pass

    # Priority 3: Direct browser binary launch
    for browser_exe in get_browser_binaries():
        try:
            subprocess.Popen([browser_exe, str_path])
            return True
        except Exception:
            pass

    return False


def open_pdf_report(pdf_path: Union[str, Path], debounce_seconds: float = 4.0) -> bool:
    """Launches the research PDF dossier in the user's default PDF viewer EXACTLY ONCE."""
    path_obj = Path(pdf_path).resolve()
    if not path_obj.exists():
        return False

    str_path = str(path_obj)
    now = time.time()
    last_time = _LAST_OPENED_PATHS.get(str_path, 0.0)
    if (now - last_time) < debounce_seconds:
        return True
    _LAST_OPENED_PATHS[str_path] = now

    if os.name == "nt":
        try:
            os.startfile(str_path)
            return True
        except Exception:
            pass

    try:
        webbrowser.open(path_obj.as_uri())
        return True
    except Exception:
        pass

    return False


def open_document_folder(folder_path: Union[str, Path], debounce_seconds: float = 4.0) -> bool:
    """Opens the document/report storage folder in Windows File Explorer EXACTLY ONCE."""
    path_obj = Path(folder_path).resolve()
    if not path_obj.exists():
        return False

    str_path = str(path_obj)
    now = time.time()
    last_time = _LAST_OPENED_PATHS.get(str_path, 0.0)
    if (now - last_time) < debounce_seconds:
        return True
    _LAST_OPENED_PATHS[str_path] = now

    if os.name == "nt":
        try:
            os.startfile(str_path)
            return True
        except Exception:
            pass

    try:
        subprocess.Popen(f'explorer "{str_path}"', shell=True)
        return True
    except Exception:
        pass

    return False


def open_research_dossier(
    html_path: Union[str, Path],
    pdf_path: Optional[Union[str, Path]] = None,
    folder_path: Optional[Union[str, Path]] = None
) -> bool:
    """Coordinates opening:
    1. Single instance of the interactive HTML report in default browser.
    2. Single instance of the research PDF dossier in default PDF viewer.
    3. Document folder where all files are saved in Windows File Explorer.
    """
    open_html_report_in_browser(html_path)
    if pdf_path and Path(pdf_path).exists():
        open_pdf_report(pdf_path)
    if folder_path and Path(folder_path).exists():
        open_document_folder(folder_path)
    return True
