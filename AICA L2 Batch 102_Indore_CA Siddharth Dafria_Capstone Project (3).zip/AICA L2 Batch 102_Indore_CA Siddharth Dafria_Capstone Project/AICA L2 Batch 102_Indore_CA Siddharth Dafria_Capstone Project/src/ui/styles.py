"""Modern Dark and Light Terminal Stylesheets for PySide6."""

DARK_THEME_QSS = """
QMainWindow, QDialog, QWidget {
    background-color: #0b0f19;
    color: #f8fafc;
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}

QTabWidget::pane {
    border: 1px solid #1e293b;
    background-color: #0b0f19;
    border-radius: 4px;
}

QTabBar::tab {
    background-color: #111827;
    color: #94a3b8;
    padding: 10px 18px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 600;
}

QTabBar::tab:selected {
    background-color: #1e293b;
    color: #38bdf8;
    border-bottom: 2px solid #38bdf8;
}

QTabBar::tab:hover:!selected {
    background-color: #1f2937;
    color: #e2e8f0;
}

QGroupBox {
    border: 1px solid #1e293b;
    border-radius: 8px;
    margin-top: 24px;
    padding-top: 18px;
    font-weight: bold;
    color: #38bdf8;
    background-color: #111827;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 10px;
    background-color: #1e293b;
    border-radius: 4px;
}

QLineEdit, QComboBox, QSpinBox {
    background-color: #151d2b;
    border: 1px solid #283548;
    border-radius: 6px;
    padding: 8px 12px;
    color: #f8fafc;
    selection-background-color: #3b82f6;
}

QLineEdit:focus, QComboBox:focus {
    border: 1px solid #38bdf8;
}

QComboBox::drop-down {
    border: none;
    padding-right: 10px;
}

QPushButton {
    background-color: #1e293b;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 9px 18px;
    font-weight: 600;
}

QPushButton:hover {
    background-color: #283548;
    border-color: #475569;
}

QPushButton:pressed {
    background-color: #0f172a;
}

QPushButton#primaryBtn {
    background-color: #2563eb;
    color: white;
    border: none;
}

QPushButton#primaryBtn:hover {
    background-color: #1d4ed8;
}

QPushButton#successBtn {
    background-color: #059669;
    color: white;
    border: none;
}

QPushButton#successBtn:hover {
    background-color: #047857;
}

QPushButton#accentBtn {
    background-color: #4f46e5;
    color: white;
    border: none;
}

QPushButton#accentBtn:hover {
    background-color: #4338ca;
}

QTableWidget {
    background-color: #111827;
    border: 1px solid #1e293b;
    border-radius: 6px;
    gridline-color: #1e293b;
    color: #f8fafc;
}

QHeaderView::section {
    background-color: #1e293b;
    color: #94a3b8;
    padding: 8px;
    font-weight: 600;
    border: 1px solid #0b0f19;
}

QTextEdit, QPlainTextEdit {
    background-color: #0f172a;
    border: 1px solid #1e293b;
    border-radius: 6px;
    color: #cbd5e1;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 12px;
    padding: 8px;
}

QProgressBar {
    background-color: #1e293b;
    border-radius: 6px;
    text-align: center;
    color: white;
    font-weight: bold;
    height: 18px;
}

QProgressBar::chunk {
    background-color: #10b981;
    border-radius: 6px;
}

QScrollBar:vertical {
    border: none;
    background: #0b0f19;
    width: 10px;
}

QScrollBar::handle:vertical {
    background: #1e293b;
    min-height: 20px;
    border-radius: 5px;
}

QScrollBar::handle:vertical:hover {
    background: #334155;
}
"""

LIGHT_THEME_QSS = """
QMainWindow, QDialog, QWidget {
    background-color: #f8fafc;
    color: #0f172a;
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}

QTabWidget::pane {
    border: 1px solid #cbd5e1;
    background-color: #f8fafc;
    border-radius: 4px;
}

QTabBar::tab {
    background-color: #e2e8f0;
    color: #475569;
    padding: 10px 18px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 600;
}

QTabBar::tab:selected {
    background-color: #ffffff;
    color: #0284c7;
    border-bottom: 2px solid #0284c7;
}

QTabBar::tab:hover:!selected {
    background-color: #f1f5f9;
    color: #1e293b;
}

QGroupBox {
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    margin-top: 24px;
    padding-top: 18px;
    font-weight: bold;
    color: #0369a1;
    background-color: #ffffff;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 10px;
    background-color: #e2e8f0;
    border-radius: 4px;
}

QLineEdit, QComboBox, QSpinBox {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 8px 12px;
    color: #0f172a;
    selection-background-color: #38bdf8;
}

QLineEdit:focus, QComboBox:focus {
    border: 1px solid #0284c7;
}

QPushButton {
    background-color: #f1f5f9;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 9px 18px;
    font-weight: 600;
}

QPushButton:hover {
    background-color: #e2e8f0;
}

QPushButton#primaryBtn {
    background-color: #0284c7;
    color: white;
    border: none;
}

QPushButton#primaryBtn:hover {
    background-color: #0369a1;
}

QPushButton#successBtn {
    background-color: #059669;
    color: white;
    border: none;
}

QPushButton#successBtn:hover {
    background-color: #047857;
}

QPushButton#accentBtn {
    background-color: #4f46e5;
    color: white;
    border: none;
}

QPushButton#accentBtn:hover {
    background-color: #4338ca;
}

QTableWidget {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    gridline-color: #e2e8f0;
    color: #0f172a;
}

QHeaderView::section {
    background-color: #f1f5f9;
    color: #475569;
    padding: 8px;
    font-weight: 600;
    border: 1px solid #e2e8f0;
}

QTextEdit, QPlainTextEdit {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    color: #0f172a;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 12px;
    padding: 8px;
}

QProgressBar {
    background-color: #e2e8f0;
    border-radius: 6px;
    text-align: center;
    color: #0f172a;
    font-weight: bold;
    height: 18px;
}

QProgressBar::chunk {
    background-color: #10b981;
    border-radius: 6px;
}
"""
