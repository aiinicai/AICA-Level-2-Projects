"""QuarterIQ UI Module."""
