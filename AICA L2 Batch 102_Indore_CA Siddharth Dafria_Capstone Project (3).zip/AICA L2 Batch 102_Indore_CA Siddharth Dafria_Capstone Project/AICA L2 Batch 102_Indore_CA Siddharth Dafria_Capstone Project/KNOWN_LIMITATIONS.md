# QuarterIQ — Known Limitations, Fallback Procedures & Compliance Boundaries
## Academic & Professional Disclosure Document

### 1. Regulatory & SEBI Compliance Boundary
- **ICAI Academic Capstone Scope:** QuarterIQ is designed as an educational, forensic, and analytical tool for the ICAI AI Level 2 Capstone. It does **not** provide SEBI-registered investment advice, portfolio management, or public research analyst recommendations under SEBI (Research Analysts) Regulations, 2014 (including the October 2026 amendments).
- **No Unsolicited Trading Signals:** Investment verdicts produced by the application (e.g., `ACCUMULATE`, `HOLD`, `REDUCE`, `AVOID`, `NO-TRADE`) reflect algorithmic scoring based strictly on historical and current disclosed numbers. When essential valuation or earnings metrics are unavailable, the system deliberately enforces `NO-TRADE / INSUFFICIENT DATA`.

### 2. Website Anti-Bot & Exchange Download Protections
- **NSE & BSE Anti-Scraping Mechanisms:** Indian stock exchange web portals (particularly NSE India) frequently utilize Akamai bot detection, dynamic session cookies, and IP rate limits.
- **Direct HTTPS Downloader Behavior:** When official exchange URLs permit direct file streaming, QuarterIQ downloads and hashes the document automatically. If an exchange blocks direct downloading, returns a CAPTCHA, or serves an HTML error page, QuarterIQ detects the invalid binary signature (`<!DOCTYPE html`) and rejects the file.
- **Standard Fallback Procedure:** Users can open the official filing portal directly in their browser using the built-in *Find Official Documents* button, download the signed PDF, and use the *Import Downloaded Files* button to place it in the workspace.

### 3. Reporting Availability vs. Calendar Quarter End
- **SEBI LODR 45/60 Day Window:** A quarter's financial results are not published on the exact date the reporting quarter closes. Under Regulation 33, listed corporations are granted 45 days (for Q1, Q2, and Q3) and 60 days (for Q4) to submit reviewed or audited results.
- **QuarterIQ Logic:** The platform checks current date against the reporting period and informs the user whether earnings season is open, whether results are overdue, or whether the quarter is in progress. It never assumes an unfiled quarter has been reported.

### 4. Browser Automation Resilience (Mode A ChatGPT Workflow)
- **Browser Scripting Fragility:** External web interfaces like ChatGPT undergo periodic DOM and UI updates. Relying purely on DOM selectors for file uploads can lead to intermittent failures.
- **Bulletproof Semi-Automated Architecture:** QuarterIQ uses a resilient hybrid workflow:
  1. Compiles the verified inventory and metrics into `prompt_ready_to_paste.txt`.
  2. Copies the text to the Windows system clipboard automatically.
  3. Launches `https://chatgpt.com/` in the user's default browser.
  4. Opens the local research folder so the user can easily drag and drop the PDFs into the browser composer.
  5. Provides an *Import Generated HTML* feature to bring the completed dashboard directly back into QuarterIQ.

### 5. Quarterly Balance Sheet & Cash Flow Disclosures
- **Half-Yearly vs. Quarterly Reporting:** Under Ind AS, Indian corporations are required to disclose full balance sheets and cash flow statements in half-yearly filings (Q2 ending September and Q4 ending March). For Q1 and Q3, cash flow disclosures are often condensed or omitted.
- **Integrity Rule:** In quarters where cash flow statements are not published, QuarterIQ refuses to extrapolate or invent quarterly CFO/FCF metrics, marking them as `NOT DISCLOSED / N/A`.
