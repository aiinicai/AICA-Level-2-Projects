@echo off
setlocal
cd /d "%~dp0"
echo Launching QuarterIQ Financial Research Terminal...
if exist "release\QuarterIQ\QuarterIQ.exe" (
    start "" "release\QuarterIQ\QuarterIQ.exe"
) else (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 (
        python quarteriq.py
    ) else (
        py -3 quarteriq.py
    )
)
if ERRORLEVEL 1 pause
