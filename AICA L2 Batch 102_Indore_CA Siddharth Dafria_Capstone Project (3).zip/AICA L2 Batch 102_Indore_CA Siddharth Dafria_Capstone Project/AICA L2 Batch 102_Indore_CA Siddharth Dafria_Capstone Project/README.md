# QuarterIQ — AI-Powered Quarterly Results, Forensic Audit & Institutional Equity Research Platform
### ICAI AI Level 2 Capstone Project & Institutional Research Platform (v4.2)

**Principal Architect & Lead Forensic Auditor:** Siddharth Dafria, Chartered Accountant (ICAI)  
**Firm:** Dafria & Co (Chartered Accountants & Institutional Equity Research)  
**Mobile:** +91 9977822290 · **Email:** sdafria@icai.org · **Location:** India  

[![Python](https://img.shields.io/badge/Python-3.10%20%7C%203.11%20%7C%203.14-blue.svg)](https://www.python.org/)
[![GUI](https://img.shields.io/badge/GUI-PySide6%20Qt-green.svg)](https://doc.qt.io/qtforpython-6/)
[![PDF Engine](https://img.shields.io/badge/PDF-ReportLab%20Vector%20Engine-red.svg)](https://www.reportlab.com/)
[![Platform](https://img.shields.io/badge/Platform-Windows%20x64-0078d4.svg)](https://www.microsoft.com/windows)
[![Tests](https://img.shields.io/badge/Tests-70%20Passed%20(100%25)-success.svg)](tests/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 1. Executive Summary

**QuarterIQ** is an institutional financial research, forensic accounting, and automated equity valuation terminal developed by **Siddharth Dafria, Chartered Accountant**. Engineered for statutory auditors, forensic specialists, and buy-side institutional equity research teams, QuarterIQ automates the comprehensive analysis of quarterly financial reports (`Ind AS` & `SEBI LODR`) for public companies listed on the National Stock Exchange of India (NSE) and Bombay Stock Exchange (BSE).

---

## 2. Platform Capabilities (v4.2 Universal Platform)

- **35-Section Master Research Dossier:** Produces exhaustive institutional-grade research dossiers across 6 analytical groups:
  1. *Verdict & Executive Summary* (Conviction Score /10, Target Price, Scenario Model)
  2. *Financial Results & Trends* (13-Quarter Time Series, P&L Waterfall, Segment Mix)
  3. *Forensic Audit & Reliability* (Beneish M-Score, Altman Z-Score, Piotroski F-Score)
  4. *Valuation & Multi-Scenario DCF* (Sensitivity Heatmap, Reverse DCF, Multiples)
  5. *Market Dynamics & Gann Timing* (DMA Technical Bands, Cycle Windows, PEAD)
  6. *Evidence Ledger & Compliance* (Document Manifest, SHA-256 Hashes, CA Review Watermark)
- **Official CA India Institutional Letterhead:** Professional typography, firm header (**Dafria & Co**), and official CA India crest embedded directly in HTML and vector PDF outputs.
- **Dual Vector PDF Export Engine:**
  - *Engine 1:* Pure Python native vector PDF generation via ReportLab (Page 1 cover, key metrics, letterhead branding).
  - *Engine 2:* Headless Chromium / Microsoft Edge high-fidelity PDF printing with `@media print` layout.
- **Four-Pillar Institutional Scoring:**
  - *Pillar A (Readiness):* Data availability, filing timeliness, disclosure completeness.
  - *Pillar B (Fundamentals):* Earnings quality, cash flow conversion (CFO/PAT), RoIC, margins.
  - *Pillar C (Tactical & Momentum):* Earnings surprise beat/miss, RSI, 20/50/200 DMA positioning.
  - *Pillar D (Reliability & Forensics):* Forensic accounting tests, CARO audit notes, auditor qualifications.
- **Dynamic Multi-Sector Profiling:**
  - Automatically identifies sector (Banking, IT Services, Automobile, Pharma, FMCG, Metals, Oil & Gas, Infrastructure) and tailors line items, leadership directories, and ratios (e.g. NII, NIM, GNPA/NNPA for Banks vs. CC Growth, TCV, Attrition for IT).
- **Cryptographic Tamper-Evident Author Protection:**
  - Multi-layer author verification (`Siddharth Dafria, CA · Dafria & Co`) protected by SHA-256 tokens and runtime GUI integrity checks.
- **Offline Self-Contained Output:**
  - Reports render inline SVG charts and embedded Base64 brand assets, functioning 100% offline with zero CDN dependencies.

---

## 3. Quick Start & Execution

### Option A: Running from Python Source

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-username/QuarterIQ.git
   cd QuarterIQ
   ```

2. **Install dependencies:**
   ```powershell
   python -m pip install -r requirements.txt
   ```

3. **Launch the Native Terminal:**
   ```powershell
   python quarteriq.py
   ```
   *(Or double-click `run_windows.bat` on Windows)*

4. **Self-Test Mode (Headless verification):**
   ```powershell
   python quarteriq.py --test-mode
   ```

---

### Option B: Compiling the Standalone Executable

QuarterIQ includes automated packaging scripts to build a portable Windows `.exe` without requiring Python on client workstations:

```powershell
# Build portable distribution folder and ZIP package
python scripts/build_exe.py

# Build single-file standalone executable
python scripts/build_onefile.py
```

The compiled binaries will be placed in `release/` and `%USERPROFILE%\Documents\QuarterIQ_Release\`.

---

## 4. Repository Structure

```
QuarterIQ/
├── src/
│   ├── analyzers/          # Financial extractors, forensic scoring, ratios, valuation, reconciliation
│   ├── assets/             # CA India logo, application icons, base64 embeddings
│   ├── core/               # Constants, models, Indian fiscal dates, branding & tamper protection
│   ├── providers/          # Screener harvester, document discovery, PyMuPDF validator
│   ├── reports/            # 35-section HTML generator, inline SVG charts, vector PDF builder
│   ├── services/           # PDF export service, Excel service, prompt management
│   ├── ui/                 # PySide6 desktop GUI terminal, stylesheets, background workers
│   └── utils/              # Browser launcher, helpers
├── prompts/                # Institutional research prompts & forensic scan templates
├── tests/                  # 70 unit and integration tests (Pytest)
├── scripts/                # Build scripts (build_exe.py, build_onefile.py)
├── assets/                 # Brand assets and icon files
├── quarteriq.py            # Primary desktop application entry point
├── requirements.txt        # Production Python dependencies
├── pyproject.toml          # Project metadata & packaging configuration
├── pytest.ini              # Automated test runner configuration
├── run_windows.bat         # Windows one-click batch launcher
├── LICENSE                 # MIT License (Siddharth Dafria / Dafria & Co)
└── README.md               # Application documentation
```

---

## 5. Automated Quality Control & Testing

QuarterIQ features a comprehensive test suite with 70 unit, forensic, and UI smoke tests:

```powershell
python -m pytest
```

Test coverage includes:
- Multi-sector dynamic profiling (Banking vs IT vs Industrial)
- Forensic accounting algorithms (Beneish M-Score, Altman Z-Score, Piotroski F-Score)
- Cryptographic author branding integrity
- Statement reconciliation arithmetic balance checks
- Offline SVG chart rendering and vector PDF layout generation

---

## 6. Author & Institutional Affiliation

- **Principal Architect & Lead Auditor:** Siddharth Dafria, Chartered Accountant
- **Firm:** Dafria & Co (Chartered Accountants & Institutional Equity Research)
- **Institution:** Institute of Chartered Accountants of India (ICAI)
- **Contact:** M: +91 9977822290 | Email: sdafria@icai.org
