import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.core.models import (
    FinancialMetrics,
    FinancialRatios,
    ForensicFinding,
    ForensicScores,
    ResearchConfig,
)
from src.reports.html_generator import HTMLReportGenerator

BASE_DIR = Path(__file__).resolve().parent.parent
EXAMPLE_DIR = BASE_DIR / "docs" / "example_report"
EXAMPLE_DIR.mkdir(parents=True, exist_ok=True)


def generate_example():
    cfg = ResearchConfig(
        company_symbol="INFY",
        company_name="Infosys Limited",
        reporting_quarter="Q2 FY2026-27",
        financial_year="FY2026-27",
        accounting_basis="Consolidated",
        research_depth="Institutional",
        current_market_price=1890.50,
        price_source="NSE Live",
        output_base_dir=str(EXAMPLE_DIR)
    )

    current_metrics = FinancialMetrics(
        period="Q2 FY2026-27",
        basis="Consolidated",
        revenue=38994.0,
        other_income=842.0,
        total_income=39836.0,
        cogs=0.0,
        employee_cost=21450.0,
        other_expenses=9256.0,
        total_expenses=30706.0,
        ebitda=8288.0,
        depreciation=1120.0,
        ebit=7168.0,
        finance_costs=118.0,
        exceptional_items=0.0,
        pbt=7892.0,
        tax_expense=1524.0,
        pat=6368.0,
        diluted_eps=15.35,
        cfo=7120.0,
        capex=1240.0,
        fcf=5880.0,
        gross_debt=0.0,
        cash_and_equivalents=14250.0,
        net_debt=-14250.0,
        receivables=8410.0,
        inventory=0.0,
        payables=3200.0,
        source_file="INFY_Consolidated_Results_Q2_FY27.pdf",
        source_page="p. 1",
        is_audited=True
    )

    ratios = FinancialRatios(
        period="Q2 FY2026-27",
        revenue_growth_yoy=7.8,
        revenue_growth_qoq=2.4,
        ebitda_margin=21.25,
        pat_margin=16.33,
        eps_growth_yoy=8.1,
        debt_to_ebitda=0.0,
        interest_coverage=60.75,
        cfo_to_ebitda=0.86,
        cfo_to_pat=1.12,
        dso=19.4,
        effective_tax_rate=19.31
    )

    forensic_scores = ForensicScores(
        beneish_m_score=-2.85,
        beneish_flag="LOW_RISK",
        altman_z_score=4.82,
        altman_zone="SAFE",
        piotroski_f_score=8,
        piotroski_rating="STRONG",
        revenue_receivables_divergence=1.2,
        cfo_ebitda_warning=False,
        other_income_excessive=False,
        tax_rate_anomaly=False
    )

    findings = [
        ForensicFinding(
            title="Pristine Cash Conversion (CFO/EBITDA of 0.86x)",
            category="Cash Realization",
            severity="POSITIVE_PASS",
            evidence="Operating cash flow of INR 7,120 Cr represents 0.86x of EBITDA, demonstrating exceptional earnings quality.",
            source_file="INFY_Cash_Flow_Q2_FY27.pdf",
            source_page="p. 3",
            materiality="HIGH",
            alternative_explanation="Consistent working capital turnaround."
        ),
        ForensicFinding(
            title="Debt-Free Balance Sheet with Significant Net Cash",
            category="Solvency",
            severity="POSITIVE_PASS",
            evidence="Zero gross interest-bearing borrowings with cash & liquid treasury reserves exceeding INR 14,250 Cr.",
            source_file="INFY_Balance_Sheet_Q2_FY27.pdf",
            source_page="p. 2",
            materiality="HIGH"
        )
    ]

    manifest = [
        {
            "category": "Financial Results",
            "file_name": "INFY_Consolidated_Results_Q2_FY27.pdf",
            "file_size_bytes": 1845200,
            "sha256": "4a7b98d890e0c1f23b7849e89b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c",
            "verified": True,
            "collected_at": "2026-10-19 22:30:00 IST"
        },
        {
            "category": "Limited Review Report",
            "file_name": "INFY_Statutory_Auditor_Review_Q2_FY27.pdf",
            "file_size_bytes": 945100,
            "sha256": "8f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a",
            "verified": True,
            "collected_at": "2026-10-19 22:31:00 IST"
        },
        {
            "category": "Investor Presentation",
            "file_name": "INFY_Earnings_Deck_Q2_FY27.pdf",
            "file_size_bytes": 3450000,
            "sha256": "1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d",
            "verified": True,
            "collected_at": "2026-10-19 22:32:00 IST"
        }
    ]

    gen = HTMLReportGenerator(EXAMPLE_DIR, cfg)
    out_path = gen.generate_report(
        current_metrics=current_metrics,
        prior_yoy=None,
        prior_qoq=None,
        ratios=ratios,
        forensic_scores=forensic_scores,
        forensic_findings=findings,
        manifest_docs=manifest,
        verdict="ACCUMULATE",
        conviction_score=86
    )
    print(f"Generated verified example report at: {out_path}")
    return out_path


if __name__ == "__main__":
    generate_example()
