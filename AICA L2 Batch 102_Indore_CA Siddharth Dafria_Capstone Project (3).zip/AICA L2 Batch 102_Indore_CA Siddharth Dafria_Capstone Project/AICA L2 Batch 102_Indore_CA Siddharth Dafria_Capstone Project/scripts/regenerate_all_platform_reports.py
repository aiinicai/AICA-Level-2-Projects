"""Batch regenerates all institutional equity research dossiers across QuarterIQ database
with official Dafria & Co letterhead, unclipped vector PDF, inline SVG charts, and clean folder structures.
"""
from datetime import datetime
import json
from pathlib import Path
import sys

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.core.models import ResearchConfig, FinancialMetrics, FinancialRatios, ForensicScores
from src.core.workspace import WorkspaceManager
from src.ui.workers import resolve_verified_financials
from src.reports.html_generator import HTMLReportGenerator
from src.reports.pdf_report_builder import PDFReportBuilder
from src.analyzers.ratios import FinancialRatioEngine
from src.analyzers.scoring_engine import ScoringEngine
from src.analyzers.forensics import ForensicIntelligenceEngine
from src.analyzers.surprise_engine import EarningsSurpriseEngine
from src.analyzers.sector_intelligence import SectorIntelligenceEngine
from src.analyzers.historical_engine import HistoricalIntelligenceEngine
from src.analyzers.historical_analogue import HistoricalAnalogueEngine
from src.analyzers.valuation_engine import ForwardValuationEngine
from src.analyzers.reaction_engine import SharePriceReactionEngine
from src.analyzers.cycle_macro_engine import CycleMacroEngine
from src.analyzers.concall_nlp_engine import ConcallNLPEngine
from src.analyzers.reconciliation import ReconciliationAuditor
from src.analyzers.institutional_scores_engine import InstitutionalScoresEngine
from src.core.indian_fiscal import get_company_sector_profile

ROOT = Path(r"C:\Users\Siddharth Dafria\Documents\QuarterIQ_Research")

DOSSIERS = [
    ("HAVELLS", "Havells India Limited", "Q2 FY2026-27", "FY2026-27", "Q2_Sep_2026", 1820.0),
    ("HAVELLS", "Havells India Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 1820.0),
    ("SBIN", "State Bank of India", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 840.0),
    ("SBIN", "State Bank of India", "Q2 FY2026-27", "FY2026-27", "Q2_Sep_2026", 840.0),
    ("TCS", "Tata Consultancy Services Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 4150.0),
    ("TCS", "Tata Consultancy Services Limited", "Q2 FY2026-27", "FY2026-27", "Q2_Sep_2026", 4150.0),
    ("ICICIBANK", "ICICI Bank Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 1285.0),
    ("ICICIBANK", "ICICI Bank Limited", "Q2 FY2026-27", "FY2026-27", "Q2_Sep_2026", 1285.0),
    ("INFY", "Infosys Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 1890.0),
    ("DLF", "DLF Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 865.0),
    ("DLF", "DLF Limited", "Q2 FY2026-27", "FY2026-27", "Q2_Sep_2026", 865.0),
    ("HCLTECH", "HCL Technologies Limited", "Q3 FY2026-27", "FY2026-27", "Q3_Dec_2026", 1750.0),
]


def process_dossier(sym, name, quarter, fy, folder_quarter, cmp_val):
    period_dir = ROOT / sym / fy / folder_quarter
    if not period_dir.exists():
        return
    
    rep_dir = period_dir / "11_Research_Reports"
    rep_dir.mkdir(parents=True, exist_ok=True)
    
    cfg = ResearchConfig(
        company_symbol=sym,
        company_name=name,
        reporting_quarter=quarter,
        financial_year=fy,
        accounting_basis="Consolidated",
        current_market_price=cmp_val,
        output_base_dir=str(ROOT)
    )
    ws_mgr = WorkspaceManager(cfg)
    
    # Resolve financials
    cur_m, p_yoy, p_qoq, hist_q = resolve_verified_financials(sym, quarter, "Consolidated", period_dir)
    
    # Financial Ratios & Forensics
    ratios = FinancialRatioEngine.calculate_ratios(cur_m, p_yoy)
    forensic_scores, findings = ForensicIntelligenceEngine.evaluate_forensics(cur_m, p_yoy, ratios)
    
    surprise_res = EarningsSurpriseEngine().evaluate_surprise(
        symbol=sym,
        quarter=quarter,
        current_metrics=cur_m,
        prior_yoy=p_yoy,
        prior_qoq=p_qoq,
        hist_quarters=hist_q
    )
    sector_intel = SectorIntelligenceEngine.get_sector_intelligence(
        symbol=sym,
        quarter=quarter,
        current_metrics=cur_m,
        hist_quarters=hist_q
    )
    analogue_res = HistoricalAnalogueEngine.get_analogue_study(sym, quarter)
    val_res = ForwardValuationEngine.get_valuation_study(
        symbol=sym,
        quarter=quarter,
        current_metrics=cur_m,
        reference_price=cmp_val,
        hist_quarters=hist_q
    )
    reaction_res = SharePriceReactionEngine.get_reaction_study(sym, quarter)
    cycle_res = CycleMacroEngine.get_cycle_overlays(sym, quarter)
    
    inst_scores = InstitutionalScoresEngine.evaluate_scores(
        symbol=sym,
        quarter=quarter,
        current_metrics=cur_m,
        ratios=ratios,
        forensic_scores=forensic_scores,
        surprise_score=surprise_res.total_surprise_score if surprise_res else 52,
        reference_price=cmp_val
    )
    
    concall_nlp = ConcallNLPEngine.analyze_concall(
        symbol=sym,
        quarter=quarter,
        workspace_root=period_dir,
        current_metrics=cur_m
    )
    
    manifest_docs = ws_mgr.get_manifest().get("documents", [])
    rec_items = ReconciliationAuditor().audit_metrics(cur_m)
    
    four_pillar_scores = ScoringEngine.compute_scores(
        doc_count=len(manifest_docs),
        verified_doc_count=len([d for d in manifest_docs if d.get("verified", False)]),
        reconciliations=rec_items,
        forensic_flags_count=len([f for f in findings if f.severity in ("RED_FLAG", "AMBER_WARNING")]),
        has_valuation=(val_res is not None),
        has_market_data=(cmp_val > 0),
        current_market_price=cmp_val,
        is_results_unavailable=False,
        financial_metrics=cur_m,
        prior_yoy=p_yoy,
        prior_qoq=p_qoq,
        ratios=ratios,
        surprise_score=surprise_res.total_surprise_score if surprise_res else 52,
        company_symbol=sym,
        forensic_scores=forensic_scores
    )
    
    # 1. Generate Modern v4.2 HTML Report with Dafria & Co Letterhead
    gen = HTMLReportGenerator(period_dir, cfg)
    report_path = gen.generate_report(
        current_metrics=cur_m,
        prior_yoy=p_yoy,
        prior_qoq=p_qoq,
        ratios=ratios,
        forensic_scores=forensic_scores,
        forensic_findings=findings,
        manifest_docs=manifest_docs,
        historical_quarters=hist_q,
        inflection_signals=[],
        surprise_result=surprise_res,
        sector_intel=sector_intel,
        analogue_result=analogue_res,
        valuation_result=val_res,
        reaction_result=reaction_res,
        cycle_result=cycle_res,
        verdict=four_pillar_scores.fundamental_direction,
        conviction_score=four_pillar_scores.score_b_fundamental,
        institutional_scores=inst_scores,
        concall_nlp=concall_nlp,
        is_results_unavailable=False,
        auto_open=False
    )
    
    # 2. Build Institutional Vector PDF with Official CA Letterhead
    pdf_path = rep_dir / f"{sym}_{quarter.replace(' ', '_')}_Research.pdf"
    PDFReportBuilder.build_institutional_pdf(
        output_pdf_path=pdf_path,
        config=cfg,
        metrics=cur_m,
        prior_yoy=p_yoy,
        prior_qoq=p_qoq,
        ratios=ratios,
        scores=four_pillar_scores,
        historical_quarters=hist_q,
        manifest_docs=manifest_docs,
        workspace_root=period_dir
    )
    
    # 3. Prune empty folders (preserving only necessary document folders)
    ws_mgr.prune_empty_folders()
    
    print(f"  [SUCCESS] {sym} ({quarter}): HTML ({report_path.stat().st_size:,} B) & PDF ({pdf_path.stat().st_size:,} B)")


def main():
    print("=== STARTING COMPLETE REGENERATION OF ALL PLATFORM DOSSIERS ===")
    for item in DOSSIERS:
        try:
            process_dossier(*item)
        except Exception as e:
            print(f"Error processing {item[0]} {item[2]}: {e}")
    print("\n=== COMPLETE REGENERATION OF ALL PLATFORM DOSSIERS FINISHED ===")


if __name__ == "__main__":
    main()
