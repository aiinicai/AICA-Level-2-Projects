"""Automated PyInstaller Build and Verification Script for QuarterIQ Windows Executable.
ICAI AI Capstone — QuarterIQ v4.2
Author: Siddharth Dafria, Chartered Accountant
Firm: Dafria & Co (Chartered Accountants & Institutional Equity Research)
"""
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RELEASE_DIR = BASE_DIR / "release"
BUILD_DIR = BASE_DIR / "build"
DOCS_RELEASE_DIR = Path.home() / "Documents" / "QuarterIQ_Release"

EXCLUDED_MODULES = [
    "torch", "torchvision", "torchaudio", "scipy", "spacy", "transformers",
    "cv2", "matplotlib", "nltk", "tornado", "jupyter", "IPython", "bokeh",
    "safetensors", "sympy", "tensorboard", "thinc", "seaborn", "altair",
    "streamlit", "optuna", "sklearn", "weasel", "cymem", "preshed", "blis",
    "selenium", "playwright", "huggingface_hub", "tokenizers", "pyarrow",
    "pytest", "_pytest", "iniconfig", "pluggy"
]


def build_executable():
    print("=" * 70)
    print("=== [QuarterIQ v4.2] Standalone Windows Executable Build Pipeline ===")
    print(f"Project root:  {BASE_DIR}")
    print(f"Release dir:   {RELEASE_DIR}")
    print(f"User docs dir: {DOCS_RELEASE_DIR}")
    print("=" * 70)

    # 1. Clean previous build artifact for QuarterIQ_v4.2 if it exists
    app_output_dir = RELEASE_DIR / "QuarterIQ_v4.2"
    if app_output_dir.exists():
        try:
            shutil.rmtree(app_output_dir)
            print(f"[CLEAN] Removed existing build directory: {app_output_dir}")
        except Exception as e:
            print(f"[WARN] Could not remove existing build directory ({e}), building in-place.")

    RELEASE_DIR.mkdir(parents=True, exist_ok=True)
    DOCS_RELEASE_DIR.mkdir(parents=True, exist_ok=True)

    # 2. Prepare Icon
    icon_path = BASE_DIR / "src" / "assets" / "quarteriq.ico"
    if not icon_path.exists():
        try:
            from PIL import Image
            png_logo = BASE_DIR / "src" / "assets" / "ca_india_logo.png"
            if png_logo.exists():
                img = Image.open(png_logo)
                size = max(img.size)
                sq = Image.new("RGBA", (size, size), (255, 255, 255, 0))
                sq.paste(img, ((size - img.width) // 2, (size - img.height) // 2))
                sq.save(icon_path, format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
                print(f"[ICON] Generated application icon: {icon_path}")
        except Exception as ie:
            print(f"[ICON] Notice: Icon generation skipped ({ie}).")

    # 3. Assemble PyInstaller command
    cmd = [
        sys.executable,
        "-m", "PyInstaller",
        "--noconfirm",
        "--onedir",
        "--windowed",
        "--name", "QuarterIQ_v4.2",
        "--distpath", str(RELEASE_DIR),
        "--workpath", str(BUILD_DIR),
        "--collect-all", "reportlab",
        "--add-data", f"{str(BASE_DIR / 'prompts')};prompts",
        "--add-data", f"{str(BASE_DIR / 'src')};src",
    ]

    if icon_path.exists():
        cmd.extend(["--icon", str(icon_path)])

    for mod in EXCLUDED_MODULES:
        cmd.extend(["--exclude-module", mod])

    cmd.append(str(BASE_DIR / "quarteriq.py"))

    print(f"\n[BUILD] Executing PyInstaller command...")
    res = subprocess.run(cmd, cwd=str(BASE_DIR))
    if res.returncode != 0:
        print(f"ERROR: PyInstaller build failed with exit code {res.returncode}")
        sys.exit(res.returncode)

    primary_exe = app_output_dir / "QuarterIQ_v4.2.exe"
    standard_exe = app_output_dir / "QuarterIQ.exe"

    if not primary_exe.exists():
        print(f"ERROR: Expected executable not found at {primary_exe}")
        sys.exit(1)

    # Create standard-named alias in the same folder
    try:
        shutil.copy2(primary_exe, standard_exe)
        print(f"[ALIAS] Created standard executable alias: {standard_exe}")
    except Exception as ce:
        print(f"[ALIAS] Notice: Could not copy alias: {ce}")

    # Add quick launcher batch file in the app directory
    batch_launcher = app_output_dir / "Launch_QuarterIQ.bat"
    batch_launcher.write_text(
        "@echo off\r\nstart \"\" \"%~dp0QuarterIQ.exe\"\r\nexit\r\n",
        encoding="utf-8"
    )

    # Add professional README in the app directory
    readme_path = app_output_dir / "README_QUARTERIQ.txt"
    readme_path.write_text(
        "================================================================================\r\n"
        "QuarterIQ v4.2 — Institutional Financial Research & Forensic Audit Terminal\r\n"
        "================================================================================\r\n"
        "Principal Architect & Lead Forensic Auditor:\r\n"
        "  Siddharth Dafria, Chartered Accountant (ICAI)\r\n"
        "  Dafria & Co (Chartered Accountants & Institutional Equity Research)\r\n"
        "  Contact: M: +91 9977822290 | Email: sdafria@icai.org\r\n\r\n"
        "PORTABLE STANDALONE APPLICATION:\r\n"
        "This package is completely self-contained. It contains its own embedded\r\n"
        "Python runtime, PySide6 GUI engine, vector PDF generator, forensic audit\r\n"
        "modules, and official CA India branding.\r\n\r\n"
        "No Python installation, administrator privileges, or developer tools\r\n"
        "are required on the destination PC.\r\n\r\n"
        "HOW TO RUN:\r\n"
        "  Double-click 'QuarterIQ.exe' or 'Launch_QuarterIQ.bat'.\r\n\r\n"
        "OUTPUT DOSSIERS:\r\n"
        "  Generated research dossiers, verified HTML terminals, and vector PDFs\r\n"
        "  are saved to:\r\n"
        "  %USERPROFILE%\\Documents\\QuarterIQ_Research\\\r\n"
        "================================================================================\r\n",
        encoding="utf-8"
    )

    exe_size_mb = primary_exe.stat().st_size / (1024 * 1024)
    print(f"\n[SUCCESS] Generated executable at: {primary_exe} ({exe_size_mb:.2f} MB)")

    # 4. Self-test: Launch executable in test mode
    print("\n" + "=" * 70)
    print("=== [QuarterIQ] Verifying Generated Executable Startup ===")
    print("=" * 70)
    test_cmd = [str(primary_exe), "--test-mode"]
    print(f"Executing: {' '.join(test_cmd)}")
    try:
        test_res = subprocess.run(test_cmd, capture_output=True, text=True, timeout=30)
        print("STDOUT:", test_res.stdout)
        print("STDERR:", test_res.stderr)
        print("Exit code:", test_res.returncode)

        if test_res.returncode == 0 and "Self-test mode" in test_res.stdout:
            print("[PASS] Generated Windows executable verified successfully in isolated runtime!")
        else:
            print("[WARN] Test run returned non-zero or unexpected output.")
    except Exception as oe:
        print(f"[NOTE] Automated subshell launch note: {oe}")
        print(f"[INFO] Executable binary is intact at {primary_exe}")

    # 5. Create Standalone Distribution Zip Archive
    print("\n" + "=" * 70)
    print("=== [QuarterIQ] Packaging Portable Distribution Archive ===")
    print("=" * 70)
    zip_target = RELEASE_DIR / "QuarterIQ_v4.2_Windows_x64.zip"
    docs_zip_target = DOCS_RELEASE_DIR / "QuarterIQ_v4.2_Windows_x64.zip"

    print(f"Compressing {app_output_dir} -> {zip_target}...")
    with zipfile.ZipFile(zip_target, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(app_output_dir):
            for file in files:
                file_path = Path(root) / file
                archive_name = file_path.relative_to(app_output_dir.parent)
                zf.write(file_path, str(archive_name))

    zip_size_mb = zip_target.stat().st_size / (1024 * 1024)
    print(f"[ZIP COMPLETED] {zip_target} ({zip_size_mb:.2f} MB)")

    # Copy zip to User's Documents\QuarterIQ_Release
    try:
        shutil.copy2(zip_target, docs_zip_target)
        print(f"[DEPLOY] Copied distribution archive to: {docs_zip_target}")
    except Exception as dze:
        print(f"[DEPLOY] Notice: {dze}")

    print("\n" + "=" * 70)
    print("=== [SUMMARY] QuarterIQ v4.2 Build Complete & Ready to Send ===")
    print(f"1. Portable Application Folder: {app_output_dir}")
    print(f"2. Primary Executable:          {primary_exe}")
    print(f"3. Distribution Archive (Zip):  {zip_target}")
    print(f"4. User Documents Archive:      {docs_zip_target}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    build_executable()
