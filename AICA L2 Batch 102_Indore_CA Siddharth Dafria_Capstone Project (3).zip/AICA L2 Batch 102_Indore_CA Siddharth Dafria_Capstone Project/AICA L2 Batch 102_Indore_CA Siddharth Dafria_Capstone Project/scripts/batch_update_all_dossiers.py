from datetime import datetime
import json
import os
from pathlib import Path
import re
import sys

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.core.branding import (
    render_institutional_letterhead_html,
    AUTHOR_MOBILE,
    AUTHOR_EMAIL,
    AUTHOR_ORGANIZATION,
    AUTHOR_NAME,
    FIRM_NAME,
    FIRM_TITLE,
    FIRM_SUBTITLE,
)
from src.core.constants import IST
from src.core.models import ResearchConfig, FinancialMetrics
from src.core.indian_fiscal import get_company_sector_profile
from src.reports.pdf_report_builder import PDFReportBuilder

ROOT = Path(r"C:\Users\Siddharth Dafria\Documents\QuarterIQ_Research")

LETTERHEAD_CSS = """
        /* Institutional Letterhead (Screen Styles) */
        .institutional-letterhead {
            background: linear-gradient(135deg, #090e1a 0%, #111a33 50%, #0d1e38 100%);
            border: 2px solid #2563eb;
            border-radius: 12px;
            padding: 20px 24px;
            margin-bottom: 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }
        .letterhead-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }
        .letterhead-crest-box {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .ca-crest-emblem {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, #38bdf8, #2563eb);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 20px;
            color: #ffffff;
            box-shadow: 0 0 16px rgba(56, 189, 248, 0.5);
            border: 2px solid #60a5fa;
            flex-shrink: 0;
        }
        .crest-details .firm-title {
            font-size: 1.35rem;
            font-weight: 900;
            color: #f8fafc;
            letter-spacing: 0.5px;
            margin: 0 0 2px 0;
        }
        .crest-details .firm-subtitle {
            font-size: 0.78rem;
            font-weight: 800;
            color: #38bdf8;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .crest-details .firm-affiliations {
            font-size: 0.74rem;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        .crest-details .firm-affiliations .sep { color: #475569; }
        .letterhead-contacts {
            display: flex;
            flex-direction: column;
            gap: 4px;
            font-size: 0.75rem;
            color: #cbd5e1;
            background: rgba(30, 41, 59, 0.6);
            padding: 8px 14px;
            border-radius: 8px;
            border: 1px solid #334155;
            text-align: right;
        }
        .letterhead-contacts .contact-item strong { color: #38bdf8; }
        .letterhead-divider {
            height: 2px;
            background: linear-gradient(90deg, #2563eb, #38bdf8, #10b981);
            margin: 14px 0;
            border-radius: 2px;
        }
        .letterhead-meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 14px;
            font-size: 0.76rem;
            color: #cbd5e1;
        }
        .letterhead-meta-grid .meta-col {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .letterhead-meta-grid .m-lbl {
            color: #94a3b8;
            font-weight: 700;
            font-size: 0.68rem;
            letter-spacing: 0.5px;
            display: inline-block;
            width: 110px;
        }
        .letterhead-meta-grid .m-val {
            color: #f8fafc;
        }
        .letterhead-meta-grid .m-val.monospace {
            font-family: monospace;
            color: #38bdf8;
        }
        .letterhead-meta-grid .compliance-col {
            background: rgba(15, 23, 42, 0.7);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 6px;
            padding: 8px 10px;
        }
        .letterhead-meta-grid .compliance-badge {
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            border: 1px solid #f59e0b;
            border-radius: 4px;
            font-size: 0.68rem;
            font-weight: 900;
            padding: 2px 6px;
            display: inline-block;
            margin-bottom: 4px;
            letter-spacing: 0.5px;
        }
        .letterhead-meta-grid .compliance-note {
            font-size: 0.68rem;
            color: #94a3b8;
            line-height: 1.35;
        }

        /* Light Theme Institutional Letterhead Overrides */
        body.light-theme .institutional-letterhead {
            background: #ffffff !important;
            border: 2px solid #0f172a !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08) !important;
            color: #0f172a !important;
        }
        body.light-theme .institutional-letterhead .ca-crest-emblem {
            background: linear-gradient(135deg, #1e3a8a, #2563eb) !important;
            color: #ffffff !important;
            box-shadow: 0 0 12px rgba(37, 99, 235, 0.3) !important;
        }
        body.light-theme .institutional-letterhead .firm-title {
            color: #0f172a !important;
        }
        body.light-theme .institutional-letterhead .firm-subtitle {
            color: #1e3a8a !important;
        }
        body.light-theme .institutional-letterhead .firm-affiliations {
            color: #475569 !important;
        }
        body.light-theme .institutional-letterhead .letterhead-contacts {
            background: #f8fafc !important;
            border-color: #cbd5e1 !important;
            color: #0f172a !important;
        }
        body.light-theme .institutional-letterhead .letterhead-contacts .contact-item strong {
            color: #1e3a8a !important;
        }
        body.light-theme .institutional-letterhead .letterhead-divider {
            background: #1e3a8a !important;
        }
        body.light-theme .institutional-letterhead .letterhead-meta-grid {
            color: #0f172a !important;
        }
        body.light-theme .institutional-letterhead .m-lbl {
            color: #475569 !important;
        }
        body.light-theme .institutional-letterhead .m-val {
            color: #0f172a !important;
        }
        body.light-theme .institutional-letterhead .m-val.monospace {
            color: #1e3a8a !important;
        }
        body.light-theme .institutional-letterhead .compliance-col {
            background: #fffbeb !important;
            border: 1px solid #d97706 !important;
        }
        body.light-theme .institutional-letterhead .compliance-badge {
            background: #fef3c7 !important;
            color: #b45309 !important;
            border-color: #f59e0b !important;
        }
        body.light-theme .institutional-letterhead .compliance-note {
            color: #92400e !important;
        }
"""

PRINT_LETTERHEAD_CSS = """
            /* 3. Executive Letterhead print formatting */
            .institutional-letterhead {
                display: block !important;
                width: 100% !important;
                max-width: 100% !important;
                box-sizing: border-box !important;
                background: #f8fafc !important;
                border: 2px solid #0f172a !important;
                border-radius: 6px !important;
                padding: 12px 16px !important;
                margin-bottom: 14px !important;
                page-break-inside: avoid !important;
                break-inside: avoid !important;
                color: #0f172a !important;
            }
            .institutional-letterhead .ca-crest-emblem {
                background: #1e3a8a !important;
                color: #ffffff !important;
            }
            .institutional-letterhead .firm-title {
                color: #0f172a !important;
                font-size: 15pt !important;
                font-weight: 900 !important;
            }
            .institutional-letterhead .firm-subtitle {
                color: #1e3a8a !important;
                font-size: 8.5pt !important;
                font-weight: 800 !important;
            }
            .institutional-letterhead .firm-affiliations {
                color: #475569 !important;
            }
            .institutional-letterhead .letterhead-contacts {
                background: #f1f5f9 !important;
                border-color: #cbd5e1 !important;
                color: #0f172a !important;
            }
            .institutional-letterhead .letterhead-contacts .contact-item strong {
                color: #1e3a8a !important;
            }
            .institutional-letterhead .letterhead-divider {
                background: #0f172a !important;
                height: 2px !important;
                margin: 8px 0 !important;
            }
            .institutional-letterhead .letterhead-meta-grid {
                color: #0f172a !important;
            }
            .institutional-letterhead .m-lbl {
                color: #475569 !important;
                font-size: 7.5pt !important;
            }
            .institutional-letterhead .m-val {
                color: #0f172a !important;
                font-size: 8pt !important;
            }
            .institutional-letterhead .m-val.monospace {
                color: #1e3a8a !important;
            }
            .institutional-letterhead .compliance-col {
                background: #fef3c7 !important;
                border: 1px solid #f59e0b !important;
            }
            .institutional-letterhead .compliance-badge {
                background: #b45309 !important;
                color: #ffffff !important;
                font-size: 7pt !important;
                font-weight: 800 !important;
                padding: 2px 6px !important;
            }
            .institutional-letterhead .compliance-note {
                color: #78350f !important;
                font-size: 7pt !important;
            }
"""

def update_dossier(rep_dir: Path):
    html_files = [f for f in rep_dir.glob("*.html") if not f.name.endswith("_BACKUP.html")]
    if not html_files:
        return
    
    html_file = html_files[0]
    parts = html_file.stem.split("_")
    sym = parts[0].upper()
    
    # Infer Quarter string (e.g. Q2 FY2026-27 or Q3 FY2026-27)
    if len(parts) >= 3 and parts[1].startswith("Q"):
        q = f"{parts[1]} {parts[2]}"
    else:
        q = "Q2 FY2026-27"
        
    profile = get_company_sector_profile(sym)
    company_name = profile.get("company_name", sym)
    sector_name = profile.get("sector_name", "Equity Research")
    bse_code = profile.get("bse_code", "")
    isin = profile.get("isin", "")
    now_ist = datetime.now(IST).strftime("%d-%b-%Y %H:%M IST")

    print(f"\nProcessing {sym} ({q})...")

    # 1. Update HTML Report
    html_content = html_file.read_text(encoding="utf-8")
    modified = False

    # Ensure CSS is present
    if ".institutional-letterhead" not in html_content:
        # Insert LETTERHEAD_CSS before </style>
        if "</style>" in html_content:
            html_content = html_content.replace("</style>", LETTERHEAD_CSS + "\n</style>", 1)
            modified = True

    # Ensure Print CSS is present
    if ".institutional-letterhead .ca-crest-emblem" not in html_content:
        idx_print = html_content.find("@media print")
        if idx_print != -1:
            idx_brace = html_content.find("{", idx_print)
            if idx_brace != -1:
                html_content = html_content[:idx_brace+1] + "\n" + PRINT_LETTERHEAD_CSS + "\n" + html_content[idx_brace+1:]
                modified = True

    # Ensure Letterhead HTML is present
    letterhead_html = render_institutional_letterhead_html(
        company_name=company_name,
        symbol=sym,
        quarter=q,
        sector=sector_name,
        bse_code=bse_code,
        isin=isin,
        now_ist=now_ist
    )

    if "ca-institutional-letterhead" not in html_content:
        # Insert at top of <main class="content"> or <main>
        if '<main class="content">' in html_content:
            html_content = html_content.replace('<main class="content">', f'<main class="content">\n{letterhead_html}\n', 1)
            modified = True
        elif '<main>' in html_content:
            html_content = html_content.replace('<main>', f'<main>\n{letterhead_html}\n', 1)
            modified = True
        elif '<div class="content">' in html_content:
            html_content = html_content.replace('<div class="content">', f'<div class="content">\n{letterhead_html}\n', 1)
            modified = True
    else:
        # Replace existing letterhead with updated Dafria & Co version
        lh_pattern = r'<div id="ca-institutional-letterhead".*?</div>\s*</div>\s*</div>'
        html_content = re.sub(lh_pattern, letterhead_html.strip(), html_content, flags=re.DOTALL)
        modified = True

    # Clean legacy branding text
    if "Siddharth Dafria &amp; Associates" in html_content:
        html_content = html_content.replace("Siddharth Dafria &amp; Associates", "Dafria &amp; Co")
        modified = True
    if "SIDDHARTH DAFRIA &amp; ASSOCIATES" in html_content:
        html_content = html_content.replace("SIDDHARTH DAFRIA &amp; ASSOCIATES", "DAFRIA &amp; CO")
        modified = True

    if modified:
        html_file.write_text(html_content, encoding="utf-8")
        print(f"  [HTML] Successfully updated with CA Letterhead: {html_file.name}")

    # 2. Build / Update Institutional Vector PDF with Official CA Letterhead
    pdf_path = rep_dir / f"{sym}_{q.replace(' ', '_')}_Research.pdf"
    cfg = ResearchConfig(
        company_symbol=sym,
        company_name=company_name,
        reporting_quarter=q,
        financial_year="FY2026-27",
        accounting_basis="Consolidated",
        current_market_price=profile.get("reference_price", 1000.0) or 1000.0,
        output_base_dir=str(ROOT)
    )

    try:
        PDFReportBuilder.build_institutional_pdf(
            output_pdf_path=pdf_path,
            config=cfg,
            workspace_root=rep_dir.parent
        )
        print(f"  [PDF] Successfully built vector PDF with CA Letterhead: {pdf_path.name} ({pdf_path.stat().st_size:,} bytes)")
    except Exception as pe:
        print(f"  [PDF Error] Could not compile PDF for {sym}: {pe}")


def main():
    print(f"=== BATCH UPGRADING ALL RESEARCH REPORTS WITH DAFRIA & CO LETTERHEAD ===")
    count = 0
    for comp_dir in sorted(ROOT.iterdir()):
        if not comp_dir.is_dir():
            continue
        for fy_dir in sorted(comp_dir.iterdir()):
            if not fy_dir.is_dir():
                continue
            for q_dir in sorted(fy_dir.iterdir()):
                if not q_dir.is_dir():
                    continue
                rep_dir = q_dir / "11_Research_Reports"
                if rep_dir.exists():
                    update_dossier(rep_dir)
                    count += 1
    print(f"\nCompleted batch processing across {count} dossier periods!")


if __name__ == "__main__":
    main()
