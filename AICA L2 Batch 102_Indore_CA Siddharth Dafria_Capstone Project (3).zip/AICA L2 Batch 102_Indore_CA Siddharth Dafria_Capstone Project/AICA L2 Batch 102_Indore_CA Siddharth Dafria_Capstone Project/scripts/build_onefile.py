"""Automated PyInstaller Build for Standalone Single-File QuarterIQ Executable.
ICAI AI Capstone — QuarterIQ v4.2
Author: Siddharth Dafria, Chartered Accountant
Firm: Dafria & Co (Chartered Accountants & Institutional Equity Research)
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RELEASE_DIR = BASE_DIR / "release"
BUILD_DIR = BASE_DIR / "build"
DOCS_RELEASE_DIR = Path.home() / "Documents" / "QuarterIQ_Release"

EXCLUDED_MODULES = [
    "torch", "torchvision", "torchaudio", "scipy", "spacy", "transformers",
    "cv2", "matplotlib", "nltk", "tornado", "jupyter", "IPython", "bokeh",
    "safetensors", "sympy", "tensorboard", "thinc", "seaborn", "altair",
    "streamlit", "optuna", "sklearn", "weasel", "cymem", "preshed", "blis",
    "selenium", "playwright", "huggingface_hub", "tokenizers", "pyarrow",
    "pytest", "_pytest", "iniconfig", "pluggy"
]


def build_onefile_executable():
    print("=" * 70)
    print("=== [QuarterIQ v4.2] Building Single-File Standalone Executable ===")
    print(f"Target:        QuarterIQ_Standalone_v4.2.exe")
    print(f"Release dir:   {RELEASE_DIR}")
    print(f"User docs dir: {DOCS_RELEASE_DIR}")
    print("=" * 70)

    RELEASE_DIR.mkdir(parents=True, exist_ok=True)
    DOCS_RELEASE_DIR.mkdir(parents=True, exist_ok=True)

    icon_path = BASE_DIR / "src" / "assets" / "quarteriq.ico"

    cmd = [
        sys.executable,
        "-m", "PyInstaller",
        "--noconfirm",
        "--onefile",
        "--windowed",
        "--name", "QuarterIQ_v4.2_Standalone",
        "--distpath", str(RELEASE_DIR),
        "--workpath", str(BUILD_DIR),
        "--collect-all", "reportlab",
        "--add-data", f"{str(BASE_DIR / 'prompts')};prompts",
        "--add-data", f"{str(BASE_DIR / 'src')};src",
    ]

    if icon_path.exists():
        cmd.extend(["--icon", str(icon_path)])

    for mod in EXCLUDED_MODULES:
        cmd.extend(["--exclude-module", mod])

    cmd.append(str(BASE_DIR / "quarteriq.py"))

    print("\n[BUILD] Invoking PyInstaller --onefile...")
    res = subprocess.run(cmd, cwd=str(BASE_DIR))
    if res.returncode != 0:
        print(f"ERROR: PyInstaller --onefile failed with exit code {res.returncode}")
        sys.exit(res.returncode)

    onefile_exe = RELEASE_DIR / "QuarterIQ_v4.2_Standalone.exe"
    if not onefile_exe.exists():
        print(f"ERROR: Expected onefile executable not found at {onefile_exe}")
        sys.exit(1)

    size_mb = onefile_exe.stat().st_size / (1024 * 1024)
    print(f"\n[SUCCESS] Single-File Executable Created: {onefile_exe} ({size_mb:.2f} MB)")

    # Copy to user's Documents\QuarterIQ_Release
    docs_onefile = DOCS_RELEASE_DIR / "QuarterIQ_v4.2_Standalone.exe"
    try:
        shutil.copy2(onefile_exe, docs_onefile)
        print(f"[DEPLOY] Copied single-file executable to: {docs_onefile}")
    except Exception as e:
        print(f"[DEPLOY] Notice: {e}")

    # Self-test the single-file executable
    print("\n=== [QuarterIQ] Smoke Testing Single-File Executable ===")
    test_cmd = [str(onefile_exe), "--test-mode"]
    print(f"Executing: {' '.join(test_cmd)}")
    try:
        test_res = subprocess.run(test_cmd, capture_output=True, text=True, timeout=45)
        print("STDOUT:", test_res.stdout)
        print("STDERR:", test_res.stderr)
        print("Exit code:", test_res.returncode)

        if test_res.returncode == 0 and "Self-test mode" in test_res.stdout:
            print("[PASS] Standalone single-file executable verified 100% operational!")
        else:
            print("[WARN] Test run finished with code", test_res.returncode)
    except Exception as te:
        print(f"[NOTE] Test note: {te}")

    print("\n" + "=" * 70)
    print("=== Standalone Single-File Executable Ready to Send! ===")
    print(f"File: {onefile_exe}")
    print(f"Documents Copy: {docs_onefile}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    build_onefile_executable()
