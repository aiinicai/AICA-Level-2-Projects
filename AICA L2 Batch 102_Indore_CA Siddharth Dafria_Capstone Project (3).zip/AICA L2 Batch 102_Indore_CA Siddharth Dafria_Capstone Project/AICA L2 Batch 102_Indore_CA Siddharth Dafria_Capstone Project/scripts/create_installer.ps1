# QuarterIQ - Windows Installer & Distribution Packager
$BaseDir = Split-Path -Parent $PSScriptRoot
$ReleaseDir = Join-Path $BaseDir "release"
$AppDir = Join-Path $ReleaseDir "QuarterIQ"
$ZipTarget = Join-Path $ReleaseDir "QuarterIQ_v4.2_Windows_x64.zip"

Write-Host "=== Packaging QuarterIQ Distribution ===" -ForegroundColor Cyan
if (-not (Test-Path $AppDir)) {
    Write-Error "Release directory not found at $AppDir. Run build_exe.py first."
    exit 1
}

if (Test-Path $ZipTarget) {
    Remove-Item -Path $ZipTarget -Force
}

Write-Host "Creating compressed archive: $ZipTarget..." -ForegroundColor Yellow
Compress-Archive -Path "$AppDir\*" -DestinationPath $ZipTarget -CompressionLevel Optimal

$ZipInfo = Get-Item $ZipTarget
Write-Host "Distribution archive created: $($ZipInfo.FullName) ($([math]::Round($ZipInfo.Length / 1MB, 2)) MB)" -ForegroundColor Green
Write-Host "Ready for standalone Windows deployment." -ForegroundColor Green
