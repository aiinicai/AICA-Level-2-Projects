# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('C:/Users/Siddharth Dafria/.gemini/antigravity/scratch/QuarterIQ/prompts', 'prompts'), ('C:/Users/Siddharth Dafria/.gemini/antigravity/scratch/QuarterIQ/src', 'src')]
binaries = []
hiddenimports = []
tmp_ret = collect_all('reportlab')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/Users/Siddharth Dafria/.gemini/antigravity/scratch/QuarterIQ/quarteriq.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['torch', 'torchvision', 'torchaudio', 'scipy', 'spacy', 'transformers', 'cv2', 'matplotlib', 'nltk', 'tornado', 'jupyter', 'IPython', 'bokeh', 'safetensors', 'sympy', 'tensorboard', 'thinc', 'seaborn', 'altair', 'streamlit', 'optuna', 'sklearn', 'weasel', 'cymem', 'preshed', 'blis', 'selenium', 'playwright', 'huggingface_hub', 'tokenizers', 'pyarrow', 'pytest', '_pytest', 'iniconfig', 'pluggy'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='QuarterIQ_v4.2',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/Users/Siddharth Dafria/.gemini/antigravity/scratch/QuarterIQ/src/assets/quarteriq.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='QuarterIQ_v4.2',
)
