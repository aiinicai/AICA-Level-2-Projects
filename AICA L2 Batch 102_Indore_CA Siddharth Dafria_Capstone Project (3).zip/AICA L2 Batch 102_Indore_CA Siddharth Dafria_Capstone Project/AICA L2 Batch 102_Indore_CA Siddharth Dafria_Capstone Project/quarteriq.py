"""QuarterIQ: AI-Powered Quarterly Results, Forensic Audit & Institutional Equity Research Platform.
ICAI AI Level 2 Capstone Project.
"""
import argparse
import os
import sys
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from src.core.constants import APP_NAME, APP_SUBTITLE, APP_VERSION
from src.ui.main_window import QuarterIQMainWindow


def main():
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{APP_VERSION} — {APP_SUBTITLE}")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {APP_VERSION}")
    parser.add_argument("--test-mode", action="store_true", help="Launch in self-test mode and exit cleanly.")
    args, unknown = parser.parse_known_args()

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("ICAI AI Capstone")

    window = QuarterIQMainWindow()

    if args.test_mode:
        print(f"[{APP_NAME}] Self-test mode: Window instantiated successfully. Exiting code 0.")
        window.close()
        return 0

    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
