# QuarterIQ — ICAI AI Level 2 Capstone Presentation & Defense Guide
## 5-Minute Demonstration Script & Technical Defense for Capstone Examiners

---

## 1. Executive Project Summary (30 Seconds)
- **Title:** QuarterIQ — AI-Powered Quarterly Results, Forensic Audit & Institutional Equity Research Platform
- **Candidate:** Siddharth Dafria (Chartered Accountant / AI Level 2 Candidate)
- **Problem Statement:** Institutional equity research and forensic audits require 8–15 hours of manual document collation, Ind AS statement re-keying, arithmetic checks, and ratio analysis. General-purpose LLMs hallucinate numbers, confuse consolidated vs. standalone results, and fail to provide verifiable audit trails.
- **Solution:** QuarterIQ is a Windows desktop application that automates listed company document discovery, creates an auditable 12-subfolder cryptographic workspace, runs deterministic CA forensic models in pure Python, and interfaces with AI models under strict zero-fabrication constraints to generate offline interactive HTML research dashboards.

---

## 2. Five-Minute Live Demonstration Script (Step-by-Step)

### Minute 1:00 — Workspace Initialization & Fiscal Logic
1. Launch `QuarterIQ.exe` from the desktop or release folder.
2. Under **New Research**, search for `INFY` or `TATASTEEL` in the autocomplete directory.
3. Select **Q2 FY2026-27**. Point out the **SEBI Filing Window Status** badge:
   > *"Notice how the system checks the current date against SEBI LODR Regulation 33. For Q2 ended September 30, it informs the user that earnings season is active and the 45-day filing window extends to mid-November."*
4. Click **Create & Initialize Research Workspace**.
5. Switch to Windows Explorer or click **Open Company Folder**:
   > *"QuarterIQ has automatically created the 12 standard audit subdirectories, initialized `source_manifest.json`, CSV records, and timestamped audit logs."*

### Minute 2:00 — Document Discovery, Downloading & Verification
1. Navigate to **Document Collection**.
2. Highlight the official exchange portals (NSE Financial Results, NSE Announcements, BSE Results, Screener, Trendlyne, Company IR).
3. Demonstrate direct URL downloading or click **Import Downloaded Files** to import sample quarterly filing PDFs into `01_Financial_Results`.
4. Switch to **Document Library** and click **Verify All Documents with PyMuPDF**:
   > *"QuarterIQ computes SHA-256 digests for every filing and runs PyMuPDF text validation to ensure the PDF entity name, quarter date, and statutory auditor review report signatures match the active session. If an analyst accidentally imports a Q1 filing or a different company's results, it triggers an immediate amber or red anomaly flag."*

### Minute 3:00 — Deterministic Financial Extraction & Reconciliation
1. Navigate to **Financial Analysis** and click **Extract Statements & Calculate Ratios**:
   > *"The system extracts Ind AS line items—Revenue, EBITDA, PBT, Tax, PAT, Diluted EPS, CFO, and Gross Debt—and normalizes all figures to INR Crore (`INR Cr`). Unlike LLMs which perform approximate math, QuarterIQ computes YoY growth, EBITDA margins, and working capital days using deterministic Python functions."*
2. Highlight the **Statement Arithmetic Reconciliation Ledger**:
   > *"Every financial equation is validated: Revenue + Other Income == Total Income; PBT - Tax == PAT. If an arithmetic discrepancy or unexplained one-off occurs, the system logs an explicit variance rather than silently fudging the balance."*

### Minute 4:00 — CA Forensic Intelligence & Anomaly Scoring
1. Navigate to **Forensic Intelligence**:
   > *"This tab runs institutional forensic accounting checks:
   > - **Revenue vs. Receivables Growth Divergence:** Identifies potential channel stuffing or aggressive revenue recognition if receivables outpace sales by >15%.
   > - **Quality of Earnings (CFO / EBITDA):** Flags any company where operating cash flow is less than 0.8x of reported EBITDA.
   > - **Beneish M-Score & Altman Z-Score:** Calculates classical statistical models with explicit formulas and safe/distress thresholds.
   > - **Piotroski F-Score:** Computes fundamental financial health out of 9 points."*

### Minute 5:00 — AI Integration & Interactive HTML Research Dashboard
1. Navigate to **AI Research (ChatGPT)**:
   > *"QuarterIQ supports a two-mode AI workflow. In Mode A, clicking 'Copy Prepared Prompt' generates `prompt_ready_to_paste.txt` with the complete cryptographic manifest, deterministic metrics, and forensic flags, copying it directly to the Windows clipboard. It opens ChatGPT and the local document folder so the user can drag and drop verified filings without sharing passwords or private credentials."*
2. Navigate to **Research Reports** and click **Generate Interactive HTML Research Dashboard**:
   > *"Click 'Open Report in Default Browser'. The deliverable is a self-contained, responsive HTML5 dashboard with dark/light mode, inline SVG trend charts, forensic anomaly cards, and a complete citation register. It opens completely offline without external CDN dependencies and includes print-friendly CSS for A4 PDF export."*
3. Conclude:
   > *"QuarterIQ delivers an end-to-end, reproducible, CA-grade financial intelligence workflow that bridges classical accounting rigor with modern AI productivity."*

---

## 3. Potential Examiner Questions & Model Answers

### Q1: How do you prevent ChatGPT from hallucinating numbers or fabricating target prices?
**Answer:**
> *"We implement a three-tier defense: First, all arithmetic, ratios, and forensic scores are pre-computed deterministically by QuarterIQ's Python engine. Second, the generated prompt explicitly directs the AI: 'Zero fabrication. Every material figure must cite [Filing, p. X] or [Computed]. If consensus or CMP is unknown, write NOT VERIFIED.' Third, when data is insufficient, the system enforces a mandatory NO-TRADE / INSUFFICIENT DATA verdict."*

### Q2: Why did you build QuarterIQ as a desktop application instead of a pure web app?
**Answer:**
> *"Confidentiality and large document processing. Financial analysts and CA firms frequently work with unreleased internal drafts or 300-page annual report PDFs. Keeping the primary research workspace on the local Windows filesystem ensures that files remain private, avoids uploading sensitive files to third-party cloud servers without permission, and allows offline operation."*

### Q3: How do you handle standalone versus consolidated financial results?
**Answer:**
> *"The user explicitly specifies the accounting basis during research initialization. In the database and manifest, every filing and metric is tagged as either Consolidated or Standalone. The financial extraction and ratio engines strictly prevent mixing standalone figures into consolidated historical trends."*
