import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import csv


def calculate_depreciation():
    try:
        cost = float(entry_cost.get())
        salvage = float(entry_salvage.get())
        useful_life = float(entry_life.get())
        it_rate = float(entry_it_rate.get()) / 100.0
        days_used = int(entry_days.get())

        if cost <= 0 or useful_life <= 0:
            messagebox.showerror("Validation Error", "Cost and Useful Life must be positive values.")
            return

        if days_used < 0 or days_used > 365:
            messagebox.showerror("Validation Error", "Days put to use must be between 0 and 365.")
            return

        # 1. Companies Act, 2013 (Schedule II - SLM)
        depreciable_base = cost - salvage
        annual_slm_dep = depreciable_base / useful_life
        comp_act_dep = (annual_slm_dep * days_used) / 365.0
        comp_closing_wdv = cost - comp_act_dep

        # 2. Income Tax Act, 1961 (Section 32 - Block of Assets)
        # Half-rate rule if put to use for less than 180 days
        if days_used >= 180:
            it_dep = cost * it_rate
            it_rule_note = "Full Rate Applied (>= 180 Days)"
        else:
            it_dep = cost * (it_rate / 2.0)
            it_rule_note = "Half Rate Applied (< 180 Days)"

        it_closing_wdv = cost - it_dep

        # 3. Timing Difference (AS 22 / Ind AS 12)
        timing_diff = comp_act_dep - it_dep
        if timing_diff > 0:
            dt_nature = "Deferred Tax Asset (DTA) created"
        elif timing_diff < 0:
            dt_nature = "Deferred Tax Liability (DTL) created"
        else:
            dt_nature = "No Timing Difference"

        # Update Display Labels
        lbl_books_dep.config(text=f"INR {comp_act_dep:,.2f}")
        lbl_books_wdv.config(text=f"INR {comp_closing_wdv:,.2f}")
        lbl_it_dep.config(text=f"INR {it_dep:,.2f} ({it_rule_note})")
        lbl_it_wdv.config(text=f"INR {it_closing_wdv:,.2f}")
        lbl_timing_diff.config(text=f"INR {abs(timing_diff):,.2f} [{dt_nature}]")

        # Store calculated results globally for CSV export
        global latest_results
        latest_results = {
            "Original Cost": cost,
            "Salvage Value": salvage,
            "Useful Life (Years)": useful_life,
            "Days Used (Year 1)": days_used,
            "IT Depreciation Rate (%)": entry_it_rate.get(),
            "Companies Act Depreciation": round(comp_act_dep, 2),
            "Companies Act Closing WDV": round(comp_closing_wdv, 2),
            "Income Tax Depreciation": round(it_dep, 2),
            "Income Tax Rule": it_rule_note,
            "Income Tax Closing WDV": round(it_closing_wdv, 2),
            "Timing Difference": round(abs(timing_diff), 2),
            "Tax Accounting Impact": dt_nature
        }

    except ValueError:
        messagebox.showerror("Input Error", "Please verify that all entries contain valid numbers.")


def export_schedule():
    if not latest_results:
        messagebox.showwarning("Export Warning", "Please calculate depreciation first before exporting.")
        return

    file_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV Spreadsheet", "*.csv")],
        title="Export Depreciation Summary"
    )

    if file_path:
        try:
            with open(file_path, mode="w", newline="", encoding="utf-8") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(["Field Name / Parameter", "Value"])
                writer.writerow(["=" * 35, "=" * 35])
                for key, value in latest_results.items():
                    writer.writerow([key, value])
            messagebox.showinfo("Export Successful", f"Schedule saved to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Export Failed", f"Could not save file: {str(e)}")


# Global state for exporter
latest_results = {}

# GUI Window
root = tk.Tk()
root.title("ICAI Level-2 Capstone: Statutory Depreciation Analyzer")
root.geometry("680x560")
root.resizable(False, False)

style = ttk.Style()
style.theme_use("clam")

main_frame = ttk.Frame(root, padding="16")
main_frame.pack(fill=tk.BOTH, expand=True)

# Title Header
header = ttk.Label(
    main_frame,
    text="Asset Depreciation & Compliance Engine (Companies Act vs IT Act)",
    font=("Arial", 11, "bold")
)
header.grid(row=0, column=0, columnspan=2, pady=(0, 15), sticky="w")

# Input Definitions
fields = [
    ("Original Cost of Asset (INR):", "1000000"),
    ("Estimated Residual / Salvage Value (INR):", "50000"),
    ("Useful Life (Years - Schedule II):", "5"),
    ("Income Tax Block Rate (%):", "15"),
    ("Days Put to Use in Year 1:", "120")
]

entries = {}
for idx, (label_text, default_val) in enumerate(fields, start=1):
    ttk.Label(main_frame, text=label_text, font=("Arial", 9)).grid(row=idx, column=0, sticky="w", pady=4)
    ent = ttk.Entry(main_frame, width=28)
    ent.insert(0, default_val)
    ent.grid(row=idx, column=1, sticky="e", pady=4)
    entries[label_text] = ent

entry_cost = entries["Original Cost of Asset (INR):"]
entry_salvage = entries["Estimated Residual / Salvage Value (INR):"]
entry_life = entries["Useful Life (Years - Schedule II):"]
entry_it_rate = entries["Income Tax Block Rate (%):"]
entry_days = entries["Days Put to Use in Year 1:"]

# Button Row
btn_frame = ttk.Frame(main_frame)
btn_frame.grid(row=6, column=0, columnspan=2, pady=12)

btn_calc = ttk.Button(btn_frame, text="Compute Statutory Comparison", command=calculate_depreciation)
btn_calc.pack(side=tk.LEFT, padx=6)

btn_export = ttk.Button(btn_frame, text="Export Summary to CSV", command=export_schedule)
btn_export.pack(side=tk.LEFT, padx=6)

# Divider
ttk.Separator(main_frame, orient="horizontal").grid(row=7, column=0, columnspan=2, sticky="ew", pady=6)

# Output Panel
ttk.Label(main_frame, text="Companies Act, 2013 (Books SLM):", font=("Arial", 9, "bold")).grid(row=8, column=0,
                                                                                               sticky="w", pady=3)
lbl_books_dep = ttk.Label(main_frame, text="INR 0.00", font=("Arial", 9))
lbl_books_dep.grid(row=8, column=1, sticky="e", pady=3)

ttk.Label(main_frame, text="Books Closing WDV:", font=("Arial", 9, "bold")).grid(row=9, column=0, sticky="w", pady=3)
lbl_books_wdv = ttk.Label(main_frame, text="INR 0.00", font=("Arial", 9))
lbl_books_wdv.grid(row=9, column=1, sticky="e", pady=3)

ttk.Label(main_frame, text="Income Tax Act, 1961 (Sec 32):", font=("Arial", 9, "bold")).grid(row=10, column=0,
                                                                                             sticky="w", pady=3)
lbl_it_dep = ttk.Label(main_frame, text="INR 0.00", font=("Arial", 9))
lbl_it_dep.grid(row=10, column=1, sticky="e", pady=3)

ttk.Label(main_frame, text="Tax Closing WDV:", font=("Arial", 9, "bold")).grid(row=11, column=0, sticky="w", pady=3)
lbl_it_wdv = ttk.Label(main_frame, text="INR 0.00", font=("Arial", 9))
lbl_it_wdv.grid(row=11, column=1, sticky="e", pady=3)

ttk.Label(main_frame, text="Timing Difference (AS 22 / Ind AS 12):", font=("Arial", 9, "bold")).grid(row=12, column=0,
                                                                                                     sticky="w",
                                                                                                     pady=(10, 3))
lbl_timing_diff = ttk.Label(main_frame, text="INR 0.00", font=("Arial", 9, "italic"))
lbl_timing_diff.grid(row=12, column=1, sticky="e", pady=(10, 3))

root.mainloop()