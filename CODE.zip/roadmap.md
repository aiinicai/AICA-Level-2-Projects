# Roadmap

- [x] Fixed Asset Register & Depreciation web app (Companies Act Sch II + Income-tax WDV, deferred tax, schedules, alerts)
- [x] Local (offline) persistence, Excel/CSV export
- [x] Package as desktop app and produce a Windows .exe build
- [x] Multi-client support: client switcher, add/duplicate/remove client, per-client register
- [x] Import assets from Excel/CSV with header matching + downloadable import template
- [x] Rebuild Windows exe and macOS (arm64 + Intel) packages with import feature
- [x] Fix Add client / Duplicate (window.prompt unsupported in desktop shell) with in-app dialog
