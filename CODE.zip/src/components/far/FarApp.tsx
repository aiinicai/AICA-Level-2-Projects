import { useEffect, useMemo, useState } from "react";
import { RegisterTab } from "@/components/far/RegisterTab";
import { ReportsTab } from "@/components/far/ReportsTab";
import { AlertsTab } from "@/components/far/AlertsTab";
import { SetupTab } from "@/components/far/SetupTab";
import { Stat } from "@/components/far/ui-bits";
import { computeAll, inr, totals } from "@/lib/far/calc";
import { blankAsset, DEFAULT_STATE } from "@/lib/far/defaults";
import { exportJson, exportWorkbook } from "@/lib/far/export";
import { parseAssetsWorkbook } from "@/lib/far/importExcel";
import { loadApp, newClientId, saveApp } from "@/lib/far/storage";
import type { AppState, Asset, RateRow, RegisterState, Settings } from "@/lib/far/types";

const TABS = ["Register", "Schedules", "Alerts", "Setup"] as const;
type Tab = (typeof TABS)[number];

export function FarApp() {
  const [app, setApp] = useState<AppState>({
    clients: [{ id: "initial", ...DEFAULT_STATE }],
    activeClientId: "initial",
  });
  const [hydrated, setHydrated] = useState(false);
  const [tab, setTab] = useState<Tab>("Register");
  const [dialog, setDialog] = useState<{ mode: "add" | "duplicate"; name: string } | null>(null);

  useEffect(() => {
    setApp(loadApp());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveApp(app);
  }, [app, hydrated]);

  const state: RegisterState =
    app.clients.find((c) => c.id === app.activeClientId) ?? app.clients[0] ?? DEFAULT_STATE;

  const setState = (updater: (s: RegisterState) => RegisterState) =>
    setApp((a) => ({
      ...a,
      clients: a.clients.map((c) => (c.id === a.activeClientId ? { id: c.id, ...updater(c) } : c)),
    }));

  const openAddClient = () => {
    setDialog({ mode: "add", name: "" });
  };

  const openDuplicateClient = () => {
    setDialog({ mode: "duplicate", name: `${state.settings.clientName} (copy)` });
  };

  const confirmDialog = () => {
    if (!dialog) return;
    const name = dialog.name.trim();
    if (!name) return;
    const id = newClientId();
    const isCopy = dialog.mode === "duplicate";
    setApp((a) => ({
      clients: [
        ...a.clients,
        {
          id,
          settings: {
            ...state.settings,
            clientName: name,
            openingDeferredTax: isCopy ? state.settings.openingDeferredTax : 0,
          },
          rates: state.rates,
          assets: isCopy ? state.assets.map((x) => ({ ...x, id: newClientId() })) : [],
        },
      ],
      activeClientId: id,
    }));
    setDialog(null);
    setTab("Register");
  };

  const removeClient = () => {
    if (app.clients.length <= 1) {
      window.alert("At least one client must remain. Use Clear register instead.");
      return;
    }
    if (!window.confirm(`Remove ${state.settings.clientName} and its register from this computer?`))
      return;
    setApp((a) => {
      const clients = a.clients.filter((c) => c.id !== a.activeClientId);
      return { clients, activeClientId: clients[0]!.id };
    });
  };


  const rows = useMemo(
    () => computeAll(state.assets, state.rates, state.settings),
    [state],
  );
  const t = totals(rows);
  const closingDt = (t.caClosing - t.itClosing) * state.settings.taxRate;
  const alertCount = rows.filter((r) => r.disposed || r.fullyDepreciated || r.overdue).length;

  const updateAsset = (id: string, patch: Partial<Asset>) =>
    setState((s) => ({
      ...s,
      assets: s.assets.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    }));

  const addAsset = () =>
    setState((s) => ({ ...s, assets: [...s.assets, blankAsset(s.assets.length + 1)] }));

  const deleteAsset = (id: string) =>
    setState((s) => ({ ...s, assets: s.assets.filter((a) => a.id !== id) }));

  const setSettings = (patch: Partial<Settings>) =>
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } }));

  const setRates = (rates: RateRow[]) => setState((s) => ({ ...s, rates }));

  const rollForward = () =>
    setState((s) => {
      const computed = computeAll(s.assets, s.rates, s.settings);
      const nextStart = new Date(s.settings.fyEnd);
      nextStart.setDate(nextStart.getDate() + 1);
      const nextEnd = new Date(nextStart);
      nextEnd.setFullYear(nextEnd.getFullYear() + 1);
      nextEnd.setDate(nextEnd.getDate() - 1);
      const iso = (d: Date) => d.toISOString().slice(0, 10);
      return {
        ...s,
        settings: {
          ...s.settings,
          fyStart: iso(nextStart),
          fyEnd: iso(nextEnd),
          openingDeferredTax:
            (totals(computed).caClosing - totals(computed).itClosing) * s.settings.taxRate,
        },
        assets: computed
          .filter((r) => !r.disposed)
          .map((r) => ({
            ...r.asset,
            openingWdvCompanies: Math.round(r.caClosing),
            openingWdvIt: Math.round(r.itClosing),
            additionThisYear: 0,
            disposalDate: "",
            saleValue: 0,
          })),
      };
    });

  const importExcel = (file: File, mode: "append" | "replace") => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const buffer = reader.result as ArrayBuffer;
        const startSr = mode === "append" ? state.assets.length + 1 : 1;
        const result = parseAssetsWorkbook(buffer, state.rates, startSr);
        setState((s) => ({
          ...s,
          assets: mode === "append" ? [...s.assets, ...result.assets] : result.assets,
        }));
        setTab("Register");
        window.alert(
          [
            `${result.assets.length} asset(s) imported from sheet "${result.sheetName}".`,
            ...result.warnings,
          ].join("\n\n"),
        );
      } catch (err) {
        window.alert(
          err instanceof Error ? err.message : "That file could not be read as an asset register.",
        );
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const importBackup = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as RegisterState;
        setState(() => ({
          settings: { ...DEFAULT_STATE.settings, ...parsed.settings },
          rates: parsed.rates?.length ? parsed.rates : DEFAULT_STATE.rates,
          assets: parsed.assets ?? [],
        }));
      } catch {
        window.alert("That file could not be read as a register backup.");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-background">
      {dialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-lg border border-border bg-card p-5 shadow-lg">
            <h2 className="text-base font-semibold text-card-foreground">
              {dialog.mode === "add" ? "Add client / entity" : "Duplicate this register"}
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              {dialog.mode === "add"
                ? "A fresh register is created with the current financial year and rate master."
                : "Settings, rate master and all assets are copied to the new client."}
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                confirmDialog();
              }}
            >
              <input
                autoFocus
                value={dialog.name}
                onChange={(e) => setDialog({ ...dialog, name: e.target.value })}
                placeholder="Client / entity name"
                className="mt-4 w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:border-ring"
              />
              <div className="mt-4 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDialog(null)}
                  className="rounded-md border border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!dialog.name.trim()}
                  className="rounded-md bg-primary px-3 py-2 text-xs font-semibold uppercase tracking-wide text-primary-foreground disabled:opacity-50"
                >
                  {dialog.mode === "add" ? "Create client" : "Duplicate"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <header className="border-b border-sidebar-border bg-sidebar text-sidebar-foreground">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div>
            <h1 className="text-xl font-semibold">Fixed Asset Register & Depreciation Automation</h1>
            <p className="mt-1 text-sm opacity-80">
              {state.settings.clientName} &middot; {state.settings.firmName} &middot; FY{" "}
              {state.settings.fyStart} to {state.settings.fyEnd}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <label className="text-[0.66rem] font-semibold uppercase tracking-widest opacity-70">
                Client
              </label>
              <select
                value={app.activeClientId}
                onChange={(e) => setApp((a) => ({ ...a, activeClientId: e.target.value }))}
                className="rounded-md border border-sidebar-border bg-sidebar px-2 py-1.5 text-sm text-sidebar-foreground outline-none"
              >
                {app.clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.settings.clientName || "Untitled client"} — FY {c.settings.fyStart.slice(0, 4)}
                    -{c.settings.fyEnd.slice(2, 4)} ({c.assets.length})
                  </option>
                ))}
              </select>
              <button
                onClick={openAddClient}
                className="rounded-md border border-sidebar-border px-2 py-1.5 text-[0.66rem] font-semibold uppercase tracking-wide"
              >
                Add client
              </button>
              <button
                onClick={openDuplicateClient}
                className="rounded-md border border-sidebar-border px-2 py-1.5 text-[0.66rem] font-semibold uppercase tracking-wide"
              >
                Duplicate
              </button>
              <button
                onClick={removeClient}
                className="rounded-md border border-sidebar-border px-2 py-1.5 text-[0.66rem] font-semibold uppercase tracking-wide opacity-80"
              >
                Remove
              </button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => exportWorkbook(state, rows)}
              className="rounded-md bg-sidebar-primary px-3 py-2 text-xs font-semibold uppercase tracking-wide text-sidebar-primary-foreground"
            >
              Export Excel
            </button>
            <button
              onClick={() => exportJson(state)}
              className="rounded-md border border-sidebar-border px-3 py-2 text-xs font-semibold uppercase tracking-wide"
            >
              Backup
            </button>
            <button
              onClick={rollForward}
              className="rounded-md border border-sidebar-border px-3 py-2 text-xs font-semibold uppercase tracking-wide"
            >
              Roll forward to next FY
            </button>
            <button
              onClick={() => window.print()}
              className="rounded-md border border-sidebar-border px-3 py-2 text-xs font-semibold uppercase tracking-wide"
            >
              Print
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] space-y-6 px-6 py-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <Stat label="Gross block" value={inr(t.gross)} hint={`${state.assets.length} assets`} />
          <Stat label="Depreciation — Companies Act" value={inr(t.caDep)} hint="Charged to P&L" />
          <Stat label="Depreciation — Income-tax" value={inr(t.itDep)} hint="u/s 32, block WDV" />
          <Stat
            label={closingDt >= 0 ? "Closing DTL" : "Closing DTA"}
            value={inr(Math.abs(closingDt))}
            hint="On depreciation timing difference"
          />
          <Stat
            label="Alerts"
            value={String(alertCount)}
            hint="Disposals, fully depreciated, life expired"
            tone={alertCount ? "flag" : "good"}
          />
        </div>

        <nav className="flex flex-wrap gap-1 border-b border-border">
          {TABS.map((x) => (
            <button
              key={x}
              onClick={() => setTab(x)}
              className={
                "rounded-t-md px-4 py-2 text-sm font-semibold transition-colors " +
                (tab === x
                  ? "bg-card text-foreground shadow-panel"
                  : "text-muted-foreground hover:text-foreground")
              }
            >
              {x}
            </button>
          ))}
        </nav>

        {tab === "Register" && (
          <RegisterTab
            rows={rows}
            rates={state.rates}
            onChange={updateAsset}
            onDelete={deleteAsset}
            onAdd={addAsset}
          />
        )}
        {tab === "Schedules" && <ReportsTab rows={rows} settings={state.settings} />}
        {tab === "Alerts" && <AlertsTab rows={rows} />}
        {tab === "Setup" && (
          <SetupTab
            settings={state.settings}
            rates={state.rates}
            onSettings={setSettings}
            onRates={setRates}
            onImport={importBackup}
            onImportExcel={importExcel}
            onReset={() => setState((s) => ({ ...s, assets: [] }))}
          />
        )}

        <p className="pb-8 text-xs text-muted-foreground">
          This tool supports the preparation process and does not replace professional judgement.
          Useful lives, block rates and residual values must be confirmed against the statute and the
          client's approved policy before signing or filing.
        </p>
      </main>
    </div>
  );
}
