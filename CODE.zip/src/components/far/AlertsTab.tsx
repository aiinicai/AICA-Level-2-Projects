import { Panel, Td, Th } from "./ui-bits";
import type { AssetComputation } from "@/lib/far/calc";
import { inr } from "@/lib/far/calc";

function alertOf(r: AssetComputation) {
  if (r.disposed)
    return {
      label: "Disposed during the year",
      detail: `Sold on ${r.asset.disposalDate} for ${inr(r.asset.saleValue)} — profit/(loss) ${inr(r.profitOnSale)}`,
    };
  if (r.fullyDepreciated)
    return {
      label: "Fully depreciated",
      detail: "Residual value reached — review whether the asset is still in use.",
    };
  if (r.overdue)
    return {
      label: "Useful life expired",
      detail: `Age ${r.ageYears.toFixed(1)} yrs against a useful life of ${r.usefulLife} yrs — review for disposal / impairment.`,
    };
  return null;
}

export function AlertsTab({ rows }: { rows: AssetComputation[] }) {
  const flagged = rows
    .map((r) => ({ r, a: alertOf(r) }))
    .filter((x): x is { r: AssetComputation; a: NonNullable<ReturnType<typeof alertOf>> } => !!x.a);

  return (
    <Panel
      title="Alerts & Review Points"
      subtitle="Disposals, fully depreciated assets and assets past their useful life"
    >
      {flagged.length === 0 ? (
        <p className="p-6 text-sm text-muted-foreground">
          No exceptions — every asset is active and within its useful life.
        </p>
      ) : (
        <div className="overflow-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <Th>Sr.</Th>
                <Th className="min-w-[200px]">Asset</Th>
                <Th>Category</Th>
                <Th>Alert</Th>
                <Th className="min-w-[260px]">Remark</Th>
                <Th className="text-right">Closing WDV</Th>
              </tr>
            </thead>
            <tbody>
              {flagged.map(({ r, a }, i) => (
                <tr key={r.asset.id} className={i % 2 ? "bg-secondary/30" : ""}>
                  <Td className="num">{r.asset.srNo}</Td>
                  <Td>{r.asset.description || "(untitled)"}</Td>
                  <Td className="text-xs">{r.asset.category}</Td>
                  <Td>
                    <span className="rounded-full bg-flag px-2 py-0.5 text-xs font-semibold text-flag-foreground">
                      {a.label}
                    </span>
                  </Td>
                  <Td className="text-xs text-muted-foreground">{a.detail}</Td>
                  <Td className="num">{inr(r.caClosing)}</Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  );
}
