import { Panel, Td, Th } from "./ui-bits";
import type { AssetComputation } from "@/lib/far/calc";
import { groupBy, inr, pct, totals } from "@/lib/far/calc";
import type { Settings } from "@/lib/far/types";

export function ReportsTab({
  rows,
  settings,
}: {
  rows: AssetComputation[];
  settings: Settings;
}) {
  const t = totals(rows);
  const closingDt = (t.caClosing - t.itClosing) * settings.taxRate;
  const charge = closingDt - settings.openingDeferredTax;

  return (
    <div className="space-y-6">
      <Panel
        title="Companies Act Schedule II — Fixed Assets Note"
        subtitle="Category-wise gross block, depreciation and net block for the financial statements"
      >
        <div className="overflow-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <Th className="min-w-[200px]">Category</Th>
                <Th className="text-right">Gross block opening</Th>
                <Th className="text-right">Additions</Th>
                <Th className="text-right">Disposals</Th>
                <Th className="text-right">Gross block closing</Th>
                <Th className="text-right">Dep. for the year</Th>
                <Th className="text-right">Net block</Th>
              </tr>
            </thead>
            <tbody>
              {groupBy(rows, (r) => r.asset.category).map(([cat, rs], i) => {
                const g = totals(rs);
                return (
                  <tr key={cat} className={i % 2 ? "bg-secondary/30" : ""}>
                    <Td>{cat}</Td>
                    <Td className="num">{inr(g.gross - g.additions)}</Td>
                    <Td className="num">{inr(g.additions)}</Td>
                    <Td className="num">{inr(g.disposalsCost)}</Td>
                    <Td className="num">{inr(g.gross - g.disposalsCost)}</Td>
                    <Td className="num">{inr(g.caDep)}</Td>
                    <Td className="num font-semibold">{inr(g.caClosing)}</Td>
                  </tr>
                );
              })}
              <tr className="bg-primary/10 font-semibold">
                <Td>Total</Td>
                <Td className="num">{inr(t.gross - t.additions)}</Td>
                <Td className="num">{inr(t.additions)}</Td>
                <Td className="num">{inr(t.disposalsCost)}</Td>
                <Td className="num">{inr(t.gross - t.disposalsCost)}</Td>
                <Td className="num">{inr(t.caDep)}</Td>
                <Td className="num">{inr(t.caClosing)}</Td>
              </tr>
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel
        title="Income-tax Act — Block-wise WDV Summary"
        subtitle="Appendix I block rates; half rate applied where the asset was put to use for less than 180 days"
      >
        <div className="overflow-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <Th className="min-w-[200px]">Block of assets</Th>
                <Th className="text-right">Rate</Th>
                <Th className="text-right">Opening WDV</Th>
                <Th className="text-right">Additions</Th>
                <Th className="text-right">Sale consideration</Th>
                <Th className="text-right">Depreciation u/s 32</Th>
                <Th className="text-right">Closing WDV</Th>
              </tr>
            </thead>
            <tbody>
              {groupBy(rows, (r) => r.rate.itBlock).map(([block, rs], i) => {
                const g = totals(rs);
                return (
                  <tr key={block} className={i % 2 ? "bg-secondary/30" : ""}>
                    <Td>{block}</Td>
                    <Td className="num">{pct(rs[0]!.rate.itRate)}</Td>
                    <Td className="num">{inr(g.itOpening)}</Td>
                    <Td className="num">{inr(g.additions)}</Td>
                    <Td className="num">{inr(g.saleValue)}</Td>
                    <Td className="num">{inr(g.itDep)}</Td>
                    <Td className="num font-semibold">{inr(g.itClosing)}</Td>
                  </tr>
                );
              })}
              <tr className="bg-primary/10 font-semibold">
                <Td>Total</Td>
                <Td />
                <Td className="num">{inr(t.itOpening)}</Td>
                <Td className="num">{inr(t.additions)}</Td>
                <Td className="num">{inr(t.saleValue)}</Td>
                <Td className="num">{inr(t.itDep)}</Td>
                <Td className="num">{inr(t.itClosing)}</Td>
              </tr>
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel
        title="Profit / (Loss) on Sale of Fixed Assets"
        subtitle="Sale consideration less written-down value on the date of sale (Companies Act)"
      >
        {rows.filter((r) => r.disposed).length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">
            No assets were disposed of during the selected financial year.
          </p>
        ) : (
          <div className="overflow-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <Th className="min-w-[200px]">Asset</Th>
                  <Th>Category</Th>
                  <Th>Date of sale</Th>
                  <Th className="text-right">Original cost</Th>
                  <Th className="text-right">Opening WDV</Th>
                  <Th className="text-right">Dep. till sale</Th>
                  <Th className="text-right">WDV on sale</Th>
                  <Th className="text-right">Sale value</Th>
                  <Th className="text-right">Profit / (Loss)</Th>
                </tr>
              </thead>
              <tbody>
                {rows
                  .filter((r) => r.disposed)
                  .map((r, i) => (
                    <tr key={r.asset.id} className={i % 2 ? "bg-secondary/30" : ""}>
                      <Td>{r.asset.description || "(unnamed asset)"}</Td>
                      <Td>{r.asset.category}</Td>
                      <Td>{r.asset.disposalDate}</Td>
                      <Td className="num">{inr(r.grossBlock)}</Td>
                      <Td className="num">{inr(r.asset.openingWdvCompanies)}</Td>
                      <Td className="num">{inr(r.caDep)}</Td>
                      <Td className="num">{inr(r.wdvOnSale)}</Td>
                      <Td className="num">{inr(r.asset.saleValue)}</Td>
                      <Td
                        className={`num font-semibold ${r.profitOnSale >= 0 ? "text-primary" : "text-destructive"}`}
                      >
                        {inr(r.profitOnSale)}
                      </Td>
                    </tr>
                  ))}
                <tr className="bg-primary/10 font-semibold">
                  <Td>
                    {t.profitOnSale >= 0
                      ? "Net profit on sale of fixed assets"
                      : "Net loss on sale of fixed assets"}
                  </Td>
                  <Td />
                  <Td />
                  <Td className="num">{inr(t.disposalsCost)}</Td>
                  <Td />
                  <Td />
                  <Td />
                  <Td className="num">{inr(t.saleValue)}</Td>
                  <Td className="num">{inr(t.profitOnSale)}</Td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <Panel
        title="Deferred Tax Statement (AS 22 / Ind AS 12)"
        subtitle="Balance-sheet approach on the depreciation timing difference"
      >
        <table className="w-full border-collapse">
          <tbody>
            {[
              ["Closing WDV as per Companies Act", inr(t.caClosing)],
              ["Closing WDV as per Income-tax Act", inr(t.itClosing)],
              ["Timing difference", inr(t.caClosing - t.itClosing)],
              ["Applicable tax rate", pct(settings.taxRate)],
              [
                closingDt >= 0 ? "Closing deferred tax liability" : "Closing deferred tax asset",
                inr(Math.abs(closingDt)),
              ],
              ["Opening deferred tax liability / (asset)", inr(settings.openingDeferredTax)],
              [
                charge >= 0 ? "Charge to Profit & Loss" : "Credit to Profit & Loss",
                inr(Math.abs(charge)),
              ],
            ].map(([label, value], i, arr) => (
              <tr key={label} className={i === arr.length - 1 ? "bg-primary/10 font-semibold" : ""}>
                <Td>{label}</Td>
                <Td className="num w-48">{value}</Td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  );
}
