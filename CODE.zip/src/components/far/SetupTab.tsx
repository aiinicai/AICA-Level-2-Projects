import { Field, Panel, Td, Th, inputClass } from "./ui-bits";
import type { RateRow, Settings } from "@/lib/far/types";
import { DEFAULT_RATES } from "@/lib/far/defaults";
import { downloadImportTemplate } from "@/lib/far/importExcel";

export function SetupTab({
  settings,
  rates,
  onSettings,
  onRates,
  onReset,
  onImport,
  onImportExcel,
}: {
  settings: Settings;
  rates: RateRow[];
  onSettings: (patch: Partial<Settings>) => void;
  onRates: (rates: RateRow[]) => void;
  onReset: () => void;
  onImport: (file: File) => void;
  onImportExcel: (file: File, mode: "append" | "replace") => void;
}) {
  const patchRate = (i: number, patch: Partial<RateRow>) =>
    onRates(rates.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));

  return (
    <div className="space-y-6">
      <Panel title="Client & Financial Year" subtitle="These details appear on every schedule and export">
        <div className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Firm name">
            <input
              className={inputClass}
              value={settings.firmName}
              onChange={(e) => onSettings({ firmName: e.target.value })}
            />
          </Field>
          <Field label="Client / entity">
            <input
              className={inputClass}
              value={settings.clientName}
              onChange={(e) => onSettings({ clientName: e.target.value })}
            />
          </Field>
          <Field label="Applicable tax rate" hint="Including surcharge & cess, e.g. 0.25168">
            <input
              className={`${inputClass} num`}
              type="number"
              step="0.00001"
              value={settings.taxRate}
              onChange={(e) => onSettings({ taxRate: Number(e.target.value) })}
            />
          </Field>
          <Field label="FY start date">
            <input
              className={inputClass}
              type="date"
              value={settings.fyStart}
              onChange={(e) => onSettings({ fyStart: e.target.value })}
            />
          </Field>
          <Field label="FY end date">
            <input
              className={inputClass}
              type="date"
              value={settings.fyEnd}
              onChange={(e) => onSettings({ fyEnd: e.target.value })}
            />
          </Field>
          <Field label="Opening deferred tax liability / (asset)">
            <input
              className={`${inputClass} num`}
              type="number"
              value={settings.openingDeferredTax}
              onChange={(e) => onSettings({ openingDeferredTax: Number(e.target.value) })}
            />
          </Field>
        </div>
      </Panel>

      <Panel
        title="Rate Master"
        subtitle="Companies Act Schedule II useful life and Income-tax Appendix I block rates — editable per client policy"
        actions={
          <button
            onClick={() => onRates(DEFAULT_RATES)}
            className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-wide"
          >
            Restore defaults
          </button>
        }
      >
        <div className="overflow-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <Th className="min-w-[220px]">Category</Th>
                <Th className="text-right">Useful life (yrs)</Th>
                <Th className="min-w-[200px]">Income-tax block</Th>
                <Th className="text-right">IT WDV rate</Th>
              </tr>
            </thead>
            <tbody>
              {rates.map((r, i) => (
                <tr key={i} className={i % 2 ? "bg-secondary/30" : ""}>
                  <Td>
                    <input
                      className="w-full bg-ledger px-1.5 py-1 text-[0.8125rem] outline-none"
                      value={r.category}
                      onChange={(e) => patchRate(i, { category: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <input
                      className="num w-full bg-ledger px-1.5 py-1 text-[0.8125rem] outline-none"
                      type="number"
                      value={r.usefulLife}
                      onChange={(e) => patchRate(i, { usefulLife: Number(e.target.value) })}
                    />
                  </Td>
                  <Td>
                    <input
                      className="w-full bg-ledger px-1.5 py-1 text-[0.8125rem] outline-none"
                      value={r.itBlock}
                      onChange={(e) => patchRate(i, { itBlock: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <input
                      className="num w-full bg-ledger px-1.5 py-1 text-[0.8125rem] outline-none"
                      type="number"
                      step="0.01"
                      value={r.itRate}
                      onChange={(e) => patchRate(i, { itRate: Number(e.target.value) })}
                    />
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="border-t border-border px-4 py-3 text-xs text-muted-foreground">
          Source: Companies Act 2013 Schedule II Part C (single-shift general use) and Income-tax Rules
          1962 Appendix I. Confirm against the latest notification and the client's board-approved policy
          before filing.
        </p>
      </Panel>

      <Panel
        title="Import assets from Excel"
        subtitle="Bring in an existing client register from .xlsx, .xls or .csv — columns are matched by heading"
        actions={
          <button
            onClick={() => downloadImportTemplate(rates)}
            className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-wide"
          >
            Download template
          </button>
        }
      >
        <div className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="cursor-pointer rounded-md bg-primary px-3 py-2 text-xs font-semibold uppercase tracking-wide text-primary-foreground">
              Add to this register
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onImportExcel(f, "append");
                  e.target.value = "";
                }}
              />
            </label>
            <label className="cursor-pointer rounded-md border border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide">
              Replace all assets
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onImportExcel(f, "replace");
                  e.target.value = "";
                }}
              />
            </label>
          </div>
          <p className="text-xs text-muted-foreground">
            Recognised headings include Description, Category, Date of Purchase, Original Cost, Addition
            during year, Disposal Date, Sale Value, Method, Residual %, CA Opening WDV and IT Opening WDV.
            Dates in dd/mm/yyyy, amounts with commas and residual values written as 5 or 0.05 are all
            accepted. Review the imported rows on the Register tab before finalising.
          </p>
        </div>
      </Panel>

      <Panel title="Data & Backup" subtitle="Everything is stored on this computer only — no data leaves the machine">
        <div className="flex flex-wrap items-center gap-3 p-4">
          <label className="cursor-pointer rounded-md border border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide">
            Restore from backup
            <input
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onImport(f);
              }}
            />
          </label>
          <button
            onClick={onReset}
            className="rounded-md border border-destructive px-3 py-2 text-xs font-semibold uppercase tracking-wide text-destructive"
          >
            Clear register
          </button>
        </div>
      </Panel>
    </div>
  );
}
