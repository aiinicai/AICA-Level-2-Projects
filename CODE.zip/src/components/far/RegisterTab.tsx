import { Th, Td, Panel } from "./ui-bits";
import type { Asset, RateRow } from "@/lib/far/types";
import type { AssetComputation } from "@/lib/far/calc";
import { inr, pct, totals } from "@/lib/far/calc";

const cell =
  "w-full rounded-sm border border-transparent bg-ledger px-1.5 py-1 text-[0.8125rem] outline-none focus:border-ring";

export function RegisterTab({
  rows,
  rates,
  onChange,
  onDelete,
  onAdd,
}: {
  rows: AssetComputation[];
  rates: RateRow[];
  onChange: (id: string, patch: Partial<Asset>) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
}) {
  const t = totals(rows);

  return (
    <Panel
      title="Asset Register"
      subtitle="One row per asset. Yellow cells are inputs — depreciation, closing WDV and flags compute automatically."
      actions={
        <button
          onClick={onAdd}
          className="rounded-md bg-primary px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-primary-foreground transition-opacity hover:opacity-90"
        >
          + Add asset
        </button>
      }
    >
      <div className="max-h-[70vh] overflow-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <Th>Sr.</Th>
              <Th className="min-w-[180px]">Description</Th>
              <Th className="min-w-[150px]">Category</Th>
              <Th>Location</Th>
              <Th>Purchase</Th>
              <Th className="text-right">Original cost</Th>
              <Th className="text-right">Addition</Th>
              <Th>Addition date</Th>
              <Th>Disposal</Th>
              <Th className="text-right">Sale value</Th>
              <Th className="text-right">Profit/(loss) on sale</Th>
              <Th>Method</Th>
              <Th className="text-right">Resid.%</Th>
              <Th className="text-right">Life</Th>
              <Th className="text-right">Days</Th>
              <Th className="text-right">Op. WDV (CA)</Th>
              <Th className="text-right">Rate CA</Th>
              <Th className="text-right">Dep CA</Th>
              <Th className="text-right">Cl. WDV (CA)</Th>
              <Th className="text-right">Op. WDV (IT)</Th>
              <Th className="text-right">Rate IT</Th>
              <Th className="text-right">Dep IT</Th>
              <Th className="text-right">Cl. WDV (IT)</Th>
              <Th>Status</Th>
              <Th />
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => {
              const a = r.asset;
              const tone = r.disposed
                ? "bg-flag/60"
                : r.overdue || r.fullyDepreciated
                  ? "bg-flag/30"
                  : i % 2
                    ? "bg-secondary/30"
                    : "";
              return (
                <tr key={a.id} className={tone}>
                  <Td className="num w-12">
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.srNo}
                      onChange={(e) => onChange(a.id, { srNo: Number(e.target.value) })}
                    />
                  </Td>
                  <Td>
                    <input
                      className={cell}
                      value={a.description}
                      placeholder="Asset description"
                      onChange={(e) => onChange(a.id, { description: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <select
                      className={cell}
                      value={a.category}
                      onChange={(e) => onChange(a.id, { category: e.target.value })}
                    >
                      {rates.map((rt) => (
                        <option key={rt.category} value={rt.category}>
                          {rt.category}
                        </option>
                      ))}
                    </select>
                  </Td>
                  <Td>
                    <input
                      className={cell}
                      value={a.location}
                      onChange={(e) => onChange(a.id, { location: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <input
                      className={cell}
                      type="date"
                      value={a.purchaseDate}
                      onChange={(e) => onChange(a.id, { purchaseDate: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.originalCost}
                      onChange={(e) => onChange(a.id, { originalCost: Number(e.target.value) })}
                    />
                  </Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.additionThisYear}
                      onChange={(e) => onChange(a.id, { additionThisYear: Number(e.target.value) })}
                    />
                  </Td>
                  <Td>
                    {a.additionThisYear > 0 ? (
                      <input
                        className={cell}
                        type="date"
                        title="Date the addition was put to use (drives the 180-day rule)"
                        value={a.additionDate ?? ""}
                        onChange={(e) => onChange(a.id, { additionDate: e.target.value })}
                      />
                    ) : (
                      <span className="px-1.5 text-xs text-muted-foreground">—</span>
                    )}
                  </Td>
                  <Td>
                    <input
                      className={cell}
                      type="date"
                      value={a.disposalDate}
                      onChange={(e) => onChange(a.id, { disposalDate: e.target.value })}
                    />
                  </Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.saleValue}
                      onChange={(e) => onChange(a.id, { saleValue: Number(e.target.value) })}
                    />
                  </Td>
                  <Td
                    className={`num ${r.disposed ? (r.profitOnSale >= 0 ? "text-primary" : "text-destructive") : "text-muted-foreground"}`}
                  >
                    {r.disposed ? inr(r.profitOnSale) : "—"}
                  </Td>
                  <Td>
                    <select
                      className={cell}
                      value={a.method}
                      onChange={(e) => onChange(a.id, { method: e.target.value as Asset["method"] })}
                    >
                      <option value="SLM">SLM</option>
                      <option value="WDV">WDV</option>
                    </select>
                  </Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      step="0.01"
                      value={a.residualPct}
                      onChange={(e) => onChange(a.id, { residualPct: Number(e.target.value) })}
                    />
                  </Td>
                  <Td className="num">{r.usefulLife}</Td>
                  <Td className="num">{r.daysHeld}</Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.openingWdvCompanies}
                      onChange={(e) =>
                        onChange(a.id, { openingWdvCompanies: Number(e.target.value) })
                      }
                    />
                  </Td>
                  <Td className="num text-muted-foreground">{pct(r.caRate)}</Td>
                  <Td className="num font-semibold">{inr(r.caDep)}</Td>
                  <Td className="num">{inr(r.caClosing)}</Td>
                  <Td>
                    <input
                      className={`${cell} num`}
                      type="number"
                      value={a.openingWdvIt}
                      onChange={(e) => onChange(a.id, { openingWdvIt: Number(e.target.value) })}
                    />
                  </Td>
                  <Td className="num text-muted-foreground">{pct(r.itRateApplied)}</Td>
                  <Td className="num font-semibold">{inr(r.itDep)}</Td>
                  <Td className="num">{inr(r.itClosing)}</Td>
                  <Td className="whitespace-nowrap text-xs">
                    {r.disposed
                      ? "Disposed"
                      : r.fullyDepreciated
                        ? "Fully dep."
                        : r.overdue
                          ? "Life expired"
                          : "Active"}
                  </Td>
                  <Td>
                    <button
                      onClick={() => onDelete(a.id)}
                      className="rounded px-1.5 text-xs text-destructive hover:underline"
                      aria-label="Delete asset"
                    >
                      Del
                    </button>
                  </Td>
                </tr>
              );
            })}
            <tr className="bg-primary/10 font-semibold">
              <Td />
              <Td>Total ({rows.length} assets)</Td>
              <Td />
              <Td />
              <Td />
              <Td className="num">{inr(t.gross)}</Td>
              <Td className="num">{inr(t.additions)}</Td>
              <Td />
              <Td />
              <Td className="num">{inr(t.saleValue)}</Td>
              <Td className="num">{inr(t.profitOnSale)}</Td>
              <Td />
              <Td />
              <Td />
              <Td />
              <Td className="num">{inr(t.caOpening)}</Td>
              <Td />
              <Td className="num">{inr(t.caDep)}</Td>
              <Td className="num">{inr(t.caClosing)}</Td>
              <Td className="num">{inr(t.itOpening)}</Td>
              <Td />
              <Td className="num">{inr(t.itDep)}</Td>
              <Td className="num">{inr(t.itClosing)}</Td>
              <Td />
              <Td />
            </tr>
          </tbody>
        </table>
      </div>
    </Panel>
  );
}
