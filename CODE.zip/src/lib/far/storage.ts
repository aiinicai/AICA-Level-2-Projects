import { DEFAULT_STATE } from "./defaults";
import type { AppState, Client, RegisterState } from "./types";

const KEY = "far-register-v1";
const APP_KEY = "far-app-v2";

function normalise(parsed: Partial<RegisterState> | undefined): RegisterState {
  return {
    settings: { ...DEFAULT_STATE.settings, ...parsed?.settings },
    rates: parsed?.rates?.length ? parsed.rates : DEFAULT_STATE.rates,
    assets: parsed?.assets ?? [],
  };
}

export function newClientId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `c-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function defaultApp(): AppState {
  const id = newClientId();
  return { clients: [{ id, ...DEFAULT_STATE }], activeClientId: id };
}

export function loadState(): RegisterState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATE;
    return normalise(JSON.parse(raw) as RegisterState);
  } catch {
    return DEFAULT_STATE;
  }
}

export function loadApp(): AppState {
  if (typeof window === "undefined") return defaultApp();
  try {
    const raw = window.localStorage.getItem(APP_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppState;
      const clients: Client[] = (parsed.clients ?? [])
        .filter(Boolean)
        .map((c) => ({ id: c.id || newClientId(), ...normalise(c) }));
      if (clients.length) {
        const active = clients.some((c) => c.id === parsed.activeClientId)
          ? parsed.activeClientId
          : clients[0]!.id;
        return { clients, activeClientId: active };
      }
    }
    // migrate a single-client register saved by an earlier version
    const legacy = window.localStorage.getItem(KEY);
    if (legacy) {
      const id = newClientId();
      return {
        clients: [{ id, ...normalise(JSON.parse(legacy) as RegisterState) }],
        activeClientId: id,
      };
    }
  } catch {
    /* fall through to defaults */
  }
  return defaultApp();
}

export function saveApp(app: AppState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(APP_KEY, JSON.stringify(app));
}

export function saveState(state: RegisterState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(state));
}
