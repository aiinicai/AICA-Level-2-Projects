import type { Asset, RateRow, Settings } from "./types";

const DAY = 86400000;

export function toDate(s: string): Date | null {
  if (!s) return null;
  const d = new Date(s + "T00:00:00");
  return isNaN(d.getTime()) ? null : d;
}

export function daysInclusive(a: Date, b: Date) {
  return Math.floor((b.getTime() - a.getTime()) / DAY) + 1;
}

export interface AssetComputation {
  asset: Asset;
  rate: RateRow;
  usefulLife: number;
  daysHeld: number;
  daysInFy: number;
  // Companies Act
  caRate: number;
  caDep: number;
  caClosing: number;
  // Income tax
  itRate: number;
  itRateApplied: number;
  itDep: number;
  itClosing: number;
  grossBlock: number;
  disposed: boolean;
  wdvOnSale: number;
  profitOnSale: number;
  fullyDepreciated: boolean;
  overdue: boolean;
  ageYears: number;
}

export function computeAsset(asset: Asset, rates: RateRow[], settings: Settings): AssetComputation {
  const rate =
    rates.find((r) => r.category === asset.category) ??
    ({ category: asset.category, usefulLife: 5, itBlock: "Unmapped", itRate: 0.15 } as RateRow);

  const fyStart = toDate(settings.fyStart) ?? new Date();
  const fyEnd = toDate(settings.fyEnd) ?? new Date();
  const daysInFy = Math.max(1, daysInclusive(fyStart, fyEnd));
  const purchase = toDate(asset.purchaseDate);
  const disposal = toDate(asset.disposalDate);

  const start = purchase && purchase > fyStart ? purchase : fyStart;
  const end = disposal && disposal < fyEnd ? disposal : fyEnd;
  const daysHeld = purchase && purchase > fyEnd ? 0 : Math.max(0, daysInclusive(start, end));
  const propn = daysHeld / daysInFy;

  const grossBlock = asset.originalCost;
  const residual = grossBlock * asset.residualPct;
  const life = Math.max(1, rate.usefulLife);

  const caOpening = asset.openingWdvCompanies + asset.additionThisYear;
  let caRate = 0;
  let caDep = 0;
  if (asset.method === "SLM") {
    caRate = 1 / life;
    caDep = ((grossBlock - residual) / life) * propn;
  } else {
    caRate = 1 - Math.pow(Math.max(asset.residualPct, 0.0001), 1 / life);
    caDep = caOpening * caRate * propn;
  }
  caDep = Math.max(0, Math.min(caDep, Math.max(0, caOpening - residual)));
  const caClosing = Math.max(residual, caOpening - caDep);

  // Income-tax: WDV block rate, half rate if put to use < 180 days in year of acquisition
  const itOpeningBase = asset.openingWdvIt;
  const acquiredThisYear = !!purchase && purchase >= fyStart && purchase <= fyEnd;
  // Additions use their own put-to-use date when supplied, else the purchase date
  const additionDate = toDate(asset.additionDate ?? "") ?? purchase;
  const additionInFy =
    !!additionDate && additionDate >= fyStart && additionDate <= fyEnd
      ? additionDate
      : acquiredThisYear
        ? purchase
        : null;
  const additionDays = additionInFy ? Math.max(0, daysInclusive(additionInFy, fyEnd)) : 0;
  const shortPeriod = asset.additionThisYear > 0 ? additionDays < 180 : acquiredThisYear && daysHeld < 180;
  const itRateApplied = shortPeriod ? rate.itRate / 2 : rate.itRate;
  let itDep = 0;
  let itClosing = 0;
  if (disposal && disposal >= fyStart && disposal <= fyEnd) {
    // no depreciation in year of sale under block concept
    itDep = 0;
    itClosing = Math.max(0, itOpeningBase + asset.additionThisYear - asset.saleValue);
  } else {
    const addition = additionInFy ? asset.additionThisYear : 0;
    const openingPart = acquiredThisYear ? 0 : itOpeningBase;
    // opening WDV always attracts the full rate; additions may attract the half rate
    itDep = openingPart * rate.itRate + (addition + (acquiredThisYear ? itOpeningBase : 0)) * itRateApplied;
    const base = openingPart + addition + (acquiredThisYear ? itOpeningBase : 0);
    itClosing = Math.max(0, base - itDep);
  }

  const disposed = !!disposal && disposal >= fyStart && disposal <= fyEnd;
  // Book value on the date of sale (Companies Act) = opening WDV + addition - dep. till date of sale
  const wdvOnSale = disposed ? Math.max(0, caOpening - caDep) : 0;
  const profitOnSale = disposed ? asset.saleValue - wdvOnSale : 0;
  const ageYears = purchase ? (fyEnd.getTime() - purchase.getTime()) / (365.25 * DAY) : 0;

  return {
    asset,
    rate,
    usefulLife: life,
    daysHeld,
    daysInFy,
    caRate,
    caDep,
    caClosing: disposed ? 0 : caClosing,
    itRate: rate.itRate,
    itRateApplied,
    itDep,
    itClosing: disposed ? 0 : itClosing,
    grossBlock,
    disposed,
    wdvOnSale,
    profitOnSale,
    fullyDepreciated: !disposed && caClosing <= residual + 1,
    overdue: !disposed && ageYears > life,
    ageYears,
  };
}

export function computeAll(assets: Asset[], rates: RateRow[], settings: Settings) {
  return assets.map((a) => computeAsset(a, rates, settings));
}

export interface Totals {
  gross: number;
  additions: number;
  disposalsCost: number;
  caOpening: number;
  caDep: number;
  caClosing: number;
  itOpening: number;
  itDep: number;
  itClosing: number;
  saleValue: number;
  profitOnSale: number;
}

export function totals(rows: AssetComputation[]): Totals {
  return rows.reduce<Totals>(
    (t, r) => ({
      gross: t.gross + r.grossBlock,
      additions: t.additions + r.asset.additionThisYear,
      disposalsCost: t.disposalsCost + (r.disposed ? r.grossBlock : 0),
      caOpening: t.caOpening + r.asset.openingWdvCompanies,
      caDep: t.caDep + r.caDep,
      caClosing: t.caClosing + r.caClosing,
      itOpening: t.itOpening + r.asset.openingWdvIt,
      itDep: t.itDep + r.itDep,
      itClosing: t.itClosing + r.itClosing,
      saleValue: t.saleValue + (r.disposed ? r.asset.saleValue : 0),
      profitOnSale: t.profitOnSale + r.profitOnSale,
    }),
    {
      gross: 0, additions: 0, disposalsCost: 0, caOpening: 0, caDep: 0, caClosing: 0,
      itOpening: 0, itDep: 0, itClosing: 0, saleValue: 0, profitOnSale: 0,
    },
  );
}

export function groupBy<T>(rows: T[], key: (r: T) => string) {
  const map = new Map<string, T[]>();
  for (const r of rows) {
    const k = key(r);
    map.set(k, [...(map.get(k) ?? []), r]);
  }
  return [...map.entries()];
}

export const inr = (n: number) =>
  (n < 0 ? "(" : "") +
  Math.abs(Math.round(n)).toLocaleString("en-IN") +
  (n < 0 ? ")" : "");

export const pct = (n: number) => (n * 100).toFixed(2) + "%";
