export type DepMethod = "SLM" | "WDV";

export interface Asset {
  id: string;
  srNo: number;
  description: string;
  category: string;
  location: string;
  purchaseDate: string; // yyyy-mm-dd
  originalCost: number;
  additionThisYear: number;
  additionDate?: string; // yyyy-mm-dd, date the addition was put to use (for the 180-day rule)
  disposalDate: string; // "" when not disposed
  saleValue: number;
  method: DepMethod;
  residualPct: number; // e.g. 0.05
  openingWdvCompanies: number;
  openingWdvIt: number;
}

export interface RateRow {
  category: string;
  usefulLife: number;
  itBlock: string;
  itRate: number;
}

export interface Settings {
  firmName: string;
  clientName: string;
  fyStart: string;
  fyEnd: string;
  taxRate: number;
  openingDeferredTax: number;
}

export interface RegisterState {
  settings: Settings;
  rates: RateRow[];
  assets: Asset[];
}

export interface Client extends RegisterState {
  id: string;
}

export interface AppState {
  clients: Client[];
  activeClientId: string;
}
