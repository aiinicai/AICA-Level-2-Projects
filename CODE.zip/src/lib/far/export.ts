import * as XLSX from "xlsx";
import type { AssetComputation } from "./calc";
import { groupBy, totals } from "./calc";
import type { RegisterState } from "./types";

export function exportWorkbook(state: RegisterState, rows: AssetComputation[]) {
  const { settings } = state;
  const wb = XLSX.utils.book_new();
  const t = totals(rows);

  const register = rows.map((r) => ({
    "Sr. No.": r.asset.srNo,
    Description: r.asset.description,
    Category: r.asset.category,
    Location: r.asset.location,
    "Date of Purchase": r.asset.purchaseDate,
    "Original Cost": r.grossBlock,
    "Addition during year": r.asset.additionThisYear,
    "Addition Date": r.asset.additionThisYear > 0 ? (r.asset.additionDate ?? "") : "",
    "Disposal Date": r.asset.disposalDate,
    "Sale Value": r.asset.disposalDate ? r.asset.saleValue : "",
    "WDV on Sale": r.disposed ? r.wdvOnSale : "",
    "Profit/(Loss) on Sale": r.disposed ? r.profitOnSale : "",
    Method: r.asset.method,
    "Residual %": r.asset.residualPct,
    "Useful Life (Yrs)": r.usefulLife,
    "Days Held": r.daysHeld,
    "CA Opening WDV": r.asset.openingWdvCompanies,
    "CA Dep Rate": r.caRate,
    "CA Depreciation": r.caDep,
    "CA Closing WDV": r.caClosing,
    "IT Block": r.rate.itBlock,
    "IT Rate Applied": r.itRateApplied,
    "IT Opening WDV": r.asset.openingWdvIt,
    "IT Depreciation": r.itDep,
    "IT Closing WDV": r.itClosing,
    "Timing Difference": r.caClosing - r.itClosing,
    "Deferred Tax": (r.caClosing - r.itClosing) * settings.taxRate,
    Status: r.disposed ? "Disposed" : r.fullyDepreciated ? "Fully depreciated" : r.overdue ? "Life expired" : "Active",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(register), "Asset Register");

  const disposals = rows
    .filter((r) => r.disposed)
    .map((r) => ({
      Asset: r.asset.description,
      Category: r.asset.category,
      "Date of Sale": r.asset.disposalDate,
      "Original Cost": r.grossBlock,
      "Opening WDV": r.asset.openingWdvCompanies,
      "Depreciation till Sale": r.caDep,
      "WDV on Sale": r.wdvOnSale,
      "Sale Value": r.asset.saleValue,
      "Profit/(Loss) on Sale": r.profitOnSale,
    }));
  if (disposals.length)
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(disposals), "Profit on Sale");

  const caSchedule = groupBy(rows, (r) => r.asset.category).map(([cat, rs]) => {
    const g = totals(rs);
    return {
      Category: cat,
      "Gross Block Opening": g.gross - g.additions,
      Additions: g.additions,
      Disposals: g.disposalsCost,
      "Gross Block Closing": g.gross - g.disposalsCost,
      "Accumulated Dep Opening": g.gross - g.additions - g.caOpening,
      "Depreciation for the year": g.caDep,
      "Net Block": g.caClosing,
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(caSchedule), "Companies Act Schedule");

  const itSummary = groupBy(rows, (r) => r.rate.itBlock).map(([block, rs]) => {
    const g = totals(rs);
    return {
      Block: block,
      Rate: rs[0]!.rate.itRate,
      "Opening WDV": g.itOpening,
      Additions: g.additions,
      "Sale Value Reduced": g.saleValue,
      "Depreciation u/s 32": g.itDep,
      "Closing WDV": g.itClosing,
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(itSummary), "IT Block Summary");

  const dt = [
    { Particulars: "Closing WDV - Companies Act", Amount: t.caClosing },
    { Particulars: "Closing WDV - Income-tax Act", Amount: t.itClosing },
    { Particulars: "Timing difference", Amount: t.caClosing - t.itClosing },
    { Particulars: "Applicable tax rate", Amount: settings.taxRate },
    { Particulars: "Closing DTL / (DTA)", Amount: (t.caClosing - t.itClosing) * settings.taxRate },
    { Particulars: "Opening DTL / (DTA)", Amount: settings.openingDeferredTax },
    {
      Particulars: "Charge / (credit) to P&L",
      Amount: (t.caClosing - t.itClosing) * settings.taxRate - settings.openingDeferredTax,
    },
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dt), "Deferred Tax");

  const alerts = rows
    .filter((r) => r.disposed || r.fullyDepreciated || r.overdue)
    .map((r) => ({
      "Sr. No.": r.asset.srNo,
      Description: r.asset.description,
      Category: r.asset.category,
      Alert: r.disposed
        ? "Disposed during the year"
        : r.fullyDepreciated
          ? "Fully depreciated - residual value reached"
          : "Useful life expired - review for disposal / impairment",
      "Closing WDV": r.caClosing,
    }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(alerts.length ? alerts : [{ Alert: "No alerts" }]), "Alerts");

  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(state.rates.map((r) => ({
      Category: r.category,
      "Useful Life (Companies Act)": r.usefulLife,
      "Income-tax Block": r.itBlock,
      "Income-tax WDV Rate": r.itRate,
    }))),
    "Rate Master",
  );

  const name = `FAR_${settings.clientName.replace(/[^a-z0-9]+/gi, "_")}_${settings.fyStart.slice(0, 4)}-${settings.fyEnd.slice(2, 4)}.xlsx`;
  XLSX.writeFile(wb, name);
}

export function exportJson(state: RegisterState) {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "fixed-asset-register-backup.json";
  a.click();
  URL.revokeObjectURL(url);
}
