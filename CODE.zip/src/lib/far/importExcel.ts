import * as XLSX from "xlsx";
import { DEFAULT_RATES } from "./defaults";
import type { Asset, DepMethod, RateRow } from "./types";

export interface ImportResult {
  assets: Asset[];
  skipped: number;
  warnings: string[];
  sheetName: string;
}

const HEADER_MAP: Record<keyof Asset | "ignore", string[]> = {
  id: [],
  srNo: ["sr no", "srno", "sr", "sl no", "serial", "s no", "#"],
  description: ["description", "asset", "asset name", "particulars", "asset description", "name"],
  category: ["category", "block", "asset category", "class", "group"],
  location: ["location", "site", "branch", "place"],
  purchaseDate: ["purchase date", "date of purchase", "date", "invoice date", "put to use date", "acquisition date"],
  originalCost: ["original cost", "cost", "gross block", "value", "amount", "purchase value", "opening gross block"],
  additionThisYear: ["addition during year", "addition", "additions", "addition this year", "purchases during year"],
  additionDate: ["addition date", "date of addition", "addition put to use date"],
  disposalDate: ["disposal date", "date of sale", "sale date", "deletion date"],
  saleValue: ["sale value", "sale proceeds", "sale consideration", "disposal value", "realisation"],
  method: ["method", "dep method", "depreciation method"],
  residualPct: ["residual %", "residual", "residual value %", "scrap %", "salvage %"],
  openingWdvCompanies: ["ca opening wdv", "opening wdv companies", "opening wdv (companies act)", "opening wdv companies act", "opening wdv", "opening net block", "wdv as per companies act"],
  openingWdvIt: ["it opening wdv", "opening wdv it", "opening wdv (income tax)", "opening wdv income tax", "wdv as per income tax", "it wdv"],
  ignore: [],
};

const norm = (s: unknown) =>
  String(s ?? "")
    .toLowerCase()
    .replace(/[_\-.]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/[()]/g, "")
    .trim();

function fieldFor(header: string): keyof Asset | null {
  const h = norm(header);
  if (!h) return null;
  for (const [field, aliases] of Object.entries(HEADER_MAP)) {
    if (field === "ignore" || field === "id") continue;
    if (aliases.some((a) => a === h)) return field as keyof Asset;
  }
  for (const [field, aliases] of Object.entries(HEADER_MAP)) {
    if (field === "ignore" || field === "id") continue;
    if (aliases.some((a) => h.includes(a))) return field as keyof Asset;
  }
  return null;
}

function toNumber(v: unknown): number {
  if (typeof v === "number") return Number.isFinite(v) ? v : 0;
  const s = String(v ?? "").replace(/[₹,\s]/g, "").replace(/^\((.*)\)$/, "-$1");
  if (!s) return 0;
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function toPct(v: unknown): number {
  const n = toNumber(v);
  if (n > 1) return n / 100;
  return n < 0 ? 0 : n;
}

function toDate(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "number") {
    const p = XLSX.SSF.parse_date_code(v);
    if (!p) return "";
    const pad = (x: number) => String(x).padStart(2, "0");
    return `${p.y}-${pad(p.m)}-${pad(p.d)}`;
  }
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.toISOString().slice(0, 10);
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$/);
  if (m) {
    const d = Number(m[1]);
    const mo = Number(m[2]);
    let y = Number(m[3]);
    if (y < 100) y += y > 60 ? 1900 : 2000;
    const pad = (x: number) => String(x).padStart(2, "0");
    return `${y}-${pad(mo)}-${pad(d)}`;
  }
  const parsed = new Date(s);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString().slice(0, 10);
}

function matchCategory(raw: string, rates: RateRow[]): { category: string; matched: boolean } {
  const value = String(raw ?? "").trim();
  if (!value) return { category: rates[0]?.category ?? DEFAULT_RATES[0]!.category, matched: false };
  const exact = rates.find((r) => norm(r.category) === norm(value));
  if (exact) return { category: exact.category, matched: true };
  const loose = rates.find(
    (r) => norm(r.category).includes(norm(value)) || norm(value).includes(norm(r.category)),
  );
  if (loose) return { category: loose.category, matched: true };
  return { category: value, matched: false };
}

export function parseAssetsWorkbook(
  data: ArrayBuffer,
  rates: RateRow[],
  startSrNo: number,
): ImportResult {
  const wb = XLSX.read(data, { cellDates: true });
  const sheetName =
    wb.SheetNames.find((n) => norm(n).includes("register")) ??
    wb.SheetNames.find((n) => norm(n).includes("asset")) ??
    wb.SheetNames[0]!;
  const sheet = wb.Sheets[sheetName]!;
  const grid = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, blankrows: false, raw: true });

  let headerRow = -1;
  let mapping: Record<number, keyof Asset> = {};
  for (let i = 0; i < Math.min(grid.length, 25); i++) {
    const candidate: Record<number, keyof Asset> = {};
    (grid[i] ?? []).forEach((cell, idx) => {
      const f = fieldFor(String(cell ?? ""));
      if (f && !Object.values(candidate).includes(f)) candidate[idx] = f;
    });
    const fields = Object.values(candidate);
    if (fields.includes("description") && fields.length >= 2) {
      headerRow = i;
      mapping = candidate;
      break;
    }
  }

  if (headerRow === -1)
    throw new Error(
      "No asset columns were recognised. The sheet needs a header row containing at least a Description column (plus Category, Purchase Date, Cost as available).",
    );

  const warnings: string[] = [];
  const unmatchedCategories = new Set<string>();
  const assets: Asset[] = [];
  let skipped = 0;
  let sr = startSrNo;

  for (let i = headerRow + 1; i < grid.length; i++) {
    const row = grid[i] ?? [];
    const get = (field: keyof Asset): unknown => {
      const idx = Object.keys(mapping).find((k) => mapping[Number(k)] === field);
      return idx === undefined ? undefined : row[Number(idx)];
    };
    const description = String(get("description") ?? "").trim();
    const cost = toNumber(get("originalCost"));
    const addition = toNumber(get("additionThisYear"));
    if (!description || /^(total|grand total|sub total|subtotal)/i.test(description)) {
      if (description) skipped++;
      continue;
    }
    if (!cost && !addition && !toNumber(get("openingWdvCompanies")) && !toNumber(get("openingWdvIt"))) {
      // keep the row: a description-only line is still a valid asset shell
    }
    const cat = matchCategory(String(get("category") ?? ""), rates);
    if (!cat.matched && String(get("category") ?? "").trim()) unmatchedCategories.add(cat.category);
    const methodRaw = norm(get("method"));
    const method: DepMethod = methodRaw.startsWith("s") ? "SLM" : "WDV";
    const disposalDate = toDate(get("disposalDate"));

    assets.push({
      id: crypto.randomUUID(),
      srNo: toNumber(get("srNo")) || sr,
      description,
      category: cat.category,
      location: String(get("location") ?? "").trim(),
      purchaseDate: toDate(get("purchaseDate")),
      originalCost: cost || addition,
      additionThisYear: addition,
      additionDate: addition > 0 ? toDate(get("additionDate")) || toDate(get("purchaseDate")) : "",
      disposalDate,
      saleValue: disposalDate ? toNumber(get("saleValue")) : 0,
      method,
      residualPct: get("residualPct") === undefined ? 0.05 : toPct(get("residualPct")),
      openingWdvCompanies: toNumber(get("openingWdvCompanies")),
      openingWdvIt: toNumber(get("openingWdvIt")),
    });
    sr++;
  }

  if (!assets.length)
    throw new Error("The header row was found but no asset rows followed it. Check the file and try again.");

  if (unmatchedCategories.size)
    warnings.push(
      `These categories are not in the rate master and were imported as-is — add them in Setup → Rate Master: ${[...unmatchedCategories].join(", ")}`,
    );
  if (skipped) warnings.push(`${skipped} total / sub-total row(s) were ignored.`);

  return { assets, skipped, warnings, sheetName };
}

export function downloadImportTemplate(rates: RateRow[]) {
  const wb = XLSX.utils.book_new();
  const sample = [
    {
      "Sr. No.": 1,
      Description: "Dell Latitude 5450 laptop",
      Category: rates.find((r) => r.category.includes("Computer"))?.category ?? rates[0]!.category,
      Location: "Head Office",
      "Date of Purchase": "2025-07-15",
      "Original Cost": 78000,
      "Addition during year": 78000,
      "Disposal Date": "",
      "Sale Value": "",
      Method: "WDV",
      "Residual %": 0.05,
      "CA Opening WDV": 0,
      "IT Opening WDV": 0,
    },
    {
      "Sr. No.": 2,
      Description: "Office air conditioner (carried forward)",
      Category: rates.find((r) => r.category.includes("Office"))?.category ?? rates[0]!.category,
      Location: "Branch",
      "Date of Purchase": "2022-04-10",
      "Original Cost": 55000,
      "Addition during year": 0,
      "Disposal Date": "",
      "Sale Value": "",
      Method: "SLM",
      "Residual %": 0.05,
      "CA Opening WDV": 33000,
      "IT Opening WDV": 30000,
    },
  ];
  const ws = XLSX.utils.json_to_sheet(sample);
  ws["!cols"] = [
    { wch: 8 }, { wch: 38 }, { wch: 30 }, { wch: 16 }, { wch: 16 },
    { wch: 14 }, { wch: 18 }, { wch: 14 }, { wch: 12 }, { wch: 10 },
    { wch: 11 }, { wch: 16 }, { wch: 16 },
  ];
  XLSX.utils.book_append_sheet(wb, ws, "Asset Register");

  const notes = [
    ["How to use this template"],
    ["1. Keep the header row as-is and replace the two sample rows with the client's assets."],
    ["2. Dates may be written as 2025-07-15 or 15/07/2025 or as real Excel dates."],
    ["3. Amounts may include commas or the rupee symbol; blanks are treated as zero."],
    ["4. Residual % accepts 0.05 or 5."],
    ["5. Method accepts SLM or WDV (blank defaults to WDV)."],
    ["6. Categories should match the Rate Master below so useful life and IT block rates are applied."],
    ["7. Rows whose Description starts with Total / Sub-total are ignored."],
    [""],
    ["Categories available in the rate master"],
    ["Category", "Useful life (yrs)", "Income-tax block", "IT WDV rate"],
    ...rates.map((r) => [r.category, r.usefulLife, r.itBlock, r.itRate]),
  ];
  const nws = XLSX.utils.aoa_to_sheet(notes);
  nws["!cols"] = [{ wch: 60 }, { wch: 18 }, { wch: 34 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, nws, "Instructions");

  XLSX.writeFile(wb, "Fixed-Asset-Import-Template.xlsx");
}
