import { createFileRoute } from "@tanstack/react-router";
import { FarApp } from "@/components/far/FarApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fixed Asset Register & Depreciation Automation for CA Firms" },
      {
        name: "description",
        content:
          "Maintain a client-wise fixed asset register with automatic Companies Act Schedule II and Income-tax Act depreciation, deferred tax and audit schedules.",
      },
      { property: "og:title", content: "Fixed Asset Register & Depreciation Automation" },
      {
        property: "og:description",
        content:
          "Schedule II and Income-tax depreciation, deferred tax working, block summaries and audit alerts — offline and client-wise.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FarApp,
});

const TABS = ["Register", "Schedules", "Alerts", "Setup"] as const;
type Tab = (typeof TABS)[number];

