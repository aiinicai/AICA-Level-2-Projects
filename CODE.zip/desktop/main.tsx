import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import { FarApp } from "@/components/far/FarApp";
import "@/styles.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <FarApp />
  </StrictMode>,
);
