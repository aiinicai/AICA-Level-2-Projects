const { app, BrowserWindow, Menu } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 1500,
    height: 950,
    title: "Fixed Asset Register & Depreciation Automation",
    backgroundColor: "#f7f6f2",
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  });
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      { role: "fileMenu" },
      { role: "editMenu" },
      { role: "viewMenu" },
      { role: "windowMenu" },
    ]),
  );
  win.loadFile(path.join(__dirname, "..", "dist-desktop", "index.html"));
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
