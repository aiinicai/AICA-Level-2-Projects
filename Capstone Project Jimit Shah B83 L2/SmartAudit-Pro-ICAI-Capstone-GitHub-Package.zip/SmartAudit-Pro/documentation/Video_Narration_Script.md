# SmartAudit Pro - Exact Capstone Video Narration Script

**Target duration:** 6-7 minutes  
**Recording format:** Keep your face visible in a small camera window while screen-sharing the application.

## 0:00-0:35 - Introduction

“Hello. My capstone project is **SmartAudit Pro - Audit Sample Selector**. The objective of this project is to demonstrate how a simple Python-based desktop application can assist an auditor in population analysis, sample selection, identification of potentially higher-risk transactions, and audit documentation.

The application is intended as a decision-support and educational tool. It does not replace the auditor’s professional judgement.”

## 0:35-1:10 - Problem statement

“In a typical audit, the auditor may receive a large general ledger or transaction dump. Before testing, the auditor has to understand the population, decide an appropriate selection approach, identify individually important or unusual items, select samples and document the results.

When these activities are performed manually in spreadsheets, they can be repetitive and the selection logic may be difficult to reproduce. SmartAudit Pro brings these activities into one local desktop workflow.”

## 1:10-1:45 - Technology

“The application is developed in Python. Tkinter is used for the desktop interface, openpyxl for Excel processing, matplotlib for dashboard charts and ReportLab for PDF reporting.

The application runs locally on the user’s computer. For this demonstration I have also created a sample general-ledger population containing 500 dummy transactions.”

## 1:45-2:20 - Upload population

[Click Browse and select SmartAudit_Demo_Population.xlsx.]

“I will now upload the sample Excel population. The application reads the first worksheet and maps the key fields. Here, Amount is mapped to Amount, Date to Date, User to User and Narration to Narration.

The application displays basic population information such as the number of records, absolute population value, average value, maximum transaction and number of items identified by the current risk rules.”

## 2:20-3:25 - Four selection methods

[Set threshold to 1000000, sample size to 25, seed 42.]

“I have set a threshold of ten lakh rupees, a sample size of 25 and a random seed of 42.

First, **Random Sampling** selects items using a pseudo-random generator. The fixed seed makes the demonstration reproducible.

Second, **Systematic Sampling** uses a random starting point and then selects transactions at approximately equal intervals through the population.

Third, **Stratified Sampling** sorts the population by absolute transaction value and divides it into three value strata. Samples are then allocated across these strata. This demonstrates how stratification can ensure representation from different value bands.

Fourth, **Risk-based Selection** ranks transactions using predefined rules. In this prototype, points are assigned for transactions above the threshold, round-value amounts, weekend postings, year-end postings and selected sensitive narrations.

An important distinction is that this risk-based method is targeted testing. I would not describe it as statistical audit sampling.”

## 3:25-4:05 - Dashboard

[Open Dashboard.]

“The Dashboard provides a visual overview. The first chart shows the distribution of transaction values in the population. The second chart groups transactions based on the rule-based risk score.

These visuals help the user understand the population before finalising the audit approach.”

## 4:05-4:50 - Sample-size calculator

[Open Sample Size Calculator.]

“The application also includes an indicative attribute sample-size calculator. It uses population size, confidence level, tolerable deviation and expected deviation.

This is intentionally labelled as an indicative planning calculator. It is not represented as an SA 530 prescribed sample-size table. In an actual audit, sample size has to be determined considering the audit objective, assessed risk, population characteristics, tolerable misstatement or deviation, expected error and professional judgement.”

## 4:50-5:35 - Reports

[Return to sampling tab and export Excel report, then PDF.]

“After selecting the samples, the user can export an Excel audit report. It contains an audit summary, the selected transactions, risk information and methodology notes.

A PDF report can also be generated for presentation or documentation purposes.

This makes the selection reproducible because the method, sample size, threshold and seed can be retained along with the output.”

## 5:35-6:20 - Audit relevance and limitations

“The project is linked conceptually to SA 530 on Audit Sampling, and also demonstrates how technology can support risk assessment and audit responses.

However, the application does not determine whether a sample is sufficient and appropriate for a real engagement. The auditor remains responsible for validating the completeness and relevance of the population, deciding whether sampling is appropriate, determining sample size, investigating exceptions and reaching the audit conclusion.

The current risk rules are illustrative and would need to be tailored to the entity and engagement before actual audit use.”

## 6:20-6:45 - Conclusion

“To conclude, SmartAudit Pro demonstrates an end-to-end workflow from Excel population upload to analysis, sample selection, risk-based identification, visualisation and audit-report generation.

The project shows how a relatively simple desktop application can improve consistency, reproducibility and documentation while retaining the auditor’s professional judgement.

Thank you.”
