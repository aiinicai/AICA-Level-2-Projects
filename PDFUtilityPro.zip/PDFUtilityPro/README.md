# PDF Utility Pro

An offline PDF toolkit for Windows — split, merge, organise, redact and edit
PDF files without any document ever leaving the computer.

Built as an ICAI Capstone Project.

**100% Offline — Your Documents Never Leave Your Computer.** No cloud service,
no upload, no external API. The application opens no network connection and
works with the network cable unplugged.

---

## Folder structure

```
PDFUtilityPro/
├── main.py                     Entry point — start the application here
├── requirements.txt            Dependencies
├── build_exe.bat               One-click Windows .exe build
├── README.md                   This file
│
├── app/
│   ├── theme.py                Seven colour themes + live theme switching
│   ├── settings.py             Local settings (theme, recent files)
│   ├── pdf_ops.py              PDF engine — no GUI, independently testable
│   ├── common.py               Shared widgets, page canvas, background worker
│   ├── main_window.py          Toolbar, theme picker, screen stack, Help
│   └── pages/
│       ├── home.py             Home screen, five function cards, theme picker
│       ├── split_page.py       1. Split  (with batch mode)
│       ├── merge_page.py       2. Merge
│       ├── organise_page.py    3. Organise (single file + batch tabs)
│       ├── organise_batch.py   3b. Organise — batch mode
│       ├── redact_page.py      4. Redact
│       └── edit_page.py        5. Edit
│
├── docs/
│   ├── PROJECT_REPORT.md       Full capstone documentation
│   ├── USER_MANUAL.md          How to use each screen
│   ├── TEST_CASES.md           Test plan and results
│   └── DEMO_WORKFLOW.md        15-minute live demonstration script
│
├── tools/
│   ├── self_test.py            Automated engine tests (38 checks)
│   ├── gui_smoke_test.py       Builds every screen in every theme
│   └── make_samples.py         Regenerates the demo PDFs
│
└── samples/                    Demo PDFs for the evaluation
```

---

## Installation (development / demonstration machine)

Requires Python 3.10 or newer. Python 3.12 was used for development.

```
cd PDFUtilityPro
python -m venv .venv
.venv\Scripts\activate          (Windows)
source .venv/bin/activate       (Linux / macOS)
pip install -r requirements.txt
python main.py
```

## Running the tests

```
python tools/self_test.py                        # PDF engine, 38 checks
python tools/gui_smoke_test.py samples/Sample_Client_Report.pdf
```

`self_test.py` builds its own sample files, runs every operation and prints a
PASS/FAIL line for each. It needs no interface and no internet.

## Building the Windows .exe

Double-click `build_exe.bat`, or run:

```
pip install pyinstaller
pyinstaller --noconfirm --clean --name PDFUtilityPro --windowed --onefile ^
    --hidden-import pymupdf --collect-submodules pymupdf main.py
```

The result is `dist\PDFUtilityPro.exe` — a single file that runs on any Windows
PC without Python installed. First launch takes a few seconds while the
one-file bundle unpacks.

---

## The seven colour themes

Blue · Green · Purple · Orange · Red · Teal · Dark

Choose a theme from the dropdown in the toolbar, or from the swatches on the
home screen. The change applies to every screen immediately — including
custom-drawn surfaces such as the page canvas and the thumbnail grid — and is
saved, so the application reopens in the same theme.

Themes are defined as colour tokens in `app/theme.py`. Adding an eighth theme
means adding one `Theme(...)` entry and one line in `THEME_ORDER`; no other
file needs to change.
