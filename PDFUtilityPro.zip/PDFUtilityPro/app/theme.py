"""
Theme engine for PDF Utility Pro.

Provides seven selectable colour themes (Blue, Green, Purple, Orange, Red,
Teal, Dark). A single ThemeManager owns the active theme, writes the
generated Qt Style Sheet onto the QApplication, persists the choice through
QSettings and emits `changed` so that custom-painted widgets (page canvas,
thumbnail grid, notification bar) can repaint themselves in the new colours.

Nothing in this module touches the network or the filesystem other than the
per-user QSettings store.
"""

from __future__ import annotations

from dataclasses import dataclass
from string import Template
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap


# --------------------------------------------------------------------------- #
#  Colour helpers
# --------------------------------------------------------------------------- #
def mix(colour_a: str, colour_b: str, weight_a: float) -> str:
    """Blend two hex colours. weight_a = 1.0 returns colour_a unchanged."""
    a, b = QColor(colour_a), QColor(colour_b)
    w = max(0.0, min(1.0, weight_a))
    return QColor(
        round(a.red() * w + b.red() * (1 - w)),
        round(a.green() * w + b.green() * (1 - w)),
        round(a.blue() * w + b.blue() * (1 - w)),
    ).name()


@dataclass(frozen=True)
class Theme:
    """A complete set of colour tokens used by the whole application."""

    key: str
    name: str
    is_dark: bool
    primary: str
    primary_hover: str
    primary_pressed: str
    on_primary: str
    bg: str
    surface: str
    surface_alt: str
    border: str
    text: str
    text_muted: str
    success: str
    warning: str
    danger: str

    # Derived tokens -------------------------------------------------------
    @property
    def tint(self) -> str:
        """Very light wash of the primary colour, used for hover states."""
        return mix(self.primary, self.surface, 0.14)

    @property
    def tint_strong(self) -> str:
        """Selection / active wash."""
        return mix(self.primary, self.surface, 0.30)

    @property
    def canvas(self) -> str:
        """Backdrop behind a rendered PDF page."""
        return mix(self.border, self.bg, 0.55)

    def qcolor(self, token: str) -> QColor:
        return QColor(getattr(self, token))


# --------------------------------------------------------------------------- #
#  The seven themes
# --------------------------------------------------------------------------- #
THEMES: Dict[str, Theme] = {
    "blue": Theme(
        key="blue", name="Blue", is_dark=False,
        primary="#1565C0", primary_hover="#1B72D4", primary_pressed="#0D47A1",
        on_primary="#FFFFFF",
        bg="#F4F6FA", surface="#FFFFFF", surface_alt="#EAEFF7", border="#D3DBE7",
        text="#16202C", text_muted="#5A6B80",
        success="#1E7D46", warning="#B26A00", danger="#C0392B",
    ),
    "green": Theme(
        key="green", name="Green", is_dark=False,
        primary="#2E7D32", primary_hover="#37913C", primary_pressed="#1B5E20",
        on_primary="#FFFFFF",
        bg="#F3F8F3", surface="#FFFFFF", surface_alt="#E7F1E8", border="#CFE1D2",
        text="#16241A", text_muted="#54695A",
        success="#1E7D46", warning="#B26A00", danger="#C0392B",
    ),
    "purple": Theme(
        key="purple", name="Purple", is_dark=False,
        primary="#5E35B1", primary_hover="#6C43C1", primary_pressed="#4527A0",
        on_primary="#FFFFFF",
        bg="#F6F4FC", surface="#FFFFFF", surface_alt="#EDE8F8", border="#DAD2EE",
        text="#1F1830", text_muted="#63597D",
        success="#1E7D46", warning="#B26A00", danger="#C0392B",
    ),
    "orange": Theme(
        key="orange", name="Orange", is_dark=False,
        primary="#D2691E", primary_hover="#E2761F", primary_pressed="#A9520F",
        on_primary="#FFFFFF",
        bg="#FBF5EF", surface="#FFFFFF", surface_alt="#F7E9DA", border="#EBD7C0",
        text="#2A1D12", text_muted="#77604B",
        success="#1E7D46", warning="#B26A00", danger="#C0392B",
    ),
    "red": Theme(
        key="red", name="Red", is_dark=False,
        primary="#C62828", primary_hover="#D33232", primary_pressed="#9B1C1C",
        on_primary="#FFFFFF",
        bg="#FCF5F5", surface="#FFFFFF", surface_alt="#F7E6E6", border="#EDD1D1",
        text="#2A1616", text_muted="#7A5757",
        success="#1E7D46", warning="#B26A00", danger="#9B1C1C",
    ),
    "teal": Theme(
        key="teal", name="Teal", is_dark=False,
        primary="#00796B", primary_hover="#088C7C", primary_pressed="#00584E",
        on_primary="#FFFFFF",
        bg="#F1F8F7", surface="#FFFFFF", surface_alt="#E2F0EE", border="#C8E0DC",
        text="#12251F", text_muted="#4E6A66",
        success="#1E7D46", warning="#B26A00", danger="#C0392B",
    ),
    "dark": Theme(
        key="dark", name="Dark", is_dark=True,
        primary="#4F9CF9", primary_hover="#63A9FA", primary_pressed="#3B84DC",
        on_primary="#0B1220",
        bg="#141922", surface="#1D242F", surface_alt="#252E3B", border="#36414F",
        text="#E6ECF4", text_muted="#97A5B7",
        success="#4CC38A", warning="#E2A03F", danger="#F0736A",
    ),
}

THEME_ORDER: List[str] = ["blue", "green", "purple", "orange", "red", "teal", "dark"]
DEFAULT_THEME = "blue"


# --------------------------------------------------------------------------- #
#  Style sheet template
# --------------------------------------------------------------------------- #
_QSS = Template("""
* { font-family: "Segoe UI", "Noto Sans", "DejaVu Sans", Arial, sans-serif; }

QWidget            { background: $bg; color: $text; font-size: 10.5pt; }
QMainWindow        { background: $bg; }
QToolTip           { background: $surface; color: $text; border: 1px solid $border;
                     padding: 4px 6px; }

/* ---------- Structure ---------- */
QFrame#Card, QFrame#Panel {
    background: $surface; border: 1px solid $border; border-radius: 10px;
}
QFrame#Banner {
    background: $tint; border: 1px solid $tint_strong; border-radius: 10px;
}
QFrame#Divider { background: $border; max-height: 1px; border: none; }

QLabel { background: transparent; }
QLabel#H1 { font-size: 19pt; font-weight: 600; color: $text; }
QLabel#H2 { font-size: 13pt; font-weight: 600; color: $text; }
QLabel#Muted   { color: $text_muted; }
QLabel#Badge   { color: $primary; font-weight: 600; }
QLabel#Warning { color: $danger; font-weight: 600; }

/* ---------- Buttons ---------- */
QPushButton {
    background: $surface; color: $text; border: 1px solid $border;
    border-radius: 7px; padding: 7px 14px; min-height: 18px;
}
QPushButton:hover    { background: $surface_alt; border-color: $primary; }
QPushButton:pressed  { background: $tint; }
QPushButton:disabled { color: $text_muted; border-color: $border; background: $bg; }

QPushButton#Primary {
    background: $primary; color: $on_primary; border: 1px solid $primary;
    font-weight: 600; padding: 9px 20px;
}
QPushButton#Primary:hover    { background: $primary_hover; border-color: $primary_hover; }
QPushButton#Primary:pressed  { background: $primary_pressed; }
QPushButton#Primary:disabled { background: $surface_alt; color: $text_muted;
                               border-color: $border; }

QPushButton#Danger {
    background: $danger; color: #FFFFFF; border: 1px solid $danger; font-weight: 600;
}
QPushButton#Danger:hover { background: $danger; border-color: $text; }

/* Home screen function cards */
QFrame#FunctionCard {
    background: $surface; border: 1px solid $border; border-radius: 12px;
}
QFrame#FunctionCard[hover="true"] {
    background: $tint; border: 2px solid $primary;
}
QLabel#CardTitle { font-size: 12pt; font-weight: 600; color: $text; }
QLabel#CardDesc  { color: $text_muted; }
QFrame#FunctionCard[hover="true"] QLabel#CardTitle { color: $primary; }

/* Theme swatches */
QToolButton#Swatch { border: 2px solid $border; border-radius: 6px; }
QToolButton#Swatch:hover    { border: 2px solid $text_muted; }
QToolButton#Swatch:checked  { border: 3px solid $text; }

/* ---------- Inputs ---------- */
QLineEdit, QSpinBox, QComboBox, QPlainTextEdit, QTextEdit {
    background: $surface; color: $text; border: 1px solid $border;
    border-radius: 7px; padding: 6px 9px; selection-background-color: $primary;
    selection-color: $on_primary;
}
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus {
    border: 1px solid $primary;
}
QLineEdit:disabled, QSpinBox:disabled { background: $bg; color: $text_muted; }
QComboBox::drop-down { border: none; width: 20px; }
QComboBox QAbstractItemView {
    background: $surface; color: $text; border: 1px solid $border;
    selection-background-color: $primary; selection-color: $on_primary;
    outline: none;
}

QRadioButton, QCheckBox { spacing: 7px; padding: 3px 0; background: transparent; }
QCheckBox::indicator, QRadioButton::indicator { width: 15px; height: 15px; }
QCheckBox::indicator { border: 1px solid $border; border-radius: 3px; background: $surface; }
QRadioButton::indicator { border: 1px solid $border; border-radius: 8px; background: $surface; }
QCheckBox::indicator:checked, QRadioButton::indicator:checked {
    background: $primary; border: 1px solid $primary;
}

/* ---------- Lists / tables ---------- */
QListWidget, QTableWidget, QTreeWidget {
    background: $surface; border: 1px solid $border; border-radius: 8px;
    outline: none; alternate-background-color: $surface_alt;
}
QListWidget::item { padding: 6px 8px; border-radius: 5px; }
QListWidget::item:selected, QTableWidget::item:selected {
    background: $tint_strong; color: $text;
}
QListWidget::item:hover { background: $tint; }
QHeaderView::section {
    background: $surface_alt; color: $text_muted; border: none;
    border-bottom: 1px solid $border; padding: 7px 8px; font-weight: 600;
}
QTableWidget { gridline-color: $border; }

/* ---------- Chrome ---------- */
QToolBar {
    background: $surface; border: none; border-bottom: 1px solid $border;
    spacing: 6px; padding: 7px 10px;
}
QToolBar QToolButton {
    background: transparent; color: $text; border: 1px solid transparent;
    border-radius: 7px; padding: 6px 11px;
}
QToolBar QToolButton:hover   { background: $tint; border-color: $primary; }
QToolBar QToolButton:pressed { background: $tint_strong; }
QToolBar QLabel { color: $text_muted; }

QStatusBar { background: $surface; border-top: 1px solid $border; color: $text_muted; }
QStatusBar::item { border: none; }

QProgressBar {
    background: $surface_alt; border: 1px solid $border; border-radius: 7px;
    height: 15px; text-align: center; color: $text;
}
QProgressBar::chunk { background: $primary; border-radius: 6px; }

QGroupBox {
    background: $surface; border: 1px solid $border; border-radius: 9px;
    margin-top: 14px; padding: 12px 12px 10px 12px; font-weight: 600;
}
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; color: $text_muted; }

QScrollArea { border: none; background: $bg; }
QScrollBar:vertical   { background: transparent; width: 11px; margin: 2px; }
QScrollBar:horizontal { background: transparent; height: 11px; margin: 2px; }
QScrollBar::handle { background: $border; border-radius: 5px; min-height: 28px; min-width: 28px; }
QScrollBar::handle:hover { background: $text_muted; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

QMenu { background: $surface; border: 1px solid $border; padding: 5px; }
QMenu::item { padding: 6px 22px; border-radius: 5px; }
QMenu::item:selected { background: $primary; color: $on_primary; }

QTabWidget::pane { border: 1px solid $border; border-radius: 9px; background: $surface; top: -1px; }
QTabBar::tab {
    background: $surface_alt; color: $text_muted; border: 1px solid $border;
    border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px;
    padding: 8px 20px; margin-right: 4px;
}
QTabBar::tab:selected { background: $surface; color: $primary; font-weight: 600; }
QTabBar::tab:hover:!selected { background: $tint; }

QSplitter::handle { background: $border; }
QMessageBox, QDialog, QFileDialog { background: $bg; }
""")


def build_stylesheet(theme: Theme) -> str:
    """Render the QSS for a theme."""
    tokens = {
        "primary": theme.primary,
        "primary_hover": theme.primary_hover,
        "primary_pressed": theme.primary_pressed,
        "on_primary": theme.on_primary,
        "bg": theme.bg,
        "surface": theme.surface,
        "surface_alt": theme.surface_alt,
        "border": theme.border,
        "text": theme.text,
        "text_muted": theme.text_muted,
        "success": theme.success,
        "warning": theme.warning,
        "danger": theme.danger,
        "tint": theme.tint,
        "tint_strong": theme.tint_strong,
    }
    return _QSS.substitute(tokens)


def swatch_icon(theme: Theme, size: int = 18) -> QIcon:
    """A small two-tone chip used in the theme picker."""
    pm = QPixmap(size, size)
    pm.fill(QColor(theme.surface))
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setBrush(QColor(theme.primary))
    p.setPen(QColor(theme.border))
    p.drawRoundedRect(0, 0, size - 1, size - 1, 4, 4)
    p.setBrush(QColor(theme.surface if not theme.is_dark else theme.surface_alt))
    p.setPen(QColor(theme.primary))
    p.drawRoundedRect(size // 2, size // 2, size // 2 - 1, size // 2 - 1, 3, 3)
    p.end()
    return QIcon(pm)


# --------------------------------------------------------------------------- #
#  Manager
# --------------------------------------------------------------------------- #
class ThemeManager(QObject):
    """Owns the active theme and repaints the whole application on change."""

    changed = Signal(object)  # emits Theme

    def __init__(self, app, settings, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._app = app
        self._settings = settings
        self._current = THEMES.get(settings.theme(), THEMES[DEFAULT_THEME])

    # -- accessors ---------------------------------------------------------
    @property
    def current(self) -> Theme:
        return self._current

    @staticmethod
    def all_themes() -> List[Theme]:
        return [THEMES[k] for k in THEME_ORDER]

    # -- actions -----------------------------------------------------------
    def apply(self, key: str) -> None:
        theme = THEMES.get(key)
        if theme is None or theme.key == self._current.key:
            if theme is not None:
                self._app.setStyleSheet(build_stylesheet(theme))
            return
        self._current = theme
        self._settings.set_theme(theme.key)
        self._app.setStyleSheet(build_stylesheet(theme))
        self.changed.emit(theme)

    def apply_current(self) -> None:
        self._app.setStyleSheet(build_stylesheet(self._current))
        self.changed.emit(self._current)


_manager: Optional[ThemeManager] = None


def init_theme(app, settings) -> ThemeManager:
    global _manager
    _manager = ThemeManager(app, settings)
    _manager.apply_current()
    return _manager


def manager() -> ThemeManager:
    if _manager is None:  # pragma: no cover - defensive
        raise RuntimeError("Theme manager not initialised. Call init_theme() first.")
    return _manager


def current() -> Theme:
    return manager().current
