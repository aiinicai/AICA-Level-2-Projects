"""
pdf_ops.py — the PDF engine.

Pure, GUI-free functions built on PyMuPDF (fitz). Every function works on the
local filesystem only; there is no network code anywhere in this module. The
separation from the interface means each operation can be unit-tested on its
own, which is what the modular requirement of the capstone brief asks for.

File-safety rules enforced here:
  * the source file is opened read-only and never written back to;
  * output filenames are suggested as Original_Split.pdf, Original_Merged.pdf
    and so on;
  * if the suggested name already exists a numeric suffix is added, so an
    existing file is never silently overwritten;
  * corrupt and password-protected files raise PdfError with a readable
    message instead of crashing.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:  # PyMuPDF >= 1.24 exposes the package as `pymupdf`; older builds as `fitz`
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz


# --------------------------------------------------------------------------- #
#  Errors
# --------------------------------------------------------------------------- #
class PdfError(Exception):
    """Any recoverable problem with a PDF, shown to the user as a message."""


class PasswordRequired(PdfError):
    """The file is encrypted and needs a password (or the one given is wrong)."""


# --------------------------------------------------------------------------- #
#  Filename helpers
# --------------------------------------------------------------------------- #
def unique_path(path: os.PathLike | str) -> Path:
    """Return `path` if free, otherwise path with ` (2)`, ` (3)`... appended."""
    p = Path(path)
    if not p.exists():
        return p
    stem, suffix, parent = p.stem, p.suffix, p.parent
    n = 2
    while True:
        candidate = parent / f"{stem} ({n}){suffix}"
        if not candidate.exists():
            return candidate
        n += 1


def suggested_name(source: os.PathLike | str, tag: str) -> str:
    """Original.pdf + 'Split' -> Original_Split.pdf"""
    return f"{Path(source).stem}_{tag}.pdf"


def suggested_path(source: os.PathLike | str, tag: str,
                   out_dir: Optional[os.PathLike | str] = None) -> Path:
    folder = Path(out_dir) if out_dir else Path(source).parent
    return unique_path(folder / suggested_name(source, tag))


# --------------------------------------------------------------------------- #
#  Page specification parsing
# --------------------------------------------------------------------------- #
def parse_pages(spec: str, total: int) -> List[int]:
    """
    Turn a user page specification into a list of zero-based page indexes.

    Accepts '1,3,5', '2-7', '1-3, 9, 12-14', 'all', 'odd', 'even' and open
    ranges like '5-'. Pages are 1-based for the user, de-duplicated and kept
    in the order typed.
    """
    spec = (spec or "").strip().lower()
    if not spec or spec == "all":
        return list(range(total))
    if spec == "odd":
        return [i for i in range(total) if i % 2 == 0]
    if spec == "even":
        return [i for i in range(total) if i % 2 == 1]

    out: List[int] = []
    for chunk in re.split(r"[,\s]+", spec):
        if not chunk:
            continue
        m = re.fullmatch(r"(\d+)\s*[-–]\s*(\d*)", chunk)
        if m:
            start = int(m.group(1))
            end = int(m.group(2)) if m.group(2) else total
        elif chunk.isdigit():
            start = end = int(chunk)
        else:
            raise PdfError(f"'{chunk}' is not a valid page entry. Use 1, 3-7 or 9-.")
        if start < 1 or end < 1:
            raise PdfError("Page numbers start at 1.")
        if start > total or end > total:
            raise PdfError(f"This PDF has {total} page(s); '{chunk}' is out of range.")
        step = 1 if end >= start else -1
        for p in range(start, end + step, step):
            if (p - 1) not in out:
                out.append(p - 1)
    if not out:
        raise PdfError("No pages selected.")
    return out


def parse_ranges(spec: str, total: int) -> List[List[int]]:
    """Like parse_pages, but keeps each comma-separated group as its own list."""
    spec = (spec or "").strip()
    if not spec:
        raise PdfError("Enter at least one page range, for example 1-3, 4-8.")
    groups: List[List[int]] = []
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if chunk:
            groups.append(parse_pages(chunk, total))
    if not groups:
        raise PdfError("No page ranges recognised.")
    return groups


def describe_pages(indexes: Sequence[int]) -> str:
    """[0,1,2,5] -> '1-3, 6' (for filenames and status messages)."""
    if not indexes:
        return ""
    pages = sorted(i + 1 for i in indexes)
    parts, start, prev = [], pages[0], pages[0]
    for p in pages[1:]:
        if p == prev + 1:
            prev = p
            continue
        parts.append(f"{start}-{prev}" if prev > start else f"{start}")
        start = prev = p
    parts.append(f"{start}-{prev}" if prev > start else f"{start}")
    return ", ".join(parts)


# --------------------------------------------------------------------------- #
#  Opening documents
# --------------------------------------------------------------------------- #
def open_doc(path: os.PathLike | str, password: Optional[str] = None) -> fitz.Document:
    """Open a PDF, raising a readable PdfError for the usual failure modes."""
    p = Path(path)
    if not p.exists():
        raise PdfError(f"File not found: {p.name}")
    if p.stat().st_size == 0:
        raise PdfError(f"{p.name} is empty (0 bytes).")
    try:
        doc = fitz.open(str(p))
    except Exception as exc:  # corrupt / not a PDF
        raise PdfError(f"{p.name} could not be opened. It may be damaged or "
                       f"not a PDF file. ({exc})") from exc
    if doc.needs_pass:
        if not password or not doc.authenticate(password):
            doc.close()
            raise PasswordRequired(
                f"{p.name} is password-protected. Enter the correct open password."
            )
    if doc.page_count == 0:
        doc.close()
        raise PdfError(f"{p.name} contains no pages.")
    return doc


@dataclass
class DocInfo:
    path: str
    pages: int
    encrypted: bool
    size_bytes: int
    title: str = ""

    @property
    def name(self) -> str:
        return Path(self.path).name


def inspect(path: os.PathLike | str, password: Optional[str] = None) -> DocInfo:
    doc = open_doc(path, password)
    try:
        meta = doc.metadata or {}
        return DocInfo(
            path=str(path),
            pages=doc.page_count,
            encrypted=bool(doc.needs_pass or doc.is_encrypted),
            size_bytes=Path(path).stat().st_size,
            title=(meta.get("title") or "").strip(),
        )
    finally:
        doc.close()


def _save(out_doc: fitz.Document, out_path: Path) -> Path:
    out_path = unique_path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        out_doc.save(str(out_path), garbage=4, deflate=True)
    except Exception as exc:
        raise PdfError(f"Could not write {out_path.name}: {exc}") from exc
    return out_path


# --------------------------------------------------------------------------- #
#  1. Split
# --------------------------------------------------------------------------- #
def split_selected(source, spec: str, out_dir, password=None,
                   one_file: bool = True) -> List[Path]:
    """
    Extract chosen pages. `one_file=True` writes a single Original_Split.pdf,
    otherwise one PDF per page (Original_Page_3.pdf ...).
    """
    doc = open_doc(source, password)
    written: List[Path] = []
    try:
        pages = parse_pages(spec, doc.page_count)
        if one_file:
            out = fitz.open()
            for i in pages:
                out.insert_pdf(doc, from_page=i, to_page=i)
            written.append(_save(out, Path(out_dir) / suggested_name(source, "Split")))
            out.close()
        else:
            for i in pages:
                out = fitz.open()
                out.insert_pdf(doc, from_page=i, to_page=i)
                target = Path(out_dir) / f"{Path(source).stem}_Page_{i + 1}.pdf"
                written.append(_save(out, target))
                out.close()
    finally:
        doc.close()
    return written


def split_ranges(source, spec: str, out_dir, password=None) -> List[Path]:
    """One output PDF per comma-separated range, e.g. '1-3, 4-8' -> two files."""
    doc = open_doc(source, password)
    written: List[Path] = []
    try:
        for group in parse_ranges(spec, doc.page_count):
            out = fitz.open()
            for i in group:
                out.insert_pdf(doc, from_page=i, to_page=i)
            label = describe_pages(group).replace(", ", "_").replace("-", "to")
            target = Path(out_dir) / f"{Path(source).stem}_Split_{label}.pdf"
            written.append(_save(out, target))
            out.close()
    finally:
        doc.close()
    return written


def split_every(source, n: int, out_dir, password=None) -> List[Path]:
    """Split into consecutive chunks of n pages."""
    if n < 1:
        raise PdfError("Pages per file must be 1 or more.")
    doc = open_doc(source, password)
    written: List[Path] = []
    try:
        total = doc.page_count
        part = 1
        for start in range(0, total, n):
            end = min(start + n - 1, total - 1)
            out = fitz.open()
            out.insert_pdf(doc, from_page=start, to_page=end)
            target = Path(out_dir) / f"{Path(source).stem}_Split_Part{part}.pdf"
            written.append(_save(out, target))
            out.close()
            part += 1
    finally:
        doc.close()
    return written


# --------------------------------------------------------------------------- #
#  2. Merge
# --------------------------------------------------------------------------- #
def merge(sources: Sequence[os.PathLike | str], out_path,
          passwords: Optional[Dict[str, str]] = None) -> Path:
    if len(sources) < 2:
        raise PdfError("Select at least two PDF files to merge.")
    passwords = passwords or {}
    out = fitz.open()
    try:
        for src in sources:
            doc = open_doc(src, passwords.get(str(src)))
            try:
                out.insert_pdf(doc)
            finally:
                doc.close()
        return _save(out, Path(out_path))
    finally:
        out.close()


# --------------------------------------------------------------------------- #
#  3. Organise
# --------------------------------------------------------------------------- #
@dataclass
class PagePlan:
    """One page of the reorganised document."""
    source_index: int          # zero-based page in the original file
    rotation: int = 0          # extra rotation in degrees, added to the original


def organise(source, plan: Sequence[PagePlan], out_path, password=None) -> Path:
    """Rebuild a document from an explicit ordered plan (reorder / delete /
    duplicate / rotate / extract are all expressed through the plan)."""
    if not plan:
        raise PdfError("The document would have no pages left. Keep at least one page.")
    doc = open_doc(source, password)
    out = fitz.open()
    try:
        for item in plan:
            if not 0 <= item.source_index < doc.page_count:
                raise PdfError(f"Page {item.source_index + 1} is not in the source file.")
            out.insert_pdf(doc, from_page=item.source_index, to_page=item.source_index)
            page = out[-1]
            base = doc[item.source_index].rotation
            page.set_rotation((base + item.rotation) % 360)
        return _save(out, Path(out_path))
    finally:
        out.close()
        doc.close()


def extract_pages(source, indexes: Sequence[int], out_path, password=None) -> Path:
    return organise(source, [PagePlan(i) for i in indexes], out_path, password)


def transform(source, out_path, extract: str = "", delete: str = "",
              rotate: int = 0, reverse: bool = False, password=None) -> Path:
    """
    Apply page operations expressed as page specifications rather than as an
    interactive plan. This is what batch mode uses: the same instruction can be
    applied to many files without opening each one in the thumbnail editor.

    Order of application: extract (keep only these), then delete, then reverse,
    then rotate every surviving page.
    """
    doc = open_doc(source, password)
    try:
        total = doc.page_count
    finally:
        doc.close()

    indexes = parse_pages(extract, total) if extract.strip() else list(range(total))
    if delete.strip():
        dropped = set(parse_pages(delete, total))
        indexes = [i for i in indexes if i not in dropped]
    if reverse:
        indexes = list(reversed(indexes))
    if not indexes:
        raise PdfError("Those settings would remove every page. "
                       "At least one page must remain.")
    if rotate % 360 == 0 and not reverse and not extract.strip() and not delete.strip():
        raise PdfError("No operation selected. Choose pages to extract or "
                       "delete, a rotation, or reverse order.")

    plan = [PagePlan(i, rotate % 360) for i in indexes]
    return organise(source, plan, out_path, password)


# --------------------------------------------------------------------------- #
#  4. Redact
# --------------------------------------------------------------------------- #
@dataclass
class RedactArea:
    page: int                                  # zero-based
    rect: Tuple[float, float, float, float]    # PDF points, page coordinates


def redact(source, areas: Sequence[RedactArea], out_path, password=None,
           fill: Tuple[float, float, float] = (0, 0, 0)) -> Path:
    """
    Permanently remove content inside the given rectangles.

    PyMuPDF's apply_redactions() deletes the underlying text, vector and image
    content in the marked area — it is not a black rectangle drawn on top —
    and the file is then saved with garbage collection so the removed objects
    cannot be recovered. The action is irreversible, which is why the caller
    always writes to a new file.
    """
    if not areas:
        raise PdfError("Mark at least one area to redact.")
    doc = open_doc(source, password)
    try:
        touched = set()
        for area in areas:
            if not 0 <= area.page < doc.page_count:
                raise PdfError(f"Page {area.page + 1} is not in this document.")
            page = doc[area.page]
            rect = fitz.Rect(*area.rect).normalize()
            if rect.is_empty:
                continue
            page.add_redact_annot(rect, fill=fill)
            touched.add(area.page)
        if not touched:
            raise PdfError("The marked areas are empty. Draw a box over the content.")
        for pno in sorted(touched):
            doc[pno].apply_redactions()
        out_path = unique_path(Path(out_path))
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out_path), garbage=4, deflate=True, clean=True)
        return Path(out_path)
    finally:
        doc.close()


def textbox(doc: fitz.Document, page_no: int, rect) -> str:
    """Text inside a rectangle of an already-open document."""
    return doc[page_no].get_textbox(fitz.Rect(*rect).normalize()).strip()


def text_in_rect(source, page: int, rect, password=None) -> str:
    """Preview the text that a redaction box will destroy."""
    doc = open_doc(source, password)
    try:
        return doc[page].get_textbox(fitz.Rect(*rect).normalize()).strip()
    finally:
        doc.close()


# --------------------------------------------------------------------------- #
#  5. Edit (annotate)
# --------------------------------------------------------------------------- #
@dataclass
class Edit:
    """
    One editing action. `kind` is one of:
      text, date, image, line, rect, highlight, note, rotate, clear_annots
    """
    kind: str
    page: int
    rect: Optional[Tuple[float, float, float, float]] = None
    point: Optional[Tuple[float, float]] = None
    point2: Optional[Tuple[float, float]] = None
    text: str = ""
    image_path: str = ""
    colour: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    size: float = 12.0
    width: float = 1.5
    rotation: int = 0
    extra: dict = field(default_factory=dict)


def apply_edits(source, edits: Sequence[Edit], out_path, password=None) -> Path:
    """Apply annotation-style edits in order and save to a new file."""
    if not edits:
        raise PdfError("No changes to save.")
    doc = open_doc(source, password)
    try:
        rotations: Dict[int, int] = {}
        for e in edits:
            if not 0 <= e.page < doc.page_count:
                raise PdfError(f"Page {e.page + 1} is not in this document.")
            page = doc[e.page]

            if e.kind in ("text", "date"):
                if not e.text:
                    continue
                point = fitz.Point(*(e.point or (72, 72)))
                page.insert_text(point, e.text, fontsize=e.size,
                                 fontname="helv", color=e.colour)

            elif e.kind == "image":
                if not e.image_path or not Path(e.image_path).exists():
                    raise PdfError("Signature or image file not found.")
                rect = fitz.Rect(*e.rect).normalize()
                if rect.is_empty:
                    raise PdfError("Draw a box for the signature or image first.")
                page.insert_image(rect, filename=e.image_path, keep_proportion=True)

            elif e.kind == "line":
                page.draw_line(fitz.Point(*e.point), fitz.Point(*e.point2),
                               color=e.colour, width=e.width)

            elif e.kind == "rect":
                rect = fitz.Rect(*e.rect).normalize()
                fill = e.extra.get("fill")
                page.draw_rect(rect, color=e.colour, width=e.width, fill=fill)

            elif e.kind == "highlight":
                rect = fitz.Rect(*e.rect).normalize()
                annot = page.add_highlight_annot(rect)
                annot.set_colors(stroke=e.colour)
                annot.update()

            elif e.kind == "note":
                annot = page.add_text_annot(fitz.Point(*e.point), e.text or "Note")
                annot.set_colors(stroke=e.colour)
                annot.update()

            elif e.kind == "rotate":
                rotations[e.page] = rotations.get(e.page, 0) + e.rotation

            elif e.kind == "clear_annots":
                for annot in list(page.annots() or []):
                    page.delete_annot(annot)

            else:
                raise PdfError(f"Unknown edit type '{e.kind}'.")

        for pno, delta in rotations.items():
            page = doc[pno]
            page.set_rotation((page.rotation + delta) % 360)

        out_path = unique_path(Path(out_path))
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out_path), garbage=4, deflate=True)
        return Path(out_path)
    finally:
        doc.close()


def annotation_count(source, password=None) -> int:
    doc = open_doc(source, password)
    try:
        return sum(len(list(page.annots() or [])) for page in doc)
    finally:
        doc.close()


# --------------------------------------------------------------------------- #
#  Rendering (for thumbnails and page preview)
# --------------------------------------------------------------------------- #
def render_page_png(doc: fitz.Document, page_no: int, zoom: float = 1.0,
                    extra_rotation: int = 0) -> Tuple[bytes, int, int]:
    """Render a page to PNG bytes. Returns (png, width_px, height_px)."""
    page = doc[page_no]
    matrix = fitz.Matrix(zoom, zoom)
    if extra_rotation:
        matrix = matrix * fitz.Matrix(extra_rotation)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    return pix.tobytes("png"), pix.width, pix.height


def page_size(doc: fitz.Document, page_no: int) -> Tuple[float, float]:
    r = doc[page_no].rect
    return r.width, r.height


# --------------------------------------------------------------------------- #
#  Batch helper
# --------------------------------------------------------------------------- #
@dataclass
class BatchResult:
    source: str
    ok: bool
    message: str
    outputs: List[str] = field(default_factory=list)


def run_batch(files: Iterable[os.PathLike | str], operation, progress=None
              ) -> List[BatchResult]:
    """
    Apply `operation(path) -> list[Path]` to every file, never stopping on a
    failure. `progress(done, total, name)` is called after each file so the
    interface can show per-file status.
    """
    files = [str(f) for f in files]
    results: List[BatchResult] = []
    total = len(files)
    for n, path in enumerate(files, start=1):
        try:
            outputs = operation(path) or []
            results.append(BatchResult(path, True,
                                       f"{len(outputs)} file(s) created",
                                       [str(o) for o in outputs]))
        except PdfError as exc:
            results.append(BatchResult(path, False, str(exc)))
        except Exception as exc:  # unexpected, still must not crash the app
            results.append(BatchResult(path, False, f"Unexpected error: {exc}"))
        if progress:
            progress(n, total, Path(path).name)
    return results
