"""Main window: toolbar, theme picker, screen stack, status bar."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QLabel,
                               QMainWindow, QStackedWidget, QTextBrowser,
                               QToolBar, QVBoxLayout, QWidget)

from . import theme as theming
from .common import muted
from .pages.edit_page import EditPage
from .pages.home import HomePage
from .pages.merge_page import MergePage
from .pages.organise_page import OrganisePage
from .pages.redact_page import RedactPage
from .pages.split_page import SplitPage

APP_TITLE = "PDF Utility Pro — Offline PDF Toolkit"
VERSION = "1.0"

HELP_HTML = """
<h2>PDF Utility Pro {version}</h2>
<p>An offline desktop utility for everyday PDF work, built as an ICAI capstone
project.</p>

<h3>Your documents stay on this computer</h3>
<p>Every page is processed locally by the PyMuPDF library. The application
opens no network connection, uses no cloud service and calls no external API.
It works with the network cable unplugged.</p>

<h3>The five tools</h3>
<ul>
<li><b>Split</b> — take out chosen pages, cut a file into ranges, or break it
into fixed-size parts. Several files can be split in one go.</li>
<li><b>Merge</b> — join files in the order you arrange them.</li>
<li><b>Organise</b> — reorder, rotate, duplicate, delete or extract pages using
thumbnails.</li>
<li><b>Redact</b> — permanently delete confidential content inside a marked box.
The text is removed from the file, not covered over.</li>
<li><b>Edit</b> — add text, a date, a signature image, lines, boxes,
highlights and notes; rotate pages; remove existing annotations.</li>
</ul>

<h3>Colour themes</h3>
<p>Seven themes are available: Blue, Green, Purple, Orange, Red, Teal and Dark.
Pick one from the toolbar or from the cards on the home screen. The choice
applies everywhere immediately and is remembered next time.</p>

<h3>File safety</h3>
<p>The file you open is never modified. Results are written to a new file with
a suggested name such as Original_Split.pdf. If that name is already taken, a
numbered copy is written instead.</p>

<h3>Page numbers</h3>
<p>Type page selections as 1, 4, 9-12. An open range such as 5- means page 5 to
the end. You can also type all, odd or even.</p>
"""


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Help and About")
        self.resize(640, 560)
        lay = QVBoxLayout(self)
        browser = QTextBrowser()
        browser.setHtml(HELP_HTML.format(version=VERSION))
        lay.addWidget(browser)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        lay.addWidget(buttons)


class MainWindow(QMainWindow):
    def __init__(self, settings):
        super().__init__()
        self._settings = settings
        self.setWindowTitle(APP_TITLE)
        self.resize(1180, 820)
        self.setMinimumSize(980, 680)

        # -- screens ---------------------------------------------------------
        self.stack = QStackedWidget()
        self.home = HomePage(settings)
        self.split = SplitPage(settings)
        self.merge = MergePage(settings)
        self.organise = OrganisePage(settings)
        self.redact = RedactPage(settings)
        self.edit = EditPage(settings)

        self._screens = {
            "home": self.home, "split": self.split, "merge": self.merge,
            "organise": self.organise, "redact": self.redact, "edit": self.edit,
        }
        for widget in self._screens.values():
            self.stack.addWidget(widget)
        self.setCentralWidget(self.stack)

        for page in (self.split, self.merge, self.organise, self.redact, self.edit):
            page.file_used.connect(self._remember_file)

        self.home.open_function.connect(self.show_screen)
        self.home.open_recent.connect(self._open_recent)
        self.home.clear_recent.connect(self._clear_recent)

        self._build_toolbar()
        self._build_statusbar()
        self.show_screen("home")
        theming.manager().changed.connect(self._on_theme_changed)

    # -- chrome ------------------------------------------------------------
    def _build_toolbar(self) -> None:
        bar = QToolBar("Main")
        bar.setMovable(False)
        bar.setIconSize(QSize(18, 18))
        self.addToolBar(bar)

        def add(text: str, slot, tip: str = "") -> QAction:
            action = QAction(text, self)
            action.setToolTip(tip or text)
            action.triggered.connect(slot)
            bar.addAction(action)
            return action

        add("Home", lambda: self.show_screen("home"))
        bar.addSeparator()
        add("Split", lambda: self.show_screen("split"))
        add("Merge", lambda: self.show_screen("merge"))
        add("Organise", lambda: self.show_screen("organise"))
        add("Redact", lambda: self.show_screen("redact"))
        add("Edit", lambda: self.show_screen("edit"))
        bar.addSeparator()
        add("Open PDF", self._open_in_current, "Open a PDF in the current tool")
        add("Save as", self._save_current, "Save the current work to a new file")
        add("Clear", self._reset_current, "Clear the current screen")

        spacer = QWidget()
        spacer.setSizePolicy(spacer.sizePolicy().horizontalPolicy(),
                             spacer.sizePolicy().verticalPolicy())
        spacer.setMinimumWidth(1)
        bar.addWidget(spacer)

        bar.addWidget(QLabel("  Theme  "))
        self.theme_combo = QComboBox()
        self.theme_combo.setMinimumWidth(140)
        for th in theming.ThemeManager.all_themes():
            self.theme_combo.addItem(theming.swatch_icon(th), th.name, th.key)
        self.theme_combo.setCurrentIndex(
            theming.THEME_ORDER.index(theming.current().key))
        self.theme_combo.currentIndexChanged.connect(
            lambda i: theming.manager().apply(self.theme_combo.itemData(i)))
        bar.addWidget(self.theme_combo)
        bar.addSeparator()
        add("Help", self._show_help)

    def _build_statusbar(self) -> None:
        self.offline_label = QLabel("100% Offline — Your Documents Never Leave "
                                    "Your Computer")
        self.status_label = QLabel("Ready")
        self.statusBar().addWidget(self.status_label, 1)
        self.statusBar().addPermanentWidget(self.offline_label)

    # -- navigation --------------------------------------------------------
    def show_screen(self, key: str) -> None:
        widget = self._screens.get(key)
        if widget is None:
            return
        self.stack.setCurrentWidget(widget)
        pretty = "Home" if key == "home" else key.capitalize() + " PDF"
        self.status_label.setText(pretty)
        self.setWindowTitle(f"{APP_TITLE} — {pretty}")

    def _current(self):
        return self.stack.currentWidget()

    def _open_in_current(self) -> None:
        page = self._current()
        if hasattr(page, "open_dialog"):
            page.open_dialog()
        elif hasattr(page, "add_files_dialog"):
            page.add_files_dialog()
        else:
            self.show_screen("split")
            self.split.add_files_dialog()

    def _save_current(self) -> None:
        page = self._current()
        if hasattr(page, "save_as"):
            page.save_as()
        elif hasattr(page, "run"):
            page.run()
        else:
            self.status_label.setText("Nothing to save on this screen.")

    def _reset_current(self) -> None:
        page = self._current()
        if hasattr(page, "reset"):
            page.reset()
            self.status_label.setText("Screen cleared.")

    # -- recent files ------------------------------------------------------
    def _remember_file(self, path: str) -> None:
        self._settings.add_recent(path)
        self.home.refresh_recent()
        self.status_label.setText(f"Opened {Path(path).name}")

    def _open_recent(self, path: str) -> None:
        if not path:
            return
        page = self._current()
        if page is self.home or not hasattr(page, "load_file"):
            self.show_screen("organise")
            page = self.organise
        page.load_file(path)

    def _clear_recent(self) -> None:
        self._settings.clear_recent()
        self.home.refresh_recent()
        self.status_label.setText("Recent file list cleared.")

    # -- misc --------------------------------------------------------------
    def _show_help(self) -> None:
        HelpDialog(self).exec()

    def _on_theme_changed(self, th) -> None:
        index = theming.THEME_ORDER.index(th.key)
        if self.theme_combo.currentIndex() != index:
            self.theme_combo.blockSignals(True)
            self.theme_combo.setCurrentIndex(index)
            self.theme_combo.blockSignals(False)
        for i, key in enumerate(theming.THEME_ORDER):
            self.theme_combo.setItemIcon(i, theming.swatch_icon(theming.THEMES[key]))
        self.status_label.setText(f"{th.name} theme applied.")

    def closeEvent(self, event) -> None:
        for page in (self.redact, self.edit):
            page._close_doc()
        super().closeEvent(event)
