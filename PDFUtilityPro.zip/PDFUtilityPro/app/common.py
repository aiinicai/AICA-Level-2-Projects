"""
Widgets and helpers shared by every screen.

Everything here listens to the theme manager, so switching the colour theme
repaints custom-drawn surfaces (page canvas, notification bar, drop zone) as
well as the style-sheet-driven widgets.
"""

from __future__ import annotations

import traceback
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from PySide6.QtCore import (QObject, QPoint, QRect, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QFont, QImage, QPainter, QPen, QPixmap)
from PySide6.QtWidgets import (QFileDialog, QFrame, QGroupBox, QHBoxLayout,
                               QInputDialog, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton,
                               QSizePolicy, QToolButton, QVBoxLayout, QWidget)

from . import theme as theming
from .pdf_ops import PasswordRequired, PdfError

PDF_FILTER = "PDF files (*.pdf);;All files (*)"


# --------------------------------------------------------------------------- #
#  Small helpers
# --------------------------------------------------------------------------- #
def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def ask_password(parent, filename: str) -> Optional[str]:
    pw, ok = QInputDialog.getText(
        parent, "Password required",
        f"{filename} is password-protected.\nEnter the open password:",
        QLineEdit.Password)
    return pw if ok and pw else None


def show_error(parent, message: str, title: str = "Cannot continue") -> None:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    box.setText(message)
    box.exec()


def choose_folder(parent, start: str, caption: str = "Choose output folder") -> str:
    return QFileDialog.getExistingDirectory(parent, caption, start) or ""


# --------------------------------------------------------------------------- #
#  Background worker
# --------------------------------------------------------------------------- #
class WorkerSignals(QObject):
    progress = Signal(int, int, str)   # done, total, label
    finished = Signal(object)          # result
    failed = Signal(str)


class Worker(QRunnable):
    """Runs a callable off the UI thread so long batches keep the app responsive."""

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self.signals = WorkerSignals()
        self._fn, self._args, self._kwargs = fn, args, kwargs
        self._kwargs["progress"] = self.signals.progress.emit

    @Slot()
    def run(self) -> None:
        try:
            result = self._fn(*self._args, **self._kwargs)
        except PdfError as exc:
            self.signals.failed.emit(str(exc))
        except Exception:
            self.signals.failed.emit(
                "Unexpected error:\n" + traceback.format_exc(limit=2))
        else:
            self.signals.finished.emit(result)


def run_in_background(worker: Worker) -> None:
    QThreadPool.globalInstance().start(worker)


# --------------------------------------------------------------------------- #
#  Notification bar
# --------------------------------------------------------------------------- #
class NotificationBar(QFrame):
    """Inline success / error strip; theme-aware, auto-hides after a while."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setVisible(False)
        self.setFrameShape(QFrame.NoFrame)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        self._label = QLabel("")
        self._label.setWordWrap(True)
        self._close = QToolButton()
        self._close.setText("✕")
        self._close.setCursor(Qt.PointingHandCursor)
        self._close.clicked.connect(lambda: self.setVisible(False))
        lay.addWidget(self._label, 1)
        lay.addWidget(self._close, 0, Qt.AlignTop)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(lambda: self.setVisible(False))
        self._kind = "info"
        theming.manager().changed.connect(lambda _t: self._restyle())

    def _restyle(self) -> None:
        t = theming.current()
        colour = {"success": t.success, "error": t.danger, "info": t.primary}[self._kind]
        self.setStyleSheet(
            f"QFrame {{ background: {theming.mix(colour, t.surface, 0.12)};"
            f" border: 1px solid {theming.mix(colour, t.surface, 0.45)};"
            f" border-radius: 8px; }}"
            f"QLabel {{ color: {t.text}; background: transparent; }}"
            f"QToolButton {{ color: {t.text_muted}; background: transparent;"
            f" border: none; }}")

    def _show(self, kind: str, text: str, timeout: int) -> None:
        self._kind = kind
        self._label.setText(text)
        self._restyle()
        self.setVisible(True)
        self._timer.stop()
        if timeout:
            self._timer.start(timeout)

    def success(self, text: str) -> None:
        self._show("success", text, 9000)

    def error(self, text: str) -> None:
        self._show("error", text, 0)

    def info(self, text: str) -> None:
        self._show("info", text, 6000)


# --------------------------------------------------------------------------- #
#  Section headings
# --------------------------------------------------------------------------- #
class BatchResultView(QWidget):
    """
    Shows the outcome of a batch run with successes and failures in separate
    panels, so a failed file is never lost among the successful ones.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(12)

        self._ok_box = QGroupBox("Successful (0)")
        ok_lay = QVBoxLayout(self._ok_box)
        self.ok_list = QListWidget()
        ok_lay.addWidget(self.ok_list)

        self._bad_box = QGroupBox("Failed (0)")
        bad_lay = QVBoxLayout(self._bad_box)
        self.bad_list = QListWidget()
        bad_lay.addWidget(self.bad_list)

        lay.addWidget(self._ok_box, 1)
        lay.addWidget(self._bad_box, 1)
        self.setMinimumHeight(170)

    def clear(self) -> None:
        self.ok_list.clear()
        self.bad_list.clear()
        self._ok_box.setTitle("Successful (0)")
        self._bad_box.setTitle("Failed (0)")

    def show_results(self, results) -> int:
        """Populate both panels. Returns the number of output files created."""
        self.clear()
        created = 0
        for res in results:
            name = Path(res.source).name
            if res.ok:
                created += len(res.outputs)
                outputs = ", ".join(Path(o).name for o in res.outputs)
                item = QListWidgetItem(f"{name}  →  {outputs}" if outputs else name)
                item.setToolTip(res.source)
                self.ok_list.addItem(item)
            else:
                item = QListWidgetItem(f"{name}  —  {res.message}")
                item.setToolTip(res.source)
                self.bad_list.addItem(item)
        self._ok_box.setTitle(f"Successful ({self.ok_list.count()})")
        self._bad_box.setTitle(f"Failed ({self.bad_list.count()})")
        return created


def heading(text: str, level: int = 2) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("H1" if level == 1 else "H2")
    return lbl


def muted(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("Muted")
    lbl.setWordWrap(True)
    return lbl


def card(*widgets: QWidget, spacing: int = 10) -> QFrame:
    frame = QFrame()
    frame.setObjectName("Card")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(16, 14, 16, 14)
    lay.setSpacing(spacing)
    for w in widgets:
        lay.addWidget(w)
    return frame


class FilePathRow(QWidget):
    """A read-only path box with a Browse button."""

    changed = Signal(str)

    def __init__(self, caption: str, folder_mode: bool = False, parent=None):
        super().__init__(parent)
        self._caption = caption
        self._folder_mode = folder_mode
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText(caption)
        self.edit.textChanged.connect(self.changed.emit)
        btn = QPushButton("Browse")
        btn.clicked.connect(self._browse)
        lay.addWidget(self.edit, 1)
        lay.addWidget(btn)

    def _browse(self) -> None:
        start = self.edit.text() or str(Path.home())
        if self._folder_mode:
            path = QFileDialog.getExistingDirectory(self, self._caption, start)
        else:
            path, _ = QFileDialog.getOpenFileName(self, self._caption, start, PDF_FILTER)
        if path:
            self.edit.setText(path)

    def path(self) -> str:
        return self.edit.text().strip()

    def set_path(self, path: str) -> None:
        self.edit.setText(path)


# --------------------------------------------------------------------------- #
#  Page canvas — used by Redact and Edit
# --------------------------------------------------------------------------- #
class PageCanvas(QWidget):
    """
    Displays one rendered PDF page and lets the user draw rectangles, lines or
    click points on it. Widget coordinates are converted back to PDF points so
    the engine can work in the document's own coordinate system.
    """

    area_drawn = Signal(tuple)     # (x0, y0, x1, y1) in PDF points
    point_clicked = Signal(tuple)  # (x, y) in PDF points

    MODE_NONE, MODE_RECT, MODE_LINE, MODE_POINT = "none", "rect", "line", "point"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(420, 560)
        self.setMouseTracking(True)
        self._pixmap: Optional[QPixmap] = None
        self._zoom = 1.0
        self._mode = self.MODE_NONE
        self._origin: Optional[QPoint] = None
        self._cursor: Optional[QPoint] = None
        self._overlays: List[Tuple[QRectF, str]] = []   # (pdf rect, style)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        theming.manager().changed.connect(lambda _t: self.update())

    # -- content -----------------------------------------------------------
    def set_page(self, png_bytes: bytes, zoom: float) -> None:
        image = QImage.fromData(png_bytes, "PNG")
        self._pixmap = QPixmap.fromImage(image)
        self._zoom = zoom
        self.setFixedSize(self._pixmap.size())
        self.update()

    def clear_page(self) -> None:
        self._pixmap = None
        self._overlays.clear()
        self.setMinimumSize(420, 560)
        self.update()

    def set_mode(self, mode: str) -> None:
        self._mode = mode
        self.setCursor(Qt.CrossCursor if mode != self.MODE_NONE else Qt.ArrowCursor)

    def set_overlays(self, rects: List[Tuple[Tuple[float, float, float, float], str]]) -> None:
        self._overlays = [(QRectF(r[0], r[1], r[2] - r[0], r[3] - r[1]), style)
                          for r, style in rects]
        self.update()

    # -- coordinate mapping ------------------------------------------------
    def _to_pdf(self, pt: QPoint) -> Tuple[float, float]:
        return (pt.x() / self._zoom, pt.y() / self._zoom)

    def _to_widget(self, rect: QRectF) -> QRect:
        z = self._zoom
        return QRect(int(rect.x() * z), int(rect.y() * z),
                     int(rect.width() * z), int(rect.height() * z))

    # -- mouse -------------------------------------------------------------
    def mousePressEvent(self, event) -> None:
        if self._pixmap is None or self._mode == self.MODE_NONE:
            return
        if event.button() != Qt.LeftButton:
            return
        if self._mode == self.MODE_POINT:
            self.point_clicked.emit(self._to_pdf(event.position().toPoint()))
            return
        self._origin = event.position().toPoint()
        self._cursor = self._origin
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._origin is not None:
            self._cursor = event.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, event) -> None:
        if self._origin is None:
            return
        end = event.position().toPoint()
        x0, y0 = self._to_pdf(self._origin)
        x1, y1 = self._to_pdf(end)
        self._origin = self._cursor = None
        self.update()
        if self._mode == self.MODE_LINE:
            self.area_drawn.emit((x0, y0, x1, y1))
        elif abs(x1 - x0) > 2 and abs(y1 - y0) > 2:
            self.area_drawn.emit((min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)))

    # -- painting ----------------------------------------------------------
    def paintEvent(self, event) -> None:
        t = theming.current()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        if self._pixmap is None:
            p.fillRect(self.rect(), QColor(t.surface_alt))
            p.setPen(QColor(t.text_muted))
            font = QFont()
            font.setPointSize(11)
            p.setFont(font)
            p.drawText(self.rect(), Qt.AlignCenter,
                       "Open a PDF to see its pages here")
            p.end()
            return

        p.fillRect(self.rect(), QColor(t.canvas))
        p.drawPixmap(0, 0, self._pixmap)
        p.setPen(QPen(QColor(t.border), 1))
        p.drawRect(self.rect().adjusted(0, 0, -1, -1))

        for rect, style in self._overlays:
            wrect = self._to_widget(rect)
            if style == "redact":
                p.setPen(QPen(QColor(t.danger), 2))
                p.setBrush(QColor(t.danger).darker(120))
                p.setOpacity(0.35)
                p.drawRect(wrect)
                p.setOpacity(1.0)
            else:
                p.setPen(QPen(QColor(t.primary), 2, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(wrect)

        if self._origin and self._cursor:
            p.setPen(QPen(QColor(t.primary), 2, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            if self._mode == self.MODE_LINE:
                p.drawLine(self._origin, self._cursor)
            else:
                p.drawRect(QRect(self._origin, self._cursor).normalized())
        p.end()
