"""
Per-user settings, stored locally through QSettings (Windows registry key
HKCU\\Software\\ICAI Capstone\\PDF Utility Pro, or an ini file on Linux/macOS).

Only three things are remembered: the chosen colour theme, the list of recent
files and the folders last used in file dialogs. No document content is ever
stored.
"""

from __future__ import annotations

import os
from typing import List

from PySide6.QtCore import QSettings

ORG = "ICAI Capstone"
APP = "PDF Utility Pro"
MAX_RECENT = 10


class AppSettings:
    def __init__(self) -> None:
        self._s = QSettings(ORG, APP)

    # -- theme -------------------------------------------------------------
    def theme(self) -> str:
        return str(self._s.value("ui/theme", "blue"))

    def set_theme(self, key: str) -> None:
        self._s.setValue("ui/theme", key)

    # -- recent files ------------------------------------------------------
    def recent_files(self) -> List[str]:
        raw = self._s.value("files/recent", [])
        if isinstance(raw, str):
            raw = [raw]
        return [p for p in (raw or []) if p and os.path.exists(p)]

    def add_recent(self, path: str) -> None:
        path = os.path.abspath(path)
        items = [p for p in self.recent_files() if os.path.abspath(p) != path]
        items.insert(0, path)
        self._s.setValue("files/recent", items[:MAX_RECENT])

    def clear_recent(self) -> None:
        self._s.setValue("files/recent", [])

    # -- folders -----------------------------------------------------------
    def last_open_dir(self) -> str:
        return str(self._s.value("files/last_open", os.path.expanduser("~")))

    def set_last_open_dir(self, path: str) -> None:
        self._s.setValue("files/last_open", path)

    def last_save_dir(self) -> str:
        return str(self._s.value("files/last_save", os.path.expanduser("~")))

    def set_last_save_dir(self, path: str) -> None:
        self._s.setValue("files/last_save", path)
