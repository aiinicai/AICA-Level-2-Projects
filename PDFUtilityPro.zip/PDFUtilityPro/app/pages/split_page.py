"""Split PDF — specific pages, page ranges, or every X pages. Supports batch."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QFileDialog,
                               QGroupBox, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QProgressBar,
                               QPushButton, QRadioButton, QScrollArea,
                               QSizePolicy, QSpinBox, QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, BatchResultView, FilePathRow,
                      NotificationBar, Worker, ask_password, heading,
                      human_size, muted, run_in_background, show_error)


class SplitPage(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._passwords: Dict[str, str] = {}

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        root = QVBoxLayout(inner)
        root.setContentsMargins(26, 20, 26, 20)
        root.setSpacing(14)

        root.addWidget(heading("Split PDF", 1))
        root.addWidget(muted("Add one file to split it, or several files to apply "
                             "the same split to all of them."))
        self.note = NotificationBar()
        root.addWidget(self.note)

        # -- files ----------------------------------------------------------
        files_box = QGroupBox("Source files")
        flay = QVBoxLayout(files_box)
        self.files = QListWidget()
        self.files.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.files.setFixedHeight(120)
        self.files.currentRowChanged.connect(self._update_summary)
        flay.addWidget(self.files)

        row = QHBoxLayout()
        add_btn = QPushButton("Add PDFs…")
        add_btn.clicked.connect(self.add_files_dialog)
        rm_btn = QPushButton("Remove selected")
        rm_btn.clicked.connect(self._remove_selected)
        clr_btn = QPushButton("Clear list")
        clr_btn.clicked.connect(self.reset)
        row.addWidget(add_btn)
        row.addWidget(rm_btn)
        row.addWidget(clr_btn)
        row.addStretch(1)
        self.summary = QLabel("No file selected")
        self.summary.setObjectName("Badge")
        row.addWidget(self.summary)
        flay.addLayout(row)
        root.addWidget(files_box)

        # -- how to split ---------------------------------------------------
        mode_box = QGroupBox("How should the file be split?")
        mode_box.setMinimumHeight(220)
        mlay = QVBoxLayout(mode_box)
        mlay.setSpacing(9)

        self.rb_pages = QRadioButton("Specific pages   (for example 1, 4, 9-12)")
        self.rb_ranges = QRadioButton("Page ranges — one PDF per range   "
                                      "(for example 1-5, 6-10, 11-20)")
        self.rb_every = QRadioButton("Split every X pages")
        self.rb_pages.setChecked(True)
        for rb in (self.rb_pages, self.rb_ranges, self.rb_every):
            rb.toggled.connect(self._sync_mode)

        self.spec = QLineEdit()
        self.spec.setPlaceholderText("1-3, 7, 10-  •  or type all / odd / even")
        self.spec.setMaximumWidth(520)
        self.one_file = QCheckBox("Put the selected pages into a single PDF "
                                  "(otherwise one PDF per page)")
        self.one_file.setChecked(True)

        self.every_n = QSpinBox()
        self.every_n.setRange(1, 5000)
        self.every_n.setValue(10)
        self.every_n.setSuffix("  pages per file")
        self.every_n.setMaximumWidth(220)

        mlay.addWidget(self.rb_pages)
        mlay.addWidget(self.spec)
        mlay.addWidget(self.one_file)
        mlay.addWidget(self.rb_ranges)
        mlay.addWidget(self.rb_every)
        mlay.addWidget(self.every_n)
        root.addWidget(mode_box)

        # -- output ---------------------------------------------------------
        out_box = QGroupBox("Save results to")
        olay = QVBoxLayout(out_box)
        self.out_dir = FilePathRow("Output folder", folder_mode=True)
        olay.addWidget(self.out_dir)
        olay.addWidget(muted("New files are named Original_Split.pdf, "
                             "Original_Split_Part1.pdf and so on. The source file "
                             "is never changed and an existing file is never "
                             "overwritten."))
        root.addWidget(out_box)

        # -- run ------------------------------------------------------------
        run_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.run_btn = QPushButton("Split PDF")
        self.run_btn.setObjectName("Primary")
        self.run_btn.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        self.run_btn.clicked.connect(self.run)
        self.progress.setFixedWidth(300)
        run_row.addWidget(self.progress)
        run_row.addStretch(1)
        run_row.addWidget(self.run_btn)
        root.addLayout(run_row)

        # -- results --------------------------------------------------------
        self.results = BatchResultView()
        root.addWidget(self.results, 1)

        self._sync_mode()

    # -- file list ---------------------------------------------------------
    def add_files_dialog(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select PDF files", self._settings.last_open_dir(), PDF_FILTER)
        if paths:
            self._settings.set_last_open_dir(str(Path(paths[0]).parent))
            self.add_files(paths)

    def add_files(self, paths: List[str]) -> None:
        existing = {self.files.item(i).data(Qt.UserRole) for i in range(self.files.count())}
        for path in paths:
            if path in existing:
                continue
            item = QListWidgetItem(Path(path).name)
            item.setData(Qt.UserRole, path)
            item.setToolTip(path)
            self.files.addItem(item)
            self.file_used.emit(path)
        if not self.out_dir.path() and paths:
            self.out_dir.set_path(str(Path(paths[0]).parent))
        self.files.setCurrentRow(self.files.count() - 1)
        self._update_summary()

    def load_file(self, path: str) -> None:
        self.add_files([path])

    def _remove_selected(self) -> None:
        for item in self.files.selectedItems():
            self.files.takeItem(self.files.row(item))
        self._update_summary()

    def reset(self) -> None:
        self.files.clear()
        self.results.clear()
        self.spec.clear()
        self.note.setVisible(False)
        self._passwords.clear()
        self._update_summary()

    def _paths(self) -> List[str]:
        return [self.files.item(i).data(Qt.UserRole) for i in range(self.files.count())]

    def _update_summary(self) -> None:
        item = self.files.currentItem()
        if item is None:
            self.summary.setText("No file selected")
            return
        path = item.data(Qt.UserRole)
        try:
            info = ops.inspect(path, self._passwords.get(path))
        except ops.PasswordRequired:
            pw = ask_password(self, Path(path).name)
            if not pw:
                self.summary.setText("Password required")
                return
            self._passwords[path] = pw
            return self._update_summary()
        except ops.PdfError as exc:
            self.summary.setText("Cannot read this file")
            self.note.error(str(exc))
            return
        self.summary.setText(f"{info.pages} page(s) · {human_size(info.size_bytes)}")
        n = self.files.count()
        if n > 1:
            self.summary.setText(self.summary.text() + f"  ·  batch of {n} files")

    def _sync_mode(self) -> None:
        self.spec.setEnabled(self.rb_pages.isChecked() or self.rb_ranges.isChecked())
        self.one_file.setEnabled(self.rb_pages.isChecked())
        self.every_n.setEnabled(self.rb_every.isChecked())
        if self.rb_ranges.isChecked():
            self.spec.setPlaceholderText("1-5, 6-10, 11-20   (one PDF per range)")
        else:
            self.spec.setPlaceholderText("1-3, 7, 10-  •  or type all / odd / even")
        self.spec.setMaximumWidth(520)

    # -- run ---------------------------------------------------------------
    def run(self) -> None:
        paths = self._paths()
        if not paths:
            show_error(self, "Add at least one PDF file first.")
            return
        out_dir = self.out_dir.path()
        if not out_dir:
            show_error(self, "Choose a folder for the new files.")
            return
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        self._settings.set_last_save_dir(out_dir)

        if self.rb_every.isChecked():
            n = self.every_n.value()
            def operation(path):
                return ops.split_every(path, n, out_dir, self._passwords.get(path))
        elif self.rb_ranges.isChecked():
            spec = self.spec.text()
            def operation(path):
                return ops.split_ranges(path, spec, out_dir, self._passwords.get(path))
        else:
            spec = self.spec.text()
            one = self.one_file.isChecked()
            def operation(path):
                return ops.split_selected(path, spec, out_dir,
                                          self._passwords.get(path), one_file=one)

        self.results.clear()
        self.progress.setVisible(True)
        self.progress.setRange(0, len(paths))
        self.progress.setValue(0)
        self.run_btn.setEnabled(False)
        self.note.info(f"Splitting {len(paths)} file(s)…")

        worker = Worker(ops.run_batch, paths, operation)
        worker.signals.progress.connect(self._on_progress)
        worker.signals.finished.connect(self._on_done)
        worker.signals.failed.connect(self._on_failed)
        run_in_background(worker)

    def _on_progress(self, done: int, total: int, name: str) -> None:
        self.progress.setValue(done)
        self.progress.setFormat(f"{done} of {total} — {name}")

    def _on_failed(self, message: str) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        self.note.error(message)

    def _on_done(self, results) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        created = self.results.show_results(results)
        ok = sum(1 for r in results if r.ok)
        failed = len(results) - ok
        if failed and ok:
            self.note.error(f"{ok} file(s) split into {created} new PDF(s); "
                            f"{failed} file(s) failed — see the Details column.")
        elif failed:
            self.note.error(f"All {failed} file(s) failed. See the Details column.")
        else:
            self.note.success(f"Done. {created} new PDF(s) written to "
                              f"{self.out_dir.path()}")
