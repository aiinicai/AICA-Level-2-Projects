"""Merge PDF — combine several files, reordering them by drag-and-drop."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QGroupBox,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QProgressBar, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, FilePathRow, NotificationBar, Worker,
                      ask_password, heading, human_size, muted,
                      run_in_background, show_error)


class MergeList(QListWidget):
    """List that accepts dropped PDF files and internal reordering."""

    files_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragDropMode(QAbstractItemView.DragDrop)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            paths = [u.toLocalFile() for u in event.mimeData().urls()
                     if u.toLocalFile().lower().endswith(".pdf")]
            if paths:
                self.files_dropped.emit(paths)
                event.acceptProposedAction()
                return
        super().dropEvent(event)


class MergePage(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._passwords: Dict[str, str] = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 20, 26, 20)
        root.setSpacing(14)

        root.addWidget(heading("Merge PDF", 1))
        root.addWidget(muted("Files are joined top to bottom. Drag a file to move it, "
                             "or use the Move up / Move down buttons."))
        self.note = NotificationBar()
        root.addWidget(self.note)

        box = QGroupBox("Files to merge")
        blay = QHBoxLayout(box)

        self.files = MergeList()
        self.files.setMinimumHeight(230)
        self.files.files_dropped.connect(self.add_files)
        self.files.model().rowsMoved.connect(lambda *_: self._update_summary())
        blay.addWidget(self.files, 1)

        side = QVBoxLayout()
        for label, slot in (("Add PDFs…", self.add_files_dialog),
                            ("Move up", lambda: self._move(-1)),
                            ("Move down", lambda: self._move(1)),
                            ("Remove", self._remove_selected),
                            ("Clear list", self.reset)):
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            side.addWidget(btn)
        side.addStretch(1)
        self.summary = QLabel("No files added")
        self.summary.setObjectName("Badge")
        self.summary.setWordWrap(True)
        side.addWidget(self.summary)
        blay.addLayout(side)
        root.addWidget(box, 1)

        out_box = QGroupBox("Save merged file as")
        olay = QVBoxLayout(out_box)
        name_row = QHBoxLayout()
        self.out_name = QLineEdit()
        self.out_name.setPlaceholderText("Merged file name, e.g. Original_Merged.pdf")
        name_row.addWidget(QLabel("File name"))
        name_row.addWidget(self.out_name, 1)
        olay.addLayout(name_row)
        self.out_dir = FilePathRow("Output folder", folder_mode=True)
        olay.addWidget(self.out_dir)
        olay.addWidget(muted("If a file with that name already exists, a numbered "
                             "copy is written instead. Source files are not changed."))
        root.addWidget(out_box)

        run_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setRange(0, 0)
        self.run_btn = QPushButton("Merge PDFs")
        self.run_btn.setObjectName("Primary")
        self.run_btn.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        self.run_btn.clicked.connect(self.run)
        self.progress.setFixedWidth(300)
        run_row.addWidget(self.progress)
        run_row.addStretch(1)
        run_row.addWidget(self.run_btn)
        root.addLayout(run_row)

    # -- list handling -----------------------------------------------------
    def add_files_dialog(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select PDF files to merge", self._settings.last_open_dir(),
            PDF_FILTER)
        if paths:
            self._settings.set_last_open_dir(str(Path(paths[0]).parent))
            self.add_files(paths)

    def add_files(self, paths: List[str]) -> None:
        for path in paths:
            item = QListWidgetItem(Path(path).name)
            item.setData(Qt.UserRole, path)
            item.setToolTip(path)
            self.files.addItem(item)
            self.file_used.emit(path)
        first = paths[0] if paths else None
        if first:
            if not self.out_dir.path():
                self.out_dir.set_path(str(Path(first).parent))
            if not self.out_name.text():
                self.out_name.setText(ops.suggested_name(first, "Merged"))
        self._update_summary()

    def load_file(self, path: str) -> None:
        self.add_files([path])

    def _move(self, delta: int) -> None:
        row = self.files.currentRow()
        new_row = row + delta
        if row < 0 or not 0 <= new_row < self.files.count():
            return
        item = self.files.takeItem(row)
        self.files.insertItem(new_row, item)
        self.files.setCurrentRow(new_row)
        self._update_summary()

    def _remove_selected(self) -> None:
        for item in self.files.selectedItems():
            self.files.takeItem(self.files.row(item))
        self._update_summary()

    def reset(self) -> None:
        self.files.clear()
        self.out_name.clear()
        self.note.setVisible(False)
        self._passwords.clear()
        self._update_summary()

    def _paths(self) -> List[str]:
        return [self.files.item(i).data(Qt.UserRole) for i in range(self.files.count())]

    def _update_summary(self) -> None:
        paths = self._paths()
        if not paths:
            self.summary.setText("No files added")
            return
        total_pages, total_size, unreadable = 0, 0, 0
        for n, path in enumerate(paths):
            try:
                info = ops.inspect(path, self._passwords.get(path))
                total_pages += info.pages
                total_size += info.size_bytes
                self.files.item(n).setText(f"{n + 1}.  {Path(path).name}   "
                                           f"({info.pages} pages)")
            except ops.PdfError:
                unreadable += 1
                self.files.item(n).setText(f"{n + 1}.  {Path(path).name}   "
                                           f"(cannot be read)")
        text = f"{len(paths)} file(s)\n{total_pages} pages\n{human_size(total_size)}"
        if unreadable:
            text += f"\n{unreadable} unreadable"
        self.summary.setText(text)

    # -- run ---------------------------------------------------------------
    def run(self) -> None:
        paths = self._paths()
        if len(paths) < 2:
            show_error(self, "Add at least two PDF files to merge.")
            return
        folder = self.out_dir.path()
        if not folder:
            show_error(self, "Choose a folder for the merged file.")
            return
        name = self.out_name.text().strip() or ops.suggested_name(paths[0], "Merged")
        if not name.lower().endswith(".pdf"):
            name += ".pdf"

        for path in paths:
            try:
                ops.inspect(path, self._passwords.get(path))
            except ops.PasswordRequired:
                pw = ask_password(self, Path(path).name)
                if not pw:
                    show_error(self, f"{Path(path).name} needs a password. "
                                     f"Remove it from the list or supply the password.")
                    return
                self._passwords[path] = pw
            except ops.PdfError as exc:
                show_error(self, str(exc))
                return

        self._settings.set_last_save_dir(folder)
        self.progress.setVisible(True)
        self.run_btn.setEnabled(False)
        self.note.info("Merging…")

        def job(progress=None):
            return ops.merge(paths, Path(folder) / name, self._passwords)

        worker = Worker(job)
        worker.signals.finished.connect(self._on_done)
        worker.signals.failed.connect(self._on_failed)
        run_in_background(worker)

    def _on_failed(self, message: str) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        self.note.error(message)

    def _on_done(self, out_path) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        self.note.success(f"Merged file saved as {Path(out_path).name} in "
                          f"{Path(out_path).parent}")
