"""Redact PDF — mark areas and permanently remove the content underneath."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QGroupBox,
                               QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton,
                               QScrollArea, QSpinBox, QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, NotificationBar, PageCanvas, ask_password,
                      heading, muted, show_error)

ZOOM_LEVELS = [0.75, 1.0, 1.25, 1.5, 2.0]


class RedactPage(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._path: Optional[str] = None
        self._password: Optional[str] = None
        self._doc = None
        self._page_no = 0
        self._zoom = 1.0
        self._areas: List[ops.RedactArea] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 20, 26, 20)
        root.setSpacing(12)

        root.addWidget(heading("Redact PDF", 1))
        root.addWidget(muted("Drag a box over anything confidential. On save, the "
                             "text and images inside every box are deleted from the "
                             "file — they are not just covered by a coloured "
                             "rectangle."))

        warning = QFrame()
        warning.setObjectName("Card")
        wlay = QVBoxLayout(warning)
        wlay.setContentsMargins(14, 10, 14, 10)
        warn = QLabel("Redaction is irreversible. Removed content cannot be "
                      "recovered from the new file. The original file is kept "
                      "untouched, so keep it somewhere safe.")
        warn.setObjectName("Warning")
        warn.setWordWrap(True)
        wlay.addWidget(warn)
        root.addWidget(warning)

        self.note = NotificationBar()
        root.addWidget(self.note)

        # Toolbar row --------------------------------------------------------
        bar = QHBoxLayout()
        open_btn = QPushButton("Open PDF…")
        open_btn.clicked.connect(self.open_dialog)
        bar.addWidget(open_btn)

        bar.addWidget(QLabel("Page"))
        self.page_spin = QSpinBox()
        self.page_spin.setRange(1, 1)
        self.page_spin.valueChanged.connect(self._goto_page)
        bar.addWidget(self.page_spin)
        self.page_total = QLabel("of 0")
        bar.addWidget(self.page_total)

        bar.addSpacing(14)
        bar.addWidget(QLabel("Zoom"))
        self.zoom_box = QComboBox()
        for z in ZOOM_LEVELS:
            self.zoom_box.addItem(f"{int(z * 100)}%", z)
        self.zoom_box.setCurrentIndex(1)
        self.zoom_box.currentIndexChanged.connect(self._change_zoom)
        bar.addWidget(self.zoom_box)

        bar.addSpacing(14)
        bar.addWidget(QLabel("Box colour"))
        self.colour_box = QComboBox()
        self.colour_box.addItem("Black", (0.0, 0.0, 0.0))
        self.colour_box.addItem("White", (1.0, 1.0, 1.0))
        bar.addWidget(self.colour_box)
        bar.addStretch(1)
        self.file_label = QLabel("No file open")
        self.file_label.setObjectName("Badge")
        bar.addWidget(self.file_label)
        root.addLayout(bar)

        # Canvas + marked list ----------------------------------------------
        body = QHBoxLayout()
        self.canvas = PageCanvas()
        self.canvas.set_mode(PageCanvas.MODE_RECT)
        self.canvas.area_drawn.connect(self._add_area)
        scroll = QScrollArea()
        scroll.setWidget(self.canvas)
        scroll.setAlignment(Qt.AlignCenter)
        scroll.setWidgetResizable(False)
        body.addWidget(scroll, 1)

        side_box = QGroupBox("Marked areas")
        slay = QVBoxLayout(side_box)
        side_box.setFixedWidth(280)
        self.area_list = QListWidget()
        self.area_list.currentRowChanged.connect(self._focus_area)
        slay.addWidget(self.area_list, 1)
        rm = QPushButton("Remove selected mark")
        rm.clicked.connect(self._remove_area)
        clear = QPushButton("Remove all marks")
        clear.clicked.connect(self._clear_areas)
        slay.addWidget(rm)
        slay.addWidget(clear)
        slay.addWidget(muted("Tip: check the preview text shown next to each mark "
                             "before saving."))
        body.addWidget(side_box)
        root.addLayout(body, 1)

        bottom = QHBoxLayout()
        bottom.addStretch(1)
        save_btn = QPushButton("Apply redaction and save as new PDF")
        save_btn.setObjectName("Danger")
        save_btn.clicked.connect(self.save_as)
        bottom.addWidget(save_btn)
        root.addLayout(bottom)

    # -- loading -----------------------------------------------------------
    def open_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open PDF", self._settings.last_open_dir(), PDF_FILTER)
        if path:
            self._settings.set_last_open_dir(str(Path(path).parent))
            self.load_file(path)

    def load_file(self, path: str) -> None:
        password = None
        while True:
            try:
                doc = ops.open_doc(path, password)
                break
            except ops.PasswordRequired:
                password = ask_password(self, Path(path).name)
                if not password:
                    return
            except ops.PdfError as exc:
                show_error(self, str(exc))
                return
        self._close_doc()
        self._path, self._password, self._doc = path, password, doc
        self._areas.clear()
        self.area_list.clear()
        self.page_spin.blockSignals(True)
        self.page_spin.setRange(1, doc.page_count)
        self.page_spin.setValue(1)
        self.page_spin.blockSignals(False)
        self.page_total.setText(f"of {doc.page_count}")
        self.file_label.setText(Path(path).name)
        self.file_used.emit(path)
        self._page_no = 0
        self._render()

    def _close_doc(self) -> None:
        if self._doc is not None:
            self._doc.close()
            self._doc = None

    def _render(self) -> None:
        if self._doc is None:
            return
        png, _w, _h = ops.render_page_png(self._doc, self._page_no, self._zoom)
        self.canvas.set_page(png, self._zoom)
        self._refresh_overlays()

    def _goto_page(self, value: int) -> None:
        self._page_no = value - 1
        self._render()

    def _change_zoom(self, index: int) -> None:
        self._zoom = self.zoom_box.itemData(index)
        self._render()

    # -- marks -------------------------------------------------------------
    def _add_area(self, rect) -> None:
        if self._doc is None:
            return
        area = ops.RedactArea(self._page_no, rect)
        self._areas.append(area)
        try:
            preview = ops.textbox(self._doc, self._page_no, rect)
        except Exception:
            preview = ""
        preview = " ".join(preview.split())[:48]
        label = f"Page {self._page_no + 1}"
        label += f" — “{preview}”" if preview else " — image or blank area"
        item = QListWidgetItem(label)
        item.setToolTip(f"x0={rect[0]:.0f} y0={rect[1]:.0f} "
                        f"x1={rect[2]:.0f} y1={rect[3]:.0f}")
        self.area_list.addItem(item)
        self._refresh_overlays()
        self.note.info(f"{len(self._areas)} area(s) marked. Nothing is changed "
                       f"until you save.")

    def _refresh_overlays(self) -> None:
        self.canvas.set_overlays([(a.rect, "redact") for a in self._areas
                                  if a.page == self._page_no])

    def _focus_area(self, row: int) -> None:
        if 0 <= row < len(self._areas):
            page = self._areas[row].page
            if page != self._page_no:
                self.page_spin.setValue(page + 1)

    def _remove_area(self) -> None:
        row = self.area_list.currentRow()
        if row < 0:
            return
        self._areas.pop(row)
        self.area_list.takeItem(row)
        self._refresh_overlays()

    def _clear_areas(self) -> None:
        self._areas.clear()
        self.area_list.clear()
        self._refresh_overlays()

    # -- save --------------------------------------------------------------
    def save_as(self) -> None:
        if not self._path:
            show_error(self, "Open a PDF first.")
            return
        if not self._areas:
            show_error(self, "Drag at least one box over the content to remove.")
            return
        pages = sorted({a.page + 1 for a in self._areas})
        confirm = QMessageBox(self)
        confirm.setIcon(QMessageBox.Warning)
        confirm.setWindowTitle("Confirm permanent redaction")
        confirm.setText(f"{len(self._areas)} area(s) on page(s) "
                        f"{', '.join(map(str, pages))} will be permanently removed.")
        confirm.setInformativeText("This cannot be undone in the new file. "
                                   "Your original PDF stays unchanged.\n\nContinue?")
        confirm.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        confirm.setDefaultButton(QMessageBox.Cancel)
        if confirm.exec() != QMessageBox.Yes:
            return

        suggested = ops.suggested_path(self._path, "Redacted",
                                       self._settings.last_save_dir()
                                       or Path(self._path).parent)
        target, _ = QFileDialog.getSaveFileName(self, "Save redacted PDF",
                                                str(suggested), PDF_FILTER)
        if not target:
            return
        try:
            out = ops.redact(self._path, self._areas, target, self._password,
                             fill=self.colour_box.currentData())
        except ops.PdfError as exc:
            self.note.error(str(exc))
            return
        self._settings.set_last_save_dir(str(out.parent))
        self.note.success(f"Redacted file saved as {out.name}. "
                          f"The removed content is gone from that file for good.")

    def reset(self) -> None:
        self._close_doc()
        self._path = None
        self._password = None
        self._clear_areas()
        self.canvas.clear_page()
        self.file_label.setText("No file open")
        self.page_total.setText("of 0")
        self.note.setVisible(False)
