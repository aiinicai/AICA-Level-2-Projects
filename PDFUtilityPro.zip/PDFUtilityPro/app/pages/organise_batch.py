"""
Batch mode for Organise — apply the same page operations to many PDFs.

The single-file screen works interactively on thumbnails, which does not
generalise to fifty files. Batch mode instead expresses the operation as page
numbers and a rotation, so one instruction can be applied to every selected
file: extract these pages, drop those pages, rotate everything, reverse the
order.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox,
                               QFileDialog, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QListWidget, QListWidgetItem,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, BatchResultView, FilePathRow,
                      NotificationBar, Worker, heading, muted,
                      run_in_background, show_error)


class BatchOrganisePanel(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._passwords: Dict[str, str] = {}

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        root = QVBoxLayout(inner)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        root.addWidget(muted("Apply one set of page operations to many files at "
                             "once — useful when every scan in a folder has the "
                             "same cover sheet to drop, or all of them came out "
                             "sideways. Each file keeps its own name, with "
                             "_Organised added."))
        self.note = NotificationBar()
        root.addWidget(self.note)

        # -- files ----------------------------------------------------------
        files_box = QGroupBox("Files to process")
        flay = QVBoxLayout(files_box)
        self.files = QListWidget()
        self.files.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.files.setFixedHeight(130)
        flay.addWidget(self.files)
        row = QHBoxLayout()
        add_btn = QPushButton("Add PDFs…")
        add_btn.clicked.connect(self.add_files_dialog)
        rm_btn = QPushButton("Remove selected")
        rm_btn.clicked.connect(self._remove_selected)
        clr_btn = QPushButton("Clear list")
        clr_btn.clicked.connect(self.reset)
        row.addWidget(add_btn)
        row.addWidget(rm_btn)
        row.addWidget(clr_btn)
        row.addStretch(1)
        self.summary = QLabel("No files added")
        self.summary.setObjectName("Badge")
        row.addWidget(self.summary)
        flay.addLayout(row)
        root.addWidget(files_box)

        # -- operations -----------------------------------------------------
        ops_box = QGroupBox("Apply to every file")
        olay = QVBoxLayout(ops_box)
        olay.setSpacing(9)

        def labelled(text: str, widget) -> QHBoxLayout:
            row = QHBoxLayout()
            label = QLabel(text)
            label.setFixedWidth(150)
            row.addWidget(label)
            row.addWidget(widget)
            row.addStretch(1)
            return row

        self.extract = QLineEdit()
        self.extract.setPlaceholderText("blank = keep every page  •  or 1-5, 8, 12-")
        self.extract.setFixedWidth(400)
        olay.addLayout(labelled("Keep only pages", self.extract))

        self.delete = QLineEdit()
        self.delete.setPlaceholderText("blank = delete none  •  or 1 to drop each cover sheet")
        self.delete.setFixedWidth(400)
        olay.addLayout(labelled("Delete pages", self.delete))

        rot_row = QHBoxLayout()
        rot_label = QLabel("Rotate every page")
        rot_label.setFixedWidth(150)
        rot_row.addWidget(rot_label)
        self.rotate = QComboBox()
        for label, value in (("No rotation", 0), ("90° right", 90),
                             ("180°", 180), ("90° left", 270)):
            self.rotate.addItem(label, value)
        self.rotate.setMaximumWidth(180)
        rot_row.addWidget(self.rotate)
        rot_row.addStretch(1)
        olay.addLayout(rot_row)

        self.reverse = QCheckBox("Reverse the page order (useful for a stack "
                                 "scanned back to front)")
        olay.addWidget(self.reverse)
        olay.addWidget(muted("Order of application: keep, then delete, then "
                             "reverse, then rotate. Page numbers refer to each "
                             "file's own pages, so a file with fewer pages than "
                             "you asked for is reported as failed rather than "
                             "silently skipped."))
        root.addWidget(ops_box)

        # -- output ---------------------------------------------------------
        out_box = QGroupBox("Save results to")
        oolay = QVBoxLayout(out_box)
        self.out_dir = FilePathRow("Output folder", folder_mode=True)
        oolay.addWidget(self.out_dir)
        oolay.addWidget(muted("Every source file is left exactly as it is."))
        root.addWidget(out_box)

        # -- run ------------------------------------------------------------
        run_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setFixedWidth(300)
        self.run_btn = QPushButton("Process all files")
        self.run_btn.setObjectName("Primary")
        self.run_btn.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        self.run_btn.clicked.connect(self.run)
        run_row.addWidget(self.progress)
        run_row.addStretch(1)
        run_row.addWidget(self.run_btn)
        root.addLayout(run_row)

        self.results = BatchResultView()
        root.addWidget(self.results, 1)

    # -- files -------------------------------------------------------------
    def add_files_dialog(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select PDF files", self._settings.last_open_dir(), PDF_FILTER)
        if paths:
            self._settings.set_last_open_dir(str(Path(paths[0]).parent))
            self.add_files(paths)

    def add_files(self, paths: List[str]) -> None:
        existing = {self.files.item(i).data(Qt.UserRole)
                    for i in range(self.files.count())}
        for path in paths:
            if path in existing:
                continue
            item = QListWidgetItem(Path(path).name)
            item.setData(Qt.UserRole, path)
            item.setToolTip(path)
            self.files.addItem(item)
            self.file_used.emit(path)
        if not self.out_dir.path() and paths:
            self.out_dir.set_path(str(Path(paths[0]).parent))
        self._update_summary()

    def load_file(self, path: str) -> None:
        self.add_files([path])

    def _remove_selected(self) -> None:
        for item in self.files.selectedItems():
            self.files.takeItem(self.files.row(item))
        self._update_summary()

    def reset(self) -> None:
        self.files.clear()
        self.results.clear()
        self.note.setVisible(False)
        self._passwords.clear()
        self._update_summary()

    def _paths(self) -> List[str]:
        return [self.files.item(i).data(Qt.UserRole)
                for i in range(self.files.count())]

    def _update_summary(self) -> None:
        n = self.files.count()
        self.summary.setText("No files added" if n == 0 else f"{n} file(s) queued")

    # -- run ---------------------------------------------------------------
    def run(self) -> None:
        paths = self._paths()
        if not paths:
            show_error(self, "Add at least one PDF file first.")
            return
        out_dir = self.out_dir.path()
        if not out_dir:
            show_error(self, "Choose a folder for the new files.")
            return
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        self._settings.set_last_save_dir(out_dir)

        extract = self.extract.text().strip()
        delete = self.delete.text().strip()
        rotate = self.rotate.currentData()
        reverse = self.reverse.isChecked()

        if not extract and not delete and not rotate and not reverse:
            show_error(self, "Choose at least one operation — pages to keep or "
                             "delete, a rotation, or reverse order.")
            return

        def operation(path):
            target = ops.suggested_path(path, "Organised", out_dir)
            return [ops.transform(path, target, extract=extract, delete=delete,
                                  rotate=rotate, reverse=reverse,
                                  password=self._passwords.get(path))]

        self.results.clear()
        self.progress.setVisible(True)
        self.progress.setRange(0, len(paths))
        self.progress.setValue(0)
        self.run_btn.setEnabled(False)
        self.note.info(f"Processing {len(paths)} file(s)…")

        worker = Worker(ops.run_batch, paths, operation)
        worker.signals.progress.connect(self._on_progress)
        worker.signals.finished.connect(self._on_done)
        worker.signals.failed.connect(self._on_failed)
        run_in_background(worker)

    def _on_progress(self, done: int, total: int, name: str) -> None:
        self.progress.setValue(done)
        self.progress.setFormat(f"{done} of {total} — {name}")

    def _on_failed(self, message: str) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        self.note.error(message)

    def _on_done(self, results) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        created = self.results.show_results(results)
        ok = sum(1 for r in results if r.ok)
        failed = len(results) - ok
        if failed and ok:
            self.note.error(f"{ok} file(s) processed into {created} new PDF(s); "
                            f"{failed} failed — listed on the right.")
        elif failed:
            self.note.error(f"All {failed} file(s) failed. See the Failed panel.")
        else:
            self.note.success(f"Done. {created} new PDF(s) written to {out_dir}"
                              if (out_dir := self.out_dir.path()) else "Done.")
