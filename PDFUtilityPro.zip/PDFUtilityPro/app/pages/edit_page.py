"""
Edit PDF — basic, annotation-style editing.

Deliberately limited to adding things on top of a page: text, today's date, a
signature image, lines, boxes, highlights and sticky notes, plus page
rotation and removal of existing annotations. Rewriting the text already
inside a PDF is out of scope, as the brief requires.
"""

from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QColorDialog, QComboBox,
                               QDoubleSpinBox, QFileDialog, QGroupBox,
                               QHBoxLayout, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QPushButton,
                               QRadioButton, QScrollArea, QSpinBox,
                               QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, NotificationBar, PageCanvas, ask_password,
                      heading, muted, show_error)

ZOOM_LEVELS = [0.75, 1.0, 1.25, 1.5, 2.0]
IMAGE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp);;All files (*)"

TOOLS = [
    ("text", "Add text", PageCanvas.MODE_POINT),
    ("date", "Add today's date", PageCanvas.MODE_POINT),
    ("image", "Add signature / image", PageCanvas.MODE_RECT),
    ("line", "Draw line", PageCanvas.MODE_LINE),
    ("rect", "Draw box", PageCanvas.MODE_RECT),
    ("highlight", "Highlight area", PageCanvas.MODE_RECT),
    ("note", "Add sticky note", PageCanvas.MODE_POINT),
]


class EditPage(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._path: Optional[str] = None
        self._password: Optional[str] = None
        self._doc = None
        self._page_no = 0
        self._zoom = 1.0
        self._edits: List[ops.Edit] = []
        self._colour = (0.0, 0.0, 0.0)
        self._image_path = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 20, 26, 20)
        root.setSpacing(12)

        root.addWidget(heading("Edit PDF", 1))
        root.addWidget(muted("Pick a tool, then click or drag on the page. Changes "
                             "are listed on the right and written only when you "
                             "save to a new file. Existing PDF text cannot be "
                             "rewritten — that is outside the scope of this tool."))
        self.note = NotificationBar()
        root.addWidget(self.note)

        bar = QHBoxLayout()
        open_btn = QPushButton("Open PDF…")
        open_btn.clicked.connect(self.open_dialog)
        bar.addWidget(open_btn)
        bar.addWidget(QLabel("Page"))
        self.page_spin = QSpinBox()
        self.page_spin.setRange(1, 1)
        self.page_spin.valueChanged.connect(self._goto_page)
        bar.addWidget(self.page_spin)
        self.page_total = QLabel("of 0")
        bar.addWidget(self.page_total)
        bar.addSpacing(12)
        bar.addWidget(QLabel("Zoom"))
        self.zoom_box = QComboBox()
        for z in ZOOM_LEVELS:
            self.zoom_box.addItem(f"{int(z * 100)}%", z)
        self.zoom_box.setCurrentIndex(1)
        self.zoom_box.currentIndexChanged.connect(self._change_zoom)
        bar.addWidget(self.zoom_box)
        bar.addStretch(1)
        self.file_label = QLabel("No file open")
        self.file_label.setObjectName("Badge")
        bar.addWidget(self.file_label)
        root.addLayout(bar)

        body = QHBoxLayout()

        # -- tools -----------------------------------------------------------
        tools_box = QGroupBox("Tools")
        tools_box.setFixedWidth(272)
        tlay = QVBoxLayout(tools_box)
        self._tool_group = QButtonGroup(self)
        self._tool = "text"
        for key, label, mode in TOOLS:
            rb = QRadioButton(label)
            rb.setProperty("tool", key)
            rb.setProperty("mode", mode)
            rb.toggled.connect(self._tool_changed)
            self._tool_group.addButton(rb)
            tlay.addWidget(rb)
            if key == "text":
                rb.setChecked(True)

        tlay.addSpacing(8)
        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Text size"))
        self.font_size = QDoubleSpinBox()
        self.font_size.setRange(6, 72)
        self.font_size.setValue(12)
        size_row.addWidget(self.font_size)
        tlay.addLayout(size_row)

        self.colour_btn = QPushButton("Choose colour…")
        self.colour_btn.clicked.connect(self._choose_colour)
        tlay.addWidget(self.colour_btn)

        self.image_btn = QPushButton("Choose signature…")
        self.image_btn.clicked.connect(self._choose_image)
        tlay.addWidget(self.image_btn)
        self.image_label = QLabel("No image chosen")
        self.image_label.setObjectName("Muted")
        self.image_label.setWordWrap(True)
        tlay.addWidget(self.image_label)

        tlay.addSpacing(8)
        rot_l = QPushButton("Rotate this page left")
        rot_l.clicked.connect(lambda: self._add_rotation(-90))
        rot_r = QPushButton("Rotate this page right")
        rot_r.clicked.connect(lambda: self._add_rotation(90))
        clear_annots = QPushButton("Remove annotations")
        clear_annots.clicked.connect(self._clear_annots)
        tlay.addWidget(rot_l)
        tlay.addWidget(rot_r)
        tlay.addWidget(clear_annots)
        tlay.addStretch(1)
        body.addWidget(tools_box)

        # -- canvas ----------------------------------------------------------
        self.canvas = PageCanvas()
        self.canvas.set_mode(PageCanvas.MODE_POINT)
        self.canvas.point_clicked.connect(self._on_point)
        self.canvas.area_drawn.connect(self._on_area)
        scroll = QScrollArea()
        scroll.setWidget(self.canvas)
        scroll.setAlignment(Qt.AlignCenter)
        scroll.setWidgetResizable(False)
        body.addWidget(scroll, 1)

        # -- change list -----------------------------------------------------
        change_box = QGroupBox("Pending changes")
        change_box.setFixedWidth(260)
        clay = QVBoxLayout(change_box)
        self.change_list = QListWidget()
        clay.addWidget(self.change_list, 1)
        undo = QPushButton("Undo last change")
        undo.clicked.connect(self._undo)
        clear = QPushButton("Discard all changes")
        clear.clicked.connect(self._discard)
        clay.addWidget(undo)
        clay.addWidget(clear)
        body.addWidget(change_box)

        root.addLayout(body, 1)

        bottom = QHBoxLayout()
        bottom.addStretch(1)
        save_btn = QPushButton("Save as new PDF")
        save_btn.setObjectName("Primary")
        save_btn.clicked.connect(self.save_as)
        bottom.addWidget(save_btn)
        root.addLayout(bottom)

    # -- file --------------------------------------------------------------
    def open_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open PDF", self._settings.last_open_dir(), PDF_FILTER)
        if path:
            self._settings.set_last_open_dir(str(Path(path).parent))
            self.load_file(path)

    def load_file(self, path: str) -> None:
        password = None
        while True:
            try:
                doc = ops.open_doc(path, password)
                break
            except ops.PasswordRequired:
                password = ask_password(self, Path(path).name)
                if not password:
                    return
            except ops.PdfError as exc:
                show_error(self, str(exc))
                return
        self._close_doc()
        self._path, self._password, self._doc = path, password, doc
        self._discard()
        self.page_spin.blockSignals(True)
        self.page_spin.setRange(1, doc.page_count)
        self.page_spin.setValue(1)
        self.page_spin.blockSignals(False)
        self.page_total.setText(f"of {doc.page_count}")
        self.file_label.setText(Path(path).name)
        self.file_used.emit(path)
        self._page_no = 0
        self._render()

    def _close_doc(self) -> None:
        if self._doc is not None:
            self._doc.close()
            self._doc = None

    def _render(self) -> None:
        if self._doc is None:
            return
        png, _w, _h = ops.render_page_png(self._doc, self._page_no, self._zoom)
        self.canvas.set_page(png, self._zoom)
        self._refresh_overlays()

    def _goto_page(self, value: int) -> None:
        self._page_no = value - 1
        self._render()

    def _change_zoom(self, index: int) -> None:
        self._zoom = self.zoom_box.itemData(index)
        self._render()

    # -- tools -------------------------------------------------------------
    def _tool_changed(self) -> None:
        btn = self._tool_group.checkedButton()
        if btn is None:
            return
        self._tool = btn.property("tool")
        if hasattr(self, "canvas"):   # the first tool is selected before the canvas exists
            self.canvas.set_mode(btn.property("mode"))

    def _choose_colour(self) -> None:
        colour = QColorDialog.getColor(parent=self, title="Choose colour")
        if colour.isValid():
            self._colour = (colour.redF(), colour.greenF(), colour.blueF())
            self.colour_btn.setText(f"Colour: {colour.name()}")

    def _choose_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose signature or image", self._settings.last_open_dir(),
            IMAGE_FILTER)
        if path:
            self._image_path = path
            self.image_label.setText(Path(path).name)

    # -- adding edits ------------------------------------------------------
    def _require_doc(self) -> bool:
        if self._doc is None:
            show_error(self, "Open a PDF first.")
            return False
        return True

    def _record(self, edit: ops.Edit, label: str) -> None:
        self._edits.append(edit)
        item = QListWidgetItem(f"Page {edit.page + 1}: {label}")
        self.change_list.addItem(item)
        self.change_list.setCurrentRow(self.change_list.count() - 1)
        self._refresh_overlays()

    def _on_point(self, point) -> None:
        if not self._require_doc():
            return
        if self._tool == "text":
            text, ok = QInputDialog.getText(self, "Add text", "Text to place:")
            if not ok or not text.strip():
                return
            self._record(ops.Edit("text", self._page_no, point=point,
                                  text=text.strip(), size=self.font_size.value(),
                                  colour=self._colour),
                         f"text “{text.strip()[:24]}”")
        elif self._tool == "date":
            today = _dt.date.today().strftime("%d-%m-%Y")
            self._record(ops.Edit("date", self._page_no, point=point, text=today,
                                  size=self.font_size.value(), colour=self._colour),
                         f"date {today}")
        elif self._tool == "note":
            text, ok = QInputDialog.getText(self, "Sticky note", "Note text:")
            if not ok or not text.strip():
                return
            self._record(ops.Edit("note", self._page_no, point=point,
                                  text=text.strip(), colour=self._colour),
                         f"note “{text.strip()[:20]}”")

    def _on_area(self, rect) -> None:
        if not self._require_doc():
            return
        if self._tool == "image":
            if not self._image_path:
                show_error(self, "Choose a signature or image file first.")
                return
            self._record(ops.Edit("image", self._page_no, rect=rect,
                                  image_path=self._image_path),
                         f"image {Path(self._image_path).name}")
        elif self._tool == "line":
            self._record(ops.Edit("line", self._page_no,
                                  point=(rect[0], rect[1]), point2=(rect[2], rect[3]),
                                  colour=self._colour, width=1.5), "line")
        elif self._tool == "rect":
            self._record(ops.Edit("rect", self._page_no, rect=rect,
                                  colour=self._colour, width=1.5), "box")
        elif self._tool == "highlight":
            colour = self._colour if self._colour != (0.0, 0.0, 0.0) else (1.0, 0.92, 0.23)
            self._record(ops.Edit("highlight", self._page_no, rect=rect,
                                  colour=colour), "highlight")

    def _add_rotation(self, delta: int) -> None:
        if not self._require_doc():
            return
        self._record(ops.Edit("rotate", self._page_no, rotation=delta),
                     f"rotate {delta}°")

    def _clear_annots(self) -> None:
        if not self._require_doc():
            return
        self._record(ops.Edit("clear_annots", self._page_no),
                     "remove existing annotations")

    def _refresh_overlays(self) -> None:
        overlays = []
        for e in self._edits:
            if e.page != self._page_no:
                continue
            if e.rect:
                overlays.append((e.rect, "edit"))
            elif e.point:
                x, y = e.point
                overlays.append(((x - 3, y - 12, x + 90, y + 4), "edit"))
        self.canvas.set_overlays(overlays)

    def _undo(self) -> None:
        if not self._edits:
            return
        self._edits.pop()
        self.change_list.takeItem(self.change_list.count() - 1)
        self._refresh_overlays()

    def _discard(self) -> None:
        self._edits.clear()
        self.change_list.clear()
        self._refresh_overlays()

    # -- save --------------------------------------------------------------
    def save_as(self) -> None:
        if not self._path:
            show_error(self, "Open a PDF first.")
            return
        if not self._edits:
            show_error(self, "Add at least one change before saving.")
            return
        suggested = ops.suggested_path(self._path, "Edited",
                                       self._settings.last_save_dir()
                                       or Path(self._path).parent)
        target, _ = QFileDialog.getSaveFileName(self, "Save edited PDF",
                                                str(suggested), PDF_FILTER)
        if not target:
            return
        try:
            out = ops.apply_edits(self._path, self._edits, target, self._password)
        except ops.PdfError as exc:
            self.note.error(str(exc))
            return
        self._settings.set_last_save_dir(str(out.parent))
        self.note.success(f"Saved {out.name} in {out.parent}. "
                          f"The original file is unchanged.")

    def reset(self) -> None:
        self._close_doc()
        self._path = None
        self._password = None
        self._discard()
        self.canvas.clear_page()
        self.file_label.setText("No file open")
        self.page_total.setText("of 0")
        self.note.setVisible(False)
