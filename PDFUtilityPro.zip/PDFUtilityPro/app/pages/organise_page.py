"""Organise PDF — thumbnails with reorder, delete, rotate, duplicate, extract."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QIcon, QImage, QPixmap, QTransform
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QFileDialog,
                               QGroupBox, QHBoxLayout, QLabel, QListView,
                               QListWidget, QListWidgetItem, QProgressBar,
                               QPushButton, QSizePolicy, QTabWidget,
                               QVBoxLayout, QWidget)

from .. import pdf_ops as ops
from ..common import (PDF_FILTER, NotificationBar, ask_password, heading,
                      muted, show_error)
from .organise_batch import BatchOrganisePanel

THUMB_ZOOM = 0.28


class SingleOrganisePanel(QWidget):
    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._path: Optional[str] = None
        self._password: Optional[str] = None
        self._thumbs: Dict[int, QPixmap] = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        root.addWidget(muted("Drag thumbnails to reorder. Select one or more pages, "
                             "then rotate, duplicate, delete or extract them. Nothing "
                             "is written until you choose Save as."))
        self.note = NotificationBar()
        root.addWidget(self.note)

        top = QHBoxLayout()
        open_btn = QPushButton("Open PDF…")
        open_btn.clicked.connect(self.open_dialog)
        top.addWidget(open_btn)
        self.file_label = QLabel("No file open")
        self.file_label.setObjectName("Badge")
        top.addWidget(self.file_label, 1)
        top.addStretch(1)
        root.addLayout(top)

        box = QGroupBox("Pages")
        blay = QHBoxLayout(box)

        self.grid = QListWidget()
        self.grid.setViewMode(QListView.IconMode)
        self.grid.setIconSize(QSize(150, 200))
        self.grid.setGridSize(QSize(176, 246))
        self.grid.setResizeMode(QListView.Adjust)
        self.grid.setMovement(QListView.Static)
        self.grid.setDragDropMode(QAbstractItemView.InternalMove)
        self.grid.setDefaultDropAction(Qt.MoveAction)
        self.grid.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.grid.setSpacing(6)
        self.grid.setWordWrap(True)
        self.grid.model().rowsMoved.connect(lambda *_: self._renumber())
        blay.addWidget(self.grid, 1)

        side = QVBoxLayout()
        for label, slot in (
            ("Rotate left", lambda: self._rotate(-90)),
            ("Rotate right", lambda: self._rotate(90)),
            ("Duplicate", self._duplicate),
            ("Delete", self._delete),
            ("Move up", lambda: self._move(-1)),
            ("Move down", lambda: self._move(1)),
            ("Select all", self.grid.selectAll),
            ("Undo all changes", self._reload_plan),
        ):
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            side.addWidget(btn)
        side.addSpacing(10)
        extract_btn = QPushButton("Extract selected…")
        extract_btn.clicked.connect(self.extract_selected)
        side.addWidget(extract_btn)
        side.addStretch(1)
        self.count_label = QLabel("")
        self.count_label.setObjectName("Muted")
        self.count_label.setWordWrap(True)
        side.addWidget(self.count_label)
        blay.addLayout(side)
        root.addWidget(box, 1)

        bottom = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        save_btn = QPushButton("Save as new PDF")
        save_btn.setObjectName("Primary")
        save_btn.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        save_btn.clicked.connect(self.save_as)
        self.progress.setFixedWidth(300)
        bottom.addWidget(self.progress)
        bottom.addStretch(1)
        bottom.addWidget(save_btn)
        root.addLayout(bottom)

    # -- loading -----------------------------------------------------------
    def open_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open PDF", self._settings.last_open_dir(), PDF_FILTER)
        if path:
            self._settings.set_last_open_dir(str(Path(path).parent))
            self.load_file(path)

    def load_file(self, path: str) -> None:
        password = None
        while True:
            try:
                info = ops.inspect(path, password)
                break
            except ops.PasswordRequired:
                password = ask_password(self, Path(path).name)
                if not password:
                    return
            except ops.PdfError as exc:
                show_error(self, str(exc))
                return

        self._path = path
        self._password = password
        self.file_label.setText(f"{Path(path).name}  ·  {info.pages} page(s)")
        self.file_used.emit(path)
        self._render_thumbnails(info.pages)
        self._reload_plan()

    def _render_thumbnails(self, pages: int) -> None:
        self._thumbs.clear()
        self.progress.setVisible(True)
        self.progress.setRange(0, pages)
        try:
            doc = ops.open_doc(self._path, self._password)
        except ops.PdfError as exc:
            self.progress.setVisible(False)
            show_error(self, str(exc))
            return
        try:
            for i in range(pages):
                png, _w, _h = ops.render_page_png(doc, i, THUMB_ZOOM)
                self._thumbs[i] = QPixmap.fromImage(QImage.fromData(png, "PNG"))
                self.progress.setValue(i + 1)
                if i % 4 == 0:
                    QApplication.processEvents()
        finally:
            doc.close()
            self.progress.setVisible(False)

    def _reload_plan(self) -> None:
        self.grid.clear()
        for i in sorted(self._thumbs):
            item = QListWidgetItem()
            item.setData(Qt.UserRole, i)        # original page index
            item.setData(Qt.UserRole + 1, 0)    # extra rotation
            self.grid.addItem(item)
        self._renumber()

    # -- plan editing ------------------------------------------------------
    def _refresh_item(self, item: QListWidgetItem, position: int) -> None:
        src = item.data(Qt.UserRole)
        rot = item.data(Qt.UserRole + 1) or 0
        pixmap = self._thumbs.get(src)
        if pixmap is not None:
            if rot:
                pixmap = pixmap.transformed(QTransform().rotate(rot),
                                            Qt.SmoothTransformation)
            item.setIcon(QIcon(pixmap))
        label = f"{position + 1}   (was page {src + 1})"
        if rot:
            label += f"  ·  {rot}°"
        item.setText(label)
        item.setTextAlignment(Qt.AlignHCenter)

    def _renumber(self) -> None:
        for row in range(self.grid.count()):
            self._refresh_item(self.grid.item(row), row)
        total = self.grid.count()
        original = len(self._thumbs)
        self.count_label.setText(
            f"{total} page(s) in the new document\n(original has {original})"
            if self._path else "")

    def _selected_items(self) -> List[QListWidgetItem]:
        items = self.grid.selectedItems()
        if not items:
            self.note.info("Select one or more pages first.")
        return items

    def _rotate(self, delta: int) -> None:
        for item in self._selected_items():
            rot = ((item.data(Qt.UserRole + 1) or 0) + delta) % 360
            item.setData(Qt.UserRole + 1, rot)
        self._renumber()

    def _duplicate(self) -> None:
        for item in self._selected_items():
            row = self.grid.row(item)
            clone = QListWidgetItem()
            clone.setData(Qt.UserRole, item.data(Qt.UserRole))
            clone.setData(Qt.UserRole + 1, item.data(Qt.UserRole + 1))
            self.grid.insertItem(row + 1, clone)
        self._renumber()

    def _delete(self) -> None:
        items = self._selected_items()
        if not items:
            return
        if len(items) >= self.grid.count():
            show_error(self, "A PDF must keep at least one page.")
            return
        for item in items:
            self.grid.takeItem(self.grid.row(item))
        self._renumber()

    def _move(self, delta: int) -> None:
        row = self.grid.currentRow()
        new_row = row + delta
        if row < 0 or not 0 <= new_row < self.grid.count():
            return
        item = self.grid.takeItem(row)
        self.grid.insertItem(new_row, item)
        self.grid.setCurrentRow(new_row)
        self._renumber()

    def _plan(self) -> List[ops.PagePlan]:
        return [ops.PagePlan(self.grid.item(r).data(Qt.UserRole),
                             self.grid.item(r).data(Qt.UserRole + 1) or 0)
                for r in range(self.grid.count())]

    # -- output ------------------------------------------------------------
    def _ask_target(self, tag: str) -> Optional[Path]:
        suggested = ops.suggested_path(self._path, tag,
                                       self._settings.last_save_dir()
                                       or Path(self._path).parent)
        path, _ = QFileDialog.getSaveFileName(self, "Save as", str(suggested),
                                              PDF_FILTER)
        return Path(path) if path else None

    def save_as(self) -> None:
        if not self._path:
            show_error(self, "Open a PDF first.")
            return
        if self.grid.count() == 0:
            show_error(self, "There are no pages left to save.")
            return
        target = self._ask_target("Organised")
        if not target:
            return
        try:
            out = ops.organise(self._path, self._plan(), target, self._password)
        except ops.PdfError as exc:
            self.note.error(str(exc))
            return
        self._settings.set_last_save_dir(str(out.parent))
        self.note.success(f"Saved {out.name} in {out.parent}. "
                          f"The original file is unchanged.")

    def extract_selected(self) -> None:
        if not self._path:
            show_error(self, "Open a PDF first.")
            return
        items = self._selected_items()
        if not items:
            return
        rows = sorted(self.grid.row(i) for i in items)
        plan = [ops.PagePlan(self.grid.item(r).data(Qt.UserRole),
                             self.grid.item(r).data(Qt.UserRole + 1) or 0)
                for r in rows]
        target = self._ask_target("Extract")
        if not target:
            return
        try:
            out = ops.organise(self._path, plan, target, self._password)
        except ops.PdfError as exc:
            self.note.error(str(exc))
            return
        self.note.success(f"Extracted {len(plan)} page(s) to {out.name}.")

    def reset(self) -> None:
        self._path = None
        self._password = None
        self._thumbs.clear()
        self.grid.clear()
        self.file_label.setText("No file open")
        self.count_label.setText("")
        self.note.setVisible(False)


class OrganisePage(QWidget):
    """Organise screen: an interactive single-file editor plus a batch mode."""

    file_used = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 20, 26, 12)
        root.setSpacing(10)
        root.addWidget(heading("Organise PDF", 1))

        self.single = SingleOrganisePanel(settings)
        self.batch = BatchOrganisePanel(settings)
        self.single.file_used.connect(self.file_used.emit)
        self.batch.file_used.connect(self.file_used.emit)

        self.tabs = QTabWidget()
        self.tabs.addTab(self.single, "Single file")
        self.tabs.addTab(self.batch, "Batch mode")
        root.addWidget(self.tabs, 1)

    # The toolbar's Open / Save as / Clear act on whichever tab is in front.
    def _active(self):
        return self.tabs.currentWidget()

    def open_dialog(self) -> None:
        panel = self._active()
        if hasattr(panel, "open_dialog"):
            panel.open_dialog()
        else:
            panel.add_files_dialog()

    def load_file(self, path: str) -> None:
        self._active().load_file(path)

    def save_as(self) -> None:
        panel = self._active()
        if hasattr(panel, "save_as"):
            panel.save_as()
        else:
            panel.run()

    def reset(self) -> None:
        self._active().reset()

    # Convenience for tests and for the main window.
    @property
    def grid(self):
        return self.single.grid
