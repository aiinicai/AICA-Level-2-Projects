"""Home screen: offline promise, the five functions, theme picker, recent files."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QListWidget, QListWidgetItem,
                               QPushButton, QScrollArea, QToolButton, QVBoxLayout,
                               QWidget)

from .. import theme as theming
from ..common import heading, muted

FUNCTIONS = [
    ("split", "SPLIT PDF", "Take out pages or ranges, or cut every X pages"),
    ("merge", "MERGE PDF", "Combine several PDFs into a single file"),
    ("organise", "ORGANISE PDF", "Reorder, delete, rotate, duplicate, extract"),
    ("redact", "REDACT PDF", "Remove confidential content permanently"),
    ("edit", "EDIT PDF", "Text, dates, signatures, shapes, highlights"),
]


class FunctionCard(QFrame):
    """A large clickable card for one of the five tools."""

    clicked = Signal(str)

    def __init__(self, key: str, title: str, description: str, parent=None):
        super().__init__(parent)
        self._key = key
        self.setObjectName("FunctionCard")
        self.setProperty("hover", "false")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(112)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(6)
        name = QLabel(title)
        name.setObjectName("CardTitle")
        desc = QLabel(description)
        desc.setObjectName("CardDesc")
        desc.setWordWrap(True)
        for lbl in (name, desc):
            lbl.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            lay.addWidget(lbl)
        lay.addStretch(1)

    def _repolish(self, hovering: bool) -> None:
        self.setProperty("hover", "true" if hovering else "false")
        self.style().unpolish(self)
        self.style().polish(self)
        for child in self.findChildren(QLabel):
            self.style().unpolish(child)
            self.style().polish(child)

    def enterEvent(self, event):
        self._repolish(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._repolish(False)
        super().leaveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(
                event.position().toPoint()):
            self.clicked.emit(self._key)
        super().mouseReleaseEvent(event)


class ThemePicker(QWidget):
    """Seven colour swatches; clicking one repaints the whole application."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)

        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._buttons = {}

        for th in theming.ThemeManager.all_themes():
            btn = QToolButton()
            btn.setObjectName("Swatch")
            btn.setCheckable(True)
            btn.setFixedSize(QSize(34, 34))
            btn.setIconSize(QSize(20, 20))
            btn.setIcon(theming.swatch_icon(th, 20))
            btn.setToolTip(f"{th.name} theme")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _c=False, key=th.key: theming.manager().apply(key))
            self._group.addButton(btn)
            self._buttons[th.key] = btn
            lay.addWidget(btn)

        self._name = QLabel("")
        self._name.setObjectName("Badge")
        lay.addSpacing(6)
        lay.addWidget(self._name)
        lay.addStretch(1)

        theming.manager().changed.connect(self._sync)
        self._sync(theming.current())

    def _sync(self, th) -> None:
        for key, btn in self._buttons.items():
            btn.setChecked(key == th.key)
            btn.setIcon(theming.swatch_icon(theming.THEMES[key], 20))
        self._name.setText(f"{th.name} theme")


class HomePage(QWidget):
    open_function = Signal(str)      # 'split' | 'merge' | ...
    open_recent = Signal(str)        # file path
    clear_recent = Signal()

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        root = QVBoxLayout(inner)
        root.setContentsMargins(26, 22, 26, 22)
        root.setSpacing(16)

        # Title -------------------------------------------------------------
        title = heading("PDF Utility Pro", 1)
        subtitle = muted("A desktop toolkit for splitting, merging, organising, "
                         "redacting and editing PDF files.")
        root.addWidget(title)
        root.addWidget(subtitle)

        # Offline banner ----------------------------------------------------
        banner = QFrame()
        banner.setObjectName("Banner")
        blay = QVBoxLayout(banner)
        blay.setContentsMargins(18, 14, 18, 14)
        blay.setSpacing(3)
        promise = QLabel("100% Offline – Your Documents Never Leave Your Computer")
        promise.setObjectName("H2")
        blay.addWidget(promise)
        blay.addWidget(muted("Every page is processed on this machine. No cloud "
                             "service, no upload, no external API, no internet "
                             "connection required."))
        root.addWidget(banner)

        # Function cards ----------------------------------------------------
        grid = QGridLayout()
        grid.setSpacing(14)
        for n, (key, label, desc) in enumerate(FUNCTIONS):
            card = FunctionCard(key, label, desc)
            card.clicked.connect(self.open_function.emit)
            grid.addWidget(card, n // 3, n % 3)
            grid.setColumnStretch(n % 3, 1)
        grid.setRowMinimumHeight(0, 112)
        grid.setRowMinimumHeight(1, 112)
        root.addLayout(grid)

        # Theme picker ------------------------------------------------------
        theme_row = QFrame()
        theme_row.setObjectName("Card")
        tlay = QVBoxLayout(theme_row)
        tlay.setContentsMargins(16, 12, 16, 12)
        tlay.setSpacing(8)
        tlay.addWidget(heading("Colour theme"))
        tlay.addWidget(muted("Choose from seven themes. The choice applies to every "
                             "screen at once and is remembered the next time you "
                             "open the application."))
        tlay.addWidget(ThemePicker())
        root.addWidget(theme_row)

        # Recent files ------------------------------------------------------
        recent_card = QFrame()
        recent_card.setObjectName("Card")
        rlay = QVBoxLayout(recent_card)
        rlay.setContentsMargins(16, 12, 16, 12)
        rlay.setSpacing(8)
        head = QHBoxLayout()
        head.addWidget(heading("Recent files"))
        head.addStretch(1)
        clear_btn = QPushButton("Clear list")
        clear_btn.clicked.connect(self.clear_recent.emit)
        head.addWidget(clear_btn)
        rlay.addLayout(head)

        self.recent_list = QListWidget()
        self.recent_list.setMaximumHeight(132)
        self.recent_list.itemDoubleClicked.connect(
            lambda item: self.open_recent.emit(item.data(Qt.UserRole)))
        rlay.addWidget(self.recent_list)
        rlay.addWidget(muted("Double-click a file to load it into the current tool. "
                             "Only file paths are remembered — never file contents."))
        root.addWidget(recent_card)
        root.addStretch(1)

        self.refresh_recent()

    def refresh_recent(self) -> None:
        self.recent_list.clear()
        files = self._settings.recent_files()
        if not files:
            item = QListWidgetItem("No files opened yet.")
            item.setFlags(Qt.NoItemFlags)
            self.recent_list.addItem(item)
            return
        for path in files:
            item = QListWidgetItem(f"{Path(path).name}   —   {Path(path).parent}")
            item.setData(Qt.UserRole, path)
            self.recent_list.addItem(item)
