"""
Offline self-test for the PDF engine (app/pdf_ops.py).

Run:  python tools/self_test.py
It creates sample PDFs in a temporary folder, runs every operation and prints
a PASS/FAIL line for each. No GUI and no network required — useful for the
capstone demonstration and for regression testing after any code change.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import pymupdf as fitz
except ImportError:
    import fitz

from app import pdf_ops as ops

PASSED = FAILED = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {name}")
    else:
        FAILED += 1
        print(f"  FAIL  {name} {detail}")


def make_pdf(path: Path, pages: int, marker: str = "SAMPLE") -> Path:
    doc = fitz.open()
    for i in range(pages):
        page = doc.new_page()
        page.insert_text((72, 100), f"{marker} page {i + 1}", fontsize=18)
        page.insert_text((72, 300), "Confidential: PAN ABCDE1234F", fontsize=12)
    doc.save(str(path))
    doc.close()
    return path


def page_count(path) -> int:
    doc = fitz.open(str(path))
    n = doc.page_count
    doc.close()
    return n


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="pdfutil_test_"))
    out = tmp / "out"
    out.mkdir()
    src = make_pdf(tmp / "Original.pdf", 10)
    src2 = make_pdf(tmp / "Second.pdf", 4, "SECOND")

    print("\nPage specification parsing")
    check("1-3,5 parses", ops.parse_pages("1-3,5", 10) == [0, 1, 2, 4])
    check("open range 8- parses", ops.parse_pages("8-", 10) == [7, 8, 9])
    check("odd pages", ops.parse_pages("odd", 5) == [0, 2, 4])
    try:
        ops.parse_pages("99", 10)
        check("out of range rejected", False)
    except ops.PdfError:
        check("out of range rejected", True)
    check("describe_pages", ops.describe_pages([0, 1, 2, 5]) == "1-3, 6")

    print("\nInspect")
    info = ops.inspect(src)
    check("page count read", info.pages == 10, f"got {info.pages}")

    print("\n1. Split")
    files = ops.split_selected(src, "1-3,7", out, one_file=True)
    check("selected pages -> one file", len(files) == 1 and page_count(files[0]) == 4)
    check("suggested name Original_Split.pdf", files[0].name == "Original_Split.pdf",
          files[0].name)
    files = ops.split_selected(src, "1-2", out, one_file=False)
    check("one file per page", len(files) == 2 and all(page_count(f) == 1 for f in files))
    files = ops.split_ranges(src, "1-4, 5-10", out)
    check("ranges -> two files", len(files) == 2 and page_count(files[0]) == 4
          and page_count(files[1]) == 6)
    files = ops.split_every(src, 3, out)
    check("every 3 pages -> 4 files", len(files) == 4 and page_count(files[-1]) == 1)

    print("\n2. Merge")
    merged = ops.merge([src, src2], out / "Merged.pdf")
    check("merge 10 + 4 = 14", page_count(merged) == 14)
    try:
        ops.merge([src], out / "x.pdf")
        check("single-file merge rejected", False)
    except ops.PdfError:
        check("single-file merge rejected", True)

    print("\n3. Organise")
    plan = [ops.PagePlan(2), ops.PagePlan(0, rotation=90), ops.PagePlan(0)]
    org = ops.organise(src, plan, out / "Original_Organised.pdf")
    doc = fitz.open(str(org))
    check("reorder + duplicate", doc.page_count == 3)
    check("rotation applied", doc[1].rotation == 90, f"got {doc[1].rotation}")
    doc.close()
    ex = ops.extract_pages(src, [4, 5], out / "Original_Extract.pdf")
    check("extract pages", page_count(ex) == 2)

    print("\n3b. Batch transform (batch organise)")
    t = ops.transform(src, out / "T_keep.pdf", extract="2-4")
    check("keep only pages", page_count(t) == 3)
    t = ops.transform(src, out / "T_del.pdf", delete="1")
    check("delete cover page", page_count(t) == 9)
    t = ops.transform(src, out / "T_rot.pdf", rotate=90)
    doc = fitz.open(str(t))
    check("rotate every page", all(doc[i].rotation == 90 for i in range(doc.page_count)))
    doc.close()
    t = ops.transform(src, out / "T_rev.pdf", reverse=True)
    doc = fitz.open(str(t))
    check("reverse order", "page 10" in doc[0].get_text())
    doc.close()
    t = ops.transform(src, out / "T_combo.pdf", extract="1-6", delete="2", rotate=180)
    check("combined keep+delete+rotate", page_count(t) == 5)
    try:
        ops.transform(src, out / "T_none.pdf")
        check("no-op rejected", False)
    except ops.PdfError:
        check("no-op rejected", True)
    try:
        ops.transform(src, out / "T_empty.pdf", extract="1-3", delete="1-3")
        check("emptying document rejected", False)
    except ops.PdfError:
        check("emptying document rejected", True)

    print("\n4. Redact")
    preview = ops.text_in_rect(src, 0, (60, 285, 400, 315))
    check("text found before redaction", "ABCDE1234F" in preview.replace(" ", ""),
          repr(preview))
    red = ops.redact(src, [ops.RedactArea(0, (60, 285, 400, 315))],
                     out / "Original_Redacted.pdf")
    doc = fitz.open(str(red))
    remaining = doc[0].get_text()
    doc.close()
    check("text actually removed, not covered",
          "ABCDE1234F" not in remaining.replace(" ", ""), repr(remaining[:80]))
    check("other pages untouched", page_count(red) == 10)
    check("original file preserved", "ABCDE1234F" in
          ops.text_in_rect(src, 0, (60, 285, 400, 315)).replace(" ", ""))

    print("\n5. Edit")
    sig = tmp / "sign.png"
    pix = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 120, 40))
    pix.set_rect(pix.irect, (30, 60, 140))
    pix.save(str(sig))
    edits = [
        ops.Edit("text", 0, point=(72, 500), text="Checked by CA", size=14),
        ops.Edit("date", 0, point=(72, 520), text="07-09-2026"),
        ops.Edit("image", 0, rect=(300, 480, 430, 530), image_path=str(sig)),
        ops.Edit("line", 0, point=(72, 540), point2=(430, 540), width=1.2),
        ops.Edit("rect", 1, rect=(72, 100, 300, 160)),
        ops.Edit("highlight", 1, rect=(70, 90, 320, 115), colour=(1, 1, 0)),
        ops.Edit("note", 1, point=(400, 100), text="Verify this figure"),
        ops.Edit("rotate", 2, rotation=90),
    ]
    edited = ops.apply_edits(src, edits, out / "Original_Edited.pdf")
    doc = fitz.open(str(edited))
    check("text added", "Checked by CA" in doc[0].get_text())
    check("date added", "07-09-2026" in doc[0].get_text())
    check("annotations added", len(list(doc[1].annots() or [])) == 2)
    check("page rotated", doc[2].rotation == 90)
    doc.close()
    cleared = ops.apply_edits(edited, [ops.Edit("clear_annots", 1)],
                              out / "Cleared.pdf")
    doc = fitz.open(str(cleared))
    check("annotations removed", len(list(doc[1].annots() or [])) == 0)
    doc.close()

    print("\nFile safety")
    again = ops.split_selected(src, "1", out, one_file=True)
    check("no overwrite, new name used", again[0].name != "Original_Split.pdf",
          again[0].name)
    check("original still 10 pages", page_count(src) == 10)

    print("\nError handling")
    bad = tmp / "broken.pdf"
    bad.write_bytes(b"this is not a pdf at all")
    try:
        ops.inspect(bad)
        check("corrupt file rejected", False)
    except ops.PdfError:
        check("corrupt file rejected", True)
    enc = tmp / "locked.pdf"
    doc = fitz.open()
    doc.new_page().insert_text((72, 100), "secret")
    doc.save(str(enc), encryption=fitz.PDF_ENCRYPT_AES_256,
             owner_pw="owner", user_pw="user123")
    doc.close()
    try:
        ops.inspect(enc)
        check("password prompt raised", False)
    except ops.PasswordRequired:
        check("password prompt raised", True)
    check("opens with correct password", ops.inspect(enc, "user123").pages == 1)

    print("\nBatch")
    results = ops.run_batch([src, src2, bad],
                            lambda p: ops.split_every(p, 5, out))
    check("2 succeeded, 1 failed",
          sum(r.ok for r in results) == 2 and sum(not r.ok for r in results) == 1)

    print(f"\n{PASSED} passed, {FAILED} failed. Work folder: {tmp}")
    return 1 if FAILED else 0


if __name__ == "__main__":
    raise SystemExit(main())
