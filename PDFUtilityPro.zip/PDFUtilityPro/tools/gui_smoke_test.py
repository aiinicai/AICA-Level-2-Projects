"""
Headless check that the interface builds, every screen loads and all seven
themes apply cleanly. Saves a screenshot per theme.

Run:  QT_QPA_PLATFORM=offscreen python tools/gui_smoke_test.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import theme as theming  # noqa: E402
from app.settings import AppSettings  # noqa: E402

SHOTS = Path("/tmp/theme_shots")


def main() -> int:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    settings = AppSettings()
    theming.init_theme(app, settings)

    from app.main_window import MainWindow
    win = MainWindow(settings)
    win.resize(1180, 860)
    win.show()
    app.processEvents()

    SHOTS.mkdir(exist_ok=True)
    sample = Path(sys.argv[1]) if len(sys.argv) > 1 else None

    for screen in ("home", "split", "merge", "organise", "redact", "edit"):
        win.show_screen(screen)
        app.processEvents()
        print(f"  screen ok: {screen}")

    if sample and sample.exists():
        win.show_screen("organise")
        win.organise.tabs.setCurrentIndex(0)
        win.organise.load_file(str(sample))
        app.processEvents()
        print(f"  loaded sample into Organise: {win.organise.grid.count()} thumbnails")
        win.organise.tabs.setCurrentIndex(1)
        win.organise.load_file(str(sample))
        app.processEvents()
        print(f"  batch tab queued: {win.organise.batch.files.count()} file(s)")
        win.grab().save(str(SHOTS / "organise_batch.png"))
        win.organise.tabs.setCurrentIndex(0)
        win.show_screen("redact")
        win.redact.load_file(str(sample))
        app.processEvents()
        print("  loaded sample into Redact")

    for th in theming.ThemeManager.all_themes():
        theming.manager().apply(th.key)
        app.processEvents()
        for screen in ("home", "split", "merge", "organise", "redact", "edit"):
            win.show_screen(screen)
            app.processEvents()
            win.grab().save(str(SHOTS / f"{screen}_{th.key}.png"))
        print(f"  theme ok: {th.name}")

    theming.manager().apply("blue")
    print(f"\nScreenshots written to {SHOTS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
