"""
Regenerate the demonstration PDFs in samples/.

Run:  python tools/make_samples.py

Creates four files used by the user manual and the demo script:
  Sample_Client_Report.pdf   6 pages, contains a PAN and a bank account number
  Sample_Annexures.pdf       3 pages, for the merge demonstration
  Sample_Ledger_Extract.pdf  12 pages, for the batch-split demonstration
  Sample_Locked.pdf          1 page, password 'user123', for error handling

Everything is generated locally; no template is downloaded.
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    import pymupdf as fitz
except ImportError:
    import fitz

OUT = Path(__file__).resolve().parents[1] / "samples"


def _page_header(page, title: str, subtitle: str) -> None:
    page.insert_text((72, 90), title, fontsize=15)
    page.insert_text((72, 118), subtitle, fontsize=10)
    page.draw_line(fitz.Point(72, 130), fitz.Point(520, 130), width=0.8)


def client_report() -> Path:
    doc = fitz.open()
    for i in range(6):
        page = doc.new_page()
        _page_header(page, "ABC & Co LLP  —  Trial Balance Extract",
                     f"Financial year 2025-26     Page {i + 1} of 6")
        page.insert_text((72, 170), "Client PAN: ABCDE1234F", fontsize=12)
        page.insert_text((72, 192), "Bank A/c: 5012 3456 7890", fontsize=12)
        page.insert_text((72, 214), "Partner in charge: CA R. Mehta", fontsize=12)
        for r in range(12):
            page.insert_text((72, 260 + r * 20),
                             f"Ledger {r + 1:02d} ..................... "
                             f"{(r + 1) * 13750:,}.00", fontsize=10)
    path = OUT / "Sample_Client_Report.pdf"
    doc.save(str(path))
    doc.close()
    return path


def annexures() -> Path:
    doc = fitz.open()
    for i in range(3):
        page = doc.new_page()
        _page_header(page, f"Annexure {chr(65 + i)}",
                     "Supporting schedule to the trial balance")
        page.insert_text((72, 180), f"This is annexure {chr(65 + i)}.", fontsize=12)
    path = OUT / "Sample_Annexures.pdf"
    doc.save(str(path))
    doc.close()
    return path


def ledger_extract() -> Path:
    doc = fitz.open()
    for i in range(12):
        page = doc.new_page()
        _page_header(page, "General Ledger Extract",
                     f"Account group {i // 4 + 1}     Page {i + 1} of 12")
        for r in range(15):
            page.insert_text((72, 170 + r * 20),
                             f"{i + 1:02d}-{r + 1:03d}   Voucher entry   "
                             f"{(r + 3) * 2450:,}.00", fontsize=10)
    path = OUT / "Sample_Ledger_Extract.pdf"
    doc.save(str(path))
    doc.close()
    return path


def locked() -> Path:
    doc = fitz.open()
    page = doc.new_page()
    _page_header(page, "Confidential Working Paper", "Protected sample file")
    page.insert_text((72, 180), "Open password is: user123", fontsize=12)
    path = OUT / "Sample_Locked.pdf"
    doc.save(str(path), encryption=fitz.PDF_ENCRYPT_AES_256,
             owner_pw="owner456", user_pw="user123")
    doc.close()
    return path


def main() -> int:
    OUT.mkdir(exist_ok=True)
    for builder in (client_report, annexures, ledger_extract, locked):
        path = builder()
        print(f"  created {path.name}")
    print(f"\nSamples written to {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
