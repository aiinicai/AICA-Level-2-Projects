"""
PDF Utility Pro — entry point.

ICAI Capstone Project. A fully offline Windows desktop application for
splitting, merging, organising, redacting and editing PDF files.

Run:  python main.py
"""

from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QMessageBox

from app import theme as theming
from app.settings import AppSettings


def main() -> int:
    QApplication.setAttribute(Qt.AA_DontUseNativeMenuBar, False)
    app = QApplication(sys.argv)
    app.setApplicationName("PDF Utility Pro")
    app.setOrganizationName("ICAI Capstone")
    app.setStyle("Fusion")

    try:
        import pymupdf  # noqa: F401
    except ImportError:
        try:
            import fitz  # noqa: F401
        except ImportError:
            QMessageBox.critical(
                None, "Missing library",
                "PyMuPDF is not installed.\n\n"
                "Install it with:  pip install -r requirements.txt")
            return 1

    settings = AppSettings()
    theming.init_theme(app, settings)

    from app.main_window import MainWindow
    window = MainWindow(settings)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
