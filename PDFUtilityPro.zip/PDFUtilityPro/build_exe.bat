@echo off
REM ===================================================================
REM  PDF Utility Pro - build a standalone Windows .exe
REM  Run this from the project folder in a Command Prompt.
REM ===================================================================

echo [1/4] Creating a clean virtual environment...
python -m venv .venv
call .venv\Scripts\activate.bat

echo [2/4] Installing dependencies...
python -m pip install --upgrade pip
pip install -r requirements.txt

echo [3/4] Running the offline self-test...
python tools\self_test.py
if errorlevel 1 (
    echo Self-test failed. Fix the errors before building.
    pause
    exit /b 1
)

echo [4/4] Building PDFUtilityPro.exe ...
pyinstaller --noconfirm --clean ^
    --name "PDFUtilityPro" ^
    --windowed ^
    --onefile ^
    --hidden-import pymupdf ^
    --collect-submodules pymupdf ^
    --exclude-module tkinter ^
    --exclude-module matplotlib ^
    main.py

echo.
echo Done. The application is at:  dist\PDFUtilityPro.exe
echo Copy that single file to any Windows PC - Python is not required there.
pause
