# PDF Utility Pro — User Manual

---

## Before you start

**Your documents never leave this computer.** Every page is processed by the
application itself. Nothing is uploaded, no cloud service is used and no
internet connection is needed. You can disconnect the network and everything
still works.

**Your original file is never changed.** Every operation writes a new file. If
a result is wrong, the file you started with is still exactly as it was.

---

## Starting the application

Double-click `PDFUtilityPro.exe`.

If you are running from source: open a command prompt in the project folder and
type `python main.py`.

The home screen opens with the five tools, the theme picker and your recent
files.

---

## The toolbar

The toolbar is on every screen.

| Button | What it does |
|---|---|
| **Home** | Returns to the home screen |
| **Split / Merge / Organise / Redact / Edit** | Goes straight to that tool |
| **Open PDF** | Opens a file in the tool you are currently using |
| **Save as** | Saves the current work to a new file |
| **Clear** | Empties the current screen. No file on disk is touched |
| **Theme** | Changes the colour scheme |
| **Help** | Explains the tools, page numbers and file safety |

The status bar at the bottom shows the current screen on the left and the
offline reminder on the right.

---

## Choosing a colour theme

Seven themes are available: **Blue, Green, Purple, Orange, Red, Teal** and
**Dark**.

Two ways to change it:

- **Toolbar** — pick a theme from the dropdown on the right of the toolbar.
- **Home screen** — click one of the seven colour swatches under *Colour
  theme*. The active theme is outlined and named beside the swatches.

The change applies to every screen immediately, including page previews and
thumbnails, and it is remembered. The next time you open the application it
starts in the theme you chose. Themes affect appearance only; they never change
how a file is processed.

Dark is useful for long sessions in a dimly lit room. The six light themes are
better for demonstration on a projector.

---

## Writing page numbers

Several screens ask which pages you want. Type them like this:

| You type | You get |
|---|---|
| `5` | Page 5 |
| `1,4,9` | Pages 1, 4 and 9 |
| `3-7` | Pages 3 to 7 |
| `1-3, 8, 12-15` | Pages 1, 2, 3, 8, 12, 13, 14, 15 |
| `8-` | Page 8 to the end |
| `all` | Every page |
| `odd` | Pages 1, 3, 5, … |
| `even` | Pages 2, 4, 6, … |

Page numbers start at 1. If you type a page that does not exist, the
application tells you how many pages the file has instead of failing silently.

---

## 1. Split PDF

Use this to take pages out of a file, or to cut one file into several.

1. Click **Add PDFs…** and choose one file — or several, to apply the same
   split to all of them.
2. The page count and file size of the selected file appear on the right.
3. Choose how to split:
   - **Specific pages** — type the pages you want, for example `1-3, 7`. Tick
     *Put the selected pages into a single PDF* to get one file; untick it to
     get one file per page.
   - **Page ranges** — type ranges separated by commas, for example
     `1-5, 6-10, 11-20`. You get one PDF per range.
   - **Split every X pages** — set the number and the file is cut into
     consecutive parts of that size.
4. Choose the output folder with **Browse**.
5. Click **Split PDF**.

Results appear at the bottom in two panels. **Successful** lists each file with
the names of the PDFs it produced; **Failed** lists any file that could not be
processed, with the reason. One bad file never stops the others.

**Names you will get:** `Original_Split.pdf`, `Original_Page_3.pdf`,
`Original_Split_1to5.pdf`, `Original_Split_Part1.pdf`.

---

## 2. Merge PDF

Use this to join several PDFs into one.

1. Click **Add PDFs…**, or drag files from Explorer onto the list.
2. The files are joined top to bottom. To change the order, drag a file up or
   down, or select it and use **Move up** / **Move down**.
3. The panel on the right shows the number of files, the total pages and the
   combined size.
4. Type a **File name** and choose an **Output folder**.
5. Click **Merge PDFs**.

If a file in the list is password-protected you are asked for the password
before merging starts. If a file cannot be read at all, you are told which one,
so you can remove it.

---

## 3. Organise PDF

This screen has two tabs: **Single file** for hands-on work with thumbnails,
and **Batch mode** for applying the same change to many files at once.

### Single file

Use this to rearrange the pages inside one file.

1. Click **Open PDF…**. Thumbnails of every page appear, labelled with their
   position and their original page number.
2. Select one or more pages by clicking, Ctrl-clicking or dragging a box.
   **Select all** selects everything.
3. Then use:
   - **Rotate left / Rotate right** — turns the selected pages 90°
   - **Duplicate** — inserts a copy after each selected page
   - **Delete** — removes the selected pages
   - **Move up / Move down** — shifts the current page one position
   - Or drag a thumbnail to a new position
4. **Undo all changes** returns to the original order at any point.
5. Click **Save as new PDF** and choose where to save it.

To pull pages out into a separate file instead, select them and click
**Extract selected…**.

Nothing is written to disk until you save. Until then you are only rearranging
a plan on screen, and the source file is untouched.

### Batch mode

Use this when every file needs the same change — a scanned batch that all came
out sideways, or a folder of statements that each start with a cover sheet.

1. Switch to the **Batch mode** tab and click **Add PDFs…**. Add as many files
   as you like.
2. Choose what to apply to every file:
   - **Keep only pages** — leave blank to keep everything, or type page numbers
     to keep only those, for example `2-` to drop the first page of each file.
   - **Delete pages** — page numbers to remove, for example `1` to drop every
     cover sheet.
   - **Rotate every page** — 90° right, 180°, or 90° left.
   - **Reverse the page order** — for a stack scanned back to front.
3. Choose an output folder and click **Process all files**.

Operations are applied in this order: keep, then delete, then reverse, then
rotate.

Results appear in two panels. **Successful** lists each file with the output it
produced. **Failed** lists any file that could not be processed and why — for
example, if you asked to keep pages 1-10 in a file that only has three. A
failure never stops the other files.

Page numbers refer to each file's own pages, so files of different lengths can
be processed together.

---

## 4. Redact PDF

Use this to remove confidential content — a PAN, a bank account number, a
partner's remuneration, a client name — permanently.

> **Read this first.** Redaction cannot be undone in the file you create. The
> content inside the box is deleted from the document, not hidden behind a
> rectangle. Your original file is kept, so keep it somewhere safe.

1. Click **Open PDF…**.
2. Move to the page you want with the **Page** box. Increase **Zoom** if the
   text is small.
3. **Drag a box** over the content to remove. It appears in the *Marked areas*
   list on the right, together with a preview of the text inside it — check
   this preview before you save.
4. Mark as many areas as you need, across as many pages as you need.
5. Choose **Box colour** — black or white. White is useful when the surrounding
   page is white and you want the removal to be unobtrusive.
6. To undo a mark, select it and click **Remove selected mark**.
7. Click **Apply redaction and save as new PDF**. Confirm the warning, then
   choose where to save.

The result is saved as `Original_Redacted.pdf`.

**To verify the redaction worked**, open the new file in any PDF reader and try
to select the text where the content used to be, or use Ctrl+F to search for
it. There is nothing there — the text was deleted, not covered.

---

## 5. Edit PDF

Use this to add things to a page: a note, a date, a signature, a highlight.

This tool adds content on top of the page. It cannot retype text that is
already inside the PDF — to remove existing text, use **Redact**.

1. Click **Open PDF…** and move to the page you want.
2. Pick a tool on the left:

| Tool | How to use it |
|---|---|
| **Add text** | Click where the text should start, then type it |
| **Add today's date** | Click where the date should go; today's date is inserted |
| **Add signature / image** | First click *Choose signature…* and pick a PNG or JPG, then drag a box on the page to place it |
| **Draw line** | Drag from one point to another |
| **Draw box** | Drag to draw a rectangle |
| **Highlight area** | Drag over the text to highlight |
| **Add sticky note** | Click a spot, then type the note text |

3. **Text size** and **Choose colour…** apply to the next item you add.
4. **Rotate this page left / right** turns the current page.
   **Remove annotations** clears existing notes and highlights from the page.
5. Every action appears in **Pending changes** on the right. **Undo last
   change** removes the most recent one; **Discard all changes** clears them
   all.
6. Click **Save as new PDF**.

Nothing is written until you save.

**Tip for a signature.** Sign a blank sheet of white paper, photograph or scan
it, crop it tightly and save it as a PNG. Use that file with *Add signature /
image*.

---

## Recent files

The home screen lists the last ten files you opened. Double-click one to load
it into the tool you are using.

Only the **file path** is remembered — never the contents of any document.
Click **Clear list** to empty it.

---

## When something goes wrong

| Message | What it means | What to do |
|---|---|---|
| *…is password-protected* | The file needs an open password | Type it when asked. The password is used for that session only and is never saved |
| *…could not be opened. It may be damaged or not a PDF file* | The file is corrupt, or is not really a PDF | Open it in a PDF reader to confirm. If it opens there, try re-saving it from that reader first |
| *This PDF has N page(s); '…' is out of range* | You asked for a page that does not exist | Check the page count shown on screen and retype |
| *'…' is not a valid page entry* | The page numbers could not be understood | Use the format `1, 4, 9-12` |
| *A PDF must keep at least one page* | You tried to delete every page | Keep at least one page, or use a different tool |
| *Mark at least one area to redact* | No box was drawn | Drag a box over the content first |
| *Could not write …* | The folder is read-only, full, or the file is open elsewhere | Close the file in other programs, or choose a different folder |

In a batch, a failure on one file never stops the rest. The results table shows
which files succeeded and which did not, with the reason.

---

## Keeping your files safe

- The application never writes to the file you opened.
- If a suggested name is already taken, a numbered copy is written instead —
  `Original_Split (2).pdf` — so an earlier result is never destroyed.
- After redacting, keep the original in a secure location. It still contains
  the information you removed from the copy.
- A redacted file is an ordinary file on your disk once saved. Normal
  precautions — locked screen, disk encryption, careful choice of who receives
  it — still apply.
