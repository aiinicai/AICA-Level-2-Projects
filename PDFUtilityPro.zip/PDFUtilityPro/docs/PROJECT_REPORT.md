# PDF Utility Pro — ICAI Capstone Project Report

---

## 1. Project title

**PDF Utility Pro — A Fully Offline PDF Management Utility for Professional Practice**

Submitted for the ICAI Artificial Intelligence Level 2 Capstone Project.

---

## 2. Problem statement

Chartered accountants handle PDF files constantly: trial balances exported from
accounting software, signed financial statements, bank statements, working
papers, notices from tax authorities, annexures to be attached to a return.
Routine handling of these files requires ordinary operations — take pages 4 to
9 out of a scanned set, join six annexures into one attachment, drop a
duplicated page, mask a client's PAN before circulating a working paper.

In practice these operations are done on free websites where the file is
uploaded to an unknown server, processed there, and downloaded back. This
creates three problems that matter specifically to the profession:

1. **Confidentiality.** A client's financial data leaves the firm's control the
   moment it is uploaded. The firm has no record of where the copy went, how
   long it is retained, or who can read it. This sits badly against the duty of
   confidentiality under the ICAI Code of Ethics, and against client
   engagement terms that commonly promise that data will not be shared.

2. **Ineffective redaction.** The common way to hide a PAN or a bank account
   number is to draw a black rectangle over it in a viewer and save. The text
   underneath survives. Anyone can select it, copy it, or extract it with a
   one-line script. Sensitive data is disclosed while the person circulating
   the file believes it is protected.

3. **Cost and availability.** Full desktop PDF suites are licensed per seat and
   are heavier than the task requires. Web tools impose file-size caps, page
   limits and daily quotas, and stop working when the internet does.

There is a gap for a small, dependable desktop utility that performs the common
operations well, processes every page on the user's own machine, and removes
redacted content for real.

---

## 3. Objective

To design and build a lightweight Windows desktop application that:

- performs the five most common PDF operations — split, merge, organise, redact
  and edit — reliably and simply;
- processes every file locally, with no cloud service, no upload and no
  external API, so that a document never leaves the user's computer;
- performs redaction by deleting the underlying content, not by covering it;
- never modifies or overwrites the user's original file;
- presents a clean, professional interface with seven selectable colour themes;
- can be packaged as a single Windows `.exe` that runs without a separate
  Python installation;
- is built modularly, so each function can be tested on its own.

---

## 4. Scope

### In scope

| Area | What is included |
|---|---|
| Split | Extract specific pages; split into page ranges; split every X pages; batch over many files |
| Merge | Combine multiple PDFs in a user-controlled order, with drag-and-drop reordering |
| Organise | Thumbnail view; reorder, delete, rotate, duplicate and extract pages; batch mode applying one set of page operations to many files |
| Redact | Mark areas; permanently delete the text and images inside them; black or white box |
| Edit | Add text, today's date, a signature image, lines, boxes, highlights and sticky notes; rotate pages; remove existing annotations |
| Interface | Home screen with five function cards, seven colour themes, recent files, progress indication, success and error notices |
| Safety | Original file preserved; new filenames suggested; graceful handling of corrupt and password-protected files |
| Packaging | Standalone Windows `.exe` via PyInstaller |

### Out of scope

- Word-processor-style editing of text already inside a PDF. Existing text can
  be covered, highlighted or redacted, but not retyped or reflowed. This is a
  deliberate limitation, in line with the brief.
- OCR of scanned documents.
- Digital signature certificates (DSC) and signature validation.
- Form filling and form field creation.
- Conversion to and from Word, Excel or image formats.
- Multi-user access, server deployment or a shared database.
- Any feature requiring an internet connection.

The application is intentionally **not** an Adobe Acrobat replacement. It is a
focused utility for the operations a practice actually repeats.

---

## 5. Features

**Split PDF**
- Shows the total page count of the selected file.
- Three modes: specific pages (`1, 4, 9-12`), page ranges producing one file
  per range (`1-5, 6-10`), or split every X pages.
- Shorthand entries: `all`, `odd`, `even`, and open ranges such as `8-`.
- Option to place selected pages into one PDF or one PDF per page.
- Batch mode: add several files and apply the same split to all of them.

**Merge PDF**
- Add files through a dialog or by dragging them onto the list.
- Reorder by dragging, or with Move up / Move down.
- Live summary of file count, total pages and combined size.
- User chooses the output filename and folder.

**Organise PDF**
- Page thumbnails rendered locally.
- Drag to reorder; rotate left or right; duplicate; delete; move up or down.
- Extract the selected pages to a separate file.
- Every change is provisional; nothing is written until Save as is chosen.
- Undo all changes returns to the original order.
- **Batch mode**, on a second tab: keep only certain pages, delete certain
  pages, rotate every page and reverse the page order — applied to any number
  of files in one run. Thumbnail editing does not generalise to fifty files, so
  batch mode expresses the same operations as page numbers instead.

**Redact PDF**
- Page-by-page view with 75% to 200% zoom.
- Drag a box over confidential content; a preview of the text inside each box
  is listed, so the user can confirm before committing.
- Black or white redaction box.
- The content inside the box is deleted from the file and the document is
  saved with garbage collection, so the removed objects are not recoverable.
- An on-screen warning and a confirmation dialog state that the action is
  irreversible.

**Edit PDF**
- Tools: add text, add today's date, add a signature or image, draw a line,
  draw a box, highlight an area, add a sticky note.
- Choice of colour and text size.
- Rotate the current page; remove existing annotations from a page.
- Pending changes are listed and can be undone individually or discarded
  altogether before saving.

**Application-wide**
- Home screen carrying the statement *100% Offline — Your Documents Never
  Leave Your Computer*, repeated in the status bar on every screen.
- Seven colour themes: Blue, Green, Purple, Orange, Red, Teal, Dark, selectable
  from the toolbar dropdown or from swatches on the home screen. The choice
  applies everywhere at once and is remembered between sessions.
- Toolbar with Home, the five tools, Open PDF, Save as, Clear, Theme and Help.
- Recent files list (paths only, never contents), with a Clear option.
- Progress bar for long and batch operations, run on a background thread so the
  window stays responsive.
- Batch results are shown in two separate panels — Successful and Failed, each
  with its own count — so a failed file is never lost among the successes.
- Inline success and error notices; file and folder selection dialogs
  throughout.

---

## 6. Technology used

| Layer | Choice | Why |
|---|---|---|
| Language | Python 3.12 | Readable, large standard library, strong PDF ecosystem |
| Interface | PySide6 (Qt 6) — LGPL | Official Qt binding for Python; native Windows look; permissive licence |
| PDF engine | PyMuPDF 1.24+ (MuPDF) | Fast, pure-local, and the only widely used Python library with genuine content removal via `apply_redactions()` |
| Styling | Qt Style Sheets generated from colour tokens | One template renders all seven themes; no per-theme stylesheet to maintain |
| Settings | `QSettings` | Stores only the theme and recent file paths, in the user's own profile |
| Packaging | PyInstaller 6.x | Produces a single-file Windows `.exe` |
| Testing | Custom script, `tools/self_test.py` | 38 assertions covering every engine function; runs without a display |

All libraries are open-source and run entirely on the local machine. No
component contacts a network service at any point.

---

## 7. System requirements

**Minimum**

| Item | Requirement |
|---|---|
| Operating system | Windows 10 (64-bit) or later |
| Processor | Dual core, 1.6 GHz |
| RAM | 4 GB |
| Disk space | 250 MB for the packaged application |
| Display | 1366 × 768 |
| Internet | Not required at any stage |

**Recommended for large documents**

8 GB RAM, SSD storage, 1920 × 1080 display.

**For running from source** — Python 3.10 or later, and the packages in
`requirements.txt`. The end user of the packaged `.exe` needs none of this.

---

## 8. Functional requirements

| Ref | Requirement |
|---|---|
| FR-01 | The user can select a PDF through a file dialog or by choosing from the recent files list. |
| FR-02 | The application displays the total page count of an opened file. |
| FR-03 | The user can extract specific pages, split into page ranges, or split every X pages, and choose the output folder. |
| FR-04 | The user can select multiple PDFs, reorder them by drag-and-drop, and merge them into one file with a chosen name and folder. |
| FR-05 | The application displays page thumbnails and allows reordering, deletion, rotation, duplication and extraction of pages. |
| FR-06 | The user can mark rectangular areas and apply permanent redaction, choosing a black or white box. |
| FR-07 | Redaction must remove the underlying text and images, verifiable by text extraction of the output file. |
| FR-08 | The application warns, on screen and in a confirmation dialog, that redaction is irreversible. |
| FR-09 | The user can add text, a date, a signature image, lines, boxes, highlights and notes, rotate pages and remove annotations, then save to a new file. |
| FR-10 | The application must not modify or overwrite the source file under any operation. |
| FR-11 | The application suggests output names of the form `Original_Split.pdf`, `Original_Merged.pdf`, `Original_Redacted.pdf`, `Original_Edited.pdf`, `Original_Organised.pdf`. |
| FR-12 | If a suggested name already exists, a numbered variant is written instead. |
| FR-13 | Corrupt and non-PDF files produce a readable error message; the application does not crash. |
| FR-14 | Password-protected files prompt for the open password and proceed if it is correct. |
| FR-15 | Batch mode applies one operation to many files and reports success and failure per file. |
| FR-15a | Batch mode is available for Split (all three split modes) and for Organise (keep, delete, rotate, reverse). |
| FR-15b | Batch results are displayed with successful and failed files in separate panels. |
| FR-16 | Seven colour themes are selectable; the choice applies application-wide and persists between sessions. |
| FR-17 | The home screen and status bar display the offline statement. |
| FR-18 | Long operations show a progress indicator and do not freeze the interface. |
| FR-19 | A Help and About screen explains each tool, the page-number syntax and the file-safety rules. |
| FR-20 | A Clear action resets the current screen without affecting any file on disk. |

---

## 9. Non-functional requirements

| Ref | Requirement | How it is met |
|---|---|---|
| NFR-01 Privacy | No document data leaves the machine | No networking library is imported anywhere in the codebase; verifiable by inspection and by running with the network disconnected |
| NFR-02 Reliability | No unhandled crash on bad input | All engine functions raise `PdfError`; every call site catches it and shows a message |
| NFR-03 Performance | A 100-page file opens in a few seconds | Thumbnails are rendered at 28% scale; batch work runs on a background thread |
| NFR-04 Usability | Usable without training | Five labelled cards; plain-language instructions on every screen; error messages state what to do next |
| NFR-05 Maintainability | Each function testable alone | Engine (`pdf_ops.py`) contains no interface code and is exercised by 38 automated checks |
| NFR-06 Portability | Runs on any Windows PC | Single-file `.exe`; no installer, no registry changes beyond the user's own settings |
| NFR-07 Consistency | Themes apply everywhere | One stylesheet template plus a change signal for custom-drawn widgets |
| NFR-08 Data integrity | Source file never altered | Source is opened, a new document is built, and output is written to a different path |
| NFR-09 Accessibility | Legible at default settings | Text contrast checked in all seven themes; keyboard focus visible; no meaning carried by colour alone |
| NFR-10 Licensing | Free to distribute within the firm | PySide6 (LGPL) and PyMuPDF (AGPL/commercial) — for internal use; see Limitations |

---

## 10. Application architecture

The application uses a three-layer structure. The dependency direction is one
way: the interface calls the engine, and the engine never calls the interface.

```
┌─────────────────────────────────────────────────────────────────┐
│  PRESENTATION LAYER                                             │
│                                                                 │
│  main_window.py   toolbar, theme picker, screen stack, Help     │
│  pages/home.py    offline banner, 5 cards, themes, recents      │
│  pages/split_page.py  merge_page.py  organise_page.py           │
│  pages/organise_batch.py   batch panel for Organise             │
│  pages/redact_page.py edit_page.py                              │
│  common.py        shared widgets, page canvas, worker thread    │
└───────────────────────────────┬─────────────────────────────────┘
                                │  function calls, plain data types
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  ENGINE LAYER — app/pdf_ops.py                                  │
│                                                                 │
│  parse_pages()   split_selected()  split_ranges()  split_every()│
│  merge()         organise()        extract_pages()  transform() │
│  redact()        apply_edits()     render_page_png()            │
│  run_batch()     unique_path()     suggested_path()             │
│                                                                 │
│  No Qt import. No network import. Raises PdfError only.         │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  LIBRARY / OS LAYER                                             │
│  PyMuPDF (MuPDF)  ·  local filesystem  ·  QSettings             │
└─────────────────────────────────────────────────────────────────┘

  Cross-cutting:  theme.py   colour tokens → stylesheet → all screens
                  settings.py  theme choice and recent file paths
```

### Why this shape

- **The engine is independently testable.** `tools/self_test.py` imports
  `pdf_ops` alone and runs 38 checks with no display attached. Any change to
  the interface cannot silently break a PDF operation.
- **The engine is auditable for the privacy claim.** The offline promise is
  easy to verify because there is exactly one file that touches documents, and
  it imports only `pymupdf`, `pathlib`, `re` and `dataclasses`.
- **Themes are a single point of change.** Each screen styles itself by object
  name; `theme.py` renders one template for the active theme and emits a
  signal so custom-drawn surfaces repaint. Adding an eighth theme is one entry
  in a dictionary.
- **Long work does not freeze the window.** Batch operations run in a
  `QRunnable` on Qt's global thread pool, reporting progress back through
  signals.

### Typical flow — redaction

```
User drags a box on the page canvas
        ↓
RedactPage converts widget pixels → PDF points using the render zoom
        ↓
RedactArea(page, rect) appended to a list; text preview shown in the sidebar
        ↓
User presses Apply → confirmation dialog (irreversible)
        ↓
pdf_ops.redact() → add_redact_annot() per area → apply_redactions() per page
        ↓
doc.save(new_path, garbage=4, deflate=True, clean=True)
        ↓
Source file untouched; new file reported to the user
```

---

## 11. Database requirement

**None.** The application stores no document data and has no database.

The only persistence is `QSettings`, which keeps three items in the current
user's own profile (`HKCU\Software\ICAI Capstone\PDF Utility Pro` on Windows):

| Key | Content |
|---|---|
| `ui/theme` | The chosen colour theme, e.g. `teal` |
| `files/recent` | Up to ten file **paths** — never file contents |
| `files/last_open`, `files/last_save` | Folders last used in dialogs, so the next dialog opens in a sensible place |

The recent list can be cleared from the home screen. Removing the settings key
returns the application to its defaults; no document is affected.

A database was considered and rejected: it would create a second copy of
sensitive information with its own retention and access problems, for no
functional gain.

---

## 12. Security and privacy considerations

**Offline by construction.** The codebase imports no networking module —
no `requests`, `urllib`, `socket`, `http` or any SDK. There is nothing to
disable and no setting to get wrong. The claim can be demonstrated during
evaluation by disconnecting the machine from the network and using every
function normally.

**No telemetry, analytics or crash reporting.** Errors are shown to the user
and go nowhere else.

**No temporary copies in shared locations.** Files are read from and written to
the paths the user chooses. Nothing is staged in a temp directory or a cloud-
synchronised folder by the application itself.

**Redaction removes content.** `apply_redactions()` deletes the text, vector
and image objects intersecting the marked rectangle, and the file is saved with
`garbage=4, clean=True` so the removed objects are not left as unreferenced
data in the file. The automated test asserts this by extracting text from the
output and confirming the PAN is absent — the check that distinguishes genuine
redaction from a black rectangle.

**Originals are preserved.** No operation opens the source file for writing. If
a redaction is applied to the wrong area, the untouched original is still
there. The user is told this in the confirmation dialog.

**No silent overwriting.** If the suggested output name is taken, a numbered
variant is written, so an earlier result is never destroyed by a later one.

**Passwords are not stored.** A password entered to open an encrypted file is
held in memory for that session only, and is not written to settings, logs or
disk.

**Only paths are remembered.** The recent files list holds paths so the user
can reopen a file; it holds no page content, and it can be cleared.

**Residual risks the user should manage.** The output PDF is an ordinary file
on the user's disk and inherits the machine's own security — full-disk
encryption, screen lock and access control remain the user's responsibility.
The application cannot protect a redacted file after it has been shared.

---

## 13. Testing methodology

Testing was carried out at four levels.

**1. Engine tests (automated).** `tools/self_test.py` builds its own sample
PDFs in a temporary folder, exercises every function in `pdf_ops.py` and prints
a PASS/FAIL line for each of 38 assertions. It needs no display and no
internet, so it can be run on any machine and before every build — the build
script runs it and refuses to package if any check fails.

**2. Interface tests (automated, headless).** `tools/gui_smoke_test.py` builds
the main window under Qt's offscreen platform, opens every screen, loads a
sample document into the thumbnail and canvas screens, then applies each of the
seven themes in turn and saves a screenshot of every screen in every theme —
42 images. This caught four real defects during development: overlapping cards
on the home screen, labels painting an opaque background inside cards, a crash
when the Edit screen initialised its default tool before the canvas existed,
and two truncated button labels.

**3. Manual functional testing.** Each of the 24 test cases in
`docs/TEST_CASES.md` was executed against the running application on Windows,
covering normal use, boundary values and error paths.

**4. Verification of the privacy claim.** The application was run with the
network adapter disabled and every function exercised end to end. The source
was also searched for networking imports, with no matches.

**Test data.** Four sample files, regenerated by `tools/make_samples.py`: a
six-page report containing a PAN and a bank account number, a three-page
annexure set, a twelve-page ledger extract for batch work, and a
password-protected file. Damaged input is simulated by writing non-PDF bytes to
a `.pdf` file.

**Results.** 38 of 38 engine checks pass; 42 of 42 interface renders complete
without error; 26 of 26 manual test cases pass. Details in
`docs/TEST_CASES.md`.

---

## 14. Test cases

Twenty-six cases are recorded in full, with steps, expected results and
observed results, in **`docs/TEST_CASES.md`**. A summary:

| Group | Cases | Result |
|---|---|---|
| Split | TC-01 to TC-05 | Pass |
| Merge | TC-06 to TC-08 | Pass |
| Organise | TC-09 to TC-12 | Pass |
| Organise — batch | TC-25 to TC-26 | Pass |
| Redact | TC-13 to TC-15 | Pass |
| Edit | TC-16 to TC-18 | Pass |
| File safety | TC-19 to TC-20 | Pass |
| Error handling | TC-21 to TC-22 | Pass |
| Interface and themes | TC-23 to TC-24 | Pass |

The two cases that matter most for the project's purpose:

- **TC-14 — redaction actually removes content.** Redact the PAN on page 1,
  then extract text from the output file. The PAN must be absent. Passed;
  asserted automatically in the engine test as well.
- **TC-19 — the original is preserved.** After every operation, the source file
  keeps its original page count, content and modification time. Passed.

---

## 15. Limitations

1. **Existing PDF text cannot be rewritten.** Text can be added on top,
   highlighted, covered or redacted, but a typo inside the original document
   cannot be corrected in place. This is by design and matches the brief.
2. **No OCR.** In a scanned PDF there is no text layer, so a redaction box over
   a scanned PAN removes the image content in that area — which is the correct
   result — but text search and text preview will show nothing.
3. **Redaction is rectangular.** Irregular shapes must be covered with several
   rectangles.
4. **Redaction applies to the marked area only.** If the same PAN appears on
   five pages, five boxes are needed. There is no search-and-redact-all.
5. **Metadata is not scrubbed.** Author, title and creation software fields are
   carried into the output. A future version should offer to clear them.
6. **Only the open password is supported.** Files with owner-password
   restrictions but no open password will open; files needing a certificate or
   a digital-rights scheme will not.
7. **Very large documents are slower.** Thumbnail rendering for a file of
   several hundred pages takes noticeable time, as every page is rasterised.
8. **Windows is the target.** The code is cross-platform and runs on Linux and
   macOS from source, but only the Windows `.exe` is built and tested.
9. **Single user, single machine.** No shared settings, no audit trail of who
   redacted what.
10. **Licensing.** PyMuPDF is AGPL-licensed. Internal use within a firm, and
    academic submission, are fine; distributing the `.exe` commercially without
    releasing source would require a commercial PyMuPDF licence. This should be
    checked before any wider release.

---

## 16. Future enhancements

| Priority | Enhancement | Benefit |
|---|---|---|
| High | Search-and-redact — find every occurrence of a PAN, GSTIN or account number by pattern and mark them all | Removes the main manual step and the main risk of missing an occurrence |
| High | Metadata scrubbing on save | Closes the residual disclosure route noted in Limitations |
| High | Redaction audit log written next to the output file | Evidence of what was removed, for the working paper file |
| Medium | Offline OCR (Tesseract bundled locally) | Makes scanned documents searchable and redactable by text |
| Medium | Page numbering, headers, footers and watermarks in batch | Common requirement when assembling annexures |
| Medium | Compress and optimise, for e-filing size limits | Practical need when portals cap attachment size |
| Medium | Split by bookmark or by detected blank separator page | Faster handling of bulk scans |
| Medium | Batch mode for Edit — stamp the same date or signature across many files | Extends batch to the one remaining tool where it makes sense |
| Low | Password protection and permissions on output files | Rounds out the confidentiality story |
| Low | Extract to Word or Excel | Frequently requested, though outside the current scope |
| Low | User-defined custom theme, in addition to the seven supplied | Firm branding |
| Low | Command-line mode for scripted batch work | Automation for repetitive month-end tasks |

---

## 17. Conclusion

PDF Utility Pro meets the objective set out for this capstone: a small,
dependable desktop application that performs the five PDF operations a practice
actually repeats, and performs them entirely on the user's own computer.

Three results are worth drawing out.

First, **the privacy claim is structural, not a promise**. The application
contains no networking code at all. There is no setting to switch off and no
configuration mistake that could send a document anywhere. The claim can be
tested in front of an evaluator by pulling the network cable and using every
function normally.

Second, **redaction works properly**. The common practice of drawing a black
box leaves the text intact underneath and gives false assurance. This
application deletes the content and the automated test proves it, by extracting
text from the output file and asserting that the PAN is gone. For a profession
under a duty of confidentiality, that difference is the substance of the
project.

Third, **the structure supports evaluation and maintenance**. The engine is
separated from the interface, tested by 38 automated checks that run without a
display, and the interface is verified across all five screens and all seven
themes by a headless screenshot test. Each function can be demonstrated and
examined on its own, as the brief required.

The scope was held deliberately narrow. No attempt was made to reproduce a
commercial PDF suite. What the application does, it does simply and
predictably, and it protects the client's data while doing it — which is the
point.
