# PDF Utility Pro — Demonstration Script

A 15-minute live walkthrough for the ICAI Capstone evaluation, with a suggested
slide outline.

---

## Before the session

1. Copy `PDFUtilityPro.exe` and the `samples/` folder to the demonstration
   machine and confirm the application launches.
2. Run `python tools/make_samples.py` if the samples are missing, then open
   `Sample_Client_Report.pdf` once in a PDF reader and use Ctrl+F to find
   `ABCDE1234F`. Confirm it is found — you will repeat this later on the
   redacted copy, and the contrast is the strongest moment of the demo.
3. Prepare a signature PNG (sign white paper, photograph, crop, save as PNG).
4. Create an empty folder on the desktop named `Demo Output`.
5. Run `python tools/self_test.py` once and leave the output on screen or in a
   slide — 38 passed, 0 failed.
6. Set the theme to Blue to start.
7. **Have the network disconnected before you begin**, or be ready to
   disconnect it live.

---

## The demonstration

### 1 · The problem (1½ minutes) — no software yet

Say what the project is for, in the evaluator's own terms:

> "A firm handles client PDFs all day — trial balances, bank statements,
> working papers. The usual way to split or merge one is a free website, which
> means uploading a client's financial data to a server nobody in the firm
> controls. And the usual way to hide a PAN is to draw a black box over it in a
> reader — which leaves the text sitting underneath, fully selectable. This
> project addresses both."

### 2 · The offline claim (1 minute)

Open the application. Point to the banner on the home screen and the reminder
in the status bar.

Then make the claim concrete:

> "The network is already disconnected. Everything you are about to see runs on
> this machine. There is no setting to switch this off — the codebase contains
> no networking library at all, so there is nothing to misconfigure."

If a projector connection allows it, disconnect the network live instead.

### 3 · Seven themes (1 minute)

Click through the swatches on the home screen: Blue → Teal → Dark. Then switch
back using the toolbar dropdown.

> "Seven themes, changeable from either place, applied everywhere at once —
> including the page previews and thumbnails you'll see shortly — and
> remembered between sessions. They're defined as colour tokens in one file, so
> adding an eighth is a single entry."

Leave it on whichever theme reads best on the projector.

### 4 · Split, with batch (2½ minutes)

Home → **SPLIT PDF**.

- Add `Sample_Client_Report.pdf`; point out the page count appearing.
- *Specific pages*, type `1-3, 5`, output to `Demo Output`, **Split PDF**.
- Show the result row and the created filename `…_Split.pdf`.

Then the batch:

- **Add PDFs…** and add `Sample_Ledger_Extract.pdf` and a deliberately damaged
  `.pdf`.
- Choose *Split every X pages*, set 5, **Split PDF**.

> "One file failed, the other two finished. Successes and failures are listed
> in separate panels — a bad file in a batch never stops the rest, and it never
> gets lost among the successes either."

### 5 · Merge (1½ minutes)

Home → **MERGE PDF**.

- Add the report and the annexures. Point out the summary: 2 files, 9 pages.
- Select the annexures, **Move up** — the numbering updates.
- Name it, choose the folder, **Merge PDFs**.

> "Order is entirely the user's, by dragging or with the buttons."

### 6 · Organise (2 minutes)

Home → **ORGANISE PDF**, open the report.

- Thumbnails render — mention these are produced locally by the same engine.
- Drag page 6 to the front. Point out the labels: *1 (was page 6)*.
- Select page 2, **Rotate right**. Select page 3, **Duplicate**.
- **Undo all changes**, then redo one change and **Save as new PDF**.

Then switch to the **Batch mode** tab, add three files, set *Delete pages* to
`1`, rotate 90° right, and **Process all files**.

> "Thumbnail editing doesn't scale to fifty scans, so batch mode says the same
> thing in page numbers instead — drop page one, rotate everything — and
> applies it to the whole queue. Successes and failures land in separate
> panels."

> "Nothing is written until Save as. Until then you're rearranging a plan on
> screen, and the file on disk hasn't been touched."

### 7 · Redact — the centrepiece (3½ minutes)

Home → **REDACT PDF**, open the report. Take your time here.

- Point out the red warning line above the page.
- Zoom to 150%. Drag a box over `Client PAN: ABCDE1234F`.
- **Point at the sidebar** — the marked area shows a preview of the text inside
  it.

> "Before committing, you can see exactly what will be destroyed."

- Add a second box over the bank account number.
- **Apply redaction and save as new PDF**. Read the confirmation dialog aloud —
  note that Cancel is the default.
- Save to `Demo Output`.

Now the proof. Open the redacted file in a PDF reader:

- Try to select the text where the PAN was. Nothing selects.
- Ctrl+F, search `ABCDE1234F`. No match.
- Then open the **original** and repeat the search. It is found.

> "That is the difference between deleting content and covering it. Every other
> tool in this application matters less than this one does."

If a slide is available, show the assertion from `self_test.py` that checks
this automatically.

### 8 · Edit (2 minutes)

Home → **EDIT PDF**, open the report.

- *Add text* → click → type "Verified by CA R. Mehta".
- *Add today's date* → click below it.
- *Choose signature…* → pick the PNG → drag a box → the signature is placed.
- *Highlight area* → drag over a ledger row.
- Point at **Pending changes**; **Undo last change** once.
- **Save as new PDF**, then open the result.

> "Deliberately limited to adding things on top. Rewriting text already inside
> a PDF is out of scope — the brief called for that, and honestly, that's where
> these tools usually go wrong."

### 9 · File safety and errors (1 minute)

- Show `Demo Output` in Explorer: every file is a new one, named
  `_Split`, `_Merged`, `_Redacted`, `_Edited`.
- Run the same split again → `… (2).pdf` appears. Nothing is overwritten.
- Open the original sample — still 6 pages, PAN intact.
- Try to split page `99` → the error names the actual page count.

### 10 · Close (½ minute)

> "Five functions, entirely offline, originals always preserved, and redaction
> that actually removes. The engine is separate from the interface and has 38
> automated checks that run without a display, so each function can be tested
> on its own. It ships as a single .exe with no Python needed on the user's
> machine."

---

## Suggested slides

| # | Slide | Content |
|---|---|---|
| 1 | Title | PDF Utility Pro — A Fully Offline PDF Utility · your name · ICAI AI Level 2 Capstone |
| 2 | The problem | Three points: confidentiality of uploads, black boxes that don't redact, cost and availability |
| 3 | Objective and scope | Five functions in; Acrobat replacement, OCR, DSC out |
| 4 | Architecture | The three-layer diagram from the project report |
| 5 | Technology | Python 3.12 · PySide6 · PyMuPDF · PyInstaller — all local, all open-source |
| 6 | Live demonstration | *(switch to the application)* |
| 7 | Redaction proof | Before and after screenshots of the Ctrl+F search |
| 8 | Testing | 38 engine checks, 42 headless interface renders, 26 manual cases; 5 defects found and fixed |
| 9 | Privacy by construction | No networking code exists; works with the network disconnected |
| 10 | Limitations and future work | Search-and-redact, metadata scrubbing, offline OCR |
| 11 | Conclusion | Simplicity · offline processing · data privacy · reliability |

---

## Questions to be ready for

**"How do you know it's really offline?"**
There is no networking library imported anywhere in the code — not `requests`,
not `urllib`, not `socket`. It isn't a setting that could be misconfigured;
the capability doesn't exist. And it's running now with the network
disconnected.

**"How is your redaction different from a black rectangle?"**
A rectangle is drawn on top and the text object stays in the file, selectable
and extractable. This calls MuPDF's `apply_redactions()`, which deletes the
text, vector and image objects intersecting the box, then saves with garbage
collection so nothing is left as unreferenced data. The test suite asserts it
by extracting text from the output.

**"What if the file is corrupt or locked?"**
Both are handled. A locked file prompts for the open password, used for that
session only and never stored. A corrupt file gives a plain message. In a batch
neither stops the other files.

**"Why not a database?"**
It would create a second copy of sensitive client data with its own retention
and access problems, for no functional gain. The only thing stored is the theme
choice and a list of recent file paths — never contents — and that list can be
cleared.

**"What can't it do?"**
It can't retype text already inside a PDF, there's no OCR, no digital signature
certificates, and no format conversion. Redaction is per-area, so a PAN
appearing on five pages needs five boxes — search-and-redact is the first item
on the enhancement list.

**"Why PyMuPDF over other libraries?"**
It's the practical option for genuine content removal. Most Python PDF
libraries can draw a rectangle; PyMuPDF actually deletes the underlying
objects. It's also fast enough to render thumbnails without a wait. The
licensing caveat is noted in the report.
