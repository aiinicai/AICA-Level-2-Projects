# Financial Ratio Analysis Tool

**ICAI AICA Level 2 – Capstone Project**  
**Submitted by:** CA. Omprakash Sahoo  
**Batch / Registration Number:** AICA-L2B110  
**Submission date:** 25 November 2026

## 1. Project Overview

The Financial Ratio Analysis Tool is a browser-based application that calculates and presents ten commonly used financial ratios from a business's financial figures. It is intended to support preliminary financial analysis by organizing the results into four areas: liquidity, profitability, leverage and efficiency.

Users can enter figures directly in the application or upload a CSV file containing the required data. The tool calculates the ratios, displays the formula and result, and provides a plain-language interpretation. The results can be exported to a CSV file for further review.

The application is implemented as a single HTML page using HTML, CSS and JavaScript. It runs locally in a modern web browser and does not require a separate server, database or application installation.

## 2. Objectives

- Simplify the calculation of selected financial ratios.
- Provide a structured way to enter current-period and previous-period financial information.
- Group ratios into meaningful financial analysis categories.
- Display calculation formulas and understandable interpretations alongside results.
- Support CSV input and CSV export to make the analysis easier to reuse and review.

## 3. Key Features

- **Manual data entry:** Enter the financial figures through the application's input form.
- **CSV upload:** Load financial data from a CSV file using the required column names.
- **Sample data:** Populate the form with the built-in example figures to demonstrate the application.
- **Ratio calculation:** Calculate ten ratios across four categories.
- **Result interpretation:** View a short explanation of each calculated result.
- **CSV export:** Download the calculated results, including category, ratio, formula, result and interpretation, as `ratio_analysis_output.csv`.
- **Responsive layout:** The interface adapts to different screen sizes.
- **Input validation:** The application checks for missing fields and reports calculation errors such as zero denominators.

## 4. Ratios Covered

| Category | Ratio | Formula used |
|---|---|---|
| Liquidity | Current Ratio | Current Assets / Current Liabilities |
| Liquidity | Quick Ratio | (Current Assets - Inventory) / Current Liabilities |
| Profitability | Net Profit Margin | Net Profit / Revenue × 100 |
| Profitability | Return on Assets (ROA) | Net Profit / Average Total Assets × 100 |
| Profitability | Return on Equity (ROE) | Net Profit / Average Equity × 100 |
| Leverage | Debt to Equity | Total Debt / Total Equity |
| Leverage | Debt Ratio | Total Liabilities / Total Assets × 100 |
| Efficiency | Inventory Turnover | Cost of Goods Sold / Average Inventory |
| Efficiency | Receivables Turnover | Credit Sales / Average Trade Receivables |
| Efficiency | Asset Turnover | Revenue / Average Total Assets |

For ROA, ROE, inventory turnover, receivables turnover and asset turnover, the application uses the average of the current and previous-period balances for the relevant denominator. Ratios are displayed in times or percentage, as applicable.

## 5. Technology Stack

- **HTML5:** Page structure and form elements.
- **CSS3:** Styling, layout and responsive presentation.
- **JavaScript:** Input handling, CSV parsing, ratio calculations, validation, result display and CSV generation.
- **CSV:** Input and output data exchange format.

No external package installation or backend service is required for the application's stated functionality.

## 6. Project Files

| File | Description |
|---|---|
| `financial-ratio-analysis.html` | Main application. Open this file in a web browser to use the tool. |
| `sample_input.csv` | Sample financial data file that can be uploaded to test the application. |
| `ratio_analysis_output.csv` | Example output showing calculated ratios and interpretations. |
| `Financial_Ratio_Analysis_Project_Report.docx` | Project report describing the capstone project. |
| `command prompt.docx` | Notes containing instructions for opening the HTML application. |
| `README.md` | Project overview and usage instructions. |

## 7. How to Run the Application

1. Extract the project ZIP file to a folder on your computer.
2. Open the extracted `financial-ratio-analysis-app` folder.
3. Double-click `financial-ratio-analysis.html`.
4. The application will open in your default web browser.
5. Enter the required financial figures, or use the **Load sample figures** option.
6. Select **Calculate ratios** to display the analysis.
7. Select **Download CSV** in the results area to export the calculations.

Alternatively, on Windows, open the project folder in File Explorer, enter `cmd` in the address bar, and run:

```bat
start "" "financial-ratio-analysis.html"
```

## 8. Input Data Requirements

The application requires the following 16 numeric fields. The CSV header names must match these names exactly.

```csv
revenue,net_profit,current_assets,current_liabilities,inventory,total_assets,total_liabilities,total_debt,total_equity,cost_of_goods_sold,credit_sales,trade_receivables,previous_total_assets,previous_total_equity,previous_inventory,previous_trade_receivables
```

A CSV upload should contain a header row and at least one data row. The application reads the first data row. `sample_input.csv` is provided as an example of the required format.

## 9. Sample Data and Expected Output

The supplied sample input contains illustrative figures, including revenue of 1,000,000, net profit of 125,000 and current assets of 540,000. The accompanying `ratio_analysis_output.csv` demonstrates the resulting calculations, such as a current ratio of 1.80 times, a quick ratio of 1.40 times and a net profit margin of 12.50%.

These figures are examples for testing and demonstration; they are not presented as actual financial results of an entity.

## 10. Validation and Limitations

- All 16 financial fields are required for calculation.
- A ratio cannot be calculated when its denominator is zero; the application displays an error instead of a valid ratio.
- CSV uploads must include all required headers and numeric values. Only the first data row is used.
- The tool calculates the ratios using the formulas stated above. It does not independently verify the accuracy, classification or accounting treatment of the figures entered.
- The application does not connect to accounting software, a database, or an external financial data source.
- Ratio interpretation depends on the business model, accounting policies, industry, period and quality of the underlying data. The output should be reviewed alongside prior-period results, budgets and suitable industry benchmarks.

## 11. Conclusion

The Financial Ratio Analysis Tool provides a simple and accessible way to calculate ten selected financial ratios from user-provided financial information. By supporting manual entry, CSV upload, categorized results, plain-language interpretations and CSV export, it demonstrates how basic web technologies can be used to make preliminary financial analysis more structured and efficient.

**Disclaimer:** This tool is intended for educational, demonstration and preliminary analytical purposes. It is not a substitute for professional judgment, verification of financial statements or a comprehensive financial review.
