# AI-Enabled Finance and Loan Collection Management System
### AICA Level-2 Capstone Project

---

## Live Application

**Vercel Deployment URL:**
https://aica-level2-finance-ai.vercel.app

---

## Showcase Video

**google drive Video URL:**
https://drive.google.com/file/d/1Az8q5pkrPYohkqRBSd_XP6S7yywEA6Yh/view?usp=sharing

---

## Project Overview

This project is an AI-enabled Finance and Loan Collection Management System designed for a collection-oriented finance environment.

The objective is to enhance an existing operational finance application with AI-based analysis and decision support. The system helps management analyse collection-related information, identify higher-risk accounts, prioritise collection activities and obtain management-oriented insights from structured operational data.

The AI functionality has been added on top of the existing application without replacing any core transaction or operational functionality.

---

## Technology Stack

| Component | Technology / Platform | Version |
|---|---|---|
| Frontend Framework | React | 18.3.1 |
| Build Tool | Vite | 6.0.5 |
| Styling | Tailwind CSS | 3.4.17 |
| Charts | Recharts | 2.15.0 |
| Icons | Lucide React | 0.468.0 |
| Excel Import / Export | SheetJS (xlsx) | 0.18.5 |
| Deployment | Vercel | — |
| Source Code Management | GitHub | — |
| Backend / Data Integration | Google Apps Script (V8 Runtime) | — |
| AI Service | Gemini API (via Vercel Serverless Function) | — |

---

## Key Features

### 1. Operational Finance Management

The application retains its complete existing core functionality, including management of:

- Customers and field agents
- Loans with weekly, monthly and custom repayment schedules
- EMI calculations (rate-based and fixed-EMI methods)
- Collections and partial payments
- Arrears tracking
- Reinvestment management
- Customer passbooks (print / PDF)
- WhatsApp and SMS payment reminders
- Bulk Excel import and export
- Full data backup and restore
- Google Apps Script shared data synchronisation with auto-save every 15 seconds

### 2. AI Portfolio Analysis (Owner Only)

The system analyses structured portfolio data and generates management-oriented observations, insights and recommended actions across five sections:

- **A. Executive Summary** — overall collection health
- **B. Key Risks** — identified risk patterns
- **C. Collection Priorities** — accounts requiring immediate attention
- **D. Agent / Area Issues** — performance observations
- **E. Recommended Actions** — management action points

### 3. Customer Collection Priority Scoring

Customers are scored and ranked from 0 to 100 using a deterministic algorithm based on:

- Number of overdue instalments
- Number of days overdue
- Overdue amount
- Outstanding balance
- Partial payment history

Priority levels:

| Score | Level | Recommended Action |
|---|---|---|
| 70 – 100 | URGENT | Immediate field visit |
| 45 – 69 | HIGH | Contact today |
| 20 – 44 | WATCH | Follow-up within 24 hours |
| 0 – 19 | LOW / NORMAL | Normal follow-up |

This directly answers the management question: **"Which customers should we contact first?"**

### 4. Agent Risk Analysis

Collection performance is analysed for each field agent, including:

- Total customers, outstanding and overdue amounts
- Collection rate (collected ÷ due)
- Number of overdue and high-risk customers
- Agent-level risk score and risk level

### 5. Area-wise Risk Analysis

Geographical areas are ranked by collection risk, showing:

- Customers, loans, outstanding and overdue amounts per area
- Overdue and high-risk customer counts per area
- Area-level collection rate and risk score

### 6. Weekly AI Collection Report

A consolidated weekly report showing:

- Amount due and collected this week
- Collection rate (always shown from deterministic data)
- Overdue customers count
- AI management narrative (when Gemini API is configured)
- Major collection issues and recommended actions for next week

### 7. Ask AI

A natural-language question-and-answer facility for the owner. Example questions:

- Which customers should we contact first?
- What are the major collection problems this week?
- Which agent needs attention?
- Give me a summary of my portfolio.

### 8. AI Governance Disclaimer

A visible disclaimer is shown in the AI Insights section confirming that AI is used for decision support only and that all final decisions remain with management.

---

## AI Architecture

The project follows a hybrid deterministic + AI architecture:

```
Operational Application Data
        ↓
Deterministic JavaScript Calculations
(scores, rates, rankings, overdue figures)
        ↓
Structured Risk / KPI Dataset
        ↓
Vercel Serverless Function (/api/ai-analysis.js)
        ↓
Gemini API  (gemini-1.5-flash / gemini-2.0-flash-lite)
        ↓
Natural-language Explanation and Recommendations
        ↓
React Frontend (read-only display)
```

**Key principle:** Gemini is never responsible for calculating financial figures. All amounts, collection rates, risk scores and rankings are calculated in JavaScript. Gemini only provides natural-language explanation, summarisation and recommendations based on pre-calculated data.

If the Gemini API is unavailable or not configured, the application automatically falls back to a deterministic rule-based response and continues to function normally.

---

## Project Structure

```
aica-level2-finance-ai/
│
├── index.html                  # App entry point
├── package.json                # Dependencies and scripts
├── vite.config.js              # Vite build configuration
├── tailwind.config.js          # Tailwind CSS configuration
├── postcss.config.js           # PostCSS configuration
│
├── src/
│   ├── main.jsx                # React entry point
│   └── App.jsx                 # Complete application (single-file React app)
│
├── api/
│   └── ai-analysis.js          # Vercel Serverless Function — Gemini AI proxy
│
└── google-apps-script/
    ├── Code.gs                  # Google Apps Script backend
    └── appsscript.json          # Apps Script manifest (V8 runtime, IST timezone)
```

---

## Setup and Run Instructions

### Prerequisites

Ensure the following are installed on your computer:

- **Node.js** v18 or later (v20 LTS recommended)
- **npm** v9 or later (included with Node.js)
- **Git**

### 1. Clone the Repository

```bash
git clone [YOUR-GITHUB-REPOSITORY-URL]
cd aica-level2-finance-ai
```

### 2. Install Dependencies

```bash
npm install
```

This installs all dependencies defined in `package.json`:

| Package | Purpose |
|---|---|
| `react` `react-dom` | UI framework |
| `recharts` | Charts and visualisations |
| `lucide-react` | Icons |
| `xlsx` | Excel import / export |
| `vite` | Development server and build tool |
| `tailwindcss` `postcss` `autoprefixer` | Utility-first CSS |
| `@vitejs/plugin-react` | React support for Vite |

### 3. Configure Environment Variables

Create a `.env` file in the project root:

```text
GEMINI_API_KEY=your_gemini_api_key_here
```

> **Important:** Never commit this file to GitHub. Add `.env` to your `.gitignore`.

The `GEMINI_API_KEY` is used only by the Vercel Serverless Function (`/api/ai-analysis.js`). It is never exposed in the frontend source code.

If no API key is configured, the application uses a built-in deterministic fallback and continues to work normally.

### 4. Start the Development Server

```bash
npm run dev
```

The terminal will display the local development URL:

```
http://localhost:5173
```

Open this URL in your browser to access the application.

### 5. Build for Production

```bash
npm run build
```

The compiled output is placed in the `dist/` folder.

### 6. Preview the Production Build Locally

```bash
npm run preview
```

### 7. Vercel Deployment

**Connect your GitHub repository to Vercel:**

1. Go to [vercel.com](https://vercel.com) and sign in.
2. Click **Add New Project** and import your GitHub repository.
3. Vercel will auto-detect the Vite/React configuration. No changes needed.
4. Click **Deploy**.

**Configure the environment variable in Vercel:**

1. Open your Vercel project → **Settings** → **Environment Variables**.
2. Add the following variable:

| Name | Value |
|---|---|
| `GEMINI_API_KEY` | Your Google Gemini API key |

3. Redeploy the project after adding the variable.

Every push to the `main` branch will trigger an automatic redeployment.

---

## Google Apps Script Setup (Shared Data Sync)

The application uses Google Apps Script as a shared data backend so the owner and all field agents can see the same data in real time from any device.

**One-time setup steps:**

1. Go to [Google Drive](https://drive.google.com) and create a new Google Sheet.
2. In the Sheet, open **Extensions → Apps Script**.
3. Delete any existing code and paste the contents of `google-apps-script/Code.gs`.
4. Click **Deploy → New deployment**.
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Click **Deploy**, authorise with your Google account, and copy the **Web app URL** (ends in `/exec`).
6. Open `src/App.jsx` and paste your Web app URL into the `SYNC_URL` constant:

```js
const SYNC_URL = "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec";
```

7. Redeploy to Vercel (or push to GitHub).

> Until a real URL is configured, the application saves data only on the local device using `localStorage`. It still works fully during setup.

**Apps Script configuration (`appsscript.json`):**

```json
{
  "timeZone": "Asia/Kolkata",
  "runtimeVersion": "V8",
  "webapp": {
    "executeAs": "USER_DEPLOYING",
    "access": "ANYONE_ANONYMOUS"
  }
}
```

---

## AI Governance and Responsible Use

- Financial figures originate from the underlying application data only.
- Core financial calculations and business rules are deterministic JavaScript.
- Gemini AI is used only for analysis, explanation, summarisation and recommendations.
- AI-generated outputs must be reviewed by the authorised user before management action.
- Confidential credentials and API keys are not included in frontend source code.
- If the Gemini API is unavailable, the application falls back to deterministic analysis automatically.

---

## Demonstration

**Live Application:** https://aica-level2-finance-ai.vercel.app

**Showcase Video:** https://drive.google.com/file/d/1Az8q5pkrPYohkqRBSd_XP6S7yywEA6Yh/view?usp=sharing

---

## Conclusion

This project demonstrates how an existing Finance and Loan Collection Management System can be enhanced using AI without disturbing its core operational functionality.

The system combines operational transaction management, collection analytics, customer prioritisation, risk analysis and AI-based decision support in a single application.

The AI layer is not designed to replace the finance professional or collection manager. It is designed to help identify important collection issues faster, provide relevant management insights and support better-informed decision-making.

---

**AICA Level-2 Capstone Project**
