/**
 * Vercel Serverless Function: /api/ai-analysis
 *
 * Secure server-side AI proxy for Annapurna Finance Ledger.
 * Analyzes structured portfolio metrics using Gemini or OpenAI API keys stored
 * securely in server environment variables.
 *
 * Financial Safety:
 * - AI never mutates financial numbers.
 * - Source of truth figures are computed in JavaScript.
 */

const SYSTEM_INSTRUCTION = `You are a financial portfolio analysis assistant for a loan collection management system.
Analyse only the structured data provided by the application.
Do not invent customers, amounts, dates, payments, overdue amounts, financial results or other facts.
Do not change or calculate official accounting figures.
Use the supplied figures as the source of truth.
Your role is to identify collection risk, explain patterns, prioritise collection actions and summarise portfolio performance.
Clearly distinguish observations from recommendations.
If the supplied data is insufficient to answer a question, say that the available data is insufficient.`;

export default async function handler(req, res) {
  // Enable CORS if needed
  res.setHeader("Access-Control-Allow-Credentials", true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version"
  );

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method === "GET") {
    return res.status(200).json({ status: "AI Analysis API active", timestamp: new Date().toISOString() });
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : (req.body || {});
    const { action, portfolioSummary, customers, question } = body;

    const geminiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
    const openAiKey = process.env.OPENAI_API_KEY;

    // Check if any LLM API key is present
    if (!geminiKey && !openAiKey) {
      // Deterministic fallback response when no API key is yet configured
      return res.status(200).json(generateDeterministicResponse(action, portfolioSummary, customers, question));
    }

    if (action === "ask_ai") {
      const prompt = `Portfolio Metrics:
${JSON.stringify(portfolioSummary, null, 2)}

Top High & Medium Risk Customers Data:
${JSON.stringify((customers || []).slice(0, 15), null, 2)}

User Question: "${question}"

Provide a concise, factual, and direct response in 2-4 sentences based strictly on the data above. Cite specific names and exact numbers where relevant. If the question cannot be answered from the provided data, state that clearly.`;

      const aiText = await callLlm(prompt, geminiKey, openAiKey, false);
      return res.status(200).json({ answer: aiText, source: geminiKey ? "gemini" : "openai" });
    }

    // Default action: portfolio_insights
    const prompt = `Analyze this loan portfolio collection data and provide structured insights.

Portfolio Summary:
${JSON.stringify(portfolioSummary, null, 2)}

Customer Risk & Arrears Profile:
${JSON.stringify((customers || []).slice(0, 20), null, 2)}

Respond with a JSON object containing:
1. "portfolioNarrative": A 2-3 sentence executive briefing of collection health and key urgency.
2. "keyObservations": An array of 3-4 bullet observations on arrears, agent concentration, or overdue trends.
3. "recommendedActions": An array of 3 actionable recommendations for field agents and the owner.
4. "customerExplanations": An object mapping each customer "id" to a 1-sentence risk explanation (e.g. "High priority because customer has 3 overdue installments totaling ₹6,000 with 0 recent payments.").

Output pure JSON only.`;

    const aiText = await callLlm(prompt, geminiKey, openAiKey, true);
    let parsedData = null;

    try {
      // Clean possible markdown code fences
      const cleanJson = aiText.replace(/```json/gi, "").replace(/```/g, "").trim();
      parsedData = JSON.parse(cleanJson);
    } catch (err) {
      parsedData = {
        portfolioNarrative: aiText,
        keyObservations: [
          `Total overdue across active portfolio: ₹${portfolioSummary?.totalOverdue?.toLocaleString("en-IN") || 0}`,
          `${portfolioSummary?.highRiskCount || 0} customer(s) classified as High Risk requiring priority outreach.`,
        ],
        recommendedActions: [
          "Direct field agents to prioritize visits to customers with 2+ consecutive overdue installments.",
          "Verify collection status on partial payments before issuing new loan disbursements.",
        ],
        customerExplanations: {},
      };
    }

    return res.status(200).json({
      ...parsedData,
      source: geminiKey ? "gemini" : "openai",
    });

  } catch (error) {
    console.error("AI Analysis API Error:", error);
    return res.status(500).json({
      error: "AI analysis failed",
      message: error.message,
    });
  }
}

/**
 * Helper to call Gemini (preferred) or OpenAI
 */
async function callLlm(userPrompt, geminiKey, openAiKey, expectJson) {
  if (geminiKey) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key=${geminiKey}`;
    const payload = {
      systemInstruction: {
        parts: [{ text: SYSTEM_INSTRUCTION }]
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }]
        }
      ],
      generationConfig: {
        temperature: 0.2,
        ...(expectJson ? { responseMimeType: "application/json" } : {})
      }
    };

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Gemini API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data?.candidates?.[0]?.content?.parts?.[0]?.text || "No response generated from Gemini.";
  }

  if (openAiKey) {
    const url = "https://api.openai.com/v1/chat/completions";
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: SYSTEM_INSTRUCTION },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.2,
      ...(expectJson ? { response_format: { type: "json_object" } } : {})
    };

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openAiKey}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data?.choices?.[0]?.message?.content || "No response generated from OpenAI.";
  }

  throw new Error("No API key available");
}

/**
 * Deterministic fallback generator when no live API key is configured in Vercel
 */
function generateDeterministicResponse(action, portfolioSummary, customers, question) {
  const highRisk = (customers || []).filter(c => c.riskLevel === "HIGH");
  const medRisk = (customers || []).filter(c => c.riskLevel === "MEDIUM");
  const totalOverdue = portfolioSummary?.totalOverdue || 0;

  if (action === "ask_ai") {
    const qLower = (question || "").toLowerCase();
    let answer = "";
    if (qLower.includes("first") || qLower.includes("contact") || qLower.includes("priority")) {
      const topNames = (customers || []).slice(0, 3).map(c => `${c.name} (Overdue: ₹${c.overdueAmount.toLocaleString("en-IN")}, ${c.overdueCount} installment(s))`).join("; ");
      answer = `Based on priority ranking, field agents should immediately contact: ${topNames || "None with overdue installments"}.`;
    } else if (qLower.includes("agent")) {
      answer = `Collection risk is concentrated around clients with multiple overdue installments. Review the Agent performance dashboard for detailed area distribution.`;
    } else if (qLower.includes("summary") || qLower.includes("portfolio")) {
      answer = `The active portfolio has ${portfolioSummary?.activeLoans || 0} active loans with ₹${(portfolioSummary?.totalOutstanding || 0).toLocaleString("en-IN")} outstanding. Total overdue amount stands at ₹${totalOverdue.toLocaleString("en-IN")} across ${portfolioSummary?.overdueCustomersCount || 0} customer(s).`;
    } else {
      answer = `Based on the current portfolio data, there are ${highRisk.length} high-risk and ${medRisk.length} medium-risk customer(s) with total arrears of ₹${totalOverdue.toLocaleString("en-IN")}. Contact high-priority accounts first.`;
    }
    return {
      answer: `${answer} (Note: Running on rule-based analysis. Add GEMINI_API_KEY in Vercel for live LLM responses.)`,
      source: "deterministic_rule_engine",
      isFallback: true
    };
  }

  const customerExplanations = {};
  (customers || []).forEach(c => {
    if (c.riskLevel === "HIGH") {
      customerExplanations[c.id] = `High priority: ${c.overdueCount} overdue installment(s) totaling ₹${c.overdueAmount.toLocaleString("en-IN")} (${c.maxOverdueDays} days overdue). Prioritize in-person visit.`;
    } else if (c.riskLevel === "MEDIUM") {
      customerExplanations[c.id] = `Medium risk: ${c.overdueCount > 0 ? `${c.overdueCount} overdue installment(s)` : "Recent partial payment activity"}. Follow up via phone/WhatsApp.`;
    } else {
      customerExplanations[c.id] = `Low risk: Account is up to date with 0 overdue installments.`;
    }
  });

  return {
    portfolioNarrative: `Portfolio Overview: ${portfolioSummary?.activeLoans || 0} active loans with ₹${(portfolioSummary?.totalOutstanding || 0).toLocaleString("en-IN")} total outstanding. There are ${portfolioSummary?.overdueCustomersCount || 0} customer(s) in arrears totaling ₹${totalOverdue.toLocaleString("en-IN")}.`,
    keyObservations: [
      `${highRisk.length} customer(s) require urgent escalation due to high overdue aging or multiple missed installments.`,
      `${medRisk.length} customer(s) show initial warning signs (partial payments or 1 overdue installment).`,
      `Total arrears represent ${portfolioSummary?.totalOutstanding ? ((totalOverdue / portfolioSummary.totalOutstanding) * 100).toFixed(1) : 0}% of the active loan book.`
    ],
    recommendedActions: [
      "Prioritize field collections on highest-scored customers in the priority table.",
      "Send WhatsApp/SMS reminders to customers due in the next 7 days to prevent slippage into arrears.",
      "Review high-risk client accounts before authorizing any new or renewed credit."
    ],
    customerExplanations,
    source: "deterministic_rule_engine",
    isFallback: true
  };
}
