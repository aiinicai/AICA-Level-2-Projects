Place the final tested capstone source files here:
App.jsx
ai-analysis.js
Code.js
appsscript.json
package.json
index.html
main.jsx

The Gemini API key is configured securely as a Vercel
Environment Variable named GEMINI_API_KEY and is not included
in the source code or submission package.
