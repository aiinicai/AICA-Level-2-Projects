/**
 * Annapurna Finance Ledger - shared data bridge
 * ------------------------------------------
 * Paste this whole file into a Google Sheet's Apps Script editor
 * (Extensions -> Apps Script), then deploy it as a Web App:
 *   Deploy -> New deployment -> type: Web app
 *   Execute as: Me
 *   Who has access: Anyone
 * Copy the resulting URL (it ends in /exec) into SYNC_URL near the
 * top of src/App.jsx in the website project, then redeploy the site.
 *
 * All the app's data (agents, clients, loans, payments) is stored as
 * one JSON blob in a Google Drive file, not a spreadsheet cell -
 * Sheets cells cap out at 50,000 characters, which a real client
 * book (dozens of loans, hundreds of payment records) blows past
 * easily. A Drive file has no such limit. Everyone using the app -
 * every agent and the owner - reads and writes that same file, so
 * everyone always sees the same information.
 */
const DATA_FILENAME = "aica-finance-demo.json";
const LOCK_TIMEOUT_MS = 10000;

// Finds (or creates, on first run) the single Drive file everyone's data
// lives in. The file's id is cached in Script Properties after the first
// lookup so repeat calls don't have to search Drive every time.
function getDataFile_() {
  const props = PropertiesService.getScriptProperties();
  const cachedId = props.getProperty("DATA_FILE_ID");
  if (cachedId) {
    try {
      return DriveApp.getFileById(cachedId);
    } catch (e) {
      // Cached id no longer resolves (file moved/deleted) - fall through
      // and re-find or re-create it below.
    }
  }
  const existing = DriveApp.getFilesByName(DATA_FILENAME);
  if (existing.hasNext()) {
    const file = existing.next();
    props.setProperty("DATA_FILE_ID", file.getId());
    return file;
  }
  const file = DriveApp.createFile(DATA_FILENAME, "", MimeType.PLAIN_TEXT);
  props.setProperty("DATA_FILE_ID", file.getId());
  return file;
}

// Handles reads: the app's browser calls this with a plain GET request.
function doGet(e) {
  const file = getDataFile_();
  const value = file.getBlob().getDataAsString() || "";
  return ContentService.createTextOutput(value).setMimeType(ContentService.MimeType.JSON);
}

// Handles saves: the app's browser calls this with a POST request
// whose body is the full JSON data. Content-Type is sent as
// text/plain on purpose (see src/App.jsx) to avoid browser CORS
// preflight requests, which Apps Script Web Apps don't support.
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(LOCK_TIMEOUT_MS);
  try {
    const body = e && e.postData && e.postData.contents ? e.postData.contents : "{}";
    JSON.parse(body); // throws if it isn't valid JSON - reject bad writes
    const file = getDataFile_();
    file.setContent(body);
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}