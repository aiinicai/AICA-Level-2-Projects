# ITC Reconciler Pro

A desktop tool that matches **Input Tax Credit (ITC)** claimed in your client's
purchase register against the government's **GSTR-2B** data, and flags
mismatches in seconds.

## What it does
- Upload the client's purchase register (Excel).
- Upload the GSTR-2B file (Excel export from the GST portal, or the raw JSON).
- Matches every line by **GSTIN + Invoice Number**.
- Compares taxable value and tax amount (₹1 tolerance for rounding).
- Color-coded grid:
  - 🟩 **Matched** — GSTIN & invoice found in both, values agree
  - 🟨 **Value Mismatch** — found in both, but amounts differ
  - 🟥 **Missing in GSTR-2B** — claimed in books, vendor hasn't uploaded it (ITC at risk)
  - 🟦 **Missing in Books** — available in GSTR-2B but not yet booked (ITC being missed)
- One-click **Export Report** — a formatted, color-coded Excel workbook with a
  Summary sheet + one sheet per category, ready to send to a client or partner.

## Running it directly with Python (any OS)
```
pip install pandas openpyxl
python itc_reconciler.py
```

## Building a standalone Windows .exe (no Python needed to run it)
1. Make sure Python 3.9+ is installed on the build machine and on PATH.
2. Double-click **build_exe.bat** (or run it from a command prompt).
3. Wait for it to finish — it creates a virtual environment, installs
   dependencies, and runs PyInstaller.
4. Your app will be at: `dist\ITC_Reconciler_Pro.exe`
5. Copy that single .exe anywhere (a client's laptop, a USB drive) — it runs
   without needing Python installed on the target machine.

## File format notes
- **Purchase register**: any Excel sheet with columns roughly like GSTIN,
  Invoice Number, Invoice Date, Taxable Value, IGST, CGST, SGST — headers are
  matched flexibly, so exact wording doesn't matter much.
- **GSTR-2B**: works with the standard Excel download from the GST portal
  (it auto-detects the "B2B" sheet and skips the title rows), or the raw JSON
  export (best-effort parser — if your JSON doesn't match the standard schema,
  use the Excel export instead).

## Notes for further customization
- Matching tolerance (currently ₹1) is set in `TOLERANCE` near the top of
  `itc_reconciler.py`.
- Column header keywords are in `KEYWORD_MAP` — extend this if your firm uses
  unusual column names in purchase registers.
