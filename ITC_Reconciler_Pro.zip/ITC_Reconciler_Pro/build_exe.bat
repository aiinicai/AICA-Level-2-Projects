@echo off
REM ==========================================================================
REM  ITC Reconciler Pro - EXE Builder
REM  Double-click this file to build a standalone Windows .exe
REM  Requires: Python 3.9+ installed and added to PATH
REM ==========================================================================

echo ============================================================
echo   ITC RECONCILER PRO - Building standalone EXE
echo ============================================================
echo.

REM --- Check Python is available ---
where python >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found on PATH.
    echo Please install Python 3.9+ from https://www.python.org/downloads/
    echo and make sure to tick "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [1/4] Creating/activating virtual environment...
IF NOT EXIST "venv" (
    python -m venv venv
)
call venv\Scripts\activate.bat

echo.
echo [2/4] Installing required packages (pandas, openpyxl, pyinstaller)...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install dependencies. Check your internet connection.
    pause
    exit /b 1
)

echo.
echo [3/4] Cleaning previous build folders (if any)...
IF EXIST "build" rmdir /s /q build
IF EXIST "dist" rmdir /s /q dist
IF EXIST "ITC_Reconciler_Pro.spec" del /q ITC_Reconciler_Pro.spec

echo.
echo [4/4] Building the .exe with PyInstaller (this can take a minute)...
pyinstaller --noconfirm --onefile --windowed ^
    --name "ITC_Reconciler_Pro" ^
    itc_reconciler.py

echo.
IF EXIST "dist\ITC_Reconciler_Pro.exe" (
    echo ============================================================
    echo   SUCCESS! Your EXE is ready at:
    echo   %cd%\dist\ITC_Reconciler_Pro.exe
    echo ============================================================
    echo You can copy this single EXE file anywhere and run it -
    echo no Python installation is required on the target machine.
) ELSE (
    echo [ERROR] Build did not produce an EXE. Scroll up to see the error above.
)

echo.
pause
