"""
==========================================================================
 ITC RECONCILER PRO  |  GSTR-2B  vs  Purchase Register Matching Tool
 Built for Chartered Accountants — matches Input Tax Credit claimed in
 books against the GSTR-2B data auto-populated by the GST Portal.
==========================================================================
Author  : Generated for CA practice automation
Run     : python itc_reconciler.py
Build   : build_exe.bat  (creates a standalone .exe via PyInstaller)
==========================================================================
"""

import os
import re
import json
import threading
import traceback
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    import pandas as pd
except ImportError:
    raise SystemExit("This app needs 'pandas' and 'openpyxl'. Install with:\n"
                      "    pip install pandas openpyxl")

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    raise SystemExit("This app needs 'openpyxl'. Install with:\n    pip install openpyxl")


# ==========================================================================
#  COLOUR PALETTE  (professional but vibrant)
# ==========================================================================
COL_BG          = "#F4F7FB"
COL_HEADER_BG   = "#0B3D62"     # deep navy-teal
COL_HEADER_FG   = "#FFFFFF"
COL_ACCENT      = "#F2A73B"     # amber accent
COL_CARD_BG     = "#FFFFFF"

BTN_BLUE        = "#1565C0"
BTN_BLUE_HOVER  = "#0D47A1"
BTN_PURPLE      = "#6A1B9A"
BTN_PURPLE_HOVER= "#4A148C"
BTN_GREEN       = "#2E7D32"
BTN_GREEN_HOVER = "#1B5E20"
BTN_ORANGE      = "#EF6C00"
BTN_ORANGE_HOVER= "#E65100"
BTN_GRAY        = "#616161"
BTN_GRAY_HOVER  = "#424242"

ROW_MATCH_BG    = "#C8E6C9"     # green
ROW_MISMATCH_BG = "#FFF59D"     # yellow
ROW_MISS_2B_BG  = "#FFCDD2"     # red  -> claimed in books, absent in GSTR-2B
ROW_MISS_BOOKS_BG = "#B3E5FC"   # blue -> present in GSTR-2B, not booked

TOLERANCE = 1.0  # rupee tolerance for value comparison


# ==========================================================================
#  DATA NORMALISATION HELPERS
# ==========================================================================
KEYWORD_MAP = {
    "GSTIN":        ["gstin", "supplier gstin", "vendor gstin", "ctin"],
    "Name":         ["trade/legal name", "supplier name", "vendor name", "legal name", "trade name", "name"],
    "InvoiceNo":    ["invoice number", "invoice no", "inv no", "inv. no", "document number", "inum"],
    "InvoiceDate":  ["invoice date", "inv date", "document date", "idt"],
    "TaxableValue": ["taxable value", "taxable amount", "taxable val"],
    "IGST":         ["integrated tax", "igst"],
    "CGST":         ["central tax", "cgst"],
    "SGST":         ["state/ut tax", "state tax", "sgst"],
    "TotalValue":   ["invoice value", "total invoice value", "total value", "invoice amt"],
}


def _clean(text):
    return re.sub(r"[^a-z0-9/. ]", "", str(text).lower()).strip()


def guess_header_row(raw_df, max_scan=20):
    """GSTR-2B portal exports have a few title rows above the real header."""
    for i in range(min(max_scan, len(raw_df))):
        row_vals = [ _clean(v) for v in raw_df.iloc[i].tolist() ]
        if any("gstin" in v for v in row_vals):
            return i
    return 0


def normalize_columns(df):
    """Rename messy real-world headers to our standard schema."""
    rename = {}
    for col in df.columns:
        cclean = _clean(col)
        for std_name, keywords in KEYWORD_MAP.items():
            if std_name in rename.values():
                continue
            if any(kw in cclean for kw in keywords):
                rename[col] = std_name
                break
    df = df.rename(columns=rename)

    for needed in ["GSTIN", "Name", "InvoiceNo", "InvoiceDate", "TaxableValue", "IGST", "CGST", "SGST", "TotalValue"]:
        if needed not in df.columns:
            df[needed] = 0 if needed in ("TaxableValue", "IGST", "CGST", "SGST", "TotalValue") else ""

    keep = ["GSTIN", "Name", "InvoiceNo", "InvoiceDate", "TaxableValue", "IGST", "CGST", "SGST", "TotalValue"]
    df = df[keep].copy()

    for c in ["TaxableValue", "IGST", "CGST", "SGST", "TotalValue"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    df["GSTIN"] = df["GSTIN"].astype(str).str.strip().str.upper()
    df["InvoiceNo"] = df["InvoiceNo"].astype(str).str.strip().str.upper().str.replace(r"[\s\-/]", "", regex=True)
    df["Name"] = df["Name"].astype(str).str.strip()

    df = df[(df["GSTIN"] != "") & (df["GSTIN"].str.lower() != "nan") &
            (df["InvoiceNo"] != "") & (df["InvoiceNo"].str.lower() != "nan")]

    df["TaxAmount"] = df["IGST"] + df["CGST"] + df["SGST"]
    df["MatchKey"] = df["GSTIN"] + "||" + df["InvoiceNo"]
    return df.reset_index(drop=True)


def load_excel_smart(path, prefer_sheets=None):
    """Load an Excel file, auto-detecting the header row & best sheet."""
    xl = pd.ExcelFile(path)
    sheet_names = xl.sheet_names
    target_sheet = sheet_names[0]

    if prefer_sheets:
        for pref in prefer_sheets:
            for sn in sheet_names:
                if pref.lower() in sn.lower():
                    target_sheet = sn
                    break

    raw = pd.read_excel(path, sheet_name=target_sheet, header=None)
    header_row = guess_header_row(raw)
    df = pd.read_excel(path, sheet_name=target_sheet, header=header_row)
    df = df.dropna(how="all")
    return df


def load_gstr2b_json(path):
    """Best-effort parser for the official GSTR-2B JSON export (B2B section)."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    rows = []
    try:
        docdata = data.get("data", data).get("docdata", data.get("data", {}))
        b2b_list = docdata.get("b2b", [])
        for supplier in b2b_list:
            gstin = supplier.get("ctin", "")
            name = supplier.get("trdnm", "")
            for inv in supplier.get("inv", []):
                taxable = 0.0
                igst = cgst = sgst = 0.0
                for item in inv.get("items", inv.get("itms", [])):
                    itc = item.get("itc_avl", item.get("itcavl", {}))
                    taxable += float(item.get("txval", 0) or 0)
                    igst += float(itc.get("igst", 0) or 0)
                    cgst += float(itc.get("cgst", 0) or 0)
                    sgst += float(itc.get("sgst", 0) or 0)
                rows.append({
                    "GSTIN": gstin, "Name": name,
                    "InvoiceNo": inv.get("inum", ""),
                    "InvoiceDate": inv.get("dt", inv.get("idt", "")),
                    "TaxableValue": taxable, "IGST": igst, "CGST": cgst, "SGST": sgst,
                    "TotalValue": inv.get("val", 0),
                })
    except Exception:
        pass

    if not rows:
        raise ValueError(
            "Could not recognise this JSON as a standard GSTR-2B export.\n"
            "Please use the Excel (.xlsx) download of GSTR-2B instead."
        )
    return pd.DataFrame(rows)


def load_purchase_register(path):
    df = load_excel_smart(path)
    return normalize_columns(df)


def load_gstr2b(path):
    if path.lower().endswith(".json"):
        df = load_gstr2b_json(path)
    else:
        df = load_excel_smart(path, prefer_sheets=["B2B", "GSTR2B", "GSTR-2B"])
    return normalize_columns(df)


# ==========================================================================
#  RECONCILIATION ENGINE  (fully vectorised — no row-by-row Python loops)
# ==========================================================================
def _aggregate_by_key(df):
    """
    Collapse multiple line items that share the same GSTIN + Invoice Number
    (very common — one invoice, several tax-rate lines) into a single row
    per invoice by summing the amounts. This also guarantees the later
    merge is a clean 1-to-1 join instead of a combinatorial cross-join,
    which is what actually caused the long hang on real data.
    """
    agg = df.groupby("MatchKey", as_index=False).agg({
        "GSTIN": "first",
        "Name": "first",
        "InvoiceNo": "first",
        "InvoiceDate": "first",
        "TaxableValue": "sum",
        "IGST": "sum",
        "CGST": "sum",
        "SGST": "sum",
        "TaxAmount": "sum",
    })
    return agg


def reconcile(books_df, gstr_df, progress_cb=None):
    if progress_cb:
        progress_cb(5, 100)

    books_agg = _aggregate_by_key(books_df)
    gstr_agg = _aggregate_by_key(gstr_df)

    if progress_cb:
        progress_cb(30, 100)

    merged = books_agg.merge(
        gstr_agg, on="MatchKey", how="outer", suffixes=("_books", "_2b"), indicator=True
    )

    if progress_cb:
        progress_cb(60, 100)

    for c in ["TaxableValue_books", "TaxableValue_2b", "TaxAmount_books", "TaxAmount_2b"]:
        merged[c] = merged[c].fillna(0.0)

    is_left = merged["_merge"] == "left_only"
    is_right = merged["_merge"] == "right_only"
    is_both = merged["_merge"] == "both"

    taxable_diff = (merged["TaxableValue_books"] - merged["TaxableValue_2b"]).abs()
    tax_diff = (merged["TaxAmount_books"] - merged["TaxAmount_2b"]).abs()
    values_agree = (taxable_diff <= TOLERANCE) & (tax_diff <= TOLERANCE)

    conditions = [is_left, is_right, is_both & values_agree, is_both & ~values_agree]
    choices = ["Missing in GSTR-2B", "Missing in Books", "Matched", "Value Mismatch"]
    merged["Status"] = pd.Series(pd.NA, index=merged.index, dtype=object)
    for cond, choice in zip(conditions, choices):
        merged.loc[cond, "Status"] = choice

    merged["GSTIN"] = merged["GSTIN_books"].where(~is_right, merged["GSTIN_2b"])
    merged["Name"] = merged["Name_books"].where(~is_right, merged["Name_2b"])
    merged["InvoiceNo"] = merged["InvoiceNo_books"].where(~is_right, merged["InvoiceNo_2b"])
    merged["InvoiceDate"] = merged["InvoiceDate_books"].where(~is_right, merged["InvoiceDate_2b"])

    if progress_cb:
        progress_cb(85, 100)

    result = merged.rename(columns={
        "TaxableValue_books": "Taxable_Books", "TaxableValue_2b": "Taxable_2B",
        "TaxAmount_books": "Tax_Books", "TaxAmount_2b": "Tax_2B",
    })[["GSTIN", "Name", "InvoiceNo", "InvoiceDate", "Taxable_Books", "Taxable_2B",
        "Tax_Books", "Tax_2B", "Status"]].copy()

    for c in ["Taxable_Books", "Taxable_2B", "Tax_Books", "Tax_2B"]:
        result[c] = result[c].round(2)

    if progress_cb:
        progress_cb(100, 100)

    return result.reset_index(drop=True)


# ==========================================================================
#  UI HELPERS — a flat, rounded-look, hover button
# ==========================================================================
class ActionButton(tk.Button):
    def __init__(self, master, text, bg, hover, command=None, fg="white", **kw):
        super().__init__(
            master, text=text, command=command, bg=bg, fg=fg,
            activebackground=hover, activeforeground=fg,
            font=("Segoe UI", 10, "bold"), relief="flat",
            padx=16, pady=8, cursor="hand2", bd=0, **kw
        )
        self._bg, self._hover = bg, hover
        self.bind("<Enter>", lambda e: self.config(bg=self._hover))
        self.bind("<Leave>", lambda e: self.config(bg=self._bg))


class StatCard(tk.Frame):
    def __init__(self, master, title, value, color):
        super().__init__(master, bg=color, bd=0, highlightthickness=0)
        self.value_lbl = tk.Label(self, text=value, font=("Segoe UI", 18, "bold"),
                                   bg=color, fg="white")
        self.value_lbl.pack(pady=(10, 0))
        tk.Label(self, text=title, font=("Segoe UI", 9, "bold"),
                 bg=color, fg="white").pack(pady=(0, 10))

    def set_value(self, value):
        self.value_lbl.config(text=str(value))


# ==========================================================================
#  MAIN APPLICATION
# ==========================================================================
class ITCReconcilerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ITC Reconciler Pro  |  GSTR-2B vs Purchase Register")
        self.geometry("1300x760")
        self.minsize(1100, 650)
        self.configure(bg=COL_BG)

        self.books_path = None
        self.gstr_path = None
        self.books_df = None
        self.gstr_df = None
        self.result_df = None

        self._build_header()
        self._build_toolbar()
        self._build_progress()
        self._build_grid()
        self._build_summary()
        self._build_statusbar()

    # ---------------------------------------------------------- HEADER ----
    def _build_header(self):
        header = tk.Frame(self, bg=COL_HEADER_BG, height=86)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        tk.Label(header, text="🧾  ITC RECONCILER PRO", font=("Segoe UI", 20, "bold"),
                 bg=COL_HEADER_BG, fg=COL_HEADER_FG).pack(side="left", padx=24, pady=10)
        tk.Label(header, text="Purchase Register  ⇄  GSTR-2B  Matching Engine",
                 font=("Segoe UI", 11), bg=COL_HEADER_BG, fg=COL_ACCENT).pack(side="left", pady=10)

        tk.Label(header, text="For Chartered Accountants", font=("Segoe UI", 10, "italic"),
                 bg=COL_HEADER_BG, fg="#B0BEC5").pack(side="right", padx=24)

    # --------------------------------------------------------- TOOLBAR ----
    def _build_toolbar(self):
        bar = tk.Frame(self, bg=COL_BG)
        bar.pack(fill="x", padx=20, pady=14)

        self.books_btn = ActionButton(bar, "📂  Upload Purchase Register", BTN_BLUE, BTN_BLUE_HOVER,
                                       command=self.upload_books)
        self.books_btn.pack(side="left", padx=(0, 10))

        self.gstr_btn = ActionButton(bar, "📥  Upload GSTR-2B (Excel/JSON)", BTN_PURPLE, BTN_PURPLE_HOVER,
                                      command=self.upload_gstr2b)
        self.gstr_btn.pack(side="left", padx=10)

        self.run_btn = ActionButton(bar, "▶  Run Reconciliation", BTN_GREEN, BTN_GREEN_HOVER,
                                     command=self.run_reconciliation)
        self.run_btn.pack(side="left", padx=10)

        self.export_btn = ActionButton(bar, "💾  Export Report", BTN_ORANGE, BTN_ORANGE_HOVER,
                                        command=self.export_report)
        self.export_btn.pack(side="left", padx=10)

        self.reset_btn = ActionButton(bar, "🔄  Reset", BTN_GRAY, BTN_GRAY_HOVER,
                                       command=self.reset_all)
        self.reset_btn.pack(side="left", padx=10)

        info = tk.Frame(self, bg=COL_BG)
        info.pack(fill="x", padx=20)
        self.books_label = tk.Label(info, text="Purchase Register: not loaded",
                                     bg=COL_BG, fg=BTN_BLUE, font=("Segoe UI", 9, "bold"), anchor="w")
        self.books_label.pack(side="left", padx=(0, 30))
        self.gstr_label = tk.Label(info, text="GSTR-2B: not loaded",
                                    bg=COL_BG, fg=BTN_PURPLE, font=("Segoe UI", 9, "bold"), anchor="w")
        self.gstr_label.pack(side="left")

    # -------------------------------------------------------- PROGRESS ----
    def _build_progress(self):
        frame = tk.Frame(self, bg=COL_BG)
        frame.pack(fill="x", padx=20, pady=(0, 8))

        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Amber.Horizontal.TProgressbar", troughcolor="#E0E0E0",
                         background=COL_ACCENT, thickness=16)

        self.progress = ttk.Progressbar(frame, style="Amber.Horizontal.TProgressbar",
                                         orient="horizontal", mode="determinate")
        self.progress.pack(fill="x", side="left", expand=True)
        self.progress_lbl = tk.Label(frame, text="", bg=COL_BG, fg=COL_HEADER_BG,
                                      font=("Segoe UI", 9, "bold"), width=14)
        self.progress_lbl.pack(side="left", padx=10)

    # ------------------------------------------------------------ GRID ----
    def _build_grid(self):
        container = tk.Frame(self, bg=COL_BG)
        container.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        style = ttk.Style(self)
        style.configure("Treeview", font=("Segoe UI", 9), rowheight=26, background="white",
                         fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"),
                         background=COL_HEADER_BG, foreground="white")
        style.map("Treeview.Heading", background=[("active", COL_HEADER_BG)])

        cols = ("GSTIN", "Name", "InvoiceNo", "InvoiceDate", "Taxable_Books", "Taxable_2B",
                "Tax_Books", "Tax_2B", "Status")
        self.tree = ttk.Treeview(container, columns=cols, show="headings", selectmode="browse")

        widths = {"GSTIN": 130, "Name": 170, "InvoiceNo": 110, "InvoiceDate": 95,
                  "Taxable_Books": 100, "Taxable_2B": 100, "Tax_Books": 90, "Tax_2B": 90, "Status": 140}
        headers = {"GSTIN": "GSTIN", "Name": "Supplier", "InvoiceNo": "Invoice No",
                   "InvoiceDate": "Inv. Date", "Taxable_Books": "Taxable (Books)",
                   "Taxable_2B": "Taxable (2B)", "Tax_Books": "Tax (Books)",
                   "Tax_2B": "Tax (2B)", "Status": "Match Status"}

        for c in cols:
            self.tree.heading(c, text=headers[c])
            self.tree.column(c, width=widths[c], anchor="center" if c != "Name" else "w")

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(container, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.tree.tag_configure("matched", background=ROW_MATCH_BG)
        self.tree.tag_configure("mismatch", background=ROW_MISMATCH_BG)
        self.tree.tag_configure("miss2b", background=ROW_MISS_2B_BG)
        self.tree.tag_configure("missbooks", background=ROW_MISS_BOOKS_BG)

        # filter buttons
        filt = tk.Frame(self, bg=COL_BG)
        filt.pack(fill="x", padx=20)
        tk.Label(filt, text="Filter:", bg=COL_BG, font=("Segoe UI", 9, "bold")).pack(side="left")
        for label, tagname, color in [
            ("All", None, "#455A64"), ("✔ Matched", "matched", "#2E7D32"),
            ("⚠ Mismatch", "mismatch", "#F9A825"),
            ("✖ Missing in 2B", "miss2b", "#C62828"),
            ("➕ Missing in Books", "missbooks", "#0277BD"),
        ]:
            ActionButton(filt, label, color, color, fg="white",
                         command=lambda t=tagname: self.filter_grid(t)).pack(side="left", padx=4, pady=6)

    # --------------------------------------------------------- SUMMARY ----
    def _build_summary(self):
        self.summary_frame = tk.Frame(self, bg=COL_BG)
        self.summary_frame.pack(fill="x", padx=20, pady=(0, 12))

        self.cards = {}
        specs = [
            ("matched", "Matched", "#2E7D32"),
            ("mismatch", "Value Mismatch", "#F9A825"),
            ("miss2b", "Missing in GSTR-2B", "#C62828"),
            ("missbooks", "Missing in Books", "#0277BD"),
            ("itc_books", "ITC as per Books (₹)", "#37474F"),
            ("itc_2b", "ITC as per GSTR-2B (₹)", "#37474F"),
        ]
        for i, (key, title, color) in enumerate(specs):
            card = StatCard(self.summary_frame, title, "0", color)
            card.grid(row=0, column=i, sticky="nsew", padx=6)
            self.summary_frame.grid_columnconfigure(i, weight=1)
            self.cards[key] = card

    # ------------------------------------------------------- STATUSBAR ----
    def _build_statusbar(self):
        self.status = tk.Label(self, text="Ready. Upload both files to begin reconciliation.",
                                bg="#ECEFF1", fg="#37474F", anchor="w",
                                font=("Segoe UI", 9), padx=10, pady=4)
        self.status.pack(fill="x", side="bottom")

    # ================================================= FILE OPERATIONS ====
    def upload_books(self):
        path = filedialog.askopenfilename(
            title="Select Purchase Register (Excel)",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            self.books_df = load_purchase_register(path)
            self.books_path = path
            self.books_label.config(text=f"Purchase Register: {os.path.basename(path)}  "
                                          f"({len(self.books_df)} rows)")
            self.set_status(f"Loaded purchase register with {len(self.books_df)} entries.")
        except Exception as e:
            messagebox.showerror("Error reading Purchase Register", str(e))

    def upload_gstr2b(self):
        path = filedialog.askopenfilename(
            title="Select GSTR-2B file",
            filetypes=[("Excel/JSON files", "*.xlsx *.xls *.json"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            self.gstr_df = load_gstr2b(path)
            self.gstr_path = path
            self.gstr_label.config(text=f"GSTR-2B: {os.path.basename(path)}  "
                                         f"({len(self.gstr_df)} rows)")
            self.set_status(f"Loaded GSTR-2B with {len(self.gstr_df)} entries.")
        except Exception as e:
            messagebox.showerror("Error reading GSTR-2B", str(e))

    # =============================================== RECONCILIATION RUN ===
    def run_reconciliation(self):
        if self.books_df is None or self.gstr_df is None:
            messagebox.showwarning("Missing files", "Please upload both the Purchase Register and GSTR-2B files first.")
            return

        self.run_btn.config(state="disabled", text="Running...")
        self.progress["value"] = 0
        self.set_status("Matching GSTIN + Invoice Number across both files...")

        thread = threading.Thread(target=self._run_reconciliation_thread, daemon=True)
        thread.start()

    def _run_reconciliation_thread(self):
        try:
            def cb(done, total):
                pct = int(done / total * 100) if total else 100
                self.after(0, lambda: self._update_progress(pct))

            result = reconcile(self.books_df, self.gstr_df, progress_cb=cb)
            self.after(0, lambda: self._on_reconcile_done(result))
        except Exception as e:
            err = traceback.format_exc()
            self.after(0, lambda: messagebox.showerror("Reconciliation failed", f"{e}\n\n{err}"))
            self.after(0, lambda: self.run_btn.config(state="normal", text="▶  Run Reconciliation"))

    def _update_progress(self, pct):
        self.progress["value"] = pct
        self.progress_lbl.config(text=f"{pct}%")

    def _on_reconcile_done(self, result_df):
        self.result_df = result_df
        self.populate_grid(result_df)
        self.update_summary(result_df)
        self.run_btn.config(state="normal", text="▶  Run Reconciliation")
        self.set_status(f"Reconciliation complete — {len(result_df)} invoice lines processed.")

    # ==================================================== GRID / FILTER ===
    def populate_grid(self, df):
        self.tree.delete(*self.tree.get_children())
        tag_map = {"Matched": "matched", "Value Mismatch": "mismatch",
                   "Missing in GSTR-2B": "miss2b", "Missing in Books": "missbooks"}
        for _, row in df.iterrows():
            tag = tag_map.get(row["Status"], "")
            self.tree.insert("", "end", values=(
                row["GSTIN"], row["Name"], row["InvoiceNo"], row["InvoiceDate"],
                f'{row["Taxable_Books"]:.2f}', f'{row["Taxable_2B"]:.2f}',
                f'{row["Tax_Books"]:.2f}', f'{row["Tax_2B"]:.2f}', row["Status"]
            ), tags=(tag,))

    def filter_grid(self, tagname):
        if self.result_df is None:
            return
        if tagname is None:
            self.populate_grid(self.result_df)
            return
        tag_status = {"matched": "Matched", "mismatch": "Value Mismatch",
                      "miss2b": "Missing in GSTR-2B", "missbooks": "Missing in Books"}[tagname]
        self.populate_grid(self.result_df[self.result_df["Status"] == tag_status])

    def update_summary(self, df):
        counts = df["Status"].value_counts()
        self.cards["matched"].set_value(int(counts.get("Matched", 0)))
        self.cards["mismatch"].set_value(int(counts.get("Value Mismatch", 0)))
        self.cards["miss2b"].set_value(int(counts.get("Missing in GSTR-2B", 0)))
        self.cards["missbooks"].set_value(int(counts.get("Missing in Books", 0)))
        self.cards["itc_books"].set_value(f'{df["Tax_Books"].sum():,.0f}')
        self.cards["itc_2b"].set_value(f'{df["Tax_2B"].sum():,.0f}')

    # ============================================================ RESET ===
    def reset_all(self):
        self.books_df = self.gstr_df = self.result_df = None
        self.books_path = self.gstr_path = None
        self.books_label.config(text="Purchase Register: not loaded")
        self.gstr_label.config(text="GSTR-2B: not loaded")
        self.tree.delete(*self.tree.get_children())
        for key in self.cards:
            self.cards[key].set_value("0")
        self.progress["value"] = 0
        self.progress_lbl.config(text="")
        self.set_status("Reset complete. Upload both files to begin reconciliation.")

    # ============================================================ EXPORT ==
    def export_report(self):
        if self.result_df is None:
            messagebox.showwarning("Nothing to export", "Please run the reconciliation first.")
            return

        default_name = f"ITC_Reconciliation_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        path = filedialog.asksaveasfilename(
            title="Save Reconciliation Report", defaultextension=".xlsx",
            initialfile=default_name, filetypes=[("Excel file", "*.xlsx")]
        )
        if not path:
            return

        try:
            self._write_excel_report(path, self.result_df)
            self.set_status(f"Report exported to {path}")
            messagebox.showinfo("Export complete", f"Reconciliation report saved to:\n{path}")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _write_excel_report(self, path, df):
        wb = Workbook()

        # ---- Summary sheet ----
        ws = wb.active
        ws.title = "Summary"
        title_font = Font(size=16, bold=True, color="FFFFFF")
        header_fill = PatternFill("solid", fgColor="0B3D62")
        ws.merge_cells("A1:D1")
        ws["A1"] = "ITC Reconciliation Summary"
        ws["A1"].font = title_font
        ws["A1"].fill = header_fill
        ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 30

        counts = df["Status"].value_counts()
        summary_rows = [
            ("Generated on", datetime.now().strftime("%d-%b-%Y %H:%M")),
            ("Total invoice lines", len(df)),
            ("Matched", int(counts.get("Matched", 0))),
            ("Value Mismatch", int(counts.get("Value Mismatch", 0))),
            ("Missing in GSTR-2B (ITC at risk)", int(counts.get("Missing in GSTR-2B", 0))),
            ("Missing in Books (unclaimed ITC)", int(counts.get("Missing in Books", 0))),
            ("Total ITC as per Books (₹)", round(df["Tax_Books"].sum(), 2)),
            ("Total ITC as per GSTR-2B (₹)", round(df["Tax_2B"].sum(), 2)),
            ("Net ITC Difference (₹)", round(df["Tax_Books"].sum() - df["Tax_2B"].sum(), 2)),
        ]
        colors = {2: "C8E6C9", 3: "FFF59D", 4: "FFCDD2", 5: "B3E5FC"}
        for i, (label, val) in enumerate(summary_rows, start=3):
            ws.cell(row=i, column=1, value=label).font = Font(bold=True)
            cell = ws.cell(row=i, column=2, value=val)
            if i in colors:
                cell.fill = PatternFill("solid", fgColor=colors[i])
        ws.column_dimensions["A"].width = 36
        ws.column_dimensions["B"].width = 20

        # ---- Detail sheets ----
        sheet_map = [
            ("All Details", df),
            ("Matched", df[df["Status"] == "Matched"]),
            ("Value Mismatch", df[df["Status"] == "Value Mismatch"]),
            ("Missing in GSTR-2B", df[df["Status"] == "Missing in GSTR-2B"]),
            ("Missing in Books", df[df["Status"] == "Missing in Books"]),
        ]
        row_colors = {
            "Matched": "C8E6C9", "Value Mismatch": "FFF59D",
            "Missing in GSTR-2B": "FFCDD2", "Missing in Books": "B3E5FC",
        }
        headers = ["GSTIN", "Name", "InvoiceNo", "InvoiceDate", "Taxable_Books",
                   "Taxable_2B", "Tax_Books", "Tax_2B", "Status"]

        thin = Side(style="thin", color="CCCCCC")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)

        for sheet_name, sub_df in sheet_map:
            sh = wb.create_sheet(sheet_name)
            for c, h in enumerate(headers, start=1):
                cell = sh.cell(row=1, column=c, value=h)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
                cell.border = border
            for r, (_, row) in enumerate(sub_df.iterrows(), start=2):
                for c, h in enumerate(headers, start=1):
                    cell = sh.cell(row=r, column=c, value=row[h])
                    cell.border = border
                    fill_color = row_colors.get(row["Status"])
                    if fill_color:
                        cell.fill = PatternFill("solid", fgColor=fill_color)
            for c, h in enumerate(headers, start=1):
                sh.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 4)
            sh.freeze_panes = "A2"

        wb.save(path)

    # ============================================================= MISC ===
    def set_status(self, text):
        self.status.config(text=text)


# ==========================================================================
if __name__ == "__main__":
    app = ITCReconcilerApp()
    app.mainloop()
