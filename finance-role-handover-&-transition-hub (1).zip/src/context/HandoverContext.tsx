import React, { createContext, useContext, useState, useEffect } from 'react';
import { HandoverPackage } from '../types/handover';
import { initialHandoverPackage } from '../data/defaultHandoverData';
import { rolePresets } from '../data/rolePresets';

interface HandoverContextType {
  data: HandoverPackage;
  updateData: (newData: HandoverPackage) => void;
  updateSection: <K extends keyof HandoverPackage>(sectionKey: K, sectionData: HandoverPackage[K]) => void;
  loadPreset: (presetId: string) => void;
  resetToDefault: () => void;
  completionRate: number;
  totalChecklistCount: number;
  completedChecklistCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAiModalOpen: boolean;
  setIsAiModalOpen: (open: boolean) => void;
  isSignOffModalOpen: boolean;
  setIsSignOffModalOpen: (open: boolean) => void;
}

const HandoverContext = createContext<HandoverContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'finance_handover_package_v1';

export const HandoverProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<HandoverPackage>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load saved handover data', e);
    }
    return initialHandoverPackage;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isSignOffModalOpen, setIsSignOffModalOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save handover data', e);
    }
  }, [data]);

  const updateData = (newData: HandoverPackage) => {
    setData({
      ...newData,
      lastUpdated: new Date().toISOString().split('T')[0],
    });
  };

  const updateSection = <K extends keyof HandoverPackage>(sectionKey: K, sectionData: HandoverPackage[K]) => {
    setData((prev) => ({
      ...prev,
      [sectionKey]: sectionData,
      lastUpdated: new Date().toISOString().split('T')[0],
    }));
  };

  const loadPreset = (presetId: string) => {
    const preset = rolePresets.find((p) => p.id === presetId);
    if (preset) {
      setData({
        ...preset.packageData,
        lastUpdated: new Date().toISOString().split('T')[0],
      });
    }
  };

  const resetToDefault = () => {
    setData(initialHandoverPackage);
  };

  // Calculate completion percentage across multiple operational vectors
  const processCount = data.processTasks.length;
  const processDone = data.processTasks.filter((t) => t.status === 'completed' || t.status === 'reverse-shadowed').length;

  const timelineCount = data.handoverTimeline.length;
  const timelineDone = data.handoverTimeline.filter((t) => t.completed).length;

  const recCount = data.reconciliationWorkflows.length;
  const recDone = data.reconciliationWorkflows.filter((w) => w.status === 'completed' || w.status === 'reverse-shadowed').length;

  const sysCount = data.systemTools.length;
  const sysDone = data.systemTools.filter((s) => s.status === 'completed').length;

  const totalChecklistCount = processCount + timelineCount + recCount + sysCount;
  const completedChecklistCount = processDone + timelineDone + recDone + sysDone;
  const completionRate = totalChecklistCount > 0 ? Math.round((completedChecklistCount / totalChecklistCount) * 100) : 0;

  return (
    <HandoverContext.Provider
      value={{
        data,
        updateData,
        updateSection,
        loadPreset,
        resetToDefault,
        completionRate,
        totalChecklistCount,
        completedChecklistCount,
        searchQuery,
        setSearchQuery,
        activeTab,
        setActiveTab,
        isAiModalOpen,
        setIsAiModalOpen,
        isSignOffModalOpen,
        setIsSignOffModalOpen,
      }}
    >
      {children}
    </HandoverContext.Provider>
  );
};

export const useHandover = () => {
  const context = useContext(HandoverContext);
  if (!context) {
    throw new Error('useHandover must be used within a HandoverProvider');
  }
  return context;
};
