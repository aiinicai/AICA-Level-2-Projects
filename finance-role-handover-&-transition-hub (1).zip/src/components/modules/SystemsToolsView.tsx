import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { SystemTool, HandoverStatus } from '../../types/handover';
import {
  Laptop,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  ExternalLink,
  FileSpreadsheet,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';

export const SystemsToolsView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [tools, setTools] = useState<SystemTool[]>(data.systemTools);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('systemTools', tools);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddTool = () => {
    const newTool: SystemTool = {
      id: `sys-${Date.now()}`,
      systemName: 'New Financial Software / Portal',
      purpose: 'Financial reporting, reconciliation, or payment management.',
      accessUrl: 'https://app.system.com',
      roleProfileRequired: 'Finance User / Approver',
      howToRequestAccess: 'Submit ticket to IT Helpdesk with manager approval.',
      adminContact: 'System Admin (admin@company.com)',
      keyReportsExtracted: [
        {
          reportName: 'Monthly General Ledger Export',
          menuPath: 'Reports > Financial Accounting > General Ledger',
          frequency: 'Monthly',
          purpose: 'Balance sheet reconciliation and close.',
        },
      ],
      status: 'in-progress',
    };
    setTools((prev) => [...prev, newTool]);
  };

  const handleRemoveTool = (id: string) => {
    setTools((prev) => prev.filter((t) => t.id !== id));
  };

  const handleUpdateTool = (id: string, field: keyof SystemTool, value: any) => {
    setTools((prev) =>
      prev.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 4</span>
            <span>•</span>
            <span>Technology & Portals</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            System Access, ERP & Reporting Extraction
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Document all ERPs, banking gateways, tax portals, BI dashboards, access provisioning workflows, and key report menu navigation paths.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddTool}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add System Tool
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Systems Grid */}
      <div className="space-y-5">
        {tools.map((tool) => (
          <div
            key={tool.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
          >
            {/* Header & Access Status */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200 shrink-0">
                  <Laptop className="h-4 w-4" />
                </div>
                <div>
                  <input
                    type="text"
                    value={tool.systemName}
                    onChange={(e) => handleUpdateTool(tool.id, 'systemName', e.target.value)}
                    className="bg-transparent font-bold text-sm text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1"
                  />
                  <div className="text-xs text-slate-500 px-1">
                    Access Portal: <code className="text-blue-700 font-mono font-semibold">{tool.accessUrl}</code>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <select
                  value={tool.status}
                  onChange={(e) => handleUpdateTool(tool.id, 'status', e.target.value as HandoverStatus)}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-md border focus:outline-none ${
                    tool.status === 'completed'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-50 text-amber-800 border-amber-300'
                  }`}
                >
                  <option value="not-started">Access Pending</option>
                  <option value="in-progress">Ticket In Progress</option>
                  <option value="shadowing">Shadowing / Shared</option>
                  <option value="completed">Provisioned & Tested</option>
                </select>

                <button
                  onClick={() => handleRemoveTool(tool.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Remove Tool"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Purpose & Provisioning Workflow */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 block">System Purpose:</span>
                <textarea
                  rows={2}
                  value={tool.purpose}
                  onChange={(e) => handleUpdateTool(tool.id, 'purpose', e.target.value)}
                  className="w-full bg-white text-slate-900 p-2 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 block">How to Request Access / Provision:</span>
                <textarea
                  rows={2}
                  value={tool.howToRequestAccess}
                  onChange={(e) => handleUpdateTool(tool.id, 'howToRequestAccess', e.target.value)}
                  className="w-full bg-white text-slate-900 p-2 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-700">
              <div>
                <span className="font-bold text-slate-700">Security Role / Profile Required:</span>
                <input
                  type="text"
                  value={tool.roleProfileRequired}
                  onChange={(e) => handleUpdateTool(tool.id, 'roleProfileRequired', e.target.value)}
                  className="w-full bg-white text-blue-700 font-mono font-bold px-2 py-1.5 rounded border border-slate-300 mt-1 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <span className="font-bold text-slate-700">System Admin / Support Contact:</span>
                <input
                  type="text"
                  value={tool.adminContact}
                  onChange={(e) => handleUpdateTool(tool.id, 'adminContact', e.target.value)}
                  className="w-full bg-white text-slate-900 px-2 py-1.5 rounded border border-slate-300 mt-1 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Key Reports & Extraction Process */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block">
                Key Reports & System Extraction Menu Paths:
              </span>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                      <th className="py-2 px-2 font-bold">Report Name</th>
                      <th className="py-2 px-2 font-bold">System Menu Path / T-Code</th>
                      <th className="py-2 px-2 font-bold">Cadence</th>
                      <th className="py-2 px-2 font-bold">Purpose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {tool.keyReportsExtracted.map((rpt, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-2 font-semibold text-slate-900">{rpt.reportName}</td>
                        <td className="py-2 px-2 font-mono text-blue-700 font-bold">{rpt.menuPath}</td>
                        <td className="py-2 px-2 text-slate-700">{rpt.frequency}</td>
                        <td className="py-2 px-2 text-slate-500">{rpt.purpose}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
