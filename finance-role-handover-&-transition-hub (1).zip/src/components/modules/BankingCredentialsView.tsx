import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { BankingCredentialItem } from '../../types/handover';
import {
  Landmark,
  KeyRound,
  ShieldCheck,
  PhoneCall,
  Lock,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  ExternalLink,
  Smartphone,
  AlertTriangle,
  FileText,
  UserX,
  UserCheck,
} from 'lucide-react';

export const BankingCredentialsView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [bankingItems, setBankingItems] = useState<BankingCredentialItem[]>(data.bankingCredentials);
  const [isSaved, setIsSaved] = useState(false);
  const [activeBankId, setActiveBankId] = useState<string>(data.bankingCredentials[0]?.id || '');

  const handleSave = () => {
    updateSection('bankingCredentials', bankingItems);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddBank = () => {
    const newBank: BankingCredentialItem = {
      id: `bank-${Date.now()}`,
      bankName: 'New Commercial Bank Partner',
      accountNumberMasked: '•••• •••• 0000',
      accountType: 'Operating Account',
      currency: 'USD ($)',
      portalUrl: 'https://bankportal.com',
      corporateId: 'CORP_NEW_ID',
      signatoryTier: 'Tier 2 (Dual >$25k)',
      dualAuthLimit: '$25,000 USD (Dual approval required)',
      tokenType: 'Hardware RSA Token',
      tokenCustodyProcedure: 'Physical token handover required with safe combination.',
      accessDeactivationProcess: 'Submit IT & Banking helpdesk ticket on LWD at 18:00 EST.',
      newHireProvisioningSteps: 'Submit Bank Mandate Form with Board Resolution signed by CFO.',
      relationshipManager: {
        name: 'Bank Relationship Manager',
        phone: '+1 (555) 000-0000',
        email: 'rm@bank.com',
      },
      escalationHotline: '1-800-000-0000 (Commercial Desk)',
    };
    setBankingItems((prev) => [...prev, newBank]);
    setActiveBankId(newBank.id);
  };

  const handleRemoveBank = (id: string) => {
    setBankingItems((prev) => prev.filter((b) => b.id !== id));
    if (activeBankId === id && bankingItems.length > 1) {
      const remaining = bankingItems.filter((b) => b.id !== id);
      setActiveBankId(remaining[0].id);
    }
  };

  const handleUpdateActiveBank = (field: keyof BankingCredentialItem, value: any) => {
    setBankingItems((prev) =>
      prev.map((b) => (b.id === activeBankId ? { ...b, [field]: value } : b))
    );
  };

  const handleUpdateRM = (field: 'name' | 'phone' | 'email', value: string) => {
    setBankingItems((prev) =>
      prev.map((b) =>
        b.id === activeBankId
          ? { ...b, relationshipManager: { ...b.relationshipManager, [field]: value } }
          : b
      )
    );
  };

  const activeBank = bankingItems.find((b) => b.id === activeBankId) || bankingItems[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Specialized Finance Toolkit</span>
            <span>•</span>
            <span>Treasury & Banking Governance</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Banking Access Protocols, Signatory Matrix & Token Custody
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Safely document portal corporate IDs, authorization limits, hardware token transitions, and relationship manager contacts (never store raw passwords).
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddBank}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1.5" />
            Add Bank Account
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Protocols
          </button>
        </div>
      </div>

      {/* Security Warning Notice Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start space-x-3 text-xs text-blue-900">
        <Lock className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-blue-950">Banking Credential Security Standard</div>
          <p className="text-blue-800/90 leading-relaxed">
            In compliance with SOX and Treasury Information Security Standards, this repository documents <strong>how to obtain access</strong>, corporate IDs, signatory tiers, and physical token custody procedures. <em>Raw user passwords must never be written in handover documentation</em>; incoming personnel must be provisioned with personalized credentials via corporate bank mandates.
          </p>
        </div>
      </div>

      {/* Main Bank Selection & Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Bank List Selector */}
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">
            Corporate Bank Accounts ({bankingItems.length})
          </div>
          <div className="space-y-2">
            {bankingItems.map((bank) => {
              const isSelected = activeBank?.id === bank.id;
              return (
                <div
                  key={bank.id}
                  onClick={() => setActiveBankId(bank.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 text-slate-900 shadow-sm ring-1 ring-blue-500/20'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Landmark className={`h-4 w-4 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span className="font-bold text-xs text-slate-900">{bank.bankName}</span>
                    </div>
                    <span className="text-[10px] font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-600 border border-slate-200">
                      {bank.accountNumberMasked}
                    </span>
                  </div>
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500">
                    <span>{bank.accountType}</span>
                    <span className="font-semibold text-blue-700">{bank.currency}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Active Bank Detail Card (2 Columns) */}
        {activeBank && (
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
            {/* Header of Active Bank */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-lg font-bold text-slate-900">{activeBank.bankName}</h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-md font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                    {activeBank.accountType}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Masked Account: <code className="text-slate-700 font-mono bg-slate-100 px-1.5 py-0.5 rounded">{activeBank.accountNumberMasked}</code> • Currency: <strong className="text-slate-800">{activeBank.currency}</strong>
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <a
                  href={activeBank.portalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-blue-700 border border-slate-200 transition"
                >
                  <ExternalLink className="h-3.5 w-3.5 mr-1" />
                  <span>Portal</span>
                </a>
                <button
                  onClick={() => handleRemoveBank(activeBank.id)}
                  className="text-slate-400 hover:text-rose-600 p-2 transition cursor-pointer"
                  title="Remove Account"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Core Signatory Matrix & Dual Auth Rules */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Signatory Authority Tier
                </label>
                <input
                  type="text"
                  value={activeBank.signatoryTier}
                  onChange={(e) => handleUpdateActiveBank('signatoryTier', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-emerald-800 font-bold px-3 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Dual-Authorization Limits
                </label>
                <input
                  type="text"
                  value={activeBank.dualAuthLimit}
                  onChange={(e) => handleUpdateActiveBank('dualAuthLimit', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-amber-800 font-semibold px-3 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Corporate Portal ID / Organization Code
                </label>
                <input
                  type="text"
                  value={activeBank.corporateId}
                  onChange={(e) => handleUpdateActiveBank('corporateId', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm font-mono text-slate-900 px-3 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Authentication & Token Device Type
                </label>
                <input
                  type="text"
                  value={activeBank.tokenType}
                  onChange={(e) => handleUpdateActiveBank('tokenType', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-blue-800 font-semibold px-3 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>
            </div>

            {/* Token Custody & Handover Protocols */}
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 flex items-center">
                  <Smartphone className="h-3.5 w-3.5 mr-1.5 text-blue-600" />
                  Hardware Token / Mobile Authenticator Custody Transfer SOP
                </label>
                <textarea
                  rows={2}
                  value={activeBank.tokenCustodyProcedure}
                  onChange={(e) => handleUpdateActiveBank('tokenCustodyProcedure', e.target.value)}
                  className="w-full bg-slate-50 text-xs text-slate-800 p-2.5 rounded-lg border border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-rose-800 flex items-center">
                    <UserX className="h-3.5 w-3.5 mr-1.5 text-rose-600" />
                    Outgoing User Deactivation Process (LWD)
                  </label>
                  <textarea
                    rows={3}
                    value={activeBank.accessDeactivationProcess}
                    onChange={(e) => handleUpdateActiveBank('accessDeactivationProcess', e.target.value)}
                    className="w-full bg-rose-50/50 text-xs text-rose-900 p-2.5 rounded-lg border border-rose-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 leading-relaxed"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-emerald-800 flex items-center">
                    <UserCheck className="h-3.5 w-3.5 mr-1.5 text-emerald-600" />
                    New Hire Banking Provisioning & Mandate Form Steps
                  </label>
                  <textarea
                    rows={3}
                    value={activeBank.newHireProvisioningSteps}
                    onChange={(e) => handleUpdateActiveBank('newHireProvisioningSteps', e.target.value)}
                    className="w-full bg-emerald-50/50 text-xs text-emerald-900 p-2.5 rounded-lg border border-emerald-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 leading-relaxed"
                  />
                </div>
              </div>
            </div>

            {/* Relationship Manager & 24/7 Escalation Hotline */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-800">
                <PhoneCall className="h-4 w-4 text-blue-600" />
                <span>Commercial Bank Contacts & Treasury Emergency Hotline</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 text-[11px] block">Relationship Manager:</span>
                  <input
                    type="text"
                    value={activeBank.relationshipManager.name}
                    onChange={(e) => handleUpdateRM('name', e.target.value)}
                    className="w-full bg-white text-slate-900 font-medium px-2.5 py-1.5 rounded border border-slate-300 mt-1 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">RM Direct Phone:</span>
                  <input
                    type="text"
                    value={activeBank.relationshipManager.phone}
                    onChange={(e) => handleUpdateRM('phone', e.target.value)}
                    className="w-full bg-white text-blue-700 font-medium px-2.5 py-1.5 rounded border border-slate-300 mt-1 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">RM Email:</span>
                  <input
                    type="text"
                    value={activeBank.relationshipManager.email}
                    onChange={(e) => handleUpdateRM('email', e.target.value)}
                    className="w-full bg-white text-slate-800 px-2.5 py-1.5 rounded border border-slate-300 mt-1 focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              <div className="text-xs pt-2 border-t border-slate-200 flex items-center justify-between">
                <span className="text-slate-500">24/7 Corporate Wire Recall & Fraud Hotline:</span>
                <input
                  type="text"
                  value={activeBank.escalationHotline}
                  onChange={(e) => handleUpdateActiveBank('escalationHotline', e.target.value)}
                  className="bg-white text-rose-700 font-bold px-2 py-1 rounded border border-rose-300 text-xs w-64 text-right"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
