import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { StatutoryTaxDeadline } from '../../types/handover';
import {
  CalendarDays,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ShieldAlert,
  Lock,
  Clock,
  FileCheck,
  Building,
} from 'lucide-react';

export const TaxComplianceView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [taxDeadlines, setTaxDeadlines] = useState<StatutoryTaxDeadline[]>(data.taxDeadlines);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('taxDeadlines', taxDeadlines);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddTax = () => {
    const newTax: StatutoryTaxDeadline = {
      id: `tax-${Date.now()}`,
      taxName: 'New Statutory Compliance Filing',
      category: 'GST / Indirect Tax',
      dueDayRule: '15th of following month',
      nextDueDate: '2026-09-15',
      filingPortal: 'https://taxportal.gov',
      portalLoginMethod: 'DSC Digital Signature Token of Director',
      penaltyRisk: 'Statutory late fee + 1.5% compounding interest per month.',
      stepSummary: [
        'Extract ledger and verify deductions.',
        'Create payment challan on tax portal.',
        'Execute payment and sign return with Director DSC.',
      ],
      responsibleRole: 'Finance Lead',
      approverRole: 'Chief Financial Officer',
      status: 'Pending Current Period',
    };
    setTaxDeadlines((prev) => [newTax, ...prev]);
  };

  const handleRemoveTax = (id: string) => {
    setTaxDeadlines((prev) => prev.filter((t) => t.id !== id));
  };

  const handleUpdateTax = (id: string, field: keyof StatutoryTaxDeadline, value: any) => {
    setTaxDeadlines((prev) =>
      prev.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    );
  };

  const filteredTaxes = taxDeadlines.filter((t) => {
    if (selectedCategory === 'all') return true;
    return t.category === selectedCategory;
  });

  const categories = [
    'all',
    'GST / Indirect Tax',
    'TDS / Withholding',
    'Advance Tax',
    'Payroll Statutory (PF/ESI/PT)',
    'Corporate Income Tax',
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Specialized Finance Toolkit</span>
            <span>•</span>
            <span>Statutory & Tax Governance</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Recurring Statutory & Tax Filing Compliance Calendar
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Manage mandatory filing cutoff calendars, portal authentication methods (DSC tokens), challan generation steps, and penalty exposure matrices.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddTax}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Tax Obligation
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Deadlines
          </button>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex flex-wrap gap-2 items-center">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              selectedCategory === cat
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-slate-200'
            }`}
          >
            {cat === 'all' ? 'All Tax Obligations' : cat}
          </button>
        ))}
      </div>

      {/* Tax Cards Grid */}
      <div className="space-y-4">
        {filteredTaxes.map((tax) => (
          <div
            key={tax.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-blue-300 transition"
          >
            {/* Header & Status */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5 flex-1">
                <span className="px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
                  {tax.category}
                </span>
                <input
                  type="text"
                  value={tax.taxName}
                  onChange={(e) => handleUpdateTax(tax.id, 'taxName', e.target.value)}
                  className="bg-transparent font-bold text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded px-1 w-full sm:w-auto"
                />
              </div>

              <div className="flex items-center space-x-3">
                <select
                  value={tax.status}
                  onChange={(e) => handleUpdateTax(tax.id, 'status', e.target.value)}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-md border focus:outline-none ${
                    tax.status === 'Compliant'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : tax.status === 'Action Required'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-amber-50 text-amber-700 border-amber-200'
                  }`}
                >
                  <option value="Compliant">Compliant</option>
                  <option value="Pending Current Period">Pending Current Period</option>
                  <option value="Action Required">Action Required (Urgent)</option>
                </select>

                <button
                  onClick={() => handleRemoveTax(tax.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Statutory Timing, Due Rule & Portal Login */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Recurring Statutory Rule
                </span>
                <input
                  type="text"
                  value={tax.dueDayRule}
                  onChange={(e) => handleUpdateTax(tax.id, 'dueDayRule', e.target.value)}
                  className="w-full bg-white text-slate-900 font-bold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Next Due Date
                </span>
                <input
                  type="date"
                  value={tax.nextDueDate}
                  onChange={(e) => handleUpdateTax(tax.id, 'nextDueDate', e.target.value)}
                  className="w-full bg-white text-blue-700 font-bold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Filing Portal URL
                </span>
                <input
                  type="text"
                  value={tax.filingPortal}
                  onChange={(e) => handleUpdateTax(tax.id, 'filingPortal', e.target.value)}
                  className="w-full bg-white text-blue-700 font-mono px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Portal Authentication & Penalty Consequences */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-800 font-bold flex items-center">
                  <Lock className="h-3.5 w-3.5 mr-1 text-blue-600" />
                  Portal Login & Signing Method (DSC / Credentials)
                </span>
                <textarea
                  rows={2}
                  value={tax.portalLoginMethod}
                  onChange={(e) => handleUpdateTax(tax.id, 'portalLoginMethod', e.target.value)}
                  className="w-full bg-white text-slate-800 p-2.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 leading-relaxed"
                />
              </div>

              <div className="bg-rose-50/50 border border-rose-200 p-3 rounded-xl space-y-1">
                <span className="text-rose-900 font-bold flex items-center">
                  <ShieldAlert className="h-3.5 w-3.5 mr-1 text-rose-600" />
                  Statutory Penalty & Non-Compliance Risk
                </span>
                <textarea
                  rows={2}
                  value={tax.penaltyRisk}
                  onChange={(e) => handleUpdateTax(tax.id, 'penaltyRisk', e.target.value)}
                  className="w-full bg-white text-rose-900 p-2.5 rounded border border-rose-200 focus:outline-none focus:ring-2 focus:ring-rose-500/20 leading-relaxed"
                />
              </div>
            </div>

            {/* Execution Steps */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
                Standard Preparation & Challan Verification Workflow:
              </span>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5 text-xs text-slate-800">
                {tax.stepSummary.map((step, i) => (
                  <div key={i} className="flex items-start space-x-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Governance Signatures */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
              <div>Preparer: <strong className="text-slate-800">{tax.responsibleRole}</strong></div>
              <div>Sign-off Authority: <strong className="text-emerald-700">{tax.approverRole}</strong></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
