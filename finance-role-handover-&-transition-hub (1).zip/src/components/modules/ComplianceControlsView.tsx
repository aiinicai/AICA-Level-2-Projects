import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { ComplianceControl } from '../../types/handover';
import {
  ShieldAlert,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Lock,
  Building2,
  Scale,
} from 'lucide-react';

export const ComplianceControlsView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [controls, setControls] = useState<ComplianceControl[]>(data.complianceControls);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('complianceControls', controls);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddControl = () => {
    const newCtrl: ComplianceControl = {
      id: `ctrl-${Date.now()}`,
      controlTitle: 'Dual Authorization for Wire Transfers > $25k',
      framework: 'Banking & Treasury Control',
      description: 'All outbound wire disbursements above $25,000 USD require secondary token authorization by CFO or Treasurer.',
      approvalMatrixRule: 'Initiator: Senior Finance Specialist -> Approver: CFO / Corporate Treasurer',
      auditEvidenceLocation: 'Treasury Sharepoint > 04_Bank_Authorizations > 2026_Approvals',
      penaltiesOrConsequences: 'Bank rejects payment; potential audit exception under IFC Rule 14.',
    };
    setControls((prev) => [newCtrl, ...prev]);
  };

  const handleRemoveControl = (id: string) => {
    setControls((prev) => prev.filter((c) => c.id !== id));
  };

  const handleUpdateControl = (id: string, field: keyof ComplianceControl, value: any) => {
    setControls((prev) =>
      prev.map((c) => (c.id === id ? { ...c, [field]: value } : c))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 9</span>
            <span>•</span>
            <span>Internal Controls & Audit Governance</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Compliance, Internal Controls & Approval Matrix (DoA)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Internal Financial Controls (IFC), Delegation of Authority thresholds, statutory PBC repositories, and compliance audit trail evidence.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddControl}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Control Policy
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Controls
          </button>
        </div>
      </div>

      {/* Controls List */}
      <div className="space-y-4">
        {controls.map((ctrl) => (
          <div
            key={ctrl.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5 flex-1">
                <Lock className="h-4 w-4 text-blue-600 shrink-0" />
                <input
                  type="text"
                  value={ctrl.controlTitle}
                  onChange={(e) => handleUpdateControl(ctrl.id, 'controlTitle', e.target.value)}
                  className="bg-transparent font-bold text-sm sm:text-base text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1 flex-1"
                />
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={ctrl.framework}
                  onChange={(e) => handleUpdateControl(ctrl.id, 'framework', e.target.value)}
                  className="text-xs font-semibold px-2.5 py-1 rounded-md border border-slate-300 bg-white text-blue-700 focus:outline-none"
                >
                  <option value="Internal Financial Controls (IFC)">Internal Financial Controls (IFC)</option>
                  <option value="Delegation of Authority (DoA)">Delegation of Authority (DoA)</option>
                  <option value="Banking & Treasury Control">Banking & Treasury Control</option>
                  <option value="Statutory Audit">Statutory Audit</option>
                  <option value="Tax Audit">Tax Audit</option>
                </select>

                <button
                  onClick={() => handleRemoveControl(ctrl.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <span className="text-slate-500 font-semibold block mb-1">Control Description & Objective:</span>
                <textarea
                  rows={2}
                  value={ctrl.description}
                  onChange={(e) => handleUpdateControl(ctrl.id, 'description', e.target.value)}
                  className="w-full bg-white text-slate-700 p-2.5 rounded-md border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                  <span className="font-bold text-slate-700">Approval Matrix / Threshold Rule:</span>
                  <input
                    type="text"
                    value={ctrl.approvalMatrixRule}
                    onChange={(e) => handleUpdateControl(ctrl.id, 'approvalMatrixRule', e.target.value)}
                    className="w-full bg-white text-slate-900 font-medium px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                  <span className="font-bold text-blue-700">Audit Evidence / PBC Repository:</span>
                  <input
                    type="text"
                    value={ctrl.auditEvidenceLocation}
                    onChange={(e) => handleUpdateControl(ctrl.id, 'auditEvidenceLocation', e.target.value)}
                    className="w-full bg-white font-mono text-blue-700 font-semibold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 text-[11px]"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
