import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { EmployeeDetails } from '../../types/handover';
import {
  UserCheck,
  Building2,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Save,
  CheckCircle2,
  AlertCircle,
  FileCheck,
} from 'lucide-react';

export const EmployeeDetailsView: React.FC = () => {
  const { data, updateSection, setIsSignOffModalOpen } = useHandover();
  const [formData, setFormData] = useState<EmployeeDetails>(data.employeeDetails);
  const [isSaved, setIsSaved] = useState(false);

  const handleChange = (field: keyof EmployeeDetails, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setIsSaved(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSection('employeeDetails', formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 1</span>
            <span>•</span>
            <span>Governance & Personnel</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Employee Transition & Details
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Document key personnel metadata, official timeline, entity coverage, and transition authorities.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Changes saved
            </span>
          )}
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Details
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Outgoing & Successor Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Outgoing Employee Information */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-3">
              <div className="h-8 w-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-200">
                <UserCheck className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Outgoing Employee (Incumbent)</h3>
                <p className="text-xs text-slate-500">Current role holder transferring operational knowledge</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name & Credentials</label>
                <input
                  type="text"
                  value={formData.outgoingName}
                  onChange={(e) => handleChange('outgoingName', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  placeholder="e.g. Priya Sharma, CA"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Exact Role Title</label>
                <input
                  type="text"
                  value={formData.outgoingRole}
                  onChange={(e) => handleChange('outgoingRole', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  placeholder="e.g. Senior Finance & Accounts Lead"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Corporate Email</label>
                  <input
                    type="email"
                    value={formData.outgoingEmail}
                    onChange={(e) => handleChange('outgoingEmail', e.target.value)}
                    className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    placeholder="email@company.com"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={formData.outgoingPhone}
                    onChange={(e) => handleChange('outgoingPhone', e.target.value)}
                    className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    placeholder="+1 (555) 000-0000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-800 mb-1">Last Working Day (LWD)</label>
                <input
                  type="date"
                  value={formData.lastWorkingDay}
                  onChange={(e) => handleChange('lastWorkingDay', e.target.value)}
                  className="w-full bg-amber-50/50 text-xs sm:text-sm text-amber-900 font-bold px-3 py-2 rounded-md border border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>
            </div>
          </div>

          {/* Incoming Successor Information */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-3">
              <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
                <UserCheck className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Incoming Successor (New Joiner)</h3>
                <p className="text-xs text-slate-500">Designated replacement assuming responsibility</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Successor Full Name & Title</label>
                <input
                  type="text"
                  value={formData.successorName}
                  onChange={(e) => handleChange('successorName', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  placeholder="e.g. Rohan Mehta, CPA"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Designated Role Title</label>
                <input
                  type="text"
                  value={formData.successorRole}
                  onChange={(e) => handleChange('successorRole', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  placeholder="e.g. Incoming Finance & Accounts Lead"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Corporate / Onboarding Email</label>
                <input
                  type="email"
                  value={formData.successorEmail}
                  onChange={(e) => handleChange('successorEmail', e.target.value)}
                  className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  placeholder="rohan.mehta@enterprise.com"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Handover Start Date</label>
                  <input
                    type="date"
                    value={formData.handoverStartDate}
                    onChange={(e) => handleChange('handoverStartDate', e.target.value)}
                    className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Target End Date</label>
                  <input
                    type="date"
                    value={formData.handoverEndDate}
                    onChange={(e) => handleChange('handoverEndDate', e.target.value)}
                    className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Reporting Manager & Organizational Context */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-3">
            <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
              <Building2 className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Management & Corporate Scope</h3>
              <p className="text-xs text-slate-500">Supervisory reporting hierarchy and covered legal entities</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Reporting Manager</label>
              <input
                type="text"
                value={formData.reportingManager}
                onChange={(e) => handleChange('reportingManager', e.target.value)}
                className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                placeholder="e.g. Alexander Wright (CFO)"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Manager Email</label>
              <input
                type="email"
                value={formData.managerEmail}
                onChange={(e) => handleChange('managerEmail', e.target.value)}
                className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                placeholder="manager@enterprise.com"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Department</label>
              <input
                type="text"
                value={formData.department}
                onChange={(e) => handleChange('department', e.target.value)}
                className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                placeholder="e.g. Finance, Treasury & Taxation"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Primary Operating Entity</label>
              <input
                type="text"
                value={formData.entityName}
                onChange={(e) => handleChange('entityName', e.target.value)}
                className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                placeholder="e.g. Apex Enterprise Solutions Global Inc."
              />
            </div>
          </div>
        </div>

        {/* Sign-off Status Callout */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div
              className={`h-10 w-10 rounded-xl flex items-center justify-center border ${
                formData.isSignedOff
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : 'bg-blue-50 text-blue-700 border border-blue-200'
              }`}
            >
              <FileCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">
                {formData.isSignedOff
                  ? `Certified Handover Completion (${formData.signOffDate})`
                  : 'Formal Tripartite Sign-off Status'}
              </div>
              <p className="text-xs text-slate-500">
                {formData.isSignedOff
                  ? 'Signatures verified for Outgoing Lead, Incoming Successor, and Reporting Manager.'
                  : 'Pending final reverse-shadowing sign-off and token handover completion.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsSignOffModalOpen(true)}
            className="w-full sm:w-auto px-4 py-2 rounded-md text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition cursor-pointer"
          >
            {formData.isSignedOff ? 'View Sign-off Certificate' : 'Review Sign-off Agreement'}
          </button>
        </div>
      </form>
    </div>
  );
};
