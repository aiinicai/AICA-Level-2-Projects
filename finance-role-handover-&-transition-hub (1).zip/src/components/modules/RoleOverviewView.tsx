import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { RoleOverview } from '../../types/handover';
import {
  Target,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Users,
  ShieldAlert,
  BarChart3,
  ListChecks,
} from 'lucide-react';

export const RoleOverviewView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [formData, setFormData] = useState<RoleOverview>(data.roleOverview);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('roleOverview', formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddResponsibility = () => {
    setFormData((prev) => ({
      ...prev,
      keyResponsibilities: [...prev.keyResponsibilities, 'New key financial responsibility...'],
    }));
  };

  const handleRemoveResponsibility = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      keyResponsibilities: prev.keyResponsibilities.filter((_, i) => i !== index),
    }));
  };

  const handleUpdateResponsibility = (index: number, text: string) => {
    const updated = [...formData.keyResponsibilities];
    updated[index] = text;
    setFormData((prev) => ({ ...prev, keyResponsibilities: updated }));
  };

  const handleAddKPI = () => {
    setFormData((prev) => ({
      ...prev,
      kpis: [
        ...prev.kpis,
        {
          name: 'New Finance KPI',
          target: '100% On-time',
          frequency: 'Monthly',
          measurementSource: 'ERP & Audit Reports',
        },
      ],
    }));
  };

  const handleRemoveKPI = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      kpis: prev.kpis.filter((_, i) => i !== index),
    }));
  };

  const handleUpdateKPI = (index: number, field: string, value: string) => {
    const updated = [...formData.kpis];
    updated[index] = { ...updated[index], [field]: value };
    setFormData((prev) => ({ ...prev, kpis: updated }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 2</span>
            <span>•</span>
            <span>Charter & Objectives</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Role Overview, Deliverables & KPIs
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Define clear functional job scope, measurable success criteria, and reporting escalation hierarchies.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved successfully
            </span>
          )}
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Primary Objective Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center space-x-2 text-sm font-bold text-slate-900">
          <Target className="h-4 w-4 text-blue-600" />
          <span>Core Role Objective & Mission</span>
        </div>
        <textarea
          rows={3}
          value={formData.primaryObjective}
          onChange={(e) => setFormData((prev) => ({ ...prev, primaryObjective: e.target.value }))}
          className="w-full bg-white text-xs sm:text-sm text-slate-900 p-3 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 leading-relaxed"
          placeholder="State the core financial mission and deliverable expectations..."
        />
      </div>

      {/* Key Responsibilities */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900">
            <ListChecks className="h-4 w-4 text-blue-600" />
            <span>Key Responsibilities & Deliverables</span>
          </div>
          <button
            onClick={handleAddResponsibility}
            className="inline-flex items-center px-2.5 py-1.5 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Responsibility
          </button>
        </div>

        <div className="space-y-2.5">
          {formData.keyResponsibilities.map((resp, idx) => (
            <div key={idx} className="flex items-start space-x-2 group">
              <span className="flex items-center justify-center h-6 w-6 rounded bg-slate-100 text-slate-600 text-xs font-semibold shrink-0 mt-1">
                {idx + 1}
              </span>
              <input
                type="text"
                value={resp}
                onChange={(e) => handleUpdateResponsibility(idx, e.target.value)}
                className="flex-1 bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
              <button
                onClick={() => handleRemoveResponsibility(idx)}
                className="text-slate-400 hover:text-rose-600 p-2 opacity-0 group-hover:opacity-100 transition shrink-0 cursor-pointer"
                title="Remove"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* KPIs & Performance Metrics */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900">
            <BarChart3 className="h-4 w-4 text-blue-600" />
            <span>KPIs & Performance Metrics</span>
          </div>
          <button
            onClick={handleAddKPI}
            className="inline-flex items-center px-2.5 py-1.5 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add KPI Metric
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                <th className="py-2.5 px-3 font-bold">KPI Name</th>
                <th className="py-2.5 px-3 font-bold">Target / SLA</th>
                <th className="py-2.5 px-3 font-bold">Frequency</th>
                <th className="py-2.5 px-3 font-bold">Measurement Source</th>
                <th className="py-2.5 px-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {formData.kpis.map((kpi, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={kpi.name}
                      onChange={(e) => handleUpdateKPI(idx, 'name', e.target.value)}
                      className="w-full bg-white text-slate-900 font-medium px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={kpi.target}
                      onChange={(e) => handleUpdateKPI(idx, 'target', e.target.value)}
                      className="w-full bg-white text-blue-700 font-semibold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={kpi.frequency}
                      onChange={(e) => handleUpdateKPI(idx, 'frequency', e.target.value)}
                      className="w-full bg-white text-slate-700 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={kpi.measurementSource}
                      onChange={(e) => handleUpdateKPI(idx, 'measurementSource', e.target.value)}
                      className="w-full bg-white text-slate-700 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-2 text-right">
                    <button
                      onClick={() => handleRemoveKPI(idx)}
                      className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reporting Structure & Escalation Hierarchy */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
          <Users className="h-4 w-4 text-blue-600" />
          <span>Reporting Structure & Escalation Matrix</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Direct Reporting To</label>
            <input
              type="text"
              value={formData.reportingStructure.reportsTo}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  reportingStructure: { ...prev.reportingStructure, reportsTo: e.target.value },
                }))
              }
              className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-rose-800 mb-1">Emergency Escalation Contact</label>
            <input
              type="text"
              value={formData.reportingStructure.escalationContact}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  reportingStructure: { ...prev.reportingStructure, escalationContact: e.target.value },
                }))
              }
              className="w-full bg-white text-xs sm:text-sm text-rose-800 font-semibold px-3 py-2 rounded-md border border-rose-300 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Direct Reports (Comma separated)</label>
            <input
              type="text"
              value={formData.reportingStructure.directReports.join(', ')}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  reportingStructure: {
                    ...prev.reportingStructure,
                    directReports: e.target.value.split(',').map((s) => s.trim()),
                  },
                }))
              }
              className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Cross-Functional Peers (Comma separated)</label>
            <input
              type="text"
              value={formData.reportingStructure.peerRoles.join(', ')}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  reportingStructure: {
                    ...prev.reportingStructure,
                    peerRoles: e.target.value.split(',').map((s) => s.trim()),
                  },
                }))
              }
              className="w-full bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
