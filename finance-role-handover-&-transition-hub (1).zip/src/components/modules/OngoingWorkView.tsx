import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { OngoingTask } from '../../types/handover';
import {
  Clock,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Calendar,
  Filter,
} from 'lucide-react';

export const OngoingWorkView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [tasks, setTasks] = useState<OngoingTask[]>(data.ongoingTasks);
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('ongoingTasks', tasks);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddTask = () => {
    const newTask: OngoingTask = {
      id: `task-${Date.now()}`,
      taskTitle: 'New Operational Finance Milestone',
      projectOrCategory: 'Month-End Close & Controls',
      status: 'In Progress',
      priority: 'High',
      deadline: '2026-03-31',
      dependencies: 'Awaiting source system GL dump & approvals',
      pendingWith: 'Incoming Successor / Team',
      handoverNotes: 'Follow standard SOP, review past month reconciliation file.',
      actionRequiredBySuccessor: 'Review open exceptions and execute final sign-off.',
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleRemoveTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const handleUpdateTask = (id: string, field: keyof OngoingTask, value: any) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    );
  };

  const filteredTasks = tasks.filter((t) => {
    if (statusFilter === 'All') return true;
    return t.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 7</span>
            <span>•</span>
            <span>WIP & Pipeline Management</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Ongoing Work, Open In-Flight Tasks & Status
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Active finance projects, open audit deliverables, vendor disputes in progress, and upcoming cutoffs requiring immediate successor pickup.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddTask}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Ongoing Task
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Tasks
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <Filter className="h-3.5 w-3.5 text-slate-500 mr-1" />
        {['All', 'In Progress', 'Under Review', 'Not Started', 'Completed'].map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              statusFilter === st
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {st} ({st === 'All' ? tasks.length : tasks.filter((t) => t.status === st).length})
          </button>
        ))}
      </div>

      {/* Ongoing Tasks Cards */}
      <div className="space-y-4">
        {filteredTasks.map((t) => (
          <div
            key={t.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
          >
            {/* Top row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2 flex-1">
                <input
                  type="text"
                  value={t.taskTitle}
                  onChange={(e) => handleUpdateTask(t.id, 'taskTitle', e.target.value)}
                  className="bg-transparent font-bold text-sm sm:text-base text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1 flex-1"
                />
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={t.priority}
                  onChange={(e) => handleUpdateTask(t.id, 'priority', e.target.value)}
                  className={`text-xs font-bold px-2.5 py-1 rounded-md border focus:outline-none ${
                    t.priority === 'Critical'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : t.priority === 'High'
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  <option value="Critical">Critical Priority</option>
                  <option value="High">High Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="Low">Low Priority</option>
                </select>

                <select
                  value={t.status}
                  onChange={(e) => handleUpdateTask(t.id, 'status', e.target.value)}
                  className="text-xs font-semibold px-2.5 py-1 rounded-md border border-slate-300 bg-white text-blue-700 focus:outline-none"
                >
                  <option value="In Progress">In Progress</option>
                  <option value="Under Review">Under Review</option>
                  <option value="Not Started">Not Started</option>
                  <option value="Blocked">Blocked</option>
                  <option value="Completed">Completed</option>
                </select>

                <button
                  onClick={() => handleRemoveTask(t.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Middle Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-slate-500 font-semibold block mb-1">Target Deadline / Cut-Off:</span>
                <div className="flex items-center space-x-1.5">
                  <Calendar className="h-3.5 w-3.5 text-blue-600" />
                  <input
                    type="date"
                    value={t.deadline}
                    onChange={(e) => handleUpdateTask(t.id, 'deadline', e.target.value)}
                    className="w-full bg-white font-semibold text-slate-900 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-semibold block mb-1">Current Pending With:</span>
                <input
                  type="text"
                  value={t.pendingWith}
                  onChange={(e) => handleUpdateTask(t.id, 'pendingWith', e.target.value)}
                  className="w-full bg-white text-amber-800 font-bold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <span className="text-slate-500 font-semibold block mb-1">Dependencies & Blockers:</span>
                <input
                  type="text"
                  value={t.dependencies}
                  onChange={(e) => handleUpdateTask(t.id, 'dependencies', e.target.value)}
                  className="w-full bg-white text-slate-700 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Handover & Action Required */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700">Outgoing Context & Status Notes:</span>
                <textarea
                  rows={2}
                  value={t.handoverNotes}
                  onChange={(e) => handleUpdateTask(t.id, 'handoverNotes', e.target.value)}
                  className="w-full bg-white text-slate-700 p-2 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
                />
              </div>

              <div className="bg-blue-50/60 p-3 rounded-lg border border-blue-200 space-y-1">
                <span className="font-bold text-blue-900">Immediate Action Required by Successor:</span>
                <textarea
                  rows={2}
                  value={t.actionRequiredBySuccessor}
                  onChange={(e) => handleUpdateTask(t.id, 'actionRequiredBySuccessor', e.target.value)}
                  className="w-full bg-white text-blue-950 p-2 rounded border border-blue-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed font-medium"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
