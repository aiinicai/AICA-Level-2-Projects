import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { KnownRisk } from '../../types/handover';
import {
  AlertTriangle,
  ShieldAlert,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Ban,
  Clock,
  Sparkles,
} from 'lucide-react';

export const RisksChallengesView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [risks, setRisks] = useState<KnownRisk[]>(data.knownRisks);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('knownRisks', risks);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddRisk = () => {
    const newRisk: KnownRisk = {
      id: `risk-${Date.now()}`,
      category: 'Cash Flow & Banking',
      knownIssue: 'Unidentified Stripe Settlement Batch Discrepancy during month-end',
      impactLevel: 'High',
      workaround: 'Run manual export of Stripe settlement breakdown report and cross-match transaction IDs against the ERP clearing account.',
      criticalCutoffTiming: 'Day -1 of Month Close (Cutoff: 5:00 PM EST)',
      whatNotToDo: 'NEVER force balance by booking unallocated clearing differences to general administrative expense without controller sign-off.',
    };
    setRisks((prev) => [newRisk, ...prev]);
  };

  const handleRemoveRisk = (id: string) => {
    setRisks((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateRisk = (id: string, field: keyof KnownRisk, value: any) => {
    setRisks((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-rose-600 uppercase tracking-wider">
            <span>Section 8</span>
            <span>•</span>
            <span>Vulnerabilities & Fail-Safes</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Key Risks, Known Challenges & "What NOT to Do"
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Institutional pitfalls, system bugs, critical timing bottlenecks, safe workarounds, and strict operational red-lines.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddRisk}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Risk Scenario
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Risks
          </button>
        </div>
      </div>

      {/* Risks List */}
      <div className="space-y-4">
        {risks.map((r) => (
          <div
            key={r.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
          >
            {/* Top row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5 flex-1">
                <AlertTriangle
                  className={`h-5 w-5 shrink-0 ${
                    r.impactLevel === 'Critical'
                      ? 'text-rose-600'
                      : r.impactLevel === 'High'
                      ? 'text-amber-600'
                      : 'text-blue-600'
                  }`}
                />
                <input
                  type="text"
                  value={r.knownIssue}
                  onChange={(e) => handleUpdateRisk(r.id, 'knownIssue', e.target.value)}
                  className="bg-transparent font-bold text-sm sm:text-base text-slate-900 focus:outline-none focus:ring-1 focus:ring-rose-500 rounded px-1 flex-1"
                />
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={r.category}
                  onChange={(e) => handleUpdateRisk(r.id, 'category', e.target.value)}
                  className="text-xs font-medium px-2 py-1 rounded-md border border-slate-300 bg-white text-slate-700 focus:outline-none"
                >
                  <option value="Cash Flow & Banking">Cash Flow & Banking</option>
                  <option value="Reconciliation & Books">Reconciliation & Books</option>
                  <option value="Statutory & Deadlines">Statutory & Deadlines</option>
                  <option value="Vendor / Customer Dispute">Vendor / Customer Dispute</option>
                  <option value="System & Data Gaps">System & Data Gaps</option>
                </select>

                <select
                  value={r.impactLevel}
                  onChange={(e) => handleUpdateRisk(r.id, 'impactLevel', e.target.value)}
                  className={`text-xs font-bold px-2.5 py-1 rounded-md border focus:outline-none ${
                    r.impactLevel === 'Critical'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : r.impactLevel === 'High'
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-blue-50 text-blue-700 border-blue-200'
                  }`}
                >
                  <option value="Critical">Critical Impact</option>
                  <option value="High">High Impact</option>
                  <option value="Medium">Medium Impact</option>
                </select>

                <button
                  onClick={() => handleRemoveRisk(r.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Critical Cutoff & Safe Workaround */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-amber-800 flex items-center">
                  <Clock className="h-3.5 w-3.5 mr-1 text-amber-600" />
                  Critical Cutoff Timing / Trigger:
                </span>
                <input
                  type="text"
                  value={r.criticalCutoffTiming}
                  onChange={(e) => handleUpdateRisk(r.id, 'criticalCutoffTiming', e.target.value)}
                  className="w-full bg-white text-slate-900 font-semibold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 flex items-center">
                  <ShieldAlert className="h-3.5 w-3.5 mr-1 text-blue-600" />
                  Safe Operational Workaround:
                </span>
                <textarea
                  rows={2}
                  value={r.workaround}
                  onChange={(e) => handleUpdateRisk(r.id, 'workaround', e.target.value)}
                  className="w-full bg-white text-slate-700 p-2 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
                />
              </div>
            </div>

            {/* What NOT to Do Warning Box */}
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-start space-x-2.5 text-xs">
              <Ban className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 space-y-1">
                <span className="font-bold text-rose-800 uppercase tracking-wider text-[11px] block">
                  Strict "What NOT To Do" Red-Line:
                </span>
                <textarea
                  rows={2}
                  value={r.whatNotToDo}
                  onChange={(e) => handleUpdateRisk(r.id, 'whatNotToDo', e.target.value)}
                  className="w-full bg-white text-rose-900 font-medium p-2 rounded border border-rose-300 focus:outline-none focus:ring-1 focus:ring-rose-500 leading-relaxed"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
