import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { ProcessTask, SOPItem, TaskFrequency, HandoverStatus } from '../../types/handover';
import {
  FileText,
  Clock,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Ban,
  Layers,
  FolderOpen,
  ExternalLink,
} from 'lucide-react';

export const ProcessDocumentationView: React.FC = () => {
  const { data, updateSection, setIsAiModalOpen } = useHandover();
  const [tasks, setTasks] = useState<ProcessTask[]>(data.processTasks);
  const [sops, setSops] = useState<SOPItem[]>(data.sops);
  const [frequencyFilter, setFrequencyFilter] = useState<string>('all');
  const [activeTab, setActiveSubTab] = useState<'tasks' | 'sops'>('tasks');
  const [expandedSopId, setExpandedSopId] = useState<string | null>(data.sops[0]?.id || null);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('processTasks', tasks);
    updateSection('sops', sops);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleTaskStatusChange = (id: string, newStatus: HandoverStatus) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  const handleAddTask = () => {
    const newTask: ProcessTask = {
      id: `pt-${Date.now()}`,
      title: 'New Financial Process / Activity',
      frequency: 'monthly',
      timingDescription: 'e.g., Working Day +3 of month',
      systemsUsed: ['SAP S/4HANA'],
      deliverable: 'Approved Journal Entry / Signed Report',
      dependencies: 'Subledger freeze and bank statement confirmation',
      status: 'in-progress',
      notes: 'Ensure 3-way check before sign-off.',
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleRemoveTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const handleAddSOP = () => {
    const newSOP: SOPItem = {
      id: `sop-${Date.now()}`,
      title: 'New Standard Operating Procedure (SOP)',
      category: 'General Ledger',
      frequency: 'monthly',
      estimatedTime: '1 hour',
      prerequisites: ['System access and valid input data files'],
      stepByStepInstructions: [
        'Step 1: Extract data from primary ERP system.',
        'Step 2: Perform matching and variance analysis.',
        'Step 3: Post adjustment journal and obtain Level 2 manager sign-off.',
      ],
      keyControls: ['Verify mathematical balancing before posting.'],
      commonPitfalls: ['Missing month-end exchange rate updates.'],
      whatNotToDo: ['DO NOT post manual adjustment to control account directly.'],
      outputDeliverable: 'Signed Reconciliation Schedule and ERP Journal Log.',
      relatedSystems: ['SAP S/4HANA', 'Excel'],
    };
    setSops((prev) => [newSOP, ...prev]);
    setExpandedSopId(newSOP.id);
    setActiveSubTab('sops');
  };

  const handleRemoveSOP = (id: string) => {
    setSops((prev) => prev.filter((s) => s.id !== id));
  };

  const filteredTasks = tasks.filter((t) => {
    if (frequencyFilter === 'all') return true;
    return t.frequency === frequencyFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 3</span>
            <span>•</span>
            <span>Standard Operating Procedures</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Process Documentation & SOP Library
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Step-by-step Standard Operating Procedures, recurring cadence schedules, key controls, and practical what-not-to-do guardrails.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5 text-blue-600" />
            <span>AI Draft SOP</span>
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Subtabs: Recurring Frequency Schedule vs SOP Library */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveSubTab('tasks')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition cursor-pointer ${
              activeTab === 'tasks'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Recurring Process Cadence ({tasks.length})
          </button>
          <button
            onClick={() => setActiveSubTab('sops')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition cursor-pointer ${
              activeTab === 'sops'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Step-by-Step SOP Library ({sops.length})
          </button>
        </div>

        {activeTab === 'tasks' ? (
          <div className="flex items-center space-x-2">
            <div className="flex bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs">
              {(['all', 'daily', 'weekly', 'monthly', 'quarterly'] as const).map((freq) => (
                <button
                  key={freq}
                  onClick={() => setFrequencyFilter(freq)}
                  className={`px-2.5 py-1 rounded-md capitalize text-xs font-medium transition cursor-pointer ${
                    frequencyFilter === freq
                      ? 'bg-white text-blue-700 font-bold shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {freq}
                </button>
              ))}
            </div>
            <button
              onClick={handleAddTask}
              className="inline-flex items-center px-2.5 py-1.5 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5 mr-1" />
              Add Task
            </button>
          </div>
        ) : (
          <button
            onClick={handleAddSOP}
            className="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Create New SOP
          </button>
        )}
      </div>

      {/* Tab 1: Recurring Cadence Tasks */}
      {activeTab === 'tasks' && (
        <div className="space-y-3">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-slate-300 transition space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center space-x-2.5">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      task.frequency === 'daily'
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : task.frequency === 'weekly'
                        ? 'bg-purple-50 text-purple-700 border border-purple-200'
                        : task.frequency === 'monthly'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {task.frequency}
                  </span>
                  <input
                    type="text"
                    value={task.title}
                    onChange={(e) => {
                      const updated = tasks.map((t) =>
                        t.id === task.id ? { ...t, title: e.target.value } : t
                      );
                      setTasks(updated);
                    }}
                    className="bg-transparent font-bold text-sm text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1 w-full sm:w-auto"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <select
                    value={task.status}
                    onChange={(e) => handleTaskStatusChange(task.id, e.target.value as HandoverStatus)}
                    className={`text-xs font-semibold px-2.5 py-1 rounded-md border focus:outline-none ${
                      task.status === 'completed'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : task.status === 'reverse-shadowed'
                        ? 'bg-blue-50 text-blue-800 border-blue-300'
                        : task.status === 'shadowing'
                        ? 'bg-purple-50 text-purple-800 border-purple-300'
                        : 'bg-amber-50 text-amber-800 border-amber-300'
                    }`}
                  >
                    <option value="not-started">Not Started</option>
                    <option value="in-progress">In Progress</option>
                    <option value="shadowing">Shadowing Active</option>
                    <option value="reverse-shadowed">Reverse Shadowed</option>
                    <option value="completed">Handover Completed</option>
                  </select>

                  <button
                    onClick={() => handleRemoveTask(task.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 transition cursor-pointer"
                    title="Remove Task"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-500 block text-[11px] mb-0.5">
                    Timing & Cutoff:
                  </span>
                  <input
                    type="text"
                    value={task.timingDescription}
                    onChange={(e) => {
                      const updated = tasks.map((t) =>
                        t.id === task.id ? { ...t, timingDescription: e.target.value } : t
                      );
                      setTasks(updated);
                    }}
                    className="w-full bg-transparent text-slate-900 font-medium focus:outline-none"
                  />
                </div>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-500 block text-[11px] mb-0.5">
                    Output Deliverable:
                  </span>
                  <input
                    type="text"
                    value={task.deliverable}
                    onChange={(e) => {
                      const updated = tasks.map((t) =>
                        t.id === task.id ? { ...t, deliverable: e.target.value } : t
                      );
                      setTasks(updated);
                    }}
                    className="w-full bg-transparent text-emerald-700 font-bold focus:outline-none"
                  />
                </div>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-500 block text-[11px] mb-0.5">
                    Systems Used:
                  </span>
                  <input
                    type="text"
                    value={task.systemsUsed.join(', ')}
                    onChange={(e) => {
                      const updated = tasks.map((t) =>
                        t.id === task.id
                          ? { ...t, systemsUsed: e.target.value.split(',').map((s) => s.trim()) }
                          : t
                      );
                      setTasks(updated);
                    }}
                    className="w-full bg-transparent text-blue-700 font-medium focus:outline-none"
                  />
                </div>
              </div>

              <div className="text-xs text-slate-500 flex items-center space-x-2 pt-1">
                <span className="font-bold text-slate-600">Operational Notes:</span>
                <input
                  type="text"
                  value={task.notes}
                  onChange={(e) => {
                    const updated = tasks.map((t) =>
                      t.id === task.id ? { ...t, notes: e.target.value } : t
                    );
                    setTasks(updated);
                  }}
                  className="w-full bg-transparent text-slate-700 focus:outline-none border-b border-transparent focus:border-slate-300"
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: SOP Library */}
      {activeTab === 'sops' && (
        <div className="space-y-4">
          {sops.map((sop) => {
            const isExpanded = expandedSopId === sop.id;
            return (
              <div
                key={sop.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm transition"
              >
                {/* SOP Accordion Header */}
                <div
                  onClick={() => setExpandedSopId(isExpanded ? null : sop.id)}
                  className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50 transition"
                >
                  <div className="flex items-center space-x-3">
                    <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200 shrink-0">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-bold text-slate-900">{sop.title}</h3>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                          {sop.category}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 flex items-center space-x-3">
                        <span>Cadence: <strong className="text-slate-700 capitalize">{sop.frequency}</strong></span>
                        <span>•</span>
                        <span>Est. Duration: <strong className="text-slate-700">{sop.estimatedTime}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveSOP(sop.id);
                      }}
                      className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                      title="Delete SOP"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                    {isExpanded ? (
                      <ChevronUp className="h-4 w-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {/* SOP Expanded Body */}
                {isExpanded && (
                  <div className="p-5 border-t border-slate-200 bg-slate-50/50 space-y-5">
                    {/* Prerequisites */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center">
                        <Layers className="h-3.5 w-3.5 mr-1.5 text-blue-600" />
                        Prerequisites & System Access Needed
                      </h4>
                      <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5 text-xs text-slate-700">
                        {sop.prerequisites.map((req, i) => (
                          <div key={i} className="flex items-start space-x-2">
                            <span className="text-blue-600 font-bold">•</span>
                            <span>{req}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Step-by-Step Instructions */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center">
                        <FileText className="h-3.5 w-3.5 mr-1.5 text-blue-600" />
                        Step-by-Step Operational Instructions
                      </h4>
                      <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-2.5 text-xs text-slate-700">
                        {sop.stepByStepInstructions.map((step, idx) => (
                          <div key={idx} className="flex items-start space-x-2.5">
                            <span className="flex items-center justify-center h-5 w-5 rounded bg-blue-50 text-blue-700 font-bold text-[11px] shrink-0 mt-0.5 border border-blue-200">
                              {idx + 1}
                            </span>
                            <span className="leading-relaxed">{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 2-Column Controls & What NOT to Do */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Key Controls */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center">
                          <ShieldCheck className="h-3.5 w-3.5 mr-1.5" />
                          Key Internal Controls & Validation
                        </h4>
                        <div className="bg-emerald-50/70 border border-emerald-200 p-3 rounded-lg space-y-1.5 text-xs text-emerald-900">
                          {sop.keyControls.map((ctrl, i) => (
                            <div key={i} className="flex items-start space-x-2">
                              <span className="text-emerald-700 font-bold">✓</span>
                              <span>{ctrl}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* What NOT to Do (Crucial Finance Warning) */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center">
                          <Ban className="h-3.5 w-3.5 mr-1.5" />
                          Critical "What NOT to Do"
                        </h4>
                        <div className="bg-rose-50/70 border border-rose-200 p-3 rounded-lg space-y-1.5 text-xs text-rose-900">
                          {sop.whatNotToDo.map((warn, i) => (
                            <div key={i} className="flex items-start space-x-2">
                              <span className="text-rose-700 font-bold">✗</span>
                              <span>{warn}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Template link & deliverable */}
                    {sop.sampleTemplatePath && (
                      <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                        <div className="flex items-center space-x-2 text-slate-700">
                          <FolderOpen className="h-4 w-4 text-blue-600" />
                          <span>Template Location: <code className="text-blue-700 font-bold">{sop.sampleTemplatePath}</code></span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
