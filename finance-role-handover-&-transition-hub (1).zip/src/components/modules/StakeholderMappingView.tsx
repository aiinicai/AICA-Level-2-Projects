import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { Stakeholder } from '../../types/handover';
import {
  Users2,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Mail,
  Phone,
  Building,
} from 'lucide-react';

export const StakeholderMappingView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [stakeholders, setStakeholders] = useState<Stakeholder[]>(data.stakeholders);
  const [activeType, setActiveType] = useState<'All' | 'Internal' | 'External'>('All');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('stakeholders', stakeholders);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddStakeholder = (type: 'Internal' | 'External') => {
    const newStakeholder: Stakeholder = {
      id: `stk-${Date.now()}`,
      name: type === 'Internal' ? 'New Internal Counterpart' : 'New External Partner / Auditor',
      type,
      role: type === 'Internal' ? 'Department Head' : 'External Audit Partner',
      departmentOrOrg: type === 'Internal' ? 'Executive Leadership' : 'External Advisory LLP',
      relationshipContext: 'Key partner for approvals, reconciliations, and reporting.',
      cadence: 'Monthly',
      email: 'contact@partner.com',
      phone: '+1 (555) 000-0000',
      keyInteractions: 'Monthly review and variance escalations.',
    };
    setStakeholders((prev) => [newStakeholder, ...prev]);
  };

  const handleRemoveStakeholder = (id: string) => {
    setStakeholders((prev) => prev.filter((s) => s.id !== id));
  };

  const handleUpdateStakeholder = (id: string, field: keyof Stakeholder, value: any) => {
    setStakeholders((prev) =>
      prev.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const filtered = stakeholders.filter((s) => {
    if (activeType === 'All') return true;
    return s.type === activeType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 6</span>
            <span>•</span>
            <span>Relationships & Governance</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Stakeholder Mapping (Internal & External)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Key operational counterparts, external statutory auditors, bank relationship managers, tax consultants, and warm introduction status.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={() => handleAddStakeholder('Internal')}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            + Internal Contact
          </button>
          <button
            onClick={() => handleAddStakeholder('External')}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            + External Partner
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Contacts
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-2">
        {(['All', 'Internal', 'External'] as const).map((type) => (
          <button
            key={type}
            onClick={() => setActiveType(type)}
            className={`px-3 py-1.5 rounded-md text-xs font-bold capitalize transition cursor-pointer ${
              activeType === type
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {type} Contacts ({type === 'All' ? stakeholders.length : stakeholders.filter((s) => s.type === type).length})
          </button>
        ))}
      </div>

      {/* Stakeholders Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((stk) => (
          <div
            key={stk.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
          >
            <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    stk.type === 'Internal'
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}
                >
                  {stk.type}
                </span>
                <input
                  type="text"
                  value={stk.name}
                  onChange={(e) => handleUpdateStakeholder(stk.id, 'name', e.target.value)}
                  className="bg-transparent font-bold text-sm text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1"
                />
              </div>

              <button
                onClick={() => handleRemoveStakeholder(stk.id)}
                className="text-slate-400 hover:text-rose-600 p-1 transition cursor-pointer"
                title="Delete"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-500 font-semibold text-[11px] block">Role:</span>
                  <input
                    type="text"
                    value={stk.role}
                    onChange={(e) => handleUpdateStakeholder(stk.id, 'role', e.target.value)}
                    className="w-full bg-white text-slate-900 font-semibold px-2 py-1.5 rounded border border-slate-300 mt-0.5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-500 font-semibold text-[11px] block">Department / Org:</span>
                  <input
                    type="text"
                    value={stk.departmentOrOrg}
                    onChange={(e) => handleUpdateStakeholder(stk.id, 'departmentOrOrg', e.target.value)}
                    className="w-full bg-white text-slate-700 px-2 py-1.5 rounded border border-slate-300 mt-0.5 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-semibold text-[11px] block">Relationship Context & Interactions:</span>
                <textarea
                  rows={2}
                  value={stk.relationshipContext}
                  onChange={(e) => handleUpdateStakeholder(stk.id, 'relationshipContext', e.target.value)}
                  className="w-full bg-white text-slate-700 p-2 rounded border border-slate-300 mt-0.5 leading-relaxed focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-slate-500 font-semibold text-[11px] block">Email:</span>
                  <input
                    type="email"
                    value={stk.email}
                    onChange={(e) => handleUpdateStakeholder(stk.id, 'email', e.target.value)}
                    className="w-full bg-white text-slate-700 px-2 py-1 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-500 font-semibold text-[11px] block">Phone / Cadence:</span>
                  <input
                    type="text"
                    value={stk.phone || stk.cadence}
                    onChange={(e) => handleUpdateStakeholder(stk.id, 'phone', e.target.value)}
                    className="w-full bg-white text-slate-700 px-2 py-1 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
