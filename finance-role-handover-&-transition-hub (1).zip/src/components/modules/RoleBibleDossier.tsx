import React from 'react';
import { useHandover } from '../../context/HandoverContext';
import {
  Printer,
  Download,
  BookMarked,
  FileSpreadsheet,
  Sparkles,
} from 'lucide-react';

export const RoleBibleDossier: React.FC = () => {
  const { data, completionRate, setIsAiModalOpen, exportDataAsJSON } = useHandover();

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadMarkdown = () => {
    const mdContent = `# OPERATIONAL ROLE BIBLE & SUCCESSION HANDOVER DOSSIER
**Organization:** ${data.employeeDetails.entityName}
**Department:** ${data.employeeDetails.department}
**Role Title:** ${data.employeeDetails.outgoingRole}
**Outgoing Lead:** ${data.employeeDetails.outgoingName} (LWD: ${data.employeeDetails.lastWorkingDay})
**Incoming Successor:** ${data.employeeDetails.successorName}
**Reporting Manager:** ${data.employeeDetails.reportingManager}
**Readiness Index:** ${completionRate}% Certified

---

## 1. EMPLOYEE DETAILS & GOVERNANCE
- Outgoing: ${data.employeeDetails.outgoingName} (${data.employeeDetails.outgoingEmail})
- Successor: ${data.employeeDetails.successorName} (${data.employeeDetails.successorEmail})
- Reporting Manager: ${data.employeeDetails.reportingManager} (${data.employeeDetails.managerEmail})
- Department: ${data.employeeDetails.department} | Entity: ${data.employeeDetails.entityName}
- Handover Period: ${data.employeeDetails.handoverStartDate} to ${data.employeeDetails.handoverEndDate}

## 2. ROLE OVERVIEW & KPIS
**Primary Objective:**
${data.roleOverview.primaryObjective}

**Key Responsibilities:**
${data.roleOverview.keyResponsibilities.map((r, i) => `${i + 1}. ${r}`).join('\n')}

**KPI Metrics:**
${data.roleOverview.kpis.map((k) => `- ${k.name} | Target: ${k.target} | Frequency: ${k.frequency} | Source: ${k.measurementSource}`).join('\n')}

## 3. BANKING & SIGNATORY MATRIX
${data.bankingCredentials.map((b) => `### ${b.bankName} (${b.accountType})
- Masked Account: ${b.accountNumberMasked} (${b.currency})
- Signatory Tier: ${b.signatoryTier}
- Dual Auth Limit: ${b.dualAuthLimit}
- Corporate ID: ${b.corporateId}
- Token Device: ${b.tokenType}
- RM Contact: ${b.relationshipManager.name} (${b.relationshipManager.phone} / ${b.relationshipManager.email})
- Fraud Escalation Hotline: ${b.escalationHotline}
- Custody Procedure: ${b.tokenCustodyProcedure}
`).join('\n')}

## 4. RECONCILIATION WORKFLOWS
${data.reconciliationWorkflows.map((r) => `### ${r.name} (${r.type})
- Frequency: ${r.frequency} | Cutoff: ${r.cutoffDay}
- Threshold: ${r.discrepancyThreshold}
- Sources: ${r.sourceSystems.join(', ')}
- Steps:
${r.primaryReconciliationSteps.map((s, i) => `  ${i + 1}. ${s}`).join('\n')}
- Dispute Resolution: ${r.disputeResolutionProcess}
- File Path: ${r.sampleWorkbookLocation}
`).join('\n')}

## 5. RECURRING STATUTORY TAX FILING DEADLINES
${data.taxDeadlines.map((t) => `- **${t.taxName}** (${t.category}) | Due: ${t.dueDayRule} (${t.nextDueDate}) | Portal: ${t.filingPortal} | Login: ${t.portalLoginMethod} | Risk: ${t.penaltyRisk}`).join('\n')}

## 6. KEY RISKS & WHAT NOT TO DO
${data.knownRisks.map((k) => `### ${k.knownIssue} [${k.impactLevel} Impact]
- Workaround: ${k.workaround}
- Deadline Impact: ${k.criticalCutoffTiming}
- WHAT NOT TO DO: ${k.whatNotToDo}
`).join('\n')}

## 7. SUCCESSOR 30-60-90 DAY PLAN
- **Days 1-30 (${data.managerAlignment.first30DaysPlan.focus}):** ${data.managerAlignment.first30DaysPlan.milestones.join('; ')}
- **Days 31-60 (${data.managerAlignment.first60DaysPlan.focus}):** ${data.managerAlignment.first60DaysPlan.milestones.join('; ')}
- **Days 61-90 (${data.managerAlignment.first90DaysPlan.focus}):** ${data.managerAlignment.first90DaysPlan.milestones.join('; ')}

## 8. SIGN-OFF CERTIFICATION
- Status: ${data.employeeDetails.isSignedOff ? `Certified on ${data.employeeDetails.signOffDate}` : 'Pending Signatures'}
`;

    const blob = new Blob([mdContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Role_Bible_${data.employeeDetails.outgoingRole.replace(/\s+/g, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Unified Operational Master Record</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1 flex items-center space-x-2">
            <BookMarked className="h-6 w-6 text-blue-600" />
            <span>Master Finance Role Bible & Handover Dossier</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Complete executive reference document for compliance audit, internal control inspection, and executive succession.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5 text-indigo-600" />
            AI Audit Dossier
          </button>
          <button
            onClick={handleDownloadMarkdown}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition cursor-pointer shadow-sm"
          >
            <Download className="h-3.5 w-3.5 mr-1.5 text-slate-500" />
            Export Markdown
          </button>
          <button
            onClick={exportDataAsJSON}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition cursor-pointer shadow-sm"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 mr-1.5 text-slate-500" />
            Export JSON
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5 mr-1.5" />
            Print Dossier
          </button>
        </div>
      </div>

      {/* The Printable Dossier Container */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-10 space-y-10 text-slate-800 shadow-sm print:bg-white print:text-black print:p-0 print:border-none">
        {/* Cover Header */}
        <div className="border-b-2 border-blue-600 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-blue-600 font-bold">
              {data.employeeDetails.entityName} • {data.employeeDetails.department}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              OPERATIONAL ROLE BIBLE & SUCCESSION DOSSIER
            </h2>
            <div className="text-sm text-slate-600 mt-1">
              Designated Position: <strong className="text-slate-900">{data.employeeDetails.outgoingRole}</strong>
            </div>
          </div>

          <div className="text-right text-xs text-slate-500 space-y-0.5">
            <div>Transition Status: <strong className="text-emerald-700">{completionRate}% Ready</strong></div>
            <div>Effective LWD: <strong className="text-blue-700">{data.employeeDetails.lastWorkingDay}</strong></div>
            <div>Sign-off: <strong className="text-slate-900">{data.employeeDetails.isSignedOff ? 'Certified' : 'Pending Final Review'}</strong></div>
          </div>
        </div>

        {/* Section 1: Executive Summary & Personnel */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            1. Governance & Transition Personnel
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-500 block font-semibold">Outgoing Incumbent:</span>
              <div className="font-bold text-slate-900 text-sm mt-0.5">{data.employeeDetails.outgoingName}</div>
              <div className="text-slate-600">{data.employeeDetails.outgoingEmail}</div>
              <div className="text-blue-700 font-medium">LWD: {data.employeeDetails.lastWorkingDay}</div>
            </div>
            <div>
              <span className="text-slate-500 block font-semibold">Designated Successor:</span>
              <div className="font-bold text-emerald-700 text-sm mt-0.5">{data.employeeDetails.successorName}</div>
              <div className="text-slate-600">{data.employeeDetails.successorEmail}</div>
              <div className="text-slate-600">Target Start: {data.employeeDetails.handoverStartDate}</div>
            </div>
            <div>
              <span className="text-slate-500 block font-semibold">Reporting Authority:</span>
              <div className="font-bold text-slate-900 text-sm mt-0.5">{data.employeeDetails.reportingManager}</div>
              <div className="text-slate-600">{data.employeeDetails.managerEmail}</div>
              <div className="text-slate-600">Dept: {data.employeeDetails.department}</div>
            </div>
          </div>
        </div>

        {/* Section 2: Role Overview & KPIs */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            2. Primary Mission & Key Performance Indicators
          </h3>
          <div className="text-xs text-slate-700 bg-slate-50 p-4 rounded-lg border border-slate-200 leading-relaxed space-y-3">
            <div>
              <strong className="text-slate-900 block mb-1">Core Charter:</strong>
              <p>{data.roleOverview.primaryObjective}</p>
            </div>
            <div>
              <strong className="text-slate-900 block mb-1">Core Deliverables:</strong>
              <ul className="list-disc list-inside space-y-1 text-slate-700">
                {data.roleOverview.keyResponsibilities.map((resp, i) => (
                  <li key={i}>{resp}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Section 3: Banking Credentials & Token Matrix */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            3. Banking Portals, Signatory Tiers & Token Custody Matrix
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 bg-slate-50">
                  <th className="py-2.5 px-3 font-semibold">Bank / Entity</th>
                  <th className="py-2.5 px-3 font-semibold">Signatory Authority</th>
                  <th className="py-2.5 px-3 font-semibold">Dual-Auth Limit</th>
                  <th className="py-2.5 px-3 font-semibold">Token Device / Security</th>
                  <th className="py-2.5 px-3 font-semibold">RM Contact & Hotline</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.bankingCredentials.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-slate-900">{b.bankName}</div>
                      <div className="text-slate-500 font-mono text-[11px]">{b.accountNumberMasked} ({b.currency})</div>
                    </td>
                    <td className="py-2.5 px-3 text-emerald-700 font-semibold">{b.signatoryTier}</td>
                    <td className="py-2.5 px-3 text-blue-700 font-medium">{b.dualAuthLimit}</td>
                    <td className="py-2.5 px-3 text-slate-700">{b.tokenType}</td>
                    <td className="py-2.5 px-3 text-slate-700">
                      <div>{b.relationshipManager.name} ({b.relationshipManager.phone})</div>
                      <div className="text-rose-600 font-mono text-[11px]">Hotline: {b.escalationHotline}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 4: Reconciliation Workflows */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            4. Balance Sheet Reconciliation Workflows
          </h3>
          <div className="space-y-3">
            {data.reconciliationWorkflows.map((rec) => (
              <div key={rec.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm text-slate-900">{rec.name} ({rec.type})</div>
                  <span className="text-blue-700 font-semibold">{rec.cutoffDay}</span>
                </div>
                <div className="text-slate-600">
                  Tolerance: <strong className="text-emerald-700">{rec.discrepancyThreshold}</strong> • Sources: {rec.sourceSystems.join(', ')}
                </div>
                <div className="pt-1 border-t border-slate-200 text-slate-700">
                  <span className="font-semibold text-slate-600">Primary Steps:</span> {rec.primaryReconciliationSteps.join(' → ')}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 5: Recurring Statutory Tax Calendar */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            5. Recurring Statutory Tax Filing Calendar
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {data.taxDeadlines.map((tax) => (
              <div key={tax.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-slate-900">{tax.taxName}</span>
                  <span className="text-blue-700">{tax.dueDayRule}</span>
                </div>
                <div className="text-slate-500">Portal: {tax.filingPortal}</div>
                <div className="text-slate-700">Signing: {tax.portalLoginMethod}</div>
                <div className="text-rose-600 text-[11px] font-medium">Penalty Risk: {tax.penaltyRisk}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 6: Known Risks & What NOT to Do */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-rose-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            6. Critical Known Risks & "What NOT to Do"
          </h3>
          <div className="space-y-3">
            {data.knownRisks.map((risk) => (
              <div key={risk.id} className="p-4 bg-rose-50/60 border border-rose-200 rounded-lg space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">{risk.knownIssue}</span>
                  <span className="text-rose-700 font-bold uppercase">{risk.impactLevel} Impact</span>
                </div>
                <div className="text-slate-700">
                  <strong className="text-emerald-700">Safe Workaround:</strong> {risk.workaround}
                </div>
                <div className="p-2 bg-white rounded border border-rose-300 text-rose-800 font-bold">
                  STRICT WHAT NOT TO DO: {risk.whatNotToDo}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 7: Successor 30-60-90 Day Plan */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-blue-700 uppercase tracking-wider border-b border-slate-200 pb-1">
            7. Successor 30-60-90 Day Roadmap
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
              <span className="font-bold text-blue-700 block">Days 1 - 30 ({data.managerAlignment.first30DaysPlan.focus})</span>
              <p className="text-slate-700 leading-relaxed">{data.managerAlignment.first30DaysPlan.milestones.join('; ')}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
              <span className="font-bold text-indigo-700 block">Days 31 - 60 ({data.managerAlignment.first60DaysPlan.focus})</span>
              <p className="text-slate-700 leading-relaxed">{data.managerAlignment.first60DaysPlan.milestones.join('; ')}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
              <span className="font-bold text-emerald-700 block">Days 61 - 90 ({data.managerAlignment.first90DaysPlan.focus})</span>
              <p className="text-slate-700 leading-relaxed">{data.managerAlignment.first90DaysPlan.milestones.join('; ')}</p>
            </div>
          </div>
        </div>

        {/* Signatures Footer */}
        <div className="pt-8 border-t-2 border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
          <div className="space-y-2 border-t border-slate-200 pt-3">
            <div className="font-bold text-slate-900">{data.employeeDetails.outgoingName}</div>
            <div className="text-slate-500">Outgoing Finance Lead</div>
            <div className="text-emerald-700 font-medium text-[11px]">Status: Verified & Submitted</div>
          </div>
          <div className="space-y-2 border-t border-slate-200 pt-3">
            <div className="font-bold text-slate-900">{data.employeeDetails.successorName}</div>
            <div className="text-slate-500">Incoming Successor</div>
            <div className="text-blue-700 font-medium text-[11px]">Status: Received & Shadowing</div>
          </div>
          <div className="space-y-2 border-t border-slate-200 pt-3">
            <div className="font-bold text-slate-900">{data.employeeDetails.reportingManager}</div>
            <div className="text-slate-500">Chief Financial Officer</div>
            <div className="text-emerald-700 font-medium text-[11px]">Status: Approved & Certified</div>
          </div>
        </div>
      </div>
    </div>
  );
};
