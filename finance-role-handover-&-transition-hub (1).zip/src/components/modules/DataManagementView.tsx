import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { DataManagement } from '../../types/handover';
import {
  FolderTree,
  FileCode,
  Save,
  CheckCircle2,
  Plus,
  Trash2,
  HardDrive,
  Copy,
} from 'lucide-react';

export const DataManagementView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [formData, setFormData] = useState<DataManagement>(data.dataManagement);
  const [isSaved, setIsSaved] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleSave = () => {
    updateSection('dataManagement', formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddFile = () => {
    setFormData((prev) => ({
      ...prev,
      criticalFileLocations: [
        ...prev.criticalFileLocations,
        {
          documentName: 'New Master Financial Model',
          path: 'Finance Shared Drive > 01_Monthly_Close > Working_Files',
          accessPermission: 'Finance Team & Approvers (Edit)',
        },
      ],
    }));
  };

  const handleRemoveFile = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      criticalFileLocations: prev.criticalFileLocations.filter((_, i) => i !== index),
    }));
  };

  const handleUpdateFile = (index: number, field: 'documentName' | 'path' | 'accessPermission', value: string) => {
    const updated = [...formData.criticalFileLocations];
    updated[index] = { ...updated[index], [field]: value };
    setFormData((prev) => ({ ...prev, criticalFileLocations: updated }));
  };

  const copyToClipboard = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 5</span>
            <span>•</span>
            <span>Information Architecture</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Data, Drive Structure & File Conventions
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Document directory trees, standardized file naming taxonomy, backup cadence, and critical master workbook repositories.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Directory Hierarchy & Naming Conventions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Drive Folder Architecture */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            <FolderTree className="h-4 w-4 text-blue-600" />
            <span>Shared Drive Folder Architecture</span>
          </div>
          <div className="space-y-3">
            {formData.folderStructure.map((folder, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{folder.driveName}</span>
                  <code className="text-[11px] text-blue-700 font-mono font-bold">{folder.rootPath}</code>
                </div>
                <p className="text-slate-600">{folder.description}</p>
                <div className="pt-1 flex flex-wrap gap-1">
                  {folder.subFolders.map((sub, sIdx) => (
                    <span key={sIdx} className="px-2 py-0.5 rounded text-[10px] bg-white border border-slate-200 text-slate-700 font-mono">
                      📁 {sub}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Naming Conventions & Archival Schedule */}
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
              <FileCode className="h-4 w-4 text-blue-600" />
              <span>Standardized File Naming Taxonomy</span>
            </div>
            <div className="space-y-2.5">
              {formData.namingConventions.map((conv, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div className="font-bold text-slate-900">{conv.fileType}</div>
                  <div className="font-mono text-blue-700 text-[11px] font-semibold">Pattern: {conv.formatPattern}</div>
                  <div className="font-mono text-slate-500 text-[11px]">Example: {conv.example}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
            <div className="flex items-center space-x-2 text-sm font-bold text-slate-900">
              <HardDrive className="h-4 w-4 text-blue-600" />
              <span>Drive Backup & Archival Schedule</span>
            </div>
            <textarea
              rows={2}
              value={formData.backupAndArchival}
              onChange={(e) => setFormData((prev) => ({ ...prev, backupAndArchival: e.target.value }))}
              className="w-full bg-white text-xs text-slate-900 p-2.5 rounded-md border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Critical File Locations Table */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900">
            <HardDrive className="h-4 w-4 text-blue-600" />
            <span>Important Master Files & Critical Workbook Locations</span>
          </div>
          <button
            onClick={handleAddFile}
            className="inline-flex items-center px-2.5 py-1.5 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add File Reference
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                <th className="py-2.5 px-3 font-bold">Document / Model Name</th>
                <th className="py-2.5 px-3 font-bold">Exact Folder Path</th>
                <th className="py-2.5 px-3 font-bold">Access Permissions</th>
                <th className="py-2.5 px-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {formData.criticalFileLocations.map((file, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={file.documentName}
                      onChange={(e) => handleUpdateFile(idx, 'documentName', e.target.value)}
                      className="w-full bg-white font-medium text-slate-900 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-3">
                    <div className="flex items-center space-x-1">
                      <input
                        type="text"
                        value={file.path}
                        onChange={(e) => handleUpdateFile(idx, 'path', e.target.value)}
                        className="w-full bg-white font-mono text-blue-700 font-semibold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 text-[11px]"
                      />
                      <button
                        onClick={() => copyToClipboard(file.path, idx)}
                        className="text-slate-400 hover:text-slate-600 p-1 transition cursor-pointer"
                        title="Copy Path"
                      >
                        {copiedIndex === idx ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                  <td className="py-2 px-3">
                    <input
                      type="text"
                      value={file.accessPermission}
                      onChange={(e) => handleUpdateFile(idx, 'accessPermission', e.target.value)}
                      className="w-full bg-white text-amber-800 font-semibold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  <td className="py-2 px-2 text-right">
                    <button
                      onClick={() => handleRemoveFile(idx)}
                      className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
