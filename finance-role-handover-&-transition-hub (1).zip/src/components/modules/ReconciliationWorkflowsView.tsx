import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { ReconciliationWorkflow, HandoverStatus } from '../../types/handover';
import {
  GitCompare,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  ArrowRight,
  TrendingUp,
  FileCheck2,
  Scale,
  Sparkles,
} from 'lucide-react';

export const ReconciliationWorkflowsView: React.FC = () => {
  const { data, updateSection, setIsAiModalOpen } = useHandover();
  const [workflows, setWorkflows] = useState<ReconciliationWorkflow[]>(data.reconciliationWorkflows);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>(data.reconciliationWorkflows[0]?.id || '');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('reconciliationWorkflows', workflows);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddWorkflow = () => {
    const newWorkflow: ReconciliationWorkflow = {
      id: `rec-${Date.now()}`,
      name: 'New Balance Sheet Reconciliation Schedule',
      type: 'GL vs Subledger (AP/AR)',
      frequency: 'Monthly',
      sourceSystems: ['SAP S/4HANA (GL 120000)', 'Billing Subledger'],
      primaryReconciliationSteps: [
        'Step 1: Extract Trial balance and subledger aging schedule.',
        'Step 2: Compare ending balances and identify un-matched transactions.',
        'Step 3: Investigate timing differences vs manual journal postings.',
        'Step 4: Prepare signed reconciliation binder for review.',
      ],
      discrepancyThreshold: '$0.00 variance tolerance at monthly close.',
      disputeResolutionProcess: 'Escalate to Accounting Lead within 24 hours of cut-off.',
      journalEntryRules: 'All adjustments require written approval from CFO.',
      cutoffDay: 'Working Day +3 at 17:00 EST',
      sampleWorkbookLocation: 'Finance Shared Drive > Reconciliations > Rec_Master_2026.xlsx',
      status: 'in-progress',
    };
    setWorkflows((prev) => [...prev, newWorkflow]);
    setSelectedWorkflowId(newWorkflow.id);
  };

  const handleRemoveWorkflow = (id: string) => {
    setWorkflows((prev) => prev.filter((w) => w.id !== id));
    if (selectedWorkflowId === id && workflows.length > 1) {
      const remaining = workflows.filter((w) => w.id !== id);
      setSelectedWorkflowId(remaining[0].id);
    }
  };

  const handleUpdateWorkflow = (field: keyof ReconciliationWorkflow, value: any) => {
    setWorkflows((prev) =>
      prev.map((w) => (w.id === selectedWorkflowId ? { ...w, [field]: value } : w))
    );
  };

  const activeRec = workflows.find((w) => w.id === selectedWorkflowId) || workflows[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Specialized Finance Toolkit</span>
            <span>•</span>
            <span>Books & Internal Balance Control</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Reconciliation Workflows & Variance Resolution
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Step-by-step procedures for Bank Rec (BRS), GL vs Subledgers, Intercompany balances, Gateway settlements, and variance tolerance rules.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleAddWorkflow}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Rec Workflow
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Workflows
          </button>
        </div>
      </div>

      {/* Main Rec Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Workflow Selector */}
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">
            Active Reconciliation Schedules ({workflows.length})
          </div>
          <div className="space-y-2">
            {workflows.map((wf) => {
              const isSelected = activeRec?.id === wf.id;
              return (
                <div
                  key={wf.id}
                  onClick={() => setSelectedWorkflowId(wf.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 text-slate-900 shadow-sm ring-1 ring-blue-500/20'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                        {wf.type}
                      </span>
                      <h4 className="font-bold text-xs text-slate-900 mt-1.5 line-clamp-1">{wf.name}</h4>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded shrink-0 ${
                        wf.status === 'completed'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : wf.status === 'reverse-shadowed'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {wf.status}
                    </span>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Frequency: <strong className="text-slate-700">{wf.frequency}</strong></span>
                    <span className="text-blue-700 font-semibold">{wf.cutoffDay.split(';')[0]}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Workflow Detail Card (2 Columns) */}
        {activeRec && (
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
            {/* Header of Active Workflow */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 rounded text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    {activeRec.type}
                  </span>
                  <select
                    value={activeRec.status}
                    onChange={(e) => handleUpdateWorkflow('status', e.target.value as HandoverStatus)}
                    className="text-xs bg-slate-50 text-slate-800 font-semibold px-2.5 py-1 rounded-md border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="not-started">Not Started</option>
                    <option value="in-progress">In Progress</option>
                    <option value="shadowing">Shadowing Active</option>
                    <option value="reverse-shadowed">Reverse Shadowed</option>
                    <option value="completed">Handover Completed</option>
                  </select>
                </div>
                <input
                  type="text"
                  value={activeRec.name}
                  onChange={(e) => handleUpdateWorkflow('name', e.target.value)}
                  className="text-lg font-bold text-slate-900 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded px-1 w-full border-b border-slate-200"
                />
              </div>

              <button
                onClick={() => handleRemoveWorkflow(activeRec.id)}
                className="text-slate-400 hover:text-rose-600 p-2 transition self-start sm:self-auto cursor-pointer"
                title="Delete Workflow"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            {/* Timing, Source Systems & Threshold */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Cadence & Cutoff Day
                </span>
                <input
                  type="text"
                  value={activeRec.cutoffDay}
                  onChange={(e) => handleUpdateWorkflow('cutoffDay', e.target.value)}
                  className="w-full bg-white text-slate-900 font-bold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Discrepancy Threshold
                </span>
                <input
                  type="text"
                  value={activeRec.discrepancyThreshold}
                  onChange={(e) => handleUpdateWorkflow('discrepancyThreshold', e.target.value)}
                  className="w-full bg-white text-emerald-700 font-bold px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">
                  Source Ledgers / Feeds
                </span>
                <input
                  type="text"
                  value={activeRec.sourceSystems.join(', ')}
                  onChange={(e) =>
                    handleUpdateWorkflow(
                      'sourceSystems',
                      e.target.value.split(',').map((s) => s.trim())
                    )
                  }
                  className="w-full bg-white text-blue-700 font-medium px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Step-by-Step Reconciliation Procedure */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center">
                <TrendingUp className="h-3.5 w-3.5 mr-1.5 text-blue-600" />
                Step-by-Step Reconciliation Steps
              </h3>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
                {activeRec.primaryReconciliationSteps.map((step, idx) => (
                  <div key={idx} className="flex items-start space-x-2 text-xs text-slate-800">
                    <span className="flex items-center justify-center h-5 w-5 rounded bg-blue-100 text-blue-700 font-bold text-[11px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <input
                      type="text"
                      value={step}
                      onChange={(e) => {
                        const updated = [...activeRec.primaryReconciliationSteps];
                        updated[idx] = e.target.value;
                        handleUpdateWorkflow('primaryReconciliationSteps', updated);
                      }}
                      className="w-full bg-white text-slate-800 focus:outline-none border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 rounded px-2 py-1"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Dispute Resolution & Journal Entry Posting Rules */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <span className="font-bold text-amber-800 block flex items-center">
                  <AlertTriangle className="h-3.5 w-3.5 mr-1 text-amber-600" />
                  Dispute & Variance Resolution Flow
                </span>
                <textarea
                  rows={3}
                  value={activeRec.disputeResolutionProcess}
                  onChange={(e) => handleUpdateWorkflow('disputeResolutionProcess', e.target.value)}
                  className="w-full bg-white text-slate-800 p-2.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 leading-relaxed"
                />
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <span className="font-bold text-blue-800 block flex items-center">
                  <Scale className="h-3.5 w-3.5 mr-1 text-blue-600" />
                  Journal Entry Rules & Control Accounts
                </span>
                <textarea
                  rows={3}
                  value={activeRec.journalEntryRules}
                  onChange={(e) => handleUpdateWorkflow('journalEntryRules', e.target.value)}
                  className="w-full bg-white text-slate-800 p-2.5 rounded border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 leading-relaxed"
                />
              </div>
            </div>

            {/* Sample Workbook Location */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2 text-slate-700">
                <FolderOpen className="h-4 w-4 text-amber-600" />
                <span>Working File Path: <code className="text-blue-700 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">{activeRec.sampleWorkbookLocation}</code></span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
