import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { HandoverTimelineDay } from '../../types/handover';
import {
  Milestone,
  CheckCircle2,
  Clock,
  Plus,
  Trash2,
  Save,
  CheckCircle,
  Calendar,
} from 'lucide-react';

export const HandoverPlanView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [timeline, setTimeline] = useState<HandoverTimelineDay[]>(data.handoverTimeline);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('handoverTimeline', timeline);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleTogglePhase = (id: string) => {
    setTimeline((prev) =>
      prev.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p))
    );
  };

  const handleUpdatePhase = (id: string, field: keyof HandoverTimelineDay, value: any) => {
    setTimeline((prev) =>
      prev.map((p) => (p.id === id ? { ...p, [field]: value } : p))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 10</span>
            <span>•</span>
            <span>Structured 4-Phase Transition</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Handover Plan, Shadowing Sessions & Sign-off Milestones
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Phase 1: Orientation & Setup → Phase 2: Live Shadowing → Phase 3: Reverse Shadowing (Successor executes) → Phase 4: Formal Independent Sign-off.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Timeline
          </button>
        </div>
      </div>

      {/* 4 Phases Accordion / Step Cards */}
      <div className="space-y-4">
        {timeline.map((phase, idx) => (
          <div
            key={phase.id}
            className={`border rounded-xl p-5 shadow-sm space-y-4 transition ${
              phase.completed
                ? 'bg-emerald-50/50 border-emerald-300'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            {/* Phase Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => handleTogglePhase(phase.id)}
                  className={`h-7 w-7 rounded-md flex items-center justify-center font-bold text-xs transition cursor-pointer ${
                    phase.completed
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
                  }`}
                  title="Toggle Completed"
                >
                  {phase.completed ? '✓' : idx + 1}
                </button>
                <div>
                  <div className="font-bold text-sm text-slate-900">
                    {phase.phase}
                  </div>
                  <div className="text-xs text-blue-700 font-semibold mt-0.5">
                    Timeframe: {phase.timeframe}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleTogglePhase(phase.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition cursor-pointer ${
                    phase.completed
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-slate-100 text-slate-700 border border-slate-200 hover:bg-slate-200'
                  }`}
                >
                  {phase.completed ? 'Phase Certified ✓' : 'Mark Completed'}
                </button>
              </div>
            </div>

            {/* Focus Areas & Tasks to Cover */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block">Key Focus Areas:</span>
                <div className="space-y-1.5">
                  {phase.focusAreas.map((area, i) => (
                    <div key={i} className="flex items-start space-x-2 text-slate-700">
                      <span className="text-blue-600 font-bold">•</span>
                      <input
                        type="text"
                        value={area}
                        onChange={(e) => {
                          const updated = [...phase.focusAreas];
                          updated[i] = e.target.value;
                          handleUpdatePhase(phase.id, 'focusAreas', updated);
                        }}
                        className="w-full bg-transparent text-slate-800 focus:outline-none border-b border-transparent focus:border-slate-400"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block">Tasks to Cover & Hands-on Practice:</span>
                <div className="space-y-1.5">
                  {phase.tasksToCover.map((task, i) => (
                    <div key={i} className="flex items-start space-x-2 text-slate-700">
                      <span className="text-emerald-600 font-bold">✓</span>
                      <input
                        type="text"
                        value={task}
                        onChange={(e) => {
                          const updated = [...phase.tasksToCover];
                          updated[i] = e.target.value;
                          handleUpdatePhase(phase.id, 'tasksToCover', updated);
                        }}
                        className="w-full bg-transparent text-slate-800 focus:outline-none border-b border-transparent focus:border-slate-400"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Validation & Success Criteria */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                <span className="font-bold text-slate-700">Phase Exit / Success Criteria:</span>
              </div>
              <input
                type="text"
                value={phase.successCriteria}
                onChange={(e) => handleUpdatePhase(phase.id, 'successCriteria', e.target.value)}
                className="bg-white text-slate-900 font-medium px-3 py-1.5 rounded-md border border-slate-300 w-full sm:w-2/3 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
