import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { ManagerAlignment } from '../../types/handover';
import {
  MessageSquare,
  Save,
  CheckCircle2,
  Sparkles,
  FileCheck,
  Calendar,
  Compass,
  Award,
} from 'lucide-react';

export const ManagerCommentsView: React.FC = () => {
  const { data, updateSection, setIsAiModalOpen, setIsSignOffModalOpen } = useHandover();
  const [alignment, setAlignment] = useState<ManagerAlignment>(data.managerAlignment);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('managerAlignment', alignment);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 12</span>
            <span>•</span>
            <span>Succession Roadmap & Governance</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Manager Expectations, 30-60-90 Day Plan & Feedback
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Structured milestones for the successor's first quarter, manager alignment criteria, and tripartite sign-off readiness.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5 text-indigo-600" />
            AI 30-60-90 Plan
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Plan
          </button>
        </div>
      </div>

      {/* 30-60-90 Day Roadmap Cards */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
          <Compass className="h-4 w-4 text-blue-600" />
          <span>Successor 30-60-90 Day Autonomy Roadmap</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Day 1 - 30 */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                Days 1 - 30
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                {alignment.first30DaysPlan.focus}
              </span>
            </div>
            <textarea
              rows={8}
              value={alignment.first30DaysPlan.milestones.join('\n')}
              onChange={(e) =>
                setAlignment((prev) => ({
                  ...prev,
                  first30DaysPlan: {
                    ...prev.first30DaysPlan,
                    milestones: e.target.value.split('\n'),
                  },
                }))
              }
              className="w-full bg-white text-xs text-slate-800 p-2.5 rounded-md border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed font-sans"
            />
          </div>

          {/* Day 31 - 60 */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                Days 31 - 60
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                {alignment.first60DaysPlan.focus}
              </span>
            </div>
            <textarea
              rows={8}
              value={alignment.first60DaysPlan.milestones.join('\n')}
              onChange={(e) =>
                setAlignment((prev) => ({
                  ...prev,
                  first60DaysPlan: {
                    ...prev.first60DaysPlan,
                    milestones: e.target.value.split('\n'),
                  },
                }))
              }
              className="w-full bg-white text-xs text-slate-800 p-2.5 rounded-md border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed font-sans"
            />
          </div>

          {/* Day 61 - 90 */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Days 61 - 90
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                {alignment.first90DaysPlan.focus}
              </span>
            </div>
            <textarea
              rows={8}
              value={alignment.first90DaysPlan.milestones.join('\n')}
              onChange={(e) =>
                setAlignment((prev) => ({
                  ...prev,
                  first90DaysPlan: {
                    ...prev.first90DaysPlan,
                    milestones: e.target.value.split('\n'),
                  },
                }))
              }
              className="w-full bg-white text-xs text-slate-800 p-2.5 rounded-md border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed font-sans"
            />
          </div>
        </div>
      </div>

      {/* Manager Evaluation & Expectations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            <Award className="h-4 w-4 text-amber-500" />
            <span>Reporting Manager Notes & Guidance</span>
          </div>
          <textarea
            rows={5}
            value={alignment.managerNotes}
            onChange={(e) => setAlignment((prev) => ({ ...prev, managerNotes: e.target.value }))}
            className="w-full bg-slate-50 text-xs text-slate-800 p-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
          />
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            <FileCheck className="h-4 w-4 text-emerald-600" />
            <span>Evaluation Criteria & Success Metrics</span>
          </div>
          <textarea
            rows={5}
            value={alignment.evaluationCriteria.join('\n')}
            onChange={(e) =>
              setAlignment((prev) => ({
                ...prev,
                evaluationCriteria: e.target.value.split('\n'),
              }))
            }
            className="w-full bg-slate-50 text-xs text-slate-800 p-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
          />
        </div>
      </div>

      {/* Sign-off Callout */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900">Tripartite Certificate of Operational Readiness</h3>
          <p className="text-xs text-slate-600 mt-1">
            Execute final digital sign-off between Outgoing Lead, Incoming Successor, and Chief Financial Officer.
          </p>
        </div>
        <button
          onClick={() => setIsSignOffModalOpen(true)}
          className="w-full sm:w-auto px-5 py-2.5 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
        >
          Open Sign-off Certificate & Export
        </button>
      </div>
    </div>
  );
};
