import React, { useState } from 'react';
import { useHandover } from '../../context/HandoverContext';
import { KnowledgeNote } from '../../types/handover';
import {
  HelpCircle,
  Lightbulb,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  BookOpen,
} from 'lucide-react';

export const KnowledgeNotesView: React.FC = () => {
  const { data, updateSection } = useHandover();
  const [notes, setNotes] = useState<KnowledgeNote[]>(data.knowledgeNotes);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSection('knowledgeNotes', notes);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddNote = (category: KnowledgeNote['category']) => {
    const newNote: KnowledgeNote = {
      id: `note-${Date.now()}`,
      category,
      title: category === 'Pro Tips & Hacks' ? 'New Finance Operational Tip' : 'Common Reconciliation Question',
      content: 'Detailed explanation, unwritten rule, or step-by-step resolution...',
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleRemoveNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const handleUpdateNote = (id: string, field: keyof KnowledgeNote, value: any) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, [field]: value } : n))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <span>Section 11</span>
            <span>•</span>
            <span>Institutional Wisdom</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Knowledge Transfer Notes, Pro Tips & FAQs
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Capture operational nuances, informal communication cadences, month-end survival tips, and common error resolutions.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isSaved && (
            <span className="text-xs text-emerald-600 flex items-center font-medium">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Saved
            </span>
          )}
          <button
            onClick={() => handleAddNote('Pro Tips & Hacks')}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            + Pro Tip
          </button>
          <button
            onClick={() => handleAddNote('Frequently Asked Questions (FAQs)')}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            + FAQ Item
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Notes
          </button>
        </div>
      </div>

      {/* Notes List */}
      <div className="space-y-4">
        {notes.map((note) => (
          <div
            key={note.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3 hover:border-slate-300 transition"
          >
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2.5 flex-1">
                {note.category === 'Pro Tips & Hacks' ? (
                  <Lightbulb className="h-4 w-4 text-amber-500 shrink-0" />
                ) : (
                  <HelpCircle className="h-4 w-4 text-blue-600 shrink-0" />
                )}
                <input
                  type="text"
                  value={note.title}
                  onChange={(e) => handleUpdateNote(note.id, 'title', e.target.value)}
                  className="bg-transparent font-bold text-sm text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded px-1 flex-1"
                />
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={note.category}
                  onChange={(e) => handleUpdateNote(note.id, 'category', e.target.value)}
                  className="text-xs font-semibold px-2 py-1 rounded-md border border-slate-300 bg-white text-slate-700 focus:outline-none"
                >
                  <option value="Pro Tips & Hacks">Pro Tips & Hacks</option>
                  <option value="Frequently Asked Questions (FAQs)">Frequently Asked Questions (FAQs)</option>
                  <option value="Email & Communication Templates">Email & Communication Templates</option>
                  <option value="Past Audit Queries">Past Audit Queries</option>
                </select>

                <button
                  onClick={() => handleRemoveNote(note.id)}
                  className="text-slate-400 hover:text-rose-600 p-1.5 transition cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <textarea
              rows={3}
              value={note.content}
              onChange={(e) => handleUpdateNote(note.id, 'content', e.target.value)}
              className="w-full bg-slate-50 text-xs text-slate-700 p-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"
            />
          </div>
        ))}
      </div>
    </div>
  );
};
