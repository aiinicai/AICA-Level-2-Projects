import React from 'react';
import { useHandover } from '../context/HandoverContext';
import {
  LayoutDashboard,
  UserCheck,
  Target,
  FileText,
  Landmark,
  GitCompare,
  CalendarDays,
  Laptop,
  FolderTree,
  Users2,
  ListTodo,
  AlertOctagon,
  ShieldAlert,
  Milestone,
  HelpCircle,
  MessageSquare,
  BookMarked,
} from 'lucide-react';

export const navItems = [
  {
    id: 'overview',
    label: 'Overview & Readiness',
    icon: LayoutDashboard,
    badge: null,
    group: 'Core',
  },
  {
    id: 'role-bible',
    label: '📖 Master Role Bible',
    icon: BookMarked,
    badge: 'Dossier',
    group: 'Core',
  },
  {
    id: 'banking',
    label: 'Banking & Signatory Matrix',
    icon: Landmark,
    badge: 'Crucial',
    group: 'Finance Toolkits',
  },
  {
    id: 'reconciliations',
    label: 'Reconciliation Workflows',
    icon: GitCompare,
    badge: 'Core',
    group: 'Finance Toolkits',
  },
  {
    id: 'tax-deadlines',
    label: 'Recurring Tax & Compliance',
    icon: CalendarDays,
    badge: 'Statutory',
    group: 'Finance Toolkits',
  },
  {
    id: 'sops',
    label: '3. Process & SOP Library',
    icon: FileText,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'employee-details',
    label: '1. Employee Details',
    icon: UserCheck,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'role-overview',
    label: '2. Role Overview & KPIs',
    icon: Target,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'systems',
    label: '4. System Access & Tools',
    icon: Laptop,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'data-management',
    label: '5. Data & File Management',
    icon: FolderTree,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'stakeholders',
    label: '6. Stakeholder Mapping',
    icon: Users2,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'ongoing-work',
    label: '7. Ongoing Work & Status',
    icon: ListTodo,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'risks-challenges',
    label: '8. Key Risks & "What NOT to Do"',
    icon: AlertOctagon,
    badge: 'Critical',
    group: '12-Section Template',
  },
  {
    id: 'compliance-controls',
    label: '9. Compliance & Controls',
    icon: ShieldAlert,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'handover-plan',
    label: '10. Handover & Shadowing Plan',
    icon: Milestone,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'knowledge-notes',
    label: '11. Knowledge Notes & FAQs',
    icon: HelpCircle,
    badge: null,
    group: '12-Section Template',
  },
  {
    id: 'manager-comments',
    label: '12. Manager & 30-60-90 Plan',
    icon: MessageSquare,
    badge: 'Strategy',
    group: '12-Section Template',
  },
];

export const NavigationTabs: React.FC = () => {
  const { activeTab, setActiveTab, data, completionRate } = useHandover();

  const groups = ['Core', 'Finance Toolkits', '12-Section Template'];

  return (
    <aside className="w-full lg:w-64 bg-slate-900 shrink-0 p-4 flex flex-col space-y-4 border-r border-slate-800">
      {/* Handover Subject Card */}
      <div className="bg-slate-800/90 rounded-xl p-3.5 border border-slate-700/70 hidden lg:block">
        <div className="text-[10px] font-bold text-blue-400 uppercase tracking-wider mb-1">
          Active Succession
        </div>
        <div className="text-sm font-bold text-white truncate">
          {data.employeeDetails.outgoingName}
        </div>
        <div className="text-xs text-slate-300 truncate mt-0.5">
          → {data.employeeDetails.successorName || 'Successor Pending'}
        </div>
        <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
          <span>Target LWD:</span>
          <span className="font-semibold text-amber-300">{data.employeeDetails.lastWorkingDay}</span>
        </div>
      </div>

      {/* Navigation Links grouped */}
      <nav className="space-y-4 flex-1 overflow-y-auto max-h-[calc(100vh-16rem)] dark-scrollbar pr-1">
        {groups.map((group) => {
          const items = navItems.filter((i) => i.group === group);
          return (
            <div key={group} className="space-y-1">
              <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {group}
              </div>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition text-left cursor-pointer ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-sm font-semibold'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 min-w-0">
                        <Icon
                          className={`h-4 w-4 shrink-0 ${
                            isActive ? 'text-white' : 'text-slate-400'
                          }`}
                        />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge && (
                        <span
                          className={`ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                            isActive
                              ? 'bg-blue-800 text-blue-100'
                              : item.badge === 'Crucial' || item.badge === 'Critical'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : item.badge === 'Statutory'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      {/* Completion Progress at bottom of Sidebar */}
      <div className="hidden lg:block p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/50 mt-auto">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span>Completion Progress</span>
          <span className="text-white font-bold">{completionRate}% Detailed</span>
        </div>
        <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
          <div
            className="bg-blue-500 h-full transition-all duration-500 rounded-full"
            style={{ width: `${completionRate}%` }}
          />
        </div>
      </div>
    </aside>
  );
};
