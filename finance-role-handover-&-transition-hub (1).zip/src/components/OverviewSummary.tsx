import React from 'react';
import { useHandover } from '../context/HandoverContext';
import {
  ShieldAlert,
  Calendar,
  Landmark,
  FileCheck,
  ArrowRight,
  AlertTriangle,
  Clock,
  Sparkles,
  BookOpen,
  CheckCircle2,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  FileText,
  Lock,
} from 'lucide-react';

export const OverviewSummary: React.FC = () => {
  const {
    data,
    setActiveTab,
    completionRate,
    completedChecklistCount,
    totalChecklistCount,
    setIsAiModalOpen,
    setIsSignOffModalOpen,
  } = useHandover();

  const daysLeft = Math.ceil(
    (new Date(data.employeeDetails.lastWorkingDay).getTime() - new Date().getTime()) /
      (1000 * 60 * 60 * 24)
  );

  const pendingTaxDeadlines = data.taxDeadlines.filter(
    (t) => t.status === 'Pending Current Period' || t.status === 'Action Required'
  );

  const highPriorityTasks = data.ongoingTasks.filter(
    (t) => t.priority === 'Critical' || t.priority === 'High'
  );

  const criticalRisks = data.knownRisks.filter((r) => r.impactLevel === 'Critical');

  return (
    <div className="space-y-6">
      {/* Hero Executive Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-7 shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
              <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              <span>Finance Succession & Operational Transition Hub</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              {data.employeeDetails.outgoingRole} Transition Master Record
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              Transitioning from <strong className="text-slate-900">{data.employeeDetails.outgoingName}</strong> to{' '}
              <strong className="text-blue-600 font-semibold">{data.employeeDetails.successorName}</strong> under reporting manager{' '}
              <strong className="text-slate-900">{data.employeeDetails.reportingManager}</strong>.
            </p>
          </div>

          {/* Handover Countdown & Status */}
          <div className="flex flex-wrap items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="text-center px-4 border-r border-slate-200">
              <div className="text-xs text-slate-500 font-medium">Last Working Day</div>
              <div className="text-sm font-bold text-slate-900 mt-0.5">
                {data.employeeDetails.lastWorkingDay}
              </div>
              <div className="text-[11px] text-amber-600 font-semibold mt-0.5">
                {daysLeft > 0 ? `${daysLeft} days remaining` : 'Transition complete'}
              </div>
            </div>

            <div className="text-center px-4">
              <div className="text-xs text-slate-500 font-medium">Readiness Index</div>
              <div className="text-2xl font-extrabold text-blue-600 mt-0.5">
                {completionRate}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {completedChecklistCount} of {totalChecklistCount} items verified
              </div>
            </div>

            <div className="w-full sm:w-auto mt-2 sm:mt-0 flex gap-2">
              <button
                onClick={() => setActiveTab('role-bible')}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center px-4 py-2 rounded-md text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-sm transition cursor-pointer"
              >
                <BookOpen className="h-3.5 w-3.5 mr-1.5" />
                <span>Role Bible</span>
              </button>
              <button
                onClick={() => setIsAiModalOpen(true)}
                className="inline-flex items-center justify-center px-3 py-2 rounded-md text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition cursor-pointer"
                title="Ask AI Transition Copilot"
              >
                <Sparkles className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Critical Highlight Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Banking Credentials & Tokens */}
        <div
          onClick={() => setActiveTab('banking')}
          className="bg-white border border-slate-200 hover:border-blue-500/50 hover:shadow-md p-5 rounded-xl transition cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
                <Landmark className="h-5 w-5" />
              </div>
              <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                {data.bankingCredentials.length} Accounts
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-3 group-hover:text-blue-600 transition">
              Banking & Signatory Matrix
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
              JPMC, Citi & SVB corporate portals, hardware RSA token custody, and dual-auth limits.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-blue-600 font-semibold">
            <span>Review Token Protocols</span>
            <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 2. Reconciliation Workflows */}
        <div
          onClick={() => setActiveTab('reconciliations')}
          className="bg-white border border-slate-200 hover:border-blue-500/50 hover:shadow-md p-5 rounded-xl transition cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
                <TrendingUp className="h-5 w-5" />
              </div>
              <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                {data.reconciliationWorkflows.length} Workflows
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-3 group-hover:text-blue-600 transition">
              Reconciliation Workflows
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
              Daily BRS, GL vs AP/AR Subledger, Intercompany FX, and Gateway settlements.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-emerald-600 font-semibold">
            <span>Explore Rec Schedules</span>
            <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 3. Recurring Statutory Tax Deadlines */}
        <div
          onClick={() => setActiveTab('tax-deadlines')}
          className="bg-white border border-slate-200 hover:border-blue-500/50 hover:shadow-md p-5 rounded-xl transition cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
                <Calendar className="h-5 w-5" />
              </div>
              <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                {pendingTaxDeadlines.length} Due Soon
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-3 group-hover:text-blue-600 transition">
              Statutory Tax Compliance
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
              GST GSTR-3B (20th), TDS Withholding (7th), Corporate Advance Tax (15th Sept).
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-amber-600 font-semibold">
            <span>View Tax Calendar</span>
            <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 4. Critical Risks & Known Pitfalls */}
        <div
          onClick={() => setActiveTab('risks-challenges')}
          className="bg-white border border-slate-200 hover:border-rose-500/50 hover:shadow-md p-5 rounded-xl transition cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                {criticalRisks.length} Critical
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-3 group-hover:text-rose-600 transition">
              Key Risks & "What NOT to Do"
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
              Wire 14:00 cut-off, vendor bank change fraud defense, and portal traffic surges.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-rose-600 font-semibold">
            <span>Read Practical Warnings</span>
            <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition" />
          </div>
        </div>
      </div>

      {/* Main Content Grid: Core Reconciliations & Dark Compliance Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Ongoing Reconciliations & Workflows Table (2 Columns) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between">
          <div>
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between">
              <h2 className="font-bold text-slate-900 text-sm sm:text-base">
                Core Ongoing Reconciliations & Operational Workflows
              </h2>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-[10px] font-bold rounded">
                ACTIVE
              </span>
            </div>

            <div className="p-0 overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50/50 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Task/Workflow Name</th>
                    <th className="px-6 py-3">Frequency</th>
                    <th className="px-6 py-3">System</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {data.reconciliationWorkflows.slice(0, 4).map((rec, idx) => (
                    <tr
                      key={rec.id}
                      onClick={() => setActiveTab('reconciliations')}
                      className="hover:bg-slate-50 cursor-pointer transition"
                    >
                      <td className="px-6 py-3.5 font-medium text-slate-900">
                        {rec.name}
                      </td>
                      <td className="px-6 py-3.5 text-slate-500 font-medium">
                        {rec.frequency}
                      </td>
                      <td className="px-6 py-3.5">
                        <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-[11px] font-mono border border-slate-200/60">
                          {rec.sourceSystems[0] || 'SAP / Oracle'}
                        </span>
                      </td>
                      <td className="px-6 py-3.5">
                        <span className="text-emerald-700 flex items-center font-medium">
                          <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                          {idx % 2 === 0 ? 'Handover Complete' : 'SOP Documented'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {/* Fallback mock-aligned items to ensure rich preview */}
                  <tr
                    onClick={() => setActiveTab('tax-deadlines')}
                    className="hover:bg-slate-50 cursor-pointer transition"
                  >
                    <td className="px-6 py-3.5 font-medium text-slate-900">
                      GST/VAT Return Filing Preparation
                    </td>
                    <td className="px-6 py-3.5 text-slate-500 font-medium">Monthly</td>
                    <td className="px-6 py-3.5">
                      <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-[11px] font-mono border border-slate-200/60">
                        ClearTax / GSTN
                      </span>
                    </td>
                    <td className="px-6 py-3.5">
                      <span className="text-amber-700 flex items-center font-medium">
                        <span className="w-2 h-2 bg-amber-500 rounded-full mr-2"></span>
                        Pending Shadowing
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              Showing critical finance operational cadences
            </span>
            <button
              onClick={() => setActiveTab('reconciliations')}
              className="text-blue-600 font-semibold hover:underline cursor-pointer"
            >
              View all {data.reconciliationWorkflows.length} workflows →
            </button>
          </div>
        </div>

        {/* Critical Compliance Calendar (Dark Theme Card from Design Spec) */}
        <div className="bg-slate-900 text-white rounded-xl shadow-lg border border-slate-800 flex flex-col justify-between p-6 space-y-4">
          <div>
            <div className="border-b border-slate-800 pb-4">
              <h2 className="font-bold text-lg text-white">Critical Compliance Calendar</h2>
              <p className="text-slate-400 text-xs mt-0.5">Upcoming tax & regulatory deadlines</p>
            </div>

            <div className="space-y-4 mt-4">
              {/* Event 1 */}
              <div
                onClick={() => setActiveTab('tax-deadlines')}
                className="flex items-start space-x-4 cursor-pointer hover:bg-slate-800/40 p-1.5 rounded-lg transition"
              >
                <div className="flex flex-col items-center justify-center w-12 h-12 bg-rose-500/20 border border-rose-500/30 rounded-lg text-rose-400 shrink-0">
                  <span className="text-[10px] font-bold">OCT</span>
                  <span className="text-base font-bold leading-none">07</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-white">TDS Monthly Deposit</p>
                  <p className="text-xs text-slate-400">Regulatory filing for Sep payouts</p>
                </div>
              </div>

              {/* Event 2 */}
              <div
                onClick={() => setActiveTab('tax-deadlines')}
                className="flex items-start space-x-4 cursor-pointer hover:bg-slate-800/40 p-1.5 rounded-lg transition"
              >
                <div className="flex flex-col items-center justify-center w-12 h-12 bg-amber-500/20 border border-amber-500/30 rounded-lg text-amber-400 shrink-0">
                  <span className="text-[10px] font-bold">OCT</span>
                  <span className="text-base font-bold leading-none">15</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-white">PF/ESI Monthly Remittance</p>
                  <p className="text-xs text-slate-400">Payroll statutory compliance</p>
                </div>
              </div>

              {/* Event 3 */}
              <div
                onClick={() => setActiveTab('tax-deadlines')}
                className="flex items-start space-x-4 cursor-pointer hover:bg-slate-800/40 p-1.5 rounded-lg transition"
              >
                <div className="flex flex-col items-center justify-center w-12 h-12 bg-blue-500/20 border border-blue-500/30 rounded-lg text-blue-400 shrink-0">
                  <span className="text-[10px] font-bold">OCT</span>
                  <span className="text-base font-bold leading-none">20</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-white">GST-3B Monthly Return</p>
                  <p className="text-xs text-slate-400">Monthly tax reconciliation & return</p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-slate-800 rounded-lg border border-slate-700">
            <p className="text-[10px] font-bold uppercase text-slate-400 mb-1">
              Banking Credentials & Tokens
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              Bank access tokens and signatory updates are initiated. New joiner should expect RSA token delivery by Oct 12.
            </p>
          </div>
        </div>
      </div>

      {/* 30-60-90 Day Success Plan (New Hire) matching Design HTML */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
          <h3 className="font-bold text-slate-900 uppercase text-xs tracking-wider">
            30-60-90 Day Success Plan (New Hire Roadmap)
          </h3>
          <div className="flex space-x-1.5">
            <div className="h-2 w-2 rounded-full bg-blue-600"></div>
            <div className="h-2 w-2 rounded-full bg-slate-300"></div>
            <div className="h-2 w-2 rounded-full bg-slate-300"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2.5 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="text-xs font-bold text-blue-700 bg-blue-100/70 px-2 py-0.5 inline-block rounded">
              Phase 1: Days 1-30
            </div>
            <p className="text-xs text-slate-700 font-medium">
              System familiarity and shadow reconciliations. Accessing ERP and establishing stakeholder relationships.
            </p>
            <ul className="text-[11px] text-slate-500 list-disc pl-4 space-y-1">
              <li>Complete SAP Finance User Training</li>
              <li>Observe Month-end Closing Cycle</li>
              <li>Setup 1:1s with Dept Heads & Bank RMs</li>
            </ul>
          </div>

          <div className="space-y-2.5 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="text-xs font-bold text-slate-700 bg-slate-200 px-2 py-0.5 inline-block rounded">
              Phase 2: Days 31-60
            </div>
            <p className="text-xs text-slate-700 font-medium">
              Independent handling of daily tasks. Transitioning into monthly reporting ownership.
            </p>
            <ul className="text-[11px] text-slate-500 list-disc pl-4 space-y-1">
              <li>Own AP/AR Reconciliation Process</li>
              <li>Participate in Interim Audit Prep</li>
              <li>Lead Weekly Cash Flow Review</li>
            </ul>
          </div>

          <div className="space-y-2.5 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="text-xs font-bold text-slate-700 bg-slate-200 px-2 py-0.5 inline-block rounded">
              Phase 3: Days 61-90
            </div>
            <p className="text-xs text-slate-700 font-medium">
              Full operational ownership. Identifying process improvements and efficiency gains.
            </p>
            <ul className="text-[11px] text-slate-500 list-disc pl-4 space-y-1">
              <li>Full Quarter-end Closing Lead</li>
              <li>Finalize Statutory Audit Documentation</li>
              <li>Propose Automation for P&L Reports</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
