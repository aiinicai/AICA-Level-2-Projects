import React, { useState } from 'react';
import { useHandover } from '../context/HandoverContext';
import {
  FileCheck2,
  X,
  CheckCircle,
  CheckCircle2,
  Printer,
  ShieldCheck,
  Award,
  Calendar,
  Lock,
} from 'lucide-react';

export const SignOffModal: React.FC = () => {
  const { isSignOffModalOpen, setIsSignOffModalOpen, data, completeSignOff, completionRate } = useHandover();
  const [outgoingConfirmed, setOutgoingConfirmed] = useState(data.employeeDetails.isSignedOff);
  const [successorConfirmed, setSuccessorConfirmed] = useState(data.employeeDetails.isSignedOff);
  const [managerConfirmed, setManagerConfirmed] = useState(data.employeeDetails.isSignedOff);
  const [signDate, setSignDate] = useState(data.employeeDetails.signOffDate || new Date().toISOString().split('T')[0]);

  if (!isSignOffModalOpen) return null;

  const handleExecuteSignOff = () => {
    completeSignOff(signDate);
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  const allConfirmed = outgoingConfirmed && successorConfirmed && managerConfirmed;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Tripartite Handover Sign-off & Certificate
              </h2>
              <p className="text-xs text-slate-500">
                Formal operational succession sign-off and token custody certification.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSignOffModalOpen(false)}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-md hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Certificate Body */}
        <div className="p-6 overflow-y-auto max-h-[60vh] space-y-6 text-xs text-slate-700 custom-scrollbar">
          {/* Certificate Card Preview */}
          <div className="bg-gradient-to-br from-slate-50 via-white to-blue-50/40 border-2 border-blue-500/30 rounded-xl p-5 space-y-4 text-center relative overflow-hidden shadow-sm">
            <div className="text-[11px] uppercase tracking-widest text-blue-700 font-bold">
              Apex Enterprise Solutions • Department of Finance & Treasury
            </div>
            <h3 className="text-lg font-extrabold text-slate-900">
              CERTIFICATE OF OPERATIONAL HANDOVER COMPLETION
            </h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              This certifies that the operational knowledge, banking matrix, reconciliation workflows, statutory tax calendars, and key passwords/tokens for the position of <strong className="text-slate-900">{data.employeeDetails.outgoingRole}</strong> have been successfully transitioned with a validated Readiness Index of <strong className="text-blue-700 font-bold">{completionRate}%</strong>.
            </p>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-200 text-[11px]">
              <div>
                <div className="text-slate-400 font-medium">Outgoing Lead</div>
                <div className="font-bold text-slate-900 mt-0.5">{data.employeeDetails.outgoingName}</div>
              </div>
              <div>
                <div className="text-slate-400 font-medium">Incoming Successor</div>
                <div className="font-bold text-blue-700 mt-0.5">{data.employeeDetails.successorName}</div>
              </div>
              <div>
                <div className="text-slate-400 font-medium">Reporting Manager</div>
                <div className="font-bold text-slate-900 mt-0.5">{data.employeeDetails.reportingManager}</div>
              </div>
            </div>
          </div>

          {/* Tripartite Confirmation Checkboxes */}
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Mandatory Signatory Confirmations
            </div>

            {/* 1. Outgoing Lead */}
            <label className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition">
              <input
                type="checkbox"
                checked={outgoingConfirmed}
                onChange={(e) => setOutgoingConfirmed(e.target.checked)}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 h-4 w-4 bg-white border-slate-300"
              />
              <div className="text-xs">
                <strong className="text-slate-900 block">
                  1. Outgoing Incumbent ({data.employeeDetails.outgoingName}):
                </strong>
                <span className="text-slate-500">
                  I certify that I have handed over all documented processes, master workbooks, banking relationship contacts, and scheduled the deactivation of my corporate banking privileges effective on my LWD ({data.employeeDetails.lastWorkingDay}).
                </span>
              </div>
            </label>

            {/* 2. Incoming Successor */}
            <label className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition">
              <input
                type="checkbox"
                checked={successorConfirmed}
                onChange={(e) => setSuccessorConfirmed(e.target.checked)}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 h-4 w-4 bg-white border-slate-300"
              />
              <div className="text-xs">
                <strong className="text-blue-700 block">
                  2. Incoming Successor ({data.employeeDetails.successorName}):
                </strong>
                <span className="text-slate-500">
                  I acknowledge receipt of the Role Bible, confirmed possession/provisioning of required system and banking authorizations, completed reverse shadowing sessions, and feel equipped to assume operational duties.
                </span>
              </div>
            </label>

            {/* 3. Reporting Manager / CFO */}
            <label className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition">
              <input
                type="checkbox"
                checked={managerConfirmed}
                onChange={(e) => setManagerConfirmed(e.target.checked)}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 h-4 w-4 bg-white border-slate-300"
              />
              <div className="text-xs">
                <strong className="text-slate-900 block">
                  3. Reporting Authority ({data.employeeDetails.reportingManager}):
                </strong>
                <span className="text-slate-500">
                  I approve the operational handover, endorse the successor's 30-60-90 day roadmap, and confirm compliance with corporate internal controls and signatory delegation policies.
                </span>
              </div>
            </label>
          </div>

          {/* Date Picker */}
          <div className="flex items-center space-x-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <Calendar className="h-4 w-4 text-blue-600" />
            <span className="font-semibold text-slate-700">Official Sign-off Effective Date:</span>
            <input
              type="date"
              value={signDate}
              onChange={(e) => setSignDate(e.target.value)}
              className="bg-white text-slate-900 font-bold px-3 py-1 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={handlePrintCertificate}
            className="inline-flex items-center px-3 py-2 rounded-md text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5 mr-1.5" />
            <span>Print Certificate</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsSignOffModalOpen(false)}
              className="px-3 py-2 rounded-md text-xs font-medium text-slate-600 hover:text-slate-900 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleExecuteSignOff}
              disabled={!allConfirmed}
              className={`px-4 py-2 rounded-md text-xs font-bold transition shadow-sm cursor-pointer ${
                allConfirmed
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              {data.employeeDetails.isSignedOff
                ? 'Update Sign-off Certification'
                : 'Execute Formal Tripartite Sign-off'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
