import React, { useState } from 'react';
import { useHandover } from '../context/HandoverContext';
import {
  Sparkles,
  X,
  Send,
  Loader2,
  BookOpen,
  FileText,
  Compass,
  ShieldCheck,
  CheckCircle,
  Copy,
} from 'lucide-react';

export const AIAssistantModal: React.FC = () => {
  const { isAiModalOpen, setIsAiModalOpen, data, applyAIGeneratedHandover } = useHandover();
  const [activeAction, setActiveAction] = useState<
    'audit_handover' | 'draft_sop' | 'generate_30_60_90' | 'generate_role_bible'
  >('audit_handover');
  const [promptInput, setPromptInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [parsedData, setParsedData] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isAiModalOpen) return null;

  const handleRunAI = async () => {
    setIsLoading(true);
    setAiResponse(null);
    setParsedData(null);

    try {
      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: activeAction,
          roleContext: {
            roleTitle: data.employeeDetails.outgoingRole,
            entity: data.employeeDetails.entityName,
            outgoing: data.employeeDetails.outgoingName,
            successor: data.employeeDetails.successorName,
            manager: data.employeeDetails.reportingManager,
          },
          currentData: data,
          customPrompt: promptInput,
        }),
      });

      const json = await res.json();
      if (json.text) {
        setAiResponse(json.text);
      }
      if (json.parsedData) {
        setParsedData(json.parsedData);
      }
    } catch (err: any) {
      setAiResponse(`Error generating AI transition analysis: ${err.message || err}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyToHub = () => {
    if (parsedData) {
      applyAIGeneratedHandover(parsedData);
      setIsAiModalOpen(false);
    }
  };

  const handleCopy = () => {
    if (aiResponse) {
      navigator.clipboard.writeText(aiResponse);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center space-x-2.5">
            <div className="h-9 w-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center space-x-2">
                <span>AI Finance Transition Copilot</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold border border-blue-200">
                  Gemini 2.5
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Specialized in Treasury, Statutory Filings, BRS Reconciliations & Succession Risk Auditing.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAiModalOpen(false)}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-md hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Action Selectors */}
        <div className="p-4 border-b border-slate-200 bg-white flex flex-wrap gap-2">
          <button
            onClick={() => setActiveAction('audit_handover')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeAction === 'audit_handover'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>Audit Handover Completeness</span>
          </button>

          <button
            onClick={() => setActiveAction('draft_sop')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeAction === 'draft_sop'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Draft Step-by-Step SOP</span>
          </button>

          <button
            onClick={() => setActiveAction('generate_30_60_90')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeAction === 'generate_30_60_90'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <Compass className="h-3.5 w-3.5" />
            <span>Generate 30-60-90 Roadmap</span>
          </button>

          <button
            onClick={() => setActiveAction('generate_role_bible')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeAction === 'generate_role_bible'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Generate Full Role Template</span>
          </button>
        </div>

        {/* Input & Prompt Area */}
        <div className="p-4 border-b border-slate-200 space-y-3 bg-slate-50">
          <label className="block text-xs font-bold text-slate-700">
            {activeAction === 'audit_handover'
              ? 'Target Focus (e.g. "Focus on banking tokens and GST penalty vulnerabilities")'
              : activeAction === 'draft_sop'
              ? 'Specify the Financial Procedure (e.g. "Month-end Intercompany Reconciliation and Transfer Pricing adjustments")'
              : activeAction === 'generate_30_60_90'
              ? 'Successor Level / Specific Goals (e.g. "Senior hire with SAP experience transitioning into APAC controller")'
              : 'Describe the Target Finance Role to generate a complete custom Handover Hub'}
          </label>

          <div className="flex gap-2">
            <input
              type="text"
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder={
                activeAction === 'draft_sop'
                  ? 'e.g. Daily Bank Reconciliation in SAP & Resolving Stripe Settlement Unmatched Items'
                  : 'Add custom requirements or leave blank to evaluate current package...'
              }
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleRunAI();
              }}
              className="flex-1 bg-white text-xs sm:text-sm text-slate-900 px-3 py-2 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
            <button
              onClick={handleRunAI}
              disabled={isLoading}
              className="inline-flex items-center px-4 py-2 rounded-md text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white transition shadow-sm cursor-pointer"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Send className="h-3.5 w-3.5 mr-1.5" />
                  <span>Execute</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* AI Output Viewport */}
        <div className="flex-1 p-5 overflow-y-auto max-h-[50vh] space-y-4 bg-white text-xs sm:text-sm text-slate-800 leading-relaxed custom-scrollbar">
          {isLoading && (
            <div className="py-12 flex flex-col items-center justify-center space-y-3 text-blue-600">
              <Loader2 className="h-8 w-8 animate-spin" />
              <div className="text-xs font-medium text-slate-500 animate-pulse">
                Consulting Financial Transition Intelligence Engine...
              </div>
            </div>
          )}

          {!isLoading && !aiResponse && (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Sparkles className="h-8 w-8 mx-auto text-slate-300" />
              <div className="font-medium text-xs">
                Select an AI action above and click <strong>Execute</strong> to generate audit findings, SOPs, or 30-60-90 plans.
              </div>
            </div>
          )}

          {aiResponse && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
                  AI Copilot Output
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopy}
                    className="inline-flex items-center text-xs text-slate-600 hover:text-slate-900 px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 border border-slate-200 transition cursor-pointer"
                  >
                    <Copy className="h-3 w-3 mr-1" />
                    <span>{copied ? 'Copied!' : 'Copy Text'}</span>
                  </button>
                  {parsedData && (
                    <button
                      onClick={handleApplyToHub}
                      className="inline-flex items-center text-xs font-bold text-white hover:bg-emerald-700 px-2.5 py-1 rounded bg-emerald-600 border border-emerald-600 transition cursor-pointer"
                    >
                      <CheckCircle className="h-3.5 w-3.5 mr-1 text-white" />
                      <span>Apply Directly to Hub</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm text-slate-800 bg-slate-50 p-4 rounded-xl border border-slate-200">
                {aiResponse}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
