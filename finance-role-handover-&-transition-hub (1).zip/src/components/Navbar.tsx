import React, { useState } from 'react';
import { useHandover } from '../context/HandoverContext';
import { rolePresets } from '../data/rolePresets';
import {
  Sparkles,
  Printer,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  BookOpen,
  Search,
  SlidersHorizontal,
  ChevronDown,
  Building2,
  Calendar,
  ShieldCheck,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    data,
    updateData,
    loadPreset,
    resetToDefault,
    completionRate,
    completedChecklistCount,
    totalChecklistCount,
    searchQuery,
    setSearchQuery,
    setActiveTab,
    setIsAiModalOpen,
    setIsSignOffModalOpen,
  } = useHandover();

  const [showPresetsMenu, setShowPresetsMenu] = useState(false);

  const handleExportJSON = () => {
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(data, null, 2)
    )}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute(
      'download',
      `Finance_Role_Handover_${data.employeeDetails.outgoingRole.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files[0]) {
      fileReader.readAsText(event.target.files[0], 'UTF-8');
      fileReader.onload = (e) => {
        try {
          const parsed = JSON.parse(e.target?.result as string);
          if (parsed && parsed.employeeDetails) {
            updateData(parsed);
            alert('Handover Dossier successfully imported!');
          }
        } catch (err) {
          alert('Invalid JSON file format.');
        }
      };
    }
  };

  return (
    <header className="bg-white text-slate-900 border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Logo & Entity info */}
          <div className="flex items-center space-x-3 min-w-0">
            <div className="h-10 w-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-sm shrink-0">
              T
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight text-slate-900 truncate">
                  Finance Role Succession: {data.employeeDetails.outgoingName}
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  ACTIVE
                </span>
              </div>
              <div className="flex items-center space-x-3 text-xs text-slate-500 mt-0.5 font-medium tracking-wide">
                <span>Dept: <strong className="text-slate-700">{data.employeeDetails.department}</strong></span>
                <span className="w-px h-3 bg-slate-300"></span>
                <span>LWD: <strong className="text-slate-700">{data.employeeDetails.lastWorkingDay}</strong></span>
                <span className="w-px h-3 bg-slate-300 hidden sm:inline-block"></span>
                <span className="hidden sm:inline">Manager: <strong className="text-slate-700">{data.employeeDetails.reportingManager}</strong></span>
              </div>
            </div>
          </div>

          {/* Quick Stats & Search */}
          <div className="hidden lg:flex items-center space-x-4 flex-1 max-w-sm mx-4">
            <div className="relative w-full">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search SOPs, bank protocols, recs..."
                className="w-full bg-slate-100 text-sm text-slate-900 pl-9 pr-4 py-1.5 rounded-lg border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 placeholder-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-xs text-slate-400 hover:text-slate-700"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Actions & Completion Meter */}
          <div className="flex items-center space-x-3">
            {/* Completion Meter */}
            <div className="hidden sm:flex flex-col items-end">
              <div className="flex items-center space-x-1.5">
                <span className="text-xs text-slate-500 font-medium">Readiness:</span>
                <span
                  className={`text-xs font-bold ${
                    completionRate >= 80
                      ? 'text-emerald-600'
                      : completionRate >= 50
                      ? 'text-blue-600'
                      : 'text-amber-600'
                  }`}
                >
                  {completionRate}%
                </span>
              </div>
              <div className="w-24 bg-slate-200 rounded-full h-1.5 mt-1 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500 bg-blue-600"
                  style={{ width: `${completionRate}%` }}
                />
              </div>
            </div>

            {/* AI Assistant Button */}
            <button
              onClick={() => setIsAiModalOpen(true)}
              className="inline-flex items-center px-3.5 py-2 rounded-md text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition-all cursor-pointer"
              title="Open AI Finance Copilot"
            >
              <Sparkles className="h-3.5 w-3.5 mr-1.5" />
              <span>AI Copilot</span>
            </button>

            {/* Presets Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowPresetsMenu(!showPresetsMenu)}
                className="inline-flex items-center px-3 py-2 rounded-md text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
              >
                <SlidersHorizontal className="h-3.5 w-3.5 mr-1 text-slate-500" />
                <span className="hidden sm:inline">Role Presets</span>
                <ChevronDown className="h-3.5 w-3.5 ml-1 text-slate-500" />
              </button>

              {showPresetsMenu && (
                <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-xl py-2 z-50">
                  <div className="px-3 py-1 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Select Finance Role Template
                  </div>
                  {rolePresets.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => {
                        loadPreset(preset.id);
                        setShowPresetsMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition flex flex-col cursor-pointer"
                    >
                      <span className="font-semibold text-slate-900">{preset.roleName}</span>
                      <span className="text-slate-500 text-[11px] line-clamp-1">{preset.description}</span>
                    </button>
                  ))}
                  <div className="border-t border-slate-100 my-1"></div>
                  <button
                    onClick={() => {
                      if (confirm('Reset all changes back to initial default dataset?')) {
                        resetToDefault();
                        setShowPresetsMenu(false);
                      }
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 transition flex items-center space-x-1.5 cursor-pointer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Reset to Default Template</span>
                  </button>
                </div>
              )}
            </div>

            {/* Master Role Bible View Button */}
            <button
              onClick={() => setActiveTab('role-bible')}
              className="inline-flex items-center px-3.5 py-2 rounded-md text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-sm transition cursor-pointer"
              title="View Unified Role Bible Master Document"
            >
              <BookOpen className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden md:inline">Role Bible</span>
            </button>

            {/* Formal Sign-off Button */}
            <button
              onClick={() => setIsSignOffModalOpen(true)}
              className={`inline-flex items-center px-3 py-2 rounded-md text-xs font-medium border transition cursor-pointer ${
                data.employeeDetails.isSignedOff
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
              title="Official Handover Sign-off Certificate"
            >
              <ShieldCheck className={`h-3.5 w-3.5 mr-1.5 ${data.employeeDetails.isSignedOff ? 'text-emerald-600' : 'text-slate-500'}`} />
              <span className="hidden sm:inline">{data.employeeDetails.isSignedOff ? 'Signed Off' : 'Sign Off'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
