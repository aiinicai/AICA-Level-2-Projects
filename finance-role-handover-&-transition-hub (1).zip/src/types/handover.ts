export type TaskFrequency = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annual' | 'ad-hoc';

export type HandoverStatus = 'not-started' | 'in-progress' | 'shadowing' | 'reverse-shadowed' | 'completed';

export interface EmployeeDetails {
  outgoingName: string;
  outgoingRole: string;
  outgoingEmail: string;
  outgoingPhone: string;
  department: string;
  lastWorkingDay: string;
  reportingManager: string;
  managerEmail: string;
  successorName: string;
  successorRole: string;
  successorEmail: string;
  handoverStartDate: string;
  handoverEndDate: string;
  location: string;
  entityName: string;
  isSignedOff: boolean;
  signOffDate?: string;
}

export interface RoleOverview {
  primaryObjective: string;
  keyResponsibilities: string[];
  kpis: {
    name: string;
    target: string;
    frequency: string;
    measurementSource: string;
  }[];
  reportingStructure: {
    reportsTo: string;
    directReports: string[];
    peerRoles: string[];
    escalationContact: string;
  };
}

export interface ProcessTask {
  id: string;
  title: string;
  frequency: TaskFrequency;
  timingDescription: string; // e.g., "Daily by 11:00 AM" or "Day 1-3 of month"
  systemsUsed: string[];
  deliverable: string;
  dependencies: string;
  sopId?: string;
  status: HandoverStatus;
  notes: string;
}

export interface SOPItem {
  id: string;
  title: string;
  category: 'Banking & Treasury' | 'Reconciliation' | 'Statutory & Tax' | 'Accounts Payable' | 'Accounts Receivable' | 'General Ledger' | 'Payroll & Compliance';
  frequency: TaskFrequency;
  estimatedTime: string;
  prerequisites: string[];
  stepByStepInstructions: string[];
  keyControls: string[];
  commonPitfalls: string[];
  whatNotToDo: string[];
  outputDeliverable: string;
  relatedSystems: string[];
  sampleTemplatePath?: string;
}

export interface BankingCredentialItem {
  id: string;
  bankName: string;
  accountNumberMasked: string;
  accountType: 'Operating Account' | 'Disbursement' | 'Collection / Escrow' | 'Statutory Taxes' | 'Foreign Currency (EEFC)';
  currency: string;
  portalUrl: string;
  corporateId: string;
  signatoryTier: 'Tier 1 (Sole >$100k)' | 'Tier 2 (Dual >$25k)' | 'Tier 3 (Initiator / Maker)' | 'Checker / Approver' | 'Viewer / Auditor';
  dualAuthLimit: string;
  tokenType: 'Hardware RSA Token' | 'Mobile App OTP / Authenticator' | 'Digital Signature Certificate (DSC)' | 'SMS OTP';
  tokenCustodyProcedure: string;
  accessDeactivationProcess: string;
  newHireProvisioningSteps: string;
  relationshipManager: {
    name: string;
    phone: string;
    email: string;
  };
  escalationHotline: string;
}

export interface ReconciliationWorkflow {
  id: string;
  name: string;
  type: 'Bank Rec (BRS)' | 'GL vs Subledger (AP/AR)' | 'Intercompany' | 'Payment Gateway vs Bank' | 'Fixed Asset Register (FAR)' | 'Statutory Ledgers vs Challans' | 'Inventory vs GL';
  frequency: 'Daily' | 'Weekly' | 'Monthly';
  sourceSystems: string[];
  primaryReconciliationSteps: string[];
  discrepancyThreshold: string;
  disputeResolutionProcess: string;
  journalEntryRules: string;
  cutoffDay: string;
  sampleWorkbookLocation: string;
  status: HandoverStatus;
}

export interface StatutoryTaxDeadline {
  id: string;
  taxName: string;
  category: 'GST / Indirect Tax' | 'TDS / Withholding' | 'Corporate Income Tax' | 'Payroll Statutory (PF/ESI/PT)' | 'Advance Tax' | 'Annual Statutory Audit & Filings';
  dueDayRule: string; // e.g. "7th of following month", "20th of month", "15th June/Sept/Dec/Mar"
  nextDueDate: string;
  filingPortal: string;
  portalLoginMethod: string; // "DSC Token of Director", "Authorized Signatory Credentials", "Portal User ID"
  penaltyRisk: string;
  stepSummary: string[];
  responsibleRole: string;
  approverRole: string;
  status: 'Compliant' | 'Pending Current Period' | 'Action Required';
}

export interface SystemTool {
  id: string;
  systemName: string;
  purpose: string;
  accessUrl: string;
  roleProfileRequired: string;
  howToRequestAccess: string;
  adminContact: string;
  keyReportsExtracted: {
    reportName: string;
    menuPath: string;
    frequency: string;
    purpose: string;
  }[];
  status: HandoverStatus;
}

export interface DataManagement {
  folderStructure: {
    driveName: string;
    rootPath: string;
    subFolders: string[];
    description: string;
  }[];
  namingConventions: {
    fileType: string;
    formatPattern: string;
    example: string;
  }[];
  criticalFileLocations: {
    documentName: string;
    path: string;
    accessPermission: string;
  }[];
  backupAndArchival: string;
}

export interface Stakeholder {
  id: string;
  name: string;
  role: string;
  departmentOrOrg: string;
  type: 'Internal' | 'External';
  email: string;
  phone: string;
  relationshipContext: string;
  cadence: string; // e.g. "Weekly Catchup", "Monthly Close", "Quarterly Audit"
  keyInteractions: string;
}

export interface OngoingTask {
  id: string;
  taskTitle: string;
  projectOrCategory: string;
  status: 'Not Started' | 'In Progress' | 'Under Review' | 'Blocked' | 'Completed';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  deadline: string;
  dependencies: string;
  pendingWith: string;
  handoverNotes: string;
  actionRequiredBySuccessor: string;
}

export interface KnownRisk {
  id: string;
  category: 'Cash Flow & Banking' | 'Reconciliation & Books' | 'Statutory & Deadlines' | 'Vendor / Customer Dispute' | 'System & Data Gaps';
  knownIssue: string;
  impactLevel: 'Critical' | 'High' | 'Medium';
  workaround: string;
  criticalCutoffTiming: string;
  whatNotToDo: string;
}

export interface ComplianceControl {
  id: string;
  controlTitle: string;
  framework: 'Internal Financial Controls (IFC)' | 'Statutory Audit' | 'Delegation of Authority (DoA)' | 'Tax Audit' | 'Banking & Treasury Control';
  description: string;
  approvalMatrixRule: string;
  auditEvidenceLocation: string;
  penaltiesOrConsequences: string;
}

export interface HandoverTimelineDay {
  id: string;
  phase: 'Phase 1: Orientation & System Setup' | 'Phase 2: Shadowing Live Operations' | 'Phase 3: Reverse Shadowing & Supervised Handling' | 'Phase 4: Independent Sign-off';
  timeframe: string; // e.g. "Day 1-3", "Week 2", "Day 10-14"
  focusAreas: string[];
  tasksToCover: string[];
  successCriteria: string;
  completed: boolean;
}

export interface KnowledgeNote {
  id: string;
  category: 'Pro Tips & Hacks' | 'Frequently Asked Questions (FAQs)' | 'Email & Communication Templates' | 'Past Audit Queries';
  title: string;
  content: string;
  sampleCodeOrText?: string;
}

export interface ManagerAlignment {
  newJoinerExpectations: string[];
  first30DaysPlan: {
    focus: string;
    milestones: string[];
    checkpointDate: string;
  };
  first60DaysPlan: {
    focus: string;
    milestones: string[];
    checkpointDate: string;
  };
  first90DaysPlan: {
    focus: string;
    milestones: string[];
    checkpointDate: string;
  };
  evaluationCriteria: string[];
  managerNotes: string;
}

export interface HandoverPackage {
  id: string;
  title: string;
  lastUpdated: string;
  employeeDetails: EmployeeDetails;
  roleOverview: RoleOverview;
  processTasks: ProcessTask[];
  sops: SOPItem[];
  bankingCredentials: BankingCredentialItem[];
  reconciliationWorkflows: ReconciliationWorkflow[];
  taxDeadlines: StatutoryTaxDeadline[];
  systemTools: SystemTool[];
  dataManagement: DataManagement;
  stakeholders: Stakeholder[];
  ongoingTasks: OngoingTask[];
  knownRisks: KnownRisk[];
  complianceControls: ComplianceControl[];
  handoverTimeline: HandoverTimelineDay[];
  knowledgeNotes: KnowledgeNote[];
  managerAlignment: ManagerAlignment;
}
