import { HandoverPackage } from '../types/handover';

export const initialHandoverPackage: HandoverPackage = {
  id: 'finance-lead-2026',
  title: 'Finance & Accounts Lead - Complete Transition Dossier',
  lastUpdated: new Date().toISOString().split('T')[0],
  employeeDetails: {
    outgoingName: 'Priya Sharma, CA',
    outgoingRole: 'Senior Finance & Accounts Lead',
    outgoingEmail: 'priya.sharma@enterprise.com',
    outgoingPhone: '+1 (555) 382-9910',
    department: 'Finance, Treasury & Taxation',
    lastWorkingDay: '2026-09-15',
    reportingManager: 'Alexander Wright (Chief Financial Officer)',
    managerEmail: 'alexander.wright@enterprise.com',
    successorName: 'Rohan Mehta, CPA',
    successorRole: 'Incoming Finance & Accounts Lead',
    successorEmail: 'rohan.mehta@enterprise.com',
    handoverStartDate: '2026-08-25',
    handoverEndDate: '2026-09-14',
    location: 'Headquarters - Financial District / Hybrid',
    entityName: 'Apex Enterprise Solutions Global Inc.',
    isSignedOff: false,
  },
  roleOverview: {
    primaryObjective:
      'Lead end-to-end financial operations, monthly close cycles, statutory and tax compliance, treasury banking relationships, and audit governance with zero operational downtime.',
    keyResponsibilities: [
      'Orchestrate 5-day Month-End Close cycle across GL, AP, AR, Fixed Assets, and Intercompany ledgers.',
      'Maintain primary custody and dual-signatory authority across multi-currency corporate bank accounts and treasury sweeps.',
      'Supervise statutory compliance filings (GST/VAT, TDS/Withholding, Corporate Advance Tax, Payroll Statutory).',
      'Lead preparation of Balance Sheet Reconciliation file (Blackline / Excel master) and resolve ledger-subledger variances.',
      'Serve as key point of contact for Big 4 statutory auditors, internal audit teams, tax authorities, and banking partners.',
      'Review and enforce Delegation of Authority (DoA) matrices, vendor payment batches, and customer credit limits.',
    ],
    kpis: [
      {
        name: 'Month-End Close Timeliness',
        target: '<= 5 Business Days post month-end (WD+5)',
        frequency: 'Monthly',
        measurementSource: 'ERP Close Log & CFO Dashboard',
      },
      {
        name: 'Bank & GL Reconciliation Accuracy',
        target: '100% unreconciled items cleared within 7 days; $0 unverified variance',
        frequency: 'Monthly',
        measurementSource: 'BRS Master Schedule & Ledger Audit',
      },
      {
        name: 'Statutory & Tax Compliance Track Record',
        target: '100% on-time filings (Zero penalty, Zero late-fee notices)',
        frequency: 'Monthly / Quarterly',
        measurementSource: 'Government Portal Challans & Returns',
      },
      {
        name: 'Vendor Invoice Processing SLA',
        target: '98% of clean invoices paid within agreed payment terms (Net 30/45)',
        frequency: 'Weekly',
        measurementSource: 'AP Aging & Vendor Payment Register',
      },
    ],
    reportingStructure: {
      reportsTo: 'Alexander Wright (Chief Financial Officer)',
      directReports: [
        'Ananya Sen (Accounts Payable Executive)',
        'Marcus Vance (Senior GL & Fixed Assets Accountant)',
        'Sneha Roy (Billing & Accounts Receivable Specialist)',
      ],
      peerRoles: [
        'David Chen (Head of FP&A)',
        'Elena Rostova (Legal & Corporate Secretarial Head)',
        'Sarah Jenkins (Global HR Operations Lead)',
      ],
      escalationContact: 'Alexander Wright (CFO) & Internal Audit Director',
    },
  },
  processTasks: [
    {
      id: 'pt-1',
      title: 'Daily Treasury Cash Position & Sweeps Review',
      frequency: 'daily',
      timingDescription: 'Every morning by 10:30 AM EST',
      systemsUsed: ['J.P. Morgan Access Portal', 'SAP S/4HANA', 'Kyriba Treasury'],
      deliverable: 'Consolidated Daily Cash Dashboard & Intercompany Sweep confirmation',
      dependencies: 'Prior day end-of-day bank statement feed',
      sopId: 'sop-1',
      status: 'completed',
      notes: 'Ensure target operating balance of $2.5M in main disbursement account before 11:00 AM wire run.',
    },
    {
      id: 'pt-2',
      title: 'Critical Vendor Payment Batch Release (Dual Signatory)',
      frequency: 'daily',
      timingDescription: 'Cut-off at 2:00 PM EST daily',
      systemsUsed: ['Bank Portal / RSA Token', 'SAP AP Approval Workflow'],
      deliverable: 'Released wire/ACH batches & payment advice dispatch',
      dependencies: '3-way matched AP invoices with Level 2 manager sign-off',
      sopId: 'sop-2',
      status: 'shadowing',
      notes: 'Wires >$50k require secondary mobile OTP from CFO. Check beneficiary bank details if updated recently.',
    },
    {
      id: 'pt-3',
      title: 'Weekly AP Aging Review & Cash Outflow Forecast',
      frequency: 'weekly',
      timingDescription: 'Every Tuesday by 3:00 PM',
      systemsUsed: ['SAP S/4HANA (FBL1N / FAGLL03)', 'Power BI Cash Planner'],
      deliverable: 'Weekly 13-Week Cash Burn & Scheduled Outflow Deck',
      dependencies: 'AP ledger run and approved purchase orders from Procurement',
      sopId: 'sop-2',
      status: 'in-progress',
      notes: 'Highlight any vendor overdue balances > 60 days to Procurement Head.',
    },
    {
      id: 'pt-4',
      title: 'Monthly Balance Sheet & Bank Reconciliation (BRS) Close',
      frequency: 'monthly',
      timingDescription: 'Working Day +2 to +4 of every calendar month',
      systemsUsed: ['SAP GL', 'Excel Rec Master', 'Bank MT940 / CAMT.053 files'],
      deliverable: 'Signed BRS Dossier & Balance Sheet Schedules for CFO Review',
      dependencies: 'GL freeze, AP/AR cut-off, and final bank statements',
      sopId: 'sop-3',
      status: 'reverse-shadowed',
      notes: 'All items outstanding > 30 days require written explanatory memo.',
    },
    {
      id: 'pt-5',
      title: 'Monthly Recurring Tax & Withholding Return Filings (TDS/GST)',
      frequency: 'monthly',
      timingDescription: 'By 7th (TDS) and 20th (GST/Sales Tax) of each month',
      systemsUsed: ['ClearTax Enterprise', 'Statutory Tax Portals', 'Bank Tax Challan Gateway'],
      deliverable: 'Challan BSR receipts & filed GSTR-3B / TDS Returns',
      dependencies: 'Tax deduction ledger vs ERP books reconciliation',
      sopId: 'sop-4',
      status: 'shadowing',
      notes: 'Strict statutory cut-off: Delay leads to 1.5% monthly compounding interest and late fees.',
    },
    {
      id: 'pt-6',
      title: 'Quarterly Advance Corporate Income Tax Calculation',
      frequency: 'quarterly',
      timingDescription: '15th of June, September, December, and March',
      systemsUsed: ['P&L Forecast Model', 'Statutory Income Tax Portal'],
      deliverable: 'Advance tax challan payment receipt and board tax memo',
      dependencies: 'FP&A year-end projected EBITDA and tax depreciation schedules',
      sopId: 'sop-4',
      status: 'in-progress',
      notes: 'Ensure minimum 45% of total annual tax paid by Sept 15 installment.',
    },
  ],
  sops: [
    {
      id: 'sop-1',
      title: 'Daily Bank Reconciliation & Cash Flow Positioning SOP',
      category: 'Banking & Treasury',
      frequency: 'daily',
      estimatedTime: '45 mins',
      prerequisites: [
        'J.P. Morgan Access & Citibank Portal token login credentials',
        'SAP S/4HANA Treasury module access (Transaction: FF67 / FEBAN)',
        'Updated Daily Cash Position Excel Model',
      ],
      stepByStepInstructions: [
        'Step 1: Log into J.P. Morgan Access and Citibank portal at 08:30 AM; extract previous day closing MT940 statement.',
        'Step 2: Upload statement into SAP automated bank statement feeder (FEBAN) to run auto-clearing for customer deposits and automated direct debits.',
        'Step 3: Identify unassigned collections, verify UTR / customer remittance advice against open AR invoices in FBL5N, and post clearing entries.',
        'Step 4: Update the Daily Cash Spreadsheet with bank balances, calculate net liquidity, and determine if an intercompany treasury sweep or money market draw is needed.',
        'Step 5: Send morning cash liquidity summary email to CFO and Treasury Director by 10:30 AM.',
      ],
      keyControls: [
        'Never post unallocated funds directly to revenue without verified customer remittance documentation.',
        'Verify that the bank statement closing balance matches SAP GL Account 110100 exactly.',
        'Obtain CFO approval for any inter-account transfer exceeding $250,000.',
      ],
      commonPitfalls: [
        'Bank fees or merchant processing fees left in transit without being expensed daily.',
        'Currency conversion differences posted to wrong FX Gain/Loss GL.',
      ],
      whatNotToDo: [
        'DO NOT share bank portal OTP or hardware token with junior staff under any circumstance.',
        'DO NOT bypass the dual authorization queue even during urgent vendor calls.',
      ],
      outputDeliverable: 'Signed Daily Liquidity Report and verified SAP Bank Clearing Ledger.',
      relatedSystems: ['J.P. Morgan Portal', 'SAP Treasury', 'Citibank Online'],
      sampleTemplatePath: 'Shared Drive > Finance > Treasury > Templates > Daily_Cash_Position_2026.xlsx',
    },
    {
      id: 'sop-2',
      title: 'Vendor Payment Run & Dual-Authorization Sign-Off SOP',
      category: 'Accounts Payable',
      frequency: 'weekly',
      estimatedTime: '2 hours',
      prerequisites: [
        'SAP AP Payment Proposal (Transaction F110)',
        'Approved Invoice 3-Way Match Audit trail with Purchase Order and Goods Receipt Note (GRN)',
        'Valid Tax Invoice & MSME / 1099 compliance validation',
      ],
      stepByStepInstructions: [
        'Step 1: Execute SAP F110 payment run proposal for due items with invoice due date <= current week Friday.',
        'Step 2: Review exception list for blocked payments, missing vendor bank details, or mismatched currency rates.',
        'Step 3: Export Payment Proposal register, cross-verify bank beneficiary details against approved Vendor Master (FK03).',
        'Step 4: Generate XML / ISO 20022 payment batch file and upload to corporate banking portal.',
        'Step 5: Primary Maker (Finance Lead) authorizes batch using RSA Hardware Token 1.',
        'Step 6: Trigger automated notification to Secondary Approver (CFO / Director) for Tier 2 biometric approval.',
        'Step 7: Confirm successful processing status on bank portal; trigger automated payment advice dispatch to vendors.',
      ],
      keyControls: [
        'Mandatory dual-signatory verification for all payment batches > $25,000.',
        'Any modification in vendor bank account details requires independent verbal callback verification via verified corporate switchboard number before payment approval.',
      ],
      commonPitfalls: [
        'Duplicate invoice posting due to slight variation in invoice numbering format.',
        'Applying wrong withholding tax / TDS section leading to statutory penalty.',
      ],
      whatNotToDo: [
        'DO NOT accept vendor bank account changes over unverified email or PDF attachments.',
        'DO NOT release payments on proforma invoices or quotes without final tax invoice.',
      ],
      outputDeliverable: 'Bank Transmittal Acknowledgment, SAP Payment Log, and Vendor Advice Dispatches.',
      relatedSystems: ['SAP S/4HANA', 'J.P. Morgan Access', 'Coupa Invoicing'],
      sampleTemplatePath: 'Shared Drive > Finance > AP > Payment_Batch_Checklist_v4.pdf',
    },
    {
      id: 'sop-3',
      title: 'Month-End Balance Sheet & Subledger Reconciliation SOP',
      category: 'Reconciliation',
      frequency: 'monthly',
      estimatedTime: '1.5 days',
      prerequisites: [
        'All subledger cutoffs completed (AP F110, AR Billing, Fixed Assets Depreciation AFAB)',
        'Accruals and prepaid amortization journal entries posted',
        'Master Balance Sheet Schedule Template',
      ],
      stepByStepInstructions: [
        'Step 1: Extract Trial Balance from SAP (F.01) and verify GL balance matches AP Subledger (FBL1N) and AR Subledger (FBL5N).',
        'Step 2: Reconcile all Bank Accounts (Operating, Payroll, Escrow) against bank statements; prepare 3-column BRS schedule.',
        'Step 3: Execute Intercompany balance reconciliation with European & APAC entities; resolve transfer pricing & clearing variance.',
        'Step 4: Review Fixed Asset Register (FAR) roll-forward vs General Ledger Asset accounts (Cost, Accumulated Depr, Net Book Value).',
        'Step 5: Populate Blackline / Excel reconciliation workbook with supporting documents, signed approvals, and variance explanations.',
        'Step 6: Present completed Balance Sheet file to CFO for final sign-off by Working Day +4 at 5:00 PM.',
      ],
      keyControls: [
        'Every single balance sheet account must have an active owner and supporting documentation.',
        'Zero manual adjustment entries allowed directly into control accounts without written CFO sign-off.',
      ],
      commonPitfalls: [
        'Timing differences in intercompany foreign exchange settlements.',
        'Unclaimed input tax credits or unposted credit notes sitting in suspense.',
      ],
      whatNotToDo: [
        'DO NOT roll over reconciling items across consecutive months without investigating root cause.',
        'DO NOT close subledgers before verifying all transit entries are accounted for.',
      ],
      outputDeliverable: 'Fully Reconciled Balance Sheet Master File signed by Preparer, Reviewer, and CFO.',
      relatedSystems: ['SAP S/4HANA', 'Blackline', 'Excel Rec Hub'],
      sampleTemplatePath: 'Shared Drive > Finance > Month_End_Close > Rec_Master_Workbook_2026.xlsx',
    },
    {
      id: 'sop-4',
      title: 'Statutory Tax Return Filing & Challan Reconciliation SOP',
      category: 'Statutory & Tax',
      frequency: 'monthly',
      estimatedTime: '3 hours',
      prerequisites: [
        'Purchases Register vs Vendor GSTR-2B / 1099 tax portal ledger',
        'Withholding / TDS calculation register extracted from AP ledger',
        'Director Digital Signature Certificate (DSC) / Token',
      ],
      stepByStepInstructions: [
        'Step 1: Extract monthly Sales Register (Outward Tax) and Purchase Register (Inward Input Credit) from SAP.',
        'Step 2: Match Input Tax Credit (ITC) with Government Tax Portal data; flag unmatched vendor invoices to AP team.',
        'Step 3: Compute net statutory liability after setting off eligible credits; prepare payment challan on government tax portal.',
        'Step 4: Initiate payment via Net Banking / Authorizer token; download and archive the official BSR Challan receipt.',
        'Step 5: Upload finalized monthly return (GSTR-3B / Withholding summary) on tax portal; sign using Director DSC token.',
        'Step 6: Post statutory payment clearing entry in SAP GL account 220100 with BSR Challan reference number.',
      ],
      keyControls: [
        'Verification of Input Tax Credit eligibility prior to claim (no blocked credits claimed).',
        'Mandatory double verification of Challan BSR code and CIN number before GL posting.',
      ],
      commonPitfalls: [
        'Filing on the last day causing server latency and potential penalty triggers.',
        'Interest calculations missed for delayed reverse charge liability.',
      ],
      whatNotToDo: [
        'DO NOT submit final return before completing 100% challan payment confirmation.',
        'DO NOT claim input tax credit for vendors whose status shows "Inactive" on the portal.',
      ],
      outputDeliverable: 'Official Return Filing Acknowledgment Receipt, Payment Challan, and SAP Clearing Entry.',
      relatedSystems: ['ClearTax', 'Government Statutory Tax Portal', 'J.P. Morgan Tax Gateway'],
      sampleTemplatePath: 'Shared Drive > Finance > Tax_Compliance > Monthly_Tax_Summary_2026.xlsx',
    },
  ],
  bankingCredentials: [
    {
      id: 'bank-1',
      bankName: 'JPMorgan Chase Bank, N.A.',
      accountNumberMasked: '•••• •••• 8842',
      accountType: 'Operating Account',
      currency: 'USD ($)',
      portalUrl: 'https://access.jpmorgan.com',
      corporateId: 'CORP_APEX_GLOBAL_01',
      signatoryTier: 'Tier 2 (Dual >$25k)',
      dualAuthLimit: '$50,000 USD (Dual approval required above $50k; Sole up to $50k)',
      tokenType: 'Hardware RSA Token',
      tokenCustodyProcedure:
        'RSA Token Serial #RSA-99420-US currently in physical custody of Outgoing Lead. Safe transfer protocol: Token to be handed over in-person to Incoming Lead during Phase 3, along with safe combination for treasury lockbox.',
      accessDeactivationProcess:
        'HR/IT tickets generated on LWD (Ticket #IT-88421). Corporate Security deactivates Outgoing User ID: priya.sharma@enterprise.com on Sept 15, 2026 at 18:00 EST.',
      newHireProvisioningSteps:
        'Submit Bank Mandate Form B-4 with Board Resolution extract signed by CFO. JPMC Relationship Manager will dispatch new hardware token via courier to Rohan Mehta within 4 business days.',
      relationshipManager: {
        name: 'Catherine Sterling (Vice President, Global Treasury Management)',
        phone: '+1 (212) 555-0199',
        email: 'catherine.sterling@jpmorgan.com',
      },
      escalationHotline: 'JPMC Executive Treasury Care: 1-800-555-4321 (Code: APEX-990)',
    },
    {
      id: 'bank-2',
      bankName: 'Citibank N.A. (International)',
      accountNumberMasked: '•••• •••• 3109',
      accountType: 'Disbursement',
      currency: 'EUR (€) / Multi-Currency',
      portalUrl: 'https://citidirect.citigroup.com',
      corporateId: 'CITI_APEX_EUR_99',
      signatoryTier: 'Checker / Approver',
      dualAuthLimit: '€25,000 EUR (All outward cross-border SWIFT transfers require Checker sign-off)',
      tokenType: 'Mobile App OTP / Authenticator',
      tokenCustodyProcedure:
        'CitiDirect Mobile App Authenticator installed on company iPhone. Profile migration form submitted to Citi Treasury Operations on Aug 26.',
      accessDeactivationProcess:
        'Portal admin Alex Wright removes CitiDirect user profile on LWD. Confirmation email archived in Compliance repository.',
      newHireProvisioningSteps:
        'Rohan Mehta to download CitiDirect Mobile App on corporate device; scan activation QR code dispatched by Citi Corporate Onboarding team.',
      relationshipManager: {
        name: 'Julian Thorne (Director, Corporate Banking)',
        phone: '+44 20 7986 5500',
        email: 'julian.thorne@citi.com',
      },
      escalationHotline: 'CitiDirect Helpdesk: +1 (800) 888-8282 (24/7 Global Desk)',
    },
    {
      id: 'bank-3',
      bankName: 'Silicon Valley Bank / First Citizens',
      accountNumberMasked: '•••• •••• 4490',
      accountType: 'Collection / Escrow',
      currency: 'USD ($)',
      portalUrl: 'https://online.svb.com',
      corporateId: 'SVB_APEX_ESCROW',
      signatoryTier: 'Viewer / Auditor',
      dualAuthLimit: 'View-Only Access (Automated daily sweep to JPMC Operating Account at 17:00 EST)',
      tokenType: 'SMS OTP',
      tokenCustodyProcedure: 'Configured on company corporate SIM card. SIM handover scheduled for Sept 14.',
      accessDeactivationProcess: 'Admin user modification request queued for Sept 15.',
      newHireProvisioningSteps: 'Portal admin adds new user profile with Read-Only and Statement Extraction rights.',
      relationshipManager: {
        name: 'Danielle Brooks (Treasury Advisor)',
        phone: '+1 (408) 555-8833',
        email: 'dbrooks@svb.com',
      },
      escalationHotline: 'SVB Commercial Client Service: 1-800-774-7390',
    },
  ],
  reconciliationWorkflows: [
    {
      id: 'rec-1',
      name: 'Daily & Month-End Bank Reconciliation Statement (BRS)',
      type: 'Bank Rec (BRS)',
      frequency: 'Daily',
      sourceSystems: ['SAP S/4HANA (GL 110100, 110101)', 'Bank MT940 / CAMT.053 feeds'],
      primaryReconciliationSteps: [
        'Extract un-cleared bank transit items from SAP Transaction FEBAN and FBL3N.',
        'Match incoming customer ACH/Wires against open AR invoices; book unidentified receipts in Suspense GL 119999 with 48-hour clearance rule.',
        'Reconcile issued un-presented checks / outward wires against bank clearing statement.',
        'Calculate Net Bank Balance vs General Ledger Balance; prepare 3-part BRS reconciliation report.',
      ],
      discrepancyThreshold: '$0.00 unverified difference allowed at month-end close.',
      disputeResolutionProcess:
        'If bank fee or debit error detected: log case with Bank Relationship Manager within 24 hours. Post temporary accrual to suspense account.',
      journalEntryRules:
        'Debit Bank Clearing GL (110101) and Credit Main Bank GL (110100) upon statement confirmation. Bank charges posted to GL 640100.',
      cutoffDay: 'Daily by 11:00 AM; Month-end final sign-off by WD+2.',
      sampleWorkbookLocation: 'Finance Shared Drive > Reconciliations > Bank_Rec_2026 > Monthly_BRS_Consolidated.xlsx',
      status: 'completed',
    },
    {
      id: 'rec-2',
      name: 'General Ledger vs Accounts Payable (AP) Subledger',
      type: 'GL vs Subledger (AP/AR)',
      frequency: 'Monthly',
      sourceSystems: ['SAP General Ledger (GL 210100)', 'SAP AP Subledger (FBL1N / FAGLB03)'],
      primaryReconciliationSteps: [
        'Run SAP Trial Balance and extract GL Account 210100 (Trade Accounts Payable).',
        'Run SAP AP Aging and Vendor Open Items report (FBL1N) on the exact same date and timestamp.',
        'Verify GL Balance equals sum of all vendor open items in the AP subledger.',
        'Investigate any variance caused by direct journal entries (manual JEs posted to control GL are prohibited).',
      ],
      discrepancyThreshold: '$0.00 tolerance between Control GL and Subledger.',
      disputeResolutionProcess:
        'In case of mismatch, execute SAP Transaction FS10N to detect manual postings; require reversal and proper AP subledger posting.',
      journalEntryRules: 'All AP entries MUST originate from subledger transactions (MIRO / FB60). No direct FB50 postings.',
      cutoffDay: 'Last calendar day of month at 23:59 EST.',
      sampleWorkbookLocation: 'Finance Shared Drive > Reconciliations > AP_Subledger_Rec > AP_GL_Match_2026.xlsx',
      status: 'reverse-shadowed',
    },
    {
      id: 'rec-3',
      name: 'Intercompany Balance & Loan Reconciliation (Global Entities)',
      type: 'Intercompany',
      frequency: 'Monthly',
      sourceSystems: ['Apex US Ledger (SAP)', 'Apex UK Ledger (NetSuite)', 'Apex APAC Ledger (SAP)'],
      primaryReconciliationSteps: [
        'Extract Intercompany Due To / Due From GL balances across all 4 global entities.',
        'Convert foreign currency balances (GBP, EUR, SGD) at agreed corporate closing exchange rate.',
        'Match individual intercompany invoice charges, management fee allocations, and cross-entity cost recharges.',
        'Record Foreign Exchange Realized / Unrealized Gain-Loss entries in GL 780200.',
        'Both entities must confirm and sign intercompany confirmation certificate by WD+3.',
      ],
      discrepancyThreshold: '< $500 FX rounding difference; zero substantive invoice mismatch.',
      disputeResolutionProcess:
        'Escalate unmatched recharges to Group Controller David Chen by WD+2 for binding arbitration.',
      journalEntryRules: 'Mirror entries posted simultaneously with cross-reference entity transaction ID.',
      cutoffDay: 'Working Day +3 of following month.',
      sampleWorkbookLocation: 'Finance Shared Drive > Reconciliations > Intercompany > Interco_Matrix_Q3_2026.xlsx',
      status: 'in-progress',
    },
    {
      id: 'rec-4',
      name: 'Payment Gateway (Stripe / Adyen) vs Merchant Bank Settlement',
      type: 'Payment Gateway vs Bank',
      frequency: 'Weekly',
      sourceSystems: ['Stripe Dashboard Settlement API', 'Adyen Enterprise Portal', 'JPMC Merchant Bank GL'],
      primaryReconciliationSteps: [
        'Download weekly settlement payout summary from Stripe and Adyen portals.',
        'Reconcile Gross Sales, Merchant Processing Fees, Chargebacks / Refunds, and Net Payout deposited to JPMC account.',
        'Match Net Settlement in bank feed against Billing Subledger batch revenue.',
        'Post merchant processing fee expense journal entry (GL 640250) and reconcile chargeback reserve account.',
      ],
      discrepancyThreshold: 'Gross-to-net reconciliation variance <= $50 (timing/FX).',
      disputeResolutionProcess:
        'Chargebacks > $5,000 flagged to Fraud & Risk team within 24 hours of notification.',
      journalEntryRules: 'DR Bank Account, DR Merchant Processing Fee, CR Deferred Revenue / Accounts Receivable.',
      cutoffDay: 'Every Friday by 4:00 PM EST.',
      sampleWorkbookLocation: 'Finance Shared Drive > Reconciliations > Gateway_Rec > Stripe_Adyen_Settlement_2026.xlsx',
      status: 'shadowing',
    },
  ],
  taxDeadlines: [
    {
      id: 'tax-1',
      taxName: 'Monthly Withholding Tax / TDS Remittance & Challan Verification',
      category: 'TDS / Withholding',
      dueDayRule: '7th of every following calendar month',
      nextDueDate: '2026-09-07',
      filingPortal: 'https://taxportal.gov/withholding / ClearTax Enterprise',
      portalLoginMethod: 'Corporate Tax Portal User ID & Authorized Signatory DSC Token',
      penaltyRisk:
        'Mandatory 1.5% interest per month for delayed remittance under Section 201(1A); potential disallowance of corresponding vendor expense in statutory tax audit.',
      stepSummary: [
        'Extract monthly TDS withholding summary from SAP AP module (withholding tax codes 194C, 194J, 194I, 195).',
        'Verify correct PAN / Tax ID capture for 100% of deducted vendors.',
        'Generate consolidated e-Challan ITNS-281 on government portal.',
        'Initiate net banking tax payment from JPMC Statutory Account before 15:00 EST on due date.',
        'Download Challan receipt containing BSR Code, Challan Date, and 5-digit CIN number; archive in Tax folder.',
      ],
      responsibleRole: 'Senior Finance Lead (Priya Sharma -> Rohan Mehta)',
      approverRole: 'Alexander Wright (CFO)',
      status: 'Pending Current Period',
    },
    {
      id: 'tax-2',
      taxName: 'Monthly GST / VAT Statutory Return & Payment (GSTR-3B)',
      category: 'GST / Indirect Tax',
      dueDayRule: '20th of every calendar month',
      nextDueDate: '2026-09-20',
      filingPortal: 'https://gstportal.gov / ClearTax GST Cloud',
      portalLoginMethod: 'Digital Signature Certificate (DSC) of Managing Director / CFO',
      penaltyRisk:
        'Late fee of $50/day plus 18% annual interest on unpaid tax liability; automated e-way bill generation blockage after 60 days of default.',
      stepSummary: [
        'Extract Outward Sales Tax Register from ERP and reconcile with customer invoices.',
        'Reconcile Inward Input Tax Credit (ITC) with GSTR-2B government auto-drafted feed.',
        'Compute net cash liability after tax set-off; create Electronic Cash Ledger challan.',
        'Disburse payment, offset tax liability in portal, and sign GSTR-3B return using Director DSC token.',
        'Post tax offset and payment clearance journal entry in SAP GL 220100.',
      ],
      responsibleRole: 'Incoming Finance Lead (Rohan Mehta) with Tax Senior',
      approverRole: 'Alexander Wright (CFO)',
      status: 'Compliant',
    },
    {
      id: 'tax-3',
      taxName: 'Quarterly Advance Corporate Income Tax (Installment 2 - 45%)',
      category: 'Advance Tax',
      dueDayRule: '15th of September (Installment 2: 45% cumulative tax)',
      nextDueDate: '2026-09-15',
      filingPortal: 'https://incometax.gov / JPMC Tax Payment Gateway',
      portalLoginMethod: 'Corporate Income Tax E-filing Login + Director DSC',
      penaltyRisk:
        'Mandatory interest levy under Section 234B & 234C (1% per month) on shortfall of advance tax estimates.',
      stepSummary: [
        'Review Year-to-Date (YTD) actual P&L and collaborate with FP&A team on FY2026 forecast EBITDA.',
        'Apply corporate effective tax rate (25.17%), factoring in depreciation, R&D tax incentives, and disallowances.',
        'Calculate cumulative 45% tax liability; deduct TDS withheld by customers to date.',
        'Prepare Board Tax Memo and obtain CFO / Audit Committee sign-off by Sept 10.',
        'Execute tax challan payment ITNS-280 on or before Sept 15, 2026.',
      ],
      responsibleRole: 'Senior Finance Lead & External Tax Consultant (PwC)',
      approverRole: 'Alexander Wright (CFO)',
      status: 'Action Required',
    },
    {
      id: 'tax-4',
      taxName: 'Monthly Payroll Statutory Compliance (PF, ESI, Social Security)',
      category: 'Payroll Statutory (PF/ESI/PT)',
      dueDayRule: '15th of every following calendar month',
      nextDueDate: '2026-09-15',
      filingPortal: 'https://unifiedportal-epfo.gov / State Labor Portals',
      portalLoginMethod: 'Authorized Signatory Employer Credentials & DSC',
      penaltyRisk:
        'Severe labor law penalties, employer prosecution risk, and 12% to 25% penal damages for delayed worker contribution remittances.',
      stepSummary: [
        'Receive finalized monthly Payroll Register from HR Operations team on the 28th of the month.',
        'Reconcile Employee & Employer Provident Fund / Social Security deductions against GL Account 210500.',
        'Generate Electronic Challan cum Return (ECR) file and upload to Unified Portal.',
        'Execute payment from JPMC Payroll Disbursement account by 13th of the month (buffer of 2 days).',
        'Archive payment receipt and send compliance certificate to HR Head.',
      ],
      responsibleRole: 'Senior Finance Lead & Payroll Accountant',
      approverRole: 'Alexander Wright (CFO) & VP Human Resources',
      status: 'Pending Current Period',
    },
  ],
  systemTools: [
    {
      id: 'sys-1',
      systemName: 'SAP S/4HANA Cloud (Enterprise ERP)',
      purpose: 'Core General Ledger, Accounts Payable, Accounts Receivable, Fixed Assets, and Financial Reporting engine.',
      accessUrl: 'https://my300192.s4hana.ondemand.com',
      roleProfileRequired: 'Z_FI_LEAD_ALL (Full FI/CO Posting, Reversal, Period Open/Close, Master Data Review)',
      howToRequestAccess:
        'Submit IT Service Desk Ticket with approval from Alexander Wright (CFO). Profile creation handled by SAP Basis Admin (basis@enterprise.com).',
      adminContact: 'Suresh Menon (Lead SAP Administrator - ext 4402)',
      keyReportsExtracted: [
        {
          reportName: 'Trial Balance & Financial Statements (F.01)',
          menuPath: 'Financial Accounting > General Ledger > Information System > F.01',
          frequency: 'Monthly close / Ad-hoc',
          purpose: 'Official Balance Sheet and P&L generation for management and board.',
        },
        {
          reportName: 'Vendor Open Items & Aging (FBL1N / S_ALR_87012085)',
          menuPath: 'Financial Accounting > Accounts Payable > Account > FBL1N',
          frequency: 'Weekly',
          purpose: 'AP aging analysis, payment scheduling, and vendor reconciliations.',
        },
        {
          reportName: 'Bank Ledger & Statement Clearing Log (FAGLL03 / FEBAN)',
          menuPath: 'Financial Accounting > Bank Ledger > FEBAN',
          frequency: 'Daily',
          purpose: 'Track unallocated cash, bank transit items, and daily ledger balancing.',
        },
        {
          reportName: 'Asset History Sheet / Depreciation Roll-forward (S_ALR_87011990)',
          menuPath: 'Financial Accounting > Fixed Assets > Information System',
          frequency: 'Monthly / Quarterly',
          purpose: 'Fixed asset additions, disposals, depreciation verification.',
        },
      ],
      status: 'completed',
    },
    {
      id: 'sys-2',
      systemName: 'J.P. Morgan Access (Corporate Cash Management Portal)',
      purpose: 'Treasury operations, multi-currency wire execution, ACH batches, positive pay check fraud prevention.',
      accessUrl: 'https://access.jpmorgan.com',
      roleProfileRequired: 'Initiator / Approver Level 2 with RSA Hardware Token',
      howToRequestAccess:
        'Execute Bank Mandate Form B-4 with Board Resolution extract signed by CFO. JPMC Relationship Manager provisions user within 4 business days.',
      adminContact: 'Catherine Sterling (JPMC VP Relationship Manager)',
      keyReportsExtracted: [
        {
          reportName: 'Previous Day Prior-Day Statement (MT940 / PDF)',
          menuPath: 'Reports > Account Statements > Prior Day Balances',
          frequency: 'Daily 08:30 AM',
          purpose: 'Automated bank reconciliation feed for SAP FEBAN.',
        },
        {
          reportName: 'Intraday Activity & Incoming Wire Advices',
          menuPath: 'Cash Management > Real-Time Activity',
          frequency: 'Real-Time',
          purpose: 'Verify high-value customer collections and release customer shipment holds.',
        },
      ],
      status: 'shadowing',
    },
    {
      id: 'sys-3',
      systemName: 'ClearTax Enterprise & Government Tax Filing Portals',
      purpose: 'Statutory GST, TDS, e-Invoicing, and Corporate Tax returns filing and input tax credit reconciliation.',
      accessUrl: 'https://enterprise.cleartax.com / https://gst.gov',
      roleProfileRequired: 'Admin / Tax Signatory with DSC Digital Token Integration',
      howToRequestAccess:
        'Admin invite sent to rohan.mehta@enterprise.com by Priya Sharma; DSC dongle driver configuration completed by IT.',
      adminContact: 'Priya Sharma / ClearTax Account Manager (support@cleartax.in)',
      keyReportsExtracted: [
        {
          reportName: 'GSTR-2B vs ERP Purchase Register ITC Matching Report',
          menuPath: 'ClearTax GST > ITC Matching > Auto-Reconcile',
          frequency: 'Monthly 14th',
          purpose: 'Identifies missing vendor invoices and ineligible tax credits.',
        },
        {
          reportName: 'Quarterly TDS Form 26AS / AIS Tax Credit Statement',
          menuPath: 'Income Tax E-filing Portal > Services > View Form 26AS',
          frequency: 'Quarterly',
          purpose: 'Verifies tax withheld by corporate customers against open receivables.',
        },
      ],
      status: 'in-progress',
    },
    {
      id: 'sys-4',
      systemName: 'Coupa Spend Management (Procure-to-Pay)',
      purpose: 'Purchase requisition approvals, PO management, vendor contracts, and invoice approval workflows.',
      accessUrl: 'https://apex.coupahost.com',
      roleProfileRequired: 'Finance Super Approver (Tier 2 DoA Authority)',
      howToRequestAccess:
        'Submit ServiceNow ticket to Procurement Operations; role automatically mapped to incoming employee email.',
      adminContact: 'Rachel Adams (Director of Global Procurement)',
      keyReportsExtracted: [
        {
          reportName: 'Uninvoiced Purchase Orders & GRN Accrual Report',
          menuPath: 'Reports > Spend Analytics > Open GRN Accrual',
          frequency: 'Monthly Close (WD-1)',
          purpose: 'Calculates unbilled goods received for month-end accrual journal entry.',
        },
      ],
      status: 'completed',
    },
  ],
  dataManagement: {
    folderStructure: [
      {
        driveName: 'Secure Finance Shared Drive (Google Workspace / Microsoft SharePoint)',
        rootPath: 'Shared Drives > Corporate Finance & Accounts (Z: Drive)',
        subFolders: [
          '01_Month_End_Close (Organized by Year > Month e.g., 2026_08_August)',
          '02_Treasury_and_Banking (Bank Mandates, Token Protocols, Daily Cash Sheets)',
          '03_Statutory_and_Tax (GST_Filings, TDS_Challans, Advance_Tax, Income_Tax_Returns)',
          '04_Reconciliations (Bank_BRS, GL_vs_AP_AR, Intercompany, Balance_Sheet_Master)',
          '05_Statutory_Audit_Files (PwC_PBC_Requests, Walkthroughs, Board_Notes)',
          '06_SOPs_and_Policies (Standard Operating Procedures, DoA Matrix, Travel Policy)',
          '07_Vendor_and_Customer_Contracts (Executed Agreements, W-9 / Tax Forms)',
        ],
        description: 'Primary repository for all accounting, audit, and tax evidence with strict restricted role-based access.',
      },
      {
        driveName: 'Confidential Executive Treasury Repository',
        rootPath: 'Shared Drives > Restricted > Treasury_Signatories_Only',
        subFolders: [
          'Bank_Mandates_and_Resolutions',
          'Token_Custody_Logs',
          'Escalation_Protocols',
        ],
        description: 'Restricted to CFO, Finance Lead, and Legal Head only.',
      },
    ],
    namingConventions: [
      {
        fileType: 'Month-End Balance Sheet Rec File',
        formatPattern: 'BS_Rec_Master_[Entity]_[YYYY]_[MM]_[vNumber].xlsx',
        example: 'BS_Rec_Master_ApexGlobal_2026_08_v2.xlsx',
      },
      {
        fileType: 'Bank Reconciliation Statement (BRS)',
        formatPattern: 'BRS_[BankName]_[AccountLast4]_[YYYYMMDD].xlsx',
        example: 'BRS_JPMC_8842_20260831.xlsx',
      },
      {
        fileType: 'Statutory Tax Payment Challan',
        formatPattern: 'Challan_[TaxType]_[ChallanNumber]_[YYYYMMDD].pdf',
        example: 'Challan_TDS_BSR002910_20260907.pdf',
      },
      {
        fileType: 'Vendor Payment Batch Approval Dossier',
        formatPattern: 'PaymentBatch_[Bank]_[BatchID]_[YYYYMMDD]_[Signed].pdf',
        example: 'PaymentBatch_JPMC_ACH99201_20260828_Signed.pdf',
      },
    ],
    criticalFileLocations: [
      {
        documentName: 'Master Delegation of Authority (DoA) Approval Matrix',
        path: 'Finance Shared Drive > 06_SOPs_and_Policies > Master_DoA_Matrix_FY2026_Approved.pdf',
        accessPermission: 'Read-Only for all Finance Staff; Edit restricted to CFO & Legal',
      },
      {
        documentName: 'Active Banking Mandates & Board Signatory Resolutions',
        path: 'Finance Shared Drive > 02_Treasury_and_Banking > Mandates > Board_Resolutions_Banking_2026.pdf',
        accessPermission: 'Finance Lead & CFO only',
      },
      {
        documentName: 'PwC Statutory Audit PBC (Provided By Client) Tracker FY2026',
        path: 'Finance Shared Drive > 05_Statutory_Audit_Files > FY2026_Interim_Audit > PwC_PBC_Tracker_v4.xlsx',
        accessPermission: 'Finance Team & External PwC Audit Team',
      },
      {
        documentName: 'Historical Tax Returns & Assessment Orders Archive (7-Year Statutory Vault)',
        path: 'Finance Shared Drive > 03_Statutory_and_Tax > Statutory_Vault_Permanent_Archive',
        accessPermission: 'Restricted Archive with write-protection',
      },
    ],
    backupAndArchival:
      'All finance shared drives are backed up automatically every 6 hours via Cloud Snapshot. Monthly close folders are locked to "Read-Only" on WD+6 after CFO formal sign-off to prevent accidental modification of finalized workbooks.',
  },
  stakeholders: [
    {
      id: 'st-1',
      name: 'Alexander Wright',
      role: 'Chief Financial Officer (CFO)',
      departmentOrOrg: 'Executive Leadership',
      type: 'Internal',
      email: 'alexander.wright@enterprise.com',
      phone: '+1 (555) 019-2831',
      relationshipContext: 'Direct reporting manager and key sign-off authority.',
      cadence: 'Daily 15-min sync; Weekly strategic 1-on-1; Month-end sign-off review.',
      keyInteractions:
        'Approval of payments >$50k, signing of statutory tax returns, reviewing month-end variance commentary, board decks.',
    },
    {
      id: 'st-2',
      name: 'Rachel Adams',
      role: 'Director of Global Procurement',
      departmentOrOrg: 'Procurement & Supply Chain',
      type: 'Internal',
      email: 'rachel.adams@enterprise.com',
      phone: '+1 (555) 392-8812',
      relationshipContext: 'Key internal peer for 3-way matching, purchase orders, and vendor dispute resolution.',
      cadence: 'Bi-weekly AP & Open GRN Review.',
      keyInteractions:
        'Resolving price/quantity invoice blocks in SAP, onboarding strategic vendors, enforcing payment terms.',
    },
    {
      id: 'st-3',
      name: 'Catherine Sterling',
      role: 'Vice President, Global Treasury Management',
      departmentOrOrg: 'J.P. Morgan Chase Bank, N.A.',
      type: 'External',
      email: 'catherine.sterling@jpmorgan.com',
      phone: '+1 (212) 555-0199',
      relationshipContext: 'Primary Commercial Banking Relationship Manager.',
      cadence: 'Monthly treasury review & quarterly bank pricing audit.',
      keyInteractions:
        'Credit facility lines, foreign exchange hedging rates, banking token issuance, wire recall requests, cash sweep setups.',
    },
    {
      id: 'st-4',
      name: 'Timothy Gallagher, FCA',
      role: 'Senior Audit Partner',
      departmentOrOrg: 'PricewaterhouseCoopers (PwC) LLP',
      type: 'External',
      email: 'timothy.gallagher@pwc.com',
      phone: '+1 (415) 555-7744',
      relationshipContext: 'Statutory Independent External Auditor.',
      cadence: 'Weekly during interim & year-end audit; quarterly reviews.',
      keyInteractions:
        'Managing PBC (Provided By Client) deliverable tracker, accounting technical position memos, walkthrough testing.',
    },
    {
      id: 'st-5',
      name: 'Siddharth Varma',
      role: 'Senior Tax Partner',
      departmentOrOrg: 'Varma & Associates (Corporate Tax Advisory)',
      type: 'External',
      email: 'siddharth.varma@varmatax.com',
      phone: '+1 (555) 782-9011',
      relationshipContext: 'Retained Statutory Tax & Transfer Pricing Advisor.',
      cadence: 'Monthly tax filing pre-review; quarterly advance tax estimation.',
      keyInteractions:
        'Review of GST/VAT returns, withholding tax treaty interpretations, representation before tax assessment authorities.',
    },
  ],
  ongoingTasks: [
    {
      id: 'ot-1',
      taskTitle: 'August 2026 Month-End Close & Financial Reporting Pack',
      projectOrCategory: 'Month-End Close',
      status: 'In Progress',
      priority: 'Critical',
      deadline: '2026-09-05',
      dependencies: 'AP subledger closing, fixed asset depreciation run, intercompany confirmations',
      pendingWith: 'Incoming Lead (Rohan Mehta) to execute under Priya Sharma supervision',
      handoverNotes:
        'All standard accruals calculated in workbook. Follow 5-day close checklist in Section 3.',
      actionRequiredBySuccessor:
        'Execute final trial balance extraction and present balance sheet variance deck to CFO on Sept 5.',
    },
    {
      id: 'ot-2',
      taskTitle: 'Q2 Corporate Advance Tax Estimation & Remittance (Installment 2)',
      projectOrCategory: 'Statutory Compliance',
      status: 'In Progress',
      priority: 'Critical',
      deadline: '2026-09-15',
      dependencies: 'FP&A revised full-year forecast P&L from David Chen',
      pendingWith: 'PwC Tax Advisor and Senior Finance Lead',
      handoverNotes:
        'Draft model prepared. Ensure minimum $1.2M remittance to satisfy safe harbor rules under Section 234C.',
      actionRequiredBySuccessor:
        'Review final calculation with Siddharth Varma (Tax Consultant) on Sept 10, obtain CFO signature, and disburse challan.',
    },
    {
      id: 'ot-3',
      taskTitle: 'PwC Interim Statutory Audit PBC Deliverables Preparation',
      projectOrCategory: 'External Audit',
      status: 'In Progress',
      priority: 'High',
      deadline: '2026-09-25',
      dependencies: 'Q1 and Q2 sample transaction pull (Revenue recognition samples, AP 3-way match samples)',
      pendingWith: 'Finance Team (Marcus & Ananya) and Incoming Lead',
      handoverNotes:
        'PBC tracker is 45% populated in Drive folder 05. PwC will begin on-site testing on Oct 1.',
      actionRequiredBySuccessor:
        'Lead weekly Thursday status call with Timothy Gallagher (PwC) and review all submitted sample packs.',
    },
    {
      id: 'ot-4',
      taskTitle: 'Bank Signatory Mandate Migration (JPMC & Citibank)',
      projectOrCategory: 'Treasury Governance',
      status: 'In Progress',
      priority: 'Critical',
      deadline: '2026-09-12',
      dependencies: 'Board Resolution execution by Corporate Secretary Elena Rostova',
      pendingWith: 'JPMC & Citi Corporate Onboarding teams',
      handoverNotes:
        'Board resolution signed on Aug 20. Form B-4 submitted. Physical tokens pending courier delivery.',
      actionRequiredBySuccessor:
        'Receive physical hardware token, register biometric OTP on mobile app, and execute $1 test wire verification.',
    },
    {
      id: 'ot-5',
      taskTitle: 'ClearTax E-Invoicing Auto-Sync API Migration in SAP',
      projectOrCategory: 'Systems & Automation',
      status: 'Under Review',
      priority: 'Medium',
      deadline: '2026-09-30',
      dependencies: 'SAP Basis transport release in production',
      pendingWith: 'Suresh Menon (SAP Lead) & ClearTax Integration Engineer',
      handoverNotes: 'UAT testing completed in sandbox environment with 100% test invoice success.',
      actionRequiredBySuccessor:
        'Sign off on production deployment cutover on Sept 28; monitor first 50 live e-invoices generated.',
    },
  ],
  knownRisks: [
    {
      id: 'kr-1',
      category: 'Cash Flow & Banking',
      knownIssue:
        'Wire cut-off time strictly enforced at 2:00 PM EST for same-day settlements on JPMC portal. System locks queued drafts at 14:00 sharp.',
      impactLevel: 'Critical',
      workaround:
        'Initiate all payment batches by 11:30 AM every morning. Never wait for last-minute approvals after 13:00 EST. If emergency occurs, use JPMC Wire Callback Desk hotline immediately.',
      criticalCutoffTiming: '14:00 EST (Same-day Fedwire) / 16:30 EST (Next-day ACH)',
      whatNotToDo:
        'DO NOT promise same-day vendor wire releases if invoice approval is received after 13:00 EST without explicit written CFO exception.',
    },
    {
      id: 'kr-2',
      category: 'Statutory & Deadlines',
      knownIssue:
        'Government tax portal server experiences extreme congestion and frequent session crashes on the 19th and 20th of every month.',
      impactLevel: 'High',
      workaround:
        'Enforce internal tax close cut-off on the 16th of each month; generate challans and file returns at least 48 hours prior to the statutory 20th deadline.',
      criticalCutoffTiming: '20th of the month at 23:59 (Internal target: 17th by 17:00)',
      whatNotToDo:
        'DO NOT wait until the final statutory due date to initiate net banking tax disbursements. Banking RTGS gateways often throttle government tax portals late at night.',
    },
    {
      id: 'kr-3',
      category: 'Reconciliation & Books',
      knownIssue:
        'Foreign exchange differences on intercompany balances can cause ledger imbalances if differing month-end spot rates are used between US and UK entities.',
      impactLevel: 'Medium',
      workaround:
        'Use the centralized Group Corporate Closing Rate published by David Chen (FP&A) on WD-1. Both entities must lock the exact same FX rate in SAP.',
      criticalCutoffTiming: 'Working Day +1 at 12:00 EST',
      whatNotToDo:
        'DO NOT pull exchange rates independently from public websites like Yahoo Finance or OANDA without corporate treasury approval.',
    },
    {
      id: 'kr-4',
      category: 'Vendor / Customer Dispute',
      knownIssue:
        'Vendor bank detail change requests via email represent the highest-risk vector for business email compromise (BEC) fraud.',
      impactLevel: 'Critical',
      workaround:
        'Mandatory dual-channel callback verification rule: Finance Lead must call the vendor Chief Financial Officer or Account Lead on a verified phone number from the original contract before changing any bank account details in SAP Vendor Master.',
      criticalCutoffTiming: 'Zero tolerance - prior to any master data change.',
      whatNotToDo:
        'NEVER accept bank account change instructions sent via email or PDF letterhead without documented verbal confirmation on a known telephone number.',
    },
  ],
  complianceControls: [
    {
      id: 'ctrl-1',
      controlTitle: 'Dual Signatory Wire & Payment Authorization Control',
      framework: 'Internal Financial Controls (IFC)',
      description:
        'All bank disbursements, payroll releases, and treasury transfers require Maker-Checker segregation of duties. Single-user sole release is strictly blocked above $50k.',
      approvalMatrixRule:
        'Up to $25k: Tier 3 Maker + Tier 2 Checker. $25k - $100k: Tier 2 Lead + CFO. >$100k: CFO + CEO / Board Member.',
      auditEvidenceLocation: 'Bank Transmittal Log & Dual Timestamp PDF archived in Payment Batch folder.',
      penaltiesOrConsequences: 'Immediate breach of SOX / IFC controls; suspension of banking access privileges.',
    },
    {
      id: 'ctrl-2',
      controlTitle: 'Mandatory 3-Way Matching for Accounts Payable Invoices',
      framework: 'Internal Financial Controls (IFC)',
      description:
        'Every non-payroll vendor invoice must be systematically matched against an approved Coupa Purchase Order and verified Warehouse / Department Goods Receipt Note (GRN) before payment.',
      approvalMatrixRule: 'Zero price variance tolerance; quantity tolerance maximum 1% for bulk raw materials.',
      auditEvidenceLocation: 'SAP Document Flow (MIRO linked to PO & GRN)',
      penaltiesOrConsequences: 'Invoice placed on immediate payment block R (Price Variance) or Q (Quantity).',
    },
    {
      id: 'ctrl-3',
      controlTitle: 'Statutory Tax Deduction & Remittance Control',
      framework: 'Statutory Audit',
      description:
        'All taxable vendor payments must undergo automated tax withholding (TDS / 1099) deduction at time of invoice credit or payment, whichever is earlier.',
      approvalMatrixRule: '100% compliance verified against Vendor Tax Master (PAN / W-9 validated).',
      auditEvidenceLocation: 'Monthly Tax Challan Master Dossier with BSR confirmation receipts.',
      penaltiesOrConsequences: '1.5% compounding monthly penalty and personal liability of Principal Officer.',
    },
    {
      id: 'ctrl-4',
      controlTitle: 'Monthly Balance Sheet Account Ownership & Sign-Off Control',
      framework: 'Delegation of Authority (DoA)',
      description:
        'Every GL balance sheet account must have a designated preparer, supporting third-party documentation, variance analysis, and formal reviewer sign-off by WD+5.',
      approvalMatrixRule: 'Preparer: Senior Accountant -> Reviewer: Finance Lead -> Final Approver: CFO.',
      auditEvidenceLocation: 'Blackline / Excel Balance Sheet Master Reconciliation Binder.',
      penaltiesOrConsequences: 'Material weakness or significant deficiency reported by Statutory Auditors to Board Audit Committee.',
    },
  ],
  handoverTimeline: [
    {
      id: 'ht-1',
      phase: 'Phase 1: Orientation & System Setup',
      timeframe: 'Days 1 - 3 (Aug 25 - Aug 27)',
      focusAreas: ['System Provisioning', 'Team Introductions', 'Documentation Review'],
      tasksToCover: [
        'Complete SAP, Coupa, JPMC, ClearTax, and Shared Drive access provisioning.',
        'Initial 1-on-1 walkthrough with CFO Alexander Wright on strategic goals.',
        'Meet direct reports (Ananya, Marcus, Sneha) and map current task allocations.',
        'Review the complete Finance Role Bible, SOP library, and DoA approval matrices.',
      ],
      successCriteria: '100% system access verified; all test logins successful.',
      completed: true,
    },
    {
      id: 'ht-2',
      phase: 'Phase 2: Shadowing Live Operations',
      timeframe: 'Days 4 - 8 (Aug 28 - Sept 3)',
      focusAreas: ['Daily Treasury Operations', 'AP Batch Releases', 'Month-End Close Kick-off'],
      tasksToCover: [
        'Observe daily morning cash positioning and bank statement clearing in SAP.',
        'Shadow weekly vendor payment proposal generation and token authorization flow.',
        'Participate in Month-End Close Working Day -1 and Day 1 subledger freezes.',
        'Attend cross-functional review with Procurement Director Rachel Adams.',
      ],
      successCriteria: 'Successor documents end-to-end observation notes with zero unanswered questions.',
      completed: true,
    },
    {
      id: 'ht-3',
      phase: 'Phase 3: Reverse Shadowing & Supervised Handling',
      timeframe: 'Days 9 - 14 (Sept 4 - Sept 11)',
      focusAreas: ['Full Execution by Successor', 'BRS Preparation', 'Tax Return Drafts'],
      tasksToCover: [
        'Incoming Lead Rohan Mehta executes daily treasury cash positioning independently while Priya observes.',
        'Rohan prepares August Month-End Balance Sheet Reconciliation file and presents to CFO.',
        'Rohan drafts September TDS Withholding return and GST challans.',
        'Execute physical token custody handover in presence of CFO.',
      ],
      successCriteria: 'Zero operational errors; successful independent execution of live daily and monthly routines.',
      completed: false,
    },
    {
      id: 'ht-4',
      phase: 'Phase 4: Independent Sign-off',
      timeframe: 'Days 15 - 16 (Sept 12 - Sept 15)',
      focusAreas: ['Final Q&A', 'Formal Sign-off Ceremony', 'Post-Handover Emergency Protocols'],
      tasksToCover: [
        'Review open audit deliverables with PwC partner Timothy Gallagher.',
        'Complete formal 3-party Handover Sign-off with Outgoing Lead, Incoming Lead, and CFO.',
        'Archive complete Transition Dossier in corporate permanent records.',
        'Transfer physical office safe keys and emergency contact binder.',
      ],
      successCriteria: 'Tripartite Handover Certificate signed by Outgoing, Successor, and Reporting Manager.',
      completed: false,
    },
  ],
  knowledgeNotes: [
    {
      id: 'kn-1',
      category: 'Pro Tips & Hacks',
      title: 'Accelerating SAP Month-End Subledger Reconciliations',
      content:
        'Instead of running individual vendor line items in FBL1N, use transaction FAGLL03 with Dynamic Selection on Field "BSTAT = Space" (Normal items). To verify unmatched AP control accounts in seconds, run transaction FS10N alongside F.01 to immediately flag if any manual journal was posted without vendor subledger link.',
      sampleCodeOrText: 'SAP T-Codes: F.01 (Trial Balance) | FBL1N (Vendor Open) | FS10N (GL Balances) | FEBAN (Bank Auto)',
    },
    {
      id: 'kn-2',
      category: 'Frequently Asked Questions (FAQs)',
      title: 'What to do if a vendor payment wire is rejected or returns due to incorrect SWIFT code?',
      content:
        '1. Check SAP FEBAN statement for return reference code (usually shows as "RET-PAY").\n2. The system auto-credits the bank clearing account; you must post an un-clearing entry in SAP AP to reverse the vendor clearing.\n3. Request formal SWIFT / IBAN verification letter on official bank letterhead from vendor.\n4. Re-queue payment in the next daily batch after updating Vendor Master with Level 2 sign-off.',
    },
    {
      id: 'kn-3',
      category: 'Email & Communication Templates',
      title: 'Formal Dual Signatory High-Value Wire Approval Request to CFO',
      content: 'Standard email template used when requesting CFO Level 2 token approval on urgent or >$50k payment batches.',
      sampleCodeOrText: `To: alexander.wright@enterprise.com
Subject: [ACTION REQUIRED] Tier 2 Banking Dual Approval - JPMC Wire Batch #99201 ($142,500.00)

Hi Alex,

The weekly priority vendor payment batch has been reviewed, 3-way matched, and approved at Tier 1 Maker level.

Batch Summary:
- Bank Account: J.P. Morgan Operating (•••8842)
- Total Amount: $142,500.00 USD
- Total Vendors: 6 (Details in attached summary)
- Key High-Value Item: $95,000 to Cloud Infrastructure Provider (Contract #APX-441)

All supporting tax invoices and Coupa PO approvals are validated in the attached PDF. 
Please authorize via your JPMC Mobile RSA Token prior to the 14:00 EST wire cut-off.

Best regards,
Rohan Mehta | Finance Lead`,
    },
    {
      id: 'kn-4',
      category: 'Past Audit Queries',
      title: 'PwC Prior-Year Revenue Cut-off & Unbilled Revenue Sample Query Resolution',
      content:
        'During the FY2025 statutory audit, PwC flagged 3 December sales invoices where shipment occurred on Dec 31 but invoice was generated on Jan 2. The solution is ensuring that the Goods Issue (PGI) date in SAP matches the revenue recognition date, rather than the billing document creation timestamp. See documentation in Audit folder 05.',
    },
  ],
  managerAlignment: {
    newJoinerExpectations: [
      'Take complete ownership of the 5-day monthly close cycle with zero escalation to CFO for routine reconciliation queries.',
      'Maintain 100% on-time statutory tax filings with zero late notices or penalty assessments.',
      'Act as a proactive business partner to Procurement, Legal, and FP&A to streamline spend controls.',
      'Uphold uncompromising standards of internal controls and dual-authorization banking discipline.',
    ],
    first30DaysPlan: {
      focus: 'Master Core Systems, Stakeholders & Supervised Close Execution',
      milestones: [
        'Complete 100% system access setup and token registrations across all 3 banking portals.',
        'Shadow August Month-End Close and independently prepare September Bank Reconciliations.',
        'Conduct 1-on-1 discovery meetings with all direct reports, Procurement Head, and PwC audit team.',
        'Review and update all standard operating procedures (SOPs) and banking signatory lists.',
      ],
      checkpointDate: '2026-09-25 (End of Month 1)',
    },
    first60DaysPlan: {
      focus: 'Independent Close Ownership & Interim Audit Leadership',
      milestones: [
        'Lead September Month-End Close independently within the target 5-day close timeline (WD+5).',
        'Lead PwC Interim Statutory Audit field testing and deliver 100% of PBC sample requests on schedule.',
        'Execute October Advance Tax planning review with external tax consultant.',
        'Identify at least 2 process bottlenecks in AP invoice processing and propose automated solutions.',
      ],
      checkpointDate: '2026-10-25 (End of Month 2)',
    },
    first90DaysPlan: {
      focus: 'Optimization, Process Automation & Strategic Value Delivery',
      milestones: [
        'Achieve full autonomy across all treasury, tax, GL, and reporting workflows.',
        'Implement automated ClearTax-SAP e-invoicing integration to reduce manual reconciliation time by 4 hours/month.',
        'Deliver finalized Q3 Balance Sheet Dossier with zero audit review findings.',
        'Present 2027 Finance Operations Roadmap and Team Development plan to CFO.',
      ],
      checkpointDate: '2026-11-25 (End of Month 3)',
    },
    evaluationCriteria: [
      'Accuracy & speed of monthly financial close (WD+5 target).',
      'Quality of audit documentation and clean review with zero material audit adjustments.',
      'Statutory compliance record (100% error-free and on-time).',
      'Team leadership and collaborative stakeholder relationship feedback.',
    ],
    managerNotes:
      'Priya has built an exceptionally strong foundation in our finance operations. Rohan brings outstanding credentials in ERP transformation and audit governance. We expect a seamless transition and look forward to Rohan driving our next phase of treasury automation.',
  },
};
