import { HandoverPackage } from '../types/handover';
import { initialHandoverPackage } from './defaultHandoverData';

export interface RolePresetSummary {
  id: string;
  roleName: string;
  department: string;
  description: string;
  packageData: HandoverPackage;
}

export const rolePresets: RolePresetSummary[] = [
  {
    id: 'finance-lead-2026',
    roleName: 'Senior Finance & Accounts Lead (Controller)',
    department: 'Finance, Treasury & Taxation',
    description: 'Comprehensive general finance lead, month-end closing, banking signatory, balance sheet recs, tax compliance, and audit governance.',
    packageData: initialHandoverPackage,
  },
  {
    id: 'ap-treasury-lead',
    roleName: 'Accounts Payable & Treasury Operations Lead',
    department: 'Treasury & Disbursements',
    description: 'Specialized focus on P2P invoice matching, weekly payment batches, banking token administration, cash sweeps, vendor dispute mitigation, and 1099/withholding.',
    packageData: {
      ...initialHandoverPackage,
      id: 'ap-treasury-lead',
      title: 'AP & Treasury Operations Lead - Transition Package',
      employeeDetails: {
        ...initialHandoverPackage.employeeDetails,
        outgoingRole: 'AP & Treasury Operations Lead',
        successorRole: 'Incoming AP & Treasury Specialist',
        department: 'Treasury & Disbursements',
      },
      roleOverview: {
        ...initialHandoverPackage.roleOverview,
        primaryObjective: 'Ensure 100% timely and accurate vendor disbursements, banking token security, cash flow liquidity management, and strict P2P controls.',
      },
    },
  },
  {
    id: 'tax-compliance-lead',
    roleName: 'Statutory Tax & Regulatory Compliance Specialist',
    department: 'Statutory Compliance & Direct/Indirect Tax',
    description: 'Specialized focus on recurring statutory deadlines (GST/VAT, TDS, Corporate Advance Tax, Labor PF/ESI), tax audits, Challan verification, and portal tokens.',
    packageData: {
      ...initialHandoverPackage,
      id: 'tax-compliance-lead',
      title: 'Statutory Tax & Regulatory Compliance Lead - Transition Package',
      employeeDetails: {
        ...initialHandoverPackage.employeeDetails,
        outgoingRole: 'Senior Statutory Tax Specialist',
        successorRole: 'Incoming Statutory Tax Lead',
        department: 'Statutory Compliance & Taxation',
      },
      roleOverview: {
        ...initialHandoverPackage.roleOverview,
        primaryObjective: 'Ensure zero-defect statutory tax filings, advance tax planning, audit defense, and seamless government portal compliance management.',
      },
    },
  },
];
