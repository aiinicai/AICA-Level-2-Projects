import React from 'react';
import { HandoverProvider, useHandover } from './context/HandoverContext';
import { Navbar } from './components/Navbar';
import { NavigationTabs } from './components/NavigationTabs';
import { OverviewSummary } from './components/OverviewSummary';
import { RoleBibleDossier } from './components/modules/RoleBibleDossier';
import { BankingCredentialsView } from './components/modules/BankingCredentialsView';
import { ReconciliationWorkflowsView } from './components/modules/ReconciliationWorkflowsView';
import { TaxComplianceView } from './components/modules/TaxComplianceView';
import { ProcessDocumentationView } from './components/modules/ProcessDocumentationView';
import { EmployeeDetailsView } from './components/modules/EmployeeDetailsView';
import { RoleOverviewView } from './components/modules/RoleOverviewView';
import { SystemsToolsView } from './components/modules/SystemsToolsView';
import { DataManagementView } from './components/modules/DataManagementView';
import { StakeholderMappingView } from './components/modules/StakeholderMappingView';
import { OngoingWorkView } from './components/modules/OngoingWorkView';
import { RisksChallengesView } from './components/modules/RisksChallengesView';
import { ComplianceControlsView } from './components/modules/ComplianceControlsView';
import { HandoverPlanView } from './components/modules/HandoverPlanView';
import { KnowledgeNotesView } from './components/modules/KnowledgeNotesView';
import { ManagerCommentsView } from './components/modules/ManagerCommentsView';
import { AIAssistantModal } from './components/AIAssistantModal';
import { SignOffModal } from './components/SignOffModal';
import { Search, Sparkles } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, searchQuery, setActiveTab, setIsAiModalOpen } = useHandover();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewSummary />;
      case 'role-bible':
        return <RoleBibleDossier />;
      case 'banking':
        return <BankingCredentialsView />;
      case 'reconciliations':
        return <ReconciliationWorkflowsView />;
      case 'tax-deadlines':
        return <TaxComplianceView />;
      case 'sops':
        return <ProcessDocumentationView />;
      case 'employee-details':
        return <EmployeeDetailsView />;
      case 'role-overview':
        return <RoleOverviewView />;
      case 'systems':
        return <SystemsToolsView />;
      case 'data-management':
        return <DataManagementView />;
      case 'stakeholders':
        return <StakeholderMappingView />;
      case 'ongoing-work':
        return <OngoingWorkView />;
      case 'risks-challenges':
        return <RisksChallengesView />;
      case 'compliance-controls':
        return <ComplianceControlsView />;
      case 'handover-plan':
        return <HandoverPlanView />;
      case 'knowledge-notes':
        return <KnowledgeNotesView />;
      case 'manager-comments':
        return <ManagerCommentsView />;
      default:
        return <OverviewSummary />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      <Navbar />

      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto">
        <NavigationTabs />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-5xl">
          {searchQuery.trim() && (
            <div className="mb-6 p-3.5 bg-white border border-blue-200 rounded-xl flex items-center justify-between text-xs shadow-xs">
              <div className="flex items-center space-x-2 text-slate-700">
                <Search className="h-4 w-4 text-blue-600" />
                <span>
                  Filtering active view for: <strong className="text-slate-900 font-semibold">"{searchQuery}"</strong>
                </span>
              </div>
              <button
                onClick={() => setIsAiModalOpen(true)}
                className="text-blue-600 font-semibold flex items-center hover:underline cursor-pointer"
              >
                <Sparkles className="h-3.5 w-3.5 mr-1 text-blue-600" />
                Ask AI about this
              </button>
            </div>
          )}

          {renderActiveView()}
        </main>
      </div>

      {/* Floating Modals */}
      <AIAssistantModal />
      <SignOffModal />
    </div>
  );
};

export default function App() {
  return (
    <HandoverProvider>
      <MainContent />
    </HandoverProvider>
  );
}
