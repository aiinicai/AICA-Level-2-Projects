import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy initialize Gemini client
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasGeminiKey: Boolean(process.env.GEMINI_API_KEY) });
});

// Gemini AI endpoint for smart handover generation, SOP drafting, 30-60-90 day planning & risk audit
app.post('/api/gemini/generate', async (req, res) => {
  try {
    const { action, payload, prompt } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured. Please ensure your API key is provided in Settings > Secrets.',
      });
    }

    let systemInstruction = 'You are a Chief Financial Officer (CFO) and Senior Finance Transition Specialist. You provide rigorous, structured, professional financial handover documentation, reconciliation workflows, SOPs, internal controls, statutory compliance timelines, and transition roadmaps.';
    let contents = prompt || '';

    if (action === 'generate_role_bible') {
      systemInstruction += ' Generate a comprehensive, high-standard Finance Role Handover package with rich practical insights, checklists, and templates.';
      contents = `Generate comprehensive finance handover content for the role: ${payload?.roleTitle || 'Senior Finance Manager'} in ${payload?.department || 'Finance & Accounts'}.
Context:
- Key focus areas: ${payload?.focusAreas || 'Banking, GL Reconciliation, Tax Compliance, Month-end Close, Stakeholders'}
- Industry / Scope: ${payload?.industry || 'Corporate / Mid-to-Large Enterprise'}
Please return a well-structured JSON response with detailed entries for:
1. roleOverview (responsibilities, KPIs, reportingStructure)
2. processTasks (daily, weekly, monthly, quarterlyAnnual)
3. keySOPs (list of 3-4 critical SOPs with step-by-step instructions, controls, common pitfalls)
4. bankingProtocols (bank accounts, portal access steps, dual auth matrix, token handling)
5. reconciliationWorkflows (bank rec, GL vs subledger, dispute resolution)
6. taxFilingDeadlines (statutory deadlines, penalty risks, filing portals)
7. ongoingProjects (current priorities, deadlines, blockers)
8. knownRisks (pitfalls, workarounds, critical deadlines)
9. plan306090 (day30, day60, day90 milestones)`;
    } else if (action === 'draft_sop') {
      contents = `Create a professional, step-by-step Standard Operating Procedure (SOP) for this Finance task:
Title: ${payload?.title}
Category: ${payload?.category || 'General Finance & Accounting'}
Inputs/Overview: ${payload?.overview || 'Standard financial process'}
Include:
- Objective & Frequency
- Prerequisites & System Access needed
- Step-by-step operational instructions with control checkpoints
- Common pitfalls and what NOT to do
- Output deliverable and sign-off authority`;
    } else if (action === 'generate_30_60_90') {
      contents = `Generate a realistic, actionable 30-60-90 Day Transition Plan for a new hire in the role of "${payload?.role || 'Finance Specialist'}".
Context:
- Reporting to: ${payload?.manager || 'Finance Director'}
- Core responsibilities: ${payload?.responsibilities || 'Month-end closing, statutory compliance, reconciliations, treasury'}
Structure into:
- Days 1-30: Learn & Shadow (Systems, Stakeholders, Shadowing Month-End)
- Days 31-60: Execute with Supervision (Reverse Shadowing, Independent Reconciliations, First cycle close)
- Days 61-90: Independent Ownership & Optimization (Full autonomy, Process improvement, Audit readiness)`;
    } else if (action === 'audit_handover') {
      contents = `Review and audit this Finance handover dataset for completeness, operational risks, single-point-of-failure vulnerabilities, and compliance gaps.
Handover Data: ${JSON.stringify(payload)}
Provide:
- Strengths of the transition plan
- Critical gaps or missing internal controls
- High-risk items (banking access, tax deadlines, key dependencies)
- Recommended immediate action items before the outgoing employee's last working day`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({
      result: response.text,
    });
  } catch (error: any) {
    console.error('Error generating with Gemini:', error);
    return res.status(500).json({
      error: error.message || 'Failed to process AI request',
    });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Finance Handover App server running on http://localhost:${PORT}`);
  });
}

startServer();
