import csv
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

FIELDS = [
    "employee_id", "employee_name", "basic_salary", "hra", "other_allowances",
    "pf_employee_rate", "pf_employer_rate", "esi_employee_rate", "esi_employer_rate",
    "professional_tax", "tds", "other_deductions"
]
OUTPUT_FIELDS = [
    "employee_id", "employee_name", "gross_salary", "employee_pf", "employee_esi",
    "professional_tax", "tds", "other_deductions", "total_deductions", "net_pay",
    "employer_pf", "employer_esi", "employer_cost"
]

def amount(value, field):
    try:
        result = float(str(value).strip().replace(",", ""))
    except (AttributeError, ValueError) as error:
        raise ValueError(f"'{field}' must be a number.") from error
    if result < 0:
        raise ValueError(f"'{field}' cannot be negative.")
    return result

def calculate_payroll(employees):
    results = []
    for employee in employees:
        values = {field: amount(employee[field], field) for field in FIELDS[2:]}
        if not str(employee["employee_id"]).strip() or not str(employee["employee_name"]).strip():
            raise ValueError("Every employee needs an employee_id and employee_name.")
        for field in ("pf_employee_rate", "pf_employer_rate", "esi_employee_rate", "esi_employer_rate"):
            if values[field] > 100:
                raise ValueError(f"'{field}' cannot be greater than 100.")
        gross = values["basic_salary"] + values["hra"] + values["other_allowances"]
        pf_employee = values["basic_salary"] * values["pf_employee_rate"] / 100
        pf_employer = values["basic_salary"] * values["pf_employer_rate"] / 100
        esi_employee = gross * values["esi_employee_rate"] / 100
        esi_employer = gross * values["esi_employer_rate"] / 100
        deductions = pf_employee + esi_employee + values["professional_tax"] + values["tds"] + values["other_deductions"]
        net = gross - deductions
        employer_cost = gross + pf_employer + esi_employer
        results.append({
            "employee_id": str(employee["employee_id"]).strip(),
            "employee_name": str(employee["employee_name"]).strip(),
            "gross_salary": f"{gross:.2f}",
            "employee_pf": f"{pf_employee:.2f}",
            "employee_esi": f"{esi_employee:.2f}",
            "professional_tax": f"{values['professional_tax']:.2f}",
            "tds": f"{values['tds']:.2f}",
            "other_deductions": f"{values['other_deductions']:.2f}",
            "total_deductions": f"{deductions:.2f}",
            "net_pay": f"{net:.2f}",
            "employer_pf": f"{pf_employer:.2f}",
            "employer_esi": f"{esi_employer:.2f}",
            "employer_cost": f"{employer_cost:.2f}",
        })
    return results

class PayrollApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Payroll Calculator")
        self.root.geometry("1180x720")
        self.root.minsize(900, 600)
        self.employees = []
        self.results = []
        self.entries = {}
        self._build()

    def _build(self):
        header = ttk.Frame(self.root, padding=(14, 12))
        header.pack(fill="x")
        ttk.Label(header, text="PAYROLL CALCULATOR", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(header, text="Enter employee details, calculate payroll, and export the payroll register.",
                  font=("Segoe UI", 9)).pack(anchor="w", pady=(3, 0))

        form = ttk.LabelFrame(self.root, text="Employee details", padding=10)
        form.pack(fill="x", padx=14, pady=6)
        labels = [
            ("employee_id", "Employee ID"), ("employee_name", "Employee name"),
            ("basic_salary", "Basic salary"), ("hra", "HRA"),
            ("other_allowances", "Other allowances"), ("pf_employee_rate", "Employee PF rate (%)"),
            ("pf_employer_rate", "Employer PF rate (%)"), ("esi_employee_rate", "Employee ESI rate (%)"),
            ("esi_employer_rate", "Employer ESI rate (%)"), ("professional_tax", "Professional tax"),
            ("tds", "TDS"), ("other_deductions", "Other deductions")
        ]
        for i, (key, label) in enumerate(labels):
            r, c = divmod(i, 4)
            cell = ttk.Frame(form)
            cell.grid(row=r, column=c, sticky="ew", padx=5, pady=4)
            ttk.Label(cell, text=label).pack(anchor="w")
            ent = ttk.Entry(cell, width=24)
            ent.pack(fill="x", pady=(2, 0))
            self.entries[key] = ent
        for c in range(4):
            form.columnconfigure(c, weight=1)

        actions = ttk.Frame(self.root, padding=(14, 5))
        actions.pack(fill="x")
        ttk.Button(actions, text="Add employee", command=self.add_employee).pack(side="left", padx=(0, 6))
        ttk.Button(actions, text="Import CSV", command=self.import_csv).pack(side="left", padx=6)
        ttk.Button(actions, text="Download CSV template", command=self.template).pack(side="left", padx=6)
        ttk.Button(actions, text="Calculate payroll", command=self.calculate).pack(side="left", padx=6)
        ttk.Button(actions, text="Export results CSV", command=self.export).pack(side="left", padx=6)
        ttk.Button(actions, text="Clear all", command=self.clear).pack(side="right")

        self.status = tk.StringVar(value="No employees added yet.")
        ttk.Label(self.root, textvariable=self.status, padding=(14, 4)).pack(anchor="w")

        table_frame = ttk.LabelFrame(self.root, text="Payroll results", padding=8)
        table_frame.pack(fill="both", expand=True, padx=14, pady=(4, 12))
        cols = OUTPUT_FIELDS
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=13)
        for col in cols:
            self.tree.heading(col, text=col.replace("_", " ").title())
            self.tree.column(col, width=112 if col not in ("employee_name",) else 150, minwidth=90, anchor="e")
        self.tree.column("employee_id", anchor="center", width=90)
        self.tree.column("employee_name", anchor="w", width=150)
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

    def _form_record(self):
        return {key: ent.get().strip() for key, ent in self.entries.items()}

    def add_employee(self):
        record = self._form_record()
        if not record["employee_id"] or not record["employee_name"]:
            messagebox.showerror("Missing details", "Employee ID and employee name are required.")
            return
        try:
            for field in FIELDS[2:]:
                amount(record[field], field)
        except ValueError as exc:
            messagebox.showerror("Invalid entry", str(exc))
            return
        self.employees.append(record)
        for ent in self.entries.values():
            ent.delete(0, "end")
        self.status.set(f"{len(self.employees)} employee(s) added.")
        self.results = []
        self._clear_table()

    def import_csv(self):
        path = filedialog.askopenfilename(title="Select employee payroll CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    raise ValueError("The CSV has no header row.")
                missing = [field for field in FIELDS if field not in reader.fieldnames]
                if missing:
                    raise ValueError("Missing CSV column(s): " + ", ".join(missing))
                rows = list(reader)
            if not rows:
                raise ValueError("The input file has no employee rows.")
            # Validate all rows before replacing the current list.
            for row in rows:
                if not row.get("employee_id", "").strip() or not row.get("employee_name", "").strip():
                    raise ValueError("Every employee needs an employee_id and employee_name.")
                vals = {field: amount(row[field], field) for field in FIELDS[2:]}
                for field in ("pf_employee_rate", "pf_employer_rate", "esi_employee_rate", "esi_employer_rate"):
                    if vals[field] > 100:
                        raise ValueError(f"'{field}' cannot be greater than 100.")
            self.employees = rows
            self.results = []
            self._clear_table()
            self.status.set(f"Imported {len(rows)} employee(s) from {Path(path).name}.")
        except Exception as exc:
            messagebox.showerror("Import failed", str(exc))

    def calculate(self):
        if not self.employees:
            messagebox.showwarning("No employees", "Add an employee or import a CSV file first.")
            return
        try:
            self.results = calculate_payroll(self.employees)
            self._clear_table()
            for row in self.results:
                self.tree.insert("", "end", values=[row[c] for c in OUTPUT_FIELDS])
            total_gross = sum(float(r["gross_salary"]) for r in self.results)
            total_net = sum(float(r["net_pay"]) for r in self.results)
            total_cost = sum(float(r["employer_cost"]) for r in self.results)
            self.status.set(
                f"{len(self.results)} employee(s) calculated  |  "
                f"Gross: Rs. {total_gross:,.2f}  |  Net pay: Rs. {total_net:,.2f}  |  "
                f"Employer cost: Rs. {total_cost:,.2f}"
            )
        except ValueError as exc:
            messagebox.showerror("Calculation error", str(exc))

    def export(self):
        if not self.results:
            messagebox.showwarning("No results", "Calculate payroll before exporting.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv",
            initialfile="payroll_output.csv", filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=OUTPUT_FIELDS)
                writer.writeheader()
                writer.writerows(self.results)
            messagebox.showinfo("Export complete", f"Payroll results saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))

    def template(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv",
            initialfile="employee_payroll_input_template.csv", filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(FIELDS)
                writer.writerow(["EMP001", "Sample Employee", "30000", "12000", "3000",
                                 "12", "12", "0.75", "3.25", "200", "0", "0"])
            messagebox.showinfo("Template saved", f"CSV template saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))

    def _clear_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

    def clear(self):
        self.employees = []
        self.results = []
        self._clear_table()
        for ent in self.entries.values():
            ent.delete(0, "end")
        self.status.set("All entries cleared.")

if __name__ == "__main__":
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "vista" in style.theme_names():
            style.theme_use("vista")
    except tk.TclError:
        pass
    PayrollApp(root)
    root.mainloop()
