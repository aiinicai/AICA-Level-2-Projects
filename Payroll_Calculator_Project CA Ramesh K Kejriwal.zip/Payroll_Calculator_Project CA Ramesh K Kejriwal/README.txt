PAYROLL CALCULATOR - WINDOWS DESKTOP APP

Included:
- PayrollCalculator.pyw: desktop GUI application (Tkinter).
- Run_Payroll_Calculator.bat: double-click launcher.
- Build_Windows_EXE.bat: optional Windows script to package as a standalone EXE.
- requirements.txt: PyInstaller build dependency.
- employee_payroll_input_template.csv: starter CSV template.

RUN THE APP
1. Install Python 3 on Windows from https://www.python.org/downloads/
   During installation, enable "Add Python to PATH".
2. Extract this ZIP to a folder.
3. Double-click Run_Payroll_Calculator.bat.

The GUI lets you add employees manually, import a CSV, download a CSV template,
calculate payroll, view the payroll register and export results to CSV.

BUILD A STANDALONE EXE ON WINDOWS
1. Ensure Python 3 is installed.
2. Double-click Build_Windows_EXE.bat.
3. When the build completes, find PayrollCalculator.exe inside the dist folder.
   This build step requires an internet connection the first time to install PyInstaller.

IMPORTANT
This ZIP contains a ready-to-run Python desktop app, not a precompiled Windows EXE.
A Windows EXE cannot be reliably built in this Linux-based file-generation environment.
The included batch file builds the EXE on your Windows PC.

CALCULATION BASIS
Gross salary = Basic + HRA + Other allowances
Employee PF = Basic x employee PF rate / 100
Employer PF = Basic x employer PF rate / 100
Employee / employer ESI = Gross salary x applicable ESI rate / 100
Total deductions = Employee PF + Employee ESI + Professional Tax + TDS + Other deductions
Net pay = Gross salary - Total deductions
Employer cost = Gross salary + Employer PF + Employer ESI

Rates are entered as percentages (e.g. 12 for 12%). This tool applies the same
calculation structure and input validation as the supplied app.py. Verify rates,
eligibility, wage ceilings and statutory applicability before using for live payroll.
