@echo off
cd /d "%~dp0"
py PayrollCalculator.pyw
if errorlevel 1 pause
