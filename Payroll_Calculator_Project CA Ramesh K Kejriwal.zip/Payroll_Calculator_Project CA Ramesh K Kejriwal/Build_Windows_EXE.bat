@echo off
cd /d "%~dp0"
echo Installing PyInstaller...
py -m pip install --upgrade pyinstaller
if errorlevel 1 goto error
echo Building PayrollCalculator.exe...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name PayrollCalculator PayrollCalculator.pyw
if errorlevel 1 goto error
echo.
echo Build complete. EXE is in the dist folder.
pause
exit /b 0
:error
echo Build failed. Check the messages above.
pause
exit /b 1
