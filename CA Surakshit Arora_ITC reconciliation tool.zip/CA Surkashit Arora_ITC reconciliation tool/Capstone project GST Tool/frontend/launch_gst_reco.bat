@echo off
cd /d "%~dp0.."
call start_gst_reconciliation.bat
