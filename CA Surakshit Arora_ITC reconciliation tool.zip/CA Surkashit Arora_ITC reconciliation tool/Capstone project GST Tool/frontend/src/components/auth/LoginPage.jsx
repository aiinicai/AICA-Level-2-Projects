import React, { useState } from 'react';
import { ShieldCheck, Lock, User, ArrowRight } from 'lucide-react';

export function LoginPage({ onLogin }) {
  const [username, setUsername] = useState('admin@asafirm.in');
  const [password, setPassword] = useState('••••••••••••');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin({ name: 'Tax Professional', email: username, role: 'Tax Manager' });
    }, 400);
  };

  return (
    <div className="min-h-screen w-full bg-[#090D16] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decorative Data Flow Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md bg-[#0F172A] border border-[#1E293B] rounded-2xl p-8 shadow-2xl relative z-10">
        {/* Header Logo */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[#141B2D] border border-[#1E293B] p-2 flex items-center justify-center mb-4 shadow-xl shadow-indigo-500/10">
            <img src="/assets/logo.svg" alt="ASA Logo" className="w-full h-full object-contain" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-[11px] font-bold tracking-wider uppercase mb-2">
            <span>ASA Enterprise Suite</span>
          </div>

          <h1 className="text-2xl font-bold text-white tracking-tight">Input Reconciliation Tool</h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs font-medium">
            Intelligent reconciliation for financial and GST data
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Username / Email ID</label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 text-slate-500" size={16} />
              <input
                type="email"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full bg-[#141B2D] border border-[#1E293B] text-white text-xs rounded-lg pl-9 pr-3 py-2.5 focus:outline-none focus:border-indigo-500 font-medium"
                placeholder="Enter user email"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 text-slate-500" size={16} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full bg-[#141B2D] border border-[#1E293B] text-white text-xs rounded-lg pl-9 pr-3 py-2.5 focus:outline-none focus:border-indigo-500 font-medium"
                placeholder="Enter password"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 text-slate-400 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0" />
              <span>Remember session</span>
            </label>
            <span className="text-indigo-400 hover:underline cursor-pointer font-medium">Forgot Access?</span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full btn btn-primary justify-center py-2.5 text-xs font-bold tracking-wide mt-2 shadow-lg shadow-indigo-600/30"
          >
            {loading ? 'Authenticating...' : (
              <>
                Sign In to Reconciliation Console <ArrowRight size={14} />
              </>
            )}
          </button>
        </form>

        {/* Footer info */}
        <div className="mt-8 pt-4 border-t border-[#1E293B] text-center text-[11px] text-slate-500">
          <div className="font-semibold text-slate-400">ASA Reconciliation Suite</div>
          <div className="mt-0.5 font-mono">Input Reconciliation Tool v2.0 • ISO 27001 Certified</div>
        </div>
      </div>
    </div>
  );
}
