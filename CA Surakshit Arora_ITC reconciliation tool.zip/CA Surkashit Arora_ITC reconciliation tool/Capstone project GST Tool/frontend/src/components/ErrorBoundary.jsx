import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('GST App UI Error Boundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0B0F17] text-white flex flex-col items-center justify-center p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
            <AlertTriangle size={32} />
          </div>
          <h2 className="text-xl font-bold">GST Application Interface Notice</h2>
          <p className="text-sm text-slate-400 max-w-md font-mono bg-[#141B2D] p-3 rounded-lg border border-[#1E293B]">
            {this.state.error?.toString() || 'An unexpected rendering error occurred.'}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="btn btn-primary text-xs px-6 py-2.5"
          >
            <RefreshCw size={14} /> Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
