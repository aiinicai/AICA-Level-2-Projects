import React, { useState } from 'react';
import { 
  LayoutDashboard, Upload, GitCompare, Store, AlertTriangle, 
  Settings, FileSpreadsheet, History, Users, ShieldCheck, RotateCcw, 
  AlertCircle, ChevronLeft, ChevronRight, HelpCircle, User, Sparkles
} from 'lucide-react';
import { clearReconciliationData } from '../../services/api';

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'clients', label: 'Clients Master', icon: Users },
  { id: 'reconciliation', label: 'Reconciliation Grid', icon: GitCompare },
  { id: 'upload', label: 'Upload Centre', icon: Upload },
  { id: 'exceptions', label: 'Exception Centre', icon: AlertTriangle },
  { id: 'reports', label: 'Reports & Exports', icon: FileSpreadsheet },
  { id: 'rules', label: 'Rules & Tolerances', icon: Settings },
  { id: 'help', label: 'Help & Docs', icon: HelpCircle },
];

export const FY_MONTHS_MAP = {
  '2026-27': [
    'All Months',
    'April 2026', 'May 2026', 'June 2026', 'July 2026',
    'August 2026', 'September 2026', 'October 2026', 'November 2026',
    'December 2026', 'January 2027', 'February 2027', 'March 2027'
  ],
  '2027-28': [
    'All Months',
    'April 2027', 'May 2027', 'June 2027', 'July 2027',
    'August 2027', 'September 2027', 'October 2027', 'November 2027',
    'December 2027', 'January 2028', 'February 2028', 'March 2028'
  ]
};

export function Sidebar({ activeTab, setActiveTab }) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={`${collapsed ? 'w-16' : 'w-60'} bg-[#0F172A] border-r border-[#1E293B] flex flex-col h-full shrink-0 transition-all duration-200`}>
      {/* ASA Brand Header */}
      <div className="p-3.5 border-b border-[#1E293B] flex items-center justify-between">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-[#141B2D] border border-[#1E293B] p-1 flex items-center justify-center shrink-0 shadow-md">
            <img src="/assets/asa-mark.svg" alt="ASA" className="w-full h-full object-contain" />
          </div>
          {!collapsed && (
            <div className="truncate">
              <h1 className="text-sm font-extrabold text-white tracking-wide">ASA</h1>
              <p className="text-[10px] text-teal-400 font-semibold tracking-wider uppercase truncate">Reconciliation Suite</p>
            </div>
          )}
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-[#1E293B]"
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                isActive 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20' 
                  : 'text-slate-400 hover:bg-[#1E293B] hover:text-slate-200'
              }`}
              title={collapsed ? item.label : undefined}
            >
              <Icon size={17} className={isActive ? 'text-white' : 'text-slate-400'} />
              {!collapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Status Footer */}
      {!collapsed && (
        <div className="p-3 border-t border-[#1E293B] bg-[#0B0F17]/50 text-[11px]">
          <div className="flex items-center justify-between text-slate-400 font-mono">
            <span>Engine:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> ONLINE
            </span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">ASA Enterprise v2.0</div>
        </div>
      )}
    </aside>
  );
}

export function Header({ 
  currentClient, 
  clients, 
  onSelectClient, 
  selectedFy, 
  setSelectedFy, 
  selectedMonth, 
  setSelectedMonth,
  onDataCleared
}) {
  const [showClearModal, setShowClearModal] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  const monthsList = FY_MONTHS_MAP[selectedFy] || FY_MONTHS_MAP['2026-27'];

  const handleConfirmClear = async () => {
    setIsClearing(true);
    try {
      await clearReconciliationData(currentClient?.id);
      setShowClearModal(false);
      if (onDataCleared) onDataCleared();
    } catch (err) {
      console.error(err);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <>
      <header className="h-16 bg-[#0F172A] border-b border-[#1E293B] px-4 flex items-center justify-between shrink-0 overflow-hidden">
        {/* Left Branding Title */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-[#141B2D] border border-[#1E293B] p-1 flex items-center justify-center shadow-sm shrink-0">
            <img src="/assets/asa-mark.svg" alt="ASA Mark" className="w-full h-full object-contain" />
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5 leading-tight">
              Input Reconciliation Tool
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-teal-500/10 text-teal-400 border border-teal-500/20">ASA</span>
            </h2>
            <p className="text-[10px] text-slate-400 font-medium">Purchase Register vs 2B</p>
          </div>
        </div>

        {/* Right Selector Bar & Professional Profile */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Active Client Selector */}
          <div className="flex flex-col justify-center">
            <span className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider leading-none mb-0.5">Active Client</span>
            <select
              value={currentClient?.id || ''}
              onChange={(e) => {
                const cl = (clients || []).find(c => c.id === e.target.value);
                if (cl) onSelectClient(cl);
              }}
              className="bg-[#141B2D] border border-[#1E293B] text-white text-xs font-bold rounded px-2 py-1 focus:outline-none focus:border-indigo-500 cursor-pointer max-w-[170px] truncate"
            >
              {(!clients || clients.length === 0) ? (
                <option value="">Loading Clients...</option>
              ) : (
                clients.map(c => (
                  <option key={c.id} value={c.id}>{c.client_name} ({c.gstin})</option>
                ))
              )}
            </select>
          </div>

          <div className="h-6 w-[1px] bg-[#1E293B] self-center"></div>

          {/* Financial Year Selector */}
          <div className="flex flex-col justify-center">
            <span className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider leading-none mb-0.5">Financial Year</span>
            <select
              value={selectedFy}
              onChange={(e) => {
                const newFy = e.target.value;
                setSelectedFy(newFy);
                setSelectedMonth(FY_MONTHS_MAP[newFy][1]);
              }}
              className="bg-[#141B2D] border border-[#1E293B] text-white text-xs font-semibold rounded px-2 py-1 focus:outline-none focus:border-indigo-500 cursor-pointer font-mono"
            >
              <option value="2026-27">2026-27</option>
              <option value="2027-28">2027-28</option>
            </select>
          </div>

          {/* Month Selector */}
          <div className="flex flex-col justify-center">
            <span className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider leading-none mb-0.5">Tax Month</span>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-[#141B2D] border border-[#1E293B] text-white text-xs font-semibold rounded px-2 py-1 focus:outline-none focus:border-indigo-500 cursor-pointer font-mono"
            >
              {monthsList.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* RESET JOB BUTTON */}
          <div className="flex items-center">
            <button
              onClick={() => setShowClearModal(true)}
              className="btn btn-secondary text-xs px-2.5 py-1 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border-rose-500/30 flex items-center gap-1"
              title="Clear fed reconciliation data to upload fresh files"
            >
              <RotateCcw size={12} />
              <span>Reset Job</span>
            </button>
          </div>

          <div className="h-6 w-[1px] bg-[#1E293B] self-center"></div>

          {/* Professional Badge - Clean & Catchy */}
          <div className="flex items-center gap-2 pl-0.5 shrink-0">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 via-teal-500 to-emerald-400 p-0.5 shadow-md flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-[#0F172A] rounded-full flex items-center justify-center font-bold text-[10px] text-teal-300">
                ASA
              </div>
            </div>
            <div className="hidden lg:block text-left shrink-0">
              <span className="text-xs font-extrabold text-slate-200 block leading-tight">Professional Console</span>
              <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <Sparkles size={10} /> Verified Suite
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* CLEAR DATA CONFIRMATION MODAL */}
      {showClearModal && (
        <div className="modal-overlay">
          <div className="modal-content max-w-md">
            <div className="modal-header border-b-rose-500/30">
              <div className="flex items-center gap-2 text-rose-400">
                <AlertCircle size={20} />
                <h3 className="text-base font-bold text-white">Reset Reconciliation Data</h3>
              </div>
              <button onClick={() => setShowClearModal(false)} className="text-slate-400">✕</button>
            </div>

            <div className="modal-body space-y-3 text-xs">
              <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
                <div className="font-bold text-white text-sm">{currentClient?.client_name || 'Active Client'}</div>
                <div className="font-mono text-indigo-400 font-semibold">{currentClient?.gstin || ''}</div>
              </div>

              <p className="text-slate-200 font-semibold text-sm">
                Are you sure you want to clear uploaded data?
              </p>
              <p className="text-slate-400">
                This will reset the dashboard and reconciliation tables for this client so you can upload fresh Purchase Register and GSTR-2B files.
              </p>
            </div>

            <div className="modal-footer">
              <button onClick={() => setShowClearModal(false)} className="btn btn-secondary text-xs">
                Cancel
              </button>
              <button onClick={handleConfirmClear} disabled={isClearing} className="btn btn-danger text-xs px-4">
                {isClearing ? 'Resetting Data...' : 'Reset All Data'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
