import React, { useState } from 'react';
import { X, CheckCircle, AlertTriangle, XCircle, Sparkles, ShieldCheck, FileText, Check, Ban, Eye } from 'lucide-react';

export function SideBySideModal({ result, onClose, onManualOverride }) {
  if (!result) return null;

  const [reason, setReason] = useState('');
  const b = result.books_record || {};
  const g = result.gstr2b_record || {};

  const handleAction = (action) => {
    onManualOverride(result.id, action, reason || 'Manual Review Decision');
    onClose();
  };

  const getStatusBadgeClass = (st) => {
    if (st.includes('EXACT MATCH') || st.includes('MATCHED')) return 'badge-exact';
    if (st.includes('TAX DIFFERENCE') || st.includes('PROBABLE')) return 'badge-tax-diff';
    if (st.includes('BOOKS ONLY')) return 'badge-books-only';
    if (st.includes('2B ONLY')) return 'badge-2b-only';
    return 'badge-tax-diff';
  };

  // Comparative analysis checks
  const gstinMatch = Boolean(b.gstin && g.gstin && b.gstin === g.gstin);
  const invNoMatch = Boolean(b.norm_invoice_number && g.norm_invoice_number && b.norm_invoice_number === g.norm_invoice_number);
  const taxableMatch = Math.abs((b.taxable_value || 0) - (g.taxable_value || 0)) <= 2.0;
  const taxMatch = Math.abs((b.total_tax || 0) - (g.total_tax || 0)) <= 1.0;
  const dateDiffDays = result.date_diff_days;

  const formatAmt = (amt) => `₹${(amt || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Human-Readable Difference Narrative Generator
  let differenceExplanation = result.match_notes || 'Reconciliation completed by engine.';
  if (b.gstin && g.gstin && b.gstin === g.gstin) {
    if (Math.abs(result.total_tax_diff || 0) > 0.01) {
      differenceExplanation = `Invoice number and GSTIN match. ITC in Books is ₹${(b.total_tax || 0).toLocaleString('en-IN')} whereas GSTR-2B reflects ₹${(g.total_tax || 0).toLocaleString('en-IN')}, resulting in an ITC difference of ₹${Math.abs(result.total_tax_diff || 0).toLocaleString('en-IN')}.`;
    } else if (dateDiffDays > 0) {
      differenceExplanation = `Invoice number and GSTIN match cleanly. ITC values are reconciled within tolerance. Invoice date differs by ${dateDiffDays} day(s).`;
    } else {
      differenceExplanation = `All parameters (GSTIN, Invoice Number, Date, and Tax Amount) are fully reconciled and verified.`;
    }
  } else if (!g.gstin && b.gstin) {
    differenceExplanation = `Transaction recorded in Purchase Register (Books) for ₹${(b.total_tax || 0).toLocaleString('en-IN')} ITC, but not identified in GSTR-2B portal statement. Ineligible under Rule 36(4).`;
  } else if (!b.gstin && g.gstin) {
    differenceExplanation = `Transaction auto-drafted in GSTR-2B portal for ₹${(g.total_tax || 0).toLocaleString('en-IN')} ITC, but not recorded in Purchase Register. Potential unclaimed credit opportunity.`;
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content max-w-4xl">
        {/* Header */}
        <div className="modal-header">
          <div className="flex items-center gap-3">
            <ShieldCheck size={24} className="text-indigo-400" />
            <div>
              <h3 className="text-base font-bold text-white">Invoice Reconciliation Details</h3>
              <p className="text-xs text-slate-400">ASA Invoice Verification Console</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="modal-body space-y-5">
          {/* Side by Side 2-Column Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* SECTION 1: BOOKS DATA */}
            <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
                <span className="font-extrabold text-indigo-400 uppercase tracking-wider text-xs">SECTION 1: BOOKS DATA</span>
                <span className="text-[10px] text-slate-500 font-mono">Purchase Register</span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Supplier GSTIN</span>
                <span className="font-mono font-bold text-white">{b.gstin || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Vendor Name</span>
                <span className="font-semibold text-white truncate max-w-[180px]">{b.vendor_name || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Books Invoice No.</span>
                <span className="font-mono font-bold text-indigo-300">{b.original_invoice_number || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Books Invoice Date</span>
                <span className="text-white font-mono">{b.invoice_date_str || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Taxable Value</span>
                <span className="font-mono font-semibold text-white">{formatAmt(b.taxable_value)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">IGST / CGST / SGST</span>
                <span className="font-mono text-slate-300">{formatAmt(b.igst)} / {formatAmt(b.cgst)}</span>
              </div>
              <div className="flex justify-between py-1.5 font-bold text-white pt-1">
                <span>Books Total ITC</span>
                <span className="text-indigo-400 font-mono text-sm">{formatAmt(b.total_tax)}</span>
              </div>
            </div>

            {/* SECTION 2: GSTR-2B DATA */}
            <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
                <span className="font-extrabold text-blue-400 uppercase tracking-wider text-xs">SECTION 2: GSTR-2B DATA</span>
                <span className="text-[10px] text-slate-500 font-mono">GST Portal Statement</span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Supplier GSTIN</span>
                <span className="font-mono font-bold text-white">{g.gstin || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Vendor Name</span>
                <span className="font-semibold text-white truncate max-w-[180px]">{g.vendor_name || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">2B Invoice No.</span>
                <span className="font-mono font-bold text-blue-300">{g.original_invoice_number || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">2B Invoice Date</span>
                <span className="text-white font-mono">{g.invoice_date_str || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">Taxable Value</span>
                <span className="font-mono font-semibold text-white">{formatAmt(g.taxable_value)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400 font-medium">IGST / CGST / SGST</span>
                <span className="font-mono text-slate-300">{formatAmt(g.igst)} / {formatAmt(g.cgst)}</span>
              </div>
              <div className="flex justify-between py-1.5 font-bold text-white pt-1">
                <span>GSTR-2B Total ITC</span>
                <span className="text-blue-400 font-mono text-sm">{formatAmt(g.total_tax)}</span>
              </div>
            </div>
          </div>

          {/* SECTION 3: MATCHING ANALYSIS */}
          <div className="bg-[#141B2D] p-4 rounded-xl border border-[#1E293B] space-y-3">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
              <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">SECTION 3: MATCHING ANALYSIS</h4>
              <span className={`badge ${getStatusBadgeClass(result.match_status)}`}>{result.match_status}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="flex items-center gap-2 p-2 rounded bg-[#0F172A] border border-[#1E293B]">
                {gstinMatch ? <CheckCircle size={16} className="text-emerald-400" /> : <XCircle size={16} className="text-rose-400" />}
                <div>
                  <span className="text-slate-400 block text-[10px]">GSTIN</span>
                  <span className={gstinMatch ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {gstinMatch ? '✓ Matched' : '✗ Mismatch'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 rounded bg-[#0F172A] border border-[#1E293B]">
                {invNoMatch ? <CheckCircle size={16} className="text-emerald-400" /> : <AlertTriangle size={16} className="text-amber-400" />}
                <div>
                  <span className="text-slate-400 block text-[10px]">Invoice No.</span>
                  <span className={invNoMatch ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                    {invNoMatch ? '✓ Matched' : '⚠ Variation'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 rounded bg-[#0F172A] border border-[#1E293B]">
                {taxMatch ? <CheckCircle size={16} className="text-emerald-400" /> : <XCircle size={16} className="text-rose-400" />}
                <div>
                  <span className="text-slate-400 block text-[10px]">ITC Amount</span>
                  <span className={taxMatch ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {taxMatch ? '✓ Matched' : `₹${Math.abs(result.total_tax_diff || 0).toLocaleString()} Diff`}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 rounded bg-[#0F172A] border border-[#1E293B]">
                {dateDiffDays === null || dateDiffDays === 0 ? (
                  <CheckCircle size={16} className="text-emerald-400" />
                ) : (
                  <AlertTriangle size={16} className="text-amber-400" />
                )}
                <div>
                  <span className="text-slate-400 block text-[10px]">Invoice Date</span>
                  <span className={dateDiffDays === null || dateDiffDays === 0 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                    {dateDiffDays === null || dateDiffDays === 0 ? '✓ Matched' : `⚠ ${dateDiffDays}d Diff`}
                  </span>
                </div>
              </div>
            </div>

            {/* HUMAN-READABLE DIFFERENCE NARRATIVE */}
            <div className="bg-[#0F172A] p-3 rounded-lg border border-indigo-500/30 text-xs">
              <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-1">Human-Readable Mismatch Narrative</div>
              <p className="text-slate-200 leading-relaxed font-medium">
                {differenceExplanation}
              </p>
            </div>
          </div>

          {/* Audit Note & Action */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">Auditor Remarks / Override Justification</label>
            <input
              type="text"
              placeholder="Enter audit remark for accepting or forcing match decision..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="modal-footer">
          <button onClick={() => handleAction('REJECT')} className="btn btn-danger text-xs">
            <Ban size={14} /> Reject Match
          </button>
          <button onClick={() => handleAction('ACCEPT')} className="btn btn-success text-xs">
            <Check size={14} /> Accept Match
          </button>
        </div>
      </div>
    </div>
  );
}
