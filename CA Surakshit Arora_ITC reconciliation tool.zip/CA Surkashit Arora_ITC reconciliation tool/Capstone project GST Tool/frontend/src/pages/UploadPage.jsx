import React, { useState } from 'react';
import { Upload, FileSpreadsheet, Download, CheckCircle, ArrowRight, Play, AlertCircle } from 'lucide-react';
import { inspectUploadFile, runReconciliationJob, getTemplateUrl } from '../services/api';

export function UploadPage({ currentClient, selectedFy, selectedMonth, onRunComplete }) {
  const [booksFile, setBooksFile] = useState(null);
  const [g2bFile, setG2bFile] = useState(null);

  const [booksInspection, setBooksInspection] = useState(null);
  const [g2bInspection, setG2bInspection] = useState(null);

  const [booksMapping, setBooksMapping] = useState({});
  const [g2bMapping, setG2bMapping] = useState({});

  const [isInspectingBooks, setIsInspectingBooks] = useState(false);
  const [isInspectingG2b, setIsInspectingG2b] = useState(false);

  const [isExecuting, setIsExecuting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleBooksFileChange = async (file) => {
    setBooksFile(file);
    if (!file) return;
    setIsInspectingBooks(true);
    setErrorMsg('');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await inspectUploadFile(formData);
      setBooksInspection(res.data);
      setBooksMapping(res.data.auto_mapping || {});
    } catch (err) {
      setErrorMsg(err.response?.data?.detail || 'Failed to inspect Purchase Register file');
    } finally {
      setIsInspectingBooks(false);
    }
  };

  const handleG2bFileChange = async (file) => {
    setG2bFile(file);
    if (!file) return;
    setIsInspectingG2b(true);
    setErrorMsg('');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await inspectUploadFile(formData);
      setG2bInspection(res.data);
      setG2bMapping(res.data.auto_mapping || {});
    } catch (err) {
      setErrorMsg(err.response?.data?.detail || 'Failed to inspect GSTR-2B file');
    } finally {
      setIsInspectingG2b(false);
    }
  };

  const handleRunReconciliation = async () => {
    if (!booksFile || !g2bFile) {
      setErrorMsg('Please select both Purchase Register and GSTR-2B files');
      return;
    }

    setIsExecuting(true);
    setErrorMsg('');

    try {
      const formData = new FormData();
      formData.append('client_id', currentClient.id);
      formData.append('financial_year', selectedFy);
      formData.append('tax_period', selectedMonth);
      formData.append('books_file', booksFile);
      formData.append('gstr2b_file', g2bFile);
      formData.append('books_mapping_json', JSON.stringify(booksMapping));
      formData.append('gstr2b_mapping_json', JSON.stringify(g2bMapping));

      const res = await runReconciliationJob(formData);
      onRunComplete(res.data);
    } catch (err) {
      setErrorMsg(err.response?.data?.detail || 'Failed to run reconciliation');
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Upload Centre & Column Detection</h2>
          <p className="text-xs text-slate-400">
            Upload Purchase Register (Books) and GSTR-2B files for <span className="text-indigo-300 font-semibold">{currentClient?.client_name}</span> ({selectedFy} | {selectedMonth})
          </p>
        </div>

        {/* Template Downloads */}
        <div className="flex gap-2">
          <a
            href={getTemplateUrl('Purchase_Register_Template.xlsx')}
            download
            className="btn btn-secondary text-xs"
          >
            <Download size={14} /> Purchase Register Template
          </a>
          <a
            href={getTemplateUrl('GSTR_2B_Template.xlsx')}
            download
            className="btn btn-secondary text-xs"
          >
            <Download size={14} /> GSTR-2B Template
          </a>
        </div>
      </div>

      {errorMsg && (
        <div className="bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs p-3.5 rounded-lg flex items-center gap-2">
          <AlertCircle size={16} /> {errorMsg}
        </div>
      )}

      {/* Upload Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Purchase Register */}
        <div className="glass-card flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold text-xs">
                1
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Purchase Register (Books)</h3>
                <p className="text-[11px] text-slate-400">Excel file from Tally / ERP / Accounting Software</p>
              </div>
            </div>

            <label className="border-2 border-dashed border-[#1E293B] hover:border-indigo-500/50 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition bg-[#0B0F17]/40 mb-4">
              <Upload size={28} className="text-indigo-400 mb-2" />
              <span className="text-xs font-semibold text-slate-200 mb-1">
                {booksFile ? booksFile.name : 'Choose Purchase Register Excel'}
              </span>
              <span className="text-[11px] text-slate-500">Supports .xlsx, .xls, .csv</span>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => handleBooksFileChange(e.target.files[0])}
              />
            </label>

            {/* Column Mapping Feedback */}
            {booksInspection && (
              <div className="bg-[#0F172A] p-3.5 rounded-lg border border-[#1E293B] text-xs space-y-2">
                <div className="flex justify-between font-bold text-emerald-400">
                  <span>Total Records: {booksInspection.total_rows}</span>
                  <span>{Object.values(booksMapping).filter(Boolean).length} Columns Auto-Mapped</span>
                </div>
                <div className="text-[11px] text-slate-300 space-y-1 font-mono">
                  <div>GSTIN $\rightarrow$ <span className="text-indigo-400">{booksMapping.gstin || 'Not Detected'}</span></div>
                  <div>Invoice Number $\rightarrow$ <span className="text-indigo-400">{booksMapping.invoice_number || 'Not Detected'}</span></div>
                  <div>Invoice Date $\rightarrow$ <span className="text-indigo-400">{booksMapping.invoice_date || 'Not Detected'}</span></div>
                  <div>ITC Amount $\rightarrow$ <span className="text-indigo-400">{booksMapping.itc_total || booksMapping.igst || 'Not Detected'}</span></div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Card 2: GSTR-2B */}
        <div className="glass-card flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                2
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">GSTR-2B Statement</h3>
                <p className="text-[11px] text-slate-400">Excel or JSON downloaded from GST Portal</p>
              </div>
            </div>

            <label className="border-2 border-dashed border-[#1E293B] hover:border-blue-500/50 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition bg-[#0B0F17]/40 mb-4">
              <Upload size={28} className="text-blue-400 mb-2" />
              <span className="text-xs font-semibold text-slate-200 mb-1">
                {g2bFile ? g2bFile.name : 'Choose GSTR-2B Excel or JSON'}
              </span>
              <span className="text-[11px] text-slate-500">Supports .xlsx, .json, .csv</span>
              <input
                type="file"
                accept=".xlsx,.xls,.json,.csv"
                className="hidden"
                onChange={(e) => handleG2bFileChange(e.target.files[0])}
              />
            </label>

            {/* Column Mapping Feedback */}
            {g2bInspection && (
              <div className="bg-[#0F172A] p-3.5 rounded-lg border border-[#1E293B] text-xs space-y-2">
                <div className="flex justify-between font-bold text-emerald-400">
                  <span>Total Records: {g2bInspection.total_rows}</span>
                  <span>{Object.values(g2bMapping).filter(Boolean).length} Columns Auto-Mapped</span>
                </div>
                <div className="text-[11px] text-slate-300 space-y-1 font-mono">
                  <div>GSTIN $\rightarrow$ <span className="text-blue-400">{g2bMapping.gstin || 'Not Detected'}</span></div>
                  <div>Invoice Number $\rightarrow$ <span className="text-blue-400">{g2bMapping.invoice_number || 'Not Detected'}</span></div>
                  <div>Invoice Date $\rightarrow$ <span className="text-blue-400">{g2bMapping.invoice_date || 'Not Detected'}</span></div>
                  <div>ITC Amount $\rightarrow$ <span className="text-blue-400">{g2bMapping.itc_total || g2bMapping.igst || 'Not Detected'}</span></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SECTION 22 RECONCILIATION PREVIEW & START BUTTON */}
      {(booksInspection || g2bInspection) && (
        <div className="glass-card p-6 bg-gradient-to-r from-indigo-950/60 via-[#141B2D] to-indigo-950/60 border-indigo-500/40 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <CheckCircle size={18} className="text-emerald-400" />
            RECONCILIATION PREVIEW SUMMARY
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
            <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
              <span className="text-slate-400 block">Purchase Register</span>
              <span className="text-lg font-bold text-indigo-400">{booksInspection?.total_rows || 0} Records</span>
            </div>
            <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
              <span className="text-slate-400 block">GSTR-2B Statement</span>
              <span className="text-lg font-bold text-blue-400">{g2bInspection?.total_rows || 0} Records</span>
            </div>
            <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
              <span className="text-slate-400 block">Financial Year</span>
              <span className="text-lg font-bold text-white">{selectedFy}</span>
            </div>
            <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
              <span className="text-slate-400 block">Tax Month</span>
              <span className="text-lg font-bold text-white">{selectedMonth}</span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[#1E293B]">
            <p className="text-xs text-slate-300">
              Primary Matching Keys: <span className="font-semibold text-indigo-300">GSTIN + Invoice Number + Invoice Date + Total ITC</span>
            </p>
            <button
              onClick={handleRunReconciliation}
              disabled={!booksFile || !g2bFile || isExecuting}
              className="btn btn-primary px-8 py-3 text-sm shadow-xl"
            >
              {isExecuting ? (
                <span>Processing 1-to-1 Waterfall Engine...</span>
              ) : (
                <>
                  <Play size={16} />
                  <span>START RECONCILIATION</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
