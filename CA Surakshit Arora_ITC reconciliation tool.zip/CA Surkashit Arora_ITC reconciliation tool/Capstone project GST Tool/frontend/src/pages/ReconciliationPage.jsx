import React, { useState, useEffect } from 'react';
import { Search, Filter, Download, Eye, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';
import { getJobResults, getExportExcelUrl, manualMatchOverride } from '../services/api';
import { SideBySideModal } from '../components/reconciliation/SideBySideModal';

export function ReconciliationPage({ activeJobId }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [selectedResult, setSelectedResult] = useState(null);

  const fetchResults = async () => {
    if (!activeJobId) return;
    setLoading(true);
    try {
      const res = await getJobResults(activeJobId, {
        status_filter: statusFilter || undefined,
        search: search || undefined,
      });
      setResults(res.data.results || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResults();
  }, [activeJobId, statusFilter, search]);

  const handleManualOverride = async (resultId, action, reason) => {
    try {
      await manualMatchOverride({
        result_id: resultId,
        action,
        reason,
        user_name: 'Tax Professional',
      });
      fetchResults();
    } catch (err) {
      console.error(err);
    }
  };

  const getStatusBadge = (status) => {
    const st = String(status);
    if (st === 'MATCHED') return <span className="badge badge-exact">✓ MATCHED</span>;
    if (st.includes('DATE DIFFERENCE') || st.includes('ITC DIFFERENCE')) return <span className="badge badge-tax-diff">⚠ {st}</span>;
    if (st.includes('PROBABLE')) return <span className="badge badge-probable">ℹ PROBABLE MATCH</span>;
    if (st === 'BOOKS ONLY') return <span className="badge badge-books-only">✕ BOOKS ONLY</span>;
    if (st === '2B ONLY') return <span className="badge badge-2b-only">2B ONLY</span>;
    if (st === 'DUPLICATE IN BOOKS') return <span className="badge badge-duplicate">DUPLICATE IN BOOKS</span>;
    if (st === 'DUPLICATE IN 2B') return <span className="badge badge-duplicate">DUPLICATE IN 2B</span>;
    if (st.includes('DUPLICATE')) return <span className="badge badge-duplicate">DUPLICATE</span>;
    if (st.includes('INVOICE NUMBER MATCH')) return <span className="badge badge-probable">ℹ NO GSTIN</span>;
    return <span className="badge badge-tax-diff">{st}</span>;
  };

  const getAuditRemarkText = (r) => {
    const b = r.books_record;
    const g = r.gstr2b_record;
    const st = String(r.match_status);
    const taxDiff = Math.abs(r.total_tax_diff || 0.0);

    if (st === 'MATCHED') {
      return "Fully matched & verified. Eligible for GSTR-3B ITC claim.";
    } else if (st.includes('MATCHED_DATE_DIFF')) {
      return `GSTIN & Invoice No matched; Tax matched. Date diff: ${r.date_diff_days} day(s).`;
    } else if (st.includes('MATCHED_TAX_DIFF')) {
      return `GSTIN & Invoice No matched. Books ITC: ₹${(b?.total_tax || 0).toLocaleString()} vs 2B ITC: ₹${(g?.total_tax || 0).toLocaleString()} (Variance: ₹${taxDiff.toLocaleString()}).`;
    } else if (st.includes('BOOKS ONLY')) {
      return `Present in Purchase Register only (₹${(b?.total_tax || 0).toLocaleString()}). Missing in GSTR-2B (Rule 36(4) Risk).`;
    } else if (st.includes('2B ONLY')) {
      return `Present in GSTR-2B portal only (₹${(g?.total_tax || 0).toLocaleString()}). Not in Purchase Register.`;
    } else if (st.includes('DUPLICATE IN BOOKS')) {
      return `Duplicate entry in Purchase Register (Books ITC: ₹${(b?.total_tax || 0).toLocaleString()}).`;
    } else if (st.includes('DUPLICATE IN 2B')) {
      return `Duplicate entry in GSTR-2B portal (2B ITC: ₹${(g?.total_tax || 0).toLocaleString()}).`;
    } else if (st.includes('PROBABLE')) {
      return `Probable match based on invoice similarity (${r.match_score}%). Review required.`;
    } else {
      return r.match_notes || "Review required by tax professional.";
    }
  };

  const formatAmt = (val) => (val !== undefined && val !== null ? `₹${val.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : '-');

  // STRICT, MUTUALLY EXCLUSIVE FRONTEND TAB ISOLATION
  const filteredResults = results.filter((r) => {
    const st = String(r.match_status || '').toUpperCase();

    if (statusFilter === 'MATCHED') {
      // ONLY exact 2-sided matched records with zero variance (no DIFFERENCE in status)
      return (st === 'MATCHED' || (st.includes('INVOICE NUMBER MATCH') && !st.includes('DIFFERENCE'))) && !st.includes('DIFFERENCE');
    }
    if (statusFilter === 'ITC_DIFF') {
      // ONLY matched records where status explicitly contains DIFFERENCE / VARIANCE
      // ABSOLUTELY EXCLUDE BOOKS ONLY, 2B ONLY, and DUPLICATE records!
      if (st.includes('BOOKS') || st.includes('2B ONLY') || st.includes('DUPLICATE')) {
        return false;
      }
      return st.includes('ITC DIFFERENCE') || st.includes('TAX DIFFERENCE') || st.includes('DATE DIFFERENCE') || st.includes('DIFFERENCE');
    }
    if (statusFilter === 'BOOKS ONLY') {
      // ONLY exact BOOKS ONLY records
      return st === 'BOOKS ONLY';
    }
    if (statusFilter === '2B ONLY') {
      // ONLY exact 2B ONLY records
      return st === '2B ONLY';
    }
    return true;
  });

  if (!activeJobId) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <h3 className="text-base font-bold text-white mb-2">No Active Reconciliation Job Selected</h3>
        <p className="text-xs text-slate-400">Please run a job in the Upload Centre to view the invoice reconciliation grid.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Invoice-Wise Reconciliation Table</h2>
          <p className="text-xs text-slate-400">Invoice-level audit comparison of Purchase Register vs GSTR-2B</p>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={fetchResults} className="btn btn-secondary text-xs">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh Grid
          </button>
          <a
            href={getExportExcelUrl(activeJobId)}
            download
            className="btn btn-success text-xs"
          >
            <Download size={14} /> Download Excel Report (.xlsx)
          </a>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="glass-card p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search size={14} className="absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search GSTIN, Invoice No, Vendor Name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg pl-8 pr-3 py-2 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Status Filter Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            onClick={() => setStatusFilter('')}
            className={`px-3 py-1 rounded-md font-semibold transition ${
              statusFilter === '' ? 'bg-indigo-600 text-white' : 'bg-[#0F172A] text-slate-400 hover:text-white'
            }`}
          >
            ALL
          </button>
          <button
            onClick={() => setStatusFilter('MATCHED')}
            className={`px-3 py-1 rounded-md font-semibold transition ${
              statusFilter === 'MATCHED' ? 'bg-emerald-600 text-white' : 'bg-[#0F172A] text-slate-400 hover:text-white'
            }`}
          >
            MATCHED
          </button>
          <button
            onClick={() => setStatusFilter('ITC_DIFF')}
            className={`px-3 py-1 rounded-md font-semibold transition ${
              statusFilter === 'ITC_DIFF' ? 'bg-amber-600 text-white' : 'bg-[#0F172A] text-slate-400 hover:text-white'
            }`}
          >
            ITC DIFF
          </button>
          <button
            onClick={() => setStatusFilter('BOOKS ONLY')}
            className={`px-3 py-1 rounded-md font-semibold transition ${
              statusFilter === 'BOOKS ONLY' ? 'bg-rose-600 text-white' : 'bg-[#0F172A] text-slate-400 hover:text-white'
            }`}
          >
            BOOKS ONLY
          </button>
          <button
            onClick={() => setStatusFilter('2B ONLY')}
            className={`px-3 py-1 rounded-md font-semibold transition ${
              statusFilter === '2B ONLY' ? 'bg-purple-600 text-white' : 'bg-[#0F172A] text-slate-400 hover:text-white'
            }`}
          >
            2B ONLY
          </button>
        </div>
      </div>

      {/* PERFECTLY ALIGNED RESPONSIVE TABLE WRAPPER */}
      <div className="custom-table-wrapper max-h-[calc(100vh-280px)] overflow-x-auto overflow-y-auto">
        <table className="custom-table w-full min-w-[1450px]">
          <thead>
            <tr className="bg-[#0F172A] border-b border-[#1E293B]">
              <th className="w-14 text-center py-3 px-3 text-slate-400 font-semibold">Sr. No.</th>
              <th className="w-36 py-3 px-3 text-left text-slate-400 font-semibold">Supplier GSTIN</th>
              <th className="w-44 py-3 px-3 text-left text-slate-400 font-semibold">Vendor Name</th>
              <th className="w-36 py-3 px-3 text-left text-slate-400 font-semibold">Books Invoice No.</th>
              <th className="w-36 py-3 px-3 text-left text-slate-400 font-semibold">2B Invoice No.</th>
              <th className="w-28 py-3 px-3 text-center text-slate-400 font-semibold">Books Date</th>
              <th className="w-28 py-3 px-3 text-center text-slate-400 font-semibold">2B Date</th>
              <th className="w-32 py-3 px-3 text-right text-slate-400 font-semibold">Books Tax (₹)</th>
              <th className="w-32 py-3 px-3 text-right text-slate-400 font-semibold">2B Tax (₹)</th>
              <th className="w-32 py-3 px-3 text-right text-slate-400 font-semibold">Tax Variance (₹)</th>
              <th className="w-48 py-3 px-3 text-left text-slate-400 font-semibold">Reconciliation Status</th>
              <th className="min-w-[320px] py-3 px-3 text-left text-slate-400 font-semibold">Audit Remarks & Reason</th>
              <th className="w-20 py-3 px-3 text-center text-slate-400 font-semibold">Action</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="13" className="text-center py-8 text-slate-400">Loading invoice reconciliation records...</td>
              </tr>
            ) : filteredResults.length === 0 ? (
              <tr>
                <td colSpan="13" className="text-center py-8 text-slate-400">No records found matching current filters.</td>
              </tr>
            ) : (
              filteredResults.map((r, idx) => {
                const b = r.books_record || {};
                const g = r.gstr2b_record || {};
                return (
                  <tr key={r.id} className="hover:bg-[#1E293B]/50 transition border-b border-[#1E293B]">
                    <td className="text-center font-mono text-slate-400 text-xs py-3 px-3">{idx + 1}</td>

                    {/* GSTIN & Vendor */}
                    <td className="font-mono font-semibold text-white py-3 px-3">{b.gstin || g.gstin || '-'}</td>
                    <td className="text-slate-300 truncate max-w-[170px] py-3 px-3">{b.vendor_name || g.vendor_name || '-'}</td>

                    {/* Invoice Numbers */}
                    <td className="font-mono text-indigo-300 font-semibold py-3 px-3">{b.original_invoice_number || '-'}</td>
                    <td className="font-mono text-blue-300 font-semibold py-3 px-3">{g.original_invoice_number || '-'}</td>

                    {/* Dates */}
                    <td className="text-center text-slate-300 text-xs py-3 px-3">{b.invoice_date_str || '-'}</td>
                    <td className="text-center text-slate-300 text-xs py-3 px-3">{g.invoice_date_str || '-'}</td>

                    {/* ITC Amounts */}
                    <td className="text-right font-mono font-bold text-indigo-400 py-3 px-3">{formatAmt(b.total_tax)}</td>
                    <td className="text-right font-mono font-bold text-blue-400 py-3 px-3">{formatAmt(g.total_tax)}</td>
                    <td className={`text-right font-mono font-bold py-3 px-3 ${r.total_tax_diff !== 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                      {formatAmt(r.total_tax_diff)}
                    </td>

                    {/* Status & Single Authoritative Remarks Column */}
                    <td className="py-3 px-3">{getStatusBadge(r.match_status)}</td>
                    <td className="text-xs text-slate-200 py-3 px-3 whitespace-normal">
                      {getAuditRemarkText(r)}
                    </td>

                    <td className="text-center py-3 px-3">
                      <button
                        onClick={() => setSelectedResult(r)}
                        className="btn btn-secondary btn-sm p-1.5 text-xs"
                        title="Inspect Side by Side"
                      >
                        <Eye size={14} className="text-indigo-400" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Side by Side Modal */}
      {selectedResult && (
        <SideBySideModal
          result={selectedResult}
          onClose={() => setSelectedResult(null)}
          onManualOverride={handleManualOverride}
        />
      )}
    </div>
  );
}
