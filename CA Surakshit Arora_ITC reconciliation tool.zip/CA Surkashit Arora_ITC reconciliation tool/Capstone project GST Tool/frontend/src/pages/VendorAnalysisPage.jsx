import React, { useState, useEffect } from 'react';
import { Store, Download, RefreshCw, AlertTriangle } from 'lucide-react';
import { getVendorSummary, getExportExcelUrl } from '../services/api';

export function VendorAnalysisPage({ activeJobId }) {
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchVendors = async () => {
    if (!activeJobId) return;
    setLoading(true);
    try {
      const res = await getVendorSummary(activeJobId);
      setVendors(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVendors();
  }, [activeJobId]);

  const formatAmt = (amt) => `₹${(amt || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  if (!activeJobId) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <h3 className="text-base font-bold text-white mb-2">No Active Job Selected</h3>
        <p className="text-xs text-slate-400">Run a reconciliation job to inspect vendor-wise compliance summaries.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Vendor-Wise Reconciliation & Risk Analysis</h2>
          <p className="text-xs text-slate-400">Aggregated ITC metrics grouped by Supplier GSTIN & Trade Name</p>
        </div>

        <button onClick={fetchVendors} className="btn btn-secondary text-xs">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh Vendors
        </button>
      </div>

      {/* Main Vendor Summary Table */}
      <div className="custom-table-wrapper">
        <table className="custom-table">
          <thead>
            <tr>
              <th>Vendor GSTIN</th>
              <th>Vendor Trade Name</th>
              <th className="text-center">Total Invoices</th>
              <th className="text-center">Matched</th>
              <th className="text-center">Probable</th>
              <th className="text-center">Tax Diffs</th>
              <th className="text-center">Books Only</th>
              <th className="text-center">2B Only</th>
              <th className="text-right">Books ITC</th>
              <th className="text-right">2B ITC</th>
              <th className="text-right">Net ITC Variance</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="11" className="text-center py-8 text-slate-400">Loading vendor compliance metrics...</td>
              </tr>
            ) : vendors.length === 0 ? (
              <tr>
                <td colSpan="11" className="text-center py-8 text-slate-400">No vendor summary data available.</td>
              </tr>
            ) : (
              vendors.map((v) => (
                <tr key={v.gstin} className="hover:bg-[#1E293B]/50 transition">
                  <td className="font-mono font-semibold text-white">{v.gstin}</td>
                  <td className="font-semibold text-slate-200">{v.vendor_name}</td>
                  <td className="text-center font-mono text-slate-300">{v.total_records}</td>
                  <td className="text-center font-mono font-bold text-emerald-400">{v.matched}</td>
                  <td className="text-center font-mono text-blue-400">{v.probable}</td>
                  <td className="text-center font-mono text-amber-400">{v.tax_diff}</td>
                  <td className="text-center font-mono text-rose-400">{v.books_only}</td>
                  <td className="text-center font-mono text-purple-400">{v.gstr2b_only}</td>
                  <td className="text-right font-mono font-bold text-indigo-400">{formatAmt(v.books_itc)}</td>
                  <td className="text-right font-mono font-bold text-blue-400">{formatAmt(v.gstr2b_itc)}</td>
                  <td className={`text-right font-mono font-bold ${v.variance !== 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {formatAmt(v.variance)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
