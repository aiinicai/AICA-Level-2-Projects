import React, { useState, useEffect } from 'react';
import { History, Shield, RefreshCw } from 'lucide-react';
import { getAuditLogs } from '../services/api';

export function AuditPage({ activeJobId }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchLogs = async () => {
    if (!activeJobId) return;
    setLoading(true);
    try {
      const res = await getAuditLogs(activeJobId);
      setLogs(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [activeJobId]);

  if (!activeJobId) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <h3 className="text-base font-bold text-white mb-2">No Active Job Selected</h3>
        <p className="text-xs text-slate-400">Run a reconciliation job to inspect the append-only audit trail.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <History size={22} className="text-indigo-400" />
            Append-Only Audit Trail Ledger
          </h2>
          <p className="text-xs text-slate-400">
            Immutable log recording every manual match, unmatch, and configuration decision
          </p>
        </div>

        <button onClick={fetchLogs} className="btn btn-secondary text-xs">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh Logs
        </button>
      </div>

      {/* Audit Log Table */}
      <div className="custom-table-wrapper">
        <table className="custom-table">
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Auditor / User</th>
              <th>Action Type</th>
              <th>Previous Status</th>
              <th>New Status</th>
              <th>Justification / Reason</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="6" className="text-center py-8 text-slate-400">Loading audit log entries...</td>
              </tr>
            ) : logs.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-center py-8 text-slate-400">No audit log entries recorded for this job.</td>
              </tr>
            ) : (
              logs.map((l) => (
                <tr key={l.id} className="hover:bg-[#1E293B]/50 transition">
                  <td className="font-mono text-xs text-slate-300">{l.timestamp}</td>
                  <td className="font-semibold text-indigo-300">{l.user}</td>
                  <td className="font-mono text-xs text-emerald-400 font-bold">{l.action_type}</td>
                  <td className="text-slate-400 text-xs">{l.previous_status || 'NONE'}</td>
                  <td className="text-slate-200 text-xs font-semibold">{l.new_status || 'N/A'}</td>
                  <td className="text-slate-300 text-xs">{l.reason}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
