import React from 'react';
import { FileSpreadsheet, Download, CheckCircle, Printer, ShieldCheck, Sparkles } from 'lucide-react';
import { getExportExcelUrl } from '../services/api';

export function ReportsPage({ activeJobId, currentClient, selectedPeriod }) {
  const handlePrintPdf = () => {
    window.print();
  };

  const sheets = [
    { name: '1. Executive Summary', desc: 'Cover details, dynamic key findings & executive KPI metrics' },
    { name: '2. Invoice Wise Reconciliation', desc: 'Complete side-by-side comparison of all ingested records with authoritative audit remarks' },
    { name: '3. Exceptions & Discrepancies', desc: 'Categorized unmatched records, tax variances, date variances & duplicates requiring review' },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gradient-to-r from-[#0F172A] via-[#141B2D] to-[#0F172A] p-5 rounded-xl border border-[#1E293B] gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ASA AUDIT REPORT ENGINE
            </span>
          </div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileSpreadsheet size={22} className="text-emerald-400" />
            Commercial GST Reconciliation Reports
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Generate audit-ready Excel and PDF reports for <span className="text-emerald-300 font-semibold">{currentClient?.client_name || 'Active Client'}</span> ({selectedPeriod}).
          </p>
        </div>

        {activeJobId && (
          <div className="flex items-center gap-3">
            <button onClick={handlePrintPdf} className="btn btn-secondary text-xs">
              <Printer size={15} /> Print / Save PDF
            </button>
            <a
              href={getExportExcelUrl(activeJobId)}
              download
              className="btn btn-success px-4 py-2 text-xs shadow-lg shadow-emerald-600/20"
            >
              <Download size={15} /> Download Commercial Excel Report (.xlsx)
            </a>
          </div>
        )}
      </div>

      {/* Printable Report Header Preview / Cover Page */}
      <div className="glass-card p-6 space-y-6 bg-gradient-to-b from-[#0F172A] to-[#141B2D]">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#0F172A] border border-[#1E293B] p-1.5 flex items-center justify-center shadow-lg">
              <img src="/assets/logo.svg" alt="ASA Logo" className="w-full h-full object-contain" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-white tracking-wide">Input Reconciliation Tool</h1>
              <p className="text-xs text-teal-400 font-bold tracking-widest uppercase">ASA Professional Suite</p>
            </div>
          </div>

          <div className="text-right text-xs text-slate-400 font-mono">
            <div>Client: <strong className="text-white">{currentClient?.client_name || 'N/A'}</strong></div>
            <div>GSTIN: <strong className="text-teal-400">{currentClient?.gstin || 'N/A'}</strong></div>
            <div>Period: <strong className="text-indigo-300">{selectedPeriod}</strong></div>
          </div>
        </div>

        {/* Essential 3-Sheet Structure Overview */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#1E293B] pb-2">
            <ShieldCheck size={16} className="text-teal-400" />
            Streamlined 3-Sheet Report Structure
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            {sheets.map((s, idx) => (
              <div key={s.name} className="bg-[#0F172A] p-3.5 rounded-lg border border-[#1E293B] flex items-start gap-3">
                <div className="w-6 h-6 rounded bg-indigo-500/20 text-indigo-400 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                  {idx + 1}
                </div>
                <div>
                  <span className="font-bold text-white block">{s.name}</span>
                  <span className="text-[11px] text-slate-400">{s.desc}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Authoritative Audit Remarks Note */}
        <div className="bg-[#0F172A] p-4 rounded-xl border border-indigo-500/30 text-xs space-y-2">
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
            <Sparkles size={16} /> Authoritative Audit Remarks & Tax Reasons
          </div>
          <p className="text-slate-300 leading-relaxed">
            The report eliminates redundant intermediate boolean flags. Each transaction is evaluated against actual ITC tax amounts and dates, placing the single authoritative status and explanation under <strong>Audit Remarks & Reason</strong> for direct professional audit use.
          </p>
        </div>
      </div>
    </div>
  );
}
