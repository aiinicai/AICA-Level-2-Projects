import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, RefreshCw, Eye, ShieldAlert, Filter, ArrowUpRight } from 'lucide-react';
import { getJobResults, manualMatchOverride } from '../services/api';
import { SideBySideModal } from '../components/reconciliation/SideBySideModal';

export function ExceptionsPage({ activeJobId }) {
  const [exceptions, setExceptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedResult, setSelectedResult] = useState(null);
  const [activeFilter, setActiveFilter] = useState('ALL');

  const fetchExceptions = async () => {
    if (!activeJobId) return;
    setLoading(true);
    try {
      const res = await getJobResults(activeJobId, {});
      const allResults = res.data.results || [];
      
      // Filter strictly exceptions requiring tax review
      const filtered = allResults.filter(r => 
        r.match_status.includes('DIFFERENCE') ||
        r.match_status.includes('PROBABLE') ||
        r.match_status.includes('DUPLICATE') ||
        r.match_status.includes('REVIEW REQUIRED') ||
        r.match_status.includes('BOOKS ONLY') ||
        r.match_status.includes('2B ONLY')
      );

      // Classify Priority dynamically for each exception
      const categorized = filtered.map(r => {
        const taxDiff = Math.abs(r.total_tax_diff || 0.0);
        const b = r.books_record || {};
        const g = r.gstr2b_record || {};
        const st = (r.match_status || '').toUpperCase();

        let priority = 'LOW';
        if (taxDiff > 1000 || st.includes('BOOKS ONLY') || st.includes('DUPLICATE') || (b.gstin && g.gstin && b.gstin !== g.gstin)) {
          priority = 'HIGH';
        } else if (taxDiff > 10 || st.includes('PROBABLE') || st.includes('DATE') || st.includes('INV')) {
          priority = 'MEDIUM';
        }

        // Generate dynamic human-readable explanation if not present
        let explanation = r.match_notes || '';
        if (b.gstin && g.gstin && b.gstin === g.gstin) {
          if (taxDiff > 0.01) {
            explanation = `GSTIN matched. ITC in Books is ₹${(b.total_tax || 0).toLocaleString('en-IN')} whereas GSTR-2B reflects ₹${(g.total_tax || 0).toLocaleString('en-IN')}, resulting in an ITC variance of ₹${taxDiff.toLocaleString('en-IN')}.`;
          } else if (r.date_diff_days > 0) {
            explanation = `GSTIN & Invoice number matched. Invoice date differs by ${r.date_diff_days} day(s).`;
          }
        } else if (st.includes('BOOKS ONLY')) {
          explanation = `Recorded in Purchase Register (Books) for ₹${(b.total_tax || 0).toLocaleString('en-IN')} ITC, but missing in GSTR-2B portal statement. High risk of ITC rejection under Rule 36(4).`;
        } else if (st.includes('2B ONLY')) {
          explanation = `Present in GSTR-2B for ₹${(g.total_tax || 0).toLocaleString('en-IN')} ITC, but not identified in Purchase Register. Potential unclaimed credit opportunity.`;
        }

        return { ...r, priority, dynamicExplanation: explanation };
      });

      setExceptions(categorized);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExceptions();
  }, [activeJobId]);

  const handleManualOverride = async (resultId, action, reason) => {
    try {
      await manualMatchOverride({
        result_id: resultId,
        action,
        reason,
        user_name: 'Tax Professional',
      });
      fetchExceptions();
    } catch (err) {
      console.error(err);
    }
  };

  // Filter list by selected active filter tab
  const displayedExceptions = exceptions.filter(r => {
    if (activeFilter === 'HIGH') return r.priority === 'HIGH';
    if (activeFilter === 'MEDIUM') return r.priority === 'MEDIUM';
    if (activeFilter === 'LOW') return r.priority === 'LOW';
    if (activeFilter === 'BOOKS_ONLY') return r.match_status.includes('BOOKS ONLY');
    if (activeFilter === '2B_ONLY') return r.match_status.includes('2B ONLY');
    if (activeFilter === 'TAX_DIFF') return Math.abs(r.total_tax_diff || 0) > 0.01;
    return true;
  });

  const highPriorityCount = exceptions.filter(r => r.priority === 'HIGH').length;
  const mediumPriorityCount = exceptions.filter(r => r.priority === 'MEDIUM').length;
  const lowPriorityCount = exceptions.filter(r => r.priority === 'LOW').length;

  const formatAmt = (val) => (val !== undefined && val !== null ? `₹${val.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : '-');

  if (!activeJobId) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <div className="w-16 h-16 rounded-2xl bg-[#141B2D] border border-[#1E293B] text-amber-400 flex items-center justify-center mb-4">
          <AlertTriangle size={32} />
        </div>
        <h3 className="text-base font-bold text-white mb-2">No Active Reconciliation Job Selected</h3>
        <p className="text-xs text-slate-400">Run a reconciliation job to populate the automated exception audit queue.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-gradient-to-r from-[#0F172A] via-[#141B2D] to-[#0F172A] p-5 rounded-xl border border-[#1E293B]">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="text-amber-400" size={20} />
            <h2 className="text-xl font-bold text-white">Exception Centre & Audit Queue</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated priority classification for tax variances, missing invoices, and probable fuzzy matches
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={fetchExceptions} className="btn btn-secondary text-xs">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh Queue
          </button>
        </div>
      </div>

      {/* Priority Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div 
          onClick={() => setActiveFilter('HIGH')}
          className={`glass-card p-3.5 cursor-pointer border-l-4 border-l-rose-500 transition ${activeFilter === 'HIGH' ? 'bg-rose-950/20 border-rose-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-rose-400">HIGH PRIORITY</span>
            <span className="badge badge-priority-high">{highPriorityCount} Issues</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Direct ITC loss, missing portal records & major tax discrepancies</p>
        </div>

        <div 
          onClick={() => setActiveFilter('MEDIUM')}
          className={`glass-card p-3.5 cursor-pointer border-l-4 border-l-amber-500 transition ${activeFilter === 'MEDIUM' ? 'bg-amber-950/20 border-amber-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-amber-400">MEDIUM PRIORITY</span>
            <span className="badge badge-priority-medium">{mediumPriorityCount} Issues</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Invoice date variances, fuzzy matches & invoice number mismatches</p>
        </div>

        <div 
          onClick={() => setActiveFilter('LOW')}
          className={`glass-card p-3.5 cursor-pointer border-l-4 border-l-emerald-500 transition ${activeFilter === 'LOW' ? 'bg-emerald-950/20 border-emerald-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-emerald-400">LOW PRIORITY</span>
            <span className="badge badge-priority-low">{lowPriorityCount} Issues</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Minor rounding differences (&lt; ₹10) & format variations</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-[#1E293B] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveFilter('ALL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === 'ALL' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          All Exceptions ({exceptions.length})
        </button>
        <button
          onClick={() => setActiveFilter('HIGH')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === 'HIGH' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          High Priority ({highPriorityCount})
        </button>
        <button
          onClick={() => setActiveFilter('MEDIUM')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === 'MEDIUM' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          Medium Priority ({mediumPriorityCount})
        </button>
        <button
          onClick={() => setActiveFilter('TAX_DIFF')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === 'TAX_DIFF' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          Tax Variances
        </button>
        <button
          onClick={() => setActiveFilter('BOOKS_ONLY')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === 'BOOKS_ONLY' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          Books Only
        </button>
        <button
          onClick={() => setActiveFilter('2B_ONLY')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeFilter === '2B_ONLY' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:bg-[#1E293B]'}`}
        >
          2B Only
        </button>
      </div>

      {/* Exception Table */}
      <div className="custom-table-wrapper">
        <table className="custom-table">
          <thead>
            <tr>
              <th>Priority</th>
              <th>Status</th>
              <th>Supplier GSTIN / Vendor</th>
              <th>Books Inv No</th>
              <th>2B Inv No</th>
              <th className="text-right">Books Tax</th>
              <th className="text-right">2B Tax</th>
              <th className="text-right">Tax Variance</th>
              <th>Human-Readable Difference Explanation</th>
              <th className="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="10" className="text-center py-8 text-slate-400">Analyzing exception queue...</td>
              </tr>
            ) : displayedExceptions.length === 0 ? (
              <tr>
                <td colSpan="10" className="text-center py-8 text-emerald-400 font-semibold">
                  ✓ Zero exceptions match the selected filter criteria.
                </td>
              </tr>
            ) : (
              displayedExceptions.map((r) => {
                const b = r.books_record || {};
                const g = r.gstr2b_record || {};

                let badgeClass = "badge-tax-diff";
                if (r.match_status.includes('BOOKS ONLY')) badgeClass = "badge-books-only";
                if (r.match_status.includes('2B ONLY')) badgeClass = "badge-2b-only";
                if (r.match_status.includes('PROBABLE')) badgeClass = "badge-probable";
                if (r.match_status.includes('DUPLICATE')) badgeClass = "badge-duplicate";

                return (
                  <tr key={r.id} className="hover:bg-[#1E293B]/50 transition">
                    <td>
                      <span className={`badge ${
                        r.priority === 'HIGH' ? 'badge-priority-high' :
                        r.priority === 'MEDIUM' ? 'badge-priority-medium' : 'badge-priority-low'
                      }`}>
                        {r.priority}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${badgeClass}`}>{r.match_status}</span>
                    </td>
                    <td>
                      <div className="font-mono font-bold text-white">{b.gstin || g.gstin || '-'}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[150px]">{b.vendor_name || g.vendor_name || '-'}</div>
                    </td>
                    <td className="font-mono text-indigo-300 font-semibold">{b.original_invoice_number || '-'}</td>
                    <td className="font-mono text-blue-300 font-semibold">{g.original_invoice_number || '-'}</td>
                    <td className="text-right font-mono font-bold text-indigo-400">{formatAmt(b.total_tax)}</td>
                    <td className="text-right font-mono font-bold text-blue-400">{formatAmt(g.total_tax)}</td>
                    <td className="text-right font-mono font-bold text-amber-400">{formatAmt(r.total_tax_diff)}</td>
                    <td className="text-xs text-slate-200 max-w-[280px] whitespace-normal">
                      {r.dynamicExplanation}
                    </td>
                    <td className="text-center">
                      <button
                        onClick={() => setSelectedResult(r)}
                        className="btn btn-primary btn-sm text-xs"
                      >
                        <Eye size={12} /> Inspect
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {selectedResult && (
        <SideBySideModal
          result={selectedResult}
          onClose={() => setSelectedResult(null)}
          onManualOverride={handleManualOverride}
        />
      )}
    </div>
  );
}
