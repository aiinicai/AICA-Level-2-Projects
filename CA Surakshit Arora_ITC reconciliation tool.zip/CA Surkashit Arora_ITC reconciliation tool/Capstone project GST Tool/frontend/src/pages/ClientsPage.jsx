import React, { useState } from 'react';
import { Users, Plus, Trash2, Edit, Eye, AlertTriangle, CheckCircle, ShieldCheck, Play, Upload, ArrowRight, X } from 'lucide-react';
import { createClient, updateClient, deleteClient } from '../services/api';

export function ClientsPage({ clients, onRefreshClients, onSelectClient, onNavigate }) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [deletingClient, setDeletingClient] = useState(null);
  const [viewingClient, setViewingClient] = useState(null);

  const [name, setName] = useState('');
  const [gstin, setGstin] = useState('');
  const [pan, setPan] = useState('');
  const [fy, setFy] = useState('2026-27');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createClient({ client_name: name, gstin, pan, financial_year: fy });
      await onRefreshClients();
      setShowCreateModal(false);
      setName('');
      setGstin('');
      setPan('');
      setMsg('Client created successfully!');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (c) => {
    setEditingClient(c);
    setName(c.client_name);
    setGstin(c.gstin);
    setPan(c.pan || '');
    setFy(c.financial_year || '2026-27');
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateClient(editingClient.id, { client_name: name, gstin, pan, financial_year: fy });
      await onRefreshClients();
      setEditingClient(null);
      setName('');
      setGstin('');
      setPan('');
      setMsg('Client updated successfully!');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmRemove = async () => {
    if (!deletingClient) return;
    setLoading(true);
    try {
      await deleteClient(deletingClient.id);
      await onRefreshClients();
      setDeletingClient(null);
      setMsg(`Client ${deletingClient.client_name} removed successfully.`);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewClient = (c) => {
    if (onSelectClient) onSelectClient(c);
    setViewingClient(c);
  };

  const handleOpenDashboard = (c) => {
    if (onSelectClient) onSelectClient(c);
    setViewingClient(null);
    if (onNavigate) onNavigate('dashboard');
  };

  const handleOpenUpload = (c) => {
    if (onSelectClient) onSelectClient(c);
    setViewingClient(null);
    if (onNavigate) onNavigate('upload');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users size={22} className="text-indigo-400" />
            Client Master Management
          </h2>
          <p className="text-xs text-slate-400">Manage client entities, GSTIN profiles, and financial year settings</p>
        </div>

        <button onClick={() => { setEditingClient(null); setName(''); setGstin(''); setPan(''); setShowCreateModal(true); }} className="btn btn-primary text-xs">
          <Plus size={16} /> Add New Client
        </button>
      </div>

      {msg && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-3 rounded-lg flex items-center gap-2">
          <CheckCircle size={16} /> {msg}
        </div>
      )}

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {clients.map((c) => (
          <div key={c.id} className="glass-card flex flex-col justify-between space-y-4 hover:border-indigo-500/40 transition">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-bold text-white mb-0.5">{c.client_name}</h3>
                <span className="font-mono text-xs font-semibold text-indigo-400">{c.gstin}</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 bg-[#0F172A] px-2 py-1 rounded border border-[#1E293B]">
                FY {c.financial_year}
              </span>
            </div>

            <div className="text-xs text-slate-400 space-y-1">
              <div>PAN: <span className="font-mono text-slate-200">{c.pan || 'N/A'}</span></div>
            </div>

            {/* ACTION BUTTONS: VIEW, EDIT, REMOVE */}
            <div className="pt-3 border-t border-[#1E293B] flex items-center justify-between">
              <div className="flex gap-2">
                <button
                  onClick={() => handleViewClient(c)}
                  className="btn btn-secondary btn-sm text-xs"
                  title="Inspect Client Master Details"
                >
                  <Eye size={14} className="text-indigo-400" /> View
                </button>
                <button
                  onClick={() => handleEdit(c)}
                  className="btn btn-secondary btn-sm text-xs"
                  title="Edit Client Master"
                >
                  <Edit size={14} className="text-blue-400" /> Edit
                </button>
              </div>

              <button
                onClick={() => setDeletingClient(c)}
                className="btn btn-danger btn-sm text-xs px-2.5"
                title="Remove Client"
              >
                <Trash2 size={14} /> Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* VIEW CLIENT DETAILS MODAL */}
      {viewingClient && (
        <div className="modal-overlay">
          <div className="modal-content max-w-lg">
            <div className="modal-header border-b-indigo-500/30">
              <div className="flex items-center gap-2">
                <ShieldCheck size={20} className="text-indigo-400" />
                <h3 className="text-base font-bold text-white">Client Master Overview</h3>
              </div>
              <button onClick={() => setViewingClient(null)} className="text-slate-400">✕</button>
            </div>

            <div className="modal-body space-y-4 text-xs">
              <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-extrabold text-white">{viewingClient.client_name}</h4>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    ACTIVE CLIENT
                  </span>
                </div>
                <div className="font-mono text-sm text-indigo-400 font-bold">{viewingClient.gstin}</div>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono">
                <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
                  <span className="text-slate-400 block text-[10px] uppercase">PAN Number</span>
                  <span className="text-slate-200 font-bold text-xs">{viewingClient.pan || 'N/A'}</span>
                </div>
                <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B]">
                  <span className="text-slate-400 block text-[10px] uppercase">Financial Year</span>
                  <span className="text-slate-200 font-bold text-xs">{viewingClient.financial_year || '2026-27'}</span>
                </div>
              </div>

              <p className="text-slate-300 text-xs">
                This client is currently active. You can open their reconciliation dashboard or run fresh file uploads immediately.
              </p>
            </div>

            <div className="modal-footer flex items-center justify-between">
              <button onClick={() => { setViewingClient(null); handleEdit(viewingClient); }} className="btn btn-secondary text-xs">
                <Edit size={14} /> Edit Master
              </button>

              <div className="flex gap-2">
                <button onClick={() => handleOpenUpload(viewingClient)} className="btn btn-secondary text-xs">
                  <Upload size={14} /> Upload Files
                </button>
                <button onClick={() => handleOpenDashboard(viewingClient)} className="btn btn-primary text-xs">
                  <Play size={14} /> Open Dashboard <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT MODAL */}
      {(showCreateModal || editingClient) && (
        <div className="modal-overlay">
          <div className="modal-content max-w-md">
            <div className="modal-header">
              <h3 className="text-base font-bold text-white">
                {editingClient ? 'Edit Client Master' : 'Create New Client Master'}
              </h3>
              <button onClick={() => { setShowCreateModal(false); setEditingClient(null); }} className="text-slate-400">✕</button>
            </div>
            <form onSubmit={editingClient ? handleUpdate : handleCreate}>
              <div className="modal-body space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Client Legal / Trade Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Zenith Office Supplies Pvt Ltd"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">GSTIN</label>
                  <input
                    type="text"
                    required
                    placeholder="15-character GSTIN e.g. 27AAACW1234F1Z5"
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value)}
                    className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 font-mono uppercase focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">PAN Number</label>
                  <input
                    type="text"
                    placeholder="10-character PAN e.g. AAACW1234F"
                    value={pan}
                    onChange={(e) => setPan(e.target.value)}
                    className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 font-mono uppercase focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Default Financial Year</label>
                  <select
                    value={fy}
                    onChange={(e) => setFy(e.target.value)}
                    className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="2026-27">2026-27</option>
                    <option value="2027-28">2027-28</option>
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => { setShowCreateModal(false); setEditingClient(null); }} className="btn btn-secondary text-xs">
                  Cancel
                </button>
                <button type="submit" disabled={loading} className="btn btn-primary text-xs">
                  {loading ? 'Saving...' : (editingClient ? 'Update Client' : 'Save Client Master')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REMOVE CLIENT CONFIRMATION MODAL */}
      {deletingClient && (
        <div className="modal-overlay">
          <div className="modal-content max-w-md">
            <div className="modal-header border-b-rose-500/30">
              <div className="flex items-center gap-2 text-rose-400">
                <AlertTriangle size={20} />
                <h3 className="text-base font-bold text-white">Remove Client Confirmation</h3>
              </div>
              <button onClick={() => setDeletingClient(null)} className="text-slate-400">✕</button>
            </div>

            <div className="modal-body space-y-3 text-xs">
              <div className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B] space-y-1">
                <div className="font-bold text-white text-sm">{deletingClient.client_name}</div>
                <div className="font-mono text-indigo-400 font-semibold">{deletingClient.gstin}</div>
              </div>

              <p className="text-slate-300 font-semibold text-sm">
                Are you sure you want to remove this client?
              </p>
              <p className="text-slate-400">
                This action will delete the client master profile. Historical reconciliation records will be safely archived.
              </p>
            </div>

            <div className="modal-footer">
              <button onClick={() => setDeletingClient(null)} className="btn btn-secondary text-xs">
                Cancel
              </button>
              <button onClick={handleConfirmRemove} disabled={loading} className="btn btn-danger text-xs">
                {loading ? 'Removing...' : 'Remove Client'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
