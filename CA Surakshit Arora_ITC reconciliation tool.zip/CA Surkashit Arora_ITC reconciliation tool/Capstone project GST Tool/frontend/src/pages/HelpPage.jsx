import React from 'react';
import { 
  HelpCircle, BookOpen, Layers, CheckCircle2, ShieldCheck, 
  FileSpreadsheet, AlertTriangle, Cpu, ArrowRight, Download, Upload 
} from 'lucide-react';

export function HelpPage() {
  const steps = [
    {
      step: '01',
      title: 'Select Active Client & Period',
      desc: 'Use the top header selectors to choose the active Client GSTIN, Financial Year (e.g. 2026-27), and Tax Period month.',
      icon: ShieldCheck
    },
    {
      step: '02',
      title: 'Upload Purchase Register & GSTR-2B',
      desc: 'Navigate to Upload Centre. Drag and drop your Purchase Register (Books Excel) and GSTR-2B auto-drafted file (Excel or JSON).',
      icon: Upload
    },
    {
      step: '03',
      title: 'Run Automated 5-Pass Matching Engine',
      desc: 'Click "Run Automated Reconciliation". The system executes multi-stage deterministic and fuzzy matching algorithms.',
      icon: Cpu
    },
    {
      step: '04',
      title: 'Inspect Health & Review Exception Queue',
      desc: 'Check the Reconciliation Health Score on the Dashboard and inspect categorized exceptions in the Exception Centre.',
      icon: AlertTriangle
    },
    {
      step: '05',
      title: 'Export Commercial Excel & PDF Audit Reports',
      desc: 'Download the 12-sheet structured Excel report with dynamic key findings, or generate printable PDF audit summaries.',
      icon: FileSpreadsheet
    }
  ];

  const matchLevels = [
    {
      level: 'Pass 1: Exact Match',
      badge: 'MATCHED',
      badgeClass: 'badge-exact',
      desc: 'Matches GSTIN, normalized invoice number, invoice date (within tolerance), and total tax amount.'
    },
    {
      level: 'Pass 2: Invoice No Match (No GSTIN)',
      badge: 'INV NO MATCH',
      badgeClass: 'badge-probable',
      desc: 'Matches normalized invoice number when GSTIN is missing or format varies.'
    },
    {
      level: 'Pass 3: Probable Match (Fuzzy)',
      badge: 'PROBABLE MATCH',
      badgeClass: 'badge-probable',
      desc: 'Matches invoices with slight typographical variations in invoice numbers using fuzzy similarity thresholds.'
    },
    {
      level: 'Pass 4: Unmatched Records',
      badge: 'BOOKS / 2B ONLY',
      badgeClass: 'badge-books-only',
      desc: 'Flags records existing only in Purchase Register (Books Only) or only in GSTR-2B portal (2B Only).'
    },
    {
      level: 'Pass 5: Duplicate Detection',
      badge: 'DUPLICATE',
      badgeClass: 'badge-duplicate',
      desc: 'Identifies duplicate invoice numbers within the same file to prevent double-claiming of ITC.'
    }
  ];

  const glossary = [
    {
      term: 'Reconciliation Health Score',
      def: 'Calculated metric evaluating reconciliation quality: 60% weight on invoice count match rate + 40% weight on eligible ITC claim coverage.'
    },
    {
      term: 'Books Only (ITC at Risk)',
      def: 'Invoices recorded in Purchase Register but absent from GSTR-2B. Claiming this ITC carries risk under Rule 36(4) of CGST Rules.'
    },
    {
      term: '2B Only (Unclaimed Credit)',
      def: 'Invoices auto-drafted on GST Portal GSTR-2B but not recorded in Purchase Register. Represents unclaimed credit opportunities.'
    },
    {
      term: 'Tax Variance',
      def: 'Difference in total tax amount (IGST/CGST/SGST) between Purchase Register and GSTR-2B statement for matched invoices.'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-gradient-to-r from-[#0F172A] via-[#141B2D] to-[#0F172A] p-5 rounded-xl border border-[#1E293B]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-teal-500/20 text-teal-400 border border-teal-500/30">
              USER DOCUMENTATION
            </span>
          </div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <HelpCircle size={22} className="text-teal-400" />
            Help Centre & Operating Manual
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Complete user guide for ASA Input Reconciliation Tool & GST Purchase Register vs GSTR-2B Matching Engine
          </p>
        </div>
      </div>

      {/* 5-Step Quick Start Workflow */}
      <div className="glass-card space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#1E293B] pb-2">
          <BookOpen size={16} className="text-indigo-400" />
          5-Step Quick Start Workflow
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {steps.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.step} className="bg-[#0F172A] p-3.5 rounded-xl border border-[#1E293B] flex flex-col justify-between space-y-2">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-bold text-indigo-400">{s.step}</span>
                    <Icon size={16} className="text-slate-400" />
                  </div>
                  <h4 className="text-xs font-bold text-white leading-snug mb-1">{s.title}</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Matching Engine Waterfall Logic */}
      <div className="glass-card space-y-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#1E293B] pb-2">
          <Layers size={16} className="text-emerald-400" />
          Multi-Pass Reconciliation Logic
        </h3>

        <div className="space-y-2">
          {matchLevels.map((m) => (
            <div key={m.level} className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
              <div className="space-y-0.5">
                <span className="font-bold text-white block">{m.level}</span>
                <p className="text-[11px] text-slate-400">{m.desc}</p>
              </div>
              <span className={`badge ${m.badgeClass} shrink-0`}>{m.badge}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Glossary & Compliance Definitions */}
      <div className="glass-card space-y-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#1E293B] pb-2">
          <ShieldCheck size={16} className="text-teal-400" />
          GST Terminology & Compliance Glossary
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {glossary.map((g) => (
            <div key={g.term} className="bg-[#0F172A] p-3 rounded-lg border border-[#1E293B] space-y-1">
              <span className="font-bold text-indigo-300 block">{g.term}</span>
              <p className="text-[11px] text-slate-300 leading-relaxed">{g.def}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
