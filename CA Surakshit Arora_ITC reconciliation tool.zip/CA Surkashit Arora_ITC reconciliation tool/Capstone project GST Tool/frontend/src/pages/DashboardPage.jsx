import React, { useState, useEffect } from 'react';
import { 
  FileText, CheckCircle2, AlertOctagon, HelpCircle, FileX2, 
  IndianRupee, ShieldAlert, ArrowUpRight, Upload, Play, Download, 
  Sparkles, Activity, AlertTriangle, Layers, Info, Award
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { getVendorSummary } from '../services/api';

export function DashboardPage({ kpis, currentClient, selectedFy, selectedMonth, activeJobId, onNavigate }) {
  const [topVendors, setTopVendors] = useState([]);

  useEffect(() => {
    if (activeJobId) {
      getVendorSummary(activeJobId)
        .then(res => {
          const vendors = res.data || [];
          // Sort by absolute variance descending
          const sorted = [...vendors].sort((a, b) => Math.abs(b.variance) - Math.abs(a.variance)).slice(0, 5);
          setTopVendors(sorted);
        })
        .catch(err => console.error(err));
    }
  }, [activeJobId]);

  if (!kpis) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <div className="w-16 h-16 rounded-2xl bg-[#141B2D] border border-[#1E293B] text-indigo-400 flex items-center justify-center mb-4 shadow-xl shadow-indigo-500/10">
          <Upload size={32} />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">No Reconciliation Job Loaded</h2>
        <p className="text-xs text-slate-400 max-w-md mb-6">
          Upload a Purchase Register (Books) and GSTR-2B auto-drafted statement in the Upload Centre to compute automated 1-to-1 GST reconciliation.
        </p>
        <button onClick={() => onNavigate('upload')} className="btn btn-primary text-xs">
          <Upload size={16} /> Open Upload Centre
        </button>
      </div>
    );
  }

  // Exact metrics calculations
  const exactCount = (kpis.exact_matches || 0) + (kpis.inv_no_match_no_gstin || 0);
  const diffCount = (kpis.matched_date_diff || 0) + (kpis.matched_tax_diff || 0) + (kpis.matched_date_tax_diff || 0);
  const probableCount = kpis.probable_matches || 0;
  const booksOnlyCount = kpis.books_only || 0;
  const g2bOnlyCount = kpis.gstr2b_only || 0;
  const duplicateCount = (kpis.duplicates_books || 0) + (kpis.duplicates_2b || 0);
  const reviewCount = kpis.review_required || 0;
  const totalMismatches = booksOnlyCount + g2bOnlyCount + diffCount + probableCount;

  // ITC Calculations
  const booksItc = kpis.books_itc || 0.0;
  const gstr2bItc = kpis.gstr2b_itc || 0.0;
  const matchedItc = kpis.matched_itc || 0.0;
  const itcDifference = Math.round((booksItc - gstr2bItc) * 100) / 100;
  const atRiskItc = kpis.potential_itc_at_risk || 0.0;
  const unclaimedItc = Math.max(0, Math.round((gstr2bItc - matchedItc) * 100) / 100);

  const matchedItcPct = booksItc > 0 ? Math.min(100, Math.round((matchedItc / booksItc) * 1000) / 10) : 0;
  const diffItcPct = booksItc > 0 ? Math.round((Math.abs(itcDifference) / booksItc) * 1000) / 10 : 0;
  const riskItcPct = booksItc > 0 ? Math.round((atRiskItc / booksItc) * 1000) / 10 : 0;
  const unclaimedItcPct = gstr2bItc > 0 ? Math.round((unclaimedItc / gstr2bItc) * 1000) / 10 : 0;

  // DYNAMIC RECONCILIATION HEALTH SCORE CALCULATION
  // Formula: 60% Weight on Invoice Count Match Rate + 40% Weight on Eligible ITC Match Rate
  const totalInvoices = (kpis.total_books_invoices || 1);
  const matchedCountForHealth = exactCount + (kpis.matched_date_diff || 0);
  const countRatio = Math.min(1.0, matchedCountForHealth / totalInvoices);
  const itcRatio = booksItc > 0 ? Math.min(1.0, matchedItc / booksItc) : 1.0;
  const healthScore = Math.round((countRatio * 60 + itcRatio * 40));

  let healthGrade = "Excellent";
  let healthColor = "text-emerald-400";
  let healthBadgeBg = "bg-emerald-500/10 border-emerald-500/30 text-emerald-400";
  let healthBarColor = "bg-emerald-500";

  if (healthScore < 70) {
    healthGrade = "Needs Attention";
    healthColor = "text-rose-400";
    healthBadgeBg = "bg-rose-500/10 border-rose-500/30 text-rose-400";
    healthBarColor = "bg-rose-500";
  } else if (healthScore < 90) {
    healthGrade = "Moderate";
    healthColor = "text-amber-400";
    healthBadgeBg = "bg-amber-500/10 border-amber-500/30 text-amber-400";
    healthBarColor = "bg-amber-500";
  }

  // Chart Data
  const matchWaterfallData = [
    { name: 'Matched', count: exactCount, color: '#10B981' },
    { name: 'Date Diff', count: kpis.matched_date_diff || 0, color: '#06B6D4' },
    { name: 'Tax Diff', count: kpis.matched_tax_diff || 0, color: '#F59E0B' },
    { name: 'Probable', count: probableCount, color: '#3B82F6' },
    { name: 'Books Only', count: booksOnlyCount, color: '#F97316' },
    { name: '2B Only', count: g2bOnlyCount, color: '#8B5CF6' },
    { name: 'Duplicates', count: duplicateCount, color: '#EF4444' },
  ];

  const itcComparisonData = [
    { name: 'Books ITC', amount: booksItc, fill: '#6366F1' },
    { name: 'GSTR-2B ITC', amount: gstr2bItc, fill: '#3B82F6' },
    { name: 'Matched Eligible', amount: matchedItc, fill: '#10B981' },
    { name: 'ITC at Risk', amount: atRiskItc, fill: '#EF4444' },
  ];

  const itcPieData = [
    { name: 'Matched Eligible ITC', value: matchedItc, color: '#10B981' },
    { name: 'Books Only (At Risk)', value: atRiskItc, color: '#F97316' },
    { name: '2B Only (Unclaimed)', value: unclaimedItc, color: '#8B5CF6' },
  ];

  const formatCurrency = (amt) => `₹${(amt || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="space-y-6">
      {/* Top Banner: Client Header & Health Indicator */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Client Metadata Header */}
        <div className="lg:col-span-3 glass-card bg-gradient-to-r from-[#0F172A] via-[#141B2D] to-[#0F172A] border-[#1E293B] flex flex-col justify-between p-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  ASA AUDIT CONSOLE
                </span>
                <span className="text-xs text-slate-400 font-mono">Job ID: {activeJobId?.slice(0, 8)}...</span>
              </div>
              <h1 className="text-2xl font-bold text-white">
                {currentClient?.client_name || 'Active Client Overview'}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 mt-2 font-mono">
                <span>GSTIN: <strong className="text-teal-400">{currentClient?.gstin || 'N/A'}</strong></span>
                <span>•</span>
                <span>FY: <strong>{selectedFy}</strong></span>
                <span>•</span>
                <span>Tax Period: <strong className="text-indigo-300">{selectedMonth}</strong></span>
              </div>
            </div>

            <div className="flex gap-2">
              <button onClick={() => onNavigate('upload')} className="btn btn-secondary text-xs">
                <Upload size={14} /> Upload Data
              </button>
              <button onClick={() => onNavigate('reports')} className="btn btn-primary text-xs">
                <Download size={14} /> Export Report
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1E293B] flex items-center justify-between text-xs text-slate-400">
            <span>Deterministic 5-Pass Matching Engine</span>
            <span>Total Purchase Records Analyzed: <strong className="text-white">{kpis.total_books_invoices + kpis.total_2b_invoices}</strong></span>
          </div>
        </div>

        {/* RECONCILIATION HEALTH SCORE CARD */}
        <div className="glass-card flex flex-col justify-between p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Reconciliation Health</span>
            <div className="has-tooltip">
              <Info size={14} className="text-slate-400 hover:text-white" />
              <div className="tooltip-box">
                <strong>Health Score Formula:</strong><br />
                • 60% Weight: Invoice Count Exact Match Rate<br />
                • 40% Weight: Eligible ITC Claim Coverage<br />
                Green (&ge;90%), Amber (70-89%), Red (&lt;70%).
              </div>
            </div>
          </div>

          <div className="my-2 flex items-baseline justify-between">
            <div className={`text-4xl font-extrabold ${healthColor}`}>
              {healthScore}%
            </div>
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${healthBadgeBg}`}>
              {healthGrade}
            </span>
          </div>

          <div>
            <div className="w-full bg-[#0F172A] rounded-full h-2 overflow-hidden border border-[#1E293B]">
              <div className={`h-full ${healthBarColor} transition-all duration-500`} style={{ width: `${healthScore}%` }}></div>
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1.5 font-mono">
              <span>0% Risk</span>
              <span>100% Reconciled</span>
            </div>
          </div>
        </div>
      </div>

      {/* DEDICATED ITC FINANCIAL SUMMARY SECTION */}
      <div className="space-y-2">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <IndianRupee size={16} className="text-teal-400" />
          Input Tax Credit (ITC) Financial Reconciliation Summary
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Books ITC */}
          <div className="glass-card p-3.5 border-l-4 border-l-indigo-500">
            <span className="text-[10px] font-bold text-slate-400 block uppercase">Books ITC</span>
            <div className="text-lg font-extrabold text-white mt-1">{formatCurrency(booksItc)}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Invoices: {kpis.total_books_invoices}</div>
          </div>

          {/* GSTR-2B ITC */}
          <div className="glass-card p-3.5 border-l-4 border-l-blue-500">
            <span className="text-[10px] font-bold text-slate-400 block uppercase">GSTR-2B ITC</span>
            <div className="text-lg font-extrabold text-white mt-1">{formatCurrency(gstr2bItc)}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Invoices: {kpis.total_2b_invoices}</div>
          </div>

          {/* Matched Eligible ITC */}
          <div className="glass-card p-3.5 border-l-4 border-l-emerald-500 bg-emerald-950/10">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-emerald-400 uppercase">Matched ITC</span>
              <span className="text-[10px] font-bold text-emerald-400 font-mono">{matchedItcPct}%</span>
            </div>
            <div className="text-lg font-extrabold text-emerald-400 mt-1">{formatCurrency(matchedItc)}</div>
            <div className="text-[10px] text-emerald-400/80 font-medium mt-0.5">Eligible for GSTR-3B</div>
          </div>

          {/* ITC Difference */}
          <div className="glass-card p-3.5 border-l-4 border-l-amber-500">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase">ITC Variance</span>
              <span className="text-[10px] font-bold text-amber-400 font-mono">{diffItcPct}%</span>
            </div>
            <div className="text-lg font-extrabold text-amber-400 mt-1">{formatCurrency(itcDifference)}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Books vs 2B Delta</div>
          </div>

          {/* Potential ITC at Risk */}
          <div className="glass-card p-3.5 border-l-4 border-l-rose-500 bg-rose-950/10">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-rose-400 uppercase">ITC At Risk</span>
              <span className="text-[10px] font-bold text-rose-400 font-mono">{riskItcPct}%</span>
            </div>
            <div className="text-lg font-extrabold text-rose-400 mt-1">{formatCurrency(atRiskItc)}</div>
            <div className="text-[10px] text-rose-400/80 font-medium mt-0.5">Unmatched in 2B</div>
          </div>

          {/* Unclaimed 2B ITC */}
          <div className="glass-card p-3.5 border-l-4 border-l-purple-500">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-purple-400 uppercase">Unclaimed 2B ITC</span>
              <span className="text-[10px] font-bold text-purple-400 font-mono">{unclaimedItcPct}%</span>
            </div>
            <div className="text-lg font-extrabold text-purple-400 mt-1">{formatCurrency(unclaimedItc)}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Available on Portal</div>
          </div>
        </div>
      </div>

      {/* KPI INVOICE COUNT BREAKDOWN CARDS */}
      <div className="space-y-2">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Layers size={16} className="text-indigo-400" />
          Reconciliation Invoice Breakdown & Classification
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          <div onClick={() => onNavigate('reconciliation')} className="glass-card p-3 cursor-pointer hover:border-emerald-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Matched (Exact)</span>
            <span className="text-xl font-extrabold text-emerald-400">{exactCount}</span>
          </div>

          <div onClick={() => onNavigate('exceptions')} className="glass-card p-3 cursor-pointer hover:border-amber-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Variances</span>
            <span className="text-xl font-extrabold text-amber-400">{diffCount}</span>
          </div>

          <div onClick={() => onNavigate('exceptions')} className="glass-card p-3 cursor-pointer hover:border-blue-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Probable Match</span>
            <span className="text-xl font-extrabold text-blue-400">{probableCount}</span>
          </div>

          <div onClick={() => onNavigate('reconciliation')} className="glass-card p-3 cursor-pointer hover:border-orange-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Books Only</span>
            <span className="text-xl font-extrabold text-orange-400">{booksOnlyCount}</span>
          </div>

          <div onClick={() => onNavigate('reconciliation')} className="glass-card p-3 cursor-pointer hover:border-purple-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">2B Only</span>
            <span className="text-xl font-extrabold text-purple-400">{g2bOnlyCount}</span>
          </div>

          <div onClick={() => onNavigate('exceptions')} className="glass-card p-3 cursor-pointer hover:border-rose-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Duplicates</span>
            <span className="text-xl font-extrabold text-rose-400">{duplicateCount}</span>
          </div>

          <div onClick={() => onNavigate('exceptions')} className="glass-card p-3 cursor-pointer hover:border-indigo-500/50 transition">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">Review Required</span>
            <span className="text-xl font-extrabold text-indigo-400">{reviewCount}</span>
          </div>
        </div>
      </div>

      {/* VISUAL CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* CHART 1: Reconciliation Status Waterfall Bar */}
        <div className="glass-card lg:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2 border-b border-[#1E293B] pb-3">
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Chart 1: Reconciliation Status Distribution</h4>
              <p className="text-[11px] text-slate-400">Multi-pass matching breakdown across all ingested records</p>
            </div>
            <span className="text-[11px] text-teal-400 font-mono font-bold">Total: {kpis.total_books_invoices + kpis.total_2b_invoices} recs</span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={matchWaterfallData} margin={{ top: 15, right: 20, left: 0, bottom: 25 }}>
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} interval={0} />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} allowDecimals={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#1E293B', borderRadius: '8px', color: '#FFF', fontSize: '12px' }} 
                  cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]} barSize={34}>
                  {matchWaterfallData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* CHART 2: ITC Financial Comparison */}
        <div className="glass-card flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2 border-b border-[#1E293B] pb-3">
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Chart 2: ITC Financial Comparison</h4>
              <p className="text-[11px] text-slate-400">Books vs 2B vs Claimable Credit</p>
            </div>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={itcComparisonData} margin={{ top: 15, right: 15, left: 0, bottom: 25 }}>
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} interval={0} />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                <Tooltip 
                  formatter={(val) => formatCurrency(val)}
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#1E293B', borderRadius: '8px', color: '#FFF', fontSize: '12px' }} 
                />
                <Bar dataKey="amount" radius={[4, 4, 0, 0]} barSize={32}>
                  {itcComparisonData.map((entry, index) => (
                    <Cell key={`cell-itc-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* CHART 3: Vendor-wise ITC Difference */}
        <div className="glass-card lg:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3 border-b border-[#1E293B] pb-3">
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Chart 3: Vendor-wise ITC Difference</h4>
              <p className="text-[11px] text-slate-400">Top vendors contributing to highest reconciliation variance</p>
            </div>
            <button onClick={() => onNavigate('vendors')} className="text-xs text-indigo-400 hover:underline font-semibold">
              View All Vendors &rarr;
            </button>
          </div>

          {topVendors.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-xs text-slate-500">
              No major vendor ITC variances identified.
            </div>
          ) : (
            <div className="space-y-2.5">
              {topVendors.map((v, idx) => (
                <div key={idx} className="bg-[#0F172A] p-2.5 rounded-lg border border-[#1E293B] flex items-center justify-between text-xs">
                  <div>
                    <div className="font-mono font-bold text-white">{v.gstin}</div>
                    <div className="text-[11px] text-slate-400 truncate max-w-[240px]">{v.vendor_name}</div>
                  </div>

                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Books ITC</span>
                      <span className="font-mono text-slate-300 font-semibold">{formatCurrency(v.books_itc)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">2B ITC</span>
                      <span className="font-mono text-slate-300 font-semibold">{formatCurrency(v.gstr2b_itc)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Variance</span>
                      <span className={`font-mono font-extrabold ${v.variance > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {formatCurrency(v.variance)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* CHART 4: ITC Composition Pie */}
        <div className="glass-card flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2 border-b border-[#1E293B] pb-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Chart 4: ITC Risk Distribution</h4>
          </div>

          <div className="h-60 w-full flex flex-col items-center justify-center">
            <ResponsiveContainer width="100%" height="70%">
              <PieChart>
                <Pie
                  data={itcPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {itcPieData.map((entry, index) => (
                    <Cell key={`cell-pie-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => formatCurrency(value)}
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#1E293B', borderRadius: '8px', fontSize: '12px' }} 
                />
              </PieChart>
            </ResponsiveContainer>

            <div className="w-full text-[11px] space-y-1 mt-1 border-t border-[#1E293B] pt-2 font-medium">
              <div className="flex justify-between items-center text-emerald-400">
                <span>● Matched Eligible ITC:</span>
                <span>{formatCurrency(matchedItc)}</span>
              </div>
              <div className="flex justify-between items-center text-orange-400">
                <span>● Books Only (At Risk):</span>
                <span>{formatCurrency(atRiskItc)}</span>
              </div>
              <div className="flex justify-between items-center text-purple-400">
                <span>● 2B Only (Unclaimed):</span>
                <span>{formatCurrency(unclaimedItc)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
