import React, { useState, useEffect } from 'react';
import { Settings, Save, CheckCircle, Sliders } from 'lucide-react';
import { getClientRules, updateClientRules } from '../services/api';

export function RulesConfigPage({ currentClient }) {
  const [rules, setRules] = useState({
    date_tolerance_days: 3,
    tax_tolerance_amount: 1.0,
    taxable_tolerance_amount: 2.0,
    fuzzy_similarity_threshold: 0.85,
    ai_confidence_threshold: 0.80,
    enable_ai_advisory: true,
    match_cn_dn_separately: true,
  });

  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!currentClient?.id) return;
    getClientRules(currentClient.id)
      .then(res => setRules(res.data))
      .catch(err => console.error(err));
  }, [currentClient]);

  const handleSave = async () => {
    setSaving(true);
    setMsg('');
    try {
      await updateClientRules(currentClient.id, rules);
      setMsg('Reconciliation rules updated successfully!');
    } catch (err) {
      setMsg('Failed to save rules');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings size={22} className="text-indigo-400" />
          Rules & Matching Configuration
        </h2>
        <p className="text-xs text-slate-400">
          Configure client-specific tolerances, fuzzy similarity thresholds, and AI advisory settings for <span className="text-indigo-300 font-semibold">{currentClient?.client_name}</span>.
        </p>
      </div>

      {msg && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-3 rounded-lg flex items-center gap-2">
          <CheckCircle size={16} /> {msg}
        </div>
      )}

      {/* Settings Grid */}
      <div className="glass-card space-y-6">
        {/* Date Tolerance */}
        <div>
          <label className="text-xs font-bold text-white block mb-1">
            Invoice Date Tolerance: <span className="text-indigo-400 font-mono">{rules.date_tolerance_days} Days</span>
          </label>
          <p className="text-[11px] text-slate-400 mb-2">Maximum allowable invoice date delta (0, 1, 3, 7 days) between Books and GSTR-2B</p>
          <input
            type="range"
            min="0"
            max="14"
            step="1"
            value={rules.date_tolerance_days}
            onChange={(e) => setRules({ ...rules, date_tolerance_days: parseInt(e.target.value) })}
            className="w-full accent-indigo-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
            <span>0 Days (Exact)</span>
            <span>3 Days</span>
            <span>7 Days</span>
            <span>14 Days</span>
          </div>
        </div>

        <div className="h-[1px] bg-[#1E293B]"></div>

        {/* Tax Amount Tolerance */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-white block mb-1">Tax Amount Tolerance (₹)</label>
            <p className="text-[11px] text-slate-400 mb-2">Allowed rounding variance for total tax</p>
            <input
              type="number"
              step="0.1"
              value={rules.tax_tolerance_amount}
              onChange={(e) => setRules({ ...rules, tax_tolerance_amount: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-white block mb-1">Taxable Value Tolerance (₹)</label>
            <p className="text-[11px] text-slate-400 mb-2">Allowed variance for taxable value</p>
            <input
              type="number"
              step="0.1"
              value={rules.taxable_tolerance_amount}
              onChange={(e) => setRules({ ...rules, taxable_tolerance_amount: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="h-[1px] bg-[#1E293B]"></div>

        {/* Fuzzy Similarity Threshold */}
        <div>
          <label className="text-xs font-bold text-white block mb-1">
            Fuzzy Invoice Match Threshold: <span className="text-indigo-400 font-mono">{(rules.fuzzy_similarity_threshold * 100).toFixed(0)}%</span>
          </label>
          <p className="text-[11px] text-slate-400 mb-2">Minimum string similarity score for invoice number matching</p>
          <input
            type="range"
            min="0.50"
            max="1.00"
            step="0.05"
            value={rules.fuzzy_similarity_threshold}
            onChange={(e) => setRules({ ...rules, fuzzy_similarity_threshold: parseFloat(e.target.value) })}
            className="w-full accent-indigo-500 cursor-pointer"
          />
        </div>

        <div className="h-[1px] bg-[#1E293B]"></div>

        {/* Toggles */}
        <div className="space-y-3">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={rules.enable_ai_advisory}
              onChange={(e) => setRules({ ...rules, enable_ai_advisory: e.target.checked })}
              className="w-4 h-4 rounded bg-[#0F172A] border-[#1E293B] text-indigo-600 focus:ring-indigo-500"
            />
            <div>
              <span className="text-xs font-bold text-white block">Enable AI Auxiliary Advisory Scoring (Level 7)</span>
              <span className="text-[11px] text-slate-400">Calls AI service on ambiguous pairs (scores 0.60–0.84) without overriding rules.</span>
            </div>
          </label>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={rules.match_cn_dn_separately}
              onChange={(e) => setRules({ ...rules, match_cn_dn_separately: e.target.checked })}
              className="w-4 h-4 rounded bg-[#0F172A] border-[#1E293B] text-indigo-600 focus:ring-indigo-500"
            />
            <div>
              <span className="text-xs font-bold text-white block">Process Credit Notes & Debit Notes Separately</span>
              <span className="text-[11px] text-slate-400">Strictly match CN with CN and DN with DN.</span>
            </div>
          </label>
        </div>

        <div className="pt-4 flex justify-end">
          <button onClick={handleSave} disabled={saving} className="btn btn-primary">
            <Save size={16} /> {saving ? 'Saving Rules...' : 'Save Configuration'}
          </button>
        </div>
      </div>
    </div>
  );
}
