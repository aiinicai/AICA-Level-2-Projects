import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:8000/api/v1';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Clients API
export const getClients = () => api.get('/clients');
export const createClient = (data) => api.post('/clients', data);
export const updateClient = (clientId, data) => api.put(`/clients/${clientId}`, data);
export const deleteClient = (clientId) => api.delete(`/clients/${clientId}`);
export const getClientRules = (clientId) => api.get(`/clients/${clientId}/rules`);
export const updateClientRules = (clientId, rules) => api.put(`/clients/${clientId}/rules`, rules);

// Uploads API
export const inspectUploadFile = (formData) => api.post('/uploads/inspect', formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
});

export const getTemplateUrl = (filename) => `${API_BASE_URL}/uploads/templates/${filename}`;

// Reconciliation API
export const runReconciliationJob = (formData) => api.post('/reconciliation/run', formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
});

export const getReconciliationJobs = (clientId) => api.get('/reconciliation/jobs', { params: { client_id: clientId } });

export const getJobResults = (jobId, params) => api.get(`/reconciliation/jobs/${jobId}/results`, { params });

export const manualMatchOverride = (data) => api.post('/reconciliation/manual-match', data);

export const clearReconciliationData = (clientId, clearAll = false) => api.post('/reconciliation/clear-data', { client_id: clientId, clear_all: clearAll });

export const getVendorSummary = (jobId) => api.get(`/reconciliation/jobs/${jobId}/vendor-summary`);

export const getAuditLogs = (jobId) => api.get(`/reconciliation/jobs/${jobId}/audit-logs`);

export const getExportExcelUrl = (jobId) => `${API_BASE_URL}/reconciliation/jobs/${jobId}/export-excel`;
