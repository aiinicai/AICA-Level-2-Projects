import React, { useState, useEffect } from 'react';
import { Sidebar, Header } from './components/layout/Header';
import { LoginPage } from './components/auth/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { UploadPage } from './pages/UploadPage';
import { ReconciliationPage } from './pages/ReconciliationPage';
import { VendorAnalysisPage } from './pages/VendorAnalysisPage';
import { ExceptionsPage } from './pages/ExceptionsPage';
import { RulesConfigPage } from './pages/RulesConfigPage';
import { ReportsPage } from './pages/ReportsPage';
import { AuditPage } from './pages/AuditPage';
import { ClientsPage } from './pages/ClientsPage';
import { HelpPage } from './pages/HelpPage';

import { getClients, getReconciliationJobs } from './services/api';

export default function App() {
  const [user, setUser] = useState({ name: 'Tax Professional', email: 'admin@asafirm.in', role: 'Tax Manager' });
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Default active session
  const [activeTab, setActiveTab] = useState('dashboard');
  const [clients, setClients] = useState([]);
  const [currentClient, setCurrentClient] = useState(null);
  
  const [selectedFy, setSelectedFy] = useState('2026-27');
  const [selectedMonth, setSelectedMonth] = useState('April 2026');

  const [activeJobId, setActiveJobId] = useState(null);
  const [kpis, setKpis] = useState(null);

  const fetchClientsList = async () => {
    try {
      const res = await getClients();
      const clientList = res.data || [];
      setClients(clientList);
      if (clientList.length > 0) {
        if (!currentClient || !clientList.find(c => c.id === currentClient.id)) {
          setCurrentClient(clientList[0]);
        }
      }
    } catch (err) {
      console.error('Failed to fetch clients:', err);
    }
  };

  const fetchLatestJobForClient = async (clientId) => {
    if (!clientId) return;
    try {
      const res = await getReconciliationJobs(clientId);
      const jobs = res.data || [];
      if (jobs.length > 0) {
        const latest = jobs[0];
        setActiveJobId(latest.job_id);
        setKpis(latest.kpis);
      } else {
        setActiveJobId(null);
        setKpis(null);
      }
    } catch (err) {
      console.error('Failed to fetch jobs:', err);
    }
  };

  useEffect(() => {
    fetchClientsList();
  }, []);

  useEffect(() => {
    if (currentClient) {
      fetchLatestJobForClient(currentClient.id);
    }
  }, [currentClient]);

  const handleRunComplete = (jobData) => {
    setActiveJobId(jobData.job_id);
    setKpis(jobData.kpis);
    setActiveTab('dashboard');
  };

  const handleDataCleared = () => {
    setActiveJobId(null);
    setKpis(null);
    setActiveTab('upload');
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={(userData) => { setUser(userData); setIsAuthenticated(true); }} />;
  }

  return (
    <div className="app-container">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="main-wrapper">
        <Header
          user={user}
          currentClient={currentClient}
          clients={clients}
          onSelectClient={setCurrentClient}
          selectedFy={selectedFy}
          setSelectedFy={setSelectedFy}
          selectedMonth={selectedMonth}
          setSelectedMonth={setSelectedMonth}
          onDataCleared={handleDataCleared}
        />

        <main className="content-area">
          {activeTab === 'dashboard' && (
            <DashboardPage
              kpis={kpis}
              currentClient={currentClient}
              selectedFy={selectedFy}
              selectedMonth={selectedMonth}
              activeJobId={activeJobId}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'reconciliation' && (
            <ReconciliationPage activeJobId={activeJobId} />
          )}

          {activeTab === 'upload' && (
            <UploadPage
              currentClient={currentClient}
              selectedFy={selectedFy}
              selectedMonth={selectedMonth}
              onRunComplete={handleRunComplete}
            />
          )}

          {activeTab === 'exceptions' && (
            <ExceptionsPage activeJobId={activeJobId} />
          )}

          {activeTab === 'rules' && (
            <RulesConfigPage currentClient={currentClient} />
          )}

          {activeTab === 'reports' && (
            <ReportsPage
              activeJobId={activeJobId}
              currentClient={currentClient}
              selectedPeriod={`${selectedFy} - ${selectedMonth}`}
            />
          )}

          {activeTab === 'clients' && (
            <ClientsPage
              clients={clients}
              onRefreshClients={fetchClientsList}
              onSelectClient={setCurrentClient}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'help' && (
            <HelpPage />
          )}
        </main>
      </div>
    </div>
  );
}
