@echo off
TITLE GST Reconciliation Suite First-Time Installer
COLOR 0B

cd /d "%~dp0"

echo =========================================================================
echo       GST INVOICE RECONCILIATION - FIRST TIME DEPENDENCY INSTALLER
echo =========================================================================
echo Working Directory: %CD%
echo.

echo [1/2] Installing Python backend requirements...
python -m pip install -r backend\requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install Python dependencies.
    pause
    exit /b 1
)

echo.
echo [2/2] Installing Frontend npm dependencies...
cd /d "%~dp0frontend"
call npm install
cd /d "%~dp0"
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install npm dependencies.
    pause
    exit /b 1
)

echo.
echo =========================================================================
echo [SUCCESS] All dependencies installed successfully!
echo You can now launch the app anytime by double-clicking:
echo start_gst_reconciliation.bat
echo =========================================================================
echo.
pause
