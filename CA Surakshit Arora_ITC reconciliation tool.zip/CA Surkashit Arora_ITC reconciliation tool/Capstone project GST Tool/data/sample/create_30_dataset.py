import os
import openpyxl

def create_30_test_datasets():
    os.makedirs("data/sample", exist_ok=True)
    
    # 1. Purchase Register (30 Records)
    pr_wb = openpyxl.Workbook()
    pr_ws = pr_wb.active
    pr_ws.title = "Purchase Register"
    
    pr_headers = [
        "Supplier GSTIN", "Supplier Name", "Invoice Number", "Invoice Date", 
        "Document Type", "Taxable Value", "IGST", "CGST", "SGST", "Cess", "Total ITC"
    ]
    pr_ws.append(pr_headers)
    
    pr_rows = [
        # 1-5: Exact Matches
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV/2026/001", "05/04/2026", "INV", 100000, 18000, 0, 0, 0, 18000],
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV/2026/002", "10/04/2026", "INV", 50000, 9000, 0, 0, 0, 9000],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "Z-8001", "15/04/2026", "INV", 25000, 0, 2250, 2250, 0, 4500],
        ["27XYZPD9876K1Z9", "Global Tech", "INV-9001", "20/04/2026", "INV", 75000, 13500, 0, 0, 0, 13500],
        ["33BBBCC9999M1Z2", "Apex Logistics", "APX-101", "25/04/2026", "INV", 40000, 7200, 0, 0, 0, 7200],
        
        # 6-9: Invoice Formatting Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV/006/26-27", "02/05/2026", "INV", 60000, 10800, 0, 0, 0, 10800],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "Z 8007 26-27", "05/05/2026", "INV", 30000, 0, 2700, 2700, 0, 5400],
        ["27XYZPD9876K1Z9", "Global Tech", "INV-008-2026", "10/05/2026", "INV", 80000, 14400, 0, 0, 0, 14400],
        ["33BBBCC9999M1Z2", "Apex Logistics", "APX/009", "12/05/2026", "INV", 45000, 8100, 0, 0, 0, 8100],
        
        # 10-12: GSTIN Missing in Books or 2B
        ["", "Vendor Without GSTIN", "NOGST-101", "15/05/2026", "INV", 20000, 3600, 0, 0, 0, 3600],
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "NOGST-102", "18/05/2026", "INV", 22000, 3960, 0, 0, 0, 3960],
        ["", "Unknown Vendor B", "NOGST-103", "20/05/2026", "INV", 15000, 2700, 0, 0, 0, 2700],
        
        # 13-15: Date Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV-DATE-13", "01/06/2026", "INV", 50000, 9000, 0, 0, 0, 9000],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-DATE-14", "05/06/2026", "INV", 35000, 0, 3150, 3150, 0, 6300],
        ["27XYZPD9876K1Z9", "Global Tech", "INV-DATE-15", "10/06/2026", "INV", 90000, 16200, 0, 0, 0, 16200],
        
        # 16-18: ITC Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV-TAX-16", "15/06/2026", "INV", 100000, 18000, 0, 0, 0, 18000.50],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-TAX-17", "18/06/2026", "INV", 40000, 0, 3600, 3600, 0, 7200], # 2B will be 7700
        ["27XYZPD9876K1Z9", "Global Tech", "INV-TAX-18", "20/06/2026", "INV", 65000, 11700, 0, 0, 0, 11700], # 2B will be 12000
        
        # 19-21: Duplicates in Books
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV-DUP-19", "22/06/2026", "INV", 30000, 5400, 0, 0, 0, 5400],
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV-DUP-19", "22/06/2026", "INV", 30000, 5400, 0, 0, 0, 5400], # Dup entry
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-DUP-21", "25/06/2026", "INV", 28000, 0, 2520, 2520, 0, 5040],
        
        # 22-25: Books Only (Unmatched)
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "BOOK-ONLY-22", "27/06/2026", "INV", 12000, 2160, 0, 0, 0, 2160],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "BOOK-ONLY-23", "28/06/2026", "INV", 18000, 0, 1620, 1620, 0, 3240],
        ["27XYZPD9876K1Z9", "Global Tech", "BOOK-ONLY-24", "29/06/2026", "INV", 24000, 4320, 0, 0, 0, 4320],
        ["33BBBCC9999M1Z2", "Apex Logistics", "BOOK-ONLY-25", "30/06/2026", "INV", 16000, 2880, 0, 0, 0, 2880],
        
        # 26-28: Credit Notes & Debit Notes
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "CN-2026-26", "30/06/2026", "CN", -10000, -1800, 0, 0, 0, -1800],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "DN-2026-27", "30/06/2026", "DN", 5000, 0, 450, 450, 0, 900],
        ["27XYZPD9876K1Z9", "Global Tech", "CN-2026-28", "30/06/2026", "CN", -5000, -900, 0, 0, 0, -900],
        
        # 29-30: Fuzzy Match Candidates
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV-TYPO-SRV-29", "30/06/2026", "INV", 50000, 9000, 0, 0, 0, 9000],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-TYPO-SRV-30", "30/06/2026", "INV", 40000, 0, 3600, 3600, 0, 7200],
    ]
    
    for r in pr_rows:
        pr_ws.append(r)
    pr_wb.save("data/sample/sample_purchase_register_30.xlsx")

    # 2. GSTR-2B (30 Records)
    g2b_wb = openpyxl.Workbook()
    g2b_ws = g2b_wb.active
    g2b_ws.title = "GSTR-2B"
    
    g2b_headers = [
        "GSTIN of Supplier", "Trade/Legal Name", "Invoice Number", "Invoice Date", 
        "Document Type", "Taxable Value", "Integrated Tax", "Central Tax", "State Tax", "Cess", "Total Tax"
    ]
    g2b_ws.append(g2b_headers)
    
    g2b_rows = [
        # 1-5: Exact Matches
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV/2026/001", "05/04/2026", "INV", 100000, 18000, 0, 0, 0, 18000],
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV/2026/002", "10/04/2026", "INV", 50000, 9000, 0, 0, 0, 9000],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "Z-8001", "15/04/2026", "INV", 25000, 0, 2250, 2250, 0, 4500],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV-9001", "20/04/2026", "INV", 75000, 13500, 0, 0, 0, 13500],
        ["33BBBCC9999M1Z2", "Apex Logistics Ltd", "APX-101", "25/04/2026", "INV", 40000, 7200, 0, 0, 0, 7200],
        
        # 6-9: Invoice Formatting Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV0062627", "02/05/2026", "INV", 60000, 10800, 0, 0, 0, 10800],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "Z80072627", "05/05/2026", "INV", 30000, 0, 2700, 2700, 0, 5400],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV0082026", "10/05/2026", "INV", 80000, 14400, 0, 0, 0, 14400],
        ["33BBBCC9999M1Z2", "Apex Logistics Ltd", "APX009", "12/05/2026", "INV", 45000, 8100, 0, 0, 0, 8100],
        
        # 10-12: GSTIN Missing in Books or 2B
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "NOGST-101", "15/05/2026", "INV", 20000, 3600, 0, 0, 0, 3600],
        ["", "Vendor Without GSTIN", "NOGST-102", "18/05/2026", "INV", 22000, 3960, 0, 0, 0, 3960],
        ["", "Unknown Vendor B", "NOGST-103", "20/05/2026", "INV", 15000, 2700, 0, 0, 0, 2700],
        
        # 13-15: Date Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV-DATE-13", "02/06/2026", "INV", 50000, 9000, 0, 0, 0, 9000], # +1 day
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-DATE-14", "07/06/2026", "INV", 35000, 0, 3150, 3150, 0, 6300], # +2 days
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV-DATE-15", "15/06/2026", "INV", 90000, 16200, 0, 0, 0, 16200], # +5 days
        
        # 16-18: ITC Differences
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV-TAX-16", "15/06/2026", "INV", 100000, 18000, 0, 0, 0, 18000.00], # diff 0.50
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-TAX-17", "18/06/2026", "INV", 40000, 0, 3850, 3850, 0, 7700], # diff 500
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV-TAX-18", "20/06/2026", "INV", 65000, 12000, 0, 0, 0, 12000], # diff 300
        
        # 19-21: Duplicates / Candidates
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV-DUP-19", "22/06/2026", "INV", 30000, 5400, 0, 0, 0, 5400],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-DUP-21", "25/06/2026", "INV", 28000, 0, 2520, 2520, 0, 5040],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-DUP-21", "25/06/2026", "INV", 28000, 0, 2520, 2520, 0, 5040], # Dup 2B
        
        # 22-25: 2B Only (Unmatched)
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "2B-ONLY-22", "27/06/2026", "INV", 15000, 2700, 0, 0, 0, 2700],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "2B-ONLY-23", "28/06/2026", "INV", 20000, 0, 1800, 1800, 0, 3600],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "2B-ONLY-24", "29/06/2026", "INV", 30000, 5400, 0, 0, 0, 5400],
        ["33BBBCC9999M1Z2", "Apex Logistics Ltd", "2B-ONLY-25", "30/06/2026", "INV", 10000, 1800, 0, 0, 0, 1800],
        
        # 26-28: Credit Notes & Debit Notes
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "CN-2026-26", "30/06/2026", "CN", -10000, -1800, 0, 0, 0, -1800],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "DN-2026-27", "30/06/2026", "DN", 5000, 0, 450, 450, 0, 900],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "CN-2026-28", "30/06/2026", "CN", -5000, -900, 0, 0, 0, -900],
        
        # 29-30: Fuzzy Match Candidates
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV-TYPO-SRV29", "30/06/2026", "INV", 50000, 9000, 0, 0, 0, 9000],
        ["29ABCDE5678G2Z1", "Zenith Supplies", "INV-TYPO-SRV30", "30/06/2026", "INV", 40000, 0, 3600, 3600, 0, 7200],
    ]
    
    for r in g2b_rows:
        g2b_ws.append(r)
    g2b_wb.save("data/sample/sample_gstr2b_30.xlsx")

    print("[SUCCESS] Created 30-record synthetic datasets in data/sample/")

if __name__ == "__main__":
    create_30_test_datasets()
