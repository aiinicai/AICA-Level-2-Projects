from typing import Dict, Any
from backend.app.ai.base import BaseAIProvider, AISuggestion
from datetime import datetime

class MockAIProvider(BaseAIProvider):
    """
    Mock AI Provider used for offline reconciliation, deterministic testing, 
    or when external API keys are not supplied.
    """
    def evaluate_ambiguous_pair(
        self,
        books_record_summary: Dict[str, Any],
        gstr2b_record_summary: Dict[str, Any],
        fuzzy_score: float
    ) -> AISuggestion:
        # Determine suggestion based on similarity score and value matching
        tax_diff = abs(books_record_summary.get("total_tax", 0) - gstr2b_record_summary.get("total_tax", 0))
        
        if fuzzy_score >= 0.75 and tax_diff <= 5.0:
            return AISuggestion(
                match_opinion="MATCH",
                confidence=0.88,
                reasoning=f"High invoice similarity ({fuzzy_score:.2f}) and minor tax variance (₹{tax_diff:.2f}). Probable OCR/formatting typo.",
                suggested_level="LEVEL_7_AI",
                provider="MockAI-V1"
            )
        elif fuzzy_score >= 0.60:
            return AISuggestion(
                match_opinion="REVIEW",
                confidence=0.65,
                reasoning=f"Moderate similarity score ({fuzzy_score:.2f}) with tax variance (₹{tax_diff:.2f}). CA manual inspection advised.",
                suggested_level="LEVEL_8_REVIEW",
                provider="MockAI-V1"
            )
        else:
            return AISuggestion(
                match_opinion="NO_MATCH",
                confidence=0.90,
                reasoning="Low similarity and high discrepancy across invoice numbers and amounts.",
                suggested_level="NO_MATCH",
                provider="MockAI-V1"
            )
