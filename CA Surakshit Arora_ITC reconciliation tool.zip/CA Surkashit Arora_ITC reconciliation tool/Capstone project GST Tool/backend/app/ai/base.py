from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timezone

class AISuggestion(BaseModel):
    match_opinion: str  # "MATCH", "NO_MATCH", "REVIEW"
    confidence: float   # 0.0 to 1.0
    reasoning: str
    suggested_level: str
    provider: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class BaseAIProvider(ABC):
    @abstractmethod
    def evaluate_ambiguous_pair(
        self,
        books_record_summary: Dict[str, Any],
        gstr2b_record_summary: Dict[str, Any],
        fuzzy_score: float
    ) -> AISuggestion:
        pass
