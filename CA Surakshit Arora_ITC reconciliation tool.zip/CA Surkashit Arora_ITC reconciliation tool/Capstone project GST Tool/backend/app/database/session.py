from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import sessionmaker, declarative_base
import os

DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data")
os.makedirs(DB_DIR, exist_ok=True)
DATABASE_URL = f"sqlite:///{os.path.join(DB_DIR, 'gst_reco.db')}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def init_db():
    from backend.app.models.domain import Base
    Base.metadata.create_all(bind=engine)
    
    # Auto-migration for SQLite missing columns
    try:
        inspector = inspect(engine)
        if "reconciliation_results" in inspector.get_table_names():
            columns = [c["name"] for c in inspector.get_columns("reconciliation_results")]
            with engine.connect() as conn:
                if "match_score" not in columns:
                    conn.execute(text("ALTER TABLE reconciliation_results ADD COLUMN match_score INTEGER DEFAULT 100"))
                if "gstin_match_status" not in columns:
                    conn.execute(text("ALTER TABLE reconciliation_results ADD COLUMN gstin_match_status VARCHAR DEFAULT 'MATCHED'"))
                if "inv_match_status" not in columns:
                    conn.execute(text("ALTER TABLE reconciliation_results ADD COLUMN inv_match_status VARCHAR DEFAULT 'MATCHED'"))
                conn.commit()
    except Exception as e:
        print(f"[DB MIGRATION NOTICE] {e}")

# Run schema initialization and migration on module import
init_db()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
