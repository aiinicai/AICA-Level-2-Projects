import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import List, Dict, Any
from datetime import datetime
from backend.app.schemas.reconciliation import MatchResult, SummaryKPI, MatchStatus

# ASA Professional Color Palette
NAVY_FILL = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
SLATE_HEADER_FILL = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
TEAL_HEADER_FILL = PatternFill(start_color="0D9488", end_color="0D9488", fill_type="solid")

HEADER_FONT = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="Segoe UI", size=16, bold=True, color="0F172A")
SUBTITLE_FONT = Font(name="Segoe UI", size=11, bold=True, color="0D9488")
SECTION_FONT = Font(name="Segoe UI", size=12, bold=True, color="0F172A")
BOLD_FONT = Font(name="Segoe UI", size=10, bold=True)
REGULAR_FONT = Font(name="Segoe UI", size=10)

THIN_BORDER = Border(
    left=Side(style="thin", color="CBD5E1"),
    right=Side(style="thin", color="CBD5E1"),
    top=Side(style="thin", color="CBD5E1"),
    bottom=Side(style="thin", color="CBD5E1")
)

def export_reconciliation_report(
    filepath: Any,
    results: List[MatchResult],
    kpis: SummaryKPI,
    client_info: Dict[str, Any],
    audit_logs: List[Dict[str, Any]] = None
):
    """
    Generates a streamlined 3-sheet commercial GST Reconciliation Report.
    Sheets:
      1. Executive Summary
      2. Invoice Wise Reconciliation
      3. Exceptions & Discrepancies
    """
    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # Remove default active sheet

    # 1. Sheet 1: Executive Summary & Dynamic Key Findings
    _build_executive_summary_sheet(wb, results, kpis, client_info)

    # 2. Sheet 2: Invoice Wise Reconciliation (All Master Records)
    _build_records_sheet(wb, "Invoice Wise Reconciliation", results)

    # 3. Sheet 3: Exceptions & Discrepancies (Filtered Unmatched / Tax Diff / Probable Records)
    def is_exception(r):
        st = r.match_status.value if hasattr(r.match_status, 'value') else str(r.match_status)
        return st not in (MatchStatus.MATCHED.value, MatchStatus.INV_NO_MATCH_NO_GSTIN.value)

    exception_results = [r for r in results if is_exception(r)]
    _build_records_sheet(wb, "Exceptions & Discrepancies", exception_results)

    wb.save(filepath)

def generate_audit_remark(r: MatchResult) -> str:
    """
    Generates single authoritative Audit Remarks & Reason based on actual ITC amounts, dates, and match status.
    """
    b = r.books_record
    g = r.gstr2b_record
    st = r.match_status.value if hasattr(r.match_status, 'value') else str(r.match_status)
    tax_diff = abs(r.total_tax_diff or 0.0)
    
    if st == MatchStatus.MATCHED.value:
        return "Fully matched & verified. Eligible for GSTR-3B ITC claim."
    elif st == MatchStatus.MATCHED_DATE_DIFF.value:
        return f"GSTIN & Invoice No matched; Tax matched. Invoice date differs by {r.date_diff_days} day(s)."
    elif st == MatchStatus.MATCHED_TAX_DIFF.value:
        return f"GSTIN & Invoice No matched. Books ITC: ₹{(b.total_tax if b else 0):,.2f} vs 2B ITC: ₹{(g.total_tax if g else 0):,.2f} (Variance: ₹{tax_diff:,.2f})."
    elif st == MatchStatus.MATCHED_DATE_TAX_DIFF.value:
        return f"GSTIN & Invoice No matched. Date diff: {r.date_diff_days} day(s); Tax variance: ₹{tax_diff:,.2f}."
    elif st == MatchStatus.INV_NO_MATCH_NO_GSTIN.value:
        return "Invoice No matched, but GSTIN was missing or unavailable in one record."
    elif st == MatchStatus.PROBABLE_MATCH.value:
        return f"Probable match based on invoice similarity ({r.match_score}%). Manual review required."
    elif st == MatchStatus.BOOKS_ONLY.value:
        return f"Present in Purchase Register only (₹{(b.total_tax if b else 0):,.2f}). Missing in GSTR-2B (Ineligible under Rule 36(4))."
    elif st == MatchStatus.GSTR2B_ONLY.value:
        return f"Present in GSTR-2B portal only (₹{(g.total_tax if g else 0):,.2f}). Not in Purchase Register (Unclaimed credit opportunity)."
    elif st == MatchStatus.DUPLICATE_IN_BOOKS.value:
        return f"Duplicate entry in Purchase Register (Books ITC: ₹{(b.total_tax if b else 0):,.2f})."
    elif st == MatchStatus.DUPLICATE_IN_2B.value:
        return f"Duplicate entry in GSTR-2B portal (2B ITC: ₹{(g.total_tax if g else 0):,.2f})."
    else:
        return r.match_notes or "Review required by tax professional."

def _build_executive_summary_sheet(wb, results: List[MatchResult], kpis: SummaryKPI, client_info: Dict[str, Any]):
    ws = wb.create_sheet("Executive Summary")
    
    # Header Cover Block
    ws.append(["ASA | INPUT RECONCILIATION TOOL"])
    ws.append(["GST PURCHASE REGISTER vs GSTR-2B AUDIT REPORT"])
    ws.append([f"Client Name: {client_info.get('client_name', 'N/A')} | GSTIN: {client_info.get('gstin', 'N/A')}"])
    ws.append([f"Financial Year: {client_info.get('fy', '2026-27')} | Tax Period: {client_info.get('period', 'N/A')} | Report Date: {datetime.now().strftime('%d-%b-%Y')}"])
    ws.append([])

    # Executive KPI Summary Table
    ws.append(["EXECUTIVE KPI SUMMARY METRIC", "INVOICE COUNT", "BOOKS ITC (₹)", "2B ITC (₹)", "AUDIT REMARK"])
    
    exact_count = (kpis.exact_matches or 0) + (kpis.inv_no_match_no_gstin or 0)
    diff_count = (kpis.matched_date_diff or 0) + (kpis.matched_tax_diff or 0) + (kpis.matched_date_tax_diff or 0)
    
    summary_rows = [
        ["Total Books Purchase Invoices", kpis.total_books_invoices, kpis.books_itc, 0.0, "Base Purchase Register"],
        ["Total GSTR-2B Portal Invoices", kpis.total_2b_invoices, 0.0, kpis.gstr2b_itc, "Portal Auto-Drafted Statement"],
        ["Matched Invoices (Exact)", exact_count, kpis.matched_itc, kpis.matched_itc, "VERIFIED - Eligible for GSTR-3B Claim"],
        ["Matched with Date/Tax Difference", diff_count, 0.0, 0.0, "Date/Tax Variance - Follow up required"],
        ["Probable Matches (Fuzzy)", kpis.probable_matches or 0, 0.0, 0.0, "Requires Manual Audit"],
        ["Books Only Unmatched (At Risk)", kpis.books_only or 0, kpis.potential_itc_at_risk, 0.0, "UNMATCHED - Ineligible under Rule 36(4)"],
        ["GSTR-2B Only Unmatched (Unclaimed)", kpis.gstr2b_only or 0, 0.0, max(0.0, round(kpis.gstr2b_itc - kpis.matched_itc, 2)), "Available Credit Opportunity"],
        ["Duplicate Invoices Identified", (kpis.duplicates_books or 0) + (kpis.duplicates_2b or 0), 0.0, 0.0, "Duplicate Entries Flagged"],
    ]
    for row in summary_rows:
        ws.append(row)

    ws.append([])
    
    # Dynamically Generated Key Findings
    ws.append(["DYNAMIC AUDIT KEY FINDINGS"])
    
    total_books = kpis.total_books_invoices if kpis.total_books_invoices > 0 else 1
    match_pct = round((exact_count / total_books) * 100, 1)
    
    findings = [
        f"• {match_pct}% of purchase invoices were successfully reconciled with GSTR-2B.",
        f"• ₹{(kpis.potential_itc_at_risk / 100000):.2f} Lakhs of ITC requires review due to invoice/tax differences or missing GSTR-2B records.",
        f"• {kpis.books_only} invoices recorded in Books were not identified in GSTR-2B (Rule 36(4) Risk).",
        f"• {kpis.gstr2b_only} invoices appear in GSTR-2B but were not identified in the Purchase Register (Unclaimed Credit opportunity)."
    ]
    for f in findings:
        ws.append([f])

    _style_executive_summary_sheet(ws)

def _build_records_sheet(wb, title: str, results: List[MatchResult]):
    ws = wb.create_sheet(title)
    
    headers = [
        "Sr. No.", "Supplier GSTIN", "Vendor Name", "Books Invoice No.", "2B Invoice No.",
        "Books Date", "2B Date", "Books Tax (₹)", "2B Tax (₹)", "Tax Variance (₹)",
        "Reconciliation Status", "Audit Remarks & Reason"
    ]
    ws.append(headers)

    for idx, r in enumerate(results):
        b = r.books_record
        g = r.gstr2b_record

        gstin = b.gstin if b else (g.gstin if g else "N/A")
        name = b.vendor_name if b else (g.vendor_name if g else "N/A")
        st_val = r.match_status.value if hasattr(r.match_status, 'value') else str(r.match_status)
        remark = generate_audit_remark(r)

        row = [
            idx + 1,
            gstin,
            name,
            b.original_invoice_number if b else "-",
            g.original_invoice_number if g else "-",
            b.invoice_date_str if b else "-",
            g.invoice_date_str if g else "-",
            b.total_tax if b else 0.0,
            g.total_tax if g else 0.0,
            r.total_tax_diff or 0.0,
            st_val,
            remark
        ]
        ws.append(row)

    _style_data_sheet(ws)

def _style_executive_summary_sheet(ws):
    ws.freeze_panes = "A7"
    ws.cell(row=1, column=1).font = TITLE_FONT
    ws.cell(row=2, column=1).font = SUBTITLE_FONT
    
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            if cell.row == 6:
                cell.fill = NAVY_FILL
                cell.font = HEADER_FONT
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif cell.row > 6:
                cell.font = REGULAR_FONT
                cell.border = THIN_BORDER
                if isinstance(cell.value, (int, float)):
                    cell.number_format = "₹#,##0.00"
            val_len = len(str(cell.value or ""))
            if val_len > max_len:
                max_len = val_len
        ws.column_dimensions[col_letter].width = max(max_len + 4, 20)

def _style_data_sheet(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            if cell.row == 1:
                cell.fill = NAVY_FILL
                cell.font = HEADER_FONT
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            else:
                cell.font = REGULAR_FONT
                cell.border = THIN_BORDER
                if isinstance(cell.value, float):
                    cell.number_format = "₹#,##0.00"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                elif isinstance(cell.value, int):
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")
                    
            val_len = len(str(cell.value or ""))
            if val_len > max_len:
                max_len = val_len
        ws.column_dimensions[col_letter].width = min(max(max_len + 4, 14), 55)
