import pandas as pd
from typing import List, Dict, Any, Tuple, Optional
from backend.app.schemas.reconciliation import StandardRecord, SourceType
from backend.app.services.cleaner import (
    clean_gstin, clean_invoice_number, clean_amount, parse_date, clean_doc_type
)
from backend.app.services.mapper import auto_detect_column_mapping

def parse_excel_to_standard_records(
    filepath_or_bytes: Any,
    source: SourceType,
    column_mapping: Optional[Dict[str, str]] = None
) -> Tuple[List[StandardRecord], Dict[str, str], List[str]]:
    """
    Parses Excel file into standardized list of StandardRecord items.
    Returns (records, used_mapping, errors).
    """
    errors: List[str] = []
    
    try:
        df = pd.read_excel(filepath_or_bytes, engine="openpyxl")
    except Exception as e:
        errors.append(f"Failed to read Excel file: {str(e)}")
        return ([], {}, errors)
        
    raw_columns = [str(c) for c in df.columns]
    
    if not column_mapping:
        used_mapping = auto_detect_column_mapping(raw_columns)
    else:
        used_mapping = column_mapping

    records: List[StandardRecord] = []
    
    for idx, row in df.iterrows():
        row_num = idx + 2  # 1-indexed header + row offset
        
        gstin_raw = row.get(used_mapping.get("gstin")) if used_mapping.get("gstin") else ""
        gstin = clean_gstin(gstin_raw)
        
        inv_raw = row.get(used_mapping.get("invoice_number")) if used_mapping.get("invoice_number") else ""
        orig_inv, norm_inv = clean_invoice_number(inv_raw)
        
        if not gstin and not orig_inv:
            # Skip completely empty trailing rows
            continue
            
        vendor_name = str(row.get(used_mapping.get("vendor_name")) or "Unknown Vendor").strip()
        date_raw = row.get(used_mapping.get("invoice_date")) if used_mapping.get("invoice_date") else None
        d_obj, d_str = parse_date(date_raw)
        
        doc_raw = row.get(used_mapping.get("doc_type")) if used_mapping.get("doc_type") else "INV"
        doc_type = clean_doc_type(doc_raw)
        
        taxable_val = clean_amount(row.get(used_mapping.get("taxable_value"))) if used_mapping.get("taxable_value") else 0.0
        igst_val = clean_amount(row.get(used_mapping.get("igst"))) if used_mapping.get("igst") else 0.0
        cgst_val = clean_amount(row.get(used_mapping.get("cgst"))) if used_mapping.get("cgst") else 0.0
        sgst_val = clean_amount(row.get(used_mapping.get("sgst"))) if used_mapping.get("sgst") else 0.0
        cess_val = clean_amount(row.get(used_mapping.get("cess"))) if used_mapping.get("cess") else 0.0
        
        # Check if direct Total ITC / Tax Amount column exists
        direct_itc = clean_amount(row.get(used_mapping.get("itc_total"))) if used_mapping.get("itc_total") else 0.0
        
        calculated_tax = round(igst_val + cgst_val + sgst_val + cess_val, 2)
        if direct_itc != 0.0:
            total_tax = direct_itc
        else:
            total_tax = calculated_tax
            
        total_inv_val = round(taxable_val + total_tax, 2)
        
        rec = StandardRecord(
            original_row_num=row_num,
            gstin=gstin,
            vendor_name=vendor_name,
            original_invoice_number=orig_inv,
            norm_invoice_number=norm_inv,
            invoice_date=d_obj,
            invoice_date_str=d_str,
            doc_type=doc_type,
            taxable_value=taxable_val,
            igst=igst_val,
            cgst=cgst_val,
            sgst=sgst_val,
            cess=cess_val,
            total_tax=total_tax,
            total_invoice_value=total_inv_val,
            source=source,
            raw_data={str(k): str(v) for k, v in row.to_dict().items() if not pd.isna(v)}
        )
        records.append(rec)

    return (records, used_mapping, errors)
