from typing import Dict, List, Any, Optional

COLUMN_PATTERNS = {
    "gstin": [
        "gstin of supplier", "supplier gstin", "gstin/uin", "gstin", 
        "vendor gstin", "party gstin", "gstin of vendor", "ctin", "supplier_gstin"
    ],
    "vendor_name": [
        "supplier name", "vendor name", "trade/legal name", "trade name", 
        "legal name", "party name", "name", "trdnm"
    ],
    "invoice_number": [
        "invoice number", "supplier invoice number", "invoice no.", "invoice no", 
        "invoice #", "bill number", "bill no", "document number", "document no", 
        "invoice id", "inv no", "inv_no", "inv_num", "inum"
    ],
    "invoice_date": [
        "invoice date", "date of invoice", "invoice dt", "bill date", 
        "document date", "inv date", "doc date", "date", "idt"
    ],
    "doc_type": [
        "document type", "doc type", "invoice type", "type", "typ"
    ],
    "itc_total": [
        "total itc", "itc amount", "itc", "total tax", "tax amount", "total tax amount", "itc_amount"
    ],
    "taxable_value": [
        "taxable value (₹)", "taxable value", "taxable val", "taxable amount", "taxable amt", "taxable", "txval"
    ],
    "igst": [
        "integrated tax (igst ₹)", "integrated tax", "igst", "igst (₹)", "igst_amount"
    ],
    "cgst": [
        "central tax (cgst ₹)", "central tax", "cgst", "cgst (₹)", "cgst_amount"
    ],
    "sgst": [
        "state tax (sgst ₹)", "state tax", "sgst", "sgst/utgst", "state tax (sgst ₹)", "sgst_amount"
    ],
    "cess": [
        "cess (₹)", "cess", "cess amount", "cess_amount"
    ],
}

def auto_detect_column_mapping(df_columns: List[str]) -> Dict[str, Optional[str]]:
    """
    Auto-detects mapping from raw Excel dataframe columns to standardized model fields.
    Guarantees official template headers match automatically.
    """
    mapping: Dict[str, Optional[str]] = {field: None for field in COLUMN_PATTERNS.keys()}
    
    col_clean_map = {col: str(col).strip().lower() for col in df_columns}
    
    for field, patterns in COLUMN_PATTERNS.items():
        for pattern in patterns:
            for raw_col, clean_col in col_clean_map.items():
                if clean_col == pattern or pattern in clean_col:
                    mapping[field] = raw_col
                    break
            if mapping[field] is not None:
                break
                
    return mapping
