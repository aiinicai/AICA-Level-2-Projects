import json
from typing import List, Tuple, Dict, Any
from backend.app.schemas.reconciliation import StandardRecord, SourceType
from backend.app.services.cleaner import (
    clean_gstin, clean_invoice_number, clean_amount, parse_date, clean_doc_type
)

def parse_gstr2b_json(json_content_or_dict: Any) -> Tuple[List[StandardRecord], List[str]]:
    """
    Parses GSTR-2B JSON downloaded from GST Portal.
    Extracts B2B, B2BA, CDNR, CDNRA items into StandardRecord models.
    """
    errors: List[str] = []
    records: List[StandardRecord] = []
    
    if isinstance(json_content_or_dict, (str, bytes)):
        try:
            data = json.loads(json_content_or_dict)
        except Exception as e:
            errors.append(f"Invalid GSTR-2B JSON structure: {str(e)}")
            return ([], errors)
    else:
        data = json_content_or_dict

    docdata = data.get("docdata", data)
    row_counter = 1
    
    # 1. B2B Invoices
    b2b_list = docdata.get("b2b", [])
    for supplier in b2b_list:
        gstin = clean_gstin(supplier.get("ctin"))
        trade_name = supplier.get("trdnm", supplier.get("tradeName", "Unknown Vendor"))
        
        inv_list = supplier.get("inv", [])
        for inv in inv_list:
            orig_inv, norm_inv = clean_invoice_number(inv.get("inum", inv.get("inv_no")))
            d_obj, d_str = parse_date(inv.get("idt", inv.get("inv_date")))
            val = clean_amount(inv.get("val", inv.get("inv_val")))
            
            # Tax rates array
            items = inv.get("items", [])
            igst = sum(clean_amount(it.get("igst")) for it in items) if items else clean_amount(inv.get("igst"))
            cgst = sum(clean_amount(it.get("cgst")) for it in items) if items else clean_amount(inv.get("cgst"))
            sgst = sum(clean_amount(it.get("sgst")) for it in items) if items else clean_amount(inv.get("sgst"))
            cess = sum(clean_amount(it.get("cess")) for it in items) if items else clean_amount(inv.get("cess"))
            taxable = sum(clean_amount(it.get("txval")) for it in items) if items else clean_amount(inv.get("txval"))
            
            total_tax = round(igst + cgst + sgst + cess, 2)
            
            rec = StandardRecord(
                original_row_num=row_counter,
                gstin=gstin,
                vendor_name=trade_name,
                original_invoice_number=orig_inv,
                norm_invoice_number=norm_inv,
                invoice_date=d_obj,
                invoice_date_str=d_str,
                doc_type=clean_doc_type(inv.get("typ", "INV")),
                taxable_value=taxable,
                igst=igst,
                cgst=cgst,
                sgst=sgst,
                cess=cess,
                total_tax=total_tax,
                total_invoice_value=val or round(taxable + total_tax, 2),
                source=SourceType.GSTR2B,
                raw_data=inv
            )
            records.append(rec)
            row_counter += 1

    return (records, errors)
