import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NAVY_FILL = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
REGULAR_FONT = Font(name="Calibri", size=10)
THIN_BORDER = Border(
    left=Side(style="thin", color="CBD5E1"),
    right=Side(style="thin", color="CBD5E1"),
    top=Side(style="thin", color="CBD5E1"),
    bottom=Side(style="thin", color="CBD5E1")
)

def create_purchase_register_template(filepath: str):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Purchase Register"
    
    headers = [
        "GSTIN of Supplier", "Supplier Name", "Invoice Number", "Invoice Date", 
        "Document Type", "Taxable Value (₹)", "Integrated Tax (IGST ₹)", 
        "Central Tax (CGST ₹)", "State Tax (SGST ₹)", "Cess (₹)"
    ]
    
    ws.append(headers)
    
    sample_rows = [
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV/2025/001", "05/04/2025", "INV", 100000.00, 18000.00, 0.00, 0.00, 0.00],
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "INV/2025/002", "12/04/2025", "INV", 50000.00, 9000.00, 0.00, 0.00, 0.00],
        ["29ABCDE5678G2Z1", "Zenith Office Supplies", "Z-8942", "15/04/2025", "INV", 25000.00, 0.00, 2250.00, 2250.00, 0.00],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV-9901", "20/04/2025", "INV", 75000.00, 13500.00, 0.00, 0.00, 0.00],
        ["27AAACW1234F1Z5", "Acme Industrial Tools", "CN/2025/001", "25/04/2025", "CN", -10000.00, -1800.00, 0.00, 0.00, 0.00],
    ]
    
    for row in sample_rows:
        ws.append(row)
        
    _format_sheet(ws)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    wb.save(filepath)

def create_gstr2b_template(filepath: str):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "GSTR-2B"
    
    headers = [
        "GSTIN of Supplier", "Trade/Legal Name", "Invoice Number", "Invoice Date", 
        "Document Type", "Taxable Value (₹)", "Integrated Tax (IGST ₹)", 
        "Central Tax (CGST ₹)", "State Tax (SGST ₹)", "Cess (₹)"
    ]
    
    ws.append(headers)
    
    sample_rows = [
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV2025001", "05/04/2025", "INV", 100000.00, 18000.00, 0.00, 0.00, 0.00],
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "INV2025002", "12/04/2025", "INV", 50000.00, 9500.00, 0.00, 0.00, 0.00], # Tax diff sample
        ["29ABCDE5678G2Z1", "Zenith Office Supplies", "Z-8942", "15/04/2025", "INV", 25000.00, 0.00, 2250.00, 2250.00, 0.00],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "INV-9901-ALT", "20/04/2025", "INV", 75000.00, 13500.00, 0.00, 0.00, 0.00], # Inv diff sample
        ["33BBBCC9999M1Z2", "Apex Logistics Ltd", "APX-441", "28/04/2025", "INV", 40000.00, 7200.00, 0.00, 0.00, 0.00], # 2B Only sample
    ]
    
    for row in sample_rows:
        ws.append(row)
        
    _format_sheet(ws)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    wb.save(filepath)

def create_vendor_master_template(filepath: str):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Vendor Master"
    
    headers = ["Vendor GSTIN", "Vendor Legal Name", "Contact Person", "Email Address", "Phone Number"]
    ws.append(headers)
    
    sample_rows = [
        ["27AAACW1234F1Z5", "Acme Industrial Tools Pvt Ltd", "Rajesh Sharma", "rajesh@acmetools.com", "+91 9876543210"],
        ["29ABCDE5678G2Z1", "Zenith Office Supplies", "Priya Nair", "priya@zenithsupplies.in", "+91 9812345678"],
        ["27XYZPD9876K1Z9", "Global Tech Solutions", "Amit Patel", "amit@globaltech.com", "+91 9900112233"],
    ]
    
    for row in sample_rows:
        ws.append(row)
        
    _format_sheet(ws)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    wb.save(filepath)

def _format_sheet(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            cell.border = THIN_BORDER
            if cell.row == 1:
                cell.fill = NAVY_FILL
                cell.font = HEADER_FONT
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            else:
                cell.font = REGULAR_FONT
                if isinstance(cell.value, (int, float)):
                    cell.number_format = "₹#,##0.00"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")
            
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
                
        ws.column_dimensions[col_letter].width = max(max_len + 4, 15)
