import re
from datetime import datetime, date
from typing import Optional, Tuple, Any
import pandas as pd

GSTIN_REGEX = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$")

def clean_gstin(gstin_val: Any) -> str:
    """
    Cleans and standardises GSTIN strings.
    - Strips whitespace
    - Converts to uppercase
    - Returns cleaned GSTIN string
    """
    if pd.isna(gstin_val) or gstin_val is None:
        return ""
    gstin_str = str(gstin_val).strip().upper()
    # Remove any stray internal spaces or non-alphanumeric characters
    gstin_str = re.sub(r"[^A-Z0-9]", "", gstin_str)
    return gstin_str

def validate_gstin(gstin_str: str) -> bool:
    """
    Validates standard 15-character GSTIN format.
    """
    if len(gstin_str) != 15:
        return False
    return bool(GSTIN_REGEX.match(gstin_str))

def clean_invoice_number(inv_val: Any) -> Tuple[str, str]:
    """
    Cleans invoice number and produces (original_invoice_number, norm_invoice_number).
    - original_invoice_number: Cleaned display string (trimmed).
    - norm_invoice_number: Normalized string stripped of special chars (/ - _ space # .) for matching.
    """
    if pd.isna(inv_val) or inv_val is None:
        return ("", "")
    
    orig_str = str(inv_val).strip()
    if orig_str.endswith(".0"):  # Handle Excel auto-float conversion like 1001.0 -> "1001"
        orig_str = orig_str[:-2]
        
    upper_str = orig_str.upper()
    # Remove special separators like / - _ . # space
    norm_str = re.sub(r"[^A-Z0-9]", "", upper_str)
    # Strip leading zeros if numeric part exists (e.g., 00123 -> 123) while keeping non-empty
    norm_str = norm_str.lstrip("0") or norm_str
    
    return (orig_str, norm_str)

def clean_amount(val: Any) -> float:
    """
    Converts input amount to clean rounded float.
    Handles strings with commas, nulls, negative brackets e.g. '(1,000)' -> -1000.0.
    """
    if pd.isna(val) or val is None:
        return 0.0
    
    val_str = str(val).strip()
    if not val_str:
        return 0.0
    
    # Handle negative accounting bracket format like (100.00)
    is_negative = False
    if val_str.startswith("(") and val_str.endswith(")"):
        is_negative = True
        val_str = val_str[1:-1]
        
    # Remove currency symbols and commas
    cleaned_str = re.sub(r"[^\d.-]", "", val_str)
    if not cleaned_str or cleaned_str == "-":
        return 0.0
    
    try:
        amount = float(cleaned_str)
        if is_negative:
            amount = -amount
        return round(amount, 2)
    except ValueError:
        return 0.0

def parse_date(val: Any) -> Tuple[Optional[date], str]:
    """
    Parses ambiguous date formats into (date_object, iso_string).
    """
    if pd.isna(val) or val is None or str(val).strip() in ("", "NaT", "nan", "None"):
        return (None, "")
    
    # If already a Python date or datetime
    if isinstance(val, (datetime, date)):
        if isinstance(val, datetime):
            d = val.date()
        else:
            d = val
        return (d, d.isoformat())
    
    # If Pandas Timestamp
    if isinstance(val, pd.Timestamp):
        d = val.date()
        return (d, d.isoformat())
        
    val_str = str(val).strip()
    
    # Handle Excel float dates
    if val_str.replace(".", "", 1).isdigit() and "." not in val_str:
        try:
            # Serial date offset from 1899-12-30
            excel_serial = float(val_str)
            if 30000 <= excel_serial <= 70000:
                dt = pd.to_datetime(excel_serial, unit='D', origin='1899-12-30')
                d = dt.date()
                return (d, d.isoformat())
        except Exception:
            pass
            
    # Try various date formats
    date_formats = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%d.%m.%Y",
        "%Y/%m/%d",
        "%d-%b-%Y",
        "%d-%b-%y",
        "%d %b %Y",
        "%Y-%m-%dT%H:%M:%S",
    ]
    
    for fmt in date_formats:
        try:
            dt = datetime.strptime(val_str, fmt)
            d = dt.date()
            return (d, d.isoformat())
        except ValueError:
            continue
            
    # Fallback to pandas flexible parser
    try:
        dt = pd.to_datetime(val_str, dayfirst=True)
        if not pd.isna(dt):
            d = dt.date()
            return (d, d.isoformat())
    except Exception:
        pass
        
    return (None, val_str)

def clean_doc_type(val: Any) -> str:
    """
    Standardises document type to INV, CN, DN, AMD.
    Avoids aggressive single-letter prefixes (e.g. COMMERCIAL INVOICE should remain INV).
    """
    if pd.isna(val) or val is None:
        return "INV"
    
    s = str(val).strip().upper()
    if not s or s in ("INV", "INVOICE", "B2B", "TAX INVOICE", "REGULAR", "COMMERCIAL INVOICE"):
        return "INV"
        
    if "CREDIT NOTE" in s or "CREDIT" in s or "CR NOTE" in s or "C.N" in s or s == "CN":
        return "CN"
    elif "DEBIT NOTE" in s or "DEBIT" in s or "DR NOTE" in s or "D.N" in s or s == "DN":
        return "DN"
    elif "AMENDMENT" in s or "AMEND" in s or "A.M.D" in s or s == "AMD":
        return "AMD"
    else:
        return "INV"
