import io
import json
import uuid
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, responses
from sqlalchemy.orm import Session
from pydantic import BaseModel

from backend.app.database.session import get_db
from backend.app.models.domain import (
    ReconciliationJobModel, ReconciliationResultModel, ClientModel, ReconciliationRuleModel, AuditLogModel
)
from backend.app.schemas.reconciliation import (
    StandardRecord, SourceType, MatchResult, MatchStatus, ReconciliationRuleConfig, SummaryKPI
)
from backend.app.services.excel_parser import parse_excel_to_standard_records
from backend.app.services.json_parser import parse_gstr2b_json
from backend.app.reconciliation.engine import ReconciliationEngine
from backend.app.services.excel_exporter import export_reconciliation_report

router = APIRouter(prefix="/reconciliation", tags=["Reconciliation"])

class ManualMatchRequest(BaseModel):
    result_id: str
    action: str  # "ACCEPT", "REJECT", "MANUAL_PAIR"
    target_2b_id: Optional[str] = None
    reason: str
    user_name: str = "Tax Auditor"

class ClearDataRequest(BaseModel):
    client_id: Optional[str] = None
    clear_all: bool = False

@router.post("/run")
async def run_reconciliation_job(
    client_id: str = Form(...),
    financial_year: str = Form("2026-27"),
    tax_period: str = Form("April 2026"),
    books_file: UploadFile = File(...),
    gstr2b_file: UploadFile = File(...),
    books_mapping_json: Optional[str] = Form(None),
    gstr2b_mapping_json: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    client = db.query(ClientModel).filter(ClientModel.id == client_id).first()
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    rule_model = db.query(ReconciliationRuleModel).filter(ReconciliationRuleModel.client_id == client_id).first()
    config = ReconciliationRuleConfig()
    if rule_model:
        config = ReconciliationRuleConfig(
            date_tolerance_days=rule_model.date_tolerance_days,
            tax_tolerance_amount=rule_model.tax_tolerance_amount,
            fuzzy_similarity_threshold=rule_model.fuzzy_similarity_threshold,
            ai_confidence_threshold=rule_model.ai_confidence_threshold,
            enable_ai_advisory=rule_model.enable_ai_advisory,
            match_cn_dn_separately=rule_model.match_cn_dn_separately
        )

    b_map = json.loads(books_mapping_json) if books_mapping_json else None
    g_map = json.loads(gstr2b_mapping_json) if gstr2b_mapping_json else None

    # Parse Books file
    b_contents = await books_file.read()
    b_records, _, b_err = parse_excel_to_standard_records(io.BytesIO(b_contents), SourceType.BOOKS, b_map)
    if b_err:
        raise HTTPException(status_code=400, detail=f"Books file parsing error: {', '.join(b_err)}")

    # Parse 2B file (Excel or JSON)
    g_contents = await gstr2b_file.read()
    if gstr2b_file.filename.lower().endswith(".json"):
        g_records, g_err = parse_gstr2b_json(g_contents)
    else:
        g_records, _, g_err = parse_excel_to_standard_records(io.BytesIO(g_contents), SourceType.GSTR2B, g_map)
    if g_err:
        raise HTTPException(status_code=400, detail=f"GSTR-2B file parsing error: {', '.join(g_err)}")

    # Assign IDs
    for idx, r in enumerate(b_records):
        r.id = f"B-{idx+1}"
    for idx, r in enumerate(g_records):
        r.id = f"G-{idx+1}"

    # Execute Reconciliation Engine
    engine = ReconciliationEngine(config)
    job_id = str(uuid.uuid4())
    results, kpis = engine.run(job_id, b_records, g_records)

    # Save to database
    job_db = ReconciliationJobModel(
        id=job_id,
        client_id=client_id,
        tax_period=tax_period,
        financial_year=financial_year or client.financial_year,
        status="COMPLETED",
        total_books_count=kpis.total_books_invoices,
        total_2b_count=kpis.total_2b_invoices,
        books_itc=kpis.books_itc,
        gstr2b_itc=kpis.gstr2b_itc,
        matched_itc=kpis.matched_itc,
        potential_risk_itc=kpis.potential_itc_at_risk,
        kpis_json=kpis.model_dump()
    )
    db.add(job_db)

    for r in results:
        res_db = ReconciliationResultModel(
            id=r.id or str(uuid.uuid4()),
            job_id=job_id,
            match_status=r.match_status.value if hasattr(r.match_status, 'value') else str(r.match_status),
            match_level=r.match_level,
            match_score=r.match_score,
            confidence_score=r.confidence_score,
            gstin_match_status=r.gstin_match_status,
            inv_match_status=r.inv_match_status,
            books_record_json=r.books_record.model_dump(mode='json') if r.books_record else None,
            gstr2b_record_json=r.gstr2b_record.model_dump(mode='json') if r.gstr2b_record else None,
            taxable_diff=r.taxable_diff,
            total_tax_diff=r.total_tax_diff,
            date_diff_days=r.date_diff_days,
            match_notes=r.match_notes,
            ai_reason=r.ai_reason
        )
        db.add(res_db)

    # Add initial audit log
    audit_init = AuditLogModel(
        job_id=job_id,
        user_name="System Engine",
        action_type="RECONCILIATION_RUN",
        previous_status="NEW",
        new_status="COMPLETED",
        reason=f"Ingested {len(b_records)} Books and {len(g_records)} GSTR-2B records."
    )
    db.add(audit_init)
    db.commit()

    return {
        "job_id": job_id,
        "status": "COMPLETED",
        "kpis": kpis
    }

@router.get("/jobs", response_model=List[Dict[str, Any]])
def list_jobs(client_id: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(ReconciliationJobModel)
    if client_id:
        query = query.filter(ReconciliationJobModel.client_id == client_id)
    jobs = query.order_by(ReconciliationJobModel.created_at.desc()).all()
    
    return [
        {
            "job_id": j.id,
            "client_id": j.client_id,
            "tax_period": j.tax_period,
            "financial_year": j.financial_year,
            "status": j.status,
            "created_at": j.created_at.isoformat() if j.created_at else "",
            "total_books_count": j.total_books_count,
            "total_2b_count": j.total_2b_count,
            "kpis": j.kpis_json
        }
        for j in jobs
    ]

from sqlalchemy import or_

@router.get("/jobs/{job_id}/results")
def get_job_results(
    job_id: str,
    status_filter: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    vendor_filter: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    job = db.query(ReconciliationJobModel).filter(ReconciliationJobModel.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    results_db = db.query(ReconciliationResultModel).filter(ReconciliationResultModel.job_id == job_id).all()
    output = []

    for r in results_db:
        b_rec = r.books_record_json or {}
        g_rec = r.gstr2b_record_json or {}
        st_upper = str(r.match_status).upper()

        # Status Filter Logic
        if status_filter:
            sf_upper = status_filter.upper().strip()
            if sf_upper == "MATCHED":
                # EXACT MATCH ONLY (Status is MATCHED or INVOICE NUMBER MATCH - GSTIN NOT AVAILABLE, no DIFFERENCE in status)
                if "DIFFERENCE" in st_upper or st_upper not in ("MATCHED", "INVOICE NUMBER MATCH — GSTIN NOT AVAILABLE", "INVOICE NUMBER MATCH - GSTIN NOT AVAILABLE"):
                    continue
            elif "ITC" in sf_upper or "TAX" in sf_upper or "DIFF" in sf_upper:
                # ITC TAX VARIANCE ONLY (Status MUST contain ITC DIFFERENCE / TAX DIFFERENCE / DATE DIFFERENCE, and MUST NOT contain BOOKS / 2B ONLY / DUPLICATE)
                if "BOOKS" in st_upper or "2B ONLY" in st_upper or "DUPLICATE" in st_upper:
                    continue
                if "DIFFERENCE" not in st_upper and "VARIANCE" not in st_upper:
                    continue
            elif sf_upper == "BOOKS ONLY":
                if st_upper != "BOOKS ONLY":
                    continue
            elif sf_upper == "2B ONLY":
                if st_upper != "2B ONLY":
                    continue
            elif "PROBABLE" in sf_upper:
                if "PROBABLE" not in st_upper:
                    continue
            elif "DUPLICATE" in sf_upper:
                if "DUPLICATE" not in st_upper:
                    continue
            else:
                if sf_upper not in st_upper:
                    continue

        # Search filter
        if search:
            s_lower = search.lower()
            b_inv = str(b_rec.get("original_invoice_number", "")).lower()
            g_inv = str(g_rec.get("original_invoice_number", "")).lower()
            b_vend = str(b_rec.get("vendor_name", "")).lower()
            g_vend = str(g_rec.get("vendor_name", "")).lower()
            b_gstin = str(b_rec.get("gstin", "")).lower()
            g_gstin = str(g_rec.get("gstin", "")).lower()

            if not (s_lower in b_inv or s_lower in g_inv or s_lower in b_vend or s_lower in g_vend or s_lower in b_gstin or s_lower in g_gstin):
                continue

        # Vendor filter
        if vendor_filter:
            v_lower = vendor_filter.lower()
            b_vend = str(b_rec.get("vendor_name", "")).lower()
            g_vend = str(g_rec.get("vendor_name", "")).lower()
            b_gstin = str(b_rec.get("gstin", "")).lower()
            g_gstin = str(g_rec.get("gstin", "")).lower()

            if not (v_lower in b_vend or v_lower in g_vend or v_lower in b_gstin or v_lower in g_gstin):
                continue

        # Determine GSTIN & Inv match indicators if not directly set
        gstin_match = r.gstin_match_status or ("MATCHED" if b_rec.get("gstin") and g_rec.get("gstin") and b_rec.get("gstin") == g_rec.get("gstin") else ("NOT AVAILABLE" if not b_rec.get("gstin") or not g_rec.get("gstin") else "MISMATCH"))
        inv_match = r.inv_match_status or ("MATCHED" if b_rec.get("norm_invoice_number") and g_rec.get("norm_invoice_number") and b_rec.get("norm_invoice_number") == g_rec.get("norm_invoice_number") else "UNMATCHED")
        score = r.match_score if r.match_score is not None else (100 if "MATCHED" in r.match_status else 0)

        output.append({
            "id": r.id,
            "match_status": r.match_status,
            "match_level": r.match_level,
            "match_score": score,
            "confidence_score": r.confidence_score,
            "gstin_match_status": gstin_match,
            "inv_match_status": inv_match,
            "books_record": b_rec,
            "gstr2b_record": g_rec,
            "taxable_diff": r.taxable_diff,
            "total_tax_diff": r.total_tax_diff,
            "date_diff_days": r.date_diff_days,
            "match_notes": r.match_notes,
            "is_manual_override": r.is_manual_override,
            "ai_reason": r.ai_reason
        })

    return {
        "job_id": job_id,
        "kpis": job.kpis_json,
        "total_results": len(output),
        "results": output
    }

@router.post("/manual-match")
def manual_match_override(req: ManualMatchRequest, db: Session = Depends(get_db)):
    res_db = db.query(ReconciliationResultModel).filter(ReconciliationResultModel.id == req.result_id).first()
    if not res_db:
        raise HTTPException(status_code=404, detail="Result record not found")

    prev_status = res_db.match_status
    if req.action == "ACCEPT":
        new_status = MatchStatus.MATCHED.value
        res_db.match_status = new_status
        res_db.is_manual_override = True
        res_db.match_notes += f" | Manually accepted by {req.user_name}: {req.reason}"
    elif req.action == "REJECT":
        new_status = MatchStatus.REVIEW_REQUIRED.value
        res_db.match_status = new_status
        res_db.is_manual_override = True
        res_db.match_notes += f" | Rejected by {req.user_name}: {req.reason}"
    else:
        new_status = MatchStatus.MATCHED.value
        res_db.match_status = new_status
        res_db.is_manual_override = True

    # Audit log entry
    log = AuditLogModel(
        job_id=res_db.job_id,
        result_id=res_db.id,
        user_name=req.user_name,
        action_type=f"MANUAL_{req.action}",
        previous_status=prev_status,
        new_status=new_status,
        reason=req.reason
    )
    db.add(log)
    db.commit()

    return {"status": "SUCCESS", "new_status": new_status}

@router.post("/clear-data")
def clear_reconciliation_data(req: ClearDataRequest, db: Session = Depends(get_db)):
    if req.clear_all or not req.client_id:
        db.query(AuditLogModel).delete()
        db.query(ReconciliationResultModel).delete()
        db.query(ReconciliationJobModel).delete()
        db.commit()
        return {"status": "SUCCESS", "message": "All reconciliation data cleared successfully."}
    else:
        jobs = db.query(ReconciliationJobModel).filter(ReconciliationJobModel.client_id == req.client_id).all()
        job_ids = [j.id for j in jobs]
        if job_ids:
            db.query(AuditLogModel).filter(AuditLogModel.job_id.in_(job_ids)).delete(synchronize_session=False)
            db.query(ReconciliationResultModel).filter(ReconciliationResultModel.job_id.in_(job_ids)).delete(synchronize_session=False)
            db.query(ReconciliationJobModel).filter(ReconciliationJobModel.client_id == req.client_id).delete(synchronize_session=False)
            db.commit()
        return {"status": "SUCCESS", "message": "Client reconciliation data cleared successfully."}

@router.get("/jobs/{job_id}/vendor-summary")
def get_vendor_summary(job_id: str, db: Session = Depends(get_db)):
    results_db = db.query(ReconciliationResultModel).filter(ReconciliationResultModel.job_id == job_id).all()
    vendors: Dict[str, Dict[str, Any]] = {}

    for r in results_db:
        b = r.books_record_json or {}
        g = r.gstr2b_record_json or {}
        gstin = b.get("gstin") or g.get("gstin") or "UNKNOWN"
        name = b.get("vendor_name") or g.get("vendor_name") or "UNKNOWN"

        if gstin not in vendors:
            vendors[gstin] = {
                "gstin": gstin, "vendor_name": name, "total_records": 0,
                "matched": 0, "probable": 0, "tax_diff": 0, "books_only": 0, "gstr2b_only": 0,
                "books_itc": 0.0, "gstr2b_itc": 0.0, "variance": 0.0
            }

        v = vendors[gstin]
        v["total_records"] += 1
        b_tax = float(b.get("total_tax", 0.0))
        g_tax = float(g.get("total_tax", 0.0))
        v["books_itc"] += b_tax
        v["gstr2b_itc"] += g_tax

        st = r.match_status
        if st in (MatchStatus.MATCHED.value, MatchStatus.INV_NO_MATCH_NO_GSTIN.value):
            v["matched"] += 1
        elif st in (MatchStatus.MATCHED_DATE_DIFF.value, MatchStatus.MATCHED_TAX_DIFF.value, MatchStatus.MATCHED_DATE_TAX_DIFF.value):
            v["tax_diff"] += 1
        elif st == MatchStatus.PROBABLE_MATCH.value:
            v["probable"] += 1
        elif st == MatchStatus.BOOKS_ONLY.value:
            v["books_only"] += 1
        elif st == MatchStatus.GSTR2B_ONLY.value:
            v["gstr2b_only"] += 1

    for v in vendors.values():
        v["books_itc"] = round(v["books_itc"], 2)
        v["gstr2b_itc"] = round(v["gstr2b_itc"], 2)
        v["variance"] = round(v["books_itc"] - v["gstr2b_itc"], 2)

    return list(vendors.values())

@router.get("/jobs/{job_id}/export-excel")
def download_excel_report(job_id: str, db: Session = Depends(get_db)):
    job = db.query(ReconciliationJobModel).filter(ReconciliationJobModel.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    client = db.query(ClientModel).filter(ClientModel.id == job.client_id).first()
    results_db = db.query(ReconciliationResultModel).filter(ReconciliationResultModel.job_id == job_id).all()
    logs_db = db.query(AuditLogModel).filter(AuditLogModel.job_id == job_id).all()

    # Reconstruct MatchResult models for exporter
    match_results = []
    for r in results_db:
        b_rec = StandardRecord(**r.books_record_json) if r.books_record_json else None
        g_rec = StandardRecord(**r.gstr2b_record_json) if r.gstr2b_record_json else None

        match_results.append(MatchResult(
            id=r.id,
            job_id=r.job_id,
            books_record=b_rec,
            gstr2b_record=g_rec,
            match_status=MatchStatus(r.match_status) if r.match_status in MatchStatus._value2member_map_ else MatchStatus.REVIEW_REQUIRED,
            match_level=r.match_level,
            confidence_score=r.confidence_score,
            taxable_diff=r.taxable_diff,
            total_tax_diff=r.total_tax_diff,
            date_diff_days=r.date_diff_days,
            match_notes=r.match_notes or "",
            is_manual_override=r.is_manual_override,
            ai_reason=r.ai_reason
        ))

    kpis = SummaryKPI(**job.kpis_json) if job.kpis_json else SummaryKPI()
    client_info = {
        "client_name": client.client_name if client else "N/A",
        "gstin": client.gstin if client else "N/A",
        "fy": job.financial_year,
        "period": job.tax_period
    }
    audit_logs = [
        {
            "timestamp": l.action_timestamp.strftime("%Y-%m-%d %H:%M:%S") if l.action_timestamp else "",
            "user": l.user_name,
            "action": l.action_type,
            "invoice_id": l.result_id or "N/A",
            "previous_status": l.previous_status or "N/A",
            "new_status": l.new_status or "N/A",
            "reason": l.reason
        }
        for l in logs_db
    ]

    output_stream = io.BytesIO()
    export_reconciliation_report(output_stream, match_results, kpis, client_info, audit_logs)
    output_stream.seek(0)

    filename = f"GST_Reconciliation_Report_{client.gstin if client else 'GST'}_{job.tax_period}.xlsx"
    return responses.StreamingResponse(
        output_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@router.get("/jobs/{job_id}/audit-logs")
def get_audit_logs(job_id: str, db: Session = Depends(get_db)):
    logs = db.query(AuditLogModel).filter(AuditLogModel.job_id == job_id).order_by(AuditLogModel.action_timestamp.desc()).all()
    return [
        {
            "id": l.id,
            "timestamp": l.action_timestamp.strftime("%Y-%m-%d %H:%M:%S") if l.action_timestamp else "",
            "user": l.user_name,
            "action_type": l.action_type,
            "previous_status": l.previous_status,
            "new_status": l.new_status,
            "reason": l.reason
        }
        for l in logs
    ]
