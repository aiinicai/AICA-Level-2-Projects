import os
import io
import pandas as pd
from fastapi import APIRouter, UploadFile, File, HTTPException, responses
from typing import Dict, Any, Optional

from backend.app.services.mapper import auto_detect_column_mapping
from backend.app.services.template_generator import (
    create_purchase_register_template, create_gstr2b_template, create_vendor_master_template
)

router = APIRouter(prefix="/uploads", tags=["Uploads"])

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "data", "templates")
os.makedirs(TEMPLATES_DIR, exist_ok=True)

@router.post("/inspect")
async def inspect_upload_file(file: UploadFile = File(...)):
    """
    Reads header columns of uploaded file and returns auto-detected column mappings + preview rows.
    """
    contents = await file.read()
    filename = file.filename.lower()
    
    try:
        if filename.endswith(".xlsx") or filename.endswith(".xls"):
            df = pd.read_excel(io.BytesIO(contents), engine="openpyxl")
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format. Please upload .xlsx or .csv")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error reading file: {str(e)}")

    raw_columns = [str(c) for c in df.columns]
    mapping = auto_detect_column_mapping(raw_columns)
    
    # Clean preview data for frontend display
    preview_df = df.head(5).fillna("")
    preview_records = preview_df.to_dict(orient="records")
    
    return {
        "filename": file.filename,
        "total_rows": len(df),
        "columns": raw_columns,
        "auto_mapping": mapping,
        "preview_rows": preview_records
    }

@router.get("/templates/{template_name}")
def download_template(template_name: str):
    """
    Serves downloadable Excel templates (Purchase_Register_Template.xlsx, GSTR_2B_Template.xlsx, Vendor_Master_Template.xlsx).
    """
    file_path = os.path.join(TEMPLATES_DIR, template_name)
    
    if not os.path.exists(file_path):
        if template_name == "Purchase_Register_Template.xlsx":
            create_purchase_register_template(file_path)
        elif template_name == "GSTR_2B_Template.xlsx":
            create_gstr2b_template(file_path)
        elif template_name == "Vendor_Master_Template.xlsx":
            create_vendor_master_template(file_path)
        else:
            raise HTTPException(status_code=404, detail="Template not found")
            
    return responses.FileResponse(
        path=file_path,
        filename=template_name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
