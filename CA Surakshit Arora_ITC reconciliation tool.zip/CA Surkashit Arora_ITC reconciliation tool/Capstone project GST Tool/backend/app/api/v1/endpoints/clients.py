from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel

from backend.app.database.session import get_db, Base, engine
from backend.app.models.domain import ClientModel, ReconciliationRuleModel
from backend.app.schemas.reconciliation import ReconciliationRuleConfig

# Initialize tables
Base.metadata.create_all(bind=engine)

router = APIRouter(prefix="/clients", tags=["Clients"])

class ClientCreateSchema(BaseModel):
    client_name: str
    gstin: str
    pan: Optional[str] = None
    financial_year: str = "2026-27"

class ClientResponseSchema(BaseModel):
    id: str
    client_name: str
    gstin: str
    pan: Optional[str]
    financial_year: str

@router.get("", response_model=List[ClientResponseSchema])
def list_clients(db: Session = Depends(get_db)):
    clients = db.query(ClientModel).all()
    if not clients:
        # Seed default sample CA client if empty
        default_client = ClientModel(
            client_name="Acme Enterprises Ltd",
            gstin="27AAACW1234F1Z5",
            pan="AAACW1234F",
            financial_year="2026-27"
        )
        db.add(default_client)
        db.commit()
        db.refresh(default_client)
        
        rule = ReconciliationRuleModel(client_id=default_client.id)
        db.add(rule)
        db.commit()
        
        clients = [default_client]
    return clients

@router.post("", response_model=ClientResponseSchema)
def create_client(client_in: ClientCreateSchema, db: Session = Depends(get_db)):
    client = ClientModel(
        client_name=client_in.client_name,
        gstin=client_in.gstin.upper(),
        pan=client_in.pan.upper() if client_in.pan else None,
        financial_year=client_in.financial_year
    )
    db.add(client)
    db.commit()
    db.refresh(client)
    
    # Create default rule config
    rule = ReconciliationRuleModel(client_id=client.id)
    db.add(rule)
    db.commit()
    
    return client

@router.put("/{client_id}", response_model=ClientResponseSchema)
def update_client(client_id: str, client_in: ClientCreateSchema, db: Session = Depends(get_db)):
    client = db.query(ClientModel).filter(ClientModel.id == client_id).first()
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
        
    client.client_name = client_in.client_name
    client.gstin = client_in.gstin.upper()
    if client_in.pan: client.pan = client_in.pan.upper()
    client.financial_year = client_in.financial_year
    
    db.commit()
    db.refresh(client)
    return client

@router.delete("/{client_id}")
def delete_client(client_id: str, db: Session = Depends(get_db)):
    client = db.query(ClientModel).filter(ClientModel.id == client_id).first()
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
        
    db.delete(client)
    db.commit()
    return {"status": "SUCCESS", "message": f"Client {client.client_name} ({client.gstin}) removed cleanly."}

@router.get("/{client_id}/rules", response_model=ReconciliationRuleConfig)
def get_client_rules(client_id: str, db: Session = Depends(get_db)):
    rule = db.query(ReconciliationRuleModel).filter(ReconciliationRuleModel.client_id == client_id).first()
    if not rule:
        return ReconciliationRuleConfig()
    return ReconciliationRuleConfig(
        date_tolerance_days=rule.date_tolerance_days,
        tax_tolerance_amount=rule.tax_tolerance_amount,
        fuzzy_similarity_threshold=rule.fuzzy_similarity_threshold,
        ai_confidence_threshold=rule.ai_confidence_threshold,
        enable_ai_advisory=rule.enable_ai_advisory,
        match_cn_dn_separately=rule.match_cn_dn_separately
    )

@router.put("/{client_id}/rules", response_model=ReconciliationRuleConfig)
def update_client_rules(client_id: str, rule_in: ReconciliationRuleConfig, db: Session = Depends(get_db)):
    rule = db.query(ReconciliationRuleModel).filter(ReconciliationRuleModel.client_id == client_id).first()
    if not rule:
        rule = ReconciliationRuleModel(client_id=client_id)
        db.add(rule)
        
    rule.date_tolerance_days = rule_in.date_tolerance_days
    rule.tax_tolerance_amount = rule_in.tax_tolerance_amount
    rule.fuzzy_similarity_threshold = rule_in.fuzzy_similarity_threshold
    rule.ai_confidence_threshold = rule_in.ai_confidence_threshold
    rule.enable_ai_advisory = rule_in.enable_ai_advisory
    rule.match_cn_dn_separately = rule_in.match_cn_dn_separately
    
    db.commit()
    return rule_in
