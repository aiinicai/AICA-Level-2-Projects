import uuid
from typing import List, Dict, Tuple, Set, Optional, Any
from datetime import datetime, date
from rapidfuzz import fuzz

from backend.app.schemas.reconciliation import (
    StandardRecord, MatchResult, MatchStatus, ReconciliationRuleConfig, SummaryKPI, DocType
)
from backend.app.reconciliation.duplicate_detector import detect_duplicates

class ReconciliationEngine:
    def __init__(self, config: ReconciliationRuleConfig, ai_provider: Optional[Any] = None):
        self.config = config

    def run(
        self,
        job_id: str,
        books_records: List[StandardRecord],
        gstr2b_records: List[StandardRecord]
    ) -> Tuple[List[MatchResult], SummaryKPI]:
        """
        Executes the 1-to-1 Hierarchical GST Reconciliation Engine.
        """
        # Step 1: Flag secondary duplicates independently in Books and GSTR-2B
        # Primary 1st instance records remain clean (is_duplicate = False) to allow matching!
        books_records = detect_duplicates(books_records)
        gstr2b_records = detect_duplicates(gstr2b_records)

        consumed_books_ids: Set[str] = set()
        consumed_2b_ids: Set[str] = set()
        results: List[MatchResult] = []

        def create_result(
            b_rec: Optional[StandardRecord],
            g_rec: Optional[StandardRecord],
            status: MatchStatus,
            level: int,
            score: int,
            gstin_match: str,
            inv_match: str,
            notes: str
        ) -> MatchResult:
            taxable_diff = 0.0
            itc_diff = 0.0
            date_diff = None

            if b_rec and g_rec:
                taxable_diff = round(b_rec.taxable_value - g_rec.taxable_value, 2)
                itc_diff = round(b_rec.total_tax - g_rec.total_tax, 2)
                if b_rec.invoice_date and g_rec.invoice_date:
                    date_diff = abs((b_rec.invoice_date - g_rec.invoice_date).days)
            elif b_rec and not g_rec:
                taxable_diff = round(b_rec.taxable_value, 2)
                itc_diff = round(b_rec.total_tax, 2)
            elif g_rec and not b_rec:
                taxable_diff = round(-g_rec.taxable_value, 2)
                itc_diff = round(-g_rec.total_tax, 2)

            return MatchResult(
                id=str(uuid.uuid4()),
                job_id=job_id,
                books_record=b_rec,
                gstr2b_record=g_rec,
                match_status=status,
                match_level=level,
                match_score=score,
                confidence_score=round(score / 100.0, 2),
                gstin_match_status=gstin_match,
                inv_match_status=inv_match,
                taxable_diff=taxable_diff,
                total_tax_diff=itc_diff,
                date_diff_days=date_diff,
                match_notes=notes
            )

        def is_doc_compatible(b: StandardRecord, g: StandardRecord) -> bool:
            if not self.config.match_cn_dn_separately:
                return True
            return b.doc_type == g.doc_type

        # Index GSTR-2B records by norm_invoice_number & zero-stripped invoice numbers
        g2b_by_norm_inv: Dict[str, List[StandardRecord]] = {}
        g2b_by_stripped_inv: Dict[str, List[StandardRecord]] = {}

        for g in gstr2b_records:
            if g.norm_invoice_number:
                g2b_by_norm_inv.setdefault(g.norm_invoice_number, []).append(g)
                stripped = g.norm_invoice_number.lstrip("0")
                if stripped:
                    g2b_by_stripped_inv.setdefault(stripped, []).append(g)

        # =========================================================================
        # WATERFALL PASS 1: GSTIN + INVOICE NUMBER MATCHING
        # =========================================================================
        for b in books_records:
            if b.id in consumed_books_ids or not b.norm_invoice_number:
                continue

            candidates: List[StandardRecord] = []
            
            # Exact norm_inv match
            if b.norm_invoice_number in g2b_by_norm_inv:
                candidates.extend([g for g in g2b_by_norm_inv[b.norm_invoice_number] if g.id not in consumed_2b_ids])
                
            # Zero-stripped match (e.g. INV/001/26-27 vs INV-001-26-27)
            b_stripped = b.norm_invoice_number.lstrip("0")
            if b_stripped in g2b_by_stripped_inv:
                for g in g2b_by_stripped_inv[b_stripped]:
                    if g.id not in consumed_2b_ids and g not in candidates:
                        candidates.append(g)

            # Filter candidates matching GSTIN
            valid_candidates = []
            for g in candidates:
                if not is_doc_compatible(b, g):
                    continue
                if b.gstin and g.gstin and b.gstin == g.gstin:
                    valid_candidates.append(g)

            if not valid_candidates:
                continue

            def rank_candidate(g_cand: StandardRecord) -> Tuple[int, int, float]:
                d_diff = 999
                if b.invoice_date and g_cand.invoice_date:
                    d_diff = abs((b.invoice_date - g_cand.invoice_date).days)
                itc_diff = abs(b.total_tax - g_cand.total_tax)
                inv_exact = 0 if b.norm_invoice_number == g_cand.norm_invoice_number else 1
                return (inv_exact, d_diff, itc_diff)

            valid_candidates.sort(key=rank_candidate)
            best_g = valid_candidates[0]

            consumed_books_ids.add(b.id)
            consumed_2b_ids.add(best_g.id)

            date_diff = abs((b.invoice_date - best_g.invoice_date).days) if (b.invoice_date and best_g.invoice_date) else 0
            itc_diff = round(abs(b.total_tax - best_g.total_tax), 2)

            is_date_ok = date_diff <= self.config.date_tolerance_days
            is_itc_ok = itc_diff <= self.config.tax_tolerance_amount

            score = 80
            if is_date_ok: score += 10
            if is_itc_ok: score += 10

            if is_date_ok and is_itc_ok:
                status = MatchStatus.MATCHED
                notes = "GSTIN and Invoice Number matched. Date and ITC within tolerance."
            elif is_itc_ok and not is_date_ok:
                status = MatchStatus.MATCHED_DATE_DIFF
                notes = f"GSTIN & Invoice No matched; ITC matched. Date diff: {date_diff} days."
            elif is_date_ok and not is_itc_ok:
                status = MatchStatus.MATCHED_TAX_DIFF
                notes = f"GSTIN & Invoice No matched; Date matched. ITC variance: ₹{itc_diff:.2f}."
            else:
                status = MatchStatus.MATCHED_DATE_TAX_DIFF
                notes = f"GSTIN & Invoice No matched. Both Date ({date_diff}d) and ITC (₹{itc_diff:.2f}) differ."

            results.append(create_result(
                b, best_g, status, level=1, score=score, gstin_match="MATCHED", inv_match="MATCHED", notes=notes
            ))

        # =========================================================================
        # WATERFALL PASS 2: INVOICE NUMBER MATCH — GSTIN NOT AVAILABLE
        # =========================================================================
        for b in books_records:
            if b.id in consumed_books_ids or not b.norm_invoice_number:
                continue

            candidates = g2b_by_norm_inv.get(b.norm_invoice_number, [])
            no_gstin_cands = [
                g for g in candidates 
                if g.id not in consumed_2b_ids and is_doc_compatible(b, g) and (not b.gstin or not g.gstin)
            ]

            if no_gstin_cands:
                best_g = no_gstin_cands[0]
                consumed_books_ids.add(b.id)
                consumed_2b_ids.add(best_g.id)

                results.append(create_result(
                    b, best_g, MatchStatus.INV_NO_MATCH_NO_GSTIN, level=2, score=60,
                    gstin_match="NOT AVAILABLE", inv_match="MATCHED",
                    notes="Invoice number matched, but GSTIN was not available in one or both records."
                ))

        # =========================================================================
        # WATERFALL PASS 3: FUZZY INVOICE MATCH (PROBABLE MATCH)
        # =========================================================================
        effective_fuzzy_thresh = min(self.config.fuzzy_similarity_threshold, 0.70)

        for b in books_records:
            if b.id in consumed_books_ids or not b.norm_invoice_number:
                continue

            best_g: Optional[StandardRecord] = None
            best_ratio: float = 0.0

            for g in gstr2b_records:
                if g.id in consumed_2b_ids or not g.norm_invoice_number or not is_doc_compatible(b, g):
                    continue

                if b.gstin and g.gstin and b.gstin != g.gstin:
                    continue

                ratio = fuzz.ratio(b.norm_invoice_number, g.norm_invoice_number) / 100.0
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_g = g

            if best_g and best_ratio >= effective_fuzzy_thresh:
                consumed_books_ids.add(b.id)
                consumed_2b_ids.add(best_g.id)
                score = int(best_ratio * 80)

                results.append(create_result(
                    b, best_g, MatchStatus.PROBABLE_MATCH, level=3, score=score,
                    gstin_match="MATCHED" if b.gstin and best_g.gstin else "NOT AVAILABLE",
                    inv_match=f"FUZZY ({int(best_ratio*100)}%)",
                    notes=f"Probable match based on invoice similarity ({best_ratio:.0%}). Review required."
                ))

        # =========================================================================
        # WATERFALL PASS 4: UNMATCHED & DUPLICATE RECORDS
        # =========================================================================
        # Unmatched Books records
        for b in books_records:
            if b.id not in consumed_books_ids:
                status = MatchStatus.DUPLICATE_IN_BOOKS if b.is_duplicate else MatchStatus.BOOKS_ONLY
                if b.doc_type == DocType.CREDIT_NOTE:
                    status = MatchStatus.CREDIT_NOTE
                elif b.doc_type == DocType.DEBIT_NOTE:
                    status = MatchStatus.DEBIT_NOTE
                elif b.doc_type == DocType.AMENDMENT:
                    status = MatchStatus.AMENDMENT

                notes = "Duplicate entry in Purchase Register." if b.is_duplicate else "Transaction present in Purchase Register only."

                results.append(create_result(
                    b, None, status, level=4, score=0,
                    gstin_match="UNMATCHED", inv_match="UNMATCHED",
                    notes=notes
                ))

        # Unmatched GSTR-2B records
        for g in gstr2b_records:
            if g.id not in consumed_2b_ids:
                status = MatchStatus.DUPLICATE_IN_2B if g.is_duplicate else MatchStatus.GSTR2B_ONLY
                if g.doc_type == DocType.CREDIT_NOTE:
                    status = MatchStatus.CREDIT_NOTE
                elif g.doc_type == DocType.DEBIT_NOTE:
                    status = MatchStatus.DEBIT_NOTE
                elif g.doc_type == DocType.AMENDMENT:
                    status = MatchStatus.AMENDMENT

                notes = "Duplicate entry in GSTR-2B statement." if g.is_duplicate else "Transaction present in GSTR-2B only."

                results.append(create_result(
                    None, g, status, level=4, score=0,
                    gstin_match="UNMATCHED", inv_match="UNMATCHED",
                    notes=notes
                ))

        # Compute Summary KPIs
        kpis = self._calculate_kpis(books_records, gstr2b_records, results)
        return results, kpis

    def _calculate_kpis(
        self,
        books: List[StandardRecord],
        gstr2b: List[StandardRecord],
        results: List[MatchResult]
    ) -> SummaryKPI:
        kpi = SummaryKPI()
        kpi.total_books_invoices = len(books)
        kpi.total_2b_invoices = len(gstr2b)

        kpi.books_itc = round(sum(b.total_tax for b in books), 2)
        kpi.gstr2b_itc = round(sum(g.total_tax for g in gstr2b), 2)
        kpi.itc_difference = round(kpi.books_itc - kpi.gstr2b_itc, 2)

        matched_itc_accum = 0.0
        at_risk_accum = 0.0

        for res in results:
            st = res.match_status
            if st == MatchStatus.MATCHED:
                kpi.exact_matches += 1
                if res.books_record:
                    matched_itc_accum += res.books_record.total_tax
            elif st == MatchStatus.MATCHED_DATE_DIFF:
                kpi.matched_date_diff += 1
                if res.books_record:
                    matched_itc_accum += res.books_record.total_tax
            elif st == MatchStatus.MATCHED_TAX_DIFF:
                kpi.matched_tax_diff += 1
                if res.books_record:
                    at_risk_accum += abs(res.total_tax_diff)
            elif st == MatchStatus.MATCHED_DATE_TAX_DIFF:
                kpi.matched_date_tax_diff += 1
                if res.books_record:
                    at_risk_accum += abs(res.total_tax_diff)
            elif st == MatchStatus.INV_NO_MATCH_NO_GSTIN:
                kpi.inv_no_match_no_gstin += 1
                if res.books_record:
                    matched_itc_accum += res.books_record.total_tax
            elif st == MatchStatus.PROBABLE_MATCH:
                kpi.probable_matches += 1
                if res.books_record:
                    at_risk_accum += res.books_record.total_tax
            elif st == MatchStatus.BOOKS_ONLY:
                kpi.books_only += 1
                if res.books_record:
                    at_risk_accum += res.books_record.total_tax
            elif st == MatchStatus.GSTR2B_ONLY:
                kpi.gstr2b_only += 1
            elif st == MatchStatus.DUPLICATE_IN_BOOKS:
                kpi.duplicates_books += 1
                if res.books_record:
                    at_risk_accum += res.books_record.total_tax
            elif st == MatchStatus.DUPLICATE_IN_2B:
                kpi.duplicates_2b += 1
            elif st == MatchStatus.REVIEW_REQUIRED:
                kpi.review_required += 1
                if res.books_record:
                    at_risk_accum += res.books_record.total_tax
            elif st in (MatchStatus.CREDIT_NOTE, MatchStatus.DEBIT_NOTE, MatchStatus.AMENDMENT):
                kpi.credit_debit_notes += 1

        kpi.matched_itc = round(matched_itc_accum, 2)
        kpi.potential_itc_at_risk = round(at_risk_accum, 2)

        return kpi
