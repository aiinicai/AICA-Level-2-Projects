from typing import List
from collections import defaultdict
from backend.app.schemas.reconciliation import StandardRecord

def detect_duplicates(records: List[StandardRecord]) -> List[StandardRecord]:
    """
    Detects duplicate records within a single dataset (Books or GSTR-2B).
    Groups records by: (GSTIN, norm_invoice_number, invoice_date_str, taxable_value, total_tax)
    
    IMPORTANT:
    Only flags subsequent repeated instances (index 1 onwards) as duplicates.
    The 1st primary record (index 0) remains clean (is_duplicate = False) so it can 
    be matched with the corresponding invoice in the opposite dataset.
    """
    groups = defaultdict(list)
    
    for rec in records:
        # Ignore empty or ultra-short invoice numbers from duplicate grouping
        inv_key = rec.norm_invoice_number or ""
        if len(inv_key) < 2:
            continue

        key = (
            rec.gstin.strip().upper() if rec.gstin else "",
            inv_key,
            rec.invoice_date_str or "",
            round(rec.taxable_value, 2),
            round(rec.total_tax, 2)
        )
        groups[key].append(rec)
        
    group_counter = 1
    for key, rec_list in groups.items():
        if len(rec_list) > 1:
            group_id = f"DUP-GRP-{group_counter:04d}"
            group_counter += 1
            # Index 0 is the primary record -> remains is_duplicate = False
            # Index 1..N are secondary duplicates -> set is_duplicate = True
            for r in rec_list[1:]:
                r.is_duplicate = True
                r.duplicate_group_id = group_id
                
    return records
