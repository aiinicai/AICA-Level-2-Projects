import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, JSON, ForeignKey
from sqlalchemy.orm import relationship
from backend.app.database.session import Base

def generate_uuid():
    return str(uuid.uuid4())

def utc_now():
    return datetime.now(timezone.utc)

class ClientModel(Base):
    __tablename__ = "clients"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    client_name = Column(String, nullable=False)
    gstin = Column(String, nullable=False, index=True)
    pan = Column(String, nullable=True)
    financial_year = Column(String, default="2026-27")
    created_at = Column(DateTime, default=utc_now)
    
    jobs = relationship("ReconciliationJobModel", back_populates="client", cascade="all, delete-orphan")
    rules = relationship("ReconciliationRuleModel", back_populates="client", uselist=False, cascade="all, delete-orphan")

class ReconciliationRuleModel(Base):
    __tablename__ = "reconciliation_rules"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    client_id = Column(String, ForeignKey("clients.id"), nullable=False)
    date_tolerance_days = Column(Integer, default=3)
    tax_tolerance_amount = Column(Float, default=1.0)
    taxable_tolerance_amount = Column(Float, default=2.0)
    fuzzy_similarity_threshold = Column(Float, default=0.85)
    ai_confidence_threshold = Column(Float, default=0.80)
    enable_ai_advisory = Column(Boolean, default=True)
    match_cn_dn_separately = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=utc_now)
    
    client = relationship("ClientModel", back_populates="rules")

class ReconciliationJobModel(Base):
    __tablename__ = "reconciliation_jobs"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    client_id = Column(String, ForeignKey("clients.id"), nullable=False)
    tax_period = Column(String, nullable=False)
    financial_year = Column(String, default="2026-27")
    status = Column(String, default="COMPLETED")
    total_books_count = Column(Integer, default=0)
    total_2b_count = Column(Integer, default=0)
    books_itc = Column(Float, default=0.0)
    gstr2b_itc = Column(Float, default=0.0)
    matched_itc = Column(Float, default=0.0)
    potential_risk_itc = Column(Float, default=0.0)
    kpis_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=utc_now)
    
    client = relationship("ClientModel", back_populates="jobs")
    results = relationship("ReconciliationResultModel", back_populates="job", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLogModel", back_populates="job", cascade="all, delete-orphan")

class ReconciliationResultModel(Base):
    __tablename__ = "reconciliation_results"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    job_id = Column(String, ForeignKey("reconciliation_jobs.id"), nullable=False)
    match_status = Column(String, nullable=False, index=True)
    match_level = Column(Integer, nullable=False)
    match_score = Column(Integer, default=100)
    confidence_score = Column(Float, default=1.0)
    gstin_match_status = Column(String, default="MATCHED")
    inv_match_status = Column(String, default="MATCHED")
    
    books_record_json = Column(JSON, nullable=True)
    gstr2b_record_json = Column(JSON, nullable=True)
    
    taxable_diff = Column(Float, default=0.0)
    total_tax_diff = Column(Float, default=0.0)
    date_diff_days = Column(Integer, nullable=True)
    match_notes = Column(Text, default="")
    is_manual_override = Column(Boolean, default=False)
    ai_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=utc_now)
    
    job = relationship("ReconciliationJobModel", back_populates="results")
    audit_logs = relationship("AuditLogModel", back_populates="result", cascade="all, delete-orphan")

class AuditLogModel(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    job_id = Column(String, ForeignKey("reconciliation_jobs.id"), nullable=False)
    result_id = Column(String, ForeignKey("reconciliation_results.id"), nullable=True)
    user_name = Column(String, default="CA Staff")
    action_type = Column(String, nullable=False)
    previous_status = Column(String, nullable=True)
    new_status = Column(String, nullable=True)
    reason = Column(Text, nullable=False)
    action_timestamp = Column(DateTime, default=utc_now)
    
    job = relationship("ReconciliationJobModel", back_populates="audit_logs")
    result = relationship("ReconciliationResultModel", back_populates="audit_logs")
