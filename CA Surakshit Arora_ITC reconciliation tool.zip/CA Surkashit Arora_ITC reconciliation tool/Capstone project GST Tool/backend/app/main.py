from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.app.database.session import Base, engine
from backend.app.api.v1.endpoints.clients import router as clients_router
from backend.app.api.v1.endpoints.uploads import router as uploads_router
from backend.app.api.v1.endpoints.reconciliation import router as reco_router

# Initialize database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="GST Invoice Reconciliation Suite",
    description="Deterministic, Auditable GST Purchase Register vs GSTR-2B Reconciliation System for CA Firms.",
    version="1.0.0"
)

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(clients_router, prefix="/api/v1")
app.include_router(uploads_router, prefix="/api/v1")
app.include_router(reco_router, prefix="/api/v1")

@app.get("/api/v1/health")
def health_check():
    return {"status": "HEALTHY", "system": "GST Reconciliation Engine V1.0"}
