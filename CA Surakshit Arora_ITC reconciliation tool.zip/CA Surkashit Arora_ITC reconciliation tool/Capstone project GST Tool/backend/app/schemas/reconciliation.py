from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import date, datetime, timezone
from enum import Enum

class DocType(str, Enum):
    INVOICE = "INV"
    CREDIT_NOTE = "CN"
    DEBIT_NOTE = "DN"
    AMENDMENT = "AMD"

class SourceType(str, Enum):
    BOOKS = "BOOKS"
    GSTR2B = "GSTR2B"

class MatchStatus(str, Enum):
    MATCHED = "MATCHED"
    MATCHED_DATE_DIFF = "MATCHED — DATE DIFFERENCE"
    MATCHED_TAX_DIFF = "MATCHED — ITC DIFFERENCE"
    MATCHED_DATE_TAX_DIFF = "MATCHED — DATE & ITC DIFFERENCE"
    INV_NO_MATCH_NO_GSTIN = "INVOICE NUMBER MATCH — GSTIN NOT AVAILABLE"
    PROBABLE_MATCH = "PROBABLE MATCH"
    BOOKS_ONLY = "BOOKS ONLY"
    GSTR2B_ONLY = "2B ONLY"
    DUPLICATE_IN_BOOKS = "DUPLICATE IN BOOKS"
    DUPLICATE_IN_2B = "DUPLICATE IN 2B"
    CREDIT_NOTE = "CREDIT NOTE"
    DEBIT_NOTE = "DEBIT NOTE"
    AMENDMENT = "AMENDMENT"
    REVIEW_REQUIRED = "REVIEW REQUIRED"

class StandardRecord(BaseModel):
    id: Optional[str] = None
    original_row_num: int
    gstin: str
    vendor_name: str
    original_invoice_number: str
    norm_invoice_number: str
    invoice_date: Optional[date] = None
    invoice_date_str: str = ""
    doc_type: DocType = DocType.INVOICE
    taxable_value: float = 0.0
    igst: float = 0.0
    cgst: float = 0.0
    sgst: float = 0.0
    cess: float = 0.0
    total_tax: float = 0.0
    total_invoice_value: float = 0.0
    source: SourceType
    is_duplicate: bool = False
    duplicate_group_id: Optional[str] = None
    raw_data: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(from_attributes=True)

class ReconciliationRuleConfig(BaseModel):
    date_tolerance_days: int = Field(default=0, ge=0, le=30)  # Default 0 days
    tax_tolerance_amount: float = Field(default=1.0, ge=0.0)   # Default Rs 1.00 ITC tolerance
    fuzzy_similarity_threshold: float = Field(default=0.85, ge=0.5, le=1.0)
    ai_confidence_threshold: float = Field(default=0.80, ge=0.5, le=1.0)
    enable_ai_advisory: bool = True
    match_cn_dn_separately: bool = True

class MatchResult(BaseModel):
    id: Optional[str] = None
    job_id: str
    books_record: Optional[StandardRecord] = None
    gstr2b_record: Optional[StandardRecord] = None
    match_status: MatchStatus
    match_level: int
    match_score: int = 100
    confidence_score: float = 1.0
    gstin_match_status: str = "MATCHED"
    inv_match_status: str = "MATCHED"
    taxable_diff: float = 0.0
    total_tax_diff: float = 0.0
    date_diff_days: Optional[int] = None
    match_notes: str = ""
    is_manual_override: bool = False
    ai_reason: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(from_attributes=True)

class SummaryKPI(BaseModel):
    total_books_invoices: int = 0
    total_2b_invoices: int = 0
    exact_matches: int = 0
    matched_date_diff: int = 0
    matched_tax_diff: int = 0
    matched_date_tax_diff: int = 0
    inv_no_match_no_gstin: int = 0
    probable_matches: int = 0
    books_only: int = 0
    gstr2b_only: int = 0
    duplicates_books: int = 0
    duplicates_2b: int = 0
    review_required: int = 0
    credit_debit_notes: int = 0
    
    # Financial ITC metrics
    books_itc: float = 0.0
    gstr2b_itc: float = 0.0
    matched_itc: float = 0.0
    itc_difference: float = 0.0
    potential_itc_at_risk: float = 0.0
