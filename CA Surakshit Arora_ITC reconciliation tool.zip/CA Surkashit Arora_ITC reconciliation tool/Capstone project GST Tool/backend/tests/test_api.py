from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "HEALTHY"

def test_clients_endpoint():
    response = client.get("/api/v1/clients")
    assert response.status_code == 200
    clients = response.json()
    assert len(clients) > 0
    assert "gstin" in clients[0]

def test_templates_download_endpoint():
    response = client.get("/api/v1/uploads/templates/Purchase_Register_Template.xlsx")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
