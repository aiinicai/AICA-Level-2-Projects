import pytest
from datetime import date
from backend.app.schemas.reconciliation import (
    StandardRecord, SourceType, MatchStatus, ReconciliationRuleConfig, DocType
)
from backend.app.reconciliation.engine import ReconciliationEngine
from backend.app.reconciliation.duplicate_detector import detect_duplicates
from backend.app.services.cleaner import clean_invoice_number, clean_gstin, clean_amount

def test_data_cleaning_and_normalisation():
    # GSTIN
    assert clean_gstin(" 27aaacw1234f1z5 ") == "27AAACW1234F1Z5"
    assert clean_gstin("27-AAACW1234F1Z5") == "27AAACW1234F1Z5"
    
    # Invoice Number
    orig, norm = clean_invoice_number(" INV/001/25-26 ")
    assert orig == "INV/001/25-26"
    assert norm == "INV0012526"
    
    orig2, norm2 = clean_invoice_number("00123.0")
    assert orig2 == "00123"
    assert norm2 == "123"
    
    # Amounts
    assert clean_amount(" 1,50,000.50 ") == 150000.50
    assert clean_amount("(1,000.00)") == -1000.00
    assert clean_amount(None) == 0.0

def test_level1_exact_match():
    config = ReconciliationRuleConfig()
    engine = ReconciliationEngine(config)
    
    b_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV-001",
        norm_invoice_number="INV001",
        invoice_date=date(2025, 4, 10),
        doc_type=DocType.INVOICE,
        taxable_value=100000.0,
        igst=18000.0,
        total_tax=18000.0,
        total_invoice_value=118000.0,
        source=SourceType.BOOKS
    )
    
    g_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV/001",
        norm_invoice_number="INV001",
        invoice_date=date(2025, 4, 10),
        doc_type=DocType.INVOICE,
        taxable_value=100000.0,
        igst=18000.0,
        total_tax=18000.0,
        total_invoice_value=118000.0,
        source=SourceType.GSTR2B
    )
    
    results, kpi = engine.run("job-1", [b_rec], [g_rec])
    assert len(results) == 1
    assert results[0].match_status == MatchStatus.MATCHED
    assert kpi.exact_matches == 1

def test_level2_tax_difference():
    config = ReconciliationRuleConfig(tax_tolerance_amount=1.0)
    engine = ReconciliationEngine(config)
    
    b_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV-002",
        norm_invoice_number="INV002",
        invoice_date=date(2025, 4, 10),
        doc_type=DocType.INVOICE,
        taxable_value=100000.0,
        igst=18000.0,
        total_tax=18000.0,
        source=SourceType.BOOKS
    )
    
    g_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV-002",
        norm_invoice_number="INV002",
        invoice_date=date(2025, 4, 10),
        doc_type=DocType.INVOICE,
        taxable_value=100000.0,
        igst=18500.0,  # Tax variance of Rs 500
        total_tax=18500.0,
        source=SourceType.GSTR2B
    )
    
    results, kpi = engine.run("job-2", [b_rec], [g_rec])
    assert len(results) == 1
    assert results[0].match_status == MatchStatus.MATCHED_TAX_DIFF
    assert results[0].total_tax_diff == -500.0
    assert kpi.matched_tax_diff == 1

def test_level3_invoice_normalisation():
    config = ReconciliationRuleConfig()
    engine = ReconciliationEngine(config)
    
    b_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV/001/25-26",
        norm_invoice_number="INV0012526",
        invoice_date=date(2025, 4, 10),
        taxable_value=50000.0,
        total_tax=9000.0,
        source=SourceType.BOOKS
    )
    
    g_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV0012526",
        norm_invoice_number="INV0012526",
        invoice_date=date(2025, 4, 10),
        taxable_value=50000.0,
        total_tax=9000.0,
        source=SourceType.GSTR2B
    )
    
    results, kpi = engine.run("job-3", [b_rec], [g_rec])
    assert len(results) == 1
    assert results[0].match_status == MatchStatus.MATCHED

def test_level4_unmatched_records():
    config = ReconciliationRuleConfig()
    engine = ReconciliationEngine(config)
    
    b_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV-9999",
        norm_invoice_number="INV9999",
        taxable_value=75000.0,
        total_tax=13500.0,
        source=SourceType.BOOKS
    )
    
    g_rec = StandardRecord(
        original_row_num=2,
        gstin="27AAACW1234F1Z5",
        vendor_name="Vendor A",
        original_invoice_number="INV-8888",  # Diff invoice number
        norm_invoice_number="INV8888",
        taxable_value=75000.0,
        total_tax=13500.0,
        source=SourceType.GSTR2B
    )
    
    results, kpi = engine.run("job-4", [b_rec], [g_rec])
    assert len(results) == 2
    assert kpi.books_only == 1
    assert kpi.gstr2b_only == 1

def test_duplicate_detection():
    r1 = StandardRecord(
        original_row_num=2, gstin="27AAACW1234F1Z5", vendor_name="Vendor A",
        original_invoice_number="INV-101", norm_invoice_number="INV101",
        invoice_date_str="2025-04-10", taxable_value=10000.0, total_tax=1800.0,
        source=SourceType.BOOKS
    )
    r2 = StandardRecord(
        original_row_num=3, gstin="27AAACW1234F1Z5", vendor_name="Vendor A",
        original_invoice_number="INV-101", norm_invoice_number="INV101",
        invoice_date_str="2025-04-10", taxable_value=10000.0, total_tax=1800.0,
        source=SourceType.BOOKS
    )
    
    recs = detect_duplicates([r1, r2])
    assert recs[0].is_duplicate is True
    assert recs[1].is_duplicate is True
    assert recs[0].duplicate_group_id == recs[1].duplicate_group_id

def test_credit_note_separation():
    config = ReconciliationRuleConfig(match_cn_dn_separately=True)
    engine = ReconciliationEngine(config)
    
    b_rec = StandardRecord(
        original_row_num=2, gstin="27AAACW1234F1Z5", vendor_name="Vendor A",
        original_invoice_number="CN-001", norm_invoice_number="CN001",
        doc_type=DocType.CREDIT_NOTE, taxable_value=-10000.0, total_tax=-1800.0,
        source=SourceType.BOOKS
    )
    
    g_rec = StandardRecord(
        original_row_num=2, gstin="27AAACW1234F1Z5", vendor_name="Vendor A",
        original_invoice_number="CN-001", norm_invoice_number="CN001",
        doc_type=DocType.CREDIT_NOTE, taxable_value=-10000.0, total_tax=-1800.0,
        source=SourceType.GSTR2B
    )
    
    results, kpi = engine.run("job-cn", [b_rec], [g_rec])
    assert len(results) == 1
    assert results[0].match_status == MatchStatus.MATCHED
