import os
import pytest
import openpyxl

from backend.app.services.template_generator import (
    create_purchase_register_template,
    create_gstr2b_template,
    create_vendor_master_template
)
from backend.app.services.excel_parser import parse_excel_to_standard_records
from backend.app.schemas.reconciliation import SourceType, ReconciliationRuleConfig
from backend.app.reconciliation.engine import ReconciliationEngine
from backend.app.services.excel_exporter import export_reconciliation_report

def test_template_generation_and_end_to_end_reconciliation(tmp_path):
    pr_path = str(tmp_path / "Purchase_Register_Template.xlsx")
    g2b_path = str(tmp_path / "GSTR_2B_Template.xlsx")
    vm_path = str(tmp_path / "Vendor_Master_Template.xlsx")
    report_path = str(tmp_path / "GST_Reconciliation_Report.xlsx")

    # 1. Generate templates
    create_purchase_register_template(pr_path)
    create_gstr2b_template(g2b_path)
    create_vendor_master_template(vm_path)

    assert os.path.exists(pr_path)
    assert os.path.exists(g2b_path)
    assert os.path.exists(vm_path)

    # 2. Parse templates
    books_records, b_map, b_err = parse_excel_to_standard_records(pr_path, SourceType.BOOKS)
    gstr2b_records, g_map, g_err = parse_excel_to_standard_records(g2b_path, SourceType.GSTR2B)

    assert len(b_err) == 0
    assert len(g_err) == 0
    assert len(books_records) == 5
    assert len(gstr2b_records) == 5

    # 3. Run Reconciliation
    config = ReconciliationRuleConfig()
    engine = ReconciliationEngine(config)
    results, kpis = engine.run("test-job-e2e", books_records, gstr2b_records)

    assert len(results) > 0
    assert kpis.total_books_invoices == 5
    assert kpis.total_2b_invoices == 5

    # 4. Export 12-Sheet Excel Report
    export_reconciliation_report(
        filepath=report_path,
        results=results,
        kpis=kpis,
        client_info={"client_name": "Acme Corp", "gstin": "27AAACW1234F1Z5", "fy": "2026-27", "period": "April 2026"},
        audit_logs=[{
            "timestamp": "2026-08-17 13:20:00",
            "user": "CA Admin",
            "action": "RUN_RECONCILIATION",
            "invoice_id": "ALL",
            "previous_status": "NONE",
            "new_status": "COMPLETED",
            "reason": "Automated monthly reconciliation run"
        }]
    )

    assert os.path.exists(report_path)

    # Verify all 12 sheets exist in exported workbook
    wb = openpyxl.load_workbook(report_path)
    sheet_names = wb.sheetnames
    expected_sheets = [
        "Summary", "Invoice Wise Reconciliation", "Matched", "Matched with Difference",
        "Probable Match", "Books Only", "2B Only", "Duplicates", "Review Required",
        "Vendor Summary", "ITC Summary", "Audit Trail"
    ]
    for s_name in expected_sheets:
        assert s_name in sheet_names
