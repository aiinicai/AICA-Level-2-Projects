import requests
import json

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_full_system_e2e():
    # 1. Health check
    h_res = requests.get(f"{BASE_URL}/health")
    assert h_res.status_code == 200
    assert h_res.json()["status"] == "HEALTHY"

    # 2. Get Client list
    c_res = requests.get(f"{BASE_URL}/clients")
    assert c_res.status_code == 200
    clients = c_res.json()
    assert len(clients) > 0
    client_id = clients[0]["id"]

    # 3. Create a temporary client & verify client management
    new_c_res = requests.post(f"{BASE_URL}/clients", json={
        "client_name": "Test CA Client Ltd",
        "gstin": "27AAACW9999F1Z9",
        "pan": "AAACW9999F",
        "financial_year": "2026-27"
    })
    assert new_c_res.status_code == 200
    test_client_id = new_c_res.json()["id"]

    # 4. Upload & Run 30-record Reconciliation Job for FY 2026-27 (April 2026)
    with open("data/sample/sample_purchase_register_30.xlsx", "rb") as b_file, \
         open("data/sample/sample_gstr2b_30.xlsx", "rb") as g_file:
        files = {
            "books_file": ("sample_purchase_register_30.xlsx", b_file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            "gstr2b_file": ("sample_gstr2b_30.xlsx", g_file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        }
        data = {
            "client_id": test_client_id,
            "financial_year": "2026-27",
            "tax_period": "April 2026"
        }
        r_res = requests.post(f"{BASE_URL}/reconciliation/run", data=data, files=files)
        assert r_res.status_code == 200, f"Error: {r_res.text}"
        run_data = r_res.json()
        job_id = run_data["job_id"]
        assert job_id is not None
        assert run_data["status"] == "COMPLETED"

    # 5. Fetch Job Results & Verify 1-to-1 Reconciliation Output
    res_res = requests.get(f"{BASE_URL}/reconciliation/jobs/{job_id}/results")
    assert res_res.status_code == 200
    res_json = res_res.json()
    results = res_json["results"]
    kpis = res_json["kpis"]
    assert len(results) > 0
    assert kpis["total_books_invoices"] == 30
    assert kpis["total_2b_invoices"] == 30
    assert kpis["exact_matches"] >= 9

    # 6. Manual Override Test
    first_id = results[0]["id"]
    m_res = requests.post(f"{BASE_URL}/reconciliation/manual-match", json={
        "result_id": first_id,
        "action": "ACCEPT",
        "reason": "CA verified physical invoice copy",
        "user_name": "CA Senior Partner"
    })
    assert m_res.status_code == 200
    assert m_res.json()["status"] == "SUCCESS"

    # 7. Vendor Summary
    v_res = requests.get(f"{BASE_URL}/reconciliation/jobs/{job_id}/vendor-summary")
    assert v_res.status_code == 200
    vendors = v_res.json()
    assert len(vendors) > 0

    # 8. Export 12-Sheet Excel Report
    exp_res = requests.get(f"{BASE_URL}/reconciliation/jobs/{job_id}/export-excel")
    assert exp_res.status_code == 200
    assert exp_res.headers["content-type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    assert len(exp_res.content) > 1000

    # 9. Test Remove Client (Delete Client)
    del_res = requests.delete(f"{BASE_URL}/clients/{test_client_id}")
    assert del_res.status_code == 200
    assert del_res.json()["status"] == "SUCCESS"

    print(f"\n[SUCCESS] Full End-to-End System Test Passed! Job ID: {job_id}")

if __name__ == "__main__":
    test_full_system_e2e()
