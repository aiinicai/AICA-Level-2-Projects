import pytest
from backend.app.services.excel_parser import parse_excel_to_standard_records
from backend.app.schemas.reconciliation import SourceType, ReconciliationRuleConfig, MatchStatus
from backend.app.reconciliation.engine import ReconciliationEngine

def test_30_record_reconciliation():
    # 1. Parse Books and 2B Excel files
    books_records, b_map, b_err = parse_excel_to_standard_records("data/sample/sample_purchase_register_30.xlsx", SourceType.BOOKS)
    g2b_records, g_map, g_err = parse_excel_to_standard_records("data/sample/sample_gstr2b_30.xlsx", SourceType.GSTR2B)

    assert len(b_err) == 0
    assert len(g_err) == 0
    assert len(books_records) == 30
    assert len(g2b_records) == 30

    for idx, r in enumerate(books_records): r.id = f"B-{idx+1}"
    for idx, r in enumerate(g2b_records): r.id = f"G-{idx+1}"

    # 2. Configure engine with 2-day date tolerance and 1.00 ITC tolerance
    config = ReconciliationRuleConfig(date_tolerance_days=2, tax_tolerance_amount=1.0)
    engine = ReconciliationEngine(config)
    results, kpis = engine.run("test-job-30", books_records, g2b_records)

    # 3. Print Diagnostic Output for Developer Review
    print("\n" + "="*80)
    print("30-RECORD RECONCILIATION ENGINE DIAGNOSTIC REPORT")
    print("="*80)
    print(f"Total Books Records Ingested : {kpis.total_books_invoices}")
    print(f"Total 2B Records Ingested    : {kpis.total_2b_invoices}")
    print(f"Exact Matches (L1)           : {kpis.exact_matches}")
    print(f"Matched with Date Difference : {kpis.matched_date_diff}")
    print(f"Matched with ITC Difference  : {kpis.matched_tax_diff}")
    print(f"Matched Date & ITC Diff     : {kpis.matched_date_tax_diff}")
    print(f"No GSTIN Invoice No Match    : {kpis.inv_no_match_no_gstin}")
    print(f"Probable Matches (Fuzzy)     : {kpis.probable_matches}")
    print(f"Books Only (Unmatched)       : {kpis.books_only}")
    print(f"2B Only (Unmatched)          : {kpis.gstr2b_only}")
    print(f"Duplicates in Books          : {kpis.duplicates_books}")
    print(f"Duplicates in GSTR-2B        : {kpis.duplicates_2b}")
    print(f"Credit & Debit Notes         : {kpis.credit_debit_notes}")
    print("="*80)

    # Print breakdown of every result
    for r in results:
        st = r.match_status.value if hasattr(r.match_status, 'value') else str(r.match_status)
        b_inv = r.books_record.original_invoice_number if r.books_record else "-"
        g_inv = r.gstr2b_record.original_invoice_number if r.gstr2b_record else "-"
        notes_clean = r.match_notes.replace("₹", "Rs ")
        print(f"[{st:<35}] Score: {r.match_score:>3} | Books: {b_inv:<18} | 2B: {g_inv:<18} | Notes: {notes_clean}")

    # Assertions to ensure engine correctly classifies records
    assert kpis.exact_matches >= 9 # Exact + format variation matches
    assert kpis.inv_no_match_no_gstin >= 2 # GSTIN missing match
    assert kpis.books_only >= 4
    assert kpis.gstr2b_only >= 4
    assert (kpis.duplicates_books + kpis.duplicates_2b) >= 2

if __name__ == "__main__":
    test_30_record_reconciliation()
