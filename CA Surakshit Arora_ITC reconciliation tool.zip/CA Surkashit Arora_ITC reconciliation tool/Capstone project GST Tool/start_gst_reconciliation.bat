@echo off
TITLE Input Reconciliation Tool - ASA Suite
COLOR 0B

:: Ensure working directory is always the folder containing this batch script
cd /d "%~dp0"

echo =========================================================================
echo               INPUT RECONCILIATION TOOL - ASA SUITE
echo =========================================================================
echo.

:: 1. Detect Python Installation
echo [1/3] Checking Python environment...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python is NOT detected on your system PATH!
    echo Please install Python 3.10+ and check "Add Python to PATH".
    pause
    exit /b 1
)

:: 2. Detect Node.js Installation
echo [2/3] Checking Node.js environment...
node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is NOT detected on your system PATH!
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

:: Auto-install Node dependencies if node_modules is missing
if not exist "%~dp0frontend\node_modules" (
    echo.
    echo Node.js packages missing. Installing dependencies...
    cd /d "%~dp0frontend"
    call npm install
    cd /d "%~dp0"
)

:: 3. Launch Backend & Frontend background processes
echo [3/3] Launching ASA Reconciliation Engine...

:: Start Backend in background
start "ASA Backend Engine" /B python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 >nul 2>&1

:: Start Frontend in background
start "ASA Frontend UI" /B cmd /c "cd /d "%~dp0frontend" && npm run dev" >nul 2>&1

echo.
echo Launching web browser in 4 seconds...
ping -n 5 127.0.0.1 >nul

:: Open default browser to app UI
start http://localhost:5173/

cls
echo =========================================================================
echo               INPUT RECONCILIATION TOOL - ASA SUITE
echo =========================================================================
echo.
echo   [ONLINE] Web Application : http://localhost:5173/
echo   [ONLINE] API Documentation: http://127.0.0.1:8000/docs
echo.
echo   ASA Reconciliation Engine is active and running in the background.
echo   Keep this console window open while using the application.
echo   Close this window when you are done working.
echo =========================================================================
echo.
pause
