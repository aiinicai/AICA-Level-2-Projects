# TDS Applicability Check Tool - PWA & Portable Standalone App

A complete, 4-step statutory compliance and audit working paper tool under Chapter XVII-B of the Indian Income-tax Act, 1961.

---

## 🚀 Options to Share and Run

You have two ready-to-use formats:

### Option 1: Standalone Single-File App (Easiest to Share)
- **File**: `TDS_Applicability_Tool_Standalone.html`
- **How to use**:
  1. Simply double-click `TDS_Applicability_Tool_Standalone.html` (or run `Run_Standalone_HTML.bat`).
  2. It opens immediately in Google Chrome, Microsoft Edge, Brave, Firefox, or Safari.
  3. **No installation, no internet, and no server required!**
  4. 100% of the calculation engine, Excel/XML parsers, and statutory rules run client-side in your browser.
  5. You can directly send this single `.html` file via **WhatsApp, Email, Telegram, Google Drive, or USB drive**.

---

### Option 2: Progressive Web App (PWA) with 1-Click Desktop/Mobile Installation
- **Folder**: `dist/`
- **How to run locally**:
  1. Double-click `Run_PWA_App_Server.bat`.
  2. The app will open at `http://localhost:5173`.
  3. Click the **"Install App"** button in the top navigation bar or the **Install icon (⬇️ / ➕)** in your browser address bar.
  4. The app will install as a native standalone desktop app with its own app window and desktop icon!
  5. Once installed, it works **100% offline** anytime with Service Worker caching.

- **How to host online**:
  - Copy the contents of the `dist/` folder to any static hosting provider (e.g., GitHub Pages, Netlify, Vercel, Firebase Hosting, Cloudflare Pages, or your company intranet).
  - Anyone visiting the HTTPS URL can tap **"Install App"** on Android, iOS, Windows, or Mac.

---

## ✨ Features Included
- **Step 1: Ledger Screening** — Automatic keyword/statutory rule matching (194C, 194J, 194I, 194H, 194A, 194R, 194Q) with CA override & bulk actions.
- **Step 2 & 3: Voucher Analysis** — Single bill threshold vs cumulative aggregate FY threshold tracking with statutory individual vs non-individual rates.
- **Step 4: Exception Summary** — Summary tables + Short deduction exception list.
- **Mandatory Control Checks** — Value reconciliation, TDS credit reconciliation, and ledger integrity.
- **3-Sheet Excel Working Paper Export** — Ready for statutory audit review.
- **PWA Service Worker & Manifest** — Offline pre-caching, standalone window display, and custom icons.
