@echo off
title TDS Applicability Check Tool - PWA Server
echo ======================================================================
echo  TDS APPLICABILITY CHECK TOOL - PROGRESSIVE WEB APP (PWA)
echo ======================================================================
echo.
echo Starting local web server for PWA installation and offline caching...
echo.

cd /d "%~dp0"

if exist "dist\index.html" (
    echo [OK] Serving production PWA build from dist/ folder...
    start "" http://localhost:5173
    call npx.cmd --yes serve -s dist -l 5173
) else (
    echo [INFO] Building PWA distribution first...
    call npm.cmd run build:pwa
    start "" http://localhost:5173
    call npx.cmd --yes serve -s dist -l 5173
)
pause
