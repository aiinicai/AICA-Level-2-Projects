@echo off
title TDS Applicability Check Tool - Portable Standalone
echo ======================================================================
echo Launching TDS Applicability Check Tool (Portable Standalone) ...
echo ======================================================================
echo.
start "" "%~dp0TDS_Applicability_Tool_Standalone.html"
exit
