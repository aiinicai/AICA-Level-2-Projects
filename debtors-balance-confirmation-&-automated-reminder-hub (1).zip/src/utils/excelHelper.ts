import * as XLSX from 'xlsx';
import { Invoice, Party, ValidatedExcelRow } from '../types';
import { getTodayDateString } from './calculations';

export const EXPECTED_EXCEL_COLUMNS = [
  'Invoice Date',
  'Invoice Number',
  'Due Date',
  'Party Name',
  'City',
  'Area',
  'Representative Name',
  'Email ID',
  'Contact Number',
  'Invoice Amount'
];

export interface FileParseResult {
  rows: ValidatedExcelRow[];
  validRows: ValidatedExcelRow[];
  totalRows: number;
  validRowsCount: number;
  errorRowsCount: number;
  duplicateCount: number;
  missingContactCount: number;
  errors: string[];
  warnings: string[];
}

function normalizeColumnName(name: string): string {
  return (name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function mapHeaderToField(header: string): string {
  const norm = normalizeColumnName(header);
  if (norm.includes('invdate') || norm.includes('invoicedate') || norm.includes('billdate') || norm === 'date') return 'invoiceDate';
  if (norm.includes('invno') || norm.includes('invoiceno') || norm.includes('invoicenumber') || norm.includes('billno')) return 'invoiceNumber';
  if (norm.includes('duedate') || norm.includes('maturitydate') || norm.includes('paymentdue')) return 'dueDate';
  if (norm.includes('party') || norm.includes('customer') || norm.includes('debtor') || norm.includes('client') || norm.includes('accountname')) return 'partyName';
  if (norm.includes('city') || norm.includes('location')) return 'city';
  if (norm.includes('area') || norm.includes('zone') || norm.includes('region')) return 'area';
  if (norm.includes('rep') || norm.includes('salesperson') || norm.includes('executive') || norm.includes('manager')) return 'representativeName';
  if (norm.includes('email') || norm.includes('mailid')) return 'email';
  if (norm.includes('contact') || norm.includes('phone') || norm.includes('mobile') || norm.includes('tel')) return 'contactNumber';
  if (norm.includes('amount') || norm.includes('invamount') || norm.includes('total') || norm.includes('gross') || norm.includes('billamount')) return 'invoiceAmount';
  if (norm.includes('paid') || norm.includes('received') || norm.includes('collection')) return 'paidAmount';
  return header;
}

export function parseExcelDate(val: any): string {
  if (!val) return '';
  if (typeof val === 'number') {
    // Excel serial date format
    const dateObj = XLSX.SSF.parse_date_code(val);
    if (dateObj) {
      const y = dateObj.y;
      const m = String(dateObj.m).padStart(2, '0');
      const d = String(dateObj.d).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
  }

  const str = String(val).trim();
  if (str.includes('/')) {
    const parts = str.split('/');
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        // DD/MM/YYYY
        return `${parts[2]}-${String(parts[1]).padStart(2, '0')}-${String(parts[0]).padStart(2, '0')}`;
      } else if (parts[0].length === 4) {
        // YYYY/MM/DD
        return `${parts[0]}-${String(parts[1]).padStart(2, '0')}-${String(parts[2]).padStart(2, '0')}`;
      }
    }
  }

  if (str.includes('-')) {
    const parts = str.split('-');
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        // DD-MM-YYYY
        return `${parts[2]}-${String(parts[1]).padStart(2, '0')}-${String(parts[0]).padStart(2, '0')}`;
      } else if (parts[0].length === 4) {
        // YYYY-MM-DD
        return str;
      }
    }
  }

  const testD = new Date(str);
  if (!isNaN(testD.getTime())) {
    const y = testD.getFullYear();
    const m = String(testD.getMonth() + 1).padStart(2, '0');
    const d = String(testD.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return str;
}

export async function validateAndParseFile(
  fileOrBuffer: File | ArrayBuffer,
  existingInvoicesOrSet: Invoice[] | Set<string> = []
): Promise<FileParseResult> {
  let arrayBuffer: ArrayBuffer;
  if (fileOrBuffer instanceof File) {
    arrayBuffer = await fileOrBuffer.arrayBuffer();
  } else {
    arrayBuffer = fileOrBuffer;
  }

  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  
  const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

  const existingInvNos = existingInvoicesOrSet instanceof Set
    ? existingInvoicesOrSet
    : new Set(existingInvoicesOrSet.map(i => i.invoiceNumber.trim().toUpperCase()));
  const seenInFile = new Set<string>();

  const rows: ValidatedExcelRow[] = [];
  const allErrors: string[] = [];
  const allWarnings: string[] = [];
  let validRowsCount = 0;
  let errorRowsCount = 0;
  let duplicateCount = 0;
  let missingContactCount = 0;

  rawJson.forEach((rawRow, index) => {
    const rowNum = index + 2;
    const errors: string[] = [];
    const warnings: string[] = [];

    const mapped: Record<string, any> = {};
    Object.keys(rawRow).forEach(key => {
      const mappedKey = mapHeaderToField(key);
      mapped[mappedKey] = rawRow[key];
    });

    const invoiceNumber = String(mapped.invoiceNumber || '').trim();
    const partyName = String(mapped.partyName || '').trim();
    const city = String(mapped.city || '').trim();
    const area = String(mapped.area || '').trim();
    const representativeName = String(mapped.representativeName || '').trim();
    const email = String(mapped.email || '').trim();
    const contactNumber = String(mapped.contactNumber || '').trim();
    const invoiceDate = parseExcelDate(mapped.invoiceDate);
    const dueDate = parseExcelDate(mapped.dueDate);
    
    // Parse numeric amounts
    let invoiceAmount = 0;
    const rawAmt = mapped.invoiceAmount;
    if (typeof rawAmt === 'number') {
      invoiceAmount = rawAmt;
    } else {
      const cleaned = String(rawAmt || '').replace(/[^0-9.-]/g, '');
      invoiceAmount = parseFloat(cleaned) || 0;
    }

    let paidAmount = 0;
    const rawPaid = mapped.paidAmount;
    if (typeof rawPaid === 'number') {
      paidAmount = rawPaid;
    } else if (rawPaid) {
      const cleanedPaid = String(rawPaid).replace(/[^0-9.-]/g, '');
      paidAmount = parseFloat(cleanedPaid) || 0;
    }

    // Validation checks
    if (!invoiceNumber) {
      errors.push(`Row ${rowNum}: Missing Invoice Number`);
    }
    if (!partyName) {
      errors.push(`Row ${rowNum}: Missing Party / Debtor Name`);
    }
    if (!invoiceDate || isNaN(new Date(invoiceDate).getTime())) {
      errors.push(`Row ${rowNum} (${invoiceNumber || 'Unknown'}): Invalid or Missing Invoice Date`);
    }
    if (!dueDate || isNaN(new Date(dueDate).getTime())) {
      errors.push(`Row ${rowNum} (${invoiceNumber || 'Unknown'}): Invalid or Missing Due Date`);
    }
    if (invoiceAmount <= 0) {
      errors.push(`Row ${rowNum} (${invoiceNumber || 'Unknown'}): Invoice Amount must be greater than 0`);
    }

    // Duplicate checks
    const upperInv = invoiceNumber.toUpperCase();
    let isDuplicate = false;
    if (upperInv) {
      if (seenInFile.has(upperInv)) {
        errors.push(`Row ${rowNum}: Duplicate Invoice Number in file: ${invoiceNumber}`);
        isDuplicate = true;
        duplicateCount++;
      } else {
        seenInFile.add(upperInv);
      }

      if (existingInvNos.has(upperInv)) {
        warnings.push(`Row ${rowNum}: Invoice #${invoiceNumber} already exists in database (will update record on import)`);
      }
    }

    // Contact warnings
    if (!email && !contactNumber) {
      warnings.push(`Row ${rowNum} (${partyName}): Missing Email & Phone (automated reminders disabled)`);
      missingContactCount++;
    } else {
      if (email && !email.includes('@')) {
        warnings.push(`Row ${rowNum} (${partyName}): Email format looks suspicious (${email})`);
      }
      if (contactNumber && contactNumber.replace(/\D/g, '').length < 8) {
        warnings.push(`Row ${rowNum} (${partyName}): Contact number appears incomplete (${contactNumber})`);
      }
    }

    const isValid = errors.length === 0;
    if (isValid) {
      validRowsCount++;
    } else {
      errorRowsCount++;
      allErrors.push(...errors);
    }
    if (warnings.length > 0) {
      allWarnings.push(...warnings);
    }

    rows.push({
      rowNumber: rowNum,
      invoiceDate,
      invoiceNumber,
      dueDate,
      partyName,
      city: city || 'General Territory',
      area: area || 'General Area',
      representativeName: representativeName || 'Accounts Desk',
      email,
      contactNumber,
      invoiceAmount,
      paidAmount,
      isValid,
      errors,
      warnings,
      isDuplicate
    });
  });

  const validRows = rows.filter(r => r.isValid);

  return {
    rows,
    validRows,
    totalRows: rawJson.length,
    validRowsCount,
    errorRowsCount,
    duplicateCount,
    missingContactCount,
    errors: allErrors,
    warnings: allWarnings
  };
}

export function generateSampleExcelFile(): Uint8Array {
  const sampleData = [
    {
      'Invoice Date': '2026-06-15',
      'Invoice Number': 'INV-2026-0891',
      'Due Date': '2026-07-15',
      'Party Name': 'Apex Industrial Solutions Pvt Ltd',
      'City': 'Mumbai',
      'Area': 'Andheri East Industrial Zone',
      'Representative Name': 'Rajesh Sharma',
      'Email ID': 'accounts@apexsolutions.in',
      'Contact Number': '+91 98201 44552',
      'Invoice Amount': 245000
    },
    {
      'Invoice Date': '2026-07-01',
      'Invoice Number': 'INV-2026-0924',
      'Due Date': '2026-07-31',
      'Party Name': 'Zenith Polymer Works',
      'City': 'Pune',
      'Area': 'Bhosari MIDC',
      'Representative Name': 'Pooja Deshmukh',
      'Email ID': 'finance@zenithpolymers.com',
      'Contact Number': '+91 98902 33119',
      'Invoice Amount': 182500
    },
    {
      'Invoice Date': '2026-07-20',
      'Invoice Number': 'INV-2026-1002',
      'Due Date': '2026-08-20',
      'Party Name': 'BlueHorizon Logistics LLP',
      'City': 'Bengaluru',
      'Area': 'Peenya 2nd Stage',
      'Representative Name': 'Kiran Kumar',
      'Email ID': 'billing@bluehorizonlogistics.com',
      'Contact Number': '+91 94481 77663',
      'Invoice Amount': 94000
    },
    {
      'Invoice Date': '2026-08-01',
      'Invoice Number': 'INV-2026-1045',
      'Due Date': '2026-08-25',
      'Party Name': 'Nova Tech Dynamics',
      'City': 'Hyderabad',
      'Area': 'HITEC City',
      'Representative Name': 'Sneha Reddy',
      'Email ID': 'payments@novatech.co.in',
      'Contact Number': '+91 98490 88221',
      'Invoice Amount': 320000
    },
    {
      'Invoice Date': '2026-08-10',
      'Invoice Number': 'INV-2026-1088',
      'Due Date': '2026-09-01',
      'Party Name': 'Vanguard Electro-Mech Corp',
      'City': 'Delhi NCR',
      'Area': 'Okhla Phase III',
      'Representative Name': 'Amit Verma',
      'Email ID': 'accounts@vanguardmech.com',
      'Contact Number': '+91 98110 55443',
      'Invoice Amount': 450000
    }
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Debtors Invoices');

  // Set column widths
  worksheet['!cols'] = [
    { wch: 14 },
    { wch: 16 },
    { wch: 14 },
    { wch: 32 },
    { wch: 15 },
    { wch: 25 },
    { wch: 20 },
    { wch: 30 },
    { wch: 18 },
    { wch: 16 }
  ];

  return XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
}

export function downloadSampleTemplate(filename: string = 'Debtors_Import_Template.xlsx') {
  const buffer = generateSampleExcelFile();
  downloadBlob(buffer, filename, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

export function downloadBlob(data: Uint8Array | string, filename: string, mimeType: string) {
  const blob = new Blob([data], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportInvoicesToExcel(invoices: Invoice[], filename: string = 'Debtors_Invoices_Master.xlsx') {
  const exportData = invoices.map(i => ({
    'Invoice No': i.invoiceNumber,
    'Party Name': i.partyName,
    'Invoice Date': i.invoiceDate,
    'Due Date': i.dueDate,
    'Invoice Amount': i.amount,
    'Paid Amount': i.paidAmount,
    'Outstanding Amount': i.outstandingAmount,
    'Days Outstanding': i.daysOutstanding,
    'Days Overdue': i.daysOverdue,
    'Status': i.status,
    'City': i.city,
    'Area': i.area,
    'Representative': i.representativeName,
    'Email': i.email,
    'Contact Phone': i.phone,
    'Reminders Sent': i.remindersSentCount,
    'Last Reminder Date': i.lastReminderDate || '-'
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoices');
  const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  downloadBlob(buffer, filename, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

export function exportPartiesToExcel(parties: Party[], filename: string = 'Debtors_Party_Master.xlsx') {
  const exportData = parties.map(p => ({
    'Party Name': p.name,
    'City': p.city,
    'Area': p.area,
    'Representative': p.representativeName,
    'Email': p.email,
    'Phone': p.phone,
    'Credit Limit': p.creditLimit,
    'Total Invoiced': p.totalInvoiced,
    'Total Paid': p.totalPaid,
    'Total Outstanding': p.totalOutstanding,
    'Overdue Amount': p.overdueAmount,
    'Max Days Overdue': p.maxDaysOverdue,
    'Invoice Count': p.invoiceCount,
    'Risk Category': p.riskScore,
    'Account Status': p.status,
    'Balance Confirmation': p.confirmationStatus,
    'Last Confirmation Date': p.lastConfirmationDate || '-'
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Parties');
  const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  downloadBlob(buffer, filename, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

export function exportAgeingReportToExcel(parties: Party[], invoices: Invoice[], filename: string = 'Debtors_Ageing_Report.xlsx') {
  const partyMap = new Map<string, {
    current: number;
    b1_30: number;
    b31_60: number;
    b61_90: number;
    b91_180: number;
    b180plus: number;
    total: number;
  }>();

  invoices.forEach(inv => {
    if (inv.outstandingAmount <= 0) return;
    if (!partyMap.has(inv.partyId)) {
      partyMap.set(inv.partyId, { current: 0, b1_30: 0, b31_60: 0, b61_90: 0, b91_180: 0, b180plus: 0, total: 0 });
    }
    const rec = partyMap.get(inv.partyId)!;
    rec.total += inv.outstandingAmount;

    if (inv.daysOverdue <= 0) {
      rec.current += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 30) {
      rec.b1_30 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 60) {
      rec.b31_60 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 90) {
      rec.b61_90 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 180) {
      rec.b91_180 += inv.outstandingAmount;
    } else {
      rec.b180plus += inv.outstandingAmount;
    }
  });

  const exportData = parties.map(p => {
    const ageing = partyMap.get(p.id) || { current: 0, b1_30: 0, b31_60: 0, b61_90: 0, b91_180: 0, b180plus: 0, total: 0 };
    return {
      'Party Name': p.name,
      'City': p.city,
      'Area': p.area,
      'Sales Rep': p.representativeName,
      'Risk Score': p.riskScore,
      'Current (Not Due)': ageing.current,
      '1 - 30 Days Overdue': ageing.b1_30,
      '31 - 60 Days Overdue': ageing.b31_60,
      '61 - 90 Days Overdue': ageing.b61_90,
      '91 - 180 Days Overdue': ageing.b91_180,
      '180+ Days Overdue': ageing.b180plus,
      'Total Outstanding': ageing.total
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Ageing Matrix');
  const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  downloadBlob(buffer, filename, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}
