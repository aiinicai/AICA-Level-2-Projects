import { Channel, CommunicationLog, Invoice, Party, ReminderRule, SystemSettings } from '../types';
import { calculateDaysBetween, formatCurrency, formatDisplayDate, getTodayDateString } from './calculations';

export const DEFAULT_REMINDER_RULES: ReminderRule[] = [
  {
    id: 'rule_before_7',
    triggerType: 'days_before',
    days: -7,
    label: '7 Days Before Due Date',
    channels: ['Email'],
    enabled: true,
    severity: 'Gentle',
    emailSubject: 'Upcoming Payment Reminder: Invoice #{{invoice_no}} due on {{due_date}}',
    emailTemplate: `Dear {{party_name}},<br><br>This is a gentle reminder that Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong> is scheduled for payment on <strong>{{due_date}}</strong> (in 7 days).<br><br>Please process the invoice at your earliest convenience to avoid any disruption in supply/services.<br><br><strong>Bank Details for NEFT/RTGS:</strong><br>Bank: {{bank_name}}<br>A/c No: {{account_no}}<br>IFSC: {{ifsc_code}}<br>UPI: {{upi_id}}<br><br>Warm regards,<br>Finance Team, {{company_name}}`,
    whatsappTemplate: `Hello *{{party_name}}*,\n\nGentle courtesy reminder from *{{company_name}}* that Invoice *#{{invoice_no}}* for *{{outstanding_amount}}* is due in 7 days on *{{due_date}}*.\n\nBank Transfer Details:\n• Bank: {{bank_name}}\n• A/c: {{account_no}}\n• IFSC: {{ifsc_code}}\n• UPI: {{upi_id}}\n\nThank you for your business!`,
    smsTemplate: `Reminder: Inv #{{invoice_no}} for {{outstanding_amount}} from {{company_name}} is due on {{due_date}}. Pls pay via NEFT/UPI: {{upi_id}}`
  },
  {
    id: 'rule_before_3',
    triggerType: 'days_before',
    days: -3,
    label: '3 Days Before Due Date',
    channels: ['Email', 'WhatsApp'],
    enabled: true,
    severity: 'Gentle',
    emailSubject: 'Payment Reminder: Invoice #{{invoice_no}} due in 3 days ({{due_date}})',
    emailTemplate: `Dear {{party_name}},<br><br>We would like to remind you that Invoice <strong>#{{invoice_no}}</strong> amounting to <strong>{{outstanding_amount}}</strong> is due for payment on <strong>{{due_date}}</strong>.<br><br>Kindly initiate payment to keep your ledger up to date.<br><br>Regards,<br>Accounts Department, {{company_name}}`,
    whatsappTemplate: `Hi *{{party_name}}*, this is a reminder from *{{company_name}}*. Invoice *#{{invoice_no}}* for *{{outstanding_amount}}* is due in 3 days (*{{due_date}}*). Please arrange the transfer. Thanks!`,
    smsTemplate: `Inv #{{invoice_no}} for {{outstanding_amount}} is due in 3 days ({{due_date}}). Kindly clear before due date. {{company_name}}`
  },
  {
    id: 'rule_before_1',
    triggerType: 'days_before',
    days: -1,
    label: '1 Day Before Due Date',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Firm',
    emailSubject: 'Action Required: Invoice #{{invoice_no}} due tomorrow ({{due_date}})',
    emailTemplate: `Dear {{party_name}},<br><br>Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong> is due for clearance <strong>tomorrow, {{due_date}}</strong>.<br><br>If already initiated, kindly share the payment UTR / transaction receipt with us.<br><br>Thank you,<br>{{company_name}} Finance`,
    whatsappTemplate: `Attention: *{{party_name}}*\nInvoice *#{{invoice_no}}* (Amount: *{{outstanding_amount}}*) is due *tomorrow ({{due_date}})*.\n\nPlease share the payment confirmation/UTR once processed.\n\n{{company_name}} Accounts`,
    smsTemplate: `Urgent: Inv #{{invoice_no}} for {{outstanding_amount}} is due tomorrow ({{due_date}}). Please process payment today. {{company_name}}`
  },
  {
    id: 'rule_on_due',
    triggerType: 'on_due_date',
    days: 0,
    label: 'On Due Date (Today)',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Firm',
    emailSubject: 'Due Today: Invoice #{{invoice_no}} payment of {{outstanding_amount}}',
    emailTemplate: `Dear {{party_name}},<br><br>This is to inform you that Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong> is <strong>DUE TODAY</strong> ({{due_date}}).<br><br>Please release payment today to ensure continuous credit and smooth operations.<br><br>Thank you,<br>{{company_name}}`,
    whatsappTemplate: `*Payment Due Today*\n\nDear *{{party_name}}*, Invoice *#{{invoice_no}}* for *{{outstanding_amount}}* is due for settlement *TODAY*.\n\nKindly remit payment and reply with UTR/receipt.\n\n{{company_name}}`,
    smsTemplate: `Inv #{{invoice_no}} for {{outstanding_amount}} is DUE TODAY. Please release payment immediately to avoid overdue charges. {{company_name}}`
  },
  {
    id: 'rule_overdue_1',
    triggerType: 'days_overdue',
    days: 1,
    label: '1 Day Overdue',
    channels: ['Email', 'WhatsApp'],
    enabled: true,
    severity: 'Firm',
    emailSubject: 'Overdue Notice: Invoice #{{invoice_no}} is 1 day past due',
    emailTemplate: `Dear {{party_name}},<br><br>Our records show that Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong> was due on {{due_date}} and is now <strong>1 day overdue</strong>.<br><br>Please verify and release the funds at the earliest.<br><br>Best regards,<br>{{company_name}}`,
    whatsappTemplate: `*Overdue Notice*: Invoice *#{{invoice_no}}* (*{{outstanding_amount}}*) was due yesterday (*{{due_date}}*). Please expedite payment today.\n\n{{company_name}} Finance`,
    smsTemplate: `Overdue: Inv #{{invoice_no}} of {{outstanding_amount}} is 1 day past due date {{due_date}}. Please clear immediately. {{company_name}}`
  },
  {
    id: 'rule_overdue_3',
    triggerType: 'days_overdue',
    days: 3,
    label: '3 Days Overdue',
    channels: ['Email', 'WhatsApp'],
    enabled: true,
    severity: 'Firm',
    emailSubject: 'Follow-up: Invoice #{{invoice_no}} is 3 days overdue ({{outstanding_amount}})',
    emailTemplate: `Dear {{party_name}},<br><br>We have not yet received payment for Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong>, which matured on {{due_date}} (3 days ago).<br><br>Kindly expedite remittance today and provide transaction reference.<br><br>Accounts Department,<br>{{company_name}}`,
    whatsappTemplate: `Hi *{{party_name}}*, we have not received payment for Invoice *#{{invoice_no}}* (*{{outstanding_amount}}*, matured {{due_date}}). Kindly clear this pending amount today.\n\n{{company_name}}`,
    smsTemplate: `Inv #{{invoice_no}} ({{outstanding_amount}}) is 3 days overdue. Kindly remit immediately. {{company_name}}`
  },
  {
    id: 'rule_overdue_7',
    triggerType: 'days_overdue',
    days: 7,
    label: '7 Days Overdue',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Urgent',
    emailSubject: 'Urgent: Invoice #{{invoice_no}} is 7 days overdue - Immediate payment requested',
    emailTemplate: `Dear {{party_name}},<br><br>Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong> is now <strong>7 days overdue</strong> (Due date: {{due_date}}).<br><br>Please note that continued delay may affect credit terms and pending dispatches. Please clear the pending dues immediately.<br><br>Finance & Credit Control,<br>{{company_name}}`,
    whatsappTemplate: `⚠️ *URGENT PAYMENT ALERT*\n\nDear *{{party_name}}*, Invoice *#{{invoice_no}}* for *{{outstanding_amount}}* is now *7 days overdue*.\n\nTo prevent account hold or delay in fresh dispatches, please clear this immediately.\n\nBank: {{bank_name}} | A/c: {{account_no}} | IFSC: {{ifsc_code}}`,
    smsTemplate: `URGENT: Inv #{{invoice_no}} for {{outstanding_amount}} is 7 DAYS OVERDUE. Settle immediately to avoid supply hold. {{company_name}}`
  },
  {
    id: 'rule_overdue_15',
    triggerType: 'days_overdue',
    days: 15,
    label: '15 Days Overdue',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Urgent',
    emailSubject: 'Second Overdue Notice: Invoice #{{invoice_no}} is 15 days overdue',
    emailTemplate: `Dear {{party_name}},<br><br>Despite previous reminders, payment of <strong>{{outstanding_amount}}</strong> against Invoice <strong>#{{invoice_no}}</strong> remains uncollected for <strong>15 days</strong>.<br><br>Please arrange immediate payment today or contact your relationship manager {{representative_name}} to discuss settlement.<br><br>Sincerely,<br>Credit Controller, {{company_name}}`,
    whatsappTemplate: `⚠️ *SECOND NOTICE - 15 DAYS OVERDUE*\n\nParty: *{{party_name}}*\nInvoice: *#{{invoice_no}}*\nPending: *{{outstanding_amount}}*\n\nPlease transfer immediately or contact rep {{representative_name}}.\n\n{{company_name}}`,
    smsTemplate: `2nd Notice: Inv #{{invoice_no}} of {{outstanding_amount}} is 15 DAYS OVERDUE. Immediate clearance required. {{company_name}}`
  },
  {
    id: 'rule_overdue_30',
    triggerType: 'days_overdue',
    days: 30,
    label: '30 Days Overdue (Account Escalation)',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Final Notice',
    emailSubject: 'FINAL NOTICE: Invoice #{{invoice_no}} is 30 days overdue - Account On Hold',
    emailTemplate: `Dear {{party_name}},<br><br>Invoice <strong>#{{invoice_no}}</strong> amounting to <strong>{{outstanding_amount}}</strong> has now exceeded <strong>30 days overdue</strong> (Due Date: {{due_date}}).<br><br>Your account has been flagged for credit review and fresh deliveries may be placed on hold until complete clearance is received.<br><br>Please treat this with utmost urgency and remit full payment immediately.<br><br>Head of Finance,<br>{{company_name}}`,
    whatsappTemplate: `🔴 *FINAL NOTICE - 30 DAYS OVERDUE*\n\nDear *{{party_name}}*,\nInvoice *#{{invoice_no}}* (*{{outstanding_amount}}*) is now 30 days overdue.\n\nAccount is flagged for credit hold. Please remit payment today to avoid service suspension.\n\n{{company_name}} Finance`,
    smsTemplate: `FINAL NOTICE: Inv #{{invoice_no}} ({{outstanding_amount}}) is 30 DAYS OVERDUE. Account flagged for credit hold. Clear today. {{company_name}}`
  },
  {
    id: 'rule_overdue_60',
    triggerType: 'days_overdue',
    days: 60,
    label: '60+ Days Overdue (Legal / CFO Escalation)',
    channels: ['Email', 'WhatsApp', 'SMS'],
    enabled: true,
    severity: 'Legal Warning',
    emailSubject: 'CRITICAL OVERDUE NOTICE: Invoice #{{invoice_no}} (60+ Days Overdue) - Legal Action Pending',
    emailTemplate: `Dear {{party_name}},<br><br>This is a formal communication regarding Invoice <strong>#{{invoice_no}}</strong> for <strong>{{outstanding_amount}}</strong>, which has been overdue for over <strong>60 days</strong>.<br><br>Unless full payment is received within 48 hours, this matter will be escalated to our legal department for formal recovery proceedings and credit bureau reporting.<br><br>Please contact CFO / Legal team immediately.<br><br>Chief Financial Officer,<br>{{company_name}}`,
    whatsappTemplate: `⛔ *LEGAL RECOVERY WARNING - 60+ DAYS OVERDUE*\n\nParty: *{{party_name}}*\nInvoice: *#{{invoice_no}}*\nOutstanding: *{{outstanding_amount}}*\n\nMatter will be handed over to legal recovery if not settled within 48 hours. Contact accounts immediately.\n\n{{company_name}}`,
    smsTemplate: `LEGAL WARNING: Inv #{{invoice_no}} ({{outstanding_amount}}) 60+ days overdue. Clear in 48h to prevent legal recovery. {{company_name}}`
  }
];

export function replacePlaceholders(
  template: string,
  party: Party,
  invoice: Invoice | null,
  settings: SystemSettings,
  tokenOrLink?: string
): string {
  if (!template) return '';

  const today = getTodayDateString();
  const invNo = invoice ? invoice.invoiceNumber : 'All Pending Invoices';
  const dueDate = invoice ? formatDisplayDate(invoice.dueDate) : '-';
  const outstanding = invoice 
    ? formatCurrency(invoice.outstandingAmount, settings.currencySymbol)
    : formatCurrency(party.totalOutstanding, settings.currencySymbol);
  const amount = invoice 
    ? formatCurrency(invoice.amount, settings.currencySymbol)
    : formatCurrency(party.totalInvoiced, settings.currencySymbol);
  const overdueDays = invoice ? String(invoice.daysOverdue) : String(party.maxDaysOverdue);
  const daysLeft = invoice ? String(Math.max(0, calculateDaysBetween(today, invoice.dueDate))) : '0';

  let result = template
    .replace(/\{\{party_name\}\}/g, party.name || '')
    .replace(/\{\{invoice_no\}\}/g, invNo)
    .replace(/\{\{due_date\}\}/g, dueDate)
    .replace(/\{\{outstanding_amount\}\}/g, outstanding)
    .replace(/\{\{amount\}\}/g, amount)
    .replace(/\{\{days_overdue\}\}/g, overdueDays)
    .replace(/\{\{days_left\}\}/g, daysLeft)
    .replace(/\{\{city\}\}/g, party.city || '')
    .replace(/\{\{area\}\}/g, party.area || '')
    .replace(/\{\{representative_name\}\}/g, party.representativeName || 'Finance Desk')
    .replace(/\{\{company_name\}\}/g, settings.companyName || 'Corporate Finance')
    .replace(/\{\{bank_name\}\}/g, settings.bankDetails?.bankName || 'HDFC Bank')
    .replace(/\{\{account_no\}\}/g, settings.bankDetails?.accountNumber || '50200012345678')
    .replace(/\{\{ifsc_code\}\}/g, settings.bankDetails?.ifscCode || 'HDFC0001234')
    .replace(/\{\{upi_id\}\}/g, settings.bankDetails?.upiId || 'finance@hdfcbank')
    .replace(/\{\{confirmation_link\}\}/g, tokenOrLink || '#/portal/sample-token');

  return result;
}

export interface EligibleReminder {
  invoice: Invoice;
  party: Party;
  rule: ReminderRule;
  daysDiff: number;
  channels: Channel[];
  alreadySentToday: boolean;
}

export function findEligibleReminders(
  invoices: Invoice[],
  parties: Party[],
  rules: ReminderRule[],
  commLogs: CommunicationLog[],
  todayStr: string = getTodayDateString()
): EligibleReminder[] {
  const partyMap = new Map<string, Party>();
  parties.forEach(p => partyMap.set(p.id, p));

  const eligible: EligibleReminder[] = [];

  // Set of sent today logs: key = `invoiceId_ruleId_today` or `invoiceId_daysDiff_today`
  const sentTodayKeys = new Set<string>();
  commLogs.forEach(log => {
    if (log.sentAt && log.sentAt.startsWith(todayStr) && log.invoiceId) {
      if (log.ruleId) {
        sentTodayKeys.add(`${log.invoiceId}_${log.ruleId}`);
      }
      if (log.triggerDays !== undefined) {
        sentTodayKeys.add(`${log.invoiceId}_days_${log.triggerDays}`);
      }
    }
  });

  const enabledRules = rules.filter(r => r.enabled);

  invoices.forEach(inv => {
    // Only remind on outstanding invoices
    if (inv.outstandingAmount <= 0) return;
    if (inv.status === 'Paid' || inv.status === 'Disputed') return;

    const party = partyMap.get(inv.partyId);
    if (!party) return;

    // Calculate days relative to due date (negative = before, 0 = due today, positive = overdue)
    const daysDiff = calculateDaysBetween(inv.dueDate, todayStr);

    // Match exact rules or overdue buckets
    for (const rule of enabledRules) {
      let matches = false;

      if (rule.triggerType === 'days_before' && daysDiff === rule.days) {
        matches = true;
      } else if (rule.triggerType === 'on_due_date' && daysDiff === 0 && rule.days === 0) {
        matches = true;
      } else if (rule.triggerType === 'days_overdue') {
        if (rule.days === 60 && daysDiff >= 60) {
          // 60+ days rule
          matches = true;
        } else if (daysDiff === rule.days) {
          matches = true;
        }
      }

      if (matches) {
        const key = `${inv.id}_${rule.id}`;
        const alreadySent = sentTodayKeys.has(key);

        eligible.push({
          invoice: inv,
          party,
          rule,
          daysDiff,
          channels: rule.channels,
          alreadySentToday: alreadySent
        });
        break; // Match highest priority rule for this day
      }
    }
  });

  return eligible;
}

export function generateMessageId(): string {
  return `MSG-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
}

export function createCommunicationLogEntry(
  party: Party,
  invoice: Invoice | null,
  channel: Channel,
  type: CommunicationLog['type'],
  templateName: string,
  subject: string,
  body: string,
  status: 'Sent' | 'Delivered' | 'Failed' = 'Sent',
  ruleId?: string,
  triggerDays?: number,
  errorReason?: string
): CommunicationLog {
  const now = new Date().toISOString();
  const recipient = channel === 'Email' ? (party.email || 'missing-email@domain.com') : (party.phone || 'missing-phone');

  return {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    partyId: party.id,
    partyName: party.name,
    invoiceId: invoice?.id,
    invoiceNumber: invoice?.invoiceNumber,
    channel,
    type,
    templateName,
    recipient,
    subject: subject || (invoice ? `Payment Follow-up: ${invoice.invoiceNumber}` : 'Account Statement'),
    messageBody: body,
    sentAt: now,
    status,
    messageId: generateMessageId(),
    ruleId,
    triggerDays,
    errorReason,
    deliveredAt: status === 'Delivered' ? now : undefined
  };
}
