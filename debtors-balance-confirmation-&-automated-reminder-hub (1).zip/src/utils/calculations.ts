import { Invoice, InvoiceStatus, Party, RiskLevel, RiskThresholds, AgeingBucketSummary, DashboardMetrics } from '../types';

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDate(dateStr: string): Date {
  if (!dateStr) return new Date();
  // Support YYYY-MM-DD or DD/MM/YYYY or DD-MM-YYYY
  if (dateStr.includes('/')) {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        // DD/MM/YYYY
        return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
      }
    }
  }
  return new Date(dateStr);
}

export function formatDisplayDate(dateStr: string | undefined): string {
  if (!dateStr) return '-';
  try {
    const d = parseDate(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
}

export function formatDateTime(dateStr: string | undefined): string {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-GB', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return dateStr;
  }
}

export function calculateDaysBetween(startDateStr: string, endDateStr: string): number {
  const start = parseDate(startDateStr);
  const end = parseDate(endDateStr);
  start.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  const diffTime = end.getTime() - start.getTime();
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

export function calculateInvoiceMetrics(
  invDate: string,
  dueDate: string,
  amount: number,
  paidAmount: number = 0,
  referenceDateStr: string = getTodayDateString(),
  disputed: boolean = false,
  disputeReason?: string
): {
  outstandingAmount: number;
  daysOutstanding: number;
  daysOverdue: number;
  status: InvoiceStatus;
} {
  const outstandingAmount = Math.max(0, amount - paidAmount);
  const daysOutstanding = Math.max(0, calculateDaysBetween(invDate, referenceDateStr));
  const daysOverdue = calculateDaysBetween(dueDate, referenceDateStr);

  let status: InvoiceStatus = 'Current';

  if (outstandingAmount <= 0) {
    status = 'Paid';
  } else if (disputed) {
    status = 'Disputed';
  } else if (paidAmount > 0 && paidAmount < amount) {
    if (daysOverdue > 0) {
      status = 'Overdue';
    } else {
      status = 'Partially Paid';
    }
  } else if (daysOverdue > 0) {
    status = 'Overdue';
  } else if (daysOverdue === 0) {
    status = 'Due Today';
  } else if (daysOverdue >= -7 && daysOverdue < 0) {
    status = 'Due Soon';
  } else {
    status = 'Current';
  }

  return {
    outstandingAmount,
    daysOutstanding,
    daysOverdue: Math.max(0, daysOverdue),
    status
  };
}

export function calculatePartyRiskScore(
  totalOutstanding: number,
  overdueAmount: number,
  maxDaysOverdue: number,
  hasDisputes: boolean,
  thresholds: RiskThresholds
): RiskLevel {
  if (totalOutstanding <= 0) return 'Low';

  // Critical conditions
  if (
    maxDaysOverdue >= thresholds.criticalOverdueDays || 
    overdueAmount >= thresholds.criticalOutstandingAmount ||
    (totalOutstanding > 200000 && maxDaysOverdue >= 60)
  ) {
    return 'Critical';
  }

  // High conditions
  if (
    maxDaysOverdue >= thresholds.highOverdueDays ||
    (overdueAmount / totalOutstanding >= 0.75 && overdueAmount > 50000) ||
    hasDisputes
  ) {
    return 'High';
  }

  // Medium conditions
  if (
    maxDaysOverdue >= thresholds.mediumOverdueDays ||
    (overdueAmount > 0 && overdueAmount / totalOutstanding >= 0.4)
  ) {
    return 'Medium';
  }

  return 'Low';
}

export function getAgeingBucket(daysOverdue: number, isOutstanding: boolean): AgeingBucketSummary['bucket'] {
  if (!isOutstanding || daysOverdue <= 0) return 'Current (Not Due)';
  if (daysOverdue <= 30) return '1 - 30 Days';
  if (daysOverdue <= 60) return '31 - 60 Days';
  if (daysOverdue <= 90) return '61 - 90 Days';
  if (daysOverdue <= 180) return '91 - 180 Days';
  return '180+ Days';
}

export function calculateAgeingSummaries(invoices: Invoice[]): AgeingBucketSummary[] {
  const buckets: Record<AgeingBucketSummary['bucket'], { amount: number; invoiceCount: number; partySet: Set<string> }> = {
    'Current (Not Due)': { amount: 0, invoiceCount: 0, partySet: new Set() },
    '1 - 30 Days': { amount: 0, invoiceCount: 0, partySet: new Set() },
    '31 - 60 Days': { amount: 0, invoiceCount: 0, partySet: new Set() },
    '61 - 90 Days': { amount: 0, invoiceCount: 0, partySet: new Set() },
    '91 - 180 Days': { amount: 0, invoiceCount: 0, partySet: new Set() },
    '180+ Days': { amount: 0, invoiceCount: 0, partySet: new Set() },
  };

  let totalOutstanding = 0;

  invoices.forEach(inv => {
    if (inv.outstandingAmount > 0) {
      totalOutstanding += inv.outstandingAmount;
      const bucket = getAgeingBucket(inv.daysOverdue, true);
      buckets[bucket].amount += inv.outstandingAmount;
      buckets[bucket].invoiceCount += 1;
      buckets[bucket].partySet.add(inv.partyId);
    }
  });

  return (Object.keys(buckets) as AgeingBucketSummary['bucket'][]).map(bucketName => {
    const data = buckets[bucketName];
    return {
      bucket: bucketName,
      amount: data.amount,
      invoiceCount: data.invoiceCount,
      partyCount: data.partySet.size,
      percentage: totalOutstanding > 0 ? (data.amount / totalOutstanding) * 100 : 0
    };
  });
}

export function computeAgeingBuckets(parties: Party[], invoices: Invoice[]): AgeingBucketSummary[] {
  return calculateAgeingSummaries(invoices);
}

export function formatCurrency(amount: number, currency: string = '₹'): string {
  if (isNaN(amount) || amount === null || amount === undefined) return `${currency}0`;
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0
  }).format(Math.round(amount));
  return `${currency}${formatted}`;
}

export function formatCompactCurrency(amount: number, currency: string = '₹'): string {
  if (isNaN(amount) || amount === 0) return `${currency}0`;
  if (amount >= 10000000) {
    return `${currency}${(amount / 10000000).toFixed(2)} Cr`;
  }
  if (amount >= 100000) {
    return `${currency}${(amount / 100000).toFixed(2)} L`;
  }
  if (amount >= 1000) {
    return `${currency}${(amount / 1000).toFixed(1)} k`;
  }
  return formatCurrency(amount, currency);
}

export function computeDashboardMetrics(
  parties: Party[],
  invoices: Invoice[],
  commLogs: any[] = [],
  confirmations: any[] = [],
  todayRemindersCount: number = 0
): DashboardMetrics {
  let totalOutstanding = 0;
  let currentOutstanding = 0;
  let dueTodayAmount = 0;
  let dueTodayCount = 0;
  let dueIn7DaysAmount = 0;
  let dueIn7DaysCount = 0;
  let overdueAmount = 0;
  let overdueCount = 0;
  let totalInvoiced = 0;
  let totalCollected = 0;

  const todayStr = getTodayDateString();

  invoices.forEach(inv => {
    totalInvoiced += inv.amount;
    totalCollected += (inv.paidAmount || 0);

    if (inv.outstandingAmount > 0) {
      totalOutstanding += inv.outstandingAmount;
      const daysDiff = calculateDaysBetween(inv.dueDate, todayStr);

      if (daysDiff > 0) {
        overdueAmount += inv.outstandingAmount;
        overdueCount += 1;
      } else if (daysDiff === 0) {
        dueTodayAmount += inv.outstandingAmount;
        dueTodayCount += 1;
      } else if (daysDiff >= -7 && daysDiff < 0) {
        dueIn7DaysAmount += inv.outstandingAmount;
        dueIn7DaysCount += 1;
        currentOutstanding += inv.outstandingAmount;
      } else {
        currentOutstanding += inv.outstandingAmount;
      }
    }
  });

  const criticalRiskCount = parties.filter(p => p.riskScore === 'Critical').length;
  const highRiskCount = parties.filter(p => p.riskScore === 'High').length;

  const confirmationPendingCount = confirmations.filter(
    c => c.status === 'Sent' || c.status === 'Delivered' || c.status === 'Awaiting Confirmation'
  ).length;
  const confirmationConfirmedCount = confirmations.filter(c => c.status === 'Confirmed').length;
  const confirmationDisputedCount = confirmations.filter(c => c.status === 'Difference Reported').length;

  const failedCommunicationsCount = commLogs.filter(log => log.status === 'Failed').length;

  return {
    totalOutstanding,
    currentOutstanding,
    dueTodayAmount,
    dueTodayCount,
    dueIn7DaysAmount,
    dueIn7DaysCount,
    overdueAmount,
    overdueCount,
    totalDebtorsCount: parties.filter(p => p.totalOutstanding > 0).length,
    confirmationPendingCount,
    confirmationConfirmedCount,
    confirmationDisputedCount,
    remindersDueTodayCount: todayRemindersCount,
    failedCommunicationsCount,
    criticalRiskCount,
    highRiskCount,
    totalInvoiced,
    totalCollected
  };
}

export function generateReceiptNumber(): string {
  const prefix = 'REC';
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${year}-${rand}`;
}

export function generateMessageId(): string {
  return `MSG-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
}

export function generateConfirmationToken(): string {
  return `CONF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

export function addDaysToDate(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}
