import {
  AuditLog,
  BalanceConfirmation,
  CommunicationLog,
  Invoice,
  Party,
  PaymentRecord,
  SystemSettings,
  ValidatedExcelRow
} from '../types';
import {
  calculateDaysBetween,
  calculateInvoiceMetrics,
  calculatePartyRiskScore,
  getTodayDateString
} from './calculations';
import { DEFAULT_REMINDER_RULES } from './reminderEngine';

const STORAGE_KEYS = {
  PARTIES: 'debtors_app_parties_v2',
  INVOICES: 'debtors_app_invoices_v2',
  PAYMENTS: 'debtors_app_payments_v2',
  COMM_LOGS: 'debtors_app_comm_logs_v2',
  CONFIRMATIONS: 'debtors_app_confirmations_v2',
  AUDIT_LOGS: 'debtors_app_audit_logs_v2',
  SETTINGS: 'debtors_app_settings_v2',
  SESSION_USER: 'debtors_app_session_v2'
};

export const DEFAULT_SETTINGS: SystemSettings = {
  companyName: 'Nexis Enterprise Solutions Ltd',
  companyAddress: 'Unit 402, Trade Tower, Financial District, Mumbai 400051',
  companyEmail: 'finance@nexis-solutions.com',
  companyPhone: '+91 (22) 6789-4000',
  companyGstOrTaxId: '27AAACN1234F1Z8',
  bankDetails: {
    bankName: 'HDFC Bank - Corporate Banking Branch',
    accountNumber: '50200084920194',
    ifscCode: 'HDFC0000240',
    accountName: 'Nexis Enterprise Solutions Ltd',
    upiId: 'nexis.finance@hdfcbank'
  },
  currencySymbol: '₹',
  authorizedUser: {
    name: 'Vikramaditya Singhania',
    email: 'cfo@nexis-solutions.com',
    role: 'Chief Financial Officer',
    pin: '1234',
    passwordHash: 'cfo2026',
    sessionTimeoutMinutes: 30
  },
  riskThresholds: {
    mediumOverdueDays: 15,
    highOverdueDays: 30,
    criticalOverdueDays: 60,
    criticalOutstandingAmount: 250000
  },
  reminderRules: DEFAULT_REMINDER_RULES,
  senderConfig: {
    emailSender: 'Accounts Receivable <billing@nexis-solutions.com>',
    smsSenderId: 'NEXISF',
    whatsappBusinessNumber: '+919820011223',
    autoSendEnabled: true
  }
};

// Seed dataset generator
export function getInitialSeedData(): {
  parties: Party[];
  invoices: Invoice[];
  payments: PaymentRecord[];
  commLogs: CommunicationLog[];
  confirmations: BalanceConfirmation[];
  auditLogs: AuditLog[];
  settings: SystemSettings;
} {
  const today = getTodayDateString();

  const rawInvoicesData = [
    // Apex Solutions - Mumbai (Rajesh Sharma) - High overdue
    {
      invNo: 'INV-2026-0810',
      party: 'Apex Industrial Solutions Pvt Ltd',
      city: 'Mumbai',
      area: 'Andheri East MIDC',
      rep: 'Rajesh Sharma',
      email: 'finance@apexsolutions.in',
      phone: '+919820144552',
      date: '2026-05-15',
      dueDate: '2026-06-15',
      amount: 245000,
      paid: 0
    },
    {
      invNo: 'INV-2026-0888',
      party: 'Apex Industrial Solutions Pvt Ltd',
      city: 'Mumbai',
      area: 'Andheri East MIDC',
      rep: 'Rajesh Sharma',
      email: 'finance@apexsolutions.in',
      phone: '+919820144552',
      date: '2026-06-20',
      dueDate: '2026-07-20',
      amount: 135000,
      paid: 50000
    },
    // Zenith Polymers - Pune (Pooja Deshmukh) - Moderate overdue
    {
      invNo: 'INV-2026-0914',
      party: 'Zenith Polymer Works',
      city: 'Pune',
      area: 'Bhosari MIDC',
      rep: 'Pooja Deshmukh',
      email: 'accounts@zenithpolymers.com',
      phone: '+919890233119',
      date: '2026-07-01',
      dueDate: '2026-07-31',
      amount: 182500,
      paid: 0
    },
    {
      invNo: 'INV-2026-1020',
      party: 'Zenith Polymer Works',
      city: 'Pune',
      area: 'Bhosari MIDC',
      rep: 'Pooja Deshmukh',
      email: 'accounts@zenithpolymers.com',
      phone: '+919890233119',
      date: '2026-08-01',
      dueDate: '2026-08-31',
      amount: 98000,
      paid: 0
    },
    // BlueHorizon Logistics - Bengaluru (Kiran Kumar) - 7 days overdue
    {
      invNo: 'INV-2026-0975',
      party: 'BlueHorizon Logistics LLP',
      city: 'Bengaluru',
      area: 'Peenya 2nd Stage',
      rep: 'Kiran Kumar',
      email: 'billing@bluehorizonlogistics.com',
      phone: '+919448177663',
      date: '2026-07-18',
      dueDate: '2026-08-18',
      amount: 94000,
      paid: 0
    },
    // Nova Tech - Hyderabad (Sneha Reddy) - Due Today
    {
      invNo: 'INV-2026-1033',
      party: 'Nova Tech Dynamics',
      city: 'Hyderabad',
      area: 'HITEC City Phase 2',
      rep: 'Sneha Reddy',
      email: 'payments@novatech.co.in',
      phone: '+919849088221',
      date: '2026-07-26',
      dueDate: '2026-08-25', // Due today
      amount: 320000,
      paid: 0
    },
    // Vanguard Electro-Mech - Delhi (Amit Verma) - Due in 3 days
    {
      invNo: 'INV-2026-1050',
      party: 'Vanguard Electro-Mech Corp',
      city: 'Delhi NCR',
      area: 'Okhla Phase III',
      rep: 'Amit Verma',
      email: 'accounts@vanguardmech.com',
      phone: '+919811055443',
      date: '2026-07-28',
      dueDate: '2026-08-28', // Due in 3 days
      amount: 450000,
      paid: 100000
    },
    // Radiant Pharma - Ahmedabad (Rajesh Sharma) - 15 days overdue
    {
      invNo: 'INV-2026-0960',
      party: 'Radiant Pharma Labs Ltd',
      city: 'Ahmedabad',
      area: 'Sanand Industrial Estate',
      rep: 'Rajesh Sharma',
      email: 'finance@radiantpharmalabs.com',
      phone: '+919879011234',
      date: '2026-07-10',
      dueDate: '2026-08-10',
      amount: 275000,
      paid: 0
    },
    // Matrix Global Automation - Chennai (Kiran Kumar) - Critical (75 days overdue)
    {
      invNo: 'INV-2026-0780',
      party: 'Matrix Global Automation Pvt Ltd',
      city: 'Chennai',
      area: 'Ambattur Industrial Estate',
      rep: 'Kiran Kumar',
      email: 'accounts@matrixautomation.in',
      phone: '+919444055667',
      date: '2026-04-28',
      dueDate: '2026-05-30',
      amount: 380000,
      paid: 0
    },
    {
      invNo: 'INV-2026-0842',
      party: 'Matrix Global Automation Pvt Ltd',
      city: 'Chennai',
      area: 'Ambattur Industrial Estate',
      rep: 'Kiran Kumar',
      email: 'accounts@matrixautomation.in',
      phone: '+919444055667',
      date: '2026-05-25',
      dueDate: '2026-06-25',
      amount: 190000,
      paid: 0
    },
    // Surya Solar Systems - Jaipur (Amit Verma) - Due in 7 days
    {
      invNo: 'INV-2026-1070',
      party: 'Surya Solar & Energy Systems',
      city: 'Jaipur',
      area: 'Sitapura Industrial Area',
      rep: 'Amit Verma',
      email: 'billing@suryasolar.in',
      phone: '+919829033445',
      date: '2026-08-01',
      dueDate: '2026-09-01', // Due in 7 days
      amount: 145000,
      paid: 0
    },
    // Orion Steel & Alloys - Kolkata (Rajesh Sharma) - 3 days overdue
    {
      invNo: 'INV-2026-0992',
      party: 'Orion Steel & Alloys Corp',
      city: 'Kolkata',
      area: 'Taratala Industrial Area',
      rep: 'Rajesh Sharma',
      email: 'finance@orionsteel.com',
      phone: '+919830022334',
      date: '2026-07-22',
      dueDate: '2026-08-22', // 3 days overdue
      amount: 210000,
      paid: 0
    },
    // Quantum Cloud Infrastructure - Bengaluru (Kiran Kumar) - Current
    {
      invNo: 'INV-2026-1085',
      party: 'Quantum Cloud Infrastructure Ltd',
      city: 'Bengaluru',
      area: 'Whitefield Tech Zone',
      rep: 'Kiran Kumar',
      email: 'ap@quantumcloudinfra.com',
      phone: '+919880099881',
      date: '2026-08-10',
      dueDate: '2026-09-10',
      amount: 360000,
      paid: 0
    },
    // Emerald Packaging - Surat (Pooja Deshmukh) - Fully Paid
    {
      invNo: 'INV-2026-0940',
      party: 'Emerald Packaging Solutions',
      city: 'Surat',
      area: 'Sachin GIDC',
      rep: 'Pooja Deshmukh',
      email: 'accounts@emeraldpackaging.in',
      phone: '+919825044332',
      date: '2026-07-05',
      dueDate: '2026-08-05',
      amount: 115000,
      paid: 115000
    }
  ];

  // Map to structured invoices & compute party master
  const partiesMap = new Map<string, Party>();
  const invoices: Invoice[] = [];

  rawInvoicesData.forEach((item, idx) => {
    const partyId = `party_${item.party.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    const invMetrics = calculateInvoiceMetrics(item.date, item.dueDate, item.amount, item.paid, today);

    const invoice: Invoice = {
      id: `inv_${idx + 100}`,
      invoiceNumber: item.invNo,
      partyId,
      partyName: item.party,
      invoiceDate: item.date,
      dueDate: item.dueDate,
      amount: item.amount,
      paidAmount: item.paid,
      outstandingAmount: invMetrics.outstandingAmount,
      daysOutstanding: invMetrics.daysOutstanding,
      daysOverdue: invMetrics.daysOverdue,
      status: invMetrics.status,
      city: item.city,
      area: item.area,
      representativeName: item.rep,
      email: item.email,
      phone: item.phone,
      remindersSentCount: invMetrics.daysOverdue > 0 ? (invMetrics.daysOverdue > 30 ? 3 : 1) : 0,
      lastReminderDate: invMetrics.daysOverdue > 0 ? '2026-08-20' : undefined,
      createdAt: item.date,
      updatedAt: today
    };

    invoices.push(invoice);

    if (!partiesMap.has(partyId)) {
      partiesMap.set(partyId, {
        id: partyId,
        name: item.party,
        email: item.email,
        phone: item.phone,
        city: item.city,
        area: item.area,
        representativeName: item.rep,
        creditLimit: item.amount * 2.5,
        riskScore: 'Low',
        totalInvoiced: 0,
        totalPaid: 0,
        totalOutstanding: 0,
        overdueAmount: 0,
        maxDaysOverdue: 0,
        invoiceCount: 0,
        overdueInvoiceCount: 0,
        status: 'Active',
        confirmationStatus: 'Not Sent',
        createdAt: item.date,
        updatedAt: today
      });
    }

    const party = partiesMap.get(partyId)!;
    party.totalInvoiced += item.amount;
    party.totalPaid += item.paid;
    party.totalOutstanding += invMetrics.outstandingAmount;
    party.invoiceCount += 1;
    if (invMetrics.daysOverdue > 0 && invMetrics.outstandingAmount > 0) {
      party.overdueAmount += invMetrics.outstandingAmount;
      party.overdueInvoiceCount += 1;
      party.maxDaysOverdue = Math.max(party.maxDaysOverdue, invMetrics.daysOverdue);
    }
  });

  const parties = Array.from(partiesMap.values()).map(p => {
    p.riskScore = calculatePartyRiskScore(
      p.totalOutstanding,
      p.overdueAmount,
      p.maxDaysOverdue,
      p.name.includes('Matrix') || p.name.includes('Apex'),
      DEFAULT_SETTINGS.riskThresholds
    );
    if (p.riskScore === 'Critical') {
      p.status = 'On Hold';
    }
    return p;
  });

  // Seed payments
  const payments: PaymentRecord[] = [
    {
      id: 'pay_101',
      invoiceId: 'inv_101',
      invoiceNumber: 'INV-2026-0888',
      partyId: parties[0].id,
      partyName: parties[0].name,
      paymentDate: '2026-08-10',
      amount: 50000,
      paymentMode: 'Bank Transfer (NEFT/RTGS)',
      referenceNumber: 'NEFT-HDFC-994821',
      notes: 'Part payment received towards INV-2026-0888',
      recordedBy: 'Vikramaditya Singhania',
      createdAt: '2026-08-10T14:30:00Z'
    },
    {
      id: 'pay_102',
      invoiceId: 'inv_106',
      invoiceNumber: 'INV-2026-1050',
      partyId: 'party_vanguard_electro_mech_corp',
      partyName: 'Vanguard Electro-Mech Corp',
      paymentDate: '2026-08-18',
      amount: 100000,
      paymentMode: 'Bank Transfer (NEFT/RTGS)',
      referenceNumber: 'RTGS-ICICI-004491',
      notes: 'Advance installment',
      recordedBy: 'Vikramaditya Singhania',
      createdAt: '2026-08-18T11:15:00Z'
    },
    {
      id: 'pay_103',
      invoiceId: 'inv_113',
      invoiceNumber: 'INV-2026-0940',
      partyId: 'party_emerald_packaging_solutions',
      partyName: 'Emerald Packaging Solutions',
      paymentDate: '2026-08-04',
      amount: 115000,
      paymentMode: 'UPI',
      referenceNumber: 'UPI-AXIS-883109923',
      notes: 'Full settlement on time',
      recordedBy: 'Vikramaditya Singhania',
      createdAt: '2026-08-04T09:20:00Z'
    }
  ];

  // Seed Balance Confirmations
  const confirmations: BalanceConfirmation[] = [
    {
      id: 'conf_101',
      partyId: parties[0].id,
      partyName: parties[0].name,
      email: parties[0].email,
      phone: parties[0].phone,
      token: 'tok_apex_q2_2026',
      expiresAt: '2026-09-30T23:59:59Z',
      asOfDate: '2026-08-25',
      totalLedgerBalance: 330000,
      invoices: [
        {
          invoiceNumber: 'INV-2026-0810',
          date: '2026-05-15',
          dueDate: '2026-06-15',
          originalAmount: 245000,
          paidAmount: 0,
          outstanding: 245000,
          status: 'Overdue (71 Days)'
        },
        {
          invoiceNumber: 'INV-2026-0888',
          date: '2026-06-20',
          dueDate: '2026-07-20',
          originalAmount: 135000,
          paidAmount: 50000,
          outstanding: 85000,
          status: 'Overdue (36 Days)'
        }
      ],
      status: 'Difference Reported',
      sentAt: '2026-08-22T10:00:00Z',
      channelSent: 'Email',
      respondedAt: '2026-08-23T16:45:00Z',
      confirmedAmount: 285000,
      differenceAmount: 45000,
      differenceReason: 'Debit Note / Return for Damaged Goods on INV-2026-0810',
      customerRemarks: 'We returned batch #B-409 items worth ₹45,000 against INV-2026-0810 on 28-May. Awaiting formal Credit Note credit.',
      customerSignatoryName: 'Harish Mehta',
      customerSignatoryDesignation: 'Head of Finance & Procurement',
      financeActionStatus: 'Pending Review',
      financeActionNotes: 'Warehouse check needed for batch B-409 return receipt.'
    },
    {
      id: 'conf_102',
      partyId: parties[1].id,
      partyName: parties[1].name,
      email: parties[1].email,
      phone: parties[1].phone,
      token: 'tok_zenith_q2_2026',
      expiresAt: '2026-09-30T23:59:59Z',
      asOfDate: '2026-08-25',
      totalLedgerBalance: 280500,
      invoices: [
        {
          invoiceNumber: 'INV-2026-0914',
          date: '2026-07-01',
          dueDate: '2026-07-31',
          originalAmount: 182500,
          paidAmount: 0,
          outstanding: 182500,
          status: 'Overdue (25 Days)'
        },
        {
          invoiceNumber: 'INV-2026-1020',
          date: '2026-08-01',
          dueDate: '2026-08-31',
          originalAmount: 98000,
          paidAmount: 0,
          outstanding: 98000,
          status: 'Current'
        }
      ],
      status: 'Confirmed',
      sentAt: '2026-08-20T11:00:00Z',
      channelSent: 'Email',
      respondedAt: '2026-08-21T14:10:00Z',
      confirmedAmount: 280500,
      customerRemarks: 'Verified against our books. Processing payment batch next Tuesday.',
      customerSignatoryName: 'Sunil Kulkarni',
      customerSignatoryDesignation: 'Chief Accountant',
      financeActionStatus: 'Resolved - Proof Verified'
    },
    {
      id: 'conf_103',
      partyId: parties[2].id,
      partyName: parties[2].name,
      email: parties[2].email,
      phone: parties[2].phone,
      token: 'tok_bluehorizon_q2_2026',
      expiresAt: '2026-09-30T23:59:59Z',
      asOfDate: '2026-08-25',
      totalLedgerBalance: 94000,
      invoices: [
        {
          invoiceNumber: 'INV-2026-0975',
          date: '2026-07-18',
          dueDate: '2026-08-18',
          originalAmount: 94000,
          paidAmount: 0,
          outstanding: 94000,
          status: 'Overdue (7 Days)'
        }
      ],
      status: 'Awaiting Confirmation',
      sentAt: '2026-08-24T09:30:00Z',
      channelSent: 'WhatsApp'
    }
  ];

  // Update party confirmation statuses to match
  parties[0].confirmationStatus = 'Difference Reported';
  parties[0].lastConfirmationToken = 'tok_apex_q2_2026';
  parties[0].lastConfirmationDate = '2026-08-23';

  parties[1].confirmationStatus = 'Confirmed';
  parties[1].lastConfirmationToken = 'tok_zenith_q2_2026';
  parties[1].lastConfirmationDate = '2026-08-21';

  parties[2].confirmationStatus = 'Awaiting Confirmation';
  parties[2].lastConfirmationToken = 'tok_bluehorizon_q2_2026';
  parties[2].lastConfirmationDate = '2026-08-24';

  // Seed Communication Logs
  const commLogs: CommunicationLog[] = [
    {
      id: 'comm_001',
      partyId: parties[0].id,
      partyName: parties[0].name,
      invoiceId: 'inv_100',
      invoiceNumber: 'INV-2026-0810',
      channel: 'Email',
      type: 'Automated Reminder',
      templateName: '60+ Days Overdue (Legal / CFO Escalation)',
      recipient: 'finance@apexsolutions.in',
      subject: 'CRITICAL OVERDUE NOTICE: Invoice #INV-2026-0810 (60+ Days Overdue)',
      messageBody: 'Formal notice regarding overdue ₹245,000 for Invoice #INV-2026-0810. Legal escalation pending.',
      sentAt: '2026-08-20T10:15:00Z',
      status: 'Delivered',
      messageId: 'MSG-APX-8821',
      ruleId: 'rule_overdue_60',
      triggerDays: 60,
      deliveredAt: '2026-08-20T10:15:20Z'
    },
    {
      id: 'comm_002',
      partyId: parties[0].id,
      partyName: parties[0].name,
      channel: 'Email',
      type: 'Balance Confirmation Request',
      templateName: 'Q2 2026 Balance Confirmation',
      recipient: 'finance@apexsolutions.in',
      subject: 'Balance Confirmation Request as of 25-Aug-2026 - Nexis Enterprise Solutions Ltd',
      messageBody: 'Please review and confirm outstanding balance of ₹330,000.00.',
      sentAt: '2026-08-22T10:00:00Z',
      status: 'Delivered',
      messageId: 'MSG-CONF-APX',
      deliveredAt: '2026-08-22T10:00:15Z'
    },
    {
      id: 'comm_003',
      partyId: parties[1].id,
      partyName: parties[1].name,
      channel: 'Email',
      type: 'Balance Confirmation Request',
      templateName: 'Q2 2026 Balance Confirmation',
      recipient: 'accounts@zenithpolymers.com',
      subject: 'Balance Confirmation Request as of 25-Aug-2026',
      messageBody: 'Please verify ledger balance ₹280,500.',
      sentAt: '2026-08-20T11:00:00Z',
      status: 'Delivered',
      messageId: 'MSG-CONF-ZEN',
      deliveredAt: '2026-08-20T11:00:12Z'
    },
    {
      id: 'comm_004',
      partyId: parties[2].id,
      partyName: parties[2].name,
      invoiceId: 'inv_104',
      invoiceNumber: 'INV-2026-0975',
      channel: 'WhatsApp',
      type: 'Automated Reminder',
      templateName: '7 Days Overdue',
      recipient: '+919448177663',
      subject: 'WhatsApp Alert: Invoice #INV-2026-0975',
      messageBody: '⚠️ URGENT PAYMENT ALERT: Invoice #INV-2026-0975 for ₹94,000 is 7 days overdue.',
      sentAt: '2026-08-24T09:30:00Z',
      status: 'Delivered',
      messageId: 'MSG-WA-BLU-01',
      ruleId: 'rule_overdue_7',
      triggerDays: 7,
      deliveredAt: '2026-08-24T09:30:05Z'
    },
    {
      id: 'comm_005',
      partyId: 'party_matrix_global_automation_pvt_ltd',
      partyName: 'Matrix Global Automation Pvt Ltd',
      channel: 'SMS',
      type: 'Automated Reminder',
      templateName: '60+ Days Overdue',
      recipient: '+919444055667',
      subject: 'SMS Warning',
      messageBody: 'LEGAL WARNING: Inv #INV-2026-0780 (₹380,000) 60+ days overdue. Clear in 48h.',
      sentAt: '2026-08-24T12:00:00Z',
      status: 'Delivered',
      messageId: 'MSG-SMS-MTX-01',
      ruleId: 'rule_overdue_60',
      triggerDays: 60
    }
  ];

  // Seed Audit Logs
  const auditLogs: AuditLog[] = [
    {
      id: 'audit_001',
      action: 'System Initialized',
      entityType: 'Security',
      details: 'Debtors Hub master database initialized with sample dataset.',
      user: 'Vikramaditya Singhania (CFO)',
      timestamp: '2026-08-25T01:00:00Z'
    },
    {
      id: 'audit_002',
      action: 'Excel Batch Upload',
      entityType: 'Excel Import',
      details: 'Imported 14 customer invoices across Mumbai, Pune, Bengaluru, Delhi NCR, and Chennai.',
      user: 'Vikramaditya Singhania (CFO)',
      timestamp: '2026-08-25T01:05:00Z'
    },
    {
      id: 'audit_003',
      action: 'Balance Confirmation Discrepancy Logged',
      entityType: 'Confirmation',
      entityId: 'conf_101',
      details: 'Apex Industrial Solutions reported ₹45,000 difference (Claim: Goods return batch B-409).',
      user: 'Customer Signatory: Harish Mehta',
      timestamp: '2026-08-23T16:45:00Z'
    },
    {
      id: 'audit_004',
      action: 'Balance Confirmed Signed',
      entityType: 'Confirmation',
      entityId: 'conf_102',
      details: 'Zenith Polymer Works confirmed ledger balance ₹280,500 without discrepancy.',
      user: 'Customer Signatory: Sunil Kulkarni',
      timestamp: '2026-08-21T14:10:00Z'
    }
  ];

  return {
    parties,
    invoices,
    payments,
    commLogs,
    confirmations,
    auditLogs,
    settings: DEFAULT_SETTINGS
  };
}

export class StorageManager {
  static loadData() {
    try {
      const storedParties = localStorage.getItem(STORAGE_KEYS.PARTIES);
      const storedInvoices = localStorage.getItem(STORAGE_KEYS.INVOICES);
      const storedPayments = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
      const storedLogs = localStorage.getItem(STORAGE_KEYS.COMM_LOGS);
      const storedConfirmations = localStorage.getItem(STORAGE_KEYS.CONFIRMATIONS);
      const storedAudit = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const storedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);

      if (storedParties && storedInvoices) {
        return {
          parties: JSON.parse(storedParties) as Party[],
          invoices: JSON.parse(storedInvoices) as Invoice[],
          payments: storedPayments ? (JSON.parse(storedPayments) as PaymentRecord[]) : [],
          commLogs: storedLogs ? (JSON.parse(storedLogs) as CommunicationLog[]) : [],
          confirmations: storedConfirmations ? (JSON.parse(storedConfirmations) as BalanceConfirmation[]) : [],
          auditLogs: storedAudit ? (JSON.parse(storedAudit) as AuditLog[]) : [],
          settings: storedSettings ? (JSON.parse(storedSettings) as SystemSettings) : DEFAULT_SETTINGS
        };
      }
    } catch (e) {
      console.warn('Could not load from localStorage, initializing fresh seeds', e);
    }

    const initial = getInitialSeedData();
    StorageManager.saveAll(initial);
    return initial;
  }

  static saveAll(data: {
    parties: Party[];
    invoices: Invoice[];
    payments: PaymentRecord[];
    commLogs: CommunicationLog[];
    confirmations: BalanceConfirmation[];
    auditLogs: AuditLog[];
    settings: SystemSettings;
  }) {
    try {
      localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(data.parties));
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(data.invoices));
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(data.payments));
      localStorage.setItem(STORAGE_KEYS.COMM_LOGS, JSON.stringify(data.commLogs));
      localStorage.setItem(STORAGE_KEYS.CONFIRMATIONS, JSON.stringify(data.confirmations));
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(data.auditLogs));
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }

  static getParties(): Party[] {
    return this.loadData().parties;
  }

  static getInvoices(): Invoice[] {
    return this.loadData().invoices;
  }

  static getPayments(): PaymentRecord[] {
    return this.loadData().payments;
  }

  static getCommLogs(): CommunicationLog[] {
    return this.loadData().commLogs;
  }

  static getConfirmations(): BalanceConfirmation[] {
    return this.loadData().confirmations;
  }

  static getSettings(): SystemSettings {
    return this.loadData().settings;
  }

  static getAuditLogs(): AuditLog[] {
    return this.loadData().auditLogs;
  }

  static saveParties(parties: Party[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(parties));
    } catch (e) {
      console.error(e);
    }
  }

  static saveInvoices(invoices: Invoice[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    } catch (e) {
      console.error(e);
    }
  }

  static savePayments(payments: PaymentRecord[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    } catch (e) {
      console.error(e);
    }
  }

  static saveCommLogs(logs: CommunicationLog[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.COMM_LOGS, JSON.stringify(logs));
    } catch (e) {
      console.error(e);
    }
  }

  static saveConfirmations(confirmations: BalanceConfirmation[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIRMATIONS, JSON.stringify(confirmations));
    } catch (e) {
      console.error(e);
    }
  }

  static saveSettings(settings: SystemSettings) {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  }

  static addAuditLog(action: string, details: string, user: string = 'Authorized CFO', role: string = 'Chief Financial Officer'): AuditLog {
    const newLog: AuditLog = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      action,
      details,
      user,
      performedBy: user,
      userRole: role,
      timestamp: new Date().toISOString()
    };

    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const list: AuditLog[] = raw ? JSON.parse(raw) : [];
      list.unshift(newLog);
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(list.slice(0, 500)));
    } catch (e) {
      console.error('Failed to save audit log', e);
    }

    return newLog;
  }

  static resetToDemo() {
    const initial = getInitialSeedData();
    this.saveAll(initial);
    return initial;
  }

  static recordAudit(
    action: string,
    entityType: AuditLog['entityType'],
    details: string,
    entityId?: string,
    user: string = 'Authorized CFO'
  ): AuditLog {
    const newLog: AuditLog = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      action,
      entityType,
      entityId,
      details,
      user,
      timestamp: new Date().toISOString()
    };

    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const list: AuditLog[] = raw ? JSON.parse(raw) : [];
      list.unshift(newLog);
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(list.slice(0, 500)));
    } catch (e) {
      console.error('Failed to save audit log', e);
    }

    return newLog;
  }

  static recalculateEntities(
    invoices: Invoice[],
    parties: Party[],
    settings: SystemSettings,
    referenceDate: string = getTodayDateString()
  ): { updatedInvoices: Invoice[]; updatedParties: Party[] } {
    const updatedInvoices = invoices.map(inv => {
      const metrics = calculateInvoiceMetrics(
        inv.invoiceDate,
        inv.dueDate,
        inv.amount,
        inv.paidAmount,
        referenceDate,
        inv.status === 'Disputed',
        inv.disputeReason
      );
      return {
        ...inv,
        outstandingAmount: metrics.outstandingAmount,
        daysOutstanding: metrics.daysOutstanding,
        daysOverdue: metrics.daysOverdue,
        status: metrics.status
      };
    });

    const partyMap = new Map<string, Party>();
    parties.forEach(p => {
      partyMap.set(p.id, {
        ...p,
        totalInvoiced: 0,
        totalPaid: 0,
        totalOutstanding: 0,
        overdueAmount: 0,
        maxDaysOverdue: 0,
        invoiceCount: 0,
        overdueInvoiceCount: 0
      });
    });

    updatedInvoices.forEach(inv => {
      if (!partyMap.has(inv.partyId)) {
        partyMap.set(inv.partyId, {
          id: inv.partyId,
          name: inv.partyName,
          email: inv.email,
          phone: inv.phone,
          city: inv.city,
          area: inv.area,
          representativeName: inv.representativeName,
          creditLimit: inv.amount * 2,
          riskScore: 'Low',
          totalInvoiced: 0,
          totalPaid: 0,
          totalOutstanding: 0,
          overdueAmount: 0,
          maxDaysOverdue: 0,
          invoiceCount: 0,
          overdueInvoiceCount: 0,
          status: 'Active',
          confirmationStatus: 'Not Sent',
          createdAt: inv.invoiceDate,
          updatedAt: referenceDate
        });
      }

      const party = partyMap.get(inv.partyId)!;
      party.totalInvoiced += inv.amount;
      party.totalPaid += inv.paidAmount;
      party.totalOutstanding += inv.outstandingAmount;
      party.invoiceCount += 1;
      if (inv.daysOverdue > 0 && inv.outstandingAmount > 0) {
        party.overdueAmount += inv.outstandingAmount;
        party.overdueInvoiceCount += 1;
        party.maxDaysOverdue = Math.max(party.maxDaysOverdue, inv.daysOverdue);
      }
    });

    const updatedParties = Array.from(partyMap.values()).map(p => {
      p.riskScore = calculatePartyRiskScore(
        p.totalOutstanding,
        p.overdueAmount,
        p.maxDaysOverdue,
        p.status === 'Disputed',
        settings.riskThresholds
      );
      return p;
    });

    return { updatedInvoices, updatedParties };
  }
}
