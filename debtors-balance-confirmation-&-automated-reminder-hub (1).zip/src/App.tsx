import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  AuditLog,
  BalanceConfirmation,
  CommunicationLog,
  Invoice,
  Party,
  PaymentRecord,
  SystemSettings
} from './types';
import { StorageManager } from './utils/storage';
import {
  computeAgeingBuckets,
  computeDashboardMetrics,
  generateReceiptNumber,
  generateMessageId,
  generateConfirmationToken,
  getTodayDateString,
  addDaysToDate,
  formatCurrency
} from './utils/calculations';
import { findEligibleReminders, EligibleReminder, replacePlaceholders } from './utils/reminderEngine';

// Components
import { Header, NavTab } from './components/Header';
import { AuthLockScreen } from './components/AuthLockScreen';
import { Dashboard } from './components/Dashboard';
import { DebtorsList } from './components/DebtorsList';
import { InvoicesList } from './components/InvoicesList';
import { AgeingAnalysis } from './components/AgeingAnalysis';
import { BalanceConfirmationHub } from './components/BalanceConfirmationHub';
import { CommunicationsHub } from './components/CommunicationsHub';
import { AnalyticsView } from './components/AnalyticsView';
import { UploadView } from './components/UploadView';
import { SettingsView } from './components/SettingsView';
import { CustomerPortal } from './components/CustomerPortal';

// Modals
import { PaymentModal } from './components/PaymentModal';
import { StatementOfAccountModal } from './components/StatementOfAccountModal';
import { ReminderModal } from './components/ReminderModal';
import { DifferenceResolutionModal } from './components/DifferenceResolutionModal';

export const App: React.FC = () => {
  // Authentication & Session
  const [isUnlocked, setIsUnlocked] = useState<boolean>(true);

  // Core Data State
  const [parties, setParties] = useState<Party[]>(() => StorageManager.getParties());
  const [invoices, setInvoices] = useState<Invoice[]>(() => StorageManager.getInvoices());
  const [payments, setPayments] = useState<PaymentRecord[]>(() => StorageManager.getPayments());
  const [commLogs, setCommLogs] = useState<CommunicationLog[]>(() => StorageManager.getCommLogs());
  const [confirmations, setConfirmations] = useState<BalanceConfirmation[]>(() => StorageManager.getConfirmations());
  const [settings, setSettings] = useState<SystemSettings>(() => StorageManager.getSettings());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => StorageManager.getAuditLogs());

  // Navigation State
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [navFilterPreset, setNavFilterPreset] = useState<string | undefined>(undefined);

  // Customer Portal preview state
  const [portalToken, setPortalToken] = useState<string | null>(null);

  // Modals & Selected items state
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);
  const [statementModalParty, setStatementModalParty] = useState<Party | null>(null);
  
  // Payment Modal
  const [paymentModalData, setPaymentModalData] = useState<{
    isOpen: boolean;
    invoice?: Invoice;
    party?: Party;
  }>({ isOpen: false });

  // Reminder Modal
  const [reminderModalData, setReminderModalData] = useState<{
    isOpen: boolean;
    party: Party | null;
    invoice?: Invoice;
  }>({ isOpen: false, party: null });

  // Difference Resolution Modal
  const [differenceModalConf, setDifferenceModalConf] = useState<BalanceConfirmation | null>(null);

  // Check URL hash for direct customer portal links (e.g. #/portal/:token)
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/portal/')) {
        const token = hash.replace('#/portal/', '').trim();
        setPortalToken(token);
      } else {
        setPortalToken(null);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Compute Metrics & Ageing summaries
  const metrics = useMemo(() => {
    return computeDashboardMetrics(parties, invoices, confirmations, commLogs);
  }, [parties, invoices, confirmations, commLogs]);

  const ageingSummaries = useMemo(() => {
    return computeAgeingBuckets(parties, invoices);
  }, [parties, invoices]);

  const todayEligibleReminders = useMemo(() => {
    return findEligibleReminders(invoices, parties, settings.reminderRules, commLogs);
  }, [invoices, parties, settings.reminderRules, commLogs]);

  // Handler: Navigation
  const handleNavigate = (tab: NavTab, filter?: string) => {
    setNavFilterPreset(filter);
    setActiveTab(tab);
  };

  // Handler: Record Payment
  const handleRecordPayment = (
    partyId: string,
    invoiceId: string | undefined,
    amount: number,
    paymentDate: string,
    paymentMode: PaymentRecord['paymentMode'],
    referenceNumber: string,
    notes?: string
  ) => {
    const party = parties.find(p => p.id === partyId);
    if (!party) return;

    const receiptNumber = generateReceiptNumber();
    const newPayment: PaymentRecord = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      receiptNumber,
      partyId,
      partyName: party.name,
      invoiceId,
      invoiceNumber: invoiceId ? invoices.find(i => i.id === invoiceId)?.invoiceNumber : undefined,
      amount,
      paymentDate,
      paymentMode,
      referenceNumber,
      notes,
      recordedBy: settings.authorizedUser.name,
      createdAt: new Date().toISOString()
    };

    // Update invoices
    let updatedInvoices = [...invoices];
    if (invoiceId) {
      updatedInvoices = updatedInvoices.map(inv => {
        if (inv.id === invoiceId) {
          const newPaid = inv.paidAmount + amount;
          const newOutstanding = Math.max(0, inv.amount - newPaid);
          const newStatus = newOutstanding === 0 ? 'Paid' : 'Partially Paid';
          return {
            ...inv,
            paidAmount: newPaid,
            outstandingAmount: newOutstanding,
            status: newStatus,
            updatedAt: new Date().toISOString()
          };
        }
        return inv;
      });
    } else {
      // FIFO adjustment against party's oldest open invoices
      let remaining = amount;
      const partyInvs = updatedInvoices
        .filter(i => i.partyId === partyId && i.outstandingAmount > 0)
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate));

      for (const inv of partyInvs) {
        if (remaining <= 0) break;
        const settle = Math.min(remaining, inv.outstandingAmount);
        const newPaid = inv.paidAmount + settle;
        const newOutstanding = inv.amount - newPaid;
        const newStatus = newOutstanding === 0 ? 'Paid' : 'Partially Paid';

        updatedInvoices = updatedInvoices.map(i => i.id === inv.id ? {
          ...i,
          paidAmount: newPaid,
          outstandingAmount: newOutstanding,
          status: newStatus,
          updatedAt: new Date().toISOString()
        } : i);

        remaining -= settle;
      }
    }

    // Recalculate party
    const partyInvs = updatedInvoices.filter(i => i.partyId === partyId);
    const totalInvoiced = partyInvs.reduce((sum, i) => sum + i.amount, 0);
    const totalPaid = partyInvs.reduce((sum, i) => sum + i.paidAmount, 0);
    const totalOutstanding = partyInvs.reduce((sum, i) => sum + i.outstandingAmount, 0);
    const overdueAmount = partyInvs.filter(i => i.daysOverdue > 0).reduce((sum, i) => sum + i.outstandingAmount, 0);
    const maxDaysOverdue = partyInvs.reduce((max, i) => Math.max(max, i.daysOverdue), 0);

    const updatedParties = parties.map(p => p.id === partyId ? {
      ...p,
      totalInvoiced,
      totalPaid,
      totalOutstanding,
      overdueAmount,
      maxDaysOverdue,
      updatedAt: new Date().toISOString()
    } : p);

    const updatedPayments = [newPayment, ...payments];
    const logText = `Recorded ${paymentMode} payment of ${formatCurrency(amount, settings.currencySymbol)} for ${party.name} (Receipt #${receiptNumber}, Ref #${referenceNumber})`;

    StorageManager.saveInvoices(updatedInvoices);
    StorageManager.saveParties(updatedParties);
    StorageManager.savePayments(updatedPayments);
    StorageManager.addAuditLog('RECORD_PAYMENT', logText, settings.authorizedUser.name, settings.authorizedUser.role);

    setInvoices(updatedInvoices);
    setParties(updatedParties);
    setPayments(updatedPayments);
    setAuditLogs(StorageManager.getAuditLogs());
    setPaymentModalData({ isOpen: false });
  };

  // Handler: Send Single Reminder
  const handleSendReminder = (
    party: Party,
    invoice: Invoice | undefined,
    channels: ('Email' | 'WhatsApp' | 'SMS')[],
    templateName: string,
    messageBody: string
  ) => {
    const newLogs: CommunicationLog[] = [];

    channels.forEach(ch => {
      const recipient = ch === 'Email' ? party.email : party.phone;
      const log: CommunicationLog = {
        id: `comm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        messageId: generateMessageId(),
        partyId: party.id,
        partyName: party.name,
        invoiceId: invoice?.id,
        invoiceNumber: invoice?.invoiceNumber,
        type: 'Reminder',
        channel: ch,
        templateName,
        recipient: recipient || 'No contact provided',
        subject: `Payment Reminder - ${party.name}`,
        messageBody,
        status: recipient ? 'Delivered' : 'Failed',
        errorReason: recipient ? undefined : 'Missing contact phone/email address',
        sentAt: new Date().toISOString(),
        deliveredAt: recipient ? new Date().toISOString() : undefined,
        metadata: {
          outstandingAmount: invoice ? invoice.outstandingAmount : party.totalOutstanding,
          dueDate: invoice?.dueDate
        }
      };
      newLogs.push(log);
    });

    const updatedLogs = [...newLogs, ...commLogs];
    StorageManager.saveCommLogs(updatedLogs);
    StorageManager.addAuditLog(
      'SEND_REMINDER',
      `Dispatched reminder notice to ${party.name} across [${channels.join(', ')}]`,
      settings.authorizedUser.name,
      settings.authorizedUser.role
    );

    setCommLogs(updatedLogs);
    setAuditLogs(StorageManager.getAuditLogs());
    setReminderModalData({ isOpen: false, party: null });
  };

  // Handler: Run Batch Reminders for Today
  const handleRunBatchReminders = (reminders: EligibleReminder[]) => {
    if (reminders.length === 0) return;

    const newLogs: CommunicationLog[] = [];

    reminders.forEach(rem => {
      const templateRaw = rem.rule.emailTemplate || rem.rule.whatsappTemplate || rem.rule.smsTemplate || rem.rule.template || '';
      const body = replacePlaceholders(templateRaw, rem.party, rem.invoice, settings);
      rem.channels.forEach(ch => {
        const recipient = ch === 'Email' ? rem.party.email : rem.party.phone;
        const log: CommunicationLog = {
          id: `comm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          messageId: generateMessageId(),
          partyId: rem.party.id,
          partyName: rem.party.name,
          invoiceId: rem.invoice.id,
          invoiceNumber: rem.invoice.invoiceNumber,
          type: 'Reminder',
          channel: ch,
          templateName: rem.rule.label,
          recipient: recipient || 'No contact',
          subject: `Automated Reminder: Invoice #${rem.invoice.invoiceNumber}`,
          messageBody: body,
          status: recipient ? 'Delivered' : 'Failed',
          sentAt: new Date().toISOString(),
          deliveredAt: recipient ? new Date().toISOString() : undefined,
          metadata: {
            ruleId: rem.rule.id,
            daysOverdue: rem.invoice.daysOverdue
          }
        };
        newLogs.push(log);
      });
    });

    const updatedLogs = [...newLogs, ...commLogs];
    StorageManager.saveCommLogs(updatedLogs);
    StorageManager.addAuditLog(
      'BATCH_REMINDER_RUN',
      `Executed Automated Reminder engine for ${reminders.length} invoices (${newLogs.length} total messages)`,
      settings.authorizedUser.name,
      settings.authorizedUser.role
    );

    setCommLogs(updatedLogs);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Launch Balance Confirmation Campaign
  const handleCreateConfirmationRun = (partyIds: string[], asOfDate: string, expiryDays: number) => {
    const expiresAt = addDaysToDate(asOfDate, expiryDays);
    const newConfirmations: BalanceConfirmation[] = [];

    partyIds.forEach(pId => {
      const party = parties.find(p => p.id === pId);
      if (!party) return;

      const partyInvs = invoices.filter(i => i.partyId === pId && i.outstandingAmount > 0);
      const totalBalance = partyInvs.reduce((sum, i) => sum + i.outstandingAmount, 0);

      const conf: BalanceConfirmation = {
        id: `conf_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        token: generateConfirmationToken(),
        partyId: party.id,
        partyName: party.name,
        email: party.email,
        phone: party.phone,
        asOfDate,
        expiresAt,
        totalLedgerBalance: totalBalance,
        invoices: partyInvs.map(i => ({
          invoiceNumber: i.invoiceNumber,
          date: i.invoiceDate,
          dueDate: i.dueDate,
          originalAmount: i.amount,
          paidAmount: i.paidAmount,
          outstanding: i.outstandingAmount,
          status: i.status
        })),
        status: 'Sent',
        sentAt: new Date().toISOString(),
        channelSent: party.email ? 'Email' : 'WhatsApp'
      };

      newConfirmations.push(conf);
    });

    // Update parties confirmation status
    const updatedParties = parties.map(p => {
      if (partyIds.includes(p.id)) {
        return { ...p, confirmationStatus: 'Sent' as const, updatedAt: new Date().toISOString() };
      }
      return p;
    });

    const updatedConfirmations = [...newConfirmations, ...confirmations];
    StorageManager.saveConfirmations(updatedConfirmations);
    StorageManager.saveParties(updatedParties);
    StorageManager.addAuditLog(
      'LAUNCH_CONFIRMATION_CAMPAIGN',
      `Issued ${newConfirmations.length} balance confirmation statement verification links (As of ${asOfDate})`,
      settings.authorizedUser.name,
      settings.authorizedUser.role
    );

    setConfirmations(updatedConfirmations);
    setParties(updatedParties);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Customer confirms balance
  const handleCustomerConfirm = (
    confId: string,
    signatoryName: string,
    designation: string,
    remarks: string
  ) => {
    const targetConf = confirmations.find(c => c.id === confId);
    if (!targetConf) return;

    const updatedConfirmations = confirmations.map(c => {
      if (c.id === confId) {
        return {
          ...c,
          status: 'Confirmed' as const,
          confirmedAmount: c.totalLedgerBalance,
          differenceAmount: 0,
          customerSignatoryName: signatoryName,
          customerSignatoryDesignation: designation,
          customerRemarks: remarks,
          respondedAt: new Date().toISOString(),
          digitalSignatureHash: `SIG-${Math.random().toString(36).substring(2, 10).toUpperCase()}`
        };
      }
      return c;
    });

    const updatedParties = parties.map(p => {
      if (p.id === targetConf.partyId) {
        return { ...p, confirmationStatus: 'Confirmed' as const, updatedAt: new Date().toISOString() };
      }
      return p;
    });

    StorageManager.saveConfirmations(updatedConfirmations);
    StorageManager.saveParties(updatedParties);
    StorageManager.addAuditLog(
      'CUSTOMER_CONFIRMATION_RECEIVED',
      `Customer ${targetConf.partyName} confirmed balance of ${formatCurrency(targetConf.totalLedgerBalance, settings.currencySymbol)} (Signed by ${signatoryName}, ${designation})`,
      signatoryName,
      'Debtor Signatory'
    );

    setConfirmations(updatedConfirmations);
    setParties(updatedParties);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Customer reports difference
  const handleCustomerReportDifference = (
    confId: string,
    customerBalance: number,
    diffReason: string,
    remarks: string,
    signatoryName: string,
    designation: string
  ) => {
    const targetConf = confirmations.find(c => c.id === confId);
    if (!targetConf) return;

    const diff = Math.abs(targetConf.totalLedgerBalance - customerBalance);

    const updatedConfirmations = confirmations.map(c => {
      if (c.id === confId) {
        return {
          ...c,
          status: 'Difference Reported' as const,
          confirmedAmount: customerBalance,
          differenceAmount: diff,
          differenceReason: diffReason,
          customerRemarks: remarks,
          customerSignatoryName: signatoryName,
          customerSignatoryDesignation: designation,
          respondedAt: new Date().toISOString(),
          financeActionStatus: 'Pending Review' as const
        };
      }
      return c;
    });

    const updatedParties = parties.map(p => {
      if (p.id === targetConf.partyId) {
        return { ...p, confirmationStatus: 'Difference Reported' as const, updatedAt: new Date().toISOString() };
      }
      return p;
    });

    StorageManager.saveConfirmations(updatedConfirmations);
    StorageManager.saveParties(updatedParties);
    StorageManager.addAuditLog(
      'CUSTOMER_DIFFERENCE_REPORTED',
      `Customer ${targetConf.partyName} reported balance difference of ${formatCurrency(diff, settings.currencySymbol)} (Reason: ${diffReason})`,
      signatoryName,
      'Debtor Signatory'
    );

    setConfirmations(updatedConfirmations);
    setParties(updatedParties);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Finance Resolves Difference
  const handleResolveDifference = (
    confId: string,
    resolutionStatus: 'Resolved - Ledger Adjusted' | 'Disputed & In Audit' | 'Difference Cleared',
    financeNotes: string
  ) => {
    const updatedConfirmations = confirmations.map(c => {
      if (c.id === confId) {
        return {
          ...c,
          financeActionStatus: resolutionStatus,
          financeResolutionNotes: financeNotes,
          resolvedAt: new Date().toISOString()
        };
      }
      return c;
    });

    StorageManager.saveConfirmations(updatedConfirmations);
    StorageManager.addAuditLog(
      'RESOLVE_DIFFERENCE',
      `Finance resolution recorded: ${resolutionStatus} for confirmation #${confId}`,
      settings.authorizedUser.name,
      settings.authorizedUser.role
    );

    setConfirmations(updatedConfirmations);
    setAuditLogs(StorageManager.getAuditLogs());
    setDifferenceModalConf(null);
  };

  // Handler: Import Excel
  const handleImportSuccess = (newParties: Party[], newInvoices: Invoice[], summaryText: string) => {
    StorageManager.saveParties(newParties);
    StorageManager.saveInvoices(newInvoices);
    StorageManager.addAuditLog(
      'EXCEL_IMPORT',
      summaryText,
      settings.authorizedUser.name,
      settings.authorizedUser.role
    );

    setParties(newParties);
    setInvoices(newInvoices);
    setAuditLogs(StorageManager.getAuditLogs());
    setActiveTab('debtors');
  };

  // Handler: Party & Invoice updates
  const handleUpdatePartyStatus = (partyId: string, status: Party['status'], notes?: string) => {
    const updated = parties.map(p => p.id === partyId ? { ...p, status, updatedAt: new Date().toISOString() } : p);
    StorageManager.saveParties(updated);
    StorageManager.addAuditLog('UPDATE_PARTY_STATUS', `Updated party #${partyId} status to ${status}`, settings.authorizedUser.name, settings.authorizedUser.role);
    setParties(updated);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  const handleUpdateInvoiceStatus = (invoiceId: string, isDisputed: boolean, disputeReason?: string) => {
    const updated = invoices.map(i => i.id === invoiceId ? {
      ...i,
      status: (isDisputed ? 'Disputed' : i.outstandingAmount === 0 ? 'Paid' : 'Current') as Invoice['status'],
      disputeReason: isDisputed ? disputeReason : undefined,
      updatedAt: new Date().toISOString()
    } : i);
    StorageManager.saveInvoices(updated);
    StorageManager.addAuditLog('UPDATE_INVOICE_STATUS', `Updated invoice #${invoiceId} dispute status: ${isDisputed}`, settings.authorizedUser.name, settings.authorizedUser.role);
    setInvoices(updated);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Save Settings
  const handleSaveSettings = (newSettings: SystemSettings) => {
    StorageManager.saveSettings(newSettings);
    StorageManager.addAuditLog('UPDATE_SETTINGS', 'System settings and reminder cadences updated', newSettings.authorizedUser.name, newSettings.authorizedUser.role);
    setSettings(newSettings);
    setAuditLogs(StorageManager.getAuditLogs());
  };

  // Handler: Reset Database
  const handleResetDatabase = () => {
    StorageManager.resetToDemo();
    setParties(StorageManager.getParties());
    setInvoices(StorageManager.getInvoices());
    setPayments(StorageManager.getPayments());
    setCommLogs(StorageManager.getCommLogs());
    setConfirmations(StorageManager.getConfirmations());
    setSettings(StorageManager.getSettings());
    setAuditLogs(StorageManager.getAuditLogs());
    setActiveTab('dashboard');
  };

  // Customer Portal View (either through token or demo preview)
  const activePortalConfirmation = portalToken
    ? confirmations.find(c => c.token === portalToken) || null
    : null;

  if (portalToken) {
    return (
      <CustomerPortal
        confirmation={activePortalConfirmation}
        settings={settings}
        onConfirm={handleCustomerConfirm}
        onReportDifference={handleCustomerReportDifference}
        onExitPortal={() => {
          window.location.hash = '';
          setPortalToken(null);
        }}
        isStandalone={true}
      />
    );
  }

  // Auth Lock Screen
  if (!isUnlocked) {
    return (
      <AuthLockScreen
        settings={settings}
        onUnlock={() => setIsUnlocked(true)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white flex flex-col font-sans">
      {/* Top Header Navigation (Strict 3-zone contract) */}
      <Header
        activeTab={activeTab}
        onTabChange={handleNavigate}
        settings={settings}
        onLockSession={() => setIsUnlocked(false)}
        pendingRemindersCount={todayEligibleReminders.filter(r => !r.alreadySentToday).length}
        onOpenCustomerPortalPreview={() => {
          if (confirmations.length > 0) {
            setPortalToken(confirmations[0].token);
          } else {
            alert('No balance confirmation campaigns exist yet. Launch a campaign first.');
          }
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            metrics={metrics}
            ageingSummaries={ageingSummaries}
            parties={parties}
            invoices={invoices}
            confirmations={confirmations}
            commLogs={commLogs}
            todayEligibleReminders={todayEligibleReminders}
            settings={settings}
            onNavigate={handleNavigate}
            onRunBatchReminders={handleRunBatchReminders}
            onSelectParty={(party) => {
              setSelectedParty(party);
              setActiveTab('debtors');
            }}
            onOpenPaymentModal={(inv) => {
              const party = parties.find(p => p.id === inv.partyId);
              setPaymentModalData({ isOpen: true, invoice: inv, party });
            }}
          />
        )}

        {activeTab === 'debtors' && (
          <DebtorsList
            parties={parties}
            invoices={invoices}
            payments={payments}
            commLogs={commLogs}
            confirmations={confirmations}
            settings={settings}
            selectedParty={selectedParty}
            onSelectParty={setSelectedParty}
            onOpenStatementModal={setStatementModalParty}
            onOpenPaymentModal={(inv, party) => setPaymentModalData({ isOpen: true, invoice: inv, party })}
            onOpenReminderModal={(party, inv) => setReminderModalData({ isOpen: true, party, invoice: inv })}
            onSendConfirmationRequest={(party) => handleCreateConfirmationRun([party.id], getTodayDateString(), 30)}
            onUpdatePartyStatus={handleUpdatePartyStatus}
            filterPreset={navFilterPreset}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoicesList
            invoices={invoices}
            parties={parties}
            settings={settings}
            onOpenPaymentModal={(inv) => {
              const party = parties.find(p => p.id === inv.partyId);
              setPaymentModalData({ isOpen: true, invoice: inv, party });
            }}
            onOpenReminderModal={(party, inv) => setReminderModalData({ isOpen: true, party, invoice: inv })}
            onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            filterPreset={navFilterPreset}
          />
        )}

        {activeTab === 'ageing' && (
          <AgeingAnalysis
            parties={parties}
            invoices={invoices}
            ageingSummaries={ageingSummaries}
            settings={settings}
            onSelectParty={(party) => {
              setSelectedParty(party);
              setActiveTab('debtors');
            }}
          />
        )}

        {activeTab === 'confirmations' && (
          <BalanceConfirmationHub
            confirmations={confirmations}
            parties={parties}
            invoices={invoices}
            settings={settings}
            onCreateConfirmationRun={handleCreateConfirmationRun}
            onOpenPortalForToken={(conf) => setPortalToken(conf.token)}
            onOpenDifferenceResolution={setDifferenceModalConf}
          />
        )}

        {activeTab === 'communications' && (
          <CommunicationsHub
            commLogs={commLogs}
            todayEligibleReminders={todayEligibleReminders}
            invoices={invoices}
            parties={parties}
            confirmations={confirmations}
            settings={settings}
            onRunBatchReminders={handleRunBatchReminders}
            onOpenReminderModal={(party, inv) => setReminderModalData({ isOpen: true, party, invoice: inv })}
            onRetryFailedMessage={(log) => {
              const party = parties.find(p => p.id === log.partyId);
              if (party) {
                setReminderModalData({ isOpen: true, party });
              }
            }}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            parties={parties}
            invoices={invoices}
            payments={payments}
            commLogs={commLogs}
            confirmations={confirmations}
            settings={settings}
            onOpenPartyDrawer={(party) => {
              setSelectedParty(party);
              setActiveTab('debtors');
            }}
          />
        )}

        {activeTab === 'upload' && (
          <UploadView
            existingInvoices={invoices}
            existingParties={parties}
            settings={settings}
            onImportSuccess={handleImportSuccess}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            auditLogs={auditLogs}
            onSaveSettings={handleSaveSettings}
            onResetDatabase={handleResetDatabase}
          />
        )}
      </main>

      {/* Floating / Universal Modals */}
      {/* 1. Payment Recording Modal */}
      <PaymentModal
        isOpen={paymentModalData.isOpen}
        onClose={() => setPaymentModalData({ isOpen: false })}
        invoice={paymentModalData.invoice}
        party={paymentModalData.party}
        parties={parties}
        invoices={invoices}
        currencySymbol={settings.currencySymbol}
        onRecordPayment={handleRecordPayment}
      />

      {/* 2. Statement of Account Modal */}
      {statementModalParty && (
        <StatementOfAccountModal
          party={statementModalParty}
          invoices={invoices}
          payments={payments}
          settings={settings}
          onClose={() => setStatementModalParty(null)}
        />
      )}

      {/* 3. Manual Reminder Modal */}
      {reminderModalData.isOpen && reminderModalData.party && (
        <ReminderModal
          party={reminderModalData.party}
          invoice={reminderModalData.invoice}
          settings={settings}
          onClose={() => setReminderModalData({ isOpen: false, party: null })}
          onSendReminder={handleSendReminder}
        />
      )}

      {/* 4. Difference Resolution Modal */}
      {differenceModalConf && (
        <DifferenceResolutionModal
          confirmation={differenceModalConf}
          settings={settings}
          onClose={() => setDifferenceModalConf(null)}
          onResolve={handleResolveDifference}
        />
      )}
    </div>
  );
};
export default App;
