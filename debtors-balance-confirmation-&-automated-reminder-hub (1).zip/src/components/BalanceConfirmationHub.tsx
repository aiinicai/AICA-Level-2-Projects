import React, { useState } from 'react';
import { BalanceConfirmation, Invoice, Party, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate, formatDateTime, getTodayDateString } from '../utils/calculations';
import {
  FileCheck,
  Plus,
  Send,
  ExternalLink,
  Copy,
  Check,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Search,
  Filter,
  Eye,
  RefreshCw
} from 'lucide-react';

interface BalanceConfirmationHubProps {
  confirmations: BalanceConfirmation[];
  parties: Party[];
  invoices: Invoice[];
  settings: SystemSettings;
  onCreateConfirmationRun: (partyIds: string[], asOfDate: string, expiryDays: number) => void;
  onOpenPortalForToken: (confirmation: BalanceConfirmation) => void;
  onOpenDifferenceResolution: (confirmation: BalanceConfirmation) => void;
}

export const BalanceConfirmationHub: React.FC<BalanceConfirmationHubProps> = ({
  confirmations,
  parties,
  invoices,
  settings,
  onCreateConfirmationRun,
  onOpenPortalForToken,
  onOpenDifferenceResolution
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showNewRunModal, setShowNewRunModal] = useState(false);

  // New run form state
  const [asOfDate, setAsOfDate] = useState(getTodayDateString());
  const [expiryDays, setExpiryDays] = useState(30);
  const [selectedPartyIds, setSelectedPartyIds] = useState<string[]>(
    parties.filter(p => p.totalOutstanding > 0).map(p => p.id)
  );

  const filteredConfirmations = confirmations.filter(c => {
    const matchesSearch = c.partyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.token.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCopyLink = (token: string, id: string) => {
    const url = `${window.location.origin}${window.location.pathname}#/portal/${token}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPartyIds.length === 0) return;
    onCreateConfirmationRun(selectedPartyIds, asOfDate, expiryDays);
    setShowNewRunModal(false);
  };

  const confirmedCount = confirmations.filter(c => c.status === 'Confirmed').length;
  const differenceCount = confirmations.filter(c => c.status === 'Difference Reported').length;
  const awaitingCount = confirmations.filter(c => c.status === 'Awaiting Confirmation' || c.status === 'Sent' || c.status === 'Delivered').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Debtors Balance Confirmation Hub</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit-ready statement verification cycles with secure, tokenized digital confirmation & dispute tracking
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setShowNewRunModal(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Launch Confirmation Campaign</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Confirmed Balances</span>
            <div className="text-2xl font-bold text-emerald-600 font-mono mt-1">{confirmedCount}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Digitally signed by debtors</div>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Differences Reported</span>
            <div className="text-2xl font-bold text-amber-600 font-mono mt-1">{differenceCount}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Requires finance ledger review</div>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Awaiting Verification</span>
            <div className="text-2xl font-bold text-blue-600 font-mono mt-1">{awaitingCount}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Pending debtor action</div>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search confirmation token, party name, email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Confirmation Statuses</option>
          <option value="Confirmed">🟢 Confirmed</option>
          <option value="Difference Reported">🔴 Difference Reported</option>
          <option value="Awaiting Confirmation">🟡 Awaiting Confirmation</option>
          <option value="Sent">🔵 Sent</option>
        </select>
      </div>

      {/* Confirmations List */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Debtor Party</th>
                <th className="py-3 px-4">Cycle & As Of Date</th>
                <th className="py-3 px-4 text-right">Stated Ledger Balance</th>
                <th className="py-3 px-4 text-right">Debtor Response</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Token & Link</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {filteredConfirmations.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    No balance confirmation records found.
                  </td>
                </tr>
              ) : (
                filteredConfirmations.map(conf => (
                  <tr key={conf.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Party */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{conf.partyName}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{conf.email}</div>
                    </td>

                    {/* Timeline */}
                    <td className="py-3 px-4">
                      <div className="text-slate-800 font-medium">As of {formatDisplayDate(conf.asOfDate)}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Sent {formatDisplayDate(conf.sentAt)} (via {conf.channelSent})
                      </div>
                    </td>

                    {/* Ledger Balance */}
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {formatCurrency(conf.totalLedgerBalance, settings.currencySymbol)}
                    </td>

                    {/* Debtor Response */}
                    <td className="py-3 px-4 text-right">
                      {conf.status === 'Confirmed' ? (
                        <div className="font-mono text-emerald-600 font-bold">
                          {formatCurrency(conf.confirmedAmount || conf.totalLedgerBalance, settings.currencySymbol)}
                          <div className="text-[10px] text-slate-500 font-normal">Signed by {conf.customerSignatoryName}</div>
                        </div>
                      ) : conf.status === 'Difference Reported' ? (
                        <div>
                          <div className="font-mono text-rose-600 font-bold">
                            Diff: {formatCurrency(conf.differenceAmount || 0, settings.currencySymbol)}
                          </div>
                          <div className="text-[10px] text-rose-600/90 truncate max-w-[140px] inline-block" title={conf.differenceReason}>
                            {conf.differenceReason}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No response yet</span>
                      )}
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        conf.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-700' :
                        conf.status === 'Difference Reported' ? 'bg-rose-100 text-rose-700' :
                        conf.status === 'Awaiting Confirmation' ? 'bg-amber-100 text-amber-700' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {conf.status}
                      </span>
                    </td>

                    {/* Token & Copy Link */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleCopyLink(conf.token, conf.id)}
                          className="px-2.5 py-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-medium text-slate-700 flex items-center gap-1 cursor-pointer shadow-xs"
                          title="Copy unique confirmation link"
                        >
                          {copiedId === conf.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600 font-bold">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 text-slate-400" />
                              <span>Copy Link</span>
                            </>
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onOpenPortalForToken(conf)}
                          title="Preview Customer Verification Portal"
                          className="p-1.5 bg-slate-50 hover:bg-blue-50 text-slate-600 hover:text-blue-600 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {conf.status === 'Difference Reported' && (
                          <button
                            onClick={() => onOpenDifferenceResolution(conf)}
                            title="Resolve Reported Difference"
                            className="px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 rounded-lg text-[11px] font-bold cursor-pointer flex items-center gap-1"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Resolve</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Confirmation Run Dialog */}
      {showNewRunModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">Create Balance Confirmation Campaign</h3>
              </div>
              <button
                onClick={() => setShowNewRunModal(false)}
                className="text-xs font-bold text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Statement As Of Date</label>
                  <input
                    type="date"
                    required
                    value={asOfDate}
                    onChange={(e) => setAsOfDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Link Expiry Period (Days)</label>
                  <input
                    type="number"
                    min="1"
                    max="180"
                    required
                    value={expiryDays}
                    onChange={(e) => setExpiryDays(parseInt(e.target.value) || 30)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-bold text-slate-700">Target Debtors</label>
                  <span className="text-[11px] text-blue-600 font-bold">
                    {selectedPartyIds.length} of {parties.length} selected
                  </span>
                </div>
                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/50">
                  {parties.map(p => (
                    <label key={p.id} className="p-2.5 flex items-center justify-between text-xs hover:bg-white cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedPartyIds.includes(p.id)}
                          onChange={() => {
                            if (selectedPartyIds.includes(p.id)) {
                              setSelectedPartyIds(selectedPartyIds.filter(id => id !== p.id));
                            } else {
                              setSelectedPartyIds([...selectedPartyIds, p.id]);
                            }
                          }}
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="font-medium text-slate-800">{p.name}</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900">{formatCurrency(p.totalOutstanding, settings.currencySymbol)}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowNewRunModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={selectedPartyIds.length === 0}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Send className="w-4 h-4" />
                  <span>Generate & Send Requests</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
