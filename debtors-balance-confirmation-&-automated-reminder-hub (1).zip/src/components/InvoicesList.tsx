import React, { useState } from 'react';
import { Invoice, Party, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate } from '../utils/calculations';
import { exportInvoicesToExcel } from '../utils/excelHelper';
import {
  Search,
  Download,
  DollarSign,
  Send,
  AlertCircle,
  CheckCircle2,
  Clock,
  Filter,
  FileSpreadsheet,
  AlertTriangle
} from 'lucide-react';

interface InvoicesListProps {
  invoices: Invoice[];
  parties: Party[];
  settings: SystemSettings;
  onOpenPaymentModal: (invoice: Invoice) => void;
  onOpenReminderModal: (party: Party, invoice: Invoice) => void;
  onUpdateInvoiceStatus: (invoiceId: string, isDisputed: boolean, disputeReason?: string) => void;
  filterPreset?: string;
}

export const InvoicesList: React.FC<InvoicesListProps> = ({
  invoices,
  parties,
  settings,
  onOpenPaymentModal,
  onOpenReminderModal,
  onUpdateInvoiceStatus,
  filterPreset
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(
    filterPreset === 'overdue' ? 'Overdue' :
    filterPreset === 'due_today' ? 'Due Today' :
    filterPreset === 'due_soon' ? 'Due Soon' : 'ALL'
  );
  const [selectedInvoices, setSelectedInvoices] = useState<string[]>([]);
  const [disputeModalInv, setDisputeModalInv] = useState<Invoice | null>(null);
  const [disputeReasonInput, setDisputeReasonInput] = useState('');

  const partyMap = new Map(parties.map(p => [p.id, p]));

  // Filter invoices
  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.partyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.representativeName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || inv.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleSelectAll = () => {
    if (selectedInvoices.length === filteredInvoices.length) {
      setSelectedInvoices([]);
    } else {
      setSelectedInvoices(filteredInvoices.map(i => i.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    if (selectedInvoices.includes(id)) {
      setSelectedInvoices(selectedInvoices.filter(i => i !== id));
    } else {
      setSelectedInvoices([...selectedInvoices, id]);
    }
  };

  const handleSaveDispute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disputeModalInv) return;
    onUpdateInvoiceStatus(disputeModalInv.id, true, disputeReasonInput);
    setDisputeModalInv(null);
    setDisputeReasonInput('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Invoice Master Register</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {invoices.length} Total Invoices • {filteredInvoices.length} matching criteria
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => exportInvoicesToExcel(filteredInvoices)}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" />
            <span>Export Invoices Excel</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search invoice no, party, city, rep..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
          />
        </div>

        {/* Status Filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Invoices</option>
          <option value="Overdue">🔴 Overdue</option>
          <option value="Due Today">🟠 Due Today</option>
          <option value="Due Soon">🟡 Due Soon (&le;7 days)</option>
          <option value="Current">🟢 Current</option>
          <option value="Partially Paid">🔵 Partially Paid</option>
          <option value="Paid">✅ Fully Paid</option>
          <option value="Disputed">⚠️ Disputed</option>
        </select>

        {/* Selected Count Indicator / Batch Bar */}
        <div className="sm:col-span-2 flex items-center justify-between px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
          <span className="text-slate-600">
            Selected: <strong className="text-slate-900">{selectedInvoices.length}</strong> invoices
          </span>
          {selectedInvoices.length > 0 && (
            <div className="flex gap-2">
              <button
                onClick={() => {
                  const toExport = invoices.filter(i => selectedInvoices.includes(i.id));
                  exportInvoicesToExcel(toExport, 'Selected_Invoices.xlsx');
                }}
                className="text-blue-600 font-bold hover:underline text-xs cursor-pointer"
              >
                Export Selected
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 w-8 text-center">
                  <input
                    type="checkbox"
                    checked={selectedInvoices.length > 0 && selectedInvoices.length === filteredInvoices.length}
                    onChange={handleSelectAll}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                  />
                </th>
                <th className="py-3 px-3">Invoice Details</th>
                <th className="py-3 px-3">Party & Contact</th>
                <th className="py-3 px-3">Maturity Timeline</th>
                <th className="py-3 px-3 text-right">Invoice Total</th>
                <th className="py-3 px-3 text-right">Paid Amount</th>
                <th className="py-3 px-3 text-right font-bold text-slate-900">Outstanding</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-500">
                    No invoices match your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map(inv => {
                  const party = partyMap.get(inv.partyId);

                  return (
                    <tr
                      key={inv.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        selectedInvoices.includes(inv.id) ? 'bg-blue-50/60' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={selectedInvoices.includes(inv.id)}
                          onChange={() => handleToggleSelect(inv.id)}
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                      </td>

                      {/* Invoice No & Date */}
                      <td className="py-3 px-3">
                        <div className="font-mono font-bold text-slate-900">{inv.invoiceNumber}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Dated: {formatDisplayDate(inv.invoiceDate)}
                        </div>
                      </td>

                      {/* Party Name & Location */}
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{inv.partyName}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {inv.city} • Rep: {inv.representativeName}
                        </div>
                      </td>

                      {/* Due Date & Days Overdue */}
                      <td className="py-3 px-3">
                        <div className="text-slate-800 font-medium">Due: {formatDisplayDate(inv.dueDate)}</div>
                        <div className="text-[11px] mt-0.5">
                          {inv.daysOverdue > 0 ? (
                            <span className="text-rose-600 font-semibold">{inv.daysOverdue} days overdue</span>
                          ) : (
                            <span className="text-slate-400">{inv.daysOutstanding}d age</span>
                          )}
                        </div>
                      </td>

                      {/* Total Amount */}
                      <td className="py-3 px-3 text-right font-mono text-slate-500">
                        {formatCurrency(inv.amount, settings.currencySymbol)}
                      </td>

                      {/* Paid Amount */}
                      <td className="py-3 px-3 text-right font-mono text-emerald-600 font-medium">
                        {inv.paidAmount > 0 ? formatCurrency(inv.paidAmount, settings.currencySymbol) : '-'}
                      </td>

                      {/* Outstanding Amount */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(inv.outstandingAmount, settings.currencySymbol)}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' :
                          inv.status === 'Overdue' ? 'bg-rose-100 text-rose-700' :
                          inv.status === 'Due Today' ? 'bg-amber-100 text-amber-700' :
                          inv.status === 'Due Soon' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                          inv.status === 'Partially Paid' ? 'bg-blue-100 text-blue-700' :
                          inv.status === 'Disputed' ? 'bg-purple-100 text-purple-700' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {inv.status}
                        </span>
                      </td>

                      {/* Quick Actions */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {inv.outstandingAmount > 0 && (
                            <>
                              <button
                                onClick={() => onOpenPaymentModal(inv)}
                                title="Record Collection Payment"
                                className="p-1 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                              >
                                <DollarSign className="w-3.5 h-3.5" />
                              </button>
                              {party && (
                                <button
                                  onClick={() => onOpenReminderModal(party, inv)}
                                  title="Send Invoice Reminder"
                                  className="p-1 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                                >
                                  <Send className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                onClick={() => {
                                  setDisputeModalInv(inv);
                                  setDisputeReasonInput(inv.disputeReason || '');
                                }}
                                title="Flag / Dispute Invoice"
                                className="p-1 text-slate-500 hover:text-purple-600 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                              >
                                <AlertTriangle className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dispute Modal */}
      {disputeModalInv && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900">Invoice Dispute Flag</h3>
            <p className="text-xs text-slate-500">
              Invoice #{disputeModalInv.invoiceNumber} • {disputeModalInv.partyName}
            </p>
            <form onSubmit={handleSaveDispute} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Dispute Reason / Issue</label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Debtor reported rate discrepancy in item #2 or awaiting warranty replacement..."
                  value={disputeReasonInput}
                  onChange={(e) => setDisputeReasonInput(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDisputeModalInv(null)}
                  className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onUpdateInvoiceStatus(disputeModalInv.id, false);
                    setDisputeModalInv(null);
                  }}
                  className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Clear Dispute
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-xs cursor-pointer"
                >
                  Save Dispute
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
