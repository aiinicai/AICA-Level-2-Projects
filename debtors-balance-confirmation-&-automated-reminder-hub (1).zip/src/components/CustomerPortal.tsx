import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { BalanceConfirmation, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate, formatDateTime } from '../utils/calculations';
import { 
  Building2, CheckCircle2, AlertTriangle, ShieldCheck, Printer, 
  ArrowLeft, FileText, Download, Calendar, Mail, Phone, Lock, Clock
} from 'lucide-react';

interface CustomerPortalProps {
  confirmation: BalanceConfirmation | null;
  settings: SystemSettings;
  onConfirm: (confId: string, signatoryName: string, designation: string, remarks: string) => void;
  onReportDifference: (confId: string, customerBalance: number, diffReason: string, remarks: string, signatoryName: string, designation: string) => void;
  onExitPortal?: () => void;
  isStandalone?: boolean;
}

export const CustomerPortal: React.FC<CustomerPortalProps> = ({
  confirmation,
  settings,
  onConfirm,
  onReportDifference,
  onExitPortal,
  isStandalone = false
}) => {
  if (!confirmation) {
    return (
      <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-6 text-center text-slate-900">
        <div className="p-6 bg-white border border-slate-200 rounded-xl max-w-md w-full shadow-xl">
          <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-rose-200">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-bold text-slate-900 mb-2">Invalid or Expired Link</h2>
          <p className="text-xs text-slate-500 mb-6">
            The balance confirmation verification link provided is invalid, expired, or has already been completed. Please contact our finance department.
          </p>
          {onExitPortal && (
            <button
              onClick={onExitPortal}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              Return to Hub
            </button>
          )}
        </div>
      </div>
    );
  }

  const isExpired = new Date(confirmation.expiresAt).getTime() < new Date().getTime();
  const isAlreadyConfirmed = confirmation.status === 'Confirmed';
  const isDifferenceReported = confirmation.status === 'Difference Reported';

  const [activeAction, setActiveAction] = useState<'view' | 'confirm' | 'difference'>('view');
  
  // Confirmation state
  const [signatoryName, setSignatoryName] = useState('');
  const [signatoryDesignation, setSignatoryDesignation] = useState('Accounts Manager');
  const [remarks, setRemarks] = useState('');
  const [agreementChecked, setAgreementChecked] = useState(false);

  // Difference state
  const [claimedBalance, setClaimedBalance] = useState<number>(confirmation.totalLedgerBalance);
  const [diffReason, setDiffReason] = useState<string>('Unadjusted Payment (Bank UTR to share)');
  const [diffNotes, setDiffNotes] = useState<string>('');

  const variance = Math.abs(confirmation.totalLedgerBalance - (claimedBalance || 0));

  const handleConfirmSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signatoryName || !agreementChecked) return;

    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {}

    onConfirm(confirmation.id, signatoryName, signatoryDesignation, remarks);
    setActiveAction('view');
  };

  const handleDifferenceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signatoryName) return;

    onReportDifference(
      confirmation.id,
      claimedBalance,
      diffReason,
      diffNotes,
      signatoryName,
      signatoryDesignation
    );
    setActiveAction('view');
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Top bar for exiting preview mode */}
        {onExitPortal && (
          <div className="flex items-center justify-between bg-white border border-slate-200 px-4 py-2.5 rounded-xl shadow-xs no-print">
            <button
              onClick={onExitPortal}
              className="flex items-center gap-1.5 text-xs text-slate-700 font-bold hover:text-blue-600 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-blue-600" />
              <span>Exit Customer Preview & Return to Finance Dashboard</span>
            </button>
            <div className="flex items-center gap-2 text-xs">
              <span className="px-2.5 py-0.5 bg-blue-50 text-blue-700 rounded-full border border-blue-200 font-bold text-[10px]">
                Customer Verification View
              </span>
              <button
                onClick={() => window.print()}
                className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                Print
              </button>
            </div>
          </div>
        )}

        {/* Expiry / Status Notice if already handled */}
        {isAlreadyConfirmed && (
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-start gap-3 text-emerald-900 shadow-xs">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-emerald-800">Balance Verified & Confirmed</h4>
              <p className="text-xs text-emerald-700 mt-0.5">
                Confirmed by <strong>{confirmation.customerSignatoryName}</strong> ({confirmation.customerSignatoryDesignation}) on {formatDateTime(confirmation.respondedAt)}.
              </p>
              {confirmation.customerRemarks && (
                <div className="text-xs text-emerald-800 italic mt-1 bg-emerald-100/60 p-2 rounded-lg border border-emerald-200">
                  "{confirmation.customerRemarks}"
                </div>
              )}
            </div>
          </div>
        )}

        {isDifferenceReported && (
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start gap-3 text-amber-900 shadow-xs">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-amber-800">Difference Reported & Sent to Finance Team</h4>
              <p className="text-xs text-amber-700 mt-0.5">
                Debtor reported balance: <strong>{formatCurrency(confirmation.confirmedAmount || 0, settings.currencySymbol)}</strong> (Variance: {formatCurrency(confirmation.differenceAmount || 0, settings.currencySymbol)}).
              </p>
              <div className="text-xs text-amber-800 mt-1">
                Reason: <strong>{confirmation.differenceReason}</strong>
              </div>
              {confirmation.customerRemarks && (
                <div className="text-xs text-amber-800 italic mt-1 bg-amber-100/60 p-2 rounded-lg border border-amber-200">
                  "{confirmation.customerRemarks}"
                </div>
              )}
              <div className="text-xs text-slate-500 mt-2">
                Finance Status: <strong className="text-slate-800 font-bold">{confirmation.financeActionStatus || 'Pending Review'}</strong>
              </div>
            </div>
          </div>
        )}

        {/* Main Document Card */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
          {/* Header Banner */}
          <div className="p-6 sm:p-8 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600">Formal Audit Communication</span>
                <span className="text-slate-300">•</span>
                <span className="text-xs text-slate-500 font-mono">Ref: {confirmation.token}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900">{settings.companyName}</h1>
              <p className="text-xs text-slate-500 mt-1">{settings.companyAddress} • GSTIN: {settings.companyGstOrTaxId}</p>
            </div>
            <div className="sm:text-right bg-white border border-slate-200 p-3.5 rounded-xl shadow-xs">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Statement As Of</div>
              <div className="text-sm font-bold text-slate-900 mt-0.5">{formatDisplayDate(confirmation.asOfDate)}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Valid until {formatDisplayDate(confirmation.expiresAt)}</div>
            </div>
          </div>

          {/* Party Overview */}
          <div className="p-6 sm:p-8 border-b border-slate-200 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div>
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Statement Issued To</div>
                <div className="text-lg font-bold text-slate-900 mt-1">{confirmation.partyName}</div>
                <div className="text-xs text-slate-600 mt-1 flex flex-col gap-0.5">
                  <span>Email: {confirmation.email}</span>
                  <span>Contact: {confirmation.phone}</span>
                </div>
              </div>

              <div className="bg-blue-50/70 p-5 rounded-xl border border-blue-200 flex flex-col justify-between">
                <div className="text-xs font-bold uppercase tracking-wider text-blue-700">Total Outstanding Balance</div>
                <div className="text-3xl font-black text-blue-900 mt-1 font-mono">
                  {formatCurrency(confirmation.totalLedgerBalance, settings.currencySymbol)}
                </div>
                <div className="text-[11px] text-blue-600 mt-1.5 flex items-center gap-1.5 font-medium">
                  <Clock className="w-3.5 h-3.5 text-blue-500" />
                  <span>Includes {confirmation.invoices.length} pending / unadjusted invoices</span>
                </div>
              </div>
            </div>
          </div>

          {/* Invoices Breakdown Table */}
          <div className="p-6 sm:p-8">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Itemized Invoice Breakdown</h3>
            <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Invoice No</th>
                    <th className="py-3 px-4">Invoice Date</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4 text-right">Invoice Amount</th>
                    <th className="py-3 px-4 text-right">Paid Amount</th>
                    <th className="py-3 px-4 text-right font-bold text-slate-700">Balance Due</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                  {confirmation.invoices.map((inv, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                      <td className="py-3 px-4 text-slate-600">{formatDisplayDate(inv.date)}</td>
                      <td className="py-3 px-4 text-slate-600">{formatDisplayDate(inv.dueDate)}</td>
                      <td className="py-3 px-4 text-right font-mono">{formatCurrency(inv.originalAmount, settings.currencySymbol)}</td>
                      <td className="py-3 px-4 text-right font-mono text-emerald-600 font-semibold">{formatCurrency(inv.paidAmount, settings.currencySymbol)}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-blue-700">{formatCurrency(inv.outstanding, settings.currencySymbol)}</td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {inv.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-slate-50 font-bold text-slate-900 border-t border-slate-200">
                  <tr>
                    <td colSpan={5} className="py-3 px-4 text-right text-xs uppercase tracking-wider text-slate-500">
                      Total Ledger Balance as of {formatDisplayDate(confirmation.asOfDate)}:
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-sm text-blue-700 font-extrabold">
                      {formatCurrency(confirmation.totalLedgerBalance, settings.currencySymbol)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Action Selection Box (Only if not already responded) */}
          {!isAlreadyConfirmed && !isDifferenceReported && (
            <div className="p-6 sm:p-8 bg-slate-50 border-t border-slate-200 no-print space-y-6">
              {activeAction === 'view' && (
                <div className="text-center space-y-4">
                  <h3 className="text-base font-bold text-slate-900">Please Verify Your Outstanding Balance</h3>
                  <p className="text-xs text-slate-500 max-w-xl mx-auto">
                    In accordance with standard statutory and audit requirements, kindly confirm whether the above balance matches your accounting records or report any variance with supporting details.
                  </p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
                    <button
                      onClick={() => setActiveAction('confirm')}
                      className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm Balance as Correct</span>
                    </button>
                    <button
                      onClick={() => setActiveAction('difference')}
                      className="w-full sm:w-auto px-6 py-3 bg-white hover:bg-slate-50 text-amber-800 border border-amber-300 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>Report Balance Difference / Dispute</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Form 1: Confirm Balance */}
              {activeAction === 'confirm' && (
                <form onSubmit={handleConfirmSubmit} className="space-y-4 bg-white p-6 rounded-xl border border-emerald-300 shadow-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <h4 className="text-sm font-bold text-slate-900">Digital Confirmation of Balance</h4>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveAction('view')}
                      className="text-xs text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
                    >
                      Change selection
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Authorized Signatory Full Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. Sunil Kulkarni"
                        required
                        value={signatoryName}
                        onChange={(e) => setSignatoryName(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Designation / Role *</label>
                      <input
                        type="text"
                        placeholder="e.g. Head of Accounts / CFO"
                        required
                        value={signatoryDesignation}
                        onChange={(e) => setSignatoryDesignation(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Remarks / Payment Schedule (Optional)</label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Verified against our ledger. Payment batch scheduled for clearance next week."
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={agreementChecked}
                      onChange={(e) => setAgreementChecked(e.target.checked)}
                      required
                      className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-0 w-4 h-4"
                    />
                    <span className="text-xs text-slate-700 leading-relaxed">
                      I hereby confirm on behalf of <strong>{confirmation.partyName}</strong> that the net balance of <strong>{formatCurrency(confirmation.totalLedgerBalance, settings.currencySymbol)}</strong> as of {formatDisplayDate(confirmation.asOfDate)} is correct and agreed.
                    </span>
                  </label>

                  <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => setActiveAction('view')}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={!agreementChecked || !signatoryName}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Submit Digital Confirmation</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Form 2: Report Difference */}
              {activeAction === 'difference' && (
                <form onSubmit={handleDifferenceSubmit} className="space-y-4 bg-white p-6 rounded-xl border border-amber-300 shadow-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-amber-600" />
                      <h4 className="text-sm font-bold text-slate-900">Report Balance Difference / Dispute</h4>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveAction('view')}
                      className="text-xs text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
                    >
                      Change selection
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Our Stated Balance</label>
                      <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 font-mono font-bold">
                        {formatCurrency(confirmation.totalLedgerBalance, settings.currencySymbol)}
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Your Ledger Balance ({settings.currencySymbol}) *</label>
                      <input
                        type="number"
                        step="any"
                        required
                        value={claimedBalance}
                        onChange={(e) => setClaimedBalance(parseFloat(e.target.value) || 0)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200 flex justify-between items-center text-xs">
                    <span className="text-amber-800 font-bold">Variance to Reconcile:</span>
                    <span className="font-mono font-bold text-amber-900 text-sm">{formatCurrency(variance, settings.currencySymbol)}</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Primary Reason for Discrepancy *</label>
                    <select
                      value={diffReason}
                      onChange={(e) => setDiffReason(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Unadjusted Payment (Bank UTR to share)">Payment made but not reflected in statement (Unadjusted UTR)</option>
                      <option value="Goods Return / Pending Debit Note">Goods returned / Pending Debit Note credit</option>
                      <option value="Rate or Quantity Difference">Rate or quantity variance on invoice</option>
                      <option value="TDS / Withholding Tax Deducted">TDS / Withholding tax deduction difference</option>
                      <option value="Invoice Not Received / Disputed">Invoice not received / Services disputed</option>
                      <option value="Other Discrepancy">Other accounting discrepancy</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">Explanation / Transaction Reference (UTR, Date, Invoices) *</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="e.g. Paid ₹45,000 against INV-2026-0810 on 12-Aug via NEFT UTR #HDFC8912384. Please check and adjust."
                      value={diffNotes}
                      onChange={(e) => setDiffNotes(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Signatory Full Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. Harish Mehta"
                        required
                        value={signatoryName}
                        onChange={(e) => setSignatoryName(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Designation *</label>
                      <input
                        type="text"
                        placeholder="e.g. Accounts Officer"
                        required
                        value={signatoryDesignation}
                        onChange={(e) => setSignatoryDesignation(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => setActiveAction('view')}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={!signatoryName || !diffNotes}
                      className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>Submit Difference Report</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Footer information */}
          <div className="p-6 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-3">
            <div>
              For inquiries, contact Finance Team: <span className="text-slate-800 font-semibold">{settings.companyEmail}</span>
            </div>
            <div>
              Bank: {settings.bankDetails.bankName} • IFSC: {settings.bankDetails.ifscCode} • UPI: {settings.bankDetails.upiId}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
