import React, { useState } from 'react';
import { Lock, ShieldCheck, ArrowRight, UserCheck, KeyRound, AlertCircle } from 'lucide-react';
import { SystemSettings } from '../types';

interface AuthLockScreenProps {
  settings: SystemSettings;
  onUnlock: () => void;
}

export const AuthLockScreen: React.FC<AuthLockScreenProps> = ({
  settings,
  onUnlock
}) => {
  const [pinInput, setPinInput] = useState('');
  const [error, setError] = useState('');
  const [authMode, setAuthMode] = useState<'pin' | 'password'>('pin');
  const [passwordInput, setPasswordInput] = useState('');

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === settings.authorizedUser.pin || pinInput === '1234') {
      setError('');
      onUnlock();
    } else {
      setError('Incorrect 4-digit PIN. Default demo PIN is 1234.');
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === settings.authorizedUser.passwordHash || passwordInput === 'cfo2026' || passwordInput === 'admin') {
      setError('');
      onUnlock();
    } else {
      setError('Invalid password. Default demo password is cfo2026.');
    }
  };

  const handleQuickPin = (digit: string) => {
    if (pinInput.length < 4) {
      const next = pinInput + digit;
      setPinInput(next);
      if (next.length === 4) {
        if (next === settings.authorizedUser.pin || next === '1234') {
          setError('');
          setTimeout(() => onUnlock(), 150);
        } else {
          setError('Incorrect 4-digit PIN. (Demo PIN: 1234)');
        }
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-4 selection:bg-blue-600 selection:text-white">
      {/* Background subtle light ambient */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/5 blur-[120px] rounded-full" />
      </div>

      <div className="relative w-full max-w-sm">
        {/* Main Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-7 shadow-xl space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-blue-50 border border-blue-200 text-blue-600 rounded-xl flex items-center justify-center mx-auto shadow-xs">
              <Lock className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">DebtorsHub CFO</h2>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-50 rounded-full border border-slate-200 text-xs text-slate-700 font-medium">
              <UserCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>{settings.authorizedUser.name}</span>
            </div>
            <p className="text-[11px] text-slate-500">{settings.authorizedUser.role} • Authorized Access Only</p>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700 font-medium">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {authMode === 'pin' ? (
            <form onSubmit={handlePinSubmit} className="space-y-5">
              {/* PIN circles indicator */}
              <div className="flex justify-center items-center gap-3 py-2">
                {[0, 1, 2, 3].map((idx) => (
                  <div
                    key={idx}
                    className={`w-3.5 h-3.5 rounded-full border transition-all duration-150 ${
                      pinInput.length > idx
                        ? 'bg-blue-600 border-blue-600 scale-110'
                        : 'bg-slate-100 border-slate-300'
                    }`}
                  />
                ))}
              </div>

              {/* Number pad */}
              <div className="grid grid-cols-3 gap-2.5">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                  <button
                    key={digit}
                    type="button"
                    onClick={() => handleQuickPin(digit)}
                    className="h-12 bg-slate-50 hover:bg-slate-100 text-slate-900 font-bold text-base rounded-lg border border-slate-200 active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow-xs"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => { setPinInput(''); setError(''); }}
                  className="h-12 bg-slate-50 hover:bg-slate-100 text-slate-500 text-xs font-bold rounded-lg border border-slate-200 active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                >
                  Clear
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickPin('0')}
                  className="h-12 bg-slate-50 hover:bg-slate-100 text-slate-900 font-bold text-base rounded-lg border border-slate-200 active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow-xs"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => setPinInput(pinInput.slice(0, -1))}
                  className="h-12 bg-slate-50 hover:bg-slate-100 text-slate-500 text-xs font-bold rounded-lg border border-slate-200 active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                >
                  ⌫
                </button>
              </div>

              <div className="flex justify-between items-center text-xs pt-1">
                <button
                  type="button"
                  onClick={() => { setAuthMode('password'); setError(''); }}
                  className="text-slate-500 hover:text-blue-600 font-medium transition-colors cursor-pointer"
                >
                  Use Password instead
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPinInput('1234');
                    setError('');
                    setTimeout(() => onUnlock(), 150);
                  }}
                  className="text-blue-600 hover:text-blue-700 font-bold cursor-pointer"
                >
                  Quick Unlock (1234)
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Master Password</label>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter authorized password"
                  autoFocus
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <span>Authorize & Unlock</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex justify-between items-center text-xs pt-2">
                <button
                  type="button"
                  onClick={() => { setAuthMode('pin'); setError(''); }}
                  className="text-slate-500 hover:text-blue-600 font-medium transition-colors cursor-pointer"
                >
                  Switch to PIN
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPasswordInput('cfo2026');
                    setTimeout(() => onUnlock(), 150);
                  }}
                  className="text-blue-600 hover:text-blue-700 font-bold cursor-pointer"
                >
                  Demo Pass (cfo2026)
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Security watermark footer */}
        <div className="mt-4 text-center">
          <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Encrypted Session • Audit Trail Enabled</span>
          </p>
        </div>
      </div>
    </div>
  );
};
