import React, { useState } from 'react';
import {
  BalanceConfirmation,
  CommunicationLog,
  Invoice,
  Party,
  SystemSettings,
  DashboardMetrics,
  AgeingBucketSummary
} from '../types';
import {
  formatCurrency,
  formatCompactCurrency,
  formatDisplayDate,
  getTodayDateString
} from '../utils/calculations';
import { EligibleReminder } from '../utils/reminderEngine';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  CheckCircle2,
  Clock,
  DollarSign,
  FileCheck,
  FileSpreadsheet,
  Mail,
  MessageSquare,
  Play,
  Send,
  ShieldAlert,
  TrendingUp,
  Users,
  XCircle,
  Zap
} from 'lucide-react';
import { NavTab } from './Header';

interface DashboardProps {
  metrics: DashboardMetrics;
  ageingSummaries: AgeingBucketSummary[];
  parties: Party[];
  invoices: Invoice[];
  confirmations: BalanceConfirmation[];
  commLogs: CommunicationLog[];
  todayEligibleReminders: EligibleReminder[];
  settings: SystemSettings;
  onNavigate: (tab: NavTab, filter?: string) => void;
  onRunBatchReminders: (reminders: EligibleReminder[]) => void;
  onSelectParty: (party: Party) => void;
  onOpenPaymentModal: (invoice: Invoice) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  metrics,
  ageingSummaries,
  parties,
  invoices,
  confirmations,
  commLogs,
  todayEligibleReminders,
  settings,
  onNavigate,
  onRunBatchReminders,
  onSelectParty,
  onOpenPaymentModal
}) => {
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [selectedReminders, setSelectedReminders] = useState<string[]>(
    todayEligibleReminders.filter(r => !r.alreadySentToday).map(r => `${r.invoice.id}_${r.rule.id}`)
  );

  const pendingEligible = todayEligibleReminders.filter(r => !r.alreadySentToday);
  const criticalParties = parties.filter(p => p.riskScore === 'Critical' && p.totalOutstanding > 0);
  const dueTodayInvoices = invoices.filter(i => i.status === 'Due Today' && i.outstandingAmount > 0);
  const dueIn7DaysInvoices = invoices.filter(i => i.status === 'Due Soon' && i.outstandingAmount > 0);

  const handleToggleReminder = (key: string) => {
    if (selectedReminders.includes(key)) {
      setSelectedReminders(selectedReminders.filter(k => k !== key));
    } else {
      setSelectedReminders([...selectedReminders, key]);
    }
  };

  const handleExecuteBatch = () => {
    const toSend = pendingEligible.filter(r => selectedReminders.includes(`${r.invoice.id}_${r.rule.id}`));
    onRunBatchReminders(toSend);
    setShowBatchModal(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Executive Welcome & Key Actions Row */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-bold text-blue-600 uppercase tracking-wider">
            <span>Executive Finance & CFO Desk</span>
            <span>•</span>
            <span className="text-slate-500">As of {formatDisplayDate(getTodayDateString())}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Debtors Balance & Reminder Command Center</h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            {metrics.totalDebtorsCount} Active Debtors • {formatCurrency(metrics.totalOutstanding, settings.currencySymbol)} Total Receivables Book • {metrics.overdueCount} Overdue Invoices requiring follow-up
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => setShowBatchModal(true)}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <Zap className="w-4 h-4 text-amber-300" />
            <span>Run Today's Reminders ({pendingEligible.length})</span>
          </button>

          <button
            onClick={() => onNavigate('confirmations')}
            className="px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <FileCheck className="w-4 h-4 text-emerald-600" />
            <span>Balance Confirmations</span>
          </button>
        </div>
      </div>

      {/* Top 4 Primary Financial KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Outstanding */}
        <div 
          onClick={() => onNavigate('debtors')}
          className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Outstanding</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:scale-105 transition-transform">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {formatCurrency(metrics.totalOutstanding, settings.currencySymbol)}
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100">
              <span>{metrics.totalDebtorsCount} Active Debtors</span>
              <span className="text-blue-600 font-medium flex items-center gap-0.5">View Master <ArrowRight className="w-3 h-3" /></span>
            </div>
          </div>
        </div>

        {/* Overdue Receivables */}
        <div 
          onClick={() => onNavigate('invoices', 'overdue')}
          className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs hover:border-rose-300 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Overdue</span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-lg group-hover:scale-105 transition-transform">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-rose-600 font-mono tracking-tight">
              {formatCurrency(metrics.overdueAmount, settings.currencySymbol)}
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100">
              <span>{metrics.overdueCount} Invoices ({((metrics.overdueAmount / (metrics.totalOutstanding || 1)) * 100).toFixed(0)}% of book)</span>
              <span className="text-rose-600 font-medium flex items-center gap-0.5">Action <ArrowRight className="w-3 h-3" /></span>
            </div>
          </div>
        </div>

        {/* Due Today & Due in 7 Days */}
        <div 
          onClick={() => onNavigate('invoices', 'due_today')}
          className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs hover:border-amber-300 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Due Today / Next 7 Days</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg group-hover:scale-105 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {formatCurrency(metrics.dueTodayAmount + metrics.dueIn7DaysAmount, settings.currencySymbol)}
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100">
              <span className="text-amber-700 font-medium">Today: {formatCurrency(metrics.dueTodayAmount, settings.currencySymbol)} ({metrics.dueTodayCount})</span>
              <span>7d: {formatCurrency(metrics.dueIn7DaysAmount, settings.currencySymbol)} ({metrics.dueIn7DaysCount})</span>
            </div>
          </div>
        </div>

        {/* Balance Confirmation Progress */}
        <div 
          onClick={() => onNavigate('confirmations')}
          className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs hover:border-emerald-300 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Confirmations Status</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg group-hover:scale-105 transition-transform">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-emerald-600 font-mono">
                {metrics.confirmationConfirmedCount}
              </span>
              <span className="text-xs text-slate-500">Confirmed / {confirmations.length} Sent</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100">
              <span className="text-amber-600 font-medium">{metrics.confirmationPendingCount} Awaiting</span>
              <span className="text-rose-600 font-medium">{metrics.confirmationDisputedCount} Disputed / Diff</span>
            </div>
          </div>
        </div>
      </div>

      {/* Overdue Ageing Breakdown Grid */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-bold uppercase text-slate-400">Ageing Analysis (Days)</h3>
            <p className="text-xs text-slate-500 mt-0.5">Aging buckets calculated relative to invoice due dates</p>
          </div>
          <button
            onClick={() => onNavigate('ageing')}
            className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-bold cursor-pointer"
          >
            <span>Open Detailed Ageing Matrix</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {ageingSummaries.map((b) => {
            const isCritical = b.bucket === '180+ Days' || b.bucket === '91 - 180 Days';
            const isMedium = b.bucket === '31 - 60 Days' || b.bucket === '61 - 90 Days';
            const isCurrent = b.bucket === 'Current (Not Due)';

            return (
              <div
                key={b.bucket}
                onClick={() => onNavigate('ageing')}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isCritical 
                    ? 'bg-rose-50/60 border-rose-200 hover:border-rose-300' 
                    : isMedium 
                      ? 'bg-amber-50/60 border-amber-200 hover:border-amber-300' 
                      : isCurrent
                        ? 'bg-emerald-50/60 border-emerald-200 hover:border-emerald-300'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="text-[11px] font-semibold text-slate-600 truncate">{b.bucket}</div>
                <div className={`text-base font-bold font-mono mt-1 ${
                  isCritical ? 'text-rose-600' : isMedium ? 'text-amber-700' : isCurrent ? 'text-emerald-700' : 'text-slate-900'
                }`}>
                  {formatCurrency(b.amount, settings.currencySymbol)}
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-500 mt-2 pt-1.5 border-t border-slate-200/80">
                  <span>{b.invoiceCount} Invoices</span>
                  <span className="font-bold text-slate-700">{b.percentage.toFixed(1)}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Critical Risk Ticker & Today's Reminder Action Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 cols: Critical Risk Parties & Escalations */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase text-slate-400">Risk Classification & Critical Debtors ({criticalParties.length})</h3>
                  <p className="text-xs text-slate-500">Parties with &gt;60 days overdue or substantial credit exposure</p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('debtors', 'critical')}
                className="text-xs text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
              >
                View all →
              </button>
            </div>

            {criticalParties.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-200">
                No parties currently in Critical Risk tier. Healthy credit control!
              </div>
            ) : (
              <div className="space-y-3">
                {criticalParties.slice(0, 4).map(party => (
                  <div
                    key={party.id}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-100/70 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{party.name}</span>
                        <span className="px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full text-[10px] font-bold">
                          {party.riskScore}
                        </span>
                        <span className="text-[10px] text-slate-500">({party.city})</span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1 flex items-center gap-3">
                        <span>Max Overdue: <strong className="text-rose-600">{party.maxDaysOverdue} days</strong></span>
                        <span>Sales Rep: <strong>{party.representativeName}</strong></span>
                        <span>Status: <strong className="text-slate-700">{party.status}</strong></span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                      <div className="text-right">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Outstanding</div>
                        <div className="text-sm font-bold text-rose-600 font-mono">
                          {formatCurrency(party.totalOutstanding, settings.currencySymbol)}
                        </div>
                      </div>

                      <button
                        onClick={() => onSelectParty(party)}
                        className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition-colors cursor-pointer shadow-xs"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Due Today Invoices Panel */}
          {dueTodayInvoices.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Invoices Due Today ({dueTodayInvoices.length})</h3>
                    <p className="text-xs text-slate-500">Prompt for payment receipt or follow-up before day close</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2.5">
                {dueTodayInvoices.map(inv => (
                  <div
                    key={inv.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-slate-900 font-mono">{inv.invoiceNumber} • {inv.partyName}</div>
                      <div className="text-slate-500 mt-0.5">Contact: {inv.phone || inv.email} • Rep: {inv.representativeName}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right font-mono font-bold text-amber-700">
                        {formatCurrency(inv.outstandingAmount, settings.currencySymbol)}
                      </div>
                      <button
                        onClick={() => onOpenPaymentModal(inv)}
                        className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 rounded-lg text-xs font-bold cursor-pointer shadow-xs"
                      >
                        Record Payment
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right 5 cols: Automated Reminder Engine Queue & Activity Log */}
        <div className="lg:col-span-5 space-y-6">
          {/* Today's Reminders Queue Widget */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Today's Reminders Queue</h3>
                  <p className="text-xs text-slate-500">{pendingEligible.length} automated messages ready</p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('communications')}
                className="text-xs text-blue-600 hover:text-blue-700 font-bold cursor-pointer"
              >
                Queue Hub →
              </button>
            </div>

            {pendingEligible.length === 0 ? (
              <div className="p-5 text-center bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto mb-1.5" />
                All eligible reminders for today have already been sent.
              </div>
            ) : (
              <div className="space-y-2.5">
                {pendingEligible.slice(0, 4).map((rem, i) => (
                  <div
                    key={i}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex justify-between items-center"
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{rem.party.name}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                        <span>Inv #{rem.invoice.invoiceNumber}</span>
                        <span>•</span>
                        <span className="text-amber-700 font-medium">{rem.rule.label}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-slate-900">
                        {formatCurrency(rem.invoice.outstandingAmount, settings.currencySymbol)}
                      </div>
                      <div className="flex items-center justify-end gap-1 text-[10px] text-slate-500 mt-0.5">
                        {rem.channels.map(ch => (
                          <span key={ch} className="px-1.5 py-0.5 bg-slate-200/80 rounded text-[9px] font-semibold text-slate-700">
                            {ch}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}

                <button
                  onClick={() => setShowBatchModal(true)}
                  className="w-full mt-2 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Review & Dispatch All ({pendingEligible.length})</span>
                </button>
              </div>
            )}
          </div>

          {/* Recent Communication Log stream */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-slate-100 text-slate-600 rounded-lg">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Recent Dispatch Stream</h3>
                  <p className="text-xs text-slate-500">Live communication delivery logs</p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('communications')}
                className="text-xs text-slate-500 hover:text-slate-800 font-bold"
              >
                All Logs →
              </button>
            </div>

            <div className="space-y-2.5">
              {commLogs.slice(0, 4).map(log => (
                <div
                  key={log.id}
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs flex justify-between items-start"
                >
                  <div className="space-y-0.5">
                    <div className="font-semibold text-slate-900">{log.partyName}</div>
                    <div className="text-[11px] text-slate-500 truncate max-w-[200px]">{log.templateName}</div>
                    <div className="text-[10px] text-slate-400">Ref: {log.messageId} • {formatDisplayDate(log.sentAt)}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      log.status === 'Delivered' ? 'bg-emerald-100 text-emerald-700' :
                      log.status === 'Sent' ? 'bg-blue-100 text-blue-700' :
                      'bg-rose-100 text-rose-700'
                    }`}>
                      {log.channel} • {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Batch Reminder Modal Dialog */}
      {showBatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Zap className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Execute Today's Automated Reminders</h3>
                  <p className="text-xs text-slate-500">Evaluates overdue & due date rules with strict duplicate prevention</p>
                </div>
              </div>
              <button
                onClick={() => setShowBatchModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">
                  Select messages to dispatch ({selectedReminders.length} of {pendingEligible.length} selected):
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedReminders(pendingEligible.map(r => `${r.invoice.id}_${r.rule.id}`))}
                    className="text-blue-600 font-bold hover:underline cursor-pointer"
                  >
                    Select All
                  </button>
                  <span className="text-slate-300">•</span>
                  <button
                    onClick={() => setSelectedReminders([])}
                    className="text-slate-500 font-medium hover:underline cursor-pointer"
                  >
                    Deselect All
                  </button>
                </div>
              </div>

              <div className="max-h-72 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-200 bg-slate-50/50">
                {pendingEligible.map((rem) => {
                  const key = `${rem.invoice.id}_${rem.rule.id}`;
                  const isChecked = selectedReminders.includes(key);

                  return (
                    <label
                      key={key}
                      className="p-3 flex items-start gap-3 hover:bg-slate-100/70 transition-colors cursor-pointer text-xs"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleToggleReminder(key)}
                        className="mt-1 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-900">{rem.party.name}</span>
                          <span className="font-mono font-bold text-slate-900">
                            {formatCurrency(rem.invoice.outstandingAmount, settings.currencySymbol)}
                          </span>
                        </div>
                        <div className="text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>Inv #{rem.invoice.invoiceNumber}</span>
                          <span>•</span>
                          <span className="text-amber-700 font-medium">{rem.rule.label}</span>
                          <span>•</span>
                          <span>Due: {formatDisplayDate(rem.invoice.dueDate)}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                          <span>Recipient: {rem.party.email || rem.party.phone}</span>
                          <span>({rem.channels.join(', ')})</span>
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-800 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 shrink-0 text-blue-600" />
                <span>
                  All dispatches are recorded into the Communication Log with unique message IDs. Repeated attempts on the same day are automatically blocked.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowBatchModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={selectedReminders.length === 0}
                  onClick={handleExecuteBatch}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Dispatch {selectedReminders.length} Reminders</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
