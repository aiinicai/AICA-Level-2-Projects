import React, { useState } from 'react';
import { AuditLog, ReminderRule, SystemSettings } from '../types';
import { formatDateTime } from '../utils/calculations';
import {
  Settings,
  Building2,
  Lock,
  CreditCard,
  Bell,
  FileText,
  ShieldCheck,
  RotateCcw,
  Save,
  CheckCircle2,
  Database,
  Download,
  AlertTriangle
} from 'lucide-react';

interface SettingsViewProps {
  settings: SystemSettings;
  auditLogs: AuditLog[];
  onSaveSettings: (newSettings: SystemSettings) => void;
  onResetDatabase: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  auditLogs,
  onSaveSettings,
  onResetDatabase
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'bank' | 'rules' | 'security' | 'audit'>('profile');
  const [formData, setFormData] = useState<SystemSettings>(JSON.parse(JSON.stringify(settings)));
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = { ...formData };
    if (newPin && newPin.length === 4) {
      updated.authorizedUser.pin = newPin;
    }
    if (newPassword) {
      updated.authorizedUser.passwordHash = newPassword;
    }

    onSaveSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleToggleRule = (ruleId: string) => {
    const updatedRules = formData.reminderRules.map(r => {
      if (r.id === ruleId) {
        return { ...r, isEnabled: !r.isEnabled };
      }
      return r;
    });
    setFormData({ ...formData, reminderRules: updatedRules });
  };

  const handleToggleChannel = (ruleId: string, channel: 'Email' | 'WhatsApp' | 'SMS') => {
    const updatedRules = formData.reminderRules.map(r => {
      if (r.id === ruleId) {
        const channels = r.channels.includes(channel)
          ? r.channels.filter(c => c !== channel)
          : [...r.channels, channel];
        return { ...r, channels: channels.length > 0 ? channels : ['Email'] };
      }
      return r;
    });
    setFormData({ ...formData, reminderRules: updatedRules });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">System Settings & Security</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure company identity, payment collections, automated reminder cadences, and access credentials
          </p>
        </div>

        <div className="flex items-center gap-2">
          {savedSuccess && (
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> Settings Saved!
            </span>
          )}
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Changes</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Company Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('bank')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'bank'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Bank & UPI Details</span>
        </button>

        <button
          onClick={() => setActiveTab('rules')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'rules'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Reminder Engine Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'security'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>User & Security</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Audit Trail ({auditLogs.length})</span>
        </button>
      </div>

      {/* Tab 1: Company Profile */}
      {activeTab === 'profile' && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider pb-2 border-b border-slate-200">
            Company Letterhead & Identification
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Company Legal Name</label>
              <input
                type="text"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">GSTIN / Tax ID</label>
              <input
                type="text"
                value={formData.companyGstOrTaxId}
                onChange={(e) => setFormData({ ...formData, companyGstOrTaxId: e.target.value })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Official Address</label>
            <input
              type="text"
              value={formData.companyAddress}
              onChange={(e) => setFormData({ ...formData, companyAddress: e.target.value })}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Finance Dept Email</label>
              <input
                type="email"
                value={formData.companyEmail}
                onChange={(e) => setFormData({ ...formData, companyEmail: e.target.value })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Helpline Phone</label>
              <input
                type="text"
                value={formData.companyPhone}
                onChange={(e) => setFormData({ ...formData, companyPhone: e.target.value })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Currency Symbol</label>
              <input
                type="text"
                value={formData.currencySymbol}
                onChange={(e) => setFormData({ ...formData, currencySymbol: e.target.value })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </form>
      )}

      {/* Tab 2: Bank & UPI Details */}
      {activeTab === 'bank' && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider pb-2 border-b border-slate-200">
            Payment Collection Bank & UPI Details
          </h3>
          <p className="text-xs text-slate-500">
            These coordinates are dynamically injected into automated reminder messages, printable statements, and debtor confirmation notices.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Account Holder Name</label>
              <input
                type="text"
                value={formData.bankDetails.accountName}
                onChange={(e) => setFormData({
                  ...formData,
                  bankDetails: { ...formData.bankDetails, accountName: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Bank Name</label>
              <input
                type="text"
                value={formData.bankDetails.bankName}
                onChange={(e) => setFormData({
                  ...formData,
                  bankDetails: { ...formData.bankDetails, bankName: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Account Number</label>
              <input
                type="text"
                value={formData.bankDetails.accountNumber}
                onChange={(e) => setFormData({
                  ...formData,
                  bankDetails: { ...formData.bankDetails, accountNumber: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">IFSC / Routing Code</label>
              <input
                type="text"
                value={formData.bankDetails.ifscCode}
                onChange={(e) => setFormData({
                  ...formData,
                  bankDetails: { ...formData.bankDetails, ifscCode: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">UPI ID (e.g. name@icici)</label>
              <input
                type="text"
                value={formData.bankDetails.upiId}
                onChange={(e) => setFormData({
                  ...formData,
                  bankDetails: { ...formData.bankDetails, upiId: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </form>
      )}

      {/* Tab 3: Reminder Engine Rules */}
      {activeTab === 'rules' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
            <div>
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Automated Reminder Cadence Engine
              </h3>
              <p className="text-xs text-slate-500">
                Configure due-date and overdue interval triggers, notification channels, and active status
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {formData.reminderRules.map(rule => (
              <div key={rule.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={rule.isEnabled}
                    onChange={() => handleToggleRule(rule.id)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-0 cursor-pointer w-4 h-4"
                  />
                  <div>
                    <div className="font-bold text-xs text-slate-900">{rule.label}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Triggers: {rule.type === 'BeforeDue' ? `${rule.daysOffset} days before maturity` : rule.type === 'OnDueDate' ? 'On invoice due date' : `${rule.daysOffset} days past due date`}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-500 font-medium">Channels:</span>
                  {(['Email', 'WhatsApp', 'SMS'] as const).map(ch => (
                    <button
                      key={ch}
                      type="button"
                      onClick={() => handleToggleChannel(rule.id, ch)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                        rule.channels.includes(ch)
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {ch}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Security & Authorized User */}
      {activeTab === 'security' && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
          <div>
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider pb-2 border-b border-slate-200">
              Authorized Single User Credentials
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Maintained strictly for one authorized Finance Manager / CFO with session locking
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Authorised User Name</label>
              <input
                type="text"
                value={formData.authorizedUser.name}
                onChange={(e) => setFormData({
                  ...formData,
                  authorizedUser: { ...formData.authorizedUser, name: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Role / Designation</label>
              <input
                type="text"
                value={formData.authorizedUser.role}
                onChange={(e) => setFormData({
                  ...formData,
                  authorizedUser: { ...formData.authorizedUser, role: e.target.value }
                })}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">New 4-Digit Quick PIN (optional)</label>
              <input
                type="password"
                maxLength={4}
                placeholder="Leave blank to keep current (1234)"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">New Master Password (optional)</label>
              <input
                type="password"
                placeholder="Leave blank to keep current (cfo2026)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Database Reset / Demo Seed Zone */}
          <div className="pt-4 border-t border-slate-200">
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>Reset Demo Financial Dataset</span>
                </h4>
                <p className="text-[11px] text-rose-600 mt-0.5">
                  Resets the database back to clean realistic sample debtors, invoices, and confirmation tokens.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Reset all debtor records and reload sample finance dataset?')) {
                    onResetDatabase();
                  }
                }}
                className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-xs"
              >
                Reset Database
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Tab 5: Audit Trail Logs */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Immutable Finance System Audit Trail
            </h3>
            <span className="text-xs text-slate-500 font-medium">{auditLogs.length} Events Logged</span>
          </div>

          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="py-2.5 px-4">Timestamp</th>
                  <th className="py-2.5 px-4">Action</th>
                  <th className="py-2.5 px-4">Performed By</th>
                  <th className="py-2.5 px-4">Event Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-4 text-slate-500 text-[11px] whitespace-nowrap">
                      {formatDateTime(log.timestamp)}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-4 text-slate-700 whitespace-nowrap">
                      {log.performedBy} ({log.userRole})
                    </td>
                    <td className="py-2.5 px-4 text-slate-600 text-[11px]">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
