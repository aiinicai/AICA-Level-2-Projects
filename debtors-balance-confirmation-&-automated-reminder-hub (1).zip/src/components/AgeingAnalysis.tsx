import React, { useState } from 'react';
import { AgeingBucketSummary, Invoice, Party, SystemSettings } from '../types';
import { formatCurrency, formatCompactCurrency } from '../utils/calculations';
import { exportAgeingReportToExcel } from '../utils/excelHelper';
import { Download, Search, Filter, ArrowRight, BarChart2, ShieldAlert } from 'lucide-react';

interface AgeingAnalysisProps {
  parties: Party[];
  invoices: Invoice[];
  ageingSummaries: AgeingBucketSummary[];
  settings: SystemSettings;
  onSelectParty: (party: Party) => void;
}

export const AgeingAnalysis: React.FC<AgeingAnalysisProps> = ({
  parties,
  invoices,
  ageingSummaries,
  settings,
  onSelectParty
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('ALL');
  const [areaFilter, setAreaFilter] = useState('ALL');

  // Compute party-level ageing breakdown
  const partyAgeingMap = new Map<string, {
    current: number;
    b1_30: number;
    b31_60: number;
    b61_90: number;
    b91_180: number;
    b180plus: number;
    total: number;
  }>();

  invoices.forEach(inv => {
    if (inv.outstandingAmount <= 0) return;
    if (!partyAgeingMap.has(inv.partyId)) {
      partyAgeingMap.set(inv.partyId, { current: 0, b1_30: 0, b31_60: 0, b61_90: 0, b91_180: 0, b180plus: 0, total: 0 });
    }
    const rec = partyAgeingMap.get(inv.partyId)!;
    rec.total += inv.outstandingAmount;

    if (inv.daysOverdue <= 0) {
      rec.current += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 30) {
      rec.b1_30 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 60) {
      rec.b31_60 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 90) {
      rec.b61_90 += inv.outstandingAmount;
    } else if (inv.daysOverdue <= 180) {
      rec.b91_180 += inv.outstandingAmount;
    } else {
      rec.b180plus += inv.outstandingAmount;
    }
  });

  const areas = Array.from(new Set(parties.map(p => p.area).filter(Boolean)));

  const filteredParties = parties.filter(p => {
    if (p.totalOutstanding <= 0) return false;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.representativeName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = riskFilter === 'ALL' || p.riskScore === riskFilter;
    const matchesArea = areaFilter === 'ALL' || p.area === areaFilter;
    return matchesSearch && matchesRisk && matchesArea;
  }).sort((a, b) => b.totalOutstanding - a.totalOutstanding);

  const grandTotals = {
    current: 0,
    b1_30: 0,
    b31_60: 0,
    b61_90: 0,
    b91_180: 0,
    b180plus: 0,
    total: 0
  };

  filteredParties.forEach(p => {
    const rec = partyAgeingMap.get(p.id) || { current: 0, b1_30: 0, b31_60: 0, b61_90: 0, b91_180: 0, b180plus: 0, total: 0 };
    grandTotals.current += rec.current;
    grandTotals.b1_30 += rec.b1_30;
    grandTotals.b31_60 += rec.b31_60;
    grandTotals.b61_90 += rec.b61_90;
    grandTotals.b91_180 += rec.b91_180;
    grandTotals.b180plus += rec.b180plus;
    grandTotals.total += rec.total;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Debtors Ageing Matrix</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Bucket-wise analysis of outstanding receivables across overdue aging intervals
          </p>
        </div>

        <button
          onClick={() => exportAgeingReportToExcel(parties, invoices)}
          className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
        >
          <Download className="w-3.5 h-3.5 text-blue-600" />
          <span>Export Ageing Excel Report</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {ageingSummaries.map((b) => (
          <div key={b.bucket} className="bg-white border border-slate-200 p-3.5 rounded-xl shadow-xs">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider truncate block">
              {b.bucket}
            </span>
            <div className="text-base font-bold font-mono text-slate-900 mt-1">
              {formatCurrency(b.amount, settings.currencySymbol)}
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-500 mt-2 pt-1 border-t border-slate-100">
              <span>{b.partyCount} Debtors</span>
              <span className="font-bold text-slate-700">{b.percentage.toFixed(1)}%</span>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search party, city, rep..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
          />
        </div>

        <select
          value={riskFilter}
          onChange={(e) => setRiskFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Risk Ratings</option>
          <option value="Low">Low Risk</option>
          <option value="Medium">Medium Risk</option>
          <option value="High">High Risk</option>
          <option value="Critical">Critical Risk</option>
        </select>

        <select
          value={areaFilter}
          onChange={(e) => setAreaFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Areas / Zones</option>
          {areas.map(a => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
      </div>

      {/* Ageing Table Matrix */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Debtor Party</th>
                <th className="py-3 px-3">Location / Rep</th>
                <th className="py-3 px-3 text-right">Current (Not Due)</th>
                <th className="py-3 px-3 text-right">1-30 Days</th>
                <th className="py-3 px-3 text-right">31-60 Days</th>
                <th className="py-3 px-3 text-right">61-90 Days</th>
                <th className="py-3 px-3 text-right">91-180 Days</th>
                <th className="py-3 px-3 text-right">180+ Days</th>
                <th className="py-3 px-4 text-right font-bold text-slate-900">Total Outstanding</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {filteredParties.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-500">
                    No debtor records found for the specified filters.
                  </td>
                </tr>
              ) : (
                filteredParties.map(party => {
                  const rec = partyAgeingMap.get(party.id) || { current: 0, b1_30: 0, b31_60: 0, b61_90: 0, b91_180: 0, b180plus: 0, total: 0 };

                  return (
                    <tr
                      key={party.id}
                      onClick={() => onSelectParty(party)}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{party.name}</span>
                          <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${
                            party.riskScore === 'Critical' ? 'bg-rose-100 text-rose-700' :
                            party.riskScore === 'High' ? 'bg-orange-100 text-orange-700' :
                            'bg-slate-100 text-slate-600'
                          }`}>
                            {party.riskScore}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-slate-600">
                        <div className="font-medium text-slate-800">{party.city}</div>
                        <div className="text-[10px] text-slate-400">{party.representativeName}</div>
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-emerald-600 font-medium">
                        {rec.current > 0 ? formatCurrency(rec.current, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-slate-700">
                        {rec.b1_30 > 0 ? formatCurrency(rec.b1_30, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-amber-700 font-medium">
                        {rec.b31_60 > 0 ? formatCurrency(rec.b31_60, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-orange-700 font-medium">
                        {rec.b61_90 > 0 ? formatCurrency(rec.b61_90, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-rose-600 font-medium">
                        {rec.b91_180 > 0 ? formatCurrency(rec.b91_180, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-rose-700 font-bold">
                        {rec.b180plus > 0 ? formatCurrency(rec.b180plus, settings.currencySymbol) : '-'}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(rec.total, settings.currencySymbol)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            <tfoot className="bg-slate-50 font-bold text-slate-900 border-t-2 border-slate-200">
              <tr>
                <td colSpan={2} className="py-3.5 px-4 text-slate-600 uppercase text-xs">
                  Grand Total ({filteredParties.length} Debtors):
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-emerald-700">
                  {formatCurrency(grandTotals.current, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-slate-800">
                  {formatCurrency(grandTotals.b1_30, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-amber-700">
                  {formatCurrency(grandTotals.b31_60, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-orange-700">
                  {formatCurrency(grandTotals.b61_90, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-rose-600">
                  {formatCurrency(grandTotals.b91_180, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-rose-700">
                  {formatCurrency(grandTotals.b180plus, settings.currencySymbol)}
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-blue-700 text-sm">
                  {formatCurrency(grandTotals.total, settings.currencySymbol)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
