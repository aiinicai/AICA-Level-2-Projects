import React, { useState, useRef } from 'react';
import {
  validateAndParseFile,
  downloadSampleTemplate,
  FileParseResult
} from '../utils/excelHelper';
import { Invoice, Party, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate } from '../utils/calculations';
import {
  Upload,
  Download,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileSpreadsheet,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Info
} from 'lucide-react';

interface UploadViewProps {
  existingInvoices: Invoice[];
  existingParties: Party[];
  settings: SystemSettings;
  onImportSuccess: (newParties: Party[], newInvoices: Invoice[], summaryText: string) => void;
}

export const UploadView: React.FC<UploadViewProps> = ({
  existingInvoices,
  existingParties,
  settings,
  onImportSuccess
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [parseResult, setParseResult] = useState<FileParseResult | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const existingInvoiceNos = new Set<string>(existingInvoices.map(i => i.invoiceNumber.toLowerCase().trim()));

  const handleFile = async (file: File) => {
    setFileName(file.name);
    setIsProcessing(true);
    try {
      const result = await validateAndParseFile(file, existingInvoiceNos);
      setParseResult(result);
    } catch (err: any) {
      alert(`Error reading file: ${err.message || 'Unknown error'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleCommitImport = () => {
    if (!parseResult || parseResult.validRows.length === 0) return;

    // Create / Merge parties and invoices
    const partyMap = new Map<string, Party>(existingParties.map(p => [p.name.toLowerCase().trim(), { ...p }]));
    const newInvoices: Invoice[] = [];

    parseResult.validRows.forEach((row, idx) => {
      const partyKey = row.partyName.toLowerCase().trim();
      let party = partyMap.get(partyKey);

      if (!party) {
        party = {
          id: `pty_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
          name: row.partyName,
          city: row.city,
          area: row.area,
          representativeName: row.representativeName,
          email: row.email,
          phone: row.phone,
          creditLimit: (row.amount || 50000) * 2,
          totalInvoiced: 0,
          totalPaid: 0,
          totalOutstanding: 0,
          overdueAmount: 0,
          maxDaysOverdue: 0,
          invoiceCount: 0,
          overdueInvoiceCount: 0,
          riskScore: 'Low',
          confirmationStatus: 'Not Sent',
          status: 'Active',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        partyMap.set(partyKey, party);
      } else {
        // Update contact details if newly provided
        if (row.email) party.email = row.email;
        if (row.phone) party.phone = row.phone;
        if (row.city) party.city = row.city;
        if (row.area) party.area = row.area;
        if (row.representativeName) party.representativeName = row.representativeName;
      }

      const inv: Invoice = {
        id: `inv_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
        invoiceNumber: row.invoiceNumber,
        invoiceDate: row.invoiceDate,
        dueDate: row.dueDate,
        partyId: party.id,
        partyName: party.name,
        city: party.city,
        area: party.area,
        representativeName: party.representativeName,
        email: party.email,
        phone: party.phone,
        amount: row.amount,
        paidAmount: 0,
        outstandingAmount: row.amount,
        daysOutstanding: 0,
        daysOverdue: 0,
        status: 'Current',
        remindersSentCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      newInvoices.push(inv);
    });

    const updatedParties = Array.from(partyMap.values());
    const summary = `Successfully imported ${newInvoices.length} invoices across ${updatedParties.length} debtors from ${fileName}`;
    onImportSuccess(updatedParties, newInvoices, summary);
    setParseResult(null);
    setFileName('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Excel / CSV Debtors Data Import</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Bulk upload accounting statements, customer ledgers, and invoice schedules with multi-layer field validation
          </p>
        </div>

        <button
          onClick={downloadSampleTemplate}
          className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
        >
          <Download className="w-3.5 h-3.5 text-blue-600" />
          <span>Download Excel Template</span>
        </button>
      </div>

      {/* Drag & Drop Upload Zone */}
      {!parseResult && (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-10 text-center transition-all cursor-pointer ${
            isDragging
              ? 'border-blue-500 bg-blue-50/50 scale-[1.01]'
              : 'border-slate-300 bg-slate-50/70 hover:border-slate-400 hover:bg-slate-100/60'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx, .xls, .csv"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFile(e.target.files[0]);
              }
            }}
          />

          <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 border border-blue-200">
            <Upload className="w-7 h-7" />
          </div>

          <h3 className="text-base font-bold text-slate-900 mb-1">
            {isProcessing ? 'Validating Excel Sheet...' : 'Click to Browse or Drag & Drop Excel/CSV'}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
            Supports Microsoft Excel (.xlsx, .xls) and standard Comma Separated Values (.csv) with auto-mapping for column headers.
          </p>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white rounded-full border border-slate-200 text-xs text-slate-600 shadow-xs">
            <Info className="w-3.5 h-3.5 text-blue-600" />
            <span>Checks duplicate invoices, invalid date formats, and missing mandatory columns</span>
          </div>
        </div>
      )}

      {/* Validation Results & Preview Section */}
      {parseResult && (
        <div className="space-y-6">
          {/* Summary Box */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-blue-600" />
                  <h3 className="text-base font-bold text-slate-900">{fileName}</h3>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Processed {parseResult.totalRows} records • {parseResult.validRows.length} valid for import
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setParseResult(null); setFileName(''); }}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                >
                  Discard & Re-upload
                </button>
                <button
                  onClick={handleCommitImport}
                  disabled={parseResult.validRows.length === 0}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-300" />
                  <span>Commit Import ({parseResult.validRows.length} Invoices)</span>
                </button>
              </div>
            </div>

            {/* Validation Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <div className="text-base font-bold text-slate-900 font-mono">{parseResult.validRows.length}</div>
                  <div className="text-[11px] text-slate-500">Valid Invoices Ready</div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                <div>
                  <div className="text-base font-bold text-slate-900 font-mono">{parseResult.warnings.length}</div>
                  <div className="text-[11px] text-slate-500">Warnings (Minor issues)</div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center gap-3">
                <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                <div>
                  <div className="text-base font-bold text-slate-900 font-mono">{parseResult.errors.length}</div>
                  <div className="text-[11px] text-slate-500">Errors (Skipped rows)</div>
                </div>
              </div>
            </div>

            {/* Errors / Warnings List */}
            {(parseResult.errors.length > 0 || parseResult.warnings.length > 0) && (
              <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs max-h-48 overflow-y-auto">
                <div className="font-bold text-slate-800">Validation Log:</div>
                {parseResult.errors.map((err, i) => (
                  <div key={`err_${i}`} className="text-rose-600 flex items-center gap-1.5 font-medium">
                    <XCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{err}</span>
                  </div>
                ))}
                {parseResult.warnings.map((warn, i) => (
                  <div key={`warn_${i}`} className="text-amber-700 flex items-center gap-1.5 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{warn}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Valid Records Preview Table */}
          {parseResult.validRows.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Import Preview (First {Math.min(50, parseResult.validRows.length)} Records)
                </h4>
                <span className="text-xs text-blue-700 font-mono font-bold">
                  Total Value: {formatCurrency(
                    parseResult.validRows.reduce((sum, r) => sum + r.amount, 0),
                    settings.currencySymbol
                  )}
                </span>
              </div>

              <div className="overflow-x-auto max-h-80 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 sticky top-0">
                    <tr>
                      <th className="py-2.5 px-3">Invoice No</th>
                      <th className="py-2.5 px-3">Invoice Date</th>
                      <th className="py-2.5 px-3">Due Date</th>
                      <th className="py-2.5 px-3">Party Name</th>
                      <th className="py-2.5 px-3">City / Area</th>
                      <th className="py-2.5 px-3">Sales Rep</th>
                      <th className="py-2.5 px-3">Contact Email / Phone</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                    {parseResult.validRows.slice(0, 50).map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{row.invoiceNumber}</td>
                        <td className="py-2.5 px-3 text-slate-700">{formatDisplayDate(row.invoiceDate)}</td>
                        <td className="py-2.5 px-3 text-slate-700">{formatDisplayDate(row.dueDate)}</td>
                        <td className="py-2.5 px-3 font-bold text-slate-900">{row.partyName}</td>
                        <td className="py-2.5 px-3 text-slate-600">{row.city} ({row.area})</td>
                        <td className="py-2.5 px-3 text-slate-600">{row.representativeName}</td>
                        <td className="py-2.5 px-3 text-slate-500">{row.email || row.phone || '-'}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-700">
                          {formatCurrency(row.amount, settings.currencySymbol)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
