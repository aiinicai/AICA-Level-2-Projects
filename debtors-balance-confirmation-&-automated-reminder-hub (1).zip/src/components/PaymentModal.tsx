import React, { useState } from 'react';
import { Invoice, Party, PaymentRecord, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate, getTodayDateString } from '../utils/calculations';
import { X, CheckCircle2, DollarSign, Calendar, FileText, CreditCard } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice?: Invoice | null;
  party?: Party | null;
  allInvoices: Invoice[];
  settings: SystemSettings;
  onSavePayment: (payment: Omit<PaymentRecord, 'id' | 'createdAt'>) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  invoice,
  party,
  allInvoices,
  settings,
  onSavePayment
}) => {
  if (!isOpen) return null;

  const relevantInvoices = party 
    ? allInvoices.filter(i => i.partyId === party.id && i.outstandingAmount > 0)
    : invoice 
      ? [invoice]
      : [];

  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>(invoice ? invoice.id : (relevantInvoices[0]?.id || ''));
  const targetInvoice = allInvoices.find(i => i.id === selectedInvoiceId) || invoice || relevantInvoices[0];

  const [amount, setAmount] = useState<number>(targetInvoice ? targetInvoice.outstandingAmount : 0);
  const [paymentDate, setPaymentDate] = useState<string>(getTodayDateString());
  const [paymentMode, setPaymentMode] = useState<PaymentRecord['paymentMode']>('Bank Transfer (NEFT/RTGS)');
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetInvoice || amount <= 0) return;

    onSavePayment({
      invoiceId: targetInvoice.id,
      invoiceNumber: targetInvoice.invoiceNumber,
      partyId: targetInvoice.partyId,
      partyName: targetInvoice.partyName,
      paymentDate,
      amount,
      paymentMode,
      referenceNumber: referenceNumber.trim() || `REF-${Date.now().toString().slice(-6)}`,
      notes: notes.trim(),
      recordedBy: settings.authorizedUser.name
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-200">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Record Payment Collection</h3>
              <p className="text-xs text-slate-500">Update ledger and automatically recalculate debtor balance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Party & Invoice Info */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Debtor Party</label>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="text-sm font-bold text-slate-900">{targetInvoice?.partyName || party?.name || 'Unknown Party'}</div>
              <div className="text-xs text-slate-500 mt-0.5">{targetInvoice?.city || party?.city} • Sales Rep: {targetInvoice?.representativeName || party?.representativeName}</div>
            </div>
          </div>

          {/* Invoice Selection */}
          {relevantInvoices.length > 1 && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Apply To Invoice</label>
              <select
                value={selectedInvoiceId}
                onChange={(e) => {
                  setSelectedInvoiceId(e.target.value);
                  const chosen = allInvoices.find(i => i.id === e.target.value);
                  if (chosen) setAmount(chosen.outstandingAmount);
                }}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              >
                {relevantInvoices.map(inv => (
                  <option key={inv.id} value={inv.id}>
                    {inv.invoiceNumber} — Outstanding: {formatCurrency(inv.outstandingAmount, settings.currencySymbol)} (Due: {formatDisplayDate(inv.dueDate)})
                  </option>
                ))}
              </select>
            </div>
          )}

          {targetInvoice && (
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 font-medium">Invoice Total:</span>
                <span className="ml-1.5 font-bold text-slate-900">{formatCurrency(targetInvoice.amount, settings.currencySymbol)}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Current Outstanding:</span>
                <span className="ml-1.5 font-bold text-amber-700 font-mono">{formatCurrency(targetInvoice.outstandingAmount, settings.currencySymbol)}</span>
              </div>
            </div>
          )}

          {/* Payment Amount & Date */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Payment Amount ({settings.currencySymbol}) *</label>
              <input
                type="number"
                min="1"
                max={targetInvoice?.outstandingAmount || 10000000}
                step="any"
                value={amount}
                onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                required
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs font-bold"
              />
              <button
                type="button"
                onClick={() => targetInvoice && setAmount(targetInvoice.outstandingAmount)}
                className="text-[11px] text-blue-600 font-bold hover:underline mt-1 cursor-pointer"
              >
                Set full outstanding amount
              </button>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Payment Date *</label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                required
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              />
            </div>
          </div>

          {/* Payment Mode & Reference */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as PaymentRecord['paymentMode'])}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs cursor-pointer"
              >
                <option value="Bank Transfer (NEFT/RTGS)">Bank Transfer (NEFT/RTGS)</option>
                <option value="Cheque">Cheque</option>
                <option value="UPI">UPI</option>
                <option value="Direct Debit">Direct Debit</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Cash">Cash</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">UTR / Cheque / Ref No.</label>
              <input
                type="text"
                placeholder="e.g. NEFT-HDFC-991204"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Collection Remarks / Notes</label>
            <textarea
              rows={2}
              placeholder="e.g. Received via NEFT, credited to HDFC main account..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              Save Payment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
