import React, { useState } from 'react';
import { BalanceConfirmation, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate, formatDateTime } from '../utils/calculations';
import { X, AlertTriangle, CheckCircle2, FileQuestion, ArrowRight, ShieldCheck } from 'lucide-react';

interface DifferenceResolutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  confirmation: BalanceConfirmation | null;
  settings: SystemSettings;
  onResolve: (confId: string, resolutionStatus: BalanceConfirmation['financeActionStatus'], resolutionNotes: string) => void;
}

export const DifferenceResolutionModal: React.FC<DifferenceResolutionModalProps> = ({
  isOpen,
  onClose,
  confirmation,
  settings,
  onResolve
}) => {
  if (!isOpen || !confirmation) return null;

  const [resolutionStatus, setResolutionStatus] = useState<BalanceConfirmation['financeActionStatus']>(
    confirmation.financeActionStatus || 'Resolved - Ledger Adjusted'
  );
  const [resolutionNotes, setResolutionNotes] = useState<string>(
    confirmation.financeActionNotes || ''
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onResolve(confirmation.id, resolutionStatus, resolutionNotes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg border border-amber-200">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Dispute & Difference Resolution</h3>
              <p className="text-xs text-slate-500">Balance Confirmation #{confirmation.id} • {confirmation.partyName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Dispute Comparison Box */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <span className="text-slate-500 text-xs font-medium block">Our Ledger Balance</span>
              <span className="text-base font-mono font-bold text-slate-900 mt-1 block">
                {formatCurrency(confirmation.totalLedgerBalance, settings.currencySymbol)}
              </span>
              <span className="text-[11px] text-slate-500 mt-0.5 block">As of {formatDisplayDate(confirmation.asOfDate)}</span>
            </div>
            <div className="bg-emerald-50 p-3.5 rounded-xl border border-emerald-200">
              <span className="text-emerald-700 text-xs font-bold block">Debtor Confirmed Bal</span>
              <span className="text-base font-mono font-bold text-emerald-800 mt-1 block">
                {formatCurrency(confirmation.confirmedAmount || 0, settings.currencySymbol)}
              </span>
              <span className="text-[11px] text-emerald-600 mt-0.5 block">Reported on {formatDisplayDate(confirmation.respondedAt)}</span>
            </div>
            <div className="bg-rose-50 p-3.5 rounded-xl border border-rose-200">
              <span className="text-rose-700 text-xs font-bold block">Reported Variance</span>
              <span className="text-base font-mono font-bold text-rose-800 mt-1 block">
                {formatCurrency(confirmation.differenceAmount || 0, settings.currencySymbol)}
              </span>
              <span className="text-[11px] text-rose-600 mt-0.5 block">Difference to reconcile</span>
            </div>
          </div>

          {/* Customer Explanation & Signatory Details */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <span className="font-bold text-slate-800">Customer Submission Details</span>
              <span className="text-slate-500">Signed by: <strong className="text-slate-800">{confirmation.customerSignatoryName || 'Authorized Signatory'}</strong> ({confirmation.customerSignatoryDesignation || 'Finance'})</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Claimed Reason:</span>
              <div className="text-amber-800 font-bold mt-0.5">{confirmation.differenceReason || 'Unspecified discrepancy'}</div>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Customer Remarks:</span>
              <div className="text-slate-800 italic bg-white p-2.5 rounded-lg border border-slate-200 mt-1 shadow-xs">
                "{confirmation.customerRemarks || 'No remarks provided.'}"
              </div>
            </div>
          </div>

          {/* Invoices attached to this confirmation */}
          <div>
            <div className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Statement Line Items Included</div>
            <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-xl shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Invoice No</th>
                    <th className="py-2 px-3">Due Date</th>
                    <th className="py-2 px-3 text-right">Original</th>
                    <th className="py-2 px-3 text-right">Outstanding</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                  {confirmation.invoices.map((inv, i) => (
                    <tr key={i} className="hover:bg-slate-50/80">
                      <td className="py-2 px-3 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                      <td className="py-2 px-3 text-slate-600">{formatDisplayDate(inv.dueDate)}</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-500">{formatCurrency(inv.originalAmount, settings.currencySymbol)}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">{formatCurrency(inv.outstanding, settings.currencySymbol)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Resolution Decision */}
          <div className="space-y-3 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Resolution Decision & Status</label>
              <select
                value={resolutionStatus}
                onChange={(e) => setResolutionStatus(e.target.value as any)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
              >
                <option value="Resolved - Ledger Adjusted">Resolved — Post Adjusting Credit Note / Ledger Correction</option>
                <option value="Resolved - Proof Verified">Resolved — Customer Proof & Bank UTR Accepted</option>
                <option value="Pending Review">Pending Review — Under Investigation with Sales / Operations</option>
                <option value="Dispute Upheld">Dispute Upheld — Reject Customer Claim (Maintain Original Balance)</option>
                <option value="Closed">Closed / Settled</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Finance Department Resolution Notes</label>
              <textarea
                rows={3}
                placeholder="e.g. Verified return note with warehouse manager. Credit Note #CN-2026-44 issued for ₹45,000. Balance reconciled."
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                required
                className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 leading-relaxed shadow-xs"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              Save Resolution
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
