import React, { useState } from 'react';
import { Channel, CommunicationLog, Invoice, Party, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate } from '../utils/calculations';
import { replacePlaceholders } from '../utils/reminderEngine';
import { X, Send, Mail, MessageSquare, PhoneCall, CheckCircle, AlertCircle } from 'lucide-react';

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  party: Party | null;
  invoice: Invoice | null;
  settings: SystemSettings;
  onSend: (log: Omit<CommunicationLog, 'id' | 'sentAt' | 'messageId'>) => void;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({
  isOpen,
  onClose,
  party,
  invoice,
  settings,
  onSend
}) => {
  if (!isOpen || !party) return null;

  const [channel, setChannel] = useState<Channel>('Email');
  const [selectedRuleId, setSelectedRuleId] = useState<string>('custom');
  const [customSubject, setCustomSubject] = useState<string>(
    invoice 
      ? `Payment Follow-up: Invoice #${invoice.invoiceNumber} (${formatCurrency(invoice.outstandingAmount, settings.currencySymbol)})`
      : `Outstanding Balance Follow-up: ${party.name}`
  );

  const defaultBody = invoice
    ? `Dear ${party.name},\n\nWe would like to remind you that Invoice #${invoice.invoiceNumber} for ${formatCurrency(invoice.outstandingAmount, settings.currencySymbol)} is pending for payment (Due Date: ${formatDisplayDate(invoice.dueDate)}).\n\nKindly process the payment at the earliest.\n\nBank Details:\nBank: ${settings.bankDetails.bankName}\nA/c: ${settings.bankDetails.accountNumber}\nIFSC: ${settings.bankDetails.ifscCode}\n\nWarm regards,\nFinance Team, ${settings.companyName}`
    : `Dear ${party.name},\n\nThis is a friendly reminder that your total outstanding ledger balance with ${settings.companyName} is ${formatCurrency(party.totalOutstanding, settings.currencySymbol)}.\n\nKindly arrange to clear the overdue invoices.\n\nRegards,\nAccounts Department`;

  const [customBody, setCustomBody] = useState<string>(defaultBody);
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  const handleRuleChange = (ruleId: string) => {
    setSelectedRuleId(ruleId);
    if (ruleId === 'custom') {
      setCustomBody(defaultBody);
      return;
    }
    const rule = settings.reminderRules.find(r => r.id === ruleId);
    if (rule) {
      const template = channel === 'Email' ? rule.emailTemplate : channel === 'WhatsApp' ? rule.whatsappTemplate : rule.smsTemplate;
      const interpolated = replacePlaceholders(template, party, invoice, settings);
      setCustomBody(interpolated.replace(/<br>/g, '\n').replace(/<\/?[^>]+(>|$)/g, ''));
      if (channel === 'Email') {
        setCustomSubject(replacePlaceholders(rule.emailSubject, party, invoice, settings));
      }
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');

    setTimeout(() => {
      onSend({
        partyId: party.id,
        partyName: party.name,
        invoiceId: invoice?.id,
        invoiceNumber: invoice?.invoiceNumber,
        channel,
        type: invoice ? 'Manual Reminder' : 'Statement of Account',
        templateName: selectedRuleId === 'custom' ? 'Custom Manual Communication' : `Rule: ${selectedRuleId}`,
        recipient: channel === 'Email' ? (party.email || 'N/A') : (party.phone || 'N/A'),
        subject: channel === 'Email' ? customSubject : undefined,
        messageBody: customBody,
        status: 'Delivered',
        ruleId: selectedRuleId !== 'custom' ? selectedRuleId : undefined
      });

      setStatus('success');
      setTimeout(() => {
        setStatus('idle');
        onClose();
      }, 1000);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg border border-blue-200">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Send Direct Reminder</h3>
              <p className="text-xs text-slate-500">Recipient: {party.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSend} className="p-6 space-y-4">
          {/* Target details */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
            <div>
              <div className="font-bold text-slate-900">{party.name}</div>
              <div className="text-slate-500 mt-0.5">{party.email} • {party.phone}</div>
            </div>
            <div className="text-right">
              <div className="text-slate-500 font-medium">Total Pending:</div>
              <div className="font-bold text-amber-700 font-mono text-sm">
                {formatCurrency(invoice ? invoice.outstandingAmount : party.totalOutstanding, settings.currencySymbol)}
              </div>
            </div>
          </div>

          {/* Channel Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Communication Channel</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => { setChannel('Email'); handleRuleChange(selectedRuleId); }}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold border transition-colors cursor-pointer shadow-xs ${
                  channel === 'Email' 
                    ? 'bg-blue-50 border-blue-500 text-blue-700' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Mail className="w-4 h-4 text-blue-600" />
                Email
              </button>
              <button
                type="button"
                onClick={() => { setChannel('WhatsApp'); handleRuleChange(selectedRuleId); }}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold border transition-colors cursor-pointer shadow-xs ${
                  channel === 'WhatsApp' 
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-700' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                WhatsApp
              </button>
              <button
                type="button"
                onClick={() => { setChannel('SMS'); handleRuleChange(selectedRuleId); }}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold border transition-colors cursor-pointer shadow-xs ${
                  channel === 'SMS' 
                    ? 'bg-sky-50 border-sky-500 text-sky-700' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <PhoneCall className="w-4 h-4 text-sky-600" />
                SMS
              </button>
            </div>
          </div>

          {/* Quick Template Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Load Template Rule</label>
            <select
              value={selectedRuleId}
              onChange={(e) => handleRuleChange(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs cursor-pointer"
            >
              <option value="custom">Custom Message (Manual)</option>
              {settings.reminderRules.map(r => (
                <option key={r.id} value={r.id}>{r.label} ({r.severity})</option>
              ))}
            </select>
          </div>

          {/* Email Subject if Email */}
          {channel === 'Email' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Email Subject</label>
              <input
                type="text"
                value={customSubject}
                onChange={(e) => setCustomSubject(e.target.value)}
                required
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              />
            </div>
          )}

          {/* Message Body */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-bold text-slate-700">Message Content</label>
              <span className="text-[11px] text-slate-500">{customBody.length} characters</span>
            </div>
            <textarea
              rows={6}
              value={customBody}
              onChange={(e) => setCustomBody(e.target.value)}
              required
              className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed shadow-xs"
            />
          </div>

          {/* Send Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <div className="text-xs text-slate-500 flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
              Will be recorded in communication log
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={status === 'sending' || status === 'success'}
                className="px-5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {status === 'sending' ? (
                  <span>Dispatching...</span>
                ) : status === 'success' ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-emerald-300" />
                    Sent Successfully
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Dispatch Reminder
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
