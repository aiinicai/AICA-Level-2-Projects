import React from 'react';
import { Invoice, Party, PaymentRecord, SystemSettings } from '../types';
import { formatCurrency, formatDisplayDate, getTodayDateString } from '../utils/calculations';
import { X, Printer, Download, Building2, Calendar, CheckCircle, Mail, Phone, MapPin } from 'lucide-react';

interface StatementOfAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  party: Party | null;
  invoices: Invoice[];
  payments: PaymentRecord[];
  settings: SystemSettings;
}

export const StatementOfAccountModal: React.FC<StatementOfAccountModalProps> = ({
  isOpen,
  onClose,
  party,
  invoices,
  payments,
  settings
}) => {
  if (!isOpen || !party) return null;

  const partyInvoices = invoices.filter(i => i.partyId === party.id);
  const partyPayments = payments.filter(p => p.partyId === party.id);
  const today = getTodayDateString();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-4xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 no-print">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg border border-blue-200">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Statement of Account</h3>
              <p className="text-xs text-slate-500">Formal ledger statement for {party.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 overflow-y-auto bg-white text-slate-900 font-sans space-y-6 print:p-0">
          {/* Company Letterhead */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{settings.companyName}</h1>
              <p className="text-xs text-slate-600 mt-1 max-w-md">{settings.companyAddress}</p>
              <div className="text-xs text-slate-600 mt-2 space-y-0.5">
                <div>GSTIN / Tax ID: <span className="font-semibold text-slate-800">{settings.companyGstOrTaxId}</span></div>
                <div>Email: {settings.companyEmail} | Tel: {settings.companyPhone}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="inline-block bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-lg">
                Statement of Account
              </div>
              <div className="text-xs text-slate-500 mt-2">
                <div>Date of Issue: <span className="font-semibold text-slate-800">{formatDisplayDate(today)}</span></div>
                <div>Statement Period: <span className="font-semibold text-slate-800">Financial Year 2026</span></div>
              </div>
            </div>
          </div>

          {/* Debtor Details & Summary Box */}
          <div className="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">Billed To</div>
              <div className="text-base font-bold text-slate-900">{party.name}</div>
              <div className="text-xs text-slate-600 mt-1 space-y-0.5">
                <div>{party.area}, {party.city}</div>
                <div>Email: {party.email || 'N/A'}</div>
                <div>Contact: {party.phone || 'N/A'}</div>
                <div>Account Manager / Rep: <span className="font-semibold text-slate-800">{party.representativeName}</span></div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col justify-between shadow-xs">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Total Net Balance Due</div>
                <div className="text-2xl font-black text-blue-700 mt-1 font-mono">
                  {formatCurrency(party.totalOutstanding, settings.currencySymbol)}
                </div>
              </div>
              <div className="text-xs text-slate-600 mt-2 pt-2 border-t border-slate-100 flex justify-between">
                <span>Overdue Portion: <strong className="text-rose-600 font-mono">{formatCurrency(party.overdueAmount, settings.currencySymbol)}</strong></span>
                <span>Max Overdue: <strong className="text-slate-800">{party.maxDaysOverdue} days</strong></span>
              </div>
            </div>
          </div>

          {/* Invoices Table */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Invoice Register</h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Invoice No</th>
                    <th className="py-2.5 px-3">Invoice Date</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3 text-right">Invoice Amount</th>
                    <th className="py-2.5 px-3 text-right">Paid Amount</th>
                    <th className="py-2.5 px-3 text-right font-bold text-slate-700">Balance Due</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                  {partyInvoices.map(inv => (
                    <tr key={inv.id} className="hover:bg-slate-50/80">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                      <td className="py-2.5 px-3 text-slate-600">{formatDisplayDate(inv.invoiceDate)}</td>
                      <td className="py-2.5 px-3 text-slate-600">{formatDisplayDate(inv.dueDate)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-500">{formatCurrency(inv.amount, settings.currencySymbol)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-600 font-semibold">{formatCurrency(inv.paidAmount, settings.currencySymbol)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">{formatCurrency(inv.outstandingAmount, settings.currencySymbol)}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' :
                          inv.status === 'Overdue' ? 'bg-rose-100 text-rose-700' :
                          inv.status === 'Due Today' ? 'bg-amber-100 text-amber-700' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {inv.status} {inv.daysOverdue > 0 ? `(${inv.daysOverdue}d)` : ''}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-slate-50 font-bold text-slate-900 border-t-2 border-slate-200">
                  <tr>
                    <td colSpan={3} className="py-2.5 px-3 text-right text-slate-500 uppercase tracking-wider text-[11px]">Totals:</td>
                    <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(party.totalInvoiced, settings.currencySymbol)}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-600">{formatCurrency(party.totalPaid, settings.currencySymbol)}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-blue-700 font-extrabold">{formatCurrency(party.totalOutstanding, settings.currencySymbol)}</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Payment History If Any */}
          {partyPayments.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Recent Receipts & Payments</h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Against Invoice</th>
                      <th className="py-2.5 px-3">Mode</th>
                      <th className="py-2.5 px-3">Reference / UTR</th>
                      <th className="py-2.5 px-3 text-right">Amount Received</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                    {partyPayments.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/80">
                        <td className="py-2 px-3 text-slate-600">{formatDisplayDate(p.paymentDate)}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">{p.invoiceNumber}</td>
                        <td className="py-2 px-3 text-slate-700">{p.paymentMode}</td>
                        <td className="py-2 px-3 font-mono text-xs text-slate-600">{p.referenceNumber}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-emerald-600">
                          {formatCurrency(p.amount, settings.currencySymbol)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Remittance Bank Information & Signatory Footer */}
          <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-200">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
              <div className="font-bold text-slate-900 mb-1.5">Remittance Bank Account Details</div>
              <div className="text-slate-600 space-y-1">
                <div>Bank: <span className="font-semibold text-slate-800">{settings.bankDetails.bankName}</span></div>
                <div>Account Name: <span className="font-semibold text-slate-800">{settings.bankDetails.accountName}</span></div>
                <div>Account Number: <span className="font-mono font-bold text-slate-900">{settings.bankDetails.accountNumber}</span></div>
                <div>IFSC Code: <span className="font-mono font-bold text-slate-900">{settings.bankDetails.ifscCode}</span></div>
                <div>UPI ID: <span className="font-mono text-blue-700 font-bold">{settings.bankDetails.upiId}</span></div>
              </div>
            </div>
            <div className="flex flex-col justify-end text-right text-xs">
              <div className="text-slate-500 mb-10">For {settings.companyName}</div>
              <div className="font-bold text-slate-900">{settings.authorizedUser.name}</div>
              <div className="text-slate-500">{settings.authorizedUser.role}</div>
              <div className="text-[10px] text-slate-400 mt-1">Computer-generated statement. No physical signature required.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
