import React, { useState } from 'react';
import {
  BalanceConfirmation,
  CommunicationLog,
  Invoice,
  Party,
  PaymentRecord,
  RiskLevel,
  SystemSettings
} from '../types';
import {
  formatCurrency,
  formatCompactCurrency,
  formatDisplayDate,
  formatDateTime
} from '../utils/calculations';
import { exportPartiesToExcel } from '../utils/excelHelper';
import {
  Search,
  Filter,
  Download,
  Building2,
  FileText,
  Send,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ChevronRight,
  X,
  Phone,
  Mail,
  MapPin,
  User,
  History,
  FileCheck
} from 'lucide-react';

interface DebtorsListProps {
  parties: Party[];
  invoices: Invoice[];
  payments: PaymentRecord[];
  commLogs: CommunicationLog[];
  confirmations: BalanceConfirmation[];
  settings: SystemSettings;
  selectedParty: Party | null;
  onSelectParty: (party: Party | null) => void;
  onOpenStatementModal: (party: Party) => void;
  onOpenPaymentModal: (invoice?: Invoice, party?: Party) => void;
  onOpenReminderModal: (party: Party, invoice?: Invoice) => void;
  onSendConfirmationRequest: (party: Party) => void;
  onUpdatePartyStatus: (partyId: string, status: Party['status'], notes?: string) => void;
  filterPreset?: string;
}

export const DebtorsList: React.FC<DebtorsListProps> = ({
  parties,
  invoices,
  payments,
  commLogs,
  confirmations,
  settings,
  selectedParty,
  onSelectParty,
  onOpenStatementModal,
  onOpenPaymentModal,
  onOpenReminderModal,
  onSendConfirmationRequest,
  onUpdatePartyStatus,
  filterPreset
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>(filterPreset === 'critical' ? 'Critical' : 'ALL');
  const [confirmationFilter, setConfirmationFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'outstanding' | 'overdue' | 'days' | 'name'>('outstanding');

  // Filter parties
  const filteredParties = parties.filter(party => {
    const matchesSearch = 
      party.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      party.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      party.area.toLowerCase().includes(searchTerm.toLowerCase()) ||
      party.representativeName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRisk = riskFilter === 'ALL' || party.riskScore === riskFilter;
    const matchesConf = confirmationFilter === 'ALL' || party.confirmationStatus === confirmationFilter;

    return matchesSearch && matchesRisk && matchesConf;
  }).sort((a, b) => {
    if (sortBy === 'outstanding') return b.totalOutstanding - a.totalOutstanding;
    if (sortBy === 'overdue') return b.overdueAmount - a.overdueAmount;
    if (sortBy === 'days') return b.maxDaysOverdue - a.maxDaysOverdue;
    return a.name.localeCompare(b.name);
  });

  const activeDrawerParty = selectedParty;
  const partyInvoices = activeDrawerParty ? invoices.filter(i => i.partyId === activeDrawerParty.id) : [];
  const partyPayments = activeDrawerParty ? payments.filter(p => p.partyId === activeDrawerParty.id) : [];
  const partyLogs = activeDrawerParty ? commLogs.filter(l => l.partyId === activeDrawerParty.id) : [];
  const partyConfirmation = activeDrawerParty ? confirmations.find(c => c.partyId === activeDrawerParty.id) : null;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Debtors Master Database</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {parties.length} Registered Debtors • {filteredParties.length} matching current filters
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => exportPartiesToExcel(parties)}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" />
            <span>Export Debtors Excel</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search party, city, rep..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs"
          />
        </div>

        {/* Risk Score Filter */}
        <select
          value={riskFilter}
          onChange={(e) => setRiskFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Risk Ratings</option>
          <option value="Low">🟢 Low Risk</option>
          <option value="Medium">🟡 Medium Risk</option>
          <option value="High">🟠 High Risk</option>
          <option value="Critical">🔴 Critical Risk</option>
        </select>

        {/* Confirmation Status Filter */}
        <select
          value={confirmationFilter}
          onChange={(e) => setConfirmationFilter(e.target.value)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="ALL">All Confirmation Statuses</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Difference Reported">Difference Reported</option>
          <option value="Awaiting Confirmation">Awaiting Confirmation</option>
          <option value="Sent">Sent</option>
          <option value="Not Sent">Not Sent</option>
        </select>

        {/* Sort Order */}
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
        >
          <option value="outstanding">Sort by Total Outstanding</option>
          <option value="overdue">Sort by Overdue Amount</option>
          <option value="days">Sort by Max Overdue Days</option>
          <option value="name">Sort by Party Name</option>
        </select>
      </div>

      {/* Debtors Master Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Party Details</th>
                <th className="py-3 px-4">Location / Sales Rep</th>
                <th className="py-3 px-4 text-center">Risk Score</th>
                <th className="py-3 px-4 text-right">Total Invoiced</th>
                <th className="py-3 px-4 text-right">Total Outstanding</th>
                <th className="py-3 px-4 text-right">Overdue Balance</th>
                <th className="py-3 px-4 text-center">Balance Confirmation</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {filteredParties.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500">
                    No debtors match your current search and filter criteria.
                  </td>
                </tr>
              ) : (
                filteredParties.map(party => (
                  <tr
                    key={party.id}
                    onClick={() => onSelectParty(party)}
                    className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${
                      selectedParty?.id === party.id ? 'bg-blue-50/60' : ''
                    }`}
                  >
                    {/* Party Name & Contact */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{party.name}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                        <span>{party.email || 'No email'}</span>
                        <span>•</span>
                        <span>{party.phone || 'No phone'}</span>
                      </div>
                    </td>

                    {/* City & Sales Rep */}
                    <td className="py-3 px-4">
                      <div className="text-slate-800 font-medium">{party.city}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">Rep: {party.representativeName}</div>
                    </td>

                    {/* Risk Badge */}
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        party.riskScore === 'Critical' ? 'bg-rose-100 text-rose-700' :
                        party.riskScore === 'High' ? 'bg-orange-100 text-orange-700' :
                        party.riskScore === 'Medium' ? 'bg-amber-100 text-amber-700' :
                        'bg-emerald-100 text-emerald-700'
                      }`}>
                        {party.riskScore}
                      </span>
                      {party.maxDaysOverdue > 0 && (
                        <div className="text-[10px] text-slate-400 mt-0.5">{party.maxDaysOverdue}d overdue</div>
                      )}
                    </td>

                    {/* Total Invoiced */}
                    <td className="py-3 px-4 text-right font-mono text-slate-500">
                      {formatCurrency(party.totalInvoiced, settings.currencySymbol)}
                    </td>

                    {/* Total Outstanding */}
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {formatCurrency(party.totalOutstanding, settings.currencySymbol)}
                    </td>

                    {/* Overdue Balance */}
                    <td className="py-3 px-4 text-right font-mono">
                      {party.overdueAmount > 0 ? (
                        <span className="text-rose-600 font-bold">
                          {formatCurrency(party.overdueAmount, settings.currencySymbol)}
                        </span>
                      ) : (
                        <span className="text-slate-400">₹0</span>
                      )}
                    </td>

                    {/* Confirmation Status */}
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        party.confirmationStatus === 'Confirmed' ? 'bg-emerald-100 text-emerald-700' :
                        party.confirmationStatus === 'Difference Reported' ? 'bg-rose-100 text-rose-700' :
                        party.confirmationStatus === 'Awaiting Confirmation' ? 'bg-amber-100 text-amber-700' :
                        party.confirmationStatus === 'Sent' ? 'bg-blue-100 text-blue-700' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {party.confirmationStatus}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onOpenStatementModal(party)}
                          title="Generate Statement of Account"
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onOpenReminderModal(party)}
                          title="Send Direct Reminder"
                          className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onOpenPaymentModal(undefined, party)}
                          title="Record Payment"
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <DollarSign className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Side Drawer for Selected Party Details */}
      {activeDrawerParty && (
        <div className="fixed inset-y-0 right-0 z-50 w-full max-w-xl bg-white border-l border-slate-200 shadow-2xl overflow-y-auto animate-in slide-in-from-right duration-200 flex flex-col">
          {/* Drawer Header */}
          <div className="p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-start sticky top-0 z-10">
            <div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  activeDrawerParty.riskScore === 'Critical' ? 'bg-rose-100 text-rose-700' :
                  activeDrawerParty.riskScore === 'High' ? 'bg-orange-100 text-orange-700' :
                  activeDrawerParty.riskScore === 'Medium' ? 'bg-amber-100 text-amber-700' :
                  'bg-emerald-100 text-emerald-700'
                }`}>
                  {activeDrawerParty.riskScore} Risk
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500">Account #{activeDrawerParty.id}</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-1">{activeDrawerParty.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{activeDrawerParty.area}, {activeDrawerParty.city}</p>
            </div>
            <button
              onClick={() => onSelectParty(null)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="p-6 space-y-6 flex-1 bg-white">
            {/* Balance Overview Stats */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500">Total Outstanding</span>
                <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                  {formatCurrency(activeDrawerParty.totalOutstanding, settings.currencySymbol)}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">{partyInvoices.length} invoices recorded</div>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500">Overdue Amount</span>
                <div className="text-xl font-bold font-mono text-rose-600 mt-1">
                  {formatCurrency(activeDrawerParty.overdueAmount, settings.currencySymbol)}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">Max {activeDrawerParty.maxDaysOverdue} days past due</div>
              </div>
            </div>

            {/* Contact & Sales Rep Actions */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="font-bold text-slate-800">Contact & Representative</span>
                <span className="text-slate-500">Rep: <strong className="text-slate-800">{activeDrawerParty.representativeName}</strong></span>
              </div>
              <div className="flex items-center justify-between text-slate-700">
                <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-slate-400" /> {activeDrawerParty.email || 'N/A'}</span>
                {activeDrawerParty.email && (
                  <a href={`mailto:${activeDrawerParty.email}`} className="text-blue-600 font-medium hover:underline">Send Email</a>
                )}
              </div>
              <div className="flex items-center justify-between text-slate-700">
                <span className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-slate-400" /> {activeDrawerParty.phone || 'N/A'}</span>
                {activeDrawerParty.phone && (
                  <a
                    href={`https://wa.me/${activeDrawerParty.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-600 font-medium hover:underline"
                  >
                    Open WhatsApp
                  </a>
                )}
              </div>
            </div>

            {/* Quick Actions Bar */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onOpenStatementModal(activeDrawerParty)}
                className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer shadow-xs"
              >
                <FileText className="w-4 h-4 text-blue-600" />
                <span>Statement</span>
              </button>
              <button
                onClick={() => onOpenReminderModal(activeDrawerParty)}
                className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer shadow-xs"
              >
                <Send className="w-4 h-4 text-amber-600" />
                <span>Send Reminder</span>
              </button>
              <button
                onClick={() => onSendConfirmationRequest(activeDrawerParty)}
                className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer shadow-xs"
              >
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span>Send Balance Conf</span>
              </button>
            </div>

            {/* Invoices List */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">Outstanding Invoices ({partyInvoices.length})</h4>
                <button
                  onClick={() => onOpenPaymentModal(undefined, activeDrawerParty)}
                  className="text-xs text-emerald-600 font-bold hover:underline cursor-pointer"
                >
                  + Record Payment
                </button>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/40">
                {partyInvoices.map(inv => (
                  <div key={inv.id} className="p-3 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-bold text-slate-900 font-mono">{inv.invoiceNumber}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Due: {formatDisplayDate(inv.dueDate)} ({inv.status})
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-slate-900">
                        {formatCurrency(inv.outstandingAmount, settings.currencySymbol)}
                      </div>
                      <button
                        onClick={() => onOpenPaymentModal(inv)}
                        className="text-[11px] text-blue-600 font-semibold hover:underline cursor-pointer mt-0.5"
                      >
                        Settle invoice
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Communication Log */}
            {partyLogs.length > 0 && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Communication History</h4>
                <div className="space-y-2 max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/40">
                  {partyLogs.map(log => (
                    <div key={log.id} className="p-2.5 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-800">{log.templateName}</span>
                        <span className="text-[10px] font-bold text-emerald-600">{log.channel} • {log.status}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 line-clamp-1">{log.messageBody}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{formatDateTime(log.sentAt)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Account Status Control */}
            <div className="pt-3 border-t border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Account Credit Status</label>
              <select
                value={activeDrawerParty.status}
                onChange={(e) => onUpdatePartyStatus(activeDrawerParty.id, e.target.value as any)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-xs cursor-pointer"
              >
                <option value="Active">Active — Normal Credit Flow</option>
                <option value="On Hold">On Hold — Fresh Dispatches Blocked</option>
                <option value="Disputed">Disputed — Under Audit / Dispute Resolution</option>
                <option value="Legal Notice">Legal Notice — Formal Recovery Initiated</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
