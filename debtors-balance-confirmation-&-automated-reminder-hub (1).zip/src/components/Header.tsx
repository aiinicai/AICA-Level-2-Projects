import React, { useState, useRef, useEffect } from 'react';
import { Lock, LogOut, ChevronDown, Upload, BarChart3, Settings, ShieldCheck, Mail, ExternalLink, RefreshCw } from 'lucide-react';
import { SystemSettings } from '../types';

export type NavTab = 
  | 'dashboard' 
  | 'debtors' 
  | 'invoices' 
  | 'ageing' 
  | 'confirmations' 
  | 'communications' 
  | 'analytics' 
  | 'upload' 
  | 'settings';

interface HeaderProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  settings: SystemSettings;
  onLockSession: () => void;
  onOpenCustomerPortalPreview?: () => void;
  pendingRemindersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  settings,
  onLockSession,
  onOpenCustomerPortalPreview,
  pendingRemindersCount
}) => {
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowMoreMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const primaryNavItems: { id: NavTab; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'debtors', label: 'Debtors' },
    { id: 'invoices', label: 'Invoices' },
    { id: 'ageing', label: 'Ageing' },
    { id: 'confirmations', label: 'Confirmations' }
  ];

  const secondaryNavItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'communications', label: 'Communications', icon: <Mail className="w-4 h-4" />, badge: pendingRemindersCount },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'upload', label: 'Excel Upload', icon: <Upload className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings & Security', icon: <Settings className="w-4 h-4" /> }
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-slate-300 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand title (Single text element only) */}
        <div className="shrink-0 flex items-center gap-2.5">
          <span className="text-base font-bold tracking-tight text-white select-none whitespace-nowrap">
            FinCollect Pro
          </span>
          <span className="hidden xl:inline text-[10px] font-semibold uppercase tracking-widest text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            CFO Suite
          </span>
        </div>

        {/* Zone 2: Navigation links */}
        <nav className="flex items-center gap-1 sm:gap-1.5">
          {primaryNavItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { onTabChange(item.id); setShowMoreMenu(false); }}
                className={`flex items-center px-3 py-1.5 rounded-lg text-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-slate-800 text-white font-semibold border border-slate-700 shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80 font-medium'
                }`}
              >
                {isActive && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 shrink-0"></span>}
                <span>{item.label}</span>
              </button>
            );
          })}

          {/* Desktop visible items for large screens */}
          <div className="hidden lg:flex items-center gap-1 sm:gap-1.5">
            {secondaryNavItems.slice(0, 2).map(item => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { onTabChange(item.id); setShowMoreMenu(false); }}
                  className={`relative flex items-center px-3 py-1.5 rounded-lg text-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-slate-800 text-white font-semibold border border-slate-700 shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80 font-medium'
                  }`}
                >
                  {isActive && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 shrink-0"></span>}
                  <span>{item.label}</span>
                  {item.badge && item.badge > 0 ? (
                    <span className="ml-1.5 px-1.5 py-0.2 bg-blue-500 text-white font-bold rounded-full text-[10px]">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>

          {/* More dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setShowMoreMenu(!showMoreMenu)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                secondaryNavItems.some(i => i.id === activeTab)
                  ? 'bg-slate-800 text-blue-400 font-semibold border border-slate-700'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <span>More</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-150 ${showMoreMenu ? 'rotate-180' : ''}`} />
            </button>

            {showMoreMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-800 rounded-xl shadow-xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                {secondaryNavItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      onTabChange(item.id);
                      setShowMoreMenu(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors cursor-pointer ${
                      activeTab === item.id 
                        ? 'bg-blue-600/20 text-blue-300 font-semibold' 
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-slate-400">{item.icon}</span>
                      <span className="whitespace-nowrap">{item.label}</span>
                    </div>
                    {item.badge && item.badge > 0 ? (
                      <span className="px-1.5 py-0.5 bg-blue-600 text-white font-bold rounded text-[10px]">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                ))}

                <div className="my-1.5 border-t border-slate-800" />

                {onOpenCustomerPortalPreview && (
                  <button
                    onClick={() => {
                      onOpenCustomerPortalPreview();
                      setShowMoreMenu(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs flex items-center gap-2.5 text-emerald-400 hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4 text-emerald-400" />
                    <span className="whitespace-nowrap">Customer Portal Demo</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </nav>

        {/* Zone 3: Primary actions (1-2 single-line controls) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onTabChange('upload')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-lg border border-blue-200 transition-colors cursor-pointer whitespace-nowrap shadow-xs"
          >
            <Upload className="w-3.5 h-3.5 text-blue-600" />
            <span>+ Upload Excel</span>
          </button>

          <button
            onClick={onLockSession}
            title={`Authorized User: ${settings.authorizedUser.name} (${settings.authorizedUser.role}) - Click to lock session`}
            className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
          >
            <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-[10px]">
              {settings.authorizedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <span className="hidden md:inline truncate max-w-[110px] font-medium">{settings.authorizedUser.name.split(' ')[0]}</span>
            <Lock className="w-3 h-3 text-slate-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
