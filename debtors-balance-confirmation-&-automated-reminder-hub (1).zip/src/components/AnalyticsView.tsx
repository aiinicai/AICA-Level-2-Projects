import React, { useState } from 'react';
import {
  BalanceConfirmation,
  CommunicationLog,
  Invoice,
  Party,
  PaymentRecord,
  SystemSettings
} from '../types';
import {
  formatCurrency,
  formatCompactCurrency,
  formatDisplayDate,
  formatDateTime
} from '../utils/calculations';
import {
  BarChart3,
  PieChart,
  TrendingUp,
  MapPin,
  User,
  Building2,
  FileText,
  History,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  Percent
} from 'lucide-react';

interface AnalyticsViewProps {
  parties: Party[];
  invoices: Invoice[];
  payments: PaymentRecord[];
  commLogs: CommunicationLog[];
  confirmations: BalanceConfirmation[];
  settings: SystemSettings;
  onOpenPartyDrawer: (party: Party) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  parties,
  invoices,
  payments,
  commLogs,
  confirmations,
  settings,
  onOpenPartyDrawer
}) => {
  // Drill-down hierarchy state: Area -> Representative -> Party -> Invoices
  const [selectedArea, setSelectedArea] = useState<string | null>(null);
  const [selectedRep, setSelectedRep] = useState<string | null>(null);
  const [selectedPartyId, setSelectedPartyId] = useState<string | null>(null);

  // Area aggregations
  const areaMap = new Map<string, { total: number; overdue: number; partyCount: number; repSet: Set<string> }>();
  parties.forEach(p => {
    const area = p.area || p.city || 'General';
    if (!areaMap.has(area)) {
      areaMap.set(area, { total: 0, overdue: 0, partyCount: 0, repSet: new Set() });
    }
    const r = areaMap.get(area)!;
    r.total += p.totalOutstanding;
    r.overdue += p.overdueAmount;
    r.partyCount += 1;
    if (p.representativeName) r.repSet.add(p.representativeName);
  });

  const areaList = Array.from(areaMap.entries()).map(([area, data]) => ({
    area,
    total: data.total,
    overdue: data.overdue,
    partyCount: data.partyCount,
    repCount: data.repSet.size
  })).sort((a, b) => b.total - a.total);

  // Representative aggregations
  const repMap = new Map<string, { total: number; overdue: number; partyCount: number; invoices: number }>();
  parties.forEach(p => {
    const rep = p.representativeName || 'Unassigned';
    if (!repMap.has(rep)) {
      repMap.set(rep, { total: 0, overdue: 0, partyCount: 0, invoices: 0 });
    }
    const r = repMap.get(rep)!;
    r.total += p.totalOutstanding;
    r.overdue += p.overdueAmount;
    r.partyCount += 1;
    r.invoices += p.invoiceCount;
  });

  const repList = Array.from(repMap.entries()).map(([rep, data]) => ({
    rep,
    total: data.total,
    overdue: data.overdue,
    partyCount: data.partyCount,
    invoices: data.invoices
  })).sort((a, b) => b.total - a.total);

  // Top Debtors Concentration (Pareto)
  const sortedParties = [...parties].sort((a, b) => b.totalOutstanding - a.totalOutstanding);
  const totalBook = parties.reduce((sum, p) => sum + p.totalOutstanding, 0) || 1;
  const top5Total = sortedParties.slice(0, 5).reduce((sum, p) => sum + p.totalOutstanding, 0);
  const top5Percentage = (top5Total / totalBook) * 100;

  // Drilldown queries
  const drilldownParties = parties.filter(p => {
    if (selectedArea && (p.area || p.city) !== selectedArea) return false;
    if (selectedRep && p.representativeName !== selectedRep) return false;
    return true;
  });

  const activeDrillParty = parties.find(p => p.id === selectedPartyId) || drilldownParties[0];
  const activeDrillInvoices = activeDrillParty ? invoices.filter(i => i.partyId === activeDrillParty.id) : [];
  const activeDrillLogs = activeDrillParty ? commLogs.filter(l => l.partyId === activeDrillParty.id) : [];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Executive Debtors Analytics & Concentration</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Multi-dimensional drilldown across territories, sales representatives, portfolio concentration, and collection velocity
        </p>
      </div>

      {/* Top Portfolio Concentration Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Pareto Concentration Card */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs lg:col-span-2">
          <div className="flex justify-between items-center mb-3">
            <div>
              <span className="text-xs font-bold uppercase text-slate-500">Debtor Portfolio Concentration</span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">Top 5 Debtors Hold {top5Percentage.toFixed(1)}% of Total Receivables</h3>
            </div>
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <Percent className="w-5 h-5" />
            </div>
          </div>

          <div className="space-y-3 mt-4">
            {sortedParties.slice(0, 5).map((p, idx) => {
              const share = (p.totalOutstanding / totalBook) * 100;
              return (
                <div key={p.id} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-slate-800">
                      {idx + 1}. {p.name} <span className="text-slate-400 font-normal">({p.city})</span>
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {formatCurrency(p.totalOutstanding, settings.currencySymbol)} ({share.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
                    <div
                      className={`h-full rounded-full ${
                        p.riskScore === 'Critical' ? 'bg-rose-500' :
                        p.riskScore === 'High' ? 'bg-orange-500' :
                        p.riskScore === 'Medium' ? 'bg-amber-500' : 'bg-blue-600'
                      }`}
                      style={{ width: `${Math.min(100, share * 3)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Territory Summary */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs">
          <span className="text-xs font-bold uppercase text-slate-500">Top Sales Territory Exposure</span>
          <div className="space-y-3 mt-3">
            {areaList.slice(0, 4).map(a => (
              <div
                key={a.area}
                onClick={() => setSelectedArea(selectedArea === a.area ? null : a.area)}
                className={`p-3 rounded-xl border transition-all cursor-pointer shadow-xs ${
                  selectedArea === a.area 
                    ? 'bg-blue-50 border-blue-500' 
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-900">{a.area}</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatCurrency(a.total, settings.currencySymbol)}
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                  <span>{a.partyCount} Debtors</span>
                  <span className="text-rose-600 font-semibold">Overdue: {formatCurrency(a.overdue, settings.currencySymbol)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Drill-down Module: Area -> Representative -> Party -> Invoices & Logs */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-bold text-slate-900">Interactive Receivables Drill-Down</h3>
            <p className="text-xs text-slate-500">
              Drill path: <strong className="text-blue-600 font-bold">Area → Representative → Party → Invoices → Communications</strong>
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {selectedArea && (
              <button
                onClick={() => setSelectedArea(null)}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg cursor-pointer"
              >
                Area: {selectedArea} ✕
              </button>
            )}
            {selectedRep && (
              <button
                onClick={() => setSelectedRep(null)}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg cursor-pointer"
              >
                Rep: {selectedRep} ✕
              </button>
            )}
          </div>
        </div>

        {/* Drill Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Level 1: Area & Representative selection */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">1. Select Representative</h4>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {repList.map(r => (
                <div
                  key={r.rep}
                  onClick={() => setSelectedRep(selectedRep === r.rep ? null : r.rep)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer text-xs ${
                    selectedRep === r.rep
                      ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                  }`}
                >
                  <div className="flex justify-between font-bold">
                    <span>{r.rep}</span>
                    <span className="font-mono text-slate-900">{formatCurrency(r.total, settings.currencySymbol)}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex justify-between">
                    <span>{r.partyCount} Debtors</span>
                    <span className="text-rose-600 font-semibold">Overdue: {formatCurrency(r.overdue, settings.currencySymbol)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Level 2: Debtors for this Territory / Rep */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              2. Debtors ({drilldownParties.length})
            </h4>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {drilldownParties.map(p => (
                <div
                  key={p.id}
                  onClick={() => setSelectedPartyId(p.id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer text-xs ${
                    activeDrillParty?.id === p.id
                      ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                  }`}
                >
                  <div className="flex justify-between font-bold">
                    <span>{p.name}</span>
                    <span className="font-mono text-slate-900">{formatCurrency(p.totalOutstanding, settings.currencySymbol)}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex justify-between items-center">
                    <span>{p.city}</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${
                      p.riskScore === 'Critical' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {p.riskScore}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Level 3: Invoice & Communication Detail */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                3. Ledger & Audit Trail
              </h4>
              {activeDrillParty && (
                <button
                  onClick={() => onOpenPartyDrawer(activeDrillParty)}
                  className="text-xs text-blue-600 font-bold hover:underline cursor-pointer"
                >
                  Open Profile
                </button>
              )}
            </div>

            {activeDrillParty ? (
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs max-h-72 overflow-y-auto">
                <div className="font-bold text-slate-900">{activeDrillParty.name}</div>
                <div className="text-slate-500 text-[11px]">
                  Total Invoiced: {formatCurrency(activeDrillParty.totalInvoiced, settings.currencySymbol)} • Max Overdue: {activeDrillParty.maxDaysOverdue} days
                </div>

                <div className="border-t border-slate-200 pt-2">
                  <div className="text-[11px] font-bold text-slate-700 mb-1">Invoices ({activeDrillInvoices.length})</div>
                  <div className="space-y-1.5">
                    {activeDrillInvoices.map(inv => (
                      <div key={inv.id} className="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-200 shadow-xs">
                        <span className="font-mono text-slate-800 font-medium">{inv.invoiceNumber}</span>
                        <span className="font-mono font-bold text-blue-700">
                          {formatCurrency(inv.outstandingAmount, settings.currencySymbol)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {activeDrillLogs.length > 0 && (
                  <div className="border-t border-slate-200 pt-2">
                    <div className="text-[11px] font-bold text-slate-700 mb-1">Communications Sent ({activeDrillLogs.length})</div>
                    <div className="space-y-1">
                      {activeDrillLogs.slice(0, 3).map(log => (
                        <div key={log.id} className="text-[10px] text-slate-600 bg-white p-1.5 rounded-lg border border-slate-100">
                          <span className="text-slate-900 font-semibold">{log.templateName}</span> • {formatDisplayDate(log.sentAt)} ({log.status})
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-slate-200">
                Select a debtor party to view itemized drill-down.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
