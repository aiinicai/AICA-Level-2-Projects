import React, { useState } from 'react';
import {
  BalanceConfirmation,
  Channel,
  CommunicationLog,
  Invoice,
  Party,
  ReminderRule,
  SystemSettings
} from '../types';
import {
  formatCurrency,
  formatDisplayDate,
  formatDateTime,
  getTodayDateString,
  calculateDaysBetween
} from '../utils/calculations';
import { EligibleReminder, replacePlaceholders } from '../utils/reminderEngine';
import {
  Mail,
  MessageSquare,
  Phone,
  Send,
  CheckCircle2,
  AlertCircle,
  Clock,
  Search,
  Filter,
  RefreshCw,
  Plus,
  ShieldCheck,
  Zap,
  Eye,
  FileCheck
} from 'lucide-react';

interface CommunicationsHubProps {
  commLogs: CommunicationLog[];
  todayEligibleReminders: EligibleReminder[];
  invoices: Invoice[];
  parties: Party[];
  confirmations: BalanceConfirmation[];
  settings: SystemSettings;
  onRunBatchReminders: (reminders: EligibleReminder[]) => void;
  onOpenReminderModal: (party: Party, invoice?: Invoice) => void;
  onRetryFailedMessage: (log: CommunicationLog) => void;
}

export const CommunicationsHub: React.FC<CommunicationsHubProps> = ({
  commLogs,
  todayEligibleReminders,
  invoices,
  parties,
  confirmations,
  settings,
  onRunBatchReminders,
  onOpenReminderModal,
  onRetryFailedMessage
}) => {
  const [activeTab, setActiveTab] = useState<'today' | 'upcoming' | 'sent' | 'failed' | 'awaiting'>('today');
  const [searchTerm, setSearchTerm] = useState('');
  const [channelFilter, setChannelFilter] = useState<string>('ALL');
  const [previewLog, setPreviewLog] = useState<CommunicationLog | null>(null);

  const todayStr = getTodayDateString();
  const partyMap = new Map(parties.map(p => [p.id, p]));

  // Today's pending eligible reminders
  const pendingToday = todayEligibleReminders.filter(r => !r.alreadySentToday);

  // Upcoming reminders (due in 1 to 14 days)
  const upcomingInvoices = invoices.filter(inv => {
    if (inv.outstandingAmount <= 0 || inv.status === 'Paid') return false;
    const diff = calculateDaysBetween(inv.dueDate, todayStr);
    return diff >= -14 && diff < 0; // due in next 14 days
  });

  // Sent logs & failed logs
  const sentLogs = commLogs.filter(l => l.status === 'Sent' || l.status === 'Delivered');
  const failedLogs = commLogs.filter(l => l.status === 'Failed');
  const awaitingConfirmations = confirmations.filter(c => c.status === 'Awaiting Confirmation' || c.status === 'Sent');

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Communications & Outbox Engine</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Multi-channel automated debtor notices, WhatsApp alerts, and statutory balance requests
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {pendingToday.length > 0 && (
            <button
              onClick={() => onRunBatchReminders(pendingToday)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>Dispatch Today's Batch ({pendingToday.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('today')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'today'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Today's Actionable Reminders</span>
          <span className="px-1.5 py-0.2 bg-blue-700/60 rounded-full text-[10px] font-bold">
            {pendingToday.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('upcoming')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'upcoming'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Upcoming Communications</span>
          <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded-full text-[10px] font-bold">
            {upcomingInvoices.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('sent')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'sent'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
          <span>Sent Dispatch Logs</span>
          <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded-full text-[10px] font-bold">
            {sentLogs.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('failed')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'failed'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
          <span>Failed / Bounced</span>
          <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded-full text-[10px] font-bold">
            {failedLogs.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('awaiting')}
          className={`px-3.5 py-2 rounded-lg text-xs transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'awaiting'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 font-medium'
          }`}
        >
          <FileCheck className="w-3.5 h-3.5 text-blue-500" />
          <span>Awaiting Confirmations</span>
          <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded-full text-[10px] font-bold">
            {awaitingConfirmations.length}
          </span>
        </button>
      </div>

      {/* Tab 1: Today's Reminders */}
      {activeTab === 'today' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex justify-between items-center text-xs">
            <span className="text-slate-700 font-medium">
              Triggered automatically based on your configured due-date and overdue cadence rules:
            </span>
            {pendingToday.length > 0 && (
              <button
                onClick={() => onRunBatchReminders(pendingToday)}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg cursor-pointer shadow-xs"
              >
                Send All {pendingToday.length} Reminders
              </button>
            )}
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Debtor Party</th>
                  <th className="py-3 px-4">Invoice Number</th>
                  <th className="py-3 px-4">Trigger Rule</th>
                  <th className="py-3 px-4 text-right">Outstanding Amount</th>
                  <th className="py-3 px-4 text-center">Channels</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                {pendingToday.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-10 text-center text-slate-500">
                      No pending automated reminders due for dispatch today.
                    </td>
                  </tr>
                ) : (
                  pendingToday.map((rem, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{rem.party.name}</div>
                        <div className="text-[11px] text-slate-500">{rem.party.email || rem.party.phone}</div>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {rem.invoice.invoiceNumber}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">
                          {rem.rule.label}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(rem.invoice.outstandingAmount, settings.currencySymbol)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {rem.channels.map(ch => (
                            <span key={ch} className="px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-semibold">
                              {ch}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => onOpenReminderModal(rem.party, rem.invoice)}
                          className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold cursor-pointer"
                        >
                          Send Now
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Upcoming Communications */}
      {activeTab === 'upcoming' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Party Name</th>
                <th className="py-3 px-4">Invoice Number</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Days Left</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-center">Upcoming Rule Trigger</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {upcomingInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-slate-500">
                    No upcoming invoice deadlines in the next 14 days.
                  </td>
                </tr>
              ) : (
                upcomingInvoices.map(inv => {
                  const daysLeft = Math.abs(calculateDaysBetween(inv.dueDate, todayStr));
                  const party = partyMap.get(inv.partyId);

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-bold text-slate-900">{inv.partyName}</td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-800">{inv.invoiceNumber}</td>
                      <td className="py-3 px-4 text-slate-700">{formatDisplayDate(inv.dueDate)}</td>
                      <td className="py-3 px-4">
                        <span className="text-amber-700 font-bold">{daysLeft} days remaining</span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(inv.outstandingAmount, settings.currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {daysLeft <= 1 ? '1 Day Before' : daysLeft <= 3 ? '3 Days Before' : '7 Days Before'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 3: Sent Dispatch Logs */}
      {activeTab === 'sent' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Message ID & Sent Time</th>
                <th className="py-3 px-4">Party & Recipient</th>
                <th className="py-3 px-4">Channel & Type</th>
                <th className="py-3 px-4">Template / Subject</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Preview</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {sentLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-slate-500">
                    No communication dispatch logs recorded yet.
                  </td>
                </tr>
              ) : (
                sentLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4">
                      <div className="font-mono text-slate-900 font-bold">{log.messageId}</div>
                      <div className="text-[10px] text-slate-400">{formatDateTime(log.sentAt)}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{log.partyName}</div>
                      <div className="text-[11px] text-slate-500">{log.recipient}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{log.type}</div>
                      <div className="text-[10px] text-blue-600 font-bold">{log.channel}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-700 truncate max-w-xs">{log.subject || log.templateName}</div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                        {log.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => setPreviewLog(log)}
                        className="p-1 text-slate-500 hover:text-blue-600 rounded hover:bg-slate-100 cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 4: Failed Communications */}
      {activeTab === 'failed' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Party</th>
                <th className="py-3 px-4">Channel & Recipient</th>
                <th className="py-3 px-4">Failure Reason</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {failedLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-slate-500">
                    No failed or bounced communications recorded. Perfect delivery health!
                  </td>
                </tr>
              ) : (
                failedLogs.map(log => (
                  <tr key={log.id}>
                    <td className="py-3 px-4 font-bold text-slate-900">{log.partyName}</td>
                    <td className="py-3 px-4 text-slate-700">{log.channel} ({log.recipient})</td>
                    <td className="py-3 px-4 text-rose-600 font-semibold">{log.errorReason || 'Bounced / Invalid Address'}</td>
                    <td className="py-3 px-4 text-slate-400">{formatDateTime(log.sentAt)}</td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => onRetryFailedMessage(log)}
                        className="px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold cursor-pointer hover:bg-rose-100 shadow-xs"
                      >
                        Retry Send
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 5: Awaiting Confirmations */}
      {activeTab === 'awaiting' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Party</th>
                <th className="py-3 px-4">Statement As Of</th>
                <th className="py-3 px-4 text-right">Outstanding Amount</th>
                <th className="py-3 px-4">Sent On</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
              {awaitingConfirmations.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-slate-500">
                    No balance confirmation requests pending.
                  </td>
                </tr>
              ) : (
                awaitingConfirmations.map(conf => (
                  <tr key={conf.id}>
                    <td className="py-3 px-4 font-bold text-slate-900">{conf.partyName}</td>
                    <td className="py-3 px-4 text-slate-700">{formatDisplayDate(conf.asOfDate)}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {formatCurrency(conf.totalLedgerBalance, settings.currencySymbol)}
                    </td>
                    <td className="py-3 px-4 text-slate-400">{formatDateTime(conf.sentAt)}</td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700">
                        {conf.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Message Preview Modal */}
      {previewLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <div>
                <h3 className="text-sm font-bold text-slate-900">{previewLog.templateName}</h3>
                <p className="text-xs text-slate-500">Ref: {previewLog.messageId} • {previewLog.channel}</p>
              </div>
              <button
                onClick={() => setPreviewLog(null)}
                className="text-xs font-bold text-slate-400 hover:text-slate-800 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed max-h-72 overflow-y-auto">
              {previewLog.messageBody}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setPreviewLog(null)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
