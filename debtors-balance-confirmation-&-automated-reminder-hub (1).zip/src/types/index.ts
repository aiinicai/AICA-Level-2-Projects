export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type InvoiceStatus = 
  | 'Current' 
  | 'Due Soon' 
  | 'Due Today' 
  | 'Overdue' 
  | 'Paid' 
  | 'Partially Paid' 
  | 'Disputed';

export type ConfirmationStatus = 
  | 'Not Sent'
  | 'Sent'
  | 'Delivered'
  | 'Awaiting Confirmation'
  | 'Confirmed'
  | 'Difference Reported';

export type Channel = 'Email' | 'WhatsApp' | 'SMS';

export type CommStatus = 'Scheduled' | 'Sent' | 'Delivered' | 'Failed';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  partyId: string;
  partyName: string;
  invoiceDate: string; // YYYY-MM-DD
  dueDate: string;     // YYYY-MM-DD
  amount: number;
  paidAmount: number;
  outstandingAmount: number;
  daysOutstanding: number;
  daysOverdue: number;
  status: InvoiceStatus;
  city: string;
  area: string;
  representativeName: string;
  email: string;
  phone: string;
  disputeReason?: string;
  lastReminderDate?: string;
  remindersSentCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Party {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  area: string;
  representativeName: string;
  creditLimit: number;
  riskScore: RiskLevel;
  totalInvoiced: number;
  totalPaid: number;
  totalOutstanding: number;
  overdueAmount: number;
  maxDaysOverdue: number;
  invoiceCount: number;
  overdueInvoiceCount: number;
  status: 'Active' | 'On Hold' | 'Disputed' | 'Legal Notice';
  confirmationStatus: ConfirmationStatus;
  lastConfirmationToken?: string;
  lastConfirmationDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentRecord {
  id: string;
  receiptNumber?: string;
  invoiceId?: string;
  invoiceNumber?: string;
  partyId: string;
  partyName: string;
  paymentDate: string;
  amount: number;
  paymentMode: 'Bank Transfer (NEFT/RTGS)' | 'Cheque' | 'UPI' | 'Direct Debit' | 'Credit Card' | 'Cash';
  referenceNumber: string;
  notes?: string;
  recordedBy: string;
  createdAt: string;
}

export interface ReminderRule {
  id: string;
  triggerType?: 'days_before' | 'on_due_date' | 'days_overdue' | 'BeforeDue' | 'OnDueDate' | 'AfterDue';
  days?: number; // e.g. -7, -3, -1, 0, 1, 3, 7, 15, 30, 60
  daysOffset?: number;
  type?: 'BeforeDue' | 'OnDueDate' | 'AfterDue';
  label: string;
  channels: Channel[];
  enabled?: boolean;
  isEnabled?: boolean;
  emailSubject?: string;
  emailTemplate?: string;
  whatsappTemplate?: string;
  smsTemplate?: string;
  template?: string;
  severity?: 'Gentle' | 'Firm' | 'Urgent' | 'Final Notice' | 'Legal Warning';
}

export interface CommunicationLog {
  id: string;
  partyId: string;
  partyName: string;
  invoiceId?: string;
  invoiceNumber?: string;
  channel: Channel;
  type: 
    | 'Automated Reminder' 
    | 'Manual Reminder' 
    | 'Balance Confirmation Request' 
    | 'Statement of Account' 
    | 'Payment Receipt' 
    | 'Dispute Escalation' 
    | 'Legal Notice'
    | 'Reminder'
    | string;
  templateName: string;
  recipient: string;
  subject?: string;
  messageBody: string;
  sentAt: string;
  status: CommStatus;
  messageId: string;
  errorReason?: string;
  ruleId?: string;
  triggerDays?: number;
  deliveredAt?: string;
  metadata?: Record<string, any>;
}

export interface BalanceConfirmationInvoiceItem {
  invoiceNumber: string;
  date: string;
  dueDate: string;
  originalAmount: number;
  paidAmount: number;
  outstanding: number;
  status: string;
}

export interface BalanceConfirmation {
  id: string;
  partyId: string;
  partyName: string;
  email: string;
  phone: string;
  token: string;
  expiresAt: string;
  asOfDate: string;
  totalLedgerBalance: number;
  invoices: BalanceConfirmationInvoiceItem[];
  status: ConfirmationStatus;
  sentAt: string;
  channelSent: Channel;
  respondedAt?: string;
  confirmedAmount?: number;
  differenceAmount?: number;
  differenceReason?: string;
  customerRemarks?: string;
  customerSignatoryName?: string;
  customerSignatoryDesignation?: string;
  digitalSignatureHash?: string;
  financeActionStatus?: 'Pending Review' | 'Resolved - Ledger Adjusted' | 'Disputed & In Audit' | 'Difference Cleared' | 'Resolved - Proof Verified' | 'Dispute Upheld' | 'Closed';
  financeActionNotes?: string;
  financeResolutionNotes?: string;
  resolvedAt?: string;
  financeResolvedAt?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  entityType?: string;
  entityId?: string;
  details: string;
  user?: string;
  performedBy?: string;
  userRole?: string;
  timestamp: string;
}

export interface RiskThresholds {
  mediumOverdueDays: number;
  highOverdueDays: number;
  criticalOverdueDays: number;
  criticalOutstandingAmount: number;
}

export interface SystemSettings {
  companyName: string;
  companyAddress: string;
  companyEmail: string;
  companyPhone: string;
  companyGstOrTaxId: string;
  bankDetails: {
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    accountName: string;
    upiId: string;
  };
  currencySymbol: string;
  authorizedUser: {
    name: string;
    email: string;
    role: string;
    pin: string;
    passwordHash: string;
    sessionTimeoutMinutes: number;
  };
  riskThresholds: RiskThresholds;
  reminderRules: ReminderRule[];
  senderConfig: {
    emailSender: string;
    smsSenderId: string;
    whatsappBusinessNumber: string;
    autoSendEnabled: boolean;
  };
}

export interface RawExcelRow {
  [key: string]: any;
}

export interface ValidatedExcelRow {
  rowNumber: number;
  invoiceDate: string;
  invoiceNumber: string;
  dueDate: string;
  partyName: string;
  city: string;
  area: string;
  representativeName: string;
  email: string;
  contactNumber: string;
  invoiceAmount: number;
  paidAmount?: number;
  isValid: boolean;
  errors: string[];
  warnings: string[];
  isDuplicate?: boolean;
}

export interface AgeingBucketSummary {
  bucket: 'Current (Not Due)' | '1 - 30 Days' | '31 - 60 Days' | '61 - 90 Days' | '91 - 180 Days' | '180+ Days';
  amount: number;
  invoiceCount: number;
  partyCount: number;
  percentage: number;
}

export interface DashboardMetrics {
  totalOutstanding: number;
  currentOutstanding: number;
  dueTodayAmount: number;
  dueTodayCount: number;
  dueIn7DaysAmount: number;
  dueIn7DaysCount: number;
  overdueAmount: number;
  overdueCount: number;
  totalDebtorsCount: number;
  confirmationPendingCount: number;
  confirmationConfirmedCount: number;
  confirmationDisputedCount: number;
  remindersDueTodayCount: number;
  failedCommunicationsCount: number;
  criticalRiskCount: number;
  highRiskCount: number;
  totalInvoiced: number;
  totalCollected: number;
}
