# Ind AS 116 Enterprise Suite v6.1.4
## AICA Level 2 Capstone Project

**Author:** CA Satish L Gupta  
**Project:** Ind AS 116 Enterprise Suite v6.1.4

This project is an AI-assisted, browser-based lease accounting and finance workflow tool for Accounts & Finance professionals.

### Main capabilities
- Lease portfolio management
- Lease liability and ROU asset measurement
- Amortisation schedules
- Journal-entry support
- Lease modification / remeasurement
- Interest-free security deposit unwinding under Ind AS 109
- CPI / variable lease analysis
- CFO-oriented analytics
- Portfolio disclosures
- Expiring lease monitoring
- Short-term and low-value lease exemption support
- Import/export, backup/restore and Self-Test

### How to run
Open `04_Executable/index.html` in Google Chrome or Microsoft Edge. Use **Load Demo** to populate sample data for demonstration.

### Important
The application is a professional decision-support / workflow tool. It should be validated against applicable accounting policies, lease contracts and Ind AS requirements before use in statutory financial reporting.

### AICA submission
The ZIP contains the project summary, AI prompt file, example data, executable application and supporting documents.
