#!/usr/bin/env python3
"""
Simple Accounting Software (Double-Entry)
==========================================
Built with PyQt6 + SQLAlchemy + SQLite.

Features:
  - Chart of Accounts (Assets / Liabilities / Income / Expense / Equity)
  - Voucher Entry (Journal / Payment / Receipt / Sales / Purchase) with
    mandatory debit = credit validation before saving
  - Ledger view for any account (running balance)
  - Trial Balance
  - Profit & Loss Statement
  - Balance Sheet

Run:
    pip install PyQt6 SQLAlchemy
    python accounting_app.py

Data is stored in "accounting.db" (SQLite) in the same folder as this file.
"""

import sys
import os
import hashlib
import secrets


def _show_fatal_error(message):
    """Show a fatal startup error in the most reliable way available,
    so it's visible even if the console window closes instantly."""
    print(message)
    try:
        import tkinter
        from tkinter import messagebox
        root = tkinter.Tk()
        root.withdraw()
        messagebox.showerror("Accounting App - Startup Error", message)
        root.destroy()
    except Exception:
        pass
    try:
        input("\nPress Enter to close this window...")
    except Exception:
        pass


try:
    from datetime import date, datetime, timedelta
    from decimal import Decimal, InvalidOperation

    from sqlalchemy import (
        create_engine, Column, Integer, String, Float, Date, ForeignKey,
        Enum as SAEnum, func
    )
    from sqlalchemy.orm import declarative_base, relationship, sessionmaker
    import enum

    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QFormLayout, QLabel, QLineEdit, QComboBox, QPushButton, QTableWidget,
        QTableWidgetItem, QTabWidget, QMessageBox, QDateEdit, QDoubleSpinBox,
        QHeaderView, QGroupBox, QSpacerItem, QSizePolicy, QDialog,
        QDialogButtonBox, QTextEdit, QAbstractItemView, QCheckBox, QFileDialog
    )
    from PyQt6.QtCore import Qt, QDate, QEvent, QObject
    from PyQt6.QtGui import QFont
except Exception:
    import traceback
    _show_fatal_error(
        "Failed to start Accounting App - a required package is missing "
        "or failed to load.\n\n"
        "Try running this in Command Prompt to fix it:\n"
        "  py -m pip install PyQt6 SQLAlchemy\n\n"
        "Full error details:\n\n" + traceback.format_exc()
    )
    sys.exit(1)

# --------------------------------------------------------------------------
# Tally-style theme (navy blue header/accent, gold highlight, light blue
# background)
# --------------------------------------------------------------------------

NAVY = "#123C6E"
NAVY_DARK = "#0C2B50"
NAVY_LIGHT = "#1B4C8C"
GOLD = "#F2A93C"
BG_LIGHT_BLUE = "#EAF3FB"
WHITE = "#FFFFFF"
TEXT_DARK = "#10243E"

STYLE_SHEET = f"""
QMainWindow, QWidget {{
    background-color: {BG_LIGHT_BLUE};
    color: {TEXT_DARK};
    font-size: 10pt;
}}

QTabWidget::pane {{
    border: 1px solid {NAVY};
    background-color: {BG_LIGHT_BLUE};
    top: -1px;
}}

QTabBar::tab {{
    background-color: {NAVY};
    color: {WHITE};
    padding: 8px 18px;
    margin-right: 2px;
    font-weight: bold;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}}

QTabBar::tab:selected {{
    background-color: {GOLD};
    color: {NAVY_DARK};
}}

QTabBar::tab:hover:!selected {{
    background-color: {NAVY_LIGHT};
}}

QGroupBox {{
    border: 1px solid {NAVY};
    border-radius: 4px;
    margin-top: 10px;
    font-weight: bold;
    color: {NAVY_DARK};
    background-color: {WHITE};
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: {NAVY_DARK};
}}

QPushButton {{
    background-color: {NAVY};
    color: {WHITE};
    border: 2px solid transparent;
    border-radius: 4px;
    padding: 6px 16px;
    font-weight: bold;
}}

QPushButton:hover {{
    background-color: {NAVY_LIGHT};
}}

QPushButton:pressed {{
    background-color: {GOLD};
    color: {NAVY_DARK};
}}

QPushButton:focus, QPushButton:default {{
    border: 2px solid {GOLD};
}}

QLineEdit, QComboBox, QDateEdit, QTextEdit {{
    background-color: {WHITE};
    border: 1px solid {NAVY};
    border-radius: 3px;
    padding: 4px;
    selection-background-color: {GOLD};
    selection-color: {NAVY_DARK};
}}

QLineEdit:focus, QComboBox:focus, QDateEdit:focus {{
    border: 2px solid {GOLD};
}}

QTableWidget {{
    background-color: {WHITE};
    gridline-color: #C7D9EC;
    border: 1px solid {NAVY};
    alternate-background-color: {BG_LIGHT_BLUE};
    selection-background-color: {GOLD};
    selection-color: {NAVY_DARK};
}}

QHeaderView::section {{
    background-color: {NAVY};
    color: {WHITE};
    padding: 6px;
    border: none;
    border-right: 1px solid {NAVY_DARK};
    font-weight: bold;
}}

QLabel {{
    color: {TEXT_DARK};
}}

QMessageBox {{
    background-color: {BG_LIGHT_BLUE};
}}

QDialog {{
    background-color: {BG_LIGHT_BLUE};
}}

QScrollBar:vertical {{
    background: {BG_LIGHT_BLUE};
    width: 14px;
}}
QScrollBar::handle:vertical {{
    background: {NAVY};
    border-radius: 6px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {NAVY_LIGHT};
}}
"""

# --------------------------------------------------------------------------
# Database setup
# --------------------------------------------------------------------------

if getattr(sys, "frozen", False):
    # Running as a PyInstaller-built .exe: __file__ would point to a
    # temporary extraction folder, not the exe's real location, so the
    # database would vanish between runs unless we use sys.executable
    # instead.
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "accounting.db")
engine = create_engine(f"sqlite:///{DB_PATH}", echo=False)
Base = declarative_base()
Session = sessionmaker(bind=engine)


class AccountType(enum.Enum):
    ASSET = "Asset"
    LIABILITY = "Liability"
    EQUITY = "Equity"
    INCOME = "Income"
    EXPENSE = "Expense"


# Which side is the "natural" (increase) balance for each account type
DEBIT_NATURE = {AccountType.ASSET, AccountType.EXPENSE}
CREDIT_NATURE = {AccountType.LIABILITY, AccountType.EQUITY, AccountType.INCOME}

# Sub-categories for a properly grouped Balance Sheet. Only meaningful for
# Asset/Liability accounts — Capital/Drawings/Cash/Bank/Purchase/Sales are
# already identified by name elsewhere in the app.
ASSET_SUB_CATEGORIES = ["Fixed Asset", "Current Asset"]
LIABILITY_SUB_CATEGORIES = ["Current Liability", "Loan & Advance"]


class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    type = Column(SAEnum(AccountType), nullable=False)
    opening_balance = Column(Float, default=0.0)
    # opening balance is stored as a signed number in the account's natural
    # direction (e.g. positive Asset opening balance = debit balance)
    sub_category = Column(String, nullable=True)
    # Only meaningful for ASSET/LIABILITY accounts, used to group the
    # Balance Sheet properly: "Fixed Asset" / "Current Asset" (assets),
    # "Current Liability" / "Loan & Advance" (liabilities). Left blank for
    # accounts that don't need this (Cash/Bank/Capital/Drawings/etc. are
    # already identified by name elsewhere in the app).

    entries = relationship("VoucherEntry", back_populates="account")

    def __repr__(self):
        return f"<Account {self.name} ({self.type.value})>"


class VoucherType(enum.Enum):
    CASH = "Cash"
    BANK = "Bank"
    PURCHASE = "Purchase"
    SALE = "Sale"
    JOURNAL = "Journal"


# The account each voucher type's "main leg" is always posted to (matches
# the fixed_account_name used in the Cash/Bank/Purchase/Sale entry tabs).
# Used by the Day Book to show one row per voucher instead of one per line.
MAIN_LEG_ACCOUNT_NAME = {
    VoucherType.CASH: "Cash in Hand",
    VoucherType.BANK: "Bank Account",
    VoucherType.PURCHASE: "Purchase Account",
    VoucherType.SALE: "Sales Account",
}


def get_voucher_display_type(voucher_type, fixed_side=None):
    """Human-friendly voucher type label — Cash/Bank split into Receipt
    vs Payment based on which side the main leg (Cash in Hand/Bank
    Account) sits on."""
    if voucher_type == VoucherType.CASH:
        return "Cash Receipt" if fixed_side == "debit" else "Cash Payment"
    if voucher_type == VoucherType.BANK:
        return "Bank Receipt" if fixed_side == "debit" else "Bank Payment"
    return voucher_type.value


def get_voucher_label_for_saved(voucher):
    """Same label as get_voucher_display_type, but derived from an
    already-saved voucher by inspecting its main-leg entry."""
    main_account_name = MAIN_LEG_ACCOUNT_NAME.get(voucher.type)
    if main_account_name:
        main_entry = next(
            (e for e in voucher.entries if e.account.name == main_account_name), None
        )
        if main_entry is not None:
            fixed_side = "debit" if main_entry.debit > 0 else "credit"
            return get_voucher_display_type(voucher.type, fixed_side)
    return voucher.type.value


class Voucher(Base):
    __tablename__ = "vouchers"
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, default=date.today)
    type = Column(SAEnum(VoucherType), nullable=False)
    narration = Column(String, default="")
    reference = Column(String, default="")

    entries = relationship(
        "VoucherEntry", back_populates="voucher", cascade="all, delete-orphan"
    )
    stock_entries = relationship(
        "VoucherStockEntry", back_populates="voucher", cascade="all, delete-orphan"
    )


class VoucherEntry(Base):
    __tablename__ = "voucher_entries"
    id = Column(Integer, primary_key=True)
    voucher_id = Column(Integer, ForeignKey("vouchers.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    debit = Column(Float, default=0.0)
    credit = Column(Float, default=0.0)

    voucher = relationship("Voucher", back_populates="entries")
    account = relationship("Account", back_populates="entries")


class StockItem(Base):
    __tablename__ = "stock_items"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    unit = Column(String, default="Nos")
    opening_qty = Column(Float, default=0.0)
    opening_rate = Column(Float, default=0.0)

    stock_entries = relationship("VoucherStockEntry", back_populates="stock_item")

    def __repr__(self):
        return f"<StockItem {self.name}>"


class VoucherStockEntry(Base):
    __tablename__ = "voucher_stock_entries"
    id = Column(Integer, primary_key=True)
    voucher_id = Column(Integer, ForeignKey("vouchers.id"), nullable=False)
    stock_item_id = Column(Integer, ForeignKey("stock_items.id"), nullable=False)
    quantity = Column(Float, default=0.0)
    rate = Column(Float, default=0.0)
    amount = Column(Float, default=0.0)

    voucher = relationship("Voucher", back_populates="stock_entries")
    stock_item = relationship("StockItem", back_populates="stock_entries")


class AppCredential(Base):
    __tablename__ = "app_credentials"
    id = Column(Integer, primary_key=True)
    username = Column(String, nullable=False)
    password_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False)


Base.metadata.create_all(engine)


def _ensure_column(table_name, column_name, column_def):
    """Lightweight migration: create_all() only creates missing TABLES, it
    won't add a new COLUMN to a table that already exists (e.g. an older
    accounting.db from before this field existed)."""
    with engine.connect() as conn:
        existing_cols = [row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table_name})")]
        if column_name not in existing_cols:
            conn.exec_driver_sql(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_def}")
            conn.commit()


_ensure_column("accounts", "sub_category", "VARCHAR")


def _hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000
    ).hex()


def has_credential():
    session = Session()
    exists = session.query(AppCredential).first() is not None
    session.close()
    return exists


def create_credential(username, password):
    salt = secrets.token_hex(16)
    pw_hash = _hash_password(password, salt)
    session = Session()
    # single-user app: replace any existing credential
    session.query(AppCredential).delete()
    session.add(AppCredential(username=username, password_hash=pw_hash, salt=salt))
    session.commit()
    session.close()


def verify_credential(username, password):
    session = Session()
    cred = session.query(AppCredential).first()
    session.close()
    if cred is None or cred.username != username:
        return False
    return _hash_password(password, cred.salt) == cred.password_hash


def change_credential(old_password, new_username, new_password):
    """Verify the old password, then replace the stored credential."""
    session = Session()
    cred = session.query(AppCredential).first()
    session.close()
    if cred is None:
        return False
    if _hash_password(old_password, cred.salt) != cred.password_hash:
        return False
    create_credential(new_username, new_password)
    return True


def get_next_voucher_number(session, voucher_type, fixed_account_name=None, fixed_side=None):
    """The number the NEXT voucher of this category will get (1-based).
    Cash Receipt and Cash Payment both use VoucherType.CASH, so passing
    the fixed account/side (e.g. "Cash in Hand"/"debit" for Receipt)
    keeps their numbering independent — same for Bank Receipt/Payment."""
    q = session.query(Voucher).filter(Voucher.type == voucher_type)
    if fixed_account_name is not None and fixed_side is not None:
        q = q.join(VoucherEntry).join(Account).filter(Account.name == fixed_account_name)
        if fixed_side == "debit":
            q = q.filter(VoucherEntry.debit > 0)
        else:
            q = q.filter(VoucherEntry.credit > 0)
    return q.count() + 1


def get_voucher_number(session, voucher):
    """The sequential number of an existing voucher within its own
    category (e.g. Cash Receipt vs Cash Payment numbered independently
    even though both are VoucherType.CASH), based on creation order."""
    fixed_account_name = MAIN_LEG_ACCOUNT_NAME.get(voucher.type)
    q = session.query(Voucher).filter(
        Voucher.type == voucher.type, Voucher.id <= voucher.id
    )
    if fixed_account_name:
        main_entry = next(
            (e for e in voucher.entries if e.account.name == fixed_account_name), None
        )
        if main_entry is not None:
            q = q.join(VoucherEntry).join(Account).filter(Account.name == fixed_account_name)
            if main_entry.debit > 0:
                q = q.filter(VoucherEntry.debit > 0)
            else:
                q = q.filter(VoucherEntry.credit > 0)
    return q.count()


def seed_default_accounts():
    """Create a small starter chart of accounts if the DB is empty."""
    session = Session()
    if session.query(Account).count() == 0:
        defaults = [
            ("Cash in Hand", AccountType.ASSET),
            ("Bank Account", AccountType.ASSET),
            ("Sundry Debtors", AccountType.ASSET),
            ("Sundry Creditors", AccountType.LIABILITY),
            ("Capital Account", AccountType.EQUITY),
            ("Sales Account", AccountType.INCOME),
            ("Purchase Account", AccountType.EXPENSE),
            ("Salary Expense", AccountType.EXPENSE),
            ("Rent Expense", AccountType.EXPENSE),
            ("Office Expenses", AccountType.EXPENSE),
        ]
        for name, atype in defaults:
            session.add(Account(name=name, type=atype, opening_balance=0.0))
        session.commit()
    session.close()


# --------------------------------------------------------------------------
# Helper functions
# --------------------------------------------------------------------------

def account_balance(session, account, as_of=None):
    """Return signed balance in the account's natural direction
    (positive = natural side, negative = opposite side)."""
    q = session.query(
        func.coalesce(func.sum(VoucherEntry.debit), 0.0),
        func.coalesce(func.sum(VoucherEntry.credit), 0.0),
    ).join(Voucher).filter(VoucherEntry.account_id == account.id)
    if as_of:
        q = q.filter(Voucher.date <= as_of)
    total_debit, total_credit = q.one()

    opening = account.opening_balance or 0.0
    if account.type in DEBIT_NATURE:
        return opening + total_debit - total_credit
    else:
        return opening + total_credit - total_debit


def account_period_totals(session, account, from_date=None, to_date=None):
    """Raw debit/credit totals for an account strictly within a date
    range (no opening balance included) — used for period-based views
    like the Day Book and Profit & Loss."""
    q = session.query(
        func.coalesce(func.sum(VoucherEntry.debit), 0.0),
        func.coalesce(func.sum(VoucherEntry.credit), 0.0),
    ).join(Voucher).filter(VoucherEntry.account_id == account.id)
    if from_date:
        q = q.filter(Voucher.date >= from_date)
    if to_date:
        q = q.filter(Voucher.date <= to_date)
    return q.one()


def account_period_balance(account, total_debit, total_credit):
    """Signed period movement in the account's natural direction, given
    raw debit/credit totals (e.g. from account_period_totals)."""
    if account.type in DEBIT_NATURE:
        return total_debit - total_credit
    else:
        return total_credit - total_debit


def stock_balance(session, item, as_of=None):
    """Current quantity on hand for a stock item: opening + purchases -
    sales, optionally as of a given date."""
    q_in = session.query(func.coalesce(func.sum(VoucherStockEntry.quantity), 0.0)).join(
        Voucher
    ).filter(
        VoucherStockEntry.stock_item_id == item.id,
        Voucher.type == VoucherType.PURCHASE,
    )
    q_out = session.query(func.coalesce(func.sum(VoucherStockEntry.quantity), 0.0)).join(
        Voucher
    ).filter(
        VoucherStockEntry.stock_item_id == item.id,
        Voucher.type == VoucherType.SALE,
    )
    if as_of:
        q_in = q_in.filter(Voucher.date <= as_of)
        q_out = q_out.filter(Voucher.date <= as_of)
    total_in = q_in.scalar() or 0.0
    total_out = q_out.scalar() or 0.0
    return (item.opening_qty or 0.0) + total_in - total_out


def get_item_closing_stock_value(session, item, as_of=None):
    """Value of this item's remaining quantity at weighted-average cost,
    computed perpetually: each Purchase adds to the cost pool, each Sale
    draws down quantity and value at the average cost per unit in effect
    at that moment (standard weighted-average-cost inventory method)."""
    q = (
        session.query(Voucher, VoucherStockEntry)
        .join(VoucherStockEntry, VoucherStockEntry.voucher_id == Voucher.id)
        .filter(VoucherStockEntry.stock_item_id == item.id)
        .filter(Voucher.type.in_([VoucherType.PURCHASE, VoucherType.SALE]))
    )
    if as_of:
        q = q.filter(Voucher.date <= as_of)
    q = q.order_by(Voucher.date, Voucher.id)

    running_qty = item.opening_qty or 0.0
    running_value = running_qty * (item.opening_rate or 0.0)

    for voucher, se in q.all():
        if voucher.type == VoucherType.PURCHASE:
            running_qty += se.quantity
            running_value += se.amount
        else:  # SALE
            cost_per_unit = running_value / running_qty if running_qty > 0.0001 else 0.0
            running_value -= cost_per_unit * se.quantity
            running_qty -= se.quantity

    return max(running_value, 0.0)


def get_total_closing_stock_value(session, as_of=None):
    items = session.query(StockItem).all()
    return sum(get_item_closing_stock_value(session, item, as_of=as_of) for item in items)


def compute_profit_loss(session, from_date, to_date):
    """Income/expense breakdown for a period, with Opening Stock added to
    costs and Closing Stock added to income (both at weighted-average
    cost) — the standard Trading Account adjustment. Used for the single
    net-profit figure shown on the Balance Sheet."""
    income_accounts = session.query(Account).filter_by(type=AccountType.INCOME).all()
    expense_accounts = session.query(Account).filter_by(type=AccountType.EXPENSE).all()

    income_lines = []
    total_income = 0.0
    for acc in income_accounts:
        d, c = account_period_totals(session, acc, from_date, to_date)
        bal = account_period_balance(acc, d, c)
        income_lines.append((acc, bal))
        total_income += bal

    opening_stock_value = (
        get_total_closing_stock_value(session, as_of=from_date - timedelta(days=1))
        if from_date else 0.0
    )
    closing_stock_value = get_total_closing_stock_value(session, as_of=to_date)
    total_income += closing_stock_value

    expense_lines = []
    total_expense = opening_stock_value
    for acc in expense_accounts:
        d, c = account_period_totals(session, acc, from_date, to_date)
        bal = account_period_balance(acc, d, c)
        expense_lines.append((acc, bal))
        total_expense += bal

    net = total_income - total_expense
    return income_lines, expense_lines, closing_stock_value, total_income, total_expense, net


def get_financial_year_start(as_of):
    """Indian financial year runs 1 April to 31 March, not the calendar
    year — e.g. 31-03-2026 belongs to FY starting 01-04-2025."""
    if as_of.month >= 4:
        return date(as_of.year, 4, 1)
    return date(as_of.year - 1, 4, 1)


def compute_trading_and_pl(session, from_date, to_date):
    """Classic two-part Trading Account + Profit & Loss Account, matching
    standard Indian CA-firm presentation: Opening Stock/Purchases/Gross
    Profit against Sales/Closing Stock, then Indirect Expenses/Net
    Profit against Gross Profit b/d (+ any other income)."""
    opening_stock = get_total_closing_stock_value(
        session, as_of=from_date - timedelta(days=1)
    ) if from_date else 0.0
    closing_stock = get_total_closing_stock_value(session, as_of=to_date)

    purchase_acc = session.query(Account).filter_by(name="Purchase Account").first()
    purchase_amount = 0.0
    if purchase_acc:
        d, c = account_period_totals(session, purchase_acc, from_date, to_date)
        purchase_amount = account_period_balance(purchase_acc, d, c)

    sales_acc = session.query(Account).filter_by(name="Sales Account").first()
    sales_amount = 0.0
    if sales_acc:
        d, c = account_period_totals(session, sales_acc, from_date, to_date)
        sales_amount = account_period_balance(sales_acc, d, c)

    other_income = []
    for acc in session.query(Account).filter_by(type=AccountType.INCOME).all():
        if sales_acc is not None and acc.id == sales_acc.id:
            continue
        d, c = account_period_totals(session, acc, from_date, to_date)
        bal = account_period_balance(acc, d, c)
        if abs(bal) > 0.001:
            other_income.append((acc, bal))

    indirect_expenses = []
    for acc in session.query(Account).filter_by(type=AccountType.EXPENSE).all():
        if purchase_acc is not None and acc.id == purchase_acc.id:
            continue
        d, c = account_period_totals(session, acc, from_date, to_date)
        bal = account_period_balance(acc, d, c)
        if abs(bal) > 0.001:
            indirect_expenses.append((acc, bal))

    trading_dr = opening_stock + purchase_amount
    trading_cr = sales_amount + closing_stock
    gross_result = trading_cr - trading_dr  # positive = Gross Profit, negative = Gross Loss

    pl_dr = sum(b for _, b in indirect_expenses)
    pl_cr = sum(b for _, b in other_income)
    if gross_result >= 0:
        pl_cr += gross_result
    else:
        pl_dr += -gross_result

    net_result = pl_cr - pl_dr  # positive = Net Profit, negative = Net Loss

    return {
        "opening_stock": opening_stock,
        "closing_stock": closing_stock,
        "purchase_amount": purchase_amount,
        "sales_amount": sales_amount,
        "other_income": other_income,
        "indirect_expenses": indirect_expenses,
        "gross_result": gross_result,
        "net_result": net_result,
    }


def fmt_money(value):
    """Format a number using the Indian numbering system (lakhs/crores)
    as a whole rupee amount, e.g. 1234567.5 -> '12,34,568' (rounded, no
    decimals) instead of '1,234,567.50'."""
    value = value or 0.0
    is_negative = value < 0
    value = abs(value)

    int_part = int(round(value))

    s = str(int_part)
    if len(s) <= 3:
        formatted = s
    else:
        last3 = s[-3:]
        rest = s[:-3]
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        formatted = ",".join(groups) + "," + last3

    return f"-{formatted}" if is_negative else formatted


def _try_import_openpyxl():
    """Excel support is optional — the app works fine without it, this
    just lazily loads openpyxl only when an Import/Export button is
    actually clicked."""
    try:
        import openpyxl
        return openpyxl
    except ImportError:
        return None


def _show_missing_openpyxl(parent):
    QMessageBox.critical(
        parent, "Missing Library",
        "Excel import/export requires the 'openpyxl' package.\n\n"
        "Install it by running this in Command Prompt:\n"
        "  py -m pip install openpyxl"
    )


def export_table_to_excel(parent, table, sheet_title, default_filename, info_lines=None):
    """Exports a QTableWidget's headers and visible cell text to a new
    .xlsx file, with optional info lines (e.g. account name, period)
    written above the table."""
    openpyxl = _try_import_openpyxl()
    if openpyxl is None:
        _show_missing_openpyxl(parent)
        return
    path, _ = QFileDialog.getSaveFileName(
        parent, f"Export {sheet_title}", default_filename, "Excel Files (*.xlsx)"
    )
    if not path:
        return

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_title[:31]  # Excel sheet-name length limit

    if info_lines:
        for line in info_lines:
            ws.append([line])
        ws.append([])

    headers = [
        table.horizontalHeaderItem(c).text() if table.horizontalHeaderItem(c) else ""
        for c in range(table.columnCount())
    ]
    ws.append(headers)
    for r in range(table.rowCount()):
        ws.append([
            table.item(r, c).text() if table.item(r, c) else ""
            for c in range(table.columnCount())
        ])

    try:
        wb.save(path)
    except Exception as e:
        QMessageBox.critical(parent, "Export Failed", str(e))
        return
    QMessageBox.information(parent, "Exported", f"{sheet_title} exported to:\n{path}")


# --------------------------------------------------------------------------
# Voucher Entry Dialog line widget helpers
# --------------------------------------------------------------------------

class VoucherLineRow:
    """A single debit/credit line inside the voucher entry table."""
    def __init__(self, table, row, accounts):
        self.table = table
        self.row = row

        self.account_combo = QComboBox()
        for acc in accounts:
            self.account_combo.addItem(f"{acc.name} ({acc.type.value})", acc.id)
        table.setCellWidget(row, 0, self.account_combo)

        self.debit_edit = QLineEdit()
        self.debit_edit.setPlaceholderText("0.00")
        table.setCellWidget(row, 1, self.debit_edit)

        self.credit_edit = QLineEdit()
        self.credit_edit.setPlaceholderText("0.00")
        table.setCellWidget(row, 2, self.credit_edit)

    def get_values(self):
        account_id = self.account_combo.currentData()
        try:
            debit = float(self.debit_edit.text() or 0)
        except ValueError:
            debit = 0.0
        try:
            credit = float(self.credit_edit.text() or 0)
        except ValueError:
            credit = 0.0
        return account_id, debit, credit


class StockLineRow:
    """A single item/qty/rate line inside a voucher's Stock Items table."""
    def __init__(self, table, row, items):
        self.table = table
        self.row = row

        self.item_combo = QComboBox()
        for it in items:
            self.item_combo.addItem(f"{it.name} ({it.unit})", it.id)
        table.setCellWidget(row, 0, self.item_combo)

        self.qty_edit = QLineEdit()
        self.qty_edit.setPlaceholderText("0")
        table.setCellWidget(row, 1, self.qty_edit)

        self.rate_edit = QLineEdit()
        self.rate_edit.setPlaceholderText("0.00")
        table.setCellWidget(row, 2, self.rate_edit)

        self.amount_edit = QLineEdit()
        self.amount_edit.setReadOnly(True)
        self.amount_edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.amount_edit.setPlaceholderText("0.00")
        table.setCellWidget(row, 3, self.amount_edit)

    def get_values(self):
        item_id = self.item_combo.currentData()
        try:
            qty = float(self.qty_edit.text() or 0)
        except ValueError:
            qty = 0.0
        try:
            rate = float(self.rate_edit.text() or 0)
        except ValueError:
            rate = 0.0
        amount = qty * rate
        return item_id, qty, rate, amount

    def update_amount(self):
        _, qty, rate, amount = self.get_values()
        self.amount_edit.setText(f"{amount:.2f}" if amount else "")


# --------------------------------------------------------------------------
# Login / Setup Dialog
# --------------------------------------------------------------------------

class LoginDialog(QDialog):
    def __init__(self, setup_mode, parent=None):
        super().__init__(parent)
        self.setup_mode = setup_mode
        self.setWindowTitle("Set Up Login" if setup_mode else "Login")
        self.setModal(True)
        self.resize(360, 220)

        layout = QVBoxLayout(self)

        if setup_mode:
            info = QLabel(
                "First-time setup: create a username and password to "
                "protect this app. You'll need these every time you open it."
            )
            info.setWordWrap(True)
            layout.addWidget(info)

        form = QFormLayout()
        self.username_edit = QLineEdit()
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Username:", self.username_edit)
        form.addRow("Password:", self.password_edit)

        if setup_mode:
            self.confirm_edit = QLineEdit()
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow("Confirm Password:", self.confirm_edit)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: red;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        btn_row = QHBoxLayout()
        submit_btn = QPushButton("Create Login" if setup_mode else "Login")
        submit_btn.clicked.connect(self.on_submit)
        btn_row.addStretch()
        btn_row.addWidget(submit_btn)
        layout.addLayout(btn_row)

        if setup_mode:
            self.username_edit.returnPressed.connect(self.password_edit.setFocus)
            self.password_edit.returnPressed.connect(self.confirm_edit.setFocus)
            self.confirm_edit.returnPressed.connect(self.on_submit)
        else:
            self.username_edit.returnPressed.connect(self.password_edit.setFocus)
            self.password_edit.returnPressed.connect(self.on_submit)

    def on_submit(self):
        username = self.username_edit.text().strip()
        password = self.password_edit.text()

        if not username or not password:
            self.error_label.setText("Please fill in all fields.")
            return

        if self.setup_mode:
            confirm = self.confirm_edit.text()
            if password != confirm:
                self.error_label.setText("Passwords do not match.")
                return
            if len(password) < 4:
                self.error_label.setText("Password must be at least 4 characters.")
                return
            create_credential(username, password)
            self.accept()
        else:
            if verify_credential(username, password):
                self.accept()
            else:
                self.error_label.setText("Incorrect username or password.")
                self.password_edit.clear()


class ChangePasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Change Login")
        self.setModal(True)
        self.resize(360, 240)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.old_password_edit = QLineEdit()
        self.old_password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.new_username_edit = QLineEdit()
        self.new_password_edit = QLineEdit()
        self.new_password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)

        form.addRow("Current Password:", self.old_password_edit)
        form.addRow("New Username:", self.new_username_edit)
        form.addRow("New Password:", self.new_password_edit)
        form.addRow("Confirm New Password:", self.confirm_edit)
        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: red;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        btn_row = QHBoxLayout()
        submit_btn = QPushButton("Update")
        submit_btn.clicked.connect(self.on_submit)
        btn_row.addStretch()
        btn_row.addWidget(submit_btn)
        layout.addLayout(btn_row)

        self.old_password_edit.returnPressed.connect(self.new_username_edit.setFocus)
        self.new_username_edit.returnPressed.connect(self.new_password_edit.setFocus)
        self.new_password_edit.returnPressed.connect(self.confirm_edit.setFocus)
        self.confirm_edit.returnPressed.connect(self.on_submit)

    def on_submit(self):
        old_password = self.old_password_edit.text()
        new_username = self.new_username_edit.text().strip()
        new_password = self.new_password_edit.text()
        confirm = self.confirm_edit.text()

        if not old_password or not new_username or not new_password:
            self.error_label.setText("Please fill in all fields.")
            return
        if new_password != confirm:
            self.error_label.setText("New passwords do not match.")
            return
        if len(new_password) < 4:
            self.error_label.setText("Password must be at least 4 characters.")
            return

        if change_credential(old_password, new_username, new_password):
            QMessageBox.information(self, "Updated", "Login updated successfully.")
            self.accept()
        else:
            self.error_label.setText("Current password is incorrect.")
            self.old_password_edit.clear()


# --------------------------------------------------------------------------
# Main Window
# --------------------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Simple Accounting Software")
        self.resize(1100, 700)

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.coa_tab = ChartOfAccountsTab()
        self.day_book_tab = DayBookTab(refresh_callback=self.refresh_all)
        self.ledger_tab = LedgerTab(refresh_callback=self.refresh_all)
        self.tb_tab = TrialBalanceTab(navigate_callback=self.open_ledger_for_account)
        self.pl_tab = ProfitLossTab(navigate_callback=self.open_ledger_for_account)
        self.bs_tab = BalanceSheetTab(navigate_callback=self.open_ledger_for_account)
        self.stock_item_ledger_tab = StockItemLedgerTab(refresh_callback=self.refresh_all)
        self.stock_summary_tab = StockSummaryTab(navigate_callback=self.open_stock_ledger_for_item)
        self.stock_items_tab = StockItemsTab(navigate_callback=self.open_stock_ledger_for_item)

        # Transactions group: one sub-tab per voucher type
        self.cash_receipt_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.CASH,
            fixed_account_name="Cash in Hand", fixed_side="debit"
        )
        self.cash_payment_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.CASH,
            fixed_account_name="Cash in Hand", fixed_side="credit"
        )
        self.bank_receipt_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.BANK,
            fixed_account_name="Bank Account", fixed_side="debit"
        )
        self.bank_payment_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.BANK,
            fixed_account_name="Bank Account", fixed_side="credit"
        )
        self.purchase_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.PURCHASE,
            fixed_account_name="Purchase Account", fixed_side="debit", enable_stock=True,
            party_in_header=True
        )
        self.sale_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.SALE,
            fixed_account_name="Sales Account", fixed_side="credit", enable_stock=True,
            party_in_header=True
        )
        self.journal_tab = VoucherEntryTab(
            refresh_callback=self.refresh_all, fixed_voucher_type=VoucherType.JOURNAL
        )
        self.voucher_tabs_list = [
            self.cash_receipt_tab, self.cash_payment_tab,
            self.bank_receipt_tab, self.bank_payment_tab,
            self.purchase_tab, self.sale_tab, self.journal_tab,
        ]

        self.cash_tabs = QTabWidget()
        self.cash_tabs.addTab(self.cash_receipt_tab, "R&eceipt")
        self.cash_tabs.addTab(self.cash_payment_tab, "&Payment")
        self.cash_tabs.currentChanged.connect(self.on_tab_changed)

        self.bank_tabs = QTabWidget()
        self.bank_tabs.addTab(self.bank_receipt_tab, "R&eceipt")
        self.bank_tabs.addTab(self.bank_payment_tab, "&Payment")
        self.bank_tabs.currentChanged.connect(self.on_tab_changed)

        self.transactions_tabs = QTabWidget()
        self.transactions_tabs.addTab(self.cash_tabs, "&Cash")
        self.transactions_tabs.addTab(self.bank_tabs, "Ba&nk")
        self.transactions_tabs.addTab(self.purchase_tab, "P&urchase")
        self.transactions_tabs.addTab(self.sale_tab, "&Sale")
        self.transactions_tabs.addTab(self.journal_tab, "&Journal")
        self.transactions_tabs.currentChanged.connect(self.on_tab_changed)

        # Reports group has multiple views, so it gets its own sub-tab bar
        self.reports_tabs = QTabWidget()
        self.reports_tabs.addTab(self.day_book_tab, "&Day Book")
        self.reports_tabs.addTab(self.ledger_tab, "&Ledger")
        self.reports_tabs.addTab(self.tb_tab, "Tr&ial Balance")
        self.reports_tabs.addTab(self.pl_tab, "&Profit && Loss")
        self.reports_tabs.addTab(self.bs_tab, "&Balance Sheet")
        self.reports_tabs.addTab(self.stock_summary_tab, "&Stock Summary")
        self.reports_tabs.addTab(self.stock_item_ledger_tab, "Stoc&k Ledger")
        self.reports_tabs.currentChanged.connect(self.on_tab_changed)

        # Masters group: Chart of Accounts + Stock Items
        self.masters_tabs = QTabWidget()
        self.masters_tabs.addTab(self.coa_tab, "&Accounts")
        self.masters_tabs.addTab(self.stock_items_tab, "&Stock Items")
        self.masters_tabs.currentChanged.connect(self.on_tab_changed)

        # Top-level grouping: 1. Transactions  2. Reports  3. Masters
        self.tabs.addTab(self.transactions_tabs, "&Transactions")
        self.tabs.addTab(self.reports_tabs, "&Reports")
        self.tabs.addTab(self.masters_tabs, "&Masters")

        self.tabs.currentChanged.connect(self.on_tab_changed)

        change_login_btn = QPushButton("Change Login")
        change_login_btn.clicked.connect(self.open_change_password)
        self.tabs.setCornerWidget(change_login_btn)

    def open_change_password(self):
        dialog = ChangePasswordDialog(parent=self)
        dialog.exec()

    def on_tab_changed(self, index):
        self.refresh_all()

    def refresh_all(self):
        self.coa_tab.load_accounts()
        self.stock_items_tab.load_items()
        for vtab in self.voucher_tabs_list:
            vtab.reload_accounts()
        self.day_book_tab.load_day_book()
        self.ledger_tab.reload_accounts()
        self.tb_tab.load_trial_balance()
        self.pl_tab.load_pl()
        self.bs_tab.load_bs()
        self.stock_summary_tab.load_stock_summary()
        self.stock_item_ledger_tab.reload_items()

    def open_ledger_for_account(self, account_id):
        """Switch to the Ledger view (inside Reports), select the given
        account, and load it. Used when a line item is double-clicked in
        Trial Balance, P&L, or Balance Sheet."""
        if account_id is None:
            return
        self.ledger_tab.reload_accounts()
        idx = self.ledger_tab.account_combo.findData(account_id)
        if idx >= 0:
            self.ledger_tab.account_combo.setCurrentIndex(idx)
        self.ledger_tab.show_all_history()
        self.ledger_tab.load_ledger()
        self.tabs.setCurrentWidget(self.reports_tabs)
        self.reports_tabs.setCurrentWidget(self.ledger_tab)

    def open_stock_ledger_for_item(self, item_id):
        """Switch to the Stock Item Ledger (inside Reports), select the
        given item, and load it. Used when a stock item row is
        double-clicked in Stock Items (Masters) or Stock Summary."""
        if item_id is None:
            return
        self.stock_item_ledger_tab.reload_items()
        idx = self.stock_item_ledger_tab.item_combo.findData(item_id)
        if idx >= 0:
            self.stock_item_ledger_tab.item_combo.setCurrentIndex(idx)
        self.stock_item_ledger_tab.show_all_history()
        self.stock_item_ledger_tab.load_item_ledger()
        self.tabs.setCurrentWidget(self.reports_tabs)
        self.reports_tabs.setCurrentWidget(self.stock_item_ledger_tab)



# --------------------------------------------------------------------------
# Chart of Accounts Tab
# --------------------------------------------------------------------------

class ChartOfAccountsTab(QWidget):
    def __init__(self):
        super().__init__()
        self.editing_account_id = None
        layout = QVBoxLayout(self)

        self.form_group = QGroupBox("Add Account")
        form_layout = QFormLayout()
        self.name_edit = QLineEdit()
        self.type_combo = QComboBox()
        for t in AccountType:
            self.type_combo.addItem(t.value, t)
        self.type_combo.currentIndexChanged.connect(self.refresh_sub_category_options)
        self.sub_category_combo = QComboBox()
        self.opening_edit = QLineEdit()
        self.opening_edit.setPlaceholderText("0.00")
        form_layout.addRow("Account Name:", self.name_edit)
        form_layout.addRow("Type:", self.type_combo)
        self.sub_category_row_label = QLabel("Category:")
        form_layout.addRow(self.sub_category_row_label, self.sub_category_combo)
        form_layout.addRow("Opening Balance:", self.opening_edit)
        btn_row = QHBoxLayout()
        self.save_btn = QPushButton("Add Account")
        self.save_btn.clicked.connect(self.save_account)
        self.cancel_edit_btn = QPushButton("Cancel")
        self.cancel_edit_btn.clicked.connect(self.cancel_edit)
        self.cancel_edit_btn.setVisible(False)
        btn_row.addWidget(self.save_btn)
        btn_row.addWidget(self.cancel_edit_btn)
        form_layout.addRow(btn_row)
        self.form_group.setLayout(form_layout)
        layout.addWidget(self.form_group)
        self.refresh_sub_category_options()

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Account Name", "Type", "Category", "Opening Balance", "Current Balance"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        edit_btn = QPushButton("Edit Selected")
        edit_btn.clicked.connect(self.edit_selected)
        delete_btn = QPushButton("Delete Selected")
        delete_btn.setStyleSheet("color: red;")
        delete_btn.clicked.connect(self.delete_selected)
        action_row.addWidget(edit_btn)
        action_row.addWidget(delete_btn)
        action_row.addStretch()
        layout.addLayout(action_row)

        excel_row = QHBoxLayout()
        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        import_btn = QPushButton("Import from Excel")
        import_btn.clicked.connect(self.import_from_excel)
        excel_row.addWidget(export_btn)
        excel_row.addWidget(import_btn)
        excel_row.addStretch()
        layout.addLayout(excel_row)

        self.load_accounts()

    def refresh_sub_category_options(self, preferred=None):
        atype = self.type_combo.currentData()
        self.sub_category_combo.clear()
        if atype == AccountType.ASSET:
            self.sub_category_combo.addItems(ASSET_SUB_CATEGORIES)
            self.sub_category_combo.setEnabled(True)
            self.sub_category_row_label.setVisible(True)
            self.sub_category_combo.setVisible(True)
        elif atype == AccountType.LIABILITY:
            self.sub_category_combo.addItems(LIABILITY_SUB_CATEGORIES)
            self.sub_category_combo.setEnabled(True)
            self.sub_category_row_label.setVisible(True)
            self.sub_category_combo.setVisible(True)
        else:
            self.sub_category_row_label.setVisible(False)
            self.sub_category_combo.setVisible(False)
        if preferred:
            idx = self.sub_category_combo.findText(preferred)
            if idx >= 0:
                self.sub_category_combo.setCurrentIndex(idx)

    def edit_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "No Selection", "Please select an account row first.")
            return
        account_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        session = Session()
        acc = session.get(Account, account_id)
        if acc is None:
            session.close()
            return
        self.editing_account_id = acc.id
        self.name_edit.setText(acc.name)
        idx = self.type_combo.findData(acc.type)
        if idx >= 0:
            self.type_combo.setCurrentIndex(idx)
        self.refresh_sub_category_options(preferred=acc.sub_category)
        self.opening_edit.setText(str(acc.opening_balance or 0))
        session.close()

        self.form_group.setTitle("Edit Account")
        self.save_btn.setText("Update Account")
        self.cancel_edit_btn.setVisible(True)

    def cancel_edit(self):
        self.editing_account_id = None
        self.name_edit.clear()
        self.opening_edit.clear()
        self.form_group.setTitle("Add Account")
        self.save_btn.setText("Add Account")
        self.cancel_edit_btn.setVisible(False)

    def delete_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "No Selection", "Please select an account row first.")
            return
        account_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        session = Session()
        acc = session.get(Account, account_id)
        if acc is None:
            session.close()
            return
        entry_count = session.query(VoucherEntry).filter_by(account_id=account_id).count()
        if entry_count > 0:
            QMessageBox.warning(
                self, "Cannot Delete",
                f"'{acc.name}' has {entry_count} voucher entr{'y' if entry_count == 1 else 'ies'} "
                "posted against it and can't be deleted. Remove or reassign those vouchers first."
            )
            session.close()
            return
        confirm = QMessageBox.question(
            self, "Delete Account",
            f"Delete '{acc.name}'? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            session.delete(acc)
            session.commit()
        session.close()
        if self.editing_account_id == account_id:
            self.cancel_edit()
        self.load_accounts()

    def save_account(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing Name", "Please enter an account name.")
            return
        try:
            opening = float(self.opening_edit.text() or 0)
        except ValueError:
            QMessageBox.warning(self, "Invalid Amount", "Opening balance must be a number.")
            return
        atype = self.type_combo.currentData()
        sub_category = None
        if atype in (AccountType.ASSET, AccountType.LIABILITY):
            sub_category = self.sub_category_combo.currentText()

        session = Session()
        duplicate = session.query(Account).filter(
            Account.name == name, Account.id != (self.editing_account_id or -1)
        ).first()
        if duplicate:
            QMessageBox.warning(self, "Duplicate", "An account with this name already exists.")
            session.close()
            return

        if self.editing_account_id is not None:
            acc = session.get(Account, self.editing_account_id)
            if acc is None:
                session.close()
                self.cancel_edit()
                return
            acc.name = name
            acc.type = atype
            acc.opening_balance = opening
            acc.sub_category = sub_category
            session.commit()
        else:
            session.add(Account(name=name, type=atype, opening_balance=opening, sub_category=sub_category))
            session.commit()
        session.close()

        self.cancel_edit()
        self.load_accounts()

    def load_accounts(self):
        session = Session()
        accounts = session.query(Account).order_by(Account.type, Account.name).all()
        self.table.setRowCount(len(accounts))
        for row, acc in enumerate(accounts):
            balance = account_balance(session, acc)
            name_item = QTableWidgetItem(acc.name)
            name_item.setData(Qt.ItemDataRole.UserRole, acc.id)
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, QTableWidgetItem(acc.type.value))
            self.table.setItem(row, 2, QTableWidgetItem(acc.sub_category or ""))
            self.table.setItem(row, 3, QTableWidgetItem(fmt_money(acc.opening_balance or 0)))
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(balance)))
        session.close()

    def export_to_excel(self):
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Chart of Accounts", "chart_of_accounts.xlsx", "Excel Files (*.xlsx)"
        )
        if not path:
            return

        session = Session()
        accounts = session.query(Account).order_by(Account.type, Account.name).all()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Chart of Accounts"
        ws.append(["Account Name", "Type", "Category", "Opening Balance", "Current Balance"])
        for acc in accounts:
            balance = account_balance(session, acc)
            ws.append([acc.name, acc.type.value, acc.sub_category or "", acc.opening_balance or 0.0, balance])
        session.close()

        try:
            wb.save(path)
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))
            return
        QMessageBox.information(self, "Exported", f"Chart of Accounts exported to:\n{path}")

    def import_from_excel(self):
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Chart of Accounts", "", "Excel Files (*.xlsx *.xls)"
        )
        if not path:
            return
        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            ws = wb.active
        except Exception as e:
            QMessageBox.critical(self, "Import Failed", f"Could not read the file:\n{e}")
            return

        valid_types = {t.value: t for t in AccountType}
        session = Session()
        added = 0
        skipped = 0
        errors = []
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            if not row or row[0] is None or str(row[0]).strip() == "":
                continue
            name = str(row[0]).strip()
            type_str = str(row[1]).strip() if len(row) > 1 and row[1] is not None else None
            sub_category = str(row[2]).strip() if len(row) > 2 and row[2] else None
            opening_raw = row[3] if len(row) > 3 else 0
            if type_str not in valid_types:
                errors.append(f"Row {row_idx}: unknown account type '{type_str}'")
                continue
            if session.query(Account).filter_by(name=name).first():
                skipped += 1
                continue
            try:
                opening_val = float(opening_raw or 0)
            except (TypeError, ValueError):
                opening_val = 0.0
            session.add(Account(
                name=name, type=valid_types[type_str], opening_balance=opening_val,
                sub_category=sub_category
            ))
            added += 1
        session.commit()
        session.close()

        msg = f"Imported {added} account(s). Skipped {skipped} duplicate(s)."
        if errors:
            msg += "\n\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                msg += f"\n...and {len(errors) - 10} more."
        QMessageBox.information(self, "Import Complete", msg)
        self.load_accounts()


# --------------------------------------------------------------------------
# Stock Items Tab (Masters)
# --------------------------------------------------------------------------

class StockItemsTab(QWidget):
    def __init__(self, navigate_callback=None):
        super().__init__()
        self.navigate_callback = navigate_callback
        self.editing_item_id = None
        layout = QVBoxLayout(self)

        self.form_group = QGroupBox("Add Stock Item")
        form_layout = QFormLayout()
        self.name_edit = QLineEdit()
        self.unit_edit = QLineEdit()
        self.unit_edit.setPlaceholderText("Nos")
        self.opening_qty_edit = QLineEdit()
        self.opening_qty_edit.setPlaceholderText("0")
        self.opening_rate_edit = QLineEdit()
        self.opening_rate_edit.setPlaceholderText("0.00")
        form_layout.addRow("Item Name:", self.name_edit)
        form_layout.addRow("Unit:", self.unit_edit)
        form_layout.addRow("Opening Quantity:", self.opening_qty_edit)
        form_layout.addRow("Opening Rate:", self.opening_rate_edit)
        btn_row = QHBoxLayout()
        self.save_btn = QPushButton("Add Stock Item")
        self.save_btn.clicked.connect(self.save_item)
        self.cancel_edit_btn = QPushButton("Cancel")
        self.cancel_edit_btn.clicked.connect(self.cancel_edit)
        self.cancel_edit_btn.setVisible(False)
        btn_row.addWidget(self.save_btn)
        btn_row.addWidget(self.cancel_edit_btn)
        form_layout.addRow(btn_row)
        self.form_group.setLayout(form_layout)
        layout.addWidget(self.form_group)

        hint = QLabel("Double-click any item row to open its transaction history.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Item Name", "Unit", "Opening Qty", "Current Qty", "Current Value"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_item_ledger)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        edit_btn = QPushButton("Edit Selected")
        edit_btn.clicked.connect(self.edit_selected)
        delete_btn = QPushButton("Delete Selected")
        delete_btn.setStyleSheet("color: red;")
        delete_btn.clicked.connect(self.delete_selected)
        action_row.addWidget(edit_btn)
        action_row.addWidget(delete_btn)
        action_row.addStretch()
        layout.addLayout(action_row)

        excel_row = QHBoxLayout()
        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        import_btn = QPushButton("Import from Excel")
        import_btn.clicked.connect(self.import_from_excel)
        excel_row.addWidget(export_btn)
        excel_row.addWidget(import_btn)
        excel_row.addStretch()
        layout.addLayout(excel_row)

        self.load_items()

    def edit_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "No Selection", "Please select an item row first.")
            return
        item_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        session = Session()
        item = session.get(StockItem, item_id)
        if item is None:
            session.close()
            return
        self.editing_item_id = item.id
        self.name_edit.setText(item.name)
        self.unit_edit.setText(item.unit)
        self.opening_qty_edit.setText(str(item.opening_qty or 0))
        self.opening_rate_edit.setText(str(item.opening_rate or 0))
        session.close()

        self.form_group.setTitle("Edit Stock Item")
        self.save_btn.setText("Update Stock Item")
        self.cancel_edit_btn.setVisible(True)

    def cancel_edit(self):
        self.editing_item_id = None
        self.name_edit.clear()
        self.unit_edit.clear()
        self.opening_qty_edit.clear()
        self.opening_rate_edit.clear()
        self.form_group.setTitle("Add Stock Item")
        self.save_btn.setText("Add Stock Item")
        self.cancel_edit_btn.setVisible(False)

    def delete_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "No Selection", "Please select an item row first.")
            return
        item_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        session = Session()
        item = session.get(StockItem, item_id)
        if item is None:
            session.close()
            return
        entry_count = session.query(VoucherStockEntry).filter_by(stock_item_id=item_id).count()
        if entry_count > 0:
            QMessageBox.warning(
                self, "Cannot Delete",
                f"'{item.name}' appears in {entry_count} voucher(s) and can't be deleted. "
                "Remove those stock lines from their vouchers first."
            )
            session.close()
            return
        confirm = QMessageBox.question(
            self, "Delete Stock Item",
            f"Delete '{item.name}'? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            session.delete(item)
            session.commit()
        session.close()
        if self.editing_item_id == item_id:
            self.cancel_edit()
        self.load_items()

    def save_item(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing Name", "Please enter an item name.")
            return
        unit = self.unit_edit.text().strip() or "Nos"
        try:
            opening_qty = float(self.opening_qty_edit.text() or 0)
            opening_rate = float(self.opening_rate_edit.text() or 0)
        except ValueError:
            QMessageBox.warning(self, "Invalid Amount", "Opening quantity and rate must be numbers.")
            return

        session = Session()
        duplicate = session.query(StockItem).filter(
            StockItem.name == name, StockItem.id != (self.editing_item_id or -1)
        ).first()
        if duplicate:
            QMessageBox.warning(self, "Duplicate", "A stock item with this name already exists.")
            session.close()
            return

        if self.editing_item_id is not None:
            item = session.get(StockItem, self.editing_item_id)
            if item is None:
                session.close()
                self.cancel_edit()
                return
            item.name = name
            item.unit = unit
            item.opening_qty = opening_qty
            item.opening_rate = opening_rate
            session.commit()
        else:
            session.add(StockItem(name=name, unit=unit, opening_qty=opening_qty, opening_rate=opening_rate))
            session.commit()
        session.close()

        self.cancel_edit()
        self.load_items()

    def load_items(self):
        session = Session()
        items = session.query(StockItem).order_by(StockItem.name).all()
        self.table.setRowCount(len(items))
        for row, item in enumerate(items):
            qty = stock_balance(session, item)
            # simple current value estimate at the item's opening rate
            value = qty * (item.opening_rate or 0.0)
            name_item = QTableWidgetItem(item.name)
            name_item.setData(Qt.ItemDataRole.UserRole, item.id)
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, QTableWidgetItem(item.unit))
            self.table.setItem(row, 2, QTableWidgetItem(f"{item.opening_qty:g}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{qty:g}"))
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(value)))
            for col in range(1, 5):
                self.table.item(row, col).setData(Qt.ItemDataRole.UserRole, item.id)
        session.close()

    def open_item_ledger(self, item):
        item_id = item.data(Qt.ItemDataRole.UserRole)
        if item_id is not None and self.navigate_callback:
            self.navigate_callback(item_id)

    def export_to_excel(self):
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Stock Items", "stock_items.xlsx", "Excel Files (*.xlsx)"
        )
        if not path:
            return

        session = Session()
        items = session.query(StockItem).order_by(StockItem.name).all()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Stock Items"
        ws.append(["Item Name", "Unit", "Opening Qty", "Opening Rate", "Current Qty", "Current Value"])
        for item in items:
            qty = stock_balance(session, item)
            value = qty * (item.opening_rate or 0.0)
            ws.append([item.name, item.unit, item.opening_qty or 0.0, item.opening_rate or 0.0, qty, value])
        session.close()

        try:
            wb.save(path)
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))
            return
        QMessageBox.information(self, "Exported", f"Stock Items exported to:\n{path}")

    def import_from_excel(self):
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Stock Items", "", "Excel Files (*.xlsx *.xls)"
        )
        if not path:
            return
        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            ws = wb.active
        except Exception as e:
            QMessageBox.critical(self, "Import Failed", f"Could not read the file:\n{e}")
            return

        session = Session()
        added = 0
        skipped = 0
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or row[0] is None or str(row[0]).strip() == "":
                continue
            name = str(row[0]).strip()
            unit = str(row[1]).strip() if len(row) > 1 and row[1] else "Nos"
            try:
                opening_qty = float(row[2] or 0) if len(row) > 2 else 0.0
            except (TypeError, ValueError):
                opening_qty = 0.0
            try:
                opening_rate = float(row[3] or 0) if len(row) > 3 else 0.0
            except (TypeError, ValueError):
                opening_rate = 0.0
            if session.query(StockItem).filter_by(name=name).first():
                skipped += 1
                continue
            session.add(StockItem(name=name, unit=unit, opening_qty=opening_qty, opening_rate=opening_rate))
            added += 1
        session.commit()
        session.close()

        QMessageBox.information(
            self, "Import Complete",
            f"Imported {added} stock item(s). Skipped {skipped} duplicate(s)."
        )
        self.load_items()


# --------------------------------------------------------------------------
# Voucher Entry Tab
# --------------------------------------------------------------------------

class VoucherEntryTab(QWidget):
    def __init__(self, refresh_callback=None, fixed_voucher_type=None,
                 fixed_account_name=None, fixed_side=None, enable_stock=False,
                 party_in_header=False):
        super().__init__()
        self.refresh_callback = refresh_callback
        self.fixed_voucher_type = fixed_voucher_type
        self.fixed_account_name = fixed_account_name
        self.fixed_side = fixed_side  # "debit" or "credit"
        self.fixed_line = None  # only set while in Double Entry mode
        self.single_entry_mode = True
        self.enable_stock = enable_stock
        self.party_in_header = party_in_header and fixed_account_name is not None
        self.lines = []
        self.stock_lines = []
        self.stock_items_cache = []

        layout = QVBoxLayout(self)

        header_group = QGroupBox("Voucher Details")
        self.header_layout = QFormLayout()

        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)

        self.type_combo = QComboBox()
        if fixed_voucher_type is not None:
            display_label = get_voucher_display_type(fixed_voucher_type, fixed_side)
            self.type_combo.addItem(display_label, fixed_voucher_type)
            self.type_combo.setEnabled(False)
        else:
            for t in VoucherType:
                self.type_combo.addItem(t.value, t)

        self.reference_edit = QLineEdit()
        self.narration_edit = QLineEdit()

        self.voucher_no_edit = QLineEdit()
        self.voucher_no_edit.setReadOnly(True)
        self.voucher_no_edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.header_layout.addRow("Voucher No.:", self.voucher_no_edit)

        self.header_layout.addRow("Date:", self.date_edit)
        self.header_layout.addRow("Voucher Type:", self.type_combo)
        if fixed_voucher_type is None:
            self.type_combo.currentIndexChanged.connect(self.refresh_voucher_no)

        self.mode_checkbox = None
        self.fixed_amount_edit = None
        if fixed_account_name is not None:
            self.mode_checkbox = QCheckBox("Single Entry")
            self.mode_checkbox.setChecked(True)
            self.mode_checkbox.stateChanged.connect(self.on_mode_changed)
            self.header_layout.addRow("Entry Mode:", self.mode_checkbox)

            side_word = "Dr" if fixed_side == "debit" else "Cr"
            self.fixed_amount_edit = QLineEdit()
            self.fixed_amount_edit.setPlaceholderText("0.00")
            if self.party_in_header:
                # This is the one and only amount field in this mode — the
                # party leg always carries the exact same amount, so there's
                # no need for a separate "Party Amount" field. It stays
                # editable unless Stock Items are driving the total.
                self.fixed_amount_edit.textChanged.connect(self.update_totals)
            else:
                self.fixed_amount_edit.setReadOnly(True)
                self.fixed_amount_edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            self.header_layout.addRow(f"{fixed_account_name} ({side_word}):", self.fixed_amount_edit)

        self.party_combo = None
        if self.party_in_header:
            self.party_combo = QComboBox()
            self.header_layout.addRow("Party Account:", self.party_combo)

        self.header_layout.addRow("Reference No.:", self.reference_edit)
        self.header_layout.addRow("Narration:", self.narration_edit)

        header_group.setLayout(self.header_layout)
        layout.addWidget(header_group)

        if self.enable_stock:
            stock_group = QGroupBox("Stock Items (optional — drives the amount below when used)")
            stock_layout = QVBoxLayout()

            self.stock_table = QTableWidget(0, 4)
            self.stock_table.setHorizontalHeaderLabels(["Item", "Qty", "Rate", "Amount"])
            self.stock_table.horizontalHeader().setSectionResizeMode(
                QHeaderView.ResizeMode.Stretch
            )
            stock_layout.addWidget(self.stock_table)

            stock_btn_row = QHBoxLayout()
            add_stock_btn = QPushButton("Add Item")
            add_stock_btn.clicked.connect(self.add_stock_line)
            remove_stock_btn = QPushButton("Remove Last Item")
            remove_stock_btn.clicked.connect(self.remove_stock_line)
            stock_btn_row.addWidget(add_stock_btn)
            stock_btn_row.addWidget(remove_stock_btn)
            stock_btn_row.addStretch()
            stock_layout.addLayout(stock_btn_row)

            self.stock_total_label = QLabel("Stock Total: 0.00")
            stock_layout.addWidget(self.stock_total_label)

            stock_group.setLayout(stock_layout)
            layout.addWidget(stock_group)

        self.lines_group = QGroupBox()
        lines_layout = QVBoxLayout()

        self.lines_table = QTableWidget(0, 3)
        self.lines_table.setHorizontalHeaderLabels(["Account", "Debit", "Credit"])
        self.lines_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        lines_layout.addWidget(self.lines_table)

        btn_row = QHBoxLayout()
        add_line_btn = QPushButton("Add Line")
        add_line_btn.clicked.connect(self.add_line)
        remove_line_btn = QPushButton("Remove Last Line")
        remove_line_btn.clicked.connect(self.remove_line)
        btn_row.addWidget(add_line_btn)
        btn_row.addWidget(remove_line_btn)
        btn_row.addStretch()
        lines_layout.addLayout(btn_row)

        self.totals_label = QLabel("Total Debit: 0.00   |   Total Credit: 0.00")
        f = QFont()
        f.setBold(True)
        self.totals_label.setFont(f)
        lines_layout.addWidget(self.totals_label)

        self.lines_group.setLayout(lines_layout)
        layout.addWidget(self.lines_group)

        action_row = QHBoxLayout()
        check_btn = QPushButton("Check Totals")
        check_btn.clicked.connect(self.update_totals)
        self.save_btn = QPushButton("Save Voucher")
        self.save_btn.clicked.connect(self.save_voucher)
        self.save_btn.setAutoDefault(True)
        self.save_btn.setDefault(True)
        action_row.addWidget(check_btn)
        action_row.addWidget(self.save_btn)
        action_row.addStretch()
        layout.addLayout(action_row)

        self._update_lines_group_title()

        self.accounts_cache = []
        self.reload_accounts()
        if self.enable_stock:
            self.reload_stock_items()
            self.add_stock_line(warn_if_empty=False)
        if self.fixed_account_name is None:
            self.add_line()
            self.add_line()
        elif self.party_in_header:
            self.lines_group.setVisible(False)
        else:
            self.add_line()
        self.refresh_voucher_no()

    def _update_lines_group_title(self):
        if self.fixed_account_name is None:
            self.lines_group.setTitle("Entries (Debit = Credit required)")
        elif self.single_entry_mode:
            other_side = "Credit" if self.fixed_side == "debit" else "Debit"
            self.lines_group.setTitle(f"Other Ledger(s) — enter {other_side} amount")
        else:
            self.lines_group.setTitle("Entries (Debit = Credit required)")

    def _set_fixed_header_visible(self, visible):
        if self.fixed_amount_edit is None:
            return
        self.fixed_amount_edit.setVisible(visible)
        label_widget = self.header_layout.labelForField(self.fixed_amount_edit)
        if label_widget is not None:
            label_widget.setVisible(visible)

    def _set_party_header_visible(self, visible):
        if self.party_combo is None:
            return
        self.party_combo.setVisible(visible)
        label1 = self.header_layout.labelForField(self.party_combo)
        if label1 is not None:
            label1.setVisible(visible)

    def _get_fixed_account(self):
        return next(
            (a for a in self.accounts_cache if a.name == self.fixed_account_name), None
        )

    def on_mode_changed(self, state):
        self.single_entry_mode = self.mode_checkbox.isChecked()
        if self.single_entry_mode:
            self._switch_to_single_entry()
        else:
            self._switch_to_double_entry()
        self._update_lines_group_title()
        self.update_totals()

    def _switch_to_double_entry(self):
        self._set_fixed_header_visible(False)
        carry_amount = self.fixed_amount_edit.text() or ""
        # unlock all existing (other-leg) lines fully
        for line in self.lines:
            line.debit_edit.setEnabled(True)
            line.credit_edit.setEnabled(True)
        # add an editable row for the fixed account, pre-filled with
        # whatever amount was showing in the header
        row = 0
        self.lines_table.insertRow(row)
        line = VoucherLineRow(self.lines_table, row, self.accounts_cache)
        target_acc = self._get_fixed_account()
        if target_acc is not None:
            idx = line.account_combo.findData(target_acc.id)
            if idx >= 0:
                line.account_combo.setCurrentIndex(idx)
        if self.fixed_side == "debit":
            line.debit_edit.setText(carry_amount)
        else:
            line.credit_edit.setText(carry_amount)
        line.debit_edit.textChanged.connect(self.update_totals)
        line.credit_edit.textChanged.connect(self.update_totals)
        self.lines.insert(0, line)
        self.fixed_line = line

        if self.party_in_header:
            # bring the party ledger back as a normal editable table row
            party_account_id = self.party_combo.currentData()
            party_amount = carry_amount
            self._set_party_header_visible(False)
            self.lines_group.setVisible(True)
            row2 = self.lines_table.rowCount()
            self.lines_table.insertRow(row2)
            pline = VoucherLineRow(self.lines_table, row2, self.accounts_cache)
            if party_account_id is not None:
                idx2 = pline.account_combo.findData(party_account_id)
                if idx2 >= 0:
                    pline.account_combo.setCurrentIndex(idx2)
            if self.fixed_side == "debit":
                pline.credit_edit.setText(party_amount)
            else:
                pline.debit_edit.setText(party_amount)
            pline.debit_edit.textChanged.connect(self.update_totals)
            pline.credit_edit.textChanged.connect(self.update_totals)
            self.lines.append(pline)

    def _switch_to_single_entry(self):
        if self.fixed_line is not None and self.fixed_line in self.lines:
            idx = self.lines.index(self.fixed_line)
            self.lines_table.removeRow(idx)
            self.lines.pop(idx)
        self.fixed_line = None

        if self.party_in_header:
            # collapse the remaining "other" line(s) back into the header
            if self.lines:
                first_other = self.lines[0]
                account_id, debit, credit = first_other.get_values()
                amount = credit if self.fixed_side == "debit" else debit
                while self.lines:
                    row = self.lines_table.rowCount() - 1
                    self.lines_table.removeRow(row)
                    self.lines.pop()
                if account_id is not None:
                    idx = self.party_combo.findData(account_id)
                    if idx >= 0:
                        self.party_combo.setCurrentIndex(idx)
                self.fixed_amount_edit.setText(f"{amount:.2f}" if amount else "")
            self.lines_group.setVisible(False)
            self._set_party_header_visible(True)
        else:
            for line in self.lines:
                if self.fixed_side == "debit":
                    line.debit_edit.setEnabled(False)
                else:
                    line.credit_edit.setEnabled(False)
            if not self.lines:
                self.add_line()

        self._set_fixed_header_visible(True)

    def reload_accounts(self):
        session = Session()
        self.accounts_cache = session.query(Account).order_by(Account.name).all()
        session.close()
        # refresh existing rows' combo contents while preserving selection
        for line in self.lines:
            current_id = line.account_combo.currentData()
            was_enabled = line.account_combo.isEnabled()
            line.account_combo.blockSignals(True)
            line.account_combo.clear()
            for acc in self.accounts_cache:
                line.account_combo.addItem(f"{acc.name} ({acc.type.value})", acc.id)
            if current_id is not None:
                idx = line.account_combo.findData(current_id)
                if idx >= 0:
                    line.account_combo.setCurrentIndex(idx)
            line.account_combo.blockSignals(False)
            line.account_combo.setEnabled(was_enabled)
        if self.party_combo is not None:
            current_id = self.party_combo.currentData()
            self.party_combo.blockSignals(True)
            self.party_combo.clear()
            for acc in self.accounts_cache:
                self.party_combo.addItem(f"{acc.name} ({acc.type.value})", acc.id)
            if current_id is not None:
                idx = self.party_combo.findData(current_id)
                if idx >= 0:
                    self.party_combo.setCurrentIndex(idx)
            self.party_combo.blockSignals(False)
        if self.enable_stock:
            self.reload_stock_items()

    def reload_stock_items(self):
        session = Session()
        self.stock_items_cache = session.query(StockItem).order_by(StockItem.name).all()
        session.close()
        for sline in self.stock_lines:
            current_id = sline.item_combo.currentData()
            sline.item_combo.blockSignals(True)
            sline.item_combo.clear()
            for it in self.stock_items_cache:
                sline.item_combo.addItem(f"{it.name} ({it.unit})", it.id)
            if current_id is not None:
                idx = sline.item_combo.findData(current_id)
                if idx >= 0:
                    sline.item_combo.setCurrentIndex(idx)
            sline.item_combo.blockSignals(False)

    def add_stock_line(self, warn_if_empty=True):
        if not self.stock_items_cache and warn_if_empty:
            QMessageBox.warning(self, "No Stock Items", "Please add stock items in Masters first.")
            return
        row = self.stock_table.rowCount()
        self.stock_table.insertRow(row)
        sline = StockLineRow(self.stock_table, row, self.stock_items_cache)
        sline.qty_edit.textChanged.connect(lambda: self._on_stock_line_changed(sline))
        sline.rate_edit.textChanged.connect(lambda: self._on_stock_line_changed(sline))
        self.stock_lines.append(sline)
        self.update_totals()

    def _on_stock_line_changed(self, sline):
        sline.update_amount()
        self.update_totals()

    def remove_stock_line(self):
        if not self.stock_lines:
            return
        row = self.stock_table.rowCount() - 1
        self.stock_table.removeRow(row)
        self.stock_lines.pop()
        self.update_totals()

    def get_focus_chain(self):
        """Ordered list of currently-focusable input widgets, used to make
        Enter move sensibly through the form even inside the lines table
        (which Qt's own focus chain doesn't dive into reliably)."""
        chain = [self.date_edit]
        if self.party_in_header and self.single_entry_mode:
            # Skip the amount field in the Enter chain — it's normally
            # filled automatically from Stock Items, so Enter shouldn't
            # stop there. It's still clickable/editable directly for
            # manual entry when Stock Items aren't used.
            chain.append(self.party_combo)
        chain.append(self.reference_edit)
        chain.append(self.narration_edit)
        if self.enable_stock:
            for sline in self.stock_lines:
                for widget in (sline.item_combo, sline.qty_edit, sline.rate_edit):
                    if widget.isEnabled() and widget.focusPolicy() != Qt.FocusPolicy.NoFocus:
                        chain.append(widget)
        if not (self.party_in_header and self.single_entry_mode):
            for line in self.lines:
                for widget in (line.account_combo, line.debit_edit, line.credit_edit):
                    if widget.isEnabled() and widget.focusPolicy() != Qt.FocusPolicy.NoFocus:
                        chain.append(widget)
        chain.append(self.save_btn)
        return chain

    def focus_next_from(self, widget):
        chain = self.get_focus_chain()
        try:
            idx = chain.index(widget)
        except ValueError:
            return
        if idx + 1 < len(chain):
            chain[idx + 1].setFocus(Qt.FocusReason.TabFocusReason)

    def showEvent(self, event):
        super().showEvent(event)
        self.refresh_voucher_no()
        self.date_edit.setFocus(Qt.FocusReason.OtherFocusReason)

    def refresh_voucher_no(self):
        vtype = self.fixed_voucher_type
        if vtype is None:
            vtype = self.type_combo.currentData()
        if vtype is None:
            return
        session = Session()
        next_no = get_next_voucher_number(
            session, vtype,
            fixed_account_name=self.fixed_account_name,
            fixed_side=self.fixed_side,
        )
        session.close()
        self.voucher_no_edit.setText(str(next_no))

    def add_line(self):
        if not self.accounts_cache:
            QMessageBox.warning(self, "No Accounts", "Please add accounts in Chart of Accounts first.")
            return
        row = self.lines_table.rowCount()
        self.lines_table.insertRow(row)
        line = VoucherLineRow(self.lines_table, row, self.accounts_cache)

        if self.single_entry_mode and self.fixed_side is not None:
            # Every "other" line can only use the side opposite the fixed
            # account (e.g. Cash is always Dr in a Receipt, so other lines
            # can only be Cr).
            if self.fixed_side == "debit":
                line.debit_edit.setEnabled(False)
            else:
                line.credit_edit.setEnabled(False)

        line.debit_edit.textChanged.connect(self.update_totals)
        line.credit_edit.textChanged.connect(self.update_totals)
        self.lines.append(line)
        self.update_totals()

    def remove_line(self):
        if len(self.lines) <= 1:
            return  # always keep at least one line
        row = self.lines_table.rowCount() - 1
        removed = self.lines[-1]
        self.lines_table.removeRow(row)
        self.lines.pop()
        if removed is self.fixed_line:
            self.fixed_line = None
        self.update_totals()

    def update_totals(self):
        stock_total = 0.0
        if self.enable_stock:
            for sline in self.stock_lines:
                sline.update_amount()
                _, qty, rate, amount = sline.get_values()
                stock_total += amount
            self.stock_total_label.setText(f"Stock Total: {fmt_money(stock_total)}")

        use_header_party = self.party_in_header and self.single_entry_mode

        if use_header_party:
            if stock_total > 0:
                fixed_value = stock_total
                self.fixed_amount_edit.blockSignals(True)
                self.fixed_amount_edit.setText(f"{fixed_value:.2f}")
                self.fixed_amount_edit.blockSignals(False)
                self.fixed_amount_edit.setReadOnly(True)
                self.fixed_amount_edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            else:
                self.fixed_amount_edit.setReadOnly(False)
                self.fixed_amount_edit.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
                try:
                    fixed_value = float(self.fixed_amount_edit.text() or 0)
                except ValueError:
                    fixed_value = 0.0
            party_amount = fixed_value  # always identical — one field only

            if self.fixed_side == "debit":
                total_debit, total_credit = fixed_value, party_amount
            else:
                total_debit, total_credit = party_amount, fixed_value
        else:
            # auto-fill the lone "other" line from stock, if applicable
            if (
                self.enable_stock and stock_total > 0 and len(self.lines) == 1
                and self.single_entry_mode and self.fixed_account_name is not None
            ):
                only_line = self.lines[0]
                target = (
                    only_line.credit_edit if self.fixed_side == "debit"
                    else only_line.debit_edit
                )
                target.blockSignals(True)
                target.setText(f"{stock_total:.2f}")
                target.blockSignals(False)

            fixed_value = 0.0
            if self.single_entry_mode and self.fixed_account_name is not None:
                other_debit = 0.0
                other_credit = 0.0
                for line in self.lines:
                    _, d, c = line.get_values()
                    other_debit += d
                    other_credit += c
                fixed_value = other_credit if self.fixed_side == "debit" else other_debit
                self.fixed_amount_edit.setText(f"{fixed_value:.2f}" if fixed_value else "")

            total_debit = 0.0
            total_credit = 0.0
            for line in self.lines:
                _, d, c = line.get_values()
                total_debit += d
                total_credit += c

            if self.single_entry_mode and self.fixed_account_name is not None:
                if self.fixed_side == "debit":
                    total_debit += fixed_value
                else:
                    total_credit += fixed_value

        self.totals_label.setText(
            f"Total Debit: {fmt_money(total_debit)}   |   Total Credit: {fmt_money(total_credit)}"
        )
        if abs(total_debit - total_credit) > 0.001:
            self.totals_label.setStyleSheet("color: red;")
        else:
            self.totals_label.setStyleSheet("color: green;")
        return total_debit, total_credit

    def save_voucher(self):
        total_debit, total_credit = self.update_totals()

        if abs(total_debit - total_credit) > 0.001:
            QMessageBox.critical(
                self, "Unbalanced Voucher",
                f"Debit ({fmt_money(total_debit)}) does not equal "
                f"Credit ({fmt_money(total_credit)}). Please correct before saving."
            )
            return

        if total_debit == 0:
            QMessageBox.warning(self, "Empty Voucher", "Please enter at least one debit and credit amount.")
            return

        entries_data = []

        if self.single_entry_mode and self.fixed_account_name is not None:
            fixed_value = float(self.fixed_amount_edit.text() or 0)
            if fixed_value > 0:
                target_acc = self._get_fixed_account()
                if target_acc is not None:
                    if self.fixed_side == "debit":
                        entries_data.append((target_acc.id, fixed_value, 0.0))
                    else:
                        entries_data.append((target_acc.id, 0.0, fixed_value))

        if self.party_in_header and self.single_entry_mode:
            party_account_id = self.party_combo.currentData()
            party_amount = float(self.fixed_amount_edit.text() or 0)
            if party_account_id is not None and party_amount > 0:
                if self.fixed_side == "debit":
                    entries_data.append((party_account_id, 0.0, party_amount))
                else:
                    entries_data.append((party_account_id, party_amount, 0.0))
        else:
            for line in self.lines:
                account_id, debit, credit = line.get_values()
                if account_id is None:
                    continue
                if debit == 0 and credit == 0:
                    continue
                if debit > 0 and credit > 0:
                    QMessageBox.critical(
                        self, "Invalid Line",
                        "A single line cannot have both a debit and a credit amount."
                    )
                    return
                entries_data.append((account_id, debit, credit))

        if len(entries_data) < 2:
            QMessageBox.warning(
                self, "Incomplete Voucher",
                "A voucher needs at least two entry lines (one debit, one credit)."
            )
            return

        confirm = QMessageBox.question(
            self, "Save Voucher",
            f"Save this voucher for {fmt_money(total_debit)}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        session = Session()
        voucher = Voucher(
            date=self.date_edit.date().toPyDate(),
            type=self.type_combo.currentData(),
            narration=self.narration_edit.text().strip(),
            reference=self.reference_edit.text().strip(),
        )
        for account_id, debit, credit in entries_data:
            voucher.entries.append(
                VoucherEntry(account_id=account_id, debit=debit, credit=credit)
            )
        if self.enable_stock:
            for sline in self.stock_lines:
                item_id, qty, rate, amount = sline.get_values()
                if item_id is None or qty == 0:
                    continue
                voucher.stock_entries.append(
                    VoucherStockEntry(stock_item_id=item_id, quantity=qty, rate=rate, amount=amount)
                )
        session.add(voucher)
        session.commit()
        session.close()

        QMessageBox.information(self, "Saved", "Voucher saved successfully.")

        # reset form
        self.narration_edit.clear()
        self.reference_edit.clear()
        self.fixed_line = None
        while self.lines:
            row = self.lines_table.rowCount() - 1
            self.lines_table.removeRow(row)
            self.lines.pop()
        if self.enable_stock:
            while self.stock_lines:
                row = self.stock_table.rowCount() - 1
                self.stock_table.removeRow(row)
                self.stock_lines.pop()
            self.add_stock_line(warn_if_empty=False)

        if not self.single_entry_mode and self.fixed_account_name is not None:
            row = 0
            self.lines_table.insertRow(row)
            line = VoucherLineRow(self.lines_table, row, self.accounts_cache)
            target_acc = self._get_fixed_account()
            if target_acc is not None:
                idx = line.account_combo.findData(target_acc.id)
                if idx >= 0:
                    line.account_combo.setCurrentIndex(idx)
            line.debit_edit.textChanged.connect(self.update_totals)
            line.credit_edit.textChanged.connect(self.update_totals)
            self.lines.insert(0, line)
            self.fixed_line = line

        if self.party_in_header and self.single_entry_mode:
            self.fixed_amount_edit.clear()
            self.fixed_amount_edit.setReadOnly(False)
            self.fixed_amount_edit.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        elif self.fixed_account_name is None:
            self.add_line()
            self.add_line()
        else:
            self.add_line()

        if self.fixed_account_name is not None:
            self._set_fixed_header_visible(self.single_entry_mode)
        if self.party_in_header:
            self._set_party_header_visible(self.single_entry_mode)
            self.lines_group.setVisible(not self.single_entry_mode)

        self.refresh_voucher_no()

        if self.refresh_callback:
            self.refresh_callback()


# --------------------------------------------------------------------------
# Voucher Detail / Edit Dialog (opened by double-clicking a ledger row)
# --------------------------------------------------------------------------

class VoucherDetailDialog(QDialog):
    def __init__(self, voucher_id, parent=None):
        super().__init__(parent)
        self.voucher_id = voucher_id
        self.lines = []
        self.stock_lines = []
        self.setWindowTitle(f"Voucher #{voucher_id}")
        self.resize(700, 650)

        layout = QVBoxLayout(self)

        header_layout = QFormLayout()
        self.voucher_no_edit = QLineEdit()
        self.voucher_no_edit.setReadOnly(True)
        self.voucher_no_edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        header_layout.addRow("Voucher No.:", self.voucher_no_edit)
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.type_combo = QComboBox()
        for t in VoucherType:
            self.type_combo.addItem(t.value, t)
        self.reference_edit = QLineEdit()
        self.narration_edit = QLineEdit()
        header_layout.addRow("Date:", self.date_edit)
        header_layout.addRow("Voucher Type:", self.type_combo)
        header_layout.addRow("Reference No.:", self.reference_edit)
        header_layout.addRow("Narration:", self.narration_edit)
        layout.addLayout(header_layout)

        self.stock_group = QGroupBox("Stock Items")
        stock_layout = QVBoxLayout()
        self.stock_table = QTableWidget(0, 4)
        self.stock_table.setHorizontalHeaderLabels(["Item", "Qty", "Rate", "Amount"])
        self.stock_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        stock_layout.addWidget(self.stock_table)
        stock_btn_row = QHBoxLayout()
        add_stock_btn = QPushButton("Add Item")
        add_stock_btn.clicked.connect(lambda: self.add_stock_line())
        remove_stock_btn = QPushButton("Remove Last Item")
        remove_stock_btn.clicked.connect(self.remove_stock_line)
        stock_btn_row.addWidget(add_stock_btn)
        stock_btn_row.addWidget(remove_stock_btn)
        stock_btn_row.addStretch()
        stock_layout.addLayout(stock_btn_row)
        self.stock_group.setLayout(stock_layout)
        layout.addWidget(self.stock_group)

        self.lines_table = QTableWidget(0, 3)
        self.lines_table.setHorizontalHeaderLabels(["Account", "Debit", "Credit"])
        self.lines_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        layout.addWidget(self.lines_table)

        btn_row = QHBoxLayout()
        add_line_btn = QPushButton("Add Line")
        add_line_btn.clicked.connect(self.add_line)
        remove_line_btn = QPushButton("Remove Last Line")
        remove_line_btn.clicked.connect(self.remove_line)
        btn_row.addWidget(add_line_btn)
        btn_row.addWidget(remove_line_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.totals_label = QLabel("")
        f = QFont()
        f.setBold(True)
        self.totals_label.setFont(f)
        layout.addWidget(self.totals_label)

        action_row = QHBoxLayout()
        self.save_btn = QPushButton("Save Changes")
        self.save_btn.clicked.connect(self.save_changes)
        self.delete_btn = QPushButton("Delete Voucher")
        self.delete_btn.setStyleSheet("color: red;")
        self.delete_btn.clicked.connect(self.delete_voucher)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        action_row.addWidget(self.save_btn)
        action_row.addWidget(self.delete_btn)
        action_row.addStretch()
        action_row.addWidget(close_btn)
        layout.addLayout(action_row)

        self.session = Session()
        self.accounts_cache = self.session.query(Account).order_by(Account.name).all()
        self.stock_items_cache = self.session.query(StockItem).order_by(StockItem.name).all()
        self.load_voucher()

    def showEvent(self, event):
        super().showEvent(event)
        self.date_edit.setFocus(Qt.FocusReason.OtherFocusReason)

    def load_voucher(self):
        voucher = self.session.get(Voucher, self.voucher_id)
        if voucher is None:
            QMessageBox.warning(self, "Not Found", "This voucher no longer exists.")
            self.reject()
            return
        voucher_no = get_voucher_number(self.session, voucher)
        self.voucher_no_edit.setText(f"{voucher_no} ({get_voucher_label_for_saved(voucher)})")
        self.date_edit.setDate(QDate(voucher.date.year, voucher.date.month, voucher.date.day))
        idx = self.type_combo.findData(voucher.type)
        if idx >= 0:
            self.type_combo.setCurrentIndex(idx)
        self.reference_edit.setText(voucher.reference or "")
        self.narration_edit.setText(voucher.narration or "")

        self.stock_group.setVisible(
            voucher.type in (VoucherType.PURCHASE, VoucherType.SALE) or bool(voucher.stock_entries)
        )
        for se in voucher.stock_entries:
            self.add_stock_line(item_id=se.stock_item_id, qty=se.quantity, rate=se.rate)

        for entry in voucher.entries:
            self.add_line(debit=entry.debit, credit=entry.credit, account_id=entry.account_id)
        self.update_totals()

    def add_stock_line(self, item_id=None, qty=0.0, rate=0.0):
        if not self.stock_items_cache:
            QMessageBox.warning(self, "No Stock Items", "Please add stock items in Masters first.")
            return
        row = self.stock_table.rowCount()
        self.stock_table.insertRow(row)
        sline = StockLineRow(self.stock_table, row, self.stock_items_cache)
        if item_id is not None:
            idx = sline.item_combo.findData(item_id)
            if idx >= 0:
                sline.item_combo.setCurrentIndex(idx)
        if qty:
            sline.qty_edit.setText(str(qty))
        if rate:
            sline.rate_edit.setText(str(rate))
        sline.update_amount()
        sline.qty_edit.textChanged.connect(lambda: sline.update_amount())
        sline.rate_edit.textChanged.connect(lambda: sline.update_amount())
        self.stock_lines.append(sline)

    def remove_stock_line(self):
        if self.stock_lines:
            row = self.stock_table.rowCount() - 1
            self.stock_table.removeRow(row)
            self.stock_lines.pop()

    def add_line(self, debit=0.0, credit=0.0, account_id=None):
        row = self.lines_table.rowCount()
        self.lines_table.insertRow(row)
        line = VoucherLineRow(self.lines_table, row, self.accounts_cache)
        if account_id is not None:
            idx = line.account_combo.findData(account_id)
            if idx >= 0:
                line.account_combo.setCurrentIndex(idx)
        if debit:
            line.debit_edit.setText(str(debit))
        if credit:
            line.credit_edit.setText(str(credit))
        line.debit_edit.textChanged.connect(self.update_totals)
        line.credit_edit.textChanged.connect(self.update_totals)
        self.lines.append(line)
        self.update_totals()

    def remove_line(self):
        if self.lines:
            row = self.lines_table.rowCount() - 1
            self.lines_table.removeRow(row)
            self.lines.pop()
            self.update_totals()

    def update_totals(self):
        total_debit = 0.0
        total_credit = 0.0
        for line in self.lines:
            _, d, c = line.get_values()
            total_debit += d
            total_credit += c
        self.totals_label.setText(
            f"Total Debit: {fmt_money(total_debit)}   |   Total Credit: {fmt_money(total_credit)}"
        )
        if abs(total_debit - total_credit) > 0.001:
            self.totals_label.setStyleSheet("color: red;")
        else:
            self.totals_label.setStyleSheet("color: green;")
        return total_debit, total_credit

    def save_changes(self):
        total_debit, total_credit = self.update_totals()
        if abs(total_debit - total_credit) > 0.001:
            QMessageBox.critical(
                self, "Unbalanced Voucher",
                f"Debit ({fmt_money(total_debit)}) does not equal "
                f"Credit ({fmt_money(total_credit)}). Please correct before saving."
            )
            return
        if total_debit == 0:
            QMessageBox.warning(self, "Empty Voucher", "Please enter at least one debit and credit amount.")
            return

        entries_data = []
        for line in self.lines:
            account_id, debit, credit = line.get_values()
            if account_id is None:
                continue
            if debit == 0 and credit == 0:
                continue
            if debit > 0 and credit > 0:
                QMessageBox.critical(
                    self, "Invalid Line",
                    "A single line cannot have both a debit and a credit amount."
                )
                return
            entries_data.append((account_id, debit, credit))

        if len(entries_data) < 2:
            QMessageBox.warning(
                self, "Incomplete Voucher",
                "A voucher needs at least two entry lines (one debit, one credit)."
            )
            return

        stock_data = []
        for sline in self.stock_lines:
            item_id, qty, rate, amount = sline.get_values()
            if item_id is None or qty == 0:
                continue
            stock_data.append((item_id, qty, rate, amount))

        confirm = QMessageBox.question(
            self, "Save Changes",
            f"Save changes to this voucher for {fmt_money(total_debit)}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        voucher = self.session.get(Voucher, self.voucher_id)
        voucher.date = self.date_edit.date().toPyDate()
        voucher.type = self.type_combo.currentData()
        voucher.reference = self.reference_edit.text().strip()
        voucher.narration = self.narration_edit.text().strip()

        # replace all entries with the edited set
        for e in list(voucher.entries):
            self.session.delete(e)
        voucher.entries.clear()
        for account_id, debit, credit in entries_data:
            voucher.entries.append(
                VoucherEntry(account_id=account_id, debit=debit, credit=credit)
            )

        # replace stock entries with the edited set
        for se in list(voucher.stock_entries):
            self.session.delete(se)
        voucher.stock_entries.clear()
        for item_id, qty, rate, amount in stock_data:
            voucher.stock_entries.append(
                VoucherStockEntry(stock_item_id=item_id, quantity=qty, rate=rate, amount=amount)
            )

        self.session.commit()
        QMessageBox.information(self, "Saved", "Voucher updated successfully.")
        self.accept()

    def delete_voucher(self):
        confirm = QMessageBox.question(
            self, "Delete Voucher",
            "Are you sure you want to delete this voucher? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return
        voucher = self.session.get(Voucher, self.voucher_id)
        self.session.delete(voucher)
        self.session.commit()
        QMessageBox.information(self, "Deleted", "Voucher deleted.")
        self.accept()

    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event)


# --------------------------------------------------------------------------
# Ledger Tab
# --------------------------------------------------------------------------

class LedgerTab(QWidget):
    def __init__(self, refresh_callback=None):
        super().__init__()
        self.refresh_callback = refresh_callback
        layout = QVBoxLayout(self)

        top_row = QHBoxLayout()
        self.account_combo = QComboBox()
        top_row.addWidget(QLabel("Account:"))
        top_row.addWidget(self.account_combo, 1)
        layout.addLayout(top_row)

        period_row = QHBoxLayout()
        self.from_edit = QDateEdit()
        self.from_edit.setCalendarPopup(True)
        self.from_edit.setDate(QDate(2000, 1, 1))
        self.to_edit = QDateEdit()
        self.to_edit.setCalendarPopup(True)
        self.to_edit.setDate(QDate.currentDate())
        self.view_btn = QPushButton("View Ledger")
        self.view_btn.clicked.connect(self.load_ledger)
        period_row.addWidget(QLabel("From:"))
        period_row.addWidget(self.from_edit)
        period_row.addWidget(QLabel("To:"))
        period_row.addWidget(self.to_edit)
        period_row.addWidget(self.view_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any row to open, edit, or delete that voucher.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Date", "Voucher Type", "Narration", "Debit", "Credit"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_voucher)
        layout.addWidget(self.table)

        self.balance_label = QLabel(
            "Opening Balance: 0.00   |   Closing Balance: 0.00"
        )
        f = QFont()
        f.setBold(True)
        self.balance_label.setFont(f)
        layout.addWidget(self.balance_label)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.reload_accounts()

    def reload_accounts(self):
        current_id = self.account_combo.currentData()
        session = Session()
        accounts = session.query(Account).order_by(Account.name).all()
        session.close()
        self.account_combo.blockSignals(True)
        self.account_combo.clear()
        for acc in accounts:
            self.account_combo.addItem(acc.name, acc.id)
        if current_id is not None:
            idx = self.account_combo.findData(current_id)
            if idx >= 0:
                self.account_combo.setCurrentIndex(idx)
        self.account_combo.blockSignals(False)

    def show_all_history(self):
        """Reset the period filter to show full history — used when
        navigating here from a drill-down click elsewhere."""
        self.from_edit.setDate(QDate(2000, 1, 1))
        self.to_edit.setDate(QDate.currentDate())

    def load_ledger(self):
        account_id = self.account_combo.currentData()
        if account_id is None:
            return
        from_date = self.from_edit.date().toPyDate()
        to_date = self.to_edit.date().toPyDate()

        session = Session()
        account = session.get(Account, account_id)
        entries = (
            session.query(VoucherEntry)
            .join(Voucher)
            .filter(
                VoucherEntry.account_id == account_id,
                Voucher.date >= from_date,
                Voucher.date <= to_date,
            )
            .order_by(Voucher.date, Voucher.id)
            .all()
        )

        opening_from = from_date - timedelta(days=1)
        opening = account_balance(session, account, as_of=opening_from)

        self.table.setRowCount(len(entries))
        for row, e in enumerate(entries):
            v = e.voucher
            date_item = QTableWidgetItem(v.date.strftime("%d-%m-%Y"))
            date_item.setData(Qt.ItemDataRole.UserRole, v.id)
            self.table.setItem(row, 0, date_item)
            self.table.setItem(row, 1, QTableWidgetItem(get_voucher_label_for_saved(v)))
            self.table.setItem(row, 2, QTableWidgetItem(v.narration or ""))
            self.table.setItem(row, 3, QTableWidgetItem(fmt_money(e.debit) if e.debit else ""))
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(e.credit) if e.credit else ""))
            for col in range(5):
                item = self.table.item(row, col)
                if col != 0:
                    item.setData(Qt.ItemDataRole.UserRole, v.id)

        natural_debit = account.type in DEBIT_NATURE
        closing = account_balance(session, account, as_of=to_date)

        opening_side = "Dr" if (opening >= 0) == natural_debit else "Cr"
        closing_side = "Dr" if (closing >= 0) == natural_debit else "Cr"
        self.balance_label.setText(
            f"Opening Balance: {fmt_money(abs(opening))} {opening_side}   |   "
            f"Closing Balance: {fmt_money(abs(closing))} {closing_side}"
        )
        session.close()

    def open_voucher(self, item):
        voucher_id = item.data(Qt.ItemDataRole.UserRole)
        if voucher_id is None:
            return
        dialog = VoucherDetailDialog(voucher_id, parent=self)
        dialog.exec()
        # refresh ledger view and the rest of the app after any edit/delete
        self.load_ledger()
        if self.refresh_callback:
            self.refresh_callback()

    def export_to_excel(self):
        account_name = self.account_combo.currentText() or "Account"
        period = (
            f"Period: {self.from_edit.date().toString('dd-MM-yyyy')} to "
            f"{self.to_edit.date().toString('dd-MM-yyyy')}"
        )
        export_table_to_excel(
            self, self.table, f"Ledger - {account_name}", f"ledger_{account_name}.xlsx",
            info_lines=[f"Account: {account_name}", period, self.balance_label.text()]
        )


# --------------------------------------------------------------------------
# Day Book Tab: every voucher entry within a date range, Tally-style
# --------------------------------------------------------------------------

class DayBookTab(QWidget):
    def __init__(self, refresh_callback=None):
        super().__init__()
        self.refresh_callback = refresh_callback
        layout = QVBoxLayout(self)

        period_row = QHBoxLayout()
        self.from_edit = QDateEdit()
        self.from_edit.setCalendarPopup(True)
        self.from_edit.setDate(QDate.currentDate())
        self.to_edit = QDateEdit()
        self.to_edit.setCalendarPopup(True)
        self.to_edit.setDate(QDate.currentDate())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_day_book)
        period_row.addWidget(QLabel("From:"))
        period_row.addWidget(self.from_edit)
        period_row.addWidget(QLabel("To:"))
        period_row.addWidget(self.to_edit)
        period_row.addWidget(refresh_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any row to open, edit, or delete that voucher.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Date", "Voucher Type", "Account", "Narration", "Debit", "Credit"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_voucher)
        layout.addWidget(self.table)

        self.totals_label = QLabel("Total Debit: 0.00   |   Total Credit: 0.00")
        f = QFont()
        f.setBold(True)
        self.totals_label.setFont(f)
        layout.addWidget(self.totals_label)

        excel_row = QHBoxLayout()
        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        import_btn = QPushButton("Import Vouchers from Excel")
        import_btn.clicked.connect(self.import_vouchers_from_excel)
        excel_row.addWidget(export_btn)
        excel_row.addWidget(import_btn)
        excel_row.addStretch()
        layout.addLayout(excel_row)

        self.load_day_book()

    def load_day_book(self):
        from_date = self.from_edit.date().toPyDate()
        to_date = self.to_edit.date().toPyDate()

        session = Session()
        vouchers = (
            session.query(Voucher)
            .filter(Voucher.date >= from_date, Voucher.date <= to_date)
            .order_by(Voucher.date, Voucher.id)
            .all()
        )

        self.table.setRowCount(len(vouchers))
        total_debit = 0.0
        total_credit = 0.0
        for row, v in enumerate(vouchers):
            main_account_name = MAIN_LEG_ACCOUNT_NAME.get(v.type)
            main_entry = None
            if main_account_name:
                main_entry = next(
                    (e for e in v.entries if e.account.name == main_account_name), None
                )
            if main_entry is None and v.entries:
                main_entry = v.entries[0]  # e.g. Journal has no fixed leg

            date_item = QTableWidgetItem(v.date.strftime("%d-%m-%Y"))
            date_item.setData(Qt.ItemDataRole.UserRole, v.id)
            self.table.setItem(row, 0, date_item)
            self.table.setItem(row, 1, QTableWidgetItem(get_voucher_label_for_saved(v)))
            self.table.setItem(row, 2, QTableWidgetItem(main_entry.account.name if main_entry else ""))
            self.table.setItem(row, 3, QTableWidgetItem(v.narration or ""))
            debit = main_entry.debit if main_entry else 0.0
            credit = main_entry.credit if main_entry else 0.0
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(debit) if debit else ""))
            self.table.setItem(row, 5, QTableWidgetItem(fmt_money(credit) if credit else ""))
            for col in range(6):
                item = self.table.item(row, col)
                if col != 0:
                    item.setData(Qt.ItemDataRole.UserRole, v.id)
            total_debit += debit
            total_credit += credit

        session.close()
        self.totals_label.setText(
            f"Total Debit: {fmt_money(total_debit)}   |   Total Credit: {fmt_money(total_credit)}"
        )

    def open_voucher(self, item):
        voucher_id = item.data(Qt.ItemDataRole.UserRole)
        if voucher_id is None:
            return
        dialog = VoucherDetailDialog(voucher_id, parent=self)
        dialog.exec()
        self.load_day_book()
        if self.refresh_callback:
            self.refresh_callback()

    def export_to_excel(self):
        """Exports every accounting entry line (not just the main leg) in
        the current date range — a full audit-trail export."""
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        from_date = self.from_edit.date().toPyDate()
        to_date = self.to_edit.date().toPyDate()
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Vouchers", "vouchers.xlsx", "Excel Files (*.xlsx)"
        )
        if not path:
            return

        session = Session()
        vouchers = (
            session.query(Voucher)
            .filter(Voucher.date >= from_date, Voucher.date <= to_date)
            .order_by(Voucher.date, Voucher.id)
            .all()
        )

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Vouchers"
        ws.append([
            "Voucher Group", "Date", "Voucher Type", "Account",
            "Debit", "Credit", "Reference", "Narration"
        ])
        for v in vouchers:
            label = get_voucher_label_for_saved(v)
            for e in v.entries:
                ws.append([
                    v.id, v.date.strftime("%Y-%m-%d"), label, e.account.name,
                    e.debit or 0.0, e.credit or 0.0, v.reference or "", v.narration or "",
                ])
        session.close()

        try:
            wb.save(path)
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))
            return
        QMessageBox.information(self, "Exported", f"Vouchers exported to:\n{path}")

    def import_vouchers_from_excel(self):
        """Expects the same layout produced by Export: rows sharing a
        'Voucher Group' value are combined into one voucher, so multiple
        entry lines can belong to the same transaction. Voucher Type
        should be one of: Cash, Bank, Purchase, Sale, Journal (plain
        'Cash Receipt'/'Cash Payment' labels are also accepted and mapped
        to Cash/Bank automatically)."""
        openpyxl = _try_import_openpyxl()
        if openpyxl is None:
            _show_missing_openpyxl(self)
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Vouchers", "", "Excel Files (*.xlsx *.xls)"
        )
        if not path:
            return
        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            ws = wb.active
        except Exception as e:
            QMessageBox.critical(self, "Import Failed", f"Could not read the file:\n{e}")
            return

        type_aliases = {t.value.lower(): t for t in VoucherType}
        for t in VoucherType:
            type_aliases[t.value.lower()] = t
        type_aliases["cash receipt"] = VoucherType.CASH
        type_aliases["cash payment"] = VoucherType.CASH
        type_aliases["bank receipt"] = VoucherType.BANK
        type_aliases["bank payment"] = VoucherType.BANK

        session = Session()
        accounts_by_name = {a.name: a for a in session.query(Account).all()}

        groups = {}
        order = []
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            if not row or row[0] is None:
                continue
            key = str(row[0]).strip()
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append((row_idx, row))

        imported = 0
        errors = []
        for key in order:
            rows = groups[key]
            first_idx, first_row = rows[0]
            date_val = first_row[1] if len(first_row) > 1 else None
            type_str = str(first_row[2]).strip().lower() if len(first_row) > 2 and first_row[2] else None
            reference = str(first_row[6]).strip() if len(first_row) > 6 and first_row[6] else ""
            narration = str(first_row[7]).strip() if len(first_row) > 7 and first_row[7] else ""

            vtype = type_aliases.get(type_str)
            if vtype is None:
                errors.append(f"Group {key}: unknown voucher type '{first_row[2]}'")
                continue

            try:
                if isinstance(date_val, datetime):
                    voucher_date = date_val.date()
                elif isinstance(date_val, date):
                    voucher_date = date_val
                else:
                    voucher_date = datetime.strptime(str(date_val).strip(), "%Y-%m-%d").date()
            except Exception:
                errors.append(f"Group {key}: invalid date '{date_val}'")
                continue

            entries_data = []
            total_debit = 0.0
            total_credit = 0.0
            group_ok = True
            for row_idx, row in rows:
                acc_name = str(row[3]).strip() if len(row) > 3 and row[3] else None
                if acc_name not in accounts_by_name:
                    errors.append(f"Row {row_idx}: unknown account '{acc_name}'")
                    group_ok = False
                    continue
                try:
                    debit = float(row[4] or 0) if len(row) > 4 else 0.0
                    credit = float(row[5] or 0) if len(row) > 5 else 0.0
                except (TypeError, ValueError):
                    errors.append(f"Row {row_idx}: invalid debit/credit amount")
                    group_ok = False
                    continue
                entries_data.append((accounts_by_name[acc_name].id, debit, credit))
                total_debit += debit
                total_credit += credit

            if not group_ok:
                continue
            if abs(total_debit - total_credit) > 0.01:
                errors.append(
                    f"Group {key}: debit ({total_debit:.2f}) does not equal "
                    f"credit ({total_credit:.2f})"
                )
                continue
            if len(entries_data) < 2:
                errors.append(f"Group {key}: needs at least 2 entry lines")
                continue

            voucher = Voucher(
                date=voucher_date, type=vtype, reference=reference, narration=narration
            )
            for acc_id, debit, credit in entries_data:
                voucher.entries.append(VoucherEntry(account_id=acc_id, debit=debit, credit=credit))
            session.add(voucher)
            imported += 1

        session.commit()
        session.close()

        msg = f"Imported {imported} voucher(s)."
        if errors:
            msg += f"\n\n{len(errors)} row(s) skipped:\n" + "\n".join(errors[:15])
            if len(errors) > 15:
                msg += f"\n...and {len(errors) - 15} more."
        QMessageBox.information(self, "Import Complete", msg)

        self.load_day_book()
        if self.refresh_callback:
            self.refresh_callback()


# --------------------------------------------------------------------------
# Stock Item Ledger Tab: transaction history for a single stock item
# --------------------------------------------------------------------------

class StockItemLedgerTab(QWidget):
    def __init__(self, refresh_callback=None):
        super().__init__()
        self.refresh_callback = refresh_callback
        layout = QVBoxLayout(self)

        top_row = QHBoxLayout()
        self.item_combo = QComboBox()
        top_row.addWidget(QLabel("Item:"))
        top_row.addWidget(self.item_combo, 1)
        layout.addLayout(top_row)

        period_row = QHBoxLayout()
        self.from_edit = QDateEdit()
        self.from_edit.setCalendarPopup(True)
        self.from_edit.setDate(QDate(2000, 1, 1))
        self.to_edit = QDateEdit()
        self.to_edit.setCalendarPopup(True)
        self.to_edit.setDate(QDate.currentDate())
        self.view_btn = QPushButton("View")
        self.view_btn.clicked.connect(self.load_item_ledger)
        period_row.addWidget(QLabel("From:"))
        period_row.addWidget(self.from_edit)
        period_row.addWidget(QLabel("To:"))
        period_row.addWidget(self.to_edit)
        period_row.addWidget(self.view_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any row to open, edit, or delete that voucher.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Date", "Voucher Type", "Qty", "Rate", "Amount"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_voucher)
        layout.addWidget(self.table)

        self.balance_label = QLabel("Opening Qty: 0   |   Closing Qty: 0")
        f = QFont()
        f.setBold(True)
        self.balance_label.setFont(f)
        layout.addWidget(self.balance_label)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.reload_items()

    def reload_items(self):
        current_id = self.item_combo.currentData()
        session = Session()
        items = session.query(StockItem).order_by(StockItem.name).all()
        session.close()
        self.item_combo.blockSignals(True)
        self.item_combo.clear()
        for it in items:
            self.item_combo.addItem(it.name, it.id)
        if current_id is not None:
            idx = self.item_combo.findData(current_id)
            if idx >= 0:
                self.item_combo.setCurrentIndex(idx)
        self.item_combo.blockSignals(False)

    def show_all_history(self):
        """Reset the period filter to show full history — used when
        navigating here from a drill-down click elsewhere."""
        self.from_edit.setDate(QDate(2000, 1, 1))
        self.to_edit.setDate(QDate.currentDate())

    def load_item_ledger(self):
        item_id = self.item_combo.currentData()
        if item_id is None:
            return
        from_date = self.from_edit.date().toPyDate()
        to_date = self.to_edit.date().toPyDate()

        session = Session()
        item = session.get(StockItem, item_id)
        entries = (
            session.query(VoucherStockEntry)
            .join(Voucher)
            .filter(
                VoucherStockEntry.stock_item_id == item_id,
                Voucher.date >= from_date,
                Voucher.date <= to_date,
            )
            .order_by(Voucher.date, Voucher.id)
            .all()
        )

        opening_from = from_date - timedelta(days=1)
        opening = stock_balance(session, item, as_of=opening_from)

        self.table.setRowCount(len(entries))
        for row, se in enumerate(entries):
            v = se.voucher
            sign = 1 if v.type == VoucherType.PURCHASE else -1
            date_item = QTableWidgetItem(v.date.strftime("%d-%m-%Y"))
            date_item.setData(Qt.ItemDataRole.UserRole, v.id)
            self.table.setItem(row, 0, date_item)
            self.table.setItem(row, 1, QTableWidgetItem(get_voucher_label_for_saved(v)))
            self.table.setItem(row, 2, QTableWidgetItem(f"{sign * se.quantity:g}"))
            self.table.setItem(row, 3, QTableWidgetItem(fmt_money(se.rate)))
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(se.amount)))
            for col in range(5):
                cell = self.table.item(row, col)
                if col != 0:
                    cell.setData(Qt.ItemDataRole.UserRole, v.id)

        closing = stock_balance(session, item, as_of=to_date)
        self.balance_label.setText(
            f"Opening Qty: {opening:g}   |   Closing Qty: {closing:g}"
        )
        session.close()

    def open_voucher(self, item):
        voucher_id = item.data(Qt.ItemDataRole.UserRole)
        if voucher_id is None:
            return
        dialog = VoucherDetailDialog(voucher_id, parent=self)
        dialog.exec()
        self.load_item_ledger()
        if self.refresh_callback:
            self.refresh_callback()

    def export_to_excel(self):
        item_name = self.item_combo.currentText() or "Item"
        period = (
            f"Period: {self.from_edit.date().toString('dd-MM-yyyy')} to "
            f"{self.to_edit.date().toString('dd-MM-yyyy')}"
        )
        export_table_to_excel(
            self, self.table, f"Stock Ledger - {item_name}", f"stock_ledger_{item_name}.xlsx",
            info_lines=[f"Item: {item_name}", period, self.balance_label.text()]
        )


# --------------------------------------------------------------------------
# Stock Summary Tab
# --------------------------------------------------------------------------

class StockSummaryTab(QWidget):
    def __init__(self, navigate_callback=None):
        super().__init__()
        self.navigate_callback = navigate_callback
        layout = QVBoxLayout(self)

        period_row = QHBoxLayout()
        self.as_of_edit = QDateEdit()
        self.as_of_edit.setCalendarPopup(True)
        self.as_of_edit.setDate(QDate.currentDate())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_stock_summary)
        period_row.addWidget(QLabel("As of:"))
        period_row.addWidget(self.as_of_edit)
        period_row.addWidget(refresh_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any item row to open its transaction history.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Item", "Unit", "Opening Qty", "Current Qty", "Current Value"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_item_ledger)
        layout.addWidget(self.table)

        self.total_label = QLabel("Total Stock Value: 0.00")
        f = QFont()
        f.setBold(True)
        self.total_label.setFont(f)
        layout.addWidget(self.total_label)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.load_stock_summary()

    def load_stock_summary(self):
        as_of = self.as_of_edit.date().toPyDate()
        session = Session()
        items = session.query(StockItem).order_by(StockItem.name).all()

        self.table.setRowCount(len(items))
        total_value = 0.0
        for row, item in enumerate(items):
            qty = stock_balance(session, item, as_of=as_of)
            value = qty * (item.opening_rate or 0.0)
            total_value += value
            name_item = QTableWidgetItem(item.name)
            name_item.setData(Qt.ItemDataRole.UserRole, item.id)
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, QTableWidgetItem(item.unit))
            self.table.setItem(row, 2, QTableWidgetItem(f"{item.opening_qty:g}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{qty:g}"))
            self.table.setItem(row, 4, QTableWidgetItem(fmt_money(value)))
            for col in range(1, 5):
                self.table.item(row, col).setData(Qt.ItemDataRole.UserRole, item.id)

        session.close()
        self.total_label.setText(f"Total Stock Value: {fmt_money(total_value)}")

    def open_item_ledger(self, item):
        item_id = item.data(Qt.ItemDataRole.UserRole)
        if item_id is not None and self.navigate_callback:
            self.navigate_callback(item_id)

    def export_to_excel(self):
        export_table_to_excel(
            self, self.table, "Stock Summary", "stock_summary.xlsx",
            info_lines=[f"As of: {self.as_of_edit.date().toString('dd-MM-yyyy')}", self.total_label.text()]
        )


# --------------------------------------------------------------------------
# Trial Balance Tab
# --------------------------------------------------------------------------

class TrialBalanceTab(QWidget):
    def __init__(self, navigate_callback=None):
        super().__init__()
        self.navigate_callback = navigate_callback
        layout = QVBoxLayout(self)

        period_row = QHBoxLayout()
        self.as_of_edit = QDateEdit()
        self.as_of_edit.setCalendarPopup(True)
        self.as_of_edit.setDate(QDate.currentDate())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_trial_balance)
        period_row.addWidget(QLabel("As of:"))
        period_row.addWidget(self.as_of_edit)
        period_row.addWidget(refresh_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any account row to open its Ledger.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Account", "Debit", "Credit"])
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_ledger)
        layout.addWidget(self.table)

        self.totals_label = QLabel("")
        f = QFont()
        f.setBold(True)
        self.totals_label.setFont(f)
        layout.addWidget(self.totals_label)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.load_trial_balance()

    def load_trial_balance(self):
        as_of = self.as_of_edit.date().toPyDate()
        session = Session()
        accounts = session.query(Account).order_by(Account.type, Account.name).all()

        rows = []
        total_debit = 0.0
        total_credit = 0.0
        for acc in accounts:
            bal = account_balance(session, acc, as_of=as_of)
            natural_debit = acc.type in DEBIT_NATURE
            if natural_debit:
                debit_col = bal if bal >= 0 else 0.0
                credit_col = -bal if bal < 0 else 0.0
            else:
                credit_col = bal if bal >= 0 else 0.0
                debit_col = -bal if bal < 0 else 0.0
            if debit_col == 0 and credit_col == 0:
                continue
            rows.append((acc.id, acc.name, debit_col, credit_col))
            total_debit += debit_col
            total_credit += credit_col

        session.close()

        self.table.setRowCount(len(rows))
        for row, (acc_id, name, d, c) in enumerate(rows):
            name_item = QTableWidgetItem(name)
            debit_item = QTableWidgetItem(fmt_money(d) if d else "")
            credit_item = QTableWidgetItem(fmt_money(c) if c else "")
            for item in (name_item, debit_item, credit_item):
                item.setData(Qt.ItemDataRole.UserRole, acc_id)
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, debit_item)
            self.table.setItem(row, 2, credit_item)

        status = "BALANCED" if abs(total_debit - total_credit) < 0.01 else "NOT BALANCED"
        self.totals_label.setText(
            f"Total Debit: {fmt_money(total_debit)}   |   "
            f"Total Credit: {fmt_money(total_credit)}   |   {status}"
        )
        self.totals_label.setStyleSheet(
            "color: green;" if status == "BALANCED" else "color: red;"
        )

    def open_ledger(self, item):
        account_id = item.data(Qt.ItemDataRole.UserRole)
        if account_id is not None and self.navigate_callback:
            self.navigate_callback(account_id)

    def export_to_excel(self):
        export_table_to_excel(
            self, self.table, "Trial Balance", "trial_balance.xlsx",
            info_lines=[f"As of: {self.as_of_edit.date().toString('dd-MM-yyyy')}", self.totals_label.text()]
        )


# --------------------------------------------------------------------------
# Shared helper for building clickable report rows (P&L / Balance Sheet)
# --------------------------------------------------------------------------

def _add_report_row(table, label, amount="", account_id=None, bold=False, header=False):
    row = table.rowCount()
    table.insertRow(row)

    label_item = QTableWidgetItem(label)
    amount_item = QTableWidgetItem(amount)
    amount_item.setTextAlignment(
        Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
    )

    f = QFont()
    if bold or header:
        f.setBold(True)
    label_item.setFont(f)
    amount_item.setFont(f)

    if header:
        from PyQt6.QtGui import QColor
        bg = QColor("#e0e0e0")
        label_item.setBackground(bg)
        amount_item.setBackground(bg)

    if account_id is not None:
        label_item.setData(Qt.ItemDataRole.UserRole, account_id)
        amount_item.setData(Qt.ItemDataRole.UserRole, account_id)

    table.setItem(row, 0, label_item)
    table.setItem(row, 1, amount_item)
    return row


# --------------------------------------------------------------------------
# Profit & Loss Tab
# --------------------------------------------------------------------------

def _add_pl_row(table, left_label="", left_amount="", right_label="", right_amount="",
                 left_account_id=None, right_account_id=None, bold=False, header=False,
                 left_header=None, right_header=None, left_bold=None, right_bold=None):
    """header applies to the whole row; left_header/right_header (if given)
    override it per side, so a header on one side doesn't visually bleed
    onto a plain subtotal that happens to land on the same row. Same idea
    for left_bold/right_bold vs. the shared bold flag (bold-only, no grey
    background — used for sub-headings like "Cash & Bank Balance:")."""
    row = table.rowCount()
    table.insertRow(row)
    is_left_header = header if left_header is None else left_header
    is_right_header = header if right_header is None else right_header
    is_left_bold = bold if left_bold is None else left_bold
    is_right_bold = bold if right_bold is None else right_bold
    from PyQt6.QtGui import QColor
    for col, text, acc_id, is_hdr, is_bold in [
        (0, left_label, left_account_id, is_left_header, is_left_bold),
        (1, left_amount, left_account_id, is_left_header, is_left_bold),
        (2, right_label, right_account_id, is_right_header, is_right_bold),
        (3, right_amount, right_account_id, is_right_header, is_right_bold),
    ]:
        it = QTableWidgetItem(text)
        if col in (1, 3):
            it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        f = QFont()
        if is_bold or is_hdr:
            f.setBold(True)
        it.setFont(f)
        if is_hdr:
            it.setBackground(QColor("#e0e0e0"))
        if acc_id is not None:
            it.setData(Qt.ItemDataRole.UserRole, acc_id)
        table.setItem(row, col, it)
    return row


class ProfitLossTab(QWidget):
    def __init__(self, navigate_callback=None):
        super().__init__()
        self.navigate_callback = navigate_callback
        layout = QVBoxLayout(self)

        title = QLabel("Trading and Profit & Loss Account")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)

        period_row = QHBoxLayout()
        self.from_edit = QDateEdit()
        self.from_edit.setCalendarPopup(True)
        fy_start = get_financial_year_start(date.today())
        self.from_edit.setDate(QDate(fy_start.year, fy_start.month, fy_start.day))
        self.to_edit = QDateEdit()
        self.to_edit.setCalendarPopup(True)
        self.to_edit.setDate(QDate.currentDate())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_pl)
        period_row.addWidget(QLabel("For the period from:"))
        period_row.addWidget(self.from_edit)
        period_row.addWidget(QLabel("to:"))
        period_row.addWidget(self.to_edit)
        period_row.addWidget(refresh_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any account row to open its Ledger.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Expenditure", "Amount", "Income", "Amount"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_ledger)
        layout.addWidget(self.table)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.load_pl()

    def load_pl(self):
        from_date = self.from_edit.date().toPyDate()
        to_date = self.to_edit.date().toPyDate()

        session = Session()
        data = compute_trading_and_pl(session, from_date, to_date)
        purchase_acc = session.query(Account).filter_by(name="Purchase Account").first()
        sales_acc = session.query(Account).filter_by(name="Sales Account").first()

        self.table.setRowCount(0)

        # ---------------- Trading Account ----------------
        _add_pl_row(self.table, "TRADING ACCOUNT", "", "", "", header=True)

        left_rows = []
        if data["opening_stock"]:
            left_rows.append(("Opening Stock", data["opening_stock"], None))
        left_rows.append((
            "Purchase Account", data["purchase_amount"],
            purchase_acc.id if purchase_acc else None
        ))

        right_rows = [(
            "Sales Account", data["sales_amount"],
            sales_acc.id if sales_acc else None
        )]

        gross_result = data["gross_result"]
        if gross_result >= 0:
            left_rows.append(("Gross Profit c/d", gross_result, None))
        else:
            right_rows.append(("Gross Loss c/d", -gross_result, None))
        if data["closing_stock"]:
            right_rows.append(("Closing Stock (at cost)", data["closing_stock"], None))

        for i in range(max(len(left_rows), len(right_rows))):
            l = left_rows[i] if i < len(left_rows) else ("", 0, None)
            r = right_rows[i] if i < len(right_rows) else ("", 0, None)
            _add_pl_row(
                self.table,
                l[0], fmt_money(l[1]) if l[0] else "",
                r[0], fmt_money(r[1]) if r[0] else "",
                left_account_id=l[2], right_account_id=r[2],
            )

        trading_total = sum(x[1] for x in left_rows)
        _add_pl_row(
            self.table, "Total", fmt_money(trading_total), "Total", fmt_money(trading_total),
            bold=True
        )

        _add_pl_row(self.table, "", "", "", "")

        # ---------------- Profit & Loss Account ----------------
        _add_pl_row(self.table, "PROFIT & LOSS ACCOUNT", "", "", "", header=True)

        left_rows2 = []
        if gross_result < 0:
            left_rows2.append(("Gross Loss b/d", -gross_result, None))
        for acc, bal in data["indirect_expenses"]:
            left_rows2.append((acc.name, bal, acc.id))

        right_rows2 = []
        if gross_result >= 0:
            right_rows2.append(("Gross Profit b/d", gross_result, None))
        for acc, bal in data["other_income"]:
            right_rows2.append((acc.name, bal, acc.id))

        net_result = data["net_result"]
        if net_result >= 0:
            left_rows2.append(("Net Profit c/f to Capital A/c.", net_result, None))
        else:
            right_rows2.append(("Net Loss c/f to Capital A/c.", -net_result, None))

        for i in range(max(len(left_rows2), len(right_rows2))):
            l = left_rows2[i] if i < len(left_rows2) else ("", 0, None)
            r = right_rows2[i] if i < len(right_rows2) else ("", 0, None)
            _add_pl_row(
                self.table,
                l[0], fmt_money(l[1]) if l[0] else "",
                r[0], fmt_money(r[1]) if r[0] else "",
                left_account_id=l[2], right_account_id=r[2],
            )

        pl_total = sum(x[1] for x in left_rows2)
        _add_pl_row(
            self.table, "Total", fmt_money(pl_total), "Total", fmt_money(pl_total),
            bold=True
        )

        session.close()

    def open_ledger(self, item):
        account_id = item.data(Qt.ItemDataRole.UserRole)
        if account_id is not None and self.navigate_callback:
            self.navigate_callback(account_id)

    def export_to_excel(self):
        period = (
            f"Period: {self.from_edit.date().toString('dd-MM-yyyy')} to "
            f"{self.to_edit.date().toString('dd-MM-yyyy')}"
        )
        export_table_to_excel(
            self, self.table, "Trading and Profit and Loss", "trading_and_pl.xlsx",
            info_lines=[period]
        )


# --------------------------------------------------------------------------
# Balance Sheet Tab
# --------------------------------------------------------------------------

class BalanceSheetTab(QWidget):
    def __init__(self, navigate_callback=None):
        super().__init__()
        self.navigate_callback = navigate_callback
        layout = QVBoxLayout(self)

        title = QLabel("Balance Sheet")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)

        period_row = QHBoxLayout()
        self.as_of_edit = QDateEdit()
        self.as_of_edit.setCalendarPopup(True)
        self.as_of_edit.setDate(QDate.currentDate())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_bs)
        period_row.addWidget(QLabel("As at:"))
        period_row.addWidget(self.as_of_edit)
        period_row.addWidget(refresh_btn)
        period_row.addStretch()
        layout.addLayout(period_row)

        hint = QLabel("Double-click any account row to open its Ledger.")
        hint.setStyleSheet("color: #666; font-style: italic;")
        layout.addWidget(hint)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Liabilities", "Amount", "Assets", "Amount"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemDoubleClicked.connect(self.open_ledger)
        layout.addWidget(self.table)

        self.status_label = QLabel("")
        f = QFont()
        f.setBold(True)
        self.status_label.setFont(f)
        layout.addWidget(self.status_label)

        export_btn = QPushButton("Export to Excel")
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        self.load_bs()

    def load_bs(self):
        as_of = self.as_of_edit.date().toPyDate()
        fy_start = get_financial_year_start(as_of)
        prior_day = fy_start - timedelta(days=1)

        session = Session()

        capital_acc = session.query(Account).filter_by(name="Capital Account").first()
        drawings_acc = session.query(Account).filter_by(name="Drawings").first()
        cash_acc = session.query(Account).filter_by(name="Cash in Hand").first()
        bank_acc = session.query(Account).filter_by(name="Bank Account").first()

        _, _, closing_stock_value, _, _, net_result = compute_profit_loss(session, fy_start, as_of)

        self.table.setRowCount(0)

        # ============== LIABILITIES (left) / ASSETS (right) ==============

        # ---- Capital A/c rollforward ----
        left_rows = [("CAPITAL A/C.:", None, None, True)]
        if capital_acc is not None:
            opening_capital = account_balance(session, capital_acc, as_of=prior_day)
            d, c = account_period_totals(session, capital_acc, fy_start, as_of)
            capital_introduced = account_period_balance(capital_acc, d, c)
        else:
            opening_capital = 0.0
            capital_introduced = 0.0

        drawings_period = 0.0
        if drawings_acc is not None:
            d, c = account_period_totals(session, drawings_acc, fy_start, as_of)
            drawings_period = account_period_balance(drawings_acc, d, c)
            # Drawings is an equity account with a natural debit balance, so
            # account_period_balance returns it negative; flip to positive
            # for "Less: Drawings" display.
            drawings_period = -drawings_period

        left_rows.append(("As per Last Year's B/Sheet", opening_capital, None, False))
        if abs(capital_introduced) > 0.001:
            left_rows.append(("Add: Capital Introduced", capital_introduced, None, False))
        profit_label = "Add: Net Profit" if net_result >= 0 else "Less: Net Loss"
        left_rows.append((profit_label, net_result if net_result >= 0 else -net_result, None, False))

        subtotal = opening_capital + capital_introduced + net_result
        left_rows.append(("", subtotal, None, False))

        closing_capital = subtotal
        if abs(drawings_period) > 0.001:
            left_rows.append(("Less: Drawings", drawings_period, None, False))
            closing_capital = subtotal - drawings_period
            left_rows.append(("", closing_capital, None, False))

        left_rows.append(("", None, None, False))  # spacer

        # ---- Loan & Advance ----
        all_liabilities = session.query(Account).filter_by(type=AccountType.LIABILITY).all()
        loan_accounts = [a for a in all_liabilities if a.sub_category == "Loan & Advance"]
        if loan_accounts:
            left_rows.append(("Loan & Advance", None, None, True))
            for acc in loan_accounts:
                bal = account_balance(session, acc, as_of=as_of)
                left_rows.append((acc.name, bal, acc.id, False))
            left_rows.append(("", None, None, False))

        # ---- Current Liabilities (includes uncategorized liabilities) ----
        current_liab_accounts = [a for a in all_liabilities if a.sub_category != "Loan & Advance"]
        left_rows.append(("CURRENT LIABILITIES:", None, None, True))
        for acc in current_liab_accounts:
            bal = account_balance(session, acc, as_of=as_of)
            left_rows.append((acc.name, bal, acc.id, False))

        # ---- Fixed Assets ----
        right_rows = []
        all_assets = session.query(Account).filter_by(type=AccountType.ASSET).all()
        fixed_asset_accounts = [a for a in all_assets if a.sub_category == "Fixed Asset"]
        if fixed_asset_accounts:
            right_rows.append(("Fixed Assets:", None, None, True, False))
            for acc in fixed_asset_accounts:
                bal = account_balance(session, acc, as_of=as_of)
                right_rows.append((acc.name, bal, acc.id, False, False))
            right_rows.append(("", None, None, False, False))

        # ---- Current Assets (includes uncategorized assets, excl. Cash/Bank) ----
        right_rows.append(("Current Assets:", None, None, True, False))
        if closing_stock_value:
            right_rows.append(("Stock in Trade", closing_stock_value, None, False, False))
        current_asset_accounts = [a for a in all_assets if a.sub_category != "Fixed Asset"]
        for acc in current_asset_accounts:
            if cash_acc is not None and acc.id == cash_acc.id:
                continue
            if bank_acc is not None and acc.id == bank_acc.id:
                continue
            bal = account_balance(session, acc, as_of=as_of)
            right_rows.append((acc.name, bal, acc.id, False, False))

        # ---- Cash & Bank Balance (nested inside Current Assets, bold
        # sub-heading rather than its own grey section) ----
        if bank_acc is not None or cash_acc is not None:
            right_rows.append(("Cash & Bank Balance:", None, None, False, True))
            if bank_acc is not None:
                right_rows.append((bank_acc.name, account_balance(session, bank_acc, as_of=as_of), bank_acc.id, False, False))
            if cash_acc is not None:
                right_rows.append((cash_acc.name, account_balance(session, cash_acc, as_of=as_of), cash_acc.id, False, False))

        # ---- Render side by side ----
        for i in range(max(len(left_rows), len(right_rows))):
            l = left_rows[i] if i < len(left_rows) else ("", None, None, False)
            r = right_rows[i] if i < len(right_rows) else ("", None, None, False, False)
            l_bold = l[4] if len(l) > 4 else False
            r_bold = r[4] if len(r) > 4 else False
            _add_pl_row(
                self.table,
                l[0], fmt_money(l[1]) if l[1] is not None else "",
                r[0], fmt_money(r[1]) if r[1] is not None else "",
                left_account_id=l[2], right_account_id=r[2],
                left_header=l[3], right_header=r[3],
                left_bold=l_bold, right_bold=r_bold,
            )

        # Total liabilities = closing capital + loans + current liabilities
        total_liab = closing_capital
        for acc in loan_accounts:
            total_liab += account_balance(session, acc, as_of=as_of)
        for acc in current_liab_accounts:
            total_liab += account_balance(session, acc, as_of=as_of)

        total_assets = closing_stock_value
        for acc in fixed_asset_accounts:
            total_assets += account_balance(session, acc, as_of=as_of)
        for acc in current_asset_accounts:
            if cash_acc is not None and acc.id == cash_acc.id:
                continue
            if bank_acc is not None and acc.id == bank_acc.id:
                continue
            total_assets += account_balance(session, acc, as_of=as_of)
        if bank_acc is not None:
            total_assets += account_balance(session, bank_acc, as_of=as_of)
        if cash_acc is not None:
            total_assets += account_balance(session, cash_acc, as_of=as_of)

        _add_pl_row(
            self.table, "Total", fmt_money(total_liab), "Total", fmt_money(total_assets), bold=True
        )

        diff = total_assets - total_liab
        status = "BALANCED" if abs(diff) < 0.01 else f"OUT OF BALANCE by {fmt_money(abs(diff))}"
        self.status_label.setText(f"Status: {status}")
        self.status_label.setStyleSheet(
            "color: green;" if status == "BALANCED" else "color: red;"
        )

        session.close()

    def open_ledger(self, item):
        account_id = item.data(Qt.ItemDataRole.UserRole)
        if account_id is not None and self.navigate_callback:
            self.navigate_callback(account_id)

    def export_to_excel(self):
        export_table_to_excel(
            self, self.table, "Balance Sheet", "balance_sheet.xlsx",
            info_lines=[
                f"As at: {self.as_of_edit.date().toString('dd-MM-yyyy')}",
                self.status_label.text(),
            ]
        )


# --------------------------------------------------------------------------
# Enter-key navigation: pressing Enter/Return moves focus to the next field,
# Tally-style, instead of the default per-widget behavior. Login screens are
# left alone since they already submit on Enter.
# --------------------------------------------------------------------------

def _find_ancestor_voucher_tab(widget):
    w = widget
    while w is not None:
        if isinstance(w, VoucherEntryTab):
            return w
        w = w.parent()
    return None


class EnterMovesFocusFilter(QObject):
    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.KeyPress and event.key() in (
            Qt.Key.Key_Return, Qt.Key.Key_Enter
        ):
            if isinstance(obj, (QLineEdit, QComboBox, QDateEdit)):
                top = obj.window()
                if isinstance(top, (LoginDialog, ChangePasswordDialog)):
                    return False

                # VoucherEntryTab has its own explicit focus-chain logic,
                # since Qt's automatic focus chain doesn't reliably dive
                # into the debit/credit cell widgets inside its table.
                voucher_tab = _find_ancestor_voucher_tab(obj)
                if voucher_tab is not None:
                    voucher_tab.focus_next_from(obj)
                    return True

                obj.focusNextChild()
                return True
        return False


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def main():
    seed_default_accounts()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE_SHEET)

    enter_filter = EnterMovesFocusFilter()
    app.installEventFilter(enter_filter)

    setup_mode = not has_credential()
    login = LoginDialog(setup_mode=setup_mode)
    if login.exec() != QDialog.DialogCode.Accepted:
        sys.exit(0)

    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        _show_fatal_error(
            "Accounting App crashed while running.\n\n"
            "Full error details:\n\n" + traceback.format_exc()
        )

