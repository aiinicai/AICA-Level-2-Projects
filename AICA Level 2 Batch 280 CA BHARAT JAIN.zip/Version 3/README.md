# CA-GST Copilot  —  Version 3

### AI-Powered GST Litigation Assistant for Chartered Accountants

**Built by CA Bharat Jain  |  8107910067**

**What is new in Version 3**

| Addition | Detail |
| --- | --- |
| Two AI providers | Gemini and ChatGPT (OpenAI), chosen in Settings; every AI feature, including draft reply generation, follows the selection |
| CBIC legislation source | GST Acts, Rules, Notifications and Circulars downloaded straight from the CBIC Tax Information Portal into the knowledge base and indexed for citation |
| Provider status | Settings reports the SDK, key and model for each provider separately, and tests either one on demand |
| CBIC status | Settings reports whether the portal is reachable before a download is attempted |

A Python desktop application that helps a Chartered Accountant handle GST
litigation work: reading a notice, breaking it into issues, computing the demand
exposure, listing what to obtain from the client, researching the law against the
firm's own document library, and preparing a draft reply for professional review.

> **AI performs the repetitive groundwork.
> The Chartered Accountant retains professional judgment.**

> **AI output is only for professional assistance and requires independent
> verification and approval by a Chartered Accountant before reliance or
> submission.**

---

## 1. Project description

CA-GST Copilot is a self-contained Windows desktop application built with
Python, CustomTkinter and SQLite. It runs entirely on the local machine. It does
**not** connect to the GST portal, does not file anything, and does not depend on
any web platform.

The application demonstrates:

| Area | How it is demonstrated |
| --- | --- |
| Python programming | Modular package layout, type hints, docstrings, PEP 8 |
| Desktop development | CustomTkinter GUI with 11 screens, dialogs, background tasks |
| AI integration | Google Gemini (`google-genai`) and ChatGPT (`openai`), selectable at run time |
| External data source | CBIC Tax Information Portal client: authentication, JSON catalogue, PDF download |
| PDF processing | PyMuPDF page-wise extraction with scanned-PDF detection |
| Structured extraction | Strict JSON contract, normalised and validated in Python |
| SQLite database | 12 tables, foreign keys, transactions, cascade deletes |
| GST notice analysis | Issue-wise allegation breakdown with risk and confidence |
| AI-assisted research | Source-grounded answers with file and page citations |
| RAG / knowledge search | Pure-Python TF-IDF retrieval over page-anchored chunks |
| Draft generation | Issue-wise reply in professional GST litigation format |
| Workflow management | Case status, stages, deadlines, draft versions, approvals |
| Calculations | `decimal.Decimal` arithmetic; the AI never computes a total |
| Validation | Format checks on GSTIN, PAN, dates, financial year and amounts |
| Human-in-the-loop | Role-gated approval, disclaimers, no automatic finalisation |

---

## 2. Features

**Dashboard** — KPI cards (clients, open cases, replies due within 7 days, high
risk matters, total tax, interest, penalty and total exposure), upcoming
deadlines with overdue highlighting, recent cases, high-risk matters and three
matplotlib charts.

**Client master** — full CRUD with search, GSTIN and PAN format validation
(length, pattern, state code and checksum), state decoding from the GSTIN, and a
detail panel showing related cases and total exposure.

**GST case master** — every case is linked to a client and carries the notice
particulars, sections invoked, officer, jurisdiction, three-way assignment, risk
level, status, workflow stage and next action. Filter by client, status, risk,
notice type and financial year.

**Upload / Analyse Notice** — upload a searchable PDF, review the page-wise
extracted text, edit it if necessary, then run the structured AI analysis. Results
appear as a Case Overview, a Demand Summary (computed in Python) and an issue
table, with a separate Validation tab that reports every field as Valid, Review
Required, Invalid Format or Not Identified and lets you correct any value by hand.

**Issue analysis** — for each allegation the screen keeps three things visually
separate: *Facts from the Notice*, *AI Analysis* and *Professional Conclusion*.
The AI proposes factual checks, reconciliations, documents, legal questions and
possible taxpayer positions; it never states a conclusion.

**Client requirements** — generate a checklist tailored to the actual
allegation, add or edit items by hand, track Pending / Received / Not Applicable
/ Clarification Required with a completion percentage, and export to Excel, Word
or PDF with an editable covering note.

**Knowledge base** — a local repository under `knowledge_base/` with folders for
acts, rules, circulars, notifications, case laws and internal research. Documents
are indexed into page-anchored passages so a research answer can cite a real file
and page. A direct passage search is also provided.

**GST research (Ask GST Copilot)** — the question is used to retrieve relevant
passages from your own knowledge base; only the question and those passages are
sent to the AI, which is instructed not to cite anything else. If nothing
relevant is found the answer says so rather than inventing a citation.

**Draft reply** — an issue-wise draft in the standard GST litigation structure
(before the proper officer, taxpayer details, subject, reference, background,
preliminary submissions, facts, issue-wise submissions, legal provisions,
annexures, without-prejudice submissions, summary, prayer). Missing facts appear
as `[CLIENT TO CONFIRM]` and missing authority as `[LEGAL SOURCE TO BE VERIFIED]`.

**Draft editor and versioning** — save, save as a new version, export to Word or
PDF, copy, send for review, mark revision required, and (only with the right
role) mark CA Approved or Final. Every version is retained with its date,
preparer, reviewer and status.

**Reports** — client-wise cases, open cases, high-risk cases, upcoming
deadlines, case-wise demand exposure, status report, document requirement status
and the activity log; exportable individually or as one multi-sheet workbook.

**Settings** — AI configuration status (never the key itself), Demo Mode switch,
database and folder locations, preferences, demo data, user administration and
the built-in self tests.

---

**Legislation from CBIC** — *Knowledge Base > Import from CBIC* fetches the
catalogue of GST Acts, Rules, Notifications and Circulars published on the
[CBIC Tax Information Portal](https://www.cbic.gov.in/entities/gst), shows
exactly what will be downloaded and what is already held, and imports the
selected categories into the knowledge base folders. Imported PDFs are indexed
like any other document, so research answers cite the real file and page.
The import is idempotent — running it again picks up only what is new.

**Choice of AI provider** — *Settings > AI Configuration* selects Gemini or
ChatGPT. Notice analysis, issue analysis, client requirements, legal research
and draft reply generation all route through the same call, so switching the
provider switches every feature at once. Demo Mode continues to work with no
key for either provider.

---

## 3. Installation

Requires **Python 3.10 or later** (3.11+ recommended). Check with:

```bash
python --version
```

Install the dependencies from the project folder:

```bash
pip install -r requirements.txt
```

If several Python versions are installed, use the launcher:

```bash
py -3.11 -m pip install -r requirements.txt
```

Nothing else needs to be installed. `tkinter` and `sqlite3` ship with Python, and
the knowledge-base retrieval is pure Python, so no vector database, compiler or
build tools are required.

---

## 4. API configuration

The application starts in **Demo / Mock AI Mode** and works fully without any
API key.

Two providers are supported and either one drives every AI feature:

| Provider | SDK | Key | Default model |
| --- | --- | --- | --- |
| Gemini | `google-genai` | `GEMINI_API_KEY` | `gemini-3.6-flash` |
| ChatGPT (OpenAI) | `openai` | `OPENAI_API_KEY` | `gpt-4o-mini` |

To use a live API:

1. Obtain a key — Google AI Studio for Gemini, platform.openai.com for ChatGPT.
2. Copy `.env.example` to `.env` in the application folder.
3. Edit `.env` and fill in the key for the provider you intend to use. Both may
   be filled in, which lets you switch between them without editing the file
   again:

```text
GEMINI_API_KEY=your_api_key_here
GEMINI_MODEL=gemini-3.6-flash
GEMINI_TIMEOUT=120

OPENAI_API_KEY=your_openai_key_here
OPENAI_MODEL=gpt-4o-mini
OPENAI_TIMEOUT=120
```

4. Start the application and open **Settings > AI Configuration**.
5. Choose the provider in **AI Provider**. The card then reports the active
   provider, its model, and the SDK and key state of *both* providers.
6. Confirm that *API key configured* reads **Yes** and switch
   **Demo / Mock AI Mode** off.
7. Click **Test AI Connection** to send a one-line live request to the selected
   provider and confirm the key works.

The selection is saved in `data\settings.json`, so it survives a restart.

Keys are never hardcoded, never logged and never displayed — Settings shows only
a masked value such as `AIza************abcd`.

### Which features follow the provider

Every AI call in the application goes through a single routed entry point
(`services.ai_service.generate`), so notice analysis, issue analysis, client
requirements, legal research **and draft reply generation** all use whichever
provider is selected. There is no per-screen setting to keep in step.

---

## 4a. CBIC legislation source

GST legislation can be downloaded directly from the CBIC Tax Information Portal
(<https://www.cbic.gov.in/entities/gst>). No key, registration or licence is
required — the portal is a public source.

**To import:**

1. Open **Knowledge Base** and click **Import from CBIC**.
2. Tick the categories to fetch: Acts, Rules, Notifications,
   Circulars / Instructions. Acts and Rules are ticked by default.
3. Click **Fetch Catalogue**. The portal is contacted and the available
   documents are listed with their number, title and date of issue. Each row is
   marked *Will download*, *Already held* or *No file offered*, so nothing is a
   surprise.
4. Narrow the list if you wish, then click **Import Listed Documents**.

Each PDF is saved into the matching `knowledge_base\` folder (Acts to `acts\`,
Rules to `rules\`, Circulars, Instructions and Orders to `circulars\`,
Notifications to `notifications\`) and indexed into page-anchored passages, so a
research answer can cite the section and the page it came from.

**Behaviour worth knowing:**

* The import is **idempotent** — a document already on disk is skipped, so it is
  safe to run again after a new circular is issued.
* A failure in one category never stops the others; what failed is reported.
* TLS certificates are always verified. The portal serves an incomplete
  certificate chain, so the client uses the Windows certificate store through
  `truststore`. Verification is never disabled.
* **Settings > Legislation Source - CBIC > Check CBIC Connection** reports
  whether the portal is reachable before a long download is attempted, and
  *Index downloads automatically* controls whether imports are indexed on
  arrival.
* Nothing is ever uploaded to the portal, and no connection is made to the GST
  return filing system.

> The portal publishes the law as issued. Always confirm the version in force
> for the period under examination — amendments, retrospective effect and
> superseding circulars are matters of professional judgment, not of download.

---

## 5. Running the application

There are three ways to run it. The executable needs no Python installed at all.

### From the Windows executable (no Python needed)

Double-click **`dist\CA-GST-Copilot-v3.exe`**.

It is a single self-contained file, so it can be copied to a USB stick or to
another Windows PC and run there. On first launch it creates `data\`, `logs\`,
`uploads\`, `exports\`, `prompts\`, `sample_data\` and `knowledge_base\` in
whatever folder the `.exe` sits in — so keep it in a folder of its own rather
than loose on the Desktop.

To verify an installation without opening the application:

```bash
CA-GST-Copilot-v3.exe --check
```

That imports every screen, checks every service and export library, renders a
chart, runs the full self-test suite, and writes a report to
`logs\startup_check.txt`.

### From a command prompt

```bash
python main.py
```

### From IDLE

1. Open IDLE.
2. **File > Open**, then select `main.py` in this folder.
3. **Run > Run Module**, or press **F5**.

The login window appears first. If IDLE reports an import error, install the
dependencies as shown in section 3 and make sure IDLE is using the same Python
installation.

### Default login

| Username | Password |
| --- | --- |
| `admin` | `admin123` |

On the first sign-in you are invited to replace this temporary password. The
current password is carried over from the sign-in screen, so you only type the
new one. You can also choose **Skip for now** and go straight into the
application, and change it later from **Settings > Change My Password**.

### User roles

| Role | Access |
| --- | --- |
| Admin / Partner | All clients and cases; user administration; can approve drafts |
| Manager | Matters assigned to them |
| Team Member | Matters assigned to them |
| Reviewer | Matters assigned to them; can approve drafts |
| Viewer | Read-only |

Only **Admin / Partner** and **Reviewer** can mark a draft *CA Approved* or
*Final*. This is deliberate: professional responsibility for the reply rests with
the Chartered Accountant.

---

## 6. Demo Mode and the sample portfolio

The application ships with a complete demonstration portfolio so it can be
presented immediately, with no real client data and no internet connection.

### Turning Demo Mode on and off

**Settings > AI Configuration > Demo / Mock AI Mode.** It is **on by default**.

| Demo Mode | Behaviour |
| --- | --- |
| **ON** | No API call is ever made. Predefined sample output is returned for notice analysis, issue analysis, requirements, research and drafting. A banner reads *AICA DEMONSTRATION MODE - FICTIONAL SAMPLE DATA*, and the sample portfolio and guided demo are available. No API key or internet connection is needed. |
| **OFF** | Existing live behaviour is unchanged: AI actions call Gemini using the key in `.env`. If the API cannot be reached, the error dialog offers to switch to Demo Mode - it never switches on its own. |

### Loading the sample portfolio

**Settings > Demo Data / Sample Cases > Load Demo Data.** One click performs the
whole setup and reports **Demo Environment Ready**:

1. generates the eight sample notice PDFs into `sample_data/notices/`
2. creates 5 fictional clients
3. creates 12 GST matters with dates relative to today
4. loads the notice analysis and issue breakdown for every matter
5. loads the 21-item requirement checklist for the featured matter
6. loads the saved research answer for the featured matter
7. loads the sample draft reply for the featured matter
8. creates and indexes the four demonstration knowledge-base notes

It is **idempotent**: running it again fills in whatever is missing and never
creates duplicates.

### The sample clients

| Client | Business | State | Fictional GSTIN |
| --- | --- | --- | --- |
| ABC Manufacturing Private Limited | Manufacturing | Maharashtra | 27AABCM1234F1ZX |
| Zenith Trading LLP | Trading | Gujarat | 24AAFFZ5678L1ZF |
| Sunrise Warehousing Private Limited | Warehousing | Rajasthan | 08AADCS9012P1ZW |
| TechNova Solutions Private Limited | IT services | Karnataka | 29AAECT3456R1ZI |
| Greenfield Infra Projects LLP | Construction / works contract | Maharashtra | 27AAGFG7890Q1ZF |

Each GSTIN is checksum-correct, so it passes the application's own format
validation, and each is entirely fictional. No validation rule was weakened to
accommodate them. The application never claims a GSTIN exists on the GST portal.

### The sample matters

Twelve matters totalling **₹83,33,000** of exposure, spread across all ten
workflow statuses and three risk levels (5 High, 4 Medium, 3 Low):

| # | Notice | Client | Exposure | Risk | Status |
| --- | --- | --- | --- | --- | --- |
| 1 | ASMT-10 | ABC Manufacturing | ₹1,31,000 | Medium | Under Analysis |
| 2 | DRC-01A | Zenith Trading | ₹3,67,000 | High | Information Pending |
| 3 | **DRC-01 (featured)** | **Sunrise Warehousing** | **₹10,55,000** | **High** | **Drafting** |
| 4 | Summons | TechNova Solutions | Nil | Medium | New |
| 5 | Audit Notice | Greenfield Infra | ₹18,50,000 | High | Information Pending |
| 6 | DRC-07 | ABC Manufacturing | ₹21,40,000 | High | Under Review |
| 7 | Refund Notice | Zenith Trading | ₹4,25,000 | Low | CA Approved |
| 8 | Registration Notice | TechNova Solutions | Nil | Low | Revision Required |
| 9 | Appeal Order | Sunrise Warehousing | ₹15,20,000 | High | Hearing Pending |
| 10 | Other communication | Greenfield Infra | ₹2,10,000 | Medium | New |
| 11 | ASMT-10 | TechNova Solutions | ₹95,000 | Low | Filed |
| 12 | DRC-01A | Greenfield Infra | ₹5,40,000 | Medium | Closed |

Reply due dates are generated relative to the day you run the setup - one
overdue by 3 days, then 2, 5 and 6 days out - so the dashboard always looks
current. Every total is computed in Python from the components; none is
hardcoded.

### The featured demo case

**Sunrise Warehousing Private Limited - DRC-01 - FY 2024-25**, carrying three
allegations:

| Issue | Amount |
| --- | --- |
| Input tax credit availed in excess of GSTR-2B | ₹4,50,000 |
| Short payment under reverse charge | ₹2,00,000 |
| GSTR-1 versus GSTR-3B turnover difference | ₹2,00,000 |
| **Total tax** (CGST ₹4,25,000 + SGST ₹4,25,000) | **₹8,50,000** |
| Interest | ₹1,20,000 |
| Penalty | ₹85,000 |
| **Total exposure** (computed in Python) | **₹10,55,000** |

It is marked with a star in the **Demo** column on the GST Cases screen and
appears as a **Featured Demo Case** card on the dashboard.

### The sample notices

Eight PDFs are generated into `sample_data/notices/`:

```text
Sample_ASMT_10.pdf                 Sample_DRC_07_Order.pdf
Sample_DRC_01A_ITC_Mismatch.pdf    Sample_Refund_Notice.pdf
Sample_DRC_01_RCM_ITC.pdf          Sample_Registration_Notice.pdf
Sample_Summons.pdf                 Sample_Audit_Notice.pdf
```

Each carries a fictional department heading, taxpayer, GSTIN, notice number,
date, financial year, sections, issue narrative, figures, reply due date and a
`Proper Officer - Demo Data` signature block, with this footer on every page:

> **Sample Notice for AICA Demonstration Only - Not a Real GST Document**

They are deliberately styled as plain demonstration documents rather than
imitations of portal-generated notices. Open one from a case with the **View
Notice** button, or regenerate them from Settings.

### One source of truth

The notice PDF, the case record, the pre-loaded analysis and the mock AI
response for a demo matter all come from a single definition in
`services/demo_scenarios.py`. Clicking **Analyse Notice with AI** on the
featured case therefore reproduces exactly the figures printed on its notice -
the numbers can never drift apart mid-presentation.

### Resetting

| Action | What it does |
| --- | --- |
| **Reset Demo to Starting Position** | Rebuilds the demo records so statuses, requirements, research and draft versions return to their starting state. Use this to repeat the demonstration. |
| **Reset Demo Data** | Deletes every record flagged `is_demo = 1` - clients, cases, analyses, issues, requirements, research, drafts and the demo knowledge-base notes. **Real records are never touched.** Confirmation is required. |
| **Clear ALL Clients and Cases** | Deletes everything, demo and real alike. Also requires confirmation. |

### Guided demo

**Start Guided Demo** (on the demo banner, or in Settings) opens a small
always-on-top companion window with eleven steps. Each step navigates the main
window to the right screen and lists the points to make. It never blocks normal
use, and it can be closed at any time.

---

## 7. Five-minute demonstration flow

| Time | Step |
| --- | --- |
| 0:00 | Launch the `.exe`, sign in as `admin` / `admin123`, choose **Skip for now** |
| 0:20 | **Dashboard** - 5 clients, 12 matters, ₹83.33 L exposure, deadlines, charts |
| 0:50 | **Featured Demo Case** card - click **Open Case** |
| 1:10 | **GST Cases** - demand summary, deadline, Demo column; click **View Notice** |
| 1:40 | **Upload / Analyse Notice** - show the extracted text, click **Analyse Notice with AI** |
| 2:20 | Results: sections, three issues, ₹10,55,000 exposure; open the **Validation** tab |
| 2:50 | **Issue Analysis** - facts from notice vs AI analysis vs professional conclusion |
| 3:20 | **Client Requirements** - 21 items, collection progress, **Export Excel** |
| 3:50 | **GST Research** - ask the ITC mismatch question, open **Sources Used** |
| 4:20 | **Draft Reply** - issue-wise draft, `[CLIENT TO CONFIRM]` placeholders |
| 4:40 | **Send for Review**, then **CA Approved**; try it as a Team Member to show the refusal |
| 4:55 | Back to the **Dashboard** - the status change has flowed through |

Press **Start Guided Demo** to have these steps prompted on screen.

## 8. Knowledge base setup

For professional use, replace the demonstration documents with authentic
official publications.

The fastest way to do this is **Import from CBIC** (section 4a), which downloads
the Acts, Rules, Notifications and Circulars as published by the department and
indexes them in one step. Use the manual route below for judgments, the firm's
own opinions, and anything the portal does not carry.

1. Save searchable PDFs into the matching folder:

```text
knowledge_base/
    acts/                # bare Acts
    rules/               # rules as amended
    circulars/           # departmental circulars
    notifications/       # notifications
    case_laws/           # judgments and orders
    internal_research/   # the firm's own notes and opinions
```

2. Open **Knowledge Base** and click **Scan Folder** to register the new files,
   then **Refresh Index** to make their passages searchable. You can also use
   **+ Add PDF** to copy files in from anywhere and index them in one step.
3. Confirm that the *Indexed* column reads **Yes** and that the *Searchable
   Passages* count has increased.

**Only searchable (text-based) PDFs can be indexed.** A scanned document is
listed but marked as not indexed, because OCR is not available in this version.

### How retrieval works

Each PDF is read page by page, split into overlapping chunks of about 1,200
characters at paragraph or sentence boundaries, and stored in SQLite with its
file name, category and page number. A question is tokenised (with extra tokens
for statutory references such as `section16(2)(c)` and `rule36(4)`) and scored
against every chunk using TF-IDF with length normalisation, a coverage bonus, an
exact-phrase bonus and a statutory-reference bonus. Only the highest-scoring
chunks are sent to the model, which keeps token cost low and every citation
traceable.

---

## 9. Testing

Run the built-in self tests from **Settings > Run Self Tests**, or from a command
prompt:

```bash
python -m tests.self_tests
```

Nineteen suites run, and all of them must pass:

dialog visibility, GSTIN validation, PAN validation, Indian currency formatting,
demand calculation (a notice with all values, one with no interest, one with no
penalty, and one with multiple allegations), deadline arithmetic, date and
financial-year handling, the database, PDF extraction, malformed AI JSON,
AI error handling (missing key, unavailable API, timeout, auth, quota), the full
notice-analysis pipeline, knowledge-base retrieval, password hashing and role
permissions, exports, the prompt templates, the demonstration data module, and —
new in Version 3 —

* **AI provider layer** — both providers offered, placeholder keys rejected,
  keys masked and never shown in full, per-provider status, routing to the
  selected provider, OpenAI failure classification, Demo Mode independent of the
  provider, and a check that draft reply generation goes through the routed AI
  call rather than its own.
* **CBIC legislation source** — every portal category maps to a real knowledge
  base folder, filenames are Windows-safe and never a bare serial number, a
  document with no published file is not treated as downloadable, and a portal
  outage is reported to the user instead of raised. This suite never touches the
  network, so it passes offline.

If pytest is installed, the same checks plus focused unit tests run with:

```bash
pytest tests -q
```

---

## 10. Project structure

```text
CA-GST Copilot/
│
├── main.py                     Application entry point
├── config.py                   Paths, theme, dropdown values, settings
├── requirements.txt
├── README.md
├── .env.example                Template for the API key file
├── .gitignore
│
├── ui/
│   ├── main_window.py          Shell: top bar, sidebar, page registry
│   ├── base_page.py            Common page scaffolding
│   ├── widgets.py              Cards, KPI tiles, tables, dialogs, task runner
│   ├── login.py                Login and password change
│   ├── dashboard.py            KPIs, deadlines, charts
│   ├── clients.py              Client master
│   ├── cases.py                GST case master
│   ├── notice_analyzer.py      Upload, extract, analyse, validate
│   ├── issue_analysis.py       Issue-wise analysis
│   ├── requirements_generator.py  Document requirements
│   ├── research.py             Ask GST Copilot
│   ├── draft_reply.py          Draft generation, editing, versions
│   ├── knowledge_base.py       Knowledge repository, CBIC import dialog
│   ├── guided_demo.py          Step-by-step walkthrough window
│   ├── reports.py              Reports and exports
│   └── settings.py             Configuration, users, demo data, self tests
│
├── services/
│   ├── ai_service.py           Routed AI calls (Gemini / ChatGPT), Demo Mode,
│   │                           error handling
│   ├── cbic_service.py         CBIC portal client: catalogue, download, import
│   ├── pdf_service.py          PyMuPDF extraction, scanned-PDF detection
│   ├── gst_notice_service.py   Notice analysis pipeline and validation
│   ├── issue_service.py        Issue-level analysis
│   ├── requirement_service.py  Document checklist generation
│   ├── rag_service.py          Chunking, indexing and TF-IDF retrieval
│   ├── research_service.py     Source-grounded research
│   ├── reply_service.py        Draft generation, versions, approval rules
│   ├── export_service.py       Excel, Word and PDF export
│   ├── prompt_setup.py         Default prompt templates
│   ├── mock_data.py            Demo Mode sample output
│   ├── demo_data.py            Demo clients, cases and sample notice PDFs
│   ├── demo_scenarios.py       The fictional demonstration portfolio
│   └── demo_kb.py              Demonstration knowledge-base documents
│
├── database/
│   ├── schema.py               SQLite DDL
│   └── database.py             Data access layer
│
├── utils/
│   ├── validators.py           GSTIN, PAN, date, financial year, amounts
│   ├── calculations.py         Decimal demand engine, deadlines, aggregation
│   ├── formatters.py           Indian currency and date formatting
│   ├── helpers.py              Hashing, roles, JSON recovery, file helpers
│   └── logger.py               Rotating file logging
│
├── prompts/                    Editable AI prompt templates (.txt)
├── knowledge_base/             acts, rules, circulars, notifications,
│                               case_laws, internal_research
├── CA-GST-Copilot.spec         PyInstaller build specification
├── build_exe.bat               One-click rebuild of the executable
├── build_assets/               Application icon used by the build
├── dist/                       CA-GST-Copilot-v3.exe (the packaged application)
│
├── tests/                      self_tests.py and the pytest wrapper
├── data/                       SQLite database and settings.json (created)
├── uploads/                    Uploaded notice PDFs (created)
├── exports/                    Generated Excel, Word and PDF files (created)
├── logs/                       app.log (created)
└── sample_data/                Sample DRC-01 notice (created)
```

---

## 11. Design decisions worth noting

**Python does the arithmetic, not the AI.** The model extracts component figures
only. `utils/calculations.py` totals them with `decimal.Decimal`:

```python
total_tax      = cgst + sgst + igst + cess
total_exposure = total_tax + interest + penalty + other_amount
```

Where the sum of the issue-wise amounts does not agree with the total tax
demanded, the difference is *reported* to the user rather than silently
corrected.

**Nothing extracted is trusted as-is.** `normalise_analysis()` coerces every
field, drops malformed entries, defaults missing values to `""`, `[]` or `0`, and
never accepts a total from the model.

**Nothing is changed behind the user's back.** Validation results are shown with
a status and a remark; corrections are made by the user, and the totals are then
recomputed in Python.

**Citations are grounded or absent.** Research answers may cite only passages
retrieved from the local knowledge base. With no relevant source, the answer
states so explicitly.

**Prompts are editable.** They live in `prompts/*.txt`, so the instructions given
to the AI can be tuned without touching Python. Settings can restore the
defaults.

**Cost control.** AI calls happen only when explicitly requested; results are
stored in SQLite and reused; long notices are truncated before sending; research
sends only the top-scoring passages.

---

## 12. Known limitations

* **No OCR.** Scanned or image-only PDFs cannot be read. The application detects
  them and asks for a searchable PDF or for the text to be pasted in.
* **GSTIN checking is format only** — length, pattern, state code and checksum.
  There is no GST portal verification, because no portal API is integrated.
* **No GST portal connection and no filing.** The application never submits
  anything on the taxpayer's behalf.
* **Research is only as good as the knowledge base.** With an empty or thin
  knowledge base the answer will correctly decline to cite anything.
* **The demonstration knowledge base is not authoritative.** Its documents are
  labelled as demonstration extracts and must be replaced with official
  publications before professional use.
* **AI output can be wrong.** Facts, sections, rules, circulars, notifications,
  judgments, computations and conclusions must all be verified by the Chartered
  Accountant.
* **Role-based access is application level**, not database level; the SQLite file
  itself is not encrypted.
* **Single-user desktop application.** SQLite is not intended for concurrent
  multi-user access over a network share.
* **Charts require matplotlib.** If it cannot be loaded, the dashboard reports it
  and everything else keeps working.
* Reverse-charge, reconciliation and hearing-calendar features listed as optional
  extensions in the specification are not implemented in this version.
* **The CBIC import needs internet access** and depends on the portal being up.
  When it is unreachable the application says so and continues to work with the
  documents already held; nothing already downloaded is affected.
* **CBIC supplies the law as published, not as in force on a given date.** The
  portal does not carry a consolidated, date-stamped statute, so the version in
  force for the period under examination remains a matter of professional
  judgment.
* **Only one AI provider is active at a time.** There is no automatic failover
  between Gemini and ChatGPT; if a call fails the reason is reported and the
  provider can be changed in Settings.

---

## 13. The Windows executable

The packaged build is **`dist\CA-GST-Copilot-v3.exe`** — one self-contained file
that runs on Windows 10/11 (64-bit) with **no Python and no `pip install`
required**. Python, Tk, CustomTkinter, PyMuPDF, matplotlib, ReportLab,
python-docx, openpyxl, both AI SDKs and the CBIC client are all inside it.

Build it with `build_exe.bat` (see *Rebuilding it* below); the source in this
folder is the authoritative deliverable and runs directly with
`python main.py`.

### Using it

1. Put the `.exe` in a folder of its own (for example `C:\CA-GST-Copilot\`).
   Copy it **out of `dist\`** first: `dist\` is the build output folder, and
   rebuilding replaces what is in it.
2. Double-click it. The login window opens in a few seconds.
3. Sign in with `admin` / `admin123`. Set a new password, or choose
   **Skip for now** to go straight in.
4. Open **Settings > Load Demo Data** to populate the demonstration matters.

On first run it creates these folders beside the `.exe`:

```text
data\            the SQLite database and settings.json
logs\            app.log
prompts\         the editable AI prompt templates
knowledge_base\  acts, rules, circulars, notifications, case_laws, internal_research
uploads\         notice PDFs you upload
exports\         generated Excel, Word and PDF files
sample_data\     the generated sample DRC-01 notice
```

Your data therefore lives outside the executable and survives replacing the
`.exe` with a newer build.

### Live AI from the executable

Place your `.env` file (see section 4) in the **same folder as the `.exe`**, then
choose the provider in **Settings > AI Configuration** and switch Demo Mode off.
Without a `.env` the application still runs fully in Demo / Mock AI Mode.

**Import from CBIC** works from the executable exactly as it does from source:
it needs internet access but no key and no `.env`.

### Verifying an installation

```bash
CA-GST-Copilot-v3.exe --check
```

This imports all 11 screens, checks every service and export library (including
the CBIC client), renders a CustomTkinter widget set and a matplotlib chart,
reports the SDK and key state of both AI providers, runs the 19 self tests, shows
a summary dialog and writes `logs\startup_check.txt`. Add `--no-dialog` to run it
from a script:

```bash
CA-GST-Copilot-v3.exe --check --no-dialog
```

### Rebuilding it

```bash
build_exe.bat
```

or, equivalently:

```bash
pip install pyinstaller
```

```bash
python -m PyInstaller --noconfirm --clean CA-GST-Copilot.spec
```

The build takes two to five minutes and produces `dist\CA-GST-Copilot-v3.exe`.
The spec file lists each screen in `hiddenimports` because the screens are loaded
dynamically by name through `importlib`, which PyInstaller's static analysis
cannot follow. It also collects both AI SDKs, `requests`, `certifi` and
`truststore`, so the CBIC download verifies TLS correctly from the packaged
build.

If you have been running the application from inside `dist\`, your database is
at `dist\data\ca_gst_copilot.db`. `build_exe.bat` deletes only the `.exe` and
leaves that data in place, but the safest habit is to keep your working copy of
the `.exe` in its own folder outside `dist\`.

### Notes on the executable

* **First launch may be slower** than later ones (roughly 3–10 seconds) while
  Windows scans the file and the bundle is unpacked to a temporary folder.
* **SmartScreen may warn** that the publisher is unknown, because the file is not
  code-signed. Choose *More info > Run anyway*. Some antivirus products also
  treat unsigned PyInstaller executables with suspicion; this is a known
  false-positive pattern, not a property of this application.
* **It is 64-bit Windows only.** To run on macOS or Linux, use the source
  (`python main.py`); the code itself is cross-platform.
* Building on a machine that already has the dependencies installed is the
  supported path; the spec deliberately excludes PyQt, pandas, SciPy and Jupyter
  to keep the file size down.

---

## 14. Troubleshooting

| Problem | What to do |
| --- | --- |
| `ModuleNotFoundError: customtkinter` | Run `pip install -r requirements.txt` with the same Python that runs the app |
| Window does not appear from IDLE | Run `python main.py` from a command prompt to see the error text |
| "No API key is configured for the selected AI provider" | Create `.env` as in section 4 for the provider chosen in Settings, or switch Demo Mode on |
| The wrong AI is being used | **Settings > AI Configuration > AI Provider**; the card shows the active provider and the state of both |
| "The AI provider rejected the configured key" | Check the key for the *selected* provider - the two use different variables |
| "This appears to be a scanned/image-based PDF" | Supply a searchable PDF, or paste the notice text into the box |
| "No sufficiently relevant source was located" | Add relevant PDFs under Knowledge Base and click Refresh Index |
| Export fails with a permission error | Close the previously exported file in Excel or Word and try again |
| Something behaved unexpectedly | Open **Settings > View Log File**, or read `logs/app.log` |
| SmartScreen blocks the .exe | Choose *More info > Run anyway*; the file is unsigned, not unsafe |
| The .exe seems to do nothing on first click | Give it up to 10 seconds on first launch; check `logspp.log` |
| Want to confirm the .exe is intact | Run `CA-GST-Copilot-v3.exe --check` and read `logs\startup_check.txt` |
| "Could not reach CBIC" | Check internet access, then **Settings > Check CBIC Connection**; the knowledge base keeps working with what it already holds |
| CBIC import says everything is "Already held" | That is correct - the import is idempotent and downloads only what is new |
| A CBIC PDF downloaded but is not searchable | It is a scanned publication; it is listed but not indexed, because OCR is not available |

---

## 15. Disclaimer

This application is designed to assist Chartered Accountants and tax
professionals. AI-generated analysis, research and drafting may contain errors or
omissions. Users must independently verify all factual, statutory and judicial
references before professional use or filing.

The application does not connect to the GST portal and does not file anything on
behalf of the taxpayer. All outputs require independent professional review and
approval by a Chartered Accountant before reliance or submission.

**CA-GST Copilot | AI-Assisted Professional Tool | Verify before reliance**

**Built by CA Bharat Jain  |  8107910067**
