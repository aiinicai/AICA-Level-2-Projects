"""
database.schema
===============
SQLite DDL for CA-GST Copilot.

The statements are idempotent (``CREATE TABLE IF NOT EXISTS``) so the
schema can safely be applied on every application start.
"""

from __future__ import annotations

SCHEMA_VERSION = 2

TABLES = [
    # ------------------------------------------------------------------ users
    """
    CREATE TABLE IF NOT EXISTS users (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT    NOT NULL,
        username        TEXT    NOT NULL UNIQUE,
        password_hash   TEXT    NOT NULL,
        role            TEXT    NOT NULL DEFAULT 'Team Member',
        email           TEXT    DEFAULT '',
        active          INTEGER NOT NULL DEFAULT 1,
        must_change_pw  INTEGER NOT NULL DEFAULT 0,
        last_login      TEXT    DEFAULT '',
        created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
    )
    """,
    # ---------------------------------------------------------------- clients
    """
    CREATE TABLE IF NOT EXISTS clients (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        client_code     TEXT    DEFAULT '',
        client_name     TEXT    NOT NULL,
        gstin           TEXT    DEFAULT '',
        pan             TEXT    DEFAULT '',
        state           TEXT    DEFAULT '',
        entity_type     TEXT    DEFAULT '',
        industry        TEXT    DEFAULT '',
        contact_person  TEXT    DEFAULT '',
        email           TEXT    DEFAULT '',
        mobile          TEXT    DEFAULT '',
        partner         TEXT    DEFAULT '',
        manager         TEXT    DEFAULT '',
        notes           TEXT    DEFAULT '',
        active          INTEGER NOT NULL DEFAULT 1,
        is_demo         INTEGER NOT NULL DEFAULT 0,
        created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
    )
    """,
    # ------------------------------------------------------------------ cases
    """
    CREATE TABLE IF NOT EXISTS cases (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        case_code            TEXT    DEFAULT '',
        client_id            INTEGER NOT NULL,
        notice_type          TEXT    DEFAULT '',
        notice_number        TEXT    DEFAULT '',
        financial_year       TEXT    DEFAULT '',
        tax_period           TEXT    DEFAULT '',
        notice_date          TEXT    DEFAULT '',
        due_date             TEXT    DEFAULT '',
        sections             TEXT    DEFAULT '',
        officer              TEXT    DEFAULT '',
        jurisdiction         TEXT    DEFAULT '',
        assigned_partner     TEXT    DEFAULT '',
        assigned_manager     TEXT    DEFAULT '',
        assigned_team_member TEXT    DEFAULT '',
        risk_level           TEXT    DEFAULT 'Review Required',
        status               TEXT    DEFAULT 'New',
        stage                TEXT    DEFAULT 'Notice Received',
        next_action          TEXT    DEFAULT '',
        next_action_date     TEXT    DEFAULT '',
        notes                TEXT    DEFAULT '',
        uploaded_file        TEXT    DEFAULT '',
        extracted_text       TEXT    DEFAULT '',
        is_demo              INTEGER NOT NULL DEFAULT 0,
        demo_tag             TEXT    DEFAULT '',
        created_at           TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at           TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (client_id) REFERENCES clients (id) ON DELETE CASCADE
    )
    """,
    # -------------------------------------------------------- notice_analysis
    """
    CREATE TABLE IF NOT EXISTS notice_analysis (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id        INTEGER NOT NULL,
        taxpayer_name  TEXT    DEFAULT '',
        gstin          TEXT    DEFAULT '',
        notice_type    TEXT    DEFAULT '',
        notice_number  TEXT    DEFAULT '',
        financial_year TEXT    DEFAULT '',
        tax_period     TEXT    DEFAULT '',
        notice_date    TEXT    DEFAULT '',
        reply_due_date TEXT    DEFAULT '',
        sections       TEXT    DEFAULT '',
        rules          TEXT    DEFAULT '',
        officer_name   TEXT    DEFAULT '',
        designation    TEXT    DEFAULT '',
        jurisdiction   TEXT    DEFAULT '',
        summary        TEXT    DEFAULT '',
        cgst           REAL    DEFAULT 0,
        sgst           REAL    DEFAULT 0,
        igst           REAL    DEFAULT 0,
        cess           REAL    DEFAULT 0,
        interest       REAL    DEFAULT 0,
        penalty        REAL    DEFAULT 0,
        other_amount   REAL    DEFAULT 0,
        total_tax      REAL    DEFAULT 0,
        total_exposure REAL    DEFAULT 0,
        source         TEXT    DEFAULT '',
        ai_raw_json    TEXT    DEFAULT '',
        created_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (case_id) REFERENCES cases (id) ON DELETE CASCADE
    )
    """,
    # ----------------------------------------------------------------- issues
    """
    CREATE TABLE IF NOT EXISTS issues (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id          INTEGER NOT NULL,
        issue_no         INTEGER DEFAULT 1,
        title            TEXT    DEFAULT '',
        allegation       TEXT    DEFAULT '',
        amount           REAL    DEFAULT 0,
        sections         TEXT    DEFAULT '',
        facts_identified TEXT    DEFAULT '',
        facts_missing    TEXT    DEFAULT '',
        risk             TEXT    DEFAULT 'Review Required',
        risk_reason      TEXT    DEFAULT '',
        confidence       TEXT    DEFAULT '',
        ai_analysis      TEXT    DEFAULT '',
        ca_remarks       TEXT    DEFAULT '',
        created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (case_id) REFERENCES cases (id) ON DELETE CASCADE
    )
    """,
    # ----------------------------------------------------------- requirements
    """
    CREATE TABLE IF NOT EXISTS requirements (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id          INTEGER NOT NULL,
        issue_id         INTEGER DEFAULT NULL,
        document_name    TEXT    NOT NULL,
        purpose          TEXT    DEFAULT '',
        requirement_type TEXT    DEFAULT 'Mandatory',
        status           TEXT    DEFAULT 'Pending',
        received_date    TEXT    DEFAULT '',
        remarks          TEXT    DEFAULT '',
        created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (case_id) REFERENCES cases (id) ON DELETE CASCADE,
        FOREIGN KEY (issue_id) REFERENCES issues (id) ON DELETE SET NULL
    )
    """,
    # --------------------------------------------------------------- research
    """
    CREATE TABLE IF NOT EXISTS research (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id    INTEGER DEFAULT NULL,
        issue_id   INTEGER DEFAULT NULL,
        question   TEXT    NOT NULL,
        answer     TEXT    DEFAULT '',
        sources    TEXT    DEFAULT '',
        raw_json   TEXT    DEFAULT '',
        source_mode TEXT   DEFAULT '',
        created_by TEXT    DEFAULT '',
        created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (case_id) REFERENCES cases (id) ON DELETE CASCADE
    )
    """,
    # ----------------------------------------------------------------- drafts
    """
    CREATE TABLE IF NOT EXISTS drafts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id     INTEGER NOT NULL,
        version     INTEGER NOT NULL DEFAULT 1,
        title       TEXT    DEFAULT '',
        draft_text  TEXT    DEFAULT '',
        status      TEXT    DEFAULT 'AI Generated',
        prepared_by TEXT    DEFAULT '',
        reviewed_by TEXT    DEFAULT '',
        remarks     TEXT    DEFAULT '',
        created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (case_id) REFERENCES cases (id) ON DELETE CASCADE
    )
    """,
    # ---------------------------------------------------- knowledge_documents
    """
    CREATE TABLE IF NOT EXISTS knowledge_documents (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        file_name   TEXT    NOT NULL,
        file_path   TEXT    NOT NULL,
        category    TEXT    DEFAULT 'internal_research',
        title       TEXT    DEFAULT '',
        date_added  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
        indexed     INTEGER NOT NULL DEFAULT 0,
        pages       INTEGER DEFAULT 0,
        chunk_count INTEGER DEFAULT 0,
        notes       TEXT    DEFAULT '',
        is_demo     INTEGER NOT NULL DEFAULT 0,
        UNIQUE (file_path)
    )
    """,
    # -------------------------------------------------------- knowledge_chunks
    """
    CREATE TABLE IF NOT EXISTS knowledge_chunks (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        file_name   TEXT    DEFAULT '',
        category    TEXT    DEFAULT '',
        page        INTEGER DEFAULT 0,
        chunk_index INTEGER DEFAULT 0,
        chunk_text  TEXT    NOT NULL,
        FOREIGN KEY (document_id) REFERENCES knowledge_documents (id) ON DELETE CASCADE
    )
    """,
    # ------------------------------------------------------------ activity_log
    """
    CREATE TABLE IF NOT EXISTS activity_log (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id    INTEGER DEFAULT NULL,
        user_name  TEXT    DEFAULT '',
        action     TEXT    DEFAULT '',
        detail     TEXT    DEFAULT '',
        created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
    )
    """,
    # ---------------------------------------------------------------- app_meta
    """
    CREATE TABLE IF NOT EXISTS app_meta (
        key   TEXT PRIMARY KEY,
        value TEXT DEFAULT ''
    )
    """,
]

# Columns added after the first release. Applied with ALTER TABLE on
# databases created by an earlier version; ignored when already present.
MIGRATIONS = [
    ("clients", "is_demo", "INTEGER NOT NULL DEFAULT 0"),
    ("cases", "is_demo", "INTEGER NOT NULL DEFAULT 0"),
    ("cases", "demo_tag", "TEXT DEFAULT ''"),
    ("knowledge_documents", "is_demo", "INTEGER NOT NULL DEFAULT 0"),
]

INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_cases_client   ON cases (client_id)",
    "CREATE INDEX IF NOT EXISTS idx_cases_status   ON cases (status)",
    "CREATE INDEX IF NOT EXISTS idx_cases_due      ON cases (due_date)",
    "CREATE INDEX IF NOT EXISTS idx_issues_case    ON issues (case_id)",
    "CREATE INDEX IF NOT EXISTS idx_req_case       ON requirements (case_id)",
    "CREATE INDEX IF NOT EXISTS idx_drafts_case    ON drafts (case_id)",
    "CREATE INDEX IF NOT EXISTS idx_research_case  ON research (case_id)",
    "CREATE INDEX IF NOT EXISTS idx_analysis_case  ON notice_analysis (case_id)",
    "CREATE INDEX IF NOT EXISTS idx_chunks_doc     ON knowledge_chunks (document_id)",
    "CREATE INDEX IF NOT EXISTS idx_clients_demo   ON clients (is_demo)",
    "CREATE INDEX IF NOT EXISTS idx_cases_demo     ON cases (is_demo)",
]
