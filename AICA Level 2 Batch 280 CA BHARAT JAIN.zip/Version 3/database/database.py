"""
database.database
=================
SQLite data-access layer.

Every public function opens a short-lived connection through the
:func:`get_connection` context manager, which commits on success and
rolls back on error, so no connection or transaction is ever left open.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import date, datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence

import config
from database.schema import INDEXES, MIGRATIONS, SCHEMA_VERSION, TABLES
from utils.helpers import hash_password
from utils.logger import get_logger

log = get_logger(__name__)


class DatabaseError(Exception):
    """Raised when a database operation cannot be completed."""


# ---------------------------------------------------------------------------
# Connection handling
# ---------------------------------------------------------------------------
@contextmanager
def get_connection(readonly: bool = False):
    """
    Yield a configured SQLite connection.

    Commits on clean exit, rolls back on exception, always closes.
    """
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn: Optional[sqlite3.Connection] = None
    try:
        conn = sqlite3.connect(str(config.DB_PATH), timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        yield conn
        if not readonly:
            conn.commit()
    except sqlite3.Error as exc:
        if conn is not None:
            conn.rollback()
        log.exception("Database error: %s", exc)
        raise DatabaseError(str(exc)) from exc
    finally:
        if conn is not None:
            conn.close()


def _rows(cursor) -> List[Dict[str, Any]]:
    return [dict(row) for row in cursor.fetchall()]


def _row(cursor) -> Optional[Dict[str, Any]]:
    row = cursor.fetchone()
    return dict(row) if row else None


def query(sql: str, params: Sequence = ()) -> List[Dict[str, Any]]:
    """Run a SELECT and return a list of dictionaries."""
    with get_connection(readonly=True) as conn:
        return _rows(conn.execute(sql, tuple(params)))


def query_one(sql: str, params: Sequence = ()) -> Optional[Dict[str, Any]]:
    """Run a SELECT and return the first row, or ``None``."""
    with get_connection(readonly=True) as conn:
        return _row(conn.execute(sql, tuple(params)))


def execute(sql: str, params: Sequence = ()) -> int:
    """Run an INSERT/UPDATE/DELETE and return lastrowid (or rowcount)."""
    with get_connection() as conn:
        cursor = conn.execute(sql, tuple(params))
        return cursor.lastrowid or cursor.rowcount


def _insert(table: str, data: Dict[str, Any]) -> int:
    columns = list(data.keys())
    placeholders = ", ".join("?" for _ in columns)
    sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
    return execute(sql, [data[c] for c in columns])


def _update(table: str, record_id: int, data: Dict[str, Any]) -> int:
    if not data:
        return 0
    assignments = ", ".join(f"{c} = ?" for c in data)
    sql = f"UPDATE {table} SET {assignments} WHERE id = ?"
    return execute(sql, list(data.values()) + [record_id])


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------
def initialise_database() -> None:
    """Create tables, indexes and the default administrator account."""
    config.ensure_directories()
    with get_connection() as conn:
        for statement in TABLES:
            conn.execute(statement)
        _apply_migrations(conn)
        for statement in INDEXES:
            conn.execute(statement)
        conn.execute(
            "INSERT OR IGNORE INTO app_meta (key, value) VALUES (?, ?)",
            ("schema_version", str(SCHEMA_VERSION)),
        )
    _create_default_admin()
    log.info("Database initialised at %s", config.DB_PATH)


def _apply_migrations(conn) -> None:
    """
    Add columns introduced after the first release.

    SQLite has no "ADD COLUMN IF NOT EXISTS", so the existing columns are
    read first. This keeps databases created by an earlier version usable
    without losing any data.
    """
    for table, column, definition in MIGRATIONS:
        try:
            existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        except sqlite3.Error:
            continue
        if not existing or column in existing:
            continue
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
            log.info("Schema migration: added %s.%s", table, column)
        except sqlite3.Error as exc:
            log.warning("Could not add %s.%s: %s", table, column, exc)


def _create_default_admin() -> None:
    """Seed the first-run administrator (admin / admin123)."""
    existing = query_one("SELECT id FROM users WHERE username = ?", ("admin",))
    if existing:
        return
    _insert(
        "users",
        {
            "name": "Administrator",
            "username": "admin",
            "password_hash": hash_password("admin123"),
            "role": "Admin / Partner",
            "email": "",
            "active": 1,
            "must_change_pw": 1,
            "created_at": _now(),
        },
    )
    log.info("Default administrator account created (admin / admin123)")


def database_status() -> Dict[str, Any]:
    """Summary used by the Settings screen."""
    try:
        counts = {}
        for table in ("users", "clients", "cases", "issues", "drafts",
                      "knowledge_documents", "knowledge_chunks"):
            row = query_one(f"SELECT COUNT(*) AS n FROM {table}")
            counts[table] = row["n"] if row else 0
        size = config.DB_PATH.stat().st_size if config.DB_PATH.exists() else 0
        return {"connected": True, "path": str(config.DB_PATH), "size": size, "counts": counts}
    except (DatabaseError, OSError) as exc:
        return {"connected": False, "path": str(config.DB_PATH), "error": str(exc), "counts": {}}


# ===========================================================================
# USERS
# ===========================================================================
def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM users WHERE username = ? COLLATE NOCASE", (username,))


def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM users WHERE id = ?", (user_id,))


def list_users(active_only: bool = False) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM users"
    if active_only:
        sql += " WHERE active = 1"
    return query(sql + " ORDER BY name COLLATE NOCASE")


def create_user(name: str, username: str, password: str, role: str,
                email: str = "", must_change_pw: int = 1) -> int:
    return _insert(
        "users",
        {
            "name": name.strip(),
            "username": username.strip().lower(),
            "password_hash": hash_password(password),
            "role": role,
            "email": email.strip(),
            "active": 1,
            "must_change_pw": must_change_pw,
            "created_at": _now(),
        },
    )


def update_user(user_id: int, data: Dict[str, Any]) -> int:
    allowed = {"name", "role", "email", "active", "must_change_pw", "last_login"}
    return _update("users", user_id, {k: v for k, v in data.items() if k in allowed})


def set_user_password(user_id: int, password: str) -> int:
    return execute(
        "UPDATE users SET password_hash = ?, must_change_pw = 0 WHERE id = ?",
        (hash_password(password), user_id),
    )


def delete_user(user_id: int) -> int:
    return execute("DELETE FROM users WHERE id = ?", (user_id,))


def record_login(user_id: int) -> None:
    execute("UPDATE users SET last_login = ? WHERE id = ?", (_now(), user_id))


def team_member_names() -> List[str]:
    """Names available in the assignment dropdowns."""
    return [u["name"] for u in list_users(active_only=True)]


# ===========================================================================
# CLIENTS
# ===========================================================================
CLIENT_FIELDS = (
    "client_code", "client_name", "gstin", "pan", "state", "entity_type",
    "industry", "contact_person", "email", "mobile", "partner", "manager",
    "notes", "active", "is_demo",
)


def next_client_code() -> str:
    row = query_one("SELECT COUNT(*) AS n FROM clients")
    return f"CL-{(row['n'] if row else 0) + 1:04d}"


def create_client(data: Dict[str, Any]) -> int:
    payload = {k: data.get(k, "") for k in CLIENT_FIELDS}
    payload["client_code"] = payload.get("client_code") or next_client_code()
    payload["active"] = int(data.get("active", 1))
    payload["is_demo"] = int(data.get("is_demo", 0))
    payload["gstin"] = (payload.get("gstin") or "").strip().upper()
    payload["pan"] = (payload.get("pan") or "").strip().upper()
    payload["created_at"] = _now()
    payload["updated_at"] = _now()
    return _insert("clients", payload)


def update_client(client_id: int, data: Dict[str, Any]) -> int:
    payload = {k: v for k, v in data.items() if k in CLIENT_FIELDS}
    if "gstin" in payload:
        payload["gstin"] = (payload["gstin"] or "").strip().upper()
    if "pan" in payload:
        payload["pan"] = (payload["pan"] or "").strip().upper()
    payload["updated_at"] = _now()
    return _update("clients", client_id, payload)


def delete_client(client_id: int) -> int:
    """Delete a client and (via ON DELETE CASCADE) all of its cases."""
    return execute("DELETE FROM clients WHERE id = ?", (client_id,))


def get_client(client_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM clients WHERE id = ?", (client_id,))


def list_clients(search: str = "", active_only: bool = False) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM clients WHERE 1 = 1"
    params: List[Any] = []
    if active_only:
        sql += " AND active = 1"
    if search:
        like = f"%{search.strip()}%"
        sql += (" AND (client_name LIKE ? OR gstin LIKE ? OR pan LIKE ?"
                " OR client_code LIKE ? OR contact_person LIKE ? OR state LIKE ?)")
        params += [like] * 6
    return query(sql + " ORDER BY client_name COLLATE NOCASE", params)


def client_name_map() -> Dict[int, str]:
    return {c["id"]: c["client_name"] for c in list_clients()}


# ===========================================================================
# CASES
# ===========================================================================
CASE_FIELDS = (
    "case_code", "client_id", "notice_type", "notice_number", "financial_year",
    "tax_period", "notice_date", "due_date", "sections", "officer", "jurisdiction",
    "assigned_partner", "assigned_manager", "assigned_team_member", "risk_level",
    "status", "stage", "next_action", "next_action_date", "notes",
    "uploaded_file", "extracted_text", "is_demo", "demo_tag",
)

CASE_SELECT = """
    SELECT c.*,
           cl.client_name, cl.gstin AS client_gstin, cl.pan AS client_pan,
           cl.state AS client_state,
           a.cgst, a.sgst, a.igst, a.cess, a.interest, a.penalty,
           a.other_amount, a.total_tax, a.total_exposure, a.summary,
           (SELECT COUNT(*) FROM issues i WHERE i.case_id = c.id) AS issue_count
      FROM cases c
      LEFT JOIN clients cl ON cl.id = c.client_id
      LEFT JOIN notice_analysis a
             ON a.id = (SELECT MAX(id) FROM notice_analysis n WHERE n.case_id = c.id)
"""


def next_case_code() -> str:
    row = query_one("SELECT COUNT(*) AS n FROM cases")
    return f"GST-{date.today().year}-{(row['n'] if row else 0) + 1:04d}"


def create_case(data: Dict[str, Any]) -> int:
    payload = {k: data.get(k, "") for k in CASE_FIELDS}
    payload["case_code"] = payload.get("case_code") or next_case_code()
    payload["client_id"] = int(data.get("client_id") or 0)
    payload["risk_level"] = data.get("risk_level") or "Review Required"
    payload["status"] = data.get("status") or "New"
    payload["stage"] = data.get("stage") or "Notice Received"
    payload["is_demo"] = int(data.get("is_demo", 0))
    payload["created_at"] = _now()
    payload["updated_at"] = _now()
    return _insert("cases", payload)


def update_case(case_id: int, data: Dict[str, Any]) -> int:
    payload = {k: v for k, v in data.items() if k in CASE_FIELDS}
    payload["updated_at"] = _now()
    return _update("cases", case_id, payload)


def delete_case(case_id: int) -> int:
    return execute("DELETE FROM cases WHERE id = ?", (case_id,))


def get_case(case_id: int) -> Optional[Dict[str, Any]]:
    return query_one(CASE_SELECT + " WHERE c.id = ?", (case_id,))


def list_cases(filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """
    List cases with optional filters.

    Supported keys: ``search``, ``client_id``, ``status``, ``risk_level``,
    ``notice_type``, ``financial_year``, ``open_only``, ``assigned_to``.
    """
    filters = filters or {}
    sql = CASE_SELECT + " WHERE 1 = 1"
    params: List[Any] = []

    if filters.get("client_id"):
        sql += " AND c.client_id = ?"
        params.append(int(filters["client_id"]))
    for key, column in (("status", "c.status"), ("risk_level", "c.risk_level"),
                        ("notice_type", "c.notice_type"),
                        ("financial_year", "c.financial_year")):
        value = filters.get(key)
        if value and value != "All":
            sql += f" AND {column} = ?"
            params.append(value)
    if filters.get("open_only"):
        sql += " AND c.status != 'Closed'"
    if filters.get("assigned_to"):
        sql += (" AND (c.assigned_partner = ? OR c.assigned_manager = ?"
                " OR c.assigned_team_member = ?)")
        params += [filters["assigned_to"]] * 3
    if filters.get("search"):
        like = f"%{str(filters['search']).strip()}%"
        sql += (" AND (cl.client_name LIKE ? OR cl.gstin LIKE ? OR c.case_code LIKE ?"
                " OR c.notice_number LIKE ? OR c.notice_type LIKE ?"
                " OR c.sections LIKE ? OR c.financial_year LIKE ?)")
        params += [like] * 7

    sql += " ORDER BY (c.due_date = '') ASC, c.due_date ASC, c.id DESC"
    return query(sql, params)


def cases_for_client(client_id: int) -> List[Dict[str, Any]]:
    return list_cases({"client_id": client_id})


def upcoming_deadlines(days: int = 7, include_overdue: bool = True) -> List[Dict[str, Any]]:
    """Open cases whose reply due date falls within ``days`` (plus overdue)."""
    rows = list_cases({"open_only": True})
    from utils.calculations import days_remaining

    result = []
    for row in rows:
        remaining = days_remaining(row.get("due_date"))
        if remaining is None:
            continue
        if remaining < 0 and not include_overdue:
            continue
        if remaining <= days:
            row["days_remaining"] = remaining
            result.append(row)
    return sorted(result, key=lambda r: r["days_remaining"])


def recent_cases(limit: int = 8) -> List[Dict[str, Any]]:
    return query(CASE_SELECT + " ORDER BY c.updated_at DESC, c.id DESC LIMIT ?", (limit,))


def high_risk_cases(limit: int = 50) -> List[Dict[str, Any]]:
    return query(
        CASE_SELECT + " WHERE c.risk_level = 'High' AND c.status != 'Closed'"
        " ORDER BY a.total_exposure DESC, c.id DESC LIMIT ?",
        (limit,),
    )


def set_case_status(case_id: int, status: str, stage: str = "") -> int:
    data: Dict[str, Any] = {"status": status}
    if stage:
        data["stage"] = stage
    return update_case(case_id, data)


# ===========================================================================
# NOTICE ANALYSIS
# ===========================================================================
ANALYSIS_FIELDS = (
    "taxpayer_name", "gstin", "notice_type", "notice_number", "financial_year",
    "tax_period", "notice_date", "reply_due_date", "sections", "rules",
    "officer_name", "designation", "jurisdiction", "summary",
    "cgst", "sgst", "igst", "cess", "interest", "penalty", "other_amount",
    "total_tax", "total_exposure", "source", "ai_raw_json",
)


def save_notice_analysis(case_id: int, data: Dict[str, Any]) -> int:
    """Insert a new analysis row (history is preserved; latest one is used)."""
    payload = {k: data.get(k, "") for k in ANALYSIS_FIELDS}
    for numeric in ("cgst", "sgst", "igst", "cess", "interest", "penalty",
                    "other_amount", "total_tax", "total_exposure"):
        payload[numeric] = float(data.get(numeric) or 0)
    payload["case_id"] = case_id
    payload["created_at"] = _now()
    return _insert("notice_analysis", payload)


def get_notice_analysis(case_id: int) -> Optional[Dict[str, Any]]:
    return query_one(
        "SELECT * FROM notice_analysis WHERE case_id = ? ORDER BY id DESC LIMIT 1",
        (case_id,),
    )


def delete_notice_analysis(case_id: int) -> int:
    return execute("DELETE FROM notice_analysis WHERE case_id = ?", (case_id,))


# ===========================================================================
# ISSUES
# ===========================================================================
ISSUE_FIELDS = (
    "issue_no", "title", "allegation", "amount", "sections", "facts_identified",
    "facts_missing", "risk", "risk_reason", "confidence", "ai_analysis", "ca_remarks",
)


def create_issue(case_id: int, data: Dict[str, Any]) -> int:
    payload = {k: data.get(k, "") for k in ISSUE_FIELDS}
    payload["case_id"] = case_id
    payload["issue_no"] = int(data.get("issue_no") or 1)
    payload["amount"] = float(data.get("amount") or 0)
    payload["created_at"] = _now()
    return _insert("issues", payload)


def update_issue(issue_id: int, data: Dict[str, Any]) -> int:
    payload = {k: v for k, v in data.items() if k in ISSUE_FIELDS}
    if "amount" in payload:
        payload["amount"] = float(payload["amount"] or 0)
    return _update("issues", issue_id, payload)


def delete_issue(issue_id: int) -> int:
    return execute("DELETE FROM issues WHERE id = ?", (issue_id,))


def delete_case_issues(case_id: int) -> int:
    return execute("DELETE FROM issues WHERE case_id = ?", (case_id,))


def get_issue(issue_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM issues WHERE id = ?", (issue_id,))


def list_issues(case_id: int) -> List[Dict[str, Any]]:
    return query("SELECT * FROM issues WHERE case_id = ? ORDER BY issue_no, id", (case_id,))


def replace_case_issues(case_id: int, issues: Iterable[Dict[str, Any]]) -> int:
    """Replace the issue set for a case inside a single transaction."""
    with get_connection() as conn:
        conn.execute("DELETE FROM issues WHERE case_id = ?", (case_id,))
        count = 0
        for index, issue in enumerate(issues or [], start=1):
            payload = {k: issue.get(k, "") for k in ISSUE_FIELDS}
            payload["case_id"] = case_id
            payload["issue_no"] = int(issue.get("issue_no") or index)
            payload["amount"] = float(issue.get("amount") or 0)
            payload["created_at"] = _now()
            columns = list(payload.keys())
            conn.execute(
                f"INSERT INTO issues ({', '.join(columns)}) "
                f"VALUES ({', '.join('?' for _ in columns)})",
                [payload[c] for c in columns],
            )
            count += 1
        return count


# ===========================================================================
# REQUIREMENTS
# ===========================================================================
REQUIREMENT_FIELDS = (
    "issue_id", "document_name", "purpose", "requirement_type",
    "status", "received_date", "remarks",
)


def create_requirement(case_id: int, data: Dict[str, Any]) -> int:
    payload = {k: data.get(k, "") for k in REQUIREMENT_FIELDS}
    payload["issue_id"] = data.get("issue_id") or None
    payload["case_id"] = case_id
    payload["requirement_type"] = data.get("requirement_type") or "Mandatory"
    payload["status"] = data.get("status") or "Pending"
    payload["created_at"] = _now()
    return _insert("requirements", payload)


def update_requirement(requirement_id: int, data: Dict[str, Any]) -> int:
    payload = {k: v for k, v in data.items() if k in REQUIREMENT_FIELDS}
    return _update("requirements", requirement_id, payload)


def delete_requirement(requirement_id: int) -> int:
    return execute("DELETE FROM requirements WHERE id = ?", (requirement_id,))


def list_requirements(case_id: int, issue_id: Optional[int] = None) -> List[Dict[str, Any]]:
    sql = """
        SELECT r.*, i.title AS issue_title, i.issue_no
          FROM requirements r
          LEFT JOIN issues i ON i.id = r.issue_id
         WHERE r.case_id = ?
    """
    params: List[Any] = [case_id]
    if issue_id:
        sql += " AND r.issue_id = ?"
        params.append(issue_id)
    return query(sql + " ORDER BY r.id", params)


def add_requirements_bulk(case_id: int, issue_id: Optional[int],
                          documents: Iterable[Dict[str, Any]]) -> int:
    """Insert an AI-generated checklist in one transaction."""
    with get_connection() as conn:
        count = 0
        for doc in documents or []:
            payload = {
                "case_id": case_id,
                "issue_id": issue_id,
                "document_name": doc.get("document_name") or doc.get("name") or "",
                "purpose": doc.get("purpose", ""),
                "requirement_type": doc.get("requirement_type") or "Mandatory",
                "status": "Pending",
                "received_date": "",
                "remarks": doc.get("remarks", ""),
                "created_at": _now(),
            }
            if not payload["document_name"]:
                continue
            columns = list(payload.keys())
            conn.execute(
                f"INSERT INTO requirements ({', '.join(columns)}) "
                f"VALUES ({', '.join('?' for _ in columns)})",
                [payload[c] for c in columns],
            )
            count += 1
        return count


# ===========================================================================
# RESEARCH
# ===========================================================================
def save_research(data: Dict[str, Any]) -> int:
    payload = {
        "case_id": data.get("case_id") or None,
        "issue_id": data.get("issue_id") or None,
        "question": data.get("question", ""),
        "answer": data.get("answer", ""),
        "sources": data.get("sources", ""),
        "raw_json": data.get("raw_json", ""),
        "source_mode": data.get("source_mode", ""),
        "created_by": data.get("created_by", ""),
        "created_at": _now(),
    }
    return _insert("research", payload)


def list_research(case_id: Optional[int] = None, limit: int = 100) -> List[Dict[str, Any]]:
    if case_id:
        return query(
            "SELECT * FROM research WHERE case_id = ? ORDER BY id DESC LIMIT ?",
            (case_id, limit),
        )
    return query("SELECT * FROM research ORDER BY id DESC LIMIT ?", (limit,))


def get_research(research_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM research WHERE id = ?", (research_id,))


def delete_research(research_id: int) -> int:
    return execute("DELETE FROM research WHERE id = ?", (research_id,))


# ===========================================================================
# DRAFTS
# ===========================================================================
def next_draft_version(case_id: int) -> int:
    row = query_one("SELECT MAX(version) AS v FROM drafts WHERE case_id = ?", (case_id,))
    return int((row or {}).get("v") or 0) + 1


def create_draft(case_id: int, draft_text: str, status: str = "AI Generated",
                 prepared_by: str = "", title: str = "", remarks: str = "") -> int:
    return _insert(
        "drafts",
        {
            "case_id": case_id,
            "version": next_draft_version(case_id),
            "title": title,
            "draft_text": draft_text,
            "status": status,
            "prepared_by": prepared_by,
            "reviewed_by": "",
            "remarks": remarks,
            "created_at": _now(),
            "updated_at": _now(),
        },
    )


def update_draft(draft_id: int, data: Dict[str, Any]) -> int:
    allowed = {"draft_text", "status", "title", "remarks", "reviewed_by", "prepared_by"}
    payload = {k: v for k, v in data.items() if k in allowed}
    payload["updated_at"] = _now()
    return _update("drafts", draft_id, payload)


def delete_draft(draft_id: int) -> int:
    return execute("DELETE FROM drafts WHERE id = ?", (draft_id,))


def get_draft(draft_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM drafts WHERE id = ?", (draft_id,))


def list_drafts(case_id: int) -> List[Dict[str, Any]]:
    return query(
        "SELECT * FROM drafts WHERE case_id = ? ORDER BY version DESC, id DESC",
        (case_id,),
    )


def latest_draft(case_id: int) -> Optional[Dict[str, Any]]:
    return query_one(
        "SELECT * FROM drafts WHERE case_id = ? ORDER BY version DESC, id DESC LIMIT 1",
        (case_id,),
    )


# ===========================================================================
# KNOWLEDGE BASE
# ===========================================================================
def add_knowledge_document(file_name: str, file_path: str, category: str,
                           title: str = "", notes: str = "",
                           is_demo: bool = False) -> int:
    existing = query_one(
        "SELECT id FROM knowledge_documents WHERE file_path = ?", (file_path,)
    )
    if existing:
        return int(existing["id"])
    return _insert(
        "knowledge_documents",
        {
            "file_name": file_name,
            "file_path": file_path,
            "category": category,
            "title": title or file_name,
            "date_added": _now(),
            "indexed": 0,
            "pages": 0,
            "chunk_count": 0,
            "notes": notes,
            "is_demo": int(bool(is_demo)),
        },
    )


def update_knowledge_document(document_id: int, data: Dict[str, Any]) -> int:
    allowed = {"file_name", "category", "title", "indexed", "pages", "chunk_count", "notes"}
    return _update("knowledge_documents", document_id, {k: v for k, v in data.items() if k in allowed})


def delete_knowledge_document(document_id: int) -> int:
    return execute("DELETE FROM knowledge_documents WHERE id = ?", (document_id,))


def get_knowledge_document(document_id: int) -> Optional[Dict[str, Any]]:
    return query_one("SELECT * FROM knowledge_documents WHERE id = ?", (document_id,))


def list_knowledge_documents(category: str = "", search: str = "") -> List[Dict[str, Any]]:
    sql = "SELECT * FROM knowledge_documents WHERE 1 = 1"
    params: List[Any] = []
    if category and category != "All":
        sql += " AND category = ?"
        params.append(category)
    if search:
        like = f"%{search.strip()}%"
        sql += " AND (file_name LIKE ? OR title LIKE ? OR notes LIKE ?)"
        params += [like] * 3
    return query(sql + " ORDER BY category, file_name COLLATE NOCASE", params)


def replace_document_chunks(document_id: int, chunks: Sequence[Dict[str, Any]]) -> int:
    """Re-index one document: delete old chunks, insert new ones atomically."""
    with get_connection() as conn:
        conn.execute("DELETE FROM knowledge_chunks WHERE document_id = ?", (document_id,))
        for chunk in chunks:
            conn.execute(
                "INSERT INTO knowledge_chunks "
                "(document_id, file_name, category, page, chunk_index, chunk_text) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    document_id, chunk.get("file_name", ""), chunk.get("category", ""),
                    int(chunk.get("page") or 0), int(chunk.get("chunk_index") or 0),
                    chunk.get("chunk_text", ""),
                ),
            )
        conn.execute(
            "UPDATE knowledge_documents SET indexed = 1, chunk_count = ? WHERE id = ?",
            (len(chunks), document_id),
        )
        return len(chunks)


def list_knowledge_chunks(category: str = "") -> List[Dict[str, Any]]:
    sql = "SELECT * FROM knowledge_chunks WHERE 1 = 1"
    params: List[Any] = []
    if category and category != "All":
        sql += " AND category = ?"
        params.append(category)
    return query(sql, params)


def knowledge_chunk_count() -> int:
    row = query_one("SELECT COUNT(*) AS n FROM knowledge_chunks")
    return int((row or {}).get("n") or 0)


# ===========================================================================
# ACTIVITY LOG
# ===========================================================================
def log_activity(action: str, detail: str = "", case_id: Optional[int] = None,
                 user_name: str = "") -> int:
    try:
        return _insert(
            "activity_log",
            {
                "case_id": case_id, "user_name": user_name, "action": action,
                "detail": detail[:1000], "created_at": _now(),
            },
        )
    except DatabaseError:
        return 0


def list_activity(case_id: Optional[int] = None, limit: int = 50) -> List[Dict[str, Any]]:
    if case_id:
        return query(
            "SELECT * FROM activity_log WHERE case_id = ? ORDER BY id DESC LIMIT ?",
            (case_id, limit),
        )
    return query("SELECT * FROM activity_log ORDER BY id DESC LIMIT ?", (limit,))


# ===========================================================================
# DEMONSTRATION DATA
# ===========================================================================
def list_demo_clients() -> List[Dict[str, Any]]:
    """Clients created by the demonstration module."""
    return query("SELECT * FROM clients WHERE is_demo = 1 ORDER BY client_name")


def list_demo_cases() -> List[Dict[str, Any]]:
    return query(CASE_SELECT + " WHERE c.is_demo = 1 ORDER BY c.id")


def get_case_by_notice_number(notice_number: str) -> Optional[Dict[str, Any]]:
    """Look a case up by its notice number (used to find the featured case)."""
    return query_one(CASE_SELECT + " WHERE c.notice_number = ? LIMIT 1",
                     (notice_number,))


def demo_counts() -> Dict[str, int]:
    """How much demonstration data is currently loaded."""
    def count(sql: str) -> int:
        row = query_one(sql)
        return int((row or {}).get("n") or 0)

    return {
        "clients": count("SELECT COUNT(*) AS n FROM clients WHERE is_demo = 1"),
        "cases": count("SELECT COUNT(*) AS n FROM cases WHERE is_demo = 1"),
        "documents": count(
            "SELECT COUNT(*) AS n FROM knowledge_documents WHERE is_demo = 1"),
        "real_clients": count("SELECT COUNT(*) AS n FROM clients WHERE is_demo = 0"),
        "real_cases": count("SELECT COUNT(*) AS n FROM cases WHERE is_demo = 0"),
    }


def delete_demo_data(include_knowledge_base: bool = False) -> Dict[str, int]:
    """
    Remove only records flagged as demonstration data.

    Deleting the demo clients cascades to their cases, analyses, issues,
    requirements, research and drafts. Records that are not flagged as demo
    are never touched.
    """
    removed = demo_counts()
    with get_connection() as conn:
        # Demo cases that somehow sit under a non-demo client are removed first.
        conn.execute("DELETE FROM cases WHERE is_demo = 1")
        conn.execute("DELETE FROM clients WHERE is_demo = 1")
        if include_knowledge_base:
            conn.execute(
                "DELETE FROM knowledge_chunks WHERE document_id IN "
                "(SELECT id FROM knowledge_documents WHERE is_demo = 1)")
            conn.execute("DELETE FROM knowledge_documents WHERE is_demo = 1")
        conn.execute("DELETE FROM activity_log WHERE case_id NOT IN "
                     "(SELECT id FROM cases) AND case_id IS NOT NULL")
    log.info("Demo data removed: %s", removed)
    return removed


# ===========================================================================
# DASHBOARD AGGREGATES
# ===========================================================================
def dashboard_data(alert_days: int = 7) -> Dict[str, Any]:
    """Everything the dashboard needs, computed from live records."""
    from utils.calculations import aggregate_cases, days_remaining

    all_cases = list_cases()
    open_cases = [c for c in all_cases if c.get("status") != "Closed"]
    totals = aggregate_cases(all_cases)

    # A matter whose reply has already been filed is not a pending deadline.
    awaiting_reply = [c for c in open_cases if c.get("status") != "Filed"]
    due_soon = []
    for case in awaiting_reply:
        remaining = days_remaining(case.get("due_date"))
        if remaining is not None and remaining <= alert_days:
            case = dict(case)
            case["days_remaining"] = remaining
            due_soon.append(case)
    due_soon.sort(key=lambda c: c["days_remaining"])

    clients = list_clients()
    return {
        "total_clients": len(clients),
        "active_clients": len([c for c in clients if c.get("active")]),
        "total_cases": len(all_cases),
        "open_cases": len(open_cases),
        "due_soon": due_soon,
        "due_soon_count": len(due_soon),
        "high_risk": [c for c in open_cases if c.get("risk_level") == "High"],
        "totals": totals,
        "recent": recent_cases(8),
        "all_cases": all_cases,
    }


def reset_transactional_data() -> None:
    """Clear demo/business data but keep users.  Used by 'Clear Demo Data'."""
    with get_connection() as conn:
        for table in ("activity_log", "drafts", "research", "requirements",
                      "issues", "notice_analysis", "cases", "clients"):
            conn.execute(f"DELETE FROM {table}")
