"""
tests.self_tests
================
Built-in self tests, runnable from Settings > Run Self Tests or from a
command prompt::

    python -m tests.self_tests

They cover the areas required by the project specification:

* GSTIN validation
* PAN validation
* Indian currency formatting
* total demand calculation
* database connection
* PDF extraction
* malformed AI JSON handling

and the specific scenarios: a notice with all values, a notice missing
interest, a notice missing penalty, a notice with multiple allegations,
an invalid GSTIN, a missing API key and an unavailable AI API.
"""

from __future__ import annotations

import sys
import traceback
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Dict, List, Tuple

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import config  # noqa: E402


# ---------------------------------------------------------------------------
# Tiny assertion helpers (no external test runner needed)
# ---------------------------------------------------------------------------
class TestFailure(AssertionError):
    """Raised when a self test assertion fails."""


def check(condition: bool, message: str) -> None:
    if not condition:
        raise TestFailure(message)


def check_equal(actual: Any, expected: Any, message: str = "") -> None:
    if actual != expected:
        raise TestFailure(f"{message or 'Values differ'}: expected {expected!r}, "
                          f"got {actual!r}")


# ===========================================================================
# 1. GSTIN validation
# ===========================================================================
def test_gstin_validation() -> str:
    from utils.validators import VALID, gstin_checksum, is_valid_gstin, validate_gstin

    valid_body = "27AABCA1234K1Z"
    valid = valid_body + (gstin_checksum(valid_body) or "")
    check(is_valid_gstin(valid), f"A well-formed GSTIN was rejected: {valid}")
    check_equal(validate_gstin(valid).status, VALID, "Valid GSTIN status")

    # Invalid GSTIN scenarios required by the specification
    cases = [
        ("", "Not Identified", "blank GSTIN"),
        ("27AABCA1234K1", "Invalid Format", "too short"),
        ("27AABCA1234K1Z55", "Invalid Format", "too long"),
        ("2XAABCA1234K1Z5", "Invalid Format", "non-numeric state code"),
        ("99AABCA1234K1Z5", "Review Required", "unusual state code 99 (Centre)"),
        ("27AABCA1234K1Z9", "Review Required", "wrong checksum digit"),
        ("271234567890123", "Invalid Format", "digits where letters are required"),
    ]
    notes: List[str] = []
    for value, expected, label in cases:
        result = validate_gstin(value)
        if value == "99AABCA1234K1Z5":
            # 99 is a recognised code, so only the checksum can fail here
            check(result.status in ("Valid", "Review Required"),
                  f"{label}: unexpected status {result.status}")
        else:
            check_equal(result.status, expected, f"{label} ({value})")
        notes.append(f"{label} -> {result.status}")

    # State code decoding
    from utils.validators import gstin_state, pan_from_gstin

    check_equal(gstin_state(valid), "Maharashtra", "State decoded from GSTIN")
    check_equal(pan_from_gstin(valid), "AABCA1234K", "PAN extracted from GSTIN")
    return f"valid GSTIN accepted; {len(cases)} invalid/edge cases handled"


# ===========================================================================
# 2. PAN validation
# ===========================================================================
def test_pan_validation() -> str:
    from utils.validators import INVALID, NOT_FOUND, VALID, is_valid_pan, validate_pan

    check(is_valid_pan("AABCA1234K"), "A valid PAN was rejected")
    check(is_valid_pan("aabca1234k"), "Lower-case PAN should be accepted")
    check(not is_valid_pan("AABCA1234"), "Nine-character PAN should be rejected")
    check(not is_valid_pan("AABC01234K"), "Digit in the alphabetic block accepted")
    check(not is_valid_pan("1ABCA1234K"), "Leading digit accepted")
    check_equal(validate_pan("").status, NOT_FOUND, "Blank PAN")
    check_equal(validate_pan("ABC").status, INVALID, "Short PAN")
    check_equal(validate_pan("AABCA1234K").status, VALID, "Valid PAN")
    return "5 pattern checks and 3 status checks passed"


# ===========================================================================
# 3. Indian currency formatting
# ===========================================================================
def test_currency_formatting() -> str:
    from utils.formatters import (
        format_currency, format_currency_short, indian_group, parse_currency,
    )

    check_equal(indian_group("10550000"), "1,05,50,000", "Indian grouping")
    check_equal(indian_group("100"), "100", "Three digits unchanged")
    check_equal(indian_group("1000"), "1,000", "Four digits")
    check_equal(indian_group("125500000"), "12,55,00,000", "Nine digits")

    check_equal(format_currency(1055000), "₹10,55,000", "Lakh formatting")
    check_equal(format_currency(12550000), "₹1,25,50,000", "Crore formatting")
    check_equal(format_currency(0), "₹0", "Zero")
    check_equal(format_currency(-5000), "-₹5,000", "Negative amount")
    check_equal(format_currency(1234.56, decimals=True), "₹1,234.56", "Paise")

    check_equal(format_currency_short(12550000), "₹1.26 Cr", "Compact crore")
    check_equal(format_currency_short(1055000), "₹10.55 L", "Compact lakh")
    check_equal(format_currency_short(9500), "₹9,500", "Compact small amount")

    check_equal(parse_currency("₹1,05,50,000"), Decimal("10550000.00"), "Round trip")
    check_equal(parse_currency("Rs. 12,345.50"), Decimal("12345.50"), "Rs prefix")
    return "13 formatting and parsing checks passed"


# ===========================================================================
# 4. Demand calculation (including the required notice scenarios)
# ===========================================================================
def test_demand_calculation() -> str:
    from utils.calculations import compute_demand, reconcile_issue_amounts

    # Scenario A - a notice with all values present
    full = {"cgst": 1240000, "sgst": 1240000, "igst": 685000, "cess": 15000,
            "interest": 1058400, "penalty": 316500, "other_amount": 5000}
    demand = compute_demand(full)
    check_equal(demand.total_tax, Decimal("3180000.00"), "Total tax (all values)")
    check_equal(demand.total_exposure, Decimal("4559900.00"),
                "Total exposure (all values)")

    # Scenario B - a notice with no interest stated
    no_interest = dict(full, interest=0)
    demand_b = compute_demand(no_interest)
    check_equal(demand_b.total_tax, Decimal("3180000.00"), "Total tax unaffected")
    check_equal(demand_b.total_exposure, Decimal("3501500.00"),
                "Total exposure without interest")

    # Scenario C - a notice with no penalty stated
    no_penalty = dict(full, penalty=None)
    demand_c = compute_demand(no_penalty)
    check_equal(demand_c.total_exposure, Decimal("4243400.00"),
                "Total exposure without penalty")

    # Scenario D - missing keys entirely, and unparseable values
    sparse = compute_demand({"cgst": "₹1,00,000", "igst": "not stated"})
    check_equal(sparse.total_tax, Decimal("100000.00"), "Currency string parsed")
    check_equal(sparse.total_exposure, Decimal("100000.00"), "Sparse exposure")
    check_equal(compute_demand({}).total_exposure, Decimal("0.00"), "Empty mapping")

    # Scenario E - a notice with multiple allegations reconciling to total tax
    issues = [{"amount": 1685000}, {"amount": 795000}, {"amount": 685000}]
    three_issue_demand = compute_demand(
        {"cgst": 1240000, "sgst": 1240000, "igst": 685000,
         "interest": 1058400, "penalty": 316500})
    reconciliation = reconcile_issue_amounts(three_issue_demand, issues)
    check_equal(reconciliation["issue_total"], Decimal("3165000.00"),
                "Sum of three allegation amounts")
    check(reconciliation["matched"],
          "Issue amounts should reconcile with the total tax demanded")

    # A material mismatch must be reported, not corrected
    mismatch = reconcile_issue_amounts(three_issue_demand, [{"amount": 100}])
    check(not mismatch["matched"], "A material mismatch must be flagged")
    return "5 demand scenarios and 2 reconciliation checks passed"


# ===========================================================================
# 5. Deadline arithmetic
# ===========================================================================
def test_deadline_calculations() -> str:
    from datetime import date

    from utils.calculations import days_remaining, deadline_severity, is_overdue

    today = date(2026, 1, 15)
    check_equal(days_remaining(date(2026, 1, 25), today), 10, "Ten days remaining")
    check_equal(days_remaining(date(2026, 1, 15), today), 0, "Due today")
    check_equal(days_remaining(date(2026, 1, 10), today), -5, "Overdue by five days")
    check_equal(days_remaining("", today), None, "No due date")
    check(is_overdue(date(2026, 1, 10), today), "Past date should be overdue")
    check(not is_overdue(date(2026, 2, 10), today), "Future date is not overdue")
    check_equal(deadline_severity(date(2026, 1, 10), today=today), "overdue", "Overdue")
    check_equal(deadline_severity(date(2026, 1, 17), today=today), "urgent", "Urgent")
    check_equal(deadline_severity(date(2026, 1, 20), today=today), "soon", "Soon")
    check_equal(deadline_severity(date(2026, 3, 1), today=today), "normal", "Normal")
    return "10 deadline checks passed"


# ===========================================================================
# 6. Date and financial-year handling
# ===========================================================================
def test_date_and_fy() -> str:
    from datetime import date

    from utils.formatters import format_date, to_iso_date
    from utils.validators import (
        INVALID, VALID, normalise_financial_year, parse_date, validate_financial_year,
    )

    check_equal(parse_date("05-07-2023"), date(2023, 7, 5), "DD-MM-YYYY")
    check_equal(parse_date("2023-07-05"), date(2023, 7, 5), "ISO")
    check_equal(parse_date("05/07/2023"), date(2023, 7, 5), "Slashes")
    check_equal(parse_date("nonsense"), None, "Unparseable date")
    check_equal(format_date("2023-07-05"), "05-07-2023", "Indian display format")
    check_equal(to_iso_date("05-07-2023"), "2023-07-05", "ISO storage format")

    check_equal(normalise_financial_year("FY 2022-2023"), "2022-23", "FY normalising")
    check_equal(normalise_financial_year("2022-23"), "2022-23", "FY already normal")
    check_equal(validate_financial_year("2022-23").status, VALID, "Valid FY")
    check_equal(validate_financial_year("2022-25").status, INVALID, "Impossible FY")
    return "10 date and financial-year checks passed"


# ===========================================================================
# 7. Database connection and CRUD round trip
# ===========================================================================
def test_database() -> str:
    from database import database as db

    db.initialise_database()
    status = db.database_status()
    check(status["connected"], "The database reported that it is not connected")
    check(status["counts"].get("users", 0) >= 1,
          "The default administrator account is missing")

    client_id = db.create_client({
        "client_name": "__SELFTEST__ Client", "gstin": "", "pan": "",
        "state": "Maharashtra", "entity_type": "Private Limited Company",
    })
    check(client_id > 0, "Client insert failed")

    case_id = db.create_case({
        "client_id": client_id, "notice_type": "DRC-01",
        "notice_number": "__SELFTEST__", "financial_year": "2022-23",
    })
    check(case_id > 0, "Case insert failed")

    db.save_notice_analysis(case_id, {
        "taxpayer_name": "__SELFTEST__", "cgst": 100, "sgst": 100,
        "total_tax": 200, "total_exposure": 250, "interest": 50,
    })
    fetched = db.get_case(case_id)
    check(fetched is not None, "Case could not be read back")
    check_equal(float(fetched.get("total_exposure") or 0), 250.0,
                "Analysis join returned the wrong exposure")

    db.replace_case_issues(case_id, [
        {"issue_no": 1, "title": "A", "amount": 100},
        {"issue_no": 2, "title": "B", "amount": 100},
    ])
    check_equal(len(db.list_issues(case_id)), 2, "Issue replacement count")

    db.create_requirement(case_id, {"document_name": "__SELFTEST__ doc"})
    check_equal(len(db.list_requirements(case_id)), 1, "Requirement insert")

    draft_id = db.create_draft(case_id, "draft text", prepared_by="selftest")
    check_equal((db.get_draft(draft_id) or {}).get("version"), 1, "First draft version")
    db.create_draft(case_id, "draft text 2", prepared_by="selftest")
    check_equal(len(db.list_drafts(case_id)), 2, "Draft versioning")

    # Cascade delete must clean everything up
    db.delete_client(client_id)
    check_equal(db.get_case(case_id), None, "Cascade delete of the case failed")
    check_equal(len(db.list_issues(case_id)), 0, "Cascade delete of issues failed")
    return "database connection, CRUD round trip and cascade delete verified"


# ===========================================================================
# 8. PDF extraction
# ===========================================================================
def test_pdf_extraction() -> str:
    from services import demo_data, demo_scenarios
    from services.pdf_service import extract_pdf

    demo_data.generate_notice_pdfs()
    scenario = demo_scenarios.featured_scenario()
    pdf_path = config.SAMPLE_NOTICE_DIR / scenario.pdf_name
    if not pdf_path.exists():
        return "skipped - the sample notice PDF could not be generated"

    result = extract_pdf(pdf_path)
    check(result.ok, f"The sample notice PDF could not be read: {result.message}")
    check(result.page_count >= 1, "No pages were reported")
    check("DRC-01" in result.text, "Expected notice text was not extracted")
    check(len(result.pages) == result.page_count, "Page list length mismatch")
    check(result.pages[0].page == 1, "Page numbering must start at 1")

    # A missing file must be reported, never raised
    missing = extract_pdf(config.SAMPLE_DATA_DIR / "__does_not_exist__.pdf")
    check(not missing.ok, "A missing file should not be reported as readable")
    check("not found" in missing.error.lower(), "Missing-file message unclear")

    # A non-PDF must be rejected politely
    text_file = config.SAMPLE_DATA_DIR / "__selftest__.txt"
    text_file.write_text("not a pdf", encoding="utf-8")
    try:
        not_pdf = extract_pdf(text_file)
        check(not not_pdf.ok, "A .txt file should not be accepted as a PDF")
    finally:
        text_file.unlink(missing_ok=True)

    return (f"{result.page_count} page(s), {result.char_count:,} characters extracted; "
            "missing-file and wrong-type handling verified")


# ===========================================================================
# 9. Malformed AI output handling
# ===========================================================================
def test_malformed_ai_json() -> str:
    from services.gst_notice_service import normalise_analysis
    from utils.helpers import extract_json

    # Recoverable shapes
    check_equal(extract_json('{"a": 1}'), {"a": 1}, "Plain JSON")
    check_equal(extract_json('```json\n{"a": 1}\n```'), {"a": 1}, "Fenced JSON")
    check_equal(extract_json('Here you go:\n{"a": 1}\nHope that helps.'), {"a": 1},
                "JSON wrapped in prose")
    check_equal(extract_json('{"a": 1,}'), {"a": 1}, "Trailing comma repaired")
    check_equal(extract_json('{"a": "x",}'), {"a": "x"}, "Trailing comma with string")

    # Unrecoverable shapes must return None, not raise
    for bad in ("", None, "not json at all", "{unclosed", "<html>nope</html>"):
        check_equal(extract_json(bad), None, f"Unparseable input {bad!r}")

    # Normalisation must survive rubbish without raising
    empty = normalise_analysis(None)
    check_equal(empty["taxpayer_name"], "", "Missing text field defaults to blank")
    check_equal(empty["cgst"], Decimal("0.00"), "Missing amount defaults to zero")
    check_equal(empty["issues"], [], "Missing issues default to an empty list")

    messy = normalise_analysis({
        "taxpayer_name": 12345,
        "gstin": "  27aabca1234k1z5 ",
        "financial_year": "FY 2022-2023",
        "cgst": "Rs. 1,00,000",
        "interest": None,
        "sections_invoked": "Section 73, Section 50",
        "issues": [
            {"issue_title": "One", "amount": "2,00,000", "initial_risk": "HIGH",
             "confidence": "high", "sections": ["S 73"]},
            "this should be ignored",
            {"title": "Two", "amount": None},
        ],
    })
    check_equal(messy["taxpayer_name"], "12345", "Numeric name coerced to text")
    check_equal(messy["gstin"], "27AABCA1234K1Z5", "GSTIN trimmed and upper-cased")
    check_equal(messy["financial_year"], "2022-23", "Financial year normalised")
    check_equal(messy["cgst"], Decimal("100000.00"), "Currency string coerced")
    check_equal(messy["interest"], Decimal("0.00"), "None coerced to zero")
    check_equal(len(messy["sections_invoked"]), 2, "Comma string split into a list")
    check_equal(len(messy["issues"]), 2, "Non-dict issue entries dropped")
    check_equal(messy["issues"][0]["initial_risk"], "High", "Risk value normalised")
    check_equal(messy["issues"][1]["initial_risk"], "Review Required",
                "Missing risk defaults to Review Required")
    return "10 JSON recovery cases and 9 normalisation checks passed"


# ===========================================================================
# 10. AI service error handling (missing key, unavailable API)
# ===========================================================================
def test_ai_error_handling() -> str:
    import services.ai_service as ai

    original_key = config.GEMINI_API_KEY
    notes: List[str] = []
    try:
        # Missing API key
        config.GEMINI_API_KEY = ""
        response = ai.generate("test", demo_mode=False, expect_json=True,
                               provider=config.PROVIDER_GEMINI, label="selftest")
        check(not response.ok, "A call without an API key must fail")
        check_equal(response.error_kind, ai.ERR_NO_KEY, "Missing key error kind")
        check("GEMINI_API_KEY" in response.friendly_error,
              "The missing-key message should tell the user what to set")
        notes.append("missing key handled")

        # API unavailable - simulated by a client that raises a network error
        config.GEMINI_API_KEY = "selftest-key"
        if ai.gemini_sdk_available():
            from google import genai

            original_client = genai.Client

            class _FailingClient:
                def __init__(self, *_args, **_kwargs):
                    raise ConnectionError("Failed to establish a new connection")

            genai.Client = _FailingClient  # type: ignore[assignment]
            try:
                response = ai.generate("test", demo_mode=False, expect_json=True,
                                       provider=config.PROVIDER_GEMINI,
                                       label="selftest")
            finally:
                genai.Client = original_client  # type: ignore[assignment]
            check(not response.ok, "A network failure must be reported as a failure")
            check_equal(response.error_kind, ai.ERR_NETWORK, "Network error kind")
            notes.append("network failure handled")
        else:
            notes.append("SDK not installed - network test skipped")

        # Classification of the other documented failure modes
        check_equal(ai._classify(TimeoutError("deadline exceeded")), ai.ERR_TIMEOUT,
                    "Timeout classification")
        check_equal(ai._classify(Exception("API key not valid")), ai.ERR_AUTH,
                    "Auth classification")
        check_equal(ai._classify(Exception("429 quota exceeded")), ai.ERR_QUOTA,
                    "Quota classification")
        notes.append("timeout, auth and quota classified")

        # Demo mode must never touch the API, even with no key
        config.GEMINI_API_KEY = ""
        demo = ai.generate("test", demo_mode=True, demo_payload={"ok": True},
                           expect_json=True, label="selftest")
        check(demo.ok and demo.demo, "Demo mode must succeed without an API key")
        check_equal(demo.data, {"ok": True}, "Demo payload returned unchanged")
        notes.append("demo mode isolated from the API")
    finally:
        config.GEMINI_API_KEY = original_key

    return "; ".join(notes)


# ===========================================================================
# 11. End-to-end notice analysis in demo mode
# ===========================================================================
def test_notice_analysis_pipeline() -> str:
    from database import database as db
    from services import gst_notice_service as notice_service
    from services import demo_data, demo_scenarios

    db.initialise_database()
    client_id = db.create_client({"client_name": "__SELFTEST__ Pipeline"})
    case_id = db.create_case({"client_id": client_id, "notice_type": "DRC-01"})
    try:
        case = db.get_case(case_id)
        from datetime import date, timedelta

        scenario = demo_scenarios.featured_scenario()
        text = demo_data.notice_text(scenario, date.today() - timedelta(days=10),
                                     date.today() + timedelta(days=20))
        result = notice_service.analyse_notice(text, case, demo_mode=True)
        check(result.ok, f"Demo-mode analysis failed: {result.error}")
        check(result.issue_count >= 3,
              f"A multi-allegation notice should yield 3+ issues, got "
              f"{result.issue_count}")
        check(result.demand.total_exposure > 0, "No exposure was computed")
        check(len(result.validations) > 10, "Too few validation results")

        notice_service.save_analysis(case_id, result)
        reloaded = notice_service.load_saved_analysis(case_id)
        check(reloaded is not None, "The saved analysis could not be reloaded")
        check_equal(reloaded.demand.total_exposure, result.demand.total_exposure,
                    "Exposure changed on reload")
        check_equal(reloaded.issue_count, result.issue_count,
                    "Issue count changed on reload")

        updated = db.get_case(case_id)
        check(updated.get("risk_level") in ("High", "Medium", "Low",
                                            "Review Required"),
              "The case risk level was not set")
        check_equal(updated.get("status"), "Under Analysis",
                    "The case status was not advanced")

        # Empty notice text must be refused politely
        empty = notice_service.analyse_notice("", case, demo_mode=True)
        check(not empty.ok, "Empty notice text should not be analysed")
        return (f"{result.issue_count} issue(s), exposure "
                f"{result.demand.total_exposure}, save/reload verified")
    finally:
        db.delete_client(client_id)


# ===========================================================================
# 12. Knowledge base retrieval
# ===========================================================================
def test_rag_retrieval() -> str:
    from services import rag_service

    status = rag_service.knowledge_base_status()
    if not status["chunks"]:
        return "skipped - the knowledge base is empty (create the demo KB first)"

    hits = rag_service.search("conditions for availing input tax credit", top_k=4)
    check(bool(hits), "No passage was retrieved for a question that should match")
    check(all(h.file_name for h in hits), "A retrieved passage has no file name")
    check(hits[0].score >= (hits[-1].score if len(hits) > 1 else 0),
          "Results are not ordered by relevance")

    nonsense = rag_service.search("zzzz qqqq xxxx nonexistentterm", top_k=4)
    check(len(nonsense) <= len(hits),
          "A nonsense query should not out-retrieve a real one")

    prompt_block = rag_service.format_sources_for_prompt(hits)
    check("[S1]" in prompt_block, "Source references are missing from the prompt block")

    empty_block = rag_service.format_sources_for_prompt([])
    check("NO SOURCES" in empty_block,
          "The prompt must state clearly when nothing was retrieved")
    return f"{len(hits)} passage(s) retrieved from {status['chunks']} indexed"


# ===========================================================================
# 13. Password hashing and role permissions
# ===========================================================================
def test_security_and_roles() -> str:
    from utils.helpers import (
        can_approve, can_manage_users, hash_password, is_readonly, verify_password,
    )

    stored = hash_password("admin123")
    check(stored.startswith("pbkdf2_sha256$"), "Unexpected hash format")
    check("admin123" not in stored, "The password must not appear in the hash")
    check(verify_password("admin123", stored), "A correct password was rejected")
    check(not verify_password("Admin123", stored), "A wrong password was accepted")
    check(not verify_password("", stored), "An empty password was accepted")
    check(not verify_password("admin123", ""), "An empty hash was accepted")
    check(hash_password("x") != hash_password("x"), "Hashes must be salted")

    check(can_approve("Admin / Partner"), "Partner should be able to approve")
    check(can_approve("Reviewer"), "Reviewer should be able to approve")
    check(not can_approve("Team Member"), "Team Member must not approve")
    check(not can_approve("Viewer"), "Viewer must not approve")
    check(is_readonly("Viewer"), "Viewer must be read-only")
    check(not is_readonly("Manager"), "Manager must not be read-only")
    check(can_manage_users("Admin / Partner"), "Partner should manage users")
    check(not can_manage_users("Manager"), "Manager must not manage users")
    return "7 hashing checks and 8 permission checks passed"


# ===========================================================================
# 14. Exports
# ===========================================================================
def test_exports() -> str:
    from services import export_service

    rows = [{"a": "Row one", "b": 1000}, {"a": "Row two", "b": 2000}]
    columns = [("a", "Description"), ("b", "Amount")]
    notes: List[str] = []

    ok, message = export_service.export_table_excel(rows, columns, "__selftest__",
                                                    "Test")
    check(ok, f"Excel export failed: {message}")
    Path(message).unlink(missing_ok=True)
    notes.append("Excel")

    ok, message = export_service.export_text_word("Line one\nLine two", "__selftest__")
    if ok:
        Path(message).unlink(missing_ok=True)
        notes.append("Word")
    else:
        notes.append(f"Word skipped ({message.splitlines()[0]})")

    ok, message = export_service.export_text_pdf("Line one\nLine two", "__selftest__")
    if ok:
        Path(message).unlink(missing_ok=True)
        notes.append("PDF")
    else:
        notes.append(f"PDF skipped ({message.splitlines()[0]})")

    return ", ".join(notes) + " export verified"


# ===========================================================================
# 15. Prompt templates
# ===========================================================================
def test_prompts() -> str:
    from services.prompt_setup import DEFAULT_PROMPTS, ensure_prompt_files
    from utils.helpers import clear_prompt_cache, load_prompt

    ensure_prompt_files()
    clear_prompt_cache()
    for name in DEFAULT_PROMPTS:
        text = load_prompt(name)
        check(bool(text.strip()), f"Prompt file {name} is empty or missing")

    from services.gst_notice_service import build_prompt

    prompt = build_prompt("A test notice mentioning Section 73.")
    check("Section 73" in prompt, "The notice text is missing from the prompt")
    check("Do not invent facts" in prompt, "The safety instruction is missing")
    check("{" in prompt and "issues" in prompt,
          "The required JSON structure is missing from the prompt")

    # Very long notices must be truncated rather than sent in full
    long_prompt = build_prompt("x" * 60_000)
    check("[NOTICE TEXT TRUNCATED FOR LENGTH]" in long_prompt,
          "A very long notice should be truncated to control token cost")
    return f"{len(DEFAULT_PROMPTS)} prompt file(s) present and rendered correctly"


# ===========================================================================
# 16. Dialog visibility
# ===========================================================================
def test_dialog_visibility() -> str:
    """
    Every modal dialog must actually appear on screen.

    CustomTkinter re-runs a title-bar routine on each ``resizable()`` call
    that withdraws the window and restores the state it sampled. Two
    overlapping runs leave a dialog permanently withdrawn: it exists, it
    grabs input, but the user never sees it. That once made first-login
    impossible, so every dialog is now checked for real visibility.
    """
    import threading
    import tkinter as tk

    if threading.current_thread() is not threading.main_thread():
        return "skipped - GUI checks only run on the main thread"

    try:
        import customtkinter as ctk
    except ImportError:
        return "skipped - customtkinter is not installed"

    # A live root means the application itself is running; a second Tk root
    # would be unsafe, so the check is skipped rather than risked.
    existing = getattr(tk, "_default_root", None)
    if existing is not None:
        try:
            existing.winfo_exists()
            return "skipped - the application is already running"
        except tk.TclError:
            tk._default_root = None

    from database import database as db

    db.initialise_database()
    ctk.set_appearance_mode("light")

    outcome: Dict[str, Any] = {"error": None}
    root = ctk.CTk()
    root.geometry("900x600+120+100")

    def build() -> None:
        try:
            from ui.login import ChangePasswordDialog
            from ui.notice_analyzer import CorrectionDialog
            from ui.requirements_generator import ExportDoneDialog
            from ui.settings import ResetPasswordDialog
            from ui.widgets import BusyDialog, MessageDialog, ModalDialog

            user = dict(db.get_user_by_username("admin") or {})
            outcome["dialogs"] = {
                "ModalDialog": ModalDialog(root, "probe", 400, 300),
                "MessageDialog": MessageDialog(root, "probe", "message"),
                "BusyDialog": BusyDialog(root, "probe", "working"),
                "ChangePasswordDialog": ChangePasswordDialog(root, user,
                                                             first_login=True),
                "CorrectionDialog": CorrectionDialog(root, "GSTIN",
                                                     "27AABCA1234K1ZY",
                                                     lambda _v: None),
                "ResetPasswordDialog": ResetPasswordDialog(root, user),
                "ExportDoneDialog": ExportDoneDialog(root, "probe.xlsx"),
            }
        except Exception as exc:  # noqa: BLE001 - reported, not raised, in a callback
            outcome["error"] = f"{type(exc).__name__}: {exc}"
        # Constructing seven toplevels takes well over a second on a cold
        # start, and each one settles its own visibility a few hundred
        # milliseconds later. Timing the inspection from the end of the
        # build -- not from the start -- is what makes this check reliable.
        root.after(1500, inspect)

    def inspect() -> None:
        if outcome.get("states") is not None:
            return
        states = {}
        for name, dialog in (outcome.get("dialogs") or {}).items():
            try:
                states[name] = (dialog.state(), bool(dialog.winfo_viewable()))
            except tk.TclError as exc:
                states[name] = ("error", str(exc)[:40])
        outcome["states"] = states
        try:
            root.destroy()
        except tk.TclError:
            pass

    root.after(200, build)
    root.after(20000, inspect)      # safety net: never leave the loop running
    root.mainloop()
    try:
        tk._default_root = None
    except Exception:  # noqa: BLE001
        pass

    check(outcome["error"] is None,
          f"A dialog could not be constructed: {outcome['error']}")
    states = outcome.get("states") or {}
    check(bool(states), "No dialog could be constructed for the visibility check")

    hidden = [name for name, (_s, viewable) in states.items() if viewable is not True]
    check(not hidden,
          "These dialogs were created but never became visible, which would "
          f"block the user with no explanation: {', '.join(hidden)}")
    return f"{len(states)} dialog(s) constructed and confirmed visible"


# ===========================================================================
# 17. Demonstration data module
# ===========================================================================
def test_demo_data() -> str:
    """
    The demonstration portfolio must build cleanly, be idempotent, and be
    removable without touching real records.
    """
    from database import database as db
    from services import demo_data, demo_scenarios
    from utils.calculations import compute_demand
    from utils.validators import is_valid_gstin

    db.initialise_database()

    # Every fictional GSTIN must pass the application's own validation.
    for client in demo_scenarios.DEMO_CLIENTS:
        check(is_valid_gstin(client.gstin),
              f"Demo GSTIN failed validation: {client.client_name} {client.gstin}")

    # Exactly one featured matter, and every scenario maps to a known client.
    featured = [s for s in demo_scenarios.DEMO_SCENARIOS if s.featured]
    check_equal(len(featured), 1, "There must be exactly one featured demo case")
    for scenario in demo_scenarios.DEMO_SCENARIOS:
        check(scenario.client_key in demo_scenarios.CLIENTS_BY_KEY,
              f"Scenario {scenario.key} references an unknown client")

    # A real record is created first and must survive everything below.
    real_client = db.create_client({"client_name": "__SELFTEST__ Real Client"})
    real_case = db.create_case({"client_id": real_client, "notice_type": "SCN",
                                "notice_number": "__SELFTEST__/REAL/1"})
    try:
        first = demo_data.prepare_demo_environment(include_knowledge_base=False)
        check(first.cases_created > 0 or db.demo_counts()["cases"] > 0,
              "The demo environment did not create any case")

        counts = db.demo_counts()
        check_equal(counts["clients"], len(demo_scenarios.DEMO_CLIENTS),
                    "Demo client count")
        check_equal(counts["cases"], len(demo_scenarios.DEMO_SCENARIOS),
                    "Demo case count")

        # Idempotency: a second run must not duplicate anything.
        second = demo_data.prepare_demo_environment(include_knowledge_base=False)
        check_equal(second.clients_created, 0, "Second run duplicated clients")
        check_equal(second.cases_created, 0, "Second run duplicated cases")
        check_equal(db.demo_counts()["cases"], counts["cases"],
                    "Case count changed on the second run")

        # The featured case must be complete enough to demonstrate.
        featured_case = demo_data.featured_case()
        check(featured_case is not None, "The featured demo case was not created")
        case_id = int(featured_case["id"])
        check_equal(featured_case["demo_tag"], "featured", "Featured tag")
        check(len(db.list_issues(case_id)) >= 3,
              "The featured case should carry three issues")
        check(len(db.list_requirements(case_id)) >= 15,
              "The featured case should carry a requirement checklist")
        check(len(db.list_research(case_id)) >= 1,
              "The featured case should carry saved research")
        check(len(db.list_drafts(case_id)) >= 1,
              "The featured case should carry a draft reply")

        # The stored demand must equal the scenario definition exactly.
        scenario = demo_scenarios.featured_scenario()
        stored = compute_demand(db.get_case(case_id))
        check_equal(stored.total_exposure, scenario.total_exposure(),
                    "Stored exposure differs from the scenario definition")

        # The mock AI must reproduce the same figures for that case.
        from services import mock_data

        payload = mock_data.notice_analysis("", db.get_case(case_id))
        check_equal(compute_demand(payload).total_exposure,
                    scenario.total_exposure(),
                    "Mock AI output differs from the printed notice figures")
        check_equal(payload["taxpayer_name"], scenario.client.client_name,
                    "Mock AI returned the wrong taxpayer for a demo case")

        # Every workflow status should be represented for the charts.
        statuses = {s.status for s in demo_scenarios.DEMO_SCENARIOS}
        check(len(statuses) >= 9,
              f"Only {len(statuses)} distinct statuses in the demo portfolio")

        # Sample notice PDFs must exist and be readable.
        from services.pdf_service import extract_pdf

        pdfs = [s for s in demo_scenarios.DEMO_SCENARIOS if s.pdf_name]
        readable = 0
        for scen in pdfs:
            path = config.SAMPLE_NOTICE_DIR / scen.pdf_name
            if path.exists() and extract_pdf(path).ok:
                readable += 1
        check(readable == len(pdfs),
              f"Only {readable} of {len(pdfs)} sample notices are readable")

        # Reset must remove demo records and keep real ones.
        demo_data.reset_demo_data(include_knowledge_base=False)
        after = db.demo_counts()
        check_equal(after["clients"], 0, "Demo clients survived the reset")
        check_equal(after["cases"], 0, "Demo cases survived the reset")
        check(db.get_client(real_client) is not None,
              "The reset deleted a real client - this must never happen")
        check(db.get_case(real_case) is not None,
              "The reset deleted a real case - this must never happen")

        return (f"{counts['clients']} client(s), {counts['cases']} case(s), "
                f"{len(pdfs)} notice PDF(s); idempotent; reset preserved real data")
    finally:
        db.delete_client(real_client)
        demo_data.reset_demo_data(include_knowledge_base=False)


# ===========================================================================
# Runner
# ===========================================================================
# ===========================================================================
# 18. AI provider layer (Gemini / ChatGPT selection)
# ===========================================================================
def test_ai_providers() -> str:
    """
    Both providers must be selectable, and every AI feature must follow the
    selection. Keys are never exposed in full, whichever provider is active.
    """
    import services.ai_service as ai

    original_gemini = config.GEMINI_API_KEY
    original_openai = config.OPENAI_API_KEY
    notes: List[str] = []
    try:
        check_equal(config.AI_PROVIDERS,
                    [config.PROVIDER_GEMINI, config.PROVIDER_OPENAI],
                    "Both providers must be offered")
        check_equal(config.provider_env_var(config.PROVIDER_OPENAI), "OPENAI_API_KEY",
                    "OpenAI environment variable name")
        check_equal(config.provider_env_var(config.PROVIDER_GEMINI), "GEMINI_API_KEY",
                    "Gemini environment variable name")

        # A placeholder key must never count as configured.
        config.GEMINI_API_KEY = "your_api_key_here"
        config.OPENAI_API_KEY = "your_openai_key_here"
        check(not config.api_key_available(config.PROVIDER_GEMINI),
              "A placeholder Gemini key must not count as configured")
        check(not config.api_key_available(config.PROVIDER_OPENAI),
              "A placeholder OpenAI key must not count as configured")
        check(not config.any_api_key_available(),
              "Placeholders alone must not report a usable configuration")
        notes.append("placeholder keys rejected")

        # Masking must never reveal the middle of a key.
        config.OPENAI_API_KEY = "sk-selftest-1234567890-abcd"
        masked = config.masked_api_key(config.PROVIDER_OPENAI)
        check(config.OPENAI_API_KEY not in masked,
              "The masked value must not contain the whole key")
        check("*" in masked, "The masked value must be masked")
        check(config.any_api_key_available(),
              "One configured provider is enough for any_api_key_available")
        notes.append("keys masked, never displayed in full")

        # Each provider reports its own readiness.
        status = ai.api_status()
        check("providers" in status, "api_status must describe every provider")
        check_equal(sorted(status["providers"]), sorted(config.AI_PROVIDERS),
                    "api_status covers both providers")
        notes.append("status reported per provider")

        # Routing: an unconfigured provider fails with the right message.
        config.OPENAI_API_KEY = ""
        response = ai.generate("test", demo_mode=False, expect_json=True,
                               provider=config.PROVIDER_OPENAI, label="selftest")
        check(not response.ok, "A call to an unconfigured provider must fail")
        expected = ai.ERR_NO_KEY if ai.openai_sdk_available() else ai.ERR_SDK
        check_equal(response.error_kind, expected,
                    "The reason a ChatGPT call cannot run must be reported exactly")
        check_equal(response.model, config.OPENAI_MODEL,
                    "The OpenAI model must be reported on the failure")
        notes.append("routing to ChatGPT verified"
                     if ai.openai_sdk_available()
                     else "routing to ChatGPT verified (SDK not installed)")

        # OpenAI-style exceptions must be classified like the Gemini ones.
        class AuthenticationError(Exception):
            pass

        class RateLimitError(Exception):
            pass

        class APIConnectionError(Exception):
            pass

        check_equal(ai._classify(AuthenticationError("Incorrect API key provided")),
                    ai.ERR_AUTH, "OpenAI auth classification")
        check_equal(ai._classify(RateLimitError("insufficient_quota")),
                    ai.ERR_QUOTA, "OpenAI quota classification")
        check_equal(ai._classify(APIConnectionError("could not reach the server")),
                    ai.ERR_NETWORK, "OpenAI network classification")
        notes.append("OpenAI failures classified")

        # Demo mode stays isolated from whichever provider is selected.
        demo = ai.generate("test", demo_mode=True, demo_payload={"ok": True},
                           expect_json=True, provider=config.PROVIDER_OPENAI,
                           label="selftest")
        check(demo.ok and demo.demo,
              "Demo Mode must work regardless of the selected provider")
        notes.append("demo mode independent of provider")

        # Draft replies must go through the same routed entry point.
        import inspect

        from services import reply_service

        source = inspect.getsource(reply_service)
        check("ai_service.generate(" in source,
              "Draft reply generation must go through ai_service.generate so it "
              "follows the selected provider")
        notes.append("draft replies use the routed AI call")
    finally:
        config.GEMINI_API_KEY = original_gemini
        config.OPENAI_API_KEY = original_openai

    return "; ".join(notes)


# ===========================================================================
# 19. CBIC legislation source
# ===========================================================================
def test_cbic_source() -> str:
    """
    The CBIC client must map portal categories onto knowledge base folders,
    produce safe filenames, and report a failure rather than raise when the
    portal cannot be reached. The network is never required for this test.
    """
    from services import cbic_service as cbic

    check_equal(cbic.PORTAL_HOME, config.CBIC_PORTAL_URL,
                "The portal URL must match the configured source")

    # Every portal category must land in a real knowledge base folder.
    for portal_category, folder in cbic.CATEGORY_MAP.items():
        check(folder in config.KB_CATEGORIES,
              f"{portal_category} maps to unknown folder '{folder}'")

    act = cbic.CBICDocument(category="Act", title="Central Goods and Services Tax Act",
                            number="6", remote_path="acts/cgst-act.pdf")
    check_equal(act.kb_category, "acts", "Acts belong in the acts folder")
    check(act.available, "A document with a remote path is available")
    name = act.filename()
    check(name.endswith(".pdf"), "Downloads are saved as PDF")
    check("Central" in name,
          "A bare serial number must not become the filename - the title is used")
    for bad in '\\/:*?"<>|':
        check(bad not in name, f"Filename must not contain {bad!r}")

    circular = cbic.CBICDocument(
        category="Circular", title="Clarification on refund",
        number="Circular No. 125/44/2019-GST",
        remote_path="circulars/circular-125.pdf")
    check_equal(circular.kb_category, "circulars", "Circulars belong in circulars")
    check("125" in circular.filename(),
          "A descriptive number must be kept in the filename")

    missing = cbic.CBICDocument(category="Notification", title="Not published")
    check(not missing.available, "A document with no file must not be downloadable")
    check_equal(missing.source_url, cbic.PORTAL_HOME,
                "A document with no file falls back to the portal home page")

    # A portal failure must be reported, never raised at the user.
    original = cbic.list_documents
    try:
        def _fail(*_args, **_kwargs):
            raise cbic.CBICError("simulated portal outage")

        cbic.list_documents = _fail  # type: ignore[assignment]
        status = cbic.connection_status()
    finally:
        cbic.list_documents = original  # type: ignore[assignment]

    check(not status["reachable"], "A portal outage must be reported as unreachable")
    check("simulated portal outage" in status["message"],
          "The reason for the failure must be passed on to the user")
    check_equal(status["portal"], config.CBIC_PORTAL_URL, "Portal URL reported")

    return ("category mapping, filename safety and offline handling verified "
            f"({len(cbic.CATEGORY_MAP)} portal categories)")


TESTS: List[Tuple[str, Callable[[], str]]] = [
    ("GSTIN validation", test_gstin_validation),
    ("PAN validation", test_pan_validation),
    ("Indian currency formatting", test_currency_formatting),
    ("Demand calculation", test_demand_calculation),
    ("Deadline calculation", test_deadline_calculations),
    ("Date and financial year", test_date_and_fy),
    ("Database", test_database),
    ("PDF extraction", test_pdf_extraction),
    ("Malformed AI output", test_malformed_ai_json),
    ("AI error handling", test_ai_error_handling),
    ("Notice analysis pipeline", test_notice_analysis_pipeline),
    ("Knowledge base retrieval", test_rag_retrieval),
    ("Security and roles", test_security_and_roles),
    ("Exports", test_exports),
    ("Prompt templates", test_prompts),
    ("Dialog visibility", test_dialog_visibility),
    ("Demonstration data", test_demo_data),
    ("AI provider layer", test_ai_providers),
    ("CBIC legislation source", test_cbic_source),
]


def run_all(verbose: bool = False) -> Dict[str, Any]:
    """
    Run every self test and return ``{passed, failed, skipped, report, results}``.
    """
    config.ensure_directories()
    lines: List[str] = []
    passed = failed = skipped = 0
    results: List[Dict[str, str]] = []

    lines.append(f"{config.APP_NAME} v{config.APP_VERSION} - self tests")
    lines.append("=" * 78)
    lines.append("")

    for name, test in TESTS:
        try:
            detail = test() or ""
            if detail.startswith("skipped"):
                skipped += 1
                status = "SKIP"
            else:
                passed += 1
                status = "PASS"
        except TestFailure as exc:
            failed += 1
            status = "FAIL"
            detail = str(exc)
        except Exception as exc:  # noqa: BLE001 - a broken test must not stop the run
            failed += 1
            status = "ERROR"
            detail = f"{type(exc).__name__}: {exc}"
            if verbose:
                detail += "\n" + traceback.format_exc()
        lines.append(f"[{status:5}] {name}")
        if detail:
            for chunk in detail.split("\n"):
                lines.append(f"         {chunk}")
        lines.append("")
        results.append({"name": name, "status": status, "detail": detail})

    lines.append("=" * 78)
    lines.append(f"Total: {len(TESTS)}   Passed: {passed}   "
                 f"Failed: {failed}   Skipped: {skipped}")
    if failed == 0:
        lines.append("All self tests passed.")
    else:
        lines.append("One or more self tests failed - see the detail above and "
                     "logs/app.log.")

    return {"passed": passed, "failed": failed, "skipped": skipped,
            "report": "\n".join(lines), "results": results}


def main() -> int:
    outcome = run_all(verbose=True)
    print(outcome["report"])
    return 0 if outcome["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
