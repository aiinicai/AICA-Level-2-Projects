"""
tests.test_ca_gst_copilot
=========================
pytest wrapper around the built-in self tests, plus a few focused unit
tests.  The application does not require pytest -- ``python -m
tests.self_tests`` runs the same checks -- but this module lets the
project be verified with::

    pytest tests -q
"""

from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import pytest  # noqa: E402  (only needed when running under pytest)

from tests import self_tests  # noqa: E402


# ---------------------------------------------------------------------------
# Every built-in self test as an individual pytest case
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("name,test", self_tests.TESTS,
                         ids=[name for name, _ in self_tests.TESTS])
def test_self_test(name, test):
    detail = test()
    if isinstance(detail, str) and detail.startswith("skipped"):
        pytest.skip(detail)


# ---------------------------------------------------------------------------
# Focused unit tests
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("value,expected", [
    (1055000, "₹10,55,000"),
    (12550000, "₹1,25,50,000"),
    (100, "₹100"),
    (0, "₹0"),
    (-2500, "-₹2,500"),
])
def test_indian_currency(value, expected):
    from utils.formatters import format_currency

    assert format_currency(value) == expected


@pytest.mark.parametrize("text,expected", [
    ("Rs. 12,345.50", Decimal("12345.50")),
    ("₹1,05,50,000", Decimal("10550000")),
    ("Rs 1,00,000/-", Decimal("100000")),
    ("(5,000)", Decimal("-5000")),
    ("not stated", None),
])
def test_amount_parsing(text, expected):
    from utils.calculations import to_decimal

    assert to_decimal(text) == expected


def test_total_demand_arithmetic():
    from utils.calculations import compute_demand

    demand = compute_demand({
        "cgst": 100, "sgst": 100, "igst": 50, "cess": 10,
        "interest": 25, "penalty": 15, "other_amount": 5,
    })
    assert demand.total_tax == Decimal("260.00")
    assert demand.total_exposure == Decimal("305.00")


@pytest.mark.parametrize("gstin,valid", [
    ("27AABCA1234K1ZY", True),
    ("27AABCA1234K1Z9", False),   # bad checksum
    ("27AABCA1234K1Z", False),    # too short
    ("XX AABCA1234K1ZY", False),  # malformed
    ("", False),
])
def test_gstin(gstin, valid):
    from utils.validators import is_valid_gstin

    assert is_valid_gstin(gstin) is valid


def test_malformed_ai_response_returns_none():
    from utils.helpers import extract_json

    assert extract_json("this is not json") is None
    assert extract_json('{"ok": true}') == {"ok": True}


def test_demo_mode_never_calls_the_api(monkeypatch):
    """Demo mode must work even with no key and no network."""
    import config
    from services import ai_service

    monkeypatch.setattr(config, "GEMINI_API_KEY", "")
    response = ai_service.generate("anything", demo_mode=True,
                                   demo_payload={"sample": 1})
    assert response.ok and response.demo
    assert response.data == {"sample": 1}


def test_missing_api_key_is_reported(monkeypatch):
    import config
    from services import ai_service

    monkeypatch.setattr(config, "GEMINI_API_KEY", "")
    response = ai_service.generate("anything", demo_mode=False)
    assert not response.ok
    assert response.error_kind == ai_service.ERR_NO_KEY
    assert "GEMINI_API_KEY" in response.friendly_error
