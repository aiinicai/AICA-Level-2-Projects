"""
config.py
=========
Central configuration for CA-GST Copilot.

Holds application constants, folder locations, theme colours and runtime
settings.  No secrets are stored here -- the Gemini API key is read from
the ``.env`` file (see ``.env.example``).
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dotenv is a declared requirement
    def load_dotenv(*_args, **_kwargs):  # type: ignore
        return False


# --------------------------------------------------------------------------
# Application identity
# --------------------------------------------------------------------------
APP_NAME = "CA-GST Copilot"
APP_TAGLINE = "AI-Powered GST Litigation Assistant"
APP_VERSION = "3.0.0"
APP_BUILD = "2026-08-30"
APP_RELEASE_NAME = "CBIC legislation + multi-provider AI"
APP_FOOTER = "CA-GST Copilot  |  AI-Assisted Professional Tool  |  Verify before reliance"

# --------------------------------------------------------------------------
# Branding
# --------------------------------------------------------------------------
APP_AUTHOR = "CA Bharat Jain"
APP_AUTHOR_CONTACT = "8107910067"
APP_BRANDING = f"Built by {APP_AUTHOR}  |  {APP_AUTHOR_CONTACT}"

# Shown wherever the user needs to confirm which build they are running.
APP_VERSION_LABEL = f"v{APP_VERSION}  (build {APP_BUILD} - {APP_RELEASE_NAME})"

AI_DISCLAIMER = (
    "AI-generated content may contain errors. Verify all facts, sections, circulars, "
    "notifications, judgments, computations and legal conclusions before professional "
    "use. Final responsibility remains with the Chartered Accountant."
)

FULL_DISCLAIMER = (
    "This application is designed to assist Chartered Accountants and tax professionals. "
    "AI-generated analysis, research and drafting may contain errors or omissions. "
    "Users must independently verify all factual, statutory and judicial references "
    "before professional use or filing.\n\n"
    "The application does not connect to the GST portal and does not file anything on "
    "behalf of the taxpayer. All outputs require independent professional review and "
    "approval by a Chartered Accountant before reliance or submission."
)


# --------------------------------------------------------------------------
# Paths (all relative to the project root -- never hardcode absolute paths)
# --------------------------------------------------------------------------
FROZEN = bool(getattr(sys, "frozen", False))


def _base_dir() -> Path:
    """
    The folder the application treats as its own.

    Running from source this is the project folder.  Running as a
    PyInstaller executable it is the folder holding the .exe, so that the
    database, logs, uploads, exports, prompts and knowledge base sit
    beside the executable and survive a rebuild -- never inside the
    read-only bundle.
    """
    if FROZEN:
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def bundled_dir() -> Path:
    """
    The folder holding read-only files shipped inside the bundle.

    Identical to :data:`BASE_DIR` when running from source.
    """
    if FROZEN:
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    return Path(__file__).resolve().parent


BASE_DIR = _base_dir()


def resource_path(relative_path: str | Path) -> Path:
    """
    Locate a read-only file that ships with the application.

    Works both in development and inside a PyInstaller bundle: the bundled
    copy is preferred, and the project folder is used as a fallback.
    """
    candidate = bundled_dir() / relative_path
    if candidate.exists():
        return candidate
    return Path(__file__).resolve().parent / relative_path

DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads"
EXPORT_DIR = BASE_DIR / "exports"
LOG_DIR = BASE_DIR / "logs"
PROMPT_DIR = BASE_DIR / "prompts"
KNOWLEDGE_BASE_DIR = BASE_DIR / "knowledge_base"
SAMPLE_DATA_DIR = BASE_DIR / "sample_data"
SAMPLE_NOTICE_DIR = SAMPLE_DATA_DIR / "notices"

DB_PATH = DATA_DIR / "ca_gst_copilot.db"
LOG_FILE = LOG_DIR / "app.log"
SETTINGS_FILE = DATA_DIR / "settings.json"

KB_CATEGORIES = [
    "acts",
    "rules",
    "circulars",
    "notifications",
    "case_laws",
    "internal_research",
]


def ensure_directories() -> None:
    """Create every runtime folder the application expects."""
    folders = [
        DATA_DIR, UPLOAD_DIR, EXPORT_DIR, LOG_DIR,
        PROMPT_DIR, KNOWLEDGE_BASE_DIR, SAMPLE_DATA_DIR, SAMPLE_NOTICE_DIR,
    ]
    folders += [KNOWLEDGE_BASE_DIR / c for c in KB_CATEGORIES]
    for folder in folders:
        folder.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------
# Environment / AI configuration
# --------------------------------------------------------------------------
load_dotenv(BASE_DIR / ".env")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.6-flash").strip() or "gemini-3.6-flash"
GEMINI_TIMEOUT = int(os.getenv("GEMINI_TIMEOUT", "120") or 120)

# OpenAI / ChatGPT is supported as an alternative provider.
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"
OPENAI_TIMEOUT = int(os.getenv("OPENAI_TIMEOUT", "120") or 120)

PROVIDER_GEMINI = "Gemini"
PROVIDER_OPENAI = "ChatGPT (OpenAI)"
AI_PROVIDERS = [PROVIDER_GEMINI, PROVIDER_OPENAI]

_PLACEHOLDERS = {"your_api_key_here", "your_openai_key_here", "changeme", "none", ""}


def _key_is_real(key: str) -> bool:
    return bool(key) and key.strip().lower() not in _PLACEHOLDERS


def provider_key(provider: str) -> str:
    """The configured key for a provider (never displayed in full)."""
    return OPENAI_API_KEY if provider == PROVIDER_OPENAI else GEMINI_API_KEY


def provider_model(provider: str) -> str:
    return OPENAI_MODEL if provider == PROVIDER_OPENAI else GEMINI_MODEL


def provider_env_var(provider: str) -> str:
    return "OPENAI_API_KEY" if provider == PROVIDER_OPENAI else "GEMINI_API_KEY"


def api_key_available(provider: str = "") -> bool:
    """
    True when a usable key is configured.

    With no provider given, the currently selected provider is checked.
    """
    return _key_is_real(provider_key(provider or current_provider()))


def any_api_key_available() -> bool:
    """True when at least one provider is configured."""
    return any(_key_is_real(provider_key(p)) for p in AI_PROVIDERS)


def mask(key: str) -> str:
    if not _key_is_real(key):
        return "Not configured"
    if len(key) <= 8:
        return "*" * len(key)
    return key[:4] + "*" * 12 + key[-4:]


def masked_api_key(provider: str = "") -> str:
    """A masked representation of a provider's key -- never the full value."""
    return mask(provider_key(provider or current_provider()))


def current_provider() -> str:
    """The provider chosen in Settings, falling back to Gemini."""
    provider = load_settings().get("ai_provider", PROVIDER_GEMINI)
    return provider if provider in AI_PROVIDERS else PROVIDER_GEMINI


# --------------------------------------------------------------------------
# User-editable settings (persisted to data/settings.json)
# --------------------------------------------------------------------------
DEFAULT_SETTINGS: Dict[str, Any] = {
    "demo_mode": True,           # start in Mock AI mode so demos never fail
    "ai_provider": "Gemini",     # or "ChatGPT (OpenAI)"
    "cbic_auto_index": True,     # index CBIC downloads into the knowledge base
    "firm_name": "",
    "default_state": "",
    "rag_top_k": 6,
    "rag_chunk_size": 1200,
    "deadline_alert_days": 7,
}


def load_settings() -> Dict[str, Any]:
    """Read the settings file, falling back to defaults on any problem."""
    settings = dict(DEFAULT_SETTINGS)
    try:
        if SETTINGS_FILE.exists():
            stored = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                settings.update({k: v for k, v in stored.items() if k in DEFAULT_SETTINGS})
    except (OSError, json.JSONDecodeError, ValueError):
        pass
    return settings


def save_settings(settings: Dict[str, Any]) -> bool:
    """Persist non-sensitive settings.  Returns True on success."""
    try:
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        clean = {k: v for k, v in settings.items() if k in DEFAULT_SETTINGS}
        SETTINGS_FILE.write_text(json.dumps(clean, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# Demonstration mode
# --------------------------------------------------------------------------
DEMO_BANNER_TEXT = "AICA DEMONSTRATION MODE - FICTIONAL SAMPLE DATA"
DEMO_EXPORT_WATERMARK = "DEMO / SAMPLE DATA - fictional records for demonstration only"
DEMO_NOTICE_FOOTER = (
    "Sample Notice for AICA Demonstration Only - Not a Real GST Document"
)
DEMO_KB_FOOTER = (
    "Educational Demo Material - Verify with Current GST Law Before Reliance"
)

# The case highlighted for the live walkthrough
FEATURED_DEMO_NOTICE_NUMBER = "DEMO/DRC-01/2024-25/0003"


# --------------------------------------------------------------------------
# CBIC legislation source
# --------------------------------------------------------------------------
CBIC_PORTAL_URL = "https://www.cbic.gov.in/entities/gst"
CBIC_API_URL = "https://taxinformation.cbic.gov.in"
CBIC_SOURCE_NOTE = (
    "Legislation downloaded from the CBIC Tax Information Portal. Always "
    "confirm the version in force for the period under examination."
)


# --------------------------------------------------------------------------
# Domain dropdown values
# --------------------------------------------------------------------------
NOTICE_TYPES = [
    "ASMT-10", "DRC-01A", "DRC-01", "DRC-07", "SCN", "Summons",
    "Audit Notice", "Refund Notice", "Registration Notice",
    "Appeal Order", "Adjudication Order", "Other",
]

CASE_STATUSES = [
    "New", "Under Analysis", "Information Pending", "Drafting",
    "Under Review", "Revision Required", "CA Approved", "Filed",
    "Hearing Pending", "Closed",
]

OPEN_STATUSES = [s for s in CASE_STATUSES if s != "Closed"]

RISK_LEVELS = ["High", "Medium", "Low", "Review Required"]

CASE_STAGES = [
    "Notice Received", "Analysis", "Information Gathering", "Research",
    "Drafting", "Review", "Approved", "Filed", "Hearing",
    "Order Received", "Closed",
]

DRAFT_STATUSES = [
    "AI Generated", "Prepared", "Manager Reviewed",
    "Revision Required", "CA Approved", "Final",
]

REQUIREMENT_STATUSES = ["Pending", "Received", "Not Applicable", "Clarification Required"]
REQUIREMENT_TYPES = ["Mandatory", "Conditional"]

ENTITY_TYPES = [
    "Private Limited Company", "Public Limited Company", "LLP", "Partnership Firm",
    "Proprietorship", "HUF", "Trust", "Society", "AOP/BOI",
    "Government Department", "Other",
]

USER_ROLES = ["Admin / Partner", "Manager", "Team Member", "Reviewer", "Viewer"]

# Roles permitted to mark a draft CA Approved / Final
APPROVAL_ROLES = {"Admin / Partner", "Reviewer"}
# Roles with read-only access
READONLY_ROLES = {"Viewer"}

INDIAN_STATES = {
    "01": "Jammu and Kashmir", "02": "Himachal Pradesh", "03": "Punjab",
    "04": "Chandigarh", "05": "Uttarakhand", "06": "Haryana", "07": "Delhi",
    "08": "Rajasthan", "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim",
    "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur", "15": "Mizoram",
    "16": "Tripura", "17": "Meghalaya", "18": "Assam", "19": "West Bengal",
    "20": "Jharkhand", "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh",
    "24": "Gujarat", "25": "Daman and Diu",
    "26": "Dadra and Nagar Haveli and Daman and Diu",
    "27": "Maharashtra", "28": "Andhra Pradesh (Old)", "29": "Karnataka",
    "30": "Goa", "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu",
    "34": "Puducherry", "35": "Andaman and Nicobar Islands", "36": "Telangana",
    "37": "Andhra Pradesh", "38": "Ladakh", "97": "Other Territory",
    "99": "Centre Jurisdiction",
}

STATE_NAMES = sorted(set(INDIAN_STATES.values()))

FINANCIAL_YEARS = [
    "2017-18", "2018-19", "2019-20", "2020-21", "2021-22",
    "2022-23", "2023-24", "2024-25", "2025-26",
]


# --------------------------------------------------------------------------
# Professional light theme palette
# --------------------------------------------------------------------------
class Theme:
    """Colour tokens for a restrained, professional legal-tech look."""

    BG = "#F4F6F9"
    SURFACE = "#FFFFFF"
    SURFACE_ALT = "#EDF1F6"
    SIDEBAR = "#14304F"
    SIDEBAR_HOVER = "#1E4570"
    SIDEBAR_ACTIVE = "#2C6DA8"
    TOPBAR = "#1B3A5C"

    PRIMARY = "#1F5C99"
    PRIMARY_HOVER = "#17497A"
    SECONDARY = "#5A6B7D"
    SECONDARY_HOVER = "#47566A"

    TEXT = "#1C2733"
    TEXT_MUTED = "#5F6E7E"
    TEXT_ON_DARK = "#EAF1F8"
    BORDER = "#D4DCE5"

    SUCCESS = "#1F7A44"
    WARNING = "#B26A00"
    DANGER = "#B02A2A"
    INFO = "#1F5C99"
    NEUTRAL = "#5A6B7D"

    SUCCESS_BG = "#E4F2EA"
    WARNING_BG = "#FBF0DC"
    DANGER_BG = "#F8E5E5"
    INFO_BG = "#E4EEF8"
    NEUTRAL_BG = "#E9EDF2"

    FONT_FAMILY = "Segoe UI"
    FONT_MONO = "Consolas"


RISK_COLORS = {
    "High": (Theme.DANGER, Theme.DANGER_BG),
    "Medium": (Theme.WARNING, Theme.WARNING_BG),
    "Low": (Theme.SUCCESS, Theme.SUCCESS_BG),
    "Review Required": (Theme.INFO, Theme.INFO_BG),
}

STATUS_COLORS = {
    "New": (Theme.INFO, Theme.INFO_BG),
    "Under Analysis": (Theme.INFO, Theme.INFO_BG),
    "Information Pending": (Theme.WARNING, Theme.WARNING_BG),
    "Drafting": (Theme.WARNING, Theme.WARNING_BG),
    "Under Review": (Theme.WARNING, Theme.WARNING_BG),
    "Revision Required": (Theme.DANGER, Theme.DANGER_BG),
    "CA Approved": (Theme.SUCCESS, Theme.SUCCESS_BG),
    "Filed": (Theme.SUCCESS, Theme.SUCCESS_BG),
    "Hearing Pending": (Theme.WARNING, Theme.WARNING_BG),
    "Closed": (Theme.NEUTRAL, Theme.NEUTRAL_BG),
}
