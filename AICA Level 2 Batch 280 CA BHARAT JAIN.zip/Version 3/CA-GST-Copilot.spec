# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller build specification for CA-GST Copilot.

Build with:

    pyinstaller --noconfirm CA-GST-Copilot.spec

The result is a single windowed executable in ``dist/``.

Notes
-----
* The screens are loaded dynamically by name from ``ui.main_window.NAV_ITEMS``
  via ``importlib``, so PyInstaller's static analysis cannot see them. Every
  page module is therefore listed explicitly in ``hiddenimports``.
* Only the application icon is bundled as data. Everything else the demo
  needs -- prompt templates, the eight sample notice PDFs, the demonstration
  knowledge-base notes -- is **generated at runtime** into folders beside the
  executable. Bundling read-only copies would be worse: PyInstaller unpacks
  them to a temporary folder that is wiped on exit, so the knowledge base
  could not be indexed and the sample notices could not be re-generated.
  Generating them keeps every demo asset writable and repairable from within
  the application (Settings > Load Demo Data / Regenerate Notice PDFs).
"""

from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_data_files, collect_submodules

block_cipher = None

datas = []
binaries = []
hiddenimports = []

# --- third-party packages that carry data files or plugins -------------------
for package in ("customtkinter", "reportlab", "pymupdf", "fitz"):
    try:
        pkg_datas, pkg_binaries, pkg_hidden = collect_all(package)
        datas += pkg_datas
        binaries += pkg_binaries
        hiddenimports += pkg_hidden
    except Exception:          # a package that is not installed is not fatal
        pass

# python-docx ships its default template as package data
try:
    datas += collect_data_files("docx")
except Exception:
    pass

# matplotlib needs mpl-data plus the Tk backend
try:
    datas += collect_data_files("matplotlib")
except Exception:
    pass

# the AI SDKs pull in a number of submodules lazily
for package in ("google.genai", "google.auth", "openai"):
    try:
        hiddenimports += collect_submodules(package)
    except Exception:
        pass

# certifi ships its CA bundle as package data; truststore reads the Windows store
for package in ("certifi", "truststore"):
    try:
        pkg_datas, pkg_binaries, pkg_hidden = collect_all(package)
        datas += pkg_datas
        binaries += pkg_binaries
        hiddenimports += pkg_hidden
    except Exception:
        pass

# --- the application icon, if it has been generated --------------------------
_icon = Path("build_assets/app_icon.ico")
if _icon.exists():
    datas += [(str(_icon), "build_assets")]

# --- application screens loaded dynamically by importlib ---------------------
hiddenimports += [
    "ui.dashboard",
    "ui.clients",
    "ui.cases",
    "ui.notice_analyzer",
    "ui.issue_analysis",
    "ui.requirements_generator",
    "ui.research",
    "ui.draft_reply",
    "ui.knowledge_base",
    "ui.reports",
    "ui.settings",
    "ui.guided_demo",
    "ui.base_page",
    "ui.widgets",
    "ui.login",
    "tests.self_tests",
    # The demonstration modules are reached through late imports.
    "services.demo_data",
    "services.demo_scenarios",
    "services.demo_kb",
    "services.cbic_service",
]

# --- other imports PyInstaller cannot infer ----------------------------------
hiddenimports += [
    "matplotlib.backends.backend_tkagg",
    "PIL._tkinter_finder",
    "openpyxl",
    "docx",
    "dotenv",
    "requests",
    "truststore",
    "sqlite3",
    "decimal",
]

# --- keep the bundle lean ----------------------------------------------------
excludes = [
    "PyQt5", "PyQt6", "PySide2", "PySide6", "wx",
    "IPython", "jupyter", "notebook", "nbconvert", "nbformat",
    "pandas", "scipy", "sympy", "pytest", "sphinx", "setuptools",
    "matplotlib.tests", "numpy.tests", "test", "tkinter.test",
]

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="CA-GST-Copilot-v3",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,                 # windowed desktop application
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="build_assets/app_icon.ico",
)
