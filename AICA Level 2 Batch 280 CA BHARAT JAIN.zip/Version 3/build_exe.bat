@echo off
REM ---------------------------------------------------------------------------
REM CA-GST Copilot - build the Windows executable
REM
REM Produces  dist\CA-GST-Copilot-v3.exe  (a single windowed executable).
REM Run this from the project folder:   build_exe.bat
REM ---------------------------------------------------------------------------

echo.
echo ==========================================================
echo   CA-GST Copilot - building the Windows executable
echo ==========================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo Python was not found on the PATH. Install Python 3.10+ and try again.
    pause
    exit /b 1
)

echo [1/3] Checking build dependencies...
python -m pip install --quiet --upgrade pyinstaller
if errorlevel 1 (
    echo Could not install PyInstaller.
    pause
    exit /b 1
)
python -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo Could not install the application dependencies.
    pause
    exit /b 1
)

echo [2/3] Removing the previous build...
if exist build rmdir /s /q build

REM Only the executable is removed. If the application has been run from
REM dist\, its data\ logs\ prompts\ knowledge_base\ uploads\ exports\ and
REM sample_data\ folders live there too, and deleting dist\ wholesale would
REM destroy the SQLite database along with every client, case and draft.
if exist "dist\CA-GST-Copilot-v3.exe" del /q "dist\CA-GST-Copilot-v3.exe"
if exist "dist\data\ca_gst_copilot.db" (
    echo.
    echo   NOTE: an existing database was found at dist\data\ca_gst_copilot.db
    echo         It has been left untouched. Only the .exe is being replaced.
    echo.
)

echo [3/3] Building (this usually takes two to five minutes)...
python -m PyInstaller --noconfirm --clean CA-GST-Copilot.spec
if errorlevel 1 (
    echo.
    echo BUILD FAILED. See the messages above.
    pause
    exit /b 1
)

echo.
echo ==========================================================
echo   Build complete:  dist\CA-GST-Copilot-v3.exe
echo ==========================================================
echo.
echo   Copy the .exe anywhere you like. On first run it creates
echo   data\, logs\, uploads\, exports\, prompts\, sample_data\
echo   and knowledge_base\ beside itself.
echo.
echo   To use a live AI API (Gemini or ChatGPT), place your .env
echo   file in the same folder as the .exe and choose the provider
echo   in Settings. Import from CBIC needs internet access but no key.
echo.
pause
