"""
utils.calculations
==================
The Python calculation engine.

**All arithmetic in this application is performed here, in Python.**
The AI model is never trusted with computation -- it only extracts the
component figures, which are then totalled with :class:`decimal.Decimal`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Dict, Iterable, List, Optional, Sequence

from utils.validators import parse_date

TWO_PLACES = Decimal("0.01")
ZERO = Decimal("0")

# First signed number in a string, tolerating Indian digit grouping
_NUMBER_RE = re.compile(r"-?\d[\d,]*(?:\.\d+)?")

# Component keys of a GST demand, in presentation order
DEMAND_COMPONENTS = ("cgst", "sgst", "igst", "cess")
OTHER_COMPONENTS = ("interest", "penalty", "other_amount")


def to_decimal(value, default: Optional[Decimal] = None) -> Optional[Decimal]:
    """
    Convert loosely-typed input into a :class:`Decimal`.

    Handles ``"Rs. 12,34,567.00"``, ``"Rs 1,00,000/-"``, ``"(5,000)"``,
    ``"12345"``, ``12345.5`` and ``None``.  Returns ``default`` (``None``
    unless overridden) when no number can be found.
    """
    if value is None or value == "":
        return default
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        try:
            return Decimal(str(value))
        except InvalidOperation:
            return default

    text = str(value).strip()
    if not text:
        return default

    # Accountancy convention: a parenthesised amount is negative.
    parenthesised = text.startswith("(") and text.endswith(")")

    # Pull out the first number, ignoring currency symbols, words such as
    # "Rs." or "INR", and trailing markers such as "/-".
    match = _NUMBER_RE.search(text.replace("₹", " "))
    if match is None:
        return default
    try:
        amount = Decimal(match.group(0).replace(",", ""))
    except InvalidOperation:
        return default
    return -amount if parenthesised and amount > 0 else amount


def money(value) -> Decimal:
    """Convert to Decimal, defaulting to zero, rounded to two places."""
    amount = to_decimal(value, ZERO) or ZERO
    return amount.quantize(TWO_PLACES, rounding=ROUND_HALF_UP)


# ---------------------------------------------------------------------------
# Demand computation
# ---------------------------------------------------------------------------
@dataclass
class DemandSummary:
    """A fully computed GST demand breakup."""

    cgst: Decimal = ZERO
    sgst: Decimal = ZERO
    igst: Decimal = ZERO
    cess: Decimal = ZERO
    interest: Decimal = ZERO
    penalty: Decimal = ZERO
    other_amount: Decimal = ZERO

    @property
    def total_tax(self) -> Decimal:
        """CGST + SGST + IGST + Cess."""
        return money(self.cgst + self.sgst + self.igst + self.cess)

    @property
    def total_exposure(self) -> Decimal:
        """Total tax + interest + penalty + other amounts."""
        return money(self.total_tax + self.interest + self.penalty + self.other_amount)

    def as_dict(self) -> Dict[str, Decimal]:
        return {
            "cgst": self.cgst, "sgst": self.sgst, "igst": self.igst, "cess": self.cess,
            "interest": self.interest, "penalty": self.penalty,
            "other_amount": self.other_amount,
            "total_tax": self.total_tax, "total_exposure": self.total_exposure,
        }

    def as_float_dict(self) -> Dict[str, float]:
        """Float view, used when writing to SQLite."""
        return {k: float(v) for k, v in self.as_dict().items()}

    def rows(self) -> List[tuple]:
        """(label, amount, is_total) rows for the Demand Summary table."""
        return [
            ("CGST", self.cgst, False),
            ("SGST", self.sgst, False),
            ("IGST", self.igst, False),
            ("Cess", self.cess, False),
            ("Total Tax", self.total_tax, True),
            ("Interest", self.interest, False),
            ("Penalty", self.penalty, False),
            ("Other", self.other_amount, False),
            ("Total Exposure", self.total_exposure, True),
        ]


def compute_demand(source: dict) -> DemandSummary:
    """
    Build a :class:`DemandSummary` from any mapping holding the component keys.

    Missing or unparseable components are treated as zero -- never as an error.
    """
    source = source or {}
    return DemandSummary(
        cgst=money(source.get("cgst")),
        sgst=money(source.get("sgst")),
        igst=money(source.get("igst")),
        cess=money(source.get("cess")),
        interest=money(source.get("interest")),
        penalty=money(source.get("penalty")),
        other_amount=money(source.get("other_amount")),
    )


def total_tax(source: dict) -> Decimal:
    """Convenience wrapper: total tax component of a demand mapping."""
    return compute_demand(source).total_tax


def total_demand(source: dict) -> Decimal:
    """Convenience wrapper: total exposure of a demand mapping."""
    return compute_demand(source).total_exposure


def sum_amounts(values: Iterable) -> Decimal:
    """Total an iterable of loosely-typed amounts."""
    return money(sum((money(v) for v in values), ZERO))


def issue_amount_total(issues: Sequence[dict]) -> Decimal:
    """Total the ``amount`` field across a list of issue dictionaries."""
    return sum_amounts((issue or {}).get("amount") for issue in (issues or []))


def reconcile_issue_amounts(
    demand: DemandSummary, issues: Sequence[dict], tolerance: Decimal = Decimal("1")
) -> Dict[str, object]:
    """
    Compare the sum of issue-wise amounts with the headline demand.

    Issue-wise figures in a notice are usually stated net of interest and
    penalty, so the sum is first compared with total tax and only then with
    total exposure.  A material difference is surfaced to the user rather
    than silently corrected -- the CA decides which figure is right.
    """
    issue_total = issue_amount_total(issues)
    tax_difference = money(demand.total_tax - issue_total)
    exposure_difference = money(demand.total_exposure - issue_total)

    if abs(tax_difference) <= tolerance:
        matched, basis, difference = True, "total tax", tax_difference
    elif abs(exposure_difference) <= tolerance:
        matched, basis, difference = True, "total exposure", exposure_difference
    else:
        matched, basis, difference = False, "total tax", tax_difference

    return {
        "issue_total": issue_total,
        "demand_total": demand.total_tax,
        "exposure_total": demand.total_exposure,
        "difference": difference,
        "basis": basis,
        "matched": matched or issue_total == ZERO,
        "checked": issue_total != ZERO,
    }


# ---------------------------------------------------------------------------
# Deadline arithmetic
# ---------------------------------------------------------------------------
def days_remaining(due_date, today: Optional[date] = None) -> Optional[int]:
    """
    Days left until ``due_date``.  Negative when overdue, ``None`` when unknown.
    """
    parsed = parse_date(due_date) if not isinstance(due_date, date) else due_date
    if parsed is None:
        return None
    reference = today or date.today()
    return (parsed - reference).days


def is_overdue(due_date, today: Optional[date] = None) -> bool:
    """True when the reply due date has already passed."""
    remaining = days_remaining(due_date, today)
    return remaining is not None and remaining < 0


def deadline_label(due_date, today: Optional[date] = None) -> str:
    """Human phrasing of the time left to reply."""
    remaining = days_remaining(due_date, today)
    if remaining is None:
        return "Not set"
    if remaining < 0:
        return f"Overdue by {abs(remaining)} day{'s' if abs(remaining) != 1 else ''}"
    if remaining == 0:
        return "Due today"
    if remaining == 1:
        return "1 day left"
    return f"{remaining} days left"


def deadline_severity(due_date, alert_days: int = 7, today: Optional[date] = None) -> str:
    """Classify a deadline as ``overdue`` / ``urgent`` / ``soon`` / ``normal`` / ``none``."""
    remaining = days_remaining(due_date, today)
    if remaining is None:
        return "none"
    if remaining < 0:
        return "overdue"
    if remaining <= 3:
        return "urgent"
    if remaining <= alert_days:
        return "soon"
    return "normal"


# ---------------------------------------------------------------------------
# Portfolio aggregation used by the dashboard and reports
# ---------------------------------------------------------------------------
@dataclass
class PortfolioTotals:
    """Aggregated exposure figures across a set of cases."""

    total_tax: Decimal = ZERO
    interest: Decimal = ZERO
    penalty: Decimal = ZERO
    other_amount: Decimal = ZERO
    total_exposure: Decimal = ZERO
    case_count: int = 0
    by_status: Dict[str, int] = field(default_factory=dict)
    by_notice_type: Dict[str, int] = field(default_factory=dict)
    by_risk: Dict[str, Decimal] = field(default_factory=dict)
    by_client: Dict[str, Decimal] = field(default_factory=dict)


def aggregate_cases(rows: Sequence[dict]) -> PortfolioTotals:
    """
    Roll up a list of case rows (each optionally carrying demand columns)
    into dashboard-ready totals.
    """
    totals = PortfolioTotals()
    for row in rows or []:
        demand = compute_demand(row)
        totals.total_tax = money(totals.total_tax + demand.total_tax)
        totals.interest = money(totals.interest + demand.interest)
        totals.penalty = money(totals.penalty + demand.penalty)
        totals.other_amount = money(totals.other_amount + demand.other_amount)
        totals.total_exposure = money(totals.total_exposure + demand.total_exposure)
        totals.case_count += 1

        status = row.get("status") or "Unspecified"
        totals.by_status[status] = totals.by_status.get(status, 0) + 1

        notice_type = row.get("notice_type") or "Other"
        totals.by_notice_type[notice_type] = totals.by_notice_type.get(notice_type, 0) + 1

        risk = row.get("risk_level") or "Review Required"
        totals.by_risk[risk] = money(totals.by_risk.get(risk, ZERO) + demand.total_exposure)

        client = row.get("client_name") or f"Client {row.get('client_id', '')}"
        totals.by_client[client] = money(totals.by_client.get(client, ZERO) + demand.total_exposure)

    return totals


def client_exposure(rows: Sequence[dict], client_id: int) -> Decimal:
    """Total exposure across every case belonging to one client."""
    return sum_amounts(
        compute_demand(row).total_exposure
        for row in rows or []
        if row.get("client_id") == client_id
    )


def percentage(part, whole) -> Decimal:
    """Safe percentage helper (returns zero when the denominator is zero)."""
    part_d, whole_d = money(part), money(whole)
    if whole_d == ZERO:
        return ZERO
    return money(part_d / whole_d * Decimal("100"))
