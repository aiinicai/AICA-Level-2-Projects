"""
utils.logger
============
Application-wide logging.  Everything is written to ``logs/app.log``
with rotation so the file never grows without bound.
"""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler

import config

_CONFIGURED = False

_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-22s | %(message)s"
_DATEFMT = "%d-%m-%Y %H:%M:%S"


def setup_logging(level: int = logging.INFO) -> None:
    """Configure the root logger once, for the whole application."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    config.LOG_DIR.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(level)

    formatter = logging.Formatter(_FORMAT, datefmt=_DATEFMT)

    try:
        file_handler = RotatingFileHandler(
            config.LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(level)
        root.addHandler(file_handler)
    except OSError:
        # Logging must never take the application down.
        pass

    console = logging.StreamHandler(stream=sys.stdout)
    console.setFormatter(formatter)
    console.setLevel(logging.WARNING)
    root.addHandler(console)

    # Third-party libraries are noisy at INFO level.
    for noisy in ("PIL", "matplotlib", "httpx", "httpcore", "google_genai", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a module logger, configuring logging on first use."""
    setup_logging()
    return logging.getLogger(name)
