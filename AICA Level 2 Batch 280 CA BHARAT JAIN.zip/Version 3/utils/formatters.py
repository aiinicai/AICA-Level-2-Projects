"""
utils.formatters
================
Presentation helpers: Indian currency grouping, Indian date format,
text truncation and JSON/list normalisation for display.
"""

from __future__ import annotations

import json
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterable, List, Optional

from utils.calculations import ZERO, money
from utils.validators import parse_date

RUPEE = "₹"


# ---------------------------------------------------------------------------
# Currency -- Indian (lakh / crore) digit grouping
# ---------------------------------------------------------------------------
def indian_group(number: str) -> str:
    """
    Apply Indian digit grouping to a plain integer string.

    ``'10550000'`` becomes ``'1,05,50,000'``.
    """
    digits = str(number)
    if len(digits) <= 3:
        return digits
    last_three = digits[-3:]
    rest = digits[:-3]
    parts = []
    while len(rest) > 2:
        parts.insert(0, rest[-2:])
        rest = rest[:-2]
    if rest:
        parts.insert(0, rest)
    return ",".join(parts + [last_three])


def format_currency(value, decimals: bool = False, symbol: bool = True) -> str:
    """
    Format an amount in Indian style, e.g. ``₹1,25,50,000``.

    ``decimals=True`` keeps paise.  Blank input renders as ``₹0``.
    """
    amount = money(value)
    negative = amount < ZERO
    amount = abs(amount)

    if decimals:
        whole, _, frac = f"{amount:.2f}".partition(".")
        text = f"{indian_group(whole)}.{frac}"
    else:
        whole = f"{amount:.0f}"
        text = indian_group(whole)

    prefix = RUPEE if symbol else ""
    return f"-{prefix}{text}" if negative else f"{prefix}{text}"


def format_currency_short(value) -> str:
    """
    Compact currency for KPI cards: ``₹1.26 Cr``, ``₹10.55 L``, ``₹9,500``.
    """
    amount = money(value)
    sign = "-" if amount < ZERO else ""
    amount = abs(amount)
    crore = Decimal("10000000")
    lakh = Decimal("100000")
    if amount >= crore:
        return f"{sign}{RUPEE}{amount / crore:.2f} Cr"
    if amount >= lakh:
        return f"{sign}{RUPEE}{amount / lakh:.2f} L"
    return f"{sign}{format_currency(amount)}"


def parse_currency(text: str) -> Decimal:
    """Read a user-typed amount back into a Decimal."""
    from utils.calculations import to_decimal

    return money(to_decimal(text, ZERO))


# ---------------------------------------------------------------------------
# Dates
# ---------------------------------------------------------------------------
def format_date(value, fallback: str = "-") -> str:
    """Render any date-ish value as ``DD-MM-YYYY``."""
    if value in (None, ""):
        return fallback
    if isinstance(value, datetime):
        return value.strftime("%d-%m-%Y")
    if isinstance(value, date):
        return value.strftime("%d-%m-%Y")
    parsed = parse_date(str(value))
    return parsed.strftime("%d-%m-%Y") if parsed else str(value)


def format_datetime(value, fallback: str = "-") -> str:
    """Render a stored timestamp as ``DD-MM-YYYY HH:MM``."""
    if value in (None, ""):
        return fallback
    if isinstance(value, datetime):
        return value.strftime("%d-%m-%Y %H:%M")
    text = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return datetime.strptime(text[:26], fmt).strftime("%d-%m-%Y %H:%M")
        except ValueError:
            continue
    return format_date(text, fallback)


def to_iso_date(value) -> str:
    """Store dates internally as ISO ``YYYY-MM-DD`` so SQLite sorts correctly."""
    parsed = parse_date(value) if not isinstance(value, date) else value
    return parsed.isoformat() if parsed else ""


def today_display() -> str:
    return date.today().strftime("%d-%m-%Y")


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------
def truncate(text: Any, length: int = 80, suffix: str = "...") -> str:
    """Shorten text for table cells."""
    value = "" if text is None else str(text).replace("\n", " ").replace("\r", " ").strip()
    value = " ".join(value.split())
    if len(value) <= length:
        return value
    return value[: max(0, length - len(suffix))].rstrip() + suffix


def clean_text(text: Optional[str]) -> str:
    """Collapse runs of whitespace while keeping paragraph breaks."""
    if not text:
        return ""
    lines = [" ".join(line.split()) for line in str(text).splitlines()]
    out: List[str] = []
    blank = False
    for line in lines:
        if line:
            out.append(line)
            blank = False
        elif not blank:
            out.append("")
            blank = True
    return "\n".join(out).strip()


def as_list(value) -> List[str]:
    """
    Normalise a value that may be a list, a JSON array string or a
    comma/semicolon separated string into a clean list of strings.
    """
    if value in (None, ""):
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value).strip()
    if text.startswith("["):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return [str(v).strip() for v in parsed if str(v).strip()]
        except (json.JSONDecodeError, ValueError):
            pass
    separators = ";" if ";" in text else ","
    return [part.strip() for part in text.split(separators) if part.strip()]


def join_list(value, separator: str = ", ", fallback: str = "-") -> str:
    """Render a list-ish value as readable text."""
    items = as_list(value)
    return separator.join(items) if items else fallback


def bullet_list(value, bullet: str = "• ") -> str:
    """Render a list-ish value as bullet lines."""
    items = as_list(value)
    if not items:
        return "  (none identified)"
    return "\n".join(f"{bullet}{item}" for item in items)


def dumps(value) -> str:
    """JSON-encode for storage, tolerating unusual types."""
    try:
        return json.dumps(value, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return json.dumps(str(value))


def loads(text, fallback=None):
    """JSON-decode stored text, returning ``fallback`` on any problem."""
    if text in (None, ""):
        return fallback
    if isinstance(text, (dict, list)):
        return text
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return fallback


def pluralise(count: int, singular: str, plural: Optional[str] = None) -> str:
    """``3 issues`` / ``1 issue``."""
    word = singular if count == 1 else (plural or singular + "s")
    return f"{count} {word}"


def initials(name: str) -> str:
    """Two-letter initials used on avatar chips."""
    parts = [p for p in (name or "").replace(".", " ").split() if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[-1][0]).upper()


def safe_filename(text: str, default: str = "export") -> str:
    """Turn arbitrary text into a filename fragment that Windows accepts."""
    cleaned = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in str(text or ""))
    cleaned = "_".join(cleaned.split())
    return cleaned[:60] or default


def wrap_paragraphs(items: Iterable[str]) -> str:
    """Join text blocks with a blank line between them."""
    return "\n\n".join(part for part in items if part)
