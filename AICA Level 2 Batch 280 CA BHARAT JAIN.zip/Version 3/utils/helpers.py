"""
utils.helpers
=============
Small cross-cutting helpers: password hashing, role permissions,
JSON recovery from AI responses, file copying and prompt loading.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import config
from utils.logger import get_logger

log = get_logger(__name__)

# ---------------------------------------------------------------------------
# Password hashing (PBKDF2-HMAC-SHA256 from the standard library)
# ---------------------------------------------------------------------------
_HASH_ALGO = "sha256"
_ITERATIONS = 200_000


def hash_password(password: str, salt: Optional[str] = None) -> str:
    """
    Hash a password with PBKDF2-HMAC-SHA256.

    The stored value is ``pbkdf2_sha256$iterations$salt$hash``.
    """
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        _HASH_ALGO, password.encode("utf-8"), salt.encode("utf-8"), _ITERATIONS
    )
    return f"pbkdf2_{_HASH_ALGO}${_ITERATIONS}${salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Constant-time check of a password against a stored hash."""
    if not stored or not password:
        return False
    try:
        algo, iterations, salt, digest = stored.split("$")
        if not algo.startswith("pbkdf2_"):
            return False
        computed = hashlib.pbkdf2_hmac(
            algo.split("_", 1)[1], password.encode("utf-8"),
            salt.encode("utf-8"), int(iterations),
        )
        return hmac.compare_digest(computed.hex(), digest)
    except (ValueError, TypeError):
        return False


def password_strength_message(password: str) -> str:
    """Return an empty string when acceptable, otherwise the problem."""
    if len(password or "") < 6:
        return "Password must be at least 6 characters long."
    if password.lower() in {"admin123", "password", "123456"}:
        return "Please choose a less predictable password."
    return ""


# ---------------------------------------------------------------------------
# Role based access
# ---------------------------------------------------------------------------
def is_readonly(role: str) -> bool:
    """Viewers may not create or modify records."""
    return (role or "") in config.READONLY_ROLES


def can_approve(role: str) -> bool:
    """Only Admin/Partner and Reviewer may mark a draft CA Approved or Final."""
    return (role or "") in config.APPROVAL_ROLES


def can_manage_users(role: str) -> bool:
    return (role or "") == "Admin / Partner"


def can_see_all_matters(role: str) -> bool:
    """Admin/Partner sees every client and case; others see assigned matters."""
    return (role or "") == "Admin / Partner"


def user_matches_assignment(user: Dict[str, Any], case: Dict[str, Any]) -> bool:
    """
    Decide whether a non-admin user is assigned to a case.

    Assignment is matched on the user's display name appearing in any of
    the three assignment fields.
    """
    name = (user or {}).get("name") or ""
    if not name:
        return False
    fields = (
        case.get("assigned_partner"), case.get("assigned_manager"),
        case.get("assigned_team_member"),
    )
    return any(name.strip().lower() == (f or "").strip().lower() for f in fields)


# ---------------------------------------------------------------------------
# JSON recovery from AI output
# ---------------------------------------------------------------------------
def extract_json(text: str) -> Optional[Any]:
    """
    Pull a JSON object out of a model response.

    Handles fenced code blocks, leading prose and trailing commentary.
    Returns ``None`` when nothing parseable is found -- callers must treat
    that as a malformed-response error rather than crashing.
    """
    if not text:
        return None
    if isinstance(text, (dict, list)):
        return text

    raw = str(text).strip()

    # 1. Straight parse
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        pass

    # 2. Fenced code block
    fence = re.search(r"```(?:json)?\s*(.*?)```", raw, re.DOTALL | re.IGNORECASE)
    if fence:
        inner = fence.group(1).strip()
        try:
            return json.loads(inner)
        except (json.JSONDecodeError, ValueError):
            raw = inner

    # 3. Widest balanced {...} or [...] span
    for opener, closer in (("{", "}"), ("[", "]")):
        start = raw.find(opener)
        end = raw.rfind(closer)
        if start != -1 and end > start:
            candidate = raw[start : end + 1]
            try:
                return json.loads(candidate)
            except (json.JSONDecodeError, ValueError):
                repaired = _repair_json(candidate)
                if repaired is not None:
                    return repaired
    return None


def _repair_json(candidate: str) -> Optional[Any]:
    """Best-effort repair of common model JSON slips (trailing commas etc.)."""
    attempt = re.sub(r",\s*([}\]])", r"\1", candidate)
    attempt = attempt.replace("“", '"').replace("”", '"')
    attempt = attempt.replace("‘", "'").replace("’", "'")
    try:
        return json.loads(attempt)
    except (json.JSONDecodeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Prompt files
# ---------------------------------------------------------------------------
_PROMPT_CACHE: Dict[str, str] = {}


def load_prompt(name: str, use_cache: bool = True) -> str:
    """
    Read a prompt template from ``prompts/<name>.txt``.

    Prompts live in editable text files so the CA can tune the AI's
    instructions without touching Python code.
    """
    key = name if name.endswith(".txt") else f"{name}.txt"
    if use_cache and key in _PROMPT_CACHE:
        return _PROMPT_CACHE[key]
    path = config.PROMPT_DIR / key
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        log.error("Prompt file could not be read: %s (%s)", path, exc)
        text = ""
    _PROMPT_CACHE[key] = text
    return text


def clear_prompt_cache() -> None:
    _PROMPT_CACHE.clear()


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------
def unique_path(folder: Path, filename: str) -> Path:
    """Return a path inside ``folder`` that does not already exist."""
    folder.mkdir(parents=True, exist_ok=True)
    candidate = folder / filename
    if not candidate.exists():
        return candidate
    stem, suffix = candidate.stem, candidate.suffix
    counter = 1
    while True:
        candidate = folder / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate
        counter += 1


def copy_into(source: str | Path, folder: Path, prefix: str = "") -> Optional[Path]:
    """
    Copy a user-selected file into an application folder.

    Returns the destination path, or ``None`` if the copy failed.
    """
    try:
        src = Path(source)
        if not src.is_file():
            return None
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        name = f"{prefix}{stamp}_{src.name}" if prefix else f"{stamp}_{src.name}"
        destination = unique_path(folder, name)
        shutil.copy2(src, destination)
        return destination
    except (OSError, shutil.Error) as exc:
        log.error("Could not copy %s into %s: %s", source, folder, exc)
        return None


def relative_to_base(path: str | Path) -> str:
    """Store paths relative to the project root wherever possible."""
    try:
        return str(Path(path).resolve().relative_to(config.BASE_DIR))
    except (ValueError, OSError):
        return str(path)


def resolve_stored_path(stored: str | Path) -> Path:
    """Turn a stored (possibly relative) path back into an absolute path."""
    path = Path(stored)
    return path if path.is_absolute() else (config.BASE_DIR / path)


def open_in_explorer(path: str | Path) -> bool:
    """Reveal a file or folder in the OS file manager."""
    try:
        target = Path(path)
        if not target.exists():
            return False
        if sys.platform.startswith("win"):
            os.startfile(str(target))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", str(target)], check=False)
        else:
            subprocess.run(["xdg-open", str(target)], check=False)
        return True
    except OSError as exc:
        log.error("Could not open %s: %s", path, exc)
        return False


def human_size(num_bytes: int) -> str:
    """``1.4 MB`` style file sizes."""
    size = float(num_bytes or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"
