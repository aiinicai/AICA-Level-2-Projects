"""
utils.validators
================
Format validation for GST domain data.

IMPORTANT: these checks are *format* checks performed locally in Python.
They do **not** verify a GSTIN against the GST portal -- no portal API is
integrated in this version.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional, Tuple

import config

# ---------------------------------------------------------------------------
# Validation result vocabulary used across the UI
# ---------------------------------------------------------------------------
VALID = "Valid"
REVIEW = "Review Required"
INVALID = "Invalid Format"
NOT_FOUND = "Not Identified"


@dataclass
class ValidationResult:
    """Outcome of validating one field."""

    field: str
    value: str
    status: str
    message: str = ""
    confidence: str = ""

    @property
    def ok(self) -> bool:
        return self.status == VALID


# ---------------------------------------------------------------------------
# Regular expressions
# ---------------------------------------------------------------------------
PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
# GSTIN = 2 digit state + 10 char PAN + 1 entity code + 1 char (usually Z) + 1 checksum
GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9A-Z]{1}[Z]{1}[0-9A-Z]{1}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
MOBILE_RE = re.compile(r"^[6-9][0-9]{9}$")
FY_RE = re.compile(r"^(19|20)\d{2}-\d{2}$")

_GSTIN_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


# ---------------------------------------------------------------------------
# PAN
# ---------------------------------------------------------------------------
def is_valid_pan(pan: str) -> bool:
    """Return True when ``pan`` matches the 10-character PAN format."""
    return bool(pan) and bool(PAN_RE.match(pan.strip().upper()))


def validate_pan(pan: str, field: str = "PAN") -> ValidationResult:
    """Validate a PAN and describe the outcome."""
    value = (pan or "").strip().upper()
    if not value:
        return ValidationResult(field, "", NOT_FOUND, "PAN not provided")
    if len(value) != 10:
        return ValidationResult(field, value, INVALID, "PAN must be exactly 10 characters")
    if not is_valid_pan(value):
        return ValidationResult(field, value, INVALID, "Expected pattern AAAAA9999A")
    return ValidationResult(field, value, VALID, "Format valid")


# ---------------------------------------------------------------------------
# GSTIN
# ---------------------------------------------------------------------------
def gstin_checksum(gstin: str) -> Optional[str]:
    """
    Compute the 15th (check) character of a GSTIN from its first 14.

    Returns ``None`` when the input cannot be processed.
    """
    body = (gstin or "").strip().upper()[:14]
    if len(body) != 14:
        return None
    total = 0
    for index, char in enumerate(body):
        if char not in _GSTIN_ALPHABET:
            return None
        value = _GSTIN_ALPHABET.index(char)
        factor = 2 if index % 2 else 1
        product = value * factor
        total += product // 36 + product % 36
    return _GSTIN_ALPHABET[(36 - total % 36) % 36]


def is_valid_gstin(gstin: str) -> bool:
    """Return True when ``gstin`` passes length, pattern, state and checksum tests."""
    value = (gstin or "").strip().upper()
    if len(value) != 15 or not GSTIN_RE.match(value):
        return False
    if value[:2] not in config.INDIAN_STATES:
        return False
    return gstin_checksum(value) == value[14]


def validate_gstin(gstin: str, field: str = "GSTIN") -> ValidationResult:
    """
    Validate GSTIN format: length, regex pattern, state code and checksum.

    This is a local format check only -- it is not portal verification.
    """
    value = (gstin or "").strip().upper()
    if not value:
        return ValidationResult(field, "", NOT_FOUND, "GSTIN not provided")
    if len(value) != 15:
        return ValidationResult(
            field, value, INVALID, f"GSTIN must be 15 characters (found {len(value)})"
        )
    if not GSTIN_RE.match(value):
        return ValidationResult(
            field, value, INVALID, "Expected pattern 99AAAAA9999A9Z9"
        )
    state_code = value[:2]
    if state_code not in config.INDIAN_STATES:
        return ValidationResult(
            field, value, INVALID, f"Unknown state code '{state_code}'"
        )
    if not is_valid_pan(value[2:12]):
        return ValidationResult(
            field, value, INVALID, "Embedded PAN segment is not a valid PAN"
        )
    if gstin_checksum(value) != value[14]:
        return ValidationResult(
            field, value, REVIEW,
            "Checksum digit does not match - please re-verify the GSTIN",
        )
    state = config.INDIAN_STATES[state_code]
    return ValidationResult(field, value, VALID, f"Format valid ({state})")


def gstin_state(gstin: str) -> str:
    """Return the state name encoded in a GSTIN, or an empty string."""
    value = (gstin or "").strip().upper()
    return config.INDIAN_STATES.get(value[:2], "") if len(value) >= 2 else ""


def pan_from_gstin(gstin: str) -> str:
    """Extract the PAN embedded in a GSTIN, or an empty string."""
    value = (gstin or "").strip().upper()
    return value[2:12] if len(value) == 15 else ""


# ---------------------------------------------------------------------------
# Dates
# ---------------------------------------------------------------------------
DATE_INPUT_FORMATS = (
    "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d.%m.%Y",
    "%d %b %Y", "%d %B %Y", "%b %d, %Y", "%d-%b-%Y", "%Y/%m/%d",
)


def parse_date(value: str) -> Optional[date]:
    """Parse a date written in any of the common Indian/ISO formats."""
    if not value:
        return None
    if isinstance(value, date):
        return value
    text = str(value).strip()
    if not text:
        return None
    for fmt in DATE_INPUT_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def validate_date(value: str, field: str = "Date", required: bool = False) -> ValidationResult:
    """Validate that ``value`` is a parseable date."""
    text = (value or "").strip()
    if not text:
        status = INVALID if required else NOT_FOUND
        return ValidationResult(field, "", status, "Date not provided")
    parsed = parse_date(text)
    if parsed is None:
        return ValidationResult(field, text, INVALID, "Unrecognised date format (use DD-MM-YYYY)")
    if parsed.year < 2017:
        return ValidationResult(
            field, text, REVIEW, "Date precedes GST implementation (01-07-2017)"
        )
    if parsed > date.today().replace(year=date.today().year + 5):
        return ValidationResult(field, text, REVIEW, "Date is unusually far in the future")
    return ValidationResult(field, parsed.strftime("%d-%m-%Y"), VALID, "Date valid")


def validate_date_order(
    notice_date: str, due_date: str
) -> ValidationResult:
    """Reply due date should not fall before the notice date."""
    nd, dd = parse_date(notice_date), parse_date(due_date)
    if nd is None or dd is None:
        return ValidationResult("Date Sequence", "", NOT_FOUND, "Both dates not available")
    if dd < nd:
        return ValidationResult(
            "Date Sequence", f"{dd:%d-%m-%Y} < {nd:%d-%m-%Y}", REVIEW,
            "Reply due date is earlier than the notice date",
        )
    return ValidationResult("Date Sequence", "", VALID, "Notice date precedes due date")


# ---------------------------------------------------------------------------
# Financial year
# ---------------------------------------------------------------------------
def normalise_financial_year(value: str) -> str:
    """
    Convert loose financial-year text into the canonical ``2023-24`` form.

    Accepts ``2023-2024``, ``FY 2023-24``, ``2023 24`` and similar.
    """
    text = (value or "").upper().replace("FY", "").replace("F.Y.", "").strip()
    text = text.replace("/", "-").replace(" ", "-").replace("--", "-").strip("- ")
    match = re.search(r"(\d{4})\s*-\s*(\d{2,4})", text)
    if not match:
        match = re.search(r"^(\d{4})$", text)
        if match:
            start = int(match.group(1))
            return f"{start}-{str(start + 1)[2:]}"
        return text
    start = int(match.group(1))
    end = match.group(2)
    end_two = end[-2:] if len(end) == 4 else end
    return f"{start}-{end_two}"


def validate_financial_year(value: str, field: str = "Financial Year") -> ValidationResult:
    """Validate a financial year string such as ``2023-24``."""
    raw = (value or "").strip()
    if not raw:
        return ValidationResult(field, "", NOT_FOUND, "Financial year not provided")
    text = normalise_financial_year(raw)
    if not FY_RE.match(text):
        return ValidationResult(field, raw, INVALID, "Expected format YYYY-YY (e.g. 2023-24)")
    start = int(text[:4])
    expected_end = str(start + 1)[2:]
    if text[5:] != expected_end:
        return ValidationResult(
            field, text, INVALID, f"Second year should be {expected_end}"
        )
    if start < 2017:
        return ValidationResult(field, text, REVIEW, "Period precedes GST implementation")
    return ValidationResult(field, text, VALID, "Financial year valid")


# ---------------------------------------------------------------------------
# Misc field validators
# ---------------------------------------------------------------------------
def validate_email(value: str, field: str = "Email") -> ValidationResult:
    text = (value or "").strip()
    if not text:
        return ValidationResult(field, "", NOT_FOUND, "Email not provided")
    if not EMAIL_RE.match(text):
        return ValidationResult(field, text, INVALID, "Email address is not well formed")
    return ValidationResult(field, text, VALID, "Email valid")


def validate_mobile(value: str, field: str = "Mobile") -> ValidationResult:
    digits = re.sub(r"\D", "", value or "")
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    if not digits:
        return ValidationResult(field, "", NOT_FOUND, "Mobile number not provided")
    if not MOBILE_RE.match(digits):
        return ValidationResult(field, digits, INVALID, "Expected a 10-digit Indian mobile number")
    return ValidationResult(field, digits, VALID, "Mobile number valid")


def validate_amount(value, field: str = "Amount") -> ValidationResult:
    """Validate that a value can be read as a non-negative money amount."""
    from utils.calculations import to_decimal  # local import avoids a cycle

    if value in (None, ""):
        return ValidationResult(field, "", NOT_FOUND, "Amount not provided")
    amount = to_decimal(value)
    if amount is None:
        return ValidationResult(field, str(value), INVALID, "Value is not numeric")
    if amount < 0:
        return ValidationResult(field, str(value), REVIEW, "Negative amount - please confirm")
    return ValidationResult(field, str(amount), VALID, "Amount valid")


def validate_required(value: str, field: str) -> ValidationResult:
    text = (value or "").strip()
    if not text:
        return ValidationResult(field, "", INVALID, f"{field} is required")
    return ValidationResult(field, text, VALID, "")


# ---------------------------------------------------------------------------
# Form-level helper
# ---------------------------------------------------------------------------
def validate_client_form(data: dict) -> Tuple[bool, list]:
    """
    Validate the Client master form.

    Returns ``(is_ok, [error messages])``.  Blank optional fields are allowed;
    supplied fields must be well formed.
    """
    errors: list = []

    if not (data.get("client_name") or "").strip():
        errors.append("Client Name is required.")

    gstin = (data.get("gstin") or "").strip()
    if gstin:
        result = validate_gstin(gstin)
        if result.status == INVALID:
            errors.append(f"GSTIN: {result.message}")

    pan = (data.get("pan") or "").strip()
    if pan and not is_valid_pan(pan):
        errors.append("PAN: expected pattern AAAAA9999A.")

    email = (data.get("email") or "").strip()
    if email and not EMAIL_RE.match(email):
        errors.append("Email address is not well formed.")

    mobile = re.sub(r"\D", "", data.get("mobile") or "")
    if mobile and not MOBILE_RE.match(mobile):
        errors.append("Mobile: expected a 10-digit Indian mobile number.")

    if gstin and pan:
        embedded = pan_from_gstin(gstin)
        if embedded and embedded != pan.strip().upper():
            errors.append("PAN does not match the PAN embedded in the GSTIN.")

    return (not errors), errors


def validate_case_form(data: dict) -> Tuple[bool, list]:
    """Validate the GST Case master form.  Returns ``(is_ok, errors)``."""
    errors: list = []

    if not data.get("client_id"):
        errors.append("A client must be selected.")
    if not (data.get("notice_type") or "").strip():
        errors.append("Notice Type is required.")

    for label, key in (("Notice Date", "notice_date"), ("Reply Due Date", "due_date")):
        text = (data.get(key) or "").strip()
        if text and parse_date(text) is None:
            errors.append(f"{label}: unrecognised date format (use DD-MM-YYYY).")

    fy = (data.get("financial_year") or "").strip()
    if fy:
        result = validate_financial_year(fy)
        if result.status == INVALID:
            errors.append(f"Financial Year: {result.message}")

    nd = parse_date(data.get("notice_date") or "")
    dd = parse_date(data.get("due_date") or "")
    if nd and dd and dd < nd:
        errors.append("Reply Due Date cannot be earlier than the Notice Date.")

    return (not errors), errors
