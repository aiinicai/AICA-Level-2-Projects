"""
CA-GST Copilot - AI-Powered GST Litigation Assistant
====================================================
Application entry point.

Run from a command prompt::

    python main.py

Run from IDLE:  open this file, then Run > Run Module (F5).

Default first-run login:  admin / admin123
"""

from __future__ import annotations

import sys
import traceback
from typing import Any, Dict, List, Optional

# Ensure the project root is importable when launched from IDLE.
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import config  # noqa: E402
from utils.logger import get_logger, setup_logging  # noqa: E402

log = get_logger("main")

MIN_PYTHON = (3, 10)


def check_environment() -> Optional[str]:
    """Return an error message when the environment cannot run the app."""
    if sys.version_info < MIN_PYTHON:
        return (
            f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ is required "
            f"(found {sys.version.split()[0]})."
        )
    missing = []
    for module, package in (
        ("customtkinter", "customtkinter"),
        ("tkinter", "tkinter (bundled with Python)"),
    ):
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    if missing:
        return (
            "Required package(s) not installed: " + ", ".join(missing)
            + "\n\nInstall dependencies with:\n    pip install -r requirements.txt"
        )
    return None


def bootstrap() -> None:
    """Create folders, configure logging and initialise the database."""
    config.ensure_directories()
    setup_logging()
    log.info("=" * 70)
    log.info("Starting %s %s", config.APP_NAME, config.APP_VERSION_LABEL)

    from database.database import initialise_database

    initialise_database()

    # Seed the editable prompt files if any are missing.
    from services.prompt_setup import ensure_prompt_files

    ensure_prompt_files()


def run() -> None:
    """Login -> main window loop (sign-out returns to the login screen)."""
    import customtkinter as ctk

    from ui.login import LoginWindow
    from ui.main_window import MainWindow

    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")

    while True:
        signed_in: Dict[str, Any] = {}

        def capture(user: Dict[str, Any]) -> None:
            signed_in.update(user)

        login = LoginWindow(on_success=capture)
        login.mainloop()

        if not signed_in:
            log.info("Login cancelled - exiting")
            return

        window = MainWindow(signed_in)
        window.mainloop()

        if not getattr(window, "restart_login", False):
            log.info("Application closed")
            return
        log.info("User signed out - returning to login")


def _probe_widgets() -> str:
    """
    Build a hidden window containing the real widget set.

    This proves the CustomTkinter theme assets are present, which a packaged
    build can silently miss.
    """
    import customtkinter as ctk

    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    root = ctk.CTk()
    root.withdraw()
    try:
        from ui.widgets import (
            Card, DataTable, KpiCard, LabeledDropdown, LabeledEntry, font,
            primary_button,
        )

        card = Card(root, "probe")
        KpiCard(card, "Metric", "1", "caption")
        LabeledEntry(card, "Field")
        LabeledDropdown(card, "Choice", ["a", "b"])
        primary_button(card, "Action", lambda: None)
        table = DataTable(card, [("id", "ID", 60, "w"), ("n", "Name", 120, "w")])
        table.load([{"id": 1, "n": "probe"}])
        ctk.CTkLabel(card, text="probe", font=font(12, "bold"))
        root.update_idletasks()
        return f" (theme '{ctk.get_appearance_mode()}' loaded)"
    finally:
        try:
            root.destroy()
        except Exception:  # noqa: BLE001
            pass


def _probe_chart() -> str:
    """
    Draw a real matplotlib figure through the Tk backend.

    A packaged build can import matplotlib but fail to draw when its font
    cache or ``mpl-data`` files were not collected, so the figure is actually
    rendered rather than merely imported.
    """
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    figure = Figure(figsize=(3, 2), dpi=72)
    axis = figure.subplots()
    axis.bar(["New", "Drafting", "Filed"], [3, 2, 1])
    axis.set_title("Cases by Status")
    canvas = FigureCanvasAgg(figure)
    canvas.draw()
    width, height = canvas.get_width_height()

    # The Tk backend is what the dashboard actually uses.
    import tkinter as tk

    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

    root = tk.Tk()
    root.withdraw()
    try:
        tk_canvas = FigureCanvasTkAgg(figure, master=root)
        tk_canvas.draw()
        root.update_idletasks()
    finally:
        try:
            root.destroy()
        except Exception:  # noqa: BLE001
            pass
    return f" ({width}x{height} figure rendered via Agg and TkAgg)"


def run_startup_check(show_dialog: bool = True) -> int:
    """
    Verify an installation without opening the application.

    Every screen is imported (the screens are normally loaded dynamically by
    name, so this is the only way to prove they resolve inside a packaged
    build), every service is imported, and the self tests are run. The report
    is written to ``logs/startup_check.txt`` and shown in a dialog.

    Invoked with:  CA-GST-Copilot.exe --check   or   python main.py --check
    Add ``--no-dialog`` to suppress the summary dialog when scripting.
    """
    import importlib

    bootstrap()
    lines: List[str] = [
        f"{config.APP_NAME} {config.APP_VERSION_LABEL} - installation check",
        "=" * 70,
        f"Frozen build      : {config.FROZEN}",
        f"Application folder: {config.BASE_DIR}",
        f"Python            : {sys.version.split()[0]}",
        "",
        "SCREENS",
    ]
    failures = 0

    from ui.main_window import NAV_ITEMS

    for _key, label, module_path, class_name in NAV_ITEMS:
        try:
            module = importlib.import_module(module_path)
            getattr(module, class_name)
            lines.append(f"  [ OK ] {label}")
        except Exception as exc:  # noqa: BLE001 - report, do not raise
            failures += 1
            lines.append(f"  [FAIL] {label}: {type(exc).__name__}: {exc}")

    lines += ["", "SERVICES AND LIBRARIES"]
    checks = [
        ("PDF reading (PyMuPDF)", "services.pdf_service"),
        ("AI providers (Gemini / ChatGPT)", "services.ai_service"),
        ("CBIC legislation source", "services.cbic_service"),
        ("Notice analysis", "services.gst_notice_service"),
        ("Knowledge base retrieval", "services.rag_service"),
        ("Research", "services.research_service"),
        ("Draft reply", "services.reply_service"),
        ("Exports", "services.export_service"),
        ("Word export (python-docx)", "docx"),
        ("Excel export (openpyxl)", "openpyxl"),
        ("PDF export (ReportLab)", "reportlab.pdfgen.canvas"),
        ("Charts (matplotlib Tk backend)", "matplotlib.backends.backend_tkagg"),
    ]
    for label, module_path in checks:
        try:
            importlib.import_module(module_path)
            lines.append(f"  [ OK ] {label}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            lines.append(f"  [FAIL] {label}: {type(exc).__name__}: {exc}")

    lines += ["", "RENDERING"]
    for label, probe in (("CustomTkinter widgets and theme", _probe_widgets),
                         ("Dashboard chart drawing", _probe_chart)):
        try:
            detail = probe()
            lines.append(f"  [ OK ] {label}{detail}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            lines.append(f"  [FAIL] {label}: {type(exc).__name__}: {exc}")

    from services import ai_service

    status = ai_service.api_status()
    lines += ["", "AI CONFIGURATION",
              f"  Active provider      : {status['provider']}",
              f"  Model                : {status['model']}"]
    for name, detail in status.get("providers", {}).items():
        lines.append(
            f"  {name:<20} : SDK {'yes' if detail['sdk_installed'] else 'no '}"
            f" / key {'yes' if detail['key_configured'] else 'no '}")
    lines += ["  (Demo Mode works without a key.)", "", "SELF TESTS"]
    try:
        from tests.self_tests import run_all

        outcome = run_all()
        failures += outcome["failed"]
        lines.append(outcome["report"])
    except Exception as exc:  # noqa: BLE001
        failures += 1
        lines.append(f"  [FAIL] self tests could not run: {type(exc).__name__}: {exc}")

    lines += ["", "=" * 70,
              "RESULT: all checks passed." if failures == 0
              else f"RESULT: {failures} check(s) failed."]
    report = "\n".join(lines)

    try:
        report_path = config.LOG_DIR / "startup_check.txt"
        report_path.write_text(report, encoding="utf-8")
    except OSError:
        report_path = None

    print(report)
    if not show_dialog:
        return 0 if failures == 0 else 1

    try:
        import tkinter as tk
        import tkinter.messagebox as messagebox

        root = tk.Tk()
        root.withdraw()
        summary = ("All checks passed. The installation is complete and working."
                   if failures == 0 else
                   f"{failures} check(s) failed. See the report for details.")
        if report_path:
            summary += f"\n\nFull report:\n{report_path}"
        (messagebox.showinfo if failures == 0 else messagebox.showerror)(
            f"{config.APP_NAME} - installation check", summary)
        root.destroy()
    except Exception:  # noqa: BLE001 - the console report is enough
        pass

    return 0 if failures == 0 else 1


def main() -> int:
    arguments = sys.argv[1:]
    if "--check" in arguments:
        return run_startup_check(show_dialog="--no-dialog" not in arguments)

    problem = check_environment()
    if problem:
        print("CA-GST Copilot could not start.\n")
        print(problem)
        try:
            import tkinter.messagebox as messagebox
            import tkinter as tk

            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("CA-GST Copilot - startup problem", problem)
            root.destroy()
        except Exception:  # noqa: BLE001 - console message is enough
            pass
        return 1

    try:
        bootstrap()
        run()
        return 0
    except Exception as exc:  # noqa: BLE001 - last-resort handler
        log.critical("Fatal error: %s", exc, exc_info=True)
        detail = traceback.format_exc()
        print("A fatal error occurred:\n")
        print(detail)
        try:
            import tkinter.messagebox as messagebox
            import tkinter as tk

            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "CA-GST Copilot - fatal error",
                f"{exc}\n\nSee logs/app.log for the full trace.",
            )
            root.destroy()
        except Exception:  # noqa: BLE001
            pass
        return 1


if __name__ == "__main__":
    sys.exit(main())
