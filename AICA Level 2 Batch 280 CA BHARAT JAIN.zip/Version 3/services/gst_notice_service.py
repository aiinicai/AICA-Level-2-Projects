"""
services.gst_notice_service
===========================
Orchestrates structured GST notice analysis.

Pipeline::

    notice text
        -> prompt (prompts/notice_analysis.txt)
        -> Gemini (or Demo Mode sample)
        -> JSON normalisation          (this module - never trusts the model)
        -> Python demand computation   (utils.calculations)
        -> Python validation           (utils.validators)
        -> SQLite

The AI extracts; **Python computes and validates**.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, List, Optional

from database import database as db
from services import ai_service, mock_data
from utils.calculations import DemandSummary, compute_demand, money, reconcile_issue_amounts
from utils.formatters import as_list, dumps, join_list, to_iso_date
from utils.helpers import load_prompt
from utils.logger import get_logger
from utils.validators import (
    INVALID, NOT_FOUND, REVIEW, VALID, ValidationResult, normalise_financial_year,
    parse_date, validate_amount, validate_date, validate_date_order,
    validate_financial_year, validate_gstin,
)

log = get_logger(__name__)

RISK_VALUES = {"high": "High", "medium": "Medium", "low": "Low",
               "review required": "Review Required", "review": "Review Required"}
CONFIDENCE_VALUES = {"high": "High", "medium": "Medium", "low": "Low"}

# Notice text longer than this is trimmed before being sent to the model,
# which keeps token cost predictable (see section 34 of the specification).
MAX_NOTICE_CHARS = 45_000


@dataclass
class NoticeAnalysisResult:
    """Everything the Notice Analysis screen needs after one AI run."""

    ok: bool = False
    data: Dict[str, Any] = field(default_factory=dict)
    demand: DemandSummary = field(default_factory=DemandSummary)
    issues: List[Dict[str, Any]] = field(default_factory=list)
    validations: List[ValidationResult] = field(default_factory=list)
    reconciliation: Dict[str, Any] = field(default_factory=dict)
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    source: str = ""
    raw_json: str = ""
    elapsed: float = 0.0

    @property
    def issue_count(self) -> int:
        return len(self.issues)


# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------
def build_prompt(notice_text: str) -> str:
    """Render the notice-analysis prompt with the safety rules embedded."""
    template = load_prompt("notice_analysis")
    safety = load_prompt("_safety_rules")
    text = (notice_text or "").strip()
    if len(text) > MAX_NOTICE_CHARS:
        text = text[:MAX_NOTICE_CHARS] + "\n\n[NOTICE TEXT TRUNCATED FOR LENGTH]"
    if not template:
        # Fall back to an inline prompt if the file was deleted.
        from services.prompt_setup import NOTICE_ANALYSIS

        template = NOTICE_ANALYSIS
    try:
        return template.format(safety=safety, notice_text=text)
    except (KeyError, IndexError, ValueError) as exc:
        log.error("notice_analysis prompt template is malformed: %s", exc)
        return (
            f"{safety}\n\nAnalyse the following GST notice and return structured "
            f"JSON only.\n\n{text}"
        )


# ---------------------------------------------------------------------------
# Normalisation - the model's output is never trusted as-is
# ---------------------------------------------------------------------------
def normalise_analysis(raw: Any) -> Dict[str, Any]:
    """
    Coerce a model response into the canonical analysis structure.

    Missing keys become blanks, empty lists or zeros; unexpected types are
    converted; totals are deliberately NOT taken from the model.
    """
    source = raw if isinstance(raw, dict) else {}

    def text(key: str) -> str:
        value = source.get(key, "")
        if isinstance(value, (list, tuple)):
            return ", ".join(str(v) for v in value)
        return "" if value is None else str(value).strip()

    def number(key: str) -> Decimal:
        return money(source.get(key))

    data: Dict[str, Any] = {
        "taxpayer_name": text("taxpayer_name"),
        "gstin": text("gstin").upper(),
        "notice_type": text("notice_type"),
        "notice_number": text("notice_number"),
        "financial_year": normalise_financial_year(text("financial_year")),
        "tax_period": text("tax_period"),
        "notice_date": text("notice_date"),
        "reply_due_date": text("reply_due_date"),
        "sections_invoked": as_list(source.get("sections_invoked")),
        "rules_invoked": as_list(source.get("rules_invoked")),
        "officer_name": text("officer_name"),
        "designation": text("designation"),
        "jurisdiction": text("jurisdiction"),
        "summary": text("summary"),
        "cgst": number("cgst"),
        "sgst": number("sgst"),
        "igst": number("igst"),
        "cess": number("cess"),
        "interest": number("interest"),
        "penalty": number("penalty"),
        "other_amount": number("other_amount"),
    }

    issues_raw = source.get("issues")
    issues: List[Dict[str, Any]] = []
    if isinstance(issues_raw, list):
        for index, item in enumerate(issues_raw, start=1):
            if not isinstance(item, dict):
                continue
            issues.append(_normalise_issue(item, index))
    data["issues"] = issues
    return data


def _normalise_issue(item: Dict[str, Any], position: int) -> Dict[str, Any]:
    """Coerce one issue entry into the canonical shape."""
    def text(key: str, *alternatives: str) -> str:
        for candidate in (key, *alternatives):
            value = item.get(candidate)
            if value not in (None, ""):
                if isinstance(value, (list, tuple)):
                    return ", ".join(str(v) for v in value)
                return str(value).strip()
        return ""

    try:
        issue_no = int(item.get("issue_no") or position)
    except (TypeError, ValueError):
        issue_no = position

    risk = RISK_VALUES.get(text("initial_risk", "risk").lower(), "Review Required")
    confidence = CONFIDENCE_VALUES.get(text("confidence").lower(), "Low")

    return {
        "issue_no": issue_no,
        "issue_title": text("issue_title", "title") or f"Issue {issue_no}",
        "department_allegation": text("department_allegation", "allegation"),
        "amount": money(item.get("amount")),
        "sections": as_list(item.get("sections")),
        "facts_identified": as_list(item.get("facts_identified")),
        "facts_missing": as_list(item.get("facts_missing")),
        "initial_risk": risk,
        "reason_for_risk": text("reason_for_risk", "risk_reason"),
        "confidence": confidence,
    }


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_analysis(data: Dict[str, Any], demand: DemandSummary
                      ) -> List[ValidationResult]:
    """
    Run Python validation over the extracted values.

    Nothing is silently corrected -- the results are shown to the user, who
    decides what to change.
    """
    results: List[ValidationResult] = []

    taxpayer = data.get("taxpayer_name", "")
    results.append(ValidationResult(
        "Taxpayer Name", taxpayer,
        VALID if taxpayer else NOT_FOUND,
        "Extracted from the notice" if taxpayer else "Not stated in the notice",
        "High" if taxpayer else "",
    ))

    results.append(validate_gstin(data.get("gstin", "")))

    notice_type = data.get("notice_type", "")
    results.append(ValidationResult(
        "Notice Type", notice_type,
        VALID if notice_type else NOT_FOUND,
        "" if notice_type else "Notice type could not be identified",
    ))

    notice_number = data.get("notice_number", "")
    results.append(ValidationResult(
        "Notice Number", notice_number,
        VALID if notice_number else NOT_FOUND,
        "" if notice_number else "Notice number could not be identified",
    ))

    results.append(validate_financial_year(data.get("financial_year", "")))

    tax_period = data.get("tax_period", "")
    results.append(ValidationResult(
        "Tax Period", tax_period, VALID if tax_period else NOT_FOUND,
        "" if tax_period else "Tax period not stated",
    ))

    results.append(validate_date(data.get("notice_date", ""), "Notice Date"))
    results.append(validate_date(data.get("reply_due_date", ""), "Reply Due Date"))
    results.append(validate_date_order(data.get("notice_date", ""),
                                       data.get("reply_due_date", "")))

    sections = data.get("sections_invoked") or []
    results.append(ValidationResult(
        "Sections Invoked", join_list(sections, fallback=""),
        VALID if sections else NOT_FOUND,
        "" if sections else "No section could be identified in the notice",
    ))

    for label, key in (("CGST", "cgst"), ("SGST", "sgst"), ("IGST", "igst"),
                       ("Cess", "cess"), ("Interest", "interest"),
                       ("Penalty", "penalty"), ("Other Amount", "other_amount")):
        results.append(validate_amount(data.get(key), label))

    # Python-computed totals, reported for transparency.
    results.append(ValidationResult(
        "Total Tax (computed)", str(demand.total_tax), VALID,
        "CGST + SGST + IGST + Cess, computed in Python", "High",
    ))
    results.append(ValidationResult(
        "Total Exposure (computed)", str(demand.total_exposure), VALID,
        "Total tax + interest + penalty + other, computed in Python", "High",
    ))

    issues = data.get("issues") or []
    results.append(ValidationResult(
        "Issues Identified", str(len(issues)),
        VALID if issues else REVIEW,
        f"{len(issues)} distinct allegation(s) separated"
        if issues else "No separate allegation was identified - please review",
    ))

    reconciliation = reconcile_issue_amounts(demand, issues)
    if reconciliation["checked"]:
        matched = reconciliation["matched"]
        results.append(ValidationResult(
            "Issue amounts vs demand",
            f"{reconciliation['issue_total']} vs {reconciliation['demand_total']}",
            VALID if matched else REVIEW,
            f"Sum of issue-wise amounts agrees with {reconciliation['basis']}"
            if matched else
            f"Difference of {reconciliation['difference']} between the sum of "
            "issue-wise amounts and the total tax demanded - please review",
        ))

    if demand.total_exposure == 0:
        results.append(ValidationResult(
            "Demand", "0", REVIEW,
            "No monetary demand was extracted - confirm whether the notice "
            "quantifies a demand",
        ))

    return results


def validation_summary(results: List[ValidationResult]) -> Dict[str, int]:
    """Count validation outcomes for the summary strip."""
    summary = {VALID: 0, REVIEW: 0, INVALID: 0, NOT_FOUND: 0}
    for result in results:
        summary[result.status] = summary.get(result.status, 0) + 1
    return summary


# ---------------------------------------------------------------------------
# The analysis run
# ---------------------------------------------------------------------------
def analyse_notice(notice_text: str, case: Optional[Dict[str, Any]] = None,
                   demo_mode: bool = True) -> NoticeAnalysisResult:
    """
    Analyse a GST notice and return a fully computed, validated result.

    This performs the AI call, so it should be run on a worker thread.
    """
    result = NoticeAnalysisResult(demo=demo_mode)

    if not (notice_text or "").strip():
        result.error = ("There is no notice text to analyse. Upload a searchable "
                        "PDF or paste the notice text first.")
        result.error_kind = "no_text"
        return result

    prompt = build_prompt(notice_text)
    response = ai_service.generate(
        prompt,
        demo_mode=demo_mode,
        demo_payload=mock_data.notice_analysis(notice_text, case),
        expect_json=True,
        temperature=0.1,
        label="Notice analysis",
    )

    result.demo = response.demo
    result.source = response.source_label
    result.elapsed = response.elapsed

    if not response.ok:
        result.error = response.friendly_error
        result.error_kind = response.error_kind
        result.raw_json = response.raw
        return result

    data = normalise_analysis(response.data)
    demand = compute_demand(data)

    result.ok = True
    result.data = data
    result.demand = demand
    result.issues = data.get("issues", [])
    result.validations = validate_analysis(data, demand)
    result.reconciliation = reconcile_issue_amounts(demand, result.issues)
    result.raw_json = dumps(response.data)
    return result


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
def save_analysis(case_id: int, result: NoticeAnalysisResult,
                  update_case: bool = True) -> int:
    """
    Store the analysis, its issues and (optionally) the derived case fields.

    Returns the new ``notice_analysis`` row id.
    """
    data = result.data
    demand = result.demand

    payload: Dict[str, Any] = {
        "taxpayer_name": data.get("taxpayer_name", ""),
        "gstin": data.get("gstin", ""),
        "notice_type": data.get("notice_type", ""),
        "notice_number": data.get("notice_number", ""),
        "financial_year": data.get("financial_year", ""),
        "tax_period": data.get("tax_period", ""),
        "notice_date": to_iso_date(data.get("notice_date")),
        "reply_due_date": to_iso_date(data.get("reply_due_date")),
        "sections": join_list(data.get("sections_invoked"), fallback=""),
        "rules": join_list(data.get("rules_invoked"), fallback=""),
        "officer_name": data.get("officer_name", ""),
        "designation": data.get("designation", ""),
        "jurisdiction": data.get("jurisdiction", ""),
        "summary": data.get("summary", ""),
        "source": result.source,
        "ai_raw_json": result.raw_json,
    }
    payload.update(demand.as_float_dict())

    analysis_id = db.save_notice_analysis(case_id, payload)

    issue_rows = [
        {
            "issue_no": issue.get("issue_no", index),
            "title": issue.get("issue_title", ""),
            "allegation": issue.get("department_allegation", ""),
            "amount": float(issue.get("amount") or 0),
            "sections": join_list(issue.get("sections"), fallback=""),
            "facts_identified": dumps(issue.get("facts_identified") or []),
            "facts_missing": dumps(issue.get("facts_missing") or []),
            "risk": issue.get("initial_risk", "Review Required"),
            "risk_reason": issue.get("reason_for_risk", ""),
            "confidence": issue.get("confidence", ""),
            "ai_analysis": "",
        }
        for index, issue in enumerate(result.issues, start=1)
    ]
    db.replace_case_issues(case_id, issue_rows)

    if update_case:
        case_update = _case_fields_from_analysis(data, result.issues)
        if case_update:
            db.update_case(case_id, case_update)

    db.log_activity(
        "Notice analysed",
        f"{result.issue_count} issue(s); total exposure {demand.total_exposure}; "
        f"source: {result.source}",
        case_id=case_id,
    )
    log.info("Analysis saved for case %s (%d issues)", case_id, len(issue_rows))
    return analysis_id


def _case_fields_from_analysis(data: Dict[str, Any],
                               issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Derive case-master fields from the analysis.

    Only fields the notice actually supplied are written back.
    """
    update: Dict[str, Any] = {}
    if data.get("notice_number"):
        update["notice_number"] = data["notice_number"]
    if data.get("financial_year"):
        update["financial_year"] = data["financial_year"]
    if data.get("tax_period"):
        update["tax_period"] = data["tax_period"]
    if parse_date(data.get("notice_date")):
        update["notice_date"] = to_iso_date(data["notice_date"])
    if parse_date(data.get("reply_due_date")):
        update["due_date"] = to_iso_date(data["reply_due_date"])
    if data.get("sections_invoked"):
        update["sections"] = join_list(data["sections_invoked"], fallback="")
    if data.get("officer_name"):
        update["officer"] = data["officer_name"]
    if data.get("jurisdiction"):
        update["jurisdiction"] = data["jurisdiction"]

    if issues:
        risks = {issue.get("initial_risk") for issue in issues}
        if "High" in risks:
            update["risk_level"] = "High"
        elif "Medium" in risks:
            update["risk_level"] = "Medium"
        elif risks == {"Low"}:
            update["risk_level"] = "Low"
        else:
            update["risk_level"] = "Review Required"

    update["status"] = "Under Analysis"
    update["stage"] = "Analysis"
    return update


def load_saved_analysis(case_id: int) -> Optional[NoticeAnalysisResult]:
    """
    Rebuild a :class:`NoticeAnalysisResult` from the database.

    Reusing the stored analysis avoids paying for the same AI call twice.
    """
    stored = db.get_notice_analysis(case_id)
    if not stored:
        return None

    issues_rows = db.list_issues(case_id)
    from utils.formatters import loads

    issues = [
        {
            "issue_no": row.get("issue_no"),
            "issue_title": row.get("title", ""),
            "department_allegation": row.get("allegation", ""),
            "amount": money(row.get("amount")),
            "sections": as_list(row.get("sections")),
            "facts_identified": loads(row.get("facts_identified"), []) or [],
            "facts_missing": loads(row.get("facts_missing"), []) or [],
            "initial_risk": row.get("risk", "Review Required"),
            "reason_for_risk": row.get("risk_reason", ""),
            "confidence": row.get("confidence", ""),
            "_id": row.get("id"),
        }
        for row in issues_rows
    ]

    data = {
        "taxpayer_name": stored.get("taxpayer_name", ""),
        "gstin": stored.get("gstin", ""),
        "notice_type": stored.get("notice_type", ""),
        "notice_number": stored.get("notice_number", ""),
        "financial_year": stored.get("financial_year", ""),
        "tax_period": stored.get("tax_period", ""),
        "notice_date": stored.get("notice_date", ""),
        "reply_due_date": stored.get("reply_due_date", ""),
        "sections_invoked": as_list(stored.get("sections")),
        "rules_invoked": as_list(stored.get("rules")),
        "officer_name": stored.get("officer_name", ""),
        "designation": stored.get("designation", ""),
        "jurisdiction": stored.get("jurisdiction", ""),
        "summary": stored.get("summary", ""),
        "cgst": money(stored.get("cgst")),
        "sgst": money(stored.get("sgst")),
        "igst": money(stored.get("igst")),
        "cess": money(stored.get("cess")),
        "interest": money(stored.get("interest")),
        "penalty": money(stored.get("penalty")),
        "other_amount": money(stored.get("other_amount")),
        "issues": issues,
    }
    demand = compute_demand(data)

    result = NoticeAnalysisResult(
        ok=True, data=data, demand=demand, issues=issues,
        source=stored.get("source", "Saved analysis"),
        raw_json=stored.get("ai_raw_json", ""),
    )
    result.validations = validate_analysis(data, demand)
    result.reconciliation = reconcile_issue_amounts(demand, issues)
    result.demo = "demo" in (stored.get("source") or "").lower()
    return result


def apply_manual_correction(case_id: int, field: str, value: Any) -> bool:
    """
    Apply a user correction to the stored analysis.

    Totals are always recomputed in Python after a component changes.
    """
    stored = db.get_notice_analysis(case_id)
    if not stored:
        return False

    numeric = {"cgst", "sgst", "igst", "cess", "interest", "penalty", "other_amount"}
    updates: Dict[str, Any] = {}
    if field in numeric:
        updates[field] = float(money(value))
        merged = {k: stored.get(k) for k in numeric}
        merged[field] = updates[field]
        demand = compute_demand(merged)
        updates["total_tax"] = float(demand.total_tax)
        updates["total_exposure"] = float(demand.total_exposure)
    else:
        updates[field] = value

    assignments = ", ".join(f"{k} = ?" for k in updates)
    db.execute(
        f"UPDATE notice_analysis SET {assignments} WHERE id = ?",
        list(updates.values()) + [stored["id"]],
    )
    db.log_activity("Analysis corrected", f"{field} set manually", case_id=case_id)
    return True
