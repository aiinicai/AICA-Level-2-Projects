"""
services.export_service
=======================
Export to Excel (openpyxl), Word (python-docx) and PDF (ReportLab).

Every function returns ``(ok, path_or_message)`` so the caller can show a
friendly message rather than a traceback when an optional library is
missing or a file is locked by another application.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import config
from utils.formatters import format_currency, format_date, safe_filename, truncate
from utils.helpers import unique_path
from utils.logger import get_logger

log = get_logger(__name__)

Result = Tuple[bool, str]

FOOTER_TEXT = (
    "CA-GST Copilot | AI-Assisted Professional Tool | Verify before reliance"
    f" | {config.APP_BRANDING}"
)
EXPORT_DISCLAIMER = (
    "This document was prepared with AI assistance. All facts, statutory "
    "references, circulars, notifications, judgments and computations must be "
    "independently verified by the Chartered Accountant before reliance or "
    "submission."
)


def demo_banner(case: Optional[Dict[str, Any]] = None) -> str:
    """
    The watermark line for an export drawn from demonstration data.

    Returns an empty string for real records, so genuine work product is
    never stamped as a sample.
    """
    if case and case.get("is_demo"):
        return config.DEMO_EXPORT_WATERMARK
    return ""


def _timestamped(name: str, extension: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return unique_path(config.EXPORT_DIR, f"{safe_filename(name)}_{stamp}.{extension}")


# ===========================================================================
# Excel
# ===========================================================================
def export_table_excel(rows: Sequence[Dict[str, Any]],
                       columns: Sequence[Tuple[str, str]],
                       filename: str, sheet_title: str = "Report",
                       heading: str = "", subheading: str = "") -> Result:
    """
    Write a list of dictionaries to a formatted Excel worksheet.

    ``columns`` is a sequence of ``(key, heading)`` pairs.
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        return False, ("openpyxl is not installed, so Excel export is unavailable.\n"
                       "Install it with:  pip install openpyxl")

    try:
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = truncate(sheet_title, 30) or "Report"

        thin = Side(style="thin", color="D4DCE5")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        header_fill = PatternFill("solid", fgColor="1F5C99")
        header_font = Font(bold=True, color="FFFFFF", size=10)
        title_font = Font(bold=True, size=14, color="14304F")

        row_index = 1
        if heading:
            sheet.cell(row=row_index, column=1, value=heading).font = title_font
            row_index += 1
        if subheading:
            sheet.cell(row=row_index, column=1, value=subheading).font = Font(
                size=9, color="5F6E7E")
            row_index += 1
        sheet.cell(
            row=row_index, column=1,
            value=f"Generated on {datetime.now():%d-%m-%Y %H:%M}  |  {FOOTER_TEXT}",
        ).font = Font(size=8, italic=True, color="5F6E7E")
        row_index += 2

        header_row = row_index
        for column_index, (_key, title) in enumerate(columns, start=1):
            cell = sheet.cell(row=header_row, column=column_index, value=title)
            cell.fill = header_fill
            cell.font = header_font
            cell.border = border
            cell.alignment = Alignment(horizontal="center", vertical="center",
                                       wrap_text=True)

        for offset, record in enumerate(rows, start=1):
            for column_index, (key, _title) in enumerate(columns, start=1):
                value = record.get(key, "")
                cell = sheet.cell(row=header_row + offset, column=column_index,
                                  value="" if value is None else value)
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.font = Font(size=10)

        for column_index, (key, title) in enumerate(columns, start=1):
            longest = max(
                [len(str(title))] +
                [len(str(record.get(key, ""))) for record in rows] or [10]
            )
            sheet.column_dimensions[get_column_letter(column_index)].width = \
                min(52, max(12, longest + 3))

        sheet.freeze_panes = sheet.cell(row=header_row + 1, column=1)
        sheet.auto_filter.ref = (
            f"A{header_row}:"
            f"{get_column_letter(max(1, len(columns)))}{header_row + len(rows)}"
        )

        path = _timestamped(filename, "xlsx")
        workbook.save(str(path))
        log.info("Excel export written: %s", path)
        return True, str(path)
    except PermissionError:
        return False, ("The Excel file could not be written. If a previous export is "
                       "open in Excel, please close it and try again.")
    except Exception as exc:  # noqa: BLE001
        log.exception("Excel export failed")
        return False, f"Excel export failed: {exc}"


def export_multi_sheet_excel(sheets: Sequence[Tuple[str, Sequence[Dict[str, Any]],
                                                    Sequence[Tuple[str, str]]]],
                             filename: str, heading: str = "") -> Result:
    """Write several tables into one workbook, one sheet each."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        return False, "openpyxl is not installed, so Excel export is unavailable."

    try:
        workbook = Workbook()
        workbook.remove(workbook.active)
        header_fill = PatternFill("solid", fgColor="1F5C99")
        header_font = Font(bold=True, color="FFFFFF", size=10)

        for title, rows, columns in sheets:
            sheet = workbook.create_sheet(truncate(title, 30) or "Sheet")
            sheet.cell(row=1, column=1, value=heading or title).font = Font(
                bold=True, size=13, color="14304F")
            sheet.cell(
                row=2, column=1,
                value=f"Generated on {datetime.now():%d-%m-%Y %H:%M}  |  {FOOTER_TEXT}",
            ).font = Font(size=8, italic=True, color="5F6E7E")

            for column_index, (_key, column_title) in enumerate(columns, start=1):
                cell = sheet.cell(row=4, column=column_index, value=column_title)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", wrap_text=True)
            for offset, record in enumerate(rows, start=1):
                for column_index, (key, _t) in enumerate(columns, start=1):
                    sheet.cell(row=4 + offset, column=column_index,
                               value=record.get(key, ""))
            for column_index, (key, column_title) in enumerate(columns, start=1):
                longest = max([len(str(column_title))] +
                              [len(str(r.get(key, ""))) for r in rows] or [10])
                sheet.column_dimensions[get_column_letter(column_index)].width = \
                    min(52, max(12, longest + 3))
            sheet.freeze_panes = sheet.cell(row=5, column=1)

        path = _timestamped(filename, "xlsx")
        workbook.save(str(path))
        return True, str(path)
    except PermissionError:
        return False, ("The Excel file could not be written. Please close any open "
                       "export and try again.")
    except Exception as exc:  # noqa: BLE001
        log.exception("Multi-sheet Excel export failed")
        return False, f"Excel export failed: {exc}"


# ===========================================================================
# Word
# ===========================================================================
def _docx_available() -> bool:
    try:
        import docx  # noqa: F401

        return True
    except ImportError:
        return False


def export_text_word(text: str, filename: str, heading: str = "",
                     subheading: str = "", monospace: bool = True,
                     disclaimer: bool = True) -> Result:
    """Write plain text (such as a draft reply) to a Word document."""
    if not _docx_available():
        return False, ("python-docx is not installed, so Word export is unavailable.\n"
                       "Install it with:  pip install python-docx")
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt, RGBColor

        document = Document()
        _apply_docx_styles(document, monospace)

        if heading:
            title = document.add_paragraph()
            run = title.add_run(heading)
            run.bold = True
            run.font.size = Pt(15)
            run.font.color.rgb = RGBColor(0x14, 0x30, 0x4F)
        if subheading:
            sub = document.add_paragraph()
            run = sub.add_run(subheading)
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x5F, 0x6E, 0x7E)

        for line in (text or "").split("\n"):
            paragraph = document.add_paragraph(line)
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

        if disclaimer:
            _add_docx_disclaimer(document)

        path = _timestamped(filename, "docx")
        document.save(str(path))
        log.info("Word export written: %s", path)
        return True, str(path)
    except PermissionError:
        return False, ("The Word file could not be written. Please close any open "
                       "export and try again.")
    except Exception as exc:  # noqa: BLE001
        log.exception("Word export failed")
        return False, f"Word export failed: {exc}"


def export_table_word(rows: Sequence[Dict[str, Any]],
                      columns: Sequence[Tuple[str, str]], filename: str,
                      heading: str = "", subheading: str = "",
                      intro: str = "") -> Result:
    """Write a table to a Word document."""
    if not _docx_available():
        return False, "python-docx is not installed, so Word export is unavailable."
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor

        document = Document()
        _apply_docx_styles(document, monospace=False)

        if heading:
            paragraph = document.add_paragraph()
            run = paragraph.add_run(heading)
            run.bold = True
            run.font.size = Pt(15)
            run.font.color.rgb = RGBColor(0x14, 0x30, 0x4F)
        if subheading:
            paragraph = document.add_paragraph()
            run = paragraph.add_run(subheading)
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x5F, 0x6E, 0x7E)
        if intro:
            document.add_paragraph(intro)

        table = document.add_table(rows=1, cols=len(columns))
        table.style = "Table Grid"
        for index, (_key, title) in enumerate(columns):
            cell = table.rows[0].cells[index]
            cell.text = title
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
                    run.font.size = Pt(9)

        for record in rows:
            cells = table.add_row().cells
            for index, (key, _title) in enumerate(columns):
                cells[index].text = str(record.get(key, "") or "")
                for paragraph in cells[index].paragraphs:
                    for run in paragraph.runs:
                        run.font.size = Pt(9)

        _add_docx_disclaimer(document)
        path = _timestamped(filename, "docx")
        document.save(str(path))
        return True, str(path)
    except PermissionError:
        return False, "The Word file could not be written. Please close it and retry."
    except Exception as exc:  # noqa: BLE001
        log.exception("Word table export failed")
        return False, f"Word export failed: {exc}"


def _apply_docx_styles(document, monospace: bool) -> None:
    from docx.shared import Pt

    style = document.styles["Normal"]
    style.font.name = "Consolas" if monospace else "Calibri"
    style.font.size = Pt(9.5 if monospace else 10.5)


def _add_docx_disclaimer(document) -> None:
    from docx.shared import Pt, RGBColor

    document.add_paragraph()
    paragraph = document.add_paragraph()
    run = paragraph.add_run(EXPORT_DISCLAIMER)
    run.italic = True
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0xB0, 0x2A, 0x2A)
    footer = document.add_paragraph()
    run = footer.add_run(FOOTER_TEXT)
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0x5F, 0x6E, 0x7E)


# ===========================================================================
# PDF
# ===========================================================================
def export_text_pdf(text: str, filename: str, heading: str = "",
                    subheading: str = "") -> Result:
    """Write plain text to a PDF with page numbering and a footer."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas as pdf_canvas
    except ImportError:
        return False, ("ReportLab is not installed, so PDF export is unavailable.\n"
                       "Install it with:  pip install reportlab")

    try:
        page_width, page_height = A4
        left = 18 * mm
        top = page_height - 20 * mm
        bottom = 22 * mm
        line_height = 4.3 * mm
        max_chars = 108

        path = _timestamped(filename, "pdf")
        pdf = pdf_canvas.Canvas(str(path), pagesize=A4)
        pdf.setTitle(heading or filename)

        def draw_footer(page_number: int) -> None:
            pdf.setFont("Helvetica-Oblique", 7)
            pdf.setFillColorRGB(0.37, 0.43, 0.49)
            pdf.drawString(left, 14 * mm, FOOTER_TEXT)
            pdf.drawRightString(page_width - left, 14 * mm, f"Page {page_number}")
            pdf.setFillColorRGB(0, 0, 0)

        page = 1
        y = top
        if heading:
            pdf.setFont("Helvetica-Bold", 13)
            pdf.drawString(left, y, heading[:90])
            y -= 6 * mm
        if subheading:
            pdf.setFont("Helvetica", 8.5)
            pdf.setFillColorRGB(0.37, 0.43, 0.49)
            pdf.drawString(left, y, subheading[:120])
            pdf.setFillColorRGB(0, 0, 0)
            y -= 6 * mm

        pdf.setFont("Courier", 8.4)
        for raw_line in (text or "").split("\n"):
            chunks = _wrap_line(raw_line, max_chars)
            for chunk in chunks:
                if y < bottom:
                    draw_footer(page)
                    pdf.showPage()
                    page += 1
                    y = top
                    pdf.setFont("Courier", 8.4)
                pdf.drawString(left, y, chunk)
                y -= line_height

        if y < bottom + 20 * mm:
            draw_footer(page)
            pdf.showPage()
            page += 1
            y = top
        pdf.setFont("Helvetica-Oblique", 7.5)
        pdf.setFillColorRGB(0.69, 0.16, 0.16)
        for chunk in _wrap_line(EXPORT_DISCLAIMER, 118):
            y -= line_height
            pdf.drawString(left, y, chunk)
        pdf.setFillColorRGB(0, 0, 0)

        draw_footer(page)
        pdf.save()
        log.info("PDF export written: %s", path)
        return True, str(path)
    except PermissionError:
        return False, "The PDF could not be written. Please close it and retry."
    except Exception as exc:  # noqa: BLE001
        log.exception("PDF export failed")
        return False, f"PDF export failed: {exc}"


def export_table_pdf(rows: Sequence[Dict[str, Any]],
                     columns: Sequence[Tuple[str, str, int]], filename: str,
                     heading: str = "", subheading: str = "") -> Result:
    """
    Write a table to a landscape PDF.

    ``columns`` is a sequence of ``(key, heading, width_mm)``.
    """
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import (
            Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)
    except ImportError:
        return False, "ReportLab is not installed, so PDF export is unavailable."

    try:
        path = _timestamped(filename, "pdf")
        document = SimpleDocTemplate(
            str(path), pagesize=landscape(A4),
            leftMargin=14 * mm, rightMargin=14 * mm,
            topMargin=14 * mm, bottomMargin=14 * mm, title=heading or filename)

        title_style = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=13,
                                     textColor=colors.HexColor("#14304F"),
                                     spaceAfter=4)
        sub_style = ParagraphStyle("sub", fontName="Helvetica", fontSize=8,
                                   textColor=colors.HexColor("#5F6E7E"), spaceAfter=8)
        cell_style = ParagraphStyle("cell", fontName="Helvetica", fontSize=7.5,
                                    leading=9.5)
        head_style = ParagraphStyle("head", fontName="Helvetica-Bold", fontSize=7.5,
                                    leading=9.5, textColor=colors.white)
        note_style = ParagraphStyle("note", fontName="Helvetica-Oblique", fontSize=7,
                                    textColor=colors.HexColor("#B02A2A"), spaceBefore=8)

        story: List[Any] = []
        if heading:
            story.append(Paragraph(heading, title_style))
        story.append(Paragraph(
            (subheading + "  |  " if subheading else "")
            + f"Generated on {datetime.now():%d-%m-%Y %H:%M}  |  {FOOTER_TEXT}",
            sub_style))

        data = [[Paragraph(title, head_style) for _key, title, _w in columns]]
        for record in rows:
            data.append([
                Paragraph(str(record.get(key, "") or "").replace("\n", "<br/>"),
                          cell_style)
                for key, _title, _w in columns
            ])

        table = Table(data, colWidths=[w * mm for _k, _t, w in columns],
                      repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F5C99")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#D4DCE5")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#FAFBFD")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(table)
        story.append(Spacer(1, 6))
        story.append(Paragraph(EXPORT_DISCLAIMER, note_style))

        document.build(story)
        return True, str(path)
    except PermissionError:
        return False, "The PDF could not be written. Please close it and retry."
    except Exception as exc:  # noqa: BLE001
        log.exception("PDF table export failed")
        return False, f"PDF export failed: {exc}"


def _wrap_line(text: str, width: int) -> List[str]:
    """Wrap a line for fixed-width PDF output, preserving leading indent."""
    line = (text or "").rstrip()
    if len(line) <= width:
        return [line]
    indent = len(line) - len(line.lstrip())
    prefix = " " * indent
    words = line.split()
    out: List[str] = []
    current = prefix
    for word in words:
        candidate = f"{current}{word} " if current.strip() else f"{prefix}{word} "
        if len(candidate) > width:
            out.append(current.rstrip())
            current = f"{prefix}{word} "
        else:
            current = candidate
    if current.strip():
        out.append(current.rstrip())
    return out or [""]


# ===========================================================================
# Domain-specific exports
# ===========================================================================
REQUIREMENT_EXPORT_COLUMNS = [
    ("sr", "Sr."),
    ("document_name", "Document / Information Required"),
    ("purpose", "Purpose"),
    ("requirement_type", "Mandatory / Conditional"),
    ("status", "Status"),
    ("received_date", "Received On"),
    ("remarks", "Remarks"),
]


def requirement_rows(records: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Shape requirement records for export."""
    rows = []
    for index, record in enumerate(records, start=1):
        rows.append({
            "sr": index,
            "document_name": record.get("document_name", ""),
            "purpose": record.get("purpose", ""),
            "requirement_type": record.get("requirement_type", ""),
            "status": record.get("status", ""),
            "received_date": format_date(record.get("received_date"), ""),
            "remarks": record.get("remarks", ""),
        })
    return rows


def export_requirements(records: Sequence[Dict[str, Any]], case: Dict[str, Any],
                        fmt: str = "excel", covering_note: str = "") -> Result:
    """Export the client requirement list to Excel, Word or PDF."""
    rows = requirement_rows(records)
    client = case.get("client_name", "Client")
    heading = f"Client Document Requirement List - {client}"
    subheading = (
        f"Case {case.get('case_code', '')}  |  {case.get('notice_type', '')} "
        f"{case.get('notice_number', '')}  |  FY {case.get('financial_year', '')}  |  "
        f"Reply due {format_date(case.get('due_date'))}"
    )
    watermark = demo_banner(case)
    if watermark:
        subheading = watermark + "  |  " + subheading
        covering_note = (watermark + "\n\n" + covering_note) if covering_note \
            else watermark
    filename = f"Requirements_{safe_filename(client)}_{case.get('case_code', '')}"

    if fmt == "excel":
        return export_table_excel(rows, REQUIREMENT_EXPORT_COLUMNS, filename,
                                  "Requirements", heading, subheading)
    if fmt == "word":
        return export_table_word(rows, REQUIREMENT_EXPORT_COLUMNS, filename,
                                 heading, subheading,
                                 intro=covering_note or "")
    if fmt == "pdf":
        columns = [("sr", "Sr.", 12), ("document_name", "Document Required", 78),
                   ("purpose", "Purpose", 70),
                   ("requirement_type", "Type", 26), ("status", "Status", 26),
                   ("received_date", "Received", 24), ("remarks", "Remarks", 40)]
        return export_table_pdf(rows, columns, filename, heading, subheading)
    return False, f"Unknown export format: {fmt}"


def export_notice_analysis(result, case: Dict[str, Any], fmt: str = "word") -> Result:
    """Export the notice analysis (overview, demand and issues) as a document."""
    data = result.data
    demand = result.demand
    lines: List[str] = []
    add = lines.append

    add("GST NOTICE ANALYSIS")
    add("=" * 78)
    add("")
    add("CASE OVERVIEW")
    for label, value in (
        ("Taxpayer", data.get("taxpayer_name")),
        ("GSTIN", data.get("gstin")),
        ("Case ID", case.get("case_code")),
        ("Notice Type", data.get("notice_type")),
        ("Notice Number", data.get("notice_number")),
        ("Financial Year", data.get("financial_year")),
        ("Tax Period", data.get("tax_period")),
        ("Notice Date", format_date(data.get("notice_date"))),
        ("Reply Due Date", format_date(data.get("reply_due_date"))),
        ("Officer", data.get("officer_name")),
        ("Designation", data.get("designation")),
        ("Jurisdiction", data.get("jurisdiction")),
    ):
        add(f"  {label:<18}: {value or '-'}")
    from utils.formatters import join_list

    add(f"  {'Sections Invoked':<18}: {join_list(data.get('sections_invoked'))}")
    add(f"  {'Rules Invoked':<18}: {join_list(data.get('rules_invoked'))}")
    add("")
    add("DEMAND SUMMARY (computed in Python)")
    for label, amount, is_total in demand.rows():
        marker = "  " if not is_total else "* "
        add(f"  {marker}{label:<18}: {format_currency(amount):>18}")
    add("")
    add("SUMMARY OF THE NOTICE")
    for chunk in _wrap_line(data.get("summary") or "-", 76):
        add(f"  {chunk}")
    add("")
    add("ISSUES IDENTIFIED")
    for issue in result.issues:
        add("")
        add(f"  Issue {issue.get('issue_no')}: {issue.get('issue_title', '')}")
        add(f"    Amount     : {format_currency(issue.get('amount'))}")
        add(f"    Sections   : {join_list(issue.get('sections'))}")
        add(f"    Risk       : {issue.get('initial_risk')}  "
            f"(confidence: {issue.get('confidence')})")
        add("    Allegation :")
        for chunk in _wrap_line(issue.get("department_allegation") or "-", 68):
            add(f"      {chunk}")
        add("    Facts identified from the notice:")
        for fact in issue.get("facts_identified") or ["(none recorded)"]:
            for chunk in _wrap_line(f"- {fact}", 68):
                add(f"      {chunk}")
        add("    Facts missing / to be obtained:")
        for fact in issue.get("facts_missing") or ["(none recorded)"]:
            for chunk in _wrap_line(f"- {fact}", 68):
                add(f"      {chunk}")
    add("")
    add(f"Source of extraction: {result.source}")

    text = "\n".join(lines)
    filename = f"NoticeAnalysis_{safe_filename(case.get('client_name', 'case'))}_" \
               f"{case.get('case_code', '')}"
    heading = f"GST Notice Analysis - {case.get('client_name', '')}"
    subheading = f"Case {case.get('case_code', '')}  |  Source: {result.source}"
    watermark = demo_banner(case)
    if watermark:
        subheading = watermark + "  |  " + subheading
        text = watermark + "\n" + ("=" * 74) + "\n\n" + text

    if fmt == "word":
        return export_text_word(text, filename, heading, subheading)
    if fmt == "pdf":
        return export_text_pdf(text, filename, heading, subheading)
    return False, f"Unknown export format: {fmt}"


def export_research(record: Dict[str, Any], fmt: str = "word") -> Result:
    """Export one research answer with its sources."""
    text = (f"GST RESEARCH\n{'=' * 78}\n\n"
            f"RESEARCH QUESTION\n  {record.get('question', '')}\n\n"
            f"{record.get('answer', '')}\n\n"
            f"SOURCES USED\n{record.get('sources', '') or '  (none)'}\n")
    filename = f"Research_{safe_filename(truncate(record.get('question', ''), 40))}"
    heading = "GST Research - source-grounded answer"
    subheading = f"Generated on {format_date(record.get('created_at'))}"
    if fmt == "word":
        return export_text_word(text, filename, heading, subheading, monospace=True)
    if fmt == "pdf":
        return export_text_pdf(text, filename, heading, subheading)
    return False, f"Unknown export format: {fmt}"


def export_draft(draft: Dict[str, Any], case: Dict[str, Any],
                 fmt: str = "word") -> Result:
    """Export a draft reply."""
    client = case.get("client_name", "Client")
    filename = f"DraftReply_{safe_filename(client)}_{case.get('case_code', '')}_" \
               f"v{draft.get('version', 1)}"
    heading = f"Draft Reply - {client}"
    subheading = (f"Case {case.get('case_code', '')}  |  Version "
                  f"{draft.get('version', 1)}  |  Status: {draft.get('status', '')}")
    text = draft.get("draft_text", "")
    watermark = demo_banner(case)
    if watermark:
        subheading = watermark + "  |  " + subheading
        text = watermark + "\n" + ("=" * 74) + "\n\n" + text
    if fmt == "word":
        return export_text_word(text, filename, heading, subheading, monospace=True)
    if fmt == "pdf":
        return export_text_pdf(text, filename, heading, subheading)
    return False, f"Unknown export format: {fmt}"
