"""
services.pdf_service
====================
PDF reading with PyMuPDF.

Text is extracted page by page so that a page reference can be kept for
every passage -- this matters for the knowledge base, where the research
answer must cite the page a passage came from.

Scanned/image-only PDFs are detected and reported clearly; OCR is not
available in this version and the application never fails silently.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from utils.logger import get_logger

log = get_logger(__name__)

# A page with fewer than this many characters is treated as having no
# usable text layer (typical for scanned images).
MIN_CHARS_PER_PAGE = 25
MIN_CHARS_TOTAL = 120

SCANNED_PDF_MESSAGE = (
    "This appears to be a scanned/image-based PDF. OCR is not currently available "
    "in this version. Please upload a searchable PDF or manually paste the notice text."
)


class PDFError(Exception):
    """Raised when a PDF cannot be opened or read."""


@dataclass
class PageText:
    """Text of a single PDF page."""

    page: int          # 1-based
    text: str

    @property
    def char_count(self) -> int:
        return len(self.text.strip())


@dataclass
class PDFExtractionResult:
    """Outcome of reading a PDF."""

    file_path: str
    page_count: int = 0
    pages: List[PageText] = field(default_factory=list)
    has_text: bool = False
    is_scanned: bool = False
    encrypted: bool = False
    error: str = ""
    message: str = ""

    @property
    def text(self) -> str:
        """Full document text with page markers."""
        return "\n\n".join(
            f"--- Page {page.page} ---\n{page.text}".rstrip()
            for page in self.pages if page.text.strip()
        )

    @property
    def plain_text(self) -> str:
        """Full document text without page markers."""
        return "\n\n".join(page.text for page in self.pages if page.text.strip())

    @property
    def char_count(self) -> int:
        return sum(page.char_count for page in self.pages)

    @property
    def ok(self) -> bool:
        return self.has_text and not self.error


# ---------------------------------------------------------------------------
def _import_fitz():
    """Import PyMuPDF, raising a friendly error when it is not installed."""
    try:
        import pymupdf as fitz  # PyMuPDF >= 1.24 preferred import name

        return fitz
    except ImportError:
        pass
    try:
        import fitz  # type: ignore

        return fitz
    except ImportError as exc:
        raise PDFError(
            "PyMuPDF is not installed. Install it with:  pip install pymupdf"
        ) from exc


def clean_page_text(raw: str) -> str:
    """
    Tidy raw PDF text: normalise whitespace, drop stray form feeds and
    repair words broken across a line by a hyphen.
    """
    if not raw:
        return ""
    text = raw.replace("\r\n", "\n").replace("\r", "\n").replace("\x0c", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    # join hyphenated line breaks: "invo-\nice" -> "invoice"
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    lines = [line.strip() for line in text.split("\n")]
    cleaned: List[str] = []
    blank = False
    for line in lines:
        if line:
            cleaned.append(line)
            blank = False
        elif not blank:
            cleaned.append("")
            blank = True
    return "\n".join(cleaned).strip()


def extract_pdf(file_path: str | Path, max_pages: Optional[int] = None
                ) -> PDFExtractionResult:
    """
    Read a PDF and return page-wise text.

    Never raises for ordinary problems -- inspect ``result.error`` and
    ``result.is_scanned`` instead.
    """
    path = Path(file_path)
    result = PDFExtractionResult(file_path=str(path))

    if not path.exists():
        result.error = f"File not found: {path}"
        result.message = result.error
        return result
    if path.suffix.lower() != ".pdf":
        result.error = "Only PDF files are supported."
        result.message = result.error
        return result

    try:
        fitz = _import_fitz()
    except PDFError as exc:
        result.error = str(exc)
        result.message = result.error
        return result

    document = None
    try:
        document = fitz.open(str(path))
        if document.needs_pass:
            result.encrypted = True
            result.error = "This PDF is password protected and cannot be read."
            result.message = result.error
            return result

        result.page_count = document.page_count
        limit = min(document.page_count, max_pages or document.page_count)
        for index in range(limit):
            page = document.load_page(index)
            raw = page.get_text("text") or ""
            result.pages.append(PageText(page=index + 1, text=clean_page_text(raw)))

    except Exception as exc:  # noqa: BLE001 - PyMuPDF raises varied errors
        log.exception("Could not read PDF %s", path)
        result.error = f"The PDF could not be read: {exc}"
        result.message = result.error
        return result
    finally:
        if document is not None:
            try:
                document.close()
            except Exception:  # noqa: BLE001
                pass

    pages_with_text = [p for p in result.pages if p.char_count >= MIN_CHARS_PER_PAGE]
    result.has_text = bool(pages_with_text) and result.char_count >= MIN_CHARS_TOTAL
    result.is_scanned = not result.has_text

    if result.is_scanned:
        result.message = SCANNED_PDF_MESSAGE
    else:
        result.message = (
            f"Extracted {result.char_count:,} characters from "
            f"{len(pages_with_text)} of {result.page_count} page(s)."
        )
    log.info("PDF read: %s -> %s", path.name, result.message)
    return result


def extract_text(file_path: str | Path) -> Tuple[str, str]:
    """
    Convenience wrapper.

    Returns ``(text, message)``; ``text`` is empty when nothing usable
    could be extracted.
    """
    result = extract_pdf(file_path)
    return (result.text if result.ok else ""), result.message


def pdf_metadata(file_path: str | Path) -> dict:
    """Basic PDF metadata for the knowledge base listing."""
    path = Path(file_path)
    info = {"pages": 0, "title": "", "size": 0}
    try:
        info["size"] = path.stat().st_size
        fitz = _import_fitz()
        with fitz.open(str(path)) as document:
            info["pages"] = document.page_count
            info["title"] = (document.metadata or {}).get("title", "") or ""
    except (PDFError, OSError, Exception):  # noqa: BLE001
        pass
    return info


def is_pdf_readable(file_path: str | Path) -> bool:
    """Quick check used before adding a document to the knowledge base."""
    return extract_pdf(file_path, max_pages=3).has_text
