"""
services.rag_service
====================
Local retrieval over the firm's GST knowledge base.

Design choice
-------------
Retrieval uses a **pure-Python TF-IDF ranker** over page-anchored text
chunks stored in SQLite.  No vector database, no native build tools and
no extra installation are required, which matters on Windows and in a
classroom setting.  Accuracy is more than adequate for statute, rule,
circular and case-note lookup, and every retrieved passage keeps its
file name, category and page number so the research answer can cite a
real source.

Pipeline::

    PDF -> page text -> overlapping chunks -> SQLite
    question -> tokens -> TF-IDF score per chunk -> top K chunks
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import config
from database import database as db
from services.pdf_service import extract_pdf
from utils.formatters import truncate
from utils.helpers import relative_to_base, resolve_stored_path
from utils.logger import get_logger

log = get_logger(__name__)

DEFAULT_CHUNK_SIZE = 1200
DEFAULT_OVERLAP = 150
MIN_CHUNK_CHARS = 120

# Words that carry no retrieval signal in this domain
STOP_WORDS = {
    "a", "an", "the", "and", "or", "of", "to", "in", "on", "for", "with", "by",
    "is", "are", "was", "were", "be", "been", "being", "as", "at", "from", "that",
    "this", "these", "those", "it", "its", "which", "who", "whom", "whose", "what",
    "when", "where", "why", "how", "shall", "may", "can", "will", "would", "should",
    "could", "any", "all", "such", "not", "no", "if", "then", "than", "so", "but",
    "there", "here", "he", "she", "they", "we", "you", "i", "his", "her", "their",
    "our", "your", "my", "me", "us", "them", "him", "into", "under", "over",
    "whether", "case", "cases", "please", "kindly", "regard", "regarding",
}

TOKEN_RE = re.compile(r"[a-z0-9]+(?:\([a-z0-9]+\))?", re.IGNORECASE)


@dataclass
class RetrievedChunk:
    """One knowledge-base passage returned by the search."""

    ref: str                      # S1, S2, ...
    score: float
    file_name: str
    category: str
    page: int
    text: str
    document_id: int = 0

    @property
    def citation(self) -> str:
        page = f", page {self.page}" if self.page else ""
        return f"[{self.ref}] {self.file_name} ({self.category}{page})"

    def excerpt(self, length: int = 300) -> str:
        return truncate(self.text, length)


@dataclass
class IndexResult:
    """Outcome of indexing the knowledge base."""

    documents_indexed: int = 0
    documents_skipped: int = 0
    chunks: int = 0
    problems: List[str] = field(default_factory=list)

    @property
    def message(self) -> str:
        parts = [f"{self.documents_indexed} document(s) indexed",
                 f"{self.chunks} passage(s) stored"]
        if self.documents_skipped:
            parts.append(f"{self.documents_skipped} skipped")
        return ", ".join(parts) + "."


# ---------------------------------------------------------------------------
# Tokenisation
# ---------------------------------------------------------------------------
def tokenize(text: str) -> List[str]:
    """Lower-cased alphanumeric tokens with stop words removed."""
    tokens = [t.lower() for t in TOKEN_RE.findall(text or "")]
    return [t for t in tokens if len(t) > 1 and t not in STOP_WORDS]


def _section_tokens(text: str) -> List[str]:
    """
    Extra tokens for statutory references so that 'Section 16(2)(c)' and
    'Rule 36(4)' match precisely rather than only on the bare number.
    """
    out: List[str] = []
    for match in re.finditer(
        r"(?i)\b(section|sec\.?|rule|notification|circular)\s*([0-9]+[A-Za-z]?"
        r"(?:\s*\([0-9a-zA-Z]+\))*)", text or ""
    ):
        kind = match.group(1).lower().rstrip(".")
        kind = "section" if kind in ("sec", "section") else kind
        number = re.sub(r"\s+", "", match.group(2))
        out.append(f"{kind}{number}".lower())
    return out


def index_terms(text: str) -> List[str]:
    return tokenize(text) + _section_tokens(text)


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------
def chunk_page(text: str, chunk_size: int = DEFAULT_CHUNK_SIZE,
               overlap: int = DEFAULT_OVERLAP) -> List[str]:
    """
    Split one page into overlapping chunks, preferring paragraph and
    sentence boundaries so a provision is not cut in half.
    """
    body = (text or "").strip()
    if not body:
        return []
    if len(body) <= chunk_size:
        return [body]

    chunks: List[str] = []
    start = 0
    length = len(body)
    while start < length:
        end = min(start + chunk_size, length)
        if end < length:
            window = body[start:end]
            for separator in ("\n\n", ". ", ".\n", "; ", "\n"):
                cut = window.rfind(separator)
                if cut > chunk_size * 0.55:
                    end = start + cut + len(separator)
                    break
        piece = body[start:end].strip()
        if len(piece) >= MIN_CHUNK_CHARS or not chunks:
            chunks.append(piece)
        elif chunks:
            chunks[-1] = f"{chunks[-1]}\n{piece}".strip()
        if end >= length:
            break
        start = max(end - overlap, start + 1)
    return [c for c in chunks if c.strip()]


def build_chunks(document: Dict[str, Any], pages, chunk_size: int
                 ) -> List[Dict[str, Any]]:
    """Turn page texts into chunk rows ready for the database."""
    rows: List[Dict[str, Any]] = []
    index = 0
    for page in pages:
        for piece in chunk_page(page.text, chunk_size):
            rows.append({
                "file_name": document.get("file_name", ""),
                "category": document.get("category", ""),
                "page": page.page,
                "chunk_index": index,
                "chunk_text": piece,
            })
            index += 1
    return rows


# ---------------------------------------------------------------------------
# Adding and indexing documents
# ---------------------------------------------------------------------------
def add_document(source_path: str | Path, category: str, notes: str = "",
                 copy_file: bool = True, is_demo: bool = False
                 ) -> Tuple[bool, str, Optional[int]]:
    """
    Register a PDF in the knowledge base.

    The file is copied into ``knowledge_base/<category>/`` unless it is
    already inside that folder.  Returns ``(ok, message, document_id)``.
    """
    source = Path(source_path)
    if not source.is_file():
        return False, f"File not found: {source}", None
    if source.suffix.lower() != ".pdf":
        return False, "Only PDF files can be added to the knowledge base.", None
    if category not in config.KB_CATEGORIES:
        category = "internal_research"

    target_dir = config.KNOWLEDGE_BASE_DIR / category
    target_dir.mkdir(parents=True, exist_ok=True)

    destination = source
    if copy_file and source.parent.resolve() != target_dir.resolve():
        from utils.helpers import copy_into

        copied = copy_into(source, target_dir)
        if copied is None:
            return False, "The file could not be copied into the knowledge base.", None
        destination = copied

    probe = extract_pdf(destination, max_pages=3)
    if probe.error and not probe.is_scanned:
        return False, probe.error, None

    document_id = db.add_knowledge_document(
        file_name=destination.name,
        file_path=relative_to_base(destination),
        category=category,
        title=destination.stem.replace("_", " "),
        notes=notes,
        is_demo=is_demo,
    )
    if probe.is_scanned:
        db.update_knowledge_document(document_id, {"indexed": 0, "notes": (
            notes + " | No text layer detected (scanned PDF) - OCR is not available "
                    "in this version.").strip(" |")})
        return (True,
                f"'{destination.name}' was added but no text layer was found. "
                "It cannot be searched until a searchable PDF is supplied.",
                document_id)

    return True, f"'{destination.name}' added to the knowledge base.", document_id


def index_document(document: Dict[str, Any], chunk_size: int = DEFAULT_CHUNK_SIZE
                   ) -> Tuple[bool, str, int]:
    """Extract, chunk and store one document.  Returns ``(ok, message, chunks)``."""
    path = resolve_stored_path(document.get("file_path", ""))
    if not path.exists():
        db.update_knowledge_document(int(document["id"]), {"indexed": 0})
        return False, f"File missing: {path.name}", 0

    extraction = extract_pdf(path)
    if not extraction.ok:
        db.update_knowledge_document(int(document["id"]),
                                     {"indexed": 0, "pages": extraction.page_count})
        return False, f"{path.name}: {extraction.message}", 0

    rows = build_chunks(document, extraction.pages, chunk_size)
    db.replace_document_chunks(int(document["id"]), rows)
    db.update_knowledge_document(int(document["id"]),
                                 {"pages": extraction.page_count,
                                  "chunk_count": len(rows), "indexed": 1})
    log.info("Indexed %s: %d chunk(s) from %d page(s)",
             path.name, len(rows), extraction.page_count)
    return True, f"{path.name}: {len(rows)} passage(s) indexed.", len(rows)


def rebuild_index(chunk_size: int = DEFAULT_CHUNK_SIZE,
                  only_unindexed: bool = False,
                  progress=None) -> IndexResult:
    """
    Index every knowledge-base document.

    ``progress`` is an optional callable receiving ``(done, total, message)``.
    """
    result = IndexResult()
    documents = db.list_knowledge_documents()
    if only_unindexed:
        documents = [d for d in documents if not d.get("indexed")]

    total = len(documents)
    for position, document in enumerate(documents, start=1):
        ok, message, chunks = index_document(document, chunk_size)
        if ok:
            result.documents_indexed += 1
            result.chunks += chunks
        else:
            result.documents_skipped += 1
            result.problems.append(message)
        if progress:
            try:
                progress(position, total, message)
            except Exception:  # noqa: BLE001 - progress must never break indexing
                pass
    _invalidate_cache()
    return result


def sync_folder() -> Tuple[int, List[str]]:
    """
    Register any PDF sitting in the knowledge_base folders that is not yet
    in the database.  Returns ``(added, messages)``.
    """
    added = 0
    messages: List[str] = []
    known = {d["file_path"] for d in db.list_knowledge_documents()}
    for category in config.KB_CATEGORIES:
        folder = config.KNOWLEDGE_BASE_DIR / category
        if not folder.exists():
            continue
        for pdf in sorted(folder.glob("*.pdf")):
            if relative_to_base(pdf) in known:
                continue
            ok, message, _document_id = add_document(pdf, category, copy_file=False)
            if ok:
                added += 1
            messages.append(message)
    return added, messages


def remove_document(document_id: int, delete_file: bool = False) -> Tuple[bool, str]:
    """Remove a document (and its chunks) from the knowledge base."""
    document = db.get_knowledge_document(document_id)
    if not document:
        return False, "Document not found."
    path = resolve_stored_path(document.get("file_path", ""))
    db.delete_knowledge_document(document_id)
    _invalidate_cache()
    if delete_file:
        try:
            if path.exists():
                path.unlink()
        except OSError as exc:
            return True, (f"Removed from the index, but the file could not be "
                          f"deleted: {exc}")
    return True, f"'{document.get('file_name')}' removed from the knowledge base."


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------
_CACHE: Dict[str, Any] = {"chunks": None, "df": None, "count": 0}


def _invalidate_cache() -> None:
    _CACHE["chunks"] = None
    _CACHE["df"] = None
    _CACHE["count"] = 0


def _load_corpus(category: str = "") -> Tuple[List[Dict[str, Any]], Counter, int]:
    """Load chunks and document frequencies, cached between searches."""
    key = category or "__all__"
    if _CACHE.get("chunks") is not None and _CACHE.get("key") == key:
        return _CACHE["chunks"], _CACHE["df"], _CACHE["count"]

    rows = db.list_knowledge_chunks(category)
    prepared: List[Dict[str, Any]] = []
    document_frequency: Counter = Counter()
    for row in rows:
        terms = index_terms(row.get("chunk_text", ""))
        if not terms:
            continue
        counts = Counter(terms)
        prepared.append({
            "row": row,
            "counts": counts,
            "length": sum(counts.values()),
            "lower": (row.get("chunk_text") or "").lower(),
        })
        for term in counts:
            document_frequency[term] += 1

    _CACHE.update({"chunks": prepared, "df": document_frequency,
                   "count": len(prepared), "key": key})
    return prepared, document_frequency, len(prepared)


def search(question: str, top_k: int = 6, category: str = "",
           min_score: float = 0.05) -> List[RetrievedChunk]:
    """
    Retrieve the most relevant knowledge-base passages for a question.

    Scoring is TF-IDF with a length normaliser, plus a bonus when the
    exact phrase or a statutory reference appears verbatim.
    """
    query_terms = index_terms(question)
    if not query_terms:
        return []

    corpus, document_frequency, total = _load_corpus(category)
    if not corpus:
        return []

    query_counts = Counter(query_terms)
    phrase = " ".join(tokenize(question)[:6])
    section_refs = set(_section_tokens(question))

    scored: List[Tuple[float, Dict[str, Any]]] = []
    for entry in corpus:
        counts = entry["counts"]
        score = 0.0
        matched = 0
        for term, query_frequency in query_counts.items():
            term_frequency = counts.get(term, 0)
            if not term_frequency:
                continue
            matched += 1
            idf = math.log((total + 1) / (document_frequency.get(term, 0) + 1)) + 1.0
            score += (1 + math.log(term_frequency)) * idf * (1 + math.log(query_frequency))
        if not matched:
            continue
        # Normalise for chunk length so long chunks do not dominate.
        score /= math.sqrt(entry["length"]) or 1.0
        # Coverage bonus: rewarding chunks that hit more distinct query terms.
        score *= 1 + (matched / max(1, len(query_counts))) * 0.6
        if phrase and phrase in entry["lower"]:
            score *= 1.5
        for ref in section_refs:
            if ref in counts:
                score *= 1.35
        scored.append((score, entry))

    if not scored:
        return []

    scored.sort(key=lambda item: item[0], reverse=True)
    best = scored[0][0] or 1.0

    results: List[RetrievedChunk] = []
    for position, (score, entry) in enumerate(scored[:top_k], start=1):
        if score / best < min_score:
            break
        row = entry["row"]
        results.append(RetrievedChunk(
            ref=f"S{position}",
            score=round(score, 4),
            file_name=row.get("file_name", ""),
            category=row.get("category", ""),
            page=int(row.get("page") or 0),
            text=row.get("chunk_text", ""),
            document_id=int(row.get("document_id") or 0),
        ))
    return results


def format_sources_for_prompt(chunks: Sequence[RetrievedChunk],
                              max_chars_each: int = 1600) -> str:
    """
    Render retrieved passages for the AI prompt.

    Only these passages may be cited -- the prompt says so explicitly.
    """
    if not chunks:
        return ("NO SOURCES WERE RETRIEVED FROM THE LOCAL KNOWLEDGE BASE.\n"
                "You must therefore state that no sufficiently relevant source was "
                "located, and you must not cite anything.")
    blocks: List[str] = []
    for chunk in chunks:
        page = f", page {chunk.page}" if chunk.page else ""
        text = chunk.text[:max_chars_each]
        blocks.append(
            f"[{chunk.ref}] Source file: {chunk.file_name} "
            f"(category: {chunk.category}{page})\n"
            f"Extract:\n{text}\n"
        )
    return "\n" + ("\n" + "-" * 60 + "\n").join(blocks)


def knowledge_base_status() -> Dict[str, Any]:
    """Summary shown on the Knowledge Base and Settings screens."""
    documents = db.list_knowledge_documents()
    indexed = [d for d in documents if d.get("indexed")]
    by_category: Dict[str, int] = {}
    for document in documents:
        category = document.get("category", "other")
        by_category[category] = by_category.get(category, 0) + 1
    return {
        "documents": len(documents),
        "indexed": len(indexed),
        "unindexed": len(documents) - len(indexed),
        "chunks": db.knowledge_chunk_count(),
        "by_category": by_category,
        "folder": str(config.KNOWLEDGE_BASE_DIR),
    }
