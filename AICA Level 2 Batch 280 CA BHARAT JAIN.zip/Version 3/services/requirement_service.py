"""
services.requirement_service
============================
Client document requirement generation and tracking.

The AI proposes a checklist tailored to the allegation; the Chartered
Accountant then adds, edits or removes items and records what has been
received.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import config
from database import database as db
from services import ai_service, mock_data
from services.issue_service import build_case_context
from utils.formatters import format_currency, join_list
from utils.helpers import load_prompt
from utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class RequirementResult:
    """Outcome of one requirement-generation run."""

    ok: bool = False
    checklist: List[Dict[str, str]] = field(default_factory=list)
    information_to_confirm: List[str] = field(default_factory=list)
    reconciliations: List[str] = field(default_factory=list)
    covering_note: str = ""
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    source: str = ""


def build_issue_context(issues: List[Dict[str, Any]]) -> str:
    """Describe the issue(s) the checklist must cover."""
    if not issues:
        return ("No specific issue selected - prepare a checklist covering the "
                "notice as a whole.")
    blocks: List[str] = []
    for issue in issues:
        blocks.append(
            f"Issue {issue.get('issue_no', '')}: "
            f"{issue.get('title') or issue.get('issue_title', '')}\n"
            f"Allegation: {issue.get('allegation') or issue.get('department_allegation', '')}\n"
            f"Amount involved: {format_currency(issue.get('amount'))}\n"
            f"Sections referred to: {join_list(issue.get('sections'), fallback='Not stated')}"
        )
    return "\n\n".join(blocks)


def build_prompt(case: Optional[Dict[str, Any]], issues: List[Dict[str, Any]]) -> str:
    template = load_prompt("document_requirements")
    if not template:
        from services.prompt_setup import DOCUMENT_REQUIREMENTS

        template = DOCUMENT_REQUIREMENTS
    safety = load_prompt("_safety_rules")
    try:
        return template.format(
            safety=safety,
            case_context=build_case_context(case),
            issue_context=build_issue_context(issues),
        )
    except (KeyError, IndexError, ValueError) as exc:
        log.error("document_requirements prompt template is malformed: %s", exc)
        return (f"{safety}\n\nPrepare a GST document requirement checklist as JSON.\n\n"
                f"{build_issue_context(issues)}")


def generate_requirements(case: Optional[Dict[str, Any]],
                          issues: Optional[List[Dict[str, Any]]] = None,
                          demo_mode: bool = True) -> RequirementResult:
    """Ask the AI for a tailored document checklist (run on a worker thread)."""
    issues = issues or []
    result = RequirementResult(demo=demo_mode)

    response = ai_service.generate(
        build_prompt(case, issues),
        demo_mode=demo_mode,
        demo_payload=mock_data.document_requirements(issues[0] if issues else None),
        expect_json=True,
        temperature=0.2,
        label="Document requirements",
    )

    result.demo = response.demo
    result.source = response.source_label

    if not response.ok:
        result.error = response.friendly_error
        result.error_kind = response.error_kind
        return result

    data = response.data if isinstance(response.data, dict) else {}
    checklist_raw = data.get("checklist")
    checklist: List[Dict[str, str]] = []
    if isinstance(checklist_raw, list):
        for item in checklist_raw:
            if isinstance(item, str):
                checklist.append({"document_name": item, "purpose": "",
                                  "requirement_type": "Mandatory", "remarks": ""})
            elif isinstance(item, dict):
                name = str(item.get("document_name") or item.get("name") or "").strip()
                if not name:
                    continue
                requirement_type = str(item.get("requirement_type") or "Mandatory").strip()
                if requirement_type not in config.REQUIREMENT_TYPES:
                    requirement_type = "Mandatory"
                checklist.append({
                    "document_name": name,
                    "purpose": str(item.get("purpose") or "").strip(),
                    "requirement_type": requirement_type,
                    "remarks": str(item.get("remarks") or "").strip(),
                })

    result.ok = True
    result.checklist = checklist
    result.information_to_confirm = [
        str(v) for v in (data.get("information_to_confirm") or []) if str(v).strip()
    ]
    result.reconciliations = [
        str(v) for v in (data.get("reconciliations_to_prepare") or []) if str(v).strip()
    ]
    result.covering_note = str(data.get("covering_note") or "")
    return result


def save_requirements(case_id: int, issue_id: Optional[int],
                      result: RequirementResult, replace: bool = False) -> int:
    """
    Store the generated checklist.

    When ``replace`` is True the existing requirements for the same scope are
    removed first; otherwise the new items are appended.
    """
    if replace:
        existing = db.list_requirements(case_id, issue_id)
        for row in existing:
            db.delete_requirement(int(row["id"]))

    added = db.add_requirements_bulk(case_id, issue_id, result.checklist)

    # The confirmations and reconciliations are recorded as conditional items
    # so nothing the AI suggested is silently dropped.
    extras: List[Dict[str, str]] = []
    for item in result.information_to_confirm:
        extras.append({"document_name": f"Written confirmation: {item}",
                       "purpose": "Factual confirmation required from the client",
                       "requirement_type": "Mandatory", "remarks": ""})
    for item in result.reconciliations:
        extras.append({"document_name": f"Reconciliation: {item}",
                       "purpose": "Working to be prepared and verified",
                       "requirement_type": "Mandatory", "remarks": ""})
    if extras:
        added += db.add_requirements_bulk(case_id, issue_id, extras)

    db.log_activity("Requirements generated",
                    f"{added} item(s); source: {result.source}", case_id=case_id)
    log.info("Saved %d requirement(s) for case %s", added, case_id)
    return added


def requirement_stats(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    """Counts used by the status strip on the requirements screen."""
    stats = {status: 0 for status in config.REQUIREMENT_STATUSES}
    stats["Total"] = len(rows)
    for row in rows:
        status = row.get("status") or "Pending"
        stats[status] = stats.get(status, 0) + 1
    mandatory = [r for r in rows if (r.get("requirement_type") or "") == "Mandatory"]
    stats["Mandatory"] = len(mandatory)
    stats["Mandatory Pending"] = len([r for r in mandatory
                                      if (r.get("status") or "Pending") == "Pending"])
    return stats


def completion_percentage(rows: List[Dict[str, Any]]) -> int:
    """Percentage of requirements that are received or not applicable."""
    if not rows:
        return 0
    done = len([r for r in rows
                if (r.get("status") or "") in ("Received", "Not Applicable")])
    return int(round(done * 100 / len(rows)))


DEFAULT_COVERING_NOTE = (
    "We have received a GST notice in respect of the period noted above. To enable "
    "us to prepare and file a comprehensive reply within the time allowed, we "
    "request that the documents and information listed below be provided at the "
    "earliest. Where any item is not applicable, kindly confirm that position in "
    "writing so that it may be recorded."
)
