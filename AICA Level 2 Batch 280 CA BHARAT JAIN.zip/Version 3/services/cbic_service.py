"""
services.cbic_service
=====================
Live GST legislation from the CBIC Tax Information Portal.

Source
------
    https://www.cbic.gov.in/entities/gst
        -> every "Tax Legislation" link resolves to
    https://taxinformation.cbic.gov.in

The portal is an Angular application backed by a public JSON API. This
module talks to that API directly, so the Acts, Rules, Notifications and
Circulars a Chartered Accountant relies on can be pulled straight into the
local knowledge base and cited by the research module.

The contract used here (verified against the live portal)::

    POST /api/authenticate-token          {}  -> {"id_token": "<JWT>"}
    GET  /api/cbic-act-msts                   -> Acts        (contentFilePath)
    GET  /api/cbic-rule-msts                  -> Rules       (contentFilePath)
    GET  /api/cbic-notification-msts/fetchUpdatesByTaxId/1000001
                                              -> recent Notifications and
                                                 Circulars  (docFilePath)
    GET  /content/pdf/<path>              -> {"data": "<base64 pdf>",
                                              "fileName": "..."}

Three details matter and are handled below:

* the token is anonymous but **mandatory** -- ``/content/pdf`` returns 401
  without it;
* document paths are stored with Windows separators and the portal's WAF
  rejects backslashes in a URL, so every path is normalised to ``/``;
* the portal does not serve a complete TLS chain, which browsers repair
  silently but Python does not. :mod:`truststore` (the OS certificate
  store) is used when available. Certificate verification is **never**
  disabled.

Nothing here is scraped from rendered HTML, so ordinary page redesigns do
not break it. Every failure is reported to the caller; none is hidden.
"""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import config
from utils.logger import get_logger

log = get_logger(__name__)

PORTAL_HOME = "https://www.cbic.gov.in/entities/gst"
BASE_URL = "https://taxinformation.cbic.gov.in"

# Tax identifiers used by the portal
TAX_GST = 1000001

USER_AGENT = (
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    f"{config.APP_NAME.replace(' ', '-')}/{config.APP_VERSION}"
)

REQUEST_TIMEOUT = 60
DOWNLOAD_TIMEOUT = 120

# Portal category -> knowledge base folder
CATEGORY_MAP = {
    "Act": "acts",
    "Rule": "rules",
    "Notification": "notifications",
    "Circular": "circulars",
    "Instruction": "circulars",
    "Order": "circulars",
}

FETCHABLE_CATEGORIES = ["Act", "Rule", "Notification", "Circular"]


class CBICError(Exception):
    """Raised when the CBIC portal cannot be reached or understood."""


@dataclass
class CBICDocument:
    """One legislation document offered by the portal."""

    category: str            # Act / Rule / Notification / Circular
    title: str
    number: str = ""
    issued: str = ""
    remote_path: str = ""    # path under /content/pdf/
    sub_category: str = ""   # e.g. "Circulars CGST", "Central Tax"

    @property
    def kb_category(self) -> str:
        """Knowledge base folder this document belongs in."""
        return CATEGORY_MAP.get(self.category, "internal_research")

    @property
    def available(self) -> bool:
        return bool(self.remote_path)

    @property
    def source_url(self) -> str:
        """A URL a person can open to read the same document."""
        if not self.remote_path:
            return PORTAL_HOME
        return f"{BASE_URL}/content/pdf/{self.remote_path}"

    def filename(self) -> str:
        """
        A stable, Windows-safe filename for the local copy.

        Acts and Rules carry a bare serial number ("6"), which makes a
        useless filename, so the title is used unless the number is itself
        descriptive (as notification and circular numbers are).
        """
        number = self.number.strip()
        descriptive = bool(re.search(r"[A-Za-z]", number) or "/" in number)
        stem = f"{number} {self.title}" if descriptive else self.title or number
        stem = re.sub(r"[^A-Za-z0-9\- ]+", " ", stem)
        stem = "_".join(stem.split())[:80] or "CBIC_document"
        tail = Path(self.remote_path).suffix.lower() or ".pdf"
        return f"CBIC_{self.category}_{stem}{tail}"

    def label(self) -> str:
        parts = [p for p in (self.number, self.title) if p]
        return " - ".join(parts)[:150]


@dataclass
class CBICFetchResult:
    """Outcome of importing documents into the knowledge base."""

    downloaded: int = 0
    skipped: int = 0
    failed: int = 0
    unavailable: int = 0
    indexed_chunks: int = 0
    files: List[str] = field(default_factory=list)
    messages: List[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        text = (f"{self.downloaded} document(s) downloaded, {self.skipped} already "
                f"present, {self.failed} failed.")
        if self.unavailable:
            text += (f" {self.unavailable} entry(ies) are listed by CBIC without a "
                     f"file and could not be fetched.")
        return text


# ---------------------------------------------------------------------------
# Transport
# ---------------------------------------------------------------------------
def _enable_os_trust_store() -> Optional[str]:
    """
    Use the operating system certificate store for TLS.

    The portal omits an intermediate certificate. Browsers fetch the missing
    link automatically; Python does not, so verification fails with
    "unable to get local issuer certificate". ``truststore`` delegates to the
    Windows store, which already holds the chain. Returns a note when it is
    unavailable so the caller can explain the situation.
    """
    try:
        import truststore

        truststore.inject_into_ssl()
        return None
    except ImportError:
        return ("The 'truststore' package is not installed, so the CBIC portal's "
                "certificate may not verify. Install it with:  pip install truststore")
    except Exception as exc:  # noqa: BLE001 - never fatal
        return f"Certificate store could not be initialised: {exc}"


class CBICClient:
    """A small, well-behaved client for the CBIC Tax Information Portal."""

    def __init__(self) -> None:
        self._session = None
        self._token: Optional[str] = None
        self.trust_note: Optional[str] = None

    # -- setup ----------------------------------------------------------
    def _requests(self):
        try:
            import requests
        except ImportError as exc:  # pragma: no cover - declared requirement
            raise CBICError(
                "The 'requests' package is required to reach the CBIC portal.\n"
                "Install it with:  pip install requests"
            ) from exc
        return requests

    def session(self):
        """Lazily build an authenticated session."""
        if self._session is not None:
            return self._session
        requests = self._requests()
        self.trust_note = _enable_os_trust_store()
        session = requests.Session()
        session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "application/json, text/plain, */*",
        })
        self._session = session
        self._authenticate()
        return session

    def _authenticate(self) -> None:
        """Obtain the portal's anonymous bearer token."""
        requests = self._requests()
        url = f"{BASE_URL}/api/authenticate-token"
        try:
            response = self._session.post(url, json={}, timeout=REQUEST_TIMEOUT)
        except requests.exceptions.SSLError as exc:
            raise CBICError(
                "The CBIC portal's security certificate could not be verified.\n\n"
                + (self.trust_note or
                   "Install the 'truststore' package so Python can use the Windows "
                   "certificate store:  pip install truststore")
                + f"\n\nDetails: {exc}"
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise CBICError(
                "The CBIC portal could not be reached. Check your internet "
                f"connection and try again.\n\nDetails: {exc}"
            ) from exc

        if response.status_code != 200:
            raise CBICError(
                f"The CBIC portal refused the anonymous session "
                f"(HTTP {response.status_code})."
            )
        try:
            self._token = response.json().get("id_token")
        except ValueError as exc:
            raise CBICError("The CBIC portal returned an unreadable token.") from exc
        if not self._token:
            raise CBICError("The CBIC portal did not issue an access token.")
        self._session.headers["Authorization"] = f"Bearer {self._token}"
        log.info("CBIC portal: anonymous session established")

    # -- requests -------------------------------------------------------
    def get_json(self, path: str) -> Any:
        """GET a JSON endpoint, raising :class:`CBICError` on any problem."""
        requests = self._requests()
        session = self.session()
        try:
            response = session.get(f"{BASE_URL}{path}", timeout=REQUEST_TIMEOUT)
        except requests.exceptions.RequestException as exc:
            raise CBICError(f"The CBIC portal did not respond: {exc}") from exc
        if response.status_code != 200:
            raise CBICError(f"CBIC returned HTTP {response.status_code} for {path}")
        try:
            return response.json()
        except ValueError as exc:
            raise CBICError(f"CBIC returned unreadable data for {path}") from exc

    def download(self, remote_path: str) -> bytes:
        """
        Fetch one document and return its bytes.

        The portal wraps the file in JSON as base64 and rejects backslashes,
        so the path is normalised first.
        """
        requests = self._requests()
        session = self.session()
        normalised = str(remote_path).replace("\\", "/").lstrip("/")
        url = f"{BASE_URL}/content/pdf/{normalised}"
        try:
            response = session.get(url, timeout=DOWNLOAD_TIMEOUT)
        except requests.exceptions.RequestException as exc:
            raise CBICError(f"Download failed: {exc}") from exc
        if response.status_code != 200:
            raise CBICError(f"CBIC returned HTTP {response.status_code} for the file")

        text = response.text.lstrip()
        if not text.startswith("{"):
            # The portal's firewall answers with an HTML page rather than an
            # error status when it dislikes a request.
            raise CBICError("CBIC rejected the request for this document.")
        try:
            payload = json.loads(text)
            blob = base64.b64decode(payload["data"])
        except (ValueError, KeyError, TypeError) as exc:
            raise CBICError("The document could not be decoded.") from exc
        if not blob.startswith(b"%PDF"):
            raise CBICError("The downloaded file is not a valid PDF.")
        return blob


# ---------------------------------------------------------------------------
# Catalogue
# ---------------------------------------------------------------------------
def _tax_name(record: Dict[str, Any]) -> str:
    for key in ("cbicTaxMst", "tax"):
        value = record.get(key)
        if isinstance(value, dict) and value.get("taxName"):
            return str(value["taxName"])
    return ""


def _looks_like_gst(record: Dict[str, Any], *names: str) -> bool:
    """GST records are identified by their tax link or by their title."""
    if _tax_name(record).upper() == "GST":
        return True
    haystack = " ".join(str(n or "") for n in names).lower()
    return ("goods and services tax" in haystack
            or "gst" in haystack.split()
            or haystack.startswith("the central goods"))


def _iso_date(value: Any) -> str:
    text = str(value or "")[:10]
    try:
        return datetime.strptime(text, "%Y-%m-%d").strftime("%d-%m-%Y")
    except ValueError:
        return str(value or "")[:11]


def list_acts(client: CBICClient) -> List[CBICDocument]:
    """GST Acts published on the portal."""
    documents: List[CBICDocument] = []
    for record in client.get_json("/api/cbic-act-msts") or []:
        name = record.get("actName") or ""
        if not _looks_like_gst(record, name):
            continue
        documents.append(CBICDocument(
            category="Act",
            title=name,
            number=str(record.get("actNo") or ""),
            issued=_iso_date(record.get("issueDt")),
            remote_path=record.get("contentFilePath") or "",
        ))
    return documents


def list_rules(client: CBICClient) -> List[CBICDocument]:
    """GST Rules published on the portal."""
    documents: List[CBICDocument] = []
    for record in client.get_json("/api/cbic-rule-msts") or []:
        name = record.get("ruleDocName") or ""
        if not _looks_like_gst(record, name):
            continue
        documents.append(CBICDocument(
            category="Rule",
            title=name,
            number=str(record.get("ruleDocNo") or ""),
            issued=_iso_date(record.get("issueDt")),
            remote_path=record.get("contentFilePath") or "",
            sub_category=str(record.get("ruleCategory") or ""),
        ))
    return documents


def list_updates(client: CBICClient) -> List[CBICDocument]:
    """The latest GST Notifications, Circulars, Instructions and Orders."""
    documents: List[CBICDocument] = []
    endpoint = f"/api/cbic-notification-msts/fetchUpdatesByTaxId/{TAX_GST}"
    for record in client.get_json(endpoint) or []:
        category = str(record.get("updateType") or "Notification").strip()
        documents.append(CBICDocument(
            category=category,
            title=(record.get("notificationName")
                   or record.get("notificationNameToBeDisplay") or ""),
            number=str(record.get("notificationNo") or ""),
            issued=str(record.get("updatedDate") or ""),
            remote_path=record.get("docFilePath") or "",
            sub_category=str(record.get("updateCategory") or ""),
        ))
    return documents


def list_documents(categories: Optional[List[str]] = None,
                   client: Optional[CBICClient] = None,
                   progress: Optional[Callable[[str], None]] = None
                   ) -> Tuple[List[CBICDocument], List[str]]:
    """
    Build the catalogue of GST legislation available from CBIC.

    Returns ``(documents, messages)``. A failure in one category never
    prevents the others from being listed.
    """
    client = client or CBICClient()
    wanted = set(categories or FETCHABLE_CATEGORIES)
    documents: List[CBICDocument] = []
    messages: List[str] = []

    def step(text: str) -> None:
        if progress:
            try:
                progress(text)
            except Exception:  # noqa: BLE001
                pass

    sources: List[Tuple[str, Callable[[CBICClient], List[CBICDocument]]]] = []
    if "Act" in wanted:
        sources.append(("Acts", list_acts))
    if "Rule" in wanted:
        sources.append(("Rules", list_rules))
    if wanted & {"Notification", "Circular", "Instruction", "Order"}:
        sources.append(("Notifications and Circulars", list_updates))

    for label, fetch in sources:
        step(f"Reading {label} from CBIC...")
        try:
            found = fetch(client)
        except CBICError as exc:
            messages.append(f"{label}: {exc}")
            continue
        documents.extend(d for d in found if d.category in wanted)

    if client.trust_note:
        messages.append(client.trust_note)
    return documents, messages


# ---------------------------------------------------------------------------
# Import into the knowledge base
# ---------------------------------------------------------------------------
def import_documents(documents: List[CBICDocument],
                     client: Optional[CBICClient] = None,
                     index: bool = True,
                     progress: Optional[Callable[[str], None]] = None
                     ) -> CBICFetchResult:
    """
    Download the chosen documents into the knowledge base and index them.

    Idempotent: a document already on disk is skipped, so the operation can
    be repeated safely.
    """
    from database import database as db
    from services import rag_service
    from utils.helpers import relative_to_base

    client = client or CBICClient()
    result = CBICFetchResult()

    def step(text: str) -> None:
        if progress:
            try:
                progress(text)
            except Exception:  # noqa: BLE001
                pass

    for position, document in enumerate(documents, start=1):
        if not document.available:
            # The portal lists some entries with no attached file. That is a
            # gap in the source, not a download failure, so it is counted and
            # named separately rather than reported as an error.
            result.unavailable += 1
            result.messages.append(
                f"{document.label()}: CBIC lists no file for this entry.")
            continue

        folder = config.KNOWLEDGE_BASE_DIR / document.kb_category
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / document.filename()

        if target.exists() and target.stat().st_size > 0:
            result.skipped += 1
            continue

        step(f"Downloading {position} of {len(documents)}: {document.label()[:60]}")
        try:
            blob = client.download(document.remote_path)
        except CBICError as exc:
            result.failed += 1
            result.messages.append(f"{document.label()}: {exc}")
            continue

        try:
            target.write_bytes(blob)
        except OSError as exc:
            result.failed += 1
            result.messages.append(f"{document.label()}: could not be saved ({exc})")
            continue

        result.downloaded += 1
        result.files.append(str(target))

        note = (f"Downloaded from the CBIC Tax Information Portal on "
                f"{datetime.now():%d-%m-%Y}. Source: {document.source_url}")
        ok, message, document_id = rag_service.add_document(
            target, document.kb_category, notes=note, copy_file=False)
        if not ok:
            result.messages.append(f"{document.label()}: {message}")
            continue
        if index and document_id:
            step(f"Indexing {document.label()[:60]}")
            indexed, index_message, chunks = rag_service.index_document(
                db.get_knowledge_document(document_id) or {})
            if indexed:
                result.indexed_chunks += chunks
            else:
                result.messages.append(index_message)

    try:
        rag_service._invalidate_cache()  # noqa: SLF001 - refresh the search cache
        db.log_activity("CBIC legislation imported", result.summary)
    except Exception:  # noqa: BLE001 - bookkeeping must not fail the import
        pass

    log.info("CBIC import: %s", result.summary)
    return result


def connection_status() -> Dict[str, Any]:
    """
    Check whether the CBIC portal is reachable right now.

    Used by the Settings and Knowledge Base screens so the user is told the
    truth before a long download is attempted.
    """
    status: Dict[str, Any] = {
        "reachable": False, "message": "", "portal": PORTAL_HOME,
        "api": BASE_URL, "documents": 0,
    }
    try:
        client = CBICClient()
        documents, messages = list_documents(client=client)
        status["reachable"] = True
        status["documents"] = len(documents)
        status["message"] = (f"Connected. {len(documents)} GST document(s) listed "
                             f"by the portal.")
        if messages:
            status["message"] += "  " + " ".join(messages[:2])
    except CBICError as exc:
        status["message"] = str(exc)
    except Exception as exc:  # noqa: BLE001 - report, never raise
        status["message"] = f"Unexpected problem: {exc}"
    return status
