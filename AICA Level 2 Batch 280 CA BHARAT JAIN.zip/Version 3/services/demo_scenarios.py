"""
services.demo_scenarios
=======================
The single source of truth for the demonstration portfolio.

Every demo notice is described once, here. The same definition drives:

* the generated sample notice PDF,
* the notice text stored against the case,
* the pre-loaded "AI" analysis and issue breakdown,
* the mock AI response when the presenter clicks *Analyse Notice with AI*.

Keeping one definition means the figures on the notice, on the dashboard
and in the AI output can never drift apart during a presentation.

**Everything here is fictional.** No real taxpayer, GSTIN, PAN, officer or
proceeding is represented.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, List, Optional

from utils.validators import gstin_checksum

DEMO_MARKER = "DEMO"


# ---------------------------------------------------------------------------
# Fictional identifiers
# ---------------------------------------------------------------------------
def fictional_gstin(state_code: str, pan: str, entity: str = "1") -> str:
    """
    Build a checksum-correct but entirely fictional GSTIN.

    The format is valid so the application's own validation passes; the
    identifier does not correspond to any registration on the GST portal.
    """
    body = f"{state_code}{pan}{entity}Z"
    return body + (gstin_checksum(body) or "0")


@dataclass
class DemoClient:
    """A fictional client profile."""

    key: str
    client_name: str
    state_code: str
    pan: str
    state: str
    entity_type: str
    industry: str
    contact_person: str
    email: str
    mobile: str
    partner: str
    manager: str

    @property
    def gstin(self) -> str:
        return fictional_gstin(self.state_code, self.pan)

    def as_record(self) -> Dict[str, Any]:
        return {
            "client_name": self.client_name,
            "gstin": self.gstin,
            "pan": self.pan,
            "state": self.state,
            "entity_type": self.entity_type,
            "industry": self.industry,
            "contact_person": self.contact_person,
            "email": self.email,
            "mobile": self.mobile,
            "partner": self.partner,
            "manager": self.manager,
            "notes": "Fictional demonstration client. Not a real taxpayer.",
            "active": 1,
            "is_demo": 1,
        }


DEMO_CLIENTS: List[DemoClient] = [
    DemoClient(
        key="abc", client_name="ABC Manufacturing Private Limited",
        state_code="27", pan="AABCM1234F", state="Maharashtra",
        entity_type="Private Limited Company",
        industry="Manufacturing - engineering components",
        contact_person="R. Sharma", email="accounts@abcmanufacturing.example",
        mobile="9820011223", partner="Administrator", manager="Administrator",
    ),
    DemoClient(
        key="zenith", client_name="Zenith Trading LLP",
        state_code="24", pan="AAFFZ5678L", state="Gujarat",
        entity_type="LLP", industry="Trading - industrial consumables",
        contact_person="K. Patel", email="finance@zenithtrading.example",
        mobile="9825566778", partner="Administrator", manager="Administrator",
    ),
    DemoClient(
        key="sunrise", client_name="Sunrise Warehousing Private Limited",
        state_code="08", pan="AADCS9012P", state="Rajasthan",
        entity_type="Private Limited Company",
        industry="Warehousing and logistics",
        contact_person="S. Verma", email="tax@sunrisewarehousing.example",
        mobile="9829099887", partner="Administrator", manager="Administrator",
    ),
    DemoClient(
        key="technova", client_name="TechNova Solutions Private Limited",
        state_code="29", pan="AAECT3456R", state="Karnataka",
        entity_type="Private Limited Company",
        industry="Information technology services",
        contact_person="A. Rao", email="compliance@technovasolutions.example",
        mobile="9845512340", partner="Administrator", manager="Administrator",
    ),
    DemoClient(
        key="greenfield", client_name="Greenfield Infra Projects LLP",
        state_code="27", pan="AAGFG7890Q", state="Maharashtra",
        entity_type="LLP", industry="Construction and works contract",
        contact_person="M. Deshpande", email="gst@greenfieldinfra.example",
        mobile="9820777654", partner="Administrator", manager="Administrator",
    ),
]

CLIENTS_BY_KEY = {c.key: c for c in DEMO_CLIENTS}


# ---------------------------------------------------------------------------
# Notice scenarios
# ---------------------------------------------------------------------------
@dataclass
class DemoScenario:
    """One fictional GST matter, described once and reused everywhere."""

    key: str
    client_key: str
    notice_type: str
    notice_number: str
    financial_year: str
    tax_period: str
    subject: str
    sections: List[str]
    rules: List[str] = field(default_factory=list)
    officer: str = "Assistant Commissioner (State Tax) - Demo Data"
    designation: str = "Proper Officer - Demo Data"
    jurisdiction: str = "Demo Ward, Demonstration Division"
    summary: str = ""
    narrative: List[str] = field(default_factory=list)
    demand: Dict[str, int] = field(default_factory=dict)
    issues: List[Dict[str, Any]] = field(default_factory=list)
    risk: str = "Medium"
    status: str = "New"
    stage: str = "Notice Received"
    next_action: str = ""
    notice_days_ago: int = 10
    due_in_days: int = 30
    pdf_name: str = ""
    featured: bool = False

    @property
    def client(self) -> DemoClient:
        return CLIENTS_BY_KEY[self.client_key]

    def total_tax(self) -> Decimal:
        from utils.calculations import compute_demand

        return compute_demand(self.demand).total_tax

    def total_exposure(self) -> Decimal:
        from utils.calculations import compute_demand

        return compute_demand(self.demand).total_exposure


def _issue(no: int, title: str, allegation: str, amount: int, sections: List[str],
           facts: List[str], missing: List[str], risk: str, reason: str,
           confidence: str = "Medium") -> Dict[str, Any]:
    return {
        "issue_no": no, "issue_title": title, "department_allegation": allegation,
        "amount": amount, "sections": sections, "facts_identified": facts,
        "facts_missing": missing, "initial_risk": risk, "reason_for_risk": reason,
        "confidence": confidence,
    }


# -- common fact lists -------------------------------------------------------
_ITC_MISSING = [
    "Month-wise reconciliation of GSTR-3B with GSTR-2A and GSTR-2B",
    "Purchase register for the period, invoice-wise and GSTIN-wise",
    "Copies of the supplier invoices comprising the difference",
    "Details of import IGST credit and reverse charge credit, which do not "
    "appear in GSTR-2A",
    "Evidence of payment to suppliers within 180 days",
]
_RCM_MISSING = [
    "Ledger-wise break-up of the expense heads relied upon",
    "Registration status of each service provider",
    "Reverse charge working prepared for the returns",
    "Whether the tax, if payable, would have been available as credit",
]
_TURNOVER_MISSING = [
    "Month-wise GSTR-1 versus GSTR-3B reconciliation",
    "Credit notes and debit notes issued during the period",
    "Reconciliation of turnover with the audited financial statements",
    "Details of amendments reported in a subsequent period",
]


DEMO_SCENARIOS: List[DemoScenario] = [
    # ---------------------------------------------------------------- 1
    DemoScenario(
        key="asmt10_abc",
        client_key="abc",
        notice_type="ASMT-10",
        notice_number="DEMO/ASMT-10/2023-24/0001",
        financial_year="2023-24",
        tax_period="April 2023 to March 2024",
        subject="Notice for intimation of discrepancies in the return after scrutiny",
        sections=["Section 61"],
        rules=["Rule 99"],
        summary=(
            "On scrutiny of the returns for the financial year 2023-24, the taxable "
            "turnover declared in GSTR-1 exceeds the taxable turnover declared in "
            "GSTR-3B. The taxpayer has been asked to explain the difference and to "
            "furnish a reconciliation."
        ),
        narrative=[
            "On scrutiny of the returns furnished for the financial year 2023-24, "
            "the following discrepancy has been noticed.",
            "",
            "Taxable turnover declared in GSTR-1        : Rs. 1,25,00,000",
            "Taxable turnover declared in GSTR-3B       : Rs. 1,18,50,000",
            "Difference in taxable turnover             : Rs.    6,50,000",
            "Tax potentially short paid thereon (18%)   : Rs.    1,17,000",
            "",
            "You are requested to explain the above difference and to furnish a "
            "month-wise reconciliation of the turnover declared in GSTR-1 with the "
            "turnover declared in GSTR-3B, together with supporting records.",
            "",
            "If the discrepancy is accepted, the tax together with interest may be "
            "paid and intimated. If no satisfactory explanation is furnished, "
            "proceedings may be initiated under the applicable provisions.",
        ],
        demand={"cgst": 58500, "sgst": 58500, "interest": 14000},
        issues=[
            _issue(
                1, "GSTR-1 turnover exceeds GSTR-3B turnover",
                "The taxable turnover declared in GSTR-1 for the year exceeds the "
                "taxable turnover declared in GSTR-3B by Rs. 6,50,000, on which tax "
                "of Rs. 1,17,000 is stated to be short paid.",
                117000, ["Section 61", "Rule 99"],
                ["Turnover as per GSTR-1 for the year is stated in the notice.",
                 "Turnover as per GSTR-3B for the year is stated in the notice.",
                 "The difference has been computed on an annual basis."],
                _TURNOVER_MISSING,
                "Medium",
                "The amount is modest and the difference is commonly explained by "
                "timing and by credit notes, but a reconciliation must be produced.",
                "High"),
        ],
        risk="Medium", status="Under Analysis", stage="Analysis",
        next_action="Obtain the month-wise GSTR-1 versus GSTR-3B reconciliation",
        notice_days_ago=18, due_in_days=14,
        pdf_name="Sample_ASMT_10.pdf",
    ),
    # ---------------------------------------------------------------- 2
    DemoScenario(
        key="drc01a_zenith",
        client_key="zenith",
        notice_type="DRC-01A",
        notice_number="DEMO/DRC-01A/2023-24/0002",
        financial_year="2023-24",
        tax_period="April 2023 to March 2024",
        subject="Intimation of tax ascertained as payable - input tax credit mismatch",
        sections=["Section 73", "Section 16"],
        rules=["Rule 142(1A)"],
        summary=(
            "Input tax credit availed in GSTR-3B for the financial year 2023-24 "
            "exceeds the credit reflected in GSTR-2B. The difference of "
            "Rs. 3,25,000, with interest of Rs. 42,000, has been ascertained as "
            "payable and intimated before issue of a show cause notice."
        ),
        narrative=[
            "It has been observed from the records available with this office that "
            "the input tax credit availed by you exceeds the credit reflected in "
            "your auto-populated statement for the financial year 2023-24.",
            "",
            "Input tax credit availed in GSTR-3B        : Rs.  18,75,000",
            "Input tax credit reflected in GSTR-2B      : Rs.  15,50,000",
            "Difference proposed to be disallowed       : Rs.   3,25,000",
            "Interest ascertained under Section 50      : Rs.     42,000",
            "Total amount ascertained as payable        : Rs.   3,67,000",
            "",
            "In terms of Section 16 of the Act, input tax credit may be availed only "
            "where the prescribed conditions are satisfied. You are advised to pay "
            "the amount ascertained above along with interest, or to furnish your "
            "submissions, failing which a notice under Section 73 may be issued.",
        ],
        demand={"cgst": 162500, "sgst": 162500, "interest": 42000},
        issues=[
            _issue(
                1, "Input tax credit availed in excess of GSTR-2B",
                "Input tax credit of Rs. 3,25,000 availed in GSTR-3B in excess of "
                "the credit reflected in GSTR-2B is proposed to be disallowed.",
                325000, ["Section 16", "Section 73"],
                ["ITC availed in GSTR-3B as stated in the intimation.",
                 "ITC reflected in GSTR-2B as stated in the intimation.",
                 "The comparison has been made on an annual basis."],
                _ITC_MISSING,
                "High",
                "The intimation precedes a show cause notice, so a reconciliation "
                "must be filed within the time allowed to avoid escalation.",
                "High"),
        ],
        risk="High", status="Information Pending", stage="Information Gathering",
        next_action="Obtain the purchase register and month-wise ITC reconciliation",
        notice_days_ago=12, due_in_days=2,
        pdf_name="Sample_DRC_01A_ITC_Mismatch.pdf",
    ),
    # ---------------------------------------------------------------- 3 FEATURED
    DemoScenario(
        key="drc01_sunrise",
        client_key="sunrise",
        notice_type="DRC-01",
        notice_number="DEMO/DRC-01/2024-25/0003",
        financial_year="2024-25",
        tax_period="April 2024 to March 2025",
        subject="Show cause notice for recovery of tax not paid or short paid and "
                "input tax credit wrongly availed",
        sections=["Section 73", "Section 16", "Section 9(3)", "Section 50",
                  "Section 122"],
        rules=["Rule 36(4)", "Rule 142(1)(a)"],
        summary=(
            "A show cause notice has been issued for the financial year 2024-25 "
            "raising three distinct allegations: input tax credit availed in excess "
            "of the auto-populated statement, short payment of tax under reverse "
            "charge, and a difference between the turnover declared in GSTR-1 and "
            "GSTR-3B. Tax, interest and penalty have been proposed."
        ),
        narrative=[
            "Whereas, on examination of the returns furnished and the records "
            "available with this office for the financial year 2024-25, it appears "
            "that tax has been short paid and that input tax credit has been availed "
            "which is not admissible. The discrepancies noticed are as follows.",
            "",
            "ISSUE 1 - INPUT TAX CREDIT AVAILED IN EXCESS OF GSTR-2B",
            "Input tax credit availed in GSTR-3B exceeds the credit reflected in the "
            "auto-populated statement for the period. The excess credit works out to "
            "Rs. 4,50,000. In terms of Section 16 read with Rule 36(4), credit may be "
            "availed only to the extent permitted.",
            "",
            "ISSUE 2 - SHORT PAYMENT OF TAX UNDER REVERSE CHARGE",
            "On examination of the expense heads appearing in the financial "
            "statements, including legal services, goods transport agency services "
            "and services received from directors, it appears that tax payable under "
            "reverse charge in terms of Section 9(3) has been short paid by "
            "Rs. 2,00,000.",
            "",
            "ISSUE 3 - DIFFERENCE BETWEEN GSTR-1 AND GSTR-3B",
            "The taxable turnover declared in GSTR-1 exceeds the taxable turnover "
            "declared in GSTR-3B for the period, resulting in short payment of tax "
            "of Rs. 2,00,000.",
            "",
            "SUMMARY OF THE AMOUNT PROPOSED",
            "Central Tax (CGST)                          : Rs.   4,25,000",
            "State Tax (SGST)                            : Rs.   4,25,000",
            "Interest under Section 50                   : Rs.   1,20,000",
            "Penalty under Section 122                   : Rs.     85,000",
            "",
            "You are hereby called upon to show cause why the amounts proposed above "
            "should not be demanded and recovered from you together with applicable "
            "interest and penalty.",
        ],
        demand={"cgst": 425000, "sgst": 425000, "interest": 120000, "penalty": 85000},
        issues=[
            _issue(
                1, "Input tax credit availed in excess of GSTR-2B",
                "Input tax credit of Rs. 4,50,000 availed in GSTR-3B in excess of the "
                "credit reflected in GSTR-2B is proposed to be disallowed under "
                "Section 16 read with Rule 36(4).",
                450000, ["Section 16", "Section 73", "Rule 36(4)"],
                ["ITC availed in GSTR-3B for the period, as stated in the notice.",
                 "ITC reflected in GSTR-2B, as stated in the notice.",
                 "The difference has been computed on an annual basis."],
                _ITC_MISSING,
                "High",
                "This is the largest component of the demand and the department has "
                "compared annual aggregates rather than individual invoices.",
                "High"),
            _issue(
                2, "Short payment of tax under reverse charge",
                "Tax of Rs. 2,00,000 payable under reverse charge on legal services, "
                "goods transport agency services and services received from directors "
                "is stated to have been short paid.",
                200000, ["Section 9(3)", "Section 73"],
                ["Expense heads identified by the officer from the financial "
                 "statements.",
                 "Reverse charge liability declared in GSTR-3B for the period."],
                _RCM_MISSING,
                "Medium",
                "Part of the liability may be revenue neutral where the tax would "
                "have been creditable, although interest exposure may remain.",
                "Medium"),
            _issue(
                3, "Turnover declared in GSTR-1 exceeds GSTR-3B",
                "Tax of Rs. 2,00,000 is stated to be short paid on the difference "
                "between the taxable turnover declared in GSTR-1 and that declared "
                "in GSTR-3B.",
                200000, ["Section 73", "Section 50"],
                ["Turnover per GSTR-1 and per GSTR-3B, as stated in the notice.",
                 "The comparison has been made for the full financial year."],
                _TURNOVER_MISSING,
                "Medium",
                "Differences of this kind are frequently explained by credit notes "
                "and by amendments reported in a later period.",
                "Medium"),
        ],
        risk="High", status="Drafting", stage="Drafting",
        next_action="Finalise the issue-wise reply and annexures for partner review",
        notice_days_ago=14, due_in_days=8,
        pdf_name="Sample_DRC_01_RCM_ITC.pdf",
        featured=True,
    ),
    # ---------------------------------------------------------------- 4
    DemoScenario(
        key="summons_technova",
        client_key="technova",
        notice_type="Summons",
        notice_number="DEMO/SUMMONS/2024-25/0004",
        financial_year="2024-25",
        tax_period="April 2024 to September 2024",
        subject="Summons to give evidence and produce documents",
        sections=["Section 70"],
        summary=(
            "Summons have been issued requiring the authorised representative to "
            "appear and to produce records relating to inward supplies and vendor "
            "transactions. No demand has been quantified at this stage."
        ),
        narrative=[
            "Whereas, in connection with an enquiry relating to inward supplies and "
            "vendor transactions, your attendance is considered necessary to give "
            "evidence and to produce the documents listed below.",
            "",
            "You are hereby summoned to appear in person, or through a duly "
            "authorised representative, before the undersigned on the date intimated "
            "separately, and to produce:",
            "",
            "  1. Purchase register for the period under enquiry",
            "  2. Copies of inward supply invoices for the listed vendors",
            "  3. Ledger accounts of the listed vendors",
            "  4. Bank statements evidencing payments to those vendors",
            "  5. Agreements or work orders with those vendors",
            "  6. Details of input tax credit availed against those supplies",
            "",
            "No demand of tax is quantified at this stage. Non-compliance with these "
            "summons may attract the consequences provided in law.",
        ],
        demand={},
        issues=[
            _issue(
                1, "Verification of inward supplies and vendor transactions",
                "Records relating to inward supplies from specified vendors have "
                "been called for to verify the genuineness of the transactions and "
                "the input tax credit availed.",
                0, ["Section 70"],
                ["The enquiry relates to inward supplies and vendor transactions.",
                 "A list of documents to be produced is set out in the summons.",
                 "No demand has been quantified at this stage."],
                ["Identity of the vendors named in the enquiry",
                 "Whether the vendors were registered on the dates of supply",
                 "Proof of movement of goods or delivery of services",
                 "Proof of payment through banking channels",
                 "Whether credit availed against those vendors has been reversed"],
                "Medium",
                "No demand has been raised, but the outcome of the enquiry could "
                "lead to proceedings, so the records must be complete and accurate.",
                "High"),
        ],
        risk="Medium", status="New", stage="Notice Received",
        next_action="Compile the vendor records listed in the summons",
        notice_days_ago=6, due_in_days=6,
        pdf_name="Sample_Summons.pdf",
    ),
    # ---------------------------------------------------------------- 5
    DemoScenario(
        key="audit_greenfield",
        client_key="greenfield",
        notice_type="Audit Notice",
        notice_number="DEMO/ADT-01/2023-24/0005",
        financial_year="2023-24",
        tax_period="April 2023 to March 2024",
        subject="Notice for conduct of audit of records",
        sections=["Section 65"],
        rules=["Rule 101"],
        summary=(
            "An audit of the records for the financial year 2023-24 has been "
            "initiated. The preliminary observations relate to input tax credit on "
            "works contract, reverse charge liability and reconciliation of turnover. "
            "The potential exposure indicated is Rs. 18,50,000."
        ),
        narrative=[
            "Whereas it has been decided to undertake an audit of your records for "
            "the financial year 2023-24 in terms of Section 65 of the Act, you are "
            "requested to make available the records listed in the annexure.",
            "",
            "The preliminary areas identified for examination are:",
            "",
            "  1. Input tax credit availed in relation to works contract services, "
            "including credit that may be restricted",
            "  2. Liability under reverse charge on specified inward supplies",
            "  3. Reconciliation of the turnover declared in the returns with the "
            "audited financial statements",
            "",
            "PRELIMINARY EXPOSURE INDICATED",
            "Central Tax (CGST)                          : Rs.   6,75,000",
            "State Tax (SGST)                            : Rs.   6,75,000",
            "Integrated Tax (IGST)                       : Rs.   1,50,000",
            "Interest (indicative)                       : Rs.   2,60,000",
            "Penalty (indicative)                        : Rs.     90,000",
            "",
            "The figures above are indicative observations recorded at the "
            "commencement of the audit and are subject to verification.",
        ],
        demand={"cgst": 675000, "sgst": 675000, "igst": 150000,
                "interest": 260000, "penalty": 90000},
        issues=[
            _issue(
                1, "Input tax credit on works contract services",
                "Credit availed in relation to works contract services is proposed "
                "to be examined for admissibility.",
                800000, ["Section 16", "Section 17(5)"],
                ["The audit covers the financial year 2023-24.",
                 "Works contract credit has been identified for examination."],
                ["Project-wise break-up of the credit availed",
                 "Whether the works relate to plant and machinery or to immovable "
                 "property",
                 "Copies of the contracts and running account bills",
                 "Capitalisation treatment adopted in the books"],
                "High",
                "Admissibility depends on the nature of each project, so the "
                "exposure cannot be assessed without a project-wise analysis.",
                "Medium"),
            _issue(
                2, "Reverse charge liability on inward supplies",
                "Liability under reverse charge on specified inward supplies is "
                "proposed to be examined.",
                400000, ["Section 9(3)"],
                ["Reverse charge has been identified as an audit area."],
                _RCM_MISSING,
                "Medium",
                "The exposure depends on the expense heads finally selected by the "
                "audit team.",
                "Medium"),
            _issue(
                3, "Reconciliation of turnover with financial statements",
                "The turnover declared in the returns is to be reconciled with the "
                "audited financial statements.",
                300000, ["Section 65"],
                ["Turnover reconciliation has been identified as an audit area."],
                _TURNOVER_MISSING,
                "Medium",
                "Retention money and unbilled revenue commonly create differences "
                "in works contract accounts.",
                "Medium"),
        ],
        risk="High", status="Information Pending", stage="Information Gathering",
        next_action="Compile the audit annexure records and project-wise ITC working",
        notice_days_ago=9, due_in_days=5,
        pdf_name="Sample_Audit_Notice.pdf",
    ),
    # ---------------------------------------------------------------- 6
    DemoScenario(
        key="drc07_abc",
        client_key="abc",
        notice_type="DRC-07",
        notice_number="DEMO/DRC-07/2022-23/0006",
        financial_year="2022-23",
        tax_period="April 2022 to March 2023",
        subject="Summary of the order confirming demand",
        sections=["Section 73", "Section 50", "Section 122"],
        rules=["Rule 142(5)"],
        summary=(
            "An adjudication order has been passed confirming a demand of "
            "Rs. 21,40,000 including interest and penalty for the financial year "
            "2022-23. The matter is under evaluation for filing a first appeal."
        ),
        narrative=[
            "This is a summary of the order passed in the proceedings initiated for "
            "the financial year 2022-23. The demand proposed in the show cause "
            "notice has been confirmed to the extent set out below.",
            "",
            "Central Tax (CGST)                          : Rs.   7,50,000",
            "State Tax (SGST)                            : Rs.   7,50,000",
            "Integrated Tax (IGST)                       : Rs.   1,00,000",
            "Interest under Section 50                   : Rs.   3,80,000",
            "Penalty under Section 122                   : Rs.   1,60,000",
            "",
            "The amount confirmed is payable within the period prescribed. An appeal "
            "against this order may be filed within the time allowed on payment of "
            "the pre-deposit prescribed by law.",
        ],
        demand={"cgst": 750000, "sgst": 750000, "igst": 100000,
                "interest": 380000, "penalty": 160000},
        issues=[
            _issue(
                1, "Demand confirmed by adjudication order",
                "The demand proposed in the show cause notice has been confirmed by "
                "the adjudicating authority together with interest and penalty.",
                1600000, ["Section 73", "Section 50", "Section 122"],
                ["The order confirms the demand for the financial year 2022-23.",
                 "Interest and penalty have been confirmed in addition to tax."],
                ["Copy of the complete speaking order with its reasoning",
                 "Whether each submission filed was dealt with in the order",
                 "Computation of the pre-deposit payable for a first appeal",
                 "Limitation date for filing the appeal"],
                "High",
                "A confirmed demand is enforceable, and the appeal period is short, "
                "so the appeal decision must be taken promptly.",
                "High"),
        ],
        risk="High", status="Under Review", stage="Order Received",
        next_action="Evaluate grounds of appeal and compute the pre-deposit",
        notice_days_ago=20, due_in_days=25,
        pdf_name="Sample_DRC_07_Order.pdf",
    ),
    # ---------------------------------------------------------------- 7
    DemoScenario(
        key="refund_zenith",
        client_key="zenith",
        notice_type="Refund Notice",
        notice_number="DEMO/RFD-08/2024-25/0007",
        financial_year="2024-25",
        tax_period="July 2024 to September 2024",
        subject="Show cause notice for rejection of refund application",
        sections=["Section 54"],
        rules=["Rule 92(3)"],
        summary=(
            "A deficiency has been raised in the refund application relating to "
            "unutilised input tax credit on exports. The refund amount at stake is "
            "Rs. 4,25,000. A reply has been prepared and approved for filing."
        ),
        narrative=[
            "With reference to your application for refund of unutilised input tax "
            "credit on account of export of goods without payment of tax, the "
            "following deficiencies are noticed.",
            "",
            "Refund claimed                              : Rs.   4,25,000",
            "",
            "  1. Statement of invoices does not reconcile with the shipping bills "
            "furnished",
            "  2. Bank realisation evidence has not been furnished for part of the "
            "consideration",
            "  3. The declaration regarding non-availment of drawback is incomplete",
            "",
            "You are called upon to show cause why the refund application should not "
            "be rejected to the extent of the deficiencies noticed above.",
        ],
        demand={"other_amount": 425000},
        issues=[
            _issue(
                1, "Deficiencies raised in the export refund application",
                "The refund of unutilised input tax credit on exports is proposed to "
                "be rejected on account of reconciliation and documentation "
                "deficiencies.",
                425000, ["Section 54", "Rule 92(3)"],
                ["The refund relates to export of goods without payment of tax.",
                 "Three specific deficiencies are listed in the notice.",
                 "The amount at stake is the refund claimed, not a demand of tax."],
                ["Reconciliation of the invoice statement with the shipping bills",
                 "Bank realisation certificates for the full consideration",
                 "Complete declaration regarding non-availment of drawback"],
                "Low",
                "The objections are documentary and are capable of being answered "
                "with the records already available.",
                "High"),
        ],
        risk="Low", status="CA Approved", stage="Approved",
        next_action="File the approved reply with the annexures on the portal",
        notice_days_ago=16, due_in_days=12,
        pdf_name="Sample_Refund_Notice.pdf",
    ),
    # ---------------------------------------------------------------- 8
    DemoScenario(
        key="registration_technova",
        client_key="technova",
        notice_type="Registration Notice",
        notice_number="DEMO/REG-17/2024-25/0008",
        financial_year="2024-25",
        tax_period="Not applicable",
        subject="Notice seeking clarification - principal place of business",
        sections=["Section 29"],
        rules=["Rule 25"],
        summary=(
            "Clarification has been sought regarding the principal place of "
            "business following a field verification. No demand has been raised. "
            "The draft reply has been returned for revision."
        ),
        narrative=[
            "On verification of the principal place of business declared in your "
            "registration, the following observations are recorded.",
            "",
            "  1. The signage displaying the registration details was not visible at "
            "the declared premises at the time of verification",
            "  2. The ownership or tenancy document on record requires updating",
            "  3. The details of additional places of business require confirmation",
            "",
            "You are requested to furnish a clarification together with supporting "
            "documents. No demand of tax arises from this notice.",
        ],
        demand={},
        issues=[
            _issue(
                1, "Verification of the principal place of business",
                "Clarification has been sought on the principal place of business "
                "following a field verification, with observations on signage, "
                "premises documents and additional places of business.",
                0, ["Section 29", "Rule 25"],
                ["A field verification of the declared premises was carried out.",
                 "Three specific observations are recorded in the notice.",
                 "No demand of tax has been raised."],
                ["Current photographs of the premises showing the signage",
                 "Registered rent agreement or ownership document",
                 "Latest electricity bill for the premises",
                 "List of additional places of business actually in use"],
                "Low",
                "No demand arises, but an unanswered notice of this kind can lead to "
                "suspension of registration, which would disrupt operations.",
                "High"),
        ],
        risk="Low", status="Revision Required", stage="Drafting",
        next_action="Revise the draft reply to address the signage observation",
        notice_days_ago=11, due_in_days=20,
        pdf_name="Sample_Registration_Notice.pdf",
    ),
    # ---------------------------------------------------------------- 9
    DemoScenario(
        key="appeal_sunrise",
        client_key="sunrise",
        notice_type="Appeal Order",
        notice_number="DEMO/APL-04/2021-22/0009",
        financial_year="2021-22",
        tax_period="April 2021 to March 2022",
        subject="Order in appeal - partial rejection of the first appeal",
        sections=["Section 107"],
        summary=(
            "The first appeal has been partly allowed and partly rejected. A demand "
            "of Rs. 15,20,000 survives. A hearing before the next appellate forum is "
            "awaited."
        ),
        narrative=[
            "The appeal filed against the order of the adjudicating authority has "
            "been decided. The relief granted and the demand sustained are "
            "summarised below.",
            "",
            "Central Tax (CGST) sustained                : Rs.   5,50,000",
            "State Tax (SGST) sustained                  : Rs.   5,50,000",
            "Interest sustained                          : Rs.   3,00,000",
            "Penalty sustained                           : Rs.   1,20,000",
            "",
            "The grounds relating to limitation have been rejected, while partial "
            "relief has been granted on the quantum. A further appeal may be filed "
            "before the appropriate appellate forum within the time allowed.",
        ],
        demand={"cgst": 550000, "sgst": 550000, "interest": 300000,
                "penalty": 120000},
        issues=[
            _issue(
                1, "Demand sustained in the order in appeal",
                "The appellate authority has sustained a demand of Rs. 11,00,000 in "
                "tax with interest and penalty, while granting partial relief on "
                "quantum.",
                1100000, ["Section 107"],
                ["Partial relief has been granted on the quantum of the demand.",
                 "The grounds relating to limitation have been rejected.",
                 "A further appeal is available within the prescribed period."],
                ["Certified copy of the order in appeal",
                 "Computation of the pre-deposit for a further appeal",
                 "Limitation date for filing the further appeal",
                 "Assessment of which grounds merit being pressed again"],
                "High",
                "A substantial demand survives and the further appeal is subject to "
                "a strict limitation period.",
                "High"),
        ],
        risk="High", status="Hearing Pending", stage="Hearing",
        next_action="Prepare the further appeal papers and the pre-deposit working",
        notice_days_ago=25, due_in_days=18,
    ),
    # ---------------------------------------------------------------- 10
    DemoScenario(
        key="other_greenfield",
        client_key="greenfield",
        notice_type="Other",
        notice_number="DEMO/COMM/2024-25/0010",
        financial_year="2024-25",
        tax_period="April 2024 to December 2024",
        subject="Departmental communication - negative liability ledger",
        sections=["Section 61"],
        summary=(
            "A departmental communication has been received regarding a negative "
            "balance appearing in the liability ledger and a related reconciliation "
            "difference of Rs. 2,10,000. The reply is overdue."
        ),
        narrative=[
            "It is observed from the system records that a negative balance appears "
            "in your liability ledger, and that the adjustment made does not "
            "reconcile with the returns furnished.",
            "",
            "Central Tax (CGST) involved                 : Rs.   1,05,000",
            "State Tax (SGST) involved                   : Rs.   1,05,000",
            "",
            "You are requested to explain the adjustment, to furnish a "
            "reconciliation of the liability discharged with the returns filed, and "
            "to correct the position in the subsequent return if required.",
        ],
        demand={"cgst": 105000, "sgst": 105000},
        issues=[
            _issue(
                1, "Negative liability ledger and reconciliation difference",
                "A negative balance in the liability ledger and an unreconciled "
                "adjustment of Rs. 2,10,000 have been pointed out.",
                210000, ["Section 61"],
                ["A negative balance appears in the liability ledger.",
                 "The adjustment does not reconcile with the returns furnished."],
                ["Month-wise liability register",
                 "Details of the adjustment entries made",
                 "Copies of the returns for the affected periods",
                 "Working showing how the negative balance arose"],
                "Medium",
                "The amount is modest but the reply is already overdue, which can "
                "escalate an otherwise routine reconciliation.",
                "Medium"),
        ],
        risk="Medium", status="New", stage="Notice Received",
        next_action="File the reconciliation reply - the due date has passed",
        notice_days_ago=24, due_in_days=-3,
    ),
    # ---------------------------------------------------------------- 11
    DemoScenario(
        key="asmt10_technova",
        client_key="technova",
        notice_type="ASMT-10",
        notice_number="DEMO/ASMT-10/2022-23/0011",
        financial_year="2022-23",
        tax_period="April 2022 to March 2023",
        subject="Scrutiny of returns - interest on delayed payment",
        sections=["Section 61", "Section 50"],
        summary=(
            "A scrutiny notice regarding interest on delayed payment of tax for the "
            "financial year 2022-23. The reply has been filed and an acknowledgement "
            "received."
        ),
        narrative=[
            "On scrutiny of the returns for the financial year 2022-23, interest "
            "appears to be payable on tax discharged after the prescribed due dates.",
            "",
            "Central Tax (CGST)                          : Rs.     47,500",
            "State Tax (SGST)                            : Rs.     47,500",
            "",
            "You are requested to furnish a month-wise working of the interest "
            "payable, or to explain why no interest is payable.",
        ],
        demand={"cgst": 47500, "sgst": 47500},
        issues=[
            _issue(
                1, "Interest on delayed payment of tax",
                "Interest is stated to be payable on tax discharged after the "
                "prescribed due dates for the financial year 2022-23.",
                95000, ["Section 50", "Section 61"],
                ["Tax for certain periods was discharged after the due date.",
                 "The notice seeks a month-wise interest working."],
                ["Month-wise working of tax paid in cash and through credit",
                 "Dates on which each return was filed",
                 "Balance available in the electronic cash ledger on each due date"],
                "Low",
                "The amount is small and the computation is mechanical once the "
                "payment dates are compiled.",
                "High"),
        ],
        risk="Low", status="Filed", stage="Filed",
        next_action="Monitor for any further communication from the department",
        notice_days_ago=60, due_in_days=-20,
    ),
    # ---------------------------------------------------------------- 12
    DemoScenario(
        key="drc01a_greenfield",
        client_key="greenfield",
        notice_type="DRC-01A",
        notice_number="DEMO/DRC-01A/2021-22/0012",
        financial_year="2021-22",
        tax_period="April 2021 to March 2022",
        subject="Intimation of tax ascertained as payable - concluded",
        sections=["Section 73(5)", "Section 16"],
        rules=["Rule 142(1A)"],
        summary=(
            "An intimation relating to input tax credit for the financial year "
            "2021-22. The matter was concluded on payment of the ascertained amount "
            "and no show cause notice followed."
        ),
        narrative=[
            "Input tax credit availed for the financial year 2021-22 appears to "
            "exceed the credit admissible.",
            "",
            "Central Tax (CGST)                          : Rs.   2,25,000",
            "State Tax (SGST)                            : Rs.   2,25,000",
            "Interest under Section 50                   : Rs.     90,000",
            "",
            "You may pay the amount ascertained above along with interest and "
            "intimate the payment, whereupon no notice will be issued in respect of "
            "the amount so paid.",
        ],
        demand={"cgst": 225000, "sgst": 225000, "interest": 90000},
        issues=[
            _issue(
                1, "Input tax credit ascertained as inadmissible",
                "Input tax credit of Rs. 4,50,000 was ascertained as inadmissible "
                "with interest of Rs. 90,000.",
                450000, ["Section 73(5)", "Section 16"],
                ["The intimation relates to the financial year 2021-22.",
                 "The amount was ascertained before issue of a show cause notice.",
                 "The matter was concluded on payment."],
                ["Acknowledgement of the payment intimation",
                 "Confirmation that no further notice was issued"],
                "Medium",
                "The matter is concluded, and is retained for record and for "
                "consistency of positions taken in later years.",
                "High"),
        ],
        risk="Medium", status="Closed", stage="Closed",
        next_action="No further action - retained for record",
        notice_days_ago=200, due_in_days=-170,
    ),
]

SCENARIOS_BY_KEY = {s.key: s for s in DEMO_SCENARIOS}
SCENARIOS_BY_NOTICE_NUMBER = {s.notice_number: s for s in DEMO_SCENARIOS}


def featured_scenario() -> DemoScenario:
    """The matter highlighted for the live walkthrough."""
    for scenario in DEMO_SCENARIOS:
        if scenario.featured:
            return scenario
    return DEMO_SCENARIOS[0]


def find_scenario(notice_number: str = "", case: Optional[Dict[str, Any]] = None
                  ) -> Optional[DemoScenario]:
    """
    Resolve the scenario behind a case.

    Used by the mock AI so that clicking *Analyse Notice with AI* on a demo
    case reproduces exactly the figures printed on that case's sample notice.
    """
    if notice_number and notice_number in SCENARIOS_BY_NOTICE_NUMBER:
        return SCENARIOS_BY_NOTICE_NUMBER[notice_number]
    if case:
        number = (case.get("notice_number") or "").strip()
        if number in SCENARIOS_BY_NOTICE_NUMBER:
            return SCENARIOS_BY_NOTICE_NUMBER[number]
    return None


def scenario_analysis(scenario: DemoScenario, notice_date: str = "",
                      due_date: str = "") -> Dict[str, Any]:
    """
    Build the structured analysis payload for a scenario.

    This is the shape the notice-analysis pipeline expects, so the same
    dictionary serves both the pre-loaded analysis and the mock AI response.
    """
    client = scenario.client
    return {
        "taxpayer_name": client.client_name,
        "gstin": client.gstin,
        "notice_type": scenario.notice_type,
        "notice_number": scenario.notice_number,
        "financial_year": scenario.financial_year,
        "tax_period": scenario.tax_period,
        "notice_date": notice_date,
        "reply_due_date": due_date,
        "sections_invoked": list(scenario.sections),
        "rules_invoked": list(scenario.rules),
        "officer_name": scenario.officer,
        "designation": scenario.designation,
        "jurisdiction": scenario.jurisdiction,
        "summary": scenario.summary,
        "cgst": scenario.demand.get("cgst", 0),
        "sgst": scenario.demand.get("sgst", 0),
        "igst": scenario.demand.get("igst", 0),
        "cess": scenario.demand.get("cess", 0),
        "interest": scenario.demand.get("interest", 0),
        "penalty": scenario.demand.get("penalty", 0),
        "other_amount": scenario.demand.get("other_amount", 0),
        "issues": [dict(issue) for issue in scenario.issues],
    }
