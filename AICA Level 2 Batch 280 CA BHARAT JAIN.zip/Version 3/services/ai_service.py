"""
services.ai_service
===================
AI integration.

Two providers are supported and are interchangeable:

* **Gemini** through the official ``google-genai`` SDK
* **ChatGPT (OpenAI)** through the official ``openai`` SDK

The provider is chosen in Settings; every screen calls the same
:func:`generate`, so notice analysis, issue analysis, requirements,
research and draft replies all follow the selection automatically.

Every AI call in the application goes through :func:`generate`, which:

* refuses to call the API unless the user explicitly triggered an AI action;
* honours **Demo / Mock AI Mode**, returning stored sample output instead
  of contacting the API (so a classroom demo never depends on the network);
* converts every failure mode (missing key, invalid key, timeout, network
  error, malformed JSON) into a friendly, actionable message;
* never logs or displays the API key.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import config
from utils.helpers import extract_json
from utils.logger import get_logger

log = get_logger(__name__)

# Error categories surfaced to the UI
ERR_NO_KEY = "no_api_key"
ERR_AUTH = "invalid_key"
ERR_TIMEOUT = "timeout"
ERR_NETWORK = "network"
ERR_QUOTA = "quota"
ERR_API = "api_error"
ERR_BAD_JSON = "malformed_json"
ERR_EMPTY = "empty_response"
ERR_SDK = "sdk_missing"

FRIENDLY_MESSAGES = {
    ERR_NO_KEY: (
        "No API key is configured for the selected AI provider.\n\n"
        "Create a file named '.env' in the application folder containing one of:\n"
        "    GEMINI_API_KEY=your_api_key_here\n"
        "    OPENAI_API_KEY=your_openai_key_here\n\n"
        "Then restart the application. Alternatively switch on Demo Mode in "
        "Settings to run the demonstration without any API."
    ),
    ERR_AUTH: (
        "The AI provider rejected the configured key.\n\n"
        "Check the key in your .env file for the provider selected in "
        "Settings, or switch on Demo Mode."
    ),
    ERR_TIMEOUT: (
        "The AI request timed out.\n\n"
        "The notice may be very long, or the connection slow. Try again, "
        "shorten the text, or use Demo Mode."
    ),
    ERR_NETWORK: (
        "The Gemini API could not be reached.\n\n"
        "Please check your internet connection, or switch on Demo Mode in "
        "Settings to continue without the API."
    ),
    ERR_QUOTA: (
        "The Gemini API reported a quota or rate limit problem.\n\n"
        "Please wait a moment and try again, or switch on Demo Mode."
    ),
    ERR_SDK: (
        "The SDK for the selected AI provider is not installed.\n\n"
        "Install the one you need:\n"
        "    pip install google-genai      (Gemini)\n"
        "    pip install openai            (ChatGPT)\n\n"
        "Demo Mode works without either SDK."
    ),
    ERR_BAD_JSON: (
        "The AI returned a response that could not be read as structured data.\n\n"
        "This can happen occasionally. Please try again. The raw response has "
        "been kept so it can be reviewed."
    ),
    ERR_EMPTY: (
        "The AI returned an empty response. Please try again."
    ),
    ERR_API: "The Gemini API reported an error.",
}


@dataclass
class AIResponse:
    """Result of one AI call."""

    ok: bool = False
    text: str = ""
    data: Optional[Any] = None
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    model: str = ""
    elapsed: float = 0.0
    raw: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)

    @property
    def friendly_error(self) -> str:
        """A message that can be shown directly to the user."""
        if not self.error_kind:
            return self.error
        base = FRIENDLY_MESSAGES.get(self.error_kind, self.error)
        if self.error_kind == ERR_API and self.error:
            return f"{base}\n\nDetails: {self.error}"
        return base

    @property
    def source_label(self) -> str:
        return "Demo Mode (sample data)" if self.demo else f"Gemini ({self.model})"


# ---------------------------------------------------------------------------
# Availability checks
# ---------------------------------------------------------------------------
def gemini_sdk_available() -> bool:
    """True when the google-genai SDK can be imported."""
    try:
        from google import genai  # noqa: F401

        return True
    except ImportError:
        return False


def openai_sdk_available() -> bool:
    """True when the openai SDK can be imported."""
    try:
        import openai  # noqa: F401

        return True
    except ImportError:
        return False


def sdk_available(provider: str = "") -> bool:
    """True when the SDK for a provider is installed."""
    provider = provider or config.current_provider()
    if provider == config.PROVIDER_OPENAI:
        return openai_sdk_available()
    return gemini_sdk_available()


def provider_status(provider: str) -> Dict[str, Any]:
    """Configuration summary for one provider."""
    return {
        "provider": provider,
        "sdk_installed": sdk_available(provider),
        "key_configured": config.api_key_available(provider),
        "key_masked": config.masked_api_key(provider),
        "model": config.provider_model(provider),
        "env_var": config.provider_env_var(provider),
        "ready": sdk_available(provider) and config.api_key_available(provider),
    }


def api_status() -> Dict[str, Any]:
    """Configuration summary for the Settings screen."""
    provider = config.current_provider()
    status = provider_status(provider)
    status.update({
        "timeout": (config.OPENAI_TIMEOUT
                    if provider == config.PROVIDER_OPENAI else config.GEMINI_TIMEOUT),
        "providers": {p: provider_status(p) for p in config.AI_PROVIDERS},
    })
    return status


def _classify(exc: Exception) -> str:
    """
    Map an SDK/network exception onto an error category.

    Both the Gemini and the OpenAI SDKs are covered: the exception class
    names differ but the underlying conditions are the same, so the
    matching looks at the class name and the message together.
    """
    name = type(exc).__name__.lower()
    text = str(exc).lower()
    if "timeout" in name or "timeout" in text or "deadline" in text:
        return ERR_TIMEOUT
    if "authentication" in name or "permissiondenied" in name:
        return ERR_AUTH
    if any(token in text for token in
           ("api key not valid", "api_key_invalid", "incorrect api key",
            "invalid_api_key", "unauthenticated", "permission denied",
            "401", "403")):
        return ERR_AUTH
    if "ratelimit" in name:
        return ERR_QUOTA
    if any(token in text for token in
           ("quota", "rate limit", "resource_exhausted", "insufficient_quota", "429")):
        return ERR_QUOTA
    if "connection" in name:
        return ERR_NETWORK
    if any(token in text for token in
           ("connection", "network", "unreachable", "dns", "ssl", "socket",
            "getaddrinfo", "temporarily unavailable")):
        return ERR_NETWORK
    return ERR_API


# ---------------------------------------------------------------------------
# The single entry point for all AI calls
# ---------------------------------------------------------------------------
def generate(prompt: str, *, demo_mode: bool = True, demo_payload: Any = None,
             expect_json: bool = True, temperature: float = 0.2,
             max_output_tokens: int = 8192, provider: str = "",
             label: str = "AI request") -> AIResponse:
    """
    Run one AI generation.

    Parameters
    ----------
    prompt:
        The fully-rendered prompt text.
    demo_mode:
        When True the API is **not** called; ``demo_payload`` is returned
        instead, flagged as demo output.
    demo_payload:
        Sample data used in demo mode (a dict/list for JSON calls, or a
        string for free-text calls).
    expect_json:
        When True the response is parsed into ``response.data``; a parse
        failure is reported as :data:`ERR_BAD_JSON`.
    provider:
        Overrides the provider chosen in Settings. Used by the connection
        test so each provider can be checked individually.
    """
    provider = provider or config.current_provider()
    started = time.perf_counter()

    # ---------------------------------------------------- demo / mock mode
    if demo_mode:
        log.info("%s served from Demo Mode (no API call)", label)
        time.sleep(0.6)  # brief pause so the progress dialog is visible
        if expect_json:
            return AIResponse(
                ok=True, data=demo_payload, demo=True, model="demo",
                text="", elapsed=time.perf_counter() - started,
            )
        return AIResponse(
            ok=True, text=str(demo_payload or ""), demo=True, model="demo",
            elapsed=time.perf_counter() - started,
        )

    # ---------------------------------------------------------- live calls
    model_name = config.provider_model(provider)

    if not sdk_available(provider):
        return AIResponse(ok=False, error_kind=ERR_SDK, model=model_name,
                          error=f"The SDK for {provider} is not installed",
                          elapsed=time.perf_counter() - started)
    if not config.api_key_available(provider):
        return AIResponse(ok=False, error_kind=ERR_NO_KEY, model=model_name,
                          error=f"{config.provider_env_var(provider)} is not set",
                          elapsed=time.perf_counter() - started)

    try:
        log.info("%s -> %s model %s (%d chars of prompt)",
                 label, provider, model_name, len(prompt))
        if provider == config.PROVIDER_OPENAI:
            text = _call_openai(prompt, expect_json, temperature, max_output_tokens)
        else:
            text = _call_gemini(prompt, expect_json, temperature, max_output_tokens)

    except Exception as exc:  # noqa: BLE001 - SDKs raise many exception types
        kind = _classify(exc)
        log.error("%s failed on %s (%s): %s", label, provider, kind, exc)
        return AIResponse(ok=False, error_kind=kind, error=str(exc),
                          model=model_name,
                          elapsed=time.perf_counter() - started)

    elapsed = time.perf_counter() - started

    if not text:
        return AIResponse(ok=False, error_kind=ERR_EMPTY,
                          error="Empty response from the model",
                          model=model_name, elapsed=elapsed)

    if not expect_json:
        return AIResponse(ok=True, text=text, raw=text,
                          model=model_name, elapsed=elapsed)

    data = extract_json(text)
    if data is None:
        log.warning("%s returned unparseable JSON (%d chars)", label, len(text))
        return AIResponse(ok=False, error_kind=ERR_BAD_JSON,
                          error="Response was not valid JSON", raw=text,
                          text=text, model=model_name, elapsed=elapsed)

    log.info("%s completed on %s in %.1fs", label, provider, elapsed)
    return AIResponse(ok=True, data=data, text=text, raw=text,
                      model=model_name, elapsed=elapsed)


# ---------------------------------------------------------------------------
# Provider back ends
# ---------------------------------------------------------------------------
def _call_gemini(prompt: str, expect_json: bool, temperature: float,
                 max_output_tokens: int) -> str:
    """One Gemini generation. Returns the raw response text."""
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=config.GEMINI_API_KEY)
    generation_config: Dict[str, Any] = {
        "temperature": temperature,
        "max_output_tokens": max_output_tokens,
    }
    if expect_json:
        generation_config["response_mime_type"] = "application/json"

    response = client.models.generate_content(
        model=config.GEMINI_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(**generation_config),
    )
    return (getattr(response, "text", "") or "").strip()


def _call_openai(prompt: str, expect_json: bool, temperature: float,
                 max_output_tokens: int) -> str:
    """
    One ChatGPT generation. Returns the raw response text.

    JSON mode is requested when structured output is expected, which keeps
    the same strict contract the rest of the application relies on.
    """
    from openai import OpenAI

    client = OpenAI(api_key=config.OPENAI_API_KEY, timeout=config.OPENAI_TIMEOUT)
    kwargs: Dict[str, Any] = {
        "model": config.OPENAI_MODEL,
        "messages": [
            {"role": "system",
             "content": "You assist a Chartered Accountant in India with GST "
                        "litigation work. Follow the user's instructions exactly "
                        "and never invent facts, citations or figures."},
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_output_tokens,
    }
    if expect_json:
        kwargs["response_format"] = {"type": "json_object"}

    response = client.chat.completions.create(**kwargs)
    if not response.choices:
        return ""
    return (response.choices[0].message.content or "").strip()


def test_connection(provider: str = "") -> AIResponse:
    """
    Send a tiny live request to confirm a provider's key works.

    Used by Settings > Test AI Connection. Always calls the API (demo mode
    is bypassed) because that is the point of the test.
    """
    return generate(
        'Reply with exactly this JSON and nothing else: {"status":"ok"}',
        demo_mode=False, expect_json=True, temperature=0.0,
        max_output_tokens=64, provider=provider, label="Connection test",
    )
