"""
services.research_service
=========================
"Ask GST Copilot" - source-grounded GST research.

Workflow::

    question
      -> retrieve relevant passages from the local knowledge base (rag_service)
      -> send question + passages to Gemini with a strict grounding rule
      -> structured answer with source references
      -> save to SQLite

The prompt forbids citing anything that is not in the retrieved passages.
When nothing relevant is retrieved the answer must say so rather than
invent a citation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from database import database as db
from services import ai_service, mock_data, rag_service
from services.issue_service import build_case_context
from services.rag_service import RetrievedChunk
from utils.formatters import dumps
from utils.helpers import load_prompt
from utils.logger import get_logger

log = get_logger(__name__)

NO_SOURCE_SENTENCE = (
    "No sufficiently relevant source was located in the current local knowledge base."
)

# Section order used when the answer is rendered as text
ANSWER_SECTIONS = [
    ("short_answer", "SHORT ANSWER"),
    ("statutory_provisions", "RELEVANT STATUTORY PROVISION"),
    ("rules", "RELEVANT RULES"),
    ("circulars_notifications", "RELEVANT CIRCULAR / NOTIFICATION"),
    ("judicial_material", "RELEVANT JUDICIAL MATERIAL"),
    ("analysis", "ANALYSIS"),
    ("applicability_to_present_case", "APPLICABILITY TO THE PRESENT CASE"),
    ("facts_requiring_verification", "INFORMATION / FACTS REQUIRING VERIFICATION"),
    ("limitations", "LIMITATIONS OF THIS ANSWER"),
]


@dataclass
class ResearchResult:
    """Outcome of one research run."""

    ok: bool = False
    question: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    answer_text: str = ""
    sources: List[RetrievedChunk] = field(default_factory=list)
    sources_text: str = ""
    grounded: bool = False
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    source: str = ""
    elapsed: float = 0.0

    @property
    def source_count(self) -> int:
        return len(self.sources)


def build_prompt(question: str, chunks: Sequence[RetrievedChunk],
                 case: Optional[Dict[str, Any]] = None) -> str:
    """Render the legal-research prompt with the retrieved passages inlined."""
    template = load_prompt("legal_research")
    if not template:
        from services.prompt_setup import LEGAL_RESEARCH

        template = LEGAL_RESEARCH
    safety = load_prompt("_safety_rules")
    try:
        return template.format(
            safety=safety,
            question=question,
            case_context=build_case_context(case) if case else "Not supplied.",
            sources=rag_service.format_sources_for_prompt(chunks),
        )
    except (KeyError, IndexError, ValueError) as exc:
        log.error("legal_research prompt template is malformed: %s", exc)
        return (f"{safety}\n\nAnswer this GST question using ONLY the sources "
                f"supplied.\n\nQuestion: {question}\n\n"
                f"{rag_service.format_sources_for_prompt(chunks)}")


def research(question: str, case: Optional[Dict[str, Any]] = None,
             top_k: int = 6, category: str = "", demo_mode: bool = True
             ) -> ResearchResult:
    """
    Answer a GST research question from the local knowledge base.

    Run this on a worker thread -- it performs retrieval and an AI call.
    """
    result = ResearchResult(question=(question or "").strip(), demo=demo_mode)
    if not result.question:
        result.error = "Please enter a research question."
        result.error_kind = "no_question"
        return result

    try:
        chunks = rag_service.search(result.question, top_k=top_k, category=category)
    except Exception as exc:  # noqa: BLE001 - retrieval must not crash the app
        log.exception("Knowledge base search failed")
        result.error = f"The knowledge base could not be searched: {exc}"
        result.error_kind = "retrieval_failed"
        return result

    result.sources = list(chunks)
    result.grounded = bool(chunks)

    response = ai_service.generate(
        build_prompt(result.question, chunks, case),
        demo_mode=demo_mode,
        demo_payload=mock_data.legal_research(result.question, bool(chunks)),
        expect_json=True,
        temperature=0.15,
        label="GST research",
    )

    result.demo = response.demo
    result.source = response.source_label
    result.elapsed = response.elapsed

    if not response.ok:
        result.error = response.friendly_error
        result.error_kind = response.error_kind
        return result

    data = response.data if isinstance(response.data, dict) else {}
    result.ok = True
    result.data = data
    result.answer_text = render_answer(result.question, data, chunks)
    result.sources_text = render_sources(chunks)
    return result


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------
def render_answer(question: str, data: Dict[str, Any],
                  chunks: Sequence[RetrievedChunk]) -> str:
    """Format the structured answer as readable text."""
    lines: List[str] = []
    add = lines.append

    add("RESEARCH QUESTION")
    add(f"  {question}")
    add("")

    if not chunks:
        add("SOURCE POSITION")
        add(f"  {NO_SOURCE_SENTENCE}")
        add("")

    for key, heading in ANSWER_SECTIONS:
        value = data.get(key)
        if value in (None, "", [], {}):
            continue
        add(heading)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    add(f"  - {_render_citation_item(item)}")
                else:
                    add(f"  - {item}")
        else:
            for paragraph in str(value).split("\n"):
                add(f"  {paragraph}" if paragraph.strip() else "")
        add("")

    confidence = data.get("confidence")
    if confidence:
        add(f"CONFIDENCE: {confidence}")
        add("")

    add("-" * 74)
    add("This answer is limited to material present in the local knowledge base.")
    add("Every citation must be verified against the original source before it is")
    add("relied upon or reproduced in a submission.")
    return "\n".join(lines)


def _render_citation_item(item: Dict[str, Any]) -> str:
    """Format one statutory / judicial citation entry."""
    label = (item.get("provision") or item.get("rule") or item.get("reference")
             or item.get("case") or "")
    effect = item.get("effect") or item.get("principle") or ""
    reference = item.get("source_ref") or ""
    parts = [str(label).strip()]
    if effect:
        parts.append(f"- {effect}")
    if reference:
        parts.append(f"[{reference}]")
    return " ".join(p for p in parts if p)


def render_sources(chunks: Sequence[RetrievedChunk]) -> str:
    """Format the source list with file, category, page and excerpt."""
    if not chunks:
        return ("No source was retrieved from the local knowledge base.\n\n"
                "Add the relevant Act, rules, circulars, notifications or case "
                "notes through Knowledge Base > Add PDF, refresh the index, and "
                "run the search again.")
    blocks: List[str] = []
    for chunk in chunks:
        page = f"page {chunk.page}" if chunk.page else "page not available"
        blocks.append(
            f"[{chunk.ref}] {chunk.file_name}\n"
            f"      Category : {chunk.category}\n"
            f"      Location : {page}\n"
            f"      Relevance: {chunk.score}\n"
            f"      Extract  : {chunk.excerpt(420)}"
        )
    return "\n\n".join(blocks)


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
def save_research(result: ResearchResult, case_id: Optional[int] = None,
                  issue_id: Optional[int] = None, user_name: str = "") -> int:
    """Store a research answer so it can be reused without another AI call."""
    record_id = db.save_research({
        "case_id": case_id,
        "issue_id": issue_id,
        "question": result.question,
        "answer": result.answer_text,
        "sources": result.sources_text,
        "raw_json": dumps(result.data),
        "source_mode": result.source,
        "created_by": user_name,
    })
    db.log_activity("GST research saved",
                    f"{result.question[:120]} ({result.source_count} source(s))",
                    case_id=case_id, user_name=user_name)
    return record_id


def research_context_for_draft(case_id: int, limit: int = 4) -> str:
    """
    Compact research extract passed to the draft-reply prompt.

    Only saved research for the case is used, keeping the draft grounded in
    material the firm actually holds.
    """
    rows = db.list_research(case_id, limit=limit)
    if not rows:
        return ("No research has been saved against this case. Do not cite any "
                "legal source; use [LEGAL SOURCE TO BE VERIFIED] where a citation "
                "would be required.")
    blocks: List[str] = []
    for row in rows:
        blocks.append(
            f"Question: {row.get('question', '')}\n"
            f"Answer extract:\n{(row.get('answer') or '')[:2200]}\n"
            f"Sources:\n{(row.get('sources') or '')[:900]}"
        )
    return "\n\n" + ("\n" + "=" * 60 + "\n").join(blocks)
