"""
services.reply_service
======================
Draft reply generation and version control.

The draft is assembled from material the application already holds -- the
case particulars, the issue-wise extraction, the documents on record and
the saved research -- so the model is not asked to supply facts or
citations from memory.  Gaps are marked ``[CLIENT TO CONFIRM]`` and
missing authority is marked ``[LEGAL SOURCE TO BE VERIFIED]``.

No draft ever becomes "Final" automatically; only a user whose role
permits approval may set the CA Approved or Final status.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import config
from database import database as db
from services import ai_service, mock_data
from services.issue_service import build_case_context
from services.research_service import research_context_for_draft
from utils.calculations import compute_demand
from utils.formatters import format_currency, format_date, loads
from utils.helpers import can_approve, load_prompt
from utils.logger import get_logger

log = get_logger(__name__)

APPROVAL_STATUSES = {"CA Approved", "Final"}

# Case status implied by a draft status, so the workflow stays in step
STATUS_TO_CASE_STATUS = {
    "AI Generated": "Drafting",
    "Prepared": "Drafting",
    "Manager Reviewed": "Under Review",
    "Revision Required": "Revision Required",
    "CA Approved": "CA Approved",
    "Final": "CA Approved",
}


@dataclass
class DraftResult:
    """Outcome of one draft-generation run."""

    ok: bool = False
    text: str = ""
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    source: str = ""
    elapsed: float = 0.0
    issues_used: int = 0


# ---------------------------------------------------------------------------
# Context builders
# ---------------------------------------------------------------------------
def build_issues_context(issues: Sequence[Dict[str, Any]]) -> str:
    """Describe the selected issues for the prompt."""
    if not issues:
        return ("No issues have been recorded. Draft a general reply and mark every "
                "factual assertion as [CLIENT TO CONFIRM].")
    blocks: List[str] = []
    for issue in issues:
        facts = loads(issue.get("facts_identified"), []) or []
        missing = loads(issue.get("facts_missing"), []) or []
        analysis = (issue.get("ai_analysis") or "").strip()
        block = [
            f"ISSUE {issue.get('issue_no')}: {issue.get('title', '')}",
            f"Department's allegation: {issue.get('allegation', '')}",
            f"Amount involved: {format_currency(issue.get('amount'))}",
            f"Sections/rules cited in the notice: {issue.get('sections') or 'Not stated'}",
            f"Risk recorded: {issue.get('risk', '')} "
            f"(confidence {issue.get('confidence', '')})",
        ]
        if facts:
            block.append("Facts identified from the notice:")
            block += [f"  - {f}" for f in facts]
        if missing:
            block.append("Facts NOT available (use [CLIENT TO CONFIRM]):")
            block += [f"  - {f}" for f in missing]
        if issue.get("ca_remarks"):
            block.append(f"Chartered Accountant's conclusion on this issue: "
                         f"{issue['ca_remarks']}")
        if analysis:
            block.append("Working analysis available for this issue:")
            block.append(analysis[:1800])
        blocks.append("\n".join(block))
    return "\n\n" + ("\n" + "-" * 60 + "\n").join(blocks)


def build_documents_context(requirements: Sequence[Dict[str, Any]]) -> str:
    """List the documents on record so annexures reference real material."""
    if not requirements:
        return ("No document list has been recorded. Refer to annexures generically "
                "and mark specifics as [CLIENT TO CONFIRM].")
    received = [r for r in requirements if (r.get("status") or "") == "Received"]
    pending = [r for r in requirements
               if (r.get("status") or "Pending") == "Pending"]
    lines: List[str] = []
    if received:
        lines.append("Documents received and available to annex:")
        lines += [f"  - {r.get('document_name', '')}" for r in received]
    if pending:
        lines.append("Documents still awaited (do not assert these as available):")
        lines += [f"  - {r.get('document_name', '')}" for r in pending]
    return "\n".join(lines) if lines else "No documents recorded."


def build_demand_context(case: Dict[str, Any]) -> str:
    """The computed demand, so the model never re-derives a figure."""
    demand = compute_demand(case)
    rows = [f"  {label:<16}: {format_currency(amount)}"
            for label, amount, _is_total in demand.rows()]
    return ("Demand as computed by the application (use these figures exactly):\n"
            + "\n".join(rows))


def build_prompt(case: Dict[str, Any], issues: Sequence[Dict[str, Any]],
                 requirements: Sequence[Dict[str, Any]], research_text: str,
                 instructions: str) -> str:
    """Render the draft-reply prompt."""
    template = load_prompt("draft_reply")
    if not template:
        from services.prompt_setup import DRAFT_REPLY

        template = DRAFT_REPLY
    safety = load_prompt("_safety_rules")

    authority = (case.get("officer") or "THE PROPER OFFICER").upper()
    case_context = (
        build_case_context(case)
        + f"\nReply due date: {format_date(case.get('due_date'))}\n"
        + build_demand_context(case)
    )
    try:
        return template.format(
            safety=safety,
            authority=authority,
            case_context=case_context,
            issues_context=build_issues_context(issues),
            documents_context=build_documents_context(requirements),
            research_context=research_text or "No research extracts supplied.",
            instructions=instructions or "None.",
        )
    except (KeyError, IndexError, ValueError) as exc:
        log.error("draft_reply prompt template is malformed: %s", exc)
        return (f"{safety}\n\nDraft a formal GST reply for the following case.\n\n"
                f"{case_context}\n\n{build_issues_context(issues)}")


# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------
def generate_draft(case: Dict[str, Any], issues: Sequence[Dict[str, Any]],
                   requirements: Optional[Sequence[Dict[str, Any]]] = None,
                   instructions: str = "", use_research: bool = True,
                   demo_mode: bool = True) -> DraftResult:
    """Generate a draft reply (run this on a worker thread)."""
    result = DraftResult(demo=demo_mode, issues_used=len(issues))
    if not case:
        result.error = "No case was selected."
        return result

    research_text = (research_context_for_draft(int(case["id"]))
                     if use_research else "Research extracts were not included.")

    response = ai_service.generate(
        build_prompt(case, issues, requirements or [], research_text, instructions),
        demo_mode=demo_mode,
        demo_payload=mock_data.draft_reply(case, list(issues), compute_demand(case)),
        expect_json=False,
        temperature=0.35,
        max_output_tokens=16384,
        label="Draft reply",
    )

    result.demo = response.demo
    result.source = response.source_label
    result.elapsed = response.elapsed

    if not response.ok:
        result.error = response.friendly_error
        result.error_kind = response.error_kind
        return result

    result.ok = True
    result.text = _append_draft_footer(response.text, response.source_label)
    return result


def _append_draft_footer(text: str, source: str) -> str:
    """Every generated draft carries an explicit review warning."""
    marker = "DRAFT PREPARED WITH AI ASSISTANCE"
    if marker in text:
        return text
    return (text.rstrip() + "\n\n" + "-" * 78 + "\n"
            + f"{marker} ({source}) - NOT FOR FILING WITHOUT REVIEW.\n"
            + "All facts marked [CLIENT TO CONFIRM] and all references marked\n"
            + "[LEGAL SOURCE TO BE VERIFIED] must be completed and independently\n"
            + "verified by the Chartered Accountant before submission.\n"
            + "-" * 78)


# ---------------------------------------------------------------------------
# Version handling
# ---------------------------------------------------------------------------
def save_new_version(case_id: int, text: str, status: str = "AI Generated",
                     prepared_by: str = "", remarks: str = "") -> int:
    """Store a new draft version."""
    draft_id = db.create_draft(case_id, text, status=status,
                               prepared_by=prepared_by, remarks=remarks)
    version = (db.get_draft(draft_id) or {}).get("version", "?")
    db.log_activity("Draft saved", f"Version {version} ({status})", case_id=case_id,
                    user_name=prepared_by)
    _sync_case_status(case_id, status)
    return draft_id


def update_draft_text(draft_id: int, text: str, user_name: str = "") -> None:
    """Save an edit in place (does not create a new version)."""
    db.update_draft(draft_id, {"draft_text": text})
    draft = db.get_draft(draft_id)
    if draft:
        db.log_activity("Draft edited", f"Version {draft.get('version')}",
                        case_id=int(draft["case_id"]), user_name=user_name)


def set_status(draft_id: int, status: str, user_role: str,
               user_name: str = "") -> tuple:
    """
    Change a draft's status, enforcing the human-in-the-loop rule.

    Returns ``(ok, message)``.
    """
    if status not in config.DRAFT_STATUSES:
        return False, f"Unknown draft status: {status}"
    if status in APPROVAL_STATUSES and not can_approve(user_role):
        return False, (
            f"Your role ({user_role or 'unknown'}) may not mark a draft "
            f"'{status}'.\n\nOnly a user with the Admin / Partner or Reviewer role "
            "can approve a draft or mark it final. This safeguard exists because "
            "professional responsibility for the reply rests with the Chartered "
            "Accountant."
        )

    draft = db.get_draft(draft_id)
    if not draft:
        return False, "The draft could not be found."

    payload: Dict[str, Any] = {"status": status}
    if status in {"Manager Reviewed", "CA Approved", "Final"}:
        payload["reviewed_by"] = user_name
    db.update_draft(draft_id, payload)
    db.log_activity("Draft status changed",
                    f"Version {draft.get('version')} -> {status}",
                    case_id=int(draft["case_id"]), user_name=user_name)
    _sync_case_status(int(draft["case_id"]), status)
    return True, f"Draft version {draft.get('version')} marked '{status}'."


def _sync_case_status(case_id: int, draft_status: str) -> None:
    """Keep the case workflow status aligned with the draft status."""
    case_status = STATUS_TO_CASE_STATUS.get(draft_status)
    if not case_status:
        return
    case = db.get_case(case_id)
    if not case or case.get("status") in ("Filed", "Closed", "Hearing Pending"):
        return
    stage = {
        "Drafting": "Drafting", "Under Review": "Review",
        "Revision Required": "Drafting", "CA Approved": "Approved",
    }.get(case_status, "")
    db.update_case(case_id, {"status": case_status, "stage": stage or case.get("stage", "")})


def version_history(case_id: int) -> List[Dict[str, Any]]:
    """Version list for the history table."""
    return db.list_drafts(case_id)


def draft_readiness(case_id: int) -> Dict[str, Any]:
    """
    Summarise what is available before drafting, so the user knows what the
    AI will and will not have to work with.
    """
    issues = db.list_issues(case_id)
    requirements = db.list_requirements(case_id)
    research = db.list_research(case_id, limit=50)
    analysis = db.get_notice_analysis(case_id)
    return {
        "issues": len(issues),
        "issues_analysed": len([i for i in issues if (i.get("ai_analysis") or "").strip()]),
        "requirements": len(requirements),
        "requirements_received": len([r for r in requirements
                                      if r.get("status") == "Received"]),
        "research": len(research),
        "has_analysis": bool(analysis),
    }
