"""
services.demo_kb
================
Demonstration knowledge-base documents.

Four short educational notes are generated so the retrieval and research
workflow can be demonstrated immediately. The content is original summary
material written for this application: it reproduces no copyrighted
commentary, and it deliberately cites no case law, circular or notification,
because the research module must only ever cite sources the firm actually
holds.

Replace these with authentic official publications before any professional
use.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

import config
from utils.logger import get_logger

log = get_logger(__name__)

FOOTER = config.DEMO_KB_FOOTER

# (category, filename, title, body)
DOCUMENTS: List[Tuple[str, str, str, str]] = [
    (
        "acts",
        "Demo_CGST_Section_16_Notes.pdf",
        "Working notes on the conditions for input tax credit",
        """WORKING NOTES - CONDITIONS FOR AVAILING INPUT TAX CREDIT
DEMONSTRATION MATERIAL PREPARED FOR TRAINING USE

PURPOSE OF THIS NOTE
This note summarises, in the author's own words, the framework a Chartered
Accountant applies when testing whether input tax credit has been validly
availed. It is a working aid. It is not a reproduction of the statute and it
is not a legal opinion.

THE CONDITIONS ARE CUMULATIVE
Entitlement to input tax credit is not established by any single fact. The
recipient must be able to demonstrate each of the following independently:

  1. POSSESSION OF A VALID TAX PAYING DOCUMENT
     A tax invoice, debit note or other prescribed document must be held, and
     it must contain the prescribed particulars. A document missing the
     recipient GSTIN, the tax amount or the place of supply invites challenge.

  2. RECEIPT OF THE GOODS OR SERVICES
     Actual receipt must be evidenced. For goods this normally means transport
     documents, gate entry records, weighbridge slips or goods receipt notes.
     For services it means deliverables, reports, timesheets or correspondence.

  3. TAX ACTUALLY REACHING THE GOVERNMENT
     The tax charged on the supply must have been paid to the Government. This
     is the condition the department relies on where a supplier has defaulted
     or where a supplier registration has been cancelled. It is the condition
     least within the recipient's control, and it is the one that most often
     becomes contested.

  4. FURNISHING OF THE RETURN
     The recipient must have furnished the return for the relevant period.

  5. COMMUNICATION AND RESTRICTION
     Credit must not have been restricted through the communicated statements,
     and the supplier reporting position must be considered for the period.

PAYMENT TO THE SUPPLIER
Where the recipient fails to pay the supplier the value of the supply together
with the tax within the prescribed period from the invoice date, an amount
equal to the credit availed becomes liable to be added to output tax liability
with interest. The credit becomes available again when payment is made. In
practice this means the ageing of creditors must be reviewed alongside the
credit register.

TIME LIMIT
Credit cannot be availed after the prescribed cut-off, which is linked to the
return for the period and to the annual return. The cut-off has been amended
over time, so the version applicable to the period under examination must be
checked rather than assumed.

PRACTICAL POINTS WHEN REPLYING TO A NOTICE
  - Each condition is independent; satisfying three of the four is not enough.
  - The burden of demonstrating compliance rests on the person claiming credit.
  - A mismatch between a return and an auto-populated statement is not, by
    itself, proof that any condition has been breached.
  - Credit that never appears in the supplier-reported statement - import IGST
    credit and reverse charge credit - commonly explains part of an alleged
    difference.
  - Where a supplier has defaulted, assemble the complete evidentiary trail for
    the transaction before conceding the credit.

CAUTION
The precise wording, the conditions and the time limits have all been amended
from time to time. Apply the provisions as they stood for the period under
examination, and verify against the bare Act and the rules before advising.
""",
    ),
    (
        "internal_research",
        "Demo_RCM_Checklist.pdf",
        "Reverse charge review checklist",
        """REVERSE CHARGE - REVIEW CHECKLIST
DEMONSTRATION MATERIAL PREPARED FOR TRAINING USE

WHEN THIS CHECKLIST IS USED
Departmental notices frequently allege short payment under reverse charge by
scanning the expense heads in the financial statements and assuming that every
rupee booked under certain heads attracts the levy. That assumption is often
wrong. This checklist sets out the review a Chartered Accountant performs
before accepting any part of such a demand.

STEP 1 - OBTAIN THE DEPARTMENT'S WORKING
Ask for the ledger-wise working relied upon. A demand computed from a
consolidated expense figure cannot be answered meaningfully, and the request
itself is a legitimate preliminary submission.

STEP 2 - MAP EACH EXPENSE HEAD
For every head identified, record:
  - the nature of the supply actually received;
  - the status of the supplier (registered or unregistered);
  - whether the supply falls within a notified reverse charge category for the
    period in question;
  - whether the head contains amounts that are not supplies at all, such as
    reimbursements, statutory levies, salaries or provisions.

STEP 3 - SEPARATE THE CATEGORIES
Expense heads commonly examined include legal services, goods transport agency
services, services received from directors, security services, sponsorship and
certain imports of service. Each has its own conditions, and each must be
tested separately rather than as a group.

STEP 4 - RECONCILE WITH WHAT WAS ALREADY PAID
Compare the liability computed with the reverse charge liability already
declared and discharged in the returns. Demands are frequently raised without
credit for amounts already paid.

STEP 5 - CONSIDER REVENUE NEUTRALITY
Where the tax, if payable, would have been available as input tax credit in the
same period, the exercise may be substantially revenue neutral. This is a
factual submission and must be supported by the credit position for the
relevant months. Note that interest exposure may remain even where the tax
position is neutral.

STEP 6 - CHECK THE SELF-INVOICING POSITION
Where reverse charge applies to supplies from an unregistered person,
self-invoicing and payment voucher requirements arise. Confirm whether these
were complied with, since a procedural gap is answered differently from a
substantive one.

DOCUMENTS TO COLLECT
  - Ledger accounts of every expense head identified
  - Sample vendor invoices for each head, at least five per head
  - Registration status of the concerned suppliers
  - The reverse charge working prepared for the returns
  - Challans evidencing payment
  - The credit position for the corresponding months

CAUTION
The categories notified for reverse charge, and the conditions attaching to
them, have changed over time. Verify the position applicable to the period
under examination before advising.
""",
    ),
    (
        "internal_research",
        "Demo_GSTR1_3B_Reconciliation_Guide.pdf",
        "Guide to reconciling outward supplies with the summary return",
        """RECONCILING OUTWARD SUPPLIES - GSTR-1 VERSUS GSTR-3B
DEMONSTRATION MATERIAL PREPARED FOR TRAINING USE

THE ALLEGATION
A scrutiny notice typically compares the taxable turnover declared in the
statement of outward supplies with the turnover declared in the summary return
for the same financial year, and treats the difference as turnover on which tax
has been short paid. The comparison is made at an annual aggregate level.

WHY A DIFFERENCE IS NOT AUTOMATICALLY A SHORT PAYMENT
A difference between the two returns is a reconciling item until it is shown to
be an omission. The following commonly explain it in whole or in part:

  1. TIMING
     An invoice reported in the statement of outward supplies in March may be
     included in the summary return for a different month, and vice versa.

  2. AMENDMENTS
     Amendments reported in a later period change the earlier figures.

  3. CREDIT NOTES AND DEBIT NOTES
     Credit notes reduce the turnover reported in one return before the other,
     particularly where they are issued close to the year end.

  4. ADVANCES
     Tax paid on advances for services, and the adjustment of those advances on
     subsequent invoicing, affects the two returns differently.

  5. SUPPLIES WITHOUT AN INVOICE IN THE PERIOD
     Certain adjustments are reported in the summary return alone.

  6. EXPORTS AND ZERO-RATED SUPPLIES
     Classification differences between the two returns can produce an apparent
     turnover difference with no tax effect.

  7. SCHEDULE ENTRIES AND NON-SUPPLIES
     Amounts that are not supplies at all are sometimes swept into the
     comparison when it is prepared from financial statements.

THE WORKING TO PREPARE
  Step 1  Obtain both returns for every month of the period.
  Step 2  Prepare a month-wise comparison, not an annual one.
  Step 3  Extract the credit note and debit note register for the period.
  Step 4  Extract the amendment report for the period.
  Step 5  Identify each reconciling item and quantify it.
  Step 6  Tie the reconciled turnover to the audited financial statements.
  Step 7  Quantify the residual difference, if any, and identify the invoices
          that comprise it.

STRUCTURE OF THE REPLY
  - Deny the allegation and state that the comparison is an annual aggregate.
  - Annex the month-wise reconciliation and explain each reconciling item.
  - Deal with the residual difference, if any, on merits.
  - Address interest and penalty separately and without prejudice.
  - Request the departmental working and a personal hearing.

CAUTION
This guide records a working methodology only. It cites no provision and no
authority. Verify the legal position against current law before advising.
""",
    ),
    (
        "internal_research",
        "Demo_ITC_Mismatch_Checklist.pdf",
        "Input tax credit mismatch - verification checklist",
        """INPUT TAX CREDIT MISMATCH - VERIFICATION CHECKLIST
DEMONSTRATION MATERIAL PREPARED FOR TRAINING USE

THE ALLEGATION
The credit availed in the summary return for the year is compared with the
credit appearing in the auto-populated statement, and the entire difference is
proposed to be disallowed.

FIRST PRINCIPLE
An aggregate annual comparison does not establish that any condition for
availing credit has been breached. It identifies an amount to be explained.
Nothing should be conceded until the difference has been reconciled at
transaction level.

CATEGORIES THAT EXPLAIN A DIFFERENCE WITHOUT ANY IRREGULARITY
  1. Credit of the preceding financial year availed in the current year.
  2. Credit of the current year availed in the succeeding year.
  3. Import IGST credit, taken from bills of entry, which does not appear in
     the supplier-reported statement at all.
  4. Credit of tax paid under reverse charge, which is self-invoiced and
     likewise does not appear in that statement.
  5. Invoices reported late by suppliers, appearing in a later period.
  6. Credit notes and amendments reported by suppliers.
  7. Transitional credit and credit distributed by an input service
     distributor.

THE WORKING TO PREPARE
  Step 1  Obtain the monthly summary returns and auto-populated statements for
          the whole period.
  Step 2  Prepare a month-wise three-way reconciliation.
  Step 3  Reconcile the purchase register with the statement, invoice by
          invoice.
  Step 4  Segregate the categories listed above and quantify each.
  Step 5  Quantify the residual difference and identify every invoice within
          it.
  Step 6  For each residual invoice, test the conditions for credit and the
          position on payment to the supplier.
  Step 7  Confirm separately that no residual credit is otherwise restricted.

EVIDENCE TO ASSEMBLE
Purchase register, monthly returns, electronic credit ledger extract, bills of
entry, reverse charge working, sample invoices, transport and receipt evidence,
bank statements evidencing payment, and the reconciliation statement itself.

WHEN TO CONCEDE
Concede only the residual amount for which a condition genuinely fails, and
deal with interest and penalty separately and without prejudice. Record the
basis of the concession in the working papers.

CAUTION
This checklist records the firm's working approach. It cites no statutory
provision and no authority, and it must not be relied upon as a statement of
law. Verify the position applicable to the period under examination.
""",
    ),
]


def _wrap_lines(text: str, width: int = 96) -> List[str]:
    """
    Word-wrap body text for fixed-width PDF output.

    Leading indentation is preserved so numbered lists and aligned figure
    columns keep their shape, and no line is ever cut mid-word.
    """
    import textwrap

    out: List[str] = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            out.append("")
            continue
        if len(line) <= width:
            out.append(line)
            continue
        indent = " " * (len(line) - len(line.lstrip()))
        # A continuation of a numbered or bulleted item is indented further.
        hanging = indent + ("  " if line.lstrip()[:1].isdigit()
                            or line.lstrip().startswith(("-", "(")) else "")
        out.extend(textwrap.wrap(line, width=width, initial_indent=indent,
                                 subsequent_indent=hanging,
                                 break_long_words=False,
                                 break_on_hyphens=False) or [""])
    return out


def _write_pdf(path: Path, title: str, body: str) -> bool:
    """Render one demonstration note to PDF, banner on every page."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas as pdf_canvas
    except ImportError:
        return False

    try:
        page_width, page_height = A4
        left, bottom = 18 * mm, 22 * mm
        top = page_height - 20 * mm
        line_height = 4.4 * mm

        pdf = pdf_canvas.Canvas(str(path), pagesize=A4)
        pdf.setTitle(title)
        pdf.setAuthor(f"{config.APP_NAME} - demonstration knowledge base")

        def page_furniture() -> float:
            pdf.setFont("Helvetica-Bold", 7)
            pdf.setFillColorRGB(0.69, 0.16, 0.16)
            pdf.drawCentredString(page_width / 2, 13 * mm, FOOTER)
            pdf.setFont("Helvetica", 6.5)
            pdf.setFillColorRGB(0.37, 0.43, 0.49)
            pdf.drawCentredString(page_width / 2, 9 * mm, config.APP_BRANDING)
            pdf.setFillColorRGB(0, 0, 0)
            return top

        y = page_furniture()
        for line in _wrap_lines(body):
            if y < bottom:
                pdf.showPage()
                y = page_furniture()
            bold = line.isupper() and len(line.strip()) > 3
            pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 9)
            pdf.drawString(left, y, line)
            y -= line_height
        pdf.save()
        return True
    except Exception as exc:  # noqa: BLE001
        log.exception("Demo knowledge-base PDF failed: %s", exc)
        return False


def create_demo_documents(overwrite: bool = False) -> Tuple[int, List[str]]:
    """Write the demonstration notes into the knowledge base folders."""
    written = 0
    messages: List[str] = []
    for category, filename, title, body in DOCUMENTS:
        folder = config.KNOWLEDGE_BASE_DIR / category
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / filename
        if path.exists() and not overwrite:
            continue
        if _write_pdf(path, title, body):
            written += 1
        else:
            messages.append(f"Could not create {filename} (ReportLab is required).")
    return written, messages


def load_demo_knowledge_base(overwrite: bool = False) -> Tuple[int, int, List[str]]:
    """
    Create, register and index the demonstration notes.

    Returns ``(documents_registered, chunks_indexed, messages)``.
    """
    from database import database as db
    from services import rag_service

    written, messages = create_demo_documents(overwrite)
    registered = 0
    for category, filename, title, _body in DOCUMENTS:
        path = config.KNOWLEDGE_BASE_DIR / category / filename
        if not path.exists():
            continue
        ok, message, document_id = rag_service.add_document(
            path, category,
            notes="Demonstration material - verify against current GST law.",
            copy_file=False, is_demo=True)
        if ok and document_id:
            registered += 1
            document = db.get_knowledge_document(document_id)
            if document and not document.get("indexed"):
                rag_service.index_document(document)
        elif not ok:
            messages.append(message)

    rag_service._invalidate_cache()  # noqa: SLF001 - refresh the search cache
    status = rag_service.knowledge_base_status()
    if written:
        messages.insert(0, f"{written} demonstration document(s) created.")
    log.info("Demo knowledge base ready: %d document(s), %d chunk(s)",
             registered, status["chunks"])
    return registered, status["chunks"], messages
