"""
services.issue_service
======================
Issue-level AI analysis.

The output deliberately keeps three things apart:

* **Facts from Notice**   - what the notice itself says (from the extraction)
* **AI Analysis**         - what the model suggests should be checked
* **Professional Conclusion** - reserved for the Chartered Accountant

Nothing the model produces is presented as an established fact or as a
concluded legal position.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from database import database as db
from services import ai_service, mock_data
from utils.formatters import as_list, bullet_list, format_currency, join_list, loads
from utils.helpers import load_prompt
from utils.logger import get_logger

log = get_logger(__name__)

# Section headings used when the analysis is rendered as text
SECTION_TITLES = [
    ("issue_explanation", "Explanation of the Issue"),
    ("factual_checks_required", "Factual Checks Required"),
    ("reconciliations_required", "Reconciliations Required"),
    ("documents_needed", "Documents Needed"),
    ("legal_questions", "Legal Questions Arising"),
    ("possible_taxpayer_positions", "Possible Taxpayer Positions"),
    ("assumptions_made", "Assumptions Made by the AI"),
    ("information_gaps", "Information Gaps"),
    ("risk_assessment", "Risk Assessment"),
    ("risk_reasoning", "Reason for the Risk Assessment"),
    ("confidence", "Confidence"),
    ("professional_note", "For the Chartered Accountant to Determine"),
]


@dataclass
class IssueAnalysisResult:
    """Outcome of one issue-level AI analysis."""

    ok: bool = False
    data: Dict[str, Any] = field(default_factory=dict)
    text: str = ""
    error: str = ""
    error_kind: str = ""
    demo: bool = False
    source: str = ""
    elapsed: float = 0.0


def build_case_context(case: Optional[Dict[str, Any]]) -> str:
    """A compact case summary for the prompt (keeps token usage low)."""
    if not case:
        return "Not supplied."
    parts = [
        f"Taxpayer: {case.get('client_name', '')}",
        f"GSTIN: {case.get('client_gstin', '')}",
        f"Notice type: {case.get('notice_type', '')}",
        f"Notice number: {case.get('notice_number', '')}",
        f"Financial year: {case.get('financial_year', '')}",
        f"Tax period: {case.get('tax_period', '')}",
        f"Sections invoked in the notice: {case.get('sections', '')}",
        f"Officer / authority: {case.get('officer', '')}",
    ]
    summary = case.get("summary")
    if summary:
        parts.append(f"Summary of the notice: {summary}")
    return "\n".join(p for p in parts if not p.endswith(": "))


def build_prompt(issue: Dict[str, Any], case: Optional[Dict[str, Any]]) -> str:
    """Render the issue-analysis prompt."""
    template = load_prompt("issue_analysis")
    if not template:
        from services.prompt_setup import ISSUE_ANALYSIS

        template = ISSUE_ANALYSIS
    safety = load_prompt("_safety_rules")

    values = {
        "safety": safety,
        "case_context": build_case_context(case),
        "issue_no": issue.get("issue_no", ""),
        "issue_title": issue.get("title") or issue.get("issue_title", ""),
        "allegation": issue.get("allegation") or issue.get("department_allegation", ""),
        "amount": format_currency(issue.get("amount")),
        "sections": join_list(issue.get("sections"), fallback="Not stated"),
        "facts_identified": bullet_list(_facts(issue, "facts_identified")),
        "facts_missing": bullet_list(_facts(issue, "facts_missing")),
    }
    try:
        return template.format(**values)
    except (KeyError, IndexError, ValueError) as exc:
        log.error("issue_analysis prompt template is malformed: %s", exc)
        return (f"{safety}\n\nAnalyse this GST issue and return JSON only.\n\n"
                f"{values['issue_title']}\n{values['allegation']}")


def _facts(issue: Dict[str, Any], key: str) -> List[str]:
    """Facts are stored as a JSON list but may arrive as a plain list."""
    value = issue.get(key)
    if isinstance(value, (list, tuple)):
        return [str(v) for v in value]
    parsed = loads(value, None)
    if isinstance(parsed, list):
        return [str(v) for v in parsed]
    return as_list(value)


def analyse_issue(issue: Dict[str, Any], case: Optional[Dict[str, Any]] = None,
                  demo_mode: bool = True) -> IssueAnalysisResult:
    """Run the issue-level AI analysis (call this on a worker thread)."""
    result = IssueAnalysisResult(demo=demo_mode)
    if not issue:
        result.error = "No issue was selected."
        return result

    response = ai_service.generate(
        build_prompt(issue, case),
        demo_mode=demo_mode,
        demo_payload=mock_data.issue_analysis(issue),
        expect_json=True,
        temperature=0.2,
        label="Issue analysis",
    )

    result.demo = response.demo
    result.source = response.source_label
    result.elapsed = response.elapsed

    if not response.ok:
        result.error = response.friendly_error
        result.error_kind = response.error_kind
        return result

    data = response.data if isinstance(response.data, dict) else {}
    result.ok = True
    result.data = data
    result.text = render_analysis(data)
    return result


def render_analysis(data: Dict[str, Any]) -> str:
    """Format the AI analysis as readable text for the screen and exports."""
    if not data:
        return "No analysis available."

    lines: List[str] = []
    for key, heading in SECTION_TITLES:
        value = data.get(key)
        if value in (None, "", [], {}):
            continue
        lines.append(heading.upper())
        if key == "possible_taxpayer_positions" and isinstance(value, list):
            for index, item in enumerate(value, start=1):
                if not isinstance(item, dict):
                    lines.append(f"  {index}. {item}")
                    continue
                lines.append(f"  {index}. {item.get('position', '')}")
                if item.get("depends_on"):
                    lines.append(f"       Depends on : {item['depends_on']}")
                if item.get("strength"):
                    lines.append(f"       Strength   : {item['strength']}")
        elif isinstance(value, list):
            for item in value:
                lines.append(f"  - {item}")
        else:
            lines.append(f"  {value}")
        lines.append("")

    lines.append("-" * 74)
    lines.append("This is AI-assisted analysis for professional use. It is not a legal")
    lines.append("opinion and it is not a conclusion. Every factual check, statutory")
    lines.append("reference and risk assessment must be independently verified by the")
    lines.append("Chartered Accountant before it is relied upon.")
    return "\n".join(lines)


def save_issue_analysis(issue_id: int, result: IssueAnalysisResult,
                        case_id: Optional[int] = None) -> bool:
    """Persist the analysis text and the model's risk view against the issue."""
    if not result.ok:
        return False
    payload: Dict[str, Any] = {"ai_analysis": result.text}

    risk = (result.data.get("risk_assessment") or "").strip()
    if risk in {"High", "Medium", "Low", "Review Required"}:
        payload["risk"] = risk
    if result.data.get("risk_reasoning"):
        payload["risk_reason"] = result.data["risk_reasoning"]
    confidence = (result.data.get("confidence") or "").strip()
    if confidence in {"High", "Medium", "Low"}:
        payload["confidence"] = confidence

    db.update_issue(issue_id, payload)
    db.log_activity("Issue analysed", f"Issue #{issue_id}; source: {result.source}",
                    case_id=case_id)
    return True


def documents_from_analysis(data: Dict[str, Any]) -> List[Dict[str, str]]:
    """Turn the 'documents_needed' list into requirement rows."""
    return [
        {"document_name": str(name), "purpose": "Identified during issue analysis",
         "requirement_type": "Mandatory", "remarks": ""}
        for name in (data.get("documents_needed") or [])
        if str(name).strip()
    ]
