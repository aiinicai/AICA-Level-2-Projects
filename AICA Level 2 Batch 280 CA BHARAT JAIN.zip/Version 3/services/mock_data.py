"""
services.mock_data
==================
Sample AI output used by **Demo / Mock AI Mode**.

When Demo Mode is on the Gemini API is never called; these payloads are
returned instead so the complete workflow can be demonstrated without an
internet connection or API key.

The samples are lightly adapted to whatever notice text is supplied
(GSTIN, notice number and dates are picked up with regular expressions
where they are present), which keeps the demonstration convincing while
remaining entirely offline.
"""

from __future__ import annotations

import re
from datetime import date, timedelta
from typing import Any, Dict, List, Optional

from utils.formatters import format_currency
from utils.validators import parse_date

GSTIN_PATTERN = re.compile(r"\b[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][0-9A-Z]Z[0-9A-Z]\b")
NOTICE_NO_PATTERN = re.compile(
    r"(?:Reference|Ref|Notice)\s*(?:No\.?|Number)?\s*[:\-]?\s*"
    r"([A-Z0-9][A-Z0-9/\-]{6,40})", re.IGNORECASE)
DATE_PATTERN = re.compile(r"\b(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})\b")
FY_PATTERN = re.compile(r"\b(20\d{2})\s*-\s*(\d{2})\b")


def _default_dates() -> Dict[str, str]:
    today = date.today()
    notice_day = today - timedelta(days=12)
    return {
        "notice_date": notice_day.strftime("%d-%m-%Y"),
        "reply_due_date": (notice_day + timedelta(days=30)).strftime("%d-%m-%Y"),
    }


# ---------------------------------------------------------------------------
# Notice analysis
# ---------------------------------------------------------------------------
def _demo_scenario_analysis(case: Dict[str, Any], notice_text: str
                            ) -> Optional[Dict[str, Any]]:
    """Return the predefined analysis for a demonstration case, if it is one."""
    try:
        from services import demo_scenarios
    except ImportError:            # pragma: no cover - demo module is optional
        return None

    scenario = demo_scenarios.find_scenario(case=case)
    if scenario is None and notice_text:
        for number, candidate in demo_scenarios.SCENARIOS_BY_NOTICE_NUMBER.items():
            if number in notice_text:
                scenario = candidate
                break
    if scenario is None:
        return None
    return demo_scenarios.scenario_analysis(
        scenario,
        notice_date=_display_date(case.get("notice_date")),
        due_date=_display_date(case.get("due_date")),
    )


def notice_analysis(notice_text: str = "", case: Optional[Dict[str, Any]] = None
                    ) -> Dict[str, Any]:
    """
    Sample structured notice analysis.

    When the case is one of the demonstration matters, the analysis defined
    for that scenario is returned, so the figures the AI "extracts" match
    exactly what is printed on that case's sample notice. Any other case
    falls back to the generic three-allegation example below.
    """
    case = case or {}

    scenario_payload = _demo_scenario_analysis(case, notice_text)
    if scenario_payload is not None:
        return scenario_payload

    text = notice_text or ""
    dates = _default_dates()

    found_dates = DATE_PATTERN.findall(text)
    notice_date = (found_dates[0] if found_dates else "") or \
        _display_date(case.get("notice_date")) or dates["notice_date"]
    due_date = (found_dates[1] if len(found_dates) > 1 else "") or \
        _display_date(case.get("due_date")) or dates["reply_due_date"]

    gstin_match = GSTIN_PATTERN.search(text)
    gstin = gstin_match.group(0) if gstin_match else (case.get("client_gstin") or "")

    number_match = NOTICE_NO_PATTERN.search(text)
    notice_number = (number_match.group(1) if number_match
                     else case.get("notice_number") or "ZD2703240001234")

    fy_match = FY_PATTERN.search(text)
    financial_year = (f"{fy_match.group(1)}-{fy_match.group(2)}" if fy_match
                      else case.get("financial_year") or "2022-23")

    taxpayer = case.get("client_name") or "ABC Private Limited"

    return {
        "taxpayer_name": taxpayer,
        "gstin": gstin,
        "notice_type": case.get("notice_type") or "DRC-01",
        "notice_number": notice_number,
        "financial_year": financial_year,
        "tax_period": case.get("tax_period") or f"April {financial_year[:4]} to "
                                                f"March 20{financial_year[5:]}",
        "notice_date": notice_date,
        "reply_due_date": due_date,
        "sections_invoked": ["Section 73", "Section 16(2)(c)", "Section 50",
                             "Section 122", "Section 9(3)"],
        "rules_invoked": ["Rule 36(4)", "Rule 142(1)(a)"],
        "officer_name": "Assistant Commissioner (State Tax)",
        "designation": "Proper Officer",
        "jurisdiction": case.get("jurisdiction") or "Ward 204, Division IV",
        "summary": (
            "The proper officer has issued a show cause notice under Section 73 "
            f"for the financial year {financial_year} proposing a demand of tax "
            "together with interest and penalty. Three distinct allegations have "
            "been raised: (i) excess input tax credit availed as compared with "
            "GSTR-2A/2B, (ii) input tax credit availed on invoices of suppliers "
            "whose registration was subsequently cancelled, and (iii) short "
            "payment of tax under reverse charge on specified services. The "
            "taxpayer has been called upon to show cause why the proposed demand "
            "should not be confirmed."
        ),
        "cgst": 1240000,
        "sgst": 1240000,
        "igst": 685000,
        "cess": 0,
        "interest": 1058400,
        "penalty": 316500,
        "other_amount": 0,
        "issues": [
            {
                "issue_no": 1,
                "issue_title": "Excess ITC availed in GSTR-3B vis-a-vis GSTR-2A/2B",
                "department_allegation": (
                    "Input tax credit availed in GSTR-3B exceeds the credit "
                    "reflected in GSTR-2A/2B for the period. The difference is "
                    "proposed to be disallowed under Section 73 read with Rule 36(4)."
                ),
                "amount": 1685000,
                "sections": ["Section 73", "Section 16", "Rule 36(4)"],
                "facts_identified": [
                    "ITC availed in GSTR-3B for the year as per the notice.",
                    "ITC reflected in GSTR-2A/2B as per the department's working.",
                    "The difference has been computed on an annual basis.",
                ],
                "facts_missing": [
                    "Month-wise reconciliation between GSTR-3B, GSTR-2A and GSTR-2B.",
                    "Details of credit relating to invoices reported late by suppliers.",
                    "Whether opening credit of the earlier year has been considered.",
                    "Copies of the underlying purchase invoices.",
                ],
                "initial_risk": "High",
                "reason_for_risk": (
                    "The amount involved is the largest component of the demand and "
                    "the department has worked out the difference on an annual basis "
                    "without a month-wise reconciliation."
                ),
                "confidence": "High",
            },
            {
                "issue_no": 2,
                "issue_title": "ITC availed from suppliers whose registration was "
                               "subsequently cancelled",
                "department_allegation": (
                    "Credit availed on inward supplies from suppliers whose "
                    "registration was cancelled with retrospective effect is "
                    "proposed to be denied on the ground that the condition in "
                    "Section 16(2)(c) is not satisfied."
                ),
                "amount": 795000,
                "sections": ["Section 16(2)(c)", "Section 73"],
                "facts_identified": [
                    "List of suppliers whose registration was cancelled.",
                    "Invoice-wise credit attributed to those suppliers.",
                    "The registrations were cancelled after the supplies were made.",
                ],
                "facts_missing": [
                    "Whether the supplier had filed GSTR-1 and GSTR-3B for the period.",
                    "Proof of movement of goods (e-way bills, lorry receipts, GRNs).",
                    "Proof of payment to the suppliers through banking channels.",
                    "Whether tax was actually paid to the Government by the supplier.",
                ],
                "initial_risk": "Medium",
                "reason_for_risk": (
                    "The outcome depends substantially on documentary evidence of "
                    "genuineness of the transaction and on the legal position "
                    "regarding a bona fide recipient."
                ),
                "confidence": "Medium",
            },
            {
                "issue_no": 3,
                "issue_title": "Short payment of tax under reverse charge mechanism",
                "department_allegation": (
                    "Tax under reverse charge on specified services, including "
                    "legal services and goods transport agency services, has not "
                    "been discharged in full for the period."
                ),
                "amount": 685000,
                "sections": ["Section 9(3)", "Section 73", "Section 50"],
                "facts_identified": [
                    "Expense heads identified by the department from the "
                    "financial statements.",
                    "RCM liability declared in GSTR-3B for the period.",
                ],
                "facts_missing": [
                    "Ledger-wise break-up of the expenses considered by the officer.",
                    "Whether the service providers were registered persons.",
                    "Whether any of the expenses are exempt or outside RCM.",
                    "Whether the tax, if payable, would be available as credit "
                    "(revenue neutrality).",
                ],
                "initial_risk": "Medium",
                "reason_for_risk": (
                    "A part of the liability may be revenue neutral where credit is "
                    "available, but interest exposure may still arise."
                ),
                "confidence": "Medium",
            },
        ],
    }


def _display_date(value) -> str:
    parsed = parse_date(value) if value else None
    return parsed.strftime("%d-%m-%Y") if parsed else ""


# ---------------------------------------------------------------------------
# Issue analysis
# ---------------------------------------------------------------------------
def issue_analysis(issue: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Sample deep-dive analysis for one issue."""
    issue = issue or {}
    title = (issue.get("title") or "").lower()

    if "cancel" in title or "16(2)(c)" in title:
        return _issue_analysis_supplier_cancelled()
    if "reverse charge" in title or "rcm" in title:
        return _issue_analysis_rcm()
    return _issue_analysis_itc_mismatch()


def _issue_analysis_itc_mismatch() -> Dict[str, Any]:
    return {
        "issue_explanation": (
            "The department has compared the total input tax credit availed in "
            "GSTR-3B for the year with the credit appearing in GSTR-2A/2B and has "
            "treated the entire difference as excess credit. This is an annual, "
            "aggregate comparison; it does not by itself establish that credit was "
            "wrongly availed, because timing differences, credit of the preceding "
            "year, import IGST and reverse charge credit commonly explain part of "
            "the difference."
        ),
        "factual_checks_required": [
            "Verify the ITC figures used by the department against the filed returns.",
            "Identify credit carried forward from the preceding financial year.",
            "Identify credit availed in the succeeding year for invoices of this year.",
            "Segregate import IGST credit and RCM credit, which do not appear in GSTR-2A.",
            "Identify invoices uploaded late by suppliers in a subsequent period.",
        ],
        "reconciliations_required": [
            "Month-wise GSTR-3B vs GSTR-2A vs GSTR-2B reconciliation for the year.",
            "Purchase register vs GSTR-2B reconciliation, invoice-wise.",
            "Reconciliation of credit as per books with credit as per the "
            "electronic credit ledger.",
        ],
        "documents_needed": [
            "Monthly GSTR-3B and GSTR-2B for the entire period",
            "Annual GSTR-2A download",
            "Purchase register with GSTIN-wise and invoice-wise details",
            "Electronic credit ledger extract",
            "Copies of high-value purchase invoices",
        ],
        "legal_questions": [
            "Whether an aggregate annual comparison can sustain a demand without "
            "invoice-level verification.",
            "The effect of Rule 36(4) as it stood during the relevant period.",
            "Whether credit relating to invoices reported by suppliers in a later "
            "period can be denied for that reason alone.",
        ],
        "possible_taxpayer_positions": [
            {
                "position": "The difference is explained by timing and by credits "
                            "that do not appear in GSTR-2A (import IGST, RCM).",
                "depends_on": "A completed month-wise reconciliation supported by "
                              "the purchase register.",
                "strength": "Strong",
            },
            {
                "position": "Credit cannot be denied merely on a mismatch where the "
                            "underlying conditions of Section 16 are satisfied.",
                "depends_on": "Availability of tax invoices, receipt of goods or "
                              "services and payment to the supplier.",
                "strength": "Moderate",
            },
        ],
        "assumptions_made": [
            "That the taxpayer maintains a complete purchase register for the period.",
            "That the department's figures are drawn from the filed returns.",
        ],
        "information_gaps": [
            "The department's working sheet, if any, has not been supplied.",
            "Month-wise break-up of the alleged difference is not in the notice.",
        ],
        "risk_assessment": "High",
        "risk_reasoning": (
            "The quantum is material and the demand will stand unless a complete "
            "reconciliation is produced within the reply period."
        ),
        "confidence": "Medium",
        "professional_note": (
            "The reconciliation must be prepared and verified by the engagement team "
            "before any position is asserted in the reply. The legal position under "
            "Rule 36(4) varied across periods and must be checked against the "
            "specific months in question."
        ),
    }


def _issue_analysis_supplier_cancelled() -> Dict[str, Any]:
    return {
        "issue_explanation": (
            "Credit has been proposed to be denied because certain suppliers' "
            "registrations were cancelled, in some cases with retrospective effect. "
            "The department relies on Section 16(2)(c), which requires that tax "
            "charged in respect of the supply has actually been paid to the "
            "Government. The recipient's position depends heavily on evidence that "
            "the transactions were genuine and that the supplier was registered and "
            "compliant at the time of supply."
        ),
        "factual_checks_required": [
            "Confirm the date of cancellation of each supplier's registration.",
            "Confirm whether the supply predates the cancellation.",
            "Confirm whether the supplier filed GSTR-1 and GSTR-3B for the period.",
            "Confirm whether the invoices appear in the taxpayer's GSTR-2A/2B.",
        ],
        "reconciliations_required": [
            "Supplier-wise reconciliation of credit availed with GSTR-2A entries.",
            "Reconciliation of payments made to each supplier with the purchase ledger.",
        ],
        "documents_needed": [
            "Tax invoices of the concerned suppliers",
            "E-way bills and transport documents",
            "Goods receipt notes / gate entry records",
            "Bank statements evidencing payment within 180 days",
            "Supplier ledger accounts",
            "Screenshots of supplier registration status at the time of supply",
        ],
        "legal_questions": [
            "Whether a bona fide recipient can be denied credit for the supplier's "
            "subsequent default or cancellation.",
            "The evidentiary burden on the recipient under Section 16(2)(c).",
            "The effect of retrospective cancellation on supplies already made.",
        ],
        "possible_taxpayer_positions": [
            {
                "position": "The supplies were genuine, the supplier was registered "
                            "on the date of supply, and payment was made through "
                            "banking channels.",
                "depends_on": "Complete documentary evidence for each transaction.",
                "strength": "Strong",
            },
            {
                "position": "Recovery should first be attempted from the defaulting "
                            "supplier before denying credit to the recipient.",
                "depends_on": "[LEGAL SOURCE TO BE VERIFIED] - requires a supporting "
                              "authority from the knowledge base.",
                "strength": "Cannot assess without facts",
            },
        ],
        "assumptions_made": [
            "That the taxpayer can obtain evidence of the supplier's status at the "
            "time of supply.",
        ],
        "information_gaps": [
            "The notice does not state the dates of cancellation supplier-wise.",
            "It is not stated whether the suppliers filed returns for the period.",
        ],
        "risk_assessment": "Medium",
        "risk_reasoning": (
            "Outcome is evidence-driven; strong documentation materially improves "
            "the position, but the legal question is contested."
        ),
        "confidence": "Medium",
        "professional_note": (
            "Any judicial authority relied upon must be verified from the firm's "
            "knowledge base or a subscription database before it is cited in the "
            "reply."
        ),
    }


def _issue_analysis_rcm() -> Dict[str, Any]:
    return {
        "issue_explanation": (
            "The department has identified expense heads from the financial "
            "statements on which, in its view, tax was payable under reverse charge "
            "and has proposed a demand for the shortfall. The correctness of the "
            "demand depends on whether each expense actually attracts reverse "
            "charge and on the registration status of the service provider."
        ),
        "factual_checks_required": [
            "Obtain the ledger-wise break-up of each expense head considered.",
            "Determine whether each supplier was registered or unregistered.",
            "Identify amounts that are exempt or not covered by a reverse charge "
            "notification.",
            "Verify RCM liability already discharged in GSTR-3B.",
        ],
        "reconciliations_required": [
            "Expense ledger vs RCM liability declared, head-wise and month-wise.",
            "RCM paid vs RCM credit availed, to assess revenue neutrality.",
        ],
        "documents_needed": [
            "Ledger accounts of the expense heads identified",
            "Sample vendor invoices for each head",
            "GSTR-3B RCM working for the year",
            "Registration status of the concerned service providers",
        ],
        "legal_questions": [
            "Whether each identified expense falls within a reverse charge "
            "notification for the relevant period.",
            "Whether interest is payable where the liability would have been "
            "available as credit in the same period.",
        ],
        "possible_taxpayer_positions": [
            {
                "position": "A part of the identified expenses does not attract "
                            "reverse charge at all.",
                "depends_on": "Head-wise examination of the ledgers.",
                "strength": "Moderate",
            },
            {
                "position": "Where tax is payable and creditable in the same period, "
                            "the exercise is revenue neutral.",
                "depends_on": "Whether the taxpayer was eligible for full credit.",
                "strength": "Moderate",
            },
        ],
        "assumptions_made": [
            "That the taxpayer is eligible for full input tax credit.",
        ],
        "information_gaps": [
            "The notice does not disclose the ledger-wise working relied upon.",
        ],
        "risk_assessment": "Medium",
        "risk_reasoning": (
            "Tax exposure may reduce substantially on examination, but interest "
            "exposure is likely to remain."
        ),
        "confidence": "Medium",
        "professional_note": (
            "Revenue neutrality is a factual submission and must be supported by "
            "the credit position for the relevant months."
        ),
    }


# ---------------------------------------------------------------------------
# Document requirements
# ---------------------------------------------------------------------------
def document_requirements(issue: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Sample client document requirement checklist."""
    issue = issue or {}
    title = (issue.get("title") or "").lower()

    common: List[Dict[str, str]] = [
        {"document_name": "Copy of the GST notice with all annexures",
         "purpose": "To confirm the exact allegations, periods and figures relied upon",
         "requirement_type": "Mandatory", "remarks": "Including the departmental working sheet"},
        {"document_name": "GSTR-3B for each month of the period",
         "purpose": "To establish the credit availed and tax paid as returned",
         "requirement_type": "Mandatory", "remarks": "PDF downloads from the portal"},
        {"document_name": "GSTR-1 for each month of the period",
         "purpose": "To establish outward supplies declared",
         "requirement_type": "Mandatory", "remarks": ""},
        {"document_name": "Electronic credit ledger and cash ledger extracts",
         "purpose": "To establish the credit and cash position for the period",
         "requirement_type": "Mandatory", "remarks": "For the full financial year"},
        {"document_name": "Audited financial statements and trial balance",
         "purpose": "To reconcile turnover and expenses with the returns",
         "requirement_type": "Mandatory", "remarks": ""},
        {"document_name": "Authorisation letter for the authorised representative",
         "purpose": "To enable appearance and filing of the reply",
         "requirement_type": "Mandatory", "remarks": "On the taxpayer's letterhead"},
    ]

    if "reverse charge" in title or "rcm" in title:
        specific = [
            {"document_name": "Ledger accounts of legal, GTA, security and other "
                              "RCM-liable expense heads",
             "purpose": "To identify which expenses actually attract reverse charge",
             "requirement_type": "Mandatory", "remarks": "For the full period"},
            {"document_name": "Sample vendor invoices for each expense head",
             "purpose": "To determine the registration status and nature of supply",
             "requirement_type": "Mandatory", "remarks": "At least five per head"},
            {"document_name": "RCM working / computation prepared for GSTR-3B",
             "purpose": "To establish the liability already discharged",
             "requirement_type": "Mandatory", "remarks": ""},
            {"document_name": "Confirmation of registration status of service providers",
             "purpose": "Reverse charge applicability depends on the supplier's status",
             "requirement_type": "Conditional",
             "remarks": "Where the department alleges supplies from unregistered persons"},
        ]
    elif "cancel" in title or "16(2)(c)" in title:
        specific = [
            {"document_name": "Tax invoices of the suppliers named in the notice",
             "purpose": "To establish possession of a valid tax invoice under Section 16(2)(a)",
             "requirement_type": "Mandatory", "remarks": "Invoice-wise for each supplier"},
            {"document_name": "E-way bills for the concerned inward supplies",
             "purpose": "To evidence movement of goods",
             "requirement_type": "Conditional", "remarks": "Where the supply is of goods"},
            {"document_name": "Goods receipt notes / gate entry / weighbridge slips",
             "purpose": "To evidence actual receipt of goods under Section 16(2)(b)",
             "requirement_type": "Mandatory", "remarks": ""},
            {"document_name": "Bank statements evidencing payment to the suppliers",
             "purpose": "To evidence payment of consideration within 180 days",
             "requirement_type": "Mandatory", "remarks": "Highlight the relevant entries"},
            {"document_name": "Supplier ledger accounts",
             "purpose": "To establish the transaction trail",
             "requirement_type": "Mandatory", "remarks": ""},
            {"document_name": "Evidence of the supplier's registration status on the "
                              "date of supply",
             "purpose": "To establish that the supplier was registered when supplies were made",
             "requirement_type": "Mandatory", "remarks": "Portal search screenshots"},
            {"document_name": "Supplier confirmation of tax payment, where obtainable",
             "purpose": "To address the condition in Section 16(2)(c)",
             "requirement_type": "Conditional",
             "remarks": "Only where the supplier is contactable"},
        ]
    else:
        specific = [
            {"document_name": "Purchase register for the period (invoice-wise, GSTIN-wise)",
             "purpose": "Base record for the reconciliation of credit availed",
             "requirement_type": "Mandatory", "remarks": "In Excel format"},
            {"document_name": "GSTR-2A (annual) and GSTR-2B (monthly) downloads",
             "purpose": "To reconcile credit available as per the portal",
             "requirement_type": "Mandatory", "remarks": ""},
            {"document_name": "Month-wise ITC reconciliation working",
             "purpose": "To explain the difference alleged by the department",
             "requirement_type": "Mandatory", "remarks": "To be prepared and verified"},
            {"document_name": "Copies of purchase invoices for the differential credit",
             "purpose": "To establish the conditions of Section 16(2)",
             "requirement_type": "Mandatory", "remarks": "At least for high-value items"},
            {"document_name": "Details of import IGST credit and RCM credit availed",
             "purpose": "These do not appear in GSTR-2A and commonly explain differences",
             "requirement_type": "Conditional", "remarks": "Where applicable"},
            {"document_name": "Bills of entry for imports",
             "purpose": "To support import IGST credit",
             "requirement_type": "Conditional", "remarks": "Where imports were made"},
            {"document_name": "Vendor ledgers and payment proof",
             "purpose": "To establish payment of consideration within 180 days",
             "requirement_type": "Mandatory", "remarks": ""},
        ]

    return {
        "checklist": specific + common,
        "information_to_confirm": [
            "Whether any reply or partial submission has already been filed.",
            "Whether a personal hearing date has been fixed.",
            "Whether any amount has already been paid under DRC-03 for these issues.",
            "Whether the same issues are pending for any other financial year.",
            "The name and designation of the authorised signatory for the reply.",
        ],
        "reconciliations_to_prepare": [
            "Month-wise GSTR-3B vs GSTR-2A vs GSTR-2B reconciliation.",
            "Books vs returns reconciliation of outward supplies and tax paid.",
            "Expense-head-wise reverse charge liability working.",
        ],
        "covering_note": (
            "We have received a notice under GST for the period in question. In order "
            "to prepare a comprehensive reply within the statutory time limit, we "
            "request the documents and information listed in the attached checklist. "
            "Kindly provide these at the earliest, and in any event within seven days, "
            "so that adequate time remains for review and filing. Where any item is "
            "not applicable, kindly confirm that position in writing."
        ),
    }


# ---------------------------------------------------------------------------
# Legal research
# ---------------------------------------------------------------------------
def legal_research(question: str = "", sources_available: bool = False) -> Dict[str, Any]:
    """
    Sample research answer.

    When no knowledge-base source was retrieved the sample demonstrates the
    required behaviour: it declines to cite anything.
    """
    if not sources_available:
        return {
            "short_answer": (
                "No sufficiently relevant source was located in the current local "
                "knowledge base. A source-grounded answer cannot be given for this "
                "question until the relevant statutory material, circulars or "
                "judgments are added to the knowledge base."
            ),
            "statutory_provisions": [],
            "rules": [],
            "circulars_notifications": [],
            "judicial_material": [],
            "analysis": (
                "This application answers research questions only from documents "
                "present in the local knowledge base, so that every citation can be "
                "traced to a source the firm holds. Nothing relevant was retrieved "
                "for this question.\n\n"
                "To obtain a grounded answer, add the relevant material through "
                "Knowledge Base > Add PDF - for example the bare Act, the relevant "
                "rules, departmental circulars, or the firm's internal research notes "
                "- and run the search again."
            ),
            "applicability_to_present_case": (
                "Cannot be assessed without source material. [LEGAL SOURCE TO BE VERIFIED]"
            ),
            "facts_requiring_verification": [
                "The exact period involved, as the legal position has changed over time.",
                "Whether the department has relied on any specific circular.",
            ],
            "limitations": (
                "No citation has been given because none could be traced to a "
                "document in the local knowledge base."
            ),
            "sources_used": [],
            "confidence": "Low",
        }

    return {
        "short_answer": (
            "On the material retrieved from the local knowledge base, the conditions "
            "for availing input tax credit are those set out in the provision "
            "reproduced at [S1], and the recipient must be in a position to "
            "demonstrate that each condition is satisfied. The retrieved material "
            "does not conclusively resolve the position of a bona fide recipient "
            "where the supplier subsequently defaults, and that point requires "
            "further authority. [LEGAL SOURCE TO BE VERIFIED]"
        ),
        "statutory_provisions": [
            {"provision": "Conditions for availing input tax credit",
             "effect": "Credit is available only where the recipient holds a tax "
                       "invoice, has received the goods or services, the tax has been "
                       "paid to the Government and the return has been furnished.",
             "source_ref": "S1"},
        ],
        "rules": [
            {"rule": "Rule referred to in the retrieved extract",
             "effect": "Prescribes the manner and restrictions applicable to the "
                       "credit claimed.",
             "source_ref": "S2"},
        ],
        "circulars_notifications": [],
        "judicial_material": [],
        "analysis": (
            "The retrieved extract at [S1] sets out the cumulative conditions for "
            "credit. Each condition is independent, and the burden of demonstrating "
            "compliance rests on the person claiming the credit.\n\n"
            "The extract at [S2] deals with the procedural restrictions applicable "
            "to the claim. Read together, the retrieved material supports the "
            "proposition that documentary evidence of the invoice, receipt and "
            "payment is central to the recipient's position.\n\n"
            "The retrieved sources do not address the specific situation where the "
            "supplier's registration is cancelled after the supply has been made. "
            "Any proposition on that point must be supported by authority that is "
            "not presently in the knowledge base. [LEGAL SOURCE TO BE VERIFIED]"
        ),
        "applicability_to_present_case": (
            "The taxpayer should be able to establish the first two conditions from "
            "its own records. The third condition, relating to payment of tax to the "
            "Government by the supplier, is not within the taxpayer's control and is "
            "the contested aspect of the allegation."
        ),
        "facts_requiring_verification": [
            "Whether the concerned suppliers filed their returns for the period.",
            "The precise date of cancellation of each supplier's registration.",
            "Whether payment to the suppliers was made within 180 days.",
        ],
        "limitations": (
            "This answer is limited to the extracts retrieved from the local "
            "knowledge base and does not reflect any material outside it."
        ),
        "sources_used": ["S1", "S2"],
        "confidence": "Medium",
    }


# ---------------------------------------------------------------------------
# Draft reply
# ---------------------------------------------------------------------------
def draft_reply(case: Optional[Dict[str, Any]] = None,
                issues: Optional[List[Dict[str, Any]]] = None,
                demand=None) -> str:
    """Sample issue-wise draft reply in GST litigation format."""
    case = case or {}
    issues = issues or []
    taxpayer = case.get("client_name") or "[CLIENT TO CONFIRM]"
    gstin = case.get("client_gstin") or "[CLIENT TO CONFIRM]"
    notice_type = case.get("notice_type") or "the notice"
    notice_number = case.get("notice_number") or "[CLIENT TO CONFIRM]"
    notice_date = _display_date(case.get("notice_date")) or "[CLIENT TO CONFIRM]"
    financial_year = case.get("financial_year") or "[CLIENT TO CONFIRM]"
    tax_period = case.get("tax_period") or "[CLIENT TO CONFIRM]"
    officer = case.get("officer") or "THE PROPER OFFICER"
    total = format_currency(demand.total_exposure) if demand is not None else "[AS PER NOTICE]"

    lines: List[str] = []
    add = lines.append

    add(f"BEFORE {officer.upper()}")
    add("")
    add("REPLY TO SHOW CAUSE NOTICE")
    add("=" * 78)
    add("")
    add("1.  TAXPAYER DETAILS")
    add(f"    Name of the taxpayer      : {taxpayer}")
    add(f"    GSTIN                     : {gstin}")
    add(f"    Financial Year            : {financial_year}")
    add(f"    Tax Period                : {tax_period}")
    add("    Principal Place of Business: [CLIENT TO CONFIRM]")
    add("")
    add("2.  SUBJECT")
    add(f"    Reply to {notice_type} bearing reference number {notice_number}")
    add(f"    dated {notice_date} - submissions on merits.")
    add("")
    add("3.  REFERENCE TO NOTICE")
    add(f"    This reply is filed in response to {notice_type} bearing reference")
    add(f"    number {notice_number} dated {notice_date}, whereby the taxpayer has")
    add("    been called upon to show cause as to why a demand aggregating to")
    add(f"    {total} should not be confirmed.")
    add("")
    add("4.  BACKGROUND")
    add(f"    {taxpayer} is engaged in [CLIENT TO CONFIRM] and is registered under")
    add(f"    the Goods and Services Tax law bearing GSTIN {gstin}. The taxpayer has")
    add("    filed its returns for the period in question and has maintained books")
    add("    of account in the ordinary course of business. [CLIENT TO CONFIRM]")
    add("")
    add("5.  PRELIMINARY SUBMISSIONS")
    add("    5.1  At the outset, the taxpayer denies each and every allegation made")
    add("         in the notice save to the extent expressly admitted herein.")
    add("    5.2  The submissions in this reply are made without prejudice to one")
    add("         another and to any further submissions that may become necessary")
    add("         upon receipt of the working sheets relied upon by the department.")
    add("    5.3  The taxpayer requests that the detailed working on the basis of")
    add("         which the demand has been computed be furnished, so that a")
    add("         complete reply may be filed on merits.")
    add("    5.4  The taxpayer requests an opportunity of personal hearing before")
    add("         any adverse order is passed.")
    add("")
    add("6.  FACTS OF THE CASE")
    add("    6.1  The taxpayer filed GSTR-1 and GSTR-3B for each tax period.")
    add("    6.2  Input tax credit was availed on the basis of tax invoices")
    add("         received from registered suppliers. [CLIENT TO CONFIRM]")
    add("    6.3  The books of account, purchase register and supporting records")
    add("         are available and can be produced for verification.")
    add("")
    add("7.  ISSUE-WISE SUBMISSIONS")
    add("")

    if not issues:
        add("    No issues have yet been recorded against this case. Run the notice")
        add("    analysis first so that issue-wise submissions can be prepared.")
        add("")
    for index, issue in enumerate(issues, start=1):
        title = issue.get("title") or f"Issue {index}"
        allegation = issue.get("allegation") or "[AS SET OUT IN THE NOTICE]"
        amount = issue.get("amount") or 0
        sections = issue.get("sections") or ""
        add(f"    ISSUE {index}: {title.upper()}")
        add(f"    Amount involved: {format_currency(amount)}")
        add("")
        add("    (a) Department's Allegation")
        for line in _wrap(allegation, 68):
            add(f"        {line}")
        add("")
        add("    (b) Taxpayer's Submission")
        add("        The allegation is denied. The taxpayer submits that the credit")
        add("        availed / tax paid is in accordance with law and that the")
        add("        difference alleged in the notice arises from the manner in")
        add("        which the comparison has been made, and not from any")
        add("        contravention. A detailed reconciliation is being placed on")
        add("        record as an annexure. [CLIENT TO CONFIRM]")
        add("")
        add("    (c) Facts")
        add("        The relevant facts are set out in paragraph 6 above and in the")
        add("        annexures. The taxpayer's records establish the transactions")
        add("        in question. [CLIENT TO CONFIRM]")
        add("")
        add("    (d) Legal Position")
        if sections:
            add(f"        The notice invokes {sections}. The conditions prescribed")
            add("        thereunder are satisfied in the present case, as borne out")
            add("        by the documents annexed. [LEGAL SOURCE TO BE VERIFIED]")
        else:
            add("        [LEGAL SOURCE TO BE VERIFIED]")
        add("")
        add("    (e) Supporting Evidence")
        add("        Tax invoices, purchase register extracts, reconciliation")
        add("        statements, bank statements evidencing payment and the")
        add("        electronic credit ledger extract are annexed.")
        add("")
        add("    (f) Source References")
        add("        [LEGAL SOURCE TO BE VERIFIED] - to be completed from the firm's")
        add("        knowledge base before filing.")
        add("")

    add("8.  RELEVANT LEGAL PROVISIONS")
    add("    The provisions invoked in the notice are those referred to above.")
    add("    Reliance on any circular, notification or judicial authority will be")
    add("    placed only after verification. [LEGAL SOURCE TO BE VERIFIED]")
    add("")
    add("9.  SUPPORTING DOCUMENTS / ANNEXURES")
    add("    Annexure A  - Month-wise reconciliation statement")
    add("    Annexure B  - Purchase register extract")
    add("    Annexure C  - Copies of tax invoices")
    add("    Annexure D  - Electronic credit ledger extract")
    add("    Annexure E  - Bank statements evidencing payment")
    add("    Annexure F  - Authorisation letter")
    add("")
    add("10. WITHOUT PREJUDICE SUBMISSIONS")
    add("    10.1 Without prejudice to the submissions above, if any part of the")
    add("         demand is held to be sustainable, the taxpayer submits that no")
    add("         penalty is warranted, there being no fraud, wilful misstatement")
    add("         or suppression of facts.")
    add("    10.2 Without prejudice, where the tax alleged to be payable would have")
    add("         been available as input tax credit, the exercise is revenue")
    add("         neutral and no interest or penalty ought to be levied.")
    add("")
    add("11. SUMMARY")
    add("    11.1 The demand proceeds on an aggregate comparison and not on any")
    add("         invoice-level verification.")
    add("    11.2 The taxpayer has complied with the conditions prescribed by law.")
    add("    11.3 The reconciliation annexed explains the differences alleged.")
    add("")
    add("12. PRAYER")
    add("    In the premises, it is respectfully prayed that this Hon'ble Authority")
    add("    may be pleased to:")
    add("    (a) drop the proceedings initiated by the said notice in their entirety;")
    add("    (b) grant an opportunity of personal hearing before passing any order;")
    add("    (c) permit the taxpayer to file further submissions upon receipt of the")
    add("        departmental working; and")
    add("    (d) pass such further order as may be deemed fit in the facts of the case.")
    add("")
    add("")
    add("                                        For " + taxpayer)
    add("")
    add("")
    add("                                        Authorised Signatory")
    add("                                        Name  : [CLIENT TO CONFIRM]")
    add("                                        Designation: [CLIENT TO CONFIRM]")
    add("")
    add("Place: [CLIENT TO CONFIRM]")
    add(f"Date : {date.today().strftime('%d-%m-%Y')}")
    add("")
    add("-" * 78)
    add("DRAFT PREPARED WITH AI ASSISTANCE - NOT FOR FILING WITHOUT REVIEW.")
    add("All facts marked [CLIENT TO CONFIRM] and all references marked")
    add("[LEGAL SOURCE TO BE VERIFIED] must be completed and independently")
    add("verified by the Chartered Accountant before submission.")
    add("-" * 78)

    return "\n".join(lines)


def _wrap(text: str, width: int) -> List[str]:
    """Simple greedy wrap used for the plain-text draft."""
    words = str(text or "").split()
    lines: List[str] = []
    current = ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines or [""]
