"""
ui.main_window
==============
The application shell: top title bar, left sidebar navigation, page
container, status bar and footer disclaimer.

Pages are created lazily the first time they are opened and cached
thereafter, which keeps start-up fast.
"""

from __future__ import annotations

import importlib
import tkinter as tk
import traceback
from typing import Any, Dict, List, Optional, Tuple

import customtkinter as ctk

import config
from config import Theme
from ui.base_page import BasePage
from ui.widgets import (
    ModalDialog, close_window_safely, font, install_quiet_error_handlers,
    primary_button, show_error,
)
from utils.formatters import initials
from utils.logger import get_logger

log = get_logger(__name__)

# (key, sidebar label, module path, class name)
NAV_ITEMS: List[Tuple[str, str, str, str]] = [
    ("dashboard", "Dashboard", "ui.dashboard", "DashboardPage"),
    ("clients", "Clients", "ui.clients", "ClientsPage"),
    ("cases", "GST Cases", "ui.cases", "CasesPage"),
    ("notice", "Upload / Analyse Notice", "ui.notice_analyzer", "NoticeAnalyzerPage"),
    ("issues", "Issue Analysis", "ui.issue_analysis", "IssueAnalysisPage"),
    ("requirements", "Client Requirements", "ui.requirements_generator",
     "RequirementsPage"),
    ("research", "GST Research", "ui.research", "ResearchPage"),
    ("draft", "Draft Reply", "ui.draft_reply", "DraftReplyPage"),
    ("knowledge", "Knowledge Base", "ui.knowledge_base", "KnowledgeBasePage"),
    ("reports", "Reports / Exports", "ui.reports", "ReportsPage"),
    ("settings", "Settings", "ui.settings", "SettingsPage"),
]


class MainWindow(ctk.CTk):
    """Main application window."""

    def __init__(self, user: Dict[str, Any]):
        super().__init__(fg_color=Theme.BG)
        self.current_user: Dict[str, Any] = user
        self.settings: Dict[str, Any] = config.load_settings()
        self._pages: Dict[str, BasePage] = {}
        self._nav_buttons: Dict[str, ctk.CTkButton] = {}
        self._active_key: str = ""
        self.restart_login: bool = False
        self.selected_case_id: Optional[int] = None

        self.title(f"{config.APP_NAME}  v{config.APP_VERSION}  -  "
                   f"{config.APP_TAGLINE}")
        self.geometry("1420x880")
        self.minsize(1180, 720)
        self._centre()

        install_quiet_error_handlers(self)
        self._build_layout()
        self.navigate("dashboard")
        self.protocol("WM_DELETE_WINDOW", self._confirm_exit)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def _centre(self) -> None:
        self.update_idletasks()
        width, height = 1420, 880
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        width = min(width, screen_w - 60)
        height = min(height, screen_h - 90)
        x = max(0, (screen_w - width) // 2)
        y = max(0, (screen_h - height) // 2 - 20)
        self.geometry(f"{width}x{height}+{x}+{y}")

    def _build_layout(self) -> None:
        self.grid_rowconfigure(2, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self._build_topbar()
        self._build_demo_banner()
        self._build_sidebar()

        self.container = ctk.CTkFrame(self, fg_color=Theme.BG, corner_radius=0)
        self.container.grid(row=2, column=1, sticky="nsew")
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self._build_statusbar()

    def _build_demo_banner(self) -> None:
        """
        Full-width reminder that the visible records are fictional.

        Shown only while Demo Mode is on, so a live matter can never be
        mistaken for demonstration data or the reverse.
        """
        self.demo_banner = ctk.CTkFrame(self, fg_color="#8A5A00", corner_radius=0,
                                        height=26)
        self.demo_banner.grid_propagate(False)

        inner = ctk.CTkFrame(self.demo_banner, fg_color="transparent")
        inner.pack(expand=True)
        ctk.CTkLabel(inner, text=config.DEMO_BANNER_TEXT, font=font(11, "bold"),
                     text_color="#FFF3D6").pack(side="left", pady=3)
        ctk.CTkButton(
            inner, text="Guided Demo", width=96, height=20, corner_radius=4,
            fg_color="#B07A12", hover_color="#C98F1E", text_color="#FFFFFF",
            font=font(10, "bold"), command=self.start_guided_demo,
        ).pack(side="left", padx=(16, 0), pady=3)
        ctk.CTkButton(
            inner, text="Demo Data", width=92, height=20, corner_radius=4,
            fg_color="transparent", hover_color="#B07A12", border_width=1,
            border_color="#D9AE5A", text_color="#FFF3D6", font=font(10),
            command=lambda: self.navigate("settings"),
        ).pack(side="left", padx=(8, 0), pady=3)
        self._refresh_demo_banner()

    def _refresh_demo_banner(self) -> None:
        """Show or hide the demonstration banner to match the current mode."""
        banner = getattr(self, "demo_banner", None)
        if banner is None:
            return
        if self.demo_mode:
            banner.grid(row=1, column=0, columnspan=2, sticky="ew")
        else:
            banner.grid_remove()

    def _build_topbar(self) -> None:
        bar = ctk.CTkFrame(self, fg_color=Theme.TOPBAR, corner_radius=0, height=62)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)

        left = ctk.CTkFrame(bar, fg_color="transparent")
        left.pack(side="left", padx=20, pady=8)
        ctk.CTkLabel(left, text=config.APP_NAME, font=font(19, "bold"),
                     text_color="#FFFFFF", anchor="w").pack(anchor="w")
        ctk.CTkLabel(left,
                     text=f"{config.APP_TAGLINE}   |   v{config.APP_VERSION}",
                     font=font(10), text_color="#9CC0E0",
                     anchor="w").pack(anchor="w")

        right = ctk.CTkFrame(bar, fg_color="transparent")
        right.pack(side="right", padx=16)

        self.mode_chip = ctk.CTkLabel(
            right, text="", font=font(10, "bold"), corner_radius=4,
            fg_color=Theme.WARNING_BG, text_color=Theme.WARNING, width=210, height=26,
        )
        self.mode_chip.pack(side="left", padx=(0, 14))
        self._refresh_mode_chip()

        ctk.CTkButton(
            right, text="Help", width=64, height=28, corner_radius=5,
            fg_color=Theme.SIDEBAR_HOVER, hover_color=Theme.SIDEBAR_ACTIVE,
            text_color="#FFFFFF", font=font(11), command=self.show_disclaimer,
        ).pack(side="left", padx=(0, 8))

        user_box = ctk.CTkFrame(right, fg_color="transparent")
        user_box.pack(side="left")
        ctk.CTkLabel(
            user_box, text=initials(self.current_user.get("name", "")),
            font=font(12, "bold"), text_color="#FFFFFF", fg_color=Theme.SIDEBAR_ACTIVE,
            corner_radius=16, width=32, height=32,
        ).pack(side="left", padx=(0, 8))
        text_box = ctk.CTkFrame(user_box, fg_color="transparent")
        text_box.pack(side="left")
        ctk.CTkLabel(text_box, text=self.current_user.get("name", ""),
                     font=font(12, "bold"), text_color="#FFFFFF",
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(text_box, text=self.current_user.get("role", ""),
                     font=font(10), text_color="#9CC0E0", anchor="w").pack(anchor="w")

        ctk.CTkButton(
            right, text="Sign out", width=80, height=28, corner_radius=5,
            fg_color="transparent", hover_color=Theme.SIDEBAR_HOVER,
            border_width=1, border_color="#4E7BA6", text_color="#FFFFFF",
            font=font(11), command=self._sign_out,
        ).pack(side="left", padx=(14, 0))

    def _build_sidebar(self) -> None:
        sidebar = ctk.CTkFrame(self, fg_color=Theme.SIDEBAR, corner_radius=0, width=232)
        sidebar.grid(row=2, column=0, sticky="nsw")
        sidebar.grid_propagate(False)

        ctk.CTkLabel(
            sidebar, text="  NAVIGATION", font=font(10, "bold"),
            text_color="#7FA3C4", anchor="w",
        ).pack(fill="x", padx=14, pady=(16, 6))

        for index, (key, label, _module, _cls) in enumerate(NAV_ITEMS, start=1):
            button = ctk.CTkButton(
                sidebar, text=f"  {index:>2}.  {label}", anchor="w",
                font=font(12), height=38, corner_radius=5,
                fg_color="transparent", hover_color=Theme.SIDEBAR_HOVER,
                text_color=Theme.TEXT_ON_DARK,
                command=lambda k=key: self.navigate(k),
            )
            button.pack(fill="x", padx=10, pady=1)
            self._nav_buttons[key] = button

        footer = ctk.CTkFrame(sidebar, fg_color="transparent")
        footer.pack(side="bottom", fill="x", padx=14, pady=14)
        ctk.CTkLabel(footer, text=f"Version {config.APP_VERSION}",
                     font=font(11, "bold"), text_color="#FFFFFF",
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(footer, text=f"Build {config.APP_BUILD}", font=font(9),
                     text_color="#6E90AE", anchor="w").pack(anchor="w")
        ctk.CTkLabel(
            footer,
            text="AI performs the groundwork.\nThe CA retains judgment.",
            font=font(9), text_color="#6E90AE", anchor="w", justify="left",
        ).pack(anchor="w", pady=(6, 0))

    def _build_statusbar(self) -> None:
        bar = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0, height=30,
                           border_width=1, border_color=Theme.BORDER)
        bar.grid(row=3, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)

        self.status_label = ctk.CTkLabel(
            bar, text="Ready", font=font(10), text_color=Theme.TEXT_MUTED, anchor="w",
        )
        self.status_label.pack(side="left", padx=14)

        ctk.CTkLabel(
            bar, text=config.APP_FOOTER, font=font(10, "bold"),
            text_color=Theme.TEXT_MUTED, anchor="e",
        ).pack(side="right", padx=14)
        ctk.CTkLabel(
            bar, text=config.APP_BRANDING, font=font(10),
            text_color=Theme.PRIMARY, anchor="e",
        ).pack(side="right", padx=(0, 6))

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def navigate(self, key: str, **context) -> None:
        """Show a page, creating it on first use."""
        page = self._get_page(key)
        if page is None:
            return

        for other in self._pages.values():
            other.grid_forget()
        page.grid(row=0, column=0, sticky="nsew")

        for nav_key, button in self._nav_buttons.items():
            active = nav_key == key
            button.configure(
                fg_color=Theme.SIDEBAR_ACTIVE if active else "transparent",
                font=font(12, "bold" if active else "normal"),
            )
        self._active_key = key

        try:
            page.on_show(**context)
        except Exception as exc:  # noqa: BLE001 - a page must not kill the app
            log.exception("Error while showing page '%s'", key)
            self.set_status(f"Could not load page: {exc}", "danger")
            show_error(self, "Page error",
                       f"The '{key}' screen reported a problem:\n\n{exc}")

    def _get_page(self, key: str) -> Optional[BasePage]:
        if key in self._pages:
            return self._pages[key]
        entry = next((item for item in NAV_ITEMS if item[0] == key), None)
        if entry is None:
            log.error("Unknown navigation key '%s'", key)
            return None
        _key, label, module_path, class_name = entry
        try:
            module = importlib.import_module(module_path)
            page_class = getattr(module, class_name)
            page = page_class(self.container, self)
        except Exception as exc:  # noqa: BLE001
            log.exception("Could not load screen '%s'", label)
            page = _ErrorPage(self.container, self, label, exc)
        self._pages[key] = page
        return page

    def refresh_page(self, key: str) -> None:
        """Force a data reload on a page if it has already been created."""
        page = self._pages.get(key)
        if page is not None and page._built:  # noqa: SLF001 - internal by design
            try:
                page.refresh()
            except Exception:  # noqa: BLE001
                log.exception("Refresh failed for page '%s'", key)

    def refresh_all(self) -> None:
        for key in list(self._pages):
            self.refresh_page(key)

    # ------------------------------------------------------------------
    # Shared state
    # ------------------------------------------------------------------
    def set_status(self, message: str, kind: str = "info") -> None:
        colour = {
            "info": Theme.TEXT_MUTED, "success": Theme.SUCCESS,
            "warning": Theme.WARNING, "danger": Theme.DANGER,
        }.get(kind, Theme.TEXT_MUTED)
        try:
            self.status_label.configure(text=message, text_color=colour)
        except Exception:  # noqa: BLE001
            pass

    def save_settings(self) -> None:
        config.save_settings(self.settings)
        self._refresh_mode_chip()

    @property
    def demo_mode(self) -> bool:
        return bool(self.settings.get("demo_mode", True))

    def set_demo_mode(self, enabled: bool) -> None:
        self.settings["demo_mode"] = bool(enabled)
        self.save_settings()
        self._refresh_demo_banner()
        self.refresh_all()

    def start_guided_demo(self) -> None:
        """Open the step-by-step presenter guide."""
        from ui.guided_demo import GuidedDemoWindow

        existing = getattr(self, "_guided_demo", None)
        if existing is not None:
            try:
                # Reuse the open guide rather than stacking a second one.
                if existing.winfo_exists():
                    existing.focus_window()
                    return
            except tk.TclError:
                pass          # the window was destroyed; fall through and rebuild
        self._guided_demo = GuidedDemoWindow(self)

    def _refresh_mode_chip(self) -> None:
        if self.demo_mode:
            self.mode_chip.configure(
                text="DEMO MODE - AI API NOT CALLED",
                fg_color=Theme.WARNING_BG, text_color=Theme.WARNING,
            )
        elif config.api_key_available():
            self.mode_chip.configure(
                text=f"LIVE AI MODE - {config.current_provider()} connected",
                fg_color=Theme.SUCCESS_BG, text_color=Theme.SUCCESS,
            )
        else:
            self.mode_chip.configure(
                text="LIVE MODE - API KEY MISSING",
                fg_color=Theme.DANGER_BG, text_color=Theme.DANGER,
            )

    # ------------------------------------------------------------------
    # Help / exit
    # ------------------------------------------------------------------
    def show_disclaimer(self) -> None:
        DisclaimerDialog(self)

    def _sign_out(self) -> None:
        from ui.widgets import confirm_action

        confirm_action(
            self, "Sign out", "Sign out and return to the login screen?",
            self._do_sign_out, confirm_text="Sign out", kind="warning",
        )

    def _do_sign_out(self) -> None:
        # main.py reads this flag after mainloop() returns and, when it is
        # set, shows the login window again instead of exiting.
        self.restart_login = True
        self.close_window()

    def _confirm_exit(self) -> None:
        from ui.widgets import confirm_action

        confirm_action(
            self, "Exit application", "Close CA-GST Copilot?",
            self.close_window, confirm_text="Exit", kind="warning",
        )

    def close_window(self) -> None:
        """Shut the window down without leaving the event loop running."""
        close_window_safely(self)


class DisclaimerDialog(ModalDialog):
    """Help > Disclaimer."""

    def __init__(self, parent):
        super().__init__(parent, "Disclaimer and professional responsibility",
                         width=620, height=460)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=22, pady=18)

        ctk.CTkLabel(body, text=f"{config.APP_NAME} v{config.APP_VERSION}",
                     font=font(16, "bold"), text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(body, text=config.APP_TAGLINE, font=font(11),
                     text_color=Theme.TEXT_MUTED).pack(anchor="w")
        ctk.CTkLabel(body, text=config.APP_VERSION_LABEL, font=font(11, "bold"),
                     text_color=Theme.PRIMARY).pack(anchor="w")
        ctk.CTkLabel(body, text=config.APP_BRANDING, font=font(11),
                     text_color=Theme.TEXT_MUTED).pack(anchor="w", pady=(0, 14))

        text = ctk.CTkTextbox(body, font=font(12), wrap="word", fg_color=Theme.SURFACE,
                              text_color=Theme.TEXT, border_width=1,
                              border_color=Theme.BORDER, corner_radius=6)
        text.pack(fill="both", expand=True)
        text.insert("1.0", config.FULL_DISCLAIMER + "\n\n" + config.AI_DISCLAIMER)
        text.configure(state="disabled")

        primary_button(body, "I understand", self.close, width=150).pack(
            anchor="e", pady=(14, 0))


class _ErrorPage(BasePage):
    """Shown when a screen module fails to import or construct."""

    def __init__(self, master, app, label: str, error: Exception):
        self.title = label
        self.subtitle = "This screen could not be loaded"
        super().__init__(master, app)
        self._error = error

    def build(self) -> None:
        ctk.CTkLabel(
            self.body, text="This screen is unavailable", font=font(16, "bold"),
            text_color=Theme.DANGER, anchor="w",
        ).pack(anchor="w", pady=(20, 6))
        detail = ctk.CTkTextbox(self.body, font=font(11), wrap="word", height=300,
                                fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                                border_width=1, border_color=Theme.BORDER)
        detail.pack(fill="both", expand=True)
        detail.insert("1.0", f"{type(self._error).__name__}: {self._error}\n\n"
                             + "".join(traceback.format_exception(
                                 type(self._error), self._error,
                                 self._error.__traceback__)))
        detail.configure(state="disabled")
        ctk.CTkLabel(
            self.body,
            text="The rest of the application continues to work. "
                 "See logs/app.log for details.",
            font=font(11), text_color=Theme.TEXT_MUTED,
        ).pack(anchor="w", pady=(10, 0))
