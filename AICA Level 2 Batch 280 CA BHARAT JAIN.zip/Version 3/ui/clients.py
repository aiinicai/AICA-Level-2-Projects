"""
ui.clients
==========
Client master: full CRUD with search, GSTIN/PAN format validation and a
client detail panel showing the related GST cases and total exposure.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from ui.base_page import BasePage
from ui.widgets import (
    Card, DataTable, DetailGrid, LabeledDropdown, LabeledEntry,
    LabeledTextbox, ModalDialog, SearchBar, confirm_action, danger_button, font,
    primary_button, secondary_button, show_error, show_success, show_warning,
)
from utils.calculations import compute_demand, sum_amounts
from utils.formatters import format_currency, format_currency_short, truncate
from utils.logger import get_logger
from utils.validators import (
    gstin_state, pan_from_gstin, validate_client_form, validate_gstin, validate_pan,
)

log = get_logger(__name__)

CLIENT_COLUMNS = [
    ("client_code", "Client ID", 90, "w"),
    ("client_name", "Client Name", 250, "w"),
    ("gstin", "GSTIN", 150, "w"),
    ("state", "State", 130, "w"),
    ("entity_type", "Entity Type", 150, "w"),
    ("contact_person", "Contact Person", 140, "w"),
    ("mobile", "Mobile", 100, "w"),
    ("case_count", "Cases", 60, "center"),
    ("exposure_display", "Exposure", 110, "e"),
    ("status_display", "Status", 80, "center"),
]


class ClientsPage(BasePage):
    """Client master screen."""

    title = "Clients"
    subtitle = "Client master - add, edit and review the clients you act for"

    def build(self) -> None:
        self._search_text = ""
        self._active_only = False

        primary_button(self.header_actions, "+ Add Client", self._add_client,
                       width=140).pack(side="right")
        secondary_button(self.header_actions, "Refresh", self.refresh,
                         width=90).pack(side="right", padx=(0, 8))

        toolbar = ctk.CTkFrame(self.body, fg_color="transparent")
        toolbar.pack(fill="x", pady=(0, 10))

        SearchBar(toolbar, "Search by name, GSTIN, PAN, contact or state...",
                  self._on_search, width=380).pack(side="left")

        self.active_switch = ctk.CTkSwitch(
            toolbar, text="Active clients only", font=font(11),
            text_color=Theme.TEXT, command=self._toggle_active,
            progress_color=Theme.PRIMARY,
        )
        self.active_switch.pack(side="left", padx=20)

        self.count_label = ctk.CTkLabel(toolbar, text="", font=font(11),
                                        text_color=Theme.TEXT_MUTED)
        self.count_label.pack(side="right")

        split = ctk.CTkFrame(self.body, fg_color="transparent")
        split.pack(fill="both", expand=True)
        split.grid_columnconfigure(0, weight=3)
        split.grid_columnconfigure(1, weight=2)
        split.grid_rowconfigure(0, weight=1)

        self.table = DataTable(
            split, CLIENT_COLUMNS, on_select=self._on_select,
            on_double_click=lambda row: self._edit_client(row), height=18,
        )
        self.table.grid(row=0, column=0, sticky="nsew", padx=(0, 12))

        self.detail_card = Card(split, "Client Details")
        self.detail_card.grid(row=0, column=1, sticky="nsew")
        self._build_detail_panel()

    def _build_detail_panel(self) -> None:
        self.detail_body = ctk.CTkScrollableFrame(
            self.detail_card, fg_color="transparent",
            scrollbar_button_color=Theme.BORDER,
        )
        self.detail_body.pack(fill="both", expand=True, padx=14, pady=12)

        self.detail_grid = DetailGrid(self.detail_body, columns=1)
        self.detail_grid.pack(fill="x")

        self.detail_placeholder = ctk.CTkLabel(
            self.detail_body,
            text="Select a client to see details,\nvalidation status and related cases.",
            font=font(12), text_color=Theme.TEXT_MUTED, justify="center",
        )
        self.detail_placeholder.pack(pady=40)

        self.detail_actions = ctk.CTkFrame(self.detail_card, fg_color="transparent",
                                           width=1, height=1)
        self.detail_actions.pack(fill="x", padx=14, pady=(0, 12))

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        try:
            clients = db.list_clients(self._search_text, active_only=self._active_only)
            cases = db.list_cases()
        except db.DatabaseError as exc:
            show_error(self, "Database error", f"Clients could not be loaded.\n\n{exc}")
            return

        exposure: Dict[int, Any] = {}
        counts: Dict[int, int] = {}
        for case in cases:
            client_id = case.get("client_id")
            counts[client_id] = counts.get(client_id, 0) + 1
            exposure[client_id] = sum_amounts(
                [exposure.get(client_id, 0), compute_demand(case).total_exposure]
            )

        rows: List[Dict[str, Any]] = []
        for client in clients:
            row = dict(client)
            client_id = client["id"]
            row["case_count"] = counts.get(client_id, 0)
            row["exposure_display"] = format_currency_short(exposure.get(client_id, 0))
            row["status_display"] = "Active" if client.get("active") else "Inactive"
            row["gstin"] = client.get("gstin") or "-"
            rows.append(row)

        self.table.load(rows, tag_fn=lambda r: "" if r["status_display"] == "Active" else "muted")
        self.count_label.configure(text=f"{len(rows)} client(s)")
        self.status(f"{len(rows)} client(s) listed")

    def _on_search(self, text: str) -> None:
        self._search_text = text
        self.refresh()

    def _toggle_active(self) -> None:
        self._active_only = bool(self.active_switch.get())
        self.refresh()

    # ------------------------------------------------------------------
    def _on_select(self, row: Optional[Dict[str, Any]]) -> None:
        for child in self.detail_actions.winfo_children():
            child.destroy()
        self.detail_grid.reset()

        if not row:
            self.detail_placeholder.pack(pady=40)
            return
        self.detail_placeholder.pack_forget()

        client = db.get_client(int(row["id"]))
        if not client:
            return

        gstin_result = validate_gstin(client.get("gstin", ""))
        pan_result = validate_pan(client.get("pan", ""))

        grid = self.detail_grid
        grid.add("Client ID", client.get("client_code", "-"))
        grid.add("Client Name", client.get("client_name", "-"), bold=True)
        grid.add("GSTIN", client.get("gstin") or "-")
        grid.add("GSTIN check", gstin_result.status,
                 value_color=_status_colour(gstin_result.status))
        grid.add("PAN", client.get("pan") or "-")
        grid.add("PAN check", pan_result.status,
                 value_color=_status_colour(pan_result.status))
        grid.add("State", client.get("state") or gstin_state(client.get("gstin", "")) or "-")
        grid.add("Entity Type", client.get("entity_type") or "-")
        grid.add("Industry", client.get("industry") or "-")
        grid.add("Contact Person", client.get("contact_person") or "-")
        grid.add("Email", client.get("email") or "-")
        grid.add("Mobile", client.get("mobile") or "-")
        grid.add("Responsible Partner", client.get("partner") or "-")
        grid.add("Manager", client.get("manager") or "-")
        grid.add("Status", "Active" if client.get("active") else "Inactive",
                 value_color=Theme.SUCCESS if client.get("active") else Theme.TEXT_MUTED)
        if client.get("notes"):
            grid.add_full("Notes", truncate(client["notes"], 400), wraplength=380)

        cases = db.cases_for_client(int(client["id"]))
        exposure = sum_amounts(compute_demand(c).total_exposure for c in cases)
        grid.add("Cases", str(len(cases)), bold=True)
        grid.add("Total Exposure", format_currency(exposure), bold=True,
                 value_color=Theme.DANGER if exposure else Theme.TEXT)

        if cases:
            ctk.CTkLabel(self.detail_body, text="Related GST Cases",
                         font=font(12, "bold"), text_color=Theme.TEXT,
                         anchor="w").pack(fill="x", pady=(14, 4))
            for case in cases[:8]:
                line = ctk.CTkFrame(self.detail_body, fg_color=Theme.SURFACE_ALT,
                                    corner_radius=5)
                line.pack(fill="x", pady=2)
                ctk.CTkLabel(
                    line,
                    text=f"{case.get('case_code', '')}  |  {case.get('notice_type', '')}"
                         f"  |  {case.get('status', '')}",
                    font=font(11), text_color=Theme.TEXT, anchor="w",
                ).pack(side="left", padx=10, pady=6)
                ctk.CTkLabel(
                    line, text=format_currency_short(compute_demand(case).total_exposure),
                    font=font(11, "bold"), text_color=Theme.TEXT_MUTED,
                ).pack(side="right", padx=10)

        primary_button(self.detail_actions, "Edit",
                       lambda: self._edit_client(row), width=90).pack(side="left")
        secondary_button(self.detail_actions, "View Cases",
                         lambda: self.navigate("cases", client_id=int(client["id"])),
                         width=110).pack(side="left", padx=6)
        danger_button(self.detail_actions, "Delete",
                      lambda: self._delete_client(client), width=90).pack(side="right")

    # ------------------------------------------------------------------
    def _add_client(self) -> None:
        if self.block_if_readonly():
            return
        ClientFormDialog(self, on_saved=self._after_save)

    def _edit_client(self, row: Optional[Dict[str, Any]]) -> None:
        if not row:
            show_warning(self, "No client selected", "Please select a client first.")
            return
        if self.block_if_readonly():
            return
        client = db.get_client(int(row["id"]))
        if client:
            ClientFormDialog(self, client=client, on_saved=self._after_save)

    def _delete_client(self, client: Dict[str, Any]) -> None:
        if self.block_if_readonly():
            return
        cases = db.cases_for_client(int(client["id"]))
        warning = (
            f"Delete client '{client['client_name']}'?\n\n"
            f"This will also permanently delete {len(cases)} linked GST case(s) "
            "together with their analysis, issues, requirements, research and drafts."
            if cases else
            f"Delete client '{client['client_name']}'?\n\nThis cannot be undone."
        )

        def do_delete() -> None:
            try:
                db.delete_client(int(client["id"]))
                db.log_activity("Client deleted", client["client_name"],
                                user_name=self.user_name)
                self.status(f"Client '{client['client_name']}' deleted", "success")
                self._after_save()
            except db.DatabaseError as exc:
                show_error(self, "Delete failed", str(exc))

        confirm_action(self, "Delete client", warning, do_delete, confirm_text="Delete")

    def _after_save(self) -> None:
        self.refresh()
        self.app.refresh_page("dashboard")
        self.app.refresh_page("cases")


def _status_colour(status: str) -> str:
    return {
        "Valid": Theme.SUCCESS,
        "Review Required": Theme.WARNING,
        "Invalid Format": Theme.DANGER,
        "Not Identified": Theme.TEXT_MUTED,
    }.get(status, Theme.TEXT)


class ClientFormDialog(ModalDialog):
    """Add / edit client form."""

    def __init__(self, parent, client: Optional[Dict[str, Any]] = None,
                 on_saved=None):
        self._client = client
        self._on_saved = on_saved
        title = "Edit Client" if client else "Add Client"
        super().__init__(parent, title, width=760, height=690)

        header = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0, height=56)
        header.pack(fill="x")
        ctk.CTkLabel(header, text=title, font=font(17, "bold"),
                     text_color=Theme.TEXT).pack(side="left", padx=20, pady=14)
        if client:
            ctk.CTkLabel(header, text=client.get("client_code", ""), font=font(12),
                         text_color=Theme.TEXT_MUTED).pack(side="left")

        body = ctk.CTkScrollableFrame(self, fg_color=Theme.BG,
                                      scrollbar_button_color=Theme.BORDER)
        body.pack(fill="both", expand=True, padx=16, pady=12)

        grid = ctk.CTkFrame(body, fg_color="transparent")
        grid.pack(fill="both", expand=True)
        grid.grid_columnconfigure(0, weight=1, uniform="col")
        grid.grid_columnconfigure(1, weight=1, uniform="col")

        c = client or {}
        row = 0

        self.client_name = LabeledEntry(grid, "Client Name", c.get("client_name", ""),
                                        required=True, width=320)
        self.client_name.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)
        self.entity_type = LabeledDropdown(grid, "Entity Type",
                                           [""] + config.ENTITY_TYPES,
                                           c.get("entity_type", ""), width=320)
        self.entity_type.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1

        self.gstin = LabeledEntry(grid, "GSTIN", c.get("gstin", ""),
                                  placeholder="27AAAPA1234A1Z5", width=320)
        self.gstin.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)
        self.gstin.entry.bind("<FocusOut>", lambda _e: self._check_gstin())
        self.pan = LabeledEntry(grid, "PAN", c.get("pan", ""),
                                placeholder="AAAPA1234A", width=320)
        self.pan.grid(row=row, column=1, sticky="ew", pady=2)
        self.pan.entry.bind("<FocusOut>", lambda _e: self._check_pan())
        row += 1

        self.state = LabeledDropdown(grid, "State", [""] + config.STATE_NAMES,
                                     c.get("state", ""), width=320)
        self.state.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)
        self.industry = LabeledEntry(grid, "Industry", c.get("industry", ""),
                                     placeholder="e.g. Manufacturing", width=320)
        self.industry.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1

        self.contact_person = LabeledEntry(grid, "Contact Person",
                                           c.get("contact_person", ""), width=320)
        self.contact_person.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)
        self.email = LabeledEntry(grid, "Email", c.get("email", ""),
                                  placeholder="name@company.com", width=320)
        self.email.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1

        self.mobile = LabeledEntry(grid, "Mobile Number", c.get("mobile", ""),
                                   placeholder="10 digits", width=320)
        self.mobile.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)
        members = [""] + db.team_member_names()
        self.partner = LabeledDropdown(grid, "Responsible Partner", members,
                                       c.get("partner", ""), width=320)
        self.partner.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1

        self.manager = LabeledDropdown(grid, "Manager", members,
                                       c.get("manager", ""), width=320)
        self.manager.grid(row=row, column=0, sticky="ew", padx=(0, 12), pady=2)

        status_box = ctk.CTkFrame(grid, fg_color="transparent")
        status_box.grid(row=row, column=1, sticky="ew", pady=2)
        ctk.CTkLabel(status_box, text="Status", font=font(11, "bold"),
                     text_color=Theme.TEXT_MUTED, anchor="w").pack(fill="x")
        self.active_switch = ctk.CTkSwitch(status_box, text="Active client",
                                           font=font(12), text_color=Theme.TEXT,
                                           progress_color=Theme.SUCCESS)
        self.active_switch.pack(anchor="w", pady=(6, 0))
        if c.get("active", 1):
            self.active_switch.select()
        row += 1

        self.notes = LabeledTextbox(grid, "Notes", c.get("notes", ""), height=90)
        self.notes.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(6, 2))
        row += 1

        note = ctk.CTkFrame(body, fg_color=Theme.INFO_BG, corner_radius=6)
        note.pack(fill="x", pady=(10, 0))
        ctk.CTkLabel(
            note,
            text="GSTIN and PAN are checked for format only (length, pattern, state "
                 "code and checksum). This application does not verify a GSTIN "
                 "against the GST portal.",
            font=font(10), text_color=Theme.INFO, wraplength=660, justify="left",
        ).pack(padx=12, pady=8, anchor="w")

        footer = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0, height=60)
        footer.pack(fill="x", side="bottom")
        primary_button(footer, "Save Client", self._save, width=140).pack(
            side="right", padx=16, pady=12)
        secondary_button(footer, "Cancel", self.close, width=100).pack(
            side="right", pady=12)

        self.client_name.focus()

    # ------------------------------------------------------------------
    def _check_gstin(self) -> None:
        value = self.gstin.get().upper()
        if not value:
            self.gstin.set_hint("")
            return
        self.gstin.set(value)
        result = validate_gstin(value)
        kind = {"Valid": "success", "Review Required": "danger"}.get(result.status, "danger")
        self.gstin.set_hint(result.message, kind)
        if result.status == "Valid":
            if not self.pan.get():
                self.pan.set(pan_from_gstin(value))
            if not self.state.get():
                self.state.set(gstin_state(value))

    def _check_pan(self) -> None:
        value = self.pan.get().upper()
        if not value:
            self.pan.set_hint("")
            return
        self.pan.set(value)
        result = validate_pan(value)
        self.pan.set_hint(result.message,
                          "success" if result.status == "Valid" else "danger")

    def _collect(self) -> Dict[str, Any]:
        return {
            "client_name": self.client_name.get(),
            "gstin": self.gstin.get().upper(),
            "pan": self.pan.get().upper(),
            "state": self.state.get(),
            "entity_type": self.entity_type.get(),
            "industry": self.industry.get(),
            "contact_person": self.contact_person.get(),
            "email": self.email.get(),
            "mobile": self.mobile.get(),
            "partner": self.partner.get(),
            "manager": self.manager.get(),
            "notes": self.notes.get(),
            "active": 1 if self.active_switch.get() else 0,
        }

    def _save(self) -> None:
        data = self._collect()
        ok, errors = validate_client_form(data)
        if not ok:
            show_error(self, "Please correct the following", "\n".join(f"• {e}" for e in errors))
            return
        try:
            if self._client:
                db.update_client(int(self._client["id"]), data)
                db.log_activity("Client updated", data["client_name"])
                message = f"Client '{data['client_name']}' updated."
            else:
                db.create_client(data)
                db.log_activity("Client created", data["client_name"])
                message = f"Client '{data['client_name']}' created."
        except db.DatabaseError as exc:
            show_error(self, "Save failed", f"The client could not be saved.\n\n{exc}")
            return

        callback = self._on_saved
        self.close()
        if callback:
            callback()
        show_success(self.master, "Saved", message)
