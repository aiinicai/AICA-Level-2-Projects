"""
ui.login
========
Local login window backed by the SQLite ``users`` table.

The first-run administrator is ``admin`` / ``admin123``. On the first
successful sign-in the user is invited to replace that temporary password,
and may skip it and continue straight into the application.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from ui.widgets import (
    LabeledEntry, ModalDialog, close_window_safely, font,
    install_quiet_error_handlers, primary_button, secondary_button, show_error,
    show_success,
)
from utils.helpers import password_strength_message, verify_password
from utils.logger import get_logger

log = get_logger(__name__)


class LoginWindow(ctk.CTk):
    """Standalone login window shown before the main application."""

    def __init__(self, on_success: Callable[[Dict[str, Any]], None]):
        super().__init__(fg_color=Theme.BG)
        self._on_success = on_success
        self.user: Optional[Dict[str, Any]] = None
        self._attempts = 0

        self.title(f"{config.APP_NAME} - Sign in")
        self.geometry("880x560")
        self.minsize(760, 520)
        self._centre()
        install_quiet_error_handlers(self)
        self._build()
        self.bind("<Return>", lambda _e: self._attempt_login())

    # ------------------------------------------------------------------
    def _centre(self) -> None:
        self.update_idletasks()
        width, height = 880, 560
        x = (self.winfo_screenwidth() - width) // 2
        y = (self.winfo_screenheight() - height) // 3
        self.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")

    def _build(self) -> None:
        self.grid_columnconfigure(0, weight=5, uniform="login")
        self.grid_columnconfigure(1, weight=4, uniform="login")
        self.grid_rowconfigure(0, weight=1)

        self._build_brand_panel()
        self._build_form_panel()

    def _build_brand_panel(self) -> None:
        panel = ctk.CTkFrame(self, fg_color=Theme.SIDEBAR, corner_radius=0)
        panel.grid(row=0, column=0, sticky="nsew")

        inner = ctk.CTkFrame(panel, fg_color="transparent")
        inner.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            inner, text="CA-GST", font=font(38, "bold"), text_color="#FFFFFF",
        ).pack(anchor="w")
        ctk.CTkLabel(
            inner, text="COPILOT", font=font(38, "bold"), text_color=Theme.SIDEBAR_ACTIVE,
        ).pack(anchor="w")
        ctk.CTkFrame(inner, height=2, width=120, fg_color=Theme.SIDEBAR_ACTIVE).pack(
            anchor="w", pady=14)
        ctk.CTkLabel(
            inner, text=config.APP_TAGLINE, font=font(14),
            text_color=Theme.TEXT_ON_DARK, anchor="w",
        ).pack(anchor="w")

        points = (
            "Structured GST notice analysis",
            "Issue-wise allegation breakdown",
            "Python-computed demand exposure",
            "Source-grounded GST research",
            "Professional draft reply generation",
        )
        block = ctk.CTkFrame(inner, fg_color="transparent")
        block.pack(anchor="w", pady=(26, 0))
        for point in points:
            row = ctk.CTkFrame(block, fg_color="transparent")
            row.pack(anchor="w", pady=3)
            ctk.CTkLabel(row, text="•", font=font(14, "bold"),
                         text_color=Theme.SIDEBAR_ACTIVE, width=14).pack(side="left")
            ctk.CTkLabel(row, text=point, font=font(12),
                         text_color=Theme.TEXT_ON_DARK).pack(side="left")

        ctk.CTkLabel(
            inner,
            text="AI performs the repetitive groundwork.\n"
                 "The Chartered Accountant retains professional judgment.",
            font=font(11, "bold"), text_color="#8FB4D9", justify="left",
        ).pack(anchor="w", pady=(28, 0))
        ctk.CTkLabel(
            inner, text=config.APP_BRANDING, font=font(11, "bold"),
            text_color=Theme.SIDEBAR_ACTIVE, anchor="w",
        ).pack(anchor="w", pady=(18, 0))

    def _build_form_panel(self) -> None:
        panel = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0)
        panel.grid(row=0, column=1, sticky="nsew")

        form = ctk.CTkFrame(panel, fg_color="transparent")
        form.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(form, text="Sign in", font=font(24, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(form, text="Use your CA-GST Copilot credentials",
                     font=font(11), text_color=Theme.TEXT_MUTED).pack(
            anchor="w", pady=(0, 18))

        self.username = LabeledEntry(form, "Username", width=290, placeholder="admin")
        self.username.pack(fill="x", pady=(0, 4))
        self.password = LabeledEntry(form, "Password", width=290, show="*",
                                     placeholder="Enter password")
        self.password.pack(fill="x", pady=(0, 4))

        self.error_label = ctk.CTkLabel(form, text="", font=font(11),
                                        text_color=Theme.DANGER, wraplength=290,
                                        justify="left", anchor="w")
        self.error_label.pack(fill="x", pady=(0, 8))

        primary_button(form, "Sign in", self._attempt_login, width=290, height=38).pack()
        secondary_button(form, "Exit", self._exit, width=290).pack(pady=(8, 0))

        hint = ctk.CTkFrame(form, fg_color=Theme.SURFACE_ALT, corner_radius=6)
        hint.pack(fill="x", pady=(22, 0))
        ctk.CTkLabel(
            hint, text="First run credentials", font=font(10, "bold"),
            text_color=Theme.TEXT_MUTED,
        ).pack(anchor="w", padx=12, pady=(8, 0))
        ctk.CTkLabel(
            hint, text="Username: admin      Password: admin123\n"
                       "You will be invited to change this; you may skip it.",
            font=font(10), text_color=Theme.TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=12, pady=(0, 8))

        ctk.CTkLabel(form, text=config.APP_VERSION_LABEL, font=font(10, "bold"),
                     text_color=Theme.PRIMARY).pack(pady=(16, 0))
        ctk.CTkLabel(form, text=config.APP_FOOTER, font=font(9),
                     text_color=Theme.TEXT_MUTED).pack(pady=(2, 0))
        ctk.CTkLabel(form, text=config.APP_BRANDING, font=font(10, "bold"),
                     text_color=Theme.PRIMARY).pack(pady=(4, 0))

        self.username.focus()

    def _exit(self) -> None:
        close_window_safely(self)

    # ------------------------------------------------------------------
    def _attempt_login(self) -> None:
        username = self.username.get()
        password = self.password.entry.get()

        if not username or not password:
            self.error_label.configure(text="Please enter both username and password.")
            return

        try:
            user = db.get_user_by_username(username)
        except db.DatabaseError as exc:
            log.error("Login failed - database unavailable: %s", exc)
            show_error(self, "Database unavailable",
                       "The application database could not be opened.\n\n"
                       f"Details: {exc}")
            return

        if not user or not verify_password(password, user.get("password_hash", "")):
            self._attempts += 1
            self.error_label.configure(
                text=f"Invalid username or password. (Attempt {self._attempts})"
            )
            self.password.set("")
            log.warning("Failed login attempt for username '%s'", username)
            return

        if not user.get("active"):
            self.error_label.configure(
                text="This account is inactive. Please contact the administrator."
            )
            return

        db.record_login(int(user["id"]))
        log.info("User '%s' signed in", user["username"])

        if user.get("must_change_pw"):
            ChangePasswordDialog(self, user, first_login=True,
                                 on_done=lambda: self._finish(user),
                                 current_password=password)
        else:
            self._finish(user)

    def _finish(self, user: Dict[str, Any]) -> None:
        self.user = dict(db.get_user(int(user["id"])) or user)
        close_window_safely(self)
        self._on_success(self.user)


class ChangePasswordDialog(ModalDialog):
    """Force / allow a password change."""

    def __init__(self, parent, user: Dict[str, Any], first_login: bool = False,
                 on_done: Optional[Callable[[], None]] = None,
                 current_password: str = ""):
        super().__init__(parent, "Change password", width=460, height=470,
                         resizable=False)
        self._user = user
        self._first_login = first_login
        self._on_done = on_done
        if first_login:
            # Closing the window skips the change rather than trapping the user.
            self.protocol("WM_DELETE_WINDOW", self._skip)

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=24, pady=20)

        heading = "Set a new password" if first_login else "Change password"
        ctk.CTkLabel(body, text=heading, font=font(16, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w")
        message = (
            "This is your first sign-in. Replacing the temporary password is "
            "recommended, but you can skip this and continue straight to the "
            "application. You can change it later from Settings."
            if first_login else
            f"Signed in as {user.get('name', '')}."
        )
        ctk.CTkLabel(body, text=message, font=font(11), text_color=Theme.TEXT_MUTED,
                     wraplength=400, justify="left").pack(anchor="w", pady=(2, 14))

        self.current = LabeledEntry(body, "Current password", show="*", width=380)
        self.current.pack(fill="x")
        if current_password:
            # The user has just typed this on the login screen; re-typing it
            # here adds nothing.
            self.current.set(current_password)
            self.current.set_hint("Carried over from the sign-in screen.", "muted")
        self.new_password = LabeledEntry(body, "New password", show="*", width=380)
        self.new_password.pack(fill="x")
        self.confirm = LabeledEntry(body, "Confirm new password", show="*", width=380)
        self.confirm.pack(fill="x")

        self.error_label = ctk.CTkLabel(body, text="", font=font(11),
                                        text_color=Theme.DANGER, wraplength=400,
                                        justify="left", anchor="w")
        self.error_label.pack(fill="x", pady=(2, 10))

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x")
        primary_button(buttons, "Update password", self._save, width=170).pack(side="right")
        if first_login:
            secondary_button(buttons, "Skip for now", self._skip, width=130).pack(
                side="right", padx=(0, 8))
        else:
            secondary_button(buttons, "Cancel", self.close, width=110).pack(
                side="right", padx=(0, 8))

    def _skip(self) -> None:
        """Continue into the application without changing the password."""
        log.info("User '%s' skipped the first-login password change",
                 self._user.get("username"))
        callback = self._on_done
        self.close()
        if callback:
            callback()

    def _save(self) -> None:
        current = self.current.entry.get()
        new_password = self.new_password.entry.get()
        confirm = self.confirm.entry.get()

        if not verify_password(current, self._user.get("password_hash", "")):
            self.error_label.configure(text="Current password is incorrect.")
            return
        if new_password != confirm:
            self.error_label.configure(text="New password and confirmation do not match.")
            return
        problem = password_strength_message(new_password)
        if problem:
            self.error_label.configure(text=problem)
            return

        try:
            db.set_user_password(int(self._user["id"]), new_password)
        except db.DatabaseError as exc:
            self.error_label.configure(text=f"Could not save password: {exc}")
            return

        log.info("Password changed for user '%s'", self._user.get("username"))
        callback = self._on_done
        self.close()
        show_success(self.master, "Password updated",
                     "Your password has been changed successfully.")
        if callback:
            callback()
