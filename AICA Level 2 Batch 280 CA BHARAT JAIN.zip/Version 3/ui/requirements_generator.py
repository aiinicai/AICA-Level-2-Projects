"""
ui.requirements_generator
=========================
Client document requirements: generate a tailored checklist with the AI,
edit it by hand, track what has been received and export the list to
Excel, Word or PDF.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import export_service, requirement_service
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DisclaimerBanner, LabeledDropdown, LabeledEntry,
    LabeledTextbox, ModalDialog, ai_button, confirm_action, danger_button, font,
    primary_button, run_in_background, secondary_button, show_error, show_info,
    show_success, show_warning,
)
from utils.formatters import format_date, to_iso_date, truncate
from utils.helpers import open_in_explorer
from utils.logger import get_logger

log = get_logger(__name__)

REQUIREMENT_COLUMNS = [
    ("sr", "Sr.", 45, "center"),
    ("document_name", "Document / Information Required", 380, "w"),
    ("purpose_short", "Purpose", 300, "w"),
    ("requirement_type", "Type", 100, "center"),
    ("status", "Status", 140, "center"),
    ("received_display", "Received On", 100, "center"),
    ("issue_display", "Issue", 90, "center"),
    ("remarks_short", "Remarks", 200, "w"),
]

ALL_ISSUES = "All issues (whole case)"


class RequirementsPage(BasePage):
    """Document requirement generation and tracking."""

    title = "Client Requirements"
    subtitle = "Generate, track and issue the document requirement list"

    def build(self) -> None:
        self._case: Optional[Dict[str, Any]] = None
        self._issues: List[Dict[str, Any]] = []
        self._covering_note = requirement_service.DEFAULT_COVERING_NOTE

        # -- selectors -------------------------------------------------------
        selector = Card(self.body)
        selector.pack(fill="x", pady=(0, 8))
        bar = ctk.CTkFrame(selector, fg_color="transparent")
        bar.pack(fill="x", padx=14, pady=12)

        self.case_picker = LabeledDropdown(bar, "GST Case", [""], "", width=400,
                                           command=lambda _v: self._load_case())
        self.case_picker.pack(side="left", padx=(0, 14))
        self.issue_picker = LabeledDropdown(bar, "Scope", [ALL_ISSUES], ALL_ISSUES,
                                            width=320,
                                            command=lambda _v: self._load_requirements())
        self.issue_picker.pack(side="left")

        ai_button(bar, "Generate Client Requirement", self._generate,
                  width=230).pack(side="right")

        DisclaimerBanner(self.body, config.AI_DISCLAIMER).pack(fill="x", pady=(0, 8))

        # -- status strip ------------------------------------------------------
        self.stats_bar = ctk.CTkFrame(self.body, fg_color="transparent",
                                      width=1, height=1)
        self.stats_bar.pack(fill="x", pady=(0, 8))

        # -- table -------------------------------------------------------------
        table_card = Card(self.body, "Requirement List",
                          "Double-click a row to update its status")
        table_card.pack(fill="both", expand=True)

        toolbar = ctk.CTkFrame(table_card, fg_color="transparent")
        toolbar.pack(fill="x", padx=14, pady=(10, 0))
        primary_button(toolbar, "+ Add Item", self._add_item, width=110).pack(side="left")
        secondary_button(toolbar, "Edit", self._edit_item, width=80).pack(
            side="left", padx=6)
        secondary_button(toolbar, "Mark Received", self._mark_received,
                         width=130).pack(side="left")
        secondary_button(toolbar, "Mark Pending", self._mark_pending,
                         width=120).pack(side="left", padx=6)
        danger_button(toolbar, "Delete", self._delete_item, width=90).pack(side="left")

        secondary_button(toolbar, "Export PDF",
                         lambda: self._export("pdf"), width=105).pack(side="right")
        secondary_button(toolbar, "Export Word",
                         lambda: self._export("word"), width=110).pack(
            side="right", padx=6)
        secondary_button(toolbar, "Export Excel",
                         lambda: self._export("excel"), width=110).pack(side="right")

        self.table = DataTable(table_card, REQUIREMENT_COLUMNS,
                               on_double_click=self._edit_item, height=14)
        self.table.pack(fill="both", expand=True, padx=14, pady=(10, 8))

        note_bar = ctk.CTkFrame(table_card, fg_color="transparent")
        note_bar.pack(fill="x", padx=14, pady=(0, 12))
        secondary_button(note_bar, "Covering Note", self._show_covering_note,
                         width=130).pack(side="left")
        secondary_button(note_bar, "Clear All", self._clear_all, width=100).pack(
            side="left", padx=6)
        self.source_label = ctk.CTkLabel(note_bar, text="", font=font(10),
                                         text_color=Theme.TEXT_MUTED)
        self.source_label.pack(side="right")

    # ==================================================================
    def refresh(self) -> None:
        try:
            cases = db.list_cases()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._case_lookup = {_case_label(c): c["id"] for c in cases}
        values = list(self._case_lookup) or ["(no cases yet)"]
        self.case_picker.set_values(values, keep=True)

        target = self.context.pop("case_id", None) or getattr(self.app, "selected_case_id", None)
        if target:
            for label, case_id in self._case_lookup.items():
                if case_id == target:
                    self.case_picker.set(label)
                    break
        elif self.case_picker.get() not in values and values:
            self.case_picker.set(values[0])

        self._load_case()

        preset_issue = self.context.pop("issue_id", None)
        if preset_issue:
            for label, issue_id in getattr(self, "_issue_lookup", {}).items():
                if issue_id == preset_issue:
                    self.issue_picker.set(label)
                    self._load_requirements()
                    break

    def _case_id(self) -> Optional[int]:
        return self._case_lookup.get(self.case_picker.get())

    def _load_case(self) -> None:
        case_id = self._case_id()
        if not case_id:
            self._case = None
            self.table.clear()
            self.issue_picker.set_values([ALL_ISSUES], keep=False)
            self._render_stats([])
            return

        self._case = db.get_case(int(case_id))
        self.app.selected_case_id = int(case_id)
        self._issues = db.list_issues(int(case_id))

        self._issue_lookup = {
            f"Issue {i.get('issue_no')}: {truncate(i.get('title'), 45)}": i["id"]
            for i in self._issues
        }
        self.issue_picker.set_values([ALL_ISSUES] + list(self._issue_lookup), keep=True)
        self._load_requirements()

    def _selected_issue_id(self) -> Optional[int]:
        label = self.issue_picker.get()
        if not label or label == ALL_ISSUES:
            return None
        return getattr(self, "_issue_lookup", {}).get(label)

    def _load_requirements(self) -> None:
        if not self._case:
            return
        issue_id = self._selected_issue_id()
        rows = db.list_requirements(int(self._case["id"]), issue_id)

        display: List[Dict[str, Any]] = []
        for index, row in enumerate(rows, start=1):
            display.append({
                "id": row["id"],
                "sr": index,
                "document_name": row.get("document_name", ""),
                "purpose_short": truncate(row.get("purpose"), 80),
                "requirement_type": row.get("requirement_type", ""),
                "status": row.get("status", ""),
                "received_display": format_date(row.get("received_date"), "-"),
                "issue_display": (f"#{row.get('issue_no')}" if row.get("issue_no")
                                  else "Case"),
                "remarks_short": truncate(row.get("remarks"), 60),
            })
        self.table.load(display, tag_fn=lambda r: {
            "Received": "success", "Pending": "warning",
            "Clarification Required": "danger", "Not Applicable": "muted",
        }.get(r["status"], ""))
        self._render_stats(rows)
        self.status(f"{len(rows)} requirement(s) listed")

    def _render_stats(self, rows: List[Dict[str, Any]]) -> None:
        for child in self.stats_bar.winfo_children():
            child.destroy()
        if not rows:
            ctk.CTkLabel(
                self.stats_bar,
                text="No requirements recorded yet. Use 'Generate Client Requirement' "
                     "to produce a checklist tailored to the allegation, or add items "
                     "manually.",
                font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
            ).pack(anchor="w")
            return

        stats = requirement_service.requirement_stats(rows)
        percent = requirement_service.completion_percentage(rows)
        chips = [
            ("Total", stats["Total"], Theme.PRIMARY, Theme.INFO_BG),
            ("Pending", stats.get("Pending", 0), Theme.WARNING, Theme.WARNING_BG),
            ("Received", stats.get("Received", 0), Theme.SUCCESS, Theme.SUCCESS_BG),
            ("Clarification Required", stats.get("Clarification Required", 0),
             Theme.DANGER, Theme.DANGER_BG),
            ("Not Applicable", stats.get("Not Applicable", 0),
             Theme.NEUTRAL, Theme.NEUTRAL_BG),
            ("Mandatory Pending", stats.get("Mandatory Pending", 0),
             Theme.DANGER, Theme.DANGER_BG),
        ]
        for label, value, fg, bg in chips:
            chip = ctk.CTkFrame(self.stats_bar, fg_color=bg, corner_radius=5)
            chip.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(chip, text=f"{label}: {value}", font=font(11, "bold"),
                         text_color=fg).pack(padx=12, pady=5)

        progress = ctk.CTkFrame(self.stats_bar, fg_color="transparent")
        progress.pack(side="right")
        ctk.CTkLabel(progress, text=f"Collection progress: {percent}%",
                     font=font(11, "bold"),
                     text_color=Theme.SUCCESS if percent >= 80 else Theme.TEXT_MUTED
                     ).pack(side="right")

    # ==================================================================
    def _require_case(self) -> bool:
        if not self._case:
            show_warning(self, "No case selected", "Please select a GST case first.")
            return False
        return True

    def _generate(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return

        issue_id = self._selected_issue_id()
        issues = ([i for i in self._issues if i["id"] == issue_id] if issue_id
                  else self._issues)
        if not issues and not self._issues:
            show_warning(
                self, "No issues recorded",
                "No issues have been recorded against this case yet.\n\n"
                "Run the notice analysis first so the checklist can be tailored to "
                "the actual allegations. A general checklist will otherwise be "
                "produced.")

        existing = db.list_requirements(int(self._case["id"]), issue_id)
        if existing:
            confirm_action(
                self, "Existing requirements",
                f"{len(existing)} requirement(s) already exist for this scope.\n\n"
                "Replace them with a newly generated list, or keep them and append?",
                lambda: self._run_generation(issues, issue_id, replace=True),
                confirm_text="Replace", kind="warning",
            )
        else:
            self._run_generation(issues, issue_id, replace=False)

    def _run_generation(self, issues: List[Dict[str, Any]],
                        issue_id: Optional[int], replace: bool) -> None:
        case = dict(self._case or {})
        demo = self.app.demo_mode
        payload_issues = [dict(i) for i in issues]
        message = ("Preparing sample checklist (Demo Mode - the API is not called)..."
                   if demo else "Preparing the requirement list with Gemini...")
        busy = BusyDialog(self, "Generating requirements", message)

        def work():
            return requirement_service.generate_requirements(
                case, payload_issues, demo_mode=demo)

        def done(result: requirement_service.RequirementResult) -> None:
            if not result.ok:
                self.status("Requirement generation failed", "danger")
                show_error(self, "Could not generate requirements", result.error)
                return
            try:
                added = requirement_service.save_requirements(
                    int(case["id"]), issue_id, result, replace=replace)
            except db.DatabaseError as exc:
                show_error(self, "Could not save", str(exc))
                return

            if result.covering_note:
                self._covering_note = result.covering_note
            self._load_requirements()
            self.source_label.configure(text=f"Source: {result.source}")
            self.status(f"{added} requirement(s) generated", "success")
            show_success(
                self, "Requirements generated",
                f"{added} item(s) added to the requirement list.\n\n"
                "Review the list, remove anything that does not apply, then export "
                "it for the client.")

        def failed(exc: Exception) -> None:
            log.exception("Requirement generation failed")
            show_error(self, "Generation failed", str(exc))

        run_in_background(self, work, done, failed, busy)

    # ==================================================================
    def _add_item(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        RequirementDialog(self, case_id=int(self._case["id"]),
                          issue_choices=getattr(self, "_issue_lookup", {}),
                          default_issue_id=self._selected_issue_id(),
                          on_saved=self._load_requirements)

    def _edit_item(self, _row=None) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        record_id = self.table.selected_int_id()
        if not record_id:
            show_warning(self, "No row selected", "Please select a requirement first.")
            return
        record = next((r for r in db.list_requirements(int(self._case["id"]))
                       if int(r["id"]) == record_id), None)
        if record:
            RequirementDialog(self, case_id=int(self._case["id"]),
                              issue_choices=getattr(self, "_issue_lookup", {}),
                              record=record, on_saved=self._load_requirements)

    def _set_status(self, status: str, with_date: bool = False) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        record_id = self.table.selected_int_id()
        if not record_id:
            show_warning(self, "No row selected", "Please select a requirement first.")
            return
        from datetime import date

        payload: Dict[str, Any] = {"status": status}
        payload["received_date"] = date.today().isoformat() if with_date else ""
        db.update_requirement(record_id, payload)
        self._load_requirements()
        self.status(f"Requirement marked '{status}'", "success")

    def _mark_received(self) -> None:
        self._set_status("Received", with_date=True)

    def _mark_pending(self) -> None:
        self._set_status("Pending")

    def _delete_item(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        record_id = self.table.selected_int_id()
        if not record_id:
            show_warning(self, "No row selected", "Please select a requirement first.")
            return

        def do_delete() -> None:
            db.delete_requirement(record_id)
            self._load_requirements()
            self.status("Requirement deleted", "success")

        confirm_action(self, "Delete requirement",
                       "Remove this item from the requirement list?",
                       do_delete, confirm_text="Delete")

    def _clear_all(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        issue_id = self._selected_issue_id()
        rows = db.list_requirements(int(self._case["id"]), issue_id)
        if not rows:
            show_info(self, "Nothing to clear", "There are no requirements in this scope.")
            return

        def do_clear() -> None:
            for row in rows:
                db.delete_requirement(int(row["id"]))
            self._load_requirements()
            self.status("Requirement list cleared", "success")

        confirm_action(self, "Clear requirement list",
                       f"Delete all {len(rows)} requirement(s) in the current scope?",
                       do_clear, confirm_text="Clear all")

    # ==================================================================
    def _export(self, fmt: str) -> None:
        if not self._require_case():
            return
        rows = db.list_requirements(int(self._case["id"]), self._selected_issue_id())
        if not rows:
            show_warning(self, "Nothing to export",
                         "There are no requirements to export in this scope.")
            return

        ok, message = export_service.export_requirements(
            rows, self._case, fmt=fmt, covering_note=self._covering_note)
        if not ok:
            show_error(self, "Export failed", message)
            return

        self.status(f"Exported to {message}", "success")
        ExportDoneDialog(self, message)

    def _show_covering_note(self) -> None:
        CoveringNoteDialog(self, self._covering_note, self._set_covering_note)

    def _set_covering_note(self, text: str) -> None:
        self._covering_note = text
        self.status("Covering note updated", "success")


def _case_label(case: Dict[str, Any]) -> str:
    return (f"{case.get('case_code', '')} - {case.get('client_name', '')} "
            f"({case.get('notice_type', '')}, FY {case.get('financial_year') or '-'})")


class RequirementDialog(ModalDialog):
    """Add / edit one requirement."""

    def __init__(self, parent, case_id: int, issue_choices: Dict[str, int],
                 record: Optional[Dict[str, Any]] = None,
                 default_issue_id: Optional[int] = None, on_saved=None):
        title = "Edit Requirement" if record else "Add Requirement"
        super().__init__(parent, title, width=620, height=560)
        self._case_id = case_id
        self._record = record
        self._issue_choices = issue_choices
        self._on_saved = on_saved

        body = ctk.CTkScrollableFrame(self, fg_color=Theme.BG,
                                      scrollbar_button_color=Theme.BORDER)
        body.pack(fill="both", expand=True, padx=18, pady=14)

        ctk.CTkLabel(body, text=title, font=font(16, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w", pady=(0, 10))

        r = record or {}
        self.document_name = LabeledEntry(body, "Document / Information Required",
                                          r.get("document_name", ""), required=True,
                                          width=540)
        self.document_name.pack(fill="x")
        self.purpose = LabeledTextbox(body, "Purpose", r.get("purpose", ""), height=70)
        self.purpose.pack(fill="x", pady=(0, 6))

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")
        self.requirement_type = LabeledDropdown(
            row, "Type", config.REQUIREMENT_TYPES,
            r.get("requirement_type", "Mandatory"), width=180)
        self.requirement_type.pack(side="left", padx=(0, 12))
        self.status_field = LabeledDropdown(
            row, "Status", config.REQUIREMENT_STATUSES,
            r.get("status", "Pending"), width=200)
        self.status_field.pack(side="left", padx=(0, 12))
        self.received_date = LabeledEntry(row, "Received On",
                                          format_date(r.get("received_date"), ""),
                                          placeholder="DD-MM-YYYY", width=140)
        self.received_date.pack(side="left")

        issue_labels = ["(whole case)"] + list(issue_choices)
        current_label = "(whole case)"
        target = r.get("issue_id") or default_issue_id
        for label, issue_id in issue_choices.items():
            if issue_id == target:
                current_label = label
                break
        self.issue_field = LabeledDropdown(body, "Linked Issue", issue_labels,
                                           current_label, width=540)
        self.issue_field.pack(fill="x", pady=(6, 0))

        self.remarks = LabeledTextbox(body, "Remarks", r.get("remarks", ""), height=70)
        self.remarks.pack(fill="x", pady=(0, 6))

        footer = ctk.CTkFrame(self, fg_color=Theme.SURFACE, height=58, corner_radius=0)
        footer.pack(fill="x", side="bottom")
        primary_button(footer, "Save", self._save, width=120).pack(
            side="right", padx=16, pady=12)
        secondary_button(footer, "Cancel", self.close, width=100).pack(
            side="right", pady=12)

    def _save(self) -> None:
        name = self.document_name.get()
        if not name:
            show_error(self, "Missing information",
                       "Please enter the document or information required.")
            return

        payload = {
            "document_name": name,
            "purpose": self.purpose.get(),
            "requirement_type": self.requirement_type.get(),
            "status": self.status_field.get(),
            "received_date": to_iso_date(self.received_date.get()),
            "remarks": self.remarks.get(),
            "issue_id": self._issue_choices.get(self.issue_field.get()),
        }
        try:
            if self._record:
                db.update_requirement(int(self._record["id"]), payload)
            else:
                db.create_requirement(self._case_id, payload)
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return

        callback = self._on_saved
        self.close()
        if callback:
            callback()


class CoveringNoteDialog(ModalDialog):
    """Edit the covering note that accompanies the exported requirement list."""

    def __init__(self, parent, note: str, on_save):
        super().__init__(parent, "Covering note for the client", width=640, height=420)
        self._on_save = on_save

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text="Covering note", font=font(15, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text="This note is included at the top of the Word export of the "
                 "requirement list.",
            font=font(11), text_color=Theme.TEXT_MUTED, wraplength=560,
            justify="left").pack(anchor="w", pady=(2, 10))

        self.text = LabeledTextbox(body, "", note, height=200)
        self.text.pack(fill="both", expand=True)

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Save note", self._save, width=130).pack(side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _save(self) -> None:
        value = self.text.get()
        callback = self._on_save
        self.close()
        callback(value)


class ExportDoneDialog(ModalDialog):
    """Confirms an export and offers to open the file."""

    def __init__(self, parent, path: str):
        super().__init__(parent, "Export complete", width=560, height=250,
                         resizable=False)
        self._path = path

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=22, pady=18)
        ctk.CTkLabel(body, text="Export complete", font=font(15, "bold"),
                     text_color=Theme.SUCCESS).pack(anchor="w")
        ctk.CTkLabel(body, text="The file has been written to:", font=font(11),
                     text_color=Theme.TEXT_MUTED).pack(anchor="w", pady=(6, 2))
        ctk.CTkLabel(body, text=path, font=font(11), text_color=Theme.TEXT,
                     wraplength=500, justify="left").pack(anchor="w")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(16, 0))
        primary_button(buttons, "Open file", self._open, width=120).pack(side="right")
        secondary_button(buttons, "Open folder", self._open_folder,
                         width=120).pack(side="right", padx=8)
        secondary_button(buttons, "Close", self.close, width=90).pack(side="right")

    def _open(self) -> None:
        open_in_explorer(self._path)
        self.close()

    def _open_folder(self) -> None:
        open_in_explorer(config.EXPORT_DIR)
        self.close()
