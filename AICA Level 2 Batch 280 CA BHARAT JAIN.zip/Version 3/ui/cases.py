"""
ui.cases
========
GST Case master: every case is linked to a client and carries the notice
particulars, assignment, risk, status and workflow stage.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from ui.base_page import BasePage
from ui.widgets import (
    Card, DataTable, DetailGrid, LabeledDropdown, LabeledEntry, LabeledTextbox,
    ModalDialog, SearchBar, confirm_action, danger_button, font, primary_button,
    secondary_button, show_error, show_success, show_warning,
)
from utils.calculations import compute_demand, deadline_label, deadline_severity
from utils.formatters import (
    format_currency, format_currency_short, format_date, to_iso_date, truncate,
)
from utils.logger import get_logger
from utils.validators import validate_case_form

log = get_logger(__name__)

CASE_COLUMNS = [
    ("case_code", "Case ID", 110, "w"),
    ("client_name", "Client", 190, "w"),
    ("notice_type", "Notice Type", 100, "w"),
    ("notice_number", "Notice No.", 130, "w"),
    ("financial_year", "FY", 75, "center"),
    ("notice_date_display", "Notice Date", 95, "center"),
    ("due_date_display", "Due Date", 95, "center"),
    ("deadline_display", "Deadline", 120, "w"),
    ("exposure_display", "Exposure", 105, "e"),
    ("risk_level", "Risk", 85, "center"),
    ("status", "Status", 120, "w"),
    ("assigned_team_member", "Assigned To", 130, "w"),
    ("demo_display", "Demo", 90, "center"),
]

ALL = "All"


class CasesPage(BasePage):
    """GST case master screen."""

    title = "GST Cases"
    subtitle = "Notice-wise litigation matters, deadlines and demand exposure"

    def build(self) -> None:
        self._search_text = ""

        primary_button(self.header_actions, "+ New Case", self._add_case,
                       width=130).pack(side="right")
        secondary_button(self.header_actions, "Refresh", self.refresh,
                         width=90).pack(side="right", padx=(0, 8))

        filters = Card(self.body)
        filters.pack(fill="x", pady=(0, 10))
        row1 = ctk.CTkFrame(filters, fg_color="transparent")
        row1.pack(fill="x", padx=14, pady=(12, 4))

        SearchBar(row1, "Search client, GSTIN, case ID, notice number, section...",
                  self._on_search, width=400).pack(side="left")
        self.count_label = ctk.CTkLabel(row1, text="", font=font(11),
                                        text_color=Theme.TEXT_MUTED)
        self.count_label.pack(side="right")

        row2 = ctk.CTkFrame(filters, fg_color="transparent")
        row2.pack(fill="x", padx=14, pady=(0, 12))

        self.client_filter = LabeledDropdown(row2, "Client", [ALL], ALL, width=200,
                                             command=lambda _v: self.refresh())
        self.client_filter.pack(side="left", padx=(0, 10))
        self.status_filter = LabeledDropdown(row2, "Status", [ALL] + config.CASE_STATUSES,
                                             ALL, width=150,
                                             command=lambda _v: self.refresh())
        self.status_filter.pack(side="left", padx=(0, 10))
        self.risk_filter = LabeledDropdown(row2, "Risk", [ALL] + config.RISK_LEVELS,
                                           ALL, width=140,
                                           command=lambda _v: self.refresh())
        self.risk_filter.pack(side="left", padx=(0, 10))
        self.type_filter = LabeledDropdown(row2, "Notice Type", [ALL] + config.NOTICE_TYPES,
                                           ALL, width=140,
                                           command=lambda _v: self.refresh())
        self.type_filter.pack(side="left", padx=(0, 10))
        self.fy_filter = LabeledDropdown(row2, "Financial Year",
                                         [ALL] + config.FINANCIAL_YEARS, ALL, width=130,
                                         command=lambda _v: self.refresh())
        self.fy_filter.pack(side="left", padx=(0, 10))

        open_box = ctk.CTkFrame(row2, fg_color="transparent")
        open_box.pack(side="left", padx=(6, 0))
        ctk.CTkLabel(open_box, text=" ", font=font(11)).pack()
        self.open_switch = ctk.CTkSwitch(open_box, text="Open cases only",
                                         font=font(11), text_color=Theme.TEXT,
                                         command=self.refresh,
                                         progress_color=Theme.PRIMARY)
        self.open_switch.pack()

        split = ctk.CTkFrame(self.body, fg_color="transparent")
        split.pack(fill="both", expand=True)
        split.grid_columnconfigure(0, weight=3)
        split.grid_columnconfigure(1, weight=2)
        split.grid_rowconfigure(0, weight=1)

        self.table = DataTable(split, CASE_COLUMNS, on_select=self._on_select,
                               on_double_click=self._edit_case, height=16)
        self.table.grid(row=0, column=0, sticky="nsew", padx=(0, 12))

        self.detail_card = Card(split, "Case Details")
        self.detail_card.grid(row=0, column=1, sticky="nsew")

        self.detail_body = ctk.CTkScrollableFrame(
            self.detail_card, fg_color="transparent",
            scrollbar_button_color=Theme.BORDER)
        self.detail_body.pack(fill="both", expand=True, padx=14, pady=12)
        self.detail_grid = DetailGrid(self.detail_body, columns=1)
        self.detail_grid.pack(fill="x")
        self.detail_placeholder = ctk.CTkLabel(
            self.detail_body,
            text="Select a case to view its particulars,\ndemand summary and next actions.",
            font=font(12), text_color=Theme.TEXT_MUTED, justify="center")
        self.detail_placeholder.pack(pady=40)

        self.detail_actions = ctk.CTkFrame(self.detail_card, fg_color="transparent",
                                           width=1, height=1)
        self.detail_actions.pack(fill="x", padx=14, pady=(0, 12))

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        try:
            clients = db.list_clients()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._client_lookup = {c["client_name"]: c["id"] for c in clients}
        self.client_filter.set_values([ALL] + sorted(self._client_lookup))

        preset_client = self.context.pop("client_id", None)
        if preset_client:
            for name, cid in self._client_lookup.items():
                if cid == preset_client:
                    self.client_filter.set(name)
                    break

        filters: Dict[str, Any] = {"search": self._search_text}
        chosen_client = self.client_filter.get()
        if chosen_client and chosen_client != ALL:
            filters["client_id"] = self._client_lookup.get(chosen_client)
        for key, widget in (("status", self.status_filter), ("risk_level", self.risk_filter),
                            ("notice_type", self.type_filter),
                            ("financial_year", self.fy_filter)):
            value = widget.get()
            if value and value != ALL:
                filters[key] = value
        if self.open_switch.get():
            filters["open_only"] = True

        # Non-admin users only see matters they are assigned to.
        from utils.helpers import can_see_all_matters

        if not can_see_all_matters(self.user_role) and self.user_name:
            filters["assigned_to"] = self.user_name

        cases = db.list_cases(filters)
        alert_days = int(self.app.settings.get("deadline_alert_days", 7))

        rows: List[Dict[str, Any]] = []
        for case in cases:
            row = dict(case)
            demand = compute_demand(case)
            row["notice_date_display"] = format_date(case.get("notice_date"), "-")
            row["due_date_display"] = format_date(case.get("due_date"), "-")
            row["deadline_display"] = deadline_label(case.get("due_date"))
            row["exposure_display"] = format_currency_short(demand.total_exposure)
            row["_severity"] = deadline_severity(case.get("due_date"), alert_days)
            row["demo_display"] = _demo_label(case)
            rows.append(row)

        self.table.load(rows, tag_fn=_case_tag)
        self.count_label.configure(text=f"{len(rows)} case(s)")
        self.status(f"{len(rows)} case(s) listed")

        preset_case = self.context.pop("case_id", None)
        if preset_case:
            self.table.select_by_id(preset_case)

    def _on_search(self, text: str) -> None:
        self._search_text = text
        self.refresh()

    # ------------------------------------------------------------------
    def _on_select(self, row: Optional[Dict[str, Any]]) -> None:
        for child in self.detail_actions.winfo_children():
            child.destroy()
        for child in list(self.detail_body.winfo_children()):
            if child is not self.detail_grid and child is not self.detail_placeholder:
                child.destroy()
        self.detail_grid.reset()

        if not row:
            self.detail_placeholder.pack(pady=40)
            return
        self.detail_placeholder.pack_forget()

        case = db.get_case(int(row["id"]))
        if not case:
            return
        self.app.selected_case_id = int(case["id"])

        demand = compute_demand(case)
        severity = deadline_severity(case.get("due_date"),
                                     int(self.app.settings.get("deadline_alert_days", 7)))
        severity_colour = {
            "overdue": Theme.DANGER, "urgent": Theme.DANGER,
            "soon": Theme.WARNING, "normal": Theme.SUCCESS,
        }.get(severity, Theme.TEXT_MUTED)

        grid = self.detail_grid
        grid.add("Case ID", case.get("case_code", "-"), bold=True)
        grid.add("Client", case.get("client_name", "-"), bold=True)
        grid.add("Client GSTIN", case.get("client_gstin") or "-")
        grid.add("Notice Type", case.get("notice_type") or "-")
        grid.add("Notice Number", case.get("notice_number") or "-")
        grid.add("Financial Year", case.get("financial_year") or "-")
        grid.add("Tax Period", case.get("tax_period") or "-")
        grid.add("Notice Date", format_date(case.get("notice_date")))
        grid.add("Reply Due Date", format_date(case.get("due_date")))
        grid.add("Deadline", deadline_label(case.get("due_date")),
                 value_color=severity_colour, bold=True)
        grid.add("Sections Invoked", case.get("sections") or "-")
        grid.add("Officer / Authority", case.get("officer") or "-")
        grid.add("Jurisdiction", case.get("jurisdiction") or "-")
        grid.add("Risk Level", case.get("risk_level") or "-",
                 value_color=_risk_colour(case.get("risk_level")), bold=True)
        grid.add("Status", case.get("status") or "-", bold=True)
        grid.add("Current Stage", case.get("stage") or "-")
        grid.add("Assigned Partner", case.get("assigned_partner") or "-")
        grid.add("Assigned Manager", case.get("assigned_manager") or "-")
        grid.add("Assigned Team Member", case.get("assigned_team_member") or "-")
        grid.add("Next Action", case.get("next_action") or "-")
        grid.add("Next Action Date", format_date(case.get("next_action_date")))
        grid.add("Issues Identified", str(case.get("issue_count") or 0))
        if case.get("is_demo"):
            grid.add("Record type",
                     "Featured demonstration case"
                     if case.get("demo_tag") == "featured" else "Demonstration case",
                     value_color=Theme.WARNING, bold=True)
        grid.add("Notice PDF",
                 "Uploaded" if case.get("uploaded_file") else "Not uploaded",
                 value_color=Theme.SUCCESS if case.get("uploaded_file") else Theme.TEXT_MUTED)
        if case.get("notes"):
            grid.add_full("Notes", truncate(case["notes"], 300), wraplength=380)

        # Demand summary block
        box = ctk.CTkFrame(self.detail_body, fg_color=Theme.SURFACE_ALT, corner_radius=6)
        box.pack(fill="x", pady=(14, 0))
        ctk.CTkLabel(box, text="DEMAND SUMMARY", font=font(10, "bold"),
                     text_color=Theme.TEXT_MUTED).pack(anchor="w", padx=12, pady=(10, 4))
        for label, amount, is_total in demand.rows():
            line = ctk.CTkFrame(box, fg_color="transparent")
            line.pack(fill="x", padx=12, pady=1)
            ctk.CTkLabel(line, text=label,
                         font=font(11, "bold" if is_total else "normal"),
                         text_color=Theme.TEXT if is_total else Theme.TEXT_MUTED,
                         anchor="w").pack(side="left")
            ctk.CTkLabel(line, text=format_currency(amount),
                         font=font(11, "bold" if is_total else "normal"),
                         text_color=Theme.DANGER if is_total else Theme.TEXT,
                         anchor="e").pack(side="right")
        ctk.CTkLabel(box, text="Computed in Python from the extracted components",
                     font=font(9), text_color=Theme.TEXT_MUTED).pack(
            anchor="w", padx=12, pady=(4, 10))

        case_id = int(case["id"])
        primary_button(self.detail_actions, "Edit",
                       lambda: self._edit_case(row), width=70).pack(side="left")
        secondary_button(self.detail_actions, "View Notice",
                         lambda: self._view_notice(case), width=100).pack(side="left")
        secondary_button(self.detail_actions, "Analyse Notice",
                         lambda: self.navigate("notice", case_id=case_id),
                         width=120).pack(side="left", padx=5)
        secondary_button(self.detail_actions, "Issues",
                         lambda: self.navigate("issues", case_id=case_id),
                         width=70).pack(side="left")
        secondary_button(self.detail_actions, "Draft",
                         lambda: self.navigate("draft", case_id=case_id),
                         width=70).pack(side="left", padx=5)
        danger_button(self.detail_actions, "Delete",
                      lambda: self._delete_case(case), width=70).pack(side="right")

    # ------------------------------------------------------------------
    def _view_notice(self, case: Dict[str, Any]) -> None:
        """Open the notice PDF held against the case in the default viewer."""
        from utils.helpers import open_in_explorer, resolve_stored_path

        stored = case.get("uploaded_file")
        if not stored:
            show_warning(self, "No notice on record",
                         "No notice PDF has been uploaded for this case.\n\n"
                         "Use Upload / Analyse Notice to attach one.")
            return
        path = resolve_stored_path(stored)
        if not path.exists():
            show_error(self, "File missing",
                       f"The notice file could not be found:\n{path}")
            return
        if not open_in_explorer(path):
            show_error(self, "Could not open",
                       f"Windows could not open the file:\n{path}")
        else:
            self.status(f"Opened {path.name}", "success")

    def _add_case(self) -> None:
        if self.block_if_readonly():
            return
        if not db.list_clients():
            show_warning(self, "No clients yet",
                         "Please create a client before adding a GST case.\n\n"
                         "Go to Clients > Add Client, or load the demo data from Settings.")
            return
        CaseFormDialog(self, on_saved=self._after_save)

    def _edit_case(self, row: Optional[Dict[str, Any]]) -> None:
        if not row:
            show_warning(self, "No case selected", "Please select a case first.")
            return
        if self.block_if_readonly():
            return
        case = db.get_case(int(row["id"]))
        if case:
            CaseFormDialog(self, case=case, on_saved=self._after_save)

    def _delete_case(self, case: Dict[str, Any]) -> None:
        if self.block_if_readonly():
            return

        def do_delete() -> None:
            try:
                db.delete_case(int(case["id"]))
                db.log_activity("Case deleted", case.get("case_code", ""),
                                user_name=self.user_name)
                self.status(f"Case {case.get('case_code')} deleted", "success")
                self._after_save()
            except db.DatabaseError as exc:
                show_error(self, "Delete failed", str(exc))

        confirm_action(
            self, "Delete case",
            f"Delete case {case.get('case_code')} ({case.get('notice_type')})?\n\n"
            "Its analysis, issues, requirements, research and drafts will also be "
            "deleted. This cannot be undone.",
            do_delete, confirm_text="Delete",
        )

    def _after_save(self) -> None:
        self.refresh()
        for key in ("dashboard", "clients", "notice", "issues", "requirements",
                    "draft", "reports"):
            self.app.refresh_page(key)


def _demo_label(case: Dict[str, Any]) -> str:
    """Mark demonstration records so they are never mistaken for real matters."""
    if not case.get("is_demo"):
        return ""
    return "* Featured" if case.get("demo_tag") == "featured" else "Demo"


def _risk_colour(risk: Optional[str]) -> str:
    return {"High": Theme.DANGER, "Medium": Theme.WARNING,
            "Low": Theme.SUCCESS}.get(risk or "", Theme.INFO)


def _case_tag(row: Dict[str, Any]) -> str:
    severity = row.get("_severity")
    if severity in ("overdue", "urgent"):
        return "danger"
    if severity == "soon":
        return "warning"
    if row.get("status") == "Closed":
        return "muted"
    return ""


class CaseFormDialog(ModalDialog):
    """Add / edit GST case."""

    def __init__(self, parent, case: Optional[Dict[str, Any]] = None, on_saved=None,
                 preset_client_id: Optional[int] = None):
        self._case = case
        self._on_saved = on_saved
        title = "Edit GST Case" if case else "New GST Case"
        super().__init__(parent, title, width=880, height=760)

        header = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0, height=56)
        header.pack(fill="x")
        ctk.CTkLabel(header, text=title, font=font(17, "bold"),
                     text_color=Theme.TEXT).pack(side="left", padx=20, pady=14)
        if case:
            ctk.CTkLabel(header, text=case.get("case_code", ""), font=font(12),
                         text_color=Theme.TEXT_MUTED).pack(side="left")

        body = ctk.CTkScrollableFrame(self, fg_color=Theme.BG,
                                      scrollbar_button_color=Theme.BORDER)
        body.pack(fill="both", expand=True, padx=16, pady=12)

        clients = db.list_clients()
        self._client_lookup = {
            f"{c['client_name']}  [{c.get('client_code', '')}]": c["id"] for c in clients
        }
        c = case or {}
        current_client = ""
        target_client_id = c.get("client_id") or preset_client_id
        for label, cid in self._client_lookup.items():
            if cid == target_client_id:
                current_client = label
                break

        grid = ctk.CTkFrame(body, fg_color="transparent")
        grid.pack(fill="both", expand=True)
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1, uniform="col")

        members = [""] + db.team_member_names()
        row = 0

        self.client = LabeledDropdown(grid, "Client", list(self._client_lookup) or [""],
                                      current_client, width=250)
        self.client.grid(row=row, column=0, columnspan=2, sticky="ew", padx=(0, 10), pady=2)
        self.notice_type = LabeledDropdown(grid, "Notice Type", config.NOTICE_TYPES,
                                           c.get("notice_type", "DRC-01"), width=250)
        self.notice_type.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.notice_number = LabeledEntry(grid, "Notice Number",
                                          c.get("notice_number", ""), width=250)
        self.notice_number.grid(row=row, column=0, sticky="ew", padx=(0, 10), pady=2)
        self.financial_year = LabeledDropdown(grid, "Financial Year",
                                              [""] + config.FINANCIAL_YEARS,
                                              c.get("financial_year", ""), width=250)
        self.financial_year.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=2)
        self.tax_period = LabeledEntry(grid, "Tax Period", c.get("tax_period", ""),
                                       placeholder="e.g. Apr 2022 - Mar 2023", width=250)
        self.tax_period.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.notice_date = LabeledEntry(grid, "Notice Date",
                                        format_date(c.get("notice_date"), ""),
                                        placeholder="DD-MM-YYYY", width=250)
        self.notice_date.grid(row=row, column=0, sticky="ew", padx=(0, 10), pady=2)
        self.due_date = LabeledEntry(grid, "Reply Due Date",
                                     format_date(c.get("due_date"), ""),
                                     placeholder="DD-MM-YYYY", width=250)
        self.due_date.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=2)
        self.sections = LabeledEntry(grid, "Section(s) Invoked", c.get("sections", ""),
                                     placeholder="e.g. Section 73, Section 16(2)(c)",
                                     width=250)
        self.sections.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.officer = LabeledEntry(grid, "Officer / Authority", c.get("officer", ""),
                                    width=250)
        self.officer.grid(row=row, column=0, sticky="ew", padx=(0, 10), pady=2)
        self.jurisdiction = LabeledEntry(grid, "Jurisdiction", c.get("jurisdiction", ""),
                                         width=250)
        self.jurisdiction.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=2)
        self.risk_level = LabeledDropdown(grid, "Risk Level", config.RISK_LEVELS,
                                          c.get("risk_level", "Review Required"), width=250)
        self.risk_level.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.assigned_partner = LabeledDropdown(grid, "Assigned Partner", members,
                                                c.get("assigned_partner", ""), width=250)
        self.assigned_partner.grid(row=row, column=0, sticky="ew", padx=(0, 10), pady=2)
        self.assigned_manager = LabeledDropdown(grid, "Assigned Manager", members,
                                                c.get("assigned_manager", ""), width=250)
        self.assigned_manager.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=2)
        self.assigned_team_member = LabeledDropdown(grid, "Assigned Team Member", members,
                                                    c.get("assigned_team_member", ""),
                                                    width=250)
        self.assigned_team_member.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.status_field = LabeledDropdown(grid, "Status", config.CASE_STATUSES,
                                            c.get("status", "New"), width=250)
        self.status_field.grid(row=row, column=0, sticky="ew", padx=(0, 10), pady=2)
        self.stage = LabeledDropdown(grid, "Current Stage", config.CASE_STAGES,
                                     c.get("stage", "Notice Received"), width=250)
        self.stage.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=2)
        self.next_action_date = LabeledEntry(grid, "Next Action Date",
                                             format_date(c.get("next_action_date"), ""),
                                             placeholder="DD-MM-YYYY", width=250)
        self.next_action_date.grid(row=row, column=2, sticky="ew", pady=2)
        row += 1

        self.next_action = LabeledEntry(grid, "Next Action", c.get("next_action", ""),
                                        placeholder="e.g. Obtain reconciliation from client",
                                        width=250)
        self.next_action.grid(row=row, column=0, columnspan=3, sticky="ew", pady=2)
        row += 1

        self.notes = LabeledTextbox(grid, "Notes", c.get("notes", ""), height=90)
        self.notes.grid(row=row, column=0, columnspan=3, sticky="ew", pady=(6, 2))

        footer = ctk.CTkFrame(self, fg_color=Theme.SURFACE, corner_radius=0, height=60)
        footer.pack(fill="x", side="bottom")
        primary_button(footer, "Save Case", self._save, width=140).pack(
            side="right", padx=16, pady=12)
        secondary_button(footer, "Cancel", self.close, width=100).pack(
            side="right", pady=12)

    # ------------------------------------------------------------------
    def _collect(self) -> Dict[str, Any]:
        return {
            "client_id": self._client_lookup.get(self.client.get()),
            "notice_type": self.notice_type.get(),
            "notice_number": self.notice_number.get(),
            "financial_year": self.financial_year.get(),
            "tax_period": self.tax_period.get(),
            "notice_date": self.notice_date.get(),
            "due_date": self.due_date.get(),
            "sections": self.sections.get(),
            "officer": self.officer.get(),
            "jurisdiction": self.jurisdiction.get(),
            "assigned_partner": self.assigned_partner.get(),
            "assigned_manager": self.assigned_manager.get(),
            "assigned_team_member": self.assigned_team_member.get(),
            "risk_level": self.risk_level.get(),
            "status": self.status_field.get(),
            "stage": self.stage.get(),
            "next_action": self.next_action.get(),
            "next_action_date": self.next_action_date.get(),
            "notes": self.notes.get(),
        }

    def _save(self) -> None:
        data = self._collect()
        ok, errors = validate_case_form(data)
        if not ok:
            show_error(self, "Please correct the following",
                       "\n".join(f"• {e}" for e in errors))
            return

        # Dates are stored ISO so SQLite sorts them correctly.
        for key in ("notice_date", "due_date", "next_action_date"):
            data[key] = to_iso_date(data[key])

        try:
            if self._case:
                db.update_case(int(self._case["id"]), data)
                db.log_activity("Case updated", self._case.get("case_code", ""),
                                case_id=int(self._case["id"]))
                message = f"Case {self._case.get('case_code')} updated."
            else:
                case_id = db.create_case(data)
                created = db.get_case(case_id)
                db.log_activity("Case created", (created or {}).get("case_code", ""),
                                case_id=case_id)
                message = f"Case {(created or {}).get('case_code', '')} created."
        except db.DatabaseError as exc:
            show_error(self, "Save failed", f"The case could not be saved.\n\n{exc}")
            return

        callback = self._on_saved
        self.close()
        if callback:
            callback()
        show_success(self.master, "Saved", message)
