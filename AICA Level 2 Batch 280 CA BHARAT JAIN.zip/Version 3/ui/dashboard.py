"""
ui.dashboard
============
Practice dashboard: KPI cards, upcoming reply deadlines, recent cases,
high-risk matters and three summary charts.

Every figure shown here is computed in Python from the SQLite records
(see :mod:`utils.calculations`).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import customtkinter as ctk

from config import Theme
from database import database as db
from ui.base_page import BasePage
from ui.widgets import (
    Card, DataTable, EmptyState, KpiCard, font, primary_button, secondary_button,
    show_error,
)
from utils.calculations import compute_demand, deadline_label, sum_amounts
from utils.formatters import (
    format_currency, format_currency_short, format_date, truncate,
)
from utils.logger import get_logger

log = get_logger(__name__)

DEADLINE_COLUMNS = [
    ("client_name", "Client", 180, "w"),
    ("notice_type", "Notice Type", 100, "w"),
    ("notice_number", "Notice Number", 140, "w"),
    ("due_date_display", "Due Date", 95, "center"),
    ("days_display", "Days Remaining", 120, "center"),
    ("assigned_team_member", "Assigned To", 130, "w"),
    ("status", "Status", 130, "w"),
]

RECENT_COLUMNS = [
    ("case_code", "Case ID", 105, "w"),
    ("client_name", "Client", 175, "w"),
    ("notice_type", "Type", 90, "w"),
    ("financial_year", "FY", 70, "center"),
    ("exposure_display", "Exposure", 105, "e"),
    ("risk_level", "Risk", 80, "center"),
    ("status", "Status", 120, "w"),
]

HIGH_RISK_COLUMNS = [
    ("case_code", "Case ID", 105, "w"),
    ("client_name", "Client", 175, "w"),
    ("notice_type", "Type", 90, "w"),
    ("exposure_display", "Exposure", 110, "e"),
    ("deadline_display", "Deadline", 120, "w"),
    ("status", "Status", 120, "w"),
]


class DashboardPage(BasePage):
    """Practice-level overview."""

    title = "Dashboard"
    subtitle = "Portfolio position computed from live case records"
    scrollable = True

    def build(self) -> None:
        secondary_button(self.header_actions, "Refresh", self.refresh,
                         width=90).pack(side="right")

        # -- KPI cards ----------------------------------------------------
        self.kpi_row1 = ctk.CTkFrame(self.body, fg_color="transparent")
        self.kpi_row1.pack(fill="x", pady=(0, 10))
        self.kpi_row2 = ctk.CTkFrame(self.body, fg_color="transparent")
        self.kpi_row2.pack(fill="x", pady=(0, 14))

        self.kpis: Dict[str, KpiCard] = {}
        first_row = [
            ("clients", "Total Clients", Theme.PRIMARY),
            ("open_cases", "Open GST Cases", Theme.INFO),
            ("due_soon", "Replies Due in 7 Days", Theme.WARNING),
            ("high_risk", "High Risk Matters", Theme.DANGER),
        ]
        second_row = [
            ("tax", "Total Tax Demand", Theme.PRIMARY),
            ("interest", "Total Interest", Theme.WARNING),
            ("penalty", "Total Penalty", Theme.DANGER),
            ("exposure", "Total Exposure", "#5B3FA8"),
        ]
        for parent, items in ((self.kpi_row1, first_row), (self.kpi_row2, second_row)):
            for index, (key, label, accent) in enumerate(items):
                parent.grid_columnconfigure(index, weight=1, uniform="kpi")
                card = KpiCard(parent, label, "-", "", accent)
                card.grid(row=0, column=index, sticky="ew",
                          padx=(0 if index == 0 else 8, 0))
                self.kpis[key] = card

        # -- Empty-state prompt --------------------------------------------
        self.empty_card = Card(self.body, "No GST cases yet",
                               "Load the demonstration portfolio to see the "
                               "application in action")
        empty_body = ctk.CTkFrame(self.empty_card, fg_color="transparent")
        empty_body.pack(fill="x", padx=16, pady=14)
        ctk.CTkLabel(
            empty_body,
            text="This database has no GST cases. One click creates 5 fictional "
                 "clients, 12 GST matters, 8 sample notice PDFs, a pre-loaded "
                 "analysis for each matter, and a requirement checklist, saved "
                 "research and draft reply for the featured case.\n"
                 "Nothing here touches real data, and it can be removed again "
                 "from Settings.",
            font=font(12), text_color=Theme.TEXT, anchor="w", justify="left",
            wraplength=780).pack(side="left", fill="x", expand=True)
        empty_actions = ctk.CTkFrame(empty_body, fg_color="transparent")
        empty_actions.pack(side="right")
        primary_button(empty_actions, "Load Demo Data", self._load_demo_data,
                       width=150, height=40).pack()
        secondary_button(empty_actions, "Open Settings",
                         lambda: self.navigate("settings"), width=150).pack(
            pady=(6, 0))

        # -- Featured demonstration case ----------------------------------
        self.featured_card = Card(
            self.body, "Featured Demo Case",
            "The matter used for the guided walkthrough")
        self.featured_body = ctk.CTkFrame(self.featured_card, fg_color="transparent")
        self.featured_body.pack(fill="x", padx=14, pady=12)

        # -- Deadlines ----------------------------------------------------
        self.deadline_card = deadline_card = Card(
            self.body, "Upcoming Deadlines",
            "Open matters with a reply due date approaching or passed")
        deadline_card.pack(fill="x", pady=(0, 14))
        self.deadline_table = DataTable(
            deadline_card, DEADLINE_COLUMNS, height=7,
            on_double_click=self._open_case,
        )
        self.deadline_table.pack(fill="x", padx=14, pady=12)
        self.deadline_empty = EmptyState(
            deadline_card, "No approaching deadlines",
            "No open case has a reply due date within the alert window.")

        # -- Charts -------------------------------------------------------
        self.charts_card = Card(self.body, "Portfolio Charts",
                                "Cases by status, cases by notice type, demand by risk")
        self.charts_card.pack(fill="x", pady=(0, 14))
        self.chart_holder = ctk.CTkFrame(self.charts_card, fg_color=Theme.SURFACE)
        self.chart_holder.pack(fill="both", expand=True, padx=14, pady=12)
        self._chart_canvas = None

        # -- Recent + high risk -------------------------------------------
        lower = ctk.CTkFrame(self.body, fg_color="transparent")
        lower.pack(fill="both", expand=True)
        lower.grid_columnconfigure(0, weight=1, uniform="lower")
        lower.grid_columnconfigure(1, weight=1, uniform="lower")

        recent_card = Card(lower, "Recent Cases", "Most recently updated matters")
        recent_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.recent_table = DataTable(recent_card, RECENT_COLUMNS, height=8,
                                      on_double_click=self._open_case)
        self.recent_table.pack(fill="both", expand=True, padx=14, pady=12)

        risk_card = Card(lower, "High Risk Matters", "Open cases marked High risk")
        risk_card.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self.risk_table = DataTable(risk_card, HIGH_RISK_COLUMNS, height=8,
                                    on_double_click=self._open_case)
        self.risk_table.pack(fill="both", expand=True, padx=14, pady=12)

        # -- Footer note ---------------------------------------------------
        ctk.CTkLabel(
            self.body,
            text="All monetary figures are computed in Python using decimal "
                 "arithmetic from the components extracted for each notice.",
            font=font(10), text_color=Theme.TEXT_MUTED,
        ).pack(anchor="w", pady=(12, 4))

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        alert_days = int(self.app.settings.get("deadline_alert_days", 7))
        try:
            data = db.dashboard_data(alert_days)
        except db.DatabaseError as exc:
            show_error(self, "Database error",
                       f"Dashboard data could not be loaded.\n\n{exc}")
            return

        totals = data["totals"]
        self.kpis["clients"].update_values(
            str(data["total_clients"]), f"{data['active_clients']} active")
        self.kpis["open_cases"].update_values(
            str(data["open_cases"]), f"{data['total_cases']} total cases")
        overdue = len([c for c in data["due_soon"] if c["days_remaining"] < 0])
        self.kpis["due_soon"].update_values(
            str(data["due_soon_count"]),
            f"{overdue} overdue" if overdue else f"within {alert_days} days")
        high_risk_exposure = sum_amounts(
            compute_demand(c).total_exposure for c in data["high_risk"])
        self.kpis["high_risk"].update_values(
            str(len(data["high_risk"])),
            format_currency_short(high_risk_exposure) + " exposure")

        self.kpis["tax"].update_values(
            format_currency_short(totals.total_tax), "CGST + SGST + IGST + Cess")
        self.kpis["interest"].update_values(format_currency_short(totals.interest),
                                            "as demanded")
        self.kpis["penalty"].update_values(format_currency_short(totals.penalty),
                                           "as demanded")
        self.kpis["exposure"].update_values(
            format_currency_short(totals.total_exposure),
            f"across {totals.case_count} case(s)")

        # Deadlines
        deadline_rows: List[Dict[str, Any]] = []
        for case in data["due_soon"]:
            row = dict(case)
            row["due_date_display"] = format_date(case.get("due_date"))
            remaining = case["days_remaining"]
            row["days_display"] = (f"Overdue {abs(remaining)}d" if remaining < 0
                                   else ("Due today" if remaining == 0 else f"{remaining} days"))
            row["assigned_team_member"] = (case.get("assigned_team_member")
                                           or case.get("assigned_manager") or "-")
            deadline_rows.append(row)
        self.deadline_table.load(
            deadline_rows,
            tag_fn=lambda r: "danger" if r["days_remaining"] < 0
            else ("warning" if r["days_remaining"] <= 3 else ""),
        )
        if deadline_rows:
            self.deadline_empty.pack_forget()
            self.deadline_table.pack(fill="x", padx=14, pady=12)
        else:
            self.deadline_table.pack_forget()
            self.deadline_empty.pack(fill="x", padx=14, pady=6)

        # Recent
        recent_rows = []
        for case in data["recent"]:
            row = dict(case)
            row["exposure_display"] = format_currency_short(
                compute_demand(case).total_exposure)
            recent_rows.append(row)
        self.recent_table.load(recent_rows)

        # High risk
        risk_rows = []
        for case in sorted(data["high_risk"],
                           key=lambda c: compute_demand(c).total_exposure, reverse=True):
            row = dict(case)
            row["exposure_display"] = format_currency_short(
                compute_demand(case).total_exposure)
            row["deadline_display"] = deadline_label(case.get("due_date"))
            risk_rows.append(row)
        self.risk_table.load(risk_rows, tag_fn=lambda _r: "danger")

        self._render_empty_prompt(bool(data["all_cases"]))
        self._render_featured_case()
        self._draw_charts(data)
        self.status(f"Dashboard refreshed - {data['total_cases']} case(s), "
                    f"total exposure {format_currency(totals.total_exposure)}")

    # ------------------------------------------------------------------
    def _render_empty_prompt(self, has_cases: bool) -> None:
        """Offer the demo portfolio when the database has nothing to show."""
        if has_cases:
            self.empty_card.pack_forget()
            return
        self.empty_card.pack(fill="x", pady=(0, 14), before=self.deadline_card)

    def _load_demo_data(self) -> None:
        """Build the demonstration portfolio straight from the dashboard."""
        from services import demo_data
        from ui.widgets import BusyDialog, run_in_background, show_success

        if self.block_if_readonly():
            return
        busy = BusyDialog(self, "Preparing demo environment",
                          "Creating clients, cases and sample notices...")

        def work():
            return demo_data.prepare_demo_environment(
                progress=lambda message: busy.set_message(message))

        def done(result) -> None:
            self.app.refresh_all()
            self.status("Demo environment ready", "success")
            show_success(self, "Demo Environment Ready", result.summary)

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Could not prepare",
                                                 str(exc)), busy)

    def _render_featured_case(self) -> None:
        """
        Highlight the featured demonstration matter.

        Only shown while demonstration data is loaded, so the card never
        appears in a real practice database.
        """
        for child in self.featured_body.winfo_children():
            child.destroy()

        case = None
        if self.app.demo_mode:
            try:
                from services import demo_data

                case = demo_data.featured_case()
            except Exception:  # noqa: BLE001 - the demo module is optional
                case = None
        if case is None:
            self.featured_card.pack_forget()
            return

        self.featured_card.pack(fill="x", pady=(0, 14), before=self.deadline_card)

        demand = compute_demand(case)
        left = ctk.CTkFrame(self.featured_body, fg_color="transparent")
        left.pack(side="left", fill="x", expand=True)

        badge_row = ctk.CTkFrame(left, fg_color="transparent")
        badge_row.pack(anchor="w")
        ctk.CTkLabel(badge_row, text="  DEMO CASE  ", font=font(10, "bold"),
                     fg_color=Theme.WARNING_BG, text_color=Theme.WARNING,
                     corner_radius=4).pack(side="left")
        ctk.CTkLabel(badge_row, text=f"  {case.get('case_code', '')}  ",
                     font=font(10, "bold"), fg_color=Theme.INFO_BG,
                     text_color=Theme.INFO, corner_radius=4).pack(side="left", padx=6)

        ctk.CTkLabel(left, text=case.get("client_name", ""), font=font(16, "bold"),
                     text_color=Theme.TEXT, anchor="w").pack(anchor="w", pady=(6, 0))
        ctk.CTkLabel(
            left,
            text=f"{case.get('notice_type', '')}  |  {case.get('notice_number', '')}"
                 f"  |  FY {case.get('financial_year', '')}  |  "
                 f"{case.get('issue_count', 0)} issue(s)  |  "
                 f"Exposure {format_currency(demand.total_exposure)}  |  "
                 f"{deadline_label(case.get('due_date'))}",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
            justify="left").pack(anchor="w", pady=(2, 0))

        buttons = ctk.CTkFrame(self.featured_body, fg_color="transparent")
        buttons.pack(side="right")
        case_id = int(case["id"])
        primary_button(buttons, "Open Case",
                       lambda: self.navigate("cases", case_id=case_id),
                       width=110).pack(side="left")
        secondary_button(buttons, "Analyse Notice",
                         lambda: self.navigate("notice", case_id=case_id),
                         width=130).pack(side="left", padx=6)
        secondary_button(buttons, "Guided Demo", self.app.start_guided_demo,
                         width=120).pack(side="left")

    def _open_case(self, row: Optional[Dict[str, Any]]) -> None:
        if row and row.get("id"):
            self.navigate("cases", case_id=int(row["id"]))

    # ------------------------------------------------------------------
    def _draw_charts(self, data: Dict[str, Any]) -> None:
        """Render the three summary charts, degrading gracefully on failure."""
        for child in self.chart_holder.winfo_children():
            child.destroy()
        self._chart_canvas = None

        try:
            import matplotlib

            matplotlib.use("TkAgg")
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            from matplotlib.figure import Figure
        except Exception as exc:  # noqa: BLE001 - charts are optional
            log.warning("Charts unavailable: %s", exc)
            ctk.CTkLabel(
                self.chart_holder,
                text="Charts are unavailable because matplotlib could not be loaded.\n"
                     "The rest of the dashboard is unaffected.",
                font=font(11), text_color=Theme.TEXT_MUTED,
            ).pack(pady=20)
            return

        totals = data["totals"]
        if not data["all_cases"]:
            ctk.CTkLabel(
                self.chart_holder,
                text="Charts will appear once GST cases have been created.\n"
                     "Tip: Settings > Load Demo Data populates sample matters.",
                font=font(11), text_color=Theme.TEXT_MUTED,
            ).pack(pady=24)
            return

        try:
            figure = Figure(figsize=(13.2, 3.3), dpi=100, facecolor=Theme.SURFACE)
            axes = figure.subplots(1, 3)

            self._bar_chart(axes[0], totals.by_status, "Cases by Status", "#1F5C99")
            self._bar_chart(axes[1], totals.by_notice_type, "Cases by Notice Type",
                            "#5B3FA8")
            self._risk_chart(axes[2], totals.by_risk)

            figure.tight_layout(pad=1.6)
            canvas = FigureCanvasTkAgg(figure, master=self.chart_holder)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)
            self._chart_canvas = canvas
        except Exception as exc:  # noqa: BLE001
            log.exception("Chart rendering failed")
            ctk.CTkLabel(self.chart_holder,
                         text=f"Charts could not be drawn: {exc}",
                         font=font(11), text_color=Theme.TEXT_MUTED).pack(pady=20)

    @staticmethod
    def _style_axis(axis, title: str) -> None:
        axis.set_title(title, fontsize=10, fontweight="bold", color=Theme.TEXT, pad=8)
        axis.set_facecolor(Theme.SURFACE)
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
        for spine in ("left", "bottom"):
            axis.spines[spine].set_color(Theme.BORDER)
        axis.tick_params(colors=Theme.TEXT_MUTED, labelsize=8)
        axis.grid(axis="y", color=Theme.BORDER, linewidth=0.6, alpha=0.7)
        axis.set_axisbelow(True)

    def _bar_chart(self, axis, mapping: Dict[str, int], title: str, colour: str) -> None:
        items = sorted(mapping.items(), key=lambda kv: kv[1], reverse=True)[:6]
        if not items:
            axis.text(0.5, 0.5, "No data", ha="center", va="center",
                      color=Theme.TEXT_MUTED, fontsize=9)
            axis.set_axis_off()
            axis.set_title(title, fontsize=10, fontweight="bold", color=Theme.TEXT)
            return
        labels = [truncate(k, 14) for k, _ in items]
        values = [v for _, v in items]
        bars = axis.bar(labels, values, color=colour, width=0.6)
        self._style_axis(axis, title)
        axis.set_xticks(range(len(labels)))
        axis.set_xticklabels(labels, rotation=20, ha="right", fontsize=8)
        for bar, value in zip(bars, values):
            axis.text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
                      str(value), ha="center", va="bottom", fontsize=8,
                      color=Theme.TEXT)
        axis.set_ylim(0, max(values) * 1.25 or 1)

    def _risk_chart(self, axis, mapping: Dict[str, Any]) -> None:
        order = ["High", "Medium", "Low", "Review Required"]
        colours = {"High": "#B02A2A", "Medium": "#B26A00", "Low": "#1F7A44",
                   "Review Required": "#1F5C99"}
        items = [(k, float(mapping.get(k, 0))) for k in order if float(mapping.get(k, 0)) > 0]
        if not items:
            axis.text(0.5, 0.5, "No demand recorded", ha="center", va="center",
                      color=Theme.TEXT_MUTED, fontsize=9)
            axis.set_axis_off()
            axis.set_title("Demand by Risk Category", fontsize=10,
                           fontweight="bold", color=Theme.TEXT)
            return
        labels = [k for k, _ in items]
        values = [v / 100000 for _, v in items]  # in lakhs
        bars = axis.barh(labels, values, color=[colours[k] for k in labels], height=0.55)
        self._style_axis(axis, "Demand by Risk Category (₹ lakh)")
        axis.grid(axis="x", color=Theme.BORDER, linewidth=0.6, alpha=0.7)
        axis.grid(axis="y", visible=False)
        axis.invert_yaxis()
        for bar, value in zip(bars, values):
            axis.text(bar.get_width(), bar.get_y() + bar.get_height() / 2,
                      f"  {value:,.2f}", va="center", fontsize=8, color=Theme.TEXT)
        axis.set_xlim(0, max(values) * 1.3 or 1)
