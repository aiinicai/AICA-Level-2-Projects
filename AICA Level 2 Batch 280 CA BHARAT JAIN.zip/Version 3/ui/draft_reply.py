"""
ui.draft_reply
==============
Draft reply generation, editing, versioning and approval.

Human-in-the-loop: a generated draft is always saved as "AI Generated".
Only a user whose role permits approval can move it to "CA Approved" or
"Final"; nothing is ever promoted automatically.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import export_service, reply_service
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DisclaimerBanner, LabeledDropdown, LabeledTextbox,
    ModalDialog, ai_button, confirm_action, danger_button, font, primary_button,
    run_in_background, secondary_button, show_error, show_info, show_success,
    show_warning,
)
from utils.formatters import format_currency, format_datetime, truncate
from utils.helpers import can_approve
from utils.logger import get_logger

log = get_logger(__name__)

VERSION_COLUMNS = [
    ("version", "Version", 70, "center"),
    ("created_display", "Date", 130, "center"),
    ("prepared_by", "Prepared By", 150, "w"),
    ("status", "Status", 150, "w"),
    ("reviewed_by", "Reviewed By", 150, "w"),
    ("remarks_short", "Remarks", 320, "w"),
]

ISSUE_PICK_COLUMNS = [
    ("include", "Include", 70, "center"),
    ("issue_no", "No.", 45, "center"),
    ("title_display", "Issue", 330, "w"),
    ("amount_display", "Amount", 110, "e"),
    ("risk", "Risk", 85, "center"),
]


class DraftReplyPage(BasePage):
    """Generate and manage the draft reply to a GST notice."""

    title = "Draft Reply"
    subtitle = "Issue-wise professional draft, versioned and approved by the CA"

    def build(self) -> None:
        self._case: Optional[Dict[str, Any]] = None
        self._issues: List[Dict[str, Any]] = []
        self._selected_issue_ids: set = set()
        self._draft: Optional[Dict[str, Any]] = None

        # -- selector ---------------------------------------------------------
        selector = Card(self.body)
        selector.pack(fill="x", pady=(0, 8))
        bar = ctk.CTkFrame(selector, fg_color="transparent")
        bar.pack(fill="x", padx=14, pady=12)

        self.case_picker = LabeledDropdown(bar, "GST Case", [""], "", width=420,
                                           command=lambda _v: self._load_case())
        self.case_picker.pack(side="left")
        self.readiness_label = ctk.CTkLabel(bar, text="", font=font(11),
                                            text_color=Theme.TEXT_MUTED,
                                            anchor="w", justify="left")
        self.readiness_label.pack(side="left", padx=18)

        ai_button(bar, "Generate Draft Reply", self._open_generator,
                  width=200).pack(side="right")

        DisclaimerBanner(self.body, config.AI_DISCLAIMER).pack(fill="x", pady=(0, 8))

        # -- tabs ---------------------------------------------------------------
        self.tabs = ctk.CTkTabview(
            self.body, fg_color=Theme.SURFACE,
            segmented_button_fg_color=Theme.SURFACE_ALT,
            segmented_button_selected_color=Theme.PRIMARY,
            segmented_button_selected_hover_color=Theme.PRIMARY_HOVER,
            segmented_button_unselected_color=Theme.SURFACE_ALT,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
        )
        self.tabs.pack(fill="both", expand=True)
        self.tab_editor = self.tabs.add("Draft Editor")
        self.tab_versions = self.tabs.add("Version History")

        self._build_editor_tab()
        self._build_versions_tab()

    # ------------------------------------------------------------------
    def _build_editor_tab(self) -> None:
        tab = self.tab_editor

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(10, 4))

        primary_button(toolbar, "Save Draft", self._save_draft, width=110).pack(side="left")
        secondary_button(toolbar, "Save as New Version", self._save_new_version,
                         width=160).pack(side="left", padx=6)
        secondary_button(toolbar, "Export Word", lambda: self._export("word"),
                         width=115).pack(side="left")
        secondary_button(toolbar, "Export PDF", lambda: self._export("pdf"),
                         width=110).pack(side="left", padx=6)
        secondary_button(toolbar, "Copy", self._copy, width=80).pack(side="left")

        workflow = ctk.CTkFrame(tab, fg_color="transparent")
        workflow.pack(fill="x", padx=12, pady=(0, 6))

        secondary_button(workflow, "Send for Review",
                         lambda: self._set_status("Manager Reviewed"),
                         width=140).pack(side="left")
        secondary_button(workflow, "Revision Required",
                         lambda: self._set_status("Revision Required"),
                         width=150).pack(side="left", padx=6)
        self.approve_button = primary_button(
            workflow, "CA Approved", lambda: self._set_status("CA Approved"),
            width=130)
        self.approve_button.pack(side="left")
        self.final_button = primary_button(
            workflow, "Mark Final", lambda: self._set_status("Final"), width=120,
            fg_color=Theme.SUCCESS, hover_color="#166134")
        self.final_button.pack(side="left", padx=6)
        danger_button(workflow, "Delete Version", self._delete_version,
                      width=130).pack(side="left")

        self.status_chip = ctk.CTkLabel(workflow, text="", font=font(11, "bold"),
                                        corner_radius=5)
        self.status_chip.pack(side="right")

        self.draft_info = ctk.CTkLabel(tab, text="", font=font(10),
                                       text_color=Theme.TEXT_MUTED, anchor="w")
        self.draft_info.pack(fill="x", padx=14)

        self.editor = ctk.CTkTextbox(
            tab, font=("Consolas", 11), wrap="word", fg_color="#FCFCFD",
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
            corner_radius=6, undo=True)
        self.editor.pack(fill="both", expand=True, padx=12, pady=(4, 12))
        self.editor.insert("1.0", _WELCOME_TEXT)

    def _build_versions_tab(self) -> None:
        tab = self.tab_versions

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(10, 6))
        secondary_button(toolbar, "Open Version", self._open_version,
                         width=120).pack(side="left")
        secondary_button(toolbar, "Compare Length", self._compare, width=130).pack(
            side="left", padx=6)
        ctk.CTkLabel(
            toolbar,
            text="Each generation and each 'Save as New Version' creates a numbered "
                 "version. Nothing is overwritten.",
            font=font(10), text_color=Theme.TEXT_MUTED).pack(side="right")

        self.version_table = DataTable(tab, VERSION_COLUMNS, height=12,
                                       on_double_click=lambda _r: self._open_version())
        self.version_table.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    # ==================================================================
    def refresh(self) -> None:
        try:
            cases = db.list_cases()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._case_lookup = {_case_label(c): c["id"] for c in cases}
        values = list(self._case_lookup) or ["(no cases yet)"]
        self.case_picker.set_values(values, keep=True)

        target = self.context.pop("case_id", None) or getattr(self.app, "selected_case_id", None)
        if target:
            for label, case_id in self._case_lookup.items():
                if case_id == target:
                    self.case_picker.set(label)
                    break
        elif self.case_picker.get() not in values and values:
            self.case_picker.set(values[0])

        self._apply_role_permissions()
        self._load_case()

    def _apply_role_permissions(self) -> None:
        allowed = can_approve(self.user_role)
        state = "normal" if allowed else "disabled"
        self.approve_button.configure(state=state)
        self.final_button.configure(state=state)

    def _case_id(self) -> Optional[int]:
        return self._case_lookup.get(self.case_picker.get())

    def _load_case(self) -> None:
        case_id = self._case_id()
        if not case_id:
            self._case = None
            self._draft = None
            self.readiness_label.configure(text="No case selected.")
            self.version_table.clear()
            return

        self._case = db.get_case(int(case_id))
        self.app.selected_case_id = int(case_id)
        self._issues = db.list_issues(int(case_id))
        self._selected_issue_ids = {int(i["id"]) for i in self._issues}

        readiness = reply_service.draft_readiness(int(case_id))
        self.readiness_label.configure(
            text=f"{readiness['issues']} issue(s)  |  "
                 f"{readiness['issues_analysed']} analysed  |  "
                 f"{readiness['requirements_received']}/{readiness['requirements']} "
                 f"documents received  |  {readiness['research']} saved research item(s)")

        self._load_versions()
        latest = db.latest_draft(int(case_id))
        if latest:
            self._open_draft(latest)
        else:
            self._draft = None
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", _WELCOME_TEXT)
            self.status_chip.configure(text="  No draft yet  ",
                                       fg_color=Theme.NEUTRAL_BG,
                                       text_color=Theme.NEUTRAL)
            self.draft_info.configure(text="")

    def _load_versions(self) -> None:
        case_id = self._case_id()
        if not case_id:
            return
        drafts = reply_service.version_history(int(case_id))
        rows = [
            {
                "id": d["id"],
                "version": f"v{d.get('version')}",
                "created_display": format_datetime(d.get("created_at")),
                "prepared_by": d.get("prepared_by") or "-",
                "status": d.get("status", ""),
                "reviewed_by": d.get("reviewed_by") or "-",
                "remarks_short": truncate(d.get("remarks"), 80),
            }
            for d in drafts
        ]
        self.version_table.load(rows, tag_fn=lambda r: {
            "Final": "success", "CA Approved": "success",
            "Revision Required": "danger", "Manager Reviewed": "warning",
        }.get(r["status"], ""))

    def _open_draft(self, draft: Dict[str, Any]) -> None:
        self._draft = draft
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", draft.get("draft_text", ""))
        status = draft.get("status", "")
        colours = {
            "AI Generated": (Theme.INFO, Theme.INFO_BG),
            "Prepared": (Theme.INFO, Theme.INFO_BG),
            "Manager Reviewed": (Theme.WARNING, Theme.WARNING_BG),
            "Revision Required": (Theme.DANGER, Theme.DANGER_BG),
            "CA Approved": (Theme.SUCCESS, Theme.SUCCESS_BG),
            "Final": (Theme.SUCCESS, Theme.SUCCESS_BG),
        }.get(status, (Theme.NEUTRAL, Theme.NEUTRAL_BG))
        self.status_chip.configure(text=f"  Version {draft.get('version')} - {status}  ",
                                   text_color=colours[0], fg_color=colours[1])
        self.draft_info.configure(
            text=f"Prepared by {draft.get('prepared_by') or '-'} on "
                 f"{format_datetime(draft.get('created_at'))}"
                 f"   |   Last updated {format_datetime(draft.get('updated_at'))}"
                 f"   |   {len(draft.get('draft_text') or ''):,} characters")

    # ==================================================================
    def _open_generator(self) -> None:
        if not self._case:
            show_warning(self, "No case selected", "Please select a GST case first.")
            return
        if self.block_if_readonly():
            return
        if not self._issues:
            confirm_action(
                self, "No issues recorded",
                "No issues have been recorded against this case.\n\n"
                "The draft will be generic and every fact will be marked "
                "[CLIENT TO CONFIRM]. Running the notice analysis first produces a "
                "far better draft.\n\nContinue anyway?",
                lambda: DraftGeneratorDialog(self, self._case, self._issues,
                                             on_generate=self._run_generation),
                confirm_text="Continue", kind="warning")
            return
        DraftGeneratorDialog(self, self._case, self._issues,
                             on_generate=self._run_generation)

    def _run_generation(self, issue_ids: List[int], instructions: str,
                        use_research: bool, include_documents: bool) -> None:
        case = dict(self._case or {})
        issues = [dict(i) for i in self._issues if int(i["id"]) in set(issue_ids)]
        requirements = (db.list_requirements(int(case["id"])) if include_documents
                        else [])
        demo = self.app.demo_mode
        user_name = self.user_name

        message = ("Preparing a sample draft (Demo Mode - the API is not called)..."
                   if demo else
                   "Drafting the reply with Gemini. A long reply can take a minute...")
        busy = BusyDialog(self, "Generating draft reply", message)
        self.status("Generating draft reply...", "info")

        def work():
            return reply_service.generate_draft(
                case, issues, requirements, instructions=instructions,
                use_research=use_research, demo_mode=demo)

        def done(result: reply_service.DraftResult) -> None:
            if not result.ok:
                self.status("Draft generation failed", "danger")
                show_error(self, "Draft could not be generated", result.error)
                return
            try:
                draft_id = reply_service.save_new_version(
                    int(case["id"]), result.text, status="AI Generated",
                    prepared_by=user_name,
                    remarks=f"Generated from {result.issues_used} issue(s); "
                            f"source: {result.source}")
            except db.DatabaseError as exc:
                show_error(self, "Could not save draft", str(exc))
                return

            self._load_versions()
            draft = db.get_draft(draft_id)
            if draft:
                self._open_draft(draft)
            self.tabs.set("Draft Editor")
            self.status("Draft reply generated", "success")
            for key in ("dashboard", "cases"):
                self.app.refresh_page(key)
            show_success(
                self, "Draft generated",
                "The draft has been saved as a new version with status "
                "'AI Generated'.\n\n"
                "Review and edit it, then send it for review. Only a Partner or "
                "Reviewer can mark a draft CA Approved or Final.")

        def failed(exc: Exception) -> None:
            log.exception("Draft generation failed")
            self.status("Draft generation failed", "danger")
            show_error(self, "Draft generation failed", str(exc))

        run_in_background(self, work, done, failed, busy)

    # ==================================================================
    def _require_draft(self) -> bool:
        if not self._draft:
            show_warning(self, "No draft", "Generate or open a draft version first.")
            return False
        return True

    def _save_draft(self) -> None:
        if not self._require_draft() or self.block_if_readonly():
            return
        if (self._draft.get("status") or "") == "Final":
            show_warning(self, "Draft is final",
                         "This version is marked Final and should not be edited.\n\n"
                         "Use 'Save as New Version' to continue working.")
            return
        text = self.editor.get("1.0", "end").rstrip()
        try:
            reply_service.update_draft_text(int(self._draft["id"]), text,
                                            user_name=self.user_name)
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return
        self._draft = db.get_draft(int(self._draft["id"]))
        self._open_draft(self._draft)
        self._load_versions()
        self.status("Draft saved", "success")

    def _save_new_version(self) -> None:
        if not self._case or self.block_if_readonly():
            return
        text = self.editor.get("1.0", "end").rstrip()
        if not text or text.strip() == _WELCOME_TEXT.strip():
            show_warning(self, "Nothing to save", "The editor is empty.")
            return
        try:
            draft_id = reply_service.save_new_version(
                int(self._case["id"]), text, status="Prepared",
                prepared_by=self.user_name, remarks="Saved manually from the editor")
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return
        self._load_versions()
        draft = db.get_draft(draft_id)
        if draft:
            self._open_draft(draft)
        self.status(f"Saved as version {draft.get('version') if draft else ''}",
                    "success")
        self.app.refresh_page("cases")

    def _set_status(self, status: str) -> None:
        if not self._require_draft() or self.block_if_readonly():
            return
        ok, message = reply_service.set_status(
            int(self._draft["id"]), status, self.user_role, self.user_name)
        if not ok:
            show_warning(self, "Not permitted", message)
            return
        self._draft = db.get_draft(int(self._draft["id"]))
        self._open_draft(self._draft)
        self._load_versions()
        self._load_case_readiness()
        self.status(message, "success")
        for key in ("dashboard", "cases"):
            self.app.refresh_page(key)
        show_success(self, "Status updated", message)

    def _load_case_readiness(self) -> None:
        case_id = self._case_id()
        if case_id:
            self._case = db.get_case(int(case_id))

    def _delete_version(self) -> None:
        if not self._require_draft() or self.block_if_readonly():
            return
        draft = self._draft

        def do_delete() -> None:
            db.delete_draft(int(draft["id"]))
            self.status(f"Version {draft.get('version')} deleted", "success")
            self._load_case()

        confirm_action(
            self, "Delete draft version",
            f"Delete version {draft.get('version')} ({draft.get('status')})?\n\n"
            "This cannot be undone.", do_delete, confirm_text="Delete")

    def _open_version(self) -> None:
        draft_id = self.version_table.selected_int_id()
        if not draft_id:
            show_warning(self, "No version selected", "Please select a version.")
            return
        draft = db.get_draft(draft_id)
        if draft:
            self._open_draft(draft)
            self.tabs.set("Draft Editor")

    def _compare(self) -> None:
        case_id = self._case_id()
        if not case_id:
            return
        drafts = reply_service.version_history(int(case_id))
        if len(drafts) < 2:
            show_info(self, "Nothing to compare",
                      "At least two versions are needed for a comparison.")
            return
        lines = ["Version  Status                Characters  Prepared by", "-" * 62]
        for draft in sorted(drafts, key=lambda d: d.get("version", 0)):
            lines.append(
                f"v{draft.get('version'):<7} {str(draft.get('status', ''))[:20]:<21} "
                f"{len(draft.get('draft_text') or ''):>10,}  "
                f"{draft.get('prepared_by') or '-'}")
        show_info(self, "Version comparison", "\n".join(lines))

    def _copy(self) -> None:
        from ui.widgets import copy_to_clipboard

        if copy_to_clipboard(self, self.editor.get("1.0", "end").strip()):
            self.status("Draft copied to the clipboard", "success")

    def _export(self, fmt: str) -> None:
        if not self._require_draft() or not self._case:
            return
        draft = dict(self._draft)
        draft["draft_text"] = self.editor.get("1.0", "end").rstrip()
        ok, message = export_service.export_draft(draft, self._case, fmt=fmt)
        if not ok:
            show_error(self, "Export failed", message)
            return
        from ui.requirements_generator import ExportDoneDialog

        self.status(f"Exported to {message}", "success")
        ExportDoneDialog(self, message)


def _case_label(case: Dict[str, Any]) -> str:
    return (f"{case.get('case_code', '')} - {case.get('client_name', '')} "
            f"({case.get('notice_type', '')}, FY {case.get('financial_year') or '-'})")


class DraftGeneratorDialog(ModalDialog):
    """Choose what the draft should be built from."""

    def __init__(self, parent, case: Dict[str, Any], issues: List[Dict[str, Any]],
                 on_generate=None):
        super().__init__(parent, "Generate draft reply", width=820, height=680)
        self._case = case
        self._issues = issues
        self._on_generate = on_generate
        self._selected = {int(i["id"]) for i in issues}

        header = ctk.CTkFrame(self, fg_color=Theme.SURFACE, height=56, corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(header, text="Generate draft reply", font=font(17, "bold"),
                     text_color=Theme.TEXT).pack(side="left", padx=20, pady=14)
        ctk.CTkLabel(header, text=f"{case.get('client_name', '')} - "
                                  f"{case.get('case_code', '')}",
                     font=font(12), text_color=Theme.TEXT_MUTED).pack(side="left")

        body = ctk.CTkScrollableFrame(self, fg_color=Theme.BG,
                                      scrollbar_button_color=Theme.BORDER)
        body.pack(fill="both", expand=True, padx=16, pady=12)

        ctk.CTkLabel(body, text="Issues to include", font=font(12, "bold"),
                     text_color=Theme.TEXT, anchor="w").pack(fill="x")
        ctk.CTkLabel(body, text="Untick any issue that should not be addressed in "
                                "this reply.",
                     font=font(10), text_color=Theme.TEXT_MUTED,
                     anchor="w").pack(fill="x", pady=(0, 6))

        self._switches: Dict[int, ctk.CTkSwitch] = {}
        for issue in issues:
            row = ctk.CTkFrame(body, fg_color=Theme.SURFACE, corner_radius=5,
                               border_width=1, border_color=Theme.BORDER)
            row.pack(fill="x", pady=2)
            switch = ctk.CTkSwitch(
                row, text="", width=44, progress_color=Theme.PRIMARY,
                command=lambda i=int(issue["id"]): self._toggle(i))
            switch.select()
            switch.pack(side="left", padx=(10, 4), pady=8)
            self._switches[int(issue["id"])] = switch

            text = ctk.CTkFrame(row, fg_color="transparent")
            text.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(
                text,
                text=f"Issue {issue.get('issue_no')}: {truncate(issue.get('title'), 70)}",
                font=font(12, "bold"), text_color=Theme.TEXT, anchor="w").pack(fill="x")
            ctk.CTkLabel(
                text,
                text=f"{format_currency(issue.get('amount'))}   |   "
                     f"Risk: {issue.get('risk')}   |   "
                     f"{'AI analysis available' if (issue.get('ai_analysis') or '').strip() else 'No AI analysis yet'}"
                     f"{'   |   CA conclusion recorded' if (issue.get('ca_remarks') or '').strip() else ''}",
                font=font(10), text_color=Theme.TEXT_MUTED, anchor="w").pack(fill="x")

        if not issues:
            ctk.CTkLabel(body, text="No issues are recorded against this case.",
                         font=font(11), text_color=Theme.WARNING,
                         anchor="w").pack(fill="x", pady=6)

        options = ctk.CTkFrame(body, fg_color="transparent")
        options.pack(fill="x", pady=(14, 4))
        self.use_research = ctk.CTkSwitch(
            options, text="Include saved research extracts (recommended)",
            font=font(11), text_color=Theme.TEXT, progress_color=Theme.PRIMARY)
        self.use_research.select()
        self.use_research.pack(anchor="w", pady=3)
        self.include_documents = ctk.CTkSwitch(
            options, text="Include the document / annexure list",
            font=font(11), text_color=Theme.TEXT, progress_color=Theme.PRIMARY)
        self.include_documents.select()
        self.include_documents.pack(anchor="w", pady=3)

        readiness = reply_service.draft_readiness(int(case["id"]))
        note = ctk.CTkFrame(body, fg_color=Theme.INFO_BG, corner_radius=6)
        note.pack(fill="x", pady=(8, 4))
        ctk.CTkLabel(
            note,
            text=f"Available material: {readiness['issues']} issue(s), "
                 f"{readiness['issues_analysed']} with AI analysis, "
                 f"{readiness['requirements']} document requirement(s), "
                 f"{readiness['research']} saved research item(s).\n"
                 "The AI is instructed to use only this material, to mark missing "
                 "facts as [CLIENT TO CONFIRM] and missing authority as "
                 "[LEGAL SOURCE TO BE VERIFIED].",
            font=font(10), text_color=Theme.INFO, anchor="w", justify="left",
            wraplength=720).pack(padx=12, pady=8, anchor="w")

        self.instructions = LabeledTextbox(
            body, "Additional instructions to the AI (optional)", "", height=90)
        self.instructions.pack(fill="x", pady=(6, 0))

        footer = ctk.CTkFrame(self, fg_color=Theme.SURFACE, height=60, corner_radius=0)
        footer.pack(fill="x", side="bottom")
        primary_button(footer, "Generate Draft", self._generate, width=160).pack(
            side="right", padx=16, pady=12)
        secondary_button(footer, "Cancel", self.close, width=100).pack(
            side="right", pady=12)

    def _toggle(self, issue_id: int) -> None:
        switch = self._switches.get(issue_id)
        if switch is None:
            return
        if switch.get():
            self._selected.add(issue_id)
        else:
            self._selected.discard(issue_id)

    def _generate(self) -> None:
        if self._issues and not self._selected:
            show_warning(self, "No issue selected",
                         "Select at least one issue to address in the reply.")
            return
        issue_ids = list(self._selected)
        instructions = self.instructions.get()
        use_research = bool(self.use_research.get())
        include_documents = bool(self.include_documents.get())
        callback = self._on_generate
        self.close()
        if callback:
            callback(issue_ids, instructions, use_research, include_documents)


_WELCOME_TEXT = """DRAFT REPLY

No draft has been prepared for this case yet.

To generate one, click 'Generate Draft Reply' above. You will be asked which
issues to address and whether to include the saved research and the document
list.

What the generator uses
-----------------------
  - the case particulars and the demand computed by the application
  - the issue-wise extraction from the notice analysis
  - any AI issue analysis and your recorded professional conclusions
  - the documents recorded as received on the requirements screen
  - research answers you have saved against this case

What it will not do
-------------------
  - it will not invent facts about the taxpayer; missing facts appear as
    [CLIENT TO CONFIRM]
  - it will not cite authority that is not in your knowledge base; missing
    authority appears as [LEGAL SOURCE TO BE VERIFIED]
  - it will not mark anything approved or final; that is a decision for the
    Chartered Accountant

Draft structure
---------------
   1. Taxpayer details            7. Issue-wise submissions
   2. Subject                     8. Relevant legal provisions
   3. Reference to notice         9. Supporting documents / annexures
   4. Background                 10. Without prejudice submissions
   5. Preliminary submissions    11. Summary
   6. Facts of the case          12. Prayer
"""
