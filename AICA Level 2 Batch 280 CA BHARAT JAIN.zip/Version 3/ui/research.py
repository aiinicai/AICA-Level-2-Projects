"""
ui.research
===========
**Ask GST Copilot** - source-grounded GST research.

A question is answered only from passages retrieved from the local
knowledge base.  Every source is displayed with its file name, category,
page and the extract relied upon, so the Chartered Accountant can verify
each citation against the original document.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import export_service, rag_service, research_service
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DisclaimerBanner, LabeledDropdown, ModalDialog,
    ai_button, confirm_action, danger_button, font, primary_button,
    run_in_background, secondary_button, show_error, show_success, show_warning,
)
from utils.formatters import format_datetime, truncate
from utils.logger import get_logger

log = get_logger(__name__)

SOURCE_COLUMNS = [
    ("ref", "Ref", 50, "center"),
    ("file_name", "Source File", 300, "w"),
    ("category", "Category", 140, "w"),
    ("page", "Page", 55, "center"),
    ("excerpt", "Relevant Extract", 640, "w"),
]

HISTORY_COLUMNS = [
    ("created_display", "Date", 130, "center"),
    ("question_short", "Question", 520, "w"),
    ("case_display", "Case", 150, "w"),
    ("source_mode", "Source", 170, "w"),
]

ALL = "All"
NO_CASE = "(not linked to a case)"

SAMPLE_QUESTIONS = [
    "Whether ITC can be denied where supplier registration was cancelled subsequently?",
    "What are the conditions for availing input tax credit?",
    "What is the effect of Rule 36(4) on credit availed in excess of GSTR-2A?",
    "What is required to be established where payment to a supplier exceeds 180 days?",
]


class ResearchPage(BasePage):
    """Ask GST Copilot."""

    title = "GST Research"
    subtitle = "Ask GST Copilot - answers grounded in your local knowledge base"

    def build(self) -> None:
        self._result: Optional[research_service.ResearchResult] = None

        # -- question panel ---------------------------------------------------
        ask_card = Card(self.body, "Ask GST Copilot")
        ask_card.pack(fill="x", pady=(0, 8))

        inner = ctk.CTkFrame(ask_card, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=(10, 12))

        ctk.CTkLabel(inner, text="Enter GST research question",
                     font=font(11, "bold"), text_color=Theme.TEXT_MUTED,
                     anchor="w").pack(fill="x")
        self.question_box = ctk.CTkTextbox(
            inner, height=68, font=font(12), wrap="word", fg_color=Theme.SURFACE,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
            corner_radius=6)
        self.question_box.pack(fill="x", pady=(3, 8))

        controls = ctk.CTkFrame(inner, fg_color="transparent")
        controls.pack(fill="x")

        self.case_picker = LabeledDropdown(controls, "Link to case (optional)",
                                           [NO_CASE], NO_CASE, width=340)
        self.case_picker.pack(side="left", padx=(0, 12))
        self.category_picker = LabeledDropdown(controls, "Search category",
                                               [ALL] + config.KB_CATEGORIES, ALL,
                                               width=170)
        self.category_picker.pack(side="left", padx=(0, 12))
        self.topk_picker = LabeledDropdown(controls, "Passages to retrieve",
                                           ["4", "6", "8", "10"], "6", width=140)
        self.topk_picker.pack(side="left")

        button_box = ctk.CTkFrame(controls, fg_color="transparent")
        button_box.pack(side="right")
        ctk.CTkLabel(button_box, text=" ", font=font(11)).pack()
        ai_button(button_box, "Ask GST Copilot", self._ask, width=190).pack(side="left")

        extras = ctk.CTkFrame(controls, fg_color="transparent")
        extras.pack(side="right", padx=10)
        ctk.CTkLabel(extras, text=" ", font=font(11)).pack()
        secondary_button(extras, "Sample question", self._insert_sample,
                         width=140).pack(side="left")

        self.kb_status = ctk.CTkLabel(inner, text="", font=font(10),
                                      text_color=Theme.TEXT_MUTED, anchor="w")
        self.kb_status.pack(fill="x", pady=(8, 0))

        DisclaimerBanner(
            self.body,
            "Source-grounding rule: the AI is instructed not to cite any provision, "
            "rule, circular, notification or judgment that is not present in the "
            "retrieved passages below. Verify every citation against the original "
            "source before relying on it.",
        ).pack(fill="x", pady=(0, 8))

        # -- results tabs -----------------------------------------------------
        self.tabs = ctk.CTkTabview(
            self.body, fg_color=Theme.SURFACE,
            segmented_button_fg_color=Theme.SURFACE_ALT,
            segmented_button_selected_color=Theme.PRIMARY,
            segmented_button_selected_hover_color=Theme.PRIMARY_HOVER,
            segmented_button_unselected_color=Theme.SURFACE_ALT,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
        )
        self.tabs.pack(fill="both", expand=True)
        self.tab_answer = self.tabs.add("Answer")
        self.tab_sources = self.tabs.add("Sources Used")
        self.tab_history = self.tabs.add("Saved Research")

        self._build_answer_tab()
        self._build_sources_tab()
        self._build_history_tab()

    # ------------------------------------------------------------------
    def _build_answer_tab(self) -> None:
        tab = self.tab_answer

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(10, 6))
        primary_button(toolbar, "Save Research", self._save, width=130).pack(side="left")
        secondary_button(toolbar, "Copy Answer", self._copy, width=120).pack(
            side="left", padx=6)
        secondary_button(toolbar, "Export Word", lambda: self._export("word"),
                         width=115).pack(side="left")
        secondary_button(toolbar, "Export PDF", lambda: self._export("pdf"),
                         width=110).pack(side="left", padx=6)
        self.answer_source = ctk.CTkLabel(toolbar, text="", font=font(10),
                                          text_color=Theme.TEXT_MUTED)
        self.answer_source.pack(side="right")

        self.grounding_chip = ctk.CTkLabel(
            tab, text="", font=font(11, "bold"), corner_radius=5, anchor="w")
        self.grounding_chip.pack(fill="x", padx=14, pady=(0, 6))

        self.answer_box = ctk.CTkTextbox(
            tab, font=("Consolas", 11), wrap="word", fg_color="#FCFCFD",
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
            corner_radius=6)
        self.answer_box.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._set_answer(_WELCOME_TEXT)

    def _build_sources_tab(self) -> None:
        tab = self.tab_sources
        ctk.CTkLabel(
            tab,
            text="These are the passages retrieved from your local knowledge base and "
                 "supplied to the AI. Double-click a row to read the full extract.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
        ).pack(fill="x", padx=14, pady=(12, 6))

        self.sources_table = DataTable(tab, SOURCE_COLUMNS, height=8,
                                       on_double_click=self._show_source)
        self.sources_table.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        self.sources_note = ctk.CTkLabel(
            tab, text="", font=font(11), text_color=Theme.TEXT_MUTED,
            anchor="w", justify="left", wraplength=1150)
        self.sources_note.pack(fill="x", padx=14, pady=(0, 12))

    def _build_history_tab(self) -> None:
        tab = self.tab_history

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(10, 6))
        secondary_button(toolbar, "Open", self._open_history, width=90).pack(side="left")
        secondary_button(toolbar, "Refresh", self._load_history, width=90).pack(
            side="left", padx=6)
        danger_button(toolbar, "Delete", self._delete_history, width=90).pack(side="left")
        ctk.CTkLabel(
            toolbar,
            text="Saved research is reused when drafting a reply, and avoids paying "
                 "for the same AI call twice.",
            font=font(10), text_color=Theme.TEXT_MUTED).pack(side="right")

        self.history_table = DataTable(tab, HISTORY_COLUMNS, height=12,
                                       on_double_click=lambda _r: self._open_history())
        self.history_table.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    # ==================================================================
    def refresh(self) -> None:
        try:
            cases = db.list_cases()
            status = rag_service.knowledge_base_status()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._case_lookup = {_case_label(c): c["id"] for c in cases}
        self.case_picker.set_values([NO_CASE] + list(self._case_lookup), keep=True)

        target = self.context.pop("case_id", None)
        if target:
            for label, case_id in self._case_lookup.items():
                if case_id == target:
                    self.case_picker.set(label)
                    break

        question = self.context.pop("question", None)
        if question:
            self.question_box.delete("1.0", "end")
            self.question_box.insert("1.0", question)

        if status["chunks"]:
            self.kb_status.configure(
                text=f"Knowledge base: {status['indexed']} indexed document(s), "
                     f"{status['chunks']:,} searchable passage(s).",
                text_color=Theme.TEXT_MUTED)
        else:
            self.kb_status.configure(
                text="Knowledge base is empty - no citation can be produced. "
                     "Add PDFs under Knowledge Base and refresh the index.",
                text_color=Theme.DANGER)

        self._load_history()

    def _insert_sample(self) -> None:
        current = self.question_box.get("1.0", "end").strip()
        try:
            index = SAMPLE_QUESTIONS.index(current) + 1
        except ValueError:
            index = 0
        self.question_box.delete("1.0", "end")
        self.question_box.insert("1.0", SAMPLE_QUESTIONS[index % len(SAMPLE_QUESTIONS)])

    def _case_id(self) -> Optional[int]:
        label = self.case_picker.get()
        if not label or label == NO_CASE:
            return None
        return self._case_lookup.get(label)

    # ==================================================================
    def _ask(self) -> None:
        question = self.question_box.get("1.0", "end").strip()
        if not question:
            show_warning(self, "No question", "Please enter a GST research question.")
            return

        case_id = self._case_id()
        case = db.get_case(int(case_id)) if case_id else None
        category = self.category_picker.get()
        try:
            top_k = int(self.topk_picker.get())
        except ValueError:
            top_k = 6
        demo = self.app.demo_mode

        message = ("Searching the knowledge base and preparing a sample answer "
                   "(Demo Mode - the API is not called)..." if demo else
                   "Searching the knowledge base, then asking Gemini...")
        busy = BusyDialog(self, "Researching", message)
        self.status("Researching...", "info")

        def work():
            return research_service.research(
                question, case=case, top_k=top_k,
                category="" if category == ALL else category, demo_mode=demo)

        def done(result: research_service.ResearchResult) -> None:
            if not result.ok:
                self.status("Research failed", "danger")
                show_error(self, "Research could not be completed", result.error)
                return
            self._result = result
            self._render(result)
            self.tabs.set("Answer")
            self.status(
                f"Research complete - {result.source_count} source(s) used", "success")

        def failed(exc: Exception) -> None:
            log.exception("Research failed")
            self.status("Research failed", "danger")
            show_error(self, "Research failed", str(exc))

        run_in_background(self, work, done, failed, busy)

    def _render(self, result: research_service.ResearchResult) -> None:
        self._set_answer(result.answer_text)
        self.answer_source.configure(
            text=f"Source: {result.source}"
                 + (f"  |  {result.elapsed:.1f}s" if result.elapsed else ""))

        if result.grounded:
            self.grounding_chip.configure(
                text=f"  SOURCE-GROUNDED - {result.source_count} passage(s) from the "
                     f"local knowledge base were supplied to the AI  ",
                fg_color=Theme.SUCCESS_BG, text_color=Theme.SUCCESS)
        else:
            self.grounding_chip.configure(
                text="  NO SOURCE FOUND - no citation may be given. "
                     "Add relevant documents to the knowledge base and try again.  ",
                fg_color=Theme.DANGER_BG, text_color=Theme.DANGER)

        rows = [
            {
                "id": index,
                "ref": chunk.ref,
                "file_name": chunk.file_name,
                "category": chunk.category,
                "page": chunk.page or "-",
                "excerpt": truncate(chunk.text, 190),
                "_full": chunk.text,
                "_score": chunk.score,
            }
            for index, chunk in enumerate(result.sources, start=1)
        ]
        self.sources_table.load(rows)
        self.sources_note.configure(
            text=("Each reference marked [S1], [S2] ... in the answer corresponds to "
                  "a row above. Open the source file from the Knowledge Base screen "
                  "to verify the passage in context."
                  if rows else
                  "No source was retrieved. The AI has been instructed to state that "
                  "no sufficiently relevant source was located rather than cite "
                  "anything from memory."))

    def _set_answer(self, text: str) -> None:
        self.answer_box.configure(state="normal")
        self.answer_box.delete("1.0", "end")
        self.answer_box.insert("1.0", text)
        self.answer_box.configure(state="disabled")

    # ==================================================================
    def _save(self) -> None:
        if not self._result or not self._result.ok:
            show_warning(self, "Nothing to save", "Run a research question first.")
            return
        if self.block_if_readonly():
            return
        try:
            research_service.save_research(
                self._result, case_id=self._case_id(), user_name=self.user_name)
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return
        self._load_history()
        self.status("Research saved", "success")
        show_success(self, "Saved",
                     "The research answer and its sources have been saved.\n\n"
                     "Saved research for a case is offered to the draft reply "
                     "generator, so no further AI call is needed for it.")

    def _copy(self) -> None:
        from ui.widgets import copy_to_clipboard

        text = self.answer_box.get("1.0", "end").strip()
        if self._result:
            text += "\n\nSOURCES USED\n" + self._result.sources_text
        if copy_to_clipboard(self, text):
            self.status("Answer copied to the clipboard", "success")

    def _export(self, fmt: str) -> None:
        if not self._result or not self._result.ok:
            show_warning(self, "Nothing to export", "Run a research question first.")
            return
        record = {
            "question": self._result.question,
            "answer": self._result.answer_text,
            "sources": self._result.sources_text,
            "created_at": "",
        }
        ok, message = export_service.export_research(record, fmt=fmt)
        if not ok:
            show_error(self, "Export failed", message)
            return
        from ui.requirements_generator import ExportDoneDialog

        self.status(f"Exported to {message}", "success")
        ExportDoneDialog(self, message)

    # ==================================================================
    def _load_history(self) -> None:
        try:
            rows = db.list_research(limit=100)
            case_names = {c["id"]: c.get("case_code", "") for c in db.list_cases()}
        except db.DatabaseError:
            return
        display = [
            {
                "id": row["id"],
                "created_display": format_datetime(row.get("created_at")),
                "question_short": truncate(row.get("question"), 110),
                "case_display": case_names.get(row.get("case_id"), "-"),
                "source_mode": row.get("source_mode", ""),
            }
            for row in rows
        ]
        self.history_table.load(display)

    def _open_history(self) -> None:
        record_id = self.history_table.selected_int_id()
        if not record_id:
            show_warning(self, "No row selected", "Please select a saved research item.")
            return
        record = db.get_research(record_id)
        if record:
            SavedResearchDialog(self, record)

    def _delete_history(self) -> None:
        if self.block_if_readonly():
            return
        record_id = self.history_table.selected_int_id()
        if not record_id:
            show_warning(self, "No row selected", "Please select a saved research item.")
            return

        def do_delete() -> None:
            db.delete_research(record_id)
            self._load_history()
            self.status("Saved research deleted", "success")

        confirm_action(self, "Delete saved research",
                       "Delete this saved research answer?", do_delete,
                       confirm_text="Delete")

    def _show_source(self, row: Optional[Dict[str, Any]]) -> None:
        if not row:
            return
        from ui.knowledge_base import PassageDialog

        PassageDialog(self, {**row, "score": row.get("_score", "")})


def _case_label(case: Dict[str, Any]) -> str:
    return (f"{case.get('case_code', '')} - {case.get('client_name', '')} "
            f"({case.get('notice_type', '')}, FY {case.get('financial_year') or '-'})")


class SavedResearchDialog(ModalDialog):
    """View a previously saved research answer with its sources."""

    def __init__(self, parent, record: Dict[str, Any]):
        super().__init__(parent, "Saved research", width=860, height=620)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=18, pady=14)

        ctk.CTkLabel(body, text=truncate(record.get("question"), 150),
                     font=font(14, "bold"), text_color=Theme.TEXT,
                     wraplength=790, justify="left").pack(anchor="w")
        ctk.CTkLabel(
            body,
            text=f"{format_datetime(record.get('created_at'))}   |   "
                 f"Source: {record.get('source_mode', '')}   |   "
                 f"By: {record.get('created_by') or '-'}",
            font=font(10), text_color=Theme.TEXT_MUTED).pack(anchor="w", pady=(2, 10))

        box = ctk.CTkTextbox(body, font=("Consolas", 11), wrap="word",
                             fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                             border_width=1, border_color=Theme.BORDER)
        box.pack(fill="both", expand=True)
        box.insert("1.0", (record.get("answer") or "")
                   + "\n\nSOURCES USED\n" + (record.get("sources") or ""))
        box.configure(state="disabled")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Close", self.close, width=100).pack(side="right")


_WELCOME_TEXT = """ASK GST COPILOT

Enter a GST research question above and click 'Ask GST Copilot'.

How the answer is produced
--------------------------
  1. The question is used to search your local knowledge base.
  2. The most relevant passages are retrieved, with their file name and page.
  3. Only the question and those passages are sent to the AI.
  4. The AI is instructed not to cite anything that is not in the passages.
  5. The answer is returned with source references [S1], [S2] ... which map to
     the rows on the 'Sources Used' tab.

If nothing relevant is found
----------------------------
  The answer will state:
    "No sufficiently relevant source was located in the current local
     knowledge base."
  It will not supply a citation from memory. Add the relevant Act, rules,
  circulars, notifications or case notes under Knowledge Base, refresh the
  index, and ask again.

Answer structure
----------------
  Research Question
  Short Answer
  Relevant Statutory Provision
  Relevant Rules
  Relevant Circular / Notification
  Relevant Judicial Material
  Analysis
  Applicability to the Present Case
  Information / Facts Requiring Verification
  Limitations
  Sources Used
"""
