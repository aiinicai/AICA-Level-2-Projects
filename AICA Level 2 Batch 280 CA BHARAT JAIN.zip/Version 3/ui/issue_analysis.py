"""
ui.issue_analysis
=================
Issue-wise analysis screen.

The layout keeps three sources of information visually distinct:

* **Facts from the Notice**  - extracted, shown on the left
* **AI Analysis**            - generated on request, shown on the right
* **Professional Conclusion** - the CA's own remarks, saved separately
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import issue_service
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DetailGrid, DisclaimerBanner, LabeledDropdown,
    ai_button, confirm_action, danger_button, font, primary_button,
    run_in_background, secondary_button, show_error, show_success, show_warning,
)
from utils.formatters import bullet_list, format_currency, join_list, loads, truncate
from utils.logger import get_logger

log = get_logger(__name__)

ISSUE_COLUMNS = [
    ("issue_no", "No.", 45, "center"),
    ("title_display", "Issue", 300, "w"),
    ("amount_display", "Amount", 110, "e"),
    ("risk", "Risk", 90, "center"),
    ("confidence", "Confidence", 90, "center"),
    ("analysed", "AI Analysis", 95, "center"),
]


class IssueAnalysisPage(BasePage):
    """Detailed analysis of each allegation raised in the notice."""

    title = "Issue Analysis"
    subtitle = "Allegation-wise breakdown, AI analysis and professional conclusion"

    def build(self) -> None:
        self._case: Optional[Dict[str, Any]] = None
        self._issue: Optional[Dict[str, Any]] = None

        # -- selector -------------------------------------------------------
        selector = Card(self.body)
        selector.pack(fill="x", pady=(0, 8))
        bar = ctk.CTkFrame(selector, fg_color="transparent")
        bar.pack(fill="x", padx=14, pady=12)

        self.case_picker = LabeledDropdown(bar, "GST Case", [""], "", width=430,
                                           command=lambda _v: self._load_case())
        self.case_picker.pack(side="left")
        self.case_info = ctk.CTkLabel(bar, text="", font=font(11),
                                      text_color=Theme.TEXT_MUTED, anchor="w")
        self.case_info.pack(side="left", padx=18)
        secondary_button(bar, "Analyse Notice",
                         lambda: self.navigate("notice", case_id=self._case_id()),
                         width=130).pack(side="right")

        DisclaimerBanner(self.body, config.AI_DISCLAIMER).pack(fill="x", pady=(0, 8))

        # -- split view ------------------------------------------------------
        split = ctk.CTkFrame(self.body, fg_color="transparent")
        split.pack(fill="both", expand=True)
        split.grid_rowconfigure(1, weight=1)
        split.grid_columnconfigure(0, weight=1)

        list_card = Card(split, "Issues Identified",
                         "Select an issue to work on it")
        list_card.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        self.issue_table = DataTable(list_card, ISSUE_COLUMNS, height=6,
                                     on_select=self._on_issue_select)
        self.issue_table.pack(fill="x", padx=14, pady=12)

        detail = ctk.CTkFrame(split, fg_color="transparent")
        detail.grid(row=1, column=0, sticky="nsew")
        detail.grid_columnconfigure(0, weight=1, uniform="d")
        detail.grid_columnconfigure(1, weight=1, uniform="d")
        detail.grid_rowconfigure(0, weight=1)

        self._build_facts_panel(detail)
        self._build_ai_panel(detail)

    # ------------------------------------------------------------------
    def _build_facts_panel(self, parent) -> None:
        card = Card(parent, "Facts from the Notice",
                    "Extracted content - not AI commentary")
        card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        self.facts_scroll = ctk.CTkScrollableFrame(
            card, fg_color="transparent", scrollbar_button_color=Theme.BORDER)
        self.facts_scroll.pack(fill="both", expand=True, padx=14, pady=12)

        self.facts_placeholder = ctk.CTkLabel(
            self.facts_scroll,
            text="Select an issue above.\n\nIf no issues are listed, run the notice "
                 "analysis first\n(Upload / Analyse Notice).",
            font=font(12), text_color=Theme.TEXT_MUTED, justify="center")
        self.facts_placeholder.pack(pady=50)

        self.facts_content = ctk.CTkFrame(self.facts_scroll, fg_color="transparent")

    def _build_ai_panel(self, parent) -> None:
        card = Card(parent, "AI Analysis and Professional Conclusion")
        card.grid(row=0, column=1, sticky="nsew")

        toolbar = ctk.CTkFrame(card, fg_color="transparent")
        toolbar.pack(fill="x", padx=14, pady=(10, 6))
        ai_button(toolbar, "Generate AI Issue Analysis", self._generate,
                  width=220).pack(side="left")
        secondary_button(toolbar, "Client Requirements", self._open_requirements,
                         width=150).pack(side="left", padx=6)
        secondary_button(toolbar, "Research this Issue", self._open_research,
                         width=150).pack(side="left")

        self.ai_source = ctk.CTkLabel(card, text="", font=font(10),
                                      text_color=Theme.TEXT_MUTED, anchor="w")
        self.ai_source.pack(fill="x", padx=16)

        ctk.CTkLabel(
            card,
            text="AI ANALYSIS - suggestions for verification, not conclusions",
            font=font(10, "bold"), text_color="#5B3FA8", anchor="w",
        ).pack(fill="x", padx=16, pady=(6, 2))

        self.ai_text = ctk.CTkTextbox(
            card, font=("Consolas", 11), wrap="word", fg_color="#FBFAFE",
            text_color=Theme.TEXT, border_width=1, border_color="#D9D2EC",
            corner_radius=6, height=260)
        self.ai_text.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        ctk.CTkLabel(
            card,
            text="PROFESSIONAL CONCLUSION - recorded by the Chartered Accountant",
            font=font(10, "bold"), text_color=Theme.SUCCESS, anchor="w",
        ).pack(fill="x", padx=16, pady=(0, 2))

        self.remarks_text = ctk.CTkTextbox(
            card, font=font(12), wrap="word", fg_color=Theme.SURFACE,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
            corner_radius=6, height=110)
        self.remarks_text.pack(fill="x", padx=14, pady=(0, 6))

        actions = ctk.CTkFrame(card, fg_color="transparent", width=1, height=1)
        actions.pack(fill="x", padx=14, pady=(0, 12))
        primary_button(actions, "Save Conclusion", self._save_remarks,
                       width=140).pack(side="left")
        secondary_button(actions, "Edit Issue", self._edit_issue, width=110).pack(
            side="left", padx=6)
        secondary_button(actions, "Copy Analysis", self._copy_analysis,
                         width=120).pack(side="left")
        danger_button(actions, "Clear AI Analysis", self._clear_analysis,
                      width=140).pack(side="right")

    # ==================================================================
    def refresh(self) -> None:
        try:
            cases = db.list_cases()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._case_lookup = {_case_label(c): c["id"] for c in cases}
        values = list(self._case_lookup) or ["(no cases yet)"]
        self.case_picker.set_values(values, keep=True)

        target = self.context.pop("case_id", None) or getattr(self.app, "selected_case_id", None)
        if target:
            for label, case_id in self._case_lookup.items():
                if case_id == target:
                    self.case_picker.set(label)
                    break
        elif self.case_picker.get() not in values and values:
            self.case_picker.set(values[0])

        self._load_case()

        preset_issue = self.context.pop("issue_id", None)
        if preset_issue:
            self.issue_table.select_by_id(preset_issue)

    def _case_id(self) -> Optional[int]:
        return self._case_lookup.get(self.case_picker.get())

    def _load_case(self) -> None:
        case_id = self._case_id()
        if not case_id:
            self._case = None
            self.case_info.configure(text="No case selected.")
            self.issue_table.clear()
            self._show_no_issue()
            return

        self._case = db.get_case(int(case_id))
        self.app.selected_case_id = int(case_id)
        issues = db.list_issues(int(case_id))

        self.case_info.configure(
            text=f"{(self._case or {}).get('client_name', '')}   |   "
                 f"{(self._case or {}).get('notice_type', '')}   |   "
                 f"{len(issues)} issue(s) recorded")

        rows = []
        for issue in issues:
            rows.append({
                "id": issue["id"],
                "issue_no": issue.get("issue_no"),
                "title_display": truncate(issue.get("title"), 70),
                "amount_display": format_currency(issue.get("amount")),
                "risk": issue.get("risk") or "-",
                "confidence": issue.get("confidence") or "-",
                "analysed": "Yes" if (issue.get("ai_analysis") or "").strip() else "-",
            })
        self.issue_table.load(rows, tag_fn=lambda r: {
            "High": "danger", "Medium": "warning", "Low": "success"}.get(r["risk"], ""))

        if rows:
            self.issue_table.select_first()
        else:
            self._show_no_issue()

    def _show_no_issue(self) -> None:
        self._issue = None
        self.facts_content.pack_forget()
        self.facts_placeholder.pack(pady=50)
        self.ai_text.delete("1.0", "end")
        self.remarks_text.delete("1.0", "end")
        self.ai_source.configure(text="")

    # ==================================================================
    def _on_issue_select(self, row: Optional[Dict[str, Any]]) -> None:
        if not row:
            self._show_no_issue()
            return
        issue = db.get_issue(int(row["id"]))
        if not issue:
            self._show_no_issue()
            return
        self._issue = issue
        self._render_issue(issue)

    def _render_issue(self, issue: Dict[str, Any]) -> None:
        self.facts_placeholder.pack_forget()
        for child in self.facts_content.winfo_children():
            child.destroy()
        self.facts_content.pack(fill="both", expand=True)

        risk_colour = {"High": Theme.DANGER, "Medium": Theme.WARNING,
                       "Low": Theme.SUCCESS}.get(issue.get("risk"), Theme.INFO)

        header = ctk.CTkFrame(self.facts_content, fg_color=Theme.SURFACE_ALT,
                              corner_radius=6)
        header.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(header, text=f"Issue {issue.get('issue_no')}",
                     font=font(10, "bold"), text_color=Theme.TEXT_MUTED,
                     anchor="w").pack(fill="x", padx=12, pady=(8, 0))
        ctk.CTkLabel(header, text=issue.get("title") or "-", font=font(14, "bold"),
                     text_color=Theme.TEXT, anchor="w", justify="left",
                     wraplength=430).pack(fill="x", padx=12, pady=(0, 8))

        grid = DetailGrid(self.facts_content, columns=1)
        grid.pack(fill="x")
        grid.add("Amount Involved", format_currency(issue.get("amount")), bold=True,
                 value_color=Theme.DANGER)
        grid.add("Section / Rule referred to in the notice",
                 join_list(issue.get("sections")))
        grid.add("Initial Risk", issue.get("risk") or "-", bold=True,
                 value_color=risk_colour)
        grid.add("Confidence of Extraction", issue.get("confidence") or "-")

        self._facts_block("DEPARTMENT'S ALLEGATION",
                          issue.get("allegation") or "Not recorded.", Theme.DANGER)
        self._facts_block("REASON FOR THE RISK ASSESSMENT",
                          issue.get("risk_reason") or "Not recorded.", Theme.WARNING)
        self._facts_block("FACTS IDENTIFIED FROM THE NOTICE",
                          bullet_list(loads(issue.get("facts_identified"), []) or []),
                          Theme.SUCCESS)
        self._facts_block("FACTS MISSING - TO BE OBTAINED",
                          bullet_list(loads(issue.get("facts_missing"), []) or []),
                          Theme.INFO)

        # AI analysis + CA remarks
        self.ai_text.delete("1.0", "end")
        analysis = (issue.get("ai_analysis") or "").strip()
        if analysis:
            self.ai_text.insert("1.0", analysis)
            self.ai_source.configure(text="Saved AI analysis for this issue.")
        else:
            self.ai_text.insert(
                "1.0",
                "No AI analysis has been generated for this issue yet.\n\n"
                "Click 'Generate AI Issue Analysis' to obtain:\n"
                "  - an explanation of the allegation\n"
                "  - the factual checks required\n"
                "  - the reconciliations required\n"
                "  - the documents needed\n"
                "  - the legal questions that arise\n"
                "  - possible taxpayer positions and their dependencies\n\n"
                "The output assists preparation. It is not a conclusion.")
            self.ai_source.configure(text="")

        self.remarks_text.delete("1.0", "end")
        if issue.get("ca_remarks"):
            self.remarks_text.insert("1.0", issue["ca_remarks"])

    def _facts_block(self, heading: str, body: str, accent: str) -> None:
        ctk.CTkLabel(self.facts_content, text=heading, font=font(10, "bold"),
                     text_color=accent, anchor="w").pack(fill="x", pady=(12, 2))
        box = ctk.CTkFrame(self.facts_content, fg_color=Theme.SURFACE,
                           corner_radius=5, border_width=1, border_color=Theme.BORDER)
        box.pack(fill="x")
        ctk.CTkLabel(box, text=body or "-", font=font(11), text_color=Theme.TEXT,
                     anchor="w", justify="left", wraplength=430).pack(
            fill="x", padx=10, pady=8)

    # ==================================================================
    def _generate(self) -> None:
        if not self._issue:
            show_warning(self, "No issue selected", "Please select an issue first.")
            return
        if self.block_if_readonly():
            return

        issue = dict(self._issue)
        case = dict(self._case or {})
        demo = self.app.demo_mode
        message = ("Preparing sample analysis (Demo Mode - the API is not called)..."
                   if demo else "Analysing the issue with Gemini...")
        busy = BusyDialog(self, "Analysing issue", message)
        self.status("Generating issue analysis...", "info")

        def work():
            return issue_service.analyse_issue(issue, case, demo_mode=demo)

        def done(result: issue_service.IssueAnalysisResult) -> None:
            if not result.ok:
                self.status("Issue analysis failed", "danger")
                show_error(self, "Analysis could not be completed", result.error)
                return
            try:
                issue_service.save_issue_analysis(int(issue["id"]), result,
                                                  case_id=int(case.get("id") or 0))
            except db.DatabaseError as exc:
                show_error(self, "Could not save", str(exc))
                return

            self._issue = db.get_issue(int(issue["id"]))
            self._render_issue(self._issue)
            self._load_case()
            self.issue_table.select_by_id(issue["id"])
            self.ai_source.configure(
                text=f"Source: {result.source}"
                     + (f"  |  {result.elapsed:.1f}s" if result.elapsed else ""))
            self.status("Issue analysis generated", "success")
            self.app.refresh_page("cases")

        def failed(exc: Exception) -> None:
            log.exception("Issue analysis failed")
            self.status("Issue analysis failed", "danger")
            show_error(self, "Analysis failed", str(exc))

        run_in_background(self, work, done, failed, busy)

    def _save_remarks(self) -> None:
        if not self._issue or self.block_if_readonly():
            return
        text = self.remarks_text.get("1.0", "end").strip()
        try:
            db.update_issue(int(self._issue["id"]), {"ca_remarks": text})
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return
        db.log_activity("Professional conclusion recorded",
                        f"Issue #{self._issue['id']}",
                        case_id=self._case_id(), user_name=self.user_name)
        self.status("Professional conclusion saved", "success")
        show_success(self, "Saved", "Your professional conclusion has been recorded "
                                    "against this issue.")

    def _clear_analysis(self) -> None:
        if not self._issue or self.block_if_readonly():
            return

        def do_clear() -> None:
            db.update_issue(int(self._issue["id"]), {"ai_analysis": ""})
            self._issue = db.get_issue(int(self._issue["id"]))
            self._render_issue(self._issue)
            self._load_case()
            self.status("AI analysis cleared", "success")

        confirm_action(self, "Clear AI analysis",
                       "Remove the saved AI analysis for this issue?\n\n"
                       "Your professional conclusion is not affected.",
                       do_clear, confirm_text="Clear", kind="warning")

    def _copy_analysis(self) -> None:
        from ui.widgets import copy_to_clipboard

        text = self.ai_text.get("1.0", "end").strip()
        if copy_to_clipboard(self, text):
            self.status("AI analysis copied to the clipboard", "success")

    def _edit_issue(self) -> None:
        if not self._issue or self.block_if_readonly():
            return
        IssueEditDialog(self, dict(self._issue), on_saved=self._after_edit)

    def _after_edit(self) -> None:
        issue_id = int(self._issue["id"]) if self._issue else None
        self._load_case()
        if issue_id:
            self.issue_table.select_by_id(issue_id)
        self.app.refresh_page("cases")
        self.app.refresh_page("notice")

    def _open_requirements(self) -> None:
        if not self._issue:
            show_warning(self, "No issue selected", "Please select an issue first.")
            return
        self.navigate("requirements", case_id=self._case_id(),
                      issue_id=int(self._issue["id"]))

    def _open_research(self) -> None:
        if not self._issue:
            show_warning(self, "No issue selected", "Please select an issue first.")
            return
        question = (
            f"What legal considerations arise in relation to this allegation: "
            f"{self._issue.get('title', '')}?"
        )
        self.navigate("research", case_id=self._case_id(),
                      issue_id=int(self._issue["id"]), question=question)


def _case_label(case: Dict[str, Any]) -> str:
    return (f"{case.get('case_code', '')} - {case.get('client_name', '')} "
            f"({case.get('notice_type', '')}, FY {case.get('financial_year') or '-'})")


class IssueEditDialog(ctk.CTkToplevel):
    """Manual correction of an extracted issue."""

    def __init__(self, parent, issue: Dict[str, Any], on_saved=None):
        super().__init__(parent, fg_color=Theme.BG)
        self._issue = issue
        self._on_saved = on_saved
        self.title(f"Edit Issue {issue.get('issue_no', '')}")
        self.geometry("700x640")
        self.transient(parent)
        self.after(120, self._grab)

        from ui.widgets import LabeledDropdown as Dropdown
        from ui.widgets import LabeledEntry, LabeledTextbox

        body = ctk.CTkScrollableFrame(self, fg_color=Theme.BG,
                                      scrollbar_button_color=Theme.BORDER)
        body.pack(fill="both", expand=True, padx=18, pady=14)

        ctk.CTkLabel(body, text="Edit issue particulars", font=font(16, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w", pady=(0, 8))

        self.title_field = LabeledEntry(body, "Issue Title", issue.get("title", ""),
                                        width=620)
        self.title_field.pack(fill="x")
        self.allegation = LabeledTextbox(body, "Department's Allegation",
                                         issue.get("allegation", ""), height=100)
        self.allegation.pack(fill="x", pady=(4, 4))
        self.amount = LabeledEntry(body, "Amount Involved",
                                   str(issue.get("amount") or 0), width=300)
        self.amount.pack(fill="x")
        self.sections = LabeledEntry(body, "Sections / Rules",
                                     issue.get("sections", ""), width=620)
        self.sections.pack(fill="x")

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")
        self.risk = Dropdown(row, "Risk", config.RISK_LEVELS,
                             issue.get("risk", "Review Required"), width=200)
        self.risk.pack(side="left", padx=(0, 12))
        self.confidence = Dropdown(row, "Confidence", ["High", "Medium", "Low"],
                                   issue.get("confidence", "Medium"), width=200)
        self.confidence.pack(side="left")

        self.risk_reason = LabeledTextbox(body, "Reason for Risk",
                                          issue.get("risk_reason", ""), height=70)
        self.risk_reason.pack(fill="x", pady=(4, 4))

        facts_identified = loads(issue.get("facts_identified"), []) or []
        facts_missing = loads(issue.get("facts_missing"), []) or []
        self.facts_identified = LabeledTextbox(
            body, "Facts Identified (one per line)",
            "\n".join(str(f) for f in facts_identified), height=90)
        self.facts_identified.pack(fill="x", pady=(0, 4))
        self.facts_missing = LabeledTextbox(
            body, "Facts Missing (one per line)",
            "\n".join(str(f) for f in facts_missing), height=90)
        self.facts_missing.pack(fill="x")

        footer = ctk.CTkFrame(self, fg_color=Theme.SURFACE, height=58, corner_radius=0)
        footer.pack(fill="x", side="bottom")
        primary_button(footer, "Save Issue", self._save, width=140).pack(
            side="right", padx=16, pady=12)
        secondary_button(footer, "Cancel", self.destroy, width=100).pack(
            side="right", pady=12)

    def _grab(self) -> None:
        try:
            self.grab_set()
            self.lift()
        except Exception:  # noqa: BLE001
            pass

    def _save(self) -> None:
        from utils.calculations import money
        from utils.formatters import dumps

        payload = {
            "title": self.title_field.get(),
            "allegation": self.allegation.get(),
            "amount": float(money(self.amount.get())),
            "sections": self.sections.get(),
            "risk": self.risk.get(),
            "confidence": self.confidence.get(),
            "risk_reason": self.risk_reason.get(),
            "facts_identified": dumps(
                [line.strip() for line in self.facts_identified.get().splitlines()
                 if line.strip()]),
            "facts_missing": dumps(
                [line.strip() for line in self.facts_missing.get().splitlines()
                 if line.strip()]),
        }
        try:
            db.update_issue(int(self._issue["id"]), payload)
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return
        callback = self._on_saved
        self.destroy()
        if callback:
            callback()
