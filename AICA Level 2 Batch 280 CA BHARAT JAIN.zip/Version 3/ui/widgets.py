"""
ui.widgets
==========
Reusable CustomTkinter building blocks shared by every screen:
cards, KPI tiles, section headings, badges, form fields, a styled
Treeview data table and a background-task runner for AI calls.
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import customtkinter as ctk

from config import RISK_COLORS, STATUS_COLORS, Theme
from utils.formatters import truncate


# ---------------------------------------------------------------------------
# Fonts
# ---------------------------------------------------------------------------
def font(size: int = 13, weight: str = "normal", family: Optional[str] = None) -> ctk.CTkFont:
    """Application font helper."""
    return ctk.CTkFont(family=family or Theme.FONT_FAMILY, size=size, weight=weight)


def mono_font(size: int = 12) -> ctk.CTkFont:
    return ctk.CTkFont(family=Theme.FONT_MONO, size=size)


# ---------------------------------------------------------------------------
# Containers
# ---------------------------------------------------------------------------
class Card(ctk.CTkFrame):
    """A white surface panel with a light border -- the basic layout unit."""

    def __init__(self, master, title: str = "", subtitle: str = "", **kwargs):
        kwargs.setdefault("fg_color", Theme.SURFACE)
        kwargs.setdefault("corner_radius", 8)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", Theme.BORDER)
        super().__init__(master, **kwargs)
        self.header: Optional[ctk.CTkFrame] = None
        if title:
            self.header = ctk.CTkFrame(self, fg_color="transparent")
            self.header.pack(fill="x", padx=16, pady=(12, 0))
            ctk.CTkLabel(
                self.header, text=title, font=font(15, "bold"),
                text_color=Theme.TEXT, anchor="w",
            ).pack(side="left")
            if subtitle:
                ctk.CTkLabel(
                    self.header, text=subtitle, font=font(11),
                    text_color=Theme.TEXT_MUTED, anchor="w",
                ).pack(side="left", padx=(10, 0))


class KpiCard(ctk.CTkFrame):
    """A dashboard metric tile: label, big value and an optional caption."""

    def __init__(self, master, label: str, value: str = "-", caption: str = "",
                 accent: str = Theme.PRIMARY, **kwargs):
        kwargs.setdefault("fg_color", Theme.SURFACE)
        kwargs.setdefault("corner_radius", 8)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", Theme.BORDER)
        kwargs.setdefault("height", 96)
        super().__init__(master, **kwargs)
        self.grid_propagate(False)
        self.pack_propagate(False)

        strip = ctk.CTkFrame(self, fg_color=accent, corner_radius=0, height=4)
        strip.pack(fill="x", side="top")

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=14, pady=(8, 10))

        ctk.CTkLabel(
            body, text=label.upper(), font=font(10, "bold"),
            text_color=Theme.TEXT_MUTED, anchor="w",
        ).pack(fill="x")
        self.value_label = ctk.CTkLabel(
            body, text=value, font=font(22, "bold"), text_color=accent, anchor="w",
        )
        self.value_label.pack(fill="x", pady=(2, 0))
        self.caption_label = ctk.CTkLabel(
            body, text=caption, font=font(10), text_color=Theme.TEXT_MUTED, anchor="w",
        )
        self.caption_label.pack(fill="x")

    def update_values(self, value: str, caption: str = "") -> None:
        self.value_label.configure(text=value)
        self.caption_label.configure(text=caption)


class SectionTitle(ctk.CTkFrame):
    """A heading with an optional right-aligned action area."""

    def __init__(self, master, text: str, subtitle: str = "", **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        left = ctk.CTkFrame(self, fg_color="transparent")
        left.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(
            left, text=text, font=font(16, "bold"), text_color=Theme.TEXT, anchor="w",
        ).pack(anchor="w")
        if subtitle:
            ctk.CTkLabel(
                left, text=subtitle, font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
            ).pack(anchor="w")
        self.actions = ctk.CTkFrame(self, fg_color="transparent")
        self.actions.pack(side="right")


class Badge(ctk.CTkLabel):
    """A small coloured status pill."""

    def __init__(self, master, text: str, kind: str = "neutral", **kwargs):
        fg, bg = _badge_colors(kind, text)
        kwargs.setdefault("font", font(11, "bold"))
        kwargs.setdefault("corner_radius", 4)
        kwargs.setdefault("padx", 0)
        super().__init__(
            master, text=f"  {text}  ", text_color=fg, fg_color=bg, **kwargs
        )

    def set(self, text: str, kind: str = "neutral") -> None:
        fg, bg = _badge_colors(kind, text)
        self.configure(text=f"  {text}  ", text_color=fg, fg_color=bg)


def _badge_colors(kind: str, text: str) -> Tuple[str, str]:
    """Resolve badge colours from an explicit kind, or from the text itself."""
    palette = {
        "success": (Theme.SUCCESS, Theme.SUCCESS_BG),
        "warning": (Theme.WARNING, Theme.WARNING_BG),
        "danger": (Theme.DANGER, Theme.DANGER_BG),
        "info": (Theme.INFO, Theme.INFO_BG),
        "neutral": (Theme.NEUTRAL, Theme.NEUTRAL_BG),
    }
    if kind in palette:
        return palette[kind]
    if kind == "auto":
        if text in RISK_COLORS:
            return RISK_COLORS[text]
        if text in STATUS_COLORS:
            return STATUS_COLORS[text]
    return palette["neutral"]


class DisclaimerBanner(ctk.CTkFrame):
    """The human-in-the-loop warning shown on every AI screen."""

    def __init__(self, master, text: str, **kwargs):
        kwargs.setdefault("fg_color", Theme.WARNING_BG)
        kwargs.setdefault("corner_radius", 6)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", "#E4C88A")
        super().__init__(master, **kwargs)
        ctk.CTkLabel(
            self, text="!", font=font(15, "bold"), text_color=Theme.WARNING, width=18,
        ).pack(side="left", padx=(12, 4), pady=8)
        ctk.CTkLabel(
            self, text=text, font=font(11), text_color="#7A4B00",
            justify="left", anchor="w", wraplength=1100,
        ).pack(side="left", fill="x", expand=True, padx=(0, 12), pady=8)


class ModeBanner(ctk.CTkFrame):
    """Shows whether the AI is in Demo (mock) mode or calling the live API."""

    def __init__(self, master, **kwargs):
        kwargs.setdefault("corner_radius", 6)
        kwargs.setdefault("fg_color", Theme.INFO_BG)
        super().__init__(master, **kwargs)
        self.label = ctk.CTkLabel(self, text="", font=font(11, "bold"), text_color=Theme.INFO)
        self.label.pack(padx=12, pady=6)

    def set_mode(self, demo_mode: bool, api_ready: bool = False) -> None:
        if demo_mode:
            self.configure(fg_color=Theme.WARNING_BG)
            self.label.configure(
                text="DEMO MODE - AI API NOT CALLED (sample output shown)",
                text_color=Theme.WARNING,
            )
        elif api_ready:
            self.configure(fg_color=Theme.SUCCESS_BG)
            self.label.configure(
                text="LIVE AI MODE - Gemini API will be called", text_color=Theme.SUCCESS
            )
        else:
            self.configure(fg_color=Theme.DANGER_BG)
            self.label.configure(
                text="LIVE AI MODE - but no API key configured (see Settings)",
                text_color=Theme.DANGER,
            )


class Divider(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        kwargs.setdefault("height", 1)
        kwargs.setdefault("fg_color", Theme.BORDER)
        super().__init__(master, **kwargs)


class EmptyState(ctk.CTkFrame):
    """Friendly placeholder shown when a list has no records."""

    def __init__(self, master, title: str, message: str = "", **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        ctk.CTkLabel(self, text=title, font=font(14, "bold"),
                     text_color=Theme.TEXT_MUTED).pack(pady=(30, 4))
        if message:
            ctk.CTkLabel(self, text=message, font=font(11),
                         text_color=Theme.TEXT_MUTED, wraplength=520,
                         justify="center").pack(pady=(0, 30))


# ---------------------------------------------------------------------------
# Buttons
# ---------------------------------------------------------------------------
def primary_button(master, text: str, command: Callable, width: int = 150,
                   **kwargs) -> ctk.CTkButton:
    kwargs.setdefault("fg_color", Theme.PRIMARY)
    kwargs.setdefault("hover_color", Theme.PRIMARY_HOVER)
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 6)
    kwargs.setdefault("height", 34)
    kwargs.setdefault("font", font(12, "bold"))
    return ctk.CTkButton(master, text=text, command=command, width=width, **kwargs)


def secondary_button(master, text: str, command: Callable, width: int = 130,
                     **kwargs) -> ctk.CTkButton:
    kwargs.setdefault("fg_color", Theme.SURFACE)
    kwargs.setdefault("hover_color", Theme.SURFACE_ALT)
    kwargs.setdefault("text_color", Theme.PRIMARY)
    kwargs.setdefault("border_width", 1)
    kwargs.setdefault("border_color", Theme.PRIMARY)
    kwargs.setdefault("corner_radius", 6)
    kwargs.setdefault("height", 34)
    kwargs.setdefault("font", font(12))
    return ctk.CTkButton(master, text=text, command=command, width=width, **kwargs)


def danger_button(master, text: str, command: Callable, width: int = 120,
                  **kwargs) -> ctk.CTkButton:
    kwargs.setdefault("fg_color", Theme.SURFACE)
    kwargs.setdefault("hover_color", Theme.DANGER_BG)
    kwargs.setdefault("text_color", Theme.DANGER)
    kwargs.setdefault("border_width", 1)
    kwargs.setdefault("border_color", Theme.DANGER)
    kwargs.setdefault("corner_radius", 6)
    kwargs.setdefault("height", 34)
    kwargs.setdefault("font", font(12))
    return ctk.CTkButton(master, text=text, command=command, width=width, **kwargs)


def ai_button(master, text: str, command: Callable, width: int = 220,
              **kwargs) -> ctk.CTkButton:
    """Distinct styling so AI-invoking actions are always obvious."""
    kwargs.setdefault("fg_color", "#5B3FA8")
    kwargs.setdefault("hover_color", "#4A3189")
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 6)
    kwargs.setdefault("height", 36)
    kwargs.setdefault("font", font(12, "bold"))
    return ctk.CTkButton(master, text=text, command=command, width=width, **kwargs)


# ---------------------------------------------------------------------------
# Form fields
# ---------------------------------------------------------------------------
class LabeledEntry(ctk.CTkFrame):
    """Label + entry box, with an optional helper/error line."""

    def __init__(self, master, label: str, value: str = "", placeholder: str = "",
                 width: int = 260, required: bool = False, show: Optional[str] = None,
                 **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        text = f"{label} *" if required else label
        ctk.CTkLabel(self, text=text, font=font(11, "bold"),
                     text_color=Theme.TEXT_MUTED, anchor="w").pack(fill="x")
        entry_kwargs: Dict[str, Any] = {
            "width": width, "height": 32, "corner_radius": 5,
            "border_color": Theme.BORDER, "fg_color": Theme.SURFACE,
            "text_color": Theme.TEXT, "font": font(12),
        }
        # A masked field must not carry placeholder text: the mask character is
        # applied to the placeholder too, which renders as a stray "*".
        if placeholder and not show:
            entry_kwargs["placeholder_text"] = placeholder
        if show:
            entry_kwargs["show"] = show
        self.entry = ctk.CTkEntry(self, **entry_kwargs)
        self.entry.pack(fill="x", pady=(2, 0))
        if value:
            self.entry.insert(0, value)
        self.hint = ctk.CTkLabel(self, text="", font=font(10),
                                 text_color=Theme.DANGER, anchor="w")
        self.hint.pack(fill="x")

    def get(self) -> str:
        return self.entry.get().strip()

    def set(self, value: str) -> None:
        self.entry.delete(0, "end")
        if value:
            self.entry.insert(0, str(value))

    def set_hint(self, message: str, kind: str = "danger") -> None:
        colour = {"danger": Theme.DANGER, "success": Theme.SUCCESS,
                  "muted": Theme.TEXT_MUTED}.get(kind, Theme.DANGER)
        self.hint.configure(text=message, text_color=colour)

    def focus(self) -> None:
        self.entry.focus_set()


class LabeledDropdown(ctk.CTkFrame):
    """Label + option menu."""

    def __init__(self, master, label: str, values: Sequence[str], value: str = "",
                 width: int = 260, command: Optional[Callable] = None, **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        ctk.CTkLabel(self, text=label, font=font(11, "bold"),
                     text_color=Theme.TEXT_MUTED, anchor="w").pack(fill="x")
        self.variable = ctk.StringVar(value=value or (values[0] if values else ""))
        self.menu = ctk.CTkOptionMenu(
            self, values=list(values) or [""], variable=self.variable, width=width,
            height=32, corner_radius=5, fg_color=Theme.SURFACE,
            button_color=Theme.SURFACE_ALT, button_hover_color=Theme.BORDER,
            text_color=Theme.TEXT, dropdown_fg_color=Theme.SURFACE,
            dropdown_text_color=Theme.TEXT, dropdown_hover_color=Theme.SURFACE_ALT,
            font=font(12), dropdown_font=font(12), command=command,
        )
        self.menu.pack(fill="x", pady=(2, 0))
        ctk.CTkLabel(self, text="", font=font(10)).pack(fill="x")

    def get(self) -> str:
        return self.variable.get()

    def set(self, value: str) -> None:
        values = self.menu.cget("values") or []
        if value and value not in values:
            self.menu.configure(values=list(values) + [value])
        self.variable.set(value or "")

    def set_values(self, values: Sequence[str], keep: bool = True) -> None:
        current = self.variable.get()
        self.menu.configure(values=list(values) or [""])
        if keep and current in values:
            self.variable.set(current)
        else:
            self.variable.set(values[0] if values else "")


class LabeledTextbox(ctk.CTkFrame):
    """Label + multi-line text area."""

    def __init__(self, master, label: str, value: str = "", height: int = 90,
                 **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        if label:
            ctk.CTkLabel(self, text=label, font=font(11, "bold"),
                         text_color=Theme.TEXT_MUTED, anchor="w").pack(fill="x")
        self.textbox = ctk.CTkTextbox(
            self, height=height, corner_radius=5, border_width=1,
            border_color=Theme.BORDER, fg_color=Theme.SURFACE,
            text_color=Theme.TEXT, font=font(12), wrap="word",
        )
        self.textbox.pack(fill="both", expand=True, pady=(2, 0))
        if value:
            self.textbox.insert("1.0", value)

    def get(self) -> str:
        return self.textbox.get("1.0", "end").strip()

    def set(self, value: str) -> None:
        self.textbox.delete("1.0", "end")
        if value:
            self.textbox.insert("1.0", str(value))

    def append(self, value: str) -> None:
        self.textbox.insert("end", str(value))

    def set_readonly(self, readonly: bool = True) -> None:
        self.textbox.configure(state="disabled" if readonly else "normal")


class SearchBar(ctk.CTkFrame):
    """Search entry that fires on Enter and on a button press."""

    def __init__(self, master, placeholder: str = "Search...",
                 command: Optional[Callable[[str], None]] = None,
                 width: int = 320, **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        self._command = command
        self.entry = ctk.CTkEntry(
            self, placeholder_text=placeholder, width=width, height=34,
            corner_radius=6, border_color=Theme.BORDER, fg_color=Theme.SURFACE,
            text_color=Theme.TEXT, font=font(12),
        )
        self.entry.pack(side="left")
        self.entry.bind("<Return>", lambda _e: self._fire())
        secondary_button(self, "Search", self._fire, width=84).pack(side="left", padx=(6, 0))
        secondary_button(self, "Clear", self.clear, width=70).pack(side="left", padx=(6, 0))

    def _fire(self) -> None:
        if self._command:
            self._command(self.entry.get().strip())

    def clear(self) -> None:
        self.entry.delete(0, "end")
        self._fire()

    def get(self) -> str:
        return self.entry.get().strip()


# ---------------------------------------------------------------------------
# Data table
# ---------------------------------------------------------------------------
_TREE_STYLE_READY = False


def _configure_tree_style() -> None:
    """Style ttk.Treeview once so it matches the CustomTkinter surfaces."""
    global _TREE_STYLE_READY
    if _TREE_STYLE_READY:
        return
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure(
        "CAGST.Treeview",
        background=Theme.SURFACE,
        fieldbackground=Theme.SURFACE,
        foreground=Theme.TEXT,
        rowheight=28,
        borderwidth=0,
        font=(Theme.FONT_FAMILY, 10),
    )
    style.configure(
        "CAGST.Treeview.Heading",
        background=Theme.SURFACE_ALT,
        foreground=Theme.TEXT,
        relief="flat",
        borderwidth=0,
        padding=(8, 6),
        font=(Theme.FONT_FAMILY, 10, "bold"),
    )
    style.map(
        "CAGST.Treeview.Heading",
        background=[("active", Theme.BORDER)],
    )
    style.map(
        "CAGST.Treeview",
        background=[("selected", Theme.SIDEBAR_ACTIVE)],
        foreground=[("selected", "#FFFFFF")],
    )
    style.configure("CAGST.Vertical.TScrollbar", background=Theme.SURFACE_ALT,
                    troughcolor=Theme.BG, borderwidth=0, arrowsize=12)
    style.configure("CAGST.Horizontal.TScrollbar", background=Theme.SURFACE_ALT,
                    troughcolor=Theme.BG, borderwidth=0, arrowsize=12)
    _TREE_STYLE_READY = True


class DataTable(ctk.CTkFrame):
    """
    A scrollable, sortable table built on ``ttk.Treeview``.

    ``columns`` is a sequence of ``(key, heading, width, anchor)`` tuples.
    Rows are supplied as dictionaries; ``row_id`` keeps the database id
    so selection can be mapped back to a record.
    """

    def __init__(self, master, columns: Sequence[Tuple[str, str, int, str]],
                 on_select: Optional[Callable[[Any], None]] = None,
                 on_double_click: Optional[Callable[[Any], None]] = None,
                 height: int = 12, **kwargs):
        kwargs.setdefault("fg_color", Theme.SURFACE)
        kwargs.setdefault("corner_radius", 6)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", Theme.BORDER)
        super().__init__(master, **kwargs)
        _configure_tree_style()

        self.columns = list(columns)
        self._keys = [c[0] for c in self.columns]
        self._rows: List[Dict[str, Any]] = []
        self._sort_state: Dict[str, bool] = {}
        self._on_select = on_select
        self._on_double_click = on_double_click

        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=1, pady=1)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(
            container, columns=self._keys, show="headings",
            style="CAGST.Treeview", height=height, selectmode="browse",
        )
        vsb = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview,
                            style="CAGST.Vertical.TScrollbar")
        hsb = ttk.Scrollbar(container, orient="horizontal", command=self.tree.xview,
                            style="CAGST.Horizontal.TScrollbar")
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        for key, heading, width, anchor in self.columns:
            self.tree.heading(key, text=heading,
                              command=lambda k=key: self._sort_by(k))
            self.tree.column(key, width=width, anchor=anchor,
                             minwidth=max(40, width // 2), stretch=True)

        self.tree.tag_configure("odd", background="#FAFBFD")
        self.tree.tag_configure("even", background=Theme.SURFACE)
        self.tree.tag_configure("danger", foreground=Theme.DANGER)
        self.tree.tag_configure("warning", foreground=Theme.WARNING)
        self.tree.tag_configure("success", foreground=Theme.SUCCESS)
        self.tree.tag_configure("muted", foreground=Theme.TEXT_MUTED)

        self.tree.bind("<<TreeviewSelect>>", self._handle_select)
        self.tree.bind("<Double-1>", self._handle_double_click)

    # -- data -------------------------------------------------------------
    def load(self, rows: Iterable[Dict[str, Any]], id_key: str = "id",
             tag_fn: Optional[Callable[[Dict[str, Any]], str]] = None) -> None:
        """Replace the table contents."""
        self.clear()
        self._rows = list(rows)
        for index, row in enumerate(self._rows):
            values = [self._cell(row, key) for key in self._keys]
            tags = ["odd" if index % 2 else "even"]
            if tag_fn:
                extra = tag_fn(row)
                if extra:
                    tags.append(extra)
            self.tree.insert(
                "", "end", iid=str(row.get(id_key, index)), values=values, tags=tuple(tags)
            )

    @staticmethod
    def _cell(row: Dict[str, Any], key: str) -> str:
        value = row.get(key, "")
        return "" if value is None else str(value)

    def clear(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._rows = []

    def selected_id(self) -> Optional[str]:
        selection = self.tree.selection()
        return selection[0] if selection else None

    def selected_int_id(self) -> Optional[int]:
        value = self.selected_id()
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def selected_row(self) -> Optional[Dict[str, Any]]:
        selected = self.selected_id()
        if selected is None:
            return None
        for row in self._rows:
            if str(row.get("id")) == selected:
                return row
        return None

    def select_first(self) -> None:
        children = self.tree.get_children()
        if children:
            self.tree.selection_set(children[0])
            self.tree.focus(children[0])

    def select_by_id(self, record_id) -> None:
        iid = str(record_id)
        if iid in self.tree.get_children():
            self.tree.selection_set(iid)
            self.tree.see(iid)

    @property
    def row_count(self) -> int:
        return len(self._rows)

    # -- events -----------------------------------------------------------
    def _handle_select(self, _event=None) -> None:
        if self._on_select:
            self._on_select(self.selected_row())

    def _handle_double_click(self, _event=None) -> None:
        if self._on_double_click:
            self._on_double_click(self.selected_row())

    def _sort_by(self, key: str) -> None:
        descending = self._sort_state.get(key, False)
        self._sort_state[key] = not descending

        def sort_key(row: Dict[str, Any]):
            value = row.get(key, "")
            text = str(value).replace("₹", "").replace(",", "").strip()
            try:
                return (0, float(text))
            except (TypeError, ValueError):
                return (1, str(value).lower())

        rows = sorted(self._rows, key=sort_key, reverse=descending)
        self.load(rows)


# ---------------------------------------------------------------------------
# Key/value display grid
# ---------------------------------------------------------------------------
class DetailGrid(ctk.CTkFrame):
    """Two-column label/value display used on overview panels."""

    def __init__(self, master, columns: int = 2, **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        self._columns = columns
        self._row = 0
        self._col = 0
        for index in range(columns):
            self.grid_columnconfigure(index * 2 + 1, weight=1, minsize=140)

    def add(self, label: str, value: str, value_color: Optional[str] = None,
            bold: bool = False) -> None:
        ctk.CTkLabel(
            self, text=f"{label}:", font=font(11, "bold"),
            text_color=Theme.TEXT_MUTED, anchor="w",
        ).grid(row=self._row, column=self._col * 2, sticky="w", padx=(0, 8), pady=3)
        ctk.CTkLabel(
            self, text=str(value) if value not in (None, "") else "-",
            font=font(12, "bold" if bold else "normal"),
            text_color=value_color or Theme.TEXT, anchor="w", justify="left",
            wraplength=360,
        ).grid(row=self._row, column=self._col * 2 + 1, sticky="w", padx=(0, 24), pady=3)

        self._col += 1
        if self._col >= self._columns:
            self._col = 0
            self._row += 1

    def add_full(self, label: str, value: str, wraplength: int = 900) -> None:
        """A row that spans the full width -- for summaries and long text."""
        if self._col != 0:
            self._col = 0
            self._row += 1
        ctk.CTkLabel(
            self, text=f"{label}:", font=font(11, "bold"),
            text_color=Theme.TEXT_MUTED, anchor="nw",
        ).grid(row=self._row, column=0, sticky="nw", padx=(0, 8), pady=3)
        ctk.CTkLabel(
            self, text=str(value) if value not in (None, "") else "-", font=font(12),
            text_color=Theme.TEXT, anchor="w", justify="left", wraplength=wraplength,
        ).grid(row=self._row, column=1, columnspan=self._columns * 2 - 1,
               sticky="w", pady=3)
        self._row += 1

    def reset(self) -> None:
        for child in self.winfo_children():
            child.destroy()
        self._row = 0
        self._col = 0


# ---------------------------------------------------------------------------
# Dialogs
# ---------------------------------------------------------------------------
class ModalDialog(ctk.CTkToplevel):
    """
    Base modal window centred on its parent.

    Pass ``resizable=False`` for fixed-size dialogs. Do **not** call
    ``self.resizable(...)`` in a subclass: on Windows, CustomTkinter re-runs
    its title-bar colour routine on every ``resizable()`` call, and that
    routine withdraws the window and then restores whatever state it sampled.
    Two overlapping runs make the second sample the state during the first
    one's withdrawal, so the window is restored to "withdrawn" and never
    becomes visible again. Calling it exactly once avoids that.
    """

    def __init__(self, parent, title: str, width: int = 640, height: int = 520,
                 resizable: bool = True):
        super().__init__(parent, fg_color=Theme.BG)
        self.title(title)
        self.resizable(resizable, resizable)     # exactly once - see the docstring
        self.transient(parent)
        self._centre(parent, width, height)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self._closing = False
        self.after(120, self._grab)
        self.after(280, self._ensure_visible)

    def _grab(self) -> None:
        try:
            self.deiconify()
            self.grab_set()
            self.lift()
            self.focus_force()
        except tk.TclError:
            pass

    def _ensure_visible(self, attempts: int = 6) -> None:
        """
        Last-resort guard against the dialog being left withdrawn.

        A hidden modal dialog is the worst possible failure -- the user is
        blocked with no explanation -- so visibility is re-asserted after
        the toolkit's own delayed callbacks have run. The check repeats for
        about a second and a half because CustomTkinter's title-bar routine
        is itself deferred: when several dialogs are created close together
        a later run can withdraw a window that was already visible, so one
        single check is not enough to catch it.
        """
        if getattr(self, "_closing", False):
            return
        try:
            if not self.winfo_viewable():
                self.deiconify()
                self.lift()
                self.focus_force()
            if attempts > 1:
                self.after(250, lambda: self._ensure_visible(attempts - 1))
        except tk.TclError:
            pass

    def _centre(self, parent, width: int, height: int) -> None:
        try:
            parent.update_idletasks()
            x = parent.winfo_rootx() + max(0, (parent.winfo_width() - width) // 2)
            y = parent.winfo_rooty() + max(0, (parent.winfo_height() - height) // 3)
        except tk.TclError:
            x, y = 200, 120
        self.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")

    def close(self) -> None:
        self._closing = True          # stops the visibility guard re-arming
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class MessageDialog(ModalDialog):
    """Information / confirmation dialog with a professional look."""

    def __init__(self, parent, title: str, message: str, kind: str = "info",
                 confirm: bool = False, confirm_text: str = "Confirm",
                 on_confirm: Optional[Callable[[], None]] = None):
        super().__init__(parent, title, width=520, height=250)
        self.result = False
        self._on_confirm = on_confirm

        accent = {
            "info": Theme.INFO, "success": Theme.SUCCESS,
            "warning": Theme.WARNING, "danger": Theme.DANGER,
        }.get(kind, Theme.INFO)

        ctk.CTkFrame(self, fg_color=accent, height=4, corner_radius=0).pack(fill="x")
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text=title, font=font(15, "bold"),
                     text_color=accent, anchor="w").pack(fill="x")
        ctk.CTkLabel(body, text=message, font=font(12), text_color=Theme.TEXT,
                     wraplength=460, justify="left", anchor="w").pack(
            fill="both", expand=True, pady=(8, 12))

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x")
        if confirm:
            secondary_button(buttons, "Cancel", self.close, width=100).pack(side="right")
            button = danger_button if kind == "danger" else primary_button
            button(buttons, confirm_text, self._confirm, width=140).pack(
                side="right", padx=(0, 8))
        else:
            primary_button(buttons, "OK", self.close, width=100).pack(side="right")

    def _confirm(self) -> None:
        self.result = True
        callback = self._on_confirm
        self.close()
        if callback:
            callback()


def show_info(parent, title: str, message: str) -> None:
    MessageDialog(parent, title, message, kind="info")


def show_success(parent, title: str, message: str) -> None:
    MessageDialog(parent, title, message, kind="success")


def show_warning(parent, title: str, message: str) -> None:
    MessageDialog(parent, title, message, kind="warning")


def show_error(parent, title: str, message: str) -> None:
    MessageDialog(parent, title, message, kind="danger")


class AIErrorDialog(ModalDialog):
    """
    An AI failure, with a way out.

    When the live API cannot be reached, the presenter is offered a switch to
    Demo Mode rather than being left stuck. The switch is never automatic:
    changing mode is the user's decision.
    """

    def __init__(self, parent, title: str, message: str,
                 on_switch_to_demo: Optional[Callable[[], None]] = None):
        super().__init__(parent, title, width=560, height=360)
        self._on_switch = on_switch_to_demo

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=22, pady=18)

        ctk.CTkLabel(body, text=title, font=font(15, "bold"),
                     text_color=Theme.DANGER, anchor="w").pack(fill="x")
        ctk.CTkLabel(body, text=message, font=font(12), text_color=Theme.TEXT,
                     wraplength=500, justify="left", anchor="w").pack(
            fill="both", expand=True, pady=(8, 10))

        if on_switch_to_demo is not None:
            hint = ctk.CTkFrame(body, fg_color=Theme.WARNING_BG, corner_radius=6)
            hint.pack(fill="x", pady=(0, 10))
            ctk.CTkLabel(
                hint,
                text="Demo Mode uses predefined sample output and needs no "
                     "internet connection or API key. Switching affects AI "
                     "actions only; your data is untouched.",
                font=font(11), text_color=Theme.WARNING, wraplength=480,
                justify="left").pack(padx=12, pady=8, anchor="w")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x")
        secondary_button(buttons, "Close", self.close, width=100).pack(side="right")
        if on_switch_to_demo is not None:
            primary_button(buttons, "Switch to Demo Mode", self._switch,
                           width=190).pack(side="right", padx=(0, 8))

    def _switch(self) -> None:
        callback = self._on_switch
        self.close()
        if callback:
            callback()


def show_ai_error(page, title: str, message: str) -> None:
    """
    Report an AI failure from a page, offering Demo Mode when it would help.

    ``page`` is any BasePage; its ``app`` supplies the current mode.
    """
    app = getattr(page, "app", None)
    offer = None
    if app is not None and not getattr(app, "demo_mode", True):
        def switch() -> None:
            app.set_demo_mode(True)
            app.set_status("Demo Mode enabled - AI actions now use sample output",
                           "warning")

        offer = switch
    AIErrorDialog(page, title, message, on_switch_to_demo=offer)


def confirm_action(parent, title: str, message: str, on_confirm: Callable[[], None],
                   confirm_text: str = "Confirm", kind: str = "danger") -> None:
    """Ask before doing something destructive."""
    MessageDialog(parent, title, message, kind=kind, confirm=True,
                  confirm_text=confirm_text, on_confirm=on_confirm)


class BusyDialog(ModalDialog):
    """Indeterminate progress dialog shown while a background task runs."""

    def __init__(self, parent, title: str = "Working", message: str = "Please wait..."):
        super().__init__(parent, title, width=420, height=170, resizable=False)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=24, pady=20)
        ctk.CTkLabel(body, text=title, font=font(14, "bold"),
                     text_color=Theme.PRIMARY).pack(anchor="w")
        self.message_label = ctk.CTkLabel(body, text=message, font=font(12),
                                          text_color=Theme.TEXT, wraplength=360,
                                          justify="left")
        self.message_label.pack(anchor="w", pady=(6, 12))
        self.bar = ctk.CTkProgressBar(body, mode="indeterminate", height=8,
                                      progress_color=Theme.PRIMARY)
        self.bar.pack(fill="x")
        self.bar.start()

    def set_message(self, message: str) -> None:
        try:
            self.message_label.configure(text=message)
        except tk.TclError:
            pass

    def close(self) -> None:
        try:
            self.bar.stop()
        except tk.TclError:
            pass
        super().close()


# ---------------------------------------------------------------------------
# Background task runner (keeps the UI responsive during AI calls)
# ---------------------------------------------------------------------------
def run_in_background(widget: tk.Misc, work: Callable[[], Any],
                      on_success: Callable[[Any], None],
                      on_error: Optional[Callable[[Exception], None]] = None,
                      busy: Optional[BusyDialog] = None,
                      poll_ms: int = 120) -> None:
    """
    Run ``work`` on a worker thread and deliver the result on the Tk thread.

    Tkinter is not thread safe, so the worker only puts its outcome on a
    queue; the result is picked up by an ``after`` poll and the callbacks
    then run on the main thread.
    """
    result_queue: "queue.Queue[Tuple[bool, Any]]" = queue.Queue(maxsize=1)

    def worker() -> None:
        try:
            result_queue.put((True, work()))
        except Exception as exc:  # noqa: BLE001 - surfaced to the user
            result_queue.put((False, exc))

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()

    def poll() -> None:
        try:
            ok, payload = result_queue.get_nowait()
        except queue.Empty:
            try:
                widget.after(poll_ms, poll)
            except tk.TclError:
                pass
            return
        if busy is not None:
            busy.close()
        if ok:
            on_success(payload)
        elif on_error is not None:
            on_error(payload)
        else:
            raise payload

    widget.after(poll_ms, poll)


# ---------------------------------------------------------------------------
# Misc helpers
# ---------------------------------------------------------------------------
def risk_tag(risk: str) -> str:
    return {"High": "danger", "Medium": "warning", "Low": "success"}.get(risk or "", "muted")


def copy_to_clipboard(widget: tk.Misc, text: str) -> bool:
    """Put text on the system clipboard."""
    try:
        widget.clipboard_clear()
        widget.clipboard_append(text)
        widget.update_idletasks()
        return True
    except tk.TclError:
        return False


def install_quiet_error_handlers(window: tk.Misc) -> None:
    """
    Keep the console clean when a window closes.

    CustomTkinter schedules periodic scaling and redraw callbacks. When a
    window is destroyed, any callback still queued in Tcl refers to a command
    that no longer exists, and Tcl prints an "invalid command name" background
    error. That is harmless but looks alarming in an IDLE shell, so those
    specific messages are filtered out; everything else is still reported.
    """
    handler = """
        proc bgerror {msg} {
            if {[string match "*invalid command name*" $msg]} {
                return
            }
            puts stderr "Tk background error: $msg"
        }
    """
    try:
        window.tk.eval(handler)
    except tk.TclError:
        pass


def close_window_safely(window: tk.Misc) -> None:
    """
    Destroy a top-level window, falling back to ``quit()`` if Tk objects.

    Tk can raise ``TclError`` part-way through tearing down a deep widget
    tree; the event loop must still be left, or the application would hang.
    """
    try:
        window.destroy()
    except tk.TclError:
        try:
            window.quit()  # type: ignore[attr-defined]
        except (tk.TclError, AttributeError):
            pass


def table_text(value: Any, length: int = 60) -> str:
    """Shorten a value for display inside a table cell."""
    return truncate(value, length)
