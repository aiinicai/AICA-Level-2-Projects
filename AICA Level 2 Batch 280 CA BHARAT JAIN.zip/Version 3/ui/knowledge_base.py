"""
ui.knowledge_base
=================
Local GST knowledge repository.

Documents are stored under ``knowledge_base/<category>/`` and indexed
into page-anchored passages so that research answers can cite a real
file and page.  Only searchable (text-based) PDFs can be indexed in this
version -- scanned documents are reported, never silently skipped.

Legislation can be added in two ways: a PDF the user already holds, or a
direct download from the CBIC Tax Information Portal
(https://www.cbic.gov.in/entities/gst), which supplies the GST Acts,
Rules, Notifications and Circulars as published by the department.
"""

from __future__ import annotations

import queue
import webbrowser
from tkinter import filedialog
from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import cbic_service, demo_kb, rag_service
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, DataTable, KpiCard, LabeledDropdown, LabeledEntry,
    LabeledTextbox, ModalDialog, SearchBar, confirm_action, danger_button, font,
    primary_button, run_in_background, secondary_button, show_error, show_info,
    show_success, show_warning,
)
from utils.formatters import format_datetime, truncate
from utils.helpers import human_size, open_in_explorer, resolve_stored_path
from utils.logger import get_logger

log = get_logger(__name__)

DOCUMENT_COLUMNS = [
    ("file_name", "File Name", 330, "w"),
    ("category_display", "Category", 140, "w"),
    ("date_display", "Date Added", 130, "center"),
    ("indexed_display", "Indexed", 90, "center"),
    ("pages", "Pages", 60, "center"),
    ("chunk_count", "Passages", 80, "center"),
    ("notes_short", "Notes", 320, "w"),
]

SEARCH_COLUMNS = [
    ("ref", "Ref", 50, "center"),
    ("file_name", "File", 250, "w"),
    ("category", "Category", 130, "w"),
    ("page", "Page", 55, "center"),
    ("score", "Relevance", 85, "e"),
    ("excerpt", "Extract", 620, "w"),
]

CBIC_COLUMNS = [
    ("category", "Type", 110, "w"),
    ("number", "Number", 190, "w"),
    ("title", "Title", 520, "w"),
    ("issued", "Issued", 100, "center"),
    ("status_display", "Status", 130, "w"),
]

ALL = "All"

CATEGORY_LABELS = {
    "acts": "Acts",
    "rules": "Rules",
    "circulars": "Circulars",
    "notifications": "Notifications",
    "case_laws": "Case Laws",
    "internal_research": "Internal Research",
}


class KnowledgeBasePage(BasePage):
    """Manage and search the local GST knowledge base."""

    title = "Knowledge Base"
    subtitle = "Local GST repository used to ground research answers"

    def build(self) -> None:
        primary_button(self.header_actions, "+ Add PDF", self._add_pdf,
                       width=110).pack(side="right")
        secondary_button(self.header_actions, "Import from CBIC", self._import_cbic,
                         width=145).pack(side="right", padx=(0, 8))
        secondary_button(self.header_actions, "Refresh Index", self._rebuild_index,
                         width=125).pack(side="right", padx=(0, 8))
        secondary_button(self.header_actions, "Scan Folder", self._sync_folder,
                         width=110).pack(side="right", padx=(0, 8))

        # -- KPI strip --------------------------------------------------------
        kpis = ctk.CTkFrame(self.body, fg_color="transparent")
        kpis.pack(fill="x", pady=(0, 10))
        self.kpis: Dict[str, KpiCard] = {}
        for index, (key, label, accent) in enumerate((
            ("documents", "Documents", Theme.PRIMARY),
            ("indexed", "Indexed", Theme.SUCCESS),
            ("unindexed", "Not Indexed", Theme.WARNING),
            ("chunks", "Searchable Passages", "#5B3FA8"),
        )):
            kpis.grid_columnconfigure(index, weight=1, uniform="kb")
            card = KpiCard(kpis, label, "-", "", accent)
            card.grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 8, 0))
            self.kpis[key] = card

        # -- tabs -------------------------------------------------------------
        self.tabs = ctk.CTkTabview(
            self.body, fg_color=Theme.SURFACE,
            segmented_button_fg_color=Theme.SURFACE_ALT,
            segmented_button_selected_color=Theme.PRIMARY,
            segmented_button_selected_hover_color=Theme.PRIMARY_HOVER,
            segmented_button_unselected_color=Theme.SURFACE_ALT,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
        )
        self.tabs.pack(fill="both", expand=True)
        self.tab_documents = self.tabs.add("Documents")
        self.tab_search = self.tabs.add("Search Passages")

        self._build_documents_tab()
        self._build_search_tab()

    # ------------------------------------------------------------------
    def _build_documents_tab(self) -> None:
        tab = self.tab_documents

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(12, 6))

        SearchBar(toolbar, "Search file name, title or notes...",
                  self._on_document_search, width=330).pack(side="left")
        self.category_filter = LabeledDropdown(
            toolbar, "Category", [ALL] + config.KB_CATEGORIES, ALL, width=180,
            command=lambda _v: self._load_documents())
        self.category_filter.pack(side="left", padx=16)

        secondary_button(toolbar, "Open File", self._open_file, width=100).pack(side="left")
        secondary_button(toolbar, "Re-index File", self._index_selected,
                         width=120).pack(side="left", padx=6)
        secondary_button(toolbar, "Edit Notes", self._edit_notes, width=110).pack(side="left")
        danger_button(toolbar, "Remove", self._remove_document, width=95).pack(
            side="left", padx=6)

        secondary_button(toolbar, "Open KB Folder",
                         lambda: open_in_explorer(config.KNOWLEDGE_BASE_DIR),
                         width=130).pack(side="right")

        self.document_table = DataTable(tab, DOCUMENT_COLUMNS, height=14)
        self.document_table.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        note = ctk.CTkFrame(tab, fg_color=Theme.INFO_BG, corner_radius=6)
        note.pack(fill="x", padx=12, pady=(0, 12))
        ctk.CTkLabel(
            note,
            text="Only searchable (text-based) PDFs can be indexed in this version. "
                 "Scanned documents are listed but marked as not indexed - OCR is not "
                 "available. Research answers cite only documents held here.",
            font=font(11), text_color=Theme.INFO, anchor="w", justify="left",
            wraplength=1180,
        ).pack(padx=12, pady=8, anchor="w")

        self._search_text = ""

    def _build_search_tab(self) -> None:
        tab = self.tab_search

        bar = ctk.CTkFrame(tab, fg_color="transparent")
        bar.pack(fill="x", padx=12, pady=(12, 6))

        self.passage_query = LabeledEntry(
            bar, "Search the indexed passages", width=560,
            placeholder="e.g. conditions for availing input tax credit")
        self.passage_query.pack(side="left")
        self.passage_query.entry.bind("<Return>", lambda _e: self._search_passages())

        self.search_category = LabeledDropdown(
            bar, "Category", [ALL] + config.KB_CATEGORIES, ALL, width=170)
        self.search_category.pack(side="left", padx=14)

        box = ctk.CTkFrame(bar, fg_color="transparent")
        box.pack(side="left")
        ctk.CTkLabel(box, text=" ", font=font(11)).pack()
        primary_button(box, "Search", self._search_passages, width=110).pack()

        ctk.CTkLabel(
            tab,
            text="This is a direct passage search, not an AI answer. Use GST Research "
                 "to obtain a structured, source-grounded answer.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
        ).pack(fill="x", padx=14, pady=(0, 6))

        self.search_table = DataTable(tab, SEARCH_COLUMNS, height=10,
                                      on_double_click=self._show_passage)
        self.search_table.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    # ==================================================================
    def refresh(self) -> None:
        self._load_documents()

    def _load_documents(self) -> None:
        try:
            status = rag_service.knowledge_base_status()
            category = self.category_filter.get()
            documents = db.list_knowledge_documents(
                "" if category == ALL else category, self._search_text)
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self.kpis["documents"].update_values(str(status["documents"]),
                                             f"{len(status['by_category'])} categories")
        self.kpis["indexed"].update_values(str(status["indexed"]), "searchable")
        self.kpis["unindexed"].update_values(
            str(status["unindexed"]),
            "add searchable PDFs" if status["unindexed"] else "all indexed")
        self.kpis["chunks"].update_values(f"{status['chunks']:,}", "indexed passages")

        rows: List[Dict[str, Any]] = []
        for document in documents:
            path = resolve_stored_path(document.get("file_path", ""))
            missing = not path.exists()
            rows.append({
                "id": document["id"],
                "file_name": document.get("file_name", ""),
                "category_display": CATEGORY_LABELS.get(document.get("category", ""),
                                                        document.get("category", "")),
                "date_display": format_datetime(document.get("date_added")),
                "indexed_display": ("File missing" if missing else
                                    ("Yes" if document.get("indexed") else "No")),
                "pages": document.get("pages") or "-",
                "chunk_count": document.get("chunk_count") or 0,
                "notes_short": truncate(document.get("notes"), 90),
            })
        self.document_table.load(rows, tag_fn=lambda r: {
            "Yes": "success", "No": "warning", "File missing": "danger",
        }.get(r["indexed_display"], ""))

        self.status(f"{len(rows)} knowledge-base document(s); "
                    f"{status['chunks']:,} searchable passage(s)")

        if not rows and self.category_filter.get() == ALL and not self._search_text:
            self._offer_demo_kb()

    def _offer_demo_kb(self) -> None:
        """First-run helper: offer to create the demonstration knowledge base."""
        if getattr(self, "_offered_demo", False):
            return
        self._offered_demo = True
        confirm_action(
            self, "Knowledge base is empty",
            "The knowledge base has no documents, so GST Research cannot cite "
            "anything yet.\n\n"
            "Create three clearly-labelled demonstration documents (an extract of "
            "the input tax credit provision, the related rules, and an internal "
            "research note) so the research workflow can be demonstrated?\n\n"
            "Replace them with authentic official publications before professional "
            "use.",
            self._load_demo_kb, confirm_text="Create demo documents", kind="info",
        )

    def _on_document_search(self, text: str) -> None:
        self._search_text = text
        self._load_documents()

    # ==================================================================
    def _add_pdf(self) -> None:
        if self.block_if_readonly():
            return
        paths = filedialog.askopenfilenames(
            title="Select GST knowledge base PDF(s)",
            filetypes=[("PDF files", "*.pdf")],
        )
        if not paths:
            return
        AddDocumentDialog(self, list(paths), on_done=self._after_add)

    def _after_add(self, added: int, messages: List[str]) -> None:
        self._load_documents()
        self.status(f"{added} document(s) added to the knowledge base", "success")
        if messages:
            show_info(self, "Documents added", "\n".join(messages[:12]))

    def _import_cbic(self) -> None:
        """Download official GST legislation from the CBIC portal."""
        if self.block_if_readonly():
            return
        CBICImportDialog(self, on_done=self._after_cbic_import)

    def _after_cbic_import(self, result) -> None:
        self._load_documents()
        self.status(f"CBIC import: {result.summary}",
                    "success" if result.downloaded or result.skipped else "warning")

    def _sync_folder(self) -> None:
        if self.block_if_readonly():
            return
        busy = BusyDialog(self, "Scanning folders",
                          "Looking for PDFs in the knowledge_base folders...")

        def work():
            return rag_service.sync_folder()

        def done(result) -> None:
            added, messages = result
            self._load_documents()
            if added:
                show_success(self, "Folder scan complete",
                             f"{added} new document(s) registered.\n\n"
                             "Use 'Refresh Index' to make them searchable.")
            else:
                show_info(self, "Folder scan complete",
                          "No new PDFs were found in the knowledge_base folders.")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Scan failed", str(exc)), busy)

    def _rebuild_index(self) -> None:
        if self.block_if_readonly():
            return
        documents = db.list_knowledge_documents()
        if not documents:
            show_warning(self, "Nothing to index",
                         "Add at least one searchable PDF to the knowledge base first.")
            return

        chunk_size = int(self.app.settings.get("rag_chunk_size", 1200))
        busy = BusyDialog(self, "Refreshing index",
                          f"Indexing {len(documents)} document(s)...")

        def work():
            return rag_service.rebuild_index(chunk_size=chunk_size)

        def done(result: rag_service.IndexResult) -> None:
            self._load_documents()
            self.status(result.message, "success")
            detail = result.message
            if result.problems:
                detail += "\n\nItems that could not be indexed:\n" + \
                          "\n".join(f"• {p}" for p in result.problems[:10])
            show_success(self, "Index refreshed", detail)

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Indexing failed", str(exc)), busy)

    def _index_selected(self) -> None:
        document_id = self.document_table.selected_int_id()
        if not document_id:
            show_warning(self, "No document selected", "Please select a document first.")
            return
        document = db.get_knowledge_document(document_id)
        if not document:
            return
        chunk_size = int(self.app.settings.get("rag_chunk_size", 1200))
        busy = BusyDialog(self, "Indexing", f"Indexing {document['file_name']}...")

        def work():
            return rag_service.index_document(document, chunk_size)

        def done(result) -> None:
            ok, message, _chunks = result
            self._load_documents()
            (show_success if ok else show_warning)(
                self, "Indexing complete" if ok else "Could not index", message)

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Indexing failed", str(exc)), busy)

    def _open_file(self) -> None:
        document_id = self.document_table.selected_int_id()
        if not document_id:
            show_warning(self, "No document selected", "Please select a document first.")
            return
        document = db.get_knowledge_document(document_id)
        path = resolve_stored_path((document or {}).get("file_path", ""))
        if not open_in_explorer(path):
            show_error(self, "Could not open",
                       f"The file could not be opened:\n{path}")

    def _edit_notes(self) -> None:
        if self.block_if_readonly():
            return
        document_id = self.document_table.selected_int_id()
        if not document_id:
            show_warning(self, "No document selected", "Please select a document first.")
            return
        document = db.get_knowledge_document(document_id)
        if document:
            NotesDialog(self, document, on_saved=self._load_documents)

    def _remove_document(self) -> None:
        if self.block_if_readonly():
            return
        document_id = self.document_table.selected_int_id()
        if not document_id:
            show_warning(self, "No document selected", "Please select a document first.")
            return
        document = db.get_knowledge_document(document_id)
        if not document:
            return

        def do_remove() -> None:
            ok, message = rag_service.remove_document(document_id, delete_file=False)
            self._load_documents()
            self.status(message, "success" if ok else "danger")

        confirm_action(
            self, "Remove from knowledge base",
            f"Remove '{document['file_name']}' from the knowledge base index?\n\n"
            "The PDF itself remains in the knowledge_base folder on disk.",
            do_remove, confirm_text="Remove")

    def _load_demo_kb(self) -> None:
        busy = BusyDialog(self, "Preparing demonstration documents",
                          "Creating and indexing the sample knowledge base...")

        def work():
            return demo_kb.load_demo_knowledge_base()

        def done(result) -> None:
            written, chunks, messages = result
            self._load_documents()
            show_success(
                self, "Demonstration knowledge base ready",
                f"{written} document(s) created and {chunks} passage(s) indexed.\n\n"
                "These are clearly marked as demonstration extracts. Replace them "
                "with authentic official publications before professional use.")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Could not prepare", str(exc)),
                          busy)

    # ==================================================================
    def _search_passages(self) -> None:
        question = self.passage_query.get()
        if not question:
            show_warning(self, "Nothing to search", "Please enter a search phrase.")
            return
        category = self.search_category.get()
        top_k = max(10, int(self.app.settings.get("rag_top_k", 6)))

        try:
            hits = rag_service.search(question, top_k=top_k,
                                      category="" if category == ALL else category)
        except Exception as exc:  # noqa: BLE001
            log.exception("Passage search failed")
            show_error(self, "Search failed", str(exc))
            return

        rows = [
            {
                "id": index,
                "ref": chunk.ref,
                "file_name": chunk.file_name,
                "category": CATEGORY_LABELS.get(chunk.category, chunk.category),
                "page": chunk.page or "-",
                "score": f"{chunk.score:.3f}",
                "excerpt": truncate(chunk.text, 200),
                "_full": chunk.text,
            }
            for index, chunk in enumerate(hits, start=1)
        ]
        self.search_table.load(rows)
        if not rows:
            self.status("No matching passage found in the knowledge base", "warning")
            show_info(
                self, "No match",
                "No sufficiently relevant passage was located in the current local "
                "knowledge base.\n\n"
                "Add the relevant Act, rules, circulars, notifications or case notes, "
                "refresh the index, and try again.")
        else:
            self.status(f"{len(rows)} passage(s) retrieved", "success")

    def _show_passage(self, row: Optional[Dict[str, Any]]) -> None:
        if not row:
            return
        PassageDialog(self, row)


class AddDocumentDialog(ModalDialog):
    """Choose the category (and notes) for one or more new documents."""

    def __init__(self, parent, paths: List[str], on_done=None):
        super().__init__(parent, "Add to knowledge base", width=620, height=440)
        self._paths = paths
        self._on_done = on_done

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text=f"Add {len(paths)} document(s)",
                     font=font(16, "bold"), text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text="The file(s) will be copied into the selected knowledge_base folder "
                 "and indexed so their passages can be cited in research answers.",
            font=font(11), text_color=Theme.TEXT_MUTED, wraplength=540,
            justify="left").pack(anchor="w", pady=(2, 12))

        listing = ctk.CTkTextbox(body, height=110, font=font(11),
                                 fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                                 border_width=1, border_color=Theme.BORDER)
        listing.pack(fill="x")
        from pathlib import Path

        for path in paths:
            p = Path(path)
            size = human_size(p.stat().st_size) if p.exists() else "?"
            listing.insert("end", f"{p.name}   ({size})\n")
        listing.configure(state="disabled")

        self.category = LabeledDropdown(body, "Category", config.KB_CATEGORIES,
                                        "acts", width=540)
        self.category.pack(fill="x", pady=(10, 0))
        self.notes = LabeledEntry(body, "Notes (optional)", width=540,
                                  placeholder="e.g. as amended up to Finance Act 2023")
        self.notes.pack(fill="x")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(14, 0))
        primary_button(buttons, "Add and index", self._add, width=150).pack(side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _add(self) -> None:
        category = self.category.get()
        notes = self.notes.get()
        paths = list(self._paths)
        parent = self.master
        callback = self._on_done
        self.close()

        busy = BusyDialog(parent, "Adding documents",
                          f"Copying and indexing {len(paths)} document(s)...")

        def work():
            added = 0
            messages: List[str] = []
            for path in paths:
                ok, message, document_id = rag_service.add_document(
                    path, category, notes)
                messages.append(message)
                if ok and document_id:
                    added += 1
                    document = db.get_knowledge_document(document_id)
                    if document:
                        index_ok, index_message, _n = rag_service.index_document(document)
                        if not index_ok:
                            messages.append(index_message)
            rag_service._invalidate_cache()  # noqa: SLF001 - refresh the search cache
            return added, messages

        def done(result) -> None:
            added, messages = result
            if callback:
                callback(added, messages)

        run_in_background(parent, work, done,
                          lambda exc: show_error(parent, "Could not add", str(exc)),
                          busy)


class CBICImportDialog(ModalDialog):
    """
    Browse the CBIC Tax Information Portal and import legislation.

    The catalogue is fetched first so the user can see exactly what will be
    downloaded; nothing is written to the knowledge base until Import is
    pressed. Documents already held are skipped, so the dialog can be run
    again safely to pick up newly issued circulars.
    """

    CATEGORIES = [
        ("Act", "Acts", True),
        ("Rule", "Rules", True),
        ("Notification", "Notifications", False),
        ("Circular", "Circulars / Instructions", False),
    ]

    def __init__(self, parent, on_done=None):
        super().__init__(parent, "Import GST legislation from CBIC",
                         width=1040, height=660)
        self._on_done = on_done
        self._documents: List[cbic_service.CBICDocument] = []
        self._listed: List[cbic_service.CBICDocument] = []
        self._progress: "queue.Queue[str]" = queue.Queue()
        self._busy: Optional[BusyDialog] = None
        self._held = self._existing_filenames()

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text="CBIC Tax Information Portal", font=font(16, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text=f"Source: {config.CBIC_PORTAL_URL}\n{config.CBIC_SOURCE_NOTE}",
            font=font(11), text_color=Theme.TEXT_MUTED, justify="left",
            wraplength=940).pack(anchor="w", pady=(2, 10))

        # -- category selection ------------------------------------------
        picker = ctk.CTkFrame(body, fg_color=Theme.SURFACE_ALT, corner_radius=6)
        picker.pack(fill="x")
        row = ctk.CTkFrame(picker, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=12)
        ctk.CTkLabel(row, text="Fetch:", font=font(12, "bold"),
                     text_color=Theme.TEXT).pack(side="left", padx=(0, 10))

        self.category_vars: Dict[str, ctk.BooleanVar] = {}
        for key, label, default in self.CATEGORIES:
            var = ctk.BooleanVar(value=default)
            self.category_vars[key] = var
            ctk.CTkCheckBox(row, text=label, variable=var, font=font(12),
                            text_color=Theme.TEXT, checkbox_width=18,
                            checkbox_height=18, fg_color=Theme.PRIMARY,
                            hover_color=Theme.PRIMARY_HOVER).pack(side="left",
                                                                  padx=(0, 18))
        primary_button(row, "Fetch Catalogue", self._fetch, width=140).pack(side="right")

        # -- filter -------------------------------------------------------
        filter_row = ctk.CTkFrame(body, fg_color="transparent")
        filter_row.pack(fill="x", pady=(10, 0))
        self.filter_box = LabeledEntry(
            filter_row, "Narrow the list (optional)", width=520,
            placeholder="e.g. input tax credit, 2024, Section 73")
        self.filter_box.pack(side="left")
        self.filter_box.entry.bind("<Return>", lambda _e: self._apply_filter())
        box = ctk.CTkFrame(filter_row, fg_color="transparent")
        box.pack(side="left", padx=10)
        ctk.CTkLabel(box, text=" ", font=font(11)).pack()
        secondary_button(box, "Apply", self._apply_filter, width=90).pack()
        portal_box = ctk.CTkFrame(filter_row, fg_color="transparent")
        portal_box.pack(side="left")
        ctk.CTkLabel(portal_box, text=" ", font=font(11)).pack()
        secondary_button(portal_box, "Open portal",
                         lambda: webbrowser.open(config.CBIC_PORTAL_URL),
                         width=110).pack()

        self.count_label = ctk.CTkLabel(body, text="No catalogue fetched yet.",
                                        font=font(11), text_color=Theme.TEXT_MUTED,
                                        anchor="w", justify="left", wraplength=940)
        self.count_label.pack(fill="x", pady=(6, 4))

        self.table = DataTable(body, CBIC_COLUMNS, height=11)
        self.table.pack(fill="both", expand=True)

        ctk.CTkLabel(
            body,
            text="Documents already held are skipped. Downloaded PDFs are stored in "
                 "the knowledge_base folders and indexed so research answers can "
                 "cite the file and page. Always confirm the version in force for "
                 "the period under examination.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=940).pack(fill="x", pady=(8, 0))

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(10, 0))
        self.import_button = primary_button(buttons, "Import Listed Documents",
                                            self._import, width=200)
        self.import_button.pack(side="right")
        secondary_button(buttons, "Close", self.close, width=100).pack(
            side="right", padx=(0, 8))
        self.import_button.configure(state="disabled")

    # ------------------------------------------------------------------
    @staticmethod
    def _existing_filenames() -> set:
        """Filenames already registered, so the preview can say what is new."""
        try:
            return {str(d.get("file_name", "")).lower()
                    for d in db.list_knowledge_documents()}
        except db.DatabaseError:
            return set()

    def _note(self, text: str) -> None:
        """Progress callback -- runs on the worker thread, so only queues."""
        self._progress.put(text)

    def _drain_progress(self) -> None:
        """Move queued progress messages onto the busy dialog (Tk thread)."""
        if self._busy is None:
            return
        latest = ""
        while True:
            try:
                latest = self._progress.get_nowait()
            except queue.Empty:
                break
        if latest:
            self._busy.set_message(latest)
        try:
            self.after(150, self._drain_progress)
        except Exception:  # noqa: BLE001 - dialog closed
            pass

    # ------------------------------------------------------------------
    def _fetch(self) -> None:
        categories = [key for key, var in self.category_vars.items() if var.get()]
        if not categories:
            show_warning(self, "Nothing selected",
                         "Tick at least one category to fetch from CBIC.")
            return

        self._busy = BusyDialog(self, "Contacting CBIC",
                                "Connecting to the Tax Information Portal...")
        self.after(150, self._drain_progress)

        def work():
            return cbic_service.list_documents(categories, progress=self._note)

        def done(result) -> None:
            self._busy = None
            documents, messages = result
            self._documents = documents
            self._apply_filter()
            if not documents:
                show_warning(
                    self, "Nothing returned",
                    "The portal did not list any document for the selected "
                    "categories.\n\n" + ("\n".join(messages) if messages else ""))
            elif messages:
                show_info(self, "Catalogue fetched", "\n".join(messages[:6]))

        def failed(exc: Exception) -> None:
            self._busy = None
            show_error(
                self, "Could not reach CBIC",
                f"{exc}\n\nThe portal may be unavailable or the machine may be "
                f"offline. Existing knowledge base documents are unaffected.")

        run_in_background(self, work, done, failed, self._busy)

    # ------------------------------------------------------------------
    def _apply_filter(self) -> None:
        needle = self.filter_box.get().strip().lower()
        rows = []
        listed = []
        for index, document in enumerate(self._documents):
            haystack = " ".join((document.category, document.number, document.title,
                                 document.sub_category, document.issued)).lower()
            if needle and needle not in haystack:
                continue
            held = document.filename().lower() in self._held
            listed.append(document)
            rows.append({
                "id": index,
                "category": document.category,
                "number": document.number or "-",
                "title": truncate(document.title, 120),
                "issued": document.issued or "-",
                "status_display": ("Already held" if held
                                   else "Will download" if document.available
                                   else "No file offered"),
            })
        self._listed = listed
        self.table.load(rows, tag_fn=lambda r: (
            "muted" if r["status_display"] == "Already held"
            else "warning" if r["status_display"] == "No file offered" else ""))

        new_count = sum(1 for r in rows if r["status_display"] == "Will download")
        self.count_label.configure(
            text=f"{len(rows)} document(s) listed - {new_count} to download, "
                 f"{len(rows) - new_count} already held or unavailable."
            if rows else "No catalogue fetched yet.")
        self.import_button.configure(state="normal" if new_count else "disabled")

    # ------------------------------------------------------------------
    def _import(self) -> None:
        pending = [d for d in self._listed
                   if d.available and d.filename().lower() not in self._held]
        if not pending:
            show_info(self, "Nothing to import",
                      "Every listed document is already in the knowledge base.")
            return
        confirm_action(
            self, "Import from CBIC",
            f"Download {len(pending)} document(s) from the CBIC portal into the "
            f"knowledge base and index them?\n\nLarge Acts and Rules can take a "
            f"minute or two.",
            lambda: self._do_import(pending), confirm_text="Import", kind="info")

    def _do_import(self, pending: List[cbic_service.CBICDocument]) -> None:
        index = bool(self.app_settings().get("cbic_auto_index", True))
        self._busy = BusyDialog(self, "Importing from CBIC",
                                f"Downloading {len(pending)} document(s)...")
        self.after(150, self._drain_progress)

        def work():
            return cbic_service.import_documents(pending, index=index,
                                                 progress=self._note)

        def done(result: cbic_service.CBICFetchResult) -> None:
            self._busy = None
            self._held = self._existing_filenames()
            self._apply_filter()
            detail = result.summary
            if result.indexed_chunks:
                detail += f"\n{result.indexed_chunks} searchable passage(s) indexed."
            if result.messages:
                detail += "\n\n" + "\n".join(result.messages[:8])
            if result.failed and not result.downloaded:
                show_error(self, "Import failed", detail)
            else:
                show_success(self, "Import complete", detail)
            if self._on_done:
                self._on_done(result)

        def failed(exc: Exception) -> None:
            self._busy = None
            show_error(self, "Import failed", str(exc))

        run_in_background(self, work, done, failed, self._busy)

    def app_settings(self) -> Dict[str, Any]:
        """Application settings, whichever parent this dialog was opened from."""
        app = getattr(self.master, "app", None)
        return getattr(app, "settings", None) or config.load_settings()


class NotesDialog(ModalDialog):
    """Edit the notes recorded against a knowledge-base document."""

    def __init__(self, parent, document: Dict[str, Any], on_saved=None):
        super().__init__(parent, "Document notes", width=560, height=380)
        self._document = document
        self._on_saved = on_saved

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)
        ctk.CTkLabel(body, text=document.get("file_name", ""), font=font(14, "bold"),
                     text_color=Theme.TEXT, wraplength=500,
                     justify="left").pack(anchor="w")

        self.title_field = LabeledEntry(body, "Title", document.get("title", ""),
                                        width=480)
        self.title_field.pack(fill="x", pady=(10, 0))
        self.category = LabeledDropdown(body, "Category", config.KB_CATEGORIES,
                                        document.get("category", "acts"), width=480)
        self.category.pack(fill="x")
        self.notes = LabeledTextbox(body, "Notes", document.get("notes", ""), height=90)
        self.notes.pack(fill="x")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Save", self._save, width=110).pack(side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _save(self) -> None:
        db.update_knowledge_document(int(self._document["id"]), {
            "title": self.title_field.get(),
            "category": self.category.get(),
            "notes": self.notes.get(),
        })
        rag_service._invalidate_cache()  # noqa: SLF001
        callback = self._on_saved
        self.close()
        if callback:
            callback()


class PassageDialog(ModalDialog):
    """Show a retrieved passage in full."""

    def __init__(self, parent, row: Dict[str, Any]):
        super().__init__(parent, f"Passage {row.get('ref', '')}", width=760, height=520)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text=row.get("file_name", ""), font=font(14, "bold"),
                     text_color=Theme.TEXT, wraplength=680,
                     justify="left").pack(anchor="w")
        ctk.CTkLabel(
            body,
            text=f"Category: {row.get('category', '')}   |   "
                 f"Page: {row.get('page', '')}   |   "
                 f"Relevance: {row.get('score', '')}",
            font=font(11), text_color=Theme.TEXT_MUTED).pack(anchor="w", pady=(2, 10))

        box = ctk.CTkTextbox(body, font=font(12), wrap="word", fg_color=Theme.SURFACE,
                             text_color=Theme.TEXT, border_width=1,
                             border_color=Theme.BORDER)
        box.pack(fill="both", expand=True)
        box.insert("1.0", row.get("_full") or row.get("excerpt", ""))
        box.configure(state="disabled")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Close", self.close, width=100).pack(side="right")
        secondary_button(
            buttons, "Copy passage",
            lambda: self._copy(row.get("_full") or ""), width=130).pack(
            side="right", padx=(0, 8))

    def _copy(self, text: str) -> None:
        from ui.widgets import copy_to_clipboard

        copy_to_clipboard(self, text)
