"""
ui.base_page
============
Common scaffolding for every screen: a page header with title, subtitle
and an action area, plus a scrollable or fixed body.
"""

from __future__ import annotations

from typing import Any, Dict

import customtkinter as ctk

from config import Theme
from ui.widgets import Divider, font
from utils.helpers import is_readonly


class BasePage(ctk.CTkFrame):
    """
    Base class for all application screens.

    Subclasses set :attr:`title` / :attr:`subtitle`, implement
    :meth:`build` to lay out their widgets and :meth:`refresh` to reload
    data.  :meth:`on_show` runs every time the page becomes visible.
    """

    title: str = ""
    subtitle: str = ""
    scrollable: bool = False

    def __init__(self, master, app):
        super().__init__(master, fg_color=Theme.BG)
        self.app = app
        self.context: Dict[str, Any] = {}
        self._built = False

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=20, pady=(16, 8))

        titles = ctk.CTkFrame(header, fg_color="transparent")
        titles.pack(side="left", fill="x", expand=True)
        self.title_label = ctk.CTkLabel(
            titles, text=self.title, font=font(20, "bold"),
            text_color=Theme.TEXT, anchor="w",
        )
        self.title_label.pack(anchor="w")
        self.subtitle_label = ctk.CTkLabel(
            titles, text=self.subtitle, font=font(11),
            text_color=Theme.TEXT_MUTED, anchor="w",
        )
        self.subtitle_label.pack(anchor="w")

        self.header_actions = ctk.CTkFrame(header, fg_color="transparent",
                                           width=1, height=34)
        self.header_actions.pack(side="right")

        Divider(self).pack(fill="x", padx=20, pady=(4, 0))

        if self.scrollable:
            self.body = ctk.CTkScrollableFrame(
                self, fg_color="transparent", scrollbar_button_color=Theme.BORDER,
                scrollbar_button_hover_color=Theme.SECONDARY,
            )
        else:
            self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=20, pady=12)

    # -- lifecycle --------------------------------------------------------
    def ensure_built(self) -> None:
        if not self._built:
            self.build()
            self._built = True

    def build(self) -> None:
        """Lay out the page.  Called once, lazily."""

    def refresh(self) -> None:
        """Reload data from the database.  Called on every show."""

    def on_show(self, **context) -> None:
        """Called each time the page is displayed."""
        self.context.update(context)
        self.ensure_built()
        self.refresh()

    # -- convenience ------------------------------------------------------
    def set_subtitle(self, text: str) -> None:
        self.subtitle_label.configure(text=text)

    @property
    def user(self) -> Dict[str, Any]:
        return self.app.current_user or {}

    @property
    def user_name(self) -> str:
        return self.user.get("name", "")

    @property
    def user_role(self) -> str:
        return self.user.get("role", "")

    @property
    def readonly(self) -> bool:
        """Viewers cannot modify records."""
        return is_readonly(self.user_role)

    def status(self, message: str, kind: str = "info") -> None:
        self.app.set_status(message, kind)

    def navigate(self, page_key: str, **context) -> None:
        self.app.navigate(page_key, **context)

    def block_if_readonly(self) -> bool:
        """Return True (and warn) when the current user may not make changes."""
        if self.readonly:
            from ui.widgets import show_warning

            show_warning(
                self, "Read-only access",
                "Your role is Viewer, which has read-only access. "
                "Please ask an Administrator or Partner to make this change.",
            )
            return True
        return False
