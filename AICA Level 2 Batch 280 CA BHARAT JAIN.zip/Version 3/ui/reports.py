"""
ui.reports
==========
Reports and exports.

Six standard reports are produced from live records with Python
calculations, previewed on screen and exported to Excel (and, where
useful, Word or PDF).
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import export_service
from ui.base_page import BasePage
from ui.widgets import (
    Card, DataTable, KpiCard, LabeledDropdown, font, primary_button,
    secondary_button, show_error, show_warning,
)
from utils.calculations import (
    aggregate_cases, compute_demand, days_remaining, deadline_label, sum_amounts,
)
from utils.formatters import format_currency, format_date, truncate
from utils.logger import get_logger

log = get_logger(__name__)

ALL = "All"


class ReportsPage(BasePage):
    """Standard practice reports."""

    title = "Reports / Exports"
    subtitle = "Standard reports computed from live case records"

    REPORTS: List[Tuple[str, str]] = [
        ("client_wise", "Client-wise Cases"),
        ("open_cases", "Open Cases"),
        ("high_risk", "High-Risk Cases"),
        ("deadlines", "Upcoming Deadlines"),
        ("exposure", "Case-wise Demand Exposure"),
        ("status", "Status Report"),
        ("requirements", "Document Requirement Status"),
        ("activity", "Activity Log"),
    ]

    def build(self) -> None:
        self._rows: List[Dict[str, Any]] = []
        self._columns: List[Tuple[str, str, int, str]] = []
        self._current = self.REPORTS[0][0]

        # -- controls -----------------------------------------------------
        controls = Card(self.body)
        controls.pack(fill="x", pady=(0, 10))
        bar = ctk.CTkFrame(controls, fg_color="transparent")
        bar.pack(fill="x", padx=14, pady=12)

        self.report_picker = LabeledDropdown(
            bar, "Report", [label for _key, label in self.REPORTS],
            self.REPORTS[0][1], width=280, command=lambda _v: self._run())
        self.report_picker.pack(side="left", padx=(0, 14))

        self.client_filter = LabeledDropdown(bar, "Client", [ALL], ALL, width=240,
                                             command=lambda _v: self._run())
        self.client_filter.pack(side="left", padx=(0, 14))
        self.fy_filter = LabeledDropdown(bar, "Financial Year",
                                         [ALL] + config.FINANCIAL_YEARS, ALL,
                                         width=150, command=lambda _v: self._run())
        self.fy_filter.pack(side="left")

        buttons = ctk.CTkFrame(bar, fg_color="transparent")
        buttons.pack(side="right")
        ctk.CTkLabel(buttons, text=" ", font=font(11)).pack()
        row = ctk.CTkFrame(buttons, fg_color="transparent")
        row.pack()
        primary_button(row, "Export Excel", lambda: self._export("excel"),
                       width=125).pack(side="left")
        secondary_button(row, "Export PDF", lambda: self._export("pdf"),
                         width=110).pack(side="left", padx=6)
        secondary_button(row, "Export All", self._export_workbook,
                         width=110).pack(side="left")

        # -- summary strip --------------------------------------------------
        kpis = ctk.CTkFrame(self.body, fg_color="transparent")
        kpis.pack(fill="x", pady=(0, 10))
        self.kpis: Dict[str, KpiCard] = {}
        for index, (key, label, accent) in enumerate((
            ("rows", "Records", Theme.PRIMARY),
            ("tax", "Total Tax", Theme.INFO),
            ("interest_penalty", "Interest + Penalty", Theme.WARNING),
            ("exposure", "Total Exposure", Theme.DANGER),
        )):
            kpis.grid_columnconfigure(index, weight=1, uniform="rep")
            card = KpiCard(kpis, label, "-", "", accent)
            card.grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 8, 0))
            self.kpis[key] = card

        # -- table -----------------------------------------------------------
        self.table_card = Card(self.body, "Report Preview")
        self.table_card.pack(fill="both", expand=True)
        self.table_holder = ctk.CTkFrame(self.table_card, fg_color="transparent")
        self.table_holder.pack(fill="both", expand=True, padx=14, pady=12)
        self.table: Optional[DataTable] = None

        self.footnote = ctk.CTkLabel(
            self.body,
            text="All amounts are computed in Python with decimal arithmetic from the "
                 "components extracted for each notice.",
            font=font(10), text_color=Theme.TEXT_MUTED, anchor="w")
        self.footnote.pack(fill="x", pady=(8, 0))

    # ==================================================================
    def refresh(self) -> None:
        try:
            clients = db.list_clients()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return
        self._client_lookup = {c["client_name"]: c["id"] for c in clients}
        self.client_filter.set_values([ALL] + sorted(self._client_lookup), keep=True)
        self._run()

    def _report_key(self) -> str:
        label = self.report_picker.get()
        for key, text in self.REPORTS:
            if text == label:
                return key
        return self.REPORTS[0][0]

    def _filtered_cases(self) -> List[Dict[str, Any]]:
        filters: Dict[str, Any] = {}
        client = self.client_filter.get()
        if client and client != ALL:
            filters["client_id"] = self._client_lookup.get(client)
        fy = self.fy_filter.get()
        if fy and fy != ALL:
            filters["financial_year"] = fy
        return db.list_cases(filters)

    def _run(self) -> None:
        key = self._report_key()
        self._current = key
        builder: Callable[[], Tuple[List, List, str]] = {
            "client_wise": self._report_client_wise,
            "open_cases": self._report_open_cases,
            "high_risk": self._report_high_risk,
            "deadlines": self._report_deadlines,
            "exposure": self._report_exposure,
            "status": self._report_status,
            "requirements": self._report_requirements,
            "activity": self._report_activity,
        }.get(key, self._report_client_wise)

        try:
            rows, columns, note = builder()
        except db.DatabaseError as exc:
            show_error(self, "Report failed", str(exc))
            return

        self._rows, self._columns = rows, columns
        self._render_table(rows, columns)
        self._render_kpis(key, rows)
        self.footnote.configure(text=note)
        self.status(f"{self.report_picker.get()}: {len(rows)} record(s)")

    def _render_table(self, rows, columns) -> None:
        if self.table is not None:
            self.table.destroy()
        self.table = DataTable(self.table_holder, columns, height=15)
        self.table.pack(fill="both", expand=True)
        self.table.load(rows, tag_fn=_report_tag)

    def _render_kpis(self, key: str, rows: List[Dict[str, Any]]) -> None:
        self.kpis["rows"].update_values(str(len(rows)), self.report_picker.get())
        if key in ("requirements", "activity", "status"):
            for name in ("tax", "interest_penalty", "exposure"):
                self.kpis[name].update_values("-", "not applicable")
            return
        cases = self._filtered_cases()
        totals = aggregate_cases(cases)
        self.kpis["tax"].update_values(format_currency(totals.total_tax),
                                       "CGST + SGST + IGST + Cess")
        self.kpis["interest_penalty"].update_values(
            format_currency(sum_amounts([totals.interest, totals.penalty])),
            "as demanded")
        self.kpis["exposure"].update_values(format_currency(totals.total_exposure),
                                            f"across {totals.case_count} case(s)")

    # ------------------------------------------------------------------
    # Report builders
    # ------------------------------------------------------------------
    def _report_client_wise(self):
        cases = self._filtered_cases()
        clients = db.list_clients()
        rows = []
        for client in clients:
            own = [c for c in cases if c.get("client_id") == client["id"]]
            if not own and self.client_filter.get() != ALL:
                continue
            totals = aggregate_cases(own)
            rows.append({
                "id": client["id"],
                "client_code": client.get("client_code", ""),
                "client_name": client.get("client_name", ""),
                "gstin": client.get("gstin") or "-",
                "state": client.get("state") or "-",
                "cases": len(own),
                "open_cases": len([c for c in own if c.get("status") != "Closed"]),
                "high_risk": len([c for c in own if c.get("risk_level") == "High"]),
                "total_tax": format_currency(totals.total_tax),
                "exposure": format_currency(totals.total_exposure),
            })
        rows.sort(key=lambda r: r["cases"], reverse=True)
        columns = [
            ("client_code", "Client ID", 90, "w"),
            ("client_name", "Client", 250, "w"),
            ("gstin", "GSTIN", 150, "w"),
            ("state", "State", 130, "w"),
            ("cases", "Cases", 65, "center"),
            ("open_cases", "Open", 60, "center"),
            ("high_risk", "High Risk", 80, "center"),
            ("total_tax", "Total Tax", 130, "e"),
            ("exposure", "Total Exposure", 140, "e"),
        ]
        return rows, columns, ("Client-wise summary of GST matters and exposure, "
                               "computed from the saved notice analysis of each case.")

    def _report_open_cases(self):
        cases = [c for c in self._filtered_cases() if c.get("status") != "Closed"]
        rows = [_case_row(c) for c in cases]
        return rows, _CASE_COLUMNS, ("All matters that are not closed, ordered by "
                                     "reply due date.")

    def _report_high_risk(self):
        cases = [c for c in self._filtered_cases()
                 if c.get("risk_level") == "High" and c.get("status") != "Closed"]
        cases.sort(key=lambda c: compute_demand(c).total_exposure, reverse=True)
        rows = [_case_row(c) for c in cases]
        return rows, _CASE_COLUMNS, ("Open matters assessed as High risk, ordered by "
                                     "total exposure.")

    def _report_deadlines(self):
        cases = [c for c in self._filtered_cases() if c.get("status") != "Closed"]
        rows = []
        for case in cases:
            remaining = days_remaining(case.get("due_date"))
            if remaining is None:
                continue
            rows.append({
                "id": case["id"],
                "case_code": case.get("case_code", ""),
                "client_name": case.get("client_name", ""),
                "notice_type": case.get("notice_type", ""),
                "notice_number": case.get("notice_number") or "-",
                "due_date": format_date(case.get("due_date")),
                "days": remaining,
                "deadline": deadline_label(case.get("due_date")),
                "assigned": (case.get("assigned_team_member")
                             or case.get("assigned_manager") or "-"),
                "status": case.get("status", ""),
                "_severity": "overdue" if remaining < 0 else
                             ("urgent" if remaining <= 3 else
                              ("soon" if remaining <= 7 else "normal")),
            })
        rows.sort(key=lambda r: r["days"])
        columns = [
            ("case_code", "Case ID", 105, "w"),
            ("client_name", "Client", 200, "w"),
            ("notice_type", "Notice Type", 100, "w"),
            ("notice_number", "Notice Number", 150, "w"),
            ("due_date", "Due Date", 95, "center"),
            ("days", "Days", 60, "center"),
            ("deadline", "Deadline", 130, "w"),
            ("assigned", "Assigned To", 140, "w"),
            ("status", "Status", 130, "w"),
        ]
        return rows, columns, ("Reply deadlines for open matters. Negative days "
                               "indicate an overdue reply.")

    def _report_exposure(self):
        cases = self._filtered_cases()
        rows = []
        for case in cases:
            demand = compute_demand(case)
            rows.append({
                "id": case["id"],
                "case_code": case.get("case_code", ""),
                "client_name": case.get("client_name", ""),
                "financial_year": case.get("financial_year") or "-",
                "cgst": format_currency(demand.cgst),
                "sgst": format_currency(demand.sgst),
                "igst": format_currency(demand.igst),
                "cess": format_currency(demand.cess),
                "total_tax": format_currency(demand.total_tax),
                "interest": format_currency(demand.interest),
                "penalty": format_currency(demand.penalty),
                "other": format_currency(demand.other_amount),
                "exposure": format_currency(demand.total_exposure),
                "_exposure": float(demand.total_exposure),
            })
        rows.sort(key=lambda r: r["_exposure"], reverse=True)
        columns = [
            ("case_code", "Case ID", 105, "w"),
            ("client_name", "Client", 180, "w"),
            ("financial_year", "FY", 70, "center"),
            ("cgst", "CGST", 105, "e"),
            ("sgst", "SGST", 105, "e"),
            ("igst", "IGST", 105, "e"),
            ("cess", "Cess", 85, "e"),
            ("total_tax", "Total Tax", 115, "e"),
            ("interest", "Interest", 105, "e"),
            ("penalty", "Penalty", 105, "e"),
            ("other", "Other", 90, "e"),
            ("exposure", "Total Exposure", 130, "e"),
        ]
        return rows, columns, ("Component-wise demand for each case. "
                               "Total Tax and Total Exposure are computed in Python.")

    def _report_status(self):
        cases = self._filtered_cases()
        counts: Dict[str, Dict[str, Any]] = {}
        for status in config.CASE_STATUSES:
            counts[status] = {"count": 0, "exposure": 0}
        for case in cases:
            status = case.get("status") or "New"
            entry = counts.setdefault(status, {"count": 0, "exposure": 0})
            entry["count"] += 1
            entry["exposure"] = sum_amounts(
                [entry["exposure"], compute_demand(case).total_exposure])
        total = len(cases) or 1
        rows = []
        for index, (status, entry) in enumerate(counts.items(), start=1):
            rows.append({
                "id": index,
                "status": status,
                "cases": entry["count"],
                "share": f"{entry['count'] * 100 / total:.1f}%",
                "exposure": format_currency(entry["exposure"]),
            })
        columns = [
            ("status", "Status", 220, "w"),
            ("cases", "Cases", 90, "center"),
            ("share", "Share", 90, "center"),
            ("exposure", "Exposure", 160, "e"),
        ]
        return rows, columns, "Distribution of matters across the workflow statuses."

    def _report_requirements(self):
        cases = self._filtered_cases()
        rows = []
        for case in cases:
            requirements = db.list_requirements(int(case["id"]))
            if not requirements:
                continue
            received = len([r for r in requirements if r.get("status") == "Received"])
            pending = len([r for r in requirements
                           if (r.get("status") or "Pending") == "Pending"])
            rows.append({
                "id": case["id"],
                "case_code": case.get("case_code", ""),
                "client_name": case.get("client_name", ""),
                "notice_type": case.get("notice_type", ""),
                "total": len(requirements),
                "received": received,
                "pending": pending,
                "progress": f"{received * 100 // max(1, len(requirements))}%",
                "due_date": format_date(case.get("due_date")),
            })
        columns = [
            ("case_code", "Case ID", 105, "w"),
            ("client_name", "Client", 210, "w"),
            ("notice_type", "Notice Type", 110, "w"),
            ("total", "Items", 70, "center"),
            ("received", "Received", 85, "center"),
            ("pending", "Pending", 80, "center"),
            ("progress", "Progress", 85, "center"),
            ("due_date", "Reply Due", 100, "center"),
        ]
        return rows, columns, ("Collection status of the client document requirement "
                               "lists.")

    def _report_activity(self):
        entries = db.list_activity(limit=300)
        rows = [
            {
                "id": entry["id"],
                "created_at": entry.get("created_at", ""),
                "action": entry.get("action", ""),
                "detail": truncate(entry.get("detail"), 130),
                "user_name": entry.get("user_name") or "-",
            }
            for entry in entries
        ]
        columns = [
            ("created_at", "Date / Time", 150, "w"),
            ("action", "Action", 200, "w"),
            ("detail", "Detail", 620, "w"),
            ("user_name", "User", 140, "w"),
        ]
        return rows, columns, "Recent activity recorded by the application."

    # ==================================================================
    def _export(self, fmt: str) -> None:
        if not self._rows:
            show_warning(self, "Nothing to export", "This report has no records.")
            return
        label = self.report_picker.get()
        columns = [(key, heading) for key, heading, _w, _a in self._columns]
        subheading = (f"Client: {self.client_filter.get()}   |   "
                      f"Financial Year: {self.fy_filter.get()}")

        if fmt == "excel":
            ok, message = export_service.export_table_excel(
                self._rows, columns, f"Report_{label}", label,
                f"CA-GST Copilot - {label}", subheading)
        else:
            pdf_columns = [(key, heading, max(18, min(70, width // 4)))
                           for key, heading, width, _a in self._columns]
            ok, message = export_service.export_table_pdf(
                self._rows, pdf_columns, f"Report_{label}",
                f"CA-GST Copilot - {label}", subheading)

        if not ok:
            show_error(self, "Export failed", message)
            return
        from ui.requirements_generator import ExportDoneDialog

        self.status(f"Exported to {message}", "success")
        ExportDoneDialog(self, message)

    def _export_workbook(self) -> None:
        """Export every report into a single multi-sheet workbook."""
        sheets = []
        original = self.report_picker.get()
        try:
            for key, label in self.REPORTS:
                self.report_picker.set(label)
                self._run()
                columns = [(k, h) for k, h, _w, _a in self._columns]
                sheets.append((label, list(self._rows), columns))
        finally:
            self.report_picker.set(original)
            self._run()

        ok, message = export_service.export_multi_sheet_excel(
            sheets, "CA_GST_Copilot_All_Reports", "CA-GST Copilot - practice reports")
        if not ok:
            show_error(self, "Export failed", message)
            return
        from ui.requirements_generator import ExportDoneDialog

        self.status(f"All reports exported to {message}", "success")
        ExportDoneDialog(self, message)


_CASE_COLUMNS = [
    ("case_code", "Case ID", 105, "w"),
    ("client_name", "Client", 190, "w"),
    ("notice_type", "Notice Type", 100, "w"),
    ("notice_number", "Notice Number", 140, "w"),
    ("financial_year", "FY", 70, "center"),
    ("due_date", "Due Date", 95, "center"),
    ("deadline", "Deadline", 125, "w"),
    ("exposure", "Exposure", 130, "e"),
    ("risk_level", "Risk", 85, "center"),
    ("status", "Status", 130, "w"),
    ("assigned", "Assigned To", 130, "w"),
]


def _case_row(case: Dict[str, Any]) -> Dict[str, Any]:
    demand = compute_demand(case)
    remaining = days_remaining(case.get("due_date"))
    return {
        "id": case["id"],
        "case_code": case.get("case_code", ""),
        "client_name": case.get("client_name", ""),
        "notice_type": case.get("notice_type", ""),
        "notice_number": case.get("notice_number") or "-",
        "financial_year": case.get("financial_year") or "-",
        "due_date": format_date(case.get("due_date")),
        "deadline": deadline_label(case.get("due_date")),
        "exposure": format_currency(demand.total_exposure),
        "risk_level": case.get("risk_level") or "-",
        "status": case.get("status", ""),
        "assigned": (case.get("assigned_team_member")
                     or case.get("assigned_manager") or "-"),
        "_severity": ("overdue" if remaining is not None and remaining < 0 else
                      ("urgent" if remaining is not None and remaining <= 3 else "")),
    }


def _report_tag(row: Dict[str, Any]) -> str:
    severity = row.get("_severity")
    if severity in ("overdue", "urgent"):
        return "danger"
    if severity == "soon":
        return "warning"
    if row.get("risk_level") == "High":
        return "danger"
    return ""
