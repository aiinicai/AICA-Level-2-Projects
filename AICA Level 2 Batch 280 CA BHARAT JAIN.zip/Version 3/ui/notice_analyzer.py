"""
ui.notice_analyzer
==================
Upload / Analyse Notice.

Three steps in one screen:

1. Upload the notice PDF (or paste the text) and review the extracted text.
2. Run the AI analysis and review the structured extraction.
3. Review the Python validation results and correct anything that is wrong.
"""

from __future__ import annotations

from pathlib import Path
from tkinter import filedialog
from typing import Any, Dict, List, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import gst_notice_service as notice_service
from services.pdf_service import SCANNED_PDF_MESSAGE, extract_pdf
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DetailGrid, DisclaimerBanner, LabeledDropdown,
    ModalDialog, ai_button, confirm_action, font, primary_button, show_ai_error,
    run_in_background, secondary_button, show_error, show_info, show_success,
    show_warning,
)
from utils.calculations import days_remaining, deadline_label
from utils.formatters import format_currency, format_date, join_list, truncate
from utils.helpers import copy_into, human_size, relative_to_base, resolve_stored_path
from utils.logger import get_logger
from utils.validators import INVALID, NOT_FOUND, REVIEW, VALID

log = get_logger(__name__)

ISSUE_COLUMNS = [
    ("issue_no", "No.", 45, "center"),
    ("title", "Issue", 250, "w"),
    ("allegation_short", "Department Allegation", 340, "w"),
    ("amount_display", "Amount", 110, "e"),
    ("sections_display", "Section", 150, "w"),
    ("risk", "Risk", 90, "center"),
    ("confidence", "Confidence", 90, "center"),
]

VALIDATION_COLUMNS = [
    ("field", "Field", 210, "w"),
    ("value", "Extracted Value", 320, "w"),
    ("status", "Validation", 130, "center"),
    ("confidence", "Confidence", 90, "center"),
    ("message", "Remarks", 380, "w"),
]


class NoticeAnalyzerPage(BasePage):
    """Notice upload, text extraction and AI analysis."""

    title = "Upload / Analyse Notice"
    subtitle = "Extract the notice text, then run structured AI analysis"

    def build(self) -> None:
        self._case: Optional[Dict[str, Any]] = None
        self._result: Optional[notice_service.NoticeAnalysisResult] = None
        self._extraction = None

        # -- case selector -------------------------------------------------
        selector = Card(self.body)
        selector.pack(fill="x", pady=(0, 8))
        bar = ctk.CTkFrame(selector, fg_color="transparent")
        bar.pack(fill="x", padx=14, pady=12)

        self.case_picker = LabeledDropdown(bar, "Select GST Case", [""], "", width=440,
                                           command=self._on_case_change)
        self.case_picker.pack(side="left")

        self.case_info = ctk.CTkLabel(bar, text="", font=font(11),
                                      text_color=Theme.TEXT_MUTED, justify="left",
                                      anchor="w")
        self.case_info.pack(side="left", padx=20)

        secondary_button(bar, "Open Case", self._open_case, width=100).pack(side="right")

        DisclaimerBanner(self.body, config.AI_DISCLAIMER).pack(fill="x", pady=(0, 8))

        # -- tabs -----------------------------------------------------------
        self.tabs = ctk.CTkTabview(
            self.body, fg_color=Theme.SURFACE, segmented_button_fg_color=Theme.SURFACE_ALT,
            segmented_button_selected_color=Theme.PRIMARY,
            segmented_button_selected_hover_color=Theme.PRIMARY_HOVER,
            segmented_button_unselected_color=Theme.SURFACE_ALT,
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
        )
        self.tabs.pack(fill="both", expand=True)
        self.tab_upload = self.tabs.add("1.  Notice Text")
        self.tab_analysis = self.tabs.add("2.  Notice Analysis")
        self.tab_validation = self.tabs.add("3.  Validation")

        self._build_upload_tab()
        self._build_analysis_tab()
        self._build_validation_tab()

    # ==================================================================
    # Tab 1 - notice text
    # ==================================================================
    def _build_upload_tab(self) -> None:
        tab = self.tab_upload

        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(12, 6))

        primary_button(toolbar, "Upload Notice PDF", self._upload_pdf,
                       width=160).pack(side="left")
        secondary_button(toolbar, "Re-extract", self._reextract,
                         width=110).pack(side="left", padx=6)
        secondary_button(toolbar, "View Notice", self._open_pdf,
                         width=110).pack(side="left")
        secondary_button(toolbar, "Clear Text", self._clear_text,
                         width=100).pack(side="left", padx=6)
        secondary_button(toolbar, "Save Text", self._save_text, width=110).pack(side="left")

        ai_button(toolbar, "Analyse Notice with AI", self._analyse,
                  width=210).pack(side="right")

        self.file_label = ctk.CTkLabel(tab, text="No file uploaded for this case.",
                                       font=font(11), text_color=Theme.TEXT_MUTED,
                                       anchor="w")
        self.file_label.pack(fill="x", padx=14, pady=(0, 4))

        self.extract_status = ctk.CTkLabel(tab, text="", font=font(11, "bold"),
                                           text_color=Theme.TEXT_MUTED, anchor="w",
                                           wraplength=1050, justify="left")
        self.extract_status.pack(fill="x", padx=14, pady=(0, 6))

        ctk.CTkLabel(
            tab,
            text="Extracted notice text - review and edit if required before analysis. "
                 "You may also paste the notice text directly.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
        ).pack(fill="x", padx=14)

        self.text_box = ctk.CTkTextbox(
            tab, font=("Consolas", 11), wrap="word", fg_color="#FCFCFD",
            text_color=Theme.TEXT, border_width=1, border_color=Theme.BORDER,
            corner_radius=6,
        )
        self.text_box.pack(fill="both", expand=True, padx=14, pady=(4, 12))

    # ==================================================================
    # Tab 2 - analysis
    # ==================================================================
    def _build_analysis_tab(self) -> None:
        tab = self.tab_analysis

        self.analysis_scroll = ctk.CTkScrollableFrame(
            tab, fg_color="transparent", scrollbar_button_color=Theme.BORDER)
        self.analysis_scroll.pack(fill="both", expand=True, padx=8, pady=8)

        self.analysis_placeholder = ctk.CTkLabel(
            self.analysis_scroll,
            text="No analysis yet for this case.\n\n"
                 "Upload or paste the notice text on the first tab, then click\n"
                 "'Analyse Notice with AI'.",
            font=font(13), text_color=Theme.TEXT_MUTED, justify="center",
        )
        self.analysis_placeholder.pack(pady=60)

        self.analysis_content = ctk.CTkFrame(self.analysis_scroll, fg_color="transparent")

        # Case overview
        self.overview_card = Card(self.analysis_content, "Case Overview",
                                  "Extracted from the notice by the AI")
        self.overview_card.pack(fill="x", pady=(0, 10))
        self.overview_grid = DetailGrid(self.overview_card, columns=3)
        self.overview_grid.pack(fill="x", padx=16, pady=12)

        # Demand summary + source
        middle = ctk.CTkFrame(self.analysis_content, fg_color="transparent")
        middle.pack(fill="x", pady=(0, 10))
        middle.grid_columnconfigure(0, weight=2)
        middle.grid_columnconfigure(1, weight=3)
        middle.grid_rowconfigure(0, weight=1)

        self.demand_card = Card(middle, "Demand Summary",
                                "Totals computed in Python")
        self.demand_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.demand_body = ctk.CTkFrame(self.demand_card, fg_color="transparent")
        self.demand_body.pack(fill="both", expand=True, padx=16, pady=12)

        self.summary_card = Card(middle, "Summary of the Notice")
        self.summary_card.grid(row=0, column=1, sticky="nsew")
        self.summary_text = ctk.CTkTextbox(
            self.summary_card, font=font(12), wrap="word", fg_color=Theme.SURFACE,
            text_color=Theme.TEXT, border_width=0, height=210)
        self.summary_text.pack(fill="both", expand=True, padx=14, pady=12)

        # Issues
        self.issues_card = Card(self.analysis_content, "Issues Identified",
                                "Double-click an issue to open the detailed analysis")
        self.issues_card.pack(fill="both", expand=True)
        self.issues_table = DataTable(self.issues_card, ISSUE_COLUMNS, height=8,
                                      on_double_click=self._open_issue)
        self.issues_table.pack(fill="both", expand=True, padx=14, pady=(12, 8))

        actions = ctk.CTkFrame(self.issues_card, fg_color="transparent")
        actions.pack(fill="x", padx=14, pady=(0, 12))
        secondary_button(actions, "Open Issue Analysis",
                         lambda: self._open_issue(self.issues_table.selected_row()),
                         width=160).pack(side="left")
        secondary_button(actions, "Client Requirements",
                         lambda: self.navigate("requirements",
                                               case_id=self._case_id()),
                         width=160).pack(side="left", padx=6)
        secondary_button(actions, "Draft Reply",
                         lambda: self.navigate("draft", case_id=self._case_id()),
                         width=120).pack(side="left")
        self.source_label = ctk.CTkLabel(actions, text="", font=font(10),
                                         text_color=Theme.TEXT_MUTED)
        self.source_label.pack(side="right")

    # ==================================================================
    # Tab 3 - validation
    # ==================================================================
    def _build_validation_tab(self) -> None:
        tab = self.tab_validation

        info = ctk.CTkFrame(tab, fg_color=Theme.INFO_BG, corner_radius=6)
        info.pack(fill="x", padx=12, pady=(12, 8))
        ctk.CTkLabel(
            info,
            text="Every extracted value is checked in Python. Nothing is changed "
                 "automatically - double-click a row to correct a value yourself.",
            font=font(11), text_color=Theme.INFO, anchor="w", justify="left",
        ).pack(padx=12, pady=8, anchor="w")

        self.validation_summary = ctk.CTkFrame(tab, fg_color="transparent",
                                               width=1, height=1)
        self.validation_summary.pack(fill="x", padx=12, pady=(0, 8))

        self.validation_table = DataTable(tab, VALIDATION_COLUMNS, height=18,
                                          on_double_click=self._correct_field)
        self.validation_table.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    # ==================================================================
    # Data loading
    # ==================================================================
    def refresh(self) -> None:
        try:
            cases = db.list_cases()
        except db.DatabaseError as exc:
            show_error(self, "Database error", str(exc))
            return

        self._case_lookup = {_case_label(c): c["id"] for c in cases}
        values = list(self._case_lookup) or ["(no cases - create one first)"]
        current = self.case_picker.get()
        self.case_picker.set_values(values, keep=True)

        target = self.context.pop("case_id", None) or getattr(self.app, "selected_case_id", None)
        if target:
            for label, case_id in self._case_lookup.items():
                if case_id == target:
                    self.case_picker.set(label)
                    break
        elif current not in values and values:
            self.case_picker.set(values[0])

        self._load_case()

    def _on_case_change(self, _value: str = "") -> None:
        self._load_case()

    def _case_id(self) -> Optional[int]:
        return self._case_lookup.get(self.case_picker.get()) if self._case else None

    def _load_case(self) -> None:
        case_id = self._case_lookup.get(self.case_picker.get())
        if not case_id:
            self._case = None
            self.case_info.configure(text="Create a GST case first (GST Cases > New Case).")
            self.text_box.delete("1.0", "end")
            self._show_no_analysis()
            return

        self._case = db.get_case(int(case_id))
        if not self._case:
            return
        self.app.selected_case_id = int(case_id)

        case = self._case
        self.case_info.configure(
            text=f"{case.get('client_name', '')}   |   {case.get('notice_type', '')}   |   "
                 f"FY {case.get('financial_year') or '-'}   |   "
                 f"Due {format_date(case.get('due_date'))}   |   "
                 f"{deadline_label(case.get('due_date'))}"
        )

        # Notice file + text
        stored_file = case.get("uploaded_file") or ""
        if stored_file:
            path = resolve_stored_path(stored_file)
            size = human_size(path.stat().st_size) if path.exists() else "missing"
            self.file_label.configure(
                text=f"Uploaded file: {path.name}   ({size})",
                text_color=Theme.SUCCESS if path.exists() else Theme.DANGER,
            )
        else:
            self.file_label.configure(text="No file uploaded for this case.",
                                      text_color=Theme.TEXT_MUTED)

        self.text_box.delete("1.0", "end")
        if case.get("extracted_text"):
            self.text_box.insert("1.0", case["extracted_text"])
            self.extract_status.configure(
                text=f"{len(case['extracted_text']):,} characters of notice text on record.",
                text_color=Theme.TEXT_MUTED)
        else:
            self.extract_status.configure(text="", text_color=Theme.TEXT_MUTED)

        # Existing analysis
        saved = notice_service.load_saved_analysis(int(case_id))
        if saved:
            self._result = saved
            self._render_result(saved, saved_note=True)
        else:
            self._result = None
            self._show_no_analysis()

    def _show_no_analysis(self) -> None:
        self.analysis_content.pack_forget()
        self.analysis_placeholder.pack(pady=60)
        self.validation_table.clear()
        for child in self.validation_summary.winfo_children():
            child.destroy()

    # ==================================================================
    # PDF upload / extraction
    # ==================================================================
    def _require_case(self) -> bool:
        if not self._case:
            show_warning(self, "No case selected",
                         "Please select a GST case first. If you have not created "
                         "one yet, go to GST Cases > New Case.")
            return False
        return True

    def _upload_pdf(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        path = filedialog.askopenfilename(
            title="Select the GST notice PDF",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
            initialdir=str(config.SAMPLE_DATA_DIR if config.SAMPLE_DATA_DIR.exists()
                           else config.BASE_DIR),
        )
        if not path:
            return

        destination = copy_into(path, config.UPLOAD_DIR,
                                prefix=f"case{self._case['id']}_")
        if destination is None:
            show_error(self, "Upload failed",
                       "The selected file could not be copied into the uploads folder.")
            return

        db.update_case(int(self._case["id"]),
                       {"uploaded_file": relative_to_base(destination)})
        self._case["uploaded_file"] = relative_to_base(destination)
        self.file_label.configure(
            text=f"Uploaded file: {destination.name}   ({human_size(destination.stat().st_size)})",
            text_color=Theme.SUCCESS)
        self.status(f"Uploaded {destination.name}", "success")
        self._extract_from(destination)

    def _reextract(self) -> None:
        if not self._require_case():
            return
        stored = self._case.get("uploaded_file")
        if not stored:
            show_warning(self, "No file", "No PDF has been uploaded for this case yet.")
            return
        self._extract_from(resolve_stored_path(stored))

    def _extract_from(self, path: Path) -> None:
        busy = BusyDialog(self, "Reading PDF", f"Extracting text from {path.name}...")

        def work():
            return extract_pdf(path)

        def done(result) -> None:
            self._extraction = result
            if result.error and not result.is_scanned:
                self.extract_status.configure(text=result.error, text_color=Theme.DANGER)
                show_error(self, "PDF could not be read", result.error)
                return
            if result.is_scanned:
                self.extract_status.configure(text=SCANNED_PDF_MESSAGE,
                                              text_color=Theme.WARNING)
                show_warning(self, "No text layer found", SCANNED_PDF_MESSAGE)
                return

            self.text_box.delete("1.0", "end")
            self.text_box.insert("1.0", result.text)
            self.extract_status.configure(text=result.message, text_color=Theme.SUCCESS)
            self._save_text(silent=True)
            self.status(result.message, "success")

        def failed(exc: Exception) -> None:
            log.exception("PDF extraction failed")
            self.extract_status.configure(text=str(exc), text_color=Theme.DANGER)
            show_error(self, "PDF could not be read", str(exc))

        run_in_background(self, work, done, failed, busy)

    def _open_pdf(self) -> None:
        if not self._require_case():
            return
        stored = self._case.get("uploaded_file")
        if not stored:
            show_warning(self, "No file", "No PDF has been uploaded for this case.")
            return
        from utils.helpers import open_in_explorer

        if not open_in_explorer(resolve_stored_path(stored)):
            show_error(self, "Could not open", "The uploaded file could not be opened.")

    def _clear_text(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return
        confirm_action(
            self, "Clear notice text",
            "Remove the notice text held against this case?\n\n"
            "The uploaded PDF itself is not deleted.",
            self._do_clear_text, confirm_text="Clear", kind="warning",
        )

    def _do_clear_text(self) -> None:
        self.text_box.delete("1.0", "end")
        db.update_case(int(self._case["id"]), {"extracted_text": ""})
        self._case["extracted_text"] = ""
        self.extract_status.configure(text="Notice text cleared.",
                                      text_color=Theme.TEXT_MUTED)

    def _save_text(self, silent: bool = False) -> None:
        if not self._require_case():
            return
        if self.readonly:
            if not silent:
                self.block_if_readonly()
            return
        text = self.text_box.get("1.0", "end").strip()
        db.update_case(int(self._case["id"]), {"extracted_text": text})
        self._case["extracted_text"] = text
        self.extract_status.configure(
            text=f"{len(text):,} characters of notice text saved against the case.",
            text_color=Theme.SUCCESS)
        if not silent:
            self.status("Notice text saved", "success")

    # ==================================================================
    # AI analysis
    # ==================================================================
    def _analyse(self) -> None:
        if not self._require_case() or self.block_if_readonly():
            return

        text = self.text_box.get("1.0", "end").strip()
        if not text:
            show_warning(
                self, "No notice text",
                "There is no notice text to analyse.\n\n"
                "Upload a searchable PDF, or paste the notice text into the box.")
            return

        existing = db.get_notice_analysis(int(self._case["id"]))
        if existing:
            confirm_action(
                self, "Re-run analysis",
                "This case already has a saved analysis.\n\n"
                "Running the analysis again will replace the stored extraction and "
                "the issue list (any AI issue analysis and remarks on those issues "
                "will be lost).\n\nContinue?",
                lambda: self._run_analysis(text), confirm_text="Re-run", kind="warning",
            )
        else:
            self._run_analysis(text)

    def _run_analysis(self, text: str) -> None:
        self._save_text(silent=True)
        demo = self.app.demo_mode
        case = dict(self._case or {})

        message = ("Preparing sample analysis (Demo Mode - the API is not called)..."
                   if demo else "Analysing notice with Gemini. This may take up to a minute...")
        busy = BusyDialog(self, "Analysing notice", message)
        self.status("Analysing notice...", "info")

        def work():
            return notice_service.analyse_notice(text, case, demo_mode=demo)

        def done(result: notice_service.NoticeAnalysisResult) -> None:
            if not result.ok:
                self.status("Analysis failed", "danger")
                if result.error_kind == notice_service.ai_service.ERR_BAD_JSON:
                    MalformedResponseDialog(self, result.raw_json or "")
                else:
                    show_ai_error(self, "Analysis could not be completed",
                                  result.error)
                return
            try:
                notice_service.save_analysis(int(case["id"]), result)
            except db.DatabaseError as exc:
                show_error(self, "Could not save analysis",
                           f"The analysis ran but could not be saved.\n\n{exc}")
                return

            self._case = db.get_case(int(case["id"]))
            self._result = result
            self._render_result(result)
            self.tabs.set("2.  Notice Analysis")
            self.status(
                f"Analysis complete - {result.issue_count} issue(s), total exposure "
                f"{format_currency(result.demand.total_exposure)}", "success")
            for key in ("dashboard", "cases", "issues", "requirements", "draft", "reports"):
                self.app.refresh_page(key)
            show_success(
                self, "Analysis complete",
                f"{result.issue_count} issue(s) identified.\n"
                f"Total exposure computed in Python: "
                f"{format_currency(result.demand.total_exposure)}.\n\n"
                "Please review the extraction and the validation tab before "
                "relying on any figure.")

        def failed(exc: Exception) -> None:
            log.exception("Notice analysis failed")
            self.status("Analysis failed", "danger")
            show_error(self, "Analysis failed", str(exc))

        run_in_background(self, work, done, failed, busy)

    # ==================================================================
    # Rendering the result
    # ==================================================================
    def _render_result(self, result: notice_service.NoticeAnalysisResult,
                       saved_note: bool = False) -> None:
        self.analysis_placeholder.pack_forget()
        self.analysis_content.pack(fill="both", expand=True)

        data = result.data
        grid = self.overview_grid
        grid.reset()
        grid.add("Taxpayer", data.get("taxpayer_name") or "-", bold=True)
        grid.add("GSTIN", data.get("gstin") or "-")
        grid.add("Notice Type", data.get("notice_type") or "-")
        grid.add("Notice Number", data.get("notice_number") or "-")
        grid.add("Financial Year", data.get("financial_year") or "-")
        grid.add("Tax Period", data.get("tax_period") or "-")
        grid.add("Notice Date", format_date(data.get("notice_date")))
        grid.add("Reply Due Date", format_date(data.get("reply_due_date")))
        remaining = days_remaining(data.get("reply_due_date"))
        grid.add("Deadline", deadline_label(data.get("reply_due_date")),
                 value_color=Theme.DANGER if (remaining is not None and remaining < 7)
                 else Theme.SUCCESS, bold=True)
        grid.add("Officer", data.get("officer_name") or "-")
        grid.add("Designation", data.get("designation") or "-")
        grid.add("Jurisdiction", data.get("jurisdiction") or "-")
        grid.add_full("Sections Invoked", join_list(data.get("sections_invoked")))
        grid.add_full("Rules Invoked", join_list(data.get("rules_invoked")))

        risks = {i.get("initial_risk") for i in result.issues}
        overall = ("High" if "High" in risks else
                   "Medium" if "Medium" in risks else
                   "Low" if risks == {"Low"} else "Review Required")
        grid.add("Overall Risk", overall, bold=True,
                 value_color={"High": Theme.DANGER, "Medium": Theme.WARNING,
                              "Low": Theme.SUCCESS}.get(overall, Theme.INFO))

        # Demand summary
        for child in self.demand_body.winfo_children():
            child.destroy()
        header = ctk.CTkFrame(self.demand_body, fg_color="transparent")
        header.pack(fill="x", pady=(0, 4))
        ctk.CTkLabel(header, text="Component", font=font(10, "bold"),
                     text_color=Theme.TEXT_MUTED, anchor="w").pack(side="left")
        ctk.CTkLabel(header, text="Amount", font=font(10, "bold"),
                     text_color=Theme.TEXT_MUTED, anchor="e").pack(side="right")
        for label, amount, is_total in result.demand.rows():
            line = ctk.CTkFrame(
                self.demand_body,
                fg_color=Theme.SURFACE_ALT if is_total else "transparent",
                corner_radius=4)
            line.pack(fill="x", pady=1)
            ctk.CTkLabel(line, text=label,
                         font=font(12, "bold" if is_total else "normal"),
                         text_color=Theme.TEXT, anchor="w").pack(side="left", padx=8, pady=3)
            ctk.CTkLabel(line, text=format_currency(amount),
                         font=font(12, "bold" if is_total else "normal"),
                         text_color=Theme.DANGER if is_total else Theme.TEXT,
                         anchor="e").pack(side="right", padx=8, pady=3)
        ctk.CTkLabel(self.demand_body,
                     text="Total Tax = CGST + SGST + IGST + Cess\n"
                          "Total Exposure = Total Tax + Interest + Penalty + Other\n"
                          "Computed in Python using decimal arithmetic.",
                     font=font(9), text_color=Theme.TEXT_MUTED, justify="left",
                     anchor="w").pack(fill="x", pady=(8, 0))

        # Summary text
        self.summary_text.configure(state="normal")
        self.summary_text.delete("1.0", "end")
        self.summary_text.insert("1.0", data.get("summary") or
                                 "No summary was extracted from the notice.")
        self.summary_text.configure(state="disabled")

        # Issues table
        rows: List[Dict[str, Any]] = []
        for index, issue in enumerate(result.issues, start=1):
            rows.append({
                "id": issue.get("_id") or index,
                "issue_no": issue.get("issue_no", index),
                "title": truncate(issue.get("issue_title"), 60),
                "allegation_short": truncate(issue.get("department_allegation"), 90),
                "amount_display": format_currency(issue.get("amount")),
                "sections_display": join_list(issue.get("sections"), fallback="-"),
                "risk": issue.get("initial_risk", ""),
                "confidence": issue.get("confidence", ""),
            })
        self.issues_table.load(
            rows,
            tag_fn=lambda r: {"High": "danger", "Medium": "warning",
                              "Low": "success"}.get(r["risk"], ""))

        note = " (loaded from saved analysis)" if saved_note else ""
        self.source_label.configure(
            text=f"Source: {result.source}{note}"
                 + (f"  |  {result.elapsed:.1f}s" if result.elapsed else ""))

        self._render_validation(result)

    def _render_validation(self, result: notice_service.NoticeAnalysisResult) -> None:
        rows = [
            {
                "id": index,
                "field": v.field,
                "value": truncate(v.value, 70) or "-",
                "status": v.status,
                "confidence": v.confidence or "-",
                "message": v.message,
                "_field_key": v.field,
            }
            for index, v in enumerate(result.validations)
        ]
        self.validation_table.load(rows, tag_fn=lambda r: {
            VALID: "success", REVIEW: "warning",
            INVALID: "danger", NOT_FOUND: "muted"}.get(r["status"], ""))

        for child in self.validation_summary.winfo_children():
            child.destroy()
        counts = notice_service.validation_summary(result.validations)
        palette = {VALID: (Theme.SUCCESS, Theme.SUCCESS_BG),
                   REVIEW: (Theme.WARNING, Theme.WARNING_BG),
                   INVALID: (Theme.DANGER, Theme.DANGER_BG),
                   NOT_FOUND: (Theme.NEUTRAL, Theme.NEUTRAL_BG)}
        for status, count in counts.items():
            fg, bg = palette[status]
            chip = ctk.CTkFrame(self.validation_summary, fg_color=bg, corner_radius=5)
            chip.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(chip, text=f"{status}: {count}", font=font(11, "bold"),
                         text_color=fg).pack(padx=12, pady=5)

    # ==================================================================
    # Interactions
    # ==================================================================
    def _open_issue(self, row: Optional[Dict[str, Any]]) -> None:
        case_id = self._case_id()
        if not case_id:
            return
        issue_id = None
        if row and row.get("id"):
            try:
                issue_id = int(row["id"])
            except (TypeError, ValueError):
                issue_id = None
        self.navigate("issues", case_id=case_id, issue_id=issue_id)

    def _open_case(self) -> None:
        case_id = self._case_id()
        if case_id:
            self.navigate("cases", case_id=case_id)

    def _correct_field(self, row: Optional[Dict[str, Any]]) -> None:
        """Allow the CA to override an extracted value."""
        if not row or not self._case or self.block_if_readonly():
            return

        field_map = {
            "Taxpayer Name": "taxpayer_name", "GSTIN": "gstin",
            "Notice Type": "notice_type", "Notice Number": "notice_number",
            "Financial Year": "financial_year", "Tax Period": "tax_period",
            "Notice Date": "notice_date", "Reply Due Date": "reply_due_date",
            "CGST": "cgst", "SGST": "sgst", "IGST": "igst", "Cess": "cess",
            "Interest": "interest", "Penalty": "penalty",
            "Other Amount": "other_amount",
        }
        column = field_map.get(row.get("field", ""))
        if not column:
            show_info(self, "Not directly editable",
                      f"'{row.get('field')}' is a computed or derived check and cannot "
                      "be edited here.\n\nCorrect the underlying component values "
                      "instead - the totals are recalculated automatically.")
            return

        CorrectionDialog(self, row.get("field", ""), row.get("value", ""),
                         lambda value: self._apply_correction(column, value))

    def _apply_correction(self, column: str, value: str) -> None:
        case_id = int(self._case["id"])
        try:
            notice_service.apply_manual_correction(case_id, column, value)
        except db.DatabaseError as exc:
            show_error(self, "Could not save correction", str(exc))
            return
        self.status(f"'{column}' corrected manually", "success")
        saved = notice_service.load_saved_analysis(case_id)
        if saved:
            self._result = saved
            self._render_result(saved, saved_note=True)
        self.app.refresh_page("dashboard")
        self.app.refresh_page("cases")


def _case_label(case: Dict[str, Any]) -> str:
    return (f"{case.get('case_code', '')} - {case.get('client_name', '')} "
            f"({case.get('notice_type', '')}, FY {case.get('financial_year') or '-'})")


class CorrectionDialog(ModalDialog):
    """Manual correction of one extracted value."""

    def __init__(self, parent, field_name: str, current: str, on_save):
        super().__init__(parent, f"Correct - {field_name}", width=520, height=290,
                         resizable=False)
        self._on_save = on_save

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=22, pady=18)

        ctk.CTkLabel(body, text=f"Correct '{field_name}'", font=font(15, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text="The corrected value replaces the AI-extracted value. Totals are "
                 "recomputed in Python.",
            font=font(11), text_color=Theme.TEXT_MUTED, wraplength=450,
            justify="left").pack(anchor="w", pady=(2, 12))

        from ui.widgets import LabeledEntry

        self.entry = LabeledEntry(body, "Corrected value", current, width=450)
        self.entry.pack(fill="x")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(16, 0))
        primary_button(buttons, "Save correction", self._save, width=150).pack(side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _save(self) -> None:
        value = self.entry.get()
        callback = self._on_save
        self.close()
        callback(value)


class MalformedResponseDialog(ModalDialog):
    """Shown when the model returns something that is not valid JSON."""

    def __init__(self, parent, raw: str):
        super().__init__(parent, "AI response could not be read", width=680, height=480)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(body, text="The AI returned an unreadable response",
                     font=font(15, "bold"), text_color=Theme.DANGER).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text="The structured data could not be parsed. Nothing has been saved. "
                 "Please try again - this is usually intermittent. The raw response "
                 "is shown below for reference.",
            font=font(11), text_color=Theme.TEXT, wraplength=600,
            justify="left").pack(anchor="w", pady=(4, 10))

        box = ctk.CTkTextbox(body, font=("Consolas", 10), wrap="word",
                             fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                             border_width=1, border_color=Theme.BORDER)
        box.pack(fill="both", expand=True)
        box.insert("1.0", raw or "(empty response)")
        box.configure(state="disabled")

        primary_button(body, "Close", self.close, width=110).pack(anchor="e", pady=(12, 0))
