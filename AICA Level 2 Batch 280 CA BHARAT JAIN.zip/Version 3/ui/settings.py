"""
ui.settings
===========
Configuration screen.

Shows which AI provider is in use and whether its key is configured
(never the key itself), the database and folder locations, the Demo /
Mock AI Mode switch, user administration, demo data loading and the
built-in self tests.
"""

from __future__ import annotations

import webbrowser
from typing import Any, Dict, Optional

import customtkinter as ctk

import config
from config import Theme
from database import database as db
from services import ai_service, cbic_service, rag_service
from services.prompt_setup import ensure_prompt_files
from ui.base_page import BasePage
from ui.widgets import (
    BusyDialog, Card, DataTable, DetailGrid, LabeledDropdown, LabeledEntry,
    ModalDialog, confirm_action, danger_button, font, primary_button,
    run_in_background, secondary_button, show_error, show_info, show_success,
    show_warning,
)
from utils.formatters import format_datetime
from utils.helpers import (
    can_manage_users, human_size, open_in_explorer, password_strength_message,
)
from utils.logger import get_logger

log = get_logger(__name__)

USER_COLUMNS = [
    ("name", "Name", 200, "w"),
    ("username", "Username", 150, "w"),
    ("role", "Role", 160, "w"),
    ("email", "Email", 220, "w"),
    ("active_display", "Active", 80, "center"),
    ("last_login_display", "Last Login", 150, "center"),
]


class SettingsPage(BasePage):
    """Application settings and administration."""

    title = "Settings"
    subtitle = "AI configuration, folders, users, demo data and self tests"
    scrollable = True

    def build(self) -> None:
        self._build_ai_card()
        self._build_cbic_card()
        self._build_paths_card()
        self._build_preferences_card()
        self._build_data_card()
        self._build_users_card()
        self._build_about_card()

    # ------------------------------------------------------------------
    def _build_ai_card(self) -> None:
        card = Card(self.body, "AI Configuration",
                    "API keys are read from the .env file and are never displayed")
        card.pack(fill="x", pady=(0, 12))

        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        provider_box = ctk.CTkFrame(inner, fg_color=Theme.SURFACE_ALT, corner_radius=6)
        provider_box.pack(fill="x", pady=(0, 10))
        provider_left = ctk.CTkFrame(provider_box, fg_color="transparent")
        provider_left.pack(side="left", padx=14, pady=12, fill="x", expand=True)
        ctk.CTkLabel(provider_left, text="AI Provider", font=font(13, "bold"),
                     text_color=Theme.TEXT, anchor="w").pack(anchor="w")
        ctk.CTkLabel(
            provider_left,
            text="Notice analysis, issue analysis, document requirements, legal "
                 "research and draft replies all use the provider selected here.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=560).pack(anchor="w", pady=(2, 0))

        self.provider_menu = LabeledDropdown(
            provider_box, "Selected provider", config.AI_PROVIDERS,
            value=config.current_provider(), width=210,
            command=self._change_provider)
        self.provider_menu.pack(side="right", padx=18, pady=(8, 0))

        mode_box = ctk.CTkFrame(inner, fg_color=Theme.SURFACE_ALT, corner_radius=6)
        mode_box.pack(fill="x", pady=(0, 12))

        left = ctk.CTkFrame(mode_box, fg_color="transparent")
        left.pack(side="left", padx=14, pady=12)
        ctk.CTkLabel(left, text="Demo / Mock AI Mode", font=font(13, "bold"),
                     text_color=Theme.TEXT, anchor="w").pack(anchor="w")
        ctk.CTkLabel(
            left,
            text="When on, no API call is made. Predefined sample output is used so "
                 "the full workflow can be demonstrated without internet access or "
                 "an API key.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=680).pack(anchor="w", pady=(2, 0))

        self.demo_switch = ctk.CTkSwitch(
            mode_box, text="", width=52, progress_color=Theme.WARNING,
            command=self._toggle_demo)
        self.demo_switch.pack(side="right", padx=18)
        self.demo_state = ctk.CTkLabel(mode_box, text="", font=font(12, "bold"))
        self.demo_state.pack(side="right")

        self.ai_grid = DetailGrid(inner, columns=2)
        self.ai_grid.pack(fill="x")

        buttons = ctk.CTkFrame(inner, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Test AI Connection", self._test_connection,
                       width=170).pack(side="left")
        secondary_button(buttons, "Open .env location",
                         lambda: open_in_explorer(config.BASE_DIR),
                         width=150).pack(side="left", padx=8)
        secondary_button(buttons, "Restore Prompt Files", self._restore_prompts,
                         width=170).pack(side="left")
        secondary_button(buttons, "Open Prompts Folder",
                         lambda: open_in_explorer(config.PROMPT_DIR),
                         width=170).pack(side="left", padx=8)

    def _build_cbic_card(self) -> None:
        card = Card(self.body, "Legislation Source - CBIC",
                    "GST Acts, Rules, Notifications and Circulars as published "
                    "by the department")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        self.cbic_grid = DetailGrid(inner, columns=1)
        self.cbic_grid.pack(fill="x")
        self.cbic_grid.add("Portal", config.CBIC_PORTAL_URL)
        self.cbic_grid.add("Data service", config.CBIC_API_URL)
        self.cbic_status = ctk.CTkLabel(
            inner, text="Connection not tested in this session.", font=font(11),
            text_color=Theme.TEXT_MUTED, anchor="w", justify="left", wraplength=900)
        self.cbic_status.pack(fill="x", pady=(6, 0))

        ctk.CTkLabel(
            inner,
            text="Documents are downloaded from Knowledge Base > Import from CBIC "
                 "and indexed locally. Nothing is uploaded to the portal and no "
                 "connection is made to the GST return filing system.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=900).pack(fill="x", pady=(4, 0))

        buttons = ctk.CTkFrame(inner, fg_color="transparent")
        buttons.pack(fill="x", pady=(10, 0))
        primary_button(buttons, "Check CBIC Connection", self._check_cbic,
                       width=200).pack(side="left")
        secondary_button(buttons, "Open CBIC Portal",
                         lambda: webbrowser.open(config.CBIC_PORTAL_URL),
                         width=160).pack(side="left", padx=8)

        self.cbic_index_switch = ctk.CTkSwitch(
            buttons, text="Index downloads automatically", font=font(12),
            text_color=Theme.TEXT, progress_color=Theme.SUCCESS,
            command=self._toggle_cbic_index)
        self.cbic_index_switch.pack(side="right", padx=6)
        if self.app.settings.get("cbic_auto_index", True):
            self.cbic_index_switch.select()

    def _toggle_cbic_index(self) -> None:
        enabled = bool(self.cbic_index_switch.get())
        self.app.settings["cbic_auto_index"] = enabled
        self.app.save_settings()
        self.status(f"CBIC downloads will {'be' if enabled else 'not be'} "
                    f"indexed automatically", "success")

    def _check_cbic(self) -> None:
        busy = BusyDialog(self, "Checking CBIC",
                          "Contacting the CBIC Tax Information Portal...")

        def work():
            return cbic_service.connection_status()

        def done(status: Dict[str, Any]) -> None:
            reachable = bool(status.get("reachable"))
            self.cbic_status.configure(
                text=status.get("message", ""),
                text_color=Theme.SUCCESS if reachable else Theme.DANGER)
            if reachable:
                show_success(self, "CBIC reachable", status.get("message", ""))
                self.status("CBIC portal reachable", "success")
            else:
                show_error(
                    self, "CBIC not reachable",
                    f"{status.get('message', '')}\n\nThe knowledge base continues "
                    f"to work with the documents already held.")
                self.status("CBIC portal not reachable", "danger")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Check failed", str(exc)), busy)

    def _build_paths_card(self) -> None:
        card = Card(self.body, "Database and Folders")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        self.paths_grid = DetailGrid(inner, columns=1)
        self.paths_grid.pack(fill="x")

        buttons = ctk.CTkFrame(inner, fg_color="transparent")
        buttons.pack(fill="x", pady=(10, 0))
        for label, folder in (
            ("Uploads", config.UPLOAD_DIR), ("Exports", config.EXPORT_DIR),
            ("Knowledge Base", config.KNOWLEDGE_BASE_DIR), ("Logs", config.LOG_DIR),
            ("Sample Data", config.SAMPLE_DATA_DIR),
        ):
            secondary_button(buttons, f"Open {label}",
                             lambda f=folder: open_in_explorer(f),
                             width=150).pack(side="left", padx=(0, 8))

    def _build_preferences_card(self) -> None:
        card = Card(self.body, "Preferences")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        row = ctk.CTkFrame(inner, fg_color="transparent")
        row.pack(fill="x")

        self.firm_name = LabeledEntry(row, "Firm name (used on exports)",
                                      self.app.settings.get("firm_name", ""),
                                      width=280)
        self.firm_name.pack(side="left", padx=(0, 14))
        self.alert_days = LabeledDropdown(
            row, "Deadline alert window (days)", ["3", "5", "7", "10", "15", "30"],
            str(self.app.settings.get("deadline_alert_days", 7)), width=180)
        self.alert_days.pack(side="left", padx=(0, 14))
        self.top_k = LabeledDropdown(
            row, "Research passages to retrieve", ["4", "6", "8", "10"],
            str(self.app.settings.get("rag_top_k", 6)), width=190)
        self.top_k.pack(side="left", padx=(0, 14))
        self.chunk_size = LabeledDropdown(
            row, "Knowledge base chunk size", ["800", "1000", "1200", "1600", "2000"],
            str(self.app.settings.get("rag_chunk_size", 1200)), width=190)
        self.chunk_size.pack(side="left")

        primary_button(inner, "Save Preferences", self._save_preferences,
                       width=160).pack(anchor="w", pady=(10, 0))

    def _build_data_card(self) -> None:
        card = Card(self.body, "Demo Data / Sample Cases",
                    "Fictional records only - no real taxpayer information")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        ctk.CTkLabel(
            inner,
            text="One click builds the whole demonstration portfolio: 5 fictional "
                 "clients, 12 GST matters across every workflow status, 8 sample "
                 "notice PDFs, a pre-loaded analysis and issue breakdown for each "
                 "matter, and a requirement checklist, saved research and draft "
                 "reply for the featured case. Running it again fills in anything "
                 "missing and never duplicates.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=1040).pack(fill="x", pady=(0, 10))

        self.demo_chips = ctk.CTkFrame(inner, fg_color="transparent",
                                       width=1, height=1)
        self.demo_chips.pack(fill="x", pady=(0, 10))

        self.data_status = ctk.CTkLabel(inner, text="", font=font(11),
                                        text_color=Theme.TEXT_MUTED, anchor="w",
                                        justify="left", wraplength=1040)
        self.data_status.pack(fill="x", pady=(0, 10))

        row1 = ctk.CTkFrame(inner, fg_color="transparent")
        row1.pack(fill="x", pady=(0, 6))
        primary_button(row1, "Load Demo Data", self._prepare_demo,
                       width=160).pack(side="left")
        secondary_button(row1, "Reset Demo to Starting Position",
                         self._reset_demo_to_start, width=230).pack(
            side="left", padx=8)
        secondary_button(row1, "Start Guided Demo", self.app.start_guided_demo,
                         width=160).pack(side="left")
        danger_button(row1, "Reset Demo Data", self._reset_demo_data,
                      width=160).pack(side="right")

        row2 = ctk.CTkFrame(inner, fg_color="transparent")
        row2.pack(fill="x")
        secondary_button(row2, "Open Featured Case", self._open_featured,
                         width=160).pack(side="left")
        secondary_button(row2, "Open Notices Folder",
                         lambda: open_in_explorer(config.SAMPLE_NOTICE_DIR),
                         width=170).pack(side="left", padx=8)
        secondary_button(row2, "Regenerate Notice PDFs", self._regenerate_notices,
                         width=180).pack(side="left")
        danger_button(row2, "Clear ALL Clients and Cases", self._clear_data,
                      width=220).pack(side="right")

        ctk.CTkLabel(
            inner,
            text="'Reset Demo Data' removes only records flagged as demonstration "
                 "data. Real clients and cases are never touched by it. "
                 "'Clear ALL Clients and Cases' does delete everything.",
            font=font(10), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=1040).pack(fill="x", pady=(10, 0))

    def _render_demo_chips(self, status: Dict[str, Any]) -> None:
        """Progress chips showing how much demo data is loaded."""
        for child in self.demo_chips.winfo_children():
            child.destroy()
        chips = [
            ("Demo clients", f"{status['clients']}/{status['expected_clients']}"),
            ("Demo cases", f"{status['cases']}/{status['expected_cases']}"),
            ("Notice PDFs", f"{status['notice_pdfs']}/{status['expected_pdfs']}"),
            ("Demo KB documents", str(status["kb_documents"])),
            ("Real clients", str(status["real_clients"])),
            ("Real cases", str(status["real_cases"])),
        ]
        for index, (label, value) in enumerate(chips):
            parts = value.split("/")
            complete = len(parts) == 2 and parts[0] == parts[1]
            if label.startswith("Real"):
                fg, bg = Theme.PRIMARY, Theme.INFO_BG
            elif complete and parts[0] != "0":
                fg, bg = Theme.SUCCESS, Theme.SUCCESS_BG
            elif len(parts) == 1 and parts[0] != "0":
                fg, bg = Theme.SUCCESS, Theme.SUCCESS_BG
            else:
                fg, bg = Theme.WARNING, Theme.WARNING_BG
            chip = ctk.CTkFrame(self.demo_chips, fg_color=bg, corner_radius=5)
            chip.pack(side="left", padx=(0 if index == 0 else 8, 0))
            ctk.CTkLabel(chip, text=f"{label}: {value}", font=font(11, "bold"),
                         text_color=fg).pack(padx=12, pady=5)

    # ------------------------------------------------------------------
    def _prepare_demo(self) -> None:
        if self.block_if_readonly():
            return
        from services import demo_data

        if demo_data.demo_data_present():
            confirm_action(
                self, "Demo data already present",
                "Demonstration data is already loaded.\n\n"
                "Running the setup again fills in anything missing - sample "
                "notices, analyses, requirements, research or the draft reply - "
                "without creating duplicates.\n\nContinue?",
                self._run_prepare_demo, confirm_text="Run setup", kind="info")
        else:
            self._run_prepare_demo()

    def _run_prepare_demo(self) -> None:
        from services import demo_data

        busy = BusyDialog(self, "Preparing demo environment",
                          "Creating clients, cases and sample notices...")

        def work():
            return demo_data.prepare_demo_environment(
                progress=lambda message: busy.set_message(message))

        def done(result) -> None:
            self.refresh()
            self.app.refresh_all()
            detail = result.summary
            if result.kb_documents:
                detail += (f"\nKnowledge base: {result.kb_documents} document(s), "
                           f"{result.kb_chunks} searchable passage(s).")
            if result.already_present:
                detail = "Everything was already in place.\n\n" + detail
            if result.messages:
                detail += "\n\n" + "\n".join(result.messages[:4])
            self.status("Demo environment ready", "success")
            show_success(self, "Demo Environment Ready", detail)

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Could not prepare", str(exc)),
                          busy)

    def _reset_demo_data(self) -> None:
        if self.block_if_readonly():
            return
        counts = db.demo_counts()
        if not (counts["clients"] or counts["cases"]):
            show_info(self, "Nothing to reset",
                      "No demonstration data is currently loaded.")
            return
        confirm_action(
            self, "Reset demo data",
            f"Delete {counts['clients']} demonstration client(s) and "
            f"{counts['cases']} demonstration case(s), together with their "
            "analyses, issues, requirements, research and drafts?\n\n"
            f"Your {counts['real_clients']} real client(s) and "
            f"{counts['real_cases']} real case(s) will NOT be affected.\n\n"
            "The demonstration knowledge-base documents are removed as well.",
            self._do_reset_demo_data, confirm_text="Delete demo data")

    def _do_reset_demo_data(self) -> None:
        from services import demo_data

        try:
            removed = demo_data.reset_demo_data(include_knowledge_base=True)
        except db.DatabaseError as exc:
            show_error(self, "Could not reset", str(exc))
            return
        self.refresh()
        self.app.refresh_all()
        self.status("Demo data removed", "warning")
        show_success(self, "Demo data removed",
                     f"{removed['clients']} client(s) and {removed['cases']} "
                     "case(s) flagged as demonstration data were deleted.\n\n"
                     "Real records were not touched.")

    def _reset_demo_to_start(self) -> None:
        if self.block_if_readonly():
            return
        confirm_action(
            self, "Reset demo to starting position",
            "Rebuild the demonstration data so statuses, requirements, research "
            "and draft versions return to their starting state?\n\n"
            "This is the quickest way to repeat the demonstration. Real records "
            "are not affected.",
            self._do_reset_demo_to_start, confirm_text="Reset to start",
            kind="warning")

    def _do_reset_demo_to_start(self) -> None:
        from services import demo_data

        busy = BusyDialog(self, "Resetting demo",
                          "Restoring the demonstration starting position...")

        def work():
            return demo_data.reset_demo_to_start(
                progress=lambda message: busy.set_message(message))

        def done(result) -> None:
            self.refresh()
            self.app.refresh_all()
            self.status("Demo reset to its starting position", "success")
            show_success(self, "Demo Environment Ready",
                         "The demonstration has been restored to its starting "
                         f"position.\n\n{result.summary}")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Could not reset", str(exc)),
                          busy)

    def _open_featured(self) -> None:
        from services import demo_data

        case = demo_data.featured_case()
        if not case:
            show_info(self, "Not loaded",
                      "The featured demonstration case is not loaded. "
                      "Use 'Load Demo Data' first.")
            return
        self.navigate("cases", case_id=int(case["id"]))

    def _regenerate_notices(self) -> None:
        from services import demo_data

        written, messages = demo_data.generate_notice_pdfs(overwrite=True)
        self.refresh()
        detail = (f"{written} sample notice PDF(s) regenerated in\n"
                  f"{config.SAMPLE_NOTICE_DIR}")
        if messages:
            detail += "\n\n" + "\n".join(messages[:4])
        show_success(self, "Sample notices regenerated", detail)

    def _build_users_card(self) -> None:
        card = Card(self.body, "Users and Roles")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=16, pady=12)

        toolbar = ctk.CTkFrame(inner, fg_color="transparent")
        toolbar.pack(fill="x", pady=(0, 8))
        primary_button(toolbar, "+ Add User", self._add_user, width=120).pack(side="left")
        secondary_button(toolbar, "Edit", self._edit_user, width=80).pack(
            side="left", padx=6)
        secondary_button(toolbar, "Reset Password", self._reset_password,
                         width=140).pack(side="left")
        secondary_button(toolbar, "Change My Password", self._change_own_password,
                         width=170).pack(side="left", padx=6)
        danger_button(toolbar, "Delete", self._delete_user, width=90).pack(side="left")

        self.role_note = ctk.CTkLabel(toolbar, text="", font=font(10),
                                      text_color=Theme.TEXT_MUTED)
        self.role_note.pack(side="right")

        self.user_table = DataTable(inner, USER_COLUMNS, height=7,
                                    on_double_click=lambda _r: self._edit_user())
        self.user_table.pack(fill="x")

        ctk.CTkLabel(
            inner,
            text="Access: Admin / Partner sees every client and case; Manager, Team "
                 "Member and Reviewer see matters they are assigned to; Viewer has "
                 "read-only access. Only Admin / Partner and Reviewer may mark a "
                 "draft 'CA Approved' or 'Final'.",
            font=font(10), text_color=Theme.TEXT_MUTED, anchor="w", justify="left",
            wraplength=1080).pack(fill="x", pady=(8, 0))

    def _build_about_card(self) -> None:
        card = Card(self.body, "Diagnostics and About")
        card.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        buttons = ctk.CTkFrame(inner, fg_color="transparent")
        buttons.pack(fill="x")
        primary_button(buttons, "Run Self Tests", self._run_self_tests,
                       width=150).pack(side="left")
        secondary_button(buttons, "View Log File", self._view_log, width=130).pack(
            side="left", padx=8)
        secondary_button(buttons, "Disclaimer", self.app.show_disclaimer,
                         width=120).pack(side="left")

        ctk.CTkLabel(
            inner,
            text=f"{config.APP_NAME}  {config.APP_VERSION_LABEL}\n"
                 f"{config.APP_TAGLINE}\n"
                 f"{config.APP_BRANDING}\n\n"
                 "AI performs the repetitive groundwork. "
                 "The Chartered Accountant retains professional judgment.",
            font=font(11), text_color=Theme.TEXT_MUTED, anchor="w",
            justify="left").pack(fill="x", pady=(12, 0))

    # ==================================================================
    def refresh(self) -> None:
        # AI status
        status = ai_service.api_status()
        self.provider_menu.set(status["provider"])
        self.ai_grid.reset()
        self.ai_grid.add("Active provider", status["provider"], bold=True)
        self.ai_grid.add("Model", status["model"])
        self.ai_grid.add("API key configured",
                         "Yes" if status["key_configured"] else "No",
                         value_color=Theme.SUCCESS if status["key_configured"]
                         else Theme.DANGER, bold=True)
        self.ai_grid.add("API key (masked)", status["key_masked"])
        self.ai_grid.add("SDK installed",
                         "Yes" if status["sdk_installed"] else "No",
                         value_color=Theme.SUCCESS if status["sdk_installed"]
                         else Theme.DANGER)
        self.ai_grid.add("Request timeout", f"{status['timeout']} seconds")

        for name, detail in status.get("providers", {}).items():
            if detail["ready"]:
                summary = f"Ready - {detail['model']} - key {detail['key_masked']}"
                colour = Theme.SUCCESS
            elif not detail["sdk_installed"]:
                summary = f"SDK not installed ({detail['model']})"
                colour = Theme.DANGER
            else:
                summary = f"No key - set {detail['env_var']} in .env"
                colour = Theme.DANGER
            self.ai_grid.add(name, summary, value_color=colour)

        self.ai_grid.add("Configuration file", str(config.BASE_DIR / ".env"))
        if not status["key_configured"]:
            self.ai_grid.add_full(
                "How to configure",
                "Create a file named '.env' in the application folder containing "
                f"{status['env_var']}=your_api_key_here and restart the "
                "application. Demo Mode works without a key.")

        if self.app.demo_mode:
            self.demo_switch.select()
            self.demo_state.configure(text="ON - API not called",
                                      text_color=Theme.WARNING)
        else:
            self.demo_switch.deselect()
            self.demo_state.configure(
                text="OFF - live API" if status["key_configured"]
                else "OFF - but no key configured",
                text_color=Theme.SUCCESS if status["key_configured"] else Theme.DANGER)

        # Paths
        database_status = db.database_status()
        kb_status = rag_service.knowledge_base_status()
        self.paths_grid.reset()
        self.paths_grid.add("Database",
                            f"{database_status['path']}  "
                            f"({human_size(database_status.get('size', 0))})")
        self.paths_grid.add("Database connection",
                            "Connected" if database_status["connected"] else "Error",
                            value_color=Theme.SUCCESS if database_status["connected"]
                            else Theme.DANGER, bold=True)
        counts = database_status.get("counts", {})
        self.paths_grid.add(
            "Records",
            "  |  ".join(f"{name}: {value}" for name, value in counts.items()))
        self.paths_grid.add("Upload folder", str(config.UPLOAD_DIR))
        self.paths_grid.add("Export folder", str(config.EXPORT_DIR))
        self.paths_grid.add("Knowledge base folder", str(config.KNOWLEDGE_BASE_DIR))
        self.paths_grid.add(
            "Knowledge base",
            f"{kb_status['documents']} document(s), {kb_status['indexed']} indexed, "
            f"{kb_status['chunks']:,} searchable passage(s)")
        self.paths_grid.add("Prompt folder", str(config.PROMPT_DIR))
        self.paths_grid.add("Log file", str(config.LOG_FILE))

        # Demo data status
        from services import demo_data

        demo = demo_data.demo_status()
        self._render_demo_chips(demo)
        if demo["loaded"]:
            featured = demo["featured_label"] or "not loaded"
            self.data_status.configure(
                text=f"Demonstration portfolio is loaded. Featured case: {featured}. "
                     f"Sample notices are in {demo['notice_folder']}.",
                text_color=Theme.SUCCESS)
        else:
            self.data_status.configure(
                text="No demonstration data is loaded yet. Click 'Load Demo Data' to "
                     "build the full sample portfolio in one step.",
                text_color=Theme.TEXT_MUTED)

        # Users
        self._load_users()

    def _load_users(self) -> None:
        try:
            users = db.list_users()
        except db.DatabaseError:
            return
        rows = [
            {
                "id": user["id"],
                "name": user.get("name", ""),
                "username": user.get("username", ""),
                "role": user.get("role", ""),
                "email": user.get("email") or "-",
                "active_display": "Yes" if user.get("active") else "No",
                "last_login_display": format_datetime(user.get("last_login"), "Never"),
            }
            for user in users
        ]
        self.user_table.load(rows, tag_fn=lambda r: "" if r["active_display"] == "Yes"
                             else "muted")
        if not can_manage_users(self.user_role):
            self.role_note.configure(
                text="Only an Admin / Partner can add, edit or delete users.")
        else:
            self.role_note.configure(text=f"{len(rows)} user account(s)")

    # ==================================================================
    def _toggle_demo(self) -> None:
        enabled = bool(self.demo_switch.get())
        if not enabled and not config.api_key_available():
            show_warning(
                self, "No API key configured",
                f"Demo Mode has been switched off, but no API key is configured "
                f"for {config.current_provider()}.\n\n"
                "AI actions will report a configuration error until a key is added "
                "to the .env file. Switch Demo Mode back on to continue without a key.")
        self.app.set_demo_mode(enabled)
        self.refresh()
        self.status(f"Demo Mode {'enabled' if enabled else 'disabled'}",
                    "warning" if enabled else "success")

    def _save_preferences(self) -> None:
        self.app.settings["firm_name"] = self.firm_name.get()
        self.app.settings["deadline_alert_days"] = int(self.alert_days.get())
        self.app.settings["rag_top_k"] = int(self.top_k.get())
        self.app.settings["rag_chunk_size"] = int(self.chunk_size.get())
        self.app.save_settings()
        self.app.refresh_page("dashboard")
        self.status("Preferences saved", "success")
        show_success(self, "Saved", "Your preferences have been saved.")

    def _change_provider(self, value: str) -> None:
        """Persist the AI provider chosen in the dropdown."""
        if value not in config.AI_PROVIDERS:
            return
        if value == self.app.settings.get("ai_provider"):
            return
        self.app.settings["ai_provider"] = value
        self.app.save_settings()
        self.refresh()
        self.status(f"AI provider set to {value}", "success")
        if not config.api_key_available(value):
            show_warning(
                self, "No API key for this provider",
                f"{value} is now selected, but {config.provider_env_var(value)} "
                "is not set in the .env file.\n\n"
                "Add the key and restart the application, or keep Demo Mode on.")

    def _test_connection(self) -> None:
        provider = self.provider_menu.get() or config.current_provider()
        if not config.api_key_available(provider):
            show_error(self, "No API key",
                       ai_service.FRIENDLY_MESSAGES[ai_service.ERR_NO_KEY])
            return
        busy = BusyDialog(self, "Testing connection",
                          f"Sending a small test request to {provider}...")

        def work():
            return ai_service.test_connection(provider)

        def done(response: ai_service.AIResponse) -> None:
            if response.ok:
                show_success(
                    self, "Connection successful",
                    f"{provider} responded successfully using model "
                    f"{response.model}.\n\nRound trip: {response.elapsed:.1f} seconds.")
                self.status(f"{provider} connection test succeeded", "success")
            else:
                show_error(self, "Connection failed", response.friendly_error)
                self.status(f"{provider} connection test failed", "danger")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Test failed", str(exc)), busy)

    def _restore_prompts(self) -> None:
        confirm_action(
            self, "Restore prompt files",
            "Overwrite the prompt files in the prompts folder with the built-in "
            "defaults?\n\nAny edits you have made to them will be lost.",
            self._do_restore_prompts, confirm_text="Restore", kind="warning")

    def _do_restore_prompts(self) -> None:
        written = ensure_prompt_files(overwrite=True)
        self.status(f"{written} prompt file(s) restored", "success")
        show_success(self, "Prompts restored",
                     f"{written} prompt template(s) were written to "
                     f"{config.PROMPT_DIR}.")

    # ==================================================================
    def _clear_data(self) -> None:
        if self.block_if_readonly():
            return
        if not can_manage_users(self.user_role):
            show_warning(self, "Not permitted",
                         "Only an Admin / Partner can clear the application data.")
            return
        confirm_action(
            self, "Clear all clients and cases",
            "Permanently delete EVERY client, case, analysis, issue, requirement, "
            "research answer and draft?\n\n"
            "User accounts and the knowledge base are not affected.\n\n"
            "This cannot be undone.",
            self._do_clear_data, confirm_text="Delete everything")

    def _do_clear_data(self) -> None:
        try:
            db.reset_transactional_data()
        except db.DatabaseError as exc:
            show_error(self, "Could not clear", str(exc))
            return
        self.refresh()
        self.app.refresh_all()
        self.status("All clients and cases deleted", "warning")
        show_success(self, "Data cleared",
                     "All clients and cases have been deleted.")

    # ==================================================================
    def _require_admin(self) -> bool:
        if not can_manage_users(self.user_role):
            show_warning(self, "Not permitted",
                         "Only an Admin / Partner can manage user accounts.")
            return False
        return True

    def _add_user(self) -> None:
        if not self._require_admin():
            return
        UserDialog(self, on_saved=self._load_users)

    def _edit_user(self) -> None:
        if not self._require_admin():
            return
        user_id = self.user_table.selected_int_id()
        if not user_id:
            show_warning(self, "No user selected", "Please select a user first.")
            return
        user = db.get_user(user_id)
        if user:
            UserDialog(self, user=user, on_saved=self._load_users)

    def _reset_password(self) -> None:
        if not self._require_admin():
            return
        user_id = self.user_table.selected_int_id()
        if not user_id:
            show_warning(self, "No user selected", "Please select a user first.")
            return
        user = db.get_user(user_id)
        if user:
            ResetPasswordDialog(self, user, on_saved=self._load_users)

    def _change_own_password(self) -> None:
        from ui.login import ChangePasswordDialog

        user = db.get_user(int(self.user.get("id", 0)))
        if not user:
            show_error(self, "Not available", "Your user record could not be loaded.")
            return
        ChangePasswordDialog(self, user, first_login=False)

    def _delete_user(self) -> None:
        if not self._require_admin():
            return
        user_id = self.user_table.selected_int_id()
        if not user_id:
            show_warning(self, "No user selected", "Please select a user first.")
            return
        if user_id == int(self.user.get("id", 0)):
            show_warning(self, "Not permitted",
                         "You cannot delete the account you are signed in with.")
            return
        user = db.get_user(user_id)
        if not user:
            return
        if len([u for u in db.list_users() if u.get("role") == "Admin / Partner"]) <= 1 \
                and user.get("role") == "Admin / Partner":
            show_warning(self, "Not permitted",
                         "At least one Admin / Partner account must remain.")
            return

        def do_delete() -> None:
            db.delete_user(user_id)
            self._load_users()
            self.status(f"User '{user.get('username')}' deleted", "success")

        confirm_action(self, "Delete user",
                       f"Delete the account '{user.get('username')}'?",
                       do_delete, confirm_text="Delete")

    # ==================================================================
    def _run_self_tests(self) -> None:
        busy = BusyDialog(self, "Running self tests",
                          "Checking validation, calculations, database, PDF and AI "
                          "error handling...")

        def work():
            from tests.self_tests import run_all

            return run_all()

        def done(result) -> None:
            SelfTestDialog(self, result)
            self.status(
                f"Self tests: {result['passed']} passed, {result['failed']} failed",
                "success" if result["failed"] == 0 else "danger")

        run_in_background(self, work, done,
                          lambda exc: show_error(self, "Self tests failed", str(exc)),
                          busy)

    def _view_log(self) -> None:
        if not config.LOG_FILE.exists():
            show_info(self, "No log yet", "The log file has not been created yet.")
            return
        LogDialog(self)


class UserDialog(ModalDialog):
    """Add / edit a user account."""

    def __init__(self, parent, user: Optional[Dict[str, Any]] = None, on_saved=None):
        title = "Edit User" if user else "Add User"
        super().__init__(parent, title, width=560, height=520)
        self._user = user
        self._on_saved = on_saved

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)
        ctk.CTkLabel(body, text=title, font=font(16, "bold"),
                     text_color=Theme.TEXT).pack(anchor="w", pady=(0, 10))

        u = user or {}
        self.name = LabeledEntry(body, "Full Name", u.get("name", ""), required=True,
                                 width=480)
        self.name.pack(fill="x")
        self.username = LabeledEntry(body, "Username", u.get("username", ""),
                                     required=True, width=480)
        self.username.pack(fill="x")
        if user:
            self.username.entry.configure(state="disabled")
        self.email = LabeledEntry(body, "Email", u.get("email", ""), width=480)
        self.email.pack(fill="x")
        self.role = LabeledDropdown(body, "Role", config.USER_ROLES,
                                    u.get("role", "Team Member"), width=480)
        self.role.pack(fill="x")

        if not user:
            self.password = LabeledEntry(body, "Temporary password", show="*",
                                         required=True, width=480)
            self.password.pack(fill="x")
            ctk.CTkLabel(body,
                         text="The user will be asked to change this on first login.",
                         font=font(10), text_color=Theme.TEXT_MUTED,
                         anchor="w").pack(fill="x")

        self.active = ctk.CTkSwitch(body, text="Account active", font=font(12),
                                    text_color=Theme.TEXT, progress_color=Theme.SUCCESS)
        self.active.pack(anchor="w", pady=(10, 0))
        if u.get("active", 1):
            self.active.select()

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(16, 0))
        primary_button(buttons, "Save", self._save, width=120).pack(side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _save(self) -> None:
        name = self.name.get()
        username = self.username.get().lower()
        if not name or not username:
            show_error(self, "Missing information",
                       "Full name and username are both required.")
            return
        try:
            if self._user:
                db.update_user(int(self._user["id"]), {
                    "name": name, "email": self.email.get(), "role": self.role.get(),
                    "active": 1 if self.active.get() else 0,
                })
            else:
                if db.get_user_by_username(username):
                    show_error(self, "Username taken",
                               f"The username '{username}' is already in use.")
                    return
                password = self.password.entry.get()
                problem = password_strength_message(password)
                if problem:
                    show_error(self, "Password problem", problem)
                    return
                db.create_user(name, username, password, self.role.get(),
                               self.email.get())
        except db.DatabaseError as exc:
            show_error(self, "Could not save", str(exc))
            return

        callback = self._on_saved
        self.close()
        if callback:
            callback()


class ResetPasswordDialog(ModalDialog):
    """Administrator reset of another user's password."""

    def __init__(self, parent, user: Dict[str, Any], on_saved=None):
        super().__init__(parent, "Reset password", width=500, height=320,
                         resizable=False)
        self._user = user
        self._on_saved = on_saved

        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)
        ctk.CTkLabel(body, text=f"Reset password for {user.get('name', '')}",
                     font=font(15, "bold"), text_color=Theme.TEXT).pack(anchor="w")
        ctk.CTkLabel(body,
                     text="The user will be asked to change this on next sign-in.",
                     font=font(11), text_color=Theme.TEXT_MUTED).pack(
            anchor="w", pady=(2, 12))

        self.password = LabeledEntry(body, "New temporary password", show="*",
                                     width=420)
        self.password.pack(fill="x")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(16, 0))
        primary_button(buttons, "Reset password", self._save, width=150).pack(
            side="right")
        secondary_button(buttons, "Cancel", self.close, width=100).pack(
            side="right", padx=(0, 8))

    def _save(self) -> None:
        password = self.password.entry.get()
        problem = password_strength_message(password)
        if problem:
            show_error(self, "Password problem", problem)
            return
        db.set_user_password(int(self._user["id"]), password)
        db.update_user(int(self._user["id"]), {"must_change_pw": 1})
        callback = self._on_saved
        self.close()
        if callback:
            callback()
        show_success(self.master, "Password reset",
                     f"The password for '{self._user.get('username')}' has been reset.")


class SelfTestDialog(ModalDialog):
    """Results of the built-in self tests."""

    def __init__(self, parent, result: Dict[str, Any]):
        super().__init__(parent, "Self test results", width=760, height=560)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)

        passed, failed = result["passed"], result["failed"]
        colour = Theme.SUCCESS if failed == 0 else Theme.DANGER
        ctk.CTkLabel(body, text=f"{passed} passed, {failed} failed",
                     font=font(18, "bold"), text_color=colour).pack(anchor="w")
        ctk.CTkLabel(
            body,
            text="These tests cover GSTIN and PAN validation, Indian currency "
                 "formatting, demand computation, the database, PDF extraction and "
                 "malformed AI output handling.",
            font=font(11), text_color=Theme.TEXT_MUTED, wraplength=680,
            justify="left").pack(anchor="w", pady=(4, 10))

        box = ctk.CTkTextbox(body, font=("Consolas", 10), wrap="none",
                             fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                             border_width=1, border_color=Theme.BORDER)
        box.pack(fill="both", expand=True)
        box.insert("1.0", result["report"])
        box.configure(state="disabled")

        primary_button(body, "Close", self.close, width=110).pack(
            anchor="e", pady=(12, 0))


class LogDialog(ModalDialog):
    """Tail of the application log."""

    def __init__(self, parent):
        super().__init__(parent, "Application log", width=900, height=580)
        body = ctk.CTkFrame(self, fg_color=Theme.BG)
        body.pack(fill="both", expand=True, padx=18, pady=14)

        ctk.CTkLabel(body, text=str(config.LOG_FILE), font=font(11),
                     text_color=Theme.TEXT_MUTED).pack(anchor="w", pady=(0, 8))

        box = ctk.CTkTextbox(body, font=("Consolas", 10), wrap="none",
                             fg_color=Theme.SURFACE, text_color=Theme.TEXT,
                             border_width=1, border_color=Theme.BORDER)
        box.pack(fill="both", expand=True)
        try:
            lines = config.LOG_FILE.read_text(encoding="utf-8",
                                              errors="replace").splitlines()
            box.insert("1.0", "\n".join(lines[-400:]))
        except OSError as exc:
            box.insert("1.0", f"The log file could not be read: {exc}")
        box.configure(state="disabled")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(12, 0))
        primary_button(buttons, "Close", self.close, width=100).pack(side="right")
        secondary_button(buttons, "Open log folder",
                         lambda: open_in_explorer(config.LOG_DIR),
                         width=140).pack(side="right", padx=(0, 8))
