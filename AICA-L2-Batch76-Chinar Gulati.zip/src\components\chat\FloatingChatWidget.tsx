import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, X, Send, Radio, Users, 
  ChevronUp, Paperclip, Sparkles, FileText, Bell 
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { formatDateTime } from '../../lib/utils';

export const FloatingChatWidget: React.FC = () => {
  const { user } = useAuth();
  const { team, chatMessages, sendChatMessage, markChatRead, unreadChatCount } = useData();

  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('all');
  const [text, setText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      markChatRead(activeTab);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, activeTab, chatMessages]);

  const activeTargetMember = team.find((m) => m.id === activeTab);

  const getShortName = (name: string) => {
    const clean = name.split('(')[0].trim();
    const parts = clean.split(' ');
    if (parts.length >= 2 && (parts[0].toLowerCase() === 'ca' || parts[0].toLowerCase() === 'adv')) {
      return `${parts[0]} ${parts[1]}`;
    }
    return parts[0];
  };

  const currentMessages = React.useMemo(() => {
    if (activeTab === 'all') {
      return chatMessages.filter((m) => m.recipient_id === 'all');
    }
    const myId = user?.id || '';
    return chatMessages.filter(
      (m) =>
        (m.sender_id === myId && m.recipient_id === activeTab) ||
        (m.sender_id === activeTab && m.recipient_id === myId)
    );
  }, [chatMessages, activeTab, user]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    sendChatMessage(
      activeTab,
      text.trim(),
      undefined,
      activeTab === 'all'
    );
    setText('');
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {/* Expanded Chat Drawer */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 h-[480px] rounded-2xl border border-border bg-card shadow-elevated flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5">
          {/* Header */}
          <div className="p-3 bg-sidebar text-sidebar-foreground flex items-center justify-between border-b border-sidebar-border">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-white font-bold text-xs">
                CG
              </div>
              <div>
                <p className="text-xs font-bold text-white">Staff Quick Chat</p>
                <p className="text-[10px] text-sidebar-foreground/70">Chinar Gulati & Co.</p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Quick Recipient Bar */}
          <div className="p-1.5 bg-muted/40 border-b border-border flex items-center gap-1 overflow-x-auto text-[11px] scrollbar-thin">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-primary text-white shadow-soft'
                  : 'text-muted-foreground hover:bg-muted'
              }`}
            >
              <Radio className="h-3 w-3" />
              <span>All Staff</span>
            </button>

            {team
              .filter((m) => m.id !== user?.id)
              .map((member) => {
                const isActive = activeTab === member.id;
                const unread = chatMessages.filter(
                  (m) => m.sender_id === member.id && m.recipient_id === user?.id && !m.read_by?.includes(user?.id || '')
                ).length;

                return (
                  <button
                    key={member.id}
                    type="button"
                    onClick={() => setActiveTab(member.id)}
                    className={`shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-semibold transition-all ${
                      isActive
                        ? 'bg-primary text-white shadow-soft font-bold'
                        : 'text-muted-foreground hover:bg-muted'
                    }`}
                  >
                    <span>{getShortName(member.display_name)}</span>
                    {unread > 0 && (
                      <span className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
                    )}
                  </button>
                );
              })}
          </div>

          {/* Message Stream */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-muted/5 text-xs">
            {currentMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-4 text-muted-foreground">
                <MessageSquare className="h-8 w-8 opacity-30 mb-1" />
                <p className="text-xs font-semibold">No messages yet</p>
                <p className="text-[10px]">Send a quick query or update.</p>
              </div>
            ) : (
              currentMessages.map((msg) => {
                const isMe = msg.sender_id === user?.id;
                return (
                  <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    <span className="text-[9px] text-muted-foreground px-1 mb-0.5">
                      {isMe ? 'You' : msg.sender_name.split('(')[0]} • {formatDateTime(msg.created_at).split(',')[1]}
                    </span>
                    <div
                      className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${
                        isMe
                          ? 'bg-primary text-white rounded-br-none'
                          : 'bg-secondary text-foreground border border-border rounded-bl-none'
                      }`}
                    >
                      {msg.is_announcement && (
                        <span className="block text-[9px] font-bold text-amber-300 pb-0.5">
                          📢 ANNOUNCEMENT
                        </span>
                      )}
                      <p className="whitespace-pre-wrap leading-tight">{msg.content}</p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Input Bar */}
          <form onSubmit={handleSend} className="p-2 border-t border-border bg-card flex items-center gap-1.5">
            <Input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={activeTab === 'all' ? 'Broadcast to team…' : `Message ${activeTargetMember?.display_name.split(' ')[0]}…`}
              className="text-xs h-8"
            />
            <Button
              type="submit"
              size="sm"
              disabled={!text.trim()}
              className="h-8 px-3 bg-gradient-primary shadow-soft shrink-0"
            >
              <Send className="h-3.5 w-3.5" />
            </Button>
          </form>
        </div>
      )}

      {/* Floating Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="Open Staff Chat"
        className="group flex items-center gap-2 rounded-full bg-gradient-primary p-3.5 text-white shadow-elevated hover:scale-105 transition-all"
      >
        <div className="relative">
          <MessageSquare className="h-5 w-5" />
          {unreadChatCount > 0 && (
            <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[9px] font-extrabold text-white border-2 border-white animate-pulse">
              {unreadChatCount}
            </span>
          )}
        </div>
        <span className="text-xs font-bold hidden sm:inline pr-1">Staff Chat</span>
      </button>
    </div>
  );
};
