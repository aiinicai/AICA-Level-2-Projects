import React from 'react';
import { 
  LayoutDashboard, Kanban, FileText, Users, CheckSquare, 
  Video, Calendar, UserCheck, Clock, Settings, Sparkles, 
  LogOut, ShieldAlert, ChevronRight, X, ShieldCheck, FileCheck2,
  MessageSquare, Radio 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { cn } from '../../lib/utils';

export interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
}

interface SidebarProps {
  currentRoute: string;
  onNavigate: (route: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRoute,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { user, role, logout } = useAuth();
  const { metrics, unreadChatCount } = useData();

  const isAdmin = role === 'partner' || role === 'admin';

  const navItems: NavItem[] = isAdmin
    ? [
        { id: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: '/chat', label: 'Staff Chat & Broadcast', icon: MessageSquare, badge: unreadChatCount },
        { id: '/tasks', label: 'Tasks & Delegation', icon: CheckSquare, badge: metrics.pendingTasks },
        { id: '/tax-audit', label: 'Tax Audit (3CD)', icon: ShieldCheck, badge: metrics.pendingTaxAudits },
        { id: '/certificates', label: 'Certifications (UDIN)', icon: FileCheck2, badge: metrics.certificatesCount },
        { id: '/itr', label: 'ITR Clients', icon: FileText, badge: metrics.totalClients },
        { id: '/workboard', label: 'Workboard & Billing', icon: Kanban, badge: metrics.pendingWorksCount },
        { id: '/clients', label: 'Clients Directory', icon: Users },
        { id: '/meetings', label: 'Meetings', icon: Video, badge: metrics.todayMeetings },
        { id: '/calendar', label: 'Compliance Calendar', icon: Calendar },
        { id: '/team', label: 'Team & Staff', icon: UserCheck },
        { id: '/attendance', label: 'Attendance', icon: Clock },
        { id: '/settings', label: 'Firm Settings', icon: Settings },
      ]
    : [
        { id: '/dashboard', label: 'My Workspace', icon: LayoutDashboard },
        { id: '/chat', label: 'Staff Chat & Broadcast', icon: MessageSquare, badge: unreadChatCount },
        { id: '/tasks', label: 'My Assigned Tasks', icon: CheckSquare, badge: metrics.pendingTasks },
        { id: '/itr', label: 'My Assigned Clients', icon: FileText, badge: metrics.totalClients },
        { id: '/calendar', label: 'Compliance Calendar', icon: Calendar },
        { id: '/attendance', label: 'My Attendance', icon: Clock },
        { id: '/meetings', label: 'Meetings', icon: Video, badge: metrics.todayMeetings },
      ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-transform duration-200 lg:static lg:translate-x-0',
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Brand Header */}
        <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border/80">
          <button
            onClick={() => onNavigate('/dashboard')}
            className="flex items-center gap-2.5 text-left group min-w-0"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/90 p-1 shadow-sm shrink-0 border border-border/40">
              <img src="/ca-logo.png" alt="CA Logo" className="h-full w-full object-contain" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 font-bold tracking-tight text-white text-xs sm:text-sm leading-tight truncate">
                Chinar Gulati & Co.
              </div>
              <p className="text-[10px] text-indigo-300 font-medium truncate">
                Virtual CA Desk
              </p>
            </div>
          </button>

          <button
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-white lg:hidden"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Daily Briefing Badge */}
        <div className="px-4 py-2.5 border-b border-sidebar-border/40">
          <div className="rounded-lg bg-sidebar-accent/50 p-2 border border-sidebar-border/60 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[11px] font-semibold text-sidebar-foreground/90">
                10 AM Briefing Active
              </span>
            </div>
            <Sparkles className="h-3.5 w-3.5 text-amber-400" />
          </div>
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-2.5 space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentRoute === item.id || (item.id !== '/dashboard' && currentRoute.startsWith(item.id));

            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={cn(
                  'group flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-medium transition-all',
                  isActive
                    ? 'bg-primary text-white shadow-soft font-semibold'
                    : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-white'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={cn('h-4 w-4 shrink-0', isActive ? 'text-white' : 'text-sidebar-foreground/60 group-hover:text-white')} />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={cn(
                      'rounded-full px-1.5 py-0.2 text-[10px] font-bold',
                      isActive ? 'bg-white/20 text-white' : 'bg-sidebar-accent text-sidebar-foreground/90 border border-sidebar-border'
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* User Info & Footer */}
        <div className="border-t border-sidebar-border/80 p-3">
          <div className="rounded-lg bg-sidebar-accent/40 p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="h-8 w-8 rounded-full bg-primary/20 text-primary border border-primary/30 flex items-center justify-center font-bold text-xs shrink-0">
                {user?.display_name ? user.display_name.slice(0, 2).toUpperCase() : 'CG'}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">
                  {user?.display_name || 'CA Chinar Gulati'}
                </p>
                <p className="text-[10px] text-sidebar-foreground/60 truncate">
                  {role === 'partner' ? 'Managing Partner (FCA)' : role === 'admin' ? 'Senior CA / Audit Lead' : role === 'article' ? 'Articled Assistant' : 'Staff Associate'}
                </p>
              </div>
            </div>

            <button
              onClick={logout}
              title="Sign Out"
              className="rounded-lg p-1.5 text-sidebar-foreground/60 hover:bg-destructive/20 hover:text-destructive transition-colors"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
