import React from 'react';
import { 
  Sparkles, ArrowRight, CheckCircle2, Mail, Calendar, 
  Video, Users, Bell, ShieldCheck, FileSpreadsheet, Lock 
} from 'lucide-react';
import { Button } from '../components/ui/Button';

interface LandingPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onSignIn }) => {
  const pillars = [
    {
      title: 'Daily 10 AM Briefing',
      description: 'A clean, consulting-style email & audio overview every morning with your schedule, priorities and join links.',
      icon: Mail,
      color: 'bg-primary/10 text-primary border-primary/20',
    },
    {
      title: 'Smart Daily Dashboard',
      description: 'Timeline view, priority highlights, overdue alerts, and quick-add — all in one calm, executive screen.',
      icon: Calendar,
      color: 'bg-info/10 text-info border-info/20',
    },
    {
      title: 'Meeting Manager',
      description: 'One-click join links (Meet, Zoom, Teams), automatic schedule conflict detection, and client reminders.',
      icon: Video,
      color: 'bg-success/10 text-success border-success/20',
    },
    {
      title: 'ITR & Compliance Tracking',
      description: 'GST, TDS, statutory audits, AY 2026-27 ITR 1-7 filings — recurring deadlines that never fall through the cracks.',
      icon: ShieldCheck,
      color: 'bg-warning/10 text-warning border-warning/20',
    },
    {
      title: 'Client 360 Workspace',
      description: 'See everything for one client in one place: document checklist, whiteboard notes, phone/WhatsApp, and activity history.',
      icon: Users,
      color: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
    },
    {
      title: 'Practice Workboard & Billing',
      description: 'Track client receivables, pending bills, and works to be done with instant Excel (XLSX) import & export.',
      icon: FileSpreadsheet,
      color: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary/20">
      {/* Navigation Bar */}
      <header className="sticky top-0 z-40 border-b border-border/80 bg-card/80 px-6 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-primary text-white shadow-soft font-bold">
              P
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-foreground">
                Praxis <span className="text-xs uppercase font-extrabold px-1.5 py-0.5 rounded bg-primary/20 text-primary border border-primary/30">PRO</span>
              </span>
              <span className="hidden sm:inline-block ml-2 text-xs text-muted-foreground">
                CA Practice Workbench
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onSignIn}>
              Sign In
            </Button>
            <Button size="sm" onClick={onGetStarted} className="bg-gradient-primary shadow-soft">
              Get Started Free
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1">
        <section className="relative overflow-hidden px-6 pt-16 pb-20 lg:pt-24 lg:pb-28">
          {/* Subtle background glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-primary/10 rounded-full blur-3xl -z-10 pointer-events-none" />

          <div className="mx-auto max-w-4xl text-center">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-primary mb-6 animate-subtle-pulse">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Built exclusively for Chartered Accountants in practice</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl font-extrabold tracking-tight sm:text-6xl text-foreground leading-[1.15]">
              The briefing-grade workbench <br />
              <span className="bg-gradient-to-r from-primary to-indigo-600 bg-clip-text text-transparent">
                for your CA practice.
              </span>
            </h1>

            {/* Subheading */}
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Daily tasks, client meetings, ITR compliance deadlines, and a calm 10 AM email briefing — all in one professional dashboard. Stop checking five apps.
            </p>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <Button size="lg" onClick={onGetStarted} className="gap-2 shadow-elevated text-base">
                Get Started Free
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={onSignIn}>
                Sign In to Workbench
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-success" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-success" />
                <span>Setup in 2 minutes</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-success" />
                <span>100% Private to your firm</span>
              </div>
            </div>
          </div>
        </section>

        {/* 6 Core Pillars Section */}
        <section className="border-t border-border/80 bg-secondary/30 px-6 py-20 lg:py-24">
          <div className="mx-auto max-w-6xl">
            <div className="text-center max-w-2xl mx-auto mb-14">
              <h2 className="text-2xl font-bold tracking-tight sm:text-3xl text-foreground">
                Six tools, one calm workspace
              </h2>
              <p className="mt-3 text-sm text-muted-foreground">
                Engineered from the ground up for Indian Chartered Accountants managing client audits, ITR filing deadlines, and partner workflows.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {pillars.map((pillar, idx) => {
                const Icon = pillar.icon;
                return (
                  <div
                    key={idx}
                    className="rounded-xl border border-border bg-card p-6 shadow-soft transition hover:shadow-elevated hover:border-primary/40 group"
                  >
                    <div className={`flex h-11 w-11 items-center justify-center rounded-lg border ${pillar.color} mb-4 transition-transform group-hover:scale-105`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <h3 className="text-base font-bold text-foreground">{pillar.title}</h3>
                    <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                      {pillar.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA Banner */}
        <section className="px-6 py-20">
          <div className="mx-auto max-w-4xl rounded-2xl border border-primary/30 bg-gradient-to-b from-primary/10 to-card p-8 sm:p-12 text-center shadow-elevated">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl text-foreground">
              Start your morning with clarity.
            </h2>
            <p className="mt-3 text-sm text-muted-foreground max-w-xl mx-auto">
              Sign up free. Add your first client and meeting in two minutes. Experience your first daily briefing tomorrow at 10 AM.
            </p>
            <div className="mt-6">
              <Button size="lg" onClick={onGetStarted} className="gap-2 shadow-elevated">
                Get Started Free
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/80 bg-card py-6 px-6 text-center text-xs text-muted-foreground">
        <p>© {new Date().getFullYear()} Praxis Pro CA Workbench. Built for Chartered Accountants.</p>
      </footer>
    </div>
  );
};
