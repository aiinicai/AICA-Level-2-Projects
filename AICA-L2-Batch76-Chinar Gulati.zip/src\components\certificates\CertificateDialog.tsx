import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { CertificateRecord, CertificateType, CertificateStatus } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { Sparkles, FileCheck2 } from 'lucide-react';

interface CertificateDialogProps {
  isOpen: boolean;
  onClose: () => void;
  certificate?: CertificateRecord | null;
}

export const CertificateDialog: React.FC<CertificateDialogProps> = ({
  isOpen,
  onClose,
  certificate,
}) => {
  const { user } = useAuth();
  const { clients, addCertificate, updateCertificate } = useData();

  const [clientId, setClientId] = useState('');
  const [certificateType, setCertificateType] = useState<CertificateType>('net_worth');
  const [title, setTitle] = useState('');
  const [purpose, setPurpose] = useState('');
  const [issuingAuthority, setIssuingAuthority] = useState('');
  const [amountCertified, setAmountCertified] = useState('');
  const [udin, setUdin] = useState('');
  const [issuedDate, setIssuedDate] = useState('');
  const [status, setStatus] = useState<CertificateStatus>('issued');
  const [signatory, setSignatory] = useState(user?.display_name || 'CA Chinar Gulati, FCA');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (certificate) {
        setClientId(certificate.client_id);
        setCertificateType(certificate.certificate_type);
        setTitle(certificate.title);
        setPurpose(certificate.purpose);
        setIssuingAuthority(certificate.issuing_authority || '');
        setAmountCertified(certificate.amount_certified ? String(certificate.amount_certified) : '');
        setUdin(certificate.udin || '');
        setIssuedDate(certificate.issued_date || '');
        setStatus(certificate.status);
        setSignatory(certificate.signatory);
        setNotes(certificate.notes || '');
      } else {
        setClientId(clients[0]?.id || '');
        setCertificateType('net_worth');
        setTitle('Net Worth Certificate for Bank Loan Appraisal');
        setPurpose('Bank Credit Appraisal & Financial Proof');
        setIssuingAuthority('Scheduled Commercial Bank / Embassy');
        setAmountCertified('25000000');
        setUdin('');
        setIssuedDate(new Date().toISOString().slice(0, 10));
        setStatus('issued');
        setSignatory(user?.display_name || 'CA Chinar Gulati, FCA');
        setNotes('');
      }
      setError('');
    }
  }, [isOpen, certificate, clients, user]);

  const generateMockUDIN = () => {
    const randomDigits = Math.floor(100000 + Math.random() * 900000);
    const prefix = certificateType === 'net_worth' ? 'NW' : certificateType === 'utilization' ? 'UC' : 'TO';
    const generated = `26098234${prefix}${randomDigits}`;
    setUdin(generated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Certificate title is required');
      return;
    }
    if (!clientId) {
      setError('Please select a client');
      return;
    }

    const selectedClient = clients.find((c) => c.id === clientId);
    if (!selectedClient) {
      setError('Client not found');
      return;
    }

    setIsSubmitting(true);
    try {
      const certData = {
        client_id: clientId,
        client_name: selectedClient.name,
        pan: selectedClient.pan,
        certificate_type: certificateType,
        title: title.trim(),
        purpose: purpose.trim(),
        issuing_authority: issuingAuthority.trim() || undefined,
        amount_certified: amountCertified ? parseFloat(amountCertified) : undefined,
        udin: udin.trim() || undefined,
        signatory: signatory.trim(),
        issued_date: issuedDate || undefined,
        status,
        notes: notes.trim() || undefined,
      };

      if (certificate) {
        updateCertificate(certificate.id, certData);
      } else {
        addCertificate(certData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={certificate ? 'Edit CA Certificate' : 'Issue New CA Certificate'}
      description="Issue Net Worth Certificates, Utilization Certificates (UC), Turnover Certificates with mandatory UDIN."
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Certificate Category *"
            value={certificateType}
            onChange={(e) => {
              const val = e.target.value as CertificateType;
              setCertificateType(val);
              if (val === 'net_worth') {
                setTitle('Net Worth Certificate for Financial Solvency');
                setPurpose('Bank Credit / VISA Financial Capability Proof');
              } else if (val === 'utilization') {
                setTitle('Statutory Utilization Certificate (UC) for Project Grants');
                setPurpose('Grant Utilization as per GFR / CSR Guidelines');
              } else if (val === 'turnover') {
                setTitle('Turnover & Financial Ratio Certificate');
                setPurpose('GeM Tender Qualification / Bank Credit Limit');
              }
            }}
          >
            <option value="net_worth">💼 Net Worth Certificate</option>
            <option value="utilization">📋 Utilization Certificate (UC)</option>
            <option value="turnover">📊 Turnover / Ratio Certificate</option>
            <option value="solvency">🏛️ Financial Solvency Certificate</option>
            <option value="working_capital">💰 Working Capital Assessment</option>
            <option value="visa">✈️ VISA / Immigration Financial Proof</option>
          </Select>

          <Select
            label="Client *"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
          >
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.pan})
              </option>
            ))}
          </Select>
        </div>

        <Input
          label="Certificate Title *"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. Net Worth Certificate for Canadian PR Application"
          autoFocus
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Purpose of Certificate *"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            placeholder="e.g. Bank Credit Appraisal / Embassy Proof"
          />

          <Input
            label="Target Authority / Beneficiary"
            value={issuingAuthority}
            onChange={(e) => setIssuingAuthority(e.target.value)}
            placeholder="e.g. HDFC Bank Credit / GeM Portal"
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Certified Amount (₹ INR)"
            type="number"
            value={amountCertified}
            onChange={(e) => setAmountCertified(e.target.value)}
            placeholder="e.g. 35000000"
          />

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-foreground/80">
                ICAI UDIN Number
              </label>
              <button
                type="button"
                onClick={generateMockUDIN}
                className="text-[11px] font-semibold text-primary hover:underline flex items-center gap-1"
              >
                <Sparkles className="h-3 w-3 text-amber-500" />
                Generate UDIN
              </button>
            </div>
            <Input
              value={udin}
              onChange={(e) => setUdin(e.target.value.toUpperCase())}
              placeholder="e.g. 26098234NWCRT9871"
              className="font-mono text-xs uppercase"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label="Status"
            value={status}
            onChange={(e) => setStatus(e.target.value as CertificateStatus)}
          >
            <option value="draft">Draft</option>
            <option value="under_review">Under Partner Review</option>
            <option value="udin_generated">UDIN Generated</option>
            <option value="issued">Issued & Certified</option>
          </Select>

          <Input
            label="Issue Date"
            type="date"
            value={issuedDate}
            onChange={(e) => setIssuedDate(e.target.value)}
          />

          <Input
            label="Signing Partner"
            value={signatory}
            onChange={(e) => setSignatory(e.target.value)}
          />
        </div>

        <Textarea
          label="Verification Scope & Annexure Notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Basis of valuation, list of bank accounts verified, fixed assets schedule…"
          rows={2}
        />

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {certificate ? 'Save Changes' : 'Issue Certificate'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
