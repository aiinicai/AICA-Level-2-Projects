import { 
  Client, Task, Meeting, WorkItem, ITRDocument, ClientNote, 
  ClientActivity, Profile, TeamMember, AttendanceRecord, TaxAuditRecord, CertificateRecord,
  ChatMessage 
} from '../types';
import { 
  INITIAL_PROFILE, INITIAL_TEAM, INITIAL_CLIENTS, INITIAL_TASKS, 
  INITIAL_MEETINGS, INITIAL_WORK_ITEMS, INITIAL_ITR_DOCS, INITIAL_NOTES, 
  INITIAL_ACTIVITIES, INITIAL_ATTENDANCE, INITIAL_TAX_AUDITS, INITIAL_CERTIFICATES,
  INITIAL_CHAT_MESSAGES 
} from './mockData';

const STORAGE_KEYS = {
  PROFILE: 'praxis_profile_v2',
  TEAM: 'praxis_team_v2',
  CLIENTS: 'praxis_clients_v2',
  TAX_AUDITS: 'praxis_tax_audits_v2',
  CERTIFICATES: 'praxis_certificates_v2',
  TASKS: 'praxis_tasks_v2',
  MEETINGS: 'praxis_meetings_v2',
  WORK_ITEMS: 'praxis_work_items_v2',
  ITR_DOCS: 'praxis_itr_docs_v2',
  NOTES: 'praxis_notes_v2',
  ACTIVITIES: 'praxis_activities_v2',
  ATTENDANCE: 'praxis_attendance_v2',
  CHAT_MESSAGES: 'praxis_chat_messages_v2',
  SUPABASE_CONFIG: 'praxis_supabase_config_v2',
};

class StorageService {
  private get<T>(key: string, fallback: T): T {
    try {
      const item = localStorage.getItem(key);
      if (!item) {
        this.set(key, fallback);
        return fallback;
      }
      return JSON.parse(item) as T;
    } catch {
      return fallback;
    }
  }

  private set<T>(key: string, data: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }

  // Profile
  getProfile(): Profile {
    return this.get<Profile>(STORAGE_KEYS.PROFILE, INITIAL_PROFILE);
  }
  saveProfile(profile: Profile): void {
    this.set(STORAGE_KEYS.PROFILE, profile);
  }

  // Team
  getTeam(): TeamMember[] {
    return this.get<TeamMember[]>(STORAGE_KEYS.TEAM, INITIAL_TEAM);
  }
  saveTeam(team: TeamMember[]): void {
    this.set(STORAGE_KEYS.TEAM, team);
  }

  // Clients
  getClients(): Client[] {
    return this.get<Client[]>(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS);
  }
  saveClients(clients: Client[]): void {
    this.set(STORAGE_KEYS.CLIENTS, clients);
  }

  // Tax Audits
  getTaxAudits(): TaxAuditRecord[] {
    return this.get<TaxAuditRecord[]>(STORAGE_KEYS.TAX_AUDITS, INITIAL_TAX_AUDITS);
  }
  saveTaxAudits(audits: TaxAuditRecord[]): void {
    this.set(STORAGE_KEYS.TAX_AUDITS, audits);
  }

  // Certifications
  getCertificates(): CertificateRecord[] {
    return this.get<CertificateRecord[]>(STORAGE_KEYS.CERTIFICATES, INITIAL_CERTIFICATES);
  }
  saveCertificates(certs: CertificateRecord[]): void {
    this.set(STORAGE_KEYS.CERTIFICATES, certs);
  }

  // Tasks
  getTasks(): Task[] {
    return this.get<Task[]>(STORAGE_KEYS.TASKS, INITIAL_TASKS);
  }
  saveTasks(tasks: Task[]): void {
    this.set(STORAGE_KEYS.TASKS, tasks);
  }

  // Meetings
  getMeetings(): Meeting[] {
    return this.get<Meeting[]>(STORAGE_KEYS.MEETINGS, INITIAL_MEETINGS);
  }
  saveMeetings(meetings: Meeting[]): void {
    this.set(STORAGE_KEYS.MEETINGS, meetings);
  }

  // Work Items (Bills & Works)
  getWorkItems(): WorkItem[] {
    return this.get<WorkItem[]>(STORAGE_KEYS.WORK_ITEMS, INITIAL_WORK_ITEMS);
  }
  saveWorkItems(items: WorkItem[]): void {
    this.set(STORAGE_KEYS.WORK_ITEMS, items);
  }

  // ITR Documents
  getITRDocs(): Record<string, ITRDocument[]> {
    return this.get<Record<string, ITRDocument[]>>(STORAGE_KEYS.ITR_DOCS, INITIAL_ITR_DOCS);
  }
  saveITRDocs(docs: Record<string, ITRDocument[]>): void {
    this.set(STORAGE_KEYS.ITR_DOCS, docs);
  }

  // Notes
  getNotes(): Record<string, ClientNote[]> {
    return this.get<Record<string, ClientNote[]>>(STORAGE_KEYS.NOTES, INITIAL_NOTES);
  }
  saveNotes(notes: Record<string, ClientNote[]>): void {
    this.set(STORAGE_KEYS.NOTES, notes);
  }

  // Activities
  getActivities(): Record<string, ClientActivity[]> {
    return this.get<Record<string, ClientActivity[]>>(STORAGE_KEYS.ACTIVITIES, INITIAL_ACTIVITIES);
  }
  saveActivities(activities: Record<string, ClientActivity[]>): void {
    this.set(STORAGE_KEYS.ACTIVITIES, activities);
  }

  // Attendance
  getAttendance(): AttendanceRecord[] {
    return this.get<AttendanceRecord[]>(STORAGE_KEYS.ATTENDANCE, INITIAL_ATTENDANCE);
  }
  saveAttendance(attendance: AttendanceRecord[]): void {
    this.set(STORAGE_KEYS.ATTENDANCE, attendance);
  }

  // Chat & Staff Messages
  getChatMessages(): ChatMessage[] {
    return this.get<ChatMessage[]>(STORAGE_KEYS.CHAT_MESSAGES, INITIAL_CHAT_MESSAGES);
  }
  saveChatMessages(messages: ChatMessage[]): void {
    this.set(STORAGE_KEYS.CHAT_MESSAGES, messages);
  }

  // Supabase Custom Config
  getSupabaseConfig(): { url: string; anonKey: string; isConnected: boolean } {
    return this.get(STORAGE_KEYS.SUPABASE_CONFIG, {
      url: 'https://khxabzptazfvxczmhwzu.supabase.co',
      anonKey: '',
      isConnected: false,
    });
  }
  saveSupabaseConfig(config: { url: string; anonKey: string; isConnected: boolean }): void {
    this.set(STORAGE_KEYS.SUPABASE_CONFIG, config);
  }

  // Reset to Factory Demo
  resetToDemo(): void {
    localStorage.clear();
  }

  // Export full practice database backup as JSON
  exportBackup(): string {
    const backup = {
      profile: this.getProfile(),
      team: this.getTeam(),
      clients: this.getClients(),
      taxAudits: this.getTaxAudits(),
      certificates: this.getCertificates(),
      tasks: this.getTasks(),
      meetings: this.getMeetings(),
      workItems: this.getWorkItems(),
      itrDocs: this.getITRDocs(),
      notes: this.getNotes(),
      activities: this.getActivities(),
      attendance: this.getAttendance(),
      exportedAt: new Date().toISOString(),
      version: '2.0.0-pro',
    };
    return JSON.stringify(backup, null, 2);
  }

  // Restore backup from JSON
  restoreBackup(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.profile) this.saveProfile(parsed.profile);
      if (parsed.team) this.saveTeam(parsed.team);
      if (parsed.clients) this.saveClients(parsed.clients);
      if (parsed.taxAudits) this.saveTaxAudits(parsed.taxAudits);
      if (parsed.certificates) this.saveCertificates(parsed.certificates);
      if (parsed.tasks) this.saveTasks(parsed.tasks);
      if (parsed.meetings) this.saveMeetings(parsed.meetings);
      if (parsed.workItems) this.saveWorkItems(parsed.workItems);
      if (parsed.itrDocs) this.saveITRDocs(parsed.itrDocs);
      if (parsed.notes) this.saveNotes(parsed.notes);
      if (parsed.activities) this.saveActivities(parsed.activities);
      if (parsed.attendance) this.saveAttendance(parsed.attendance);
      return true;
    } catch {
      return false;
    }
  }
}

export const storage = new StorageService();
