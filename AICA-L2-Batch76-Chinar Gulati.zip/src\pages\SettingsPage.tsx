import React, { useState } from 'react';
import { 
  Building2, Mail, Clock, Database, Download, 
  Upload, RotateCcw, LogOut, CheckCircle2, AlertCircle, Sparkles 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { storage } from '../lib/storage';

export const SettingsPage: React.FC = () => {
  const { user, updateProfile, logout } = useAuth();
  const { resetData } = useData();

  // Profile fields
  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [firmName, setFirmName] = useState(user?.firm_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [briefingTime, setBriefingTime] = useState(user?.briefing_time || '10:00');
  const [timezone, setTimezone] = useState(user?.timezone || 'Asia/Kolkata');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Supabase Custom Config fields
  const storedSupabase = storage.getSupabaseConfig();
  const [supabaseUrl, setSupabaseUrl] = useState(storedSupabase.url);
  const [supabaseKey, setSupabaseKey] = useState(storedSupabase.anonKey);
  const [supabaseStatus, setSupabaseStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  // Backup restore
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      display_name: displayName,
      firm_name: firmName,
      phone,
      briefing_time: briefingTime,
      timezone,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleSaveSupabase = () => {
    setSupabaseStatus('testing');
    try {
      storage.saveSupabaseConfig({
        url: supabaseUrl.trim(),
        anonKey: supabaseKey.trim(),
        isConnected: !!supabaseKey.trim(),
      });
      setTimeout(() => {
        setSupabaseStatus('success');
        setTimeout(() => setSupabaseStatus('idle'), 2500);
      }, 500);
    } catch {
      setSupabaseStatus('error');
    }
  };

  const handleDownloadBackup = () => {
    const backupJson = storage.exportBackup();
    const blob = new Blob([backupJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Praxis_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const ok = storage.restoreBackup(text);
        if (ok) {
          setRestoreMessage('Backup restored successfully! Refreshing data…');
          setTimeout(() => window.location.reload(), 1000);
        } else {
          setRestoreMessage('Failed to restore. Invalid backup file structure.');
        }
      } catch {
        setRestoreMessage('Failed to parse JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
          Firm & Practice Settings
        </h2>
        <p className="text-xs text-muted-foreground">
          Configure CA letterhead details, daily 10 AM briefing schedule, Supabase backend sync, and backups.
        </p>
      </div>

      {/* 1. CA Firm Profile Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <Building2 className="h-4 w-4 text-primary" />
            Chartered Accountant & Firm Profile
          </CardTitle>
          <CardDescription>
            Your practice letterhead information and contact credentials.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                label="Partner Display Name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. CA Rajesh Sharma, FCA"
              />
              <Input
                label="CA Firm Name"
                value={firmName}
                onChange={(e) => setFirmName(e.target.value)}
                placeholder="e.g. Sharma & Associates Chartered Accountants"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                label="Email Address"
                value={email}
                disabled
                className="bg-muted text-muted-foreground cursor-not-allowed"
              />
              <Input
                label="Practice Phone / WhatsApp"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98201 54321"
              />
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-border/60">
              {savedSuccess ? (
                <span className="text-xs text-success font-semibold flex items-center gap-1">
                  <CheckCircle2 className="h-4 w-4" /> Profile updated successfully!
                </span>
              ) : <div />}

              <Button type="submit" size="sm">
                Save Profile Changes
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* 2. Daily Briefing Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <Clock className="h-4 w-4 text-amber-500" />
            Daily Executive Briefing Dispatch
          </CardTitle>
          <CardDescription>
            Set the delivery time for your daily morning overview of schedule and deadlines.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              label="Briefing Delivery Time"
              type="time"
              value={briefingTime}
              onChange={(e) => setBriefingTime(e.target.value)}
            />

            <Select
              label="Practice Timezone"
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
            >
              <option value="Asia/Kolkata">Asia/Kolkata (IST +5:30) — Default</option>
              <option value="Asia/Dubai">Asia/Dubai (GST +4:00)</option>
              <option value="Asia/Singapore">Asia/Singapore (SGT +8:00)</option>
              <option value="Europe/London">Europe/London (GMT)</option>
              <option value="America/New_York">America/New York (EST)</option>
            </Select>
          </div>

          <div className="flex items-center gap-2 rounded-lg bg-primary/5 p-3 border border-primary/20 text-xs text-muted-foreground">
            <Sparkles className="h-4 w-4 text-primary shrink-0" />
            <span>
              Your daily briefing is compiled at <strong>{briefingTime} AM ({timezone})</strong> with meetings, overdue compliance alerts, and today&apos;s priority deliverables.
            </span>
          </div>
        </CardContent>
      </Card>

      {/* 3. Supabase Custom Sync (Pro Feature) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <Database className="h-4 w-4 text-emerald-600" />
            Supabase Cloud Database Integration (Pro)
          </CardTitle>
          <CardDescription>
            Optionally connect your dedicated Supabase database to sync live data across all partner devices.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <Input
            label="Supabase Project URL"
            value={supabaseUrl}
            onChange={(e) => setSupabaseUrl(e.target.value)}
            placeholder="https://xyzcompany.supabase.co"
          />

          <Input
            label="Supabase Anon / Public API Key"
            type="password"
            value={supabaseKey}
            onChange={(e) => setSupabaseKey(e.target.value)}
            placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
          />

          <div className="flex items-center justify-between pt-2 border-t border-border/60">
            {supabaseStatus === 'success' && (
              <span className="text-xs text-success font-semibold flex items-center gap-1">
                <CheckCircle2 className="h-4 w-4" /> Connected & configured!
              </span>
            )}
            {supabaseStatus === 'error' && (
              <span className="text-xs text-destructive font-semibold flex items-center gap-1">
                <AlertCircle className="h-4 w-4" /> Connection error. Check credentials.
              </span>
            )}
            {supabaseStatus === 'idle' && <div />}

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleSaveSupabase}
              loading={supabaseStatus === 'testing'}
            >
              Save & Test Connection
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 4. Backup, Export & Reset */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <Download className="h-4 w-4 text-blue-500" />
            Data Backup, Export & Reset
          </CardTitle>
          <CardDescription>
            Export complete practice JSON snapshots or reset to default demo dataset.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadBackup}
              className="gap-1.5"
            >
              <Download className="h-4 w-4" />
              Download Full Practice JSON Backup
            </Button>

            <label className="inline-flex items-center justify-center rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-muted cursor-pointer transition-colors">
              <Upload className="h-4 w-4 mr-1.5" />
              Restore from JSON Backup
              <input
                type="file"
                accept=".json"
                onChange={handleRestoreBackup}
                className="hidden"
              />
            </label>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                if (confirm('Reset entire practice data to factory demo roster? This cannot be undone.')) {
                  resetData();
                  window.location.reload();
                }
              }}
              className="text-xs text-destructive hover:bg-destructive/10 gap-1.5 ml-auto"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to Demo Data
            </Button>
          </div>

          {restoreMessage && (
            <p className="text-xs text-primary font-semibold">{restoreMessage}</p>
          )}
        </CardContent>
      </Card>

      {/* 5. Sign Out Button */}
      <div className="pt-4 flex justify-end">
        <Button
          variant="destructive"
          onClick={logout}
          className="gap-1.5 text-xs"
        >
          <LogOut className="h-4 w-4" />
          Sign Out of Workbench
        </Button>
      </div>
    </div>
  );
};
