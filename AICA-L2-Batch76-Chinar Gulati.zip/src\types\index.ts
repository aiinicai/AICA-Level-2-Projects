export type Priority = 'high' | 'medium' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'done';
export type TaskCategory = 'compliance' | 'meeting' | 'call' | 'personal';
export type Recurrence = 'none' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';

export type ITRFilingStatus = 'not_started' | 'documents_pending' | 'in_review' | 'filed' | 'completed';
export type DocStatus = 'pending_client' | 'received' | 'needs_review' | 'not_applicable';
export type WorkItemType = 'bill' | 'work';
export type WorkItemStatus = 'pending' | 'done';
export type UserRole = 'admin' | 'employee' | 'partner' | 'article';

export type TaxAuditType = '3CA-3CD' | '3CB-3CD' | '44AB' | '44AD' | '44ADA';
export type TaxAuditStatus = 'not_started' | 'drafting' | 'partner_review' | 'udin_generated' | 'filed' | 'completed';

export type CertificateType = 'net_worth' | 'utilization' | 'turnover' | 'solvency' | 'working_capital' | 'visa';
export type CertificateStatus = 'draft' | 'under_review' | 'udin_generated' | 'issued';

export interface Client {
  id: string;
  name: string;
  pan: string;
  mobile: string;
  contact_phone?: string;
  contact_email?: string;
  assessment_year?: string;
  itr_type?: string;
  filing_status: ITRFilingStatus;
  assigned_to?: string | null;
  category?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface TaxAuditRecord {
  id: string;
  client_id: string;
  client_name: string;
  pan: string;
  assessment_year: string;
  financial_year: string;
  audit_type: TaxAuditType;
  turnover_amount?: number;
  status: TaxAuditStatus;
  udin?: string;
  assigned_to?: string;
  due_date?: string;
  msme_compliance?: boolean;
  depreciation_verified?: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CertificateRecord {
  id: string;
  client_id: string;
  client_name: string;
  pan: string;
  certificate_type: CertificateType;
  title: string;
  purpose: string;
  issuing_authority?: string;
  amount_certified?: number;
  udin?: string;
  signatory: string;
  issued_date?: string;
  status: CertificateStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface TaskComment {
  id: string;
  task_id: string;
  author_id: string;
  author_name: string;
  author_role: UserRole;
  author_avatar?: string;
  content: string;
  type: 'note' | 'query' | 'resolution' | 'system';
  is_query?: boolean;
  is_resolved?: boolean;
  created_at: string;
}

export interface TaskReassignment {
  id: string;
  task_id: string;
  from_user_id?: string;
  from_user_name?: string;
  to_user_id: string;
  to_user_name: string;
  reassigned_by_id: string;
  reassigned_by_name: string;
  reason?: string;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  sender_id: string;
  sender_name: string;
  sender_role: UserRole;
  sender_avatar?: string;
  recipient_id: string; // 'all' for whole staff broadcast, or specific user_id for 1-on-1 direct message
  recipient_name?: string;
  content: string;
  attachment_name?: string;
  attachment_type?: string;
  created_at: string;
  read_by?: string[];
  is_announcement?: boolean;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description?: string | null;
  client_id?: string | null;
  assigned_to?: string;
  assigned_to_name?: string;
  assigned_by?: string;
  assigned_by_name?: string;
  due_at?: string | null;
  priority: Priority;
  category: TaskCategory;
  status: TaskStatus;
  recurrence?: Recurrence | null;
  completed_at?: string | null;
  created_at: string;
  client?: Client | null;
  task_notes?: TaskComment[];
  reassignment_history?: TaskReassignment[];
  queries_count?: number;
  has_pending_query?: boolean;
}

export interface Meeting {
  id: string;
  user_id: string;
  title: string;
  description?: string | null;
  client_id?: string | null;
  start_at: string;
  end_at: string;
  join_url?: string | null;
  location?: string | null;
  reminder_minutes: number;
  created_at: string;
  client?: Client | null;
}

export interface WorkItem {
  id: string;
  client_id: string;
  type: WorkItemType;
  title: string;
  amount?: number | null;
  due_date?: string | null;
  notes?: string | null;
  status: WorkItemStatus;
  created_at: string;
  client?: Client | null;
}

export interface ITRDocument {
  id: string;
  client_id: string;
  firm_owner_id?: string;
  name: string;
  status: DocStatus;
  is_custom?: boolean;
  sort_order: number;
  file_url?: string;
  updated_by?: string;
  updated_at?: string;
}

export interface ClientNote {
  id: string;
  client_id: string;
  firm_owner_id?: string;
  author_id?: string;
  content: string;
  is_pinned: boolean;
  created_at: string;
  updated_at: string;
}

export interface ClientActivity {
  id: string;
  client_id: string;
  firm_owner_id?: string;
  actor_id?: string;
  action: 'status_changed' | 'doc_status_changed' | 'doc_added' | 'assigned' | 'note_added' | 'client_created';
  details?: Record<string, any>;
  created_at: string;
}

export interface Profile {
  id: string;
  email: string;
  display_name: string;
  firm_name?: string;
  firm_owner_id?: string;
  role: UserRole;
  briefing_time: string;
  timezone: string;
  avatar_url?: string;
  phone?: string;
  created_at: string;
}

export interface TeamMember {
  id: string;
  email: string;
  display_name: string;
  role: UserRole;
  firm_owner_id: string;
  status: 'active' | 'pending';
  tasks_count?: number;
  clients_count?: number;
  avatar_color?: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  user_id: string;
  user_name: string;
  date: string;
  check_in?: string;
  check_out?: string;
  total_hours?: number;
  status: 'present' | 'half_day' | 'on_leave' | 'remote';
  notes?: string;
  location?: string;
  latitude?: number;
  longitude?: number;
  accuracy?: number;
  maps_url?: string;
  location_type?: 'office' | 'client_site' | 'remote' | 'field';
}

export interface Invitation {
  id: string;
  firm_owner_id: string;
  email: string;
  display_name?: string;
  status: 'pending' | 'accepted';
  created_at: string;
  accepted_user_id?: string;
}

export type ComplianceCategory = 'gst' | 'tds' | 'income_tax' | 'tax_audit' | 'roc' | 'pf_esi';

export interface ComplianceItem {
  id: string;
  title: string;
  category: ComplianceCategory;
  form_name: string;
  due_day_or_date: string;
  due_date: string; // ISO format date (e.g. "2026-08-11")
  period: string;
  authority: string;
  applicable_to: string;
  penalty_interest_info?: string;
  is_recurring: boolean;
  recurrence_type?: 'monthly' | 'quarterly' | 'yearly';
  reminded?: boolean;
}

