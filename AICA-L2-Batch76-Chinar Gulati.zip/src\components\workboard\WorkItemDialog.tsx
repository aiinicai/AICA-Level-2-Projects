import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { WorkItem, WorkItemType, WorkItemStatus } from '../../types';
import { useData } from '../../context/DataContext';

interface WorkItemDialogProps {
  isOpen: boolean;
  onClose: () => void;
  item?: WorkItem | null;
  defaultType?: WorkItemType;
  defaultClientId?: string;
}

export const WorkItemDialog: React.FC<WorkItemDialogProps> = ({
  isOpen,
  onClose,
  item,
  defaultType = 'bill',
  defaultClientId,
}) => {
  const { clients, addWorkItem, updateWorkItem } = useData();

  const [type, setType] = useState<WorkItemType>(defaultType);
  const [clientId, setClientId] = useState<string>('');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<WorkItemStatus>('pending');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (item) {
        setType(item.type);
        setClientId(item.client_id);
        setTitle(item.title);
        setAmount(item.amount ? String(item.amount) : '');
        setDueDate(item.due_date || '');
        setNotes(item.notes || '');
        setStatus(item.status);
      } else {
        setType(defaultType);
        setClientId(defaultClientId || (clients[0]?.id ?? ''));
        setTitle('');
        setAmount('');
        setDueDate(new Date().toISOString().slice(0, 10));
        setNotes('');
        setStatus('pending');
      }
      setError('');
    }
  }, [isOpen, item, defaultType, defaultClientId, clients]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title / Description is required');
      return;
    }
    if (!clientId) {
      setError('Please select a client');
      return;
    }

    setIsSubmitting(true);
    try {
      const itemData = {
        client_id: clientId,
        type,
        title: title.trim(),
        amount: type === 'bill' && amount ? parseFloat(amount) : null,
        due_date: dueDate || null,
        notes: notes.trim() || null,
        status,
      };

      if (item) {
        updateWorkItem(item.id, itemData);
      } else {
        addWorkItem(itemData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={item ? `Edit ${type === 'bill' ? 'Bill' : 'Work'}` : `Add ${type === 'bill' ? 'Pending Bill' : 'Work To Be Done'}`}
      description="Track practice receivables or pending compliance workflows per client."
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium">
            {error}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 rounded-lg bg-secondary p-1 border border-border">
          <button
            type="button"
            onClick={() => setType('bill')}
            className={`py-1.5 text-xs font-bold rounded-md transition-all ${
              type === 'bill'
                ? 'bg-primary text-white shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            💰 Pending Bill / Fee
          </button>
          <button
            type="button"
            onClick={() => setType('work')}
            className={`py-1.5 text-xs font-bold rounded-md transition-all ${
              type === 'work'
                ? 'bg-primary text-white shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            📝 Work To Be Done
          </button>
        </div>

        <Select
          label="Client *"
          value={clientId}
          onChange={(e) => setClientId(e.target.value)}
        >
          {clients.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({c.pan})
            </option>
          ))}
        </Select>

        <Input
          label={type === 'bill' ? 'Invoice / Fee Description *' : 'Work Description *'}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder={type === 'bill' ? 'e.g. Statutory Audit Fee Invoice #2026/104' : 'e.g. File GSTR-9 Annual Return'}
          autoFocus
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {type === 'bill' ? (
            <Input
              label="Amount (₹ INR)"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 50000"
            />
          ) : (
            <Select
              label="Status"
              value={status}
              onChange={(e) => setStatus(e.target.value as WorkItemStatus)}
            >
              <option value="pending">Pending</option>
              <option value="done">Done / Completed</option>
            </Select>
          )}

          <Input
            label={type === 'bill' ? 'Payment Due Date' : 'Target Completion Date'}
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </div>

        <Textarea
          label="Internal Notes (Optional)"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Payment reminders, follow-up person, or status notes…"
          rows={2}
        />

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {item ? 'Save Changes' : 'Add Entry'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
