import React, { useState } from 'react';
import { 
  Menu, Search, Plus, Bell, Sparkles, Moon, Sun, 
  CheckCircle2, Clock, Video, FileText, UserPlus, ShieldCheck, 
  FileCheck2, MessageSquare, ChevronDown, UserCheck, Shield, Lock 
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';

interface NavbarProps {
  onOpenMobileNav: () => void;
  onOpenQuickAdd: (type: 'task' | 'meeting' | 'client' | 'work' | 'audit' | 'cert') => void;
  pageTitle: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenMobileNav,
  onOpenQuickAdd,
  pageTitle,
}) => {
  const { user, role, isAdmin, switchUser } = useAuth();
  const { metrics, team, unreadChatCount } = useData();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserSwitcher, setShowUserSwitcher] = useState(false);

  const toggleDarkMode = () => {
    const root = document.documentElement;
    if (root.classList.contains('dark')) {
      root.classList.remove('dark');
      setIsDarkMode(false);
    } else {
      root.classList.add('dark');
      setIsDarkMode(true);
    }
  };

  const getRoleBadge = (userRole?: string) => {
    switch (userRole) {
      case 'partner':
        return <Badge variant="default" className="text-[9px] px-1.5 py-0 bg-indigo-600">Managing Partner</Badge>;
      case 'admin':
        return <Badge variant="info" className="text-[9px] px-1.5 py-0">Senior CA / Admin</Badge>;
      case 'article':
        return <Badge variant="warning" className="text-[9px] px-1.5 py-0">Articled Assistant</Badge>;
      default:
        return <Badge variant="secondary" className="text-[9px] px-1.5 py-0">Associate</Badge>;
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border/70 bg-card/80 px-4 backdrop-blur-md lg:px-8">
      {/* Left: Mobile Nav Button + Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileNav}
          className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div>
          <h1 className="text-lg font-bold tracking-tight text-foreground">{pageTitle}</h1>
          <p className="hidden text-xs text-muted-foreground sm:block">
            Chinar Gulati & Co. Chartered Accountants
          </p>
        </div>
      </div>

      {/* Right: Quick Actions, Role Switcher & Utilities */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Quick User / Role Switcher Pill */}
        <div className="relative">
          <button
            onClick={() => setShowUserSwitcher(!showUserSwitcher)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl border border-border bg-secondary/40 hover:bg-secondary text-left transition-all"
            title="Switch logged-in role / employee for testing"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/20 text-primary font-bold text-xs">
              {user?.display_name ? user.display_name.slice(0, 2).toUpperCase() : 'CG'}
            </div>
            <div className="hidden md:block min-w-0 max-w-[130px]">
              <p className="text-xs font-bold text-foreground truncate leading-tight">
                {user?.display_name?.split('(')[0] || 'User'}
              </p>
              <div className="text-[9px] text-muted-foreground truncate">
                {role === 'partner' ? 'Managing Partner' : role === 'admin' ? 'Senior CA' : role === 'article' ? 'Articled Staff' : 'Associate'}
              </div>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          </button>

          {showUserSwitcher && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowUserSwitcher(false)}
              />
              <div className="absolute right-0 mt-2 w-72 rounded-2xl border border-border bg-card p-2 shadow-elevated z-50 animate-in fade-in zoom-in-95 space-y-2">
                <div className="px-2 pt-1 pb-1.5 border-b border-border">
                  <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">
                    Switch Active User & Role
                  </span>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Test how task privacy, assignments and queries look for different roles.
                  </p>
                </div>

                <div className="space-y-1 max-h-64 overflow-y-auto pr-1">
                  {team.map((member) => {
                    const isCurrent = user?.id === member.id;
                    return (
                      <button
                        key={member.id}
                        onClick={() => {
                          switchUser(member.id);
                          setShowUserSwitcher(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all ${
                          isCurrent
                            ? 'bg-primary/10 border border-primary/30'
                            : 'hover:bg-muted'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <div className={`flex h-7 w-7 items-center justify-center rounded-lg text-white font-bold text-xs ${member.avatar_color || 'bg-primary'}`}>
                            {member.display_name.slice(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-foreground truncate">
                              {member.display_name.split('(')[0]}
                            </p>
                            <p className="text-[10px] text-muted-foreground truncate">{member.email}</p>
                          </div>
                        </div>

                        <div className="shrink-0 pl-1">
                          {getRoleBadge(member.role)}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Quick Add Dropdown */}
        <div className="relative">
          <Button
            size="sm"
            onClick={() => setShowQuickMenu(!showQuickMenu)}
            className="flex items-center gap-1.5 bg-gradient-primary shadow-soft"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Quick Add</span>
          </Button>

          {showQuickMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowQuickMenu(false)}
              />
              <div className="absolute right-0 mt-2 w-52 rounded-xl border border-border bg-card p-1.5 shadow-elevated z-50 animate-in fade-in zoom-in-95">
                {isAdmin && (
                  <>
                    <button
                      onClick={() => {
                        setShowQuickMenu(false);
                        onOpenQuickAdd('audit');
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-foreground hover:bg-muted"
                    >
                      <ShieldCheck className="h-4 w-4 text-amber-500" />
                      <span>New Tax Audit (3CD)</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowQuickMenu(false);
                        onOpenQuickAdd('cert');
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-foreground hover:bg-muted"
                    >
                      <FileCheck2 className="h-4 w-4 text-purple-500" />
                      <span>Issue Certificate (UDIN)</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowQuickMenu(false);
                        onOpenQuickAdd('client');
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-foreground hover:bg-muted"
                    >
                      <UserPlus className="h-4 w-4 text-blue-500" />
                      <span>New ITR Client</span>
                    </button>
                  </>
                )}
                <button
                  onClick={() => {
                    setShowQuickMenu(false);
                    onOpenQuickAdd('task');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-foreground hover:bg-muted"
                >
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span>New Task</span>
                </button>
                <button
                  onClick={() => {
                    setShowQuickMenu(false);
                    onOpenQuickAdd('meeting');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-foreground hover:bg-muted"
                >
                  <Video className="h-4 w-4 text-emerald-500" />
                  <span>Schedule Meeting</span>
                </button>
              </div>
            </>
          )}
        </div>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <Bell className="h-4 w-4" />
            {metrics.overdueTasks > 0 && (
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive animate-pulse" />
            )}
          </button>

          {showNotifications && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowNotifications(false)}
              />
              <div className="absolute right-0 mt-2 w-80 rounded-xl border border-border bg-card p-4 shadow-elevated z-50 animate-in fade-in zoom-in-95">
                <div className="flex items-center justify-between pb-2 border-b border-border/60">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-foreground">
                    Firm Alerts & Queries
                  </h4>
                  <span className="text-[10px] text-muted-foreground">Live</span>
                </div>

                <div className="mt-3 space-y-2.5 text-xs">
                  {unreadChatCount > 0 && (
                    <div className="flex items-start gap-2.5 rounded-lg bg-primary/10 p-2.5 text-primary border border-primary/20">
                      <MessageSquare className="h-4 w-4 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold">{unreadChatCount} New Staff Message(s)</p>
                        <p className="text-[11px] opacity-80">Check Staff Chat for updates.</p>
                      </div>
                    </div>
                  )}

                  {metrics.overdueTasks > 0 ? (
                    <div className="flex items-start gap-2.5 rounded-lg bg-destructive/10 p-2.5 text-destructive border border-destructive/20">
                      <Clock className="h-4 w-4 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold">{metrics.overdueTasks} Overdue Task(s)</p>
                        <p className="text-[11px] opacity-80">Requires review.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 rounded-lg bg-success/10 p-2.5 text-success">
                      <CheckCircle2 className="h-4 w-4 shrink-0" />
                      <span>All audit tasks on track.</span>
                    </div>
                  )}

                  <div className="flex items-start gap-2.5 rounded-lg bg-info/10 p-2.5 text-info border border-info/20">
                    <Sparkles className="h-4 w-4 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold">Practice Briefing Ready</p>
                      <p className="text-[11px] opacity-80">
                        {metrics.taxAuditsCount} Tax Audits and {metrics.todayMeetings} meeting(s) scheduled.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Dark/Light Mode Switcher */}
        <button
          onClick={toggleDarkMode}
          title="Toggle Theme"
          className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
        >
          {isDarkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4" />}
        </button>
      </div>
    </header>
  );
};
