import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Textarea } from '../ui/Textarea';
import { 
  CheckCircle2, Clock, User, Shield, MessageSquare, 
  HelpCircle, Send, ArrowRight, UserCheck, RefreshCw, 
  AlertCircle, History, CheckCheck, Edit2, Share2 
} from 'lucide-react';
import { Task, TaskComment, TaskReassignment, UserRole } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { formatDateTime, isOverdue } from '../../lib/utils';
import { TaskReassignModal } from './TaskReassignModal';

interface TaskDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
  onEdit?: (task: Task) => void;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  isOpen,
  onClose,
  task,
  onEdit,
}) => {
  const { user, isAdmin } = useAuth();
  const { team, toggleTaskStatus, addTaskComment, resolveTaskQuery } = useData();

  const [activeTab, setActiveTab] = useState<'discussion' | 'history' | 'details'>('discussion');
  const [commentText, setCommentText] = useState('');
  const [isQueryType, setIsQueryType] = useState(false);
  const [showReassignModal, setShowReassignModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (!task) return null;

  const assignedMember = team.find((m) => m.id === task.assigned_to);
  const isDone = task.status === 'done';
  const overdue = isOverdue(task.due_at, task.status);

  const notesList: TaskComment[] = task.task_notes || [];
  const historyList: TaskReassignment[] = task.reassignment_history || [];
  const pendingQueriesCount = notesList.filter((n) => n.is_query && !n.is_resolved).length;

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    setSubmitting(true);
    try {
      addTaskComment(
        task.id,
        commentText.trim(),
        isQueryType ? 'query' : 'note',
        isQueryType
      );
      setCommentText('');
      setIsQueryType(false);
    } finally {
      setSubmitting(false);
    }
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'partner':
        return <Badge variant="default" className="text-[9px] px-1.5 py-0 bg-indigo-600">Managing Partner</Badge>;
      case 'admin':
        return <Badge variant="info" className="text-[9px] px-1.5 py-0">Senior CA / Admin</Badge>;
      case 'article':
        return <Badge variant="warning" className="text-[9px] px-1.5 py-0">Articled Assistant</Badge>;
      default:
        return <Badge variant="secondary" className="text-[9px] px-1.5 py-0">Staff Associate</Badge>;
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={
          <div className="flex items-center gap-2 flex-wrap pr-6">
            <span className={isDone ? 'line-through text-muted-foreground' : 'text-foreground'}>
              {task.title}
            </span>
            <Badge
              variant={
                task.priority === 'high'
                  ? 'destructive'
                  : task.priority === 'medium'
                  ? 'warning'
                  : 'secondary'
              }
              className="text-[10px] capitalize"
            >
              {task.priority} Priority
            </Badge>
          </div>
        }
        description={`Practice Task Workspace • Category: ${task.category.toUpperCase()}`}
        maxWidth="2xl"
      >
        <div className="space-y-5">
          {/* Quick Info Ribbon */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl border border-border bg-muted/30">
            {/* Assignee Info */}
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">Assigned Staff</span>
              <div className="flex items-center gap-2">
                <div className={`flex h-6 w-6 items-center justify-center rounded-full text-white font-bold text-[10px] ${assignedMember?.avatar_color || 'bg-primary'}`}>
                  {assignedMember?.display_name.slice(0, 2).toUpperCase() || 'ST'}
                </div>
                <span className="text-xs font-bold text-foreground truncate">
                  {assignedMember?.display_name.split('(')[0] || 'Unassigned'}
                </span>
              </div>
            </div>

            {/* Client Info */}
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">Client Association</span>
              <p className="text-xs font-semibold text-foreground truncate">
                {task.client ? task.client.name : 'Firm Internal Work'}
              </p>
            </div>

            {/* Due Date Info */}
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">Deadline</span>
              <p className={`text-xs font-semibold flex items-center gap-1.5 ${overdue ? 'text-destructive font-bold' : 'text-foreground'}`}>
                <Clock className="h-3.5 w-3.5" />
                {task.due_at ? formatDateTime(task.due_at) : 'No due date'}
              </p>
            </div>
          </div>

          {/* Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant={isDone ? 'outline' : 'primary'}
                onClick={() => toggleTaskStatus(task.id)}
                className={`gap-1.5 text-xs font-bold ${isDone ? 'border-success text-success' : 'bg-emerald-600 hover:bg-emerald-700 text-white'}`}
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>{isDone ? 'Mark Pending' : 'Mark Completed'}</span>
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowReassignModal(true)}
                className="gap-1.5 text-xs text-foreground border-border hover:border-primary/50"
              >
                <Share2 className="h-3.5 w-3.5 text-primary" />
                <span>Reassign Task</span>
              </Button>
            </div>

            {onEdit && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  onClose();
                  onEdit(task);
                }}
                className="gap-1 text-xs text-muted-foreground hover:text-foreground"
              >
                <Edit2 className="h-3.5 w-3.5" />
                <span>Edit Details</span>
              </Button>
            )}
          </div>

          {/* Description / Instructions */}
          {task.description && (
            <div className="p-3.5 rounded-xl border border-border bg-card space-y-1">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">
                Task Brief & Scope
              </span>
              <p className="text-xs text-foreground leading-relaxed whitespace-pre-wrap">
                {task.description}
              </p>
            </div>
          )}

          {/* Section Navigation Tabs */}
          <div className="flex border-b border-border text-xs font-medium">
            <button
              onClick={() => setActiveTab('discussion')}
              className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-bold transition-colors ${
                activeTab === 'discussion'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5" />
              <span>Notes & Employee Queries</span>
              {notesList.length > 0 && (
                <span className="rounded-full bg-secondary px-1.5 py-0.2 text-[10px]">
                  {notesList.length}
                </span>
              )}
              {pendingQueriesCount > 0 && (
                <span className="rounded-full bg-amber-500/20 text-amber-600 px-1.5 py-0.2 text-[10px] font-extrabold border border-amber-500/30">
                  {pendingQueriesCount} Query
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-bold transition-colors ${
                activeTab === 'history'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <History className="h-3.5 w-3.5" />
              <span>Reassignment Trail</span>
              {historyList.length > 0 && (
                <span className="rounded-full bg-secondary px-1.5 py-0.2 text-[10px]">
                  {historyList.length}
                </span>
              )}
            </button>
          </div>

          {/* Tab 1: Notes & Employee Queries */}
          {activeTab === 'discussion' && (
            <div className="space-y-4">
              {/* Post Note / Query Box */}
              <form onSubmit={handlePostComment} className="p-3.5 rounded-xl border border-primary/20 bg-primary/5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
                    {isQueryType ? (
                      <HelpCircle className="h-4 w-4 text-amber-500" />
                    ) : (
                      <MessageSquare className="h-4 w-4 text-primary" />
                    )}
                    {isQueryType ? 'Raise a Query to Practice Partner' : 'Post Task Note / Instruction'}
                  </span>

                  <div className="flex items-center gap-1 bg-card p-0.5 rounded-lg border border-border text-[11px]">
                    <button
                      type="button"
                      onClick={() => setIsQueryType(false)}
                      className={`px-2.5 py-1 rounded-md transition-all ${
                        !isQueryType ? 'bg-primary text-white font-bold' : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      Instruction / Note
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsQueryType(true)}
                      className={`px-2.5 py-1 rounded-md transition-all ${
                        isQueryType ? 'bg-amber-500 text-white font-bold' : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      ❓ Ask Query / Blocker
                    </button>
                  </div>
                </div>

                <Textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={
                    isQueryType
                      ? 'Describe your question or blocker for partner guidance (e.g. Missing 26AS reflection, joint account treatment...)'
                      : 'Add compliance notes, statutory section references, or working remarks...'
                  }
                  rows={2}
                  className="bg-card text-xs"
                />

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-muted-foreground">
                    Posting as: <strong className="text-foreground">{user?.display_name}</strong>
                  </span>
                  <Button
                    type="submit"
                    size="sm"
                    loading={submitting}
                    disabled={!commentText.trim()}
                    className={`gap-1.5 text-xs font-bold shadow-soft ${
                      isQueryType ? 'bg-amber-600 hover:bg-amber-700 text-white' : 'bg-primary'
                    }`}
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>{isQueryType ? 'Post Query to Admin' : 'Post Note'}</span>
                  </Button>
                </div>
              </form>

              {/* Comments / Queries Feed */}
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {notesList.length === 0 ? (
                  <div className="p-8 rounded-xl border border-border/80 bg-card text-center space-y-1">
                    <MessageSquare className="h-7 w-7 text-muted-foreground/40 mx-auto" />
                    <p className="text-xs font-bold text-foreground">No notes or queries yet</p>
                    <p className="text-[11px] text-muted-foreground">
                      Use the box above to post task instructions or raise questions with the Managing Partner.
                    </p>
                  </div>
                ) : (
                  notesList.map((comment) => {
                    const isQuery = comment.is_query || comment.type === 'query';
                    const isSystem = comment.type === 'system';

                    if (isSystem) {
                      return (
                        <div key={comment.id} className="flex items-center justify-center gap-2 p-2 rounded-lg bg-secondary/60 text-[11px] text-muted-foreground border border-border/60">
                          <RefreshCw className="h-3 w-3 text-primary shrink-0" />
                          <span>{comment.content}</span>
                          <span className="text-[10px] opacity-70">• {formatDateTime(comment.created_at)}</span>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={comment.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isQuery
                            ? comment.is_resolved
                              ? 'bg-emerald-500/5 border-emerald-500/20'
                              : 'bg-amber-500/10 border-amber-500/30'
                            : 'bg-card border-border'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/20 text-primary font-bold text-[10px]">
                              {comment.author_name.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-bold text-foreground">
                                  {comment.author_name}
                                </span>
                                {getRoleBadge(comment.author_role)}
                              </div>
                              <p className="text-[10px] text-muted-foreground">
                                {formatDateTime(comment.created_at)}
                              </p>
                            </div>
                          </div>

                          {isQuery && (
                            <div>
                              {comment.is_resolved ? (
                                <Badge variant="default" className="bg-emerald-600 text-white text-[9px] flex items-center gap-1">
                                  <CheckCheck className="h-3 w-3" />
                                  Resolved
                                </Badge>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <Badge variant="warning" className="text-[9px] flex items-center gap-1">
                                    <HelpCircle className="h-3 w-3" />
                                    Query Pending
                                  </Badge>
                                  {(isAdmin || user?.id === comment.author_id) && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => resolveTaskQuery(task.id, comment.id)}
                                      className="h-6 px-2 text-[10px] border-emerald-500/40 text-emerald-600 hover:bg-emerald-500/10"
                                    >
                                      Mark Resolved
                                    </Button>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <p className="text-xs text-foreground leading-relaxed whitespace-pre-wrap pl-8">
                          {comment.content}
                        </p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Tab 2: Reassignment Trail */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              {historyList.length === 0 ? (
                <div className="p-8 rounded-xl border border-border bg-card text-center space-y-1">
                  <History className="h-7 w-7 text-muted-foreground/40 mx-auto" />
                  <p className="text-xs font-bold text-foreground">Initial Assignment Only</p>
                  <p className="text-[11px] text-muted-foreground">
                    This task has not been reassigned yet. Click "Reassign Task" to transfer ownership.
                  </p>
                </div>
              ) : (
                historyList.map((item) => (
                  <div key={item.id} className="p-3.5 rounded-xl border border-border bg-card space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-foreground flex items-center gap-1.5">
                        <UserCheck className="h-4 w-4 text-primary" />
                        Ownership Transferred
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {formatDateTime(item.created_at)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs py-1">
                      <span className="font-semibold text-muted-foreground bg-muted px-2 py-0.5 rounded">
                        {item.from_user_name || 'Unassigned'}
                      </span>
                      <ArrowRight className="h-3.5 w-3.5 text-primary" />
                      <span className="font-bold text-primary bg-primary/10 px-2 py-0.5 rounded border border-primary/20">
                        {item.to_user_name}
                      </span>
                    </div>

                    {item.reason && (
                      <p className="text-xs text-muted-foreground bg-secondary/40 p-2 rounded-lg border border-border/50">
                        <strong>Reason:</strong> {item.reason}
                      </p>
                    )}

                    <p className="text-[10px] text-muted-foreground">
                      Reassigned by: <strong>{item.reassigned_by_name}</strong>
                    </p>
                  </div>
                ))
              )}
            </div>
          )}

          <div className="flex justify-end pt-3 border-t border-border/60">
            <Button variant="outline" onClick={onClose}>
              Close Workspace
            </Button>
          </div>
        </div>
      </Modal>

      {/* Nested Reassign Modal */}
      <TaskReassignModal
        isOpen={showReassignModal}
        onClose={() => setShowReassignModal(false)}
        task={task}
      />
    </>
  );
};
