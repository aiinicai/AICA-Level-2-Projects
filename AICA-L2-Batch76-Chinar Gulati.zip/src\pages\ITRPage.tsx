import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, FileSpreadsheet, Download, Upload, 
  ExternalLink, CheckCircle2, Clock, AlertTriangle, 
  ChevronRight, Edit2, Trash2, ShieldCheck, UserCheck 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Select } from '../components/ui/Select';
import { useData } from '../context/DataContext';
import { Client, ITRFilingStatus } from '../types';
import { ASSESSMENT_YEARS } from '../lib/utils';
import { ITRClientDialog } from '../components/itr/ITRClientDialog';
import { ExcelImportExportModal } from '../components/itr/ExcelImportExportModal';

interface ITRPageProps {
  onOpenClient: (clientId: string) => void;
}

export const ITRPage: React.FC<ITRPageProps> = ({ onOpenClient }) => {
  const { clients, team, deleteClient } = useData();

  const [selectedAY, setSelectedAY] = useState('2026-27');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showExcelModal, setShowExcelModal] = useState(false);

  const teamMap = useMemo(() => {
    const map = new Map<string, string>();
    team.forEach((t) => map.set(t.id, t.display_name));
    return map;
  }, [team]);

  const filteredClients = useMemo(() => {
    return clients.filter((c) => {
      if (selectedAY && c.assessment_year && c.assessment_year !== selectedAY) return false;
      if (statusFilter !== 'all' && c.filing_status !== statusFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const nameMatch = c.name.toLowerCase().includes(q);
        const panMatch = c.pan.toLowerCase().includes(q);
        const mobileMatch = (c.mobile || c.contact_phone || '').includes(q);
        if (!nameMatch && !panMatch && !mobileMatch) return false;
      }
      return true;
    });
  }, [clients, selectedAY, statusFilter, searchQuery]);

  const statusBadges: Record<ITRFilingStatus, { label: string; variant: 'secondary' | 'warning' | 'info' | 'default' | 'success' }> = {
    not_started: { label: 'Not Started', variant: 'secondary' },
    documents_pending: { label: 'Docs Pending', variant: 'warning' },
    in_review: { label: 'In Review', variant: 'info' },
    filed: { label: 'Filed', variant: 'default' },
    completed: { label: 'Completed', variant: 'success' },
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            ITR & Tax Compliance Hub
          </h2>
          <p className="text-xs text-muted-foreground">
            Track individual and corporate Income Tax Returns (ITR-1 to 7) for AY {selectedAY}.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowExcelModal(true)}
            className="gap-1.5"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
            <span>Excel Import / Export</span>
          </Button>

          <Button
            size="sm"
            onClick={() => setShowAddModal(true)}
            className="gap-1.5 shadow-soft"
          >
            <Plus className="h-4 w-4" />
            <span>New ITR Client</span>
          </Button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
        <div className="sm:col-span-2 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by client name, PAN (e.g. ABCDE1234F), or mobile…"
            className="pl-9"
          />
        </div>

        <Select
          value={selectedAY}
          onChange={(e) => setSelectedAY(e.target.value)}
        >
          {ASSESSMENT_YEARS.map((ay) => (
            <option key={ay} value={ay}>
              Assessment Year {ay}
            </option>
          ))}
        </Select>

        <Select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">All Filing Statuses</option>
          <option value="not_started">⚪ Not Started</option>
          <option value="documents_pending">🟡 Documents Pending</option>
          <option value="in_review">🔵 In Review</option>
          <option value="filed">🟣 Filed</option>
          <option value="completed">🟢 Completed</option>
        </Select>
      </div>

      {/* ITR Clients Table */}
      <div className="rounded-xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-secondary/40 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Client & Contact</th>
                <th className="px-4 py-3.5">PAN & Form</th>
                <th className="px-4 py-3.5">Filing Status</th>
                <th className="px-4 py-3.5">Assigned To</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filteredClients.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-xs text-muted-foreground">
                    <ShieldCheck className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
                    No client records match the current filters.
                  </td>
                </tr>
              ) : (
                filteredClients.map((client) => {
                  const badgeInfo = statusBadges[client.filing_status] || { label: client.filing_status, variant: 'secondary' };

                  return (
                    <tr
                      key={client.id}
                      className="hover:bg-secondary/20 transition-colors group cursor-pointer"
                      onClick={() => onOpenClient(client.id)}
                    >
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-foreground group-hover:text-primary transition-colors">
                          {client.name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {client.mobile || client.contact_phone || 'No phone'} · {client.contact_email || 'No email'}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="font-mono text-xs font-bold text-foreground uppercase tracking-wider">
                          {client.pan}
                        </span>
                        <div className="text-xs text-muted-foreground">
                          {client.itr_type || 'ITR-1'} · AY {client.assessment_year}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <Badge variant={badgeInfo.variant}>
                          {badgeInfo.label}
                        </Badge>
                      </td>

                      <td className="px-4 py-3.5 text-xs text-muted-foreground">
                        {client.assigned_to
                          ? teamMap.get(client.assigned_to) || 'Partner'
                          : '— Unassigned —'}
                      </td>

                      <td className="px-4 py-3.5 text-xs text-muted-foreground">
                        {client.category || 'General'}
                      </td>

                      <td className="px-4 py-3.5 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onOpenClient(client.id)}
                            className="h-8 px-2 text-xs font-semibold text-primary hover:bg-primary/10"
                          >
                            Open 360 <ChevronRight className="h-3.5 w-3.5 ml-1" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setEditingClient(client)}
                            className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => {
                              if (confirm(`Remove ${client.name}?`)) {
                                deleteClient(client.id);
                              }
                            }}
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      <ITRClientDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <ITRClientDialog
        isOpen={!!editingClient}
        onClose={() => setEditingClient(null)}
        client={editingClient}
      />
      <ExcelImportExportModal
        isOpen={showExcelModal}
        onClose={() => setShowExcelModal(false)}
      />
    </div>
  );
};
