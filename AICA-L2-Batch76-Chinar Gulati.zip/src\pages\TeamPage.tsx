import React, { useState } from 'react';
import { 
  UserPlus, Users, Mail, Shield, CheckCircle2, 
  Trash2, UserCheck, Sparkles 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { Card, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { TeamMember, UserRole } from '../types';

export const TeamPage: React.FC = () => {
  const { team, tasks, clients, addTeamMember, deleteTeamMember } = useData();

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<UserRole>('employee');
  const [error, setError] = useState('');

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim() || !inviteEmail.trim()) {
      setError('Name and valid email are required');
      return;
    }

    addTeamMember(inviteName.trim(), inviteEmail.trim(), inviteRole);
    setInviteName('');
    setInviteEmail('');
    setInviteRole('employee');
    setError('');
    setShowInviteModal(false);
  };

  const roleLabels: Record<UserRole, { label: string; variant: 'default' | 'info' | 'warning' | 'secondary' }> = {
    partner: { label: 'Managing Partner', variant: 'default' },
    admin: { label: 'Senior CA / Admin', variant: 'info' },
    article: { label: 'Articled Assistant', variant: 'warning' },
    employee: { label: 'Staff / Associate', variant: 'secondary' },
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Practice Team & Staff Management
          </h2>
          <p className="text-xs text-muted-foreground">
            Assign statutory audit tasks, delegate ITR clients, and manage firm permissions.
          </p>
        </div>

        <Button onClick={() => setShowInviteModal(true)} className="gap-1.5 shadow-soft">
          <UserPlus className="h-4 w-4" />
          <span>Invite Member</span>
        </Button>
      </div>

      {/* Team Member Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {team.map((member) => {
          const roleInfo = roleLabels[member.role] || { label: member.role, variant: 'secondary' };
          const memberTasks = tasks.filter((t) => t.assigned_to === member.id && t.status !== 'done').length;
          const memberClients = clients.filter((c) => c.assigned_to === member.id).length;

          return (
            <Card key={member.id} className="shadow-soft hover:border-primary/40 transition-all">
              <CardContent className="p-5 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl text-white font-bold text-sm shadow-soft ${member.avatar_color || 'bg-primary'}`}>
                      {member.display_name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-foreground line-clamp-1">{member.display_name}</h4>
                      <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                    </div>
                  </div>

                  <Badge variant={roleInfo.variant} className="text-[10px] shrink-0">
                    {roleInfo.label}
                  </Badge>
                </div>

                {/* Workload Stats */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/60 text-center">
                  <div className="rounded-lg bg-secondary/40 p-2 border border-border/50">
                    <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">
                      Assigned Tasks
                    </span>
                    <p className="text-base font-bold text-foreground mt-0.5">{memberTasks}</p>
                  </div>

                  <div className="rounded-lg bg-secondary/40 p-2 border border-border/50">
                    <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">
                      Managed Clients
                    </span>
                    <p className="text-base font-bold text-foreground mt-0.5">{memberClients}</p>
                  </div>
                </div>

                {/* Footer Action */}
                {member.role !== 'partner' && (
                  <div className="flex justify-end pt-1 border-t border-border/60">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm(`Remove ${member.display_name} from the practice?`)) {
                          deleteTeamMember(member.id);
                        }
                      }}
                      className="text-xs text-muted-foreground hover:text-destructive h-7 px-2"
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Remove
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Invite Member Modal */}
      <Modal
        isOpen={showInviteModal}
        onClose={() => setShowInviteModal(false)}
        title="Invite Practice Staff Member"
        description="Add articles, associates, or managers to collaborate on client tasks."
        maxWidth="md"
      >
        <form onSubmit={handleInviteSubmit} className="space-y-4">
          {error && (
            <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium">
              {error}
            </div>
          )}

          <Input
            label="Full Name *"
            value={inviteName}
            onChange={(e) => setInviteName(e.target.value)}
            placeholder="e.g. Ankit Verma"
            autoFocus
          />

          <Input
            label="Email Address *"
            type="email"
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
            placeholder="ankit.tax@firm.com"
          />

          <Select
            label="Practice Role"
            value={inviteRole}
            onChange={(e) => setInviteRole(e.target.value as UserRole)}
          >
            <option value="admin">Senior CA / Manager (Full Access)</option>
            <option value="article">Articled Assistant (Data & Filing Access)</option>
            <option value="employee">Staff / Associate</option>
          </Select>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
            <Button type="button" variant="outline" onClick={() => setShowInviteModal(false)}>
              Cancel
            </Button>
            <Button type="submit">
              Send Invite
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
