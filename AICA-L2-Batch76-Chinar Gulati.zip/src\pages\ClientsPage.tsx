import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, Users, Phone, Mail, ChevronRight, 
  Edit2, Trash2, ShieldCheck, Building2 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Card, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { Client } from '../types';
import { ITRClientDialog } from '../components/itr/ITRClientDialog';

interface ClientsPageProps {
  onOpenClient: (clientId: string) => void;
}

export const ClientsPage: React.FC<ClientsPageProps> = ({ onOpenClient }) => {
  const { clients, deleteClient } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredClients = useMemo(() => {
    return clients.filter((c) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const nameMatch = c.name.toLowerCase().includes(q);
        const panMatch = c.pan.toLowerCase().includes(q);
        const phoneMatch = (c.mobile || c.contact_phone || '').includes(q);
        const catMatch = (c.category || '').toLowerCase().includes(q);
        if (!nameMatch && !panMatch && !phoneMatch && !catMatch) return false;
      }
      return true;
    });
  }, [clients, searchQuery]);

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Clients Directory
          </h2>
          <p className="text-xs text-muted-foreground">
            Manage your firm's complete taxpayer roster, corporate entities, and individual clients.
          </p>
        </div>

        <Button onClick={() => setShowAddModal(true)} className="gap-1.5 shadow-soft">
          <Plus className="h-4 w-4" />
          <span>Add Client</span>
        </Button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by client name, PAN, mobile number, or practice category…"
          className="pl-9"
        />
      </div>

      {/* Client Grid Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredClients.length === 0 ? (
          <div className="col-span-full rounded-xl border border-border bg-card p-12 text-center">
            <Users className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-foreground">No clients found</h4>
            <p className="text-xs text-muted-foreground mt-1">
              Try adjusting your search query or add a new client.
            </p>
          </div>
        ) : (
          filteredClients.map((client) => (
            <Card
              key={client.id}
              className="cursor-pointer hover:border-primary/40 transition-all flex flex-col justify-between"
              onClick={() => onOpenClient(client.id)}
            >
              <CardContent className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary font-bold text-xs shrink-0">
                      {client.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-foreground line-clamp-1">{client.name}</h4>
                      <p className="text-[11px] font-mono text-muted-foreground uppercase">{client.pan}</p>
                    </div>
                  </div>

                  <Badge variant="outline" className="text-[10px] shrink-0 capitalize">
                    {client.filing_status.replace('_', ' ')}
                  </Badge>
                </div>

                <div className="space-y-1.5 text-xs text-muted-foreground pt-1 border-t border-border/50">
                  {client.mobile && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground/70" />
                      <span>{client.mobile}</span>
                    </div>
                  )}
                  {client.contact_email && (
                    <div className="flex items-center gap-2">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground/70" />
                      <span className="truncate">{client.contact_email}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-3.5 w-3.5 text-muted-foreground/70" />
                    <span>{client.category || 'General Practice'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-border/60" onClick={(e) => e.stopPropagation()}>
                  <Button
                    size="sm"
                    variant="link"
                    onClick={() => onOpenClient(client.id)}
                    className="text-xs text-primary font-semibold p-0"
                  >
                    Open 360 Workspace <ChevronRight className="h-3 w-3 ml-0.5" />
                  </Button>

                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setEditingClient(client)}
                      className="h-7 w-7 text-muted-foreground hover:text-foreground"
                    >
                      <Edit2 className="h-3 w-3" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        if (confirm(`Delete ${client.name}?`)) {
                          deleteClient(client.id);
                        }
                      }}
                      className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modals */}
      <ITRClientDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <ITRClientDialog
        isOpen={!!editingClient}
        onClose={() => setEditingClient(null)}
        client={editingClient}
      />
    </div>
  );
};
