import React, { useState, useEffect, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { Meeting } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { AlertTriangle } from 'lucide-react';

interface MeetingDialogProps {
  isOpen: boolean;
  onClose: () => void;
  meeting?: Meeting | null;
  defaultDate?: string;
}

export const MeetingDialog: React.FC<MeetingDialogProps> = ({
  isOpen,
  onClose,
  meeting,
  defaultDate,
}) => {
  const { user } = useAuth();
  const { clients, meetings, addMeeting, updateMeeting } = useData();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [clientId, setClientId] = useState<string>('none');
  const [startAt, setStartAt] = useState('');
  const [endAt, setEndAt] = useState('');
  const [joinUrl, setJoinUrl] = useState('');
  const [location, setLocation] = useState('');
  const [reminderMinutes, setReminderMinutes] = useState(15);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (meeting) {
        setTitle(meeting.title);
        setDescription(meeting.description || '');
        setClientId(meeting.client_id || 'none');
        setStartAt(meeting.start_at.slice(0, 16));
        setEndAt(meeting.end_at.slice(0, 16));
        setJoinUrl(meeting.join_url || '');
        setLocation(meeting.location || '');
        setReminderMinutes(meeting.reminder_minutes || 15);
      } else {
        const defaultStart = defaultDate || new Date().toISOString().slice(0, 16);
        const endDateObj = new Date(defaultStart);
        endDateObj.setMinutes(endDateObj.getMinutes() + 30);
        const defaultEnd = endDateObj.toISOString().slice(0, 16);

        setTitle('');
        setDescription('');
        setClientId('none');
        setStartAt(defaultStart);
        setEndAt(defaultEnd);
        setJoinUrl('https://meet.google.com/new');
        setLocation('Google Meet');
        setReminderMinutes(15);
      }
      setError('');
    }
  }, [isOpen, meeting, defaultDate]);

  // Meeting conflict detector
  const conflict = useMemo(() => {
    if (!startAt || !endAt) return null;
    const newStart = new Date(startAt).getTime();
    const newEnd = new Date(endAt).getTime();

    const conflictingMeeting = meetings.find((m) => {
      if (meeting && m.id === meeting.id) return false;
      const mStart = new Date(m.start_at).getTime();
      const mEnd = new Date(m.end_at).getTime();
      return (newStart < mEnd && newEnd > mStart);
    });

    return conflictingMeeting || null;
  }, [startAt, endAt, meetings, meeting]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Meeting title is required');
      return;
    }
    if (!startAt || !endAt) {
      setError('Start and end time are required');
      return;
    }
    if (new Date(endAt) <= new Date(startAt)) {
      setError('End time must be after start time');
      return;
    }

    setIsSubmitting(true);
    try {
      const meetingData = {
        user_id: user?.id || 'user_ca_pro_01',
        title: title.trim(),
        description: description.trim() || null,
        client_id: clientId === 'none' ? null : clientId,
        start_at: new Date(startAt).toISOString(),
        end_at: new Date(endAt).toISOString(),
        join_url: joinUrl.trim() || null,
        location: location.trim() || null,
        reminder_minutes: reminderMinutes,
      };

      if (meeting) {
        updateMeeting(meeting.id, meetingData);
      } else {
        addMeeting(meetingData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={meeting ? 'Edit Meeting' : 'Schedule Meeting'}
      description="Set up client consultations, tax reviews, or audit committee calls."
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {conflict && (
          <div className="flex items-start gap-2.5 rounded-lg border border-warning/30 bg-warning/10 p-3 text-warning text-xs">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Schedule Conflict Detected!</p>
              <p className="opacity-90">
                Overlaps with &ldquo;{conflict.title}&rdquo; (
                {new Date(conflict.start_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} -{' '}
                {new Date(conflict.end_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
              </p>
            </div>
          </div>
        )}

        <Input
          label="Meeting Title *"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. Q3 Statutory Audit Review with Directors"
          error={error}
          autoFocus
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Client"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
          >
            <option value="none">— No client (Internal Practice) —</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.pan})
              </option>
            ))}
          </Select>

          <Select
            label="Reminder Notification"
            value={String(reminderMinutes)}
            onChange={(e) => setReminderMinutes(Number(e.target.value))}
          >
            <option value="0">No reminder</option>
            <option value="5">5 minutes before</option>
            <option value="15">15 minutes before (Recommended)</option>
            <option value="30">30 minutes before</option>
            <option value="60">1 hour before</option>
          </Select>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Start Date & Time *"
            type="datetime-local"
            value={startAt}
            onChange={(e) => setStartAt(e.target.value)}
          />
          <Input
            label="End Date & Time *"
            type="datetime-local"
            value={endAt}
            onChange={(e) => setEndAt(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Join Link (Meet / Zoom / Teams)"
            type="url"
            value={joinUrl}
            onChange={(e) => setJoinUrl(e.target.value)}
            placeholder="https://meet.google.com/abc-defg-hij"
          />
          <Input
            label="Location / Room"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Main Boardroom / Client Office"
          />
        </div>

        <Textarea
          label="Meeting Agenda & Discussion Points"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Points to discuss: Sec 80D deduction, share valuation, Form 3CD queries…"
          rows={3}
        />

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {meeting ? 'Save Changes' : 'Schedule Meeting'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
