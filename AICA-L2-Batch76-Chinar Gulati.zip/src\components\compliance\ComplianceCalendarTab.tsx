import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, Clock, Calendar as CalendarIcon, AlertTriangle, 
  CheckCircle2, Bell, Plus, Search, Filter, ArrowRight, 
  FileText, ExternalLink, HelpCircle, UserCheck, Sparkles 
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { ComplianceItem, ComplianceCategory } from '../../types';
import { generateMonthlyCompliances } from '../../lib/complianceData';
import { TaskDialog } from '../tasks/TaskDialog';

interface ComplianceCalendarTabProps {
  initialYear?: number;
  initialMonth?: number;
  onOpenTaskForCompliance?: (compliance: ComplianceItem) => void;
}

export const ComplianceCalendarTab: React.FC<ComplianceCalendarTabProps> = ({
  initialYear = 2026,
  initialMonth = 8,
}) => {
  const [year, setYear] = useState<number>(initialYear);
  const [month, setMonth] = useState<number>(initialMonth);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [remindedItems, setRemindedItems] = useState<Record<string, boolean>>({});
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [prefilledTask, setPrefilledTask] = useState<{
    title: string;
    description: string;
    due_at: string;
    category: 'compliance';
  } | null>(null);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June', 
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const monthlyCompliances = useMemo(() => {
    return generateMonthlyCompliances(year, month);
  }, [year, month]);

  const filteredCompliances = useMemo(() => {
    return monthlyCompliances.filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchForm = item.form_name.toLowerCase().includes(q);
        const matchAuth = item.authority.toLowerCase().includes(q);
        const matchPeriod = item.period.toLowerCase().includes(q);
        if (!matchTitle && !matchForm && !matchAuth && !matchPeriod) return false;
      }
      return true;
    });
  }, [monthlyCompliances, selectedCategory, searchQuery]);

  const toggleReminder = (id: string) => {
    setRemindedItems((prev) => {
      const next = !prev[id];
      return { ...prev, [id]: next };
    });
  };

  const handleCreateTask = (item: ComplianceItem) => {
    setPrefilledTask({
      title: `${item.form_name}: ${item.title}`,
      description: `Statutory Compliance Due Date: ${item.due_day_or_date}\nPeriod: ${item.period}\nAuthority: ${item.authority}\nApplicability: ${item.applicable_to}\n${item.penalty_interest_info || ''}`,
      due_at: `${item.due_date}T18:00:00.000Z`,
      category: 'compliance',
    });
    setTaskDialogOpen(true);
  };

  const getCategoryBadge = (cat: ComplianceCategory) => {
    switch (cat) {
      case 'gst':
        return <Badge variant="default" className="text-[10px] bg-indigo-600">GST (Goods & Services Tax)</Badge>;
      case 'tds':
        return <Badge variant="warning" className="text-[10px] bg-amber-600 text-white">TDS & TCS (Income Tax)</Badge>;
      case 'income_tax':
        return <Badge variant="info" className="text-[10px] bg-blue-600 text-white">Income Tax & Advance Tax</Badge>;
      case 'tax_audit':
        return <Badge variant="default" className="text-[10px] bg-emerald-600">Tax Audit & UDIN (Sec 44AB)</Badge>;
      case 'roc':
        return <Badge variant="secondary" className="text-[10px] bg-purple-600 text-white">ROC & MCA Compliances</Badge>;
      case 'pf_esi':
        return <Badge variant="secondary" className="text-[10px] bg-rose-600 text-white">EPF & ESIC Monthly</Badge>;
      default:
        return <Badge variant="secondary" className="text-[10px]">Statutory</Badge>;
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  const gstCount = monthlyCompliances.filter((c) => c.category === 'gst').length;
  const tdsCount = monthlyCompliances.filter((c) => c.category === 'tds').length;
  const incomeTaxCount = monthlyCompliances.filter((c) => c.category === 'income_tax' || c.category === 'tax_audit').length;
  const rocCount = monthlyCompliances.filter((c) => c.category === 'roc' || c.category === 'pf_esi').length;

  return (
    <div className="space-y-6">
      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-3.5 space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">GST Deadlines</span>
          <div className="flex items-baseline justify-between">
            <p className="text-xl font-extrabold text-foreground">{gstCount}</p>
            <span className="text-[10px] text-muted-foreground font-semibold">11th, 20th, 25th</span>
          </div>
        </div>

        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3.5 space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">TDS / TCS Due</span>
          <div className="flex items-baseline justify-between">
            <p className="text-xl font-extrabold text-foreground">{tdsCount}</p>
            <span className="text-[10px] text-muted-foreground font-semibold">7th Deposit / Returns</span>
          </div>
        </div>

        <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3.5 space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-500">Income Tax & Audit</span>
          <div className="flex items-baseline justify-between">
            <p className="text-xl font-extrabold text-foreground">{incomeTaxCount}</p>
            <span className="text-[10px] text-muted-foreground font-semibold">Advance Tax / 3CD</span>
          </div>
        </div>

        <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-3.5 space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-500">ROC & Labor Laws</span>
          <div className="flex items-baseline justify-between">
            <p className="text-xl font-extrabold text-foreground">{rocCount}</p>
            <span className="text-[10px] text-muted-foreground font-semibold">PF/ESI 15th, AOC-4</span>
          </div>
        </div>
      </div>

      {/* Month Selector & Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl border border-border bg-card shadow-soft">
        <div className="flex items-center gap-2 flex-wrap">
          <Select
            value={month.toString()}
            onChange={(e) => setMonth(Number(e.target.value))}
            className="w-40 font-bold"
          >
            {monthNames.map((name, i) => (
              <option key={i} value={(i + 1).toString()}>
                {name}
              </option>
            ))}
          </Select>

          <Select
            value={year.toString()}
            onChange={(e) => setYear(Number(e.target.value))}
            className="w-28 font-bold"
          >
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
          </Select>

          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              const now = new Date();
              setYear(now.getFullYear());
              setMonth(now.getMonth() + 1);
            }}
            className="text-xs"
          >
            Current Month
          </Button>
        </div>

        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search GSTR-1, 3B, TDS, Form 26Q, Sec 44AB..."
              className="pl-8 text-xs h-9"
            />
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-muted-foreground font-semibold text-xs shrink-0 mr-1 flex items-center gap-1">
          <Filter className="h-3.5 w-3.5" />
          Filter:
        </span>
        {[
          { id: 'all', label: 'All Statutory Compliances' },
          { id: 'gst', label: 'GST (GSTR-1, 3B, 9)' },
          { id: 'tds', label: 'TDS & TCS (Challan 281, 24Q/26Q)' },
          { id: 'income_tax', label: 'Income Tax & Advance Tax' },
          { id: 'tax_audit', label: 'Tax Audit (3CD & UDIN)' },
          { id: 'roc', label: 'ROC & MCA Returns' },
          { id: 'pf_esi', label: 'EPF & ESI Monthly' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`shrink-0 px-3 py-1.5 rounded-lg font-bold transition-all ${
              selectedCategory === cat.id
                ? 'bg-primary text-white shadow-soft'
                : 'bg-card border border-border text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Compliances List */}
      <div className="space-y-3.5">
        {filteredCompliances.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-12 text-center shadow-soft space-y-2">
            <CheckCircle2 className="h-9 w-9 text-muted-foreground/40 mx-auto" />
            <h4 className="text-sm font-bold text-foreground">No compliances found for this period</h4>
            <p className="text-xs text-muted-foreground">
              Try choosing another month or adjusting your search filters.
            </p>
          </div>
        ) : (
          filteredCompliances.map((comp) => {
            const isOverdue = comp.due_date < todayStr;
            const isToday = comp.due_date === todayStr;
            const hasReminder = !!remindedItems[comp.id];

            return (
              <div
                key={comp.id}
                className={`rounded-2xl border p-4.5 transition-all shadow-soft space-y-3 ${
                  isToday
                    ? 'border-amber-500/50 bg-amber-500/5'
                    : isOverdue
                    ? 'border-destructive/30 bg-destructive/5'
                    : 'border-border bg-card hover:border-primary/40'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-extrabold px-2 py-0.5 rounded-md bg-secondary border border-border text-foreground">
                        {comp.form_name}
                      </span>
                      {getCategoryBadge(comp.category)}
                      {comp.is_recurring && (
                        <Badge variant="secondary" className="text-[9px] uppercase">
                          {comp.recurrence_type}
                        </Badge>
                      )}
                    </div>

                    <h3 className="text-sm font-bold text-foreground">
                      {comp.title}
                    </h3>

                    <p className="text-xs text-muted-foreground">
                      <strong>Applicable to:</strong> {comp.applicable_to} • <strong>Period:</strong> {comp.period}
                    </p>
                  </div>

                  {/* Due Date Badge */}
                  <div className="flex flex-col sm:items-end gap-1 shrink-0">
                    <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold border ${
                      isToday
                        ? 'bg-amber-500 text-white border-amber-600 animate-pulse'
                        : isOverdue
                        ? 'bg-destructive/10 text-destructive border-destructive/30'
                        : 'bg-primary/10 text-primary border-primary/20'
                    }`}>
                      <Clock className="h-3.5 w-3.5" />
                      <span>Due: {comp.due_day_or_date}</span>
                    </div>

                    <span className="text-[10px] text-muted-foreground">
                      Authority: <strong>{comp.authority}</strong>
                    </span>
                  </div>
                </div>

                {/* Penalty / Statutory Warning */}
                {comp.penalty_interest_info && (
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-muted/40 border border-border/70 text-xs text-muted-foreground">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <span>
                      <strong className="text-foreground">Statutory Impact / Late Fees:</strong> {comp.penalty_interest_info}
                    </span>
                  </div>
                )}

                {/* Actions Ribbon */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-border/60">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleCreateTask(comp)}
                      className="h-8 gap-1.5 text-xs font-bold bg-gradient-primary shadow-soft"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>Assign Task to Staff</span>
                    </Button>

                    <Button
                      size="sm"
                      variant={hasReminder ? 'primary' : 'outline'}
                      onClick={() => toggleReminder(comp.id)}
                      className={`h-8 gap-1.5 text-xs ${
                        hasReminder ? 'bg-emerald-600 text-white' : 'text-foreground'
                      }`}
                    >
                      <Bell className="h-3.5 w-3.5" />
                      <span>{hasReminder ? 'Reminder Active ✓' : 'Set Practice Reminder'}</span>
                    </Button>
                  </div>

                  <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                    <Sparkles className="h-3 w-3 text-primary" />
                    Chinar Gulati & Co. Compliance Calendar
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pre-filled Task Dialog */}
      {prefilledTask && (
        <TaskDialog
          isOpen={taskDialogOpen}
          onClose={() => {
            setTaskDialogOpen(false);
            setPrefilledTask(null);
          }}
          defaultDate={prefilledTask.due_at.slice(0, 16)}
        />
      )}
    </div>
  );
};
