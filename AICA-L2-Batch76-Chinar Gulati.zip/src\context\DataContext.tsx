import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { 
  Client, Task, Meeting, WorkItem, ITRDocument, ClientNote, 
  ClientActivity, TeamMember, AttendanceRecord, DocStatus, TaskStatus, 
  WorkItemStatus, ITRFilingStatus, TaxAuditRecord, CertificateRecord,
  ChatMessage, TaskComment, TaskReassignment 
} from '../types';
import { storage } from '../lib/storage';
import { useAuth } from './AuthContext';

interface DataContextType {
  clients: Client[];
  taxAudits: TaxAuditRecord[];
  certificates: CertificateRecord[];
  tasks: Task[];
  allTasks: Task[];
  meetings: Meeting[];
  workItems: WorkItem[];
  team: TeamMember[];
  attendance: AttendanceRecord[];
  
  // Clients
  addClient: (client: Omit<Client, 'id' | 'created_at' | 'updated_at'>) => Client;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClientById: (id: string) => Client | undefined;
  bulkImportClients: (newClients: Partial<Client>[]) => void;

  // Tax Audits
  addTaxAudit: (audit: Omit<TaxAuditRecord, 'id' | 'created_at' | 'updated_at'>) => TaxAuditRecord;
  updateTaxAudit: (id: string, audit: Partial<TaxAuditRecord>) => void;
  deleteTaxAudit: (id: string) => void;

  // Certifications
  addCertificate: (cert: Omit<CertificateRecord, 'id' | 'created_at' | 'updated_at'>) => CertificateRecord;
  updateCertificate: (id: string, cert: Partial<CertificateRecord>) => void;
  deleteCertificate: (id: string) => void;

  // Tasks
  addTask: (task: Omit<Task, 'id' | 'created_at'>) => Task;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskStatus: (id: string) => void;
  reassignTask: (taskId: string, newAssigneeId: string, reason?: string) => void;
  addTaskComment: (taskId: string, content: string, type?: 'note' | 'query' | 'resolution' | 'system', isQuery?: boolean) => void;
  resolveTaskQuery: (taskId: string, commentId: string) => void;

  // Chat & Staff Messages
  chatMessages: ChatMessage[];
  sendChatMessage: (recipientId: string, content: string, attachmentName?: string, isAnnouncement?: boolean) => ChatMessage;
  markChatRead: (targetId: string) => void;
  unreadChatCount: number;

  // Meetings
  addMeeting: (meeting: Omit<Meeting, 'id' | 'created_at'>) => Meeting;
  updateMeeting: (id: string, meeting: Partial<Meeting>) => void;
  deleteMeeting: (id: string) => void;

  // Work Items (Bills & Works)
  addWorkItem: (item: Omit<WorkItem, 'id' | 'created_at'>) => WorkItem;
  updateWorkItem: (id: string, item: Partial<WorkItem>) => void;
  deleteWorkItem: (id: string) => void;
  toggleWorkItemStatus: (id: string) => void;

  // ITR Docs
  getDocsForClient: (clientId: string) => ITRDocument[];
  updateDocStatus: (clientId: string, docId: string, status: DocStatus) => void;
  addCustomDoc: (clientId: string, name: string) => void;
  deleteDoc: (clientId: string, docId: string) => void;

  // Notes
  getNotesForClient: (clientId: string) => ClientNote[];
  addNote: (clientId: string, content: string) => void;
  updateNote: (clientId: string, noteId: string, content: string) => void;
  deleteNote: (clientId: string, noteId: string) => void;
  togglePinNote: (clientId: string, noteId: string) => void;

  // Activities
  getActivitiesForClient: (clientId: string) => ClientActivity[];
  addActivity: (clientId: string, action: ClientActivity['action'], details?: Record<string, any>) => void;

  // Team
  addTeamMember: (name: string, email: string, role: TeamMember['role']) => void;
  deleteTeamMember: (id: string) => void;

  // Attendance
  recordAttendance: (record: Omit<AttendanceRecord, 'id'>) => void;
  toggleCheckIn: (
    userId: string, 
    locationData?: { 
      location?: string; 
      latitude?: number; 
      longitude?: number; 
      accuracy?: number; 
      maps_url?: string;
      location_type?: 'office' | 'client_site' | 'remote' | 'field';
      notes?: string; 
    }
  ) => void;

  // Reset / Refresh
  resetData: () => void;

  // Metrics
  metrics: {
    totalClients: number;
    taxAuditsCount: number;
    pendingTaxAudits: number;
    certificatesCount: number;
    issuedCertificatesCount: number;
    pendingTasks: number;
    completedTasks: number;
    overdueTasks: number;
    todayMeetings: number;
    pendingBillsAmount: number;
    pendingWorksCount: number;
  };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [clients, setClients] = useState<Client[]>(() => storage.getClients());
  const [taxAudits, setTaxAudits] = useState<TaxAuditRecord[]>(() => storage.getTaxAudits());
  const [certificates, setCertificates] = useState<CertificateRecord[]>(() => storage.getCertificates());
  const [tasks, setTasks] = useState<Task[]>(() => storage.getTasks());
  const [meetings, setMeetings] = useState<Meeting[]>(() => storage.getMeetings());
  const [workItems, setWorkItems] = useState<WorkItem[]>(() => storage.getWorkItems());
  const [team, setTeam] = useState<TeamMember[]>(() => storage.getTeam());
  const [itrDocs, setItrDocs] = useState<Record<string, ITRDocument[]>>(() => storage.getITRDocs());
  const [notes, setNotes] = useState<Record<string, ClientNote[]>>(() => storage.getNotes());
  const [activities, setActivities] = useState<Record<string, ClientActivity[]>>(() => storage.getActivities());
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => storage.getAttendance());
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => storage.getChatMessages());

  // Save to storage upon updates
  useEffect(() => storage.saveClients(clients), [clients]);
  useEffect(() => storage.saveTaxAudits(taxAudits), [taxAudits]);
  useEffect(() => storage.saveCertificates(certificates), [certificates]);
  useEffect(() => storage.saveTasks(tasks), [tasks]);
  useEffect(() => storage.saveMeetings(meetings), [meetings]);
  useEffect(() => storage.saveWorkItems(workItems), [workItems]);
  useEffect(() => storage.saveTeam(team), [team]);
  useEffect(() => storage.saveITRDocs(itrDocs), [itrDocs]);
  useEffect(() => storage.saveNotes(notes), [notes]);
  useEffect(() => storage.saveActivities(activities), [activities]);
  useEffect(() => storage.saveAttendance(attendance), [attendance]);
  useEffect(() => storage.saveChatMessages(chatMessages), [chatMessages]);

  // Clients Map
  const clientsMap = useMemo(() => {
    const map = new Map<string, Client>();
    clients.forEach((c) => map.set(c.id, c));
    return map;
  }, [clients]);

  // Team Map
  const teamMap = useMemo(() => {
    const map = new Map<string, TeamMember>();
    team.forEach((m) => map.set(m.id, m));
    return map;
  }, [team]);

  const tasksWithClients = useMemo(() => {
    return tasks.map((t) => {
      const assignedMember = t.assigned_to ? teamMap.get(t.assigned_to) : null;
      return {
        ...t,
        client: t.client_id ? clientsMap.get(t.client_id) || null : null,
        assigned_to_name: t.assigned_to_name || (assignedMember ? assignedMember.display_name : undefined),
      };
    });
  }, [tasks, clientsMap, teamMap]);

  // Role-Aware Task Visibility:
  // Admins & Managing Partners see ALL tasks.
  // Employees & Articled Assistants ONLY see tasks assigned to them or created by them.
  const visibleTasks = useMemo(() => {
    if (!user) return tasksWithClients;
    const isAdmin = user.role === 'partner' || user.role === 'admin';
    if (isAdmin) {
      return tasksWithClients;
    }
    return tasksWithClients.filter(
      (t) => t.assigned_to === user.id || t.user_id === user.id
    );
  }, [tasksWithClients, user]);

  // Role-Aware Client Visibility:
  // Admins see all practice clients.
  // Employees ONLY see clients assigned to them.
  const visibleClients = useMemo(() => {
    if (!user) return clients;
    const isAdmin = user.role === 'partner' || user.role === 'admin';
    if (isAdmin) return clients;
    return clients.filter((c) => c.assigned_to === user.id);
  }, [clients, user]);

  const meetingsWithClients = useMemo(() => {
    return meetings.map((m) => ({
      ...m,
      client: m.client_id ? clientsMap.get(m.client_id) || null : null,
    }));
  }, [meetings, clientsMap]);

  const workItemsWithClients = useMemo(() => {
    return workItems.map((w) => ({
      ...w,
      client: w.client_id ? clientsMap.get(w.client_id) || null : null,
    }));
  }, [workItems, clientsMap]);

  // Client Methods
  const addClient = (clientData: Omit<Client, 'id' | 'created_at' | 'updated_at'>): Client => {
    const id = `cli_${Date.now()}`;
    const newClient: Client = {
      ...clientData,
      id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setClients((prev) => [newClient, ...prev]);

    const defaultDocs: ITRDocument[] = [
      { id: `doc_${Date.now()}_1`, client_id: id, name: 'Form 26AS & AIS / TIS Downloaded', status: 'pending_client', sort_order: 1 },
      { id: `doc_${Date.now()}_2`, client_id: id, name: 'Bank Statements & Interest Certificates', status: 'pending_client', sort_order: 2 },
      { id: `doc_${Date.now()}_3`, client_id: id, name: 'Form 16 / 16A TDS Certificates', status: 'pending_client', sort_order: 3 },
      { id: `doc_${Date.now()}_4`, client_id: id, name: 'Tax Audit / Computation Draft', status: 'not_applicable', sort_order: 4 },
    ];
    setItrDocs((prev) => ({ ...prev, [id]: defaultDocs }));

    addActivity(id, 'client_created', { name: newClient.name });
    return newClient;
  };

  const updateClient = (id: string, clientData: Partial<Client>) => {
    setClients((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...clientData, updated_at: new Date().toISOString() } : c))
    );
  };

  const deleteClient = (id: string) => {
    setClients((prev) => prev.filter((c) => c.id !== id));
    setTaxAudits((prev) => prev.filter((t) => t.client_id !== id));
    setCertificates((prev) => prev.filter((c) => c.client_id !== id));
    setTasks((prev) => prev.filter((t) => t.client_id !== id));
    setMeetings((prev) => prev.filter((m) => m.client_id !== id));
    setWorkItems((prev) => prev.filter((w) => w.client_id !== id));
  };

  const getClientById = (id: string) => clients.find((c) => c.id === id);

  const bulkImportClients = (newClients: Partial<Client>[]) => {
    const created: Client[] = [];
    const newDocsMap = { ...itrDocs };

    newClients.forEach((item, index) => {
      if (!item.name || !item.pan) return;
      const id = `cli_${Date.now()}_${index}`;
      const c: Client = {
        id,
        name: item.name,
        pan: item.pan.toUpperCase(),
        mobile: item.mobile || item.contact_phone || '9800000000',
        contact_phone: item.contact_phone || item.mobile || '9800000000',
        contact_email: item.contact_email || '',
        assessment_year: item.assessment_year || '2026-27',
        itr_type: item.itr_type || 'ITR-1',
        filing_status: (item.filing_status as ITRFilingStatus) || 'not_started',
        assigned_to: item.assigned_to || user?.id || null,
        category: item.category || 'General',
        notes: item.notes || '',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      created.push(c);
      newDocsMap[id] = [
        { id: `doc_${id}_1`, client_id: id, name: 'Form 26AS & AIS / TIS', status: 'pending_client', sort_order: 1 },
        { id: `doc_${id}_2`, client_id: id, name: 'Bank Statement Analysis', status: 'pending_client', sort_order: 2 },
      ];
    });

    setClients((prev) => [...created, ...prev]);
    setItrDocs(newDocsMap);
  };

  // Tax Audit Methods
  const addTaxAudit = (auditData: Omit<TaxAuditRecord, 'id' | 'created_at' | 'updated_at'>): TaxAuditRecord => {
    const newAudit: TaxAuditRecord = {
      ...auditData,
      id: `ta_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setTaxAudits((prev) => [newAudit, ...prev]);
    return newAudit;
  };

  const updateTaxAudit = (id: string, auditData: Partial<TaxAuditRecord>) => {
    setTaxAudits((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...auditData, updated_at: new Date().toISOString() } : a))
    );
  };

  const deleteTaxAudit = (id: string) => {
    setTaxAudits((prev) => prev.filter((a) => a.id !== id));
  };

  // Certificate Methods
  const addCertificate = (certData: Omit<CertificateRecord, 'id' | 'created_at' | 'updated_at'>): CertificateRecord => {
    const newCert: CertificateRecord = {
      ...certData,
      id: `cert_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setCertificates((prev) => [newCert, ...prev]);
    return newCert;
  };

  const updateCertificate = (id: string, certData: Partial<CertificateRecord>) => {
    setCertificates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...certData, updated_at: new Date().toISOString() } : c))
    );
  };

  const deleteCertificate = (id: string) => {
    setCertificates((prev) => prev.filter((c) => c.id !== id));
  };

  // Task Methods
  const addTask = (taskData: Omit<Task, 'id' | 'created_at'>): Task => {
    const newTask: Task = {
      ...taskData,
      id: `tsk_${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
    return newTask;
  };

  const updateTask = (id: string, taskData: Partial<Task>) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...taskData } : t)));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleTaskStatus = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextStatus: TaskStatus = t.status === 'done' ? 'pending' : 'done';
          return {
            ...t,
            status: nextStatus,
            completed_at: nextStatus === 'done' ? new Date().toISOString() : null,
          };
        }
        return t;
      })
    );
  };

  const reassignTask = (taskId: string, newAssigneeId: string, reason?: string) => {
    const targetMember = team.find((m) => m.id === newAssigneeId);
    const targetName = targetMember ? targetMember.display_name : 'Staff Member';
    const currentUserName = user?.display_name || 'Admin';

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const oldAssigneeName = t.assigned_to_name || team.find((m) => m.id === t.assigned_to)?.display_name || 'Previous Assignee';
          const newHistoryItem: TaskReassignment = {
            id: `rh_${Date.now()}`,
            task_id: taskId,
            from_user_id: t.assigned_to,
            from_user_name: oldAssigneeName,
            to_user_id: newAssigneeId,
            to_user_name: targetName,
            reassigned_by_id: user?.id || 'admin',
            reassigned_by_name: currentUserName,
            reason: reason || 'Reassigned by practice partner',
            created_at: new Date().toISOString(),
          };

          const systemComment: TaskComment = {
            id: `tn_${Date.now()}`,
            task_id: taskId,
            author_id: user?.id || 'admin',
            author_name: currentUserName,
            author_role: user?.role || 'partner',
            content: `🔄 Task reassigned from ${oldAssigneeName} to ${targetName}. ${reason ? `Reason: ${reason}` : ''}`,
            type: 'system',
            created_at: new Date().toISOString(),
          };

          return {
            ...t,
            assigned_to: newAssigneeId,
            assigned_to_name: targetName,
            assigned_by: user?.id || 'admin',
            assigned_by_name: currentUserName,
            reassignment_history: [newHistoryItem, ...(t.reassignment_history || [])],
            task_notes: [...(t.task_notes || []), systemComment],
          };
        }
        return t;
      })
    );
  };

  const addTaskComment = (
    taskId: string, 
    content: string, 
    type: 'note' | 'query' | 'resolution' | 'system' = 'note', 
    isQuery: boolean = false
  ) => {
    if (!content.trim()) return;
    const newComment: TaskComment = {
      id: `tn_${Date.now()}`,
      task_id: taskId,
      author_id: user?.id || 'user_ca_pro_01',
      author_name: user?.display_name || 'Staff Member',
      author_role: user?.role || 'employee',
      content: content.trim(),
      type,
      is_query: isQuery || type === 'query',
      is_resolved: false,
      created_at: new Date().toISOString(),
    };

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedNotes = [...(t.task_notes || []), newComment];
          const pendingQueries = updatedNotes.filter((n) => n.is_query && !n.is_resolved).length;
          return {
            ...t,
            task_notes: updatedNotes,
            queries_count: updatedNotes.filter((n) => n.is_query).length,
            has_pending_query: pendingQueries > 0,
          };
        }
        return t;
      })
    );
  };

  const resolveTaskQuery = (taskId: string, commentId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedNotes = (t.task_notes || []).map((n) =>
            n.id === commentId ? { ...n, is_resolved: true } : n
          );
          const pendingQueries = updatedNotes.filter((n) => n.is_query && !n.is_resolved).length;
          return {
            ...t,
            task_notes: updatedNotes,
            has_pending_query: pendingQueries > 0,
          };
        }
        return t;
      })
    );
  };

  // Chat & Messaging Methods
  const sendChatMessage = (
    recipientId: string, 
    content: string, 
    attachmentName?: string, 
    isAnnouncement?: boolean
  ): ChatMessage => {
    const recipientMember = recipientId === 'all' ? null : team.find((m) => m.id === recipientId);
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender_id: user?.id || 'user_ca_pro_01',
      sender_name: user?.display_name || 'CA Chinar Gulati',
      sender_role: user?.role || 'partner',
      recipient_id: recipientId,
      recipient_name: recipientMember ? recipientMember.display_name : recipientId === 'all' ? 'All Staff' : undefined,
      content: content.trim(),
      attachment_name: attachmentName,
      is_announcement: isAnnouncement || recipientId === 'all',
      created_at: new Date().toISOString(),
      read_by: [user?.id || 'user_ca_pro_01'],
    };
    setChatMessages((prev) => [...prev, newMsg]);
    return newMsg;
  };

  const markChatRead = (targetId: string) => {
    if (!user) return;
    setChatMessages((prev) =>
      prev.map((m) => {
        const isMatch = m.recipient_id === targetId || m.sender_id === targetId || (targetId === 'all' && m.recipient_id === 'all');
        if (isMatch && !m.read_by?.includes(user.id)) {
          return {
            ...m,
            read_by: [...(m.read_by || []), user.id],
          };
        }
        return m;
      })
    );
  };

  const unreadChatCount = useMemo(() => {
    if (!user) return 0;
    return chatMessages.filter(
      (m) => (m.recipient_id === 'all' || m.recipient_id === user.id) && m.sender_id !== user.id && !m.read_by?.includes(user.id)
    ).length;
  }, [chatMessages, user]);

  // Meeting Methods
  const addMeeting = (meetingData: Omit<Meeting, 'id' | 'created_at'>): Meeting => {
    const newMeeting: Meeting = {
      ...meetingData,
      id: `meet_${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    setMeetings((prev) => [newMeeting, ...prev]);
    return newMeeting;
  };

  const updateMeeting = (id: string, meetingData: Partial<Meeting>) => {
    setMeetings((prev) => prev.map((m) => (m.id === id ? { ...m, ...meetingData } : m)));
  };

  const deleteMeeting = (id: string) => {
    setMeetings((prev) => prev.filter((m) => m.id !== id));
  };

  // Work Item Methods
  const addWorkItem = (itemData: Omit<WorkItem, 'id' | 'created_at'>): WorkItem => {
    const newItem: WorkItem = {
      ...itemData,
      id: `wrk_${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    setWorkItems((prev) => [newItem, ...prev]);
    return newItem;
  };

  const updateWorkItem = (id: string, itemData: Partial<WorkItem>) => {
    setWorkItems((prev) => prev.map((w) => (w.id === id ? { ...w, ...itemData } : w)));
  };

  const deleteWorkItem = (id: string) => {
    setWorkItems((prev) => prev.filter((w) => w.id !== id));
  };

  const toggleWorkItemStatus = (id: string) => {
    setWorkItems((prev) =>
      prev.map((w) => {
        if (w.id === id) {
          const nextStatus: WorkItemStatus = w.status === 'done' ? 'pending' : 'done';
          return { ...w, status: nextStatus };
        }
        return w;
      })
    );
  };

  // Document Methods
  const getDocsForClient = (clientId: string): ITRDocument[] => {
    return itrDocs[clientId] || [];
  };

  const updateDocStatus = (clientId: string, docId: string, status: DocStatus) => {
    setItrDocs((prev) => {
      const clientDocs = prev[clientId] || [];
      const updated = clientDocs.map((d) => (d.id === docId ? { ...d, status, updated_at: new Date().toISOString() } : d));
      return { ...prev, [clientId]: updated };
    });
    const doc = (itrDocs[clientId] || []).find((d) => d.id === docId);
    if (doc) {
      addActivity(clientId, 'doc_status_changed', { doc: doc.name, from: doc.status, to: status });
    }
  };

  const addCustomDoc = (clientId: string, name: string) => {
    const clientDocs = itrDocs[clientId] || [];
    const newDoc: ITRDocument = {
      id: `doc_${Date.now()}`,
      client_id: clientId,
      name,
      status: 'pending_client',
      is_custom: true,
      sort_order: clientDocs.length + 1,
      updated_at: new Date().toISOString(),
    };
    setItrDocs((prev) => ({
      ...prev,
      [clientId]: [...(prev[clientId] || []), newDoc],
    }));
    addActivity(clientId, 'doc_added', { name });
  };

  const deleteDoc = (clientId: string, docId: string) => {
    setItrDocs((prev) => ({
      ...prev,
      [clientId]: (prev[clientId] || []).filter((d) => d.id !== docId),
    }));
  };

  // Notes Methods
  const getNotesForClient = (clientId: string): ClientNote[] => {
    return notes[clientId] || [];
  };

  const addNote = (clientId: string, content: string) => {
    const newNote: ClientNote = {
      id: `not_${Date.now()}`,
      client_id: clientId,
      author_id: user?.id || 'user_ca_pro_01',
      content,
      is_pinned: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setNotes((prev) => ({
      ...prev,
      [clientId]: [newNote, ...(prev[clientId] || [])],
    }));
    addActivity(clientId, 'note_added');
  };

  const updateNote = (clientId: string, noteId: string, content: string) => {
    setNotes((prev) => ({
      ...prev,
      [clientId]: (prev[clientId] || []).map((n) =>
        n.id === noteId ? { ...n, content, updated_at: new Date().toISOString() } : n
      ),
    }));
  };

  const deleteNote = (clientId: string, noteId: string) => {
    setNotes((prev) => ({
      ...prev,
      [clientId]: (prev[clientId] || []).filter((n) => n.id !== noteId),
    }));
  };

  const togglePinNote = (clientId: string, noteId: string) => {
    setNotes((prev) => ({
      ...prev,
      [clientId]: (prev[clientId] || []).map((n) =>
        n.id === noteId ? { ...n, is_pinned: !n.is_pinned } : n
      ),
    }));
  };

  // Activity Methods
  const getActivitiesForClient = (clientId: string): ClientActivity[] => {
    return activities[clientId] || [];
  };

  const addActivity = (clientId: string, action: ClientActivity['action'], details?: Record<string, any>) => {
    const newActivity: ClientActivity = {
      id: `act_${Date.now()}`,
      client_id: clientId,
      actor_id: user?.id || 'user_ca_pro_01',
      action,
      details,
      created_at: new Date().toISOString(),
    };
    setActivities((prev) => ({
      ...prev,
      [clientId]: [newActivity, ...(prev[clientId] || [])],
    }));
  };

  // Team Methods
  const addTeamMember = (name: string, email: string, role: TeamMember['role']) => {
    const colors = ['bg-purple-600', 'bg-sky-600', 'bg-teal-600', 'bg-orange-600', 'bg-pink-600'];
    const newMember: TeamMember = {
      id: `user_team_${Date.now()}`,
      email,
      display_name: name,
      role,
      firm_owner_id: user?.id || 'user_ca_pro_01',
      status: 'active',
      tasks_count: 0,
      clients_count: 0,
      avatar_color: colors[team.length % colors.length],
      created_at: new Date().toISOString(),
    };
    setTeam((prev) => [...prev, newMember]);
  };

  const deleteTeamMember = (id: string) => {
    setTeam((prev) => prev.filter((m) => m.id !== id));
  };

  // Attendance Methods
  const recordAttendance = (record: Omit<AttendanceRecord, 'id'>) => {
    const newRec: AttendanceRecord = {
      ...record,
      id: `att_${Date.now()}`,
    };
    setAttendance((prev) => [newRec, ...prev]);
  };

  const toggleCheckIn = (
    userId: string,
    locationData?: {
      location?: string;
      latitude?: number;
      longitude?: number;
      accuracy?: number;
      maps_url?: string;
      location_type?: 'office' | 'client_site' | 'remote' | 'field';
      notes?: string;
    }
  ) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const existing = attendance.find((a) => a.user_id === userId && a.date === todayStr);

    if (existing) {
      if (existing.check_out === '—') {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        setAttendance((prev) =>
          prev.map((a) =>
            a.id === existing.id
              ? {
                  ...a,
                  check_out: timeStr,
                  total_hours: 8.5,
                  ...(locationData?.location ? { location: locationData.location } : {}),
                  ...(locationData?.latitude ? { latitude: locationData.latitude } : {}),
                  ...(locationData?.longitude ? { longitude: locationData.longitude } : {}),
                  ...(locationData?.maps_url ? { maps_url: locationData.maps_url } : {}),
                }
              : a
          )
        );
      }
    } else {
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const targetUser = team.find((t) => t.id === userId) || user;
      recordAttendance({
        user_id: userId,
        user_name: targetUser?.display_name || 'Staff Member',
        date: todayStr,
        check_in: timeStr,
        check_out: '—',
        total_hours: 0,
        status: locationData?.location_type === 'remote' ? 'remote' : 'present',
        notes: locationData?.notes || 'Punch in with GPS Location',
        location: locationData?.location || 'New Delhi, India',
        latitude: locationData?.latitude || 28.6315,
        longitude: locationData?.longitude || 77.2167,
        accuracy: locationData?.accuracy || 10,
        maps_url:
          locationData?.maps_url ||
          (locationData?.latitude && locationData?.longitude
            ? `https://www.google.com/maps?q=${locationData.latitude},${locationData.longitude}`
            : 'https://www.google.com/maps?q=28.6315,77.2167'),
        location_type: locationData?.location_type || 'office',
      });
    }
  };

  const resetData = () => {
    storage.resetToDemo();
    setClients(storage.getClients());
    setTaxAudits(storage.getTaxAudits());
    setCertificates(storage.getCertificates());
    setTasks(storage.getTasks());
    setMeetings(storage.getMeetings());
    setWorkItems(storage.getWorkItems());
    setTeam(storage.getTeam());
    setItrDocs(storage.getITRDocs());
    setNotes(storage.getNotes());
    setActivities(storage.getActivities());
    setAttendance(storage.getAttendance());
  };

  // Computed Metrics (Role-Aware)
  const metrics = useMemo(() => {
    const activeTasks = visibleTasks;
    const pendingTasks = activeTasks.filter((t) => t.status !== 'done').length;
    const completedTasks = activeTasks.filter((t) => t.status === 'done').length;
    const overdueTasks = activeTasks.filter((t) => {
      if (t.status === 'done' || !t.due_at) return false;
      const d = new Date(t.due_at);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return d < today;
    }).length;

    const todayStr = new Date().toISOString().split('T')[0];
    const todayMeetings = meetings.filter((m) => m.start_at.startsWith(todayStr)).length;

    const pendingBillsAmount = workItems
      .filter((w) => w.type === 'bill' && w.status === 'pending')
      .reduce((sum, w) => sum + (Number(w.amount) || 0), 0);

    const pendingWorksCount = workItems.filter((w) => w.type === 'work' && w.status === 'pending').length;
    const pendingTaxAudits = taxAudits.filter((a) => a.status !== 'filed' && a.status !== 'completed').length;
    const issuedCertificatesCount = certificates.filter((c) => c.status === 'issued').length;

    return {
      totalClients: visibleClients.length,
      taxAuditsCount: taxAudits.length,
      pendingTaxAudits,
      certificatesCount: certificates.length,
      issuedCertificatesCount,
      pendingTasks,
      completedTasks,
      overdueTasks,
      todayMeetings,
      pendingBillsAmount,
      pendingWorksCount,
    };
  }, [visibleClients, taxAudits, certificates, visibleTasks, meetings, workItems]);

  return (
    <DataContext.Provider
      value={{
        clients: visibleClients,
        taxAudits,
        certificates,
        tasks: visibleTasks,
        allTasks: tasksWithClients,
        meetings: meetingsWithClients,
        workItems: workItemsWithClients,
        team,
        attendance,
        addClient,
        updateClient,
        deleteClient,
        getClientById,
        bulkImportClients,
        addTaxAudit,
        updateTaxAudit,
        deleteTaxAudit,
        addCertificate,
        updateCertificate,
        deleteCertificate,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskStatus,
        reassignTask,
        addTaskComment,
        resolveTaskQuery,
        chatMessages,
        sendChatMessage,
        markChatRead,
        unreadChatCount,
        addMeeting,
        updateMeeting,
        deleteMeeting,
        addWorkItem,
        updateWorkItem,
        deleteWorkItem,
        toggleWorkItemStatus,
        getDocsForClient,
        updateDocStatus,
        addCustomDoc,
        deleteDoc,
        getNotesForClient,
        addNote,
        updateNote,
        deleteNote,
        togglePinNote,
        getActivitiesForClient,
        addActivity,
        addTeamMember,
        deleteTeamMember,
        recordAttendance,
        toggleCheckIn,
        resetData,
        metrics,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
