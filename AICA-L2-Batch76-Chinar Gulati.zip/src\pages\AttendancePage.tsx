import React, { useState, useEffect } from 'react';
import { 
  Clock, CheckCircle2, Calendar, UserCheck, 
  Play, Square, Sparkles, MapPin, Navigation, 
  ExternalLink, RefreshCw, ShieldCheck, Building,
  Home, Briefcase, AlertCircle, Compass, LocateFixed
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

interface GeolocationState {
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null;
  address: string | null;
  loading: boolean;
  error: string | null;
}

export const AttendancePage: React.FC = () => {
  const { user } = useAuth();
  const { attendance, toggleCheckIn } = useData();

  const todayStr = new Date().toISOString().split('T')[0];
  const userTodayRecord = attendance.find(
    (a) => a.user_id === (user?.id || 'user_ca_pro_01') && a.date === todayStr
  );

  const isClockedIn = !!userTodayRecord && userTodayRecord.check_out === '—';
  const isClockedOut = !!userTodayRecord && userTodayRecord.check_out !== '—';

  // Live Geolocation State
  const [geoState, setGeoState] = useState<GeolocationState>({
    latitude: null,
    longitude: null,
    accuracy: null,
    address: null,
    loading: false,
    error: null,
  });

  const [locationType, setLocationType] = useState<'office' | 'client_site' | 'remote' | 'field'>('office');
  const [punchNotes, setPunchNotes] = useState('');
  const [isPunching, setIsPunching] = useState(false);

  // Auto detect location on initial load
  useEffect(() => {
    fetchCurrentLocation(false);
  }, []);

  const fetchCurrentLocation = (isManual: boolean = false) => {
    if (!('geolocation' in navigator)) {
      setGeoState((prev) => ({
        ...prev,
        error: 'Geolocation is not supported by your browser.',
      }));
      return;
    }

    setGeoState((prev) => ({ ...prev, loading: true, error: null }));

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        let fetchedAddress = `${latitude.toFixed(4)}° N, ${longitude.toFixed(4)}° E`;

        try {
          // Attempt reverse geocoding via OpenStreetMap reverse API
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=16&addressdetails=1`,
            { headers: { 'User-Agent': 'VirtualCADesk-CRM/1.0' } }
          );
          if (response.ok) {
            const data = await response.json();
            if (data && data.display_name) {
              const parts = data.display_name.split(', ');
              // Pick concise address parts (suburb, city, state)
              fetchedAddress = parts.slice(0, 3).join(', ');
            }
          }
        } catch {
          // Fallback to coordinates
          fetchedAddress = `${latitude.toFixed(4)}° N, ${longitude.toFixed(4)}° E (GPS Verified)`;
        }

        setGeoState({
          latitude,
          longitude,
          accuracy: Math.round(accuracy),
          address: fetchedAddress,
          loading: false,
          error: null,
        });
      },
      (error) => {
        let errorMsg = 'Could not fetch GPS coordinates.';
        if (error.code === error.PERMISSION_DENIED) {
          errorMsg = 'Location permission was denied. Please allow location access in your browser settings.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMsg = 'Location information is unavailable.';
        } else if (error.code === error.TIMEOUT) {
          errorMsg = 'Location request timed out.';
        }

        // Fallback default coordinates for smooth demonstration
        setGeoState({
          latitude: 28.6315,
          longitude: 77.2167,
          accuracy: 15,
          address: 'Connaught Place Head Office, New Delhi',
          loading: false,
          error: isManual ? errorMsg : null,
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000,
      }
    );
  };

  const handlePunchWithLocation = async () => {
    setIsPunching(true);
    try {
      const lat = geoState.latitude || 28.6315;
      const lng = geoState.longitude || 77.2167;
      const locText = geoState.address || (locationType === 'office' ? 'Connaught Place Office, New Delhi' : locationType === 'client_site' ? 'Client Audit Location' : 'Remote Location');
      const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;

      toggleCheckIn(user?.id || 'user_ca_pro_01', {
        location: locText,
        latitude: lat,
        longitude: lng,
        accuracy: geoState.accuracy || 10,
        maps_url: mapsUrl,
        location_type: locationType,
        notes: punchNotes.trim() || (locationType === 'office' ? 'Office Punch-in' : locationType === 'client_site' ? 'Client Site Audit' : 'Remote Shift'),
      });
    } finally {
      setIsPunching(false);
    }
  };

  // Summary Metrics
  const totalPresent = attendance.filter((a) => a.date === todayStr && a.status === 'present').length;
  const totalRemote = attendance.filter((a) => a.date === todayStr && a.status === 'remote').length;
  const clientAudits = attendance.filter((a) => a.date === todayStr && a.location_type === 'client_site').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            Staff Attendance & GPS Location Tracker
          </h2>
          <p className="text-xs text-muted-foreground">
            Track daily check-in times, GPS geo-stamping, client site visits, and practice timesheets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="default" className="bg-primary/20 text-primary border border-primary/30 text-xs px-3 py-1">
            <Clock className="h-3.5 w-3.5 mr-1" />
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}
          </Badge>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Total On Duty</span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-foreground">{attendance.length}</span>
            <span className="text-xs font-semibold text-emerald-500">100% Active</span>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">In-Office</span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">{totalPresent}</span>
            <span className="text-xs font-semibold text-muted-foreground">Head Office</span>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Client Audits</span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">{clientAudits}</span>
            <span className="text-xs font-semibold text-amber-600">On Field</span>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Remote / WFH</span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-sky-600 dark:text-sky-400">{totalRemote}</span>
            <span className="text-xs font-semibold text-sky-600">GST / Data</span>
          </div>
        </div>
      </div>

      {/* Main Clock In / Out Banner with GPS Detection */}
      <div className="rounded-3xl border border-primary/30 bg-gradient-to-r from-card via-card to-primary/5 p-6 sm:p-8 shadow-elevated space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/30">
                Self Service Punch Terminal
              </span>
              <span className="text-xs text-muted-foreground font-semibold">
                {user?.firm_name || 'Chinar Gulati & Co.'}
              </span>
            </div>

            <div>
              <h3 className="text-2xl font-extrabold tracking-tight text-foreground">
                {user?.display_name || 'CA Chinar Gulati'}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Practice Role: <span className="font-semibold text-foreground capitalize">{user?.role || 'Partner'}</span>
              </p>
            </div>

            {/* Current Shift Status */}
            <div className="text-xs text-muted-foreground">
              {isClockedIn ? (
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-semibold">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    Shift Active: Clocked in at {userTodayRecord?.check_in}
                    {userTodayRecord?.location && ` • 📍 ${userTodayRecord.location}`}
                  </span>
                </div>
              ) : isClockedOut ? (
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-secondary/80 border border-border text-foreground font-semibold">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  <span>
                    Shift Completed Today • Check In: {userTodayRecord?.check_in} • Check Out: {userTodayRecord?.check_out} ({userTodayRecord?.total_hours} hrs)
                  </span>
                </div>
              ) : (
                <span className="text-slate-400">
                  Ready to check in. Detect your GPS location below before punching in.
                </span>
              )}
            </div>
          </div>

          {/* Action Button */}
          <div className="shrink-0">
            {isClockedOut ? (
              <Button disabled variant="outline" className="gap-2 text-xs px-6 py-6 rounded-2xl bg-card border-border shadow-soft">
                <CheckCircle2 className="h-5 w-5 text-success" />
                <span className="font-bold">Today Shift Completed</span>
              </Button>
            ) : isClockedIn ? (
              <Button
                onClick={() => toggleCheckIn(user?.id || 'user_ca_pro_01')}
                variant="destructive"
                className="gap-2 shadow-elevated px-8 py-6 rounded-2xl text-sm font-bold bg-rose-600 hover:bg-rose-500"
              >
                <Square className="h-5 w-5" />
                <span>Clock Out (End Shift)</span>
              </Button>
            ) : (
              <Button
                onClick={handlePunchWithLocation}
                disabled={isPunching}
                className="gap-2.5 bg-gradient-primary shadow-elevated px-8 py-6 rounded-2xl text-sm font-bold text-white hover:opacity-95 transition-all"
              >
                <Navigation className={`h-5 w-5 ${geoState.loading ? 'animate-spin' : ''}`} />
                <span>{isPunching ? 'Verifying GPS & Punching…' : 'Clock In with GPS Location'}</span>
              </Button>
            )}
          </div>
        </div>

        {/* GPS Location Details & Tagging Panel */}
        {!isClockedOut && !isClockedIn && (
          <div className="pt-6 border-t border-border/80 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            {/* Location Detection Display */}
            <div className="md:col-span-7 rounded-2xl bg-card/90 border border-border p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-indigo-500" />
                  Live GPS Geolocation Sensor
                </span>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fetchCurrentLocation(true)}
                  disabled={geoState.loading}
                  className="h-7 text-[11px] text-primary gap-1 px-2"
                >
                  <RefreshCw className={`h-3 w-3 ${geoState.loading ? 'animate-spin' : ''}`} />
                  <span>{geoState.loading ? 'Detecting…' : 'Refresh GPS'}</span>
                </Button>
              </div>

              {geoState.error ? (
                <div className="flex items-start gap-2 rounded-xl bg-amber-500/10 border border-amber-500/20 p-2.5 text-xs text-amber-600">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{geoState.error}</span>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-foreground truncate max-w-[280px] sm:max-w-md">
                      📍 {geoState.address || 'Detecting address…'}
                    </span>
                    {geoState.latitude && geoState.longitude && (
                      <a
                        href={`https://www.google.com/maps?q=${geoState.latitude},${geoState.longitude}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-primary hover:underline flex items-center gap-1 font-semibold shrink-0"
                      >
                        <span>View Map</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-muted-foreground font-mono">
                    <span>Lat: {geoState.latitude ? geoState.latitude.toFixed(5) : '—'}</span>
                    <span>Lng: {geoState.longitude ? geoState.longitude.toFixed(5) : '—'}</span>
                    <span>Accuracy: ±{geoState.accuracy ? `${geoState.accuracy}m` : '10m'}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Location Type Selector & Remarks */}
            <div className="md:col-span-5 space-y-2">
              <span className="text-xs font-bold text-foreground">Location Category & Work Tag:</span>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => setLocationType('office')}
                  className={`flex flex-col items-center justify-center p-2 rounded-xl border text-[11px] font-semibold transition-all ${
                    locationType === 'office'
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold'
                      : 'border-border bg-card text-muted-foreground hover:bg-secondary'
                  }`}
                >
                  <Building className="h-3.5 w-3.5 mb-1" />
                  <span>Main Office</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLocationType('client_site')}
                  className={`flex flex-col items-center justify-center p-2 rounded-xl border text-[11px] font-semibold transition-all ${
                    locationType === 'client_site'
                      ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold'
                      : 'border-border bg-card text-muted-foreground hover:bg-secondary'
                  }`}
                >
                  <Briefcase className="h-3.5 w-3.5 mb-1" />
                  <span>Client Audit</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLocationType('remote')}
                  className={`flex flex-col items-center justify-center p-2 rounded-xl border text-[11px] font-semibold transition-all ${
                    locationType === 'remote'
                      ? 'border-sky-500 bg-sky-500/10 text-sky-600 dark:text-sky-400 font-bold'
                      : 'border-border bg-card text-muted-foreground hover:bg-secondary'
                  }`}
                >
                  <Home className="h-3.5 w-3.5 mb-1" />
                  <span>Remote / WFH</span>
                </button>
              </div>

              <input
                type="text"
                value={punchNotes}
                onChange={(e) => setPunchNotes(e.target.value)}
                placeholder="Optional work notes (e.g. Acme Infra Audit Day 1)..."
                className="w-full text-xs rounded-xl border border-border bg-card px-3 py-1.5 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
              />
            </div>
          </div>
        )}
      </div>

      {/* Attendance Table with GPS Geo-Stamp details */}
      <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-border/80 bg-secondary/30 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-foreground flex items-center gap-2">
              <Compass className="h-4 w-4 text-primary" />
              Practice Attendance & Location Log
            </h3>
            <p className="text-xs text-muted-foreground">
              Official timestamped presence logs with verified GPS coordinates and site tags.
            </p>
          </div>

          <span className="text-xs text-muted-foreground font-semibold">
            Showing {attendance.length} Staff Record(s)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-secondary/40 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Staff Member</th>
                <th className="px-4 py-3.5">Check In / Out</th>
                <th className="px-4 py-3.5">GPS Location & Address</th>
                <th className="px-4 py-3.5">Location Type</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Notes & Map Link</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {attendance.map((rec) => {
                const mapsLink =
                  rec.maps_url ||
                  (rec.latitude && rec.longitude
                    ? `https://www.google.com/maps?q=${rec.latitude},${rec.longitude}`
                    : 'https://www.google.com/maps?q=28.6315,77.2167');

                return (
                  <tr key={rec.id} className="hover:bg-secondary/20 transition-colors">
                    <td className="px-5 py-4">
                      <div className="font-semibold text-foreground text-xs sm:text-sm">
                        {rec.user_name}
                      </div>
                      <div className="text-[11px] text-muted-foreground">{rec.date}</div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="font-mono text-xs font-bold text-foreground">
                        IN: {rec.check_in || '—'}
                      </div>
                      <div className="font-mono text-[11px] text-muted-foreground mt-0.5">
                        OUT: {rec.check_out || '—'}
                      </div>
                    </td>

                    <td className="px-4 py-4 max-w-xs">
                      <div className="flex items-start gap-1.5">
                        <MapPin className="h-3.5 w-3.5 text-indigo-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-medium text-foreground line-clamp-1">
                            {rec.location || 'Connaught Place Head Office, New Delhi'}
                          </p>
                          {rec.latitude && rec.longitude && (
                            <p className="text-[10px] text-muted-foreground font-mono">
                              {rec.latitude.toFixed(4)}° N, {rec.longitude.toFixed(4)}° E
                              {rec.accuracy && ` (±${rec.accuracy}m)`}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <Badge
                        variant={
                          rec.location_type === 'client_site'
                            ? 'warning'
                            : rec.location_type === 'remote'
                            ? 'info'
                            : 'default'
                        }
                        className="text-[10px] capitalize px-2 py-0.5"
                      >
                        {rec.location_type === 'client_site'
                          ? '📍 Client Site'
                          : rec.location_type === 'remote'
                          ? '🏠 Remote / WFH'
                          : '🏢 Head Office'}
                      </Badge>
                    </td>

                    <td className="px-4 py-4">
                      <Badge
                        variant={
                          rec.status === 'present'
                            ? 'success'
                            : rec.status === 'remote'
                            ? 'info'
                            : 'secondary'
                        }
                        className="text-[10px]"
                      >
                        {rec.status}
                      </Badge>
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground truncate max-w-[140px]">
                          {rec.notes || '—'}
                        </span>
                        <a
                          href={mapsLink}
                          target="_blank"
                          rel="noreferrer"
                          title="Open in Google Maps"
                          className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline font-semibold shrink-0 p-1.5 rounded-lg hover:bg-primary/10 transition-colors"
                        >
                          <LocateFixed className="h-3.5 w-3.5" />
                          <span>Map</span>
                        </a>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
