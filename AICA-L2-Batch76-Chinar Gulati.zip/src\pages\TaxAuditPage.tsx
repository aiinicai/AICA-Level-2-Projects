import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, ShieldCheck, CheckCircle2, Clock, 
  AlertCircle, Sparkles, FileText, ChevronRight, Edit2, Trash2 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Select } from '../components/ui/Select';
import { Card, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { TaxAuditRecord, TaxAuditStatus } from '../types';
import { formatCurrency, formatDateTime, ASSESSMENT_YEARS } from '../lib/utils';
import { TaxAuditDialog } from '../components/tax-audit/TaxAuditDialog';

export const TaxAuditPage: React.FC = () => {
  const { taxAudits, deleteTaxAudit } = useData();

  const [selectedAY, setSelectedAY] = useState('2026-27');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingAudit, setEditingAudit] = useState<TaxAuditRecord | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredAudits = useMemo(() => {
    return taxAudits.filter((a) => {
      if (selectedAY && a.assessment_year !== selectedAY) return false;
      if (statusFilter !== 'all' && a.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const clientMatch = a.client_name.toLowerCase().includes(q);
        const panMatch = a.pan.toLowerCase().includes(q);
        const udinMatch = (a.udin || '').toLowerCase().includes(q);
        if (!clientMatch && !panMatch && !udinMatch) return false;
      }
      return true;
    });
  }, [taxAudits, selectedAY, statusFilter, searchQuery]);

  const statusBadges: Record<TaxAuditStatus, { label: string; variant: 'secondary' | 'warning' | 'info' | 'default' | 'success' }> = {
    not_started: { label: 'Not Started', variant: 'secondary' },
    drafting: { label: 'Drafting 3CD', variant: 'warning' },
    partner_review: { label: 'Partner Review', variant: 'info' },
    udin_generated: { label: 'UDIN Generated', variant: 'default' },
    filed: { label: 'Filed on IT Portal', variant: 'success' },
    completed: { label: 'Completed', variant: 'success' },
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Tax Audit Hub (Section 44AB)
          </h2>
          <p className="text-xs text-muted-foreground">
            Form 3CA-3CD & 3CB-3CD disclosures, Clause 44 GST analysis, MSME Sec 43B(h) clearance, and UDIN sign-offs.
          </p>
        </div>

        <Button onClick={() => setShowAddModal(true)} className="gap-1.5 shadow-soft">
          <Plus className="h-4 w-4" />
          <span>New Tax Audit</span>
        </Button>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
        <div className="sm:col-span-2 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by client name, PAN, or UDIN…"
            className="pl-9"
          />
        </div>

        <Select
          value={selectedAY}
          onChange={(e) => setSelectedAY(e.target.value)}
        >
          {ASSESSMENT_YEARS.map((ay) => (
            <option key={ay} value={ay}>
              Assessment Year {ay}
            </option>
          ))}
        </Select>

        <Select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">All Audit Statuses</option>
          <option value="not_started">⚪ Not Started</option>
          <option value="drafting">🟡 Drafting 3CD</option>
          <option value="partner_review">🔵 Partner Review</option>
          <option value="udin_generated">🟣 UDIN Generated</option>
          <option value="filed">🟢 Filed on Portal</option>
        </Select>
      </div>

      {/* Audit Table */}
      <div className="rounded-xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-secondary/40 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Audit Client</th>
                <th className="px-4 py-3.5">Report Type & Turnover</th>
                <th className="px-4 py-3.5">Audit Status</th>
                <th className="px-4 py-3.5">ICAI UDIN</th>
                <th className="px-4 py-3.5">Due Date & Compliance</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filteredAudits.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-xs text-muted-foreground">
                    <ShieldCheck className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
                    No Tax Audit records found for the selected filter.
                  </td>
                </tr>
              ) : (
                filteredAudits.map((audit) => {
                  const badgeInfo = statusBadges[audit.status] || { label: audit.status, variant: 'secondary' };

                  return (
                    <tr key={audit.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-foreground">{audit.client_name}</div>
                        <div className="font-mono text-xs text-muted-foreground uppercase">
                          {audit.pan} · AY {audit.assessment_year}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-foreground">{audit.audit_type}</div>
                        <div className="text-xs font-mono text-muted-foreground">
                          {formatCurrency(audit.turnover_amount)}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <Badge variant={badgeInfo.variant}>
                          {badgeInfo.label}
                        </Badge>
                      </td>

                      <td className="px-4 py-3.5">
                        {audit.udin ? (
                          <span className="font-mono text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded border border-primary/20">
                            {audit.udin}
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground italic">Pending UDIN</span>
                        )}
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="text-xs font-semibold text-foreground">
                          Due: {audit.due_date || '30 Sept'}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-0.5">
                          {audit.msme_compliance && (
                            <span className="text-emerald-600 font-medium">✓ Sec 43B(h) OK</span>
                          )}
                          {audit.depreciation_verified && (
                            <span className="text-blue-600 font-medium">✓ Sec 32 OK</span>
                          )}
                        </div>
                      </td>

                      <td className="px-4 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setEditingAudit(audit)}
                            className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => {
                              if (confirm(`Remove Tax Audit record for ${audit.client_name}?`)) {
                                deleteTaxAudit(audit.id);
                              }
                            }}
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      <TaxAuditDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <TaxAuditDialog
        isOpen={!!editingAudit}
        onClose={() => setEditingAudit(null)}
        audit={editingAudit}
      />
    </div>
  );
};
