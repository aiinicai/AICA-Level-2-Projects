import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Client, ITRFilingStatus } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { validatePAN, validateMobile, ASSESSMENT_YEARS, ITR_TYPES } from '../../lib/utils';

interface ITRClientDialogProps {
  isOpen: boolean;
  onClose: () => void;
  client?: Client | null;
}

export const ITRClientDialog: React.FC<ITRClientDialogProps> = ({
  isOpen,
  onClose,
  client,
}) => {
  const { user } = useAuth();
  const { team, addClient, updateClient } = useData();

  const [name, setName] = useState('');
  const [pan, setPan] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [assessmentYear, setAssessmentYear] = useState('2026-27');
  const [itrType, setItrType] = useState('ITR-1');
  const [filingStatus, setFilingStatus] = useState<ITRFilingStatus>('not_started');
  const [assignedTo, setAssignedTo] = useState<string>('unassigned');
  const [category, setCategory] = useState('Salaried & Capital Gains');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (client) {
        setName(client.name);
        setPan(client.pan);
        setMobile(client.mobile || client.contact_phone || '');
        setEmail(client.contact_email || '');
        setAssessmentYear(client.assessment_year || '2026-27');
        setItrType(client.itr_type || 'ITR-1');
        setFilingStatus(client.filing_status || 'not_started');
        setAssignedTo(client.assigned_to || 'unassigned');
        setCategory(client.category || 'General');
        setNotes(client.notes || '');
      } else {
        setName('');
        setPan('');
        setMobile('');
        setEmail('');
        setAssessmentYear('2026-27');
        setItrType('ITR-1');
        setFilingStatus('not_started');
        setAssignedTo('unassigned');
        setCategory('Salaried & Capital Gains');
        setNotes('');
      }
      setError('');
    }
  }, [isOpen, client]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Client Name is required');
      return;
    }
    const cleanPan = pan.trim().toUpperCase();
    if (!validatePAN(cleanPan)) {
      setError('Invalid PAN format (e.g. ABCDE1234F)');
      return;
    }
    const cleanMobile = mobile.trim();
    if (cleanMobile && !validateMobile(cleanMobile)) {
      setError('Invalid Mobile Number (10 digits starting with 6-9)');
      return;
    }

    setIsSubmitting(true);
    try {
      const clientData = {
        name: name.trim(),
        pan: cleanPan,
        mobile: cleanMobile || '9800000000',
        contact_phone: cleanMobile || '9800000000',
        contact_email: email.trim() || undefined,
        assessment_year: assessmentYear,
        itr_type: itrType,
        filing_status: filingStatus,
        assigned_to: assignedTo === 'unassigned' ? null : assignedTo,
        category,
        notes,
      };

      if (client) {
        updateClient(client.id, clientData);
      } else {
        addClient(clientData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={client ? 'Edit Client' : 'New ITR Client'}
      description="Add client details, PAN, mobile, ITR filing category, and assessment year."
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium border border-destructive/20">
            {error}
          </div>
        )}

        <Input
          label="Client Full Name / Entity Name *"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Ramesh Kumar / Acme Technologies LLP"
          autoFocus
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Permanent Account Number (PAN) *"
            value={pan}
            onChange={(e) => setPan(e.target.value.toUpperCase())}
            placeholder="ABCDE1234F"
            maxLength={10}
            className="font-mono uppercase tracking-wider"
          />
          <Input
            label="Mobile Number *"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            placeholder="9876543210"
            maxLength={10}
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            label="Email Address"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="client@taxpayer.com"
          />
          <Input
            label="Practice Category / Segment"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="e.g. Presumptive 44ADA / Corporate"
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label="Assessment Year"
            value={assessmentYear}
            onChange={(e) => setAssessmentYear(e.target.value)}
          >
            {ASSESSMENT_YEARS.map((ay) => (
              <option key={ay} value={ay}>
                AY {ay}
              </option>
            ))}
          </Select>

          <Select
            label="ITR Form Type"
            value={itrType}
            onChange={(e) => setItrType(e.target.value)}
          >
            {ITR_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </Select>

          <Select
            label="Filing Status"
            value={filingStatus}
            onChange={(e) => setFilingStatus(e.target.value as ITRFilingStatus)}
          >
            <option value="not_started">⚪ Not Started</option>
            <option value="documents_pending">🟡 Documents Pending</option>
            <option value="in_review">🔵 In Review</option>
            <option value="filed">🟣 Filed</option>
            <option value="completed">🟢 Completed</option>
          </Select>
        </div>

        <Select
          label="Assigned Team Member"
          value={assignedTo}
          onChange={(e) => setAssignedTo(e.target.value)}
        >
          <option value="unassigned">— Unassigned —</option>
          <option value={user?.id || 'user_ca_pro_01'}>
            👤 {user?.display_name || 'Rajesh Sharma'} (Partner)
          </option>
          {team.map((m) => (
            <option key={m.id} value={m.id}>
              {m.display_name} ({m.role})
            </option>
          ))}
        </Select>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {client ? 'Save Changes' : 'Add Client'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
