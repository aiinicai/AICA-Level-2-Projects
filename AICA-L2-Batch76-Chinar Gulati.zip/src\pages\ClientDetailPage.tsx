import React, { useState, useRef } from 'react';
import { 
  ArrowLeft, Phone, Mail, MessageSquare, Edit2, 
  Trash2, Plus, Pin, PinOff, CheckCircle2, Clock, 
  FileText, ShieldCheck, Video, Bold, List, CheckSquare, 
  Send, Sparkles, ExternalLink 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Select } from '../components/ui/Select';
import { Input } from '../components/ui/Input';
import { Tabs } from '../components/ui/Tabs';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { DocStatus, ITRFilingStatus } from '../types';
import { formatDateTime, formatDateShort } from '../lib/utils';
import { ITRClientDialog } from '../components/itr/ITRClientDialog';
import { TaskDialog } from '../components/tasks/TaskDialog';
import { MeetingDialog } from '../components/meetings/MeetingDialog';

interface ClientDetailPageProps {
  clientId: string;
  onBack: () => void;
}

export const ClientDetailPage: React.FC<ClientDetailPageProps> = ({ clientId, onBack }) => {
  const { user } = useAuth();
  const { 
    getClientById, updateClient, deleteClient, 
    getDocsForClient, updateDocStatus, addCustomDoc, deleteDoc, 
    getNotesForClient, addNote, updateNote, deleteNote, togglePinNote, 
    getActivitiesForClient, tasks, meetings, team 
  } = useData();

  const client = getClientById(clientId);
  const docs = getDocsForClient(clientId);
  const notes = getNotesForClient(clientId);
  const activities = getActivitiesForClient(clientId);

  const clientTasks = tasks.filter((t) => t.client_id === clientId);
  const clientMeetings = meetings.filter((m) => m.client_id === clientId);

  const [activeTab, setActiveTab] = useState('docs');
  const [showEditClientModal, setShowEditClientModal] = useState(false);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);
  const [newDocName, setNewDocName] = useState('');
  
  // Rich Notes State
  const [isEditingNote, setIsEditingNote] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const noteEditorRef = useRef<HTMLDivElement>(null);

  if (!client) {
    return (
      <div className="rounded-xl border border-border bg-card p-12 text-center">
        <h3 className="text-lg font-bold text-foreground">Client Not Found</h3>
        <p className="text-xs text-muted-foreground mt-1 mb-4">
          The requested client record does not exist or has been removed.
        </p>
        <Button onClick={onBack} variant="outline" size="sm">
          <ArrowLeft className="h-4 w-4 mr-1.5" />
          Back to Roster
        </Button>
      </div>
    );
  }

  const docStatusOptions = [
    { value: 'pending_client', label: '🟡 Pending from Client' },
    { value: 'received', label: '🟢 Received' },
    { value: 'needs_review', label: '🔵 Needs CA Review' },
    { value: 'not_applicable', label: '⚪ Not Applicable' },
  ];

  const receivedDocsCount = docs.filter((d) => d.status === 'received').length;
  const pendingDocsCount = docs.filter((d) => d.status === 'pending_client').length;

  const handleAddCustomDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocName.trim()) return;
    addCustomDoc(clientId, newDocName.trim());
    setNewDocName('');
  };

  const handleSaveNote = () => {
    if (!noteEditorRef.current) return;
    const content = noteEditorRef.current.innerHTML.trim();
    if (!content) return;

    if (editingNoteId) {
      updateNote(clientId, editingNoteId, content);
    } else {
      addNote(clientId, content);
    }
    setIsEditingNote(false);
    setEditingNoteId(null);
  };

  const handleFormatNote = (cmd: string, val?: string) => {
    document.execCommand(cmd, false, val);
    noteEditorRef.current?.focus();
  };

  const handleInsertCheckbox = () => {
    handleFormatNote('insertHTML', '<div><input type="checkbox" /> </div>');
  };

  const cleanPhone = (client.mobile || client.contact_phone || '').replace(/\D/g, '');
  const whatsappUrl = cleanPhone ? `https://wa.me/91${cleanPhone}?text=Hello%20${encodeURIComponent(client.name)},%20regarding%20your%20ITR%20filing%20for%20AY%20${client.assessment_year || '2026-27'}...` : '#';

  const tabs = [
    { id: 'docs', label: 'Document Checklist', count: docs.length, icon: <FileText className="h-4 w-4" /> },
    { id: 'notes', label: 'Whiteboard & Notes', count: notes.length, icon: <Edit2 className="h-4 w-4" /> },
    { id: 'activity', label: 'Activity Audit Log', count: activities.length, icon: <Clock className="h-4 w-4" /> },
    { id: 'tasks', label: 'Client Tasks', count: clientTasks.length, icon: <CheckSquare className="h-4 w-4" /> },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Back Button */}
      <div>
        <Button variant="ghost" size="sm" onClick={onBack} className="text-xs -ml-2 gap-1">
          <ArrowLeft className="h-4 w-4" />
          Back to Roster
        </Button>
      </div>

      {/* Client 360 Header Banner */}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-soft space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-2xl font-bold tracking-tight text-foreground">{client.name}</h2>
              <Badge variant="outline" className="font-mono uppercase tracking-wider text-xs">
                {client.pan}
              </Badge>
              {client.itr_type && (
                <Badge variant="info">{client.itr_type}</Badge>
              )}
              {client.assessment_year && (
                <Badge variant="secondary">AY {client.assessment_year}</Badge>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
              {client.mobile && (
                <span className="flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5" />
                  {client.mobile}
                </span>
              )}
              {client.contact_email && (
                <span className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5" />
                  {client.contact_email}
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5" />
                {client.category || 'General Practice'}
              </span>
            </div>
          </div>

          {/* Quick Communication Triggers */}
          <div className="flex flex-wrap items-center gap-2">
            {cleanPhone && (
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-600 hover:bg-emerald-500/20 transition-colors"
              >
                <MessageSquare className="h-3.5 w-3.5" />
                WhatsApp
              </a>
            )}
            {client.contact_email && (
              <a
                href={`mailto:${client.contact_email}?subject=ITR%20Filing%20AY%20${client.assessment_year}%20Update`}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/50 px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary transition-colors"
              >
                <Mail className="h-3.5 w-3.5" />
                Email
              </a>
            )}
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowEditClientModal(true)}
              className="text-xs gap-1"
            >
              <Edit2 className="h-3.5 w-3.5" />
              Edit
            </Button>
          </div>
        </div>

        {/* Status & Assignee Quick Update Bar */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-4 pt-4 border-t border-border/60">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Filing Pipeline Status
            </label>
            <Select
              value={client.filing_status}
              onChange={(e) => updateClient(client.id, { filing_status: e.target.value as ITRFilingStatus })}
              className="mt-1"
            >
              <option value="not_started">⚪ Not Started</option>
              <option value="documents_pending">🟡 Documents Pending</option>
              <option value="in_review">🔵 In Review</option>
              <option value="filed">🟣 Filed</option>
              <option value="completed">🟢 Completed</option>
            </Select>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Assigned Team Member
            </label>
            <Select
              value={client.assigned_to || 'unassigned'}
              onChange={(e) => updateClient(client.id, { assigned_to: e.target.value === 'unassigned' ? null : e.target.value })}
              className="mt-1"
            >
              <option value="unassigned">— Unassigned —</option>
              <option value={user?.id || 'user_ca_pro_01'}>👤 Partner ({user?.display_name || 'Rajesh Sharma'})</option>
              {team.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.display_name} ({m.role})
                </option>
              ))}
            </Select>
          </div>

          <div className="rounded-lg border border-border bg-secondary/30 p-2.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Documents Received
            </span>
            <p className="text-base font-bold text-foreground mt-0.5">
              {receivedDocsCount} / {docs.length}
            </p>
          </div>

          <div className="rounded-lg border border-warning/30 bg-warning/5 p-2.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-warning">
              Pending from Client
            </span>
            <p className="text-base font-bold text-warning mt-0.5">
              {pendingDocsCount} documents
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Row */}
      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {/* Tab 1: Document Checklist */}
      {activeTab === 'docs' && (
        <div className="space-y-4">
          <div className="rounded-xl border border-border bg-card shadow-soft overflow-hidden">
            <div className="divide-y divide-border/60">
              {docs.length === 0 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">
                  No documents in checklist yet.
                </p>
              ) : (
                docs.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-3.5 hover:bg-secondary/20 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-7 w-7 items-center justify-center rounded bg-primary/10 text-primary shrink-0">
                        <FileText className="h-3.5 w-3.5" />
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-foreground">{doc.name}</span>
                        {doc.is_custom && (
                          <span className="ml-2 text-[10px] text-muted-foreground font-mono">(custom)</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Select
                        value={doc.status}
                        onChange={(e) => updateDocStatus(clientId, doc.id, e.target.value as DocStatus)}
                        className="w-48 text-xs h-8"
                      >
                        {docStatusOptions.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </Select>

                      {doc.is_custom && (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteDoc(clientId, doc.id)}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Add Custom Document Form */}
          <form onSubmit={handleAddCustomDoc} className="flex gap-2">
            <Input
              value={newDocName}
              onChange={(e) => setNewDocName(e.target.value)}
              placeholder="Add custom compliance document (e.g. Form 10BA / ESOP Valuation Statement)…"
            />
            <Button type="submit" variant="outline" disabled={!newDocName.trim()} className="gap-1.5 shrink-0">
              <Plus className="h-4 w-4" />
              Add Doc
            </Button>
          </form>
        </div>
      )}

      {/* Tab 2: Whiteboard & Notes */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          {isEditingNote ? (
            <Card className="shadow-elevated">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      type="button"
                      onClick={() => handleFormatNote('bold')}
                      className="h-7 w-7"
                    >
                      <Bold className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      type="button"
                      onClick={() => handleFormatNote('insertUnorderedList')}
                      className="h-7 w-7"
                    >
                      <List className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      type="button"
                      onClick={handleInsertCheckbox}
                      className="h-7 w-7"
                      title="Insert Checklist Item"
                    >
                      <CheckSquare className="h-3.5 w-3.5" />
                    </Button>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setIsEditingNote(false);
                        setEditingNoteId(null);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSaveNote}>
                      Save Note
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div
                  ref={noteEditorRef}
                  contentEditable
                  className="min-h-[140px] rounded-lg border border-border bg-card p-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 leading-relaxed"
                  suppressContentEditableWarning
                />
              </CardContent>
            </Card>
          ) : (
            <Button
              variant="outline"
              onClick={() => {
                setIsEditingNote(true);
                setEditingNoteId(null);
                setTimeout(() => {
                  if (noteEditorRef.current) noteEditorRef.current.innerHTML = '';
                }, 50);
              }}
              className="w-full justify-start text-muted-foreground border-dashed py-5 gap-2"
            >
              <Plus className="h-4 w-4" />
              Add directions, follow-up checklist, or tax strategy notes…
            </Button>
          )}

          {/* Notes List */}
          <div className="space-y-3">
            {notes.map((note) => (
              <div
                key={note.id}
                className={`rounded-xl border p-4 shadow-soft transition-all ${
                  note.is_pinned ? 'border-amber-500/40 bg-amber-500/5' : 'border-border bg-card'
                }`}
              >
                <div
                  className="text-sm prose prose-sm max-w-none text-foreground [&_ul]:list-disc [&_ul]:pl-5 [&_input]:mr-2"
                  dangerouslySetInnerHTML={{ __html: note.content }}
                />

                <div className="mt-3 flex items-center justify-between pt-2.5 border-t border-border/60 text-xs text-muted-foreground">
                  <span>Updated {formatDateTime(note.updated_at)}</span>

                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => togglePinNote(clientId, note.id)}
                      className="h-7 w-7"
                    >
                      {note.is_pinned ? <PinOff className="h-3.5 w-3.5 text-amber-500" /> : <Pin className="h-3.5 w-3.5" />}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        setEditingNoteId(note.id);
                        setIsEditingNote(true);
                        setTimeout(() => {
                          if (noteEditorRef.current) noteEditorRef.current.innerHTML = note.content;
                        }, 50);
                      }}
                      className="h-7 w-7"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => deleteNote(clientId, note.id)}
                      className="h-7 w-7 hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Activity Audit Log */}
      {activeTab === 'activity' && (
        <div className="space-y-3">
          {activities.length === 0 ? (
            <p className="py-8 text-center text-xs text-muted-foreground">
              No audit log entries recorded yet.
            </p>
          ) : (
            activities.map((act) => (
              <div
                key={act.id}
                className="flex items-start gap-3 rounded-xl border border-border bg-card p-3.5 shadow-soft text-xs"
              >
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary shrink-0 mt-0.5">
                  <Clock className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">
                    {act.action === 'status_changed' && `Filing status changed to "${act.details?.to}"`}
                    {act.action === 'doc_status_changed' && `Document "${act.details?.doc}" updated to ${act.details?.to}`}
                    {act.action === 'doc_added' && `Added document: "${act.details?.name}"`}
                    {act.action === 'note_added' && 'Added a new direction / note'}
                    {act.action === 'client_created' && 'Client profile created'}
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    {formatDateTime(act.created_at)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 4: Client Tasks */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-foreground">Active Tasks for {client.name}</h4>
            <Button size="sm" onClick={() => setShowTaskDialog(true)} className="gap-1 text-xs">
              <Plus className="h-3.5 w-3.5" /> New Task
            </Button>
          </div>

          <div className="space-y-2.5">
            {clientTasks.length === 0 ? (
              <p className="py-8 text-center text-xs text-muted-foreground">
                No active tasks linked to this client.
              </p>
            ) : (
              clientTasks.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between rounded-xl border border-border bg-card p-3.5 text-xs shadow-soft"
                >
                  <div className="space-y-1">
                    <p className="font-semibold text-foreground">{t.title}</p>
                    <p className="text-muted-foreground">
                      Due: {formatDateTime(t.due_at)} · Priority: {t.priority}
                    </p>
                  </div>
                  <Badge variant={t.status === 'done' ? 'success' : 'secondary'}>
                    {t.status}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Modals */}
      <ITRClientDialog
        isOpen={showEditClientModal}
        onClose={() => setShowEditClientModal(false)}
        client={client}
      />
      <TaskDialog
        isOpen={showTaskDialog}
        onClose={() => setShowTaskDialog(false)}
      />
      <MeetingDialog
        isOpen={showMeetingDialog}
        onClose={() => setShowMeetingDialog(false)}
      />
    </div>
  );
};
