import React, { createContext, useContext, useState, useEffect } from 'react';
import { Profile, UserRole, TeamMember } from '../types';
import { storage } from '../lib/storage';

interface AuthContextType {
  user: Profile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  isEmployee: boolean;
  role: UserRole;
  signIn: (email: string, pass: string, role?: UserRole) => Promise<{ success: boolean; error?: string }>;
  signUp: (name: string, email: string, pass: string, role?: UserRole) => Promise<{ success: boolean; error?: string }>;
  loginDemo: (role?: UserRole, memberId?: string) => void;
  switchUser: (userIdOrEmail: string) => void;
  logout: () => void;
  updateProfile: (data: Partial<Profile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Only restore session if user explicitly signed in
    const storedAuth = localStorage.getItem('praxis_auth_active');
    const storedUser = localStorage.getItem('praxis_active_user');
    
    if (storedAuth === 'true' && storedUser) {
      try {
        const parsed = JSON.parse(storedUser);
        if (parsed && parsed.display_name) {
          setUser(parsed);
        } else {
          setUser(null);
        }
      } catch {
        setUser(null);
      }
    } else {
      setUser(null);
    }
    setIsLoading(false);
  }, []);

  const saveActiveSession = (profile: Profile) => {
    setUser(profile);
    localStorage.setItem('praxis_auth_active', 'true');
    localStorage.setItem('praxis_active_user', JSON.stringify(profile));
  };

  const signIn = async (loginId: string, pass: string, portalType: UserRole | 'admin' | 'employee' = 'admin') => {
    const trimmedId = loginId.trim();
    const trimmedPass = pass.trim();

    if (!trimmedId) return { success: false, error: 'Login ID / Employee Name is required' };
    if (!trimmedPass) return { success: false, error: 'Password is required' };

    const normalizedId = trimmedId.toLowerCase();

    // 1. Admin Authentication Check
    if (portalType === 'admin' || normalizedId === 'cachinar' || normalizedId === 'partner@chinargulati.com') {
      if ((normalizedId === 'cachinar' || normalizedId === 'partner@chinargulati.com' || normalizedId === 'ca chinar gulati') && trimmedPass === 'admin') {
        const adminProfile: Profile = {
          id: 'user_ca_pro_01',
          email: 'partner@chinargulati.com',
          display_name: 'CA Chinar Gulati, FCA',
          firm_name: 'Chinar Gulati & Co.',
          role: 'partner',
          firm_owner_id: 'user_ca_pro_01',
          briefing_time: '10:00',
          timezone: 'Asia/Kolkata',
          created_at: new Date().toISOString(),
        };
        saveActiveSession(adminProfile);
        return { success: true };
      } else {
        return { 
          success: false, 
          error: 'Invalid Admin Credentials. (Login ID: CAChinar | Password: admin)' 
        };
      }
    }

    // 2. Employee Authentication Check
    if (trimmedPass !== '123456') {
      return { 
        success: false, 
        error: 'Invalid Employee Password. (Password must be 123456)' 
      };
    }

    const team = storage.getTeam();
    const matchedEmployee = team.find((m) => {
      const memberName = m.display_name.toLowerCase();
      const pureName = memberName.split('(')[0].replace(/adv\s+/i, '').trim();
      const memberEmail = m.email.toLowerCase();
      const memberId = m.id.toLowerCase();

      return (
        memberName.includes(normalizedId) ||
        normalizedId.includes(pureName) ||
        pureName.includes(normalizedId) ||
        memberEmail === normalizedId ||
        memberId === normalizedId ||
        normalizedId.includes(m.display_name.toLowerCase())
      );
    });

    if (matchedEmployee) {
      const profile: Profile = {
        id: matchedEmployee.id,
        email: matchedEmployee.email,
        display_name: matchedEmployee.display_name,
        role: matchedEmployee.role,
        firm_name: 'Chinar Gulati & Co.',
        firm_owner_id: matchedEmployee.firm_owner_id || 'user_ca_pro_01',
        briefing_time: '10:00',
        timezone: 'Asia/Kolkata',
        created_at: matchedEmployee.created_at || new Date().toISOString(),
      };
      saveActiveSession(profile);
      return { success: true };
    }

    return {
      success: false,
      error: `Employee "${trimmedId}" not found in practice staff roster. Available names: Adv Arpit Gupta, Divyanshu, Kriti, Abhishek, Khushi.`,
    };
  };

  const signUp = async (name: string, email: string, _pass: string, role: UserRole = 'employee') => {
    if (!name.trim() || !email.trim()) return { success: false, error: 'Name and email are required' };
    
    const newProfile: Profile = {
      id: `user_${Date.now()}`,
      email: email.trim(),
      display_name: name.trim(),
      firm_name: 'Chinar Gulati & Co.',
      firm_owner_id: 'user_ca_pro_01',
      role,
      briefing_time: '10:00',
      timezone: 'Asia/Kolkata',
      created_at: new Date().toISOString(),
    };

    // Also add to team if not exists
    const team = storage.getTeam();
    if (!team.some((m) => m.email.toLowerCase() === email.trim().toLowerCase())) {
      const newMember: TeamMember = {
        id: newProfile.id,
        email: newProfile.email,
        display_name: newProfile.display_name,
        role: newProfile.role,
        firm_owner_id: 'user_ca_pro_01',
        status: 'active',
        tasks_count: 0,
        clients_count: 0,
        avatar_color: role === 'partner' ? 'bg-indigo-600' : role === 'admin' ? 'bg-emerald-600' : role === 'article' ? 'bg-amber-600' : 'bg-rose-600',
        created_at: new Date().toISOString(),
      };
      storage.saveTeam([...team, newMember]);
    }

    saveActiveSession(newProfile);
    return { success: true };
  };

  const loginDemo = (role: UserRole = 'partner', memberId?: string) => {
    const team = storage.getTeam();
    let targetMember: TeamMember | undefined;

    if (memberId) {
      targetMember = team.find((m) => m.id === memberId);
    } else if (role === 'partner') {
      targetMember = team.find((m) => m.role === 'partner') || team[0];
    } else if (role === 'admin') {
      targetMember = team.find((m) => m.role === 'admin');
    } else if (role === 'article') {
      targetMember = team.find((m) => m.role === 'article');
    } else {
      targetMember = team.find((m) => m.role === 'employee');
    }

    if (targetMember) {
      const profile: Profile = {
        id: targetMember.id,
        email: targetMember.email,
        display_name: targetMember.display_name,
        role: targetMember.role,
        firm_name: 'Chinar Gulati & Co.',
        firm_owner_id: targetMember.firm_owner_id || 'user_ca_pro_01',
        briefing_time: '10:00',
        timezone: 'Asia/Kolkata',
        created_at: targetMember.created_at || new Date().toISOString(),
      };
      saveActiveSession(profile);
    } else {
      const base = storage.getProfile();
      saveActiveSession({ ...base, role });
    }
  };

  const switchUser = (userIdOrEmail: string) => {
    const team = storage.getTeam();
    const member = team.find((m) => m.id === userIdOrEmail || m.email.toLowerCase() === userIdOrEmail.toLowerCase());
    
    if (member) {
      const profile: Profile = {
        id: member.id,
        email: member.email,
        display_name: member.display_name,
        role: member.role,
        firm_name: 'Chinar Gulati & Co.',
        firm_owner_id: member.firm_owner_id || 'user_ca_pro_01',
        briefing_time: '10:00',
        timezone: 'Asia/Kolkata',
        created_at: member.created_at || new Date().toISOString(),
      };
      saveActiveSession(profile);
    }
  };

  const logout = () => {
    localStorage.removeItem('praxis_auth_active');
    localStorage.removeItem('praxis_active_user');
    setUser(null);
  };

  const updateProfile = (data: Partial<Profile>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    saveActiveSession(updated);
    storage.saveProfile(updated);
  };

  const userRole: UserRole = user?.role || 'employee';
  
  // All rights and administrative access are strictly reserved for CA Chinar Gulati and Adv Arpit Gupta
  const isCAChinar = Boolean(user?.id === 'user_ca_pro_01' || user?.display_name?.toLowerCase().includes('chinar') || userRole === 'partner');
  const isAdvArpit = Boolean(user?.id === 'emp_arpit' || user?.display_name?.toLowerCase().includes('arpit'));
  
  const isAdmin: boolean = isCAChinar || isAdvArpit;
  const isEmployee: boolean = !isAdmin;

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isAdmin,
        isEmployee,
        role: userRole,
        signIn,
        signUp,
        loginDemo,
        switchUser,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
