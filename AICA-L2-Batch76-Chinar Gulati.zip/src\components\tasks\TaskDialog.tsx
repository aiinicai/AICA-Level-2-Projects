import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { Task, Priority, TaskCategory, TaskStatus, Recurrence } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';

interface TaskDialogProps {
  isOpen: boolean;
  onClose: () => void;
  task?: Task | null;
  defaultDate?: string;
}

export const TaskDialog: React.FC<TaskDialogProps> = ({
  isOpen,
  onClose,
  task,
  defaultDate,
}) => {
  const { user } = useAuth();
  const { clients, team, addTask, updateTask } = useData();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [clientId, setClientId] = useState<string>('none');
  const [assignedTo, setAssignedTo] = useState<string>('self');
  const [dueAt, setDueAt] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [category, setCategory] = useState<TaskCategory>('compliance');
  const [status, setStatus] = useState<TaskStatus>('pending');
  const [recurrence, setRecurrence] = useState<Recurrence>('none');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (task) {
        setTitle(task.title);
        setDescription(task.description || '');
        setClientId(task.client_id || 'none');
        setAssignedTo(task.assigned_to || user?.id || 'self');
        setDueAt(task.due_at ? task.due_at.slice(0, 16) : '');
        setPriority(task.priority);
        setCategory(task.category);
        setStatus(task.status);
        setRecurrence(task.recurrence || 'none');
      } else {
        setTitle('');
        setDescription('');
        setClientId('none');
        setAssignedTo('self');
        setDueAt(defaultDate || new Date().toISOString().slice(0, 16));
        setPriority('medium');
        setCategory('compliance');
        setStatus('pending');
        setRecurrence('none');
      }
      setError('');
    }
  }, [isOpen, task, defaultDate, user]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Task title is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const finalAssigneeId = assignedTo === 'self' ? (user?.id || 'user_ca_pro_01') : assignedTo;
      const assignedMember = team.find((m) => m.id === finalAssigneeId);
      const assigneeName = assignedMember ? assignedMember.display_name : (user?.display_name || 'Partner');

      const taskData = {
        user_id: user?.id || 'user_ca_pro_01',
        title: title.trim(),
        description: description.trim() || null,
        client_id: clientId === 'none' ? null : clientId,
        assigned_to: finalAssigneeId,
        assigned_to_name: assigneeName,
        assigned_by: user?.id || 'user_ca_pro_01',
        assigned_by_name: user?.display_name || 'Practice Partner',
        due_at: dueAt ? new Date(dueAt).toISOString() : null,
        priority,
        category,
        status,
        recurrence: recurrence === 'none' ? null : recurrence,
        completed_at: status === 'done' ? new Date().toISOString() : null,
        task_notes: description.trim() ? [
          {
            id: `tn_${Date.now()}`,
            task_id: task ? task.id : `tsk_${Date.now()}`,
            author_id: user?.id || 'user_ca_pro_01',
            author_name: user?.display_name || 'Practice Partner',
            author_role: user?.role || 'partner',
            content: `Initial Instructions: ${description.trim()}`,
            type: 'note' as const,
            created_at: new Date().toISOString(),
          }
        ] : [],
        reassignment_history: [],
      };

      if (task) {
        updateTask(task.id, {
          title: title.trim(),
          description: description.trim() || null,
          client_id: clientId === 'none' ? null : clientId,
          assigned_to: finalAssigneeId,
          assigned_to_name: assigneeName,
          due_at: dueAt ? new Date(dueAt).toISOString() : null,
          priority,
          category,
          status,
          recurrence: recurrence === 'none' ? null : recurrence,
        });
      } else {
        addTask(taskData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={task ? 'Edit Task' : 'New Task'}
      description="Create or modify a practice task, set priority and recurrence."
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label="Title *"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. File GSTR-3B for Acme Pvt Ltd"
          error={error}
          autoFocus
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Client"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
          >
            <option value="none">— No client (Firm Internal) —</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.pan})
              </option>
            ))}
          </Select>

          <Input
            label="Due Date & Time"
            type="datetime-local"
            value={dueAt}
            onChange={(e) => setDueAt(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label="Priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value as Priority)}
          >
            <option value="high">🔴 High</option>
            <option value="medium">🟡 Medium</option>
            <option value="low">🔵 Low</option>
          </Select>

          <Select
            label="Category"
            value={category}
            onChange={(e) => setCategory(e.target.value as TaskCategory)}
          >
            <option value="compliance">🛡️ Compliance</option>
            <option value="meeting">👥 Meeting</option>
            <option value="call">📞 Call</option>
            <option value="personal">✨ Practice/Firm</option>
          </Select>

          <Select
            label="Status"
            value={status}
            onChange={(e) => setStatus(e.target.value as TaskStatus)}
          >
            <option value="pending">Pending</option>
            <option value="in_progress">In Progress</option>
            <option value="done">Completed</option>
          </Select>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Assign To"
            value={assignedTo}
            onChange={(e) => setAssignedTo(e.target.value)}
          >
            <option value="self">👤 Myself ({user?.display_name || 'Partner'})</option>
            {team.map((m) => (
              <option key={m.id} value={m.id}>
                {m.display_name} ({m.role})
              </option>
            ))}
          </Select>

          <Select
            label="Recurrence"
            value={recurrence}
            onChange={(e) => setRecurrence(e.target.value as Recurrence)}
          >
            <option value="none">Does not repeat</option>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="yearly">Yearly</option>
          </Select>
        </div>

        <Textarea
          label="Notes / Instructions"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Specific compliance sections, document references, or guidance…"
          rows={3}
        />

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {task ? 'Save Changes' : 'Create Task'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
