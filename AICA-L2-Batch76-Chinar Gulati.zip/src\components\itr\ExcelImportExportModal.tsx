import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Upload, Download, FileSpreadsheet, CheckCircle2, AlertCircle } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { exportClientsToExcel, parseExcelFile } from '../../lib/excel';
import { Client } from '../../types';

interface ExcelImportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExcelImportExportModal: React.FC<ExcelImportExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { clients, bulkImportClients } = useData();
  const [importedList, setImportedList] = useState<Partial<Client>[]>([]);
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successCount, setSuccessCount] = useState<number | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setError('');
    setIsProcessing(true);

    try {
      const parsed = await parseExcelFile(file);
      if (parsed.length === 0) {
        setError('No valid client records found in this file. Please check columns.');
      } else {
        setImportedList(parsed);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to read Excel/CSV spreadsheet.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmImport = () => {
    if (importedList.length === 0) return;
    bulkImportClients(importedList);
    setSuccessCount(importedList.length);
    setTimeout(() => {
      onClose();
      setSuccessCount(null);
      setImportedList([]);
      setFileName('');
    }, 1200);
  };

  const handleDownloadSample = () => {
    const sampleData: Client[] = [
      {
        id: 'sample_1',
        name: 'Rohan Deshmukh',
        pan: 'ABCDE1234F',
        mobile: '9820112233',
        contact_phone: '9820112233',
        contact_email: 'rohan.d@sample.com',
        assessment_year: '2026-27',
        itr_type: 'ITR-1',
        filing_status: 'not_started',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'sample_2',
        name: 'Shivaji Trading Co LLP',
        pan: 'AAFFS9988K',
        mobile: '9821998877',
        contact_phone: '9821998877',
        contact_email: 'accounts@shivajitrading.in',
        assessment_year: '2026-27',
        itr_type: 'ITR-5',
        filing_status: 'documents_pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];
    exportClientsToExcel(sampleData, 'Praxis_Clients_Template.xlsx');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Bulk Import & Export ITR Clients"
      description="Import existing client rosters or export full filing reports into Microsoft Excel (XLSX / CSV)."
      maxWidth="lg"
    >
      <div className="space-y-5">
        {/* Export Section */}
        <div className="rounded-xl border border-border/80 bg-secondary/30 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600">
                <FileSpreadsheet className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-foreground">Export Current Practice Roster</h4>
                <p className="text-xs text-muted-foreground">
                  Download all {clients.length} clients with PAN, mobile, AY, and filing status.
                </p>
              </div>
            </div>

            <Button
              size="sm"
              variant="outline"
              onClick={() => exportClientsToExcel(clients)}
              className="gap-1.5"
            >
              <Download className="h-4 w-4" />
              Export .xlsx
            </Button>
          </div>
        </div>

        {/* Import Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-foreground">Import Clients Spreadsheet</h4>
            <Button
              size="sm"
              variant="link"
              onClick={handleDownloadSample}
              className="text-xs text-primary"
            >
              Download Sample Template
            </Button>
          </div>

          <div className="rounded-xl border-2 border-dashed border-border/90 p-6 text-center hover:border-primary/50 transition-colors">
            <input
              type="file"
              id="excel-file-input"
              accept=".xlsx, .xls, .csv"
              onChange={handleFileUpload}
              className="hidden"
            />
            <label
              htmlFor="excel-file-input"
              className="flex flex-col items-center justify-center cursor-pointer"
            >
              <Upload className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm font-semibold text-foreground">
                {fileName ? fileName : 'Click to browse or drop .xlsx / .csv spreadsheet'}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Supports columns: Client Name, PAN, Mobile, Email, AY, ITR Type
              </p>
            </label>
          </div>

          {error && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successCount !== null && (
            <div className="flex items-center gap-2 rounded-lg bg-success/10 p-3 text-xs text-success font-semibold">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>Successfully imported {successCount} client(s)!</span>
            </div>
          )}

          {importedList.length > 0 && successCount === null && (
            <div className="space-y-3 rounded-lg border border-border bg-card p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-foreground">
                  Preview ({importedList.length} clients detected):
                </span>
                <span className="text-[11px] text-muted-foreground">Ready to import</span>
              </div>
              <div className="max-h-36 overflow-y-auto space-y-1.5 divide-y divide-border/60">
                {importedList.slice(0, 5).map((item, idx) => (
                  <div key={idx} className="pt-1.5 flex items-center justify-between text-xs">
                    <span className="font-medium text-foreground">{item.name}</span>
                    <span className="font-mono text-muted-foreground">{item.pan}</span>
                  </div>
                ))}
                {importedList.length > 5 && (
                  <p className="text-[10px] text-muted-foreground text-center pt-1">
                    + {importedList.length - 5} more client rows…
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          {importedList.length > 0 && successCount === null && (
            <Button onClick={handleConfirmImport} loading={isProcessing}>
              Import {importedList.length} Clients
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
};
