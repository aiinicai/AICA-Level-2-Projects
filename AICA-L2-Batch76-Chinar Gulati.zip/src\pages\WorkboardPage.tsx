import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, Kanban, CheckCircle2, Clock, 
  Trash2, Edit2, FileSpreadsheet, Building2, TrendingUp 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { useData } from '../context/DataContext';
import { WorkItem, WorkItemType } from '../types';
import { formatCurrency, formatDateShort } from '../lib/utils';
import { WorkItemDialog } from '../components/workboard/WorkItemDialog';

export const WorkboardPage: React.FC = () => {
  const { clients, workItems, toggleWorkItemStatus, deleteWorkItem } = useData();

  const [activeFilter, setActiveFilter] = useState<'all' | 'bill' | 'work'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingItem, setEditingItem] = useState<WorkItem | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedType, setSelectedType] = useState<WorkItemType>('bill');
  const [targetClientId, setTargetClientId] = useState<string | undefined>(undefined);

  // Stats calculation
  const stats = useMemo(() => {
    const pendingBills = workItems.filter((w) => w.type === 'bill' && w.status === 'pending');
    const pendingBillsAmount = pendingBills.reduce((sum, w) => sum + (Number(w.amount) || 0), 0);
    const pendingWorks = workItems.filter((w) => w.type === 'work' && w.status === 'pending');

    return {
      pendingBillsCount: pendingBills.length,
      pendingBillsAmount,
      pendingWorksCount: pendingWorks.length,
      activeClientsCount: clients.length,
    };
  }, [workItems, clients]);

  // Group work items by client
  const clientGroups = useMemo(() => {
    return clients.map((client) => {
      const items = workItems.filter((w) => {
        if (w.client_id !== client.id) return false;
        if (activeFilter !== 'all' && w.type !== activeFilter) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const titleMatch = w.title.toLowerCase().includes(q);
          const clientMatch = client.name.toLowerCase().includes(q);
          const panMatch = client.pan.toLowerCase().includes(q);
          if (!titleMatch && !clientMatch && !panMatch) return false;
        }
        return true;
      });

      const clientPendingBills = items.filter((w) => w.type === 'bill' && w.status === 'pending');
      const clientPendingAmount = clientPendingBills.reduce((sum, w) => sum + (Number(w.amount) || 0), 0);
      const clientPendingWorks = items.filter((w) => w.type === 'work' && w.status === 'pending');

      return {
        client,
        items,
        pendingAmount: clientPendingAmount,
        pendingWorksCount: clientPendingWorks.length,
      };
    }).filter((g) => g.items.length > 0 || !searchQuery.trim());
  }, [clients, workItems, activeFilter, searchQuery]);

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Practice Workboard & Billing
          </h2>
          <p className="text-xs text-muted-foreground">
            Client-grouped view of pending fee bills, receivables, and statutory works in progress.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => {
              setSelectedType('bill');
              setTargetClientId(undefined);
              setShowAddModal(true);
            }}
            className="gap-1.5 shadow-soft"
          >
            <Plus className="h-4 w-4" />
            <span>Add Bill</span>
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setSelectedType('work');
              setTargetClientId(undefined);
              setShowAddModal(true);
            }}
            className="gap-1.5"
          >
            <Plus className="h-4 w-4" />
            <span>Add Work</span>
          </Button>
        </div>
      </div>

      {/* Summary Financial Metrics Bar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <p className="text-xs font-semibold text-muted-foreground">Pending Receivables</p>
          <h3 className="text-2xl font-bold text-foreground mt-1">
            {formatCurrency(stats.pendingBillsAmount)}
          </h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            {stats.pendingBillsCount} pending fee invoices
          </p>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <p className="text-xs font-semibold text-muted-foreground">Works To Be Done</p>
          <h3 className="text-2xl font-bold text-foreground mt-1">
            {stats.pendingWorksCount}
          </h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Pending client assignments
          </p>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
          <p className="text-xs font-semibold text-muted-foreground">Active Clients</p>
          <h3 className="text-2xl font-bold text-foreground mt-1">
            {stats.activeClientsCount}
          </h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Across Corporate & Individual practice
          </p>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-lg bg-secondary p-1 border border-border">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
              activeFilter === 'all'
                ? 'bg-primary text-white shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            All Items
          </button>
          <button
            onClick={() => setActiveFilter('bill')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
              activeFilter === 'bill'
                ? 'bg-primary text-white shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Bills Only ({stats.pendingBillsCount})
          </button>
          <button
            onClick={() => setActiveFilter('work')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
              activeFilter === 'work'
                ? 'bg-primary text-white shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Works Only ({stats.pendingWorksCount})
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by client or item title…"
            className="pl-9"
          />
        </div>
      </div>

      {/* Client-Grouped Workboard Cards */}
      <div className="space-y-4">
        {clientGroups.map(({ client, items, pendingAmount, pendingWorksCount }) => (
          <div
            key={client.id}
            className="rounded-xl border border-border bg-card shadow-soft overflow-hidden transition hover:shadow-elevated"
          >
            {/* Group Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-secondary/40 px-5 py-3.5 border-b border-border/80">
              <div className="flex items-center gap-2.5">
                <Building2 className="h-4 w-4 text-primary" />
                <div>
                  <h3 className="text-sm font-bold text-foreground">{client.name}</h3>
                  <p className="text-[11px] font-mono text-muted-foreground">{client.pan} · {client.category || 'General'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {pendingAmount > 0 && (
                  <Badge variant="warning" className="font-mono">
                    Pending: {formatCurrency(pendingAmount)}
                  </Badge>
                )}
                {pendingWorksCount > 0 && (
                  <Badge variant="info">
                    {pendingWorksCount} Works
                  </Badge>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setSelectedType('bill');
                    setTargetClientId(client.id);
                    setShowAddModal(true);
                  }}
                  className="h-7 text-xs px-2"
                >
                  + Add Item
                </Button>
              </div>
            </div>

            {/* Items List */}
            <div className="divide-y divide-border/60 p-2">
              {items.length === 0 ? (
                <p className="py-4 text-center text-xs text-muted-foreground">
                  No active work or bill entries for this client.
                </p>
              ) : (
                items.map((item) => {
                  const isDone = item.status === 'done';
                  const isBill = item.type === 'bill';

                  return (
                    <div
                      key={item.id}
                      className={`group flex items-start justify-between gap-3 rounded-lg p-3 transition-colors ${
                        isDone
                          ? 'bg-muted/20 opacity-60'
                          : 'hover:bg-secondary/30'
                      }`}
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <button
                          onClick={() => toggleWorkItemStatus(item.id)}
                          className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors ${
                            isDone
                              ? 'border-success bg-success text-white'
                              : 'border-muted-foreground/40 hover:border-primary'
                          }`}
                        >
                          {isDone && <CheckCircle2 className="h-3 w-3" />}
                        </button>

                        <div className="min-w-0 space-y-0.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-xs font-semibold ${isDone ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                              {item.title}
                            </span>
                            <Badge
                              variant={isBill ? 'warning' : 'info'}
                              className="text-[10px] px-1.5 py-0"
                            >
                              {isBill ? 'Bill' : 'Work'}
                            </Badge>
                          </div>

                          {item.notes && (
                            <p className="text-[11px] text-muted-foreground">
                              {item.notes}
                            </p>
                          )}

                          <div className="flex items-center gap-3 pt-0.5 text-[11px] text-muted-foreground">
                            {isBill && item.amount && (
                              <span className="font-bold text-foreground font-mono">
                                {formatCurrency(item.amount)}
                              </span>
                            )}
                            {item.due_date && (
                              <span>Due: {formatDateShort(item.due_date)}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setEditingItem(item)}
                          className="h-7 w-7 text-muted-foreground hover:text-foreground"
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteWorkItem(item.id)}
                          className="h-7 w-7 text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modals */}
      <WorkItemDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        defaultType={selectedType}
        defaultClientId={targetClientId}
      />
      <WorkItemDialog
        isOpen={!!editingItem}
        onClose={() => setEditingItem(null)}
        item={editingItem}
      />
    </div>
  );
};
