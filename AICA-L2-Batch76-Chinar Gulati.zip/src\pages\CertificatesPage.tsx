import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, FileCheck2, Download, Printer, 
  Sparkles, CheckCircle2, Clock, Trash2, Edit2, Shield 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Select } from '../components/ui/Select';
import { Modal } from '../components/ui/Modal';
import { Card, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { CertificateRecord, CertificateType, CertificateStatus } from '../types';
import { formatCurrency, formatDateTime } from '../lib/utils';
import { CertificateDialog } from '../components/certificates/CertificateDialog';

export const CertificatesPage: React.FC = () => {
  const { user } = useAuth();
  const { certificates, deleteCertificate } = useData();

  const [typeFilter, setTypeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingCert, setEditingCert] = useState<CertificateRecord | null>(null);
  const [previewCert, setPreviewCert] = useState<CertificateRecord | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredCerts = useMemo(() => {
    return certificates.filter((c) => {
      if (typeFilter !== 'all' && c.certificate_type !== typeFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const titleMatch = c.title.toLowerCase().includes(q);
        const clientMatch = c.client_name.toLowerCase().includes(q);
        const panMatch = c.pan.toLowerCase().includes(q);
        const udinMatch = (c.udin || '').toLowerCase().includes(q);
        const purposeMatch = c.purpose.toLowerCase().includes(q);
        if (!titleMatch && !clientMatch && !panMatch && !udinMatch && !purposeMatch) return false;
      }
      return true;
    });
  }, [certificates, typeFilter, searchQuery]);

  const typeLabels: Record<CertificateType, { label: string; icon: string }> = {
    net_worth: { label: 'Net Worth Certificate', icon: '💼' },
    utilization: { label: 'Utilization Certificate (UC)', icon: '📋' },
    turnover: { label: 'Turnover Certificate', icon: '📊' },
    solvency: { label: 'Solvency Certificate', icon: '🏛️' },
    working_capital: { label: 'Working Capital Assessment', icon: '💰' },
    visa: { label: 'VISA Financial Proof', icon: '✈️' },
  };

  const statusBadges: Record<CertificateStatus, { label: string; variant: 'secondary' | 'warning' | 'info' | 'success' }> = {
    draft: { label: 'Draft', variant: 'secondary' },
    under_review: { label: 'Under Partner Review', variant: 'warning' },
    udin_generated: { label: 'UDIN Generated', variant: 'info' },
    issued: { label: 'Issued & Certified', variant: 'success' },
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            CA Certifications & UDIN Hub
          </h2>
          <p className="text-xs text-muted-foreground">
            Issue and track Net Worth Certificates, Utilization Certificates (UC), Turnover Certificates with ICAI UDINs.
          </p>
        </div>

        <Button onClick={() => setShowAddModal(true)} className="gap-1.5 shadow-soft">
          <Plus className="h-4 w-4" />
          <span>Issue Certificate</span>
        </Button>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by certificate title, client name, purpose, or UDIN…"
            className="pl-9"
          />
        </div>

        <Select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
        >
          <option value="all">All Certificate Types</option>
          <option value="net_worth">💼 Net Worth Certificates</option>
          <option value="utilization">📋 Utilization Certificates (UC)</option>
          <option value="turnover">📊 Turnover Certificates</option>
          <option value="solvency">🏛️ Solvency Certificates</option>
          <option value="visa">✈️ VISA / Immigration Proofs</option>
        </Select>
      </div>

      {/* Certificates Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredCerts.length === 0 ? (
          <div className="col-span-full rounded-xl border border-border bg-card p-12 text-center">
            <FileCheck2 className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-foreground">No certificates found</h4>
            <p className="text-xs text-muted-foreground mt-1">
              Click &ldquo;Issue Certificate&rdquo; to draft a new Net Worth or Utilization Certificate.
            </p>
          </div>
        ) : (
          filteredCerts.map((cert) => {
            const typeInfo = typeLabels[cert.certificate_type] || { label: cert.certificate_type, icon: '📄' };
            const statusInfo = statusBadges[cert.status] || { label: cert.status, variant: 'secondary' };

            return (
              <Card
                key={cert.id}
                className="shadow-soft hover:border-primary/40 transition-all flex flex-col justify-between"
              >
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xl">{typeInfo.icon}</span>
                    <Badge variant={statusInfo.variant} className="text-[10px]">
                      {statusInfo.label}
                    </Badge>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-foreground line-clamp-2">{cert.title}</h4>
                    <p className="text-xs text-primary font-semibold mt-1">
                      Client: {cert.client_name}
                    </p>
                    <p className="text-[11px] font-mono text-muted-foreground uppercase">{cert.pan}</p>
                  </div>

                  <div className="space-y-1 text-xs text-muted-foreground pt-2 border-t border-border/60">
                    <p className="line-clamp-1">
                      <span className="font-semibold text-foreground/80">Purpose:</span> {cert.purpose}
                    </p>
                    {cert.amount_certified && (
                      <p className="text-xs font-bold text-foreground font-mono">
                        Certified Amount: {formatCurrency(cert.amount_certified)}
                      </p>
                    )}
                    {cert.udin && (
                      <p className="text-[11px] font-mono font-bold text-primary">
                        UDIN: {cert.udin}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-border/60">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setPreviewCert(cert)}
                      className="text-xs gap-1 h-7 px-2.5"
                    >
                      <Printer className="h-3 w-3" />
                      Preview & Print
                    </Button>

                    <div className="flex items-center gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setEditingCert(cert)}
                        className="h-7 w-7 text-muted-foreground hover:text-foreground"
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          if (confirm(`Remove certificate "${cert.title}"?`)) {
                            deleteCertificate(cert.id);
                          }
                        }}
                        className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Certificate Preview / Letterhead Modal */}
      {previewCert && (
        <Modal
          isOpen={!!previewCert}
          onClose={() => setPreviewCert(null)}
          title="Official Certificate Preview"
          description="Issued on firm letterhead with ICAI UDIN security watermark."
          maxWidth="lg"
        >
          <div className="space-y-5 rounded-xl border border-border bg-card p-6 shadow-soft text-foreground">
            {/* Letterhead Header */}
            <div className="text-center pb-4 border-b-2 border-primary/40">
              <h3 className="text-lg font-extrabold tracking-wide uppercase text-foreground">
                {user?.firm_name || 'Chinar Gulati & Co.'}
              </h3>
              <p className="text-xs text-muted-foreground">
                Chartered Accountants · FRN: 012345N · {user?.email || 'partner@chinargulati.com'}
              </p>
            </div>

            {/* Certificate Title */}
            <div className="text-center space-y-1">
              <h4 className="text-sm font-bold uppercase underline tracking-wider text-primary">
                {previewCert.title}
              </h4>
              <p className="text-xs text-muted-foreground font-mono">
                {previewCert.udin ? `UDIN: ${previewCert.udin}` : 'UDIN: PENDING GENERATION'}
              </p>
            </div>

            {/* Body */}
            <div className="text-xs leading-relaxed space-y-3 text-muted-foreground">
              <p>
                This is to certify that we have verified the books of accounts, statutory returns, financial statements, and relevant records of <strong>{previewCert.client_name}</strong> (PAN: <span className="font-mono">{previewCert.pan}</span>).
              </p>
              <p>
                <strong>Purpose:</strong> {previewCert.purpose}.
              </p>
              {previewCert.amount_certified && (
                <div className="rounded-lg bg-secondary/60 p-3 text-center border border-border">
                  <span className="text-[11px] uppercase font-bold text-muted-foreground">Certified Value / Turnover</span>
                  <p className="text-xl font-bold font-mono text-foreground mt-0.5">
                    {formatCurrency(previewCert.amount_certified)}
                  </p>
                </div>
              )}
              {previewCert.notes && (
                <p className="italic text-[11px]">
                  <strong>Scope & Qualifications:</strong> {previewCert.notes}
                </p>
              )}
            </div>

            {/* Letterhead Signatory Footer */}
            <div className="pt-6 flex justify-between items-end border-t border-border/80 text-xs">
              <div>
                <p>Date: {previewCert.issued_date || new Date().toLocaleDateString('en-IN')}</p>
                <p>Place: New Delhi / Gurugram</p>
              </div>

              <div className="text-right space-y-1">
                <p className="font-bold text-foreground">For {user?.firm_name || 'Chinar Gulati & Co.'}</p>
                <p className="text-muted-foreground">Chartered Accountants</p>
                <p className="font-bold text-primary pt-2">{previewCert.signatory || 'CA Chinar Gulati, FCA'}</p>
                <p className="text-[11px] text-muted-foreground">Proprietor / Partner (M.No. 098234)</p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-border/60">
              <Button variant="outline" size="sm" onClick={() => setPreviewCert(null)}>
                Close
              </Button>
              <Button size="sm" onClick={() => window.print()} className="gap-1.5">
                <Printer className="h-4 w-4" />
                Print Certificate
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Modals */}
      <CertificateDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <CertificateDialog
        isOpen={!!editingCert}
        onClose={() => setEditingCert(null)}
        certificate={editingCert}
      />
    </div>
  );
};
