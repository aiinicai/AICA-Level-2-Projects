import React, { useState } from 'react';
import { 
  Sparkles, CheckCircle2, Clock, AlertTriangle, Calendar, 
  Video, FileText, ArrowRight, Plus, ExternalLink, Volume2, 
  TrendingUp, Users, CheckSquare, ShieldCheck, FileCheck2, 
  Building2, MessageSquare, Lock, HelpCircle, UserCheck, Radio 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { formatCurrency, formatDateTime, formatDateShort, isOverdue } from '../lib/utils';
import { TaskDialog } from '../components/tasks/TaskDialog';
import { MeetingDialog } from '../components/meetings/MeetingDialog';
import { TaxAuditDialog } from '../components/tax-audit/TaxAuditDialog';
import { CertificateDialog } from '../components/certificates/CertificateDialog';
import { TaskDetailModal } from '../components/tasks/TaskDetailModal';
import { Task } from '../types';

interface DashboardPageProps {
  onNavigate: (route: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { user, isAdmin, isEmployee, role } = useAuth();
  const { 
    tasks, meetings, clients, taxAudits, certificates, 
    metrics, attendance, toggleCheckIn, toggleTaskStatus, unreadChatCount 
  } = useData();

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);
  const [showTaxAuditDialog, setShowTaxAuditDialog] = useState(false);
  const [showCertDialog, setShowCertDialog] = useState(false);
  const [selectedTaskDetail, setSelectedTaskDetail] = useState<Task | null>(null);

  const todayIso = new Date().toISOString().split('T')[0];
  const todayTasks = tasks.filter((t) => t.due_at?.startsWith(todayIso) || (!t.due_at && t.status !== 'done'));
  const todayMeetings = meetings.filter((m) => m.start_at.startsWith(todayIso));
  const overdueTasks = tasks.filter((t) => isOverdue(t.due_at, t.status));

  // User attendance today
  const userTodayAttendance = attendance.find(
    (a) => a.user_id === user?.id && a.date === todayIso
  );
  const isClockedIn = !!userTodayAttendance && userTodayAttendance.check_out === '—';
  const isClockedOut = !!userTodayAttendance && userTodayAttendance.check_out !== '—';

  // Audio briefing readout using browser SpeechSynthesis API
  const handleReadBriefing = () => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    let text = '';
    if (isAdmin) {
      text = `Good morning CA Chinar Gulati. Here is your executive briefing for ${user?.firm_name || 'Chinar Gulati & Co.'}. You have ${todayMeetings.length} meetings scheduled, ${metrics.pendingTaxAudits} tax audit reports in review, ${certificates.length} certifications, and ${tasks.filter(t => t.status !== 'done').length} priority practice tasks.`;
    } else {
      text = `Good day ${user?.display_name}. Here is your staff workbench for ${user?.firm_name || 'Chinar Gulati & Co.'}. You have ${tasks.filter(t => t.status !== 'done').length} assigned tasks to complete, and ${clients.length} client portfolios assigned to you.`;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleQuickPunch = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          toggleCheckIn(user?.id || '', {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy),
            location: `${pos.coords.latitude.toFixed(4)}° N, ${pos.coords.longitude.toFixed(4)}° E (GPS Verified)`,
            maps_url: `https://www.google.com/maps?q=${pos.coords.latitude},${pos.coords.longitude}`,
            location_type: 'office',
          });
        },
        () => {
          toggleCheckIn(user?.id || '', {
            location: 'Connaught Place Head Office, New Delhi',
            latitude: 28.6315,
            longitude: 77.2167,
            location_type: 'office',
          });
        },
        { timeout: 5000 }
      );
    } else {
      toggleCheckIn(user?.id || '');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Daily Briefing Executive / Staff Workbench Card */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-r from-primary/10 via-card to-card p-6 sm:p-8 shadow-elevated">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="default" className="bg-primary/20 text-primary border border-primary/30">
                <Sparkles className="h-3 w-3 mr-1 text-amber-400" />
                {isAdmin ? 'Virtual CA Desk — Practice Overview' : 'Virtual CA Desk — Staff Workspace'}
              </Badge>
              <span className="text-xs text-muted-foreground font-semibold">
                {user?.firm_name || 'Chinar Gulati & Co.'}
              </span>
              {!isAdmin && (
                <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground border border-border">
                  {role === 'article' ? 'Articled Assistant' : 'Staff Associate'}
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground">
              Good day, {user?.display_name || 'Partner'}
            </h2>

            <p className="text-sm text-muted-foreground max-w-2xl leading-relaxed">
              {isAdmin ? (
                <>
                  Executive practice overview for <span className="font-semibold text-foreground">{user?.firm_name || 'Chinar Gulati & Co.'}</span>. You have <span className="font-semibold text-foreground">{todayMeetings.length} meeting(s)</span> scheduled today, <span className="font-semibold text-foreground">{metrics.pendingTaxAudits} Tax Audits (Form 3CD)</span> in progress, and <span className="font-semibold text-foreground">{metrics.pendingTasks} priority tasks</span> across your practice.
                </>
              ) : (
                <>
                  Welcome to your workbench. You have <span className="font-semibold text-foreground">{tasks.filter(t => t.status !== 'done').length} assigned tasks</span> pending, <span className="font-semibold text-foreground">{clients.length} client files</span> assigned to you, and active connection to the Managing Partner.
                </>
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Button
              variant="outline"
              size="sm"
              onClick={handleReadBriefing}
              className="gap-1.5 bg-card/80 backdrop-blur-sm"
            >
              <Volume2 className={`h-4 w-4 ${isSpeaking ? 'text-primary animate-pulse' : ''}`} />
              <span>{isSpeaking ? 'Stop Audio' : 'Audio Briefing'}</span>
            </Button>

            <Button
              size="sm"
              onClick={() => setShowTaskDialog(true)}
              className="gap-1.5 shadow-soft bg-gradient-primary"
            >
              <Plus className="h-4 w-4" />
              <span>{isAdmin ? 'Assign Task' : 'New Task'}</span>
            </Button>
          </div>
        </div>

        {/* Briefing Highlights Row */}
        {isAdmin ? (
          <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-4 pt-5 border-t border-border/60">
            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-info/10 text-info font-bold text-sm">
                {todayMeetings.length}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Meetings Today</p>
                <p className="text-[11px] text-muted-foreground">
                  {todayMeetings.length > 0 ? `${todayMeetings[0].title.slice(0, 20)}…` : 'No upcoming calls'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600 font-bold text-sm">
                {metrics.taxAuditsCount}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Tax Audits (3CD)</p>
                <p className="text-[11px] text-muted-foreground">
                  {metrics.pendingTaxAudits} in drafting/review
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-500/10 text-purple-600 font-bold text-sm">
                {metrics.certificatesCount}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Certifications (UDIN)</p>
                <p className="text-[11px] text-muted-foreground">
                  {metrics.issuedCertificatesCount} issued & certified
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 font-bold text-sm">
                {metrics.totalClients}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Practice Clients</p>
                <p className="text-[11px] text-muted-foreground">
                  {formatCurrency(metrics.pendingBillsAmount)} receivables
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-4 pt-5 border-t border-border/60">
            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary font-bold text-sm">
                {tasks.filter((t) => t.status !== 'done').length}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">My Pending Tasks</p>
                <p className="text-[11px] text-muted-foreground">
                  {todayTasks.length} due today
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/10 text-blue-600 font-bold text-sm">
                {clients.length}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">My Assigned Clients</p>
                <p className="text-[11px] text-muted-foreground">
                  ITR documentation active
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 font-bold text-sm">
                {isClockedIn ? 'ON' : isClockedOut ? 'OUT' : 'OFF'}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Today Shift</p>
                <p className="text-[11px] text-muted-foreground">
                  {isClockedIn ? `In at ${userTodayAttendance?.check_in}` : isClockedOut ? 'Shift Done' : 'Not Clocked In'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg bg-card/60 p-3 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-500/10 text-purple-600 font-bold text-sm">
                {unreadChatCount}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Staff Messages</p>
                <p className="text-[11px] text-muted-foreground">
                  {unreadChatCount > 0 ? 'Unread updates' : 'All messages read'}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Metrics Row (Tailored by Role) */}
      {isAdmin ? (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {/* Tax Audit Tile */}
          <Card className="cursor-pointer hover:border-amber-500/40 transition-all" onClick={() => onNavigate('/tax-audit')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Tax Audit Hub</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">{metrics.taxAuditsCount}</h3>
                <p className="text-[11px] text-amber-600 font-semibold mt-0.5">Form 3CA / 3CB / 3CD</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/10 text-amber-600">
                <ShieldCheck className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* Certifications Tile */}
          <Card className="cursor-pointer hover:border-purple-500/40 transition-all" onClick={() => onNavigate('/certificates')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Certifications</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">{metrics.certificatesCount}</h3>
                <p className="text-[11px] text-purple-600 font-semibold mt-0.5">Net Worth & UCs (UDIN)</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-500/10 text-purple-600">
                <FileCheck2 className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* ITR Tile */}
          <Card className="cursor-pointer hover:border-primary/40 transition-all" onClick={() => onNavigate('/itr')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">ITR Roster</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">{metrics.totalClients}</h3>
                <p className="text-[11px] text-muted-foreground mt-0.5">AY 2026-27 filings</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-info/10 text-info">
                <FileText className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* Workboard & Receivables Tile */}
          <Card className="cursor-pointer hover:border-emerald-500/40 transition-all" onClick={() => onNavigate('/workboard')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Pending Receivables</p>
                <h3 className="text-xl sm:text-2xl font-bold text-foreground mt-1">{formatCurrency(metrics.pendingBillsAmount)}</h3>
                <p className="text-[11px] text-muted-foreground mt-0.5">{metrics.pendingWorksCount} works pending</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600">
                <TrendingUp className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {/* My Tasks Tile */}
          <Card className="cursor-pointer hover:border-primary/40 transition-all" onClick={() => onNavigate('/tasks')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">My Assigned Tasks</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">{tasks.filter(t => t.status !== 'done').length}</h3>
                <p className="text-[11px] text-primary font-semibold mt-0.5">Personal Task Queue</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <CheckSquare className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* Compliance Calendar Tile */}
          <Card className="cursor-pointer hover:border-indigo-500/40 transition-all" onClick={() => onNavigate('/calendar')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Compliance Calendar</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">Due Dates</h3>
                <p className="text-[11px] text-indigo-600 font-semibold mt-0.5">GSTR-1, 3B, TDS 7th</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-600">
                <Calendar className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* My Assigned Clients Tile */}
          <Card className="cursor-pointer hover:border-blue-500/40 transition-all" onClick={() => onNavigate('/itr')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">My Assigned Clients</p>
                <h3 className="text-2xl font-bold text-foreground mt-1">{clients.length}</h3>
                <p className="text-[11px] text-blue-600 font-semibold mt-0.5">Documents & ITR</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-500/10 text-blue-600">
                <Users className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          {/* Staff Chat Tile */}
          <Card className="cursor-pointer hover:border-emerald-500/40 transition-all" onClick={() => onNavigate('/chat')}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Staff Chat & Help</p>
                <h3 className="text-xl sm:text-2xl font-bold text-foreground mt-1">
                  {unreadChatCount > 0 ? `${unreadChatCount} Unread` : 'Connected'}
                </h3>
                <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">Ask Partner Directly</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600">
                <MessageSquare className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main 2-Column Section */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left 2 Cols: Priority Tasks */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-foreground">
                {isAdmin ? 'Practice Priority Tasks' : 'My Assigned Workload'}
              </h3>
              <p className="text-xs text-muted-foreground">
                {isAdmin ? 'High priority compliance and audit items.' : 'Tasks assigned to you by the practice partner.'}
              </p>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('/tasks')}
              className="gap-1 text-xs text-primary"
            >
              <span>View All</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>

          <div className="space-y-3">
            {tasks.filter((t) => t.status !== 'done').slice(0, 5).length === 0 ? (
              <div className="rounded-xl border border-border bg-card p-8 text-center shadow-soft">
                <CheckCircle2 className="h-8 w-8 text-success/60 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-foreground">All assigned tasks completed!</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  No pending action items in your queue right now.
                </p>
              </div>
            ) : (
              tasks
                .filter((t) => t.status !== 'done')
                .slice(0, 5)
                .map((task) => {
                  const overdue = isOverdue(task.due_at, task.status);
                  const hasQueries = task.task_notes && task.task_notes.some(n => n.is_query && !n.is_resolved);

                  return (
                    <div
                      key={task.id}
                      className={`flex items-start justify-between gap-3 rounded-xl border p-3.5 transition-all ${
                        overdue
                          ? 'border-destructive/30 bg-destructive/5'
                          : hasQueries
                          ? 'border-amber-500/40 bg-amber-500/5'
                          : 'border-border bg-card hover:border-primary/40 shadow-soft'
                      }`}
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <button
                          onClick={() => toggleTaskStatus(task.id)}
                          className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border border-muted-foreground/40 hover:border-primary"
                        />

                        <div className="min-w-0 space-y-1">
                          <button
                            onClick={() => setSelectedTaskDetail(task)}
                            className="text-xs font-bold text-foreground hover:underline text-left line-clamp-1"
                          >
                            {task.title}
                          </button>

                          <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                            {task.client && (
                              <span className="font-semibold text-foreground/80">
                                🏢 {task.client.name}
                              </span>
                            )}

                            {task.due_at && (
                              <span className={`flex items-center gap-1 ${overdue ? 'text-destructive font-bold' : ''}`}>
                                <Clock className="h-3 w-3" />
                                {formatDateTime(task.due_at)}
                              </span>
                            )}

                            {hasQueries && (
                              <span className="inline-flex items-center gap-1 rounded bg-amber-500/20 text-amber-600 px-1.5 py-0.2 font-extrabold text-[10px]">
                                ❓ Query Raised
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <Badge
                          variant={task.priority === 'high' ? 'destructive' : task.priority === 'medium' ? 'warning' : 'secondary'}
                          className="text-[10px] px-1.5 py-0 capitalize"
                        >
                          {task.priority}
                        </Badge>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedTaskDetail(task)}
                          className="h-7 text-[11px] px-2 text-primary border-primary/30"
                        >
                          Discussion
                        </Button>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>

        {/* Right 1 Col: Quick Links, Attendance & Upcoming Statutory Dates */}
        <div className="space-y-4">
          {/* Staff Attendance Quick Card (Useful for Employee) */}
          {isEmployee && (
            <Card className="shadow-soft border-primary/30 bg-gradient-to-br from-card to-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-foreground flex items-center justify-between">
                  <span>My Attendance Status</span>
                  <Badge variant="default" className="text-[10px] bg-primary">
                    Today
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-2.5 rounded-lg bg-card border border-border flex items-center justify-between">
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-bold text-foreground">
                      {isClockedIn ? 'Clocked In (Active)' : isClockedOut ? 'Shift Completed' : 'Not Clocked In'}
                    </p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {isClockedIn 
                        ? `Since ${userTodayAttendance?.check_in}${userTodayAttendance?.location ? ` • 📍 ${userTodayAttendance.location.split(',')[0]}` : ''}` 
                        : 'Daily GPS verified timesheet'}
                    </p>
                  </div>
                  {isClockedIn ? (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => toggleCheckIn(user?.id || '')}
                      className="h-7 text-xs shrink-0"
                    >
                      Clock Out
                    </Button>
                  ) : !isClockedOut ? (
                    <Button
                      size="sm"
                      onClick={handleQuickPunch}
                      className="h-7 text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-bold shrink-0"
                    >
                      Punch In
                    </Button>
                  ) : (
                    <span className="text-xs text-success font-bold shrink-0">✓ Complete</span>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Statutory Deadlines Quick Card */}
          <Card className="shadow-soft">
            <CardHeader className="pb-2 border-b border-border/60">
              <CardTitle className="text-xs font-bold uppercase tracking-wider text-foreground flex items-center justify-between">
                <span>Statutory Reminders</span>
                <button
                  onClick={() => onNavigate('/calendar')}
                  className="text-[11px] text-primary hover:underline font-semibold"
                >
                  Full Calendar
                </button>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-2.5">
              <div className="flex items-center justify-between p-2 rounded-lg bg-indigo-500/5 border border-indigo-500/20 text-xs">
                <div>
                  <p className="font-bold text-foreground">GSTR-1 Monthly Return</p>
                  <p className="text-[10px] text-muted-foreground">Monthly Outward Supplies</p>
                </div>
                <Badge variant="default" className="text-[10px] bg-indigo-600">11th</Badge>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-indigo-500/5 border border-indigo-500/20 text-xs">
                <div>
                  <p className="font-bold text-foreground">GSTR-3B Summary Return</p>
                  <p className="text-[10px] text-muted-foreground">Tax Payment & ITC</p>
                </div>
                <Badge variant="default" className="text-[10px] bg-indigo-600">20th</Badge>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-amber-500/5 border border-amber-500/20 text-xs">
                <div>
                  <p className="font-bold text-foreground">TDS / TCS Monthly Deposit</p>
                  <p className="text-[10px] text-muted-foreground">Challan ITNS 281</p>
                </div>
                <Badge variant="warning" className="text-[10px]">7th</Badge>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/5 border border-emerald-500/20 text-xs">
                <div>
                  <p className="font-bold text-foreground">Tax Audit Form 3CD & UDIN</p>
                  <p className="text-[10px] text-muted-foreground">Sec 44AB Statutory Audit</p>
                </div>
                <Badge variant="default" className="text-[10px] bg-emerald-600">30th Sep</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Task Modals */}
      <TaskDialog
        isOpen={showTaskDialog}
        onClose={() => setShowTaskDialog(false)}
      />
      <MeetingDialog
        isOpen={showMeetingDialog}
        onClose={() => setShowMeetingDialog(false)}
      />
      <TaxAuditDialog
        isOpen={showTaxAuditDialog}
        onClose={() => setShowTaxAuditDialog(false)}
      />
      <CertificateDialog
        isOpen={showCertDialog}
        onClose={() => setShowCertDialog(false)}
      />
      <TaskDetailModal
        isOpen={!!selectedTaskDetail}
        onClose={() => setSelectedTaskDetail(null)}
        task={selectedTaskDetail}
      />
    </div>
  );
};
