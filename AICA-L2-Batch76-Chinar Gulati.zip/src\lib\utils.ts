import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, isToday, isTomorrow, isPast, parseISO } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number | null | undefined): string {
  if (amount == null) return '₹0';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDateTime(dateStr?: string | null): string {
  if (!dateStr) return '';
  try {
    const d = typeof dateStr === 'string' ? parseISO(dateStr) : dateStr;
    if (isToday(d)) {
      return `Today at ${format(d, 'h:mm a')}`;
    }
    if (isTomorrow(d)) {
      return `Tomorrow at ${format(d, 'h:mm a')}`;
    }
    return format(d, 'MMM d, yyyy · h:mm a');
  } catch {
    return dateStr;
  }
}

export function formatDateShort(dateStr?: string | null): string {
  if (!dateStr) return '';
  try {
    const d = typeof dateStr === 'string' ? parseISO(dateStr) : dateStr;
    if (isToday(d)) return 'Today';
    if (isTomorrow(d)) return 'Tomorrow';
    return format(d, 'MMM d');
  } catch {
    return dateStr;
  }
}

export function isOverdue(dateStr?: string | null, status?: string): boolean {
  if (!dateStr || status === 'done' || status === 'completed') return false;
  try {
    const d = parseISO(dateStr);
    return isPast(d) && !isToday(d);
  } catch {
    return false;
  }
}

export const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
export const MOBILE_REGEX = /^[6-9]\d{9}$/;
export const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

export function validatePAN(pan: string): boolean {
  return PAN_REGEX.test(pan.trim().toUpperCase());
}

export function validateMobile(mobile: string): boolean {
  return MOBILE_REGEX.test(mobile.trim());
}

export const ASSESSMENT_YEARS = (() => {
  const cur = new Date().getFullYear();
  return [
    `${cur + 1}-${String((cur + 2) % 100).padStart(2, '0')}`,
    `${cur}-${String((cur + 1) % 100).padStart(2, '0')}`,
    `${cur - 1}-${String(cur % 100).padStart(2, '0')}`,
    `${cur - 2}-${String((cur - 1) % 100).padStart(2, '0')}`,
  ];
})();

export const ITR_TYPES = ['ITR-1', 'ITR-2', 'ITR-3', 'ITR-4', 'ITR-5', 'ITR-6', 'ITR-7'];
