import React, { useState, useMemo } from 'react';
import { 
  ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, 
  Video, CheckSquare, Clock, ExternalLink, ShieldCheck, 
  AlertTriangle, Bell, Sparkles, Filter 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Tabs } from '../components/ui/Tabs';
import { useData } from '../context/DataContext';
import { 
  format, addMonths, subMonths, startOfMonth, endOfMonth, 
  startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, 
  isSameDay, isToday, parseISO 
} from 'date-fns';
import { TaskDialog } from '../components/tasks/TaskDialog';
import { MeetingDialog } from '../components/meetings/MeetingDialog';
import { ComplianceCalendarTab } from '../components/compliance/ComplianceCalendarTab';
import { generateMonthlyCompliances } from '../lib/complianceData';

export const CalendarPage: React.FC = () => {
  const { tasks, meetings } = useData();

  const [viewTab, setViewTab] = useState<'schedule' | 'compliance'>('compliance');
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);

  const calendarDays = useMemo(() => {
    return eachDayOfInterval({ start: startDate, end: endDate });
  }, [startDate, endDate]);

  const currentYearNum = currentMonth.getFullYear();
  const currentMonthNum = currentMonth.getMonth() + 1;

  const currentMonthCompliances = useMemo(() => {
    return generateMonthlyCompliances(currentYearNum, currentMonthNum);
  }, [currentYearNum, currentMonthNum]);

  // Selected date events
  const selectedDayIso = format(selectedDate, 'yyyy-MM-dd');
  const selectedDayTasks = tasks.filter((t) => t.due_at?.startsWith(selectedDayIso));
  const selectedDayMeetings = meetings.filter((m) => m.start_at.startsWith(selectedDayIso));
  const selectedDayCompliances = currentMonthCompliances.filter((c) => c.due_date === selectedDayIso);

  const tabs = [
    { id: 'compliance', label: '🛡️ Statutory Compliance Calendar (GST, TDS, Advance Tax, 3CD)' },
    { id: 'schedule', label: '📅 Practice Schedule & Client Meetings' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Compliance & Practice Calendar
          </h2>
          <p className="text-xs text-muted-foreground">
            Track GSTR-1, GSTR-3B, TDS deposits, quarterly returns, advance tax installments and client appointments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowMeetingDialog(true)}
            className="gap-1 text-xs"
          >
            <Video className="h-3.5 w-3.5 text-emerald-500" />
            + Meeting
          </Button>
          <Button
            size="sm"
            onClick={() => setShowTaskDialog(true)}
            className="gap-1 text-xs shadow-soft bg-gradient-primary"
          >
            <Plus className="h-3.5 w-3.5" />
            + Task
          </Button>
        </div>
      </div>

      {/* Primary Mode Tabs */}
      <div className="flex border-b border-border text-xs font-bold">
        <button
          onClick={() => setViewTab('compliance')}
          className={`flex items-center gap-2 px-5 py-3 border-b-2 transition-all ${
            viewTab === 'compliance'
              ? 'border-primary text-primary bg-primary/5'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <ShieldCheck className="h-4 w-4 text-indigo-500" />
          <span>Statutory Compliance Calendar</span>
          <span className="rounded-full bg-indigo-500/20 text-indigo-600 px-2 py-0.5 text-[10px] font-extrabold border border-indigo-500/30">
            GST • TDS • ITR • 3CD
          </span>
        </button>

        <button
          onClick={() => setViewTab('schedule')}
          className={`flex items-center gap-2 px-5 py-3 border-b-2 transition-all ${
            viewTab === 'schedule'
              ? 'border-primary text-primary bg-primary/5'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <CalendarIcon className="h-4 w-4 text-emerald-500" />
          <span>Monthly Grid & Meetings Schedule</span>
        </button>
      </div>

      {/* Tab 1: Statutory Compliance Calendar */}
      {viewTab === 'compliance' && (
        <ComplianceCalendarTab
          initialYear={currentYearNum}
          initialMonth={currentMonthNum}
        />
      )}

      {/* Tab 2: Monthly Grid & Practice Schedule */}
      {viewTab === 'schedule' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Left 2 Cols: Monthly Calendar Grid */}
          <div className="lg:col-span-2 rounded-2xl border border-border bg-card shadow-soft p-5 space-y-4">
            {/* Month Navigator */}
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-foreground">
                {format(currentMonth, 'MMMM yyyy')}
              </h3>

              <div className="flex items-center gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setCurrentMonth(new Date())}
                  className="h-8 text-xs px-2.5"
                >
                  Today
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                  className="h-8 w-8"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                  className="h-8 w-8"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Days of Week Header */}
            <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-muted-foreground pb-2 border-b border-border/60">
              <span>Sun</span>
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((day, idx) => {
                const dayIso = format(day, 'yyyy-MM-dd');
                const isSelected = isSameDay(day, selectedDate);
                const isCurrent = isSameMonth(day, currentMonth);
                const today = isToday(day);

                const dayTasks = tasks.filter((t) => t.due_at?.startsWith(dayIso));
                const dayMeetings = meetings.filter((m) => m.start_at.startsWith(dayIso));
                const dayCompliances = currentMonthCompliances.filter((c) => c.due_date === dayIso);

                const hasEvents = dayTasks.length > 0 || dayMeetings.length > 0 || dayCompliances.length > 0;

                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedDate(day)}
                    className={`min-h-[75px] p-1.5 text-left rounded-xl border transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-primary ring-2 ring-primary/20 bg-primary/5 font-bold'
                        : isCurrent
                        ? 'border-border/60 bg-card hover:border-primary/40'
                        : 'border-transparent bg-muted/20 text-muted-foreground opacity-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold ${
                          today
                            ? 'bg-primary text-white'
                            : isSelected
                            ? 'bg-primary/20 text-primary'
                            : 'text-foreground'
                        }`}
                      >
                        {format(day, 'd')}
                      </span>

                      {dayCompliances.length > 0 && (
                        <span className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse" title="Statutory Compliance Due" />
                      )}
                    </div>

                    {/* Mini Event Indicators */}
                    {hasEvents && (
                      <div className="space-y-0.5 mt-1 overflow-hidden">
                        {dayCompliances.slice(0, 1).map((comp) => (
                          <div
                            key={comp.id}
                            className="truncate rounded px-1 py-0.2 text-[9px] font-extrabold bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30"
                          >
                            🛡️ {comp.form_name}
                          </div>
                        ))}
                        {dayMeetings.slice(0, 1).map((m) => (
                          <div
                            key={m.id}
                            className="truncate rounded px-1 py-0.2 text-[9px] font-bold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20"
                          >
                            📹 {m.title}
                          </div>
                        ))}
                        {dayTasks.slice(0, 1).map((t) => (
                          <div
                            key={t.id}
                            className="truncate rounded px-1 py-0.2 text-[9px] font-bold bg-blue-500/10 text-blue-600 border border-blue-500/20"
                          >
                            ✓ {t.title}
                          </div>
                        ))}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right 1 Col: Selected Date Detail Agenda */}
          <div className="space-y-4">
            <Card className="shadow-soft">
              <CardHeader className="pb-3 border-b border-border/60">
                <CardTitle className="text-sm font-bold flex items-center justify-between">
                  <span>Agenda for {format(selectedDate, 'd MMMM yyyy')}</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {selectedDayTasks.length + selectedDayMeetings.length + selectedDayCompliances.length} item(s)
                  </Badge>
                </CardTitle>
              </CardHeader>

              <CardContent className="p-4 space-y-4 max-h-[500px] overflow-y-auto">
                {/* Statutory Compliances Due on this Day */}
                {selectedDayCompliances.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                      <ShieldCheck className="h-3.5 w-3.5" />
                      Statutory Due Dates
                    </span>

                    {selectedDayCompliances.map((comp) => (
                      <div
                        key={comp.id}
                        className="rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-3 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                            {comp.form_name}
                          </span>
                          <Badge variant="default" className="text-[9px] bg-indigo-600">
                            {comp.category.toUpperCase()}
                          </Badge>
                        </div>
                        <h4 className="text-xs font-bold text-foreground">
                          {comp.title}
                        </h4>
                        <p className="text-[10px] text-muted-foreground">
                          {comp.penalty_interest_info}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Meetings on this Day */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-500 flex items-center gap-1">
                    <Video className="h-3.5 w-3.5" />
                    Scheduled Meetings ({selectedDayMeetings.length})
                  </span>

                  {selectedDayMeetings.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">No client meetings scheduled.</p>
                  ) : (
                    selectedDayMeetings.map((meeting) => (
                      <div
                        key={meeting.id}
                        className="rounded-xl border border-border bg-card p-3 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-foreground">{meeting.title}</h4>
                          <span className="text-[10px] font-bold text-primary">
                            {meeting.start_at.slice(11, 16)}
                          </span>
                        </div>
                        {meeting.client && (
                          <p className="text-[10px] text-muted-foreground">🏢 {meeting.client.name}</p>
                        )}
                        {meeting.join_url && (
                          <a
                            href={meeting.join_url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 hover:underline pt-1"
                          >
                            <ExternalLink className="h-3 w-3" />
                            Join Video Call
                          </a>
                        )}
                      </div>
                    ))
                  )}
                </div>

                {/* Tasks Due on this Day */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-500 flex items-center gap-1">
                    <CheckSquare className="h-3.5 w-3.5" />
                    Tasks Due ({selectedDayTasks.length})
                  </span>

                  {selectedDayTasks.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">No tasks due on this date.</p>
                  ) : (
                    selectedDayTasks.map((task) => (
                      <div
                        key={task.id}
                        className="rounded-xl border border-border bg-card p-3 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className={`text-xs font-semibold ${task.status === 'done' ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                            {task.title}
                          </h4>
                          <Badge variant={task.priority === 'high' ? 'destructive' : 'secondary'} className="text-[9px]">
                            {task.priority}
                          </Badge>
                        </div>
                        {task.client && (
                          <p className="text-[10px] text-muted-foreground">🏢 {task.client.name}</p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Dialogs */}
      <TaskDialog
        isOpen={showTaskDialog}
        onClose={() => setShowTaskDialog(false)}
        defaultDate={format(selectedDate, 'yyyy-MM-dd')}
      />
      <MeetingDialog
        isOpen={showMeetingDialog}
        onClose={() => setShowMeetingDialog(false)}
        defaultDate={format(selectedDate, 'yyyy-MM-dd')}
      />
    </div>
  );
};
