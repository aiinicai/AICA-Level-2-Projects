import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Send, Users, MessageSquare, Sparkles, Shield, 
  CheckCheck, Paperclip, Search, Bell, Radio, Lock, 
  ChevronRight, Smile, FileText, CheckCircle2 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { ChatMessage, TeamMember, UserRole } from '../types';
import { formatDateTime } from '../lib/utils';

export const ChatPage: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { team, chatMessages, sendChatMessage, markChatRead } = useData();

  const [activeRecipientId, setActiveRecipientId] = useState<string>('all');
  const [messageInput, setMessageInput] = useState('');
  const [searchFilter, setSearchFilter] = useState('');
  const [isBroadcastAnnouncement, setIsBroadcastAnnouncement] = useState(false);
  const [attachedFile, setAttachedFile] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mark active conversation as read
  useEffect(() => {
    markChatRead(activeRecipientId);
  }, [activeRecipientId, chatMessages]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, activeRecipientId]);

  const activeTargetMember = team.find((m) => m.id === activeRecipientId);

  // Filter messages for current thread:
  // If 'all': recipient_id === 'all'
  // If specific user_id:
  // messages between logged in user and that specific user
  const currentThreadMessages = useMemo(() => {
    if (activeRecipientId === 'all') {
      return chatMessages.filter((m) => m.recipient_id === 'all');
    }
    const myId = user?.id || '';
    return chatMessages.filter(
      (m) =>
        (m.sender_id === myId && m.recipient_id === activeRecipientId) ||
        (m.sender_id === activeRecipientId && m.recipient_id === myId)
    );
  }, [chatMessages, activeRecipientId, user]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() && !attachedFile) return;

    sendChatMessage(
      activeRecipientId,
      messageInput.trim(),
      attachedFile || undefined,
      activeRecipientId === 'all' && isBroadcastAnnouncement
    );

    setMessageInput('');
    setAttachedFile(null);
    setIsBroadcastAnnouncement(false);
  };

  const getUnreadForTarget = (targetId: string) => {
    if (!user) return 0;
    return chatMessages.filter(
      (m) =>
        (targetId === 'all' ? m.recipient_id === 'all' : m.sender_id === targetId && m.recipient_id === user.id) &&
        m.sender_id !== user.id &&
        !m.read_by?.includes(user.id)
    ).length;
  };

  const filteredTeam = useMemo(() => {
    return team.filter((m) => {
      if (m.id === user?.id) return false;
      if (!searchFilter.trim()) return true;
      const q = searchFilter.toLowerCase();
      return m.display_name.toLowerCase().includes(q) || m.role.toLowerCase().includes(q);
    });
  }, [team, user, searchFilter]);

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'partner':
        return <Badge variant="default" className="text-[9px] px-1.5 py-0 bg-indigo-600">Managing Partner</Badge>;
      case 'admin':
        return <Badge variant="info" className="text-[9px] px-1.5 py-0">Senior CA</Badge>;
      case 'article':
        return <Badge variant="warning" className="text-[9px] px-1.5 py-0">Articled Assistant</Badge>;
      default:
        return <Badge variant="secondary" className="text-[9px] px-1.5 py-0">Associate</Badge>;
    }
  };

  const quickTemplates = [
    'Please review the draft 3CD Clause 44 reconciliation.',
    'Tax challan generated. Ready for client OTP verification.',
    'UDIN generated and certificate uploaded.',
    'Kindly verify Form 16A TDS reflection on IT portal.',
  ];

  return (
    <div className="space-y-4 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-primary" />
            <span>Staff Chat & Firm Announcements</span>
          </h2>
          <p className="text-xs text-muted-foreground">
            Broadcast firm-wide statutory notices or hold 1-on-1 private coordination chats with individual staff.
          </p>
        </div>
      </div>

      {/* Main Chat Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[calc(100vh-220px)] min-h-[550px] rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
        {/* Left Column: Channels & Contacts (4 cols) */}
        <div className="md:col-span-4 border-r border-border flex flex-col bg-muted/20">
          {/* Search Box */}
          <div className="p-3 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search staff or channels…"
                className="pl-8 h-8 text-xs bg-card"
              />
            </div>
          </div>

          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {/* Whole Staff Broadcast Channel */}
            <div className="mb-2">
              <span className="px-2 text-[10px] uppercase font-bold text-muted-foreground tracking-wider">
                Firm Channels
              </span>
              <button
                type="button"
                onClick={() => setActiveRecipientId('all')}
                className={`w-full mt-1 flex items-center justify-between p-2.5 rounded-xl transition-all ${
                  activeRecipientId === 'all'
                    ? 'bg-primary text-white shadow-soft font-bold'
                    : 'text-foreground hover:bg-muted/80'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                    activeRecipientId === 'all' ? 'bg-white/20 text-white' : 'bg-primary/10 text-primary'
                  }`}>
                    <Radio className="h-4 w-4 animate-pulse" />
                  </div>
                  <div className="min-w-0 text-left">
                    <p className="text-xs font-bold truncate"># General Announcements</p>
                    <p className={`text-[10px] truncate ${
                      activeRecipientId === 'all' ? 'text-white/80' : 'text-muted-foreground'
                    }`}>
                      Whole practice broadcast
                    </p>
                  </div>
                </div>

                {getUnreadForTarget('all') > 0 && (
                  <span className="rounded-full bg-destructive text-white text-[10px] font-bold px-1.5 py-0.2 shrink-0">
                    {getUnreadForTarget('all')}
                  </span>
                )}
              </button>
            </div>

            {/* Direct Messages List */}
            <div className="pt-2">
              <span className="px-2 text-[10px] uppercase font-bold text-muted-foreground tracking-wider">
                Direct Messages (1-on-1)
              </span>

              <div className="mt-1 space-y-1">
                {filteredTeam.map((member) => {
                  const isActive = activeRecipientId === member.id;
                  const unread = getUnreadForTarget(member.id);

                  return (
                    <button
                      key={member.id}
                      type="button"
                      onClick={() => setActiveRecipientId(member.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all ${
                        isActive
                          ? 'bg-primary text-white shadow-soft font-bold'
                          : 'text-foreground hover:bg-muted/80'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className={`relative flex h-8 w-8 items-center justify-center rounded-lg text-white font-bold text-xs shrink-0 ${
                          member.avatar_color || 'bg-emerald-600'
                        }`}>
                          {member.display_name.slice(0, 2).toUpperCase()}
                          <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 border-2 border-card" />
                        </div>
                        <div className="min-w-0 text-left">
                          <p className="text-xs font-bold truncate">{member.display_name.split('(')[0]}</p>
                          <p className={`text-[10px] truncate ${
                            isActive ? 'text-white/80' : 'text-muted-foreground'
                          }`}>
                            {member.role.toUpperCase()}
                          </p>
                        </div>
                      </div>

                      {unread > 0 && (
                        <span className="rounded-full bg-destructive text-white text-[10px] font-bold px-1.5 py-0.2 shrink-0">
                          {unread}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Active Conversation Stream (8 cols) */}
        <div className="md:col-span-8 flex flex-col h-full bg-card">
          {/* Thread Header */}
          <div className="p-3.5 border-b border-border flex items-center justify-between bg-muted/10">
            <div className="flex items-center gap-3 min-w-0">
              {activeRecipientId === 'all' ? (
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Radio className="h-5 w-5" />
                </div>
              ) : (
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl text-white font-bold text-xs ${
                  activeTargetMember?.avatar_color || 'bg-primary'
                }`}>
                  {activeTargetMember?.display_name.slice(0, 2).toUpperCase()}
                </div>
              )}

              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-foreground truncate">
                    {activeRecipientId === 'all' ? '# General Announcements (All Staff)' : activeTargetMember?.display_name}
                  </h3>
                  {activeRecipientId === 'all' ? (
                    <Badge variant="default" className="text-[9px] bg-primary/20 text-primary border border-primary/30">
                      Firm Broadcast
                    </Badge>
                  ) : (
                    activeTargetMember && getRoleBadge(activeTargetMember.role)
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground truncate">
                  {activeRecipientId === 'all'
                    ? 'Messages in this channel are visible to all partners, CAs, and articles.'
                    : `Direct private coordination channel with ${activeTargetMember?.email}`}
                </p>
              </div>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-muted/5">
            {currentThreadMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
                <MessageSquare className="h-10 w-10 text-muted-foreground/30" />
                <h4 className="text-sm font-bold text-foreground">No messages yet</h4>
                <p className="text-xs text-muted-foreground max-w-xs">
                  {activeRecipientId === 'all'
                    ? 'Post the first broadcast announcement or firm notification to all staff.'
                    : `Start a direct conversation with ${activeTargetMember?.display_name}.`}
                </p>
              </div>
            ) : (
              currentThreadMessages.map((msg) => {
                const isMe = msg.sender_id === user?.id;
                const isAnnouncement = msg.is_announcement;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1 px-1">
                      <span className="text-[11px] font-bold text-foreground">
                        {isMe ? 'You' : msg.sender_name}
                      </span>
                      {getRoleBadge(msg.sender_role)}
                      <span className="text-[10px] text-muted-foreground">
                        {formatDateTime(msg.created_at)}
                      </span>
                    </div>

                    <div
                      className={`max-w-md sm:max-w-lg rounded-2xl px-4 py-2.5 text-xs shadow-sm space-y-1.5 ${
                        isAnnouncement
                          ? 'bg-amber-500/10 border border-amber-500/30 text-foreground'
                          : isMe
                          ? 'bg-primary text-white rounded-br-none'
                          : 'bg-secondary/70 text-foreground border border-border/80 rounded-bl-none'
                      }`}
                    >
                      {isAnnouncement && (
                        <div className="flex items-center gap-1.5 text-[10px] font-extrabold text-amber-700 dark:text-amber-400 uppercase tracking-wider pb-1 border-b border-amber-500/20">
                          <Bell className="h-3 w-3" />
                          <span>Official Firm Announcement</span>
                        </div>
                      )}

                      <p className="whitespace-pre-wrap leading-relaxed">
                        {msg.content}
                      </p>

                      {msg.attachment_name && (
                        <div className={`flex items-center gap-1.5 p-2 rounded-lg text-[11px] font-semibold border ${
                          isMe ? 'bg-white/10 border-white/20 text-white' : 'bg-card border-border text-foreground'
                        }`}>
                          <FileText className="h-3.5 w-3.5 text-primary" />
                          <span className="truncate">{msg.attachment_name}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Response Templates */}
          <div className="px-3 py-1.5 border-t border-border/40 bg-card flex items-center gap-1.5 overflow-x-auto text-[10px]">
            <span className="text-muted-foreground font-semibold shrink-0">Quick Insert:</span>
            {quickTemplates.map((tpl, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setMessageInput(tpl)}
                className="shrink-0 px-2 py-0.5 rounded-full bg-secondary/80 hover:bg-primary/10 hover:text-primary border border-border transition-colors text-muted-foreground"
              >
                {tpl.length > 35 ? `${tpl.slice(0, 35)}…` : tpl}
              </button>
            ))}
          </div>

          {/* Message Input Box */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-border bg-card space-y-2">
            {attachedFile && (
              <div className="flex items-center justify-between p-1.5 px-2.5 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary font-semibold">
                <span className="flex items-center gap-1.5">
                  <FileText className="h-3.5 w-3.5" />
                  Attached: {attachedFile}
                </span>
                <button
                  type="button"
                  onClick={() => setAttachedFile(null)}
                  className="text-muted-foreground hover:text-destructive text-[10px]"
                >
                  Remove
                </button>
              </div>
            )}

            <div className="flex items-center gap-2">
              <Input
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder={
                  activeRecipientId === 'all'
                    ? 'Broadcast message to whole practice staff…'
                    : `Message ${activeTargetMember?.display_name.split('(')[0]}…`
                }
                className="flex-1 text-xs"
              />

              <Button
                type="button"
                size="icon"
                variant="outline"
                onClick={() => {
                  const sampleFiles = [
                    'Form_3CD_Draft_Clause44.xlsx',
                    'Dr_Kulkarni_NetWorth_Schedule.pdf',
                    'Mahalaxmi_GSTR3B_Challan.pdf',
                    'Kothari_Exports_15CB_Computation.pdf',
                  ];
                  const pick = sampleFiles[Math.floor(Math.random() * sampleFiles.length)];
                  setAttachedFile(pick);
                }}
                title="Attach working file / schedule"
                className="shrink-0 h-9 w-9 text-muted-foreground hover:text-primary"
              >
                <Paperclip className="h-4 w-4" />
              </Button>

              <Button
                type="submit"
                disabled={!messageInput.trim() && !attachedFile}
                className="shrink-0 gap-1.5 text-xs font-bold bg-gradient-primary shadow-soft px-4"
              >
                <Send className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Send</span>
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
