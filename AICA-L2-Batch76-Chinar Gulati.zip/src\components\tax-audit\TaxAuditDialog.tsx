import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { TaxAuditRecord, TaxAuditType, TaxAuditStatus } from '../../types';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { ASSESSMENT_YEARS } from '../../lib/utils';
import { Sparkles } from 'lucide-react';

interface TaxAuditDialogProps {
  isOpen: boolean;
  onClose: () => void;
  audit?: TaxAuditRecord | null;
}

export const TaxAuditDialog: React.FC<TaxAuditDialogProps> = ({
  isOpen,
  onClose,
  audit,
}) => {
  const { user } = useAuth();
  const { clients, team, addTaxAudit, updateTaxAudit } = useData();

  const [clientId, setClientId] = useState('');
  const [assessmentYear, setAssessmentYear] = useState('2026-27');
  const [financialYear, setFinancialYear] = useState('2025-26');
  const [auditType, setAuditType] = useState<TaxAuditType>('3CA-3CD');
  const [turnoverAmount, setTurnoverAmount] = useState('');
  const [status, setStatus] = useState<TaxAuditStatus>('drafting');
  const [udin, setUdin] = useState('');
  const [assignedTo, setAssignedTo] = useState('self');
  const [dueDate, setDueDate] = useState('2026-09-30');
  const [msmeCompliance, setMsmeCompliance] = useState(true);
  const [depreciationVerified, setDepreciationVerified] = useState(true);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (audit) {
        setClientId(audit.client_id);
        setAssessmentYear(audit.assessment_year);
        setFinancialYear(audit.financial_year);
        setAuditType(audit.audit_type);
        setTurnoverAmount(audit.turnover_amount ? String(audit.turnover_amount) : '');
        setStatus(audit.status);
        setUdin(audit.udin || '');
        setAssignedTo(audit.assigned_to || 'self');
        setDueDate(audit.due_date || '2026-09-30');
        setMsmeCompliance(audit.msme_compliance ?? true);
        setDepreciationVerified(audit.depreciation_verified ?? true);
        setNotes(audit.notes || '');
      } else {
        setClientId(clients[0]?.id || '');
        setAssessmentYear('2026-27');
        setFinancialYear('2025-26');
        setAuditType('3CA-3CD');
        setTurnoverAmount('150000000');
        setStatus('drafting');
        setUdin('');
        setAssignedTo('self');
        setDueDate('2026-09-30');
        setMsmeCompliance(true);
        setDepreciationVerified(true);
        setNotes('');
      }
      setError('');
    }
  }, [isOpen, audit, clients]);

  const generateMockUDIN = () => {
    const randomDigits = Math.floor(100000 + Math.random() * 900000);
    const generated = `26098234AUDT${randomDigits}`;
    setUdin(generated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) {
      setError('Please select an audit client');
      return;
    }

    const selectedClient = clients.find((c) => c.id === clientId);
    if (!selectedClient) {
      setError('Client not found');
      return;
    }

    setIsSubmitting(true);
    try {
      const auditData = {
        client_id: clientId,
        client_name: selectedClient.name,
        pan: selectedClient.pan,
        assessment_year: assessmentYear,
        financial_year: financialYear,
        audit_type: auditType,
        turnover_amount: turnoverAmount ? parseFloat(turnoverAmount) : undefined,
        status,
        udin: udin.trim() || undefined,
        assigned_to: assignedTo === 'self' ? user?.id : assignedTo,
        due_date: dueDate,
        msme_compliance: msmeCompliance,
        depreciation_verified: depreciationVerified,
        notes: notes.trim() || undefined,
      };

      if (audit) {
        updateTaxAudit(audit.id, auditData);
      } else {
        addTaxAudit(auditData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={audit ? 'Edit Tax Audit Record' : 'New Tax Audit (Form 3CA/3CB/3CD)'}
      description="Track Income Tax Act Section 44AB audits, clause disclosures, UDIN generation, and filing status."
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium">
            {error}
          </div>
        )}

        <Select
          label="Audit Client *"
          value={clientId}
          onChange={(e) => setClientId(e.target.value)}
        >
          {clients.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({c.pan})
            </option>
          ))}
        </Select>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label="Audit Report Form"
            value={auditType}
            onChange={(e) => setAuditType(e.target.value as TaxAuditType)}
          >
            <option value="3CA-3CD">Form 3CA-3CD (Corporate Audit)</option>
            <option value="3CB-3CD">Form 3CB-3CD (Non-Corporate Audit)</option>
            <option value="44AB">Sec 44AB (Standard Business)</option>
            <option value="44ADA">Sec 44ADA (Professionals)</option>
          </Select>

          <Select
            label="Assessment Year"
            value={assessmentYear}
            onChange={(e) => setAssessmentYear(e.target.value)}
          >
            {ASSESSMENT_YEARS.map((ay) => (
              <option key={ay} value={ay}>
                AY {ay}
              </option>
            ))}
          </Select>

          <Input
            label="Gross Turnover / Receipts (₹)"
            type="number"
            value={turnoverAmount}
            onChange={(e) => setTurnoverAmount(e.target.value)}
            placeholder="e.g. 150000000"
          />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Audit Progress Status"
            value={status}
            onChange={(e) => setStatus(e.target.value as TaxAuditStatus)}
          >
            <option value="not_started">⚪ Not Started</option>
            <option value="drafting">🟡 Drafting Form 3CD Clauses</option>
            <option value="partner_review">🔵 Partner Review</option>
            <option value="udin_generated">🟣 UDIN Generated</option>
            <option value="filed">🟢 Uploaded on IT Portal</option>
            <option value="completed">✅ Client Accepted & Complete</option>
          </Select>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-foreground/80">
                ICAI Unique Doc ID (UDIN)
              </label>
              <button
                type="button"
                onClick={generateMockUDIN}
                className="text-[11px] font-semibold text-primary hover:underline flex items-center gap-1"
              >
                <Sparkles className="h-3 w-3 text-amber-500" />
                Auto-Generate
              </button>
            </div>
            <Input
              value={udin}
              onChange={(e) => setUdin(e.target.value.toUpperCase())}
              placeholder="e.g. 26098234AAAAAA1234"
              className="font-mono text-xs uppercase"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label="Assigned Lead"
            value={assignedTo}
            onChange={(e) => setAssignedTo(e.target.value)}
          >
            <option value="self">👤 {user?.display_name || 'CA Chinar Gulati'} (Partner)</option>
            {team.map((m) => (
              <option key={m.id} value={m.id}>
                {m.display_name} ({m.role})
              </option>
            ))}
          </Select>

          <Input
            label="Statutory Due Date"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </div>

        {/* Section 43B(h) & Clause Checkboxes */}
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 rounded-lg bg-secondary/40 p-3 border border-border">
          <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={msmeCompliance}
              onChange={(e) => setMsmeCompliance(e.target.checked)}
              className="rounded text-primary focus:ring-primary h-4 w-4"
            />
            <span className="font-semibold">Sec 43B(h) MSME Clearance Verified</span>
          </label>

          <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={depreciationVerified}
              onChange={(e) => setDepreciationVerified(e.target.checked)}
              className="rounded text-primary focus:ring-primary h-4 w-4"
            />
            <span className="font-semibold">Sec 32 Depreciation Verified</span>
          </label>
        </div>

        <Textarea
          label="Form 3CD Clause Observations & Notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Clause 44 GST expenditure breakup, Clause 34 TDS defaults, Clause 21 disallowances…"
          rows={2}
        />

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {audit ? 'Save Audit Changes' : 'Create Tax Audit Record'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
