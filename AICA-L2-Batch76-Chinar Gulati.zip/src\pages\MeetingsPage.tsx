import React, { useState, useMemo } from 'react';
import { 
  Plus, Video, Calendar, Clock, MapPin, ExternalLink, 
  Trash2, Edit2, AlertTriangle, CheckCircle2 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Tabs } from '../components/ui/Tabs';
import { Card, CardContent } from '../components/ui/Card';
import { useData } from '../context/DataContext';
import { Meeting } from '../types';
import { formatDateTime } from '../lib/utils';
import { MeetingDialog } from '../components/meetings/MeetingDialog';

export const MeetingsPage: React.FC = () => {
  const { meetings, deleteMeeting } = useData();

  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [editingMeeting, setEditingMeeting] = useState<Meeting | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const nowIso = new Date().toISOString();

  const counts = useMemo(() => {
    return {
      upcoming: meetings.filter((m) => m.end_at >= nowIso).length,
      past: meetings.filter((m) => m.end_at < nowIso).length,
    };
  }, [meetings, nowIso]);

  const filteredMeetings = useMemo(() => {
    return meetings
      .filter((m) => (activeTab === 'upcoming' ? m.end_at >= nowIso : m.end_at < nowIso))
      .sort((a, b) => (activeTab === 'upcoming' ? a.start_at.localeCompare(b.start_at) : b.start_at.localeCompare(a.start_at)));
  }, [meetings, activeTab, nowIso]);

  const tabs = [
    { id: 'upcoming', label: 'Upcoming Consultations', count: counts.upcoming, icon: <Video className="h-4 w-4" /> },
    { id: 'past', label: 'Past Meetings', count: counts.past, icon: <Clock className="h-4 w-4" /> },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            Meeting Manager
          </h2>
          <p className="text-xs text-muted-foreground">
            1-Click join links, client consultations, automatic conflict alerts, and reminders.
          </p>
        </div>

        <Button onClick={() => setShowAddModal(true)} className="gap-1.5 shadow-soft">
          <Plus className="h-4 w-4" />
          <span>Schedule Meeting</span>
        </Button>
      </div>

      {/* Tabs */}
      <Tabs tabs={tabs} activeTab={activeTab} onChange={(id) => setActiveTab(id as any)} />

      {/* Meetings List */}
      <div className="space-y-3">
        {filteredMeetings.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-12 text-center shadow-soft">
            <Video className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-foreground">No meetings scheduled</h4>
            <p className="text-xs text-muted-foreground mt-1">
              Click &ldquo;Schedule Meeting&rdquo; to set up your next client or team call.
            </p>
          </div>
        ) : (
          filteredMeetings.map((meeting) => (
            <div
              key={meeting.id}
              className="group flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-border bg-card p-4 shadow-soft hover:border-primary/40 transition-all"
            >
              <div className="flex items-start gap-3.5 min-w-0">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary font-bold">
                  <Video className="h-5 w-5" />
                </div>

                <div className="space-y-1 min-w-0">
                  <h4 className="text-sm font-bold text-foreground">{meeting.title}</h4>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 font-medium text-foreground/80">
                      <Clock className="h-3.5 w-3.5" />
                      {formatDateTime(meeting.start_at)} — {new Date(meeting.end_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {meeting.client && (
                      <span className="font-semibold text-primary">
                        🏢 {meeting.client.name}
                      </span>
                    )}

                    {meeting.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {meeting.location}
                      </span>
                    )}
                  </div>

                  {meeting.description && (
                    <p className="text-xs text-muted-foreground pt-0.5 line-clamp-1">
                      {meeting.description}
                    </p>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-border/60">
                {meeting.join_url && (
                  <a
                    href={meeting.join_url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-primary px-3.5 py-1.5 text-xs font-bold text-white shadow-soft hover:opacity-95 transition-opacity"
                  >
                    <span>Join Call</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}

                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setEditingMeeting(meeting)}
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                </Button>

                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteMeeting(meeting.id)}
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modals */}
      <MeetingDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <MeetingDialog
        isOpen={!!editingMeeting}
        onClose={() => setEditingMeeting(null)}
        meeting={editingMeeting}
      />
    </div>
  );
};
