import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, Filter, CheckCircle2, Clock, 
  AlertCircle, Trash2, Edit2, RefreshCw, Calendar, 
  MessageSquare, HelpCircle, Share2, UserCheck, Shield, Lock, Users 
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Select } from '../components/ui/Select';
import { Tabs } from '../components/ui/Tabs';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Task, Priority } from '../types';
import { formatDateTime, isOverdue } from '../lib/utils';
import { TaskDialog } from '../components/tasks/TaskDialog';
import { TaskDetailModal } from '../components/tasks/TaskDetailModal';
import { TaskReassignModal } from '../components/tasks/TaskReassignModal';

export const TasksPage: React.FC = () => {
  const { user, isAdmin, isEmployee } = useAuth();
  const { tasks, allTasks, team, toggleTaskStatus, deleteTask } = useData();

  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [staffFilter, setStaffFilter] = useState('all');
  const [queryFilter, setQueryFilter] = useState('all');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [detailTask, setDetailTask] = useState<Task | null>(null);
  const [reassigningTask, setReassigningTask] = useState<Task | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  // Base list depending on role:
  // Admins can see all tasks (or filter by specific staff member).
  // Employees ONLY see their own assigned tasks (already filtered by DataContext).
  const baseTasks = useMemo(() => {
    if (isAdmin && staffFilter !== 'all') {
      if (staffFilter === 'self') {
        return allTasks.filter((t) => t.assigned_to === user?.id);
      }
      return allTasks.filter((t) => t.assigned_to === staffFilter);
    }
    return tasks;
  }, [tasks, allTasks, isAdmin, staffFilter, user]);

  const counts = useMemo(() => {
    return {
      all: baseTasks.length,
      today: baseTasks.filter((t) => t.due_at?.startsWith(todayStr) && t.status !== 'done').length,
      upcoming: baseTasks.filter((t) => t.due_at && t.due_at > `${todayStr}T23:59:59` && t.status !== 'done').length,
      overdue: baseTasks.filter((t) => isOverdue(t.due_at, t.status)).length,
      queries: baseTasks.filter((t) => t.has_pending_query || (t.task_notes && t.task_notes.some(n => n.is_query && !n.is_resolved))).length,
      completed: baseTasks.filter((t) => t.status === 'done').length,
    };
  }, [baseTasks, todayStr]);

  const filteredTasks = useMemo(() => {
    return baseTasks.filter((task) => {
      // Tab filter
      if (activeTab === 'today') {
        if (!task.due_at?.startsWith(todayStr) || task.status === 'done') return false;
      } else if (activeTab === 'upcoming') {
        if (!task.due_at || task.due_at <= `${todayStr}T23:59:59` || task.status === 'done') return false;
      } else if (activeTab === 'overdue') {
        if (!isOverdue(task.due_at, task.status)) return false;
      } else if (activeTab === 'queries') {
        const hasQuery = task.has_pending_query || (task.task_notes && task.task_notes.some(n => n.is_query && !n.is_resolved));
        if (!hasQuery) return false;
      } else if (activeTab === 'completed') {
        if (task.status !== 'done') return false;
      }

      // Priority filter
      if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
        return false;
      }

      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const titleMatch = task.title.toLowerCase().includes(query);
        const clientMatch = task.client?.name.toLowerCase().includes(query);
        const descMatch = task.description?.toLowerCase().includes(query);
        const assigneeMatch = task.assigned_to_name?.toLowerCase().includes(query);
        if (!titleMatch && !clientMatch && !descMatch && !assigneeMatch) return false;
      }

      return true;
    });
  }, [baseTasks, activeTab, priorityFilter, searchQuery, todayStr]);

  const tabs = [
    { id: 'all', label: 'All Tasks', count: counts.all },
    { id: 'today', label: 'Today', count: counts.today },
    { id: 'upcoming', label: 'Upcoming', count: counts.upcoming },
    { id: 'overdue', label: 'Overdue', count: counts.overdue },
    { id: 'queries', label: '❓ Queries Pending', count: counts.queries },
    { id: 'completed', label: 'Completed', count: counts.completed },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
              {isAdmin ? 'Practice Tasks & Staff Delegation' : 'My Assigned Tasks & Workflow'}
            </h2>
            {isAdmin ? (
              <Badge variant="default" className="text-[10px] bg-indigo-600">Admin Oversight</Badge>
            ) : (
              <Badge variant="secondary" className="text-[10px] flex items-center gap-1">
                <Lock className="h-2.5 w-2.5" />
                Private View ({user?.display_name})
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {isAdmin
              ? 'Assign, track and reassign statutory audit steps, resolve staff queries, and manage deadlines.'
              : 'Tasks assigned to you by the firm. Post queries to the Managing Partner, update status and track deadlines.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button onClick={() => setShowAddModal(true)} className="gap-1.5 shadow-soft bg-gradient-primary">
            <Plus className="h-4 w-4" />
            <span>{isAdmin ? 'Assign New Task' : 'New Task'}</span>
          </Button>
        </div>
      </div>

      {/* Role Notice Banner for Employees */}
      {isEmployee && (
        <div className="rounded-xl border border-border bg-secondary/30 p-3 flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-primary shrink-0" />
            <span>
              <strong>Private Task Isolation Active:</strong> You are viewing tasks assigned specifically to you (<strong>{user?.display_name}</strong>). Tasks assigned to other staff members are kept private.
            </span>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {/* Search & Priority / Staff Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className={isAdmin ? 'sm:col-span-2 relative' : 'sm:col-span-3 relative'}>
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, client, instructions or staff name…"
            className="pl-9"
          />
        </div>

        {isAdmin && (
          <Select
            value={staffFilter}
            onChange={(e) => setStaffFilter(e.target.value)}
          >
            <option value="all">👥 All Staff Members</option>
            <option value="self">👤 Assigned to Myself ({user?.display_name})</option>
            {team.map((m) => (
              <option key={m.id} value={m.id}>
                👤 {m.display_name} ({m.role.toUpperCase()})
              </option>
            ))}
          </Select>
        )}

        <Select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
        >
          <option value="all">⚡ All Priorities</option>
          <option value="high">🔴 High Priority</option>
          <option value="medium">🟡 Medium Priority</option>
          <option value="low">🔵 Low Priority</option>
        </Select>
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-12 text-center shadow-soft">
            <CheckCircle2 className="h-8 w-8 text-muted-foreground/50 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-foreground">No tasks found</h4>
            <p className="text-xs text-muted-foreground mt-1">
              {searchQuery || priorityFilter !== 'all' || staffFilter !== 'all'
                ? 'Try adjusting your search query, staff filter, or priority settings.'
                : 'All caught up! Click "Assign New Task" to create one.'}
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isDone = task.status === 'done';
            const overdue = isOverdue(task.due_at, task.status);
            const notesCount = task.task_notes?.length || 0;
            const pendingQueries = task.task_notes?.filter((n) => n.is_query && !n.is_resolved).length || 0;
            const isAssignedToMe = task.assigned_to === user?.id;

            return (
              <div
                key={task.id}
                className={`group flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border p-4 transition-all ${
                  isDone
                    ? 'border-border/60 bg-muted/30 opacity-70'
                    : overdue
                    ? 'border-destructive/30 bg-destructive/5'
                    : pendingQueries > 0
                    ? 'border-amber-500/40 bg-amber-500/5'
                    : 'border-border bg-card hover:border-primary/40 shadow-soft'
                }`}
              >
                <div className="flex items-start gap-3.5 min-w-0 flex-1">
                  <button
                    onClick={() => toggleTaskStatus(task.id)}
                    title={isDone ? 'Mark as pending' : 'Mark as complete'}
                    className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                      isDone
                        ? 'border-success bg-success text-white'
                        : 'border-muted-foreground/40 hover:border-primary'
                    }`}
                  >
                    {isDone && <CheckCircle2 className="h-3.5 w-3.5" />}
                  </button>

                  <div className="min-w-0 space-y-1.5 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => setDetailTask(task)}
                        className={`text-sm font-semibold text-left hover:underline ${
                          isDone ? 'line-through text-muted-foreground' : 'text-foreground'
                        }`}
                      >
                        {task.title}
                      </button>

                      <Badge
                        variant={
                          task.priority === 'high'
                            ? 'destructive'
                            : task.priority === 'medium'
                            ? 'warning'
                            : 'secondary'
                        }
                        className="text-[10px] px-1.5 py-0 capitalize"
                      >
                        {task.priority}
                      </Badge>

                      {/* Staff Assignee Badge */}
                      <span className="inline-flex items-center gap-1 rounded-full bg-secondary/80 px-2 py-0.5 text-[10px] font-semibold text-foreground border border-border">
                        <UserCheck className="h-3 w-3 text-primary" />
                        <span>{isAssignedToMe ? 'Assigned to Me' : task.assigned_to_name || 'Staff Member'}</span>
                      </span>

                      {/* Pending Query Alert Badge */}
                      {pendingQueries > 0 && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-extrabold text-amber-700 dark:text-amber-400 border border-amber-500/40 animate-pulse">
                          <HelpCircle className="h-3 w-3" />
                          {pendingQueries} Query Pending
                        </span>
                      )}

                      {task.recurrence && task.recurrence !== 'none' && (
                        <span className="flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground border border-border">
                          <RefreshCw className="h-2.5 w-2.5" />
                          {task.recurrence}
                        </span>
                      )}
                    </div>

                    {task.description && (
                      <p className="text-xs text-muted-foreground line-clamp-1">
                        {task.description}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-3 pt-0.5 text-xs text-muted-foreground">
                      {task.client && (
                        <span className="font-semibold text-foreground/80 flex items-center gap-1">
                          🏢 {task.client.name}
                        </span>
                      )}

                      {task.due_at && (
                        <span className={`flex items-center gap-1 ${overdue ? 'text-destructive font-bold' : ''}`}>
                          <Clock className="h-3 w-3" />
                          {formatDateTime(task.due_at)}
                        </span>
                      )}

                      {/* Discussion & Query Button Indicator */}
                      <button
                        onClick={() => setDetailTask(task)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary hover:underline ml-auto sm:ml-0"
                      >
                        <MessageSquare className="h-3 w-3" />
                        <span>{notesCount} Note(s) & Discussion</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center pt-2 sm:pt-0 border-t sm:border-t-0 border-border/60 w-full sm:w-auto justify-end">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDetailTask(task)}
                    className="h-8 text-xs gap-1 border-primary/30 text-primary hover:bg-primary/5"
                  >
                    <MessageSquare className="h-3.5 w-3.5" />
                    <span>Discussion</span>
                  </Button>

                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setReassigningTask(task)}
                    title="Reassign Task"
                    className="h-8 text-xs gap-1 text-muted-foreground hover:text-foreground"
                  >
                    <Share2 className="h-3.5 w-3.5 text-primary" />
                    <span className="hidden md:inline">Reassign</span>
                  </Button>

                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setEditingTask(task)}
                    className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </Button>

                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      if (confirm(`Delete task "${task.title}"?`)) {
                        deleteTask(task.id);
                      }
                    }}
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Dialogs & Modals */}
      <TaskDialog
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
      <TaskDialog
        isOpen={!!editingTask}
        onClose={() => setEditingTask(null)}
        task={editingTask}
      />
      <TaskDetailModal
        isOpen={!!detailTask}
        onClose={() => setDetailTask(null)}
        task={detailTask}
        onEdit={(t) => setEditingTask(t)}
      />
      <TaskReassignModal
        isOpen={!!reassigningTask}
        onClose={() => setReassigningTask(null)}
        task={reassigningTask}
      />
    </div>
  );
};
