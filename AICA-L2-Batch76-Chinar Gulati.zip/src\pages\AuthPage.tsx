import React, { useState } from 'react';
import { 
  Shield, UserCheck, Lock, User, CheckCircle2, 
  Sparkles, ArrowRight, Building2, KeyRound, AlertCircle,
  FileCheck2, ChevronRight
} from 'lucide-react';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { useAuth } from '../context/AuthContext';
import { storage } from '../lib/storage';
import { UserRole } from '../types';

interface AuthPageProps {
  onBackHome?: () => void;
  onSuccess: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onSuccess }) => {
  const { signIn, loginDemo } = useAuth();

  const [portalType, setPortalType] = useState<'admin' | 'employee'>('admin');
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const teamMembers = storage.getTeam();
  const staffMembers = teamMembers.filter((m) => m.role !== 'partner');

  // Handle manual login submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await signIn(loginId, password, portalType);
      if (res.success) {
        onSuccess();
      } else {
        setError(res.error || 'Invalid credentials. Please verify your ID and password.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Quick autofill credentials helper
  const handleAutofillAdmin = () => {
    setLoginId('CAChinar');
    setPassword('admin');
    setError('');
  };

  const handleSelectStaffQuickLogin = (memberName: string, memberId: string, role: UserRole) => {
    setLoginId(memberName.split('(')[0].trim());
    setPassword('123456');
    setError('');
    // Fast 1-click execution
    loginDemo(role, memberId);
    onSuccess();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden selection:bg-indigo-500 selection:text-white">
      {/* Dynamic Background Gradients & Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.25),rgba(255,255,255,0))] -z-10" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl -z-10 pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="w-full max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center z-10">
        
        {/* Left Side: CA Firm Identity & CA Logo Showcase */}
        <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6">
          {/* Official CA Emblem Card */}
          <div className="inline-flex flex-col items-center p-6 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl transition-transform hover:scale-105 duration-300">
            <img 
              src="/ca-logo.png" 
              alt="ICAI Chartered Accountants Logo" 
              className="h-28 sm:h-32 w-auto object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)]"
            />
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Chinar Gulati & Co.
            </h1>
            <p className="text-base sm:text-lg font-medium text-slate-300 tracking-wide">
              Chartered Accountants
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mt-2">
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>Virtual CA Desk</span>
            </div>
          </div>

          <div className="hidden lg:flex flex-col space-y-2.5 text-xs text-slate-300 pt-2 border-t border-slate-800/80 w-full">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>Secured Multi-Role Practice Environment</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>Direct Tax & GST Practice Workflow</span>
            </div>
          </div>
        </div>

        {/* Right Side: Login Form Card */}
        <div className="lg:col-span-7">
          <div className="rounded-3xl border border-slate-800 bg-slate-900/90 backdrop-blur-2xl p-6 sm:p-8 shadow-2xl space-y-6">
            
            {/* Header / Tabs */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                    Sign In to Virtual CA Desk
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Select your access role to continue
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400">
                  <Lock className="h-5 w-5" />
                </div>
              </div>

              {/* Portal Selector Toggle */}
              <div className="grid grid-cols-2 p-1 gap-1 rounded-2xl bg-slate-950/80 border border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setPortalType('admin');
                    setLoginId('');
                    setPassword('');
                    setError('');
                  }}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                    portalType === 'admin'
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Shield className="h-4 w-4" />
                  <span>Login as Admin</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPortalType('employee');
                    setLoginId('');
                    setPassword('');
                    setError('');
                  }}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                    portalType === 'employee'
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck className="h-4 w-4" />
                  <span>Login as Employee</span>
                </button>
              </div>
            </div>

            {/* Error Display */}
            {error && (
              <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 p-3 text-xs text-rose-300 font-medium flex items-start gap-2.5 animate-in fade-in zoom-in-95">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {/* Credential Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {portalType === 'admin' ? (
                <>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-300">
                        Admin Login ID <span className="text-indigo-400">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleAutofillAdmin}
                        className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 transition-colors"
                      >
                        <Sparkles className="h-3 w-3" />
                        Autofill (CAChinar / admin)
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        value={loginId}
                        onChange={(e) => setLoginId(e.target.value)}
                        placeholder="Enter CAChinar"
                        required
                        className="w-full rounded-xl bg-slate-950/90 border border-slate-800 px-3.5 py-2.5 pl-10 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-mono"
                      />
                      <User className="h-4 w-4 text-slate-500 absolute left-3.5 top-3" />
                    </div>
                    <p className="text-[11px] text-slate-500">Preset Login ID: <code className="text-indigo-300 font-mono">CAChinar</code></p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Admin Password <span className="text-indigo-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password (admin)"
                        required
                        className="w-full rounded-xl bg-slate-950/90 border border-slate-800 px-3.5 py-2.5 pl-10 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-mono"
                      />
                      <KeyRound className="h-4 w-4 text-slate-500 absolute left-3.5 top-3" />
                    </div>
                    <p className="text-[11px] text-slate-500">Preset Password: <code className="text-indigo-300 font-mono">admin</code></p>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Employee Name / Login ID <span className="text-indigo-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={loginId}
                        onChange={(e) => setLoginId(e.target.value)}
                        placeholder="e.g. Adv Arpit Gupta, Divyanshu, Kriti..."
                        required
                        className="w-full rounded-xl bg-slate-950/90 border border-slate-800 px-3.5 py-2.5 pl-10 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                      />
                      <User className="h-4 w-4 text-slate-500 absolute left-3.5 top-3" />
                    </div>
                    <p className="text-[11px] text-slate-500">Enter your name as registered in the employee roster below.</p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Employee Password <span className="text-indigo-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password (123456)"
                        required
                        className="w-full rounded-xl bg-slate-950/90 border border-slate-800 px-3.5 py-2.5 pl-10 text-xs text-white placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-mono"
                      />
                      <KeyRound className="h-4 w-4 text-slate-500 absolute left-3.5 top-3" />
                    </div>
                    <p className="text-[11px] text-slate-500">Employee Passcode: <code className="text-indigo-300 font-mono">123456</code></p>
                  </div>
                </>
              )}

              <Button
                type="submit"
                loading={loading}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all duration-200"
              >
                {portalType === 'admin' ? 'Enter as Managing Partner (Admin)' : 'Sign In as Employee'}
              </Button>
            </form>

            {/* Quick 1-Click Employee Access Chips */}
            {portalType === 'employee' && (
              <div className="pt-4 border-t border-slate-800/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Quick Staff 1-Click Access
                  </span>
                  <span className="text-[10px] text-slate-500">Password: 123456</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {staffMembers.map((member) => (
                    <button
                      key={member.id}
                      type="button"
                      onClick={() => handleSelectStaffQuickLogin(member.display_name, member.id, member.role)}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 text-left transition-all group"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className={`flex h-6 w-6 items-center justify-center rounded-lg text-white font-bold text-[10px] shrink-0 ${member.avatar_color || 'bg-indigo-600'}`}>
                          {member.display_name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-200 group-hover:text-indigo-300 truncate">
                            {member.display_name.split('(')[0]}
                          </p>
                          <p className="text-[9px] text-slate-400 truncate">
                            {member.display_name.includes('(') ? member.display_name.split('(')[1].replace(')', '') : member.role}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="h-3.5 w-3.5 text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-transform shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quick 1-Click Admin Access Chip */}
            {portalType === 'admin' && (
              <div className="pt-3 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => {
                    handleAutofillAdmin();
                    signIn('CAChinar', 'admin', 'admin').then((res) => {
                      if (res.success) onSuccess();
                    });
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-indigo-950/30 border border-indigo-500/30 hover:bg-indigo-900/40 text-left transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white font-bold text-xs">
                      CG
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white group-hover:text-indigo-300">
                        1-Click Direct Admin Access
                      </p>
                      <p className="text-[10px] text-indigo-300">CA Chinar Gulati (Managing Partner)</p>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            )}

          </div>
        </div>

      </div>

      {/* Footer Branding */}
      <footer className="mt-8 text-center text-[11px] text-slate-500">
        © {new Date().getFullYear()} Chinar Gulati & Co. Chartered Accountants • Virtual CA Desk Practice System
      </footer>
    </div>
  );
};
