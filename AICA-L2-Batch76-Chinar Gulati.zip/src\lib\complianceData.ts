import { ComplianceItem } from '../types';

export const STATUTORY_COMPLIANCES: Omit<ComplianceItem, 'id' | 'due_date'>[] = [
  // GST Compliances
  {
    title: 'GSTR-1 Monthly Return (Outward Supplies)',
    category: 'gst',
    form_name: 'Form GSTR-1',
    due_day_or_date: '11th of every month',
    period: 'Monthly (Turnover > 5 Cr or Non-QRMP)',
    authority: 'GSTN Portal (Sec 37)',
    applicable_to: 'All Regular GST Registered Taxpayers',
    penalty_interest_info: 'Late fee Rs. 50/day (Rs. 20 for NIL return) under Sec 47.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'GSTR-1 IFF (Invoice Furnishing Facility - QRMP)',
    category: 'gst',
    form_name: 'Form GSTR-1 (IFF)',
    due_day_or_date: '13th of every month',
    period: 'Monthly (M1 & M2 of Quarter)',
    authority: 'GSTN Portal (Rule 59)',
    applicable_to: 'Taxpayers under QRMP Scheme',
    penalty_interest_info: 'Optional facility for uploading B2B invoices to pass ITC.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'GSTR-3B Monthly Return & Tax Settlement',
    category: 'gst',
    form_name: 'Form GSTR-3B',
    due_day_or_date: '20th of every month',
    period: 'Monthly Summary Return',
    authority: 'GSTN Portal (Sec 39)',
    applicable_to: 'All Regular GST Registered Taxpayers',
    penalty_interest_info: 'Late fee Rs. 50/day + 18% p.a. interest under Sec 50 on net tax liability.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'GSTR-3B Quarterly (QRMP Scheme - Staggered)',
    category: 'gst',
    form_name: 'Form GSTR-3B (Quarterly)',
    due_day_or_date: '22nd / 24th following quarter',
    period: 'Quarterly (Jan-Mar, Apr-Jun, Jul-Sep, Oct-Dec)',
    authority: 'GSTN Portal (Rule 61)',
    applicable_to: 'QRMP Category 1 & Category 2 States',
    penalty_interest_info: 'Late fee Rs. 50/day + Interest on unpaid tax.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },
  {
    title: 'PMT-06 GST Monthly Challan Payment (QRMP)',
    category: 'gst',
    form_name: 'Challan PMT-06',
    due_day_or_date: '25th of M1 & M2 of quarter',
    period: 'Monthly Tax Deposit (QRMP)',
    authority: 'GSTN Portal',
    applicable_to: 'QRMP Scheme Taxpayers (Fixed Sum or Self-Assessment)',
    penalty_interest_info: 'Interest @ 18% p.a. on short tax deposit from 25th till payment.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'CMP-08 Quarterly Challan-cum-Statement',
    category: 'gst',
    form_name: 'Form GST CMP-08',
    due_day_or_date: '18th of month following quarter',
    period: 'Quarterly (Q1, Q2, Q3, Q4)',
    authority: 'GSTN Portal (Sec 10)',
    applicable_to: 'Composition Scheme Taxpayers',
    penalty_interest_info: 'Late fee Rs. 50/day (Rs. 20 for NIL) + 18% interest.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },
  {
    title: 'GSTR-9 & GSTR-9C Annual Return & Self-Reconciliation',
    category: 'gst',
    form_name: 'Form GSTR-9 / 9C',
    due_day_or_date: '31st December',
    period: 'Annual (FY 2025-26)',
    authority: 'GSTN Portal (Sec 44)',
    applicable_to: 'Regular Taxpayers (GSTR-9C mandatory if Turnover > 5 Cr)',
    penalty_interest_info: 'Late fee Rs. 200/day subject to max 0.50% of turnover.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },

  // TDS & TCS Compliances
  {
    title: 'TDS / TCS Monthly Deposit (Challan ITNS 281)',
    category: 'tds',
    form_name: 'Challan ITNS 281',
    due_day_or_date: '7th of every month (30th Apr for March)',
    period: 'Monthly Tax Deduction Deposit',
    authority: 'Income Tax Portal / NSDL TRACES (Sec 200)',
    applicable_to: 'All Corporate & Non-Corporate Tax Deductors (Salary & Non-Salary)',
    penalty_interest_info: 'Mandatory interest @ 1.5% per month or part thereof under Sec 201(1A) from deduction date.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'TDS Quarterly Return — Form 24Q (Salary TDS)',
    category: 'tds',
    form_name: 'Form 24Q',
    due_day_or_date: '31st Jul (Q1), 31st Oct (Q2), 31st Jan (Q3), 31st May (Q4)',
    period: 'Quarterly Salary Deductions (Sec 192)',
    authority: 'TRACES / Income Tax Portal',
    applicable_to: 'All Employers deducting TDS on employee salary',
    penalty_interest_info: 'Late filing fee Rs. 200/day under Sec 234E + Penalty under Sec 271H (Rs. 10,000 to Rs. 1 Lakh).',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },
  {
    title: 'TDS Quarterly Return — Form 26Q (Non-Salary TDS)',
    category: 'tds',
    form_name: 'Form 26Q',
    due_day_or_date: '31st Jul (Q1), 31st Oct (Q2), 31st Jan (Q3), 31st May (Q4)',
    period: 'Quarterly Non-Salary Deductions (Sec 194C, 194J, 194I, 194Q, etc.)',
    authority: 'TRACES / Income Tax Portal',
    applicable_to: 'All Business Deductors making contractor/professional/rent payments',
    penalty_interest_info: 'Late filing fee Rs. 200/day under Sec 234E + Section 271H penalty.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },
  {
    title: 'TCS Quarterly Return — Form 27EQ (Tax Collected at Source)',
    category: 'tds',
    form_name: 'Form 27EQ',
    due_day_or_date: '15th Jul (Q1), 15th Oct (Q2), 15th Jan (Q3), 15th May (Q4)',
    period: 'Quarterly TCS Collections (Sec 206C / 206C(1H) / 206C(1G))',
    authority: 'TRACES / Income Tax Portal',
    applicable_to: 'Sellers of scrap, minerals, foreign remittance, car sales > 10L',
    penalty_interest_info: 'Late fee Rs. 200/day under Sec 234E + Section 271H penalty.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },
  {
    title: 'Form 16 Annual Salary TDS Certificate Issuance',
    category: 'tds',
    form_name: 'Form 16 (Part A & B)',
    due_day_or_date: '15th June',
    period: 'Annual Salary TDS Certificate',
    authority: 'TRACES Portal',
    applicable_to: 'Employers to Employees',
    penalty_interest_info: 'Penalty Rs. 100/day under Section 272A(2)(g) for delay.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Form 16A Quarterly Non-Salary TDS Certificate Issuance',
    category: 'tds',
    form_name: 'Form 16A',
    due_day_or_date: '15 days from quarterly return due date',
    period: 'Quarterly (15th Aug, 15th Nov, 15th Feb, 15th Jun)',
    authority: 'TRACES Portal',
    applicable_to: 'All Deductors to Deductees (Vendors/Professionals/Landlords)',
    penalty_interest_info: 'Penalty Rs. 100/day under Section 272A(2)(g) for delay.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  },

  // Income Tax & Advance Tax
  {
    title: 'Advance Tax — 1st Installment (15%)',
    category: 'income_tax',
    form_name: 'Challan ITNS 280 (Advance Tax)',
    due_day_or_date: '15th June',
    period: 'FY 2026-27 (15% of estimated net tax liability)',
    authority: 'Income Tax Portal (Sec 208/211)',
    applicable_to: 'All taxpayers with net tax liability >= Rs. 10,000',
    penalty_interest_info: 'Interest @ 1% per month for 3 months under Section 234C on deferment.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Advance Tax — 2nd Installment (45%)',
    category: 'income_tax',
    form_name: 'Challan ITNS 280 (Advance Tax)',
    due_day_or_date: '15th September',
    period: 'FY 2026-27 (Cumulative 45% of estimated net tax liability)',
    authority: 'Income Tax Portal (Sec 208/211)',
    applicable_to: 'All taxpayers with net tax liability >= Rs. 10,000',
    penalty_interest_info: 'Interest @ 1% per month for 3 months under Section 234C on deferment.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Advance Tax — 3rd Installment (75%)',
    category: 'income_tax',
    form_name: 'Challan ITNS 280 (Advance Tax)',
    due_day_or_date: '15th December',
    period: 'FY 2026-27 (Cumulative 75% of estimated net tax liability)',
    authority: 'Income Tax Portal (Sec 208/211)',
    applicable_to: 'All taxpayers with net tax liability >= Rs. 10,000',
    penalty_interest_info: 'Interest @ 1% per month for 3 months under Section 234C on deferment.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Advance Tax — 4th Installment (100%)',
    category: 'income_tax',
    form_name: 'Challan ITNS 280 (Advance Tax)',
    due_day_or_date: '15th March',
    period: 'FY 2026-27 (100% of estimated net tax liability)',
    authority: 'Income Tax Portal (Sec 208/211)',
    applicable_to: 'All taxpayers (including Presumptive 44AD/44ADA 100% single installment)',
    penalty_interest_info: 'Interest @ 1% per month under Section 234B & 234C.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Non-Audit ITR Filing (ITR-1, ITR-2, ITR-4)',
    category: 'income_tax',
    form_name: 'ITR-1 / ITR-2 / ITR-4',
    due_day_or_date: '31st July',
    period: 'AY 2026-27 (Individuals, HUF, Non-Audit Partnership)',
    authority: 'Income Tax e-Filing Portal (Sec 139(1))',
    applicable_to: 'Salaried, Professionals (44ADA), Small Businesses (44AD), Capital Gains',
    penalty_interest_info: 'Late fee Rs. 5,000 (Rs. 1,000 for income < 5L) under Sec 234F + Interest under Sec 234A.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },

  // Tax Audit & Corporate Filing
  {
    title: 'Tax Audit Report Filing (Form 3CA/3CB-3CD) & UDIN',
    category: 'tax_audit',
    form_name: 'Form 3CA-3CD / 3CB-3CD',
    due_day_or_date: '30th September',
    period: 'AY 2026-27 (Sec 44AB)',
    authority: 'Income Tax Portal & ICAI UDIN Portal',
    applicable_to: 'Business Turnover > 1 Cr (or 10 Cr if cash < 5%) & Professionals Gross Receipts > 50 Lakhs (75L)',
    penalty_interest_info: 'Penalty 0.5% of turnover subject to maximum Rs. 1,50,000 under Section 271B.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Corporate & Tax Audit ITR Filing (ITR-6, ITR-5, ITR-7)',
    category: 'tax_audit',
    form_name: 'ITR-6 / ITR-5 / ITR-7',
    due_day_or_date: '31st October',
    period: 'AY 2026-27 (Corporate & Audited Entities)',
    authority: 'Income Tax e-Filing Portal (Sec 139(1))',
    applicable_to: 'Companies, Audited LLPs/Firms, Working Partners of Audited Firms',
    penalty_interest_info: 'Late fee Rs. 5,000 under Sec 234F + Interest under Sec 234A.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Transfer Pricing Report Filing (Form 3CEB)',
    category: 'tax_audit',
    form_name: 'Form 3CEB',
    due_day_or_date: '31st October',
    period: 'AY 2026-27 (International / Specified Domestic Transactions)',
    authority: 'Income Tax Portal (Sec 92E)',
    applicable_to: 'Entities with International / Domestic Transfer Pricing Transactions',
    penalty_interest_info: 'Penalty Rs. 1,00,000 under Section 271BA for non-filing.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },

  // ROC & Labor Laws
  {
    title: 'EPF & ESI Monthly Contribution & ECR Filing',
    category: 'pf_esi',
    form_name: 'EPFO ECR & ESIC Monthly Challan',
    due_day_or_date: '15th of every month',
    period: 'Monthly Labor Law Compliance',
    authority: 'Unified EPFO & ESIC Portals',
    applicable_to: 'Establishments with >= 20 employees (EPF) and >= 10 employees (ESI)',
    penalty_interest_info: 'Damages @ 5% to 25% p.a. under Sec 14B + 12% interest under Sec 7Q for delay.',
    is_recurring: true,
    recurrence_type: 'monthly',
  },
  {
    title: 'DIR-3 KYC Annual Director KYC Filing',
    category: 'roc',
    form_name: 'Form DIR-3 KYC / Web KYC',
    due_day_or_date: '30th September',
    period: 'Annual Director KYC (FY 2025-26)',
    authority: 'MCA21 Portal (Rule 12A)',
    applicable_to: 'All Individuals holding Director Identification Number (DIN)',
    penalty_interest_info: 'Late fee Rs. 5,000 per DIN and DIN deactivation on delay.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Form AOC-4 Financial Statements Filing with ROC',
    category: 'roc',
    form_name: 'Form AOC-4 / AOC-4 XBRL',
    due_day_or_date: '29th October (30 days from AGM)',
    period: 'Annual Financial Statements (FY 2025-26)',
    authority: 'MCA21 V3 Portal (Sec 137)',
    applicable_to: 'All Private Limited & Public Limited Companies',
    penalty_interest_info: 'Late fee Rs. 100/day without upper limit + Company penalty under Sec 137.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Form MGT-7 / 7A Annual Return Filing with ROC',
    category: 'roc',
    form_name: 'Form MGT-7 / MGT-7A (OPC/Small Co)',
    due_day_or_date: '29th November (60 days from AGM)',
    period: 'Annual Return (FY 2025-26)',
    authority: 'MCA21 V3 Portal (Sec 92)',
    applicable_to: 'All Registered Companies',
    penalty_interest_info: 'Late fee Rs. 100/day + Director & Company fines under Sec 92.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'Form DPT-3 Return of Deposits & Outstanding Loans',
    category: 'roc',
    form_name: 'Form DPT-3',
    due_day_or_date: '30th June',
    period: 'Annual Return of Deposits & Non-Deposit Loans as on 31st March',
    authority: 'MCA21 Portal (Rule 16)',
    applicable_to: 'All Companies except Banking & NBFCs',
    penalty_interest_info: 'Penalty under Section 76A and Rule 21.',
    is_recurring: true,
    recurrence_type: 'yearly',
  },
  {
    title: 'MSME-1 Half-Yearly Return of Outstanding Dues',
    category: 'roc',
    form_name: 'Form MSME-1',
    due_day_or_date: '30th April (H2) & 31st October (H1)',
    period: 'Half-Yearly Specified Outstanding to MSME Suppliers > 45 Days',
    authority: 'MCA21 Portal',
    applicable_to: 'All Companies having delayed payments to Micro & Small Enterprises',
    penalty_interest_info: 'Penalty under Section 405 of Companies Act, 2013.',
    is_recurring: true,
    recurrence_type: 'quarterly',
  }
];

/**
 * Generate full compliance list with exact ISO due dates for a given month and year
 */
export function generateMonthlyCompliances(year: number, month: number): ComplianceItem[] {
  // month is 1-indexed (1 to 12)
  const pad = (n: number) => n.toString().padStart(2, '0');
  const monthStr = pad(month);

  const items: ComplianceItem[] = [];

  // Monthly items
  // 7th: TDS deposit
  items.push({
    id: `comp_tds_dep_${year}_${monthStr}`,
    title: 'TDS / TCS Monthly Deposit (Challan ITNS 281)',
    category: 'tds',
    form_name: 'Challan ITNS 281',
    due_day_or_date: `7th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-07`,
    period: `Deductions of ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'Income Tax & TRACES (Sec 200)',
    applicable_to: 'All Deductors (Salary & Non-Salary TDS)',
    penalty_interest_info: 'Mandatory interest @ 1.5% per month or part under Sec 201(1A).',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // 11th: GSTR-1
  items.push({
    id: `comp_gstr1_${year}_${monthStr}`,
    title: 'GSTR-1 Monthly Return of Outward Supplies',
    category: 'gst',
    form_name: 'Form GSTR-1',
    due_day_or_date: `11th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-11`,
    period: `Monthly Outward Supplies for ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'GSTN Portal (Sec 37)',
    applicable_to: 'Regular Taxpayers (Turnover > 5 Cr or Non-QRMP)',
    penalty_interest_info: 'Late fee Rs. 50/day (Rs. 20 for NIL).',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // 13th: GSTR-1 IFF (QRMP)
  items.push({
    id: `comp_iff_${year}_${monthStr}`,
    title: 'GSTR-1 IFF (Invoice Furnishing Facility - QRMP)',
    category: 'gst',
    form_name: 'Form GSTR-1 (IFF)',
    due_day_or_date: `13th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-13`,
    period: `B2B Invoices for ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'GSTN Portal (Rule 59)',
    applicable_to: 'QRMP Scheme Taxpayers',
    penalty_interest_info: 'Optional facility to pass ITC to buyers.',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // 15th: PF & ESI
  items.push({
    id: `comp_pf_${year}_${monthStr}`,
    title: 'EPF & ESI Monthly Contribution & ECR',
    category: 'pf_esi',
    form_name: 'EPFO ECR & ESIC Challan',
    due_day_or_date: `15th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-15`,
    period: `Wage Month of ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'EPFO & ESIC Unified Portals',
    applicable_to: 'All Covered Employers (EPF/ESI)',
    penalty_interest_info: 'Damages 5% to 25% + 12% interest for delay.',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // 20th: GSTR-3B
  items.push({
    id: `comp_gstr3b_${year}_${monthStr}`,
    title: 'GSTR-3B Monthly Return & Tax Settlement',
    category: 'gst',
    form_name: 'Form GSTR-3B',
    due_day_or_date: `20th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-20`,
    period: `Monthly Summary & ITC for ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'GSTN Portal (Sec 39)',
    applicable_to: 'All Regular GST Registered Taxpayers',
    penalty_interest_info: 'Late fee Rs. 50/day + 18% p.a. interest under Sec 50 on net cash tax liability.',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // 25th: PMT-06 (QRMP)
  items.push({
    id: `comp_pmt06_${year}_${monthStr}`,
    title: 'PMT-06 GST Monthly Tax Payment (QRMP Scheme)',
    category: 'gst',
    form_name: 'Challan PMT-06',
    due_day_or_date: `25th ${getMonthName(month)} ${year}`,
    due_date: `${year}-${monthStr}-25`,
    period: `Tax Payment for ${getMonthName(month === 1 ? 12 : month - 1)}`,
    authority: 'GSTN Portal',
    applicable_to: 'Taxpayers under QRMP Scheme',
    penalty_interest_info: 'Interest @ 18% p.a. on short tax deposit from 25th till payment date.',
    is_recurring: true,
    recurrence_type: 'monthly',
  });

  // Specific Month / Quarterly Milestones:
  // Month 1 (January):
  if (month === 1) {
    items.push({
      id: `comp_q3_24q_${year}`,
      title: 'TDS Quarterly Return (Q3) — Form 24Q & 26Q',
      category: 'tds',
      form_name: 'Form 24Q / 26Q',
      due_day_or_date: `31st January ${year}`,
      due_date: `${year}-01-31`,
      period: 'Q3 (October - December)',
      authority: 'TRACES / Income Tax Portal',
      applicable_to: 'All Business & Employer Deductors',
      penalty_interest_info: 'Late fee Rs. 200/day under Sec 234E + Section 271H penalty.',
      is_recurring: true,
      recurrence_type: 'quarterly',
    });
  }

  // Month 3 (March):
  if (month === 3) {
    items.push({
      id: `comp_adv_tax_q4_${year}`,
      title: 'Advance Tax — 4th Installment (100%)',
      category: 'income_tax',
      form_name: 'Challan ITNS 280 (Advance Tax)',
      due_day_or_date: `15th March ${year}`,
      due_date: `${year}-03-15`,
      period: `FY ${year - 1}-${year.toString().slice(-2)} (100% Tax)`,
      authority: 'Income Tax Portal (Sec 208/211)',
      applicable_to: 'All Taxpayers (and Presumptive 44AD/44ADA single installment)',
      penalty_interest_info: 'Interest @ 1% per month under Sec 234B & 234C on short payment.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Month 5 (May):
  if (month === 5) {
    items.push({
      id: `comp_q4_24q_${year}`,
      title: 'TDS Quarterly Return (Q4) — Form 24Q & 26Q',
      category: 'tds',
      form_name: 'Form 24Q / 26Q',
      due_day_or_date: `31st May ${year}`,
      due_date: `${year}-05-31`,
      period: 'Q4 (January - March)',
      authority: 'TRACES / Income Tax Portal',
      applicable_to: 'All Deductors',
      penalty_interest_info: 'Late fee Rs. 200/day under Sec 234E.',
      is_recurring: true,
      recurrence_type: 'quarterly',
    });
  }

  // Month 6 (June):
  if (month === 6) {
    items.push({
      id: `comp_adv_tax_q1_${year}`,
      title: 'Advance Tax — 1st Installment (15%)',
      category: 'income_tax',
      form_name: 'Challan ITNS 280',
      due_day_or_date: `15th June ${year}`,
      due_date: `${year}-06-15`,
      period: `FY ${year}-${(year + 1).toString().slice(-2)}`,
      authority: 'Income Tax Portal',
      applicable_to: 'All Taxpayers with tax >= 10K',
      penalty_interest_info: 'Interest @ 1% p.m. under Sec 234C.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_form16_${year}`,
      title: 'Form 16 Annual Salary TDS Certificate Issuance',
      category: 'tds',
      form_name: 'Form 16',
      due_day_or_date: `15th June ${year}`,
      due_date: `${year}-06-15`,
      period: `FY ${year - 1}-${year.toString().slice(-2)}`,
      authority: 'TRACES Portal',
      applicable_to: 'All Employers',
      penalty_interest_info: 'Penalty Rs. 100/day under Sec 272A(2)(g).',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_dpt3_${year}`,
      title: 'Form DPT-3 Return of Deposits & Non-Deposit Loans',
      category: 'roc',
      form_name: 'Form DPT-3',
      due_day_or_date: `30th June ${year}`,
      due_date: `${year}-06-30`,
      period: `As on 31st March ${year}`,
      authority: 'MCA21 Portal',
      applicable_to: 'All Companies',
      penalty_interest_info: 'Penalty under Section 76A.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Month 7 (July):
  if (month === 7) {
    items.push({
      id: `comp_itr_non_audit_${year}`,
      title: 'Non-Audit ITR Filing (ITR-1, ITR-2, ITR-4)',
      category: 'income_tax',
      form_name: 'ITR-1 / 2 / 4',
      due_day_or_date: `31st July ${year}`,
      due_date: `${year}-07-31`,
      period: `AY ${year}-${(year + 1).toString().slice(-2)}`,
      authority: 'Income Tax e-Filing Portal',
      applicable_to: 'Individuals, HUF, Non-Audit Partnership Firms',
      penalty_interest_info: 'Late fee Rs. 5,000 under Sec 234F + Interest under Sec 234A.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_q1_24q_${year}`,
      title: 'TDS Quarterly Return (Q1) — Form 24Q & 26Q',
      category: 'tds',
      form_name: 'Form 24Q / 26Q',
      due_day_or_date: `31st July ${year}`,
      due_date: `${year}-07-31`,
      period: 'Q1 (April - June)',
      authority: 'TRACES / Income Tax Portal',
      applicable_to: 'All Deductors',
      penalty_interest_info: 'Late fee Rs. 200/day under Sec 234E.',
      is_recurring: true,
      recurrence_type: 'quarterly',
    });
  }

  // Month 8 (August):
  if (month === 8) {
    items.push({
      id: `comp_form16a_q1_${year}`,
      title: 'Form 16A Quarterly TDS Certificate Issuance (Q1)',
      category: 'tds',
      form_name: 'Form 16A',
      due_day_or_date: `15th August ${year}`,
      due_date: `${year}-08-15`,
      period: 'Q1 (April - June)',
      authority: 'TRACES Portal',
      applicable_to: 'All Non-Salary Deductors to Deductees',
      penalty_interest_info: 'Penalty Rs. 100/day under Sec 272A(2)(g).',
      is_recurring: true,
      recurrence_type: 'quarterly',
    });
  }

  // Month 9 (September):
  if (month === 9) {
    items.push({
      id: `comp_adv_tax_q2_${year}`,
      title: 'Advance Tax — 2nd Installment (45%)',
      category: 'income_tax',
      form_name: 'Challan ITNS 280',
      due_day_or_date: `15th September ${year}`,
      due_date: `${year}-09-15`,
      period: `FY ${year}-${(year + 1).toString().slice(-2)}`,
      authority: 'Income Tax Portal',
      applicable_to: 'All Taxpayers with tax >= 10K',
      penalty_interest_info: 'Interest @ 1% p.m. under Sec 234C on deferment.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_tax_audit_${year}`,
      title: 'Tax Audit Report (Form 3CA/3CB-3CD) & UDIN Sign-off',
      category: 'tax_audit',
      form_name: 'Form 3CA-3CD / 3CB-3CD',
      due_day_or_date: `30th September ${year}`,
      due_date: `${year}-09-30`,
      period: `AY ${year}-${(year + 1).toString().slice(-2)} (Sec 44AB)`,
      authority: 'Income Tax Portal & ICAI UDIN Portal',
      applicable_to: 'Auditable Businesses & Professionals (Turnover > 1Cr/10Cr, Gross Receipts > 50L/75L)',
      penalty_interest_info: 'Penalty 0.5% of turnover up to Rs. 1.5 Lakhs under Sec 271B.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_dir3_kyc_${year}`,
      title: 'DIR-3 KYC Annual Director KYC Filing',
      category: 'roc',
      form_name: 'Form DIR-3 KYC / Web KYC',
      due_day_or_date: `30th September ${year}`,
      due_date: `${year}-09-30`,
      period: `Annual Director KYC for FY ${year - 1}-${year.toString().slice(-2)}`,
      authority: 'MCA21 Portal',
      applicable_to: 'All DIN Holders',
      penalty_interest_info: 'Late fee Rs. 5,000 per DIN on delay.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Month 10 (October):
  if (month === 10) {
    items.push({
      id: `comp_q2_24q_${year}`,
      title: 'TDS Quarterly Return (Q2) — Form 24Q & 26Q',
      category: 'tds',
      form_name: 'Form 24Q / 26Q',
      due_day_or_date: `31st October ${year}`,
      due_date: `${year}-10-31`,
      period: 'Q2 (July - September)',
      authority: 'TRACES / Income Tax Portal',
      applicable_to: 'All Deductors',
      penalty_interest_info: 'Late fee Rs. 200/day under Sec 234E.',
      is_recurring: true,
      recurrence_type: 'quarterly',
    });
    items.push({
      id: `comp_corp_itr_${year}`,
      title: 'Corporate & Audit ITR Filing (ITR-6, ITR-5, ITR-7)',
      category: 'tax_audit',
      form_name: 'ITR-6 / 5 / 7',
      due_day_or_date: `31st October ${year}`,
      due_date: `${year}-10-31`,
      period: `AY ${year}-${(year + 1).toString().slice(-2)}`,
      authority: 'Income Tax e-Filing Portal',
      applicable_to: 'Companies, Audited LLPs/Firms, Working Partners',
      penalty_interest_info: 'Late fee Rs. 5,000 under Sec 234F + Interest under Sec 234A.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_aoc4_${year}`,
      title: 'Form AOC-4 Financial Statements Filing with ROC',
      category: 'roc',
      form_name: 'Form AOC-4 / XBRL',
      due_day_or_date: `29th October ${year}`,
      due_date: `${year}-10-29`,
      period: `Financial Statements for FY ${year - 1}-${year.toString().slice(-2)}`,
      authority: 'MCA21 V3 Portal',
      applicable_to: 'All Private & Public Companies',
      penalty_interest_info: 'Late fee Rs. 100/day without upper limit.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Month 11 (November):
  if (month === 11) {
    items.push({
      id: `comp_mgt7_${year}`,
      title: 'Form MGT-7 / 7A Annual Return Filing with ROC',
      category: 'roc',
      form_name: 'Form MGT-7 / MGT-7A',
      due_day_or_date: `29th November ${year}`,
      due_date: `${year}-11-29`,
      period: `Annual Return for FY ${year - 1}-${year.toString().slice(-2)}`,
      authority: 'MCA21 V3 Portal',
      applicable_to: 'All Companies',
      penalty_interest_info: 'Late fee Rs. 100/day + Director penalties.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Month 12 (December):
  if (month === 12) {
    items.push({
      id: `comp_adv_tax_q3_${year}`,
      title: 'Advance Tax — 3rd Installment (75%)',
      category: 'income_tax',
      form_name: 'Challan ITNS 280',
      due_day_or_date: `15th December ${year}`,
      due_date: `${year}-12-15`,
      period: `FY ${year}-${(year + 1).toString().slice(-2)}`,
      authority: 'Income Tax Portal',
      applicable_to: 'All Taxpayers with tax >= 10K',
      penalty_interest_info: 'Interest @ 1% p.m. under Sec 234C on deferment.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
    items.push({
      id: `comp_gstr9_${year}`,
      title: 'GSTR-9 & GSTR-9C Annual Return & Self-Reconciliation',
      category: 'gst',
      form_name: 'Form GSTR-9 / 9C',
      due_day_or_date: `31st December ${year}`,
      due_date: `${year}-12-31`,
      period: `Annual GST Return for FY ${year - 1}-${year.toString().slice(-2)}`,
      authority: 'GSTN Portal (Sec 44)',
      applicable_to: 'Regular GST Taxpayers (GSTR-9C if Turnover > 5 Cr)',
      penalty_interest_info: 'Late fee Rs. 200/day subject to max 0.50% turnover.',
      is_recurring: true,
      recurrence_type: 'yearly',
    });
  }

  // Sort chronologically by due_date
  return items.sort((a, b) => a.due_date.localeCompare(b.due_date));
}

function getMonthName(m: number): string {
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return months[(m - 1 + 12) % 12];
}
