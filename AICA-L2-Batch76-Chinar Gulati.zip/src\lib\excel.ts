import * as XLSX from 'xlsx';
import { Client } from '../types';

export function exportClientsToExcel(clients: Client[], fileName = 'Praxis_ITR_Clients.xlsx') {
  const data = clients.map((c, i) => ({
    'Sr No': i + 1,
    'Client Name': c.name,
    'PAN': c.pan,
    'Mobile': c.mobile || c.contact_phone || '',
    'Email': c.contact_email || '',
    'Assessment Year': c.assessment_year || '',
    'ITR Type': c.itr_type || '',
    'Filing Status': c.filing_status,
    'Category': c.category || '',
    'Assigned To': c.assigned_to || '',
    'Notes': c.notes || '',
    'Last Updated': c.updated_at ? new Date(c.updated_at).toLocaleDateString() : '',
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'ITR Clients');
  XLSX.writeFile(workbook, fileName);
}

export function parseExcelFile(file: File): Promise<Partial<Client>[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buffer = e.target?.result;
        const workbook = XLSX.read(buffer, { type: 'binary' });
        const firstSheet = workbook.SheetNames[0];
        const rows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);
        
        const clients: Partial<Client>[] = rows.map((r) => {
          const name = r['Client Name'] || r['Name'] || r['name'] || 'Unnamed Client';
          const pan = (r['PAN'] || r['pan'] || '').toString().trim().toUpperCase();
          const mobile = (r['Mobile'] || r['Phone'] || r['mobile'] || '').toString().trim();
          const email = (r['Email'] || r['email'] || '').toString().trim();
          const ay = r['Assessment Year'] || r['AY'] || '2026-27';
          const itrType = r['ITR Type'] || r['ITR'] || 'ITR-1';
          const status = r['Filing Status'] || r['Status'] || 'not_started';

          return {
            name,
            pan,
            mobile,
            contact_phone: mobile,
            contact_email: email,
            assessment_year: ay,
            itr_type: itrType,
            filing_status: status,
          };
        });

        resolve(clients);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsBinaryString(file);
  });
}
