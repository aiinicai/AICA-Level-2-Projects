import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { ArrowRight, UserCheck, Shield, AlertCircle } from 'lucide-react';
import { Task } from '../../types';
import { useData } from '../../context/DataContext';

interface TaskReassignModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
}

export const TaskReassignModal: React.FC<TaskReassignModalProps> = ({
  isOpen,
  onClose,
  task,
}) => {
  const { team, reassignTask } = useData();
  const [selectedAssignee, setSelectedAssignee] = useState<string>('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  React.useEffect(() => {
    if (task) {
      setSelectedAssignee(task.assigned_to || '');
      setReason('');
      setError('');
    }
  }, [task, isOpen]);

  if (!task) return null;

  const currentMember = team.find((m) => m.id === task.assigned_to);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssignee) {
      setError('Please select a staff member to assign this task to');
      return;
    }
    if (selectedAssignee === task.assigned_to) {
      setError('Selected staff member is already assigned to this task');
      return;
    }

    setIsSubmitting(true);
    try {
      reassignTask(task.id, selectedAssignee, reason.trim());
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Reassign Task Ownership"
      description="Transfer task responsibility to another staff member with handover instructions."
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-2.5 text-xs text-destructive font-medium border border-destructive/20">
            {error}
          </div>
        )}

        {/* Task Summary Banner */}
        <div className="rounded-xl border border-border bg-muted/40 p-3.5 space-y-2">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
            Task Subject
          </p>
          <h4 className="text-xs font-bold text-foreground line-clamp-2">
            {task.title}
          </h4>
          {task.client && (
            <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
              <span>🏢 {task.client.name}</span>
              <span>•</span>
              <span className="font-mono">{task.client.pan}</span>
            </p>
          )}
        </div>

        {/* Transfer Visualizer */}
        <div className="grid grid-cols-5 items-center gap-2 rounded-xl border border-border p-3 bg-card text-center">
          <div className="col-span-2 space-y-1">
            <span className="text-[10px] uppercase font-bold text-muted-foreground">Current Assignee</span>
            <div className="p-2 rounded-lg bg-secondary/50 border border-border/80 text-xs font-semibold text-foreground truncate">
              {currentMember ? currentMember.display_name.split('(')[0] : 'Unassigned'}
            </div>
          </div>

          <div className="flex justify-center text-primary">
            <ArrowRight className="h-5 w-5 animate-pulse" />
          </div>

          <div className="col-span-2 space-y-1">
            <span className="text-[10px] uppercase font-bold text-primary">New Assignee</span>
            <div className="p-2 rounded-lg bg-primary/10 border border-primary/30 text-xs font-bold text-primary truncate">
              {team.find((m) => m.id === selectedAssignee)?.display_name.split('(')[0] || 'Select Below'}
            </div>
          </div>
        </div>

        {/* Select Target Staff */}
        <Select
          label="Assign Task To *"
          value={selectedAssignee}
          onChange={(e) => {
            setSelectedAssignee(e.target.value);
            setError('');
          }}
          required
        >
          <option value="">— Select Staff Member —</option>
          {team.map((member) => (
            <option key={member.id} value={member.id}>
              {member.display_name} ({member.role.toUpperCase()})
            </option>
          ))}
        </Select>

        {/* Reason / Handover Notes */}
        <Textarea
          label="Reassignment Reason & Handover Notes"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. Delegated to Ankit for Form 15CB calculation and TRC verification..."
          rows={3}
        />

        <div className="rounded-lg bg-info/10 p-2.5 text-xs text-info flex items-start gap-2 border border-info/20">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>
            The task will automatically appear in the newly assigned employee's task queue and discussion notes will record this transfer audit trail.
          </span>
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border/60">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={isSubmitting} className="bg-gradient-primary shadow-soft">
            Confirm Reassignment
          </Button>
        </div>
      </form>
    </Modal>
  );
};
