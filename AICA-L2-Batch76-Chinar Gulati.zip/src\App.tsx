import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { Sidebar } from './components/layout/Sidebar';
import { Navbar } from './components/layout/Navbar';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';
import { TaxAuditPage } from './pages/TaxAuditPage';
import { CertificatesPage } from './pages/CertificatesPage';
import { TasksPage } from './pages/TasksPage';
import { ChatPage } from './pages/ChatPage';
import { WorkboardPage } from './pages/WorkboardPage';
import { ITRPage } from './pages/ITRPage';
import { ClientsPage } from './pages/ClientsPage';
import { ClientDetailPage } from './pages/ClientDetailPage';
import { MeetingsPage } from './pages/MeetingsPage';
import { CalendarPage } from './pages/CalendarPage';
import { TeamPage } from './pages/TeamPage';
import { AttendancePage } from './pages/AttendancePage';
import { SettingsPage } from './pages/SettingsPage';
import { TaskDialog } from './components/tasks/TaskDialog';
import { MeetingDialog } from './components/meetings/MeetingDialog';
import { ITRClientDialog } from './components/itr/ITRClientDialog';
import { WorkItemDialog } from './components/workboard/WorkItemDialog';
import { TaxAuditDialog } from './components/tax-audit/TaxAuditDialog';
import { CertificateDialog } from './components/certificates/CertificateDialog';
import { FloatingChatWidget } from './components/chat/FloatingChatWidget';
import { Lock, ShieldAlert } from 'lucide-react';
import { Button } from './components/ui/Button';

function AccessRestrictedCard({ onReturn }: { onReturn: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center p-12 rounded-2xl border border-border bg-card shadow-soft max-w-lg mx-auto text-center space-y-4 my-12">
      <div className="h-12 w-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
        <Lock className="h-6 w-6" />
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-bold text-foreground">Access Restricted — Partner Access Only</h3>
        <p className="text-xs text-muted-foreground">
          This section contains confidential firm management or financial billing records. Only the Managing Partner (CA Chinar Gulati) has authorization.
        </p>
      </div>
      <Button onClick={onReturn} className="text-xs bg-gradient-primary">
        Return to My Workspace
      </Button>
    </div>
  );
}

function AppContent() {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();

  const [route, setRoute] = useState<string>(() => {
    return window.location.hash ? window.location.hash.replace('#', '') : '/dashboard';
  });

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [quickAddType, setQuickAddType] = useState<'task' | 'meeting' | 'client' | 'work' | 'audit' | 'cert' | null>(null);

  useEffect(() => {
    const handleHashChange = () => {
      const h = window.location.hash.replace('#', '');
      if (h) setRoute(h);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = (newRoute: string) => {
    window.location.hash = newRoute;
    setRoute(newRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <img src="/ca-logo.png" alt="CA Logo" className="h-12 w-auto animate-pulse" />
          <div className="h-6 w-6 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin" />
          <span className="text-xs font-semibold text-slate-300">Loading Virtual CA Desk…</span>
        </div>
      </div>
    );
  }

  // If not authenticated, always display the branded Login Page first
  if (!isAuthenticated) {
    return (
      <AuthPage
        onSuccess={() => navigate('/dashboard')}
      />
    );
  }

  const isClientDetail = route.startsWith('/clients/') || route.startsWith('/itr/clients/');
  const selectedClientId = isClientDetail ? route.split('/').pop() || '' : '';

  const getPageTitle = () => {
    if (route === '/dashboard') return 'Virtual CA Desk';
    if (route === '/chat') return 'Staff Chat & Firm Announcements';
    if (route === '/tasks') return 'Tasks & Practice Flow';
    if (route === '/tax-audit') return 'Tax Audit Hub (Sec 44AB / 3CD)';
    if (route === '/certificates') return 'CA Certifications & UDIN Hub';
    if (route === '/workboard') return 'Workboard & Billing';
    if (route === '/itr') return 'ITR & Compliance Hub';
    if (route === '/clients') return 'Clients Directory';
    if (isClientDetail) return 'Client 360 Workspace';
    if (route === '/meetings') return 'Meeting Manager';
    if (route === '/calendar') return 'Schedule Calendar';
    if (route === '/team') return 'Team & Staff';
    if (route === '/attendance') return 'Attendance & Timesheets';
    if (route === '/settings') return 'Firm Settings';
    return 'Virtual CA Desk — Chinar Gulati & Co.';
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar
        currentRoute={route}
        onNavigate={navigate}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        <Navbar
          onOpenMobileNav={() => setMobileNavOpen(true)}
          onOpenQuickAdd={(type) => setQuickAddType(type)}
          pageTitle={getPageTitle()}
        />

        <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 lg:px-8">
          {route === '/dashboard' && <DashboardPage onNavigate={navigate} />}
          {route === '/chat' && <ChatPage />}
          {route === '/tasks' && <TasksPage />}
          {route === '/tax-audit' && (isAdmin ? <TaxAuditPage /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {route === '/certificates' && (isAdmin ? <CertificatesPage /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {route === '/workboard' && (isAdmin ? <WorkboardPage /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {route === '/itr' && <ITRPage onOpenClient={(id) => navigate(`/clients/${id}`)} />}
          {route === '/clients' && (isAdmin ? <ClientsPage onOpenClient={(id) => navigate(`/clients/${id}`)} /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {isClientDetail && <ClientDetailPage clientId={selectedClientId} onBack={() => navigate('/itr')} />}
          {route === '/meetings' && <MeetingsPage />}
          {route === '/calendar' && <CalendarPage />}
          {route === '/team' && (isAdmin ? <TeamPage /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {route === '/attendance' && <AttendancePage />}
          {route === '/settings' && (isAdmin ? <SettingsPage /> : <AccessRestrictedCard onReturn={() => navigate('/dashboard')} />)}
          {route === '/' && <DashboardPage onNavigate={navigate} />}
        </main>
      </div>

      {/* Floating Quick Chat Widget for Global Access */}
      <FloatingChatWidget />

      {/* Quick Add Modals */}
      <TaskDialog
        isOpen={quickAddType === 'task'}
        onClose={() => setQuickAddType(null)}
      />
      <MeetingDialog
        isOpen={quickAddType === 'meeting'}
        onClose={() => setQuickAddType(null)}
      />
      <ITRClientDialog
        isOpen={quickAddType === 'client'}
        onClose={() => setQuickAddType(null)}
      />
      <WorkItemDialog
        isOpen={quickAddType === 'work'}
        onClose={() => setQuickAddType(null)}
      />
      <TaxAuditDialog
        isOpen={quickAddType === 'audit'}
        onClose={() => setQuickAddType(null)}
      />
      <CertificateDialog
        isOpen={quickAddType === 'cert'}
        onClose={() => setQuickAddType(null)}
      />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;
