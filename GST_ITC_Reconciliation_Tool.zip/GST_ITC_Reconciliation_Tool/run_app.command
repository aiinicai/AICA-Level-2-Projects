#!/bin/bash
cd "$(dirname "$0")"
echo "Installing required packages, this may take a minute the first time..."
python3 -m pip install -r requirements.txt
echo "Starting the app..."
python3 -m streamlit run app.py
