"""
GST ITC Reconciliation Tool
----------------------------
A beginner-friendly Streamlit app that reconciles a client's Purchase
Register (purchases, expenses, debit notes and credit notes) against their
GSTR-2B data, and flags Input Tax Credit (ITC) mismatches so claims can be
verified before filing GSTR-3B.

How it works (in plain terms):
1. User uploads two Excel files: Purchase Register and GSTR-2B. A third,
   optional file for ITC carried forward from earlier periods is supported
   too (see "Carry-forward" below).
2. The Purchase Register can hold four kinds of entries: Purchase, Expense,
   Debit Note, Credit Note (a "Document Type" column). Credit notes reduce
   available ITC; everything else adds to it.
3. Matching invoices:
   - Where GSTIN is available on both sides, invoices are matched on
     GSTIN + Invoice Number (the normal, reliable case).
   - Where GSTIN is missing on either side (common for small/unregistered
     vendors, or Excel exports that drop it), the tool falls back to
     Supplier Name + Invoice Number + Invoice Date as the matching key.
4. Tax is never consolidated: CGST, SGST and IGST are compared and reported
   as separate columns throughout, never folded into one "Total Tax" figure
   in the detail sheets.
5. Every invoice is bucketed into one of four categories:
   - Matched               : found in both, amounts agree (within tolerance)
   - Mismatched Amount     : found in both, but Taxable Value/CGST/SGST/IGST differ
   - Missing in GSTR-2B    : in Purchase Register but not in GSTR-2B (ITC at risk)
   - Unclaimed ITC Available : in GSTR-2B but not booked/claimed by the client
6. A Purchase Register row can also be flagged "ITC Reversal = Yes" (Rule
   38/42/43 or Section 17(5) blocked credit). These get their own "ITC
   Reversal" sheet (mirroring GSTR-3B Table 4(B)), cross-checked against
   whether that invoice is actually reflected in GSTR-2B.
7. Results are shown on screen and can be downloaded as a single Excel
   report: a counts summary, an amounts summary (CGST/SGST/IGST kept
   separate, including reversal and net-ITC-after-reversal), and one sheet
   per category.

Carry-forward (previous period unclaimed ITC):
GSTR-2B for a month can include invoices the client never claimed earlier,
and under the current IMS-based system such credit stays available until
claimed, not just in that one month. So the app accepts an optional third
file: "Previous Period(s) Unclaimed ITC" (same column format as GSTR-2B).
Its rows are added to the current GSTR-2B pool before matching, tagged as
"Carried Forward", so they get picked up as claimable this period too. The
"Unclaimed ITC Available" sheet in the output is itself in the right format
to re-upload as next month's "previous period" file, closing the loop.

Run with:  streamlit run app.py
"""

import io
from datetime import datetime

import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Page setup
# ---------------------------------------------------------------------------
st.set_page_config(page_title="GST ITC Reconciliation Tool", layout="wide")

st.title("GST ITC Reconciliation Tool")
st.caption(
    "Reconcile Purchases, Expenses, Debit Notes and Credit Notes against "
    "GSTR-2B and flag ITC mismatches before filing GSTR-3B."
)

# Amount difference (in Rs.) below which we still treat two values as "matched".
# Small rounding differences between books and the GST portal are normal.
TOLERANCE = 1.0

# Columns every uploaded file must have.
REQUIRED_COLUMNS = ["Supplier Name", "Invoice Number", "Invoice Date", "Taxable Value", "CGST", "SGST", "IGST"]

# Columns that are nice to have but get a safe default when missing.
OPTIONAL_COLUMN_DEFAULTS = {"GSTIN": "", "Document Type": "Purchase", "ITC Reversal": "No", "Reversal Basis": ""}

DOCUMENT_TYPES = ["Purchase", "Expense", "Debit Note", "Credit Note"]


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------
def load_excel(uploaded_file) -> pd.DataFrame:
    """Read an uploaded Excel file into a cleaned-up DataFrame."""
    df = pd.read_excel(uploaded_file)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def validate_columns(df: pd.DataFrame) -> list:
    """Return a list of missing required columns, if any."""
    return [c for c in REQUIRED_COLUMNS if c not in df.columns]


def ensure_optional_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Fill in optional columns (GSTIN, Document Type) with safe defaults
    when the uploaded file doesn't have them at all."""
    df = df.copy()
    for col, default in OPTIONAL_COLUMN_DEFAULTS.items():
        if col not in df.columns:
            df[col] = default
    return df


def is_valid_gstin(value) -> bool:
    """A very light GSTIN sanity check: 15 alphanumeric characters."""
    s = str(value).strip().upper()
    return len(s) == 15 and s.isalnum()


def normalize_document_type(value) -> str:
    s = str(value).strip().title()
    return s if s in DOCUMENT_TYPES else "Purchase"


def prep(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and standardise a file: fill optional columns, normalise text
    and numbers, and compute the matching keys used for reconciliation."""
    df = ensure_optional_columns(df)
    df = df.copy()

    for col in ["Taxable Value", "CGST", "SGST", "IGST"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    df["Document Type"] = df["Document Type"].apply(normalize_document_type)
    df["GSTIN"] = df["GSTIN"].astype(str).str.strip().str.upper().replace("NAN", "")
    df["Supplier Name"] = df["Supplier Name"].astype(str).str.strip()
    df["Invoice Number"] = df["Invoice Number"].astype(str).str.strip()
    df["ITC Reversal"] = df["ITC Reversal"].apply(
        lambda v: "Yes" if str(v).strip().lower() in ("yes", "y", "true", "1") else "No"
    )
    df["Reversal Basis"] = df["Reversal Basis"].apply(lambda v: "" if pd.isna(v) else str(v).strip())

    supplier_norm = df["Supplier Name"].str.upper()
    invoice_norm = df["Invoice Number"].str.upper()
    date_norm = pd.to_datetime(df["Invoice Date"], errors="coerce").dt.date.astype(str)

    df["_gstin_valid"] = df["GSTIN"].apply(is_valid_gstin)
    df["_gstin_key"] = df["GSTIN"] + "|" + invoice_norm
    df["_name_key"] = supplier_norm + "|" + invoice_norm + "|" + date_norm
    df["_row_id"] = range(len(df))
    return df


def _signed(df: pd.DataFrame, col: str) -> pd.Series:
    """A Credit Note reduces ITC; everything else adds to it."""
    sign = df["Document Type"].apply(lambda d: -1 if normalize_document_type(d) == "Credit Note" else 1)
    return df[col] * sign


def signed_head_sums(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"CGST": 0.0, "SGST": 0.0, "IGST": 0.0}
    return {
        "CGST": round(_signed(df, "CGST").sum(), 2),
        "SGST": round(_signed(df, "SGST").sum(), 2),
        "IGST": round(_signed(df, "IGST").sum(), 2),
    }


def build_gstr2b_pool(current_gstr2b: pd.DataFrame, previous_unclaimed: pd.DataFrame = None) -> pd.DataFrame:
    """Combine current GSTR-2B with any carried-forward unclaimed invoices
    from earlier periods, so this period's reconciliation also catches ITC
    that was available before but never claimed. If an invoice shows up in
    both, the current period's row wins (it has re-surfaced in this 2B)."""
    current = ensure_optional_columns(current_gstr2b).copy()
    current["Source"] = "Current 2B"

    if previous_unclaimed is None or previous_unclaimed.empty:
        return current

    previous = ensure_optional_columns(previous_unclaimed).copy()
    previous["Source"] = "Carried Forward (Prior Period)"

    pool = pd.concat([current, previous], ignore_index=True)
    pool["_dedupe_key"] = (
        pool["GSTIN"].astype(str).str.strip().str.upper()
        + "|"
        + pool["Supplier Name"].astype(str).str.strip().str.upper()
        + "|"
        + pool["Invoice Number"].astype(str).str.strip().str.upper()
    )
    # keep first occurrence per key; current rows are listed first, so a
    # duplicate carried-forward row is dropped in favour of the current one
    pool = pool.drop_duplicates(subset="_dedupe_key", keep="first").drop(columns="_dedupe_key")
    return pool.reset_index(drop=True)


def two_stage_match(purchase: pd.DataFrame, gstr2b: pd.DataFrame):
    """Match invoices in two passes: first by GSTIN + Invoice Number
    (wherever both sides have a valid GSTIN), then, for whatever is left,
    by Supplier Name + Invoice Number + Invoice Date. Returns
    (matched_both, only_purchase, only_gstr2b)."""
    p = prep(purchase)
    g = prep(gstr2b)

    suffixes = (" (Purchase Reg.)", " (GSTR-2B)")

    # Stage 1: GSTIN-based match
    p_g = p[p["_gstin_valid"]]
    g_g = g[g["_gstin_valid"]]
    stage1 = p_g.merge(g_g, on="_gstin_key", suffixes=suffixes)
    stage1["Match Basis"] = "GSTIN + Invoice Number"

    matched_p_ids = set(stage1["_row_id (Purchase Reg.)"]) if not stage1.empty else set()
    matched_g_ids = set(stage1["_row_id (GSTR-2B)"]) if not stage1.empty else set()

    # Stage 2: fallback match on whatever GSTIN matching didn't resolve
    p_remain = p[~p["_row_id"].isin(matched_p_ids)]
    g_remain = g[~g["_row_id"].isin(matched_g_ids)]
    stage2 = p_remain.merge(g_remain, on="_name_key", suffixes=suffixes)
    stage2["Match Basis"] = "Supplier Name + Invoice No. + Date (GSTIN not available)"

    if not stage2.empty:
        matched_p_ids |= set(stage2["_row_id (Purchase Reg.)"])
        matched_g_ids |= set(stage2["_row_id (GSTR-2B)"])

    matched_both = pd.concat([stage1, stage2], ignore_index=True)
    only_purchase = p[~p["_row_id"].isin(matched_p_ids)].copy()
    only_gstr2b = g[~g["_row_id"].isin(matched_g_ids)].copy()

    return matched_both, only_purchase, only_gstr2b


def reconcile(purchase: pd.DataFrame, gstr2b: pd.DataFrame) -> dict:
    """Core reconciliation logic. Returns a dict of category -> DataFrame."""
    matched_both, only_purchase, only_gstr2b = two_stage_match(purchase, gstr2b)

    display_cols_common = [
        "Document Type (Purchase Reg.)",
        "GSTIN (Purchase Reg.)",
        "Supplier Name (Purchase Reg.)",
        "Invoice Number (Purchase Reg.)",
        "Invoice Date (Purchase Reg.)",
        "Taxable Value (Purchase Reg.)",
        "CGST (Purchase Reg.)",
        "SGST (Purchase Reg.)",
        "IGST (Purchase Reg.)",
        "GSTIN (GSTR-2B)",
        "Supplier Name (GSTR-2B)",
        "Invoice Number (GSTR-2B)",
        "Invoice Date (GSTR-2B)",
        "Taxable Value (GSTR-2B)",
        "CGST (GSTR-2B)",
        "SGST (GSTR-2B)",
        "IGST (GSTR-2B)",
        "Match Basis",
    ]

    if matched_both.empty:
        matched = pd.DataFrame(columns=display_cols_common)
        mismatched = pd.DataFrame(columns=display_cols_common + ["Taxable Value Diff", "CGST Diff", "SGST Diff", "IGST Diff"])
    else:
        taxable_diff = (matched_both["Taxable Value (Purchase Reg.)"] - matched_both["Taxable Value (GSTR-2B)"]).abs()
        cgst_diff = (matched_both["CGST (Purchase Reg.)"] - matched_both["CGST (GSTR-2B)"]).abs()
        sgst_diff = (matched_both["SGST (Purchase Reg.)"] - matched_both["SGST (GSTR-2B)"]).abs()
        igst_diff = (matched_both["IGST (Purchase Reg.)"] - matched_both["IGST (GSTR-2B)"]).abs()

        is_matched = (
            (taxable_diff <= TOLERANCE)
            & (cgst_diff <= TOLERANCE)
            & (sgst_diff <= TOLERANCE)
            & (igst_diff <= TOLERANCE)
        )

        matched = matched_both[is_matched][display_cols_common].reset_index(drop=True)

        mismatched = matched_both[~is_matched].copy()
        mismatched["Taxable Value Diff"] = (
            matched_both.loc[~is_matched, "Taxable Value (Purchase Reg.)"] - matched_both.loc[~is_matched, "Taxable Value (GSTR-2B)"]
        )
        mismatched["CGST Diff"] = matched_both.loc[~is_matched, "CGST (Purchase Reg.)"] - matched_both.loc[~is_matched, "CGST (GSTR-2B)"]
        mismatched["SGST Diff"] = matched_both.loc[~is_matched, "SGST (Purchase Reg.)"] - matched_both.loc[~is_matched, "SGST (GSTR-2B)"]
        mismatched["IGST Diff"] = matched_both.loc[~is_matched, "IGST (Purchase Reg.)"] - matched_both.loc[~is_matched, "IGST (GSTR-2B)"]
        mismatched = mismatched[display_cols_common + ["Taxable Value Diff", "CGST Diff", "SGST Diff", "IGST Diff"]].reset_index(drop=True)

    only_cols = ["Document Type", "GSTIN", "Supplier Name", "Invoice Number", "Invoice Date", "Taxable Value", "CGST", "SGST", "IGST"]

    results = {
        "Matched": matched,
        "Mismatched Amount": mismatched,
        "Missing in GSTR-2B": only_purchase[only_cols].reset_index(drop=True),
        "Unclaimed ITC Available": only_gstr2b[only_cols + (["Source"] if "Source" in only_gstr2b.columns else [])].reset_index(drop=True),
    }
    results["ITC Reversal"] = build_reversal_sheet(purchase, matched_both, only_purchase)
    return results


def build_reversal_sheet(purchase: pd.DataFrame, matched_both: pd.DataFrame, only_purchase: pd.DataFrame) -> pd.DataFrame:
    """Rows from the Purchase Register flagged 'ITC Reversal = Yes' (Rule
    38/42/43 or Section 17(5) blocked credit), cross-checked against
    whether that invoice is actually reflected in the GSTR-2B pool. This
    mirrors GSTR-3B Table 4(B) and lets you verify the reversal is being
    made against ITC that was genuinely available in 2B."""
    p = prep(purchase)
    flagged = p[p["ITC Reversal"] == "Yes"].copy()

    reversal_cols = ["Document Type", "GSTIN", "Supplier Name", "Invoice Number", "Invoice Date", "Reversal Basis", "Taxable Value", "CGST", "SGST", "IGST"]

    if flagged.empty:
        return pd.DataFrame(
            columns=reversal_cols + ["Found in GSTR-2B", "GSTR-2B Taxable Value", "GSTR-2B CGST", "GSTR-2B SGST", "GSTR-2B IGST", "Match Basis"]
        )

    # matched_both / only_purchase come from two_stage_match on this same
    # purchase df, so "_row_id (Purchase Reg.)" / "_row_id" line up with
    # flagged's own "_row_id".
    if not matched_both.empty:
        found_lookup = matched_both.set_index("_row_id (Purchase Reg.)")[
            ["Taxable Value (GSTR-2B)", "CGST (GSTR-2B)", "SGST (GSTR-2B)", "IGST (GSTR-2B)", "Match Basis"]
        ]
    else:
        found_lookup = pd.DataFrame(
            columns=["Taxable Value (GSTR-2B)", "CGST (GSTR-2B)", "SGST (GSTR-2B)", "IGST (GSTR-2B)", "Match Basis"]
        )

    rows = []
    for _, row in flagged.iterrows():
        rid = row["_row_id"]
        base = {c: row[c] for c in reversal_cols}
        if rid in found_lookup.index:
            hit = found_lookup.loc[rid]
            # a purchase row could in theory match more than one 2B row; take the first
            if isinstance(hit, pd.DataFrame):
                hit = hit.iloc[0]
            base.update(
                {
                    "Found in GSTR-2B": "Yes",
                    "GSTR-2B Taxable Value": hit["Taxable Value (GSTR-2B)"],
                    "GSTR-2B CGST": hit["CGST (GSTR-2B)"],
                    "GSTR-2B SGST": hit["SGST (GSTR-2B)"],
                    "GSTR-2B IGST": hit["IGST (GSTR-2B)"],
                    "Match Basis": hit["Match Basis"],
                }
            )
        else:
            base.update(
                {
                    "Found in GSTR-2B": "No",
                    "GSTR-2B Taxable Value": None,
                    "GSTR-2B CGST": None,
                    "GSTR-2B SGST": None,
                    "GSTR-2B IGST": None,
                    "Match Basis": "",
                }
            )
        rows.append(base)

    return pd.DataFrame(rows).reset_index(drop=True)


def build_summary(results: dict, purchase_prepped: pd.DataFrame, gstr2b_pool_prepped: pd.DataFrame):
    """Returns (counts_df, amounts_df). Amounts keep CGST/SGST/IGST
    separate throughout - never consolidated into one tax figure."""
    matched = results["Matched"]
    mismatched = results["Mismatched Amount"]
    missing_2b = results["Missing in GSTR-2B"]
    unclaimed = results["Unclaimed ITC Available"]
    reversal = results["ITC Reversal"]

    matched_and_mismatched_basis = pd.concat([matched["Match Basis"], mismatched["Match Basis"]]) if not matched.empty or not mismatched.empty else pd.Series(dtype=str)
    via_gstin = int((matched_and_mismatched_basis == "GSTIN + Invoice Number").sum())
    via_name = int((matched_and_mismatched_basis == "Supplier Name + Invoice No. + Date (GSTIN not available)").sum())

    source_col = unclaimed["Source"] if "Source" in unclaimed.columns else pd.Series(dtype=str)
    unclaimed_current = unclaimed[source_col == "Current 2B"] if not unclaimed.empty else unclaimed
    unclaimed_carried = unclaimed[source_col == "Carried Forward (Prior Period)"] if not unclaimed.empty else unclaimed

    counts = pd.DataFrame(
        {
            "Metric": [
                "Total entries - Purchase Register (purchases, expenses, debit/credit notes)",
                "Total entries - GSTR-2B pool (current + carried forward)",
                "Matched invoices",
                "  matched via GSTIN + Invoice Number",
                "  matched via Supplier Name fallback (GSTIN missing)",
                "Mismatched amount invoices",
                "Missing in GSTR-2B (ITC at risk)",
                "Unclaimed ITC Available - total",
                "  of which: from current period GSTR-2B",
                "  of which: carried forward from earlier periods",
                "ITC Reversal entries (Rule 38/42/43, Section 17(5))",
                "  of which: reversed ITC found in GSTR-2B",
                "  of which: reversed ITC NOT found in GSTR-2B",
            ],
            "Value": [
                len(purchase_prepped),
                len(gstr2b_pool_prepped),
                len(matched),
                via_gstin,
                via_name,
                len(mismatched),
                len(missing_2b),
                len(unclaimed),
                len(unclaimed_current),
                len(unclaimed_carried),
                len(reversal),
                int((reversal["Found in GSTR-2B"] == "Yes").sum()) if not reversal.empty else 0,
                int((reversal["Found in GSTR-2B"] == "No").sum()) if not reversal.empty else 0,
            ],
        }
    )

    pr_sums = signed_head_sums(purchase_prepped)
    g_sums = signed_head_sums(gstr2b_pool_prepped)
    risk_sums = signed_head_sums(missing_2b)
    unclaimed_sums = signed_head_sums(unclaimed)
    unclaimed_current_sums = signed_head_sums(unclaimed_current)
    unclaimed_carried_sums = signed_head_sums(unclaimed_carried)

    # Reversal amounts are always a straight sum (not sign-flipped by
    # Document Type) - Table 4(B) reports the reversal itself as a positive
    # figure that gets subtracted from ITC Available.
    def _plain_sums(df, cgst_col="CGST", sgst_col="SGST", igst_col="IGST"):
        if df.empty:
            return {"CGST": 0.0, "SGST": 0.0, "IGST": 0.0}
        return {
            "CGST": round(df[cgst_col].fillna(0).sum(), 2),
            "SGST": round(df[sgst_col].fillna(0).sum(), 2),
            "IGST": round(df[igst_col].fillna(0).sum(), 2),
        }

    reversal_sums = _plain_sums(reversal)
    net_after_reversal = {k: round(pr_sums[k] - reversal_sums[k], 2) for k in ("CGST", "SGST", "IGST")}

    amount_rows = [
        ("Purchase Register - ITC before reversal (Credit Notes already netted)", pr_sums),
        ("Less: ITC Reversal (Rule 38/42/43, Section 17(5))", reversal_sums),
        ("Net ITC Available after reversal (Purchase Register basis)", net_after_reversal),
        ("GSTR-2B Pool - net ITC (current + carried forward)", g_sums),
        ("Missing in GSTR-2B - ITC at risk", risk_sums),
        ("Unclaimed ITC Available - total", unclaimed_sums),
        ("  of which: from current period GSTR-2B", unclaimed_current_sums),
        ("  of which: carried forward from earlier periods", unclaimed_carried_sums),
    ]

    amounts = pd.DataFrame(
        [
            {
                "Metric": label,
                "CGST (Rs.)": sums["CGST"],
                "SGST (Rs.)": sums["SGST"],
                "IGST (Rs.)": sums["IGST"],
                "Total (Rs.)": round(sums["CGST"] + sums["SGST"] + sums["IGST"], 2),
            }
            for label, sums in amount_rows
        ]
    )

    return counts, amounts


def to_excel_report(results: dict, counts: pd.DataFrame, amounts: pd.DataFrame) -> bytes:
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="xlsxwriter") as writer:
        counts.to_excel(writer, sheet_name="Summary - Counts", index=False)
        amounts.to_excel(writer, sheet_name="Summary - Amounts", index=False)
        for name, df in results.items():
            sheet_name = name[:31]  # Excel sheet name limit
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Sidebar - instructions
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("How to use")
    st.markdown(
        """
        1. Upload your **Purchase Register** — purchases, expenses, debit
           notes and credit notes all go in one file, distinguished by a
           `Document Type` column.
        2. Upload your **GSTR-2B** Excel file.
        3. (Optional) Upload **Previous Period(s) Unclaimed ITC** — invoices
           that were in an earlier month's GSTR-2B but never claimed. These
           are still eligible now and will be checked too.
        4. Required columns on every file:
           - `Supplier Name`
           - `Invoice Number`
           - `Invoice Date`
           - `Taxable Value`
           - `CGST`, `SGST`, `IGST` (leave 0 where not applicable)
        5. Optional columns (safe defaults if missing):
           - `GSTIN` — if blank for a row, that row is matched by Supplier
             Name + Invoice Number + Invoice Date instead
           - `Document Type` — one of Purchase, Expense, Debit Note, Credit
             Note (defaults to Purchase)
           - `ITC Reversal` — Yes/No, for ITC to be reversed under Rule
             38/42/43 or Section 17(5) (blocked credit). Defaults to No.
           - `Reversal Basis` — free text, e.g. "Rule 42", "Section 17(5) -
             motor vehicle"
        6. Click **Run Reconciliation**.
        7. Review results and download the Excel report. The **Unclaimed
           ITC Available** sheet is already in the right format to reuse as
           next month's "Previous Period" file.
        """
    )
    st.info("Sample files are included with this project so you can try it immediately.")

# ---------------------------------------------------------------------------
# Main - file upload
# ---------------------------------------------------------------------------
col1, col2 = st.columns(2)
with col1:
    purchase_file = st.file_uploader("Upload Purchase Register (Excel)", type=["xlsx", "xls"])
with col2:
    gstr2b_file = st.file_uploader("Upload GSTR-2B (Excel) - current period", type=["xlsx", "xls"])

previous_file = st.file_uploader(
    "Upload Previous Period(s) Unclaimed ITC (Excel) - optional",
    type=["xlsx", "xls"],
    help=(
        "Invoices that appeared in an earlier month's GSTR-2B but were never "
        "claimed. Under the current IMS-based system this credit doesn't "
        "expire after one month, so upload it here to include it in this "
        "period's reconciliation. Use the 'Unclaimed ITC Available' sheet "
        "from a previous run of this tool."
    ),
)

run = st.button("Run Reconciliation", type="primary", disabled=not (purchase_file and gstr2b_file))

if run:
    purchase_df = load_excel(purchase_file)
    gstr2b_df = load_excel(gstr2b_file)
    previous_df = load_excel(previous_file) if previous_file else None

    missing_p = validate_columns(purchase_df)
    missing_g = validate_columns(gstr2b_df)
    missing_prev = validate_columns(previous_df) if previous_df is not None else []

    if missing_p or missing_g or missing_prev:
        if missing_p:
            st.error(f"Purchase Register is missing columns: {missing_p}")
        if missing_g:
            st.error(f"GSTR-2B is missing columns: {missing_g}")
        if missing_prev:
            st.error(f"Previous Period Unclaimed ITC file is missing columns: {missing_prev}")
    else:
        gstr2b_pool = build_gstr2b_pool(gstr2b_df, previous_df)
        results = reconcile(purchase_df, gstr2b_pool)
        counts, amounts = build_summary(results, prep(purchase_df), prep(gstr2b_pool))

        st.success("Reconciliation complete.")
        if previous_df is not None:
            st.caption(
                f"Included {len(previous_df)} carried-forward invoice(s) from prior periods "
                "in this reconciliation."
            )

        # Key metrics
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Matched", len(results["Matched"]))
        m2.metric("Mismatched", len(results["Mismatched Amount"]))
        m3.metric("Missing in GSTR-2B", len(results["Missing in GSTR-2B"]))
        m4.metric("Unclaimed ITC Available", len(results["Unclaimed ITC Available"]))
        m5.metric("ITC Reversal entries", len(results["ITC Reversal"]))

        st.subheader("Summary - Invoice Counts")
        st.dataframe(counts, use_container_width=True, hide_index=True)

        st.subheader("Summary - Amounts (CGST / SGST / IGST kept separate)")
        st.dataframe(amounts, use_container_width=True, hide_index=True)

        tabs = st.tabs(list(results.keys()))
        for tab, (name, df) in zip(tabs, results.items()):
            with tab:
                st.dataframe(df, use_container_width=True, hide_index=True)

        report_bytes = to_excel_report(results, counts, amounts)
        st.download_button(
            label="Download Excel Report",
            data=report_bytes,
            file_name=f"ITC_Reconciliation_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
else:
    st.write("Upload the Purchase Register and GSTR-2B files, then click **Run Reconciliation** to begin.")
