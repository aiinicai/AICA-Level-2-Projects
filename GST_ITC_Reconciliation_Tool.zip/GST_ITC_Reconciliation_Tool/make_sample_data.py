"""Generates sample_purchase_register.xlsx, sample_gstr2b.xlsx and
sample_previous_period_unclaimed.xlsx for demoing the GST ITC Reconciliation
Tool. Deliberately covers: Purchase, Expense, Debit Note and Credit Note
entries; one row with GSTIN missing (matched by Supplier Name + Invoice No.
+ Date instead); split CGST/SGST/IGST; carried-forward ITC from an earlier
period; and two ITC Reversal cases (one found in GSTR-2B, one not)."""

import pandas as pd

# Purchase Register (as per client's books) - current period
# Columns: GSTIN (optional - blank for one row on purpose), Supplier Name,
# Invoice Number, Invoice Date, Document Type, Taxable Value, CGST, SGST,
# IGST, ITC Reversal (Yes/No), Reversal Basis
purchase_register = pd.DataFrame([
    # Matched invoices (intra-state, CGST+SGST)
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-101", "Invoice Date": "2026-04-05", "Document Type": "Purchase", "Taxable Value": 50000, "CGST": 4500, "SGST": 4500, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-102", "Invoice Date": "2026-04-08", "Document Type": "Purchase", "Taxable Value": 22000, "CGST": 1980, "SGST": 1980, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    # Matched invoice (inter-state, IGST)
    {"GSTIN": "27AABCU9603R1ZM", "Supplier Name": "Universal Traders", "Invoice Number": "SLS-778", "Invoice Date": "2026-04-10", "Document Type": "Purchase", "Taxable Value": 15000, "CGST": 0, "SGST": 0, "IGST": 2700, "ITC Reversal": "No", "Reversal Basis": ""},
    # Mismatched amount (SGST differs)
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-103", "Invoice Date": "2026-04-12", "Document Type": "Purchase", "Taxable Value": 30000, "CGST": 2700, "SGST": 2700, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    # Missing in GSTR-2B (supplier hasn't filed / ITC at risk)
    {"GSTIN": "29AAGCB7383D1Z0", "Supplier Name": "Bangalore Components", "Invoice Number": "PO-556", "Invoice Date": "2026-04-15", "Document Type": "Purchase", "Taxable Value": 18000, "CGST": 0, "SGST": 0, "IGST": 3240, "ITC Reversal": "No", "Reversal Basis": ""},
    {"GSTIN": "06AABCU1234F1Z2", "Supplier Name": "Haryana Steel Corp", "Invoice Number": "BILL-90", "Invoice Date": "2026-04-18", "Document Type": "Purchase", "Taxable Value": 42000, "CGST": 0, "SGST": 0, "IGST": 7560, "ITC Reversal": "No", "Reversal Basis": ""},
    # Expense entry, matched
    {"GSTIN": "24AABCT5678K1Z9", "Supplier Name": "Swift Courier Services", "Invoice Number": "CR-4410", "Invoice Date": "2026-04-09", "Document Type": "Expense", "Taxable Value": 3500, "CGST": 315, "SGST": 315, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    # Debit note (increases ITC), matched
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "DN-011", "Invoice Date": "2026-04-22", "Document Type": "Debit Note", "Taxable Value": 4000, "CGST": 360, "SGST": 360, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    # Credit note (reduces ITC), matched
    {"GSTIN": "27AABCU9603R1ZM", "Supplier Name": "Universal Traders", "Invoice Number": "CN-007", "Invoice Date": "2026-04-25", "Document Type": "Credit Note", "Taxable Value": 2000, "CGST": 0, "SGST": 0, "IGST": 360, "ITC Reversal": "No", "Reversal Basis": ""},
    # GSTIN missing - must be matched by Supplier Name + Invoice Number + Date
    {"GSTIN": "", "Supplier Name": "Local Stationery Mart", "Invoice Number": "LSM-221", "Invoice Date": "2026-04-14", "Document Type": "Expense", "Taxable Value": 1200, "CGST": 108, "SGST": 108, "IGST": 0, "ITC Reversal": "No", "Reversal Basis": ""},
    # ITC Reversal - blocked credit on a motor vehicle purchase, matched in 2B
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-201", "Invoice Date": "2026-04-16", "Document Type": "Purchase", "Taxable Value": 800000, "CGST": 72000, "SGST": 72000, "IGST": 0, "ITC Reversal": "Yes", "Reversal Basis": "Section 17(5) - motor vehicle"},
    # ITC Reversal - proportionate reversal for exempt supply (Rule 42), on
    # an invoice that has NOT been found in GSTR-2B (supplier hasn't filed)
    {"GSTIN": "29AAGCB7383D1Z0", "Supplier Name": "Bangalore Components", "Invoice Number": "PO-590", "Invoice Date": "2026-04-19", "Document Type": "Purchase", "Taxable Value": 10000, "CGST": 0, "SGST": 0, "IGST": 1800, "ITC Reversal": "Yes", "Reversal Basis": "Rule 42 - exempt supply proportion"},
])

# GSTR-2B (as per GST portal) - current period
gstr2b = pd.DataFrame([
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-101", "Invoice Date": "2026-04-05", "Document Type": "Purchase", "Taxable Value": 50000, "CGST": 4500, "SGST": 4500, "IGST": 0},
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-102", "Invoice Date": "2026-04-08", "Document Type": "Purchase", "Taxable Value": 22000, "CGST": 1980, "SGST": 1980, "IGST": 0},
    {"GSTIN": "27AABCU9603R1ZM", "Supplier Name": "Universal Traders", "Invoice Number": "SLS-778", "Invoice Date": "2026-04-10", "Document Type": "Purchase", "Taxable Value": 15000, "CGST": 0, "SGST": 0, "IGST": 2700},
    # Mismatch: portal shows lower SGST than books
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-103", "Invoice Date": "2026-04-12", "Document Type": "Purchase", "Taxable Value": 30000, "CGST": 2700, "SGST": 2500, "IGST": 0},
    {"GSTIN": "24AABCT5678K1Z9", "Supplier Name": "Swift Courier Services", "Invoice Number": "CR-4410", "Invoice Date": "2026-04-09", "Document Type": "Expense", "Taxable Value": 3500, "CGST": 315, "SGST": 315, "IGST": 0},
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "DN-011", "Invoice Date": "2026-04-22", "Document Type": "Debit Note", "Taxable Value": 4000, "CGST": 360, "SGST": 360, "IGST": 0},
    {"GSTIN": "27AABCU9603R1ZM", "Supplier Name": "Universal Traders", "Invoice Number": "CN-007", "Invoice Date": "2026-04-25", "Document Type": "Credit Note", "Taxable Value": 2000, "CGST": 0, "SGST": 0, "IGST": 360},
    # The motor-vehicle purchase behind the ITC Reversal entry - it IS
    # reflected in GSTR-2B, the reversal just needs to be checked against it
    {"GSTIN": "24AAACP1234A1Z5", "Supplier Name": "Patel Traders", "Invoice Number": "INV-201", "Invoice Date": "2026-04-16", "Document Type": "Purchase", "Taxable Value": 800000, "CGST": 72000, "SGST": 72000, "IGST": 0},
    # Same GSTIN-missing vendor invoice, filed on the portal WITH a GSTIN this
    # time (small unregistered-looking vendors sometimes still appear via
    # their supplier's own filing) - matched here by Supplier Name + Invoice
    # Number + Date since the Purchase Register side has no GSTIN
    {"GSTIN": "08AAECL5566P1Z3", "Supplier Name": "Local Stationery Mart", "Invoice Number": "LSM-221", "Invoice Date": "2026-04-14", "Document Type": "Expense", "Taxable Value": 1200, "CGST": 108, "SGST": 108, "IGST": 0},
    # Missing in Purchase Register (available in 2B but not booked by client yet)
    {"GSTIN": "33AAECS1234K1Z8", "Supplier Name": "Chennai Fabricators", "Invoice Number": "XYZ-222", "Invoice Date": "2026-04-20", "Document Type": "Purchase", "Taxable Value": 12000, "CGST": 0, "SGST": 0, "IGST": 2160},
])

# Previous Period(s) Unclaimed ITC (optional third file) - invoices that
# appeared in an earlier month's GSTR-2B but were never claimed by the
# client. Still eligible now, so the tool folds these into this period's
# reconciliation.
previous_period_unclaimed = pd.DataFrame([
    {"GSTIN": "19AABCU1234M1Z1", "Supplier Name": "Kolkata Metal Works", "Invoice Number": "OLD-001", "Invoice Date": "2026-02-10", "Document Type": "Purchase", "Taxable Value": 9000, "CGST": 0, "SGST": 0, "IGST": 1620},
    {"GSTIN": "08AAHCS1234N1Z6", "Supplier Name": "Rajasthan Textiles", "Invoice Number": "FEB-045", "Invoice Date": "2026-03-02", "Document Type": "Purchase", "Taxable Value": 26000, "CGST": 2340, "SGST": 2340, "IGST": 0},
])

purchase_register.to_excel("sample_purchase_register.xlsx", index=False)
gstr2b.to_excel("sample_gstr2b.xlsx", index=False)
previous_period_unclaimed.to_excel("sample_previous_period_unclaimed.xlsx", index=False)
print("Sample files created.")
