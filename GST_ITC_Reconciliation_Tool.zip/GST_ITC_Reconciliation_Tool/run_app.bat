@echo off
cd /d "%~dp0"
echo Installing required packages, this may take a minute the first time...
python -m pip install -r requirements.txt
echo Starting the app...
python -m streamlit run app.py
pause
