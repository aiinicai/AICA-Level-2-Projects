# GST ITC Reconciliation Tool

A Python + Streamlit application that reconciles a Purchase Register
(purchases, expenses, debit notes and credit notes) against GSTR-2B and
flags Input Tax Credit (ITC) mismatches before GSTR-3B filing.

## Setup

```bash
pip install -r requirements.txt
```

## Run

Easiest: double-click `run_app.bat` (Windows) or `run_app.command` (Mac).

Or from a terminal:

```bash
streamlit run app.py
```

This opens the app in your browser (usually http://localhost:8501).

## Try it with sample data

Sample files are included:
- `sample_purchase_register.xlsx`
- `sample_gstr2b.xlsx`
- `sample_previous_period_unclaimed.xlsx` (optional third file)

Upload the first two (and optionally the third) in the app and click
**Run Reconciliation**.

To regenerate the sample files: `python make_sample_data.py`

## Required columns

Every uploaded Excel file (Purchase Register, GSTR-2B, and the optional
previous-period file) must contain:
- `Supplier Name`
- `Invoice Number`
- `Invoice Date`
- `Taxable Value`
- `CGST`, `SGST`, `IGST` (enter 0 where a head doesn't apply — e.g. IGST is
  0 for an intra-state purchase, CGST/SGST are 0 for an inter-state one)

Optional columns, with safe defaults if left out:
- `GSTIN` — if blank for a row (common for small/unregistered vendors or a
  messy export), that row is matched using Supplier Name + Invoice Number +
  Invoice Date instead of GSTIN.
- `Document Type` — one of `Purchase`, `Expense`, `Debit Note`, `Credit
  Note`. Defaults to `Purchase` if the column or a cell is left blank.
- `ITC Reversal` — `Yes`/`No`, on the Purchase Register only, for ITC that
  needs to be reversed under Rule 38/42/43 or Section 17(5) (blocked
  credit). Defaults to `No`.
- `Reversal Basis` — free text describing why, e.g. "Rule 42 - exempt
  supply proportion" or "Section 17(5) - motor vehicle".

## How matching works

Two passes:
1. **GSTIN + Invoice Number** — wherever both files have a valid GSTIN for
   that row, this is the primary key.
2. **Supplier Name + Invoice Number + Invoice Date** — used only for rows
   where GSTIN is missing on either side. The "Match Basis" column in the
   output tells you which method matched each invoice.

Tax heads are never consolidated: CGST, SGST and IGST are compared and
reported as separate columns throughout, both in the app and in the Excel
report. A "Mismatched Amount" invoice shows exactly which head(s) differ.

Every invoice lands in one of four categories:
- **Matched** — agrees in both
- **Mismatched Amount** — found in both, Taxable Value / CGST / SGST / IGST differ
- **Missing in GSTR-2B** — booked in Purchase Register but not reflected in
  GSTR-2B (ITC at risk — supplier may not have filed)
- **Unclaimed ITC Available** — available in GSTR-2B but not yet booked/claimed
  by the client, tagged by `Source` as either "Current 2B" or "Carried
  Forward (Prior Period)"

## Document types and net ITC

`Document Type` affects the **amounts summary** only (not whether an
invoice matches): a Credit Note reduces net ITC, everything else
(Purchase, Expense, Debit Note) adds to it. The summary's amount rows are
always net of credit notes, shown separately for CGST, SGST and IGST.

## ITC Reversal (Rule 38/42/43, Section 17(5))

Mirrors GSTR-3B Table 4(B). Flag a Purchase Register row `ITC Reversal =
Yes` and give a `Reversal Basis` (blocked credit, exempt-supply
apportionment, etc.). These rows get their own **ITC Reversal** sheet,
cross-checked against GSTR-2B: each row shows whether that invoice is
actually reflected in GSTR-2B (`Found in GSTR-2B`), and its GSTR-2B-side
Taxable Value/CGST/SGST/IGST side by side for verification — a reversal
should normally be made against ITC that was genuinely available in 2B, so
a "No" here is worth a second look.

The amounts summary shows, per tax head: ITC before reversal, less
reversal, and net ITC available after reversal — matching GSTR-3B Table
4(A)–(C)'s structure, without consolidating CGST/SGST/IGST.

## Carrying forward unclaimed ITC from earlier periods

GSTR-2B in a given month can include, or a client can simply forget to
claim, ITC that stays valid beyond that one month under the current
IMS-based system. To catch this, upload a third (optional) file — **Previous
Period(s) Unclaimed ITC** — in the same column format. Its invoices are
folded into the current GSTR-2B pool before matching, so they get flagged as
claimable this period too. If an invoice reappears in the current GSTR-2B,
the tool treats it as current and drops the duplicate from the carried-forward
list automatically.

The **Unclaimed ITC Available** sheet in the output report is already in the
right format to re-upload as next month's "Previous Period" file — carry it
forward each month until the invoice is finally matched or written off.

## Output

A downloadable Excel report with two summary sheets (invoice counts, and
amounts with CGST/SGST/IGST kept separate) plus one sheet per category.
