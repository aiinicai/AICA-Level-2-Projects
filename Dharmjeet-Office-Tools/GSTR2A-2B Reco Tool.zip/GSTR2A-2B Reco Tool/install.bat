@echo off
echo =========================================================================
echo  Installing Dependencies for GSTR-2A/2B Offline Reconciliation Tool
echo =========================================================================
echo.

python -m venv venv
call venv\Scripts\activate.bat

echo Upgrading pip...
python -m pip install --upgrade pip

echo Installing required packages...
pip install -r requirements.txt

echo.
echo =========================================================================
echo  Installation completed successfully!
echo  Run 'run.bat' to start the application.
echo =========================================================================
pause
