"""Database DDL and initial configuration schemas."""

CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    trade_name TEXT,
    legal_name TEXT,
    pan TEXT,
    contact_person TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gstins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    gstin TEXT NOT NULL UNIQUE,
    state TEXT,
    registration_type TEXT DEFAULT 'Regular',
    books_software TEXT DEFAULT 'Tally',
    default_format TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS financial_years (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gstin_id INTEGER NOT NULL,
    fy TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(gstin_id) REFERENCES gstins(id) ON DELETE CASCADE,
    UNIQUE(gstin_id, fy)
);

CREATE TABLE IF NOT EXISTS periods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fy_id INTEGER NOT NULL,
    period_name TEXT NOT NULL,
    is_locked INTEGER DEFAULT 0,
    locked_at TIMESTAMP,
    locked_by TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(fy_id) REFERENCES financial_years(id) ON DELETE CASCADE,
    UNIQUE(fy_id, period_name)
);

CREATE TABLE IF NOT EXISTS import_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id INTEGER NOT NULL,
    source_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT,
    file_hash TEXT,
    record_count INTEGER DEFAULT 0,
    imported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    imported_by TEXT DEFAULT 'Admin',
    FOREIGN KEY(period_id) REFERENCES periods(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS books_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id INTEGER NOT NULL,
    import_file_id INTEGER,
    supplier_gstin TEXT NOT NULL,
    supplier_name TEXT,
    invoice_number TEXT NOT NULL,
    normalized_inv_no TEXT NOT NULL,
    invoice_date TEXT,
    invoice_value REAL DEFAULT 0.0,
    taxable_value REAL DEFAULT 0.0,
    igst REAL DEFAULT 0.0,
    cgst REAL DEFAULT 0.0,
    sgst REAL DEFAULT 0.0,
    cess REAL DEFAULT 0.0,
    total_tax REAL DEFAULT 0.0,
    itc_eligibility TEXT DEFAULT 'Eligible',
    pos TEXT,
    rcm TEXT DEFAULT 'N',
    doc_type TEXT DEFAULT 'B2B',
    source_sheet TEXT,
    source_row INTEGER,
    remarks TEXT,
    is_carried_forward INTEGER DEFAULT 0,
    carried_forward_from_period TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(period_id) REFERENCES periods(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gst_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id INTEGER NOT NULL,
    import_file_id INTEGER,
    gstr_type TEXT NOT NULL,
    supplier_gstin TEXT NOT NULL,
    supplier_name TEXT,
    invoice_number TEXT NOT NULL,
    normalized_inv_no TEXT NOT NULL,
    invoice_date TEXT,
    filing_date TEXT,
    gstr2b_period TEXT,
    invoice_value REAL DEFAULT 0.0,
    taxable_value REAL DEFAULT 0.0,
    igst REAL DEFAULT 0.0,
    cgst REAL DEFAULT 0.0,
    sgst REAL DEFAULT 0.0,
    cess REAL DEFAULT 0.0,
    total_tax REAL DEFAULT 0.0,
    itc_available TEXT DEFAULT 'Y',
    reason_unavail TEXT,
    pos TEXT,
    rcm TEXT DEFAULT 'N',
    doc_type TEXT DEFAULT 'B2B',
    amendment_flag TEXT DEFAULT 'N',
    original_inv_no TEXT,
    original_inv_date TEXT,
    source_sheet TEXT,
    source_row INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(period_id) REFERENCES periods(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reconciliation_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id INTEGER NOT NULL,
    books_id INTEGER,
    gst_id INTEGER,
    match_status TEXT NOT NULL,
    match_score REAL DEFAULT 0.0,
    matching_level TEXT,
    matched_fields TEXT,
    mismatched_fields TEXT,
    diff_amount REAL DEFAULT 0.0,
    diff_tax REAL DEFAULT 0.0,
    diff_days INTEGER DEFAULT 0,
    inv_similarity REAL DEFAULT 0.0,
    explanation TEXT,
    recommendation TEXT,
    user_action TEXT DEFAULT 'OPEN',
    user_remarks TEXT,
    assigned_to TEXT,
    reviewed_by TEXT,
    reviewed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(period_id) REFERENCES periods(id) ON DELETE CASCADE,
    FOREIGN KEY(books_id) REFERENCES books_transactions(id) ON DELETE SET NULL,
    FOREIGN KEY(gst_id) REFERENCES gst_transactions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS exceptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id INTEGER NOT NULL,
    reco_result_id INTEGER NOT NULL,
    priority TEXT DEFAULT 'MEDIUM',
    category TEXT NOT NULL,
    description TEXT,
    diff_value REAL DEFAULT 0.0,
    status TEXT DEFAULT 'Open',
    assigned_person TEXT,
    remarks TEXT,
    resolution_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(period_id) REFERENCES periods(id) ON DELETE CASCADE,
    FOREIGN KEY(reco_result_id) REFERENCES reconciliation_results(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gstin_id INTEGER NOT NULL,
    supplier_gstin TEXT NOT NULL,
    supplier_name TEXT,
    books_count INTEGER DEFAULT 0,
    gst_count INTEGER DEFAULT 0,
    matched_count INTEGER DEFAULT 0,
    mismatched_count INTEGER DEFAULT 0,
    missing_count INTEGER DEFAULT 0,
    total_books_itc REAL DEFAULT 0.0,
    total_gst_itc REAL DEFAULT 0.0,
    itc_at_risk REAL DEFAULT 0.0,
    reliability_score REAL DEFAULT 100.0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(gstin_id) REFERENCES gstins(id) ON DELETE CASCADE,
    UNIQUE(gstin_id, supplier_gstin)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT DEFAULT 'System',
    action TEXT NOT NULL,
    entity TEXT,
    entity_id TEXT,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS matching_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name TEXT NOT NULL UNIQUE,
    description TEXT,
    enabled INTEGER DEFAULT 1,
    priority INTEGER DEFAULT 1,
    condition_json TEXT
);

CREATE TABLE IF NOT EXISTS column_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_name TEXT NOT NULL UNIQUE,
    software_type TEXT,
    mapping_json TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'Staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_books_period ON books_transactions(period_id);
CREATE INDEX IF NOT EXISTS idx_books_gstin ON books_transactions(supplier_gstin);
CREATE INDEX IF NOT EXISTS idx_books_norm_inv ON books_transactions(normalized_inv_no);

CREATE INDEX IF NOT EXISTS idx_gst_period ON gst_transactions(period_id);
CREATE INDEX IF NOT EXISTS idx_gst_gstin ON gst_transactions(supplier_gstin);
CREATE INDEX IF NOT EXISTS idx_gst_norm_inv ON gst_transactions(normalized_inv_no);

CREATE INDEX IF NOT EXISTS idx_reco_period ON reconciliation_results(period_id);
CREATE INDEX IF NOT EXISTS idx_reco_status ON reconciliation_results(match_status);
CREATE INDEX IF NOT EXISTS idx_reco_user_action ON reconciliation_results(user_action);

CREATE INDEX IF NOT EXISTS idx_exceptions_period ON exceptions(period_id);
CREATE INDEX IF NOT EXISTS idx_exceptions_priority ON exceptions(priority);
CREATE INDEX IF NOT EXISTS idx_exceptions_status ON exceptions(status);
"""

INITIAL_SETTINGS_SQL = """
INSERT OR IGNORE INTO settings (key, value) VALUES ('date_tolerance_days', '3');
INSERT OR IGNORE INTO settings (key, value) VALUES ('amount_tolerance_rs', '1.0');
INSERT OR IGNORE INTO settings (key, value) VALUES ('amount_tolerance_pct', '0.01');
INSERT OR IGNORE INTO settings (key, value) VALUES ('fuzzy_threshold_high', '90');
INSERT OR IGNORE INTO settings (key, value) VALUES ('fuzzy_threshold_medium', '80');
INSERT OR IGNORE INTO settings (key, value) VALUES ('auto_accept_high_confidence', '1');
INSERT OR IGNORE INTO settings (key, value) VALUES ('theme', 'Light');

INSERT OR IGNORE INTO users (username, password_hash, full_name, role)
VALUES ('admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'System Administrator', 'Administrator');
"""
