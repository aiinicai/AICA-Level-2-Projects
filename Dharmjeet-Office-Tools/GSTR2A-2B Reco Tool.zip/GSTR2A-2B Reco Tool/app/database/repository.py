import json
import sqlite3
from typing import List, Dict, Any, Optional, Tuple
from app.database.connection import DatabaseManager
from app.database.models import (
    ClientModel, GSTINModel, TransactionModel, RecoResultModel,
    SupplierMetricsModel, ExceptionModel
)


class Repository:
    """Repository class encapsulating all SQLite database operations."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.db = db_manager or DatabaseManager()

    # --- CLIENTS & GSTINS ---

    def create_client(self, client: ClientModel) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO clients (name, trade_name, legal_name, pan, contact_person, email, phone, address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (client.name, client.trade_name, client.legal_name, client.pan,
                 client.contact_person, client.email, client.phone, client.address)
            )
            client_id = cursor.lastrowid
            self.log_audit_conn(conn, "Admin", "CREATE_CLIENT", "Client", str(client_id), f"Created client {client.name}")
            return client_id

    def get_all_clients(self) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM clients ORDER BY name ASC")
            return [dict(row) for row in cursor.fetchall()]

    def get_client(self, client_id: int) -> Optional[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM clients WHERE id = ?", (client_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def delete_client(self, client_id: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM clients WHERE id = ?", (client_id,))
            client = cursor.fetchone()
            client_name = client["name"] if client else str(client_id)
            cursor.execute("DELETE FROM clients WHERE id = ?", (client_id,))
            deleted = cursor.rowcount > 0
            if deleted:
                self.log_audit_conn(conn, "Admin", "DELETE_CLIENT", "Client", str(client_id), f"Deleted client {client_name}")
            return deleted

    def delete_gstin(self, gstin_id: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT gstin FROM gstins WHERE id = ?", (gstin_id,))
            row = cursor.fetchone()
            gstin_str = row["gstin"] if row else str(gstin_id)
            cursor.execute("DELETE FROM gstins WHERE id = ?", (gstin_id,))
            deleted = cursor.rowcount > 0
            if deleted:
                self.log_audit_conn(conn, "Admin", "DELETE_GSTIN", "GSTIN", str(gstin_id), f"Deleted GSTIN {gstin_str}")
            return deleted

    def add_gstin(self, gstin_model: GSTINModel) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO gstins (client_id, gstin, state, registration_type, books_software, default_format)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (gstin_model.client_id, gstin_model.gstin.upper(), gstin_model.state,
                 gstin_model.registration_type, gstin_model.books_software, gstin_model.default_format)
            )
            gstin_id = cursor.lastrowid
            self.log_audit_conn(conn, "Admin", "ADD_GSTIN", "GSTIN", str(gstin_id), f"Added GSTIN {gstin_model.gstin}")
            return gstin_id

    def get_gstins_for_client(self, client_id: int) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM gstins WHERE client_id = ? ORDER BY gstin ASC", (client_id,))
            return [dict(row) for row in cursor.fetchall()]

    def get_or_create_fy(self, gstin_id: int, fy_name: str) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM financial_years WHERE gstin_id = ? AND fy = ?", (gstin_id, fy_name))
            row = cursor.fetchone()
            if row:
                return row['id']
            cursor.execute("INSERT INTO financial_years (gstin_id, fy) VALUES (?, ?)", (gstin_id, fy_name))
            return cursor.lastrowid

    def get_or_create_period(self, fy_id: int, period_name: str) -> Tuple[int, bool]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, is_locked FROM periods WHERE fy_id = ? AND period_name = ?", (fy_id, period_name))
            row = cursor.fetchone()
            if row:
                return row['id'], bool(row['is_locked'])
            cursor.execute("INSERT INTO periods (fy_id, period_name) VALUES (?, ?)", (fy_id, period_name))
            return cursor.lastrowid, False

    def get_periods_for_fy(self, fy_id: int) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM periods WHERE fy_id = ? ORDER BY id ASC", (fy_id,))
            return [dict(row) for row in cursor.fetchall()]

    def lock_period(self, period_id: int, user: str = "Admin") -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE periods SET is_locked = 1, locked_at = CURRENT_TIMESTAMP, locked_by = ? WHERE id = ?",
                (user, period_id)
            )
            self.log_audit_conn(conn, user, "LOCK_PERIOD", "Period", str(period_id), "Locked reconciliation period")
            return cursor.rowcount > 0

    # --- IMPORT FILE REGISTRATION ---

    def register_import_file(self, period_id: int, source_type: str, file_name: str, file_hash: str, record_count: int, imported_by: str = "Admin") -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO import_files (period_id, source_type, file_name, file_hash, record_count, imported_by)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (period_id, source_type, file_name, file_hash, record_count, imported_by)
            )
            return cursor.lastrowid

    def check_file_imported(self, period_id: int, file_hash: str) -> Optional[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM import_files WHERE period_id = ? AND file_hash = ?", (period_id, file_hash))
            row = cursor.fetchone()
            return dict(row) if row else None

    # --- BATCH TRANSACTIONS ---

    def insert_books_transactions(self, period_id: int, import_file_id: int, tx_list: List[TransactionModel]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            rows = []
            for tx in tx_list:
                rows.append((
                    period_id, import_file_id, tx.supplier_gstin, tx.supplier_name,
                    tx.invoice_number, tx.normalized_inv_no, tx.invoice_date,
                    tx.invoice_value, tx.taxable_value, tx.igst, tx.cgst, tx.sgst, tx.cess,
                    tx.total_tax, tx.itc_eligibility, tx.pos, tx.rcm, tx.doc_type,
                    tx.source_sheet, tx.source_row, tx.remarks, tx.is_carried_forward, tx.carried_forward_from_period
                ))
            cursor.executemany(
                """
                INSERT INTO books_transactions (
                    period_id, import_file_id, supplier_gstin, supplier_name, invoice_number,
                    normalized_inv_no, invoice_date, invoice_value, taxable_value, igst, cgst, sgst,
                    cess, total_tax, itc_eligibility, pos, rcm, doc_type, source_sheet, source_row,
                    remarks, is_carried_forward, carried_forward_from_period
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows
            )
            self.log_audit_conn(conn, "Admin", "IMPORT_BOOKS", "Period", str(period_id), f"Imported {len(tx_list)} Books records")

    def insert_gst_transactions(self, period_id: int, import_file_id: int, gstr_type: str, tx_list: List[TransactionModel]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            rows = []
            for tx in tx_list:
                rows.append((
                    period_id, import_file_id, gstr_type, tx.supplier_gstin, tx.supplier_name,
                    tx.invoice_number, tx.normalized_inv_no, tx.invoice_date, tx.filing_date,
                    tx.gstr2b_period, tx.invoice_value, tx.taxable_value, tx.igst, tx.cgst, tx.sgst,
                    tx.cess, tx.total_tax, tx.itc_available, tx.pos, tx.rcm, tx.doc_type,
                    tx.amendment_flag, tx.original_inv_no, tx.original_inv_date,
                    tx.source_sheet, tx.source_row
                ))
            cursor.executemany(
                """
                INSERT INTO gst_transactions (
                    period_id, import_file_id, gstr_type, supplier_gstin, supplier_name,
                    invoice_number, normalized_inv_no, invoice_date, filing_date, gstr2b_period,
                    invoice_value, taxable_value, igst, cgst, sgst, cess, total_tax, itc_available,
                    pos, rcm, doc_type, amendment_flag, original_inv_no, original_inv_date,
                    source_sheet, source_row
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows
            )
            self.log_audit_conn(conn, "Admin", f"IMPORT_{gstr_type}", "Period", str(period_id), f"Imported {len(tx_list)} {gstr_type} records")

    def clear_period_reconciliation(self, period_id: int):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM exceptions WHERE period_id = ?", (period_id,))
            cursor.execute("DELETE FROM reconciliation_results WHERE period_id = ?", (period_id,))
            conn.commit()

    def get_period_data_summary(self, period_id: int) -> Dict[str, Any]:
        """Returns financial control totals and record counts for books, gst, and reconciliation for the period."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Books control totals
            cursor.execute("""
                SELECT 
                    COUNT(*) as cnt,
                    COALESCE(SUM(taxable_value), 0.0) as sum_taxable,
                    COALESCE(SUM(igst), 0.0) as sum_igst,
                    COALESCE(SUM(cgst), 0.0) as sum_cgst,
                    COALESCE(SUM(sgst), 0.0) as sum_sgst,
                    COALESCE(SUM(cess), 0.0) as sum_cess,
                    COALESCE(SUM(total_tax), 0.0) as sum_tax,
                    COALESCE(SUM(invoice_value), 0.0) as sum_val
                FROM books_transactions WHERE period_id = ?
            """, (period_id,))
            b_row = cursor.fetchone()

            # GST control totals
            cursor.execute("""
                SELECT 
                    COUNT(*) as cnt,
                    COALESCE(SUM(taxable_value), 0.0) as sum_taxable,
                    COALESCE(SUM(igst), 0.0) as sum_igst,
                    COALESCE(SUM(cgst), 0.0) as sum_cgst,
                    COALESCE(SUM(sgst), 0.0) as sum_sgst,
                    COALESCE(SUM(cess), 0.0) as sum_cess,
                    COALESCE(SUM(total_tax), 0.0) as sum_tax,
                    COALESCE(SUM(invoice_value), 0.0) as sum_val
                FROM gst_transactions WHERE period_id = ?
            """, (period_id,))
            g_row = cursor.fetchone()

            # GSTR-2B specific totals
            cursor.execute("""
                SELECT 
                    COUNT(*) as cnt,
                    COALESCE(SUM(total_tax), 0.0) as sum_tax,
                    COALESCE(SUM(taxable_value), 0.0) as sum_taxable
                FROM gst_transactions WHERE period_id = ? AND gstr_type = 'GSTR2B'
            """, (period_id,))
            g2b_row = cursor.fetchone()

            # GSTR-2A specific totals
            cursor.execute("""
                SELECT 
                    COUNT(*) as cnt,
                    COALESCE(SUM(total_tax), 0.0) as sum_tax,
                    COALESCE(SUM(taxable_value), 0.0) as sum_taxable
                FROM gst_transactions WHERE period_id = ? AND gstr_type = 'GSTR2A'
            """, (period_id,))
            g2a_row = cursor.fetchone()

            cursor.execute("SELECT COUNT(*) as cnt FROM import_files WHERE period_id = ?", (period_id,))
            files_cnt = cursor.fetchone()["cnt"]

            cursor.execute("SELECT COUNT(*) as cnt FROM reconciliation_results WHERE period_id = ?", (period_id,))
            reco_cnt = cursor.fetchone()["cnt"]

            cursor.execute("SELECT COUNT(*) as cnt FROM exceptions WHERE period_id = ?", (period_id,))
            exc_cnt = cursor.fetchone()["cnt"]

            return {
                "books_count": b_row["cnt"],
                "books_taxable": round(b_row["sum_taxable"], 2),
                "books_igst": round(b_row["sum_igst"], 2),
                "books_cgst": round(b_row["sum_cgst"], 2),
                "books_sgst": round(b_row["sum_sgst"], 2),
                "books_cess": round(b_row["sum_cess"], 2),
                "books_itc": round(b_row["sum_tax"], 2),
                "books_val": round(b_row["sum_val"], 2),

                "gst_count": g_row["cnt"],
                "gst_taxable": round(g_row["sum_taxable"], 2),
                "gst_igst": round(g_row["sum_igst"], 2),
                "gst_cgst": round(g_row["sum_cgst"], 2),
                "gst_sgst": round(g_row["sum_sgst"], 2),
                "gst_cess": round(g_row["sum_cess"], 2),
                "gst_itc": round(g_row["sum_tax"], 2),
                "gst_val": round(g_row["sum_val"], 2),

                "gstr2b_count": g2b_row["cnt"],
                "gstr2b_itc": round(g2b_row["sum_tax"], 2),
                "gstr2b_taxable": round(g2b_row["sum_taxable"], 2),

                "gstr2a_count": g2a_row["cnt"],
                "gstr2a_itc": round(g2a_row["sum_tax"], 2),
                "gstr2a_taxable": round(g2a_row["sum_taxable"], 2),

                "files_count": files_cnt,
                "reco_count": reco_cnt,
                "exceptions_count": exc_cnt,
                "total_imported": b_row["cnt"] + g_row["cnt"]
            }

    def reset_period_data(self, period_id: int, target: str = "ALL", user: str = "Admin") -> Dict[str, int]:
        """
        Resets and clears imported data for the given period.
        target: 'ALL', 'BOOKS', or 'GST'.
        Returns counts of deleted records.
        """
        counts = {"books_deleted": 0, "gst_deleted": 0, "files_deleted": 0, "reco_deleted": 0}
        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            if target in ["ALL", "BOOKS"]:
                cursor.execute("DELETE FROM books_transactions WHERE period_id = ?", (period_id,))
                counts["books_deleted"] = cursor.rowcount
                cursor.execute("DELETE FROM import_files WHERE period_id = ? AND source_type = 'BOOKS'", (period_id,))
                counts["files_deleted"] += cursor.rowcount

            if target in ["ALL", "GST", "GSTR2B", "GSTR2A"]:
                cursor.execute("DELETE FROM gst_transactions WHERE period_id = ?", (period_id,))
                counts["gst_deleted"] = cursor.rowcount
                cursor.execute("DELETE FROM import_files WHERE period_id = ? AND source_type != 'BOOKS'", (period_id,))
                counts["files_deleted"] += cursor.rowcount

            if target == "ALL":
                cursor.execute("DELETE FROM import_files WHERE period_id = ?", (period_id,))
                counts["files_deleted"] = cursor.rowcount

            # Clear dependent reconciliation results & exceptions when data is reset
            cursor.execute("DELETE FROM exceptions WHERE period_id = ?", (period_id,))
            cursor.execute("DELETE FROM reconciliation_results WHERE period_id = ?", (period_id,))
            counts["reco_deleted"] = cursor.rowcount

            conn.commit()
            self.log_audit_conn(conn, user, "RESET_DATA", "Period", str(period_id), f"Reset data target={target}: {counts}")

        return counts

    def get_books_transactions(self, period_id: int) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM books_transactions WHERE period_id = ? ORDER BY invoice_date ASC, id ASC", (period_id,))
            return [dict(row) for row in cursor.fetchall()]

    def get_gst_transactions(self, period_id: int, gstr_type: str = None) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            if gstr_type:
                cursor.execute("SELECT * FROM gst_transactions WHERE period_id = ? AND gstr_type = ? ORDER BY invoice_date ASC, id ASC", (period_id, gstr_type))
            else:
                cursor.execute("SELECT * FROM gst_transactions WHERE period_id = ? ORDER BY invoice_date ASC, id ASC", (period_id,))
            return [dict(row) for row in cursor.fetchall()]

    def get_all_imported_transactions(
        self,
        period_id: int,
        source_filter: str = "ALL",
        section_filter: str = "ALL",
        search_text: str = ""
    ) -> List[Dict[str, Any]]:
        """Returns unified imported transactions list across Books and GST for Data Register and Control Totals view."""
        results = []
        books_list = self.get_books_transactions(period_id) if source_filter in ["ALL", "BOOKS"] else []
        gst_list = self.get_gst_transactions(period_id) if source_filter in ["ALL", "GST", "GSTR2B", "GSTR2A"] else []

        if source_filter == "GSTR2B":
            gst_list = [g for g in gst_list if g.get("gstr_type") == "GSTR2B"]
        elif source_filter == "GSTR2A":
            gst_list = [g for g in gst_list if g.get("gstr_type") == "GSTR2A"]

        for b in books_list:
            b_dict = dict(b)
            b_dict["data_source"] = "BOOKS"
            b_dict["source_badge"] = "📚 Books Purchase"
            b_dict["itc_avail_str"] = b_dict.get("itc_eligibility") or "Eligible"
            results.append(b_dict)

        for g in gst_list:
            g_dict = dict(g)
            g_type = g_dict.get("gstr_type", "GSTR2B")
            g_dict["data_source"] = g_type
            g_dict["source_badge"] = f"🏛️ {g_type}"
            g_dict["itc_avail_str"] = g_dict.get("itc_available") or "Y"
            results.append(g_dict)

        # Section filter
        if section_filter and section_filter != "ALL":
            results = [r for r in results if str(r.get("doc_type", "")).upper() == section_filter.upper()]

        # Search query filter
        if search_text:
            s_clean = search_text.strip().lower()
            results = [
                r for r in results
                if s_clean in str(r.get("supplier_gstin", "")).lower()
                or s_clean in str(r.get("supplier_name", "")).lower()
                or s_clean in str(r.get("invoice_number", "")).lower()
            ]

        return results

    # --- RECONCILIATION RESULTS ---

    def save_reconciliation_results(self, period_id: int, results: List[RecoResultModel]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            rows = []
            for r in results:
                rows.append((
                    period_id, r.books_id, r.gst_id, r.match_status, r.match_score,
                    r.matching_level, r.matched_fields, r.mismatched_fields,
                    r.diff_amount, r.diff_tax, r.diff_days, r.inv_similarity,
                    r.explanation, r.recommendation, r.user_action, r.user_remarks
                ))
            cursor.executemany(
                """
                INSERT INTO reconciliation_results (
                    period_id, books_id, gst_id, match_status, match_score,
                    matching_level, matched_fields, mismatched_fields,
                    diff_amount, diff_tax, diff_days, inv_similarity,
                    explanation, recommendation, user_action, user_remarks
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows
            )
            self.log_audit_conn(conn, "Admin", "RUN_RECONCILIATION", "Period", str(period_id), f"Saved {len(results)} reconciliation results")

    def get_reconciliation_results(self, period_id: int, status_filter: str = None) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT 
                    r.*,
                    b.supplier_gstin as b_gstin, b.supplier_name as b_supplier,
                    b.invoice_number as b_inv_no, b.invoice_date as b_date,
                    b.invoice_value as b_inv_val, b.taxable_value as b_taxable,
                    b.total_tax as b_tax, b.igst as b_igst, b.cgst as b_cgst, b.sgst as b_sgst,
                    g.supplier_gstin as g_gstin, g.supplier_name as g_supplier,
                    g.invoice_number as g_inv_no, g.invoice_date as g_date,
                    g.invoice_value as g_inv_val, g.taxable_value as g_taxable,
                    g.total_tax as g_tax, g.igst as g_igst, g.cgst as g_cgst, g.sgst as g_sgst,
                    g.gstr2b_period as g_period, g.itc_available as g_itc_avail
                FROM reconciliation_results r
                LEFT JOIN books_transactions b ON r.books_id = b.id
                LEFT JOIN gst_transactions g ON r.gst_id = g.id
                WHERE r.period_id = ?
            """
            params = [period_id]
            if status_filter:
                query += " AND r.match_status = ?"
                params.append(status_filter)
            query += " ORDER BY r.id ASC"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def update_user_action(self, reco_id: int, user_action: str, remarks: str = "", user: str = "Admin") -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE reconciliation_results 
                SET user_action = ?, user_remarks = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (user_action, remarks, user, reco_id)
            )
            self.log_audit_conn(conn, user, "UPDATE_RECO_ACTION", "RecoResult", str(reco_id), f"Updated status to {user_action}")
            return cursor.rowcount > 0

    def manual_match_records(self, period_id: int, books_id: int, gst_id: int, remarks: str = "", user: str = "Admin"):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            # Remove existing results linked to these records if any
            cursor.execute("DELETE FROM reconciliation_results WHERE period_id = ? AND (books_id = ? OR gst_id = ?)", (period_id, books_id, gst_id))
            # Insert manual match record
            cursor.execute(
                """
                INSERT INTO reconciliation_results (
                    period_id, books_id, gst_id, match_status, match_score, matching_level,
                    explanation, recommendation, user_action, user_remarks, reviewed_by, reviewed_at
                ) VALUES (?, ?, ?, 'EXACT', 100.0, 'MANUAL', 'Manually matched by CA/User', 'Manual Override', 'ACCEPTED', ?, ?, CURRENT_TIMESTAMP)
                """,
                (period_id, books_id, gst_id, remarks, user)
            )
            self.log_audit_conn(conn, user, "MANUAL_MATCH", "RecoResult", f"B:{books_id}-G:{gst_id}", f"Manually matched Books ID {books_id} with GST ID {gst_id}")

    # --- EXCEPTIONS WORK QUEUE ---

    def save_exceptions(self, period_id: int, exceptions: List[ExceptionModel]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            rows = []
            for exc in exceptions:
                rows.append((
                    period_id, exc.reco_result_id, exc.priority, exc.category,
                    exc.description, exc.diff_value, exc.status, exc.assigned_person, exc.remarks
                ))
            cursor.executemany(
                """
                INSERT INTO exceptions (
                    period_id, reco_result_id, priority, category,
                    description, diff_value, status, assigned_person, remarks
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows
            )

    def get_exceptions_work_queue(self, period_id: int, priority_filter: str = None) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT 
                    e.*,
                    r.match_status, r.match_score, r.explanation,
                    b.supplier_gstin as b_gstin, b.supplier_name as b_supplier, b.invoice_number as b_inv_no, b.invoice_value as b_val,
                    g.supplier_gstin as g_gstin, g.supplier_name as g_supplier, g.invoice_number as g_inv_no, g.invoice_value as g_val
                FROM exceptions e
                JOIN reconciliation_results r ON e.reco_result_id = r.id
                LEFT JOIN books_transactions b ON r.books_id = b.id
                LEFT JOIN gst_transactions g ON r.gst_id = g.id
                WHERE e.period_id = ?
            """
            params = [period_id]
            if priority_filter:
                query += " AND e.priority = ?"
                params.append(priority_filter)
            query += " ORDER BY CASE e.priority WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, e.diff_value DESC"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def update_exception_status(self, exception_id: int, status: str, remarks: str = "", assigned_person: str = None):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            if assigned_person:
                cursor.execute(
                    "UPDATE exceptions SET status = ?, remarks = ?, assigned_person = ?, resolution_date = CURRENT_TIMESTAMP WHERE id = ?",
                    (status, remarks, assigned_person, exception_id)
                )
            else:
                cursor.execute(
                    "UPDATE exceptions SET status = ?, remarks = ?, resolution_date = CURRENT_TIMESTAMP WHERE id = ?",
                    (status, remarks, exception_id)
                )

    # --- SUPPLIERS ---

    def update_supplier_metrics(self, gstin_id: int, metrics_list: List[SupplierMetricsModel]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            for m in metrics_list:
                cursor.execute(
                    """
                    INSERT INTO suppliers (
                        gstin_id, supplier_gstin, supplier_name, books_count, gst_count,
                        matched_count, mismatched_count, missing_count, total_books_itc,
                        total_gst_itc, itc_at_risk, reliability_score, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(gstin_id, supplier_gstin) DO UPDATE SET
                        supplier_name = excluded.supplier_name,
                        books_count = excluded.books_count,
                        gst_count = excluded.gst_count,
                        matched_count = excluded.matched_count,
                        mismatched_count = excluded.mismatched_count,
                        missing_count = excluded.missing_count,
                        total_books_itc = excluded.total_books_itc,
                        total_gst_itc = excluded.total_gst_itc,
                        itc_at_risk = excluded.itc_at_risk,
                        reliability_score = excluded.reliability_score,
                        updated_at = CURRENT_TIMESTAMP
                    """,
                    (gstin_id, m.supplier_gstin, m.supplier_name, m.books_count, m.gst_count,
                     m.matched_count, m.mismatched_count, m.missing_count, m.total_books_itc,
                     m.total_gst_itc, m.itc_at_risk, m.reliability_score)
                )

    def get_suppliers_by_gstin(self, gstin_id: int) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM suppliers WHERE gstin_id = ? ORDER BY itc_at_risk DESC", (gstin_id,))
            return [dict(row) for row in cursor.fetchall()]

    # --- SETTINGS & AUDIT ---

    def get_settings(self) -> Dict[str, str]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM settings")
            return {row['key']: row['value'] for row in cursor.fetchall()}

    def update_settings(self, settings_dict: Dict[str, str]):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            for k, v in settings_dict.items():
                cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))

    def log_audit(self, user: str, action: str, entity: str = "", entity_id: str = "", details: str = ""):
        with self.db.get_connection() as conn:
            self.log_audit_conn(conn, user, action, entity, entity_id, details)

    def log_audit_conn(self, conn: sqlite3.Connection, user: str, action: str, entity: str = "", entity_id: str = "", details: str = ""):
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO audit_logs (user, action, entity, entity_id, details) VALUES (?, ?, ?, ?, ?)",
            (user, action, entity, entity_id, details)
        )

    def get_audit_logs(self, limit: int = 200) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]
