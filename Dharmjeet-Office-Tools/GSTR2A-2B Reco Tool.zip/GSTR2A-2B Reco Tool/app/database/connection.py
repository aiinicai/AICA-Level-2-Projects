import sqlite3
import os
from pathlib import Path

DEFAULT_DB_PATH = Path.home() / ".gstr_reco" / "gstr_reconciliation.db"


def get_db_path(custom_path: str = None) -> Path:
    if custom_path:
        p = Path(custom_path)
    else:
        p = DEFAULT_DB_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


class DatabaseManager:
    """Manages SQLite database connections with WAL mode and foreign key constraints."""

    def __init__(self, db_path: str = None):
        self.db_path = get_db_path(db_path)
        self.init_db()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        return conn

    def init_db(self):
        from app.database.schema import CREATE_TABLES_SQL, INITIAL_SETTINGS_SQL

        with self.get_connection() as conn:
            cursor = conn.cursor()
            for statement in CREATE_TABLES_SQL.split(";"):
                stmt = statement.strip()
                if stmt:
                    cursor.execute(stmt)
            for stmt in INITIAL_SETTINGS_SQL.split(";"):
                s = stmt.strip()
                if s:
                    try:
                        cursor.execute(s)
                    except sqlite3.IntegrityError:
                        pass
            conn.commit()
