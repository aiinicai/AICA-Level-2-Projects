from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class ClientModel:
    id: Optional[int] = None
    name: str = ""
    trade_name: Optional[str] = ""
    legal_name: Optional[str] = ""
    pan: Optional[str] = ""
    contact_person: Optional[str] = ""
    email: Optional[str] = ""
    phone: Optional[str] = ""
    address: Optional[str] = ""
    created_at: Optional[str] = None


@dataclass
class GSTINModel:
    id: Optional[int] = None
    client_id: int = 0
    gstin: str = ""
    state: str = ""
    registration_type: str = "Regular"
    books_software: str = "Tally"
    default_format: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class TransactionModel:
    id: Optional[int] = None
    period_id: int = 0
    import_file_id: Optional[int] = None
    supplier_gstin: str = ""
    supplier_name: Optional[str] = ""
    invoice_number: str = ""
    normalized_inv_no: str = ""
    invoice_date: Optional[str] = ""
    invoice_value: float = 0.0
    taxable_value: float = 0.0
    igst: float = 0.0
    cgst: float = 0.0
    sgst: float = 0.0
    cess: float = 0.0
    total_tax: float = 0.0
    itc_eligibility: str = "Eligible"
    pos: Optional[str] = ""
    rcm: str = "N"
    doc_type: str = "B2B"
    source_sheet: Optional[str] = ""
    source_row: Optional[int] = 0
    remarks: Optional[str] = ""
    # Additional GST fields
    filing_date: Optional[str] = ""
    gstr2b_period: Optional[str] = ""
    itc_available: str = "Y"
    amendment_flag: str = "N"
    original_inv_no: Optional[str] = ""
    original_inv_date: Optional[str] = ""
    is_carried_forward: int = 0
    carried_forward_from_period: Optional[str] = ""


@dataclass
class RecoResultModel:
    id: Optional[int] = None
    period_id: int = 0
    books_id: Optional[int] = None
    gst_id: Optional[int] = None
    match_status: str = "MISMATCH"
    match_score: float = 0.0
    matching_level: str = ""
    matched_fields: str = "{}"
    mismatched_fields: str = "{}"
    diff_amount: float = 0.0
    diff_tax: float = 0.0
    diff_days: int = 0
    inv_similarity: float = 0.0
    explanation: str = ""
    recommendation: str = ""
    user_action: str = "OPEN"
    user_remarks: Optional[str] = ""
    assigned_to: Optional[str] = ""
    reviewed_by: Optional[str] = ""
    reviewed_at: Optional[str] = ""


@dataclass
class SupplierMetricsModel:
    id: Optional[int] = None
    gstin_id: int = 0
    supplier_gstin: str = ""
    supplier_name: Optional[str] = ""
    books_count: int = 0
    gst_count: int = 0
    matched_count: int = 0
    mismatched_count: int = 0
    missing_count: int = 0
    total_books_itc: float = 0.0
    total_gst_itc: float = 0.0
    itc_at_risk: float = 0.0
    reliability_score: float = 100.0


@dataclass
class ExceptionModel:
    id: Optional[int] = None
    period_id: int = 0
    reco_result_id: int = 0
    priority: str = "MEDIUM"
    category: str = ""
    description: str = ""
    diff_value: float = 0.0
    status: str = "Open"
    assigned_person: Optional[str] = ""
    remarks: Optional[str] = ""
    resolution_date: Optional[str] = ""
