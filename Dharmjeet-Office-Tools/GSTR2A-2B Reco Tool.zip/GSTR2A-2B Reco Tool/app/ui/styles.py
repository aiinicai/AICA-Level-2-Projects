"""QSS Style Tokens and Themes for PySide6 Desktop GUI."""

LIGHT_THEME_QSS = """
QMainWindow {
    background-color: #F8FAFC;
    font-family: 'Segoe UI', Arial, sans-serif;
}

QWidget {
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #1E293B;
}

/* Sidebar */
#SidebarWidget {
    background-color: #0F172A;
    border-right: 1px solid #1E293B;
}

#SidebarTitle {
    color: #FFFFFF;
    font-size: 16px;
    font-weight: bold;
    padding: 15px 10px;
}

QPushButton.NavBtn {
    background-color: transparent;
    color: #94A3B8;
    border: none;
    padding: 12px 15px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    border-radius: 6px;
    margin: 2px 8px;
}

QPushButton.NavBtn:hover {
    background-color: #1E293B;
    color: #F8FAFC;
}

QPushButton.NavBtn:checked {
    background-color: #2563EB;
    color: #FFFFFF;
}

/* Top Header Bar */
#HeaderBar {
    background-color: #FFFFFF;
    border-bottom: 1px solid #E2E8F0;
    padding: 8px 15px;
}

QComboBox {
    background-color: #F1F5F9;
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    padding: 6px 12px;
    font-weight: 500;
    min-width: 140px;
}

QComboBox:hover {
    border-color: #2563EB;
}

/* KPI Cards */
.KPICard {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    padding: 15px;
}

.KPITitle {
    color: #64748B;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.KPIValue {
    color: #0F172A;
    font-size: 22px;
    font-weight: bold;
    margin-top: 5px;
}

/* Buttons */
QPushButton.PrimaryBtn {
    background-color: #2563EB;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}

QPushButton.PrimaryBtn:hover {
    background-color: #1D4ED8;
}

QPushButton.SuccessBtn {
    background-color: #059669;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}

QPushButton.SuccessBtn:hover {
    background-color: #047857;
}

QPushButton.DangerBtn {
    background-color: #DC2626;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}

/* Tables */
QTableWidget {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    gridline-color: #F1F5F9;
    border-radius: 8px;
    selection-background-color: #E0F2FE;
    selection-color: #0369A1;
}

QHeaderView::section {
    background-color: #F8FAFC;
    color: #475569;
    font-weight: bold;
    font-size: 12px;
    border: none;
    border-bottom: 2px solid #E2E8F0;
    padding: 8px;
}

/* Tabs */
QTabWidget::pane {
    border: 1px solid #E2E8F0;
    background-color: #FFFFFF;
    border-radius: 8px;
}

QTabBar::tab {
    background-color: #F1F5F9;
    color: #64748B;
    padding: 8px 16px;
    font-weight: 600;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    margin-right: 4px;
}

QTabBar::tab:selected {
    background-color: #FFFFFF;
    color: #2563EB;
    border-bottom: 2px solid #2563EB;
}
"""

DARK_THEME_QSS = """
QMainWindow {
    background-color: #0F172A;
    font-family: 'Segoe UI', Arial, sans-serif;
}

QWidget {
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #F8FAFC;
}

#SidebarWidget {
    background-color: #0B0F19;
    border-right: 1px solid #1E293B;
}

#SidebarTitle {
    color: #FFFFFF;
    font-size: 16px;
    font-weight: bold;
    padding: 15px 10px;
}

QPushButton.NavBtn {
    background-color: transparent;
    color: #94A3B8;
    border: none;
    padding: 12px 15px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    border-radius: 6px;
    margin: 2px 8px;
}

QPushButton.NavBtn:hover {
    background-color: #1E293B;
    color: #F8FAFC;
}

QPushButton.NavBtn:checked {
    background-color: #2563EB;
    color: #FFFFFF;
}

#HeaderBar {
    background-color: #1E293B;
    border-bottom: 1px solid #334155;
    padding: 8px 15px;
}

QComboBox {
    background-color: #334155;
    color: #F8FAFC;
    border: 1px solid #475569;
    border-radius: 6px;
    padding: 6px 12px;
}

.KPICard {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 10px;
    padding: 15px;
}

.KPITitle {
    color: #94A3B8;
    font-size: 12px;
    font-weight: 600;
}

.KPIValue {
    color: #F8FAFC;
    font-size: 22px;
    font-weight: bold;
}

QTableWidget {
    background-color: #1E293B;
    border: 1px solid #334155;
    gridline-color: #334155;
    color: #F8FAFC;
}

QHeaderView::section {
    background-color: #0F172A;
    color: #94A3B8;
    font-weight: bold;
    border-bottom: 2px solid #334155;
}
"""
