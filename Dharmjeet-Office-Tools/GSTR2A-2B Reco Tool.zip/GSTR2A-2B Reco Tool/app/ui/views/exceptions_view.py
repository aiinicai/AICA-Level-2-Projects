from typing import Optional, Callable, Dict, Any, List
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QComboBox, QLineEdit, QGroupBox,
    QFrame, QMessageBox, QFileDialog
)
from PySide6.QtCore import Qt, QTimer
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


class ExceptionsView(QWidget):
    """Prioritized Exceptions Work Queue with Multi-Dimensional Filters and Discrepancy Control Totals."""

    def __init__(self, repository, get_current_period_cb: Callable, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.current_filtered_exceptions: List[Dict[str, Any]] = []
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.refresh_data)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Header Title and Actions
        top_bar = QHBoxLayout()
        title = QLabel("⚠ Exceptions & Discrepancies Work Queue")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        top_bar.addWidget(title)
        top_bar.addStretch()

        btn_export = QPushButton("📊 Export Exceptions to Excel")
        btn_export.setProperty("class", "SuccessBtn")
        btn_export.clicked.connect(self.export_exceptions_to_excel)
        top_bar.addWidget(btn_export)

        btn_refresh = QPushButton("🔄 Refresh Queue")
        btn_refresh.clicked.connect(self.refresh_data)
        top_bar.addWidget(btn_refresh)

        layout.addLayout(top_bar)

        # Summary / Discrepancy KPI Cards Bar
        kpi_frame = QFrame()
        kpi_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 8px; padding: 8px;")
        kpi_layout = QHBoxLayout(kpi_frame)
        kpi_layout.setContentsMargins(12, 6, 12, 6)

        self.lbl_kpi_total = QLabel("Total Exceptions: <b>0</b>")
        self.lbl_kpi_total.setStyleSheet("font-size: 13px; color: #1E293B;")
        kpi_layout.addWidget(self.lbl_kpi_total)

        kpi_layout.addWidget(QLabel(" | "))

        self.lbl_kpi_critical = QLabel("Critical / High: <b>0</b>")
        self.lbl_kpi_critical.setStyleSheet("font-size: 13px; color: #DC2626;")
        kpi_layout.addWidget(self.lbl_kpi_critical)

        kpi_layout.addWidget(QLabel(" | "))

        self.lbl_kpi_risk = QLabel("Total ITC at Risk: <b>₹0.00</b>")
        self.lbl_kpi_risk.setStyleSheet("font-size: 13px; color: #B91C1C; font-weight: bold;")
        kpi_layout.addWidget(self.lbl_kpi_risk)

        kpi_layout.addStretch()
        layout.addWidget(kpi_frame)

        # Filters Bar
        flt_box = QFrame()
        flt_box.setStyleSheet("background-color: #F8FAFC; border: 1px solid #CBD5E1; border-radius: 6px; padding: 6px;")
        flt_layout = QHBoxLayout(flt_box)
        flt_layout.setContentsMargins(8, 6, 8, 6)
        flt_layout.setSpacing(10)

        flt_layout.addWidget(QLabel("Priority:"))
        self.cmb_priority = QComboBox()
        self.cmb_priority.addItems(["All Priorities", "CRITICAL", "HIGH", "MEDIUM", "LOW"])
        self.cmb_priority.currentIndexChanged.connect(self.refresh_data)
        flt_layout.addWidget(self.cmb_priority)

        flt_layout.addWidget(QLabel("Category:"))
        self.cmb_category = QComboBox()
        self.cmb_category.addItems([
            "All Categories",
            "MISMATCH (Tax/Amount Mismatch)",
            "BOOKS_ONLY (Pending in 2A/2B)",
            "GSTR_ONLY (Missing in Books)",
            "PARTIAL (Probable Matches)",
            "DUPLICATE (Duplicate Invoices)"
        ])
        self.cmb_category.currentIndexChanged.connect(self.refresh_data)
        flt_layout.addWidget(self.cmb_category)

        flt_layout.addWidget(QLabel("Status:"))
        self.cmb_status = QComboBox()
        self.cmb_status.addItems(["All Statuses", "OPEN", "ACCEPTED", "REJECTED"])
        self.cmb_status.currentIndexChanged.connect(self.refresh_data)
        flt_layout.addWidget(self.cmb_status)

        flt_layout.addWidget(QLabel("Search:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("Search Supplier, GSTIN, Inv No...")
        self.txt_search.textChanged.connect(lambda: self.search_timer.start(250))
        flt_layout.addWidget(self.txt_search)

        layout.addWidget(flt_box)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(9)
        self.table.setHorizontalHeaderLabels([
            "Priority", "Category", "Supplier GSTIN", "Supplier / Trade Name",
            "Books Inv No", "GST Inv No", "ITC Difference (₹)", "Status", "Resolution"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)

    def refresh_data(self):
        period_id = self.get_period_cb()
        if not period_id:
            self.table.setRowCount(0)
            self.lbl_kpi_total.setText("Total Exceptions: <b>0</b>")
            self.lbl_kpi_critical.setText("Critical / High: <b>0</b>")
            self.lbl_kpi_risk.setText("Total ITC at Risk: <b>₹0.00</b>")
            return

        p_sel = self.cmb_priority.currentText()
        p_filter = None if p_sel == "All Priorities" else p_sel

        cat_sel = self.cmb_category.currentText()
        if "MISMATCH" in cat_sel:
            cat_filter = "MISMATCH"
        elif "BOOKS_ONLY" in cat_sel:
            cat_filter = "BOOKS_ONLY"
        elif "GSTR_ONLY" in cat_sel:
            cat_filter = "GSTR_ONLY"
        elif "PARTIAL" in cat_sel:
            cat_filter = "PARTIAL"
        elif "DUPLICATE" in cat_sel:
            cat_filter = "DUPLICATE"
        else:
            cat_filter = None

        status_sel = self.cmb_status.currentText()
        status_filter = None if status_sel == "All Statuses" else status_sel
        search_query = self.txt_search.text().strip().lower()

        # Populate queue directly from reconciliation results
        reco_results = self.repo.get_reconciliation_results(period_id)
        raw_mismatches = [
            r for r in reco_results
            if r.get("match_status") in ["MISMATCH", "BOOKS_ONLY", "GSTR_ONLY", "DUPLICATE", "PARTIAL", "PROBABLE"]
        ]

        # Filter items first
        filtered: List[Dict[str, Any]] = []
        total_risk = 0.0
        critical_count = 0

        for r in raw_mismatches:
            diff_amt = float(r.get("diff_tax") or r.get("diff_amount") or 0.0)
            status_match = r.get("match_status", "")
            user_action = str(r.get("user_action") or "OPEN").upper()

            # Assign Priority
            if diff_amt >= 50000 or status_match == "DUPLICATE":
                priority = "CRITICAL"
            elif diff_amt >= 10000 or status_match == "MISMATCH":
                priority = "HIGH"
            elif diff_amt >= 1000 or status_match == "BOOKS_ONLY":
                priority = "MEDIUM"
            else:
                priority = "LOW"

            if priority in ["CRITICAL", "HIGH"]:
                critical_count += 1
            total_risk += diff_amt

            # Apply Filters
            if p_filter and priority != p_filter:
                continue

            if cat_filter:
                if cat_filter == "PARTIAL" and status_match not in ["PARTIAL", "PROBABLE"]:
                    continue
                elif cat_filter != "PARTIAL" and status_match != cat_filter:
                    continue

            if status_filter and user_action != status_filter:
                continue

            if search_query:
                sup_gstin = str(r.get("b_gstin") or r.get("g_gstin") or "").lower()
                sup_name = str(r.get("b_supplier") or r.get("g_supplier") or "").lower()
                b_inv = str(r.get("b_inv_no") or "").lower()
                g_inv = str(r.get("g_inv_no") or "").lower()
                if search_query not in sup_gstin and search_query not in sup_name and search_query not in b_inv and search_query not in g_inv:
                    continue

            item_data = dict(r)
            item_data["computed_priority"] = priority
            item_data["computed_diff"] = diff_amt
            filtered.append(item_data)

        self.current_filtered_exceptions = filtered

        # Update KPI Summary
        self.lbl_kpi_total.setText(f"Total Exceptions: <b>{len(filtered):,}</b> (of {len(raw_mismatches):,} total)")
        self.lbl_kpi_critical.setText(f"Critical / High: <b>{critical_count:,}</b>")
        self.lbl_kpi_risk.setText(f"Total ITC at Risk: <b>₹{total_risk:,.2f}</b>")

        # Populate Table Correctly (Filter first, setRowCount, then populate all rows 0..N-1)
        self.table.setUpdatesEnabled(False)
        try:
            self.table.setRowCount(len(filtered))
            for idx, r in enumerate(filtered):
                priority = r["computed_priority"]
                diff_amt = r["computed_diff"]

                item_pri = QTableWidgetItem(priority)
                item_pri.setTextAlignment(Qt.AlignCenter)
                if priority == "CRITICAL":
                    item_pri.setForeground(Qt.red)
                elif priority == "HIGH":
                    item_pri.setForeground(Qt.darkYellow)
                self.table.setItem(idx, 0, item_pri)

                self.table.setItem(idx, 1, QTableWidgetItem(r.get("match_status", "-")))
                self.table.setItem(idx, 2, QTableWidgetItem(r.get("b_gstin") or r.get("g_gstin") or "-"))
                self.table.setItem(idx, 3, QTableWidgetItem(r.get("b_supplier") or r.get("g_supplier") or "-"))
                self.table.setItem(idx, 4, QTableWidgetItem(r.get("b_inv_no") or "-"))
                self.table.setItem(idx, 5, QTableWidgetItem(r.get("g_inv_no") or "-"))

                item_diff = QTableWidgetItem(f"₹{diff_amt:,.2f}")
                item_diff.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                item_diff.setForeground(Qt.red if diff_amt > 0 else Qt.black)
                self.table.setItem(idx, 6, item_diff)

                self.table.setItem(idx, 7, QTableWidgetItem(r.get("user_action") or "OPEN"))
                self.table.setItem(idx, 8, QTableWidgetItem(r.get("recommendation") or "Review and follow up"))
        finally:
            self.table.setUpdatesEnabled(True)

    def export_exceptions_to_excel(self):
        if not self.current_filtered_exceptions:
            QMessageBox.warning(self, "No Data", "No exceptions in current filtered queue to export.")
            return

        file_path, _ = QFileDialog.getSaveFileName(self, "Save Exceptions Queue", "Exceptions_Work_Queue.xlsx", "Excel Files (*.xlsx)")
        if not file_path:
            return

        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Exceptions Queue"

            headers = [
                "#", "Priority", "Category", "Supplier GSTIN", "Supplier Name",
                "Books Invoice No", "GST Invoice No", "ITC Difference (₹)", "Status", "Recommendation"
            ]
            ws.append(headers)

            header_fill = PatternFill(start_color="B91C1C", end_color="B91C1C", fill_type="solid")
            header_font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
            for col in range(1, len(headers) + 1):
                cell = ws.cell(row=1, column=col)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")

            for idx, r in enumerate(self.current_filtered_exceptions, start=1):
                ws.append([
                    idx,
                    r.get("computed_priority", "MEDIUM"),
                    r.get("match_status", ""),
                    r.get("b_gstin") or r.get("g_gstin") or "",
                    r.get("b_supplier") or r.get("g_supplier") or "",
                    r.get("b_inv_no") or "",
                    r.get("g_inv_no") or "",
                    r.get("computed_diff", 0.0),
                    r.get("user_action") or "OPEN",
                    r.get("recommendation") or ""
                ])

            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = max(10, min(max_len + 3, 40))

            wb.save(file_path)
            QMessageBox.information(self, "Export Completed", f"Successfully exported {len(self.current_filtered_exceptions)} exceptions to:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to export exceptions file: {str(e)}")
