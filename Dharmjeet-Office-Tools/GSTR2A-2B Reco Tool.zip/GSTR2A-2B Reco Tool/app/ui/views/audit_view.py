from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView
)


class AuditView(QWidget):
    """Immutable Audit Trail Log Viewer."""

    def __init__(self, repository, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("📜 Immutable Application Audit Trail")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID", "Timestamp", "User", "Action", "Entity", "Details"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.refresh_data()

    def refresh_data(self):
        logs = self.repo.get_audit_logs(limit=200)
        self.table.setRowCount(len(logs))

        for idx, l in enumerate(logs):
            self.table.setItem(idx, 0, QTableWidgetItem(str(l["id"])))
            self.table.setItem(idx, 1, QTableWidgetItem(str(l["timestamp"])))
            self.table.setItem(idx, 2, QTableWidgetItem(str(l["user"])))
            self.table.setItem(idx, 3, QTableWidgetItem(str(l["action"])))
            self.table.setItem(idx, 4, QTableWidgetItem(str(l["entity"])))
            self.table.setItem(idx, 5, QTableWidgetItem(str(l["details"])))
