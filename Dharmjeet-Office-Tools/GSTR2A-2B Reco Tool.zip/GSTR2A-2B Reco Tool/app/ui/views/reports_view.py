import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog,
    QMessageBox, QGroupBox, QFormLayout, QLineEdit, QTextEdit
)
from app.reports.excel_exporter import ExcelExporter
from app.reports.pdf_exporter import PDFExporter
from app.reconciliation.itc_engine import ITCEngine


class ReportsView(QWidget):
    """Reports & CA Workpaper Generation Center."""

    def __init__(self, repository, get_current_period_cb, get_current_gstin_cb, get_client_info_cb, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.get_gstin_cb = get_current_gstin_cb
        self.get_client_info_cb = get_client_info_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("📑 Reports & CA Workpapers Generator")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        # CA Sign-off details
        grp_ca = QGroupBox("CA Workpaper Sign-Off Details")
        ca_layout = QFormLayout(grp_ca)

        self.txt_prep = QLineEdit("Staff Accountant")
        self.txt_rev = QLineEdit("CA Partner")
        self.txt_remarks = QTextEdit("GSTR-2B reconciliation verified with purchase register. Exceptions flagged for client follow-up.")
        self.txt_remarks.setMaximumHeight(60)

        ca_layout.addRow("Prepared By:", self.txt_prep)
        ca_layout.addRow("Reviewed By:", self.txt_rev)
        ca_layout.addRow("Sign-off Remarks:", self.txt_remarks)

        layout.addWidget(grp_ca)

        # Export Buttons
        btn_layout = QHBoxLayout()

        btn_excel = QPushButton("📊 Export Complete Excel Workpaper (.xlsx)")
        btn_excel.setProperty("class", "PrimaryBtn")
        btn_excel.setStyleSheet("font-size: 13px; padding: 12px 20px;")
        btn_excel.clicked.connect(self.export_excel)
        btn_layout.addWidget(btn_excel)

        btn_pdf = QPushButton("📄 Generate Audit Report PDF (.pdf)")
        btn_pdf.setProperty("class", "SuccessBtn")
        btn_pdf.setStyleSheet("font-size: 13px; padding: 12px 20px;")
        btn_pdf.clicked.connect(self.export_pdf)
        btn_layout.addWidget(btn_pdf)

        layout.addLayout(btn_layout)
        layout.addStretch()

    def export_excel(self):
        period_id = self.get_period_cb()
        if not period_id:
            QMessageBox.warning(self, "Warning", "Please select Client & Period first.")
            return

        client_info = self.get_client_info_cb()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel Reconciliation Workpaper", "GSTR2B_Reconciliation_Workpaper.xlsx", "Excel Files (*.xlsx)")
        if not file_path:
            return

        try:
            reco_results = self.repo.get_reconciliation_results(period_id)
            summary = ITCEngine.calculate_itc_control_statement(reco_results)
            suppliers = self.repo.get_suppliers_by_gstin(self.get_gstin_cb())

            ExcelExporter.export_reconciliation_workpaper(
                file_path=file_path,
                client_name=client_info.get("client_name", "Client"),
                gstin=client_info.get("gstin", ""),
                period_name=client_info.get("period", ""),
                itc_summary=summary,
                reco_results=reco_results,
                suppliers_list=suppliers
            )
            QMessageBox.information(self, "Success", f"Excel workpaper exported successfully to:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", f"Could not export Excel file: {str(e)}")

    def export_pdf(self):
        period_id = self.get_period_cb()
        if not period_id:
            QMessageBox.warning(self, "Warning", "Please select Client & Period first.")
            return

        client_info = self.get_client_info_cb()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save PDF Audit Report", "GSTR2B_Reconciliation_Report.pdf", "PDF Files (*.pdf)")
        if not file_path:
            return

        try:
            reco_results = self.repo.get_reconciliation_results(period_id)
            summary = ITCEngine.calculate_itc_control_statement(reco_results)

            PDFExporter.generate_pdf_report(
                file_path=file_path,
                client_name=client_info.get("client_name", "Client"),
                gstin=client_info.get("gstin", ""),
                period_name=client_info.get("period", ""),
                summary=summary,
                prepared_by=self.txt_prep.text().strip(),
                reviewed_by=self.txt_rev.text().strip(),
                remarks=self.txt_remarks.toPlainText().strip()
            )
            QMessageBox.information(self, "Success", f"PDF report generated successfully to:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", f"Could not export PDF file: {str(e)}")
