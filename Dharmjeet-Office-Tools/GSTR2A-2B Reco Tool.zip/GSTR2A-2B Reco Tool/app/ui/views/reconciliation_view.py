from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QGroupBox, QGridLayout
)
from PySide6.QtCore import Qt, QThread, Signal
from app.reconciliation.matching_engine import MatchingEngine
from app.reconciliation.itc_engine import ITCEngine
from app.reconciliation.supplier_engine import SupplierEngine


class RecoWorkerThread(QThread):
    progress_sig = Signal(int, str)
    finished_sig = Signal(dict)
    error_sig = Signal(str)

    def __init__(self, repo, period_id, gstin_id):
        super().__init__()
        self.repo = repo
        self.period_id = period_id
        self.gstin_id = gstin_id

    def run(self):
        try:
            self.progress_sig.emit(10, "Fetching Books and GST records from database...")
            books_list = self.repo.get_books_transactions(self.period_id)
            gst_list = self.repo.get_gst_transactions(self.period_id)

            if not books_list and not gst_list:
                self.error_sig.emit("No imported Books or GSTR-2B transactions found for this period.")
                return

            self.progress_sig.emit(25, "Clearing previous reconciliation cache...")
            self.repo.clear_period_reconciliation(self.period_id)

            self.progress_sig.emit(40, "Running 8-Level Hierarchical Matching Engine...")
            settings = self.repo.get_settings()
            engine = MatchingEngine(
                date_tolerance_days=int(settings.get("date_tolerance_days", "3")),
                amount_tolerance_rs=float(settings.get("amount_tolerance_rs", "1.0")),
                amount_tolerance_pct=float(settings.get("amount_tolerance_pct", "0.01")),
                fuzzy_threshold_high=float(settings.get("fuzzy_threshold_high", "90")),
                fuzzy_threshold_medium=float(settings.get("fuzzy_threshold_medium", "80"))
            )

            results = engine.reconcile(self.period_id, books_list, gst_list)

            self.progress_sig.emit(70, "Saving reconciliation results...")
            self.repo.save_reconciliation_results(self.period_id, results)

            self.progress_sig.emit(85, "Calculating supplier compliance and reliability scores...")
            saved_results = self.repo.get_reconciliation_results(self.period_id)
            supplier_metrics = SupplierEngine.compute_supplier_metrics(self.gstin_id, saved_results)
            self.repo.update_supplier_metrics(self.gstin_id, supplier_metrics)

            self.progress_sig.emit(100, "Reconciliation completed successfully!")
            summary = ITCEngine.calculate_itc_control_statement(saved_results)
            self.finished_sig.emit(summary)

        except Exception as e:
            self.error_sig.emit(str(e))


class ReconciliationView(QWidget):
    """Reconciliation Workspace & Execution Center."""

    def __init__(self, repository, get_current_period_cb, get_current_gstin_cb, on_reco_completed_cb=None, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.get_gstin_cb = get_current_gstin_cb
        self.on_completed_cb = on_reco_completed_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("📊 Multi-Stage GSTR-2B Reconciliation Engine")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        # Control Panel
        ctrl_box = QGroupBox("Run Reconciliation")
        ctrl_layout = QVBoxLayout(ctrl_box)

        lbl_desc = QLabel("Click below to execute the 8-Level Hierarchical Reconciliation Engine (Level 1 Exact -> Level 8 Fuzzy/Proximity).")
        lbl_desc.setStyleSheet("color: #64748B; font-size: 13px;")
        ctrl_layout.addWidget(lbl_desc)

        btn_layout = QHBoxLayout()
        self.btn_run = QPushButton("🚀 START RECONCILIATION")
        self.btn_run.setProperty("class", "PrimaryBtn")
        self.btn_run.setStyleSheet("font-size: 14px; padding: 10px 20px;")
        self.btn_run.clicked.connect(self.start_reconciliation)
        btn_layout.addWidget(self.btn_run)
        btn_layout.addStretch()

        ctrl_layout.addLayout(btn_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        ctrl_layout.addWidget(self.progress_bar)

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color: #2563EB; font-weight: bold;")
        ctrl_layout.addWidget(self.lbl_status)

        layout.addWidget(ctrl_box)

        # Results Summary Table
        res_box = QGroupBox("Reconciliation Outcome Summary")
        res_layout = QVBoxLayout(res_box)

        self.lbl_results_status = QLabel("Showing imported data totals. Run reconciliation for full breakdown.")
        self.lbl_results_status.setStyleSheet("color: #2563EB; font-size: 12px; padding: 4px;")
        res_layout.addWidget(self.lbl_results_status)

        self.table_summary = QTableWidget()
        self.table_summary.setColumnCount(5)
        self.table_summary.setHorizontalHeaderLabels([
            "Category", "Invoice Count", "Books ITC (₹)", "GSTR-2B / 2A ITC (₹)", "ITC Difference (₹)"
        ])
        self.table_summary.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table_summary.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_summary.setAlternatingRowColors(True)
        res_layout.addWidget(self.table_summary)

        layout.addWidget(res_box)

    def refresh_data(self):
        """Show imported data ITC totals in the summary table (pre-reconciliation state)."""
        period_id = self.get_period_cb()
        if not period_id:
            self.table_summary.setRowCount(0)
            self.lbl_results_status.setText("Select a Client, GSTIN, and Period to begin.")
            return

        # If reco results exist, keep them displayed (they were set by on_reco_finished)
        reco_results = self.repo.get_reconciliation_results(period_id)
        if reco_results:
            # Reco already done – rebuild the summary table from saved results
            from app.reconciliation.itc_engine import ITCEngine
            summary = ITCEngine.calculate_itc_control_statement(reco_results)
            self._populate_reco_summary(summary)
            self.lbl_results_status.setText(
                f"✓ Reconciliation results loaded. Match: {summary.get('match_pct', 0.0)}% | "
                f"Total invoices: {summary.get('total_count', 0)}"
            )
            self.lbl_results_status.setStyleSheet(
                "color: #15803D; font-size: 12px; font-weight: bold; "
                "background-color: #DCFCE7; padding: 4px; border-radius: 4px;"
            )
            return

        # No reco yet – show imported data summary
        ds = self.repo.get_period_data_summary(period_id)
        b_cnt   = ds.get("books_count",   0)
        g2b_cnt = ds.get("gstr2b_count",  0)
        g2a_cnt = ds.get("gstr2a_count",  0)
        b_itc   = ds.get("books_itc",     0.0)
        g2b_itc = ds.get("gstr2b_itc",   0.0)
        g2a_itc = ds.get("gstr2a_itc",   0.0)
        total_g_cnt = g2b_cnt + g2a_cnt
        total_g_itc = g2b_itc + g2a_itc

        rows = [
            ("Books Purchase Register",  b_cnt,       b_itc,    0.0,         b_itc),
            ("GSTR-2B (Filing Data)",    g2b_cnt,     0.0,      g2b_itc,     g2b_itc),
            ("GSTR-2A (Auto-populated)", g2a_cnt,     0.0,      g2a_itc,     g2a_itc),
            ("TOTAL (All Sources)",      b_cnt + total_g_cnt,  b_itc, total_g_itc, abs(b_itc - total_g_itc)),
        ]

        self.table_summary.setRowCount(len(rows))
        for idx, (cat, cnt, b_val, g_val, diff) in enumerate(rows):
            self.table_summary.setItem(idx, 0, QTableWidgetItem(cat))
            cnt_item = QTableWidgetItem(str(cnt))
            cnt_item.setTextAlignment(Qt.AlignCenter)
            self.table_summary.setItem(idx, 1, cnt_item)
            for col, val in [(2, b_val), (3, g_val), (4, diff)]:
                from PySide6.QtWidgets import QTableWidgetItem as TWI
                item = TWI(f"₹{val:,.2f}")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_summary.setItem(idx, col, item)

        if b_cnt == 0 and total_g_cnt == 0:
            self.lbl_results_status.setText(
                "ℹ No data imported yet for this period. Use 'Import Data' to upload Books/GSTR-2A/2B."
            )
            self.lbl_results_status.setStyleSheet("color: #64748B; font-size: 12px; padding: 4px;")
        else:
            self.lbl_results_status.setText(
                f"📊 Imported: {b_cnt} Books invoices (₹{b_itc:,.2f} ITC) | "
                f"{g2b_cnt} GSTR-2B (₹{g2b_itc:,.2f}) | "
                f"{g2a_cnt} GSTR-2A (₹{g2a_itc:,.2f}). Click START RECONCILIATION to begin."
            )
            self.lbl_results_status.setStyleSheet(
                "color: #1D4ED8; font-size: 12px; font-weight: bold; padding: 4px;"
            )

    def _populate_reco_summary(self, summary: dict):
        rows = [
            ("Exact Matches",           summary.get("matched_count",     0), summary.get("matched_itc",    0.0), summary.get("matched_itc",    0.0), 0.0),
            ("Probable & Mismatches",   summary.get("mismatched_count",  0), summary.get("itc_at_risk",    0.0), 0.0,                                  summary.get("itc_at_risk", 0.0)),
            ("Books Only (Pending 2B)", summary.get("books_only_count",  0), summary.get("books_only_itc", 0.0), 0.0,                                  summary.get("books_only_itc", 0.0)),
            ("GSTR-2B Only",           summary.get("gst_only_count",    0), 0.0,                               summary.get("gst_only_itc",   0.0),   summary.get("gst_only_itc", 0.0)),
            ("Total Invoices",          summary.get("total_count",        0), summary.get("total_books_itc",0.0), summary.get("total_2b_itc",  0.0),   abs(summary.get("total_books_itc", 0.0) - summary.get("total_2b_itc", 0.0))),
        ]
        self.table_summary.setRowCount(0)
        for idx, (cat, cnt, b_itc, g_itc, diff) in enumerate(rows):
            self.table_summary.insertRow(idx)
            self.table_summary.setItem(idx, 0, QTableWidgetItem(cat))
            self.table_summary.setItem(idx, 1, QTableWidgetItem(str(cnt)))
            self.table_summary.setItem(idx, 2, QTableWidgetItem(f"₹{b_itc:,.2f}"))
            self.table_summary.setItem(idx, 3, QTableWidgetItem(f"₹{g_itc:,.2f}"))
            self.table_summary.setItem(idx, 4, QTableWidgetItem(f"₹{diff:,.2f}"))

    def start_reconciliation(self):
        period_id = self.get_period_cb()
        gstin_id = self.get_gstin_cb()

        if not period_id:
            QMessageBox.warning(self, "Warning", "Please select a Client, GSTIN, and Period first from the top bar.")
            return

        self.btn_run.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)

        self.worker = RecoWorkerThread(self.repo, period_id, gstin_id)
        self.worker.progress_sig.connect(self.update_progress)
        self.worker.finished_sig.connect(self.on_reco_finished)
        self.worker.error_sig.connect(self.on_reco_error)
        self.worker.start()

    def update_progress(self, pct, msg):
        self.progress_bar.setValue(pct)
        self.lbl_status.setText(msg)

    def on_reco_finished(self, summary):
        self.btn_run.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.lbl_status.setText("✓ Reconciliation Completed!")
        self._populate_reco_summary(summary)
        self.lbl_results_status.setText(
            f"✓ Reconciliation complete! Match: {summary.get('match_pct', 0.0)}% across {summary.get('total_count', 0)} invoices."
        )
        self.lbl_results_status.setStyleSheet(
            "color: #15803D; font-size: 12px; font-weight: bold; "
            "background-color: #DCFCE7; padding: 4px; border-radius: 4px;"
        )

        if self.on_completed_cb:
            self.on_completed_cb(self.get_period_cb())

        QMessageBox.information(self, "Success", f"Reconciliation finished! Match percentage: {summary.get('match_pct', 0.0)}%")

    def on_reco_error(self, err):
        self.btn_run.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.lbl_status.setText("")
        QMessageBox.critical(self, "Reconciliation Error", f"Failed to reconcile: {err}")
