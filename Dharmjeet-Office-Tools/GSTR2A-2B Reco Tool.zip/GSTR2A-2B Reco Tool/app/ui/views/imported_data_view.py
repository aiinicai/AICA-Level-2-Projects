import os
from typing import Optional, Callable
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox,
    QGridLayout, QFrame, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


class ImportedDataView(QWidget):
    """
    Imported Data Register and Financial Control Totals Center.
    Allows complete verification of data completeness and accuracy across Books and GSTR-2A/2B.
    """

    def __init__(self, repository, get_current_period_cb: Callable, on_navigate_import_cb: Optional[Callable] = None, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.on_navigate_import_cb = on_navigate_import_cb
        self.current_records = []
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.refresh_data)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Header Title
        hdr_layout = QHBoxLayout()
        title = QLabel("📋 Imported Data Register & Financial Control Totals")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        hdr_layout.addWidget(title)
        hdr_layout.addStretch()

        btn_import_more = QPushButton("📥 Import More Data")
        btn_import_more.setProperty("class", "PrimaryBtn")
        if self.on_navigate_import_cb:
            btn_import_more.clicked.connect(self.on_navigate_import_cb)
        hdr_layout.addWidget(btn_import_more)

        btn_export = QPushButton("📊 Export Register to Excel")
        btn_export.setProperty("class", "SuccessBtn")
        btn_export.clicked.connect(self.export_to_excel)
        hdr_layout.addWidget(btn_export)

        layout.addLayout(hdr_layout)

        # Financial Control Totals Panel
        self.grp_control = QGroupBox("Financial Control Totals & Completeness Reconciliation")
        self.grp_control.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                margin-top: 6px;
                padding-top: 10px;
                background-color: #F8FAFC;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 4px;
                color: #1E293B;
            }
        """)
        ctrl_layout = QVBoxLayout(self.grp_control)
        ctrl_layout.setContentsMargins(12, 12, 12, 12)
        ctrl_layout.setSpacing(8)

        # Summary Grid
        self.table_control = QTableWidget()
        self.table_control.setColumnCount(8)
        self.table_control.setHorizontalHeaderLabels([
            "Data Source", "Invoices Count", "Taxable Value (₹)", "IGST (₹)", "CGST (₹)", "SGST (₹)", "CESS (₹)", "Total ITC / Tax (₹)"
        ])
        self.table_control.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table_control.verticalHeader().setVisible(False)
        self.table_control.setFixedHeight(125)
        self.table_control.setEditTriggers(QTableWidget.NoEditTriggers)
        ctrl_layout.addWidget(self.table_control)

        # Status / Variance Banner
        self.lbl_variance_banner = QLabel("Select Client and Period to calculate Control Totals.")
        self.lbl_variance_banner.setStyleSheet("font-size: 13px; font-weight: bold; color: #475569; padding: 4px;")
        ctrl_layout.addWidget(self.lbl_variance_banner)

        layout.addWidget(self.grp_control)

        # Filter & Search Toolbar
        filter_box = QFrame()
        filter_box.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 6px; padding: 6px;")
        flt_layout = QHBoxLayout(filter_box)
        flt_layout.setContentsMargins(8, 4, 8, 4)
        flt_layout.setSpacing(10)

        flt_layout.addWidget(QLabel("Data Source:"))
        self.cmb_source_filter = QComboBox()
        self.cmb_source_filter.addItems([
            "All Data Sources (Books + GST)",
            "Books Purchase Register Only",
            "GSTR-2B Filing Data Only",
            "GSTR-2A Filing Data Only",
            "All GST Portal Data (2A + 2B)"
        ])
        self.cmb_source_filter.currentIndexChanged.connect(self.refresh_data)
        flt_layout.addWidget(self.cmb_source_filter)

        flt_layout.addWidget(QLabel("Section:"))
        self.cmb_section_filter = QComboBox()
        self.cmb_section_filter.addItems([
            "All Sections", "B2B", "B2BA", "CDNR", "CDNRA", "ISD", "ISDA", "IMPG", "IMPGSEZ", "TDS", "TCS"
        ])
        self.cmb_section_filter.currentIndexChanged.connect(self.refresh_data)
        flt_layout.addWidget(self.cmb_section_filter)

        flt_layout.addWidget(QLabel("Search:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("Search GSTIN, Trade Name, or Invoice No...")
        self.txt_search.textChanged.connect(lambda: self.search_timer.start(250))
        flt_layout.addWidget(self.txt_search)

        btn_refresh = QPushButton("🔄 Refresh")
        btn_refresh.clicked.connect(self.refresh_data)
        flt_layout.addWidget(btn_refresh)

        layout.addWidget(filter_box)

        # Tabular Register
        self.table_data = QTableWidget()
        self.table_data.setColumnCount(15)
        self.table_data.setHorizontalHeaderLabels([
            "#", "Source", "Supplier GSTIN", "Supplier / Trade Name", "Invoice / Note No",
            "Date", "Doc Type", "Taxable Value (₹)", "IGST (₹)", "CGST (₹)", "SGST (₹)",
            "Cess (₹)", "Total ITC / Tax (₹)", "Invoice Value (₹)", "ITC Status"
        ])
        self.table_data.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table_data.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table_data.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table_data.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_data.setAlternatingRowColors(True)
        layout.addWidget(self.table_data)

    def refresh_data(self):
        period_id = self.get_period_cb()
        if not period_id:
            self.table_control.setRowCount(0)
            self.table_data.setRowCount(0)
            self.lbl_variance_banner.setText("Please select a Client, GSTIN, and Period from the top bar.")
            return

        # 1. Update Financial Control Totals
        summary = self.repo.get_period_data_summary(period_id)
        self.update_control_totals_table(summary)

        # 2. Query transactions based on filters
        src_idx = self.cmb_source_filter.currentIndex()
        if src_idx == 1:
            src_filter = "BOOKS"
        elif src_idx == 2:
            src_filter = "GSTR2B"
        elif src_idx == 3:
            src_filter = "GSTR2A"
        elif src_idx == 4:
            src_filter = "GST"
        else:
            src_filter = "ALL"

        sec_text = self.cmb_section_filter.currentText()
        sec_filter = None if sec_text == "All Sections" else sec_text
        search_query = self.txt_search.text().strip()

        records = self.repo.get_all_imported_transactions(
            period_id=period_id,
            source_filter=src_filter,
            section_filter=sec_filter or "ALL",
            search_text=search_query
        )
        self.current_records = records

        # 3. Populate Register Table with batch updates enabled
        self.table_data.setUpdatesEnabled(False)
        try:
            display_limit = 2000
            display_records = records[:display_limit]
            self.table_data.setRowCount(len(display_records))

            for idx, r in enumerate(display_records):
                self.table_data.setItem(idx, 0, QTableWidgetItem(str(idx + 1)))
                self.table_data.setItem(idx, 1, QTableWidgetItem(r.get("source_badge", "-")))
                self.table_data.setItem(idx, 2, QTableWidgetItem(r.get("supplier_gstin") or "-"))
                self.table_data.setItem(idx, 3, QTableWidgetItem(r.get("supplier_name") or "-"))
                self.table_data.setItem(idx, 4, QTableWidgetItem(r.get("invoice_number") or "-"))
                self.table_data.setItem(idx, 5, QTableWidgetItem(r.get("invoice_date") or "-"))
                self.table_data.setItem(idx, 6, QTableWidgetItem(r.get("doc_type") or "-"))

                item_taxable = QTableWidgetItem(f"₹{r.get('taxable_value', 0.0):,.2f}")
                item_taxable.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 7, item_taxable)

                item_igst = QTableWidgetItem(f"₹{r.get('igst', 0.0):,.2f}")
                item_igst.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 8, item_igst)

                item_cgst = QTableWidgetItem(f"₹{r.get('cgst', 0.0):,.2f}")
                item_cgst.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 9, item_cgst)

                item_sgst = QTableWidgetItem(f"₹{r.get('sgst', 0.0):,.2f}")
                item_sgst.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 10, item_sgst)

                item_cess = QTableWidgetItem(f"₹{r.get('cess', 0.0):,.2f}")
                item_cess.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 11, item_cess)

                item_tax = QTableWidgetItem(f"₹{r.get('total_tax', 0.0):,.2f}")
                item_tax.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                item_tax.setForeground(Qt.darkBlue)
                self.table_data.setItem(idx, 12, item_tax)

                item_val = QTableWidgetItem(f"₹{r.get('invoice_value', 0.0):,.2f}")
                item_val.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table_data.setItem(idx, 13, item_val)

                self.table_data.setItem(idx, 14, QTableWidgetItem(r.get("itc_avail_str") or "Eligible"))
        finally:
            self.table_data.setUpdatesEnabled(True)

    def update_control_totals_table(self, summary: dict):
        self.table_control.setUpdatesEnabled(False)
        try:
            self.table_control.setRowCount(3)

            b_cnt = summary.get("books_count", 0)
            b_taxable = summary.get("books_taxable", 0.0)
            b_igst = summary.get("books_igst", 0.0)
            b_cgst = summary.get("books_cgst", 0.0)
            b_sgst = summary.get("books_sgst", 0.0)
            b_cess = summary.get("books_cess", 0.0)
            b_itc = summary.get("books_itc", 0.0)

            g_cnt = summary.get("gst_count", 0)
            g_taxable = summary.get("gst_taxable", 0.0)
            g_igst = summary.get("gst_igst", 0.0)
            g_cgst = summary.get("gst_cgst", 0.0)
            g_sgst = summary.get("gst_sgst", 0.0)
            g_cess = summary.get("gst_cess", 0.0)
            g_itc = summary.get("gst_itc", 0.0)

            diff_cnt = b_cnt - g_cnt
            diff_taxable = b_taxable - g_taxable
            diff_igst = b_igst - g_igst
            diff_cgst = b_cgst - g_cgst
            diff_sgst = b_sgst - g_sgst
            diff_cess = b_cess - g_cess
            diff_itc = b_itc - g_itc

            rows = [
                ("📚 Books Purchase Register", b_cnt, b_taxable, b_igst, b_cgst, b_sgst, b_cess, b_itc),
                ("🏛️ GST Portal (GSTR-2B / 2A)", g_cnt, g_taxable, g_igst, g_cgst, g_sgst, g_cess, g_itc),
                ("⚖ Variance / Net Difference", diff_cnt, diff_taxable, diff_igst, diff_cgst, diff_sgst, diff_cess, diff_itc)
            ]

            for r_idx, (src_name, cnt, taxable, igst, cgst, sgst, cess, itc) in enumerate(rows):
                self.table_control.setItem(r_idx, 0, QTableWidgetItem(src_name))
                
                cnt_item = QTableWidgetItem(f"{cnt:,}")
                cnt_item.setTextAlignment(Qt.AlignCenter)
                self.table_control.setItem(r_idx, 1, cnt_item)

                for c_idx, val in enumerate([taxable, igst, cgst, sgst, cess, itc], start=2):
                    val_item = QTableWidgetItem(f"₹{val:,.2f}")
                    val_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    if r_idx == 2 and abs(val) > 0.05:
                        val_item.setForeground(Qt.red)
                    elif r_idx == 2:
                        val_item.setForeground(Qt.darkGreen)
                    self.table_control.setItem(r_idx, c_idx, val_item)

        finally:
            self.table_control.setUpdatesEnabled(True)

        # Update Banner
        if b_cnt == 0 and g_cnt == 0:
            self.lbl_variance_banner.setText("ℹ No transactions imported for this period yet. Click 'Import More Data' to start.")
            self.lbl_variance_banner.setStyleSheet("color: #64748B; font-weight: bold;")
        elif abs(diff_itc) <= 1.0 and abs(diff_taxable) <= 1.0 and diff_cnt == 0:
            self.lbl_variance_banner.setText(f"✓ Control Totals Perfectly Balanced! Books ITC (₹{b_itc:,.2f}) == GST Portal ITC (₹{g_itc:,.2f}) across {b_cnt} invoices.")
            self.lbl_variance_banner.setStyleSheet("color: #15803D; font-weight: bold; background-color: #DCFCE7; padding: 6px; border-radius: 4px;")
        else:
            self.lbl_variance_banner.setText(
                f"⚠ Control Variance: Books ITC ₹{b_itc:,.2f} ({b_cnt} invs) vs GST Portal ITC ₹{g_itc:,.2f} ({g_cnt} invs) | "
                f"Net Difference: ₹{diff_itc:,.2f} (Invoices Diff: {diff_cnt:+d})"
            )
            self.lbl_variance_banner.setStyleSheet("color: #B91C1C; font-weight: bold; background-color: #FEE2E2; padding: 6px; border-radius: 4px;")

    def export_to_excel(self):
        if not self.current_records:
            QMessageBox.warning(self, "No Data", "No imported transactions available to export.")
            return

        file_path, _ = QFileDialog.getSaveFileName(self, "Save Imported Data Register", "Imported_Data_Register.xlsx", "Excel Files (*.xlsx)")
        if not file_path:
            return

        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Imported Data Register"

            headers = [
                "#", "Source", "Supplier GSTIN", "Supplier Name", "Invoice No",
                "Invoice Date", "Doc Type", "Taxable Value (₹)", "IGST (₹)", "CGST (₹)", "SGST (₹)",
                "Cess (₹)", "Total ITC / Tax (₹)", "Invoice Value (₹)", "ITC Status"
            ]
            ws.append(headers)

            # Header Style
            header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
            header_font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
            for col in range(1, len(headers) + 1):
                cell = ws.cell(row=1, column=col)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")

            for idx, r in enumerate(self.current_records, start=1):
                ws.append([
                    idx,
                    r.get("source_badge", ""),
                    r.get("supplier_gstin", ""),
                    r.get("supplier_name", ""),
                    r.get("invoice_number", ""),
                    r.get("invoice_date", ""),
                    r.get("doc_type", ""),
                    r.get("taxable_value", 0.0),
                    r.get("igst", 0.0),
                    r.get("cgst", 0.0),
                    r.get("sgst", 0.0),
                    r.get("cess", 0.0),
                    r.get("total_tax", 0.0),
                    r.get("invoice_value", 0.0),
                    r.get("itc_avail_str", "")
                ])

            # Autofit column widths
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = max(10, min(max_len + 3, 40))

            wb.save(file_path)
            QMessageBox.information(self, "Export Completed", f"Successfully exported {len(self.current_records)} records to:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to export Excel file: {str(e)}")
