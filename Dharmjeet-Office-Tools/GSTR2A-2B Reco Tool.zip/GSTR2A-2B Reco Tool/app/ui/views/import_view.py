import os
import json
import pandas as pd
from typing import Dict, List, Optional, Any, Callable
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog,
    QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QGroupBox, QFormLayout, QSpinBox, QDialog, QRadioButton, QButtonGroup
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont, QColor
from app.importers.excel_importer import ExcelImporter
from app.importers.json_importer import JSONImporter
from app.importers.column_mapper import ColumnMapper


class ImportWorkerThread(QThread):
    finished_sig = Signal(int, list, list)
    error_sig = Signal(str)

    def __init__(self, repo, period_id, file_path, data_type, column_map=None, sheet_name=None, header_row=None):
        super().__init__()
        self.repo = repo
        self.period_id = period_id
        self.file_path = file_path
        self.data_type = data_type
        self.column_map = column_map
        self.sheet_name = sheet_name
        self.header_row = header_row

    def run(self):
        try:
            file_hash = ExcelImporter.get_file_hash(self.file_path)
            file_name = os.path.basename(self.file_path)

            if self.data_type == "BOOKS":
                txs, errors, _ = ExcelImporter.import_purchase_register(
                    file_path=self.file_path,
                    sheet_name=self.sheet_name,
                    column_mapping=self.column_map,
                    header_row=self.header_row
                )
                file_id = self.repo.register_import_file(self.period_id, "BOOKS", file_name, file_hash, len(txs))
                self.repo.insert_books_transactions(self.period_id, file_id, txs)

            elif self.data_type == "GSTR2B_EXCEL":
                txs, errors = ExcelImporter.import_gstr2b_excel(self.file_path)
                file_id = self.repo.register_import_file(self.period_id, "GSTR2B", file_name, file_hash, len(txs))
                self.repo.insert_gst_transactions(self.period_id, file_id, "GSTR2B", txs)

            elif self.data_type == "GSTR2B_JSON":
                txs, errors, _ = JSONImporter.import_gstr2b_json(self.file_path)
                file_id = self.repo.register_import_file(self.period_id, "GSTR2B", file_name, file_hash, len(txs))
                self.repo.insert_gst_transactions(self.period_id, file_id, "GSTR2B", txs)

            elif self.data_type == "GSTR2A_EXCEL":
                txs, errors = ExcelImporter.import_gstr2a_excel(self.file_path)
                file_id = self.repo.register_import_file(self.period_id, "GSTR2A", file_name, file_hash, len(txs))
                self.repo.insert_gst_transactions(self.period_id, file_id, "GSTR2A", txs)

            elif self.data_type == "GSTR2A_JSON":
                txs, errors, _ = JSONImporter.import_gstr2a_json(self.file_path)
                file_id = self.repo.register_import_file(self.period_id, "GSTR2A", file_name, file_hash, len(txs))
                self.repo.insert_gst_transactions(self.period_id, file_id, "GSTR2A", txs)

            self.finished_sig.emit(len(txs), errors, [])
        except Exception as e:
            self.error_sig.emit(str(e))


class ResetDataDialog(QDialog):
    """Confirmation and options dialog for resetting imported data."""

    def __init__(self, summary: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.setWindowTitle("🗑️ Reset Imported Data")
        self.resize(500, 360)
        self.target_option = "ALL"

        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("Reset Imported Transactions")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #B91C1C;")
        layout.addWidget(title)

        desc = QLabel(
            "If data was erroneously imported or needs to be reloaded from scratch, "
            "you can reset the records for this period back to zero."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #475569;")
        layout.addWidget(desc)

        # Summary box
        grp_summary = QGroupBox("Current Period Data & Control Totals")
        sum_layout = QFormLayout(grp_summary)
        b_cnt = summary.get('books_count', 0)
        b_itc = summary.get('books_itc', 0.0)
        g_cnt = summary.get('gst_count', 0)
        g_itc = summary.get('gst_itc', 0.0)
        r_cnt = summary.get('reco_count', 0)

        sum_layout.addRow("📚 Books Purchase Register:", QLabel(f"<b>{b_cnt:,}</b> invoices | ITC: <b>₹{b_itc:,.2f}</b>"))
        sum_layout.addRow("🏛️ GST Portal (2B/2A) Records:", QLabel(f"<b>{g_cnt:,}</b> records | ITC: <b>₹{g_itc:,.2f}</b>"))
        sum_layout.addRow("📊 Reconciliations & Exceptions:", QLabel(f"<b>{r_cnt:,}</b> processed items"))
        layout.addWidget(grp_summary)

        # Options
        self.rb_all = QRadioButton("Reset ALL Imported Data (Books + GST + Reconciliations -> Set to 0)")
        self.rb_all.setChecked(True)
        self.rb_books = QRadioButton("Reset Books Purchase Register Only")
        self.rb_gst = QRadioButton("Reset GST Portal Data Only (GSTR-2B / 2A)")

        btn_grp = QButtonGroup(self)
        btn_grp.addButton(self.rb_all)
        btn_grp.addButton(self.rb_books)
        btn_grp.addButton(self.rb_gst)

        layout.addWidget(self.rb_all)
        layout.addWidget(self.rb_books)
        layout.addWidget(self.rb_gst)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(btn_cancel)

        btn_confirm = QPushButton("🗑️ Confirm Reset to 0")
        btn_confirm.setStyleSheet("background-color: #DC2626; color: white; font-weight: bold; padding: 6px 14px; border-radius: 4px;")
        btn_confirm.clicked.connect(self.on_confirm)
        btn_layout.addWidget(btn_confirm)

        layout.addLayout(btn_layout)

    def on_confirm(self):
        if self.rb_books.isChecked():
            self.target_option = "BOOKS"
        elif self.rb_gst.isChecked():
            self.target_option = "GST"
        else:
            self.target_option = "ALL"
        self.accept()


class ImportView(QWidget):
    """Interactive File Import Wizard for Purchase Registers & GST portal files."""

    FIELDS_DEF = [
        ("supplier_gstin", "Supplier GSTIN *", True),
        ("invoice_number", "Invoice / Note Number *", True),
        ("invoice_date", "Invoice / Note Date *", True),
        ("taxable_value", "Taxable Value *", True),
        ("invoice_value", "Invoice Value / Total Amount *", True),
        ("igst", "Integrated Tax (IGST)", False),
        ("cgst", "Central Tax (CGST)", False),
        ("sgst", "State / UT Tax (SGST)", False),
        ("cess", "GST Cess", False),
        ("supplier_name", "Supplier / Trade / Legal Name", False),
        ("doc_type", "Document Type (B2B/CDNR)", False),
        ("pos", "Place of Supply (POS)", False),
        ("rcm", "Reverse Charge (RCM)", False),
        ("itc_eligibility", "ITC Eligibility / Availability", False)
    ]

    def __init__(
        self,
        repository,
        get_current_period_cb,
        on_data_reset_cb: Optional[Callable] = None,
        on_navigate_register_cb: Optional[Callable] = None,
        parent=None
    ):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.on_data_reset_cb = on_data_reset_cb
        self.on_navigate_register_cb = on_navigate_register_cb
        self.selected_file = None
        self.current_mapping: Dict[str, str] = {}
        self.available_columns: List[str] = []
        self.current_df: Optional[pd.DataFrame] = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Header Title and Reset Actions Bar
        top_bar = QHBoxLayout()
        title = QLabel("📥 Import Accounting & GST Portal Data")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        top_bar.addWidget(title)
        top_bar.addStretch()

        btn_view_register = QPushButton("📋 View Imported Data & Control Totals")
        btn_view_register.setStyleSheet("""
            QPushButton {
                background-color: #F0FDF4;
                color: #16A34A;
                border: 1px solid #86EFAC;
                font-weight: 600;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #DCFCE7;
                border-color: #22C55E;
            }
        """)
        btn_view_register.clicked.connect(self.on_view_control_totals_clicked)
        top_bar.addWidget(btn_view_register)

        btn_reset_period = QPushButton("🗑️ Reset Imported Data (Set to 0)")
        btn_reset_period.setStyleSheet("""
            QPushButton {
                background-color: #FEF2F2;
                color: #DC2626;
                border: 1px solid #FCA5A5;
                font-weight: 600;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #FEE2E2;
                border-color: #EF4444;
            }
        """)
        btn_reset_period.clicked.connect(self.prompt_reset_data)
        top_bar.addWidget(btn_reset_period)

        layout.addLayout(top_bar)

        # Step 1: File Selection
        grp_file = QGroupBox("Step 1: Select File & Data Source")
        grp_layout = QFormLayout(grp_file)

        self.cmb_source = QComboBox()
        self.cmb_source.addItems([
            "Books Purchase Register (Excel / CSV)",
            "GSTR-2B File (Official GST Portal Excel / Multi-Section)",
            "GSTR-2B File (Official GST Portal JSON)",
            "GSTR-2A File (Official GST Portal Excel / Multi-Section)",
            "GSTR-2A File (Official GST Portal JSON)"
        ])
        self.cmb_source.currentIndexChanged.connect(self.on_source_type_changed)
        grp_layout.addRow("Data Type:", self.cmb_source)

        file_pick_layout = QHBoxLayout()
        self.lbl_file_path = QLabel("No file selected")
        self.lbl_file_path.setStyleSheet("color: #64748B; font-style: italic;")
        btn_browse = QPushButton("Browse File...")
        btn_browse.clicked.connect(self.browse_file)
        file_pick_layout.addWidget(btn_browse)
        file_pick_layout.addWidget(self.lbl_file_path)
        file_pick_layout.addStretch()

        btn_clear_file = QPushButton("🔄 Clear Form")
        btn_clear_file.clicked.connect(self.clear_form)
        file_pick_layout.addWidget(btn_clear_file)

        grp_layout.addRow("Select File:", file_pick_layout)
        layout.addWidget(grp_file)

        # Step 2: Sheet & Header Controls (Visible for Excel)
        self.grp_sheet_controls = QGroupBox("Workbook & Header Options")
        ctrl_layout = QHBoxLayout(self.grp_sheet_controls)

        ctrl_layout.addWidget(QLabel("Sheet:"))
        self.cmb_sheet = QComboBox()
        self.cmb_sheet.currentIndexChanged.connect(self.on_sheet_changed)
        ctrl_layout.addWidget(self.cmb_sheet)

        ctrl_layout.addWidget(QLabel("Header Row:"))
        self.spn_header_row = QSpinBox()
        self.spn_header_row.setRange(1, 30)
        self.spn_header_row.setValue(1)
        self.spn_header_row.valueChanged.connect(self.on_header_row_changed)
        ctrl_layout.addWidget(self.spn_header_row)

        btn_auto_header = QPushButton("⚡ Auto-Detect Header")
        btn_auto_header.clicked.connect(self.auto_detect_header_row)
        ctrl_layout.addWidget(btn_auto_header)

        ctrl_layout.addWidget(QLabel("Template Preset:"))
        self.cmb_template = QComboBox()
        self.cmb_template.addItem("⚡ Auto-Detect Columns")
        for t_name in ColumnMapper.get_standard_templates().keys():
            self.cmb_template.addItem(t_name)
        self.cmb_template.currentIndexChanged.connect(self.apply_template_preset)
        ctrl_layout.addWidget(self.cmb_template)

        ctrl_layout.addStretch()
        layout.addWidget(self.grp_sheet_controls)

        # Step 3: Column Mapping & JSON Preview
        self.grp_map = QGroupBox("Step 2: Interactive Column Mapping & Data Verification")
        map_layout = QVBoxLayout(self.grp_map)

        self.table_preview = QTableWidget()
        self.table_preview.setColumnCount(4)
        self.table_preview.setHorizontalHeaderLabels([
            "Normalized Field", "Source Column in File", "Sample Value (Row 1)", "Mapping Status"
        ])
        self.table_preview.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_preview.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table_preview.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table_preview.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        map_layout.addWidget(self.table_preview)

        # Summary info label for JSON or multi-sheet files
        self.lbl_file_summary = QLabel("")
        self.lbl_file_summary.setStyleSheet("font-weight: 500; color: #0284C7; padding: 4px;")
        map_layout.addWidget(self.lbl_file_summary)

        layout.addWidget(self.grp_map)

        # Step 4: Import Action Bar
        act_layout = QHBoxLayout()
        self.lbl_import_status = QLabel("")
        act_layout.addWidget(self.lbl_import_status)
        act_layout.addStretch()

        self.btn_import = QPushButton("📥 Import Transactions")
        self.btn_import.setProperty("class", "PrimaryBtn")
        self.btn_import.setEnabled(False)
        self.btn_import.clicked.connect(self.start_import)
        act_layout.addWidget(self.btn_import)

        layout.addLayout(act_layout)

    def on_source_type_changed(self):
        if self.selected_file:
            self.preview_file(self.selected_file)

    def browse_file(self):
        file_filter = "All Supported Files (*.xlsx *.xls *.csv *.json);;Excel Files (*.xlsx *.xls);;CSV Files (*.csv);;JSON Files (*.json)"
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Accounting/GST File", "", file_filter)
        if not file_path:
            return

        self.selected_file = file_path
        self.lbl_file_path.setText(os.path.basename(file_path))
        self.btn_import.setEnabled(True)

        f_lower = file_path.lower()
        # Auto-switch data type combobox based on filename & extension
        if f_lower.endswith('.json'):
            if "2a" in f_lower:
                self.cmb_source.setCurrentIndex(4)  # GSTR-2A JSON
            else:
                self.cmb_source.setCurrentIndex(2)  # GSTR-2B JSON
        elif "2a" in f_lower:
            self.cmb_source.setCurrentIndex(3)  # GSTR-2A Excel
        elif "2b" in f_lower or "gstr" in f_lower:
            self.cmb_source.setCurrentIndex(1)  # GSTR-2B Excel

        self.preview_file(file_path)

    def clear_form(self):
        """Resets the UI form back to initial unselected state."""
        self.selected_file = None
        self.lbl_file_path.setText("No file selected")
        self.btn_import.setEnabled(False)
        self.table_preview.setRowCount(0)
        self.current_mapping.clear()
        self.available_columns.clear()
        self.current_df = None
        self.lbl_file_summary.setText("")
        self.lbl_import_status.setText("")
        self.cmb_sheet.blockSignals(True)
        self.cmb_sheet.clear()
    def on_view_control_totals_clicked(self):
        """Navigates to the Imported Data Register & Financial Control Totals view, or shows modal summary."""
        if self.on_navigate_register_cb:
            self.on_navigate_register_cb()
        else:
            period_id = self.get_period_cb()
            if not period_id:
                QMessageBox.warning(self, "Warning", "Please select a Client, GSTIN, and Period first from the top bar.")
                return
            summary = self.repo.get_period_data_summary(period_id)
            b_cnt = summary.get('books_count', 0)
            b_itc = summary.get('books_itc', 0.0)
            g_cnt = summary.get('gst_count', 0)
            g_itc = summary.get('gst_itc', 0.0)
            diff_itc = abs(b_itc - g_itc)
            msg = (
                f"Financial Control Totals for Period:\n\n"
                f"• Books Purchase Register: {b_cnt:,} invoices | ITC: ₹{b_itc:,.2f}\n"
                f"• GST Portal Records: {g_cnt:,} records | ITC: ₹{g_itc:,.2f}\n"
                f"• Variance / Difference: ₹{diff_itc:,.2f}\n"
                f"• Processed Reconciliations: {summary.get('reco_count', 0):,} items"
            )
            QMessageBox.information(self, "📋 Financial Control Totals", msg)

    def prompt_reset_data(self):
        """Prompts the user with summary of imported data and resets to 0 upon confirmation."""
        period_id = self.get_period_cb()
        if not period_id:
            QMessageBox.warning(self, "Warning", "Please select a Client, GSTIN, and Period first from the top bar.")
            return

        summary = self.repo.get_period_data_summary(period_id)
        if summary.get("total_imported", 0) == 0 and summary.get("reco_count", 0) == 0:
            QMessageBox.information(
                self,
                "Period Already Empty",
                "The selected period currently has 0 imported transactions and 0 reconciliation results."
            )
            return

        dlg = ResetDataDialog(summary, self)
        if dlg.exec() == QDialog.Accepted:
            target = dlg.target_option
            counts = self.repo.reset_period_data(period_id, target=target, user="Admin")

            del_msg = (
                f"Data successfully reset to 0!\n\n"
                f"• Books Records Removed: {counts.get('books_deleted', 0):,}\n"
                f"• GST Records Removed: {counts.get('gst_deleted', 0):,}\n"
                f"• Reconciliations Cleared: {counts.get('reco_deleted', 0):,}\n"
                f"• Import File Registrations Removed: {counts.get('files_deleted', 0):,}"
            )
            QMessageBox.information(self, "Reset Completed", del_msg)

            if self.on_data_reset_cb:
                self.on_data_reset_cb()

    def preview_file(self, file_path: str):
        try:
            if file_path.lower().endswith('.json'):
                self.grp_sheet_controls.setVisible(False)
                self.preview_json(file_path)
                return

            self.grp_sheet_controls.setVisible(True)
            # Populate sheets
            sheet_names = ExcelImporter.get_sheet_names(file_path)
            self.cmb_sheet.blockSignals(True)
            self.cmb_sheet.clear()
            self.cmb_sheet.addItems(sheet_names)

            data_type = "GSTR2B_EXCEL" if self.cmb_source.currentIndex() in [1, 3] else "BOOKS"
            best_sheet = ExcelImporter.get_best_sheet_name(file_path, data_type)
            if best_sheet in sheet_names:
                self.cmb_sheet.setCurrentText(best_sheet)
            self.cmb_sheet.blockSignals(False)

            self.load_sheet_data()
        except Exception as e:
            QMessageBox.warning(self, "Preview Error", f"Could not preview file: {str(e)}")

    def on_sheet_changed(self):
        self.load_sheet_data()

    def on_header_row_changed(self):
        self.load_sheet_data(use_spinbox_header=True)

    def auto_detect_header_row(self):
        if not self.selected_file:
            return
        sheet = self.cmb_sheet.currentText()
        detected_row = ExcelImporter.detect_header_row(self.selected_file, sheet)
        self.spn_header_row.blockSignals(True)
        self.spn_header_row.setValue(detected_row + 1)  # 1-indexed for display
        self.spn_header_row.blockSignals(False)
        self.load_sheet_data(use_spinbox_header=True)

    def load_sheet_data(self, use_spinbox_header: bool = False):
        if not self.selected_file:
            return

        sheet = self.cmb_sheet.currentText()
        if use_spinbox_header:
            header_idx = max(0, self.spn_header_row.value() - 1)
        else:
            header_idx = ExcelImporter.detect_header_row(self.selected_file, sheet)
            self.spn_header_row.blockSignals(True)
            self.spn_header_row.setValue(header_idx + 1)
            self.spn_header_row.blockSignals(False)

        df, _, _ = ExcelImporter.read_dataframe(
            self.selected_file,
            sheet_name=sheet,
            header_row=header_idx,
            nrows=20
        )
        self.current_df = df
        self.available_columns = [str(c) for c in df.columns if not str(c).startswith('Unnamed:')]

        # Auto-detect mapping
        self.current_mapping = ColumnMapper.auto_detect(list(df.columns))

        # Check if GST multi-section workbook
        curr_src_idx = self.cmb_source.currentIndex()
        if curr_src_idx in [1, 3]:  # GSTR-2B or GSTR-2A Excel
            detected_secs = ExcelImporter.detect_gst_sections(self.selected_file)
            gst_label = "GSTR-2A" if curr_src_idx == 3 else "GSTR-2B"
            if detected_secs:
                sec_names = [f"{s['section']} ('{s['sheet_name']}')" for s in detected_secs]
                self.lbl_file_summary.setText(
                    f"✓ Multi-Section {gst_label} Detected ({len(detected_secs)} sections: {', '.join(sec_names)}). "
                    f"⚡ 1-Click Import will import all sections automatically!"
                )
            else:
                self.lbl_file_summary.setText(f"ℹ Loaded sheet '{sheet}' with {len(df.columns)} columns detected.")
        else:
            self.lbl_file_summary.setText(f"ℹ Loaded sheet '{sheet}' (Header at Row {header_idx + 1}) with {len(df.columns)} columns detected.")

        self.populate_mapping_table()

    def populate_mapping_table(self):
        self.table_preview.setUpdatesEnabled(False)
        try:
            self.table_preview.setRowCount(len(self.FIELDS_DEF))

            bold_font = QFont()
            bold_font.setBold(True)

            for idx, (field_key, field_label, is_required) in enumerate(self.FIELDS_DEF):
                # Column 0: Target Normalized Field
                item_target = QTableWidgetItem(field_label)
                item_target.setFlags(Qt.ItemIsEnabled)
                if is_required:
                    item_target.setFont(bold_font)
                    item_target.setForeground(QColor("#0F172A"))
                else:
                    item_target.setForeground(QColor("#475569"))
                self.table_preview.setItem(idx, 0, item_target)

                # Column 1: Interactive Combobox
                combo = QComboBox()
                combo.addItem("— (Skip / Not Mapped) —", "")
                for col in self.available_columns:
                    combo.addItem(col, col)

                # Preselect detected column
                detected_col = self.current_mapping.get(field_key)
                if detected_col and detected_col in self.available_columns:
                    combo.setCurrentText(detected_col)
                else:
                    combo.setCurrentIndex(0)

                combo.currentIndexChanged.connect(lambda _, row=idx, f_key=field_key, cmb=combo: self.on_column_dropdown_changed(row, f_key, cmb))
                self.table_preview.setCellWidget(idx, 1, combo)

                # Column 2: Sample Value
                sample_val = self.get_sample_value(combo.currentData())
                item_sample = QTableWidgetItem(sample_val)
                item_sample.setFlags(Qt.ItemIsEnabled)
                item_sample.setForeground(QColor("#334155"))
                self.table_preview.setItem(idx, 2, item_sample)

                # Column 3: Status Badge
                status_text = self.get_status_text(is_required, combo.currentData())
                item_status = QTableWidgetItem(status_text)
                item_status.setFlags(Qt.ItemIsEnabled)
                if combo.currentData():
                    item_status.setForeground(QColor("#16A34A"))
                elif is_required:
                    item_status.setForeground(QColor("#DC2626"))
                else:
                    item_status.setForeground(QColor("#64748B"))
                self.table_preview.setItem(idx, 3, item_status)
        finally:
            self.table_preview.setUpdatesEnabled(True)

    def on_column_dropdown_changed(self, row_idx: int, field_key: str, combo: QComboBox):
        selected_col = combo.currentData()
        if selected_col:
            self.current_mapping[field_key] = selected_col
        else:
            self.current_mapping.pop(field_key, None)

        # Update Sample Value
        sample_val = self.get_sample_value(selected_col)
        item_sample = QTableWidgetItem(sample_val)
        item_sample.setFlags(Qt.ItemIsEnabled)
        item_sample.setForeground(QColor("#334155"))
        self.table_preview.setItem(row_idx, 2, item_sample)

        # Update Status
        _, _, is_required = self.FIELDS_DEF[row_idx]
        status_text = self.get_status_text(is_required, selected_col)
        item_status = QTableWidgetItem(status_text)
        item_status.setFlags(Qt.ItemIsEnabled)
        if selected_col:
            item_status.setForeground(QColor("#16A34A"))
        elif is_required:
            item_status.setForeground(QColor("#DC2626"))
        else:
            item_status.setForeground(QColor("#64748B"))
        self.table_preview.setItem(row_idx, 3, item_status)

    def get_sample_value(self, col_name: Optional[str]) -> str:
        if not col_name or self.current_df is None or col_name not in self.current_df.columns:
            return "—"
        series = self.current_df[col_name].dropna()
        if len(series) > 0:
            val = str(series.iloc[0]).strip()
            return val if len(val) <= 40 else val[:37] + "..."
        return "—"

    def get_status_text(self, is_required: bool, col_name: Optional[str]) -> str:
        if col_name:
            return "✓ Mapped"
        elif is_required:
            return "⚠ Required - Missing"
        else:
            return "○ Optional"

    def apply_template_preset(self):
        preset_name = self.cmb_template.currentText()
        if preset_name == "⚡ Auto-Detect Columns":
            if self.current_df is not None:
                self.current_mapping = ColumnMapper.auto_detect(list(self.current_df.columns))
                self.populate_mapping_table()
            return

        templates = ColumnMapper.get_standard_templates()
        template = templates.get(preset_name, {})
        for field_key, src_col in template.items():
            if src_col in self.available_columns:
                self.current_mapping[field_key] = src_col
            else:
                # Try finding closest matching column
                for col in self.available_columns:
                    if ColumnMapper.clean_header_text(src_col) == ColumnMapper.clean_header_text(col):
                        self.current_mapping[field_key] = col
                        break

        self.populate_mapping_table()

    def preview_json(self, file_path: str):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            meta = JSONImporter.extract_metadata(data)
            txs, errors, meta_full = JSONImporter.import_gstr2b_json(file_path)

            gstin = meta.get("gstin") or meta_full.get("gstin") or "N/A"
            fp = meta.get("fp") or meta_full.get("fp") or "N/A"
            gen_date = meta.get("gen_date") or meta_full.get("gen_date") or "N/A"
            total_records = len(txs)
            total_taxable = sum(t.taxable_value for t in txs)
            total_tax = sum(t.total_tax for t in txs)

            self.lbl_file_summary.setText(
                f"✓ Official GST Portal JSON Verified: GSTIN={gstin} | Period={fp} | Gen Date={gen_date} | "
                f"Records={total_records} | Taxable=₹{total_taxable:,.2f} | Tax=₹{total_tax:,.2f}"
            )

            # Populate preview table with parsed JSON summary
            preview_items = [
                ("GSTIN of Supplier", "Supplier CTIN", txs[0].supplier_gstin if txs else "—", "✓ Auto-parsed"),
                ("Invoice Number", "INUM / NTNUM", txs[0].invoice_number if txs else "—", "✓ Auto-parsed"),
                ("Invoice Date", "IDT / NTDT", txs[0].invoice_date if txs else "—", "✓ Auto-parsed"),
                ("Taxable Value", "ITM_DET.TXVAL", f"₹{txs[0].taxable_value:,.2f}" if txs else "—", "✓ Auto-parsed"),
                ("Invoice Value", "VAL", f"₹{txs[0].invoice_value:,.2f}" if txs else "—", "✓ Auto-parsed"),
                ("Integrated Tax (IGST)", "ITM_DET.IAMT", f"₹{txs[0].igst:,.2f}" if txs else "—", "✓ Auto-parsed"),
                ("Central Tax (CGST)", "ITM_DET.CAMT", f"₹{txs[0].cgst:,.2f}" if txs else "—", "✓ Auto-parsed"),
                ("State Tax (SGST)", "ITM_DET.SAMT", f"₹{txs[0].sgst:,.2f}" if txs else "—", "✓ Auto-parsed"),
                ("Document Type", "INV / CDNR / B2BA", txs[0].doc_type if txs else "—", "✓ Auto-parsed")
            ]

            self.table_preview.setRowCount(len(preview_items))
            for idx, (target, src, sample, status) in enumerate(preview_items):
                self.table_preview.setItem(idx, 0, QTableWidgetItem(target))
                self.table_preview.setItem(idx, 1, QTableWidgetItem(src))
                self.table_preview.setItem(idx, 2, QTableWidgetItem(sample))
                self.table_preview.setItem(idx, 3, QTableWidgetItem(status))

        except Exception as e:
            QMessageBox.warning(self, "JSON Preview Error", f"Could not read GSTR JSON file: {str(e)}")

    def start_import(self):
        period_id = self.get_period_cb()
        if not period_id:
            QMessageBox.warning(self, "Warning", "Please select a Client, GSTIN, and Period first from the top bar.")
            return

        if not self.selected_file:
            return

        idx = self.cmb_source.currentIndex()
        if idx == 0:
            data_type = "BOOKS"
        elif idx == 1:
            data_type = "GSTR2B_EXCEL"
        elif idx == 2:
            data_type = "GSTR2B_JSON"
        elif idx == 3:
            data_type = "GSTR2A_EXCEL"
        elif idx == 4:
            data_type = "GSTR2A_JSON"
        else:
            data_type = "BOOKS"

        # Validate required mappings for Books
        if data_type == "BOOKS":
            missing_req = []
            for field_key, field_label, is_required in self.FIELDS_DEF:
                if is_required and field_key not in self.current_mapping:
                    # Invoice value can be auto-calculated if taxable + tax is present
                    if field_key == "invoice_value" and "taxable_value" in self.current_mapping:
                        continue
                    missing_req.append(field_label)

            if missing_req:
                res = QMessageBox.question(
                    self,
                    "Missing Required Fields",
                    f"The following required fields are not mapped:\n• " + "\n• ".join(missing_req) +
                    "\n\nDo you still want to proceed with import?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No
                )
                if res != QMessageBox.Yes:
                    return

        self.btn_import.setEnabled(False)
        self.btn_import.setText("⏳ Importing Data...")

        sheet_name = self.cmb_sheet.currentText() if self.cmb_sheet.count() > 0 else None
        header_row = max(0, self.spn_header_row.value() - 1)

        self.worker = ImportWorkerThread(
            repo=self.repo,
            period_id=period_id,
            file_path=self.selected_file,
            data_type=data_type,
            column_map=self.current_mapping,
            sheet_name=sheet_name,
            header_row=header_row
        )
        self.worker.finished_sig.connect(self.on_import_finished)
        self.worker.error_sig.connect(self.on_import_error)
        self.worker.start()

    def on_import_finished(self, count, errors, warnings):
        self.btn_import.setEnabled(True)
        self.btn_import.setText("📥 Import Transactions")
        msg = f"Successfully imported {count} transactions into database!"
        if errors:
            msg += f"\n\n{len(errors)} records had minor validation warnings."
        QMessageBox.information(self, "Import Completed", msg)

        if self.on_data_reset_cb:
            self.on_data_reset_cb()

    def on_import_error(self, err):
        self.btn_import.setEnabled(True)
        self.btn_import.setText("📥 Import Transactions")
        QMessageBox.critical(self, "Import Failed", f"Failed to import file: {err}")
