from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QDialog, QFormLayout, QLineEdit, QComboBox, QMessageBox
)
from app.database.models import ClientModel, GSTINModel

STATE_CODES = {
    "01": "Jammu & Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh",
    "05": "Uttarakhand", "06": "Haryana", "07": "Delhi", "08": "Rajasthan",
    "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh",
    "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura",
    "17": "Meghalaya", "18": "Assam", "19": "West Bengal", "20": "Jharkhand",
    "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
    "26": "Dadra & Nagar Haveli", "27": "Maharashtra", "28": "Andhra Pradesh",
    "29": "Karnataka", "30": "Goa", "31": "Lakshadweep", "32": "Kerala",
    "33": "Tamil Nadu", "34": "Puducherry", "35": "Andaman & Nicobar", "36": "Telangana",
    "37": "Andhra Pradesh (New)"
}


class ClientsView(QWidget):
    """Client & GSTIN Management View."""

    def __init__(self, repository, on_clients_changed_cb=None, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.on_changed_cb = on_clients_changed_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        # Header Action Bar
        hdr_layout = QHBoxLayout()
        lbl_title = QLabel("👥 Client & GSTIN Management Hierarchy")
        lbl_title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        hdr_layout.addWidget(lbl_title)
        hdr_layout.addStretch()

        btn_add_client = QPushButton("+ Add Client")
        btn_add_client.setProperty("class", "PrimaryBtn")
        btn_add_client.clicked.connect(self.open_add_client_dialog)
        hdr_layout.addWidget(btn_add_client)

        btn_add_gstin = QPushButton("+ Add GSTIN")
        btn_add_gstin.setProperty("class", "SuccessBtn")
        btn_add_gstin.clicked.connect(self.open_add_gstin_dialog)
        hdr_layout.addWidget(btn_add_gstin)

        btn_del_client = QPushButton("🗑 Delete Client")
        btn_del_client.setProperty("class", "DangerBtn")
        btn_del_client.clicked.connect(self.open_delete_client_dialog)
        hdr_layout.addWidget(btn_del_client)

        layout.addLayout(hdr_layout)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Client Name", "Trade Name", "PAN", "GSTIN", "State", "Books Software", "Actions"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.refresh_data()

    def refresh_data(self):
        clients = self.repo.get_all_clients()
        self.table.setRowCount(0)

        row_idx = 0
        for c in clients:
            gstins = self.repo.get_gstins_for_client(c["id"])
            if not gstins:
                self.table.insertRow(row_idx)
                self.table.setItem(row_idx, 0, QTableWidgetItem(c["name"]))
                self.table.setItem(row_idx, 1, QTableWidgetItem(c.get("trade_name") or ""))
                self.table.setItem(row_idx, 2, QTableWidgetItem(c.get("pan") or ""))
                self.table.setItem(row_idx, 3, QTableWidgetItem("No GSTIN"))
                self.table.setItem(row_idx, 4, QTableWidgetItem("-"))
                self.table.setItem(row_idx, 5, QTableWidgetItem("-"))
                
                # Action buttons widget
                btn_widget = QWidget()
                btn_layout = QHBoxLayout(btn_widget)
                btn_layout.setContentsMargins(4, 2, 4, 2)
                btn_del = QPushButton("Delete")
                btn_del.setProperty("class", "DangerBtn")
                btn_del.setStyleSheet("padding: 3px 8px; font-size: 11px;")
                btn_del.clicked.connect(lambda _, cid=c["id"], cname=c["name"]: self.confirm_delete_client(cid, cname))
                btn_layout.addWidget(btn_del)
                self.table.setCellWidget(row_idx, 6, btn_widget)

                row_idx += 1
            else:
                for g in gstins:
                    self.table.insertRow(row_idx)
                    self.table.setItem(row_idx, 0, QTableWidgetItem(c["name"]))
                    self.table.setItem(row_idx, 1, QTableWidgetItem(c.get("trade_name") or ""))
                    self.table.setItem(row_idx, 2, QTableWidgetItem(c.get("pan") or ""))
                    self.table.setItem(row_idx, 3, QTableWidgetItem(g["gstin"]))
                    self.table.setItem(row_idx, 4, QTableWidgetItem(g.get("state") or ""))
                    self.table.setItem(row_idx, 5, QTableWidgetItem(g.get("books_software") or "Tally"))
                    
                    # Action buttons widget
                    btn_widget = QWidget()
                    btn_layout = QHBoxLayout(btn_widget)
                    btn_layout.setContentsMargins(4, 2, 4, 2)

                    btn_del_g = QPushButton("Delete GSTIN")
                    btn_del_g.setProperty("class", "DangerBtn")
                    btn_del_g.setStyleSheet("padding: 3px 6px; font-size: 10px; background-color: #EF4444;")
                    btn_del_g.clicked.connect(lambda _, gid=g["id"], gstr=g["gstin"]: self.confirm_delete_gstin(gid, gstr))
                    btn_layout.addWidget(btn_del_g)

                    btn_del_c = QPushButton("Delete Client")
                    btn_del_c.setProperty("class", "DangerBtn")
                    btn_del_c.setStyleSheet("padding: 3px 6px; font-size: 10px; background-color: #991B1B;")
                    btn_del_c.clicked.connect(lambda _, cid=c["id"], cname=c["name"]: self.confirm_delete_client(cid, cname))
                    btn_layout.addWidget(btn_del_c)

                    self.table.setCellWidget(row_idx, 6, btn_widget)
                    row_idx += 1

    def open_add_client_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Create New Client")
        dlg.setFixedSize(450, 420)
        layout = QFormLayout(dlg)
        layout.setSpacing(10)

        lbl_header = QLabel("Client Details")
        lbl_header.setStyleSheet("font-weight: bold; font-size: 14px; color: #1E293B;")
        layout.addRow(lbl_header)

        txt_name = QLineEdit()
        txt_trade = QLineEdit()
        txt_pan = QLineEdit()
        txt_person = QLineEdit()

        layout.addRow("Client Name*:", txt_name)
        layout.addRow("Trade Name:", txt_trade)
        layout.addRow("PAN Number:", txt_pan)
        layout.addRow("Contact Person:", txt_person)

        lbl_gstin_hdr = QLabel("Primary GSTIN Details (Optional)")
        lbl_gstin_hdr.setStyleSheet("font-weight: bold; font-size: 14px; color: #1E293B; margin-top: 10px;")
        layout.addRow(lbl_gstin_hdr)

        txt_gstin = QLineEdit()
        txt_gstin.setPlaceholderText("e.g. 07AAAAA1234A1Z5")
        txt_state = QLineEdit()
        cmb_software = QComboBox()
        cmb_software.addItems(["Tally", "Busy", "Marg", "Excel Standard", "Custom ERP"])

        layout.addRow("GSTIN (15 Chars):", txt_gstin)
        layout.addRow("State:", txt_state)
        layout.addRow("Books Software:", cmb_software)

        # Auto-fill helpers
        def on_gstin_changed():
            g_str = txt_gstin.text().strip().upper()
            if len(g_str) >= 2:
                state_code = g_str[:2]
                if state_code in STATE_CODES and not txt_state.text().strip():
                    txt_state.setText(STATE_CODES[state_code])
            if len(g_str) >= 12 and not txt_pan.text().strip():
                txt_pan.setText(g_str[2:12])

        txt_gstin.textChanged.connect(on_gstin_changed)

        btn_save = QPushButton("Save Client")
        btn_save.setProperty("class", "PrimaryBtn")
        btn_save.setStyleSheet("margin-top: 15px; padding: 10px;")
        layout.addRow(btn_save)

        def save():
            client_name = txt_name.text().strip()
            if not client_name:
                QMessageBox.warning(dlg, "Error", "Client Name is required.")
                return

            gstin_str = txt_gstin.text().strip().upper()
            if gstin_str and len(gstin_str) != 15:
                QMessageBox.warning(dlg, "Error", "GSTIN must be exactly 15 characters long if provided.")
                return

            pan_str = txt_pan.text().strip().upper()
            if not pan_str and gstin_str:
                pan_str = gstin_str[2:12]

            state_str = txt_state.text().strip()
            if gstin_str and not state_str:
                state_str = STATE_CODES.get(gstin_str[:2], "")

            c = ClientModel(
                name=client_name,
                trade_name=txt_trade.text().strip(),
                pan=pan_str,
                contact_person=txt_person.text().strip()
            )
            try:
                client_id = self.repo.create_client(c)

                if gstin_str:
                    g = GSTINModel(
                        client_id=client_id,
                        gstin=gstin_str,
                        state=state_str,
                        books_software=cmb_software.currentText()
                    )
                    self.repo.add_gstin(g)

                dlg.accept()
                self.refresh_data()
                if self.on_changed_cb:
                    self.on_changed_cb()
            except Exception as e:
                QMessageBox.critical(dlg, "Error", f"Could not create client: {str(e)}")

        btn_save.clicked.connect(save)
        dlg.exec()

    def open_add_gstin_dialog(self):
        clients = self.repo.get_all_clients()
        if not clients:
            QMessageBox.warning(self, "Warning", "Please create a Client first.")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("Add GSTIN to Client")
        dlg.setFixedSize(400, 300)
        layout = QFormLayout(dlg)

        cmb_client = QComboBox()
        for c in clients:
            cmb_client.addItem(c["name"], c["id"])

        txt_gstin = QLineEdit()
        txt_state = QLineEdit()
        cmb_software = QComboBox()
        cmb_software.addItems(["Tally", "Busy", "Marg", "Excel Standard", "Custom ERP"])

        def on_gstin_changed():
            g_str = txt_gstin.text().strip().upper()
            if len(g_str) >= 2:
                state_code = g_str[:2]
                if state_code in STATE_CODES and not txt_state.text().strip():
                    txt_state.setText(STATE_CODES[state_code])

        txt_gstin.textChanged.connect(on_gstin_changed)

        layout.addRow("Select Client*:", cmb_client)
        layout.addRow("GSTIN (15 Chars)*:", txt_gstin)
        layout.addRow("State:", txt_state)
        layout.addRow("Books Software:", cmb_software)

        btn_save = QPushButton("Add GSTIN")
        btn_save.setProperty("class", "SuccessBtn")
        layout.addRow(btn_save)

        def save():
            gstin_str = txt_gstin.text().strip().upper()
            if len(gstin_str) != 15:
                QMessageBox.warning(dlg, "Error", "GSTIN must be exactly 15 characters long.")
                return
            g = GSTINModel(
                client_id=cmb_client.currentData(),
                gstin=gstin_str,
                state=txt_state.text().strip(),
                books_software=cmb_software.currentText()
            )
            try:
                self.repo.add_gstin(g)
                dlg.accept()
                self.refresh_data()
                if self.on_changed_cb:
                    self.on_changed_cb()
            except Exception as e:
                QMessageBox.critical(dlg, "Error", f"Could not add GSTIN: {str(e)}")

        btn_save.clicked.connect(save)
        dlg.exec()

    def open_delete_client_dialog(self):
        clients = self.repo.get_all_clients()
        if not clients:
            QMessageBox.warning(self, "Warning", "No clients available to delete.")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("Delete Client")
        dlg.setFixedSize(420, 240)
        layout = QFormLayout(dlg)

        lbl_info = QLabel("⚠️ Warning: Deleting a client will permanently delete all associated GSTINs, financial years, imported records, and reconciliation data.")
        lbl_info.setWordWrap(True)
        lbl_info.setStyleSheet("color: #DC2626; font-weight: bold; font-size: 11px; margin-bottom: 10px;")
        layout.addRow(lbl_info)

        cmb_client = QComboBox()
        for c in clients:
            cmb_client.addItem(c["name"], c["id"])

        # Pre-select currently highlighted client row if any
        curr_row = self.table.currentRow()
        if curr_row >= 0:
            item = self.table.item(curr_row, 0)
            if item:
                cname = item.text()
                idx = cmb_client.findText(cname)
                if idx >= 0:
                    cmb_client.setCurrentIndex(idx)

        layout.addRow("Select Client to Delete*:", cmb_client)

        btn_delete = QPushButton("🗑 Delete Selected Client")
        btn_delete.setProperty("class", "DangerBtn")
        btn_delete.setStyleSheet("margin-top: 15px; padding: 10px;")
        layout.addRow(btn_delete)

        def do_delete():
            cid = cmb_client.currentData()
            cname = cmb_client.currentText()
            dlg.accept()
            self.confirm_delete_client(cid, cname)

        btn_delete.clicked.connect(do_delete)
        dlg.exec()

    def confirm_delete_client(self, client_id: int, client_name: str):
        reply = QMessageBox.question(
            self,
            "Confirm Delete Client",
            f"Are you sure you want to permanently delete client '{client_name}'?\n\n"
            "This will delete ALL associated GSTINs, financial years, transactions, and reconciliation data.\n"
            "This action CANNOT be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            success = self.repo.delete_client(client_id)
            if success:
                QMessageBox.information(self, "Deleted", f"Client '{client_name}' deleted successfully.")
                self.refresh_data()
                if self.on_changed_cb:
                    self.on_changed_cb()
            else:
                QMessageBox.warning(self, "Error", f"Failed to delete client '{client_name}'.")

    def confirm_delete_gstin(self, gstin_id: int, gstin_str: str):
        reply = QMessageBox.question(
            self,
            "Confirm Delete GSTIN",
            f"Are you sure you want to permanently delete GSTIN '{gstin_str}'?\n\n"
            "This will delete ALL associated financial years, transactions, and reconciliation data for this GSTIN.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            success = self.repo.delete_gstin(gstin_id)
            if success:
                QMessageBox.information(self, "Deleted", f"GSTIN '{gstin_str}' deleted successfully.")
                self.refresh_data()
                if self.on_changed_cb:
                    self.on_changed_cb()
            else:
                QMessageBox.warning(self, "Error", f"Failed to delete GSTIN '{gstin_str}'.")
