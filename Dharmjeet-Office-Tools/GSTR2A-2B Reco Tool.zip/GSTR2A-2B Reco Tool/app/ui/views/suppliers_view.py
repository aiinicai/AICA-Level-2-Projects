from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox
)


class SuppliersView(QWidget):
    """Supplier Compliance & Reliability Score Dashboard."""

    def __init__(self, repository, get_current_gstin_cb, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_gstin_cb = get_current_gstin_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("🏭 Supplier Filing Compliance & Reliability Scorecard")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels([
            "Supplier GSTIN", "Supplier Name", "Reliability Score",
            "Books Invs", "Books ITC (₹)", "2A/2B Invs", "GSTR-2A/2B ITC (₹)",
            "Matched Invs", "Missing Invs", "ITC at Risk (₹)"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

    def refresh_data(self):
        gstin_id = self.get_gstin_cb()
        if not gstin_id:
            self.table.setRowCount(0)
            return

        suppliers = self.repo.get_suppliers_by_gstin(gstin_id)
        self.table.setRowCount(len(suppliers))

        for idx, s in enumerate(suppliers):
            self.table.setItem(idx, 0, QTableWidgetItem(s["supplier_gstin"]))
            self.table.setItem(idx, 1, QTableWidgetItem(s.get("supplier_name") or "-"))
            score_item = QTableWidgetItem(f"{s['reliability_score']}/100")
            score_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(idx, 2, score_item)

            self.table.setItem(idx, 3, QTableWidgetItem(str(s["books_count"])))
            
            item_b_itc = QTableWidgetItem(f"₹{s.get('total_books_itc', 0.0):,.2f}")
            item_b_itc.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(idx, 4, item_b_itc)

            self.table.setItem(idx, 5, QTableWidgetItem(str(s["gst_count"])))

            item_g_itc = QTableWidgetItem(f"₹{s.get('total_gst_itc', 0.0):,.2f}")
            item_g_itc.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(idx, 6, item_g_itc)

            self.table.setItem(idx, 7, QTableWidgetItem(str(s["matched_count"])))
            self.table.setItem(idx, 8, QTableWidgetItem(str(s["missing_count"])))

            item_risk = QTableWidgetItem(f"₹{s['itc_at_risk']:,.2f}")
            item_risk.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if s['itc_at_risk'] > 0:
                item_risk.setForeground(Qt.red)
            self.table.setItem(idx, 9, item_risk)
