from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QHeaderView, QGroupBox, QFrame, QGridLayout
)
from PySide6.QtCore import Qt
from app.reconciliation.itc_engine import ITCEngine


class ITCControlView(QWidget):
    """ITC Control Centre & Risk Dashboard.
    Shows imported GSTR-2A/2B ITC even before reconciliation is run.
    """

    def __init__(self, repository, get_current_period_cb, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("💰 ITC Control Centre & Component Breakdown")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        # --- Pre-Reconciliation: Imported Data ITC Summary ---
        grp_imported = QGroupBox("📥 Imported Data – ITC Summary (Books vs GSTR-2A / GSTR-2B)")
        grp_imported.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                margin-top: 6px;
                padding-top: 10px;
                background-color: #F0F9FF;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 4px;
                color: #0369A1;
            }
        """)
        imported_layout = QVBoxLayout(grp_imported)

        # KPI summary row
        self.kpi_frame = QFrame()
        kpi_layout = QGridLayout(self.kpi_frame)
        kpi_layout.setSpacing(12)

        self.kpi_books_itc  = self._make_kpi("Books ITC (₹)", "₹0.00", "#2563EB")
        self.kpi_2b_itc     = self._make_kpi("GSTR-2B ITC (₹)", "₹0.00", "#059669")
        self.kpi_2a_itc     = self._make_kpi("GSTR-2A ITC (₹)", "₹0.00", "#7C3AED")
        self.kpi_variance   = self._make_kpi("Books vs 2B Variance (₹)", "₹0.00", "#DC2626")
        self.kpi_books_cnt  = self._make_kpi("Books Invoices", "0", "#0F172A")
        self.kpi_2b_cnt     = self._make_kpi("GSTR-2B Invoices", "0", "#0F172A")

        kpi_layout.addWidget(self.kpi_books_itc,  0, 0)
        kpi_layout.addWidget(self.kpi_2b_itc,     0, 1)
        kpi_layout.addWidget(self.kpi_2a_itc,     0, 2)
        kpi_layout.addWidget(self.kpi_variance,   0, 3)
        kpi_layout.addWidget(self.kpi_books_cnt,  1, 0)
        kpi_layout.addWidget(self.kpi_2b_cnt,     1, 1)

        imported_layout.addWidget(self.kpi_frame)

        # Status banner
        self.lbl_import_status = QLabel("Select a Client and Period to view ITC summary.")
        self.lbl_import_status.setStyleSheet("font-size: 12px; font-weight: bold; color: #475569; padding: 4px;")
        imported_layout.addWidget(self.lbl_import_status)

        layout.addWidget(grp_imported)

        # --- Post-Reconciliation: Tax Component Comparison ---
        grp_comp = QGroupBox("📊 Post-Reconciliation – Tax Component Comparison (IGST / CGST / SGST / CESS)")
        grp_comp.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #CBD5E1;
                border-radius: 8px;
                margin-top: 6px;
                padding-top: 10px;
                background-color: #F8FAFC;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 4px;
                color: #1E293B;
            }
        """)
        comp_layout = QVBoxLayout(grp_comp)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            "Tax Head", "Books Register Claim (₹)", "GSTR-2B Filing (₹)", "Matched Claim (₹)", "ITC Variance / Risk (₹)"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        comp_layout.addWidget(self.table)

        self.lbl_reco_note = QLabel("ℹ Run Reconciliation to see matched vs mismatched tax component breakdown.")
        self.lbl_reco_note.setStyleSheet("color: #64748B; font-size: 12px; padding: 4px;")
        comp_layout.addWidget(self.lbl_reco_note)

        layout.addWidget(grp_comp)

    def _make_kpi(self, title: str, value: str, color: str) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(f"""
            QFrame {{
                background-color: #FFFFFF;
                border-radius: 8px;
                border-left: 4px solid {color};
                border-top: 1px solid #E2E8F0;
                border-right: 1px solid #E2E8F0;
                border-bottom: 1px solid #E2E8F0;
                padding: 8px;
            }}
        """)
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(8, 8, 8, 8)
        fl.setSpacing(4)
        lbl_title = QLabel(title)
        lbl_title.setStyleSheet("color: #64748B; font-size: 11px; font-weight: bold;")
        lbl_val = QLabel(value)
        lbl_val.setObjectName("kpi_value")
        lbl_val.setStyleSheet(f"color: {color}; font-size: 16px; font-weight: bold;")
        fl.addWidget(lbl_title)
        fl.addWidget(lbl_val)
        return frame

    def _set_kpi(self, frame: QFrame, value: str):
        lbl = frame.findChild(QLabel, "kpi_value")
        if lbl:
            lbl.setText(value)

    def refresh_data(self):
        period_id = self.get_period_cb()
        if not period_id:
            self._set_kpi(self.kpi_books_itc,  "₹0.00")
            self._set_kpi(self.kpi_2b_itc,     "₹0.00")
            self._set_kpi(self.kpi_2a_itc,     "₹0.00")
            self._set_kpi(self.kpi_variance,   "₹0.00")
            self._set_kpi(self.kpi_books_cnt,  "0")
            self._set_kpi(self.kpi_2b_cnt,     "0")
            self.lbl_import_status.setText("Please select a Client, GSTIN, and Period from the top bar.")
            self.lbl_import_status.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold; padding: 4px;")
            self.table.setRowCount(0)
            self.lbl_reco_note.setText("ℹ Run Reconciliation to see matched vs mismatched tax component breakdown.")
            return

        # --- Part 1: Imported data KPIs (always show even before reco) ---
        summary = self.repo.get_period_data_summary(period_id)
        b_itc   = summary.get("books_itc",    0.0)
        g_itc   = summary.get("gst_itc",      0.0)   # combined 2A+2B
        g2b_itc = summary.get("gstr2b_itc",   0.0)
        g2a_itc = summary.get("gstr2a_itc",   0.0)
        b_cnt   = summary.get("books_count",   0)
        g2b_cnt = summary.get("gstr2b_count",  0)
        variance = b_itc - g2b_itc

        self._set_kpi(self.kpi_books_itc,  f"₹{b_itc:,.2f}")
        self._set_kpi(self.kpi_2b_itc,     f"₹{g2b_itc:,.2f}")
        self._set_kpi(self.kpi_2a_itc,     f"₹{g2a_itc:,.2f}")
        self._set_kpi(self.kpi_variance,   f"₹{variance:,.2f}")
        self._set_kpi(self.kpi_books_cnt,  f"{b_cnt:,}")
        self._set_kpi(self.kpi_2b_cnt,     f"{g2b_cnt:,}")

        if b_cnt == 0 and g2b_cnt == 0:
            self.lbl_import_status.setText("ℹ No transactions imported for this period. Go to 'Import Data' to start.")
            self.lbl_import_status.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold; padding: 4px;")
        elif abs(variance) <= 1.0:
            self.lbl_import_status.setText(
                f"✓ Books ITC (₹{b_itc:,.2f}) matches GSTR-2B ITC (₹{g2b_itc:,.2f}) — Perfectly Balanced!"
            )
            self.lbl_import_status.setStyleSheet(
                "color: #15803D; font-size: 12px; font-weight: bold; background-color: #DCFCE7; padding: 6px; border-radius: 4px;"
            )
        else:
            self.lbl_import_status.setText(
                f"⚠ ITC Variance: Books ₹{b_itc:,.2f} vs GSTR-2B ₹{g2b_itc:,.2f} | "
                f"Net Difference: ₹{variance:,.2f} | Run Reconciliation for detailed analysis."
            )
            self.lbl_import_status.setStyleSheet(
                "color: #B91C1C; font-size: 12px; font-weight: bold; background-color: #FEE2E2; padding: 6px; border-radius: 4px;"
            )

        # --- Part 2: Post-reconciliation tax component table ---
        reco_results = self.repo.get_reconciliation_results(period_id)
        if not reco_results:
            # Show component breakdown from imported data (no reco yet)
            self.table.setRowCount(0)
            self.lbl_reco_note.setText(
                "ℹ Reconciliation not yet run for this period. "
                "Run Reconciliation to see matched vs mismatched breakdown per tax head."
            )
            return

        self.lbl_reco_note.setText("✓ Reconciliation results loaded. Breakdown by tax component:")
        reco_summary = ITCEngine.calculate_itc_control_statement(reco_results)

        heads = [
            ("Integrated Tax (IGST)", reco_summary["igst"]["books"], reco_summary["igst"]["gst"], reco_summary["igst"]["matched"]),
            ("Central Tax (CGST)",    reco_summary["cgst"]["books"], reco_summary["cgst"]["gst"], reco_summary["cgst"]["matched"]),
            ("State/UT Tax (SGST)",   reco_summary["sgst"]["books"], reco_summary["sgst"]["gst"], reco_summary["sgst"]["matched"]),
            ("GST Cess",              reco_summary["cess"]["books"], reco_summary["cess"]["gst"], reco_summary["cess"]["matched"]),
            ("TOTAL ITC",             reco_summary["total_books_itc"], reco_summary["total_2b_itc"], reco_summary["matched_itc"])
        ]

        self.table.setRowCount(len(heads))
        for idx, (head, b_val, g_val, m_val) in enumerate(heads):
            diff = abs(b_val - g_val)
            self.table.setItem(idx, 0, QTableWidgetItem(head))
            item_b = QTableWidgetItem(f"₹{b_val:,.2f}")
            item_b.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item_g = QTableWidgetItem(f"₹{g_val:,.2f}")
            item_g.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item_m = QTableWidgetItem(f"₹{m_val:,.2f}")
            item_m.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item_d = QTableWidgetItem(f"₹{diff:,.2f}")
            item_d.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if diff > 0.05:
                item_d.setForeground(Qt.red)
            else:
                item_d.setForeground(Qt.darkGreen)
            if idx == len(heads) - 1:  # TOTAL row bold
                for item in [item_b, item_g, item_m, item_d]:
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
            self.table.setItem(idx, 1, item_b)
            self.table.setItem(idx, 2, item_g)
            self.table.setItem(idx, 3, item_m)
            self.table.setItem(idx, 4, item_d)
