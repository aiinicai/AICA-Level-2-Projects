from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGroupBox, QFormLayout,
    QLineEdit, QSpinBox, QDoubleSpinBox, QMessageBox, QFileDialog
)
from app.backup.backup_manager import BackupManager


class SettingsView(QWidget):
    """Application Settings & Database Backup Center."""

    def __init__(self, repository, on_theme_toggle_cb=None, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.on_theme_toggle_cb = on_theme_toggle_cb
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("⚙ Settings, Tolerances & Database Backup")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        # Tolerances Group
        grp_tol = QGroupBox("Reconciliation Matching Tolerances")
        tol_layout = QFormLayout(grp_tol)

        self.spn_date_tol = QSpinBox()
        self.spn_date_tol.setRange(0, 30)
        self.spn_date_tol.setValue(3)

        self.spn_amt_rs = QDoubleSpinBox()
        self.spn_amt_rs.setRange(0.0, 1000.0)
        self.spn_amt_rs.setValue(1.0)

        self.spn_amt_pct = QDoubleSpinBox()
        self.spn_amt_pct.setRange(0.0, 10.0)
        self.spn_amt_pct.setValue(0.01)

        self.spn_fuzzy = QSpinBox()
        self.spn_fuzzy.setRange(50, 100)
        self.spn_fuzzy.setValue(90)

        tol_layout.addRow("Date Tolerance (± Days):", self.spn_date_tol)
        tol_layout.addRow("Amount Tolerance (± ₹):", self.spn_amt_rs)
        tol_layout.addRow("Amount Tolerance (± %):", self.spn_amt_pct)
        tol_layout.addRow("Fuzzy Similarity High Cutoff (%):", self.spn_fuzzy)

        btn_save_tol = QPushButton("Save Tolerances")
        btn_save_tol.setProperty("class", "PrimaryBtn")
        btn_save_tol.clicked.connect(self.save_tolerances)
        tol_layout.addRow(btn_save_tol)

        layout.addWidget(grp_tol)

        # Backup & Restore Group
        grp_bak = QGroupBox("Database Backup & Restore")
        bak_layout = QHBoxLayout(grp_bak)

        btn_backup = QPushButton("💾 Create Database Backup (.zip)")
        btn_backup.setProperty("class", "PrimaryBtn")
        btn_backup.clicked.connect(self.create_backup)
        bak_layout.addWidget(btn_backup)

        btn_restore = QPushButton("📂 Restore Database from Backup")
        btn_restore.setProperty("class", "DangerBtn")
        btn_restore.clicked.connect(self.restore_backup)
        bak_layout.addWidget(btn_restore)

        layout.addWidget(grp_bak)

        # Appearance Group
        grp_app = QGroupBox("Appearance & Theme")
        app_layout = QHBoxLayout(grp_app)

        btn_theme = QPushButton("🌓 Toggle Dark / Light Theme")
        btn_theme.clicked.connect(self.toggle_theme)
        app_layout.addWidget(btn_theme)

        layout.addWidget(grp_app)

        layout.addStretch()

        self.load_settings()

    def load_settings(self):
        settings = self.repo.get_settings()
        self.spn_date_tol.setValue(int(settings.get("date_tolerance_days", "3")))
        self.spn_amt_rs.setValue(float(settings.get("amount_tolerance_rs", "1.0")))
        self.spn_amt_pct.setValue(float(settings.get("amount_tolerance_pct", "0.01")))
        self.spn_fuzzy.setValue(int(settings.get("fuzzy_threshold_high", "90")))

    def save_tolerances(self):
        d = {
            "date_tolerance_days": str(self.spn_date_tol.value()),
            "amount_tolerance_rs": str(self.spn_amt_rs.value()),
            "amount_tolerance_pct": str(self.spn_amt_pct.value()),
            "fuzzy_threshold_high": str(self.spn_fuzzy.value())
        }
        self.repo.update_settings(d)
        QMessageBox.information(self, "Settings Saved", "Matching tolerances updated successfully.")

    def create_backup(self):
        try:
            backup_path = BackupManager.create_backup()
            QMessageBox.information(self, "Backup Created", f"Database backup saved successfully to:\n{backup_path}")
        except Exception as e:
            QMessageBox.critical(self, "Backup Error", f"Failed to create backup: {str(e)}")

    def restore_backup(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Backup ZIP Archive", "", "ZIP Archives (*.zip)")
        if not file_path:
            return

        reply = QMessageBox.question(self, "Confirm Restore", "Restoring will replace current database. Proceed?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try:
                ok = BackupManager.restore_backup(file_path)
                if ok:
                    QMessageBox.information(self, "Restore Completed", "Database restored successfully!")
                else:
                    QMessageBox.warning(self, "Warning", "Restore finished with warnings.")
            except Exception as e:
                QMessageBox.critical(self, "Restore Failed", f"Could not restore database: {str(e)}")

    def toggle_theme(self):
        if self.on_theme_toggle_cb:
            self.on_theme_toggle_cb()
