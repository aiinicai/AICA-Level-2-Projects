from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QGroupBox, QSplitter, QLineEdit
)
from PySide6.QtCore import Qt


class ManualMatchingView(QWidget):
    """Side-by-side Manual Invoice Matcher Screen."""

    def __init__(self, repository, get_current_period_cb, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.selected_books_id = None
        self.selected_gst_id = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("⚡ Side-by-Side Manual Invoice Matcher")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        # Action Bar
        act_box = QHBoxLayout()
        self.lbl_selected_info = QLabel("Select one Books invoice (Left) and one GSTR-2B invoice (Right)")
        self.lbl_selected_info.setStyleSheet("font-weight: bold; color: #2563EB;")
        act_box.addWidget(self.lbl_selected_info)
        act_box.addStretch()

        self.btn_confirm = QPushButton("✓ CONFIRM MANUAL MATCH")
        self.btn_confirm.setProperty("class", "SuccessBtn")
        self.btn_confirm.setEnabled(False)
        self.btn_confirm.clicked.connect(self.confirm_manual_match)
        act_box.addWidget(self.btn_confirm)

        layout.addLayout(act_box)

        splitter = QSplitter(Qt.Horizontal)

        # Left Panel: Unmatched Books Invoices
        grp_books = QGroupBox("Unmatched Books Purchase Register Invoices")
        layout_b = QVBoxLayout(grp_books)
        self.table_books = QTableWidget()
        self.table_books.setColumnCount(5)
        self.table_books.setHorizontalHeaderLabels(["ID", "GSTIN", "Inv No", "Date", "Amount (₹)"])
        self.table_books.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table_books.itemSelectionChanged.connect(self.on_books_selected)
        layout_b.addWidget(self.table_books)
        splitter.addWidget(grp_books)

        # Right Panel: Unmatched GSTR-2B Invoices
        grp_gst = QGroupBox("Unmatched GSTR-2B Portal Invoices")
        layout_g = QVBoxLayout(grp_gst)
        self.table_gst = QTableWidget()
        self.table_gst.setColumnCount(5)
        self.table_gst.setHorizontalHeaderLabels(["ID", "GSTIN", "Inv No", "Date", "Amount (₹)"])
        self.table_gst.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table_gst.itemSelectionChanged.connect(self.on_gst_selected)
        layout_g.addWidget(self.table_gst)
        splitter.addWidget(grp_gst)

        splitter.setSizes([450, 450])
        layout.addWidget(splitter)

    def refresh_data(self):
        period_id = self.get_period_cb()
        if not period_id:
            self.table_books.setRowCount(0)
            self.table_gst.setRowCount(0)
            return

        b_list = self.repo.get_books_transactions(period_id)
        g_list = self.repo.get_gst_transactions(period_id)

        self.table_books.setUpdatesEnabled(False)
        self.table_gst.setUpdatesEnabled(False)
        try:
            self.table_books.setRowCount(len(b_list))
            for idx, b in enumerate(b_list):
                self.table_books.setItem(idx, 0, QTableWidgetItem(str(b["id"])))
                self.table_books.setItem(idx, 1, QTableWidgetItem(b["supplier_gstin"]))
                self.table_books.setItem(idx, 2, QTableWidgetItem(b["invoice_number"]))
                self.table_books.setItem(idx, 3, QTableWidgetItem(b.get("invoice_date") or "-"))
                self.table_books.setItem(idx, 4, QTableWidgetItem(f"₹{b['invoice_value']:,.2f}"))

            self.table_gst.setRowCount(len(g_list))
            for idx, g in enumerate(g_list):
                self.table_gst.setItem(idx, 0, QTableWidgetItem(str(g["id"])))
                self.table_gst.setItem(idx, 1, QTableWidgetItem(g["supplier_gstin"]))
                self.table_gst.setItem(idx, 2, QTableWidgetItem(g["invoice_number"]))
                self.table_gst.setItem(idx, 3, QTableWidgetItem(g.get("invoice_date") or "-"))
                self.table_gst.setItem(idx, 4, QTableWidgetItem(f"₹{g['invoice_value']:,.2f}"))
        finally:
            self.table_books.setUpdatesEnabled(True)
            self.table_gst.setUpdatesEnabled(True)

    def on_books_selected(self):
        rows = self.table_books.selectedItems()
        if not rows:
            self.selected_books_id = None
        else:
            row = self.table_books.currentRow()
            self.selected_books_id = int(self.table_books.item(row, 0).text())
        self._update_selection_label()

    def on_gst_selected(self):
        rows = self.table_gst.selectedItems()
        if not rows:
            self.selected_gst_id = None
        else:
            row = self.table_gst.currentRow()
            self.selected_gst_id = int(self.table_gst.item(row, 0).text())
        self._update_selection_label()

    def _update_selection_label(self):
        if self.selected_books_id and self.selected_gst_id:
            self.lbl_selected_info.setText(f"Ready to match: Books ID {self.selected_books_id} ↔ GSTR ID {self.selected_gst_id}")
            self.btn_confirm.setEnabled(True)
        else:
            self.lbl_selected_info.setText("Select one Books invoice (Left) and one GSTR-2B invoice (Right)")
            self.btn_confirm.setEnabled(False)

    def confirm_manual_match(self):
        if not self.selected_books_id or not self.selected_gst_id:
            return
        period_id = self.get_period_cb()
        self.repo.manual_match_records(period_id, self.selected_books_id, self.selected_gst_id, remarks="User manual override match")
        QMessageBox.information(self, "Success", "Invoices manually matched successfully!")
        self.refresh_data()
