from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout, QScrollArea
)
from PySide6.QtCore import Qt
import matplotlib
matplotlib.use('QtAgg')
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from typing import Dict, Any


class DashboardView(QWidget):
    """Modern Executive Dashboard with KPI cards and interactive Matplotlib charts."""

    def __init__(self, repository, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # Title
        title_label = QLabel("🏠 Executive Reconciliation Dashboard")
        title_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #0F172A;")
        main_layout.addWidget(title_label)

        # KPI Cards Grid
        kpi_grid = QGridLayout()
        kpi_grid.setSpacing(15)

        self.card_books_itc = self._create_kpi_card("Books Purchase & ITC", "₹0.00", "#2563EB")
        self.card_2b_itc = self._create_kpi_card("GSTR-2B Filing ITC", "₹0.00", "#059669")
        self.card_matched_pct = self._create_kpi_card("Matched Confidence %", "0.0%", "#10B981")
        self.card_at_risk = self._create_kpi_card("ITC at Risk", "₹0.00", "#DC2626")
        self.card_books_only = self._create_kpi_card("Books Only (Pending)", "₹0.00", "#D97706")
        self.card_exceptions = self._create_kpi_card("Open Exceptions", "0", "#9333EA")

        kpi_grid.addWidget(self.card_books_itc, 0, 0)
        kpi_grid.addWidget(self.card_2b_itc, 0, 1)
        kpi_grid.addWidget(self.card_matched_pct, 0, 2)
        kpi_grid.addWidget(self.card_at_risk, 1, 0)
        kpi_grid.addWidget(self.card_books_only, 1, 1)
        kpi_grid.addWidget(self.card_exceptions, 1, 2)

        main_layout.addLayout(kpi_grid)

        # Matplotlib Charts Section
        charts_layout = QHBoxLayout()

        # Chart 1: Donut Chart - Matched vs Pending
        self.fig_pie = Figure(figsize=(5, 3.5), dpi=100)
        self.canvas_pie = FigureCanvas(self.fig_pie)
        charts_layout.addWidget(self.canvas_pie)

        # Chart 2: Bar Chart - ITC at Risk by Status
        self.fig_bar = Figure(figsize=(5, 3.5), dpi=100)
        self.canvas_bar = FigureCanvas(self.fig_bar)
        charts_layout.addWidget(self.canvas_bar)

        main_layout.addLayout(charts_layout)
        self.refresh_dashboard(None)

    def _create_kpi_card(self, title: str, initial_val: str, accent_color: str) -> QFrame:
        card = QFrame()
        card.setProperty("class", "KPICard")
        card.setStyleSheet(f"""
            QFrame {{
                background-color: #FFFFFF;
                border-radius: 10px;
                border-left: 5px solid {accent_color};
                border-top: 1px solid #E2E8F0;
                border-right: 1px solid #E2E8F0;
                border-bottom: 1px solid #E2E8F0;
                padding: 12px;
            }}
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 10, 10, 10)

        lbl_title = QLabel(title)
        lbl_title.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold; text-transform: uppercase;")
        lbl_val = QLabel(initial_val)
        lbl_val.setObjectName("value_label")
        lbl_val.setStyleSheet("color: #0F172A; font-size: 20px; font-weight: bold; margin-top: 4px;")

        layout.addWidget(lbl_title)
        layout.addWidget(lbl_val)
        return card

    def refresh_dashboard(self, period_id: int = None):
        if not period_id:
            self._update_card(self.card_books_itc, "₹0.00")
            self._update_card(self.card_2b_itc, "₹0.00")
            self._update_card(self.card_matched_pct, "0.0%")
            self._update_card(self.card_at_risk, "₹0.00")
            self._update_card(self.card_books_only, "₹0.00")
            self._update_card(self.card_exceptions, "0")
            self._draw_empty_charts()
            return

        from app.reconciliation.itc_engine import ITCEngine
        reco_results = self.repo.get_reconciliation_results(period_id)
        period_data_sum = self.repo.get_period_data_summary(period_id)

        if reco_results:
            summary = ITCEngine.calculate_itc_control_statement(reco_results)
            self._update_card(self.card_books_itc, f"₹{summary['total_books_itc']:,.2f}")
            self._update_card(self.card_2b_itc, f"₹{summary['total_2b_itc']:,.2f}")
            self._update_card(self.card_matched_pct, f"{summary['match_pct']}%")
            self._update_card(self.card_at_risk, f"₹{summary['itc_at_risk']:,.2f}")
            self._update_card(self.card_books_only, f"₹{summary['books_only_itc']:,.2f}")
            
            exceptions = [r for r in reco_results if r.get("match_status") in ["MISMATCH", "BOOKS_ONLY", "GSTR_ONLY", "DUPLICATE", "PARTIAL"]]
            self._update_card(self.card_exceptions, str(len(exceptions)))
            self._draw_charts(summary)
        else:
            # Show imported data control totals before reconciliation is run
            b_itc = period_data_sum.get("books_itc", 0.0)
            g_itc = period_data_sum.get("gst_itc", 0.0)
            self._update_card(self.card_books_itc, f"₹{b_itc:,.2f}")
            self._update_card(self.card_2b_itc, f"₹{g_itc:,.2f}")
            self._update_card(self.card_matched_pct, "Ready to Reconcile")
            self._update_card(self.card_at_risk, f"₹{abs(b_itc - g_itc):,.2f}")
            self._update_card(self.card_books_only, f"{period_data_sum.get('books_count', 0):,} Books Invs")
            self._update_card(self.card_exceptions, f"{period_data_sum.get('gst_count', 0):,} GST Invs")
            self._draw_empty_charts()

    def _update_card(self, card: QFrame, val: str):
        val_lbl = card.findChild(QLabel, "value_label")
        if val_lbl:
            val_lbl.setText(val)

    def _draw_empty_charts(self):
        self.fig_pie.clear()
        ax = self.fig_pie.add_subplot(111)
        ax.text(0.5, 0.5, 'Select Client & Period to View Charts', horizontalalignment='center', verticalalignment='center')
        ax.axis('off')
        self.canvas_pie.draw()

        self.fig_bar.clear()
        ax2 = self.fig_bar.add_subplot(111)
        ax2.text(0.5, 0.5, 'No Reconciliation Data Available', horizontalalignment='center', verticalalignment='center')
        ax2.axis('off')
        self.canvas_bar.draw()

    def _draw_charts(self, summary: Dict[str, Any]):
        # Pie Donut Chart
        self.fig_pie.clear()
        ax = self.fig_pie.add_subplot(111)
        labels = ['Matched ITC', 'Books Only', '2B Only', 'At Risk']
        sizes = [
            summary['matched_itc'],
            summary['books_only_itc'],
            summary['gst_only_itc'],
            summary['itc_at_risk']
        ]
        colors = ['#10B981', '#F59E0B', '#3B82F6', '#EF4444']

        # Filter out zeros
        filtered_labels = [l for l, s in zip(labels, sizes) if s > 0]
        filtered_sizes = [s for s in sizes if s > 0]
        filtered_colors = [c for c, s in zip(colors, sizes) if s > 0]

        if filtered_sizes:
            ax.pie(filtered_sizes, labels=filtered_labels, colors=filtered_colors, autopct='%1.1f%%', startangle=90, wedgeprops=dict(width=0.4))
            ax.set_title("ITC Breakdown (₹)", fontsize=11, fontweight='bold', color='#1E293B')
        else:
            ax.text(0.5, 0.5, 'No ITC Data', ha='center', va='center')
            ax.axis('off')
        self.canvas_pie.draw()

        # Bar Chart
        self.fig_bar.clear()
        ax2 = self.fig_bar.add_subplot(111)
        categories = ['Matched', 'Mismatched', 'Books Only', '2B Only']
        counts = [summary['matched_count'], summary['mismatched_count'], summary['books_only_count'], summary['gst_only_count']]
        bar_colors = ['#10B981', '#EF4444', '#F59E0B', '#3B82F6']
        ax2.bar(categories, counts, color=bar_colors)
        ax2.set_title("Invoice Reconciliation Count", fontsize=11, fontweight='bold', color='#1E293B')
        ax2.set_ylabel("Invoices")
        self.canvas_bar.draw()
