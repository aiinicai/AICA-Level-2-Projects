from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QFrame, QTextEdit, QSplitter
)
from PySide6.QtCore import Qt


class SmartMatchingView(QWidget):
    """Smart Matching / AI Assist Review Workspace."""

    def __init__(self, repository, get_current_period_cb, parent=None):
        super().__init__(parent)
        self.repo = repository
        self.get_period_cb = get_current_period_cb
        self.current_reco_id = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("🧠 Smart Matching / AI-Assist Review Workspace")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #0F172A;")
        layout.addWidget(title)

        splitter = QSplitter(Qt.Horizontal)

        # Left: Probable Matches Table
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)

        lbl_table = QLabel("Candidates Requiring Review")
        lbl_table.setStyleSheet("font-weight: bold; color: #475569;")
        left_layout.addWidget(lbl_table)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID", "Status", "Score", "Books Inv", "2B Inv", "Action"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self.on_candidate_selected)
        left_layout.addWidget(self.table)

        splitter.addWidget(left_widget)

        # Right: Side-by-Side Evidence Card
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(10, 0, 0, 0)

        lbl_card_title = QLabel("Matching Evidence & Underlying Reasons")
        lbl_card_title.setStyleSheet("font-weight: bold; color: #475569;")
        right_layout.addWidget(lbl_card_title)

        self.card_frame = QFrame()
        self.card_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #CBD5E1; border-radius: 8px; padding: 15px;")
        card_layout = QVBoxLayout(self.card_frame)

        self.lbl_score = QLabel("Match Score: -")
        self.lbl_score.setStyleSheet("font-size: 16px; font-weight: bold; color: #2563EB;")
        card_layout.addWidget(self.lbl_score)

        self.lbl_explanation = QLabel("Select a record from the list to view underlying matching evidence.")
        self.lbl_explanation.setWordWrap(True)
        self.lbl_explanation.setStyleSheet("font-size: 13px; color: #334155; line-height: 1.4;")
        card_layout.addWidget(self.lbl_explanation)

        card_layout.addStretch()

        # Actions
        self.txt_remarks = QTextEdit()
        self.txt_remarks.setPlaceholderText("Enter CA/User remarks here...")
        self.txt_remarks.setMaximumHeight(60)
        card_layout.addWidget(self.txt_remarks)

        act_box = QHBoxLayout()
        self.btn_accept = QPushButton("✓ Accept Match")
        self.btn_accept.setProperty("class", "SuccessBtn")
        self.btn_accept.clicked.connect(self.accept_match)
        act_box.addWidget(self.btn_accept)

        self.btn_reject = QPushButton("✗ Reject Match")
        self.btn_reject.setProperty("class", "DangerBtn")
        self.btn_reject.clicked.connect(self.reject_match)
        act_box.addWidget(self.btn_reject)

        card_layout.addLayout(act_box)

        right_layout.addWidget(self.card_frame)
        splitter.addWidget(right_widget)

        splitter.setSizes([500, 400])
        layout.addWidget(splitter)

    def refresh_data(self):
        period_id = self.get_period_cb()
        if not period_id:
            self.table.setRowCount(0)
            return

        reco_list = self.repo.get_reconciliation_results(period_id)
        # Filter for candidates needing review
        candidates = [r for r in reco_list if r.get("match_status") in ["PROBABLE", "PARTIAL", "MISMATCH"]]

        self.table.setRowCount(len(candidates))
        for idx, r in enumerate(candidates):
            self.table.setItem(idx, 0, QTableWidgetItem(str(r["id"])))
            self.table.setItem(idx, 1, QTableWidgetItem(r["match_status"]))
            self.table.setItem(idx, 2, QTableWidgetItem(f"{r['match_score']}%"))
            self.table.setItem(idx, 3, QTableWidgetItem(r.get("b_inv_no") or "-"))
            self.table.setItem(idx, 4, QTableWidgetItem(r.get("g_inv_no") or "-"))
            self.table.setItem(idx, 5, QTableWidgetItem(r.get("user_action") or "OPEN"))

    def on_candidate_selected(self):
        selected_rows = self.table.selectedItems()
        if not selected_rows:
            return
        row = self.table.currentRow()
        reco_id = int(self.table.item(row, 0).text())
        self.current_reco_id = reco_id

        period_id = self.get_period_cb()
        reco_list = self.repo.get_reconciliation_results(period_id)
        match_item = next((r for r in reco_list if r["id"] == reco_id), None)

        if match_item:
            self.lbl_score.setText(f"Match Score: {match_item['match_score']}% ({match_item['match_status']})")
            self.lbl_explanation.setText(match_item.get("explanation", ""))
            self.txt_remarks.setText(match_item.get("user_remarks", ""))

    def accept_match(self):
        if not self.current_reco_id:
            return
        remarks = self.txt_remarks.toPlainText().strip()
        self.repo.update_user_action(self.current_reco_id, "ACCEPTED", remarks)
        QMessageBox.information(self, "Success", "Match accepted and marked as ACCEPTED.")
        self.refresh_data()

    def reject_match(self):
        if not self.current_reco_id:
            return
        remarks = self.txt_remarks.toPlainText().strip()
        self.repo.update_user_action(self.current_reco_id, "REJECTED", remarks)
        QMessageBox.information(self, "Success", "Match rejected.")
        self.refresh_data()
