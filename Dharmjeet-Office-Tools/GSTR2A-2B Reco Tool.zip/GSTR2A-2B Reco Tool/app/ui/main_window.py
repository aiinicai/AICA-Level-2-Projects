from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QStackedWidget,
    QPushButton, QLabel, QComboBox, QFrame, QStatusBar, QMessageBox
)
from PySide6.QtCore import Qt
from app.database.repository import Repository
from app.ui.styles import LIGHT_THEME_QSS, DARK_THEME_QSS

# Import Views
from app.ui.views.dashboard_view import DashboardView
from app.ui.views.clients_view import ClientsView
from app.ui.views.import_view import ImportView
from app.ui.views.reconciliation_view import ReconciliationView
from app.ui.views.smart_matching_view import SmartMatchingView
from app.ui.views.manual_matching_view import ManualMatchingView
from app.ui.views.exceptions_view import ExceptionsView
from app.ui.views.itc_control_view import ITCControlView
from app.ui.views.suppliers_view import SuppliersView
from app.ui.views.reports_view import ReportsView
from app.ui.views.audit_view import AuditView
from app.ui.views.settings_view import SettingsView
from app.ui.views.imported_data_view import ImportedDataView


class MainWindow(QMainWindow):
    """Main Application Window shell for GSTR-2A/2B Reconciliation Tool."""

    def __init__(self, db_manager=None):
        super().__init__()
        self.repo = Repository(db_manager)
        self.is_dark_theme = False

        self.selected_client_id = None
        self.selected_gstin_id = None
        self.selected_fy_id = None
        self.selected_period_id = None

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Professional GSTR-2A / GSTR-2B Offline Reconciliation Tool (CA Edition)")
        self.resize(1350, 850)

        # Central Container
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 1. Left Sidebar Navigation
        sidebar = QFrame()
        sidebar.setObjectName("SidebarWidget")
        sidebar.setFixedWidth(240)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(4)

        lbl_app_title = QLabel("  GSTR Reco Pro")
        lbl_app_title.setObjectName("SidebarTitle")
        sidebar_layout.addWidget(lbl_app_title)

        nav_items = [
            ("🏠 Dashboard", 0),
            ("👥 Clients & GSTINs", 1),
            ("📥 Import Data", 2),
            ("📋 Imported Data Register", 3),
            ("📊 Reconciliation", 4),
            ("🧠 Smart Matching", 5),
            ("⚡ Side-by-Side Matcher", 6),
            ("⚠ Exceptions Queue", 7),
            ("💰 ITC Control Centre", 8),
            ("🏭 Suppliers Dashboard", 9),
            ("📑 Reports & Workpapers", 10),
            ("📜 Audit Log", 11),
            ("⚙ Settings", 12)
        ]

        self.nav_buttons = []
        for text, index in nav_items:
            btn = QPushButton(text)
            btn.setProperty("class", "NavBtn")
            btn.setCheckable(True)
            btn.clicked.connect(lambda _, idx=index: self.switch_view(idx))
            sidebar_layout.addWidget(btn)
            self.nav_buttons.append(btn)

        sidebar_layout.addStretch()

        # Offline Status Indicator
        lbl_offline = QLabel("🔒 Offline-First Mode Active\nNo Cloud Uploads")
        lbl_offline.setStyleSheet("color: #64748B; font-size: 11px; padding: 15px; border-top: 1px solid #1E293B;")
        sidebar_layout.addWidget(lbl_offline)

        main_layout.addWidget(sidebar)

        # 2. Right Content Area (Top Header + Stacked Views)
        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        # Top Header Bar (Client Selector)
        header_bar = QFrame()
        header_bar.setObjectName("HeaderBar")
        hdr_layout = QHBoxLayout(header_bar)
        hdr_layout.setContentsMargins(15, 8, 15, 8)
        hdr_layout.setSpacing(10)

        hdr_layout.addWidget(QLabel("Client:"))
        self.cmb_client = QComboBox()
        self.cmb_client.currentIndexChanged.connect(self.on_client_changed)
        hdr_layout.addWidget(self.cmb_client)

        hdr_layout.addWidget(QLabel("GSTIN:"))
        self.cmb_gstin = QComboBox()
        self.cmb_gstin.currentIndexChanged.connect(self.on_gstin_changed)
        hdr_layout.addWidget(self.cmb_gstin)

        hdr_layout.addWidget(QLabel("FY:"))
        self.cmb_fy = QComboBox()
        self.cmb_fy.currentIndexChanged.connect(self.on_fy_changed)
        hdr_layout.addWidget(self.cmb_fy)

        hdr_layout.addWidget(QLabel("Period:"))
        self.cmb_period = QComboBox()
        self.cmb_period.currentIndexChanged.connect(self.on_period_changed)
        hdr_layout.addWidget(self.cmb_period)

        hdr_layout.addStretch()

        btn_lock = QPushButton("🔒 Lock Period")
        btn_lock.clicked.connect(self.lock_current_period)
        hdr_layout.addWidget(btn_lock)

        right_layout.addWidget(header_bar)

        # Stacked Widget for Views
        self.stack = QStackedWidget()

        # Instantiate Views
        self.view_dashboard = DashboardView(self.repo)
        self.view_clients = ClientsView(self.repo, on_clients_changed_cb=self.populate_clients_dropdown)
        self.view_import = ImportView(
            self.repo,
            get_current_period_cb=lambda: self.selected_period_id,
            on_data_reset_cb=self._on_data_changed,
            on_navigate_register_cb=lambda: self.switch_view(3)
        )
        self.view_imported_data = ImportedDataView(
            self.repo,
            get_current_period_cb=lambda: self.selected_period_id,
            on_navigate_import_cb=lambda: self.switch_view(2)
        )
        self.view_reco = ReconciliationView(self.repo, get_current_period_cb=lambda: self.selected_period_id, get_current_gstin_cb=lambda: self.selected_gstin_id, on_reco_completed_cb=self.on_reco_completed)
        self.view_smart = SmartMatchingView(self.repo, get_current_period_cb=lambda: self.selected_period_id)
        self.view_manual = ManualMatchingView(self.repo, get_current_period_cb=lambda: self.selected_period_id)
        self.view_exceptions = ExceptionsView(self.repo, get_current_period_cb=lambda: self.selected_period_id)
        self.view_itc = ITCControlView(self.repo, get_current_period_cb=lambda: self.selected_period_id)
        self.view_suppliers = SuppliersView(self.repo, get_current_gstin_cb=lambda: self.selected_gstin_id)
        self.view_reports = ReportsView(self.repo, get_current_period_cb=lambda: self.selected_period_id, get_current_gstin_cb=lambda: self.selected_gstin_id, get_client_info_cb=self.get_client_info)
        self.view_audit = AuditView(self.repo)
        self.view_settings = SettingsView(self.repo, on_theme_toggle_cb=self.toggle_theme)

        self.stack.addWidget(self.view_dashboard)       # index 0
        self.stack.addWidget(self.view_clients)         # index 1
        self.stack.addWidget(self.view_import)          # index 2
        self.stack.addWidget(self.view_imported_data)   # index 3
        self.stack.addWidget(self.view_reco)            # index 4
        self.stack.addWidget(self.view_smart)           # index 5
        self.stack.addWidget(self.view_manual)          # index 6
        self.stack.addWidget(self.view_exceptions)      # index 7
        self.stack.addWidget(self.view_itc)             # index 8
        self.stack.addWidget(self.view_suppliers)       # index 9
        self.stack.addWidget(self.view_reports)         # index 10
        self.stack.addWidget(self.view_audit)           # index 11
        self.stack.addWidget(self.view_settings)        # index 12

        right_layout.addWidget(self.stack)
        main_layout.addWidget(right_container)

        # Status Bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready. Select Client & Period to begin.")

        # Apply Light Theme by default
        self.setStyleSheet(LIGHT_THEME_QSS)
        self.nav_buttons[0].setChecked(True)

        # Initial Dropdown Population
        self.populate_clients_dropdown()

    def switch_view(self, index: int):
        self.stack.setCurrentIndex(index)
        for idx, btn in enumerate(self.nav_buttons):
            btn.setChecked(idx == index)

        # Auto-refresh view data
        current_view = self.stack.currentWidget()
        if hasattr(current_view, 'refresh_data'):
            current_view.refresh_data()
        elif hasattr(current_view, 'refresh_dashboard'):
            current_view.refresh_dashboard(self.selected_period_id)

    def populate_clients_dropdown(self):
        self.cmb_client.blockSignals(True)
        self.cmb_client.clear()
        clients = self.repo.get_all_clients()
        for c in clients:
            self.cmb_client.addItem(c["name"], c["id"])
        self.cmb_client.blockSignals(False)

        if clients:
            self.selected_client_id = clients[0]["id"]
            self.populate_gstins_dropdown(self.selected_client_id)
        else:
            self.cmb_gstin.clear()
            self.cmb_fy.clear()
            self.cmb_period.clear()

    def on_client_changed(self):
        client_id = self.cmb_client.currentData()
        if client_id:
            self.selected_client_id = client_id
            self.populate_gstins_dropdown(client_id)

    def populate_gstins_dropdown(self, client_id: int):
        self.cmb_gstin.blockSignals(True)
        self.cmb_gstin.clear()
        gstins = self.repo.get_gstins_for_client(client_id)
        for g in gstins:
            self.cmb_gstin.addItem(g["gstin"], g["id"])
        self.cmb_gstin.blockSignals(False)

        if gstins:
            self.selected_gstin_id = gstins[0]["id"]
            self.populate_fy_dropdown(self.selected_gstin_id)
        else:
            self.cmb_fy.clear()
            self.cmb_period.clear()

    def on_gstin_changed(self):
        gstin_id = self.cmb_gstin.currentData()
        if gstin_id:
            self.selected_gstin_id = gstin_id
            self.populate_fy_dropdown(gstin_id)

    def populate_fy_dropdown(self, gstin_id: int):
        self.cmb_fy.blockSignals(True)
        self.cmb_fy.clear()
        
        fys = ["2026-27", "2025-26", "2024-25", "2027-28"]
        first_fy_id = None
        first_fy_str = fys[0]

        for fy_str in fys:
            fy_id = self.repo.get_or_create_fy(gstin_id, fy_str)
            if first_fy_id is None:
                first_fy_id = fy_id
                first_fy_str = fy_str
            self.cmb_fy.addItem(f"FY {fy_str}", (fy_id, fy_str))

        self.selected_fy_id = first_fy_id
        self.cmb_fy.blockSignals(False)

        self.populate_periods_dropdown(first_fy_id, first_fy_str)

    def on_fy_changed(self):
        data = self.cmb_fy.currentData()
        if data:
            fy_id, fy_str = data
            self.selected_fy_id = fy_id
            self.populate_periods_dropdown(fy_id, fy_str)

    def populate_periods_dropdown(self, fy_id: int, fy_str: str = "2026-27"):
        try:
            start_yr = int(fy_str.split("-")[0])
            end_yr = start_yr + 1 if len(fy_str.split("-")[1]) == 2 else int(fy_str.split("-")[1])
            if end_yr < 100:
                end_yr = 2000 + end_yr
        except Exception:
            start_yr, end_yr = 2026, 2027

        monthly_names = [
            f"April {start_yr}", f"May {start_yr}", f"June {start_yr}",
            f"July {start_yr}", f"August {start_yr}", f"September {start_yr}",
            f"October {start_yr}", f"November {start_yr}", f"December {start_yr}",
            f"January {end_yr}", f"February {end_yr}", f"March {end_yr}"
        ]

        quarterly_names = [
            f"Q1 (Apr-Jun {start_yr})",
            f"Q2 (Jul-Sep {start_yr})",
            f"Q3 (Oct-Dec {start_yr})",
            f"Q4 (Jan-Mar {end_yr})"
        ]

        yearly_names = [
            f"FY {fy_str} (Annual)"
        ]

        self.cmb_period.blockSignals(True)
        self.cmb_period.clear()

        first_period_id = None

        # Add Monthly Header / Items
        for p_name in monthly_names:
            pid, _ = self.repo.get_or_create_period(fy_id, p_name)
            if first_period_id is None:
                first_period_id = pid
            self.cmb_period.addItem(f"📅 {p_name}", pid)

        # Add Quarterly Items
        for p_name in quarterly_names:
            pid, _ = self.repo.get_or_create_period(fy_id, p_name)
            self.cmb_period.addItem(f"📊 {p_name}", pid)

        # Add Yearly Item
        for p_name in yearly_names:
            pid, _ = self.repo.get_or_create_period(fy_id, p_name)
            self.cmb_period.addItem(f"🗓️ {p_name}", pid)

        self.selected_period_id = first_period_id
        self.cmb_period.blockSignals(False)

        self.on_period_changed()

    def _on_data_changed(self):
        """Called after any import or data reset — refreshes dashboard and active view."""
        period_id = self.selected_period_id
        self.view_dashboard.refresh_dashboard(period_id)
        current_view = self.stack.currentWidget()
        if current_view != self.view_dashboard and hasattr(current_view, 'refresh_data'):
            current_view.refresh_data()

    def on_period_changed(self):
        period_id = self.cmb_period.currentData()
        self.selected_period_id = period_id
        
        current_view = self.stack.currentWidget()
        if hasattr(current_view, 'refresh_dashboard'):
            current_view.refresh_dashboard(period_id)
        elif hasattr(current_view, 'refresh_data'):
            current_view.refresh_data()

        self.status_bar.showMessage(f"Active Client: {self.cmb_client.currentText()} | GSTIN: {self.cmb_gstin.currentText()} | Period: {self.cmb_period.currentText()}")

    def on_reco_completed(self, period_id):
        self.view_dashboard.refresh_dashboard(period_id)
        current_view = self.stack.currentWidget()
        if current_view != self.view_dashboard and hasattr(current_view, 'refresh_data'):
            current_view.refresh_data()

    def lock_current_period(self):
        if not self.selected_period_id:
            return
        reply = QMessageBox.question(self, "Confirm Lock", "Lock reconciliation period? After locking, records cannot be modified without admin override.", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.repo.lock_period(self.selected_period_id, "Admin")
            QMessageBox.information(self, "Locked", "Period locked successfully.")

    def get_client_info(self):
        raw_period = self.cmb_period.currentText() or ""
        clean_period = raw_period.replace("📅 ", "").replace("📊 ", "").replace("🗓️ ", "").strip()
        return {
            "client_name": self.cmb_client.currentText(),
            "gstin": self.cmb_gstin.currentText(),
            "fy": self.cmb_fy.currentText(),
            "period": clean_period
        }

    def toggle_theme(self):
        self.is_dark_theme = not self.is_dark_theme
        if self.is_dark_theme:
            self.setStyleSheet(DARK_THEME_QSS)
        else:
            self.setStyleSheet(LIGHT_THEME_QSS)
