"""
GSTR-2A / GSTR-2B Offline Reconciliation Tool for CA Firms
"""

__version__ = "1.0.0"
