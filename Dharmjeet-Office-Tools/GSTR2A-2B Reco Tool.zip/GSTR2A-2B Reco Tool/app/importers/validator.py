from typing import List, Dict, Any, Tuple
from app.reconciliation.normalizer import is_valid_gstin, clean_gstin
from app.database.models import TransactionModel


class DataValidator:
    """Pre-import validation engine for Purchase Registers and GST records."""

    @staticmethod
    def validate_transactions(transactions: List[TransactionModel]) -> Tuple[List[TransactionModel], List[Dict[str, Any]]]:
        """
        Validates transactions. Returns a tuple of (valid_transactions, error_logs).
        Does not reject slightly imperfect records, but flags issues in remarks/error_logs.
        """
        valid_list = []
        errors = []

        inv_seen = set()

        for idx, tx in enumerate(transactions, start=1):
            row_num = tx.source_row or idx
            issues = []

            # 1. GSTIN Check
            gstin = clean_gstin(tx.supplier_gstin)
            if not gstin:
                issues.append("Missing Supplier GSTIN")
            elif not is_valid_gstin(gstin):
                issues.append(f"Invalid GSTIN format ({tx.supplier_gstin})")
            tx.supplier_gstin = gstin

            # 2. Invoice Number Check
            if not tx.invoice_number or not str(tx.invoice_number).strip():
                issues.append("Blank Invoice Number")

            # 3. Value Checks
            if tx.invoice_value < 0 or tx.taxable_value < 0:
                issues.append("Negative invoice or taxable value")

            calc_tax = tx.igst + tx.cgst + tx.sgst + tx.cess
            if abs(tx.total_tax - calc_tax) > 1.0:
                tx.total_tax = calc_tax  # Self-correct total_tax

            if tx.invoice_value > 0 and tx.taxable_value > 0:
                expected_total = tx.taxable_value + calc_tax
                if abs(tx.invoice_value - expected_total) > 5.0:
                    issues.append(f"Tax calculation mismatch (Taxable + Tax = ₹{expected_total:,.2f} vs Total ₹{tx.invoice_value:,.2f})")

            # 4. Duplicate Check within source file
            dedup_key = (tx.supplier_gstin, tx.normalized_inv_no)
            if dedup_key in inv_seen:
                issues.append("Duplicate invoice within same source file")
            else:
                inv_seen.add(dedup_key)

            if issues:
                tx.remarks = f"Validation Warnings: {'; '.join(issues)}"
                errors.append({
                    "row": row_num,
                    "gstin": tx.supplier_gstin,
                    "invoice_no": tx.invoice_number,
                    "warnings": issues
                })

            valid_list.append(tx)

        return valid_list, errors
