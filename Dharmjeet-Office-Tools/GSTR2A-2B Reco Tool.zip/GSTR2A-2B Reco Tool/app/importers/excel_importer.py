import os
import hashlib
import re
import pandas as pd
import openpyxl
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime
from app.reconciliation.normalizer import normalize_invoice_number, clean_gstin
from app.importers.column_mapper import ColumnMapper
from app.importers.validator import DataValidator
from app.database.models import TransactionModel


class ExcelImporter:
    """Imports Excel (.xlsx, .xls) and CSV purchase registers & official GSTR-2A/2B Excel workbooks."""

    HEADER_KEYWORDS = [
        "gstin", "supplier", "party", "particulars", "invoice", "vch", "voucher",
        "bill", "date", "taxable", "igst", "cgst", "sgst", "total", "gross",
        "amount", "value", "doc", "pos", "rcm", "rate", "itc", "note", "tax"
    ]

    SUMMARY_ROW_KEYWORDS = [
        "grand total", "sub total", "total", "closing balance", "opening balance",
        "carried forward", "brought forward", "b/f", "c/f", "total amount",
        "page total", "month total", "period total"
    ]

    @staticmethod
    def get_file_hash(file_path: str) -> str:
        """Computes SHA-256 hash of the file for duplicate file prevention."""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            while chunk := f.read(8192):
                sha256.update(chunk)
        return sha256.hexdigest()

    @staticmethod
    def get_sheet_names(file_path: str) -> List[str]:
        """Returns sheet names in an Excel file."""
        if file_path.lower().endswith('.csv'):
            return ['CSV Sheet']
        try:
            wb = openpyxl.load_workbook(file_path, read_only=True)
            names = wb.sheetnames
            wb.close()
            return names
        except Exception:
            try:
                xl = pd.ExcelFile(file_path)
                return xl.sheet_names
            except Exception:
                return ['Sheet1']

    @classmethod
    def get_best_sheet_name(cls, file_path: str, data_type: str = "BOOKS") -> str:
        """Determines the most appropriate sheet to use for preview/import."""
        sheet_names = cls.get_sheet_names(file_path)
        if not sheet_names or file_path.lower().endswith('.csv'):
            return sheet_names[0] if sheet_names else 'Sheet1'

        if data_type == "GSTR2B_EXCEL":
            for s in sheet_names:
                s_upper = s.upper().replace(" ", "").replace("-", "")
                if "B2B" in s_upper:
                    return s
            for s in sheet_names:
                if s.lower() not in ["read me", "readme", "gstr-2b summary", "summary", "instructions"]:
                    return s
            return sheet_names[0]

        # For BOOKS / Accounting registers
        for s in sheet_names:
            s_clean = s.lower().replace(" ", "").replace("_", "")
            if "purchase" in s_clean or "register" in s_clean or "vouchers" in s_clean:
                return s

        for s in sheet_names:
            if s.lower() not in ["read me", "readme", "summary", "instructions"]:
                return s

        return sheet_names[0]

    @classmethod
    def detect_header_row(cls, file_path: str, sheet_name: Optional[str] = None, max_scan_rows: int = 25) -> int:
        """
        Scans top rows of an Excel/CSV file to detect where the actual column headers reside.
        Essential for Tally/accounting exports with company metadata headers and GST portal files.
        """
        try:
            if file_path.lower().endswith('.csv'):
                df_raw = pd.read_csv(file_path, header=None, nrows=max_scan_rows, encoding='utf-8', on_bad_lines='skip')
            else:
                target_sheet = sheet_name or cls.get_best_sheet_name(file_path)
                df_raw = pd.read_excel(file_path, sheet_name=target_sheet, header=None, nrows=max_scan_rows)

            best_row = 0
            best_score = 0

            for r in range(min(max_scan_rows, len(df_raw))):
                row_vals = [str(val).lower().strip() for val in df_raw.iloc[r].values if pd.notna(val)]
                row_text = " ".join(row_vals)

                score = 0
                for kw in cls.HEADER_KEYWORDS:
                    if kw in row_text:
                        score += 1

                # If the row has multiple non-empty cells with header keywords
                if score > best_score:
                    best_score = score
                    best_row = r

            # If score is significant, return the detected row
            if best_score >= 2:
                return best_row
            return 0
        except Exception:
            return 0

    @classmethod
    def read_dataframe(
        cls,
        file_path: str,
        sheet_name: Optional[str] = None,
        header_row: Optional[int] = None,
        nrows: Optional[int] = None
    ) -> Tuple[pd.DataFrame, int, str]:
        """
        Reads Excel/CSV with auto-detected sheet name and header row.
        Returns (DataFrame, header_row_index, sheet_name).
        """
        target_sheet = sheet_name or cls.get_best_sheet_name(file_path)
        if header_row is None:
            header_row = cls.detect_header_row(file_path, target_sheet)

        if file_path.lower().endswith('.csv'):
            df = pd.read_csv(
                file_path,
                header=header_row,
                nrows=nrows,
                encoding='utf-8',
                on_bad_lines='skip'
            )
        else:
            df = pd.read_excel(
                file_path,
                sheet_name=target_sheet,
                header=header_row,
                nrows=nrows
            )

        # Clean column names (strip whitespace and handle None)
        df.columns = [str(c).strip() if pd.notna(c) else f"Unnamed: {i}" for i, c in enumerate(df.columns)]
        return df, header_row, target_sheet

    @classmethod
    def import_purchase_register(
        cls,
        file_path: str,
        sheet_name: Optional[str] = None,
        column_mapping: Optional[Dict[str, str]] = None,
        header_row: Optional[int] = None
    ) -> Tuple[List[TransactionModel], List[Dict[str, Any]], Dict[str, str]]:
        """Imports purchase register file into list of TransactionModel objects."""
        df, detected_header_row, target_sheet = cls.read_dataframe(file_path, sheet_name, header_row)

        # Strip whitespace from string columns
        df = df.apply(lambda col: col.str.strip() if col.dtype == "object" else col)

        # Auto-detect column mapping if not provided
        if not column_mapping:
            column_mapping = ColumnMapper.auto_detect(list(df.columns))

        transactions = []
        for idx, row in df.iterrows():
            def get_val(field: str, default=None):
                col_name = column_mapping.get(field)
                if col_name and col_name in df.columns:
                    v = row[col_name]
                    if pd.isna(v):
                        return default
                    return v
                return default

            supplier_name_raw = str(get_val("supplier_name", "") or "").strip()
            inv_no_raw = str(get_val("invoice_number", "") or "").strip()
            date_raw = get_val("invoice_date")
            gstin_raw = str(get_val("supplier_gstin", "") or "").strip()

            # Check if this row is a Tally summary/total/balance row
            comb_text = f"{supplier_name_raw} {inv_no_raw}".lower()
            if any(comb_text.startswith(kw) or comb_text == kw for kw in cls.SUMMARY_ROW_KEYWORDS):
                continue  # Skip grand total, closing balance, etc.

            # If invoice_number is empty, try checking fallback columns like "Voucher No" or "Vch No."
            inv_no = inv_no_raw
            if not inv_no or inv_no.lower() == 'nan':
                for fb_col in ["Vch No.", "Vch No", "Voucher No.", "Voucher No", "Bill No.", "Bill No"]:
                    if fb_col in df.columns and pd.notna(row[fb_col]):
                        val_str = str(row[fb_col]).strip()
                        if val_str and val_str.lower() != 'nan':
                            inv_no = val_str
                            break

            # If row is completely empty or missing both invoice number and date/particulars, skip
            if not inv_no or inv_no.lower() == 'nan':
                continue

            gstin = clean_gstin(gstin_raw)
            supplier_name = supplier_name_raw
            inv_date = cls._format_date(date_raw)
            inv_val = cls._to_float(get_val("invoice_value"))
            taxable_val = cls._to_float(get_val("taxable_value"))
            igst = cls._to_float(get_val("igst"))
            cgst = cls._to_float(get_val("cgst"))
            sgst = cls._to_float(get_val("sgst"))
            cess = cls._to_float(get_val("cess"))

            total_tax = igst + cgst + sgst + cess
            if inv_val == 0.0 and (taxable_val > 0 or total_tax > 0):
                inv_val = taxable_val + total_tax
            elif taxable_val == 0.0 and inv_val > 0 and total_tax > 0:
                taxable_val = inv_val - total_tax

            doc_type_val = str(get_val("doc_type", "B2B") or "B2B").upper()
            if any(k in doc_type_val for k in ["CREDIT", "CDNR", " CN", "CR NOTE"]):
                doc_type = "CDNR"
            elif any(k in doc_type_val for k in ["DEBIT", "DBNR", " DN", "DR NOTE"]):
                doc_type = "DBNR"
            else:
                doc_type = "B2B"

            pos = str(get_val("pos", "") or "").strip()
            rcm_raw = str(get_val("rcm", "N") or "N").upper().strip()
            rcm = "Y" if rcm_raw in ["Y", "YES", "TRUE", "1"] else "N"

            norm_inv = normalize_invoice_number(inv_no)

            tx = TransactionModel(
                supplier_gstin=gstin,
                supplier_name=supplier_name,
                invoice_number=inv_no,
                normalized_inv_no=norm_inv,
                invoice_date=inv_date,
                invoice_value=round(inv_val, 2),
                taxable_value=round(taxable_val, 2),
                igst=round(igst, 2),
                cgst=round(cgst, 2),
                sgst=round(sgst, 2),
                cess=round(cess, 2),
                total_tax=round(total_tax, 2),
                itc_eligibility="Eligible",
                pos=pos,
                rcm=rcm,
                doc_type=doc_type,
                source_sheet=target_sheet or "Sheet1",
                source_row=int(idx) + detected_header_row + 2
            )
            transactions.append(tx)

        valid_txs, errors = DataValidator.validate_transactions(transactions)
        return valid_txs, errors, column_mapping

    @classmethod
    def detect_gst_sections(cls, file_path: str) -> List[Dict[str, Any]]:
        """Scans workbook and returns all detected GST data sheets and their detected section type."""
        sheet_names = cls.get_sheet_names(file_path)
        sections = []
        for sheet in sheet_names:
            sheet_clean = sheet.upper().replace(" ", "").replace("_", "").replace("-", "")
            if any(k in sheet.lower() for k in ["read me", "readme", "summary", "instruction", "gstr-2b summary", "gstr-2a summary"]):
                continue

            sec = None
            if "CDNRA" in sheet_clean:
                sec = "CDNRA"
            elif "CDNR" in sheet_clean:
                sec = "CDNR"
            elif "B2BA" in sheet_clean:
                sec = "B2BA"
            elif "ISDA" in sheet_clean:
                sec = "ISDA"
            elif "ISD" in sheet_clean:
                sec = "ISD"
            elif "IMPGSEZ" in sheet_clean:
                sec = "IMPGSEZ"
            elif "IMPG" in sheet_clean:
                sec = "IMPG"
            elif "TDSA" in sheet_clean:
                sec = "TDSA"
            elif "TDS" in sheet_clean:
                sec = "TDS"
            elif "TCS" in sheet_clean:
                sec = "TCS"
            elif "ECO" in sheet_clean:
                sec = "ECO"
            elif "B2B" in sheet_clean:
                sec = "B2B"

            if sec:
                sections.append({"sheet_name": sheet, "section": sec})
        return sections

    @classmethod
    def import_gst_excel(cls, file_path: str, gstr_type: str = "GSTR2B") -> Tuple[List[TransactionModel], List[Dict[str, Any]]]:
        """Auto-detects and imports all multi-sheet GSTR-2A or GSTR-2B sections downloaded from official GST portal in 1 click."""
        matched_sections = cls.detect_gst_sections(file_path)
        all_txs = []
        all_errors = []

        if matched_sections:
            for item in matched_sections:
                sheet = item["sheet_name"]
                section = item["section"]
                header_idx = cls.detect_header_row(file_path, sheet)
                df, _, _ = cls.read_dataframe(file_path, sheet, header_idx)
                col_map = ColumnMapper.auto_detect(list(df.columns))

                txs, errs, _ = cls.import_purchase_register(
                    file_path=file_path,
                    sheet_name=sheet,
                    column_mapping=col_map,
                    header_row=header_idx
                )

                for tx in txs:
                    if section == "CDNRA":
                        tx.doc_type = "CDNRA"
                        tx.amendment_flag = "Y"
                    elif section == "CDNR":
                        tx.doc_type = "CDNR"
                    elif section == "B2BA":
                        tx.doc_type = "B2BA"
                        tx.amendment_flag = "Y"
                    elif section == "ISDA":
                        tx.doc_type = "ISDA"
                        tx.amendment_flag = "Y"
                    elif section == "ISD":
                        tx.doc_type = "ISD"
                    elif section == "IMPGSEZ":
                        tx.doc_type = "IMPGSEZ"
                    elif section == "IMPG":
                        tx.doc_type = "IMPG"
                    elif section == "TDSA":
                        tx.doc_type = "TDSA"
                        tx.amendment_flag = "Y"
                    elif section == "TDS":
                        tx.doc_type = "TDS"
                    elif section == "TCS":
                        tx.doc_type = "TCS"
                    elif section == "ECO":
                        tx.doc_type = "ECO"
                    else:
                        tx.doc_type = "B2B"

                    tx.source_sheet = f"{section} ({sheet})"
                    tx.itc_available = "Y"
                    all_txs.append(tx)
                all_errors.extend(errs)
        else:
            # Fallback: auto-detect best single sheet
            best_sheet = cls.get_best_sheet_name(file_path, f"{gstr_type}_EXCEL")
            header_idx = cls.detect_header_row(file_path, best_sheet)
            df, _, _ = cls.read_dataframe(file_path, best_sheet, header_idx)
            col_map = ColumnMapper.auto_detect(list(df.columns))
            all_txs, all_errors, _ = cls.import_purchase_register(
                file_path=file_path,
                sheet_name=best_sheet,
                column_mapping=col_map,
                header_row=header_idx
            )
            for tx in all_txs:
                tx.source_sheet = best_sheet
                tx.itc_available = "Y"

        return all_txs, all_errors

    @classmethod
    def import_gstr2b_excel(cls, file_path: str) -> Tuple[List[TransactionModel], List[Dict[str, Any]]]:
        """Auto-detects and imports multi-sheet GSTR-2B Excel downloaded from official GST portal."""
        return cls.import_gst_excel(file_path, gstr_type="GSTR2B")

    @classmethod
    def import_gstr2a_excel(cls, file_path: str) -> Tuple[List[TransactionModel], List[Dict[str, Any]]]:
        """Auto-detects and imports multi-sheet GSTR-2A Excel downloaded from official GST portal."""
        return cls.import_gst_excel(file_path, gstr_type="GSTR2A")

    @staticmethod
    def _format_date(val) -> str:
        """Formats dates in all common Indian and standard formats."""
        if pd.isna(val) or val is None:
            return ""
        if isinstance(val, (datetime, pd.Timestamp)):
            return val.strftime("%Y-%m-%d")

        val_str = str(val).strip()
        if not val_str or val_str.lower() == 'nan':
            return ""

        # Try common date formats
        formats = (
            "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d",
            "%d-%b-%Y", "%d-%b-%y", "%d/%b/%Y", "%d/%b/%y",
            "%d-%B-%Y", "%d-%B-%y", "%d %b %Y", "%d %b %y",
            "%d %B %Y", "%d %B %y", "%Y%m%d"
        )
        for fmt in formats:
            try:
                return datetime.strptime(val_str, fmt).strftime("%Y-%m-%d")
            except ValueError:
                pass

        # Handle numeric Excel date serials
        try:
            float_val = float(val_str)
            if 30000 < float_val < 60000:
                return (pd.to_datetime('1899-12-30') + pd.to_timedelta(float_val, 'D')).strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            pass

        return val_str[:10]

    @staticmethod
    def _to_float(val) -> float:
        """Converts strings with currency symbols, commas, or blanks to float."""
        if pd.isna(val) or val is None:
            return 0.0
        try:
            val_clean = str(val).replace(',', '').replace('₹', '').replace('Rs.', '').replace('Rs', '').strip()
            if not val_clean or val_clean.lower() == 'nan':
                return 0.0
            return float(val_clean)
        except (ValueError, TypeError):
            return 0.0
