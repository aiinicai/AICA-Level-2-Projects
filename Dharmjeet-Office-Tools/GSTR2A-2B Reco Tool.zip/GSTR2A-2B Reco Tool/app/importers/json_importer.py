import json
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime
from app.reconciliation.normalizer import normalize_invoice_number, clean_gstin
from app.importers.validator import DataValidator
from app.database.models import TransactionModel


class JSONImporter:
    """Parses official GST Portal GSTR-2A and GSTR-2B JSON export files."""

    @classmethod
    def import_gstr2b_json(cls, file_path: str) -> Tuple[List[TransactionModel], List[Dict[str, Any]], Dict[str, Any]]:
        """
        Parses GSTR-2B JSON file into TransactionModel list.
        Returns (transactions, errors, metadata).
        """
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        metadata = cls.extract_metadata(data)
        docdata = cls._find_docdata(data)
        tx_list = []

        # 1. Parse B2B
        b2b_list = docdata.get("b2b", docdata.get("b2bData", []))
        for b2b in b2b_list:
            ctin = clean_gstin(b2b.get("ctin", ""))
            trade_name = b2b.get("trdnm", b2b.get("lgnm", b2b.get("trade_name", "")))
            invs = b2b.get("inv", b2b.get("invs", []))
            for inv in invs:
                tx_list.extend(cls._parse_inv_item(ctin, trade_name, inv, doc_type="B2B", metadata=metadata))

        # 2. Parse CDNR (Credit/Debit Notes)
        cdnr_list = docdata.get("cdnr", docdata.get("cdnrData", []))
        for cdnr in cdnr_list:
            ctin = clean_gstin(cdnr.get("ctin", ""))
            trade_name = cdnr.get("trdnm", cdnr.get("lgnm", ""))
            notes = cdnr.get("nt", cdnr.get("notes", []))
            for nt in notes:
                nt_typ = str(nt.get("nt_typ", nt.get("typ", "C"))).upper()
                doc_type = "DBNR" if "D" in nt_typ or "DEBIT" in nt_typ else "CDNR"
                tx_list.extend(cls._parse_inv_item(ctin, trade_name, nt, doc_type=doc_type, metadata=metadata))

        # 3. Parse B2BA (Amendments to Invoices)
        b2ba_list = docdata.get("b2ba", docdata.get("b2baData", []))
        for b2ba in b2ba_list:
            ctin = clean_gstin(b2ba.get("ctin", ""))
            trade_name = b2ba.get("trdnm", b2ba.get("lgnm", ""))
            invs = b2ba.get("inv", b2ba.get("invs", []))
            for inv in invs:
                txs = cls._parse_inv_item(ctin, trade_name, inv, doc_type="B2BA", metadata=metadata)
                for t in txs:
                    t.amendment_flag = "Y"
                    t.original_inv_no = inv.get("oinum", "")
                    t.original_inv_date = cls._format_json_date(inv.get("oidt", ""))
                tx_list.extend(txs)

        # 4. Parse CDNRA (Amendments to Credit/Debit Notes)
        cdnra_list = docdata.get("cdnra", docdata.get("cdnraData", []))
        for cdnra in cdnra_list:
            ctin = clean_gstin(cdnra.get("ctin", ""))
            trade_name = cdnra.get("trdnm", cdnra.get("lgnm", ""))
            notes = cdnra.get("nt", cdnra.get("notes", []))
            for nt in notes:
                txs = cls._parse_inv_item(ctin, trade_name, nt, doc_type="CDNRA", metadata=metadata)
                for t in txs:
                    t.amendment_flag = "Y"
                    t.original_inv_no = nt.get("ont_num", nt.get("onum", ""))
                    t.original_inv_date = cls._format_json_date(nt.get("ont_dt", nt.get("odt", "")))
                tx_list.extend(txs)

        # 5. Parse ISD
        isd_list = docdata.get("isd", docdata.get("isdData", []))
        for isd in isd_list:
            ctin = clean_gstin(isd.get("ctin", ""))
            trade_name = isd.get("trdnm", "")
            doclist = isd.get("doclist", [])
            for doc in doclist:
                tx_list.extend(cls._parse_inv_item(ctin, trade_name, doc, doc_type="ISD", metadata=metadata))

        # 6. Parse ISDA (Amendments to ISD)
        isda_list = docdata.get("isda", docdata.get("isdaData", []))
        for isda in isda_list:
            ctin = clean_gstin(isda.get("ctin", ""))
            trade_name = isda.get("trdnm", "")
            doclist = isda.get("doclist", [])
            for doc in doclist:
                txs = cls._parse_inv_item(ctin, trade_name, doc, doc_type="ISDA", metadata=metadata)
                for t in txs:
                    t.amendment_flag = "Y"
                tx_list.extend(txs)

        # 7. Parse IMPG (Import of Goods from Overseas)
        impg_list = docdata.get("impg", docdata.get("impgData", []))
        for impg in impg_list:
            port = impg.get("port_code", "")
            boe_num = str(impg.get("boe_num", impg.get("boenum", "")))
            boe_dt = cls._format_json_date(impg.get("boe_dt", impg.get("boedt", "")))
            txs = cls._parse_inv_item("OVERSEAS", f"Import of Goods ({port})", impg, doc_type="IMPG", metadata=metadata)
            for t in txs:
                if not t.invoice_number:
                    t.invoice_number = f"BOE-{boe_num}"
                if not t.invoice_date and boe_dt:
                    t.invoice_date = boe_dt
            tx_list.extend(txs)

        # 8. Parse IMPGSEZ (Import of Goods from SEZ)
        impgsez_list = docdata.get("impgsez", docdata.get("impgsezData", []))
        for impgsez in impgsez_list:
            ctin = clean_gstin(impgsez.get("ctin", ""))
            trade_name = impgsez.get("trdnm", "SEZ Supplier")
            txs = cls._parse_inv_item(ctin, trade_name, impgsez, doc_type="IMPGSEZ", metadata=metadata)
            tx_list.extend(txs)

        metadata["total_records"] = len(tx_list)
        metadata["total_taxable"] = sum(t.taxable_value for t in tx_list)
        metadata["total_tax"] = sum(t.total_tax for t in tx_list)

        valid_txs, errors = DataValidator.validate_transactions(tx_list)
        return valid_txs, errors, metadata

    @classmethod
    def import_gstr2a_json(cls, file_path: str) -> Tuple[List[TransactionModel], List[Dict[str, Any]], Dict[str, Any]]:
        """Parses GSTR-2A JSON file into TransactionModel list."""
        return cls.import_gstr2b_json(file_path)

    @classmethod
    def import_gst_json(cls, file_path: str, gstr_type: str = "GSTR2B") -> Tuple[List[TransactionModel], List[Dict[str, Any]], Dict[str, Any]]:
        """Parses any official GST Portal JSON file (GSTR-2A or GSTR-2B) in single click."""
        return cls.import_gstr2b_json(file_path)

    @classmethod
    def _find_docdata(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Navigates through possible root envelopes to locate docdata."""
        if "docdata" in data and isinstance(data["docdata"], dict):
            return data["docdata"]
        if "data" in data and isinstance(data["data"], dict):
            if "docdata" in data["data"]:
                return data["data"]["docdata"]
            return data["data"]
        return data

    @classmethod
    def extract_metadata(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Extracts GSTIN, return period (fp), and generation date from JSON payload."""
        gstin = data.get("gstin", data.get("data", {}).get("gstin", "")) if isinstance(data, dict) else ""
        fp = data.get("fp", data.get("data", {}).get("fp", "")) if isinstance(data, dict) else ""
        gen_date = data.get("gen_date", data.get("data", {}).get("gen_date", "")) if isinstance(data, dict) else ""

        return {
            "gstin": gstin,
            "fp": fp,
            "gen_date": gen_date
        }

    @classmethod
    def _parse_inv_item(
        cls,
        ctin: str,
        trade_name: str,
        item_dict: Dict[str, Any],
        doc_type: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> List[TransactionModel]:
        inv_no = str(item_dict.get("inum", item_dict.get("ntnum", item_dict.get("docnum", "")))).strip()
        inv_date = cls._format_json_date(item_dict.get("idt", item_dict.get("ntdt", item_dict.get("docdt", ""))))
        inv_val = float(item_dict.get("val", item_dict.get("docval", 0.0)))
        pos = str(item_dict.get("pos", ""))
        rcm = str(item_dict.get("rchrg", "N")).upper()
        itc_avail = str(item_dict.get("itcavl", item_dict.get("itc_elg", "Y"))).upper()

        taxable_val = 0.0
        igst = 0.0
        cgst = 0.0
        sgst = 0.0
        cess = 0.0

        items = item_dict.get("itms", item_dict.get("items", []))
        for itm in items:
            # Check both 'itm_det' (official GST portal JSON) and 'item_det'
            det = itm.get("itm_det") or itm.get("item_det") or itm
            taxable_val += float(det.get("txval", 0.0))
            igst += float(det.get("iamt", 0.0))
            cgst += float(det.get("camt", 0.0))
            sgst += float(det.get("samt", 0.0))
            cess += float(det.get("csamt", 0.0))

        total_tax = igst + cgst + sgst + cess
        if inv_val == 0.0:
            inv_val = taxable_val + total_tax
        elif taxable_val == 0.0 and inv_val > 0 and total_tax > 0:
            taxable_val = inv_val - total_tax

        norm_inv = normalize_invoice_number(inv_no)
        fp = metadata.get("fp", "") if metadata else ""
        gen_date = cls._format_json_date(metadata.get("gen_date", "")) if metadata else ""

        tx = TransactionModel(
            supplier_gstin=ctin,
            supplier_name=trade_name,
            invoice_number=inv_no,
            normalized_inv_no=norm_inv,
            invoice_date=inv_date,
            filing_date=gen_date,
            gstr2b_period=fp,
            invoice_value=round(inv_val, 2),
            taxable_value=round(taxable_val, 2),
            igst=round(igst, 2),
            cgst=round(cgst, 2),
            sgst=round(sgst, 2),
            cess=round(cess, 2),
            total_tax=round(total_tax, 2),
            itc_available=itc_avail,
            pos=pos,
            rcm=rcm,
            doc_type=doc_type,
            source_sheet="JSON",
            source_row=1
        )
        return [tx]

    @staticmethod
    def _format_json_date(dt_str: str) -> str:
        if not dt_str:
            return ""
        dt_clean = str(dt_str).strip()
        for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y", "%d-%b-%Y", "%d/%b/%Y"):
            try:
                return datetime.strptime(dt_clean, fmt).strftime("%Y-%m-%d")
            except ValueError:
                pass
        return dt_clean[:10]
