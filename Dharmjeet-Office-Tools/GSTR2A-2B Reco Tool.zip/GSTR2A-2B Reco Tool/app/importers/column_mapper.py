import re
import json
from typing import Dict, List, Optional, Tuple, Any

SYNONYMS = {
    "supplier_gstin": [
        "gstin of supplier", "supplier gstin", "party gstin", "party's gstin",
        "buyer/supplier gstin", "gstin/uin", "gstin", "gst no", "party gst no",
        "supplier gst", "vendor gstin", "vendor gst", "tin/gstin", "party gst",
        "gst number", "party gstin/uin", "ctin", "gstin of counter party"
    ],
    "supplier_name": [
        "trade/legal name", "trade legal name", "trade name", "legal name",
        "legal name of supplier", "trade name of supplier", "particulars",
        "party name", "name of supplier", "name of party", "party/ledger name",
        "supplier name", "party", "vendor name", "vendor", "account name",
        "ledger name", "supplier", "account", "customer name", "supplier's legal/trade name"
    ],
    "invoice_number": [
        "invoice number", "invoice no", "inv number", "inv no", "invoice no.",
        "inv no.", "note number", "note no", "note no.", "credit/debit note no",
        "supplier invoice no", "supplier invoice no.", "supplier inv no",
        "supplier inv no.", "vch no.", "vch no", "voucher no.", "voucher no",
        "voucher number", "vch number", "bill number", "bill no", "bill no.",
        "doc no", "doc no.", "document number", "document no", "ref no",
        "ref no.", "reference no", "invoice #", "bill #", "inum", "ntnum",
        "original invoice number", "original note number", "doc num", "bill of entry no", "boe no"
    ],
    "invoice_date": [
        "invoice date", "inv date", "invoice dt", "inv dt", "note date", "note dt",
        "supplier invoice date", "supplier inv date", "bill date", "vch date",
        "voucher date", "doc date", "document date", "posting date", "date",
        "ref date", "reference date", "idt", "ntdt", "doc dt", "bill of entry date", "boe date"
    ],
    "invoice_value": [
        "invoice value", "invoice value(₹)", "invoice value (₹)", "invoice value (rs.)", "invoice value(?)",
        "note value", "note value(₹)", "note value (₹)", "note value (rs.)", "note value(?)",
        "gross total", "total amount", "total value", "invoice amount", "inv amount",
        "bill amount", "bill value", "net amount", "total", "grand total",
        "gross amount", "invoice val", "inv value", "val", "doc val", "taxable value + tax"
    ],
    "taxable_value": [
        "taxable value", "taxable value (₹)", "taxable value(₹)", "taxable value (rs.)", "taxable value(?)",
        "taxable amount", "assessable value", "assessable amt", "taxable val",
        "taxable", "goods value", "pur value", "purchase value", "base value",
        "base amount", "net taxable amount", "txval", "taxable value (?)"
    ],
    "igst": [
        "integrated tax", "integrated tax(₹)", "integrated tax (₹)", "integrated tax (rs.)", "integrated tax(?)",
        "igst", "igst amount", "igst amt", "input igst", "igst (rs)", "igst tax",
        "igst amt (rs.)", "igst @ 18%", "igst @ 12%", "igst @ 5%", "igst @ 28%",
        "igst 18%", "igst 12%", "igst 5%", "igst 28%", "input igst @ 18%",
        "input igst 18%", "integrated gst", "iamt", "integrated tax (?)"
    ],
    "cgst": [
        "central tax", "central tax(₹)", "central tax (₹)", "central tax (rs.)", "central tax(?)",
        "cgst", "cgst amount", "cgst amt", "input cgst", "cgst (rs)", "cgst tax",
        "cgst amt (rs.)", "cgst @ 9%", "cgst @ 6%", "cgst @ 2.5%", "cgst @ 14%",
        "cgst 9%", "cgst 6%", "cgst 2.5%", "cgst 14%", "input cgst @ 9%",
        "input cgst 9%", "central gst", "camt", "central tax (?)"
    ],
    "sgst": [
        "state/ut tax", "state/ut tax(₹)", "state/ut tax (₹)", "state/ut tax (rs.)", "state/ut tax(?)",
        "state ut tax", "state tax", "sgst", "sgst amount", "sgst amt", "input sgst",
        "utgst", "sgst/utgst", "sgst (rs)", "sgst tax", "sgst amt (rs.)",
        "sgst @ 9%", "sgst @ 6%", "sgst @ 2.5%", "sgst @ 14%",
        "sgst 9%", "sgst 6%", "sgst 2.5%", "sgst 14%", "input sgst @ 9%",
        "input sgst 9%", "ut tax", "utgst amt", "state gst", "samt", "state/ut tax (?)"
    ],
    "cess": [
        "cess", "cess(₹)", "cess (₹)", "cess (rs.)", "cess(?)", "cess amount", "cess amt",
        "cess (rs)", "gst cess", "input cess", "csamt", "cess (?)"
    ],
    "doc_type": [
        "invoice type", "note type", "doc type", "document type", "voucher type",
        "vch type", "supply type", "type", "supply type", "note typ"
    ],
    "pos": [
        "place of supply", "place of supply (pos)", "pos", "supply state",
        "state", "state name", "state of supply", "place of supply(pos)"
    ],
    "rcm": [
        "supply attract reverse charge", "reverse charge", "reverse charge flag",
        "reverse charge applicable", "rcm", "rcm applicable", "supply attracts reverse charge",
        "applicable % of tax rate"
    ],
    "itc_eligibility": [
        "itc availability", "itc available", "itc eligibility", "itc eligible",
        "itc claimable", "eligibility for itc", "itc type", "itc available y/n"
    ]
}


class ColumnMapper:
    """Auto-detects columns and manages reusable column mapping templates."""

    @staticmethod
    def clean_header_text(header: Any) -> str:
        """Cleans and standardizes column header string."""
        if header is None:
            return ""
        s = str(header).lower().strip()
        # Remove special characters except alphanumeric
        s = re.sub(r'[\r\n\t]+', ' ', s)
        s = re.sub(r'[^a-z0-9\s]', ' ', s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    @classmethod
    def auto_detect(cls, columns: List[str]) -> Dict[str, str]:
        """
        Automatically maps header columns to target normalized fields based on synonym scoring.
        Uses prioritized matching:
        1. Exact synonym string match
        2. Normalized alphanumeric match
        3. Word boundary / whole word token match
        """
        mapping: Dict[str, str] = {}
        if not columns:
            return mapping

        # Filter out empty or Unnamed headers
        cleaned_col_map: Dict[str, str] = {}
        for c in columns:
            if c is None:
                continue
            orig = str(c).strip()
            if not orig or orig.lower().startswith('unnamed:'):
                continue
            cleaned = cls.clean_header_text(orig)
            if cleaned:
                cleaned_col_map[orig] = cleaned

        # Priority order for field resolution to avoid greedy claims
        field_order = [
            "supplier_gstin",
            "invoice_number",
            "invoice_date",
            "taxable_value",
            "invoice_value",
            "igst",
            "cgst",
            "sgst",
            "cess",
            "supplier_name",
            "doc_type",
            "rcm",
            "pos",
            "itc_eligibility"
        ]

        mapped_columns = set()

        for target_field in field_order:
            synonyms = SYNONYMS.get(target_field, [])
            best_col = None
            best_score = 0

            for orig_col, clean_col in cleaned_col_map.items():
                if orig_col in mapped_columns:
                    continue

                score = 0
                clean_no_space = clean_col.replace(" ", "")

                for syn in synonyms:
                    syn_clean = cls.clean_header_text(syn)
                    syn_no_space = syn_clean.replace(" ", "")

                    # 1. Exact string match
                    if clean_col == syn_clean:
                        score = max(score, 1000 + len(syn_clean))
                    # 2. Exact match ignoring spaces
                    elif clean_no_space == syn_no_space and len(clean_no_space) >= 3:
                        score = max(score, 800 + len(syn_clean))
                    # 3. Whole phrase/word match
                    elif re.search(r'\b' + re.escape(syn_clean) + r'\b', clean_col):
                        # Avoid single-letter or generic word false positives
                        if len(syn_clean) >= 4 or syn_clean in ["gst", "rcm", "pos", "cn", "dn"]:
                            score = max(score, 500 + len(syn_clean))
                    # 4. Synonym is a full token inside column
                    elif syn_clean in clean_col:
                        # Exclude generic collision risks like 'rate', 'date', 'tax', 'value'
                        if syn_clean not in ["rate", "value", "amount", "total", "tax", "date", "party", "type"]:
                            score = max(score, 300 + len(syn_clean))

                if score > best_score:
                    best_score = score
                    best_col = orig_col

            if best_col and best_score >= 300:
                mapping[target_field] = best_col
                mapped_columns.add(best_col)

        return mapping

    @staticmethod
    def get_standard_templates() -> Dict[str, Dict[str, str]]:
        """Returns standard pre-built mapping templates for Tally, Busy, Marg, GST Portal, etc."""
        return {
            "Tally Columnar Register": {
                "supplier_gstin": "GSTIN/UIN",
                "supplier_name": "Particulars",
                "invoice_number": "Vch No.",
                "invoice_date": "Date",
                "invoice_value": "Gross Total",
                "taxable_value": "Taxable Value",
                "igst": "Integrated Tax",
                "cgst": "Central Tax",
                "sgst": "State Tax",
                "cess": "Cess",
                "doc_type": "Vch Type"
            },
            "Tally with Supplier Inv Details": {
                "supplier_gstin": "GSTIN / UIN",
                "supplier_name": "Particulars",
                "invoice_number": "Supplier Invoice No.",
                "invoice_date": "Supplier Invoice Date",
                "invoice_value": "Total Amount",
                "taxable_value": "Taxable Amount",
                "igst": "IGST",
                "cgst": "CGST",
                "sgst": "SGST",
                "doc_type": "Voucher Type"
            },
            "Official GST Portal GSTR-2B": {
                "supplier_gstin": "GSTIN of supplier",
                "supplier_name": "Trade/Legal name",
                "invoice_number": "Invoice number",
                "invoice_date": "Invoice Date",
                "invoice_value": "Invoice Value(₹)",
                "taxable_value": "Taxable Value (₹)",
                "igst": "Integrated Tax(₹)",
                "cgst": "Central Tax(₹)",
                "sgst": "State/UT Tax(₹)",
                "cess": "Cess(₹)",
                "pos": "Place of supply",
                "rcm": "Supply Attract Reverse Charge",
                "doc_type": "Invoice type",
                "itc_eligibility": "ITC Availability"
            },
            "Busy Purchase Register": {
                "supplier_gstin": "Party GSTIN",
                "supplier_name": "Party Name",
                "invoice_number": "Bill No.",
                "invoice_date": "Date",
                "invoice_value": "Total Amount",
                "taxable_value": "Taxable Amt",
                "igst": "IGST Amt",
                "cgst": "CGST Amt",
                "sgst": "SGST Amt",
                "cess": "Cess Amt"
            },
            "Marg Purchase Register": {
                "supplier_gstin": "GST No",
                "supplier_name": "Supplier Name",
                "invoice_number": "Bill Number",
                "invoice_date": "Bill Date",
                "invoice_value": "Net Amt",
                "taxable_value": "Taxable",
                "igst": "IGST",
                "cgst": "CGST",
                "sgst": "SGST"
            }
        }
