import sys
import os
from PySide6.QtWidgets import QApplication
from app.database.connection import DatabaseManager
from app.database.repository import Repository
from app.database.models import ClientModel, GSTINModel
from app.ui.main_window import MainWindow


def seed_initial_demo_data(repo: Repository):
    """Seeds initial demo client and sample data if database is empty."""
    clients = repo.get_all_clients()
    if not clients:
        # Create Sample Client ABC Pvt Ltd
        client_id = repo.create_client(ClientModel(
            name="ABC Pvt Ltd",
            trade_name="ABC Electronics",
            pan="AAACA1234A",
            contact_person="CA Dharmjeet",
            email="contact@abc.com",
            phone="9876543210",
            address="New Delhi, India"
        ))

        # Add GSTIN
        gstin_id = repo.add_gstin(GSTINModel(
            client_id=client_id,
            gstin="07AAAAA1234A1Z5",
            state="Delhi",
            books_software="Tally"
        ))

        fy_id = repo.get_or_create_fy(gstin_id, "2026-27")
        repo.get_or_create_period(fy_id, "April 2026")
        repo.get_or_create_period(fy_id, "May 2026")
        repo.get_or_create_period(fy_id, "Q1 (Apr-Jun 2026)")
        repo.get_or_create_period(fy_id, "FY 2026-27 (Annual)")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("GSTR-2A/2B Offline Reconciliation Tool")
    app.setOrganizationName("CA Tools India")

    db_manager = DatabaseManager()
    repo = Repository(db_manager)

    seed_initial_demo_data(repo)

    window = MainWindow(db_manager)
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
