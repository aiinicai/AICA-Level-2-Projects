import hashlib


def hash_password(password: str) -> str:
    """Hashes password with SHA-256."""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()


class RolePermissions:
    ROLES = {
        "Administrator": ["create_client", "delete_client", "lock_period", "unlock_period", "manage_users", "backup_restore", "override_match"],
        "Partner": ["create_client", "lock_period", "unlock_period", "override_match", "export_reports"],
        "Manager": ["create_client", "lock_period", "override_match", "export_reports"],
        "Staff": ["import_data", "run_reco", "accept_match", "reject_match", "export_reports"],
        "Reviewer": ["review_exceptions", "accept_match", "reject_match", "export_reports"],
        "Read Only": ["view_reports", "view_reco"]
    }

    @classmethod
    def can_perform(cls, role: str, action: str) -> bool:
        allowed_actions = cls.ROLES.get(role, [])
        return action in allowed_actions
