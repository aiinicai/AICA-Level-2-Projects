from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from typing import Dict, Any, List


class PDFExporter:
    """Generates professional PDF Reconciliation Audit Reports and CA Workpapers."""

    @classmethod
    def generate_pdf_report(
        cls,
        file_path: str,
        client_name: str,
        gstin: str,
        period_name: str,
        summary: Dict[str, Any],
        prepared_by: str = "Staff Accountant",
        reviewed_by: str = "CA Partner",
        remarks: str = "Reconciliation verified and signed off."
    ):
        """Generates a professional PDF reconciliation audit report."""
        doc = SimpleDocTemplate(
            file_path,
            pagesize=A4,
            leftMargin=36,
            rightMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            'DocTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=16,
            leading=20,
            textColor=colors.HexColor('#1F4E78')
        )
        subtitle_style = ParagraphStyle(
            'DocSubTitle',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=10,
            leading=14,
            textColor=colors.HexColor('#595959')
        )
        heading2_style = ParagraphStyle(
            'Heading2',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=12,
            leading=16,
            textColor=colors.HexColor('#1F4E78'),
            spaceBefore=10,
            spaceAfter=5
        )
        body_style = ParagraphStyle(
            'Body',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=12
        )

        story = []

        # 1. Header
        story.append(Paragraph("GSTR-2B RECONCILIATION AUDIT REPORT", title_style))
        story.append(Paragraph(f"<b>Client:</b> {client_name} | <b>GSTIN:</b> {gstin} | <b>Period:</b> {period_name}", subtitle_style))
        story.append(Spacer(1, 10))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#1F4E78'), spaceAfter=15))

        # 2. Executive Summary Metrics Table
        story.append(Paragraph("1. Executive Summary & ITC Control Statement", heading2_style))

        kpi_data = [
            ["Metric", "Books Claim (₹)", "GSTR-2B Filing (₹)", "Variance / Risk (₹)", "Status"],
            ["Total Purchase & ITC", f"₹{summary.get('total_books_itc', 0.0):,.2f}", f"₹{summary.get('total_2b_itc', 0.0):,.2f}", f"₹{abs(summary.get('total_books_itc', 0.0) - summary.get('total_2b_itc', 0.0)):,.2f}", f"Match: {summary.get('match_pct', 0.0)}%"],
            ["Matched Invoices", f"₹{summary.get('matched_itc', 0.0):,.2f}", f"₹{summary.get('matched_itc', 0.0):,.2f}", "₹0.00", "Verified"],
            ["Books Only (Pending 2B)", f"₹{summary.get('books_only_itc', 0.0):,.2f}", "₹0.00", f"₹{summary.get('books_only_itc', 0.0):,.2f}", "Pending 2B"],
            ["GSTR-2B Only", "₹0.00", f"₹{summary.get('gst_only_itc', 0.0):,.2f}", f"₹{summary.get('gst_only_itc', 0.0):,.2f}", "Unrecorded"],
            ["ITC at Risk", "₹0.00", "₹0.00", f"₹{summary.get('itc_at_risk', 0.0):,.2f}", "Action Req."]
        ]

        kpi_table = Table(kpi_data, colWidths=[150, 95, 95, 95, 80])
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1F4E78')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-2, -1), 'RIGHT'),
            ('ALIGN', (-1, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#D9D9D9')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(kpi_table)
        story.append(Spacer(1, 15))

        # 3. Disclaimer
        story.append(Paragraph("2. GST Compliance Disclaimer", heading2_style))
        disclaimer_text = (
            "<i>This application is a reconciliation and analytical tool. Final determination of ITC eligibility "
            "must be made by the taxpayer/professional after considering the applicable provisions of the GST law, "
            "rules, notifications, circulars and relevant facts.</i>"
        )
        story.append(Paragraph(disclaimer_text, body_style))
        story.append(Spacer(1, 20))

        # 4. CA Workpaper Sign-off Section
        story.append(Paragraph("3. Professional Review & Sign-Off Workpaper", heading2_style))
        signoff_data = [
            ["Prepared By:", prepared_by, "Date:", "17-Aug-2026"],
            ["Reviewed By:", reviewed_by, "Designation:", "Chartered Accountant / Partner"],
            ["Sign-off Remarks:", remarks, "", ""]
        ]
        signoff_table = Table(signoff_data, colWidths=[100, 160, 90, 165])
        signoff_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('SPAN', (1, 2), (3, 2)),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#D9D9D9')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F9F9F9'))
        ]))
        story.append(signoff_table)
        story.append(Spacer(1, 30))

        # Footer Notice
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=8,
            alignment=1,
            textColor=colors.HexColor('#A0A0A0')
        )
        story.append(Paragraph("CONFIDENTIAL — FOR CLIENT / PROFESSIONAL USE ONLY", footer_style))

        doc.build(story)
