import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import List, Dict, Any, Optional


class ExcelExporter:
    """Generates professional multi-sheet Excel reconciliation workpapers."""

    HEADER_FILL = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    HEADER_FONT = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")

    TITLE_FONT = Font(name="Segoe UI", size=14, bold=True, color="1F4E78")
    SUBTITLE_FONT = Font(name="Segoe UI", size=10, italic=True, color="595959")
    BOLD_FONT = Font(name="Segoe UI", size=10, bold=True)
    REGULAR_FONT = Font(name="Segoe UI", size=10)

    GREEN_FILL = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
    YELLOW_FILL = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
    RED_FILL = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
    BLUE_FILL = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
    GREY_FILL = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

    THIN_BORDER = Border(
        left=Side(style='thin', color='D9D9D9'),
        right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'),
        bottom=Side(style='thin', color='D9D9D9')
    )

    @classmethod
    def export_reconciliation_workpaper(
        cls,
        file_path: str,
        client_name: str,
        gstin: str,
        period_name: str,
        itc_summary: Dict[str, Any],
        reco_results: List[Dict[str, Any]],
        suppliers_list: List[Dict[str, Any]]
    ):
        """Generates a complete multi-tab Excel workpaper."""
        wb = openpyxl.Workbook()

        # 1. Summary Sheet
        ws_summary = wb.active
        ws_summary.title = "Summary & Control"
        cls._build_summary_sheet(ws_summary, client_name, gstin, period_name, itc_summary)

        # 2. Matched Invoices Sheet
        ws_matched = wb.create_sheet(title="Matched Invoices")
        matched_rows = [r for r in reco_results if r.get("match_status") in ["EXACT", "HIGH_CONFIDENCE"]]
        cls._build_details_sheet(ws_matched, "Matched Invoices", matched_rows)

        # 3. Probable & Mismatches Sheet
        ws_review = wb.create_sheet(title="Review Required")
        review_rows = [r for r in reco_results if r.get("match_status") in ["PROBABLE", "PARTIAL", "MISMATCH"]]
        cls._build_details_sheet(ws_review, "Probable Matches & Mismatches", review_rows)

        # 4. Books Only Sheet
        ws_books = wb.create_sheet(title="Books Only (Missing 2B)")
        books_rows = [r for r in reco_results if r.get("match_status") == "BOOKS_ONLY"]
        cls._build_details_sheet(ws_books, "Books Only Invoices", books_rows)

        # 5. 2B Only Sheet
        ws_2b = wb.create_sheet(title="GSTR-2B Only")
        gst_rows = [r for r in reco_results if r.get("match_status") == "GSTR_ONLY"]
        cls._build_details_sheet(ws_2b, "GSTR-2B Only Invoices", gst_rows)

        # 6. Supplier Analysis Sheet
        ws_supp = wb.create_sheet(title="Supplier Analysis")
        cls._build_supplier_sheet(ws_supp, suppliers_list)

        wb.save(file_path)

    @classmethod
    def _build_summary_sheet(cls, ws, client_name: str, gstin: str, period_name: str, summary: Dict[str, Any]):
        ws.views.sheetView[0].showGridLines = True

        ws["A1"] = f"GSTR-2B RECONCILIATION SUMMARY WORKPAPER"
        ws["A1"].font = cls.TITLE_FONT
        ws["A2"] = f"Client: {client_name} | GSTIN: {gstin} | Period: {period_name}"
        ws["A2"].font = cls.SUBTITLE_FONT

        headers = ["KPI Metric", "Books Claim (₹)", "GSTR-2B (₹)", "Difference / Risk (₹)", "Count"]
        ws.append([])
        ws.append(headers)

        for col in range(1, 6):
            cell = ws.cell(row=4, column=col)
            cell.fill = cls.HEADER_FILL
            cell.font = cls.HEADER_FONT
            cell.alignment = Alignment(horizontal="center")

        kpis = [
            ("Total Purchase & ITC", summary.get("total_books_itc", 0.0), summary.get("total_2b_itc", 0.0), summary.get("total_books_itc", 0.0) - summary.get("total_2b_itc", 0.0), summary.get("total_count", 0)),
            ("Matched Invoices (High Confidence)", summary.get("matched_itc", 0.0), summary.get("matched_itc", 0.0), 0.0, summary.get("matched_count", 0)),
            ("Books Only (Pending 2B Filing)", summary.get("books_only_itc", 0.0), 0.0, summary.get("books_only_itc", 0.0), summary.get("books_only_count", 0)),
            ("GSTR-2B Only (Unrecorded in Books)", 0.0, summary.get("gst_only_itc", 0.0), summary.get("gst_only_itc", 0.0), summary.get("gst_only_count", 0)),
            ("ITC at Risk (Mismatches & Pending)", 0.0, 0.0, summary.get("itc_at_risk", 0.0), summary.get("mismatched_count", 0))
        ]

        row_idx = 5
        for label, b_val, g_val, diff_val, cnt in kpis:
            ws.cell(row=row_idx, column=1, value=label).font = cls.BOLD_FONT
            ws.cell(row=row_idx, column=2, value=b_val).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=3, value=g_val).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=4, value=diff_val).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=5, value=cnt).alignment = Alignment(horizontal="center")

            for col in range(1, 6):
                ws.cell(row=row_idx, column=col).border = cls.THIN_BORDER
            row_idx += 1

        cls._autofit_columns(ws)

    @classmethod
    def _build_details_sheet(cls, ws, title: str, rows: List[Dict[str, Any]]):
        ws.views.sheetView[0].showGridLines = True
        ws.freeze_panes = "A2"

        headers = [
            "Match Status", "Score", "Level",
            "Books GSTIN", "Books Supplier", "Books Inv No", "Books Date", "Books Inv Val", "Books Tax",
            "2B GSTIN", "2B Supplier", "2B Inv No", "2B Date", "2B Inv Val", "2B Tax",
            "Difference (₹)", "Explanation", "User Action", "Remarks"
        ]

        ws.append(headers)
        for col in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=col)
            cell.fill = cls.HEADER_FILL
            cell.font = cls.HEADER_FONT

        row_idx = 2
        for r in rows:
            status = r.get("match_status", "")
            ws.cell(row=row_idx, column=1, value=status).font = cls.BOLD_FONT
            ws.cell(row=row_idx, column=2, value=r.get("match_score", 0.0))
            ws.cell(row=row_idx, column=3, value=r.get("matching_level", ""))

            ws.cell(row=row_idx, column=4, value=r.get("b_gstin", ""))
            ws.cell(row=row_idx, column=5, value=r.get("b_supplier", ""))
            ws.cell(row=row_idx, column=6, value=r.get("b_inv_no", ""))
            ws.cell(row=row_idx, column=7, value=r.get("b_date", ""))
            ws.cell(row=row_idx, column=8, value=r.get("b_inv_val", 0.0)).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=9, value=r.get("b_tax", 0.0)).number_format = "₹#,##0.00"

            ws.cell(row=row_idx, column=10, value=r.get("g_gstin", ""))
            ws.cell(row=row_idx, column=11, value=r.get("g_supplier", ""))
            ws.cell(row=row_idx, column=12, value=r.get("g_inv_no", ""))
            ws.cell(row=row_idx, column=13, value=r.get("g_date", ""))
            ws.cell(row=row_idx, column=14, value=r.get("g_inv_val", 0.0)).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=15, value=r.get("g_tax", 0.0)).number_format = "₹#,##0.00"

            ws.cell(row=row_idx, column=16, value=r.get("diff_amount", 0.0)).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=17, value=r.get("explanation", ""))
            ws.cell(row=row_idx, column=18, value=r.get("user_action", ""))
            ws.cell(row=row_idx, column=19, value=r.get("user_remarks", ""))

            # Status row highlight
            fill = None
            if status in ["EXACT", "HIGH_CONFIDENCE"]: fill = cls.GREEN_FILL
            elif status in ["PROBABLE", "PARTIAL"]: fill = cls.YELLOW_FILL
            elif status in ["MISMATCH", "DUPLICATE"]: fill = cls.RED_FILL
            elif status == "BOOKS_ONLY": fill = cls.GREY_FILL
            elif status == "GSTR_ONLY": fill = cls.BLUE_FILL

            if fill:
                ws.cell(row=row_idx, column=1).fill = fill

            for col in range(1, len(headers) + 1):
                ws.cell(row=row_idx, column=col).border = cls.THIN_BORDER

            row_idx += 1

        cls._autofit_columns(ws)

    @classmethod
    def _build_supplier_sheet(cls, ws, suppliers: List[Dict[str, Any]]):
        ws.views.sheetView[0].showGridLines = True
        ws.freeze_panes = "A2"

        headers = [
            "Supplier GSTIN", "Supplier Name", "Reliability Score", "Books Count", "GSTR-2B Count",
            "Matched Count", "Mismatched Count", "Missing Count", "Books ITC (₹)", "2B ITC (₹)", "ITC at Risk (₹)"
        ]

        ws.append(headers)
        for col in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=col)
            cell.fill = cls.HEADER_FILL
            cell.font = cls.HEADER_FONT

        row_idx = 2
        for s in suppliers:
            ws.cell(row=row_idx, column=1, value=s.get("supplier_gstin", ""))
            ws.cell(row=row_idx, column=2, value=s.get("supplier_name", ""))
            score_cell = ws.cell(row=row_idx, column=3, value=s.get("reliability_score", 100.0))
            score_cell.font = cls.BOLD_FONT

            ws.cell(row=row_idx, column=4, value=s.get("books_count", 0))
            ws.cell(row=row_idx, column=5, value=s.get("gst_count", 0))
            ws.cell(row=row_idx, column=6, value=s.get("matched_count", 0))
            ws.cell(row=row_idx, column=7, value=s.get("mismatched_count", 0))
            ws.cell(row=row_idx, column=8, value=s.get("missing_count", 0))

            ws.cell(row=row_idx, column=9, value=s.get("total_books_itc", 0.0)).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=10, value=s.get("total_gst_itc", 0.0)).number_format = "₹#,##0.00"
            ws.cell(row=row_idx, column=11, value=s.get("itc_at_risk", 0.0)).number_format = "₹#,##0.00"

            for col in range(1, len(headers) + 1):
                ws.cell(row=row_idx, column=col).border = cls.THIN_BORDER

            row_idx += 1

        cls._autofit_columns(ws)

    @staticmethod
    def _autofit_columns(ws):
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val_str = str(cell.value or '')
                if cell.number_format and "₹" in cell.number_format:
                    val_str = f"₹{val_str}"
                max_len = max(max_len, len(val_str))
            ws.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 50)
