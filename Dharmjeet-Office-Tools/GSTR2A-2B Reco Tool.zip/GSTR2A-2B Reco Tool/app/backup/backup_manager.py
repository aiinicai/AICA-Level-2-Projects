import os
import shutil
import zipfile
import sqlite3
from datetime import datetime
from pathlib import Path
from app.database.connection import get_db_path


class BackupManager:
    """Manages database backup archives and restore operations."""

    @staticmethod
    def create_backup(backup_dir: Optional[str] = None) -> str:
        """Creates a timestamped zip archive of the SQLite database."""
        db_path = get_db_path()
        if not db_path.exists():
            raise FileNotFoundError(f"Database file not found at {db_path}")

        target_dir = Path(backup_dir) if backup_dir else db_path.parent / "backups"
        target_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = target_dir / f"gstr_reco_backup_{timestamp}.zip"

        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(db_path, arcname=db_path.name)

        return str(zip_filename)

    @staticmethod
    def restore_backup(backup_file_path: str) -> bool:
        """Restores database from a zip backup file after verifying integrity."""
        db_path = get_db_path()
        if not os.path.exists(backup_file_path):
            raise FileNotFoundError("Backup archive file not found.")

        temp_extract = db_path.parent / "temp_restore.db"

        with zipfile.ZipFile(backup_file_path, 'r') as zipf:
            names = zipf.namelist()
            if db_path.name not in names:
                raise ValueError("Invalid backup file: database file missing inside zip.")
            zipf.extract(db_path.name, path=db_path.parent)

        # Verify restored DB integrity
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check;")
            res = cursor.fetchone()[0]
            conn.close()
            return res == "ok"
        except Exception as e:
            raise ValueError(f"Restored database integrity check failed: {str(e)}")
