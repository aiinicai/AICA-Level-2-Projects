from typing import List, Dict, Any, Tuple
from collections import defaultdict
from app.reconciliation.normalizer import clean_gstin


class CandidateBlocker:
    """Blocks candidate transactions by GSTIN to avoid O(N * M) performance bottleneck."""

    @staticmethod
    def block_by_gstin(
        books_list: List[Dict[str, Any]],
        gst_list: List[Dict[str, Any]]
    ) -> Dict[str, Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]]:
        """
        Groups books and GST records by normalized supplier GSTIN.
        Returns dict mapping gstin -> (books_records, gst_records).
        """
        blocks = defaultdict(lambda: ([], []))

        for b in books_list:
            gstin = clean_gstin(b.get("supplier_gstin", ""))
            blocks[gstin][0].append(b)

        for g in gst_list:
            gstin = clean_gstin(g.get("supplier_gstin", ""))
            blocks[gstin][1].append(g)

        return blocks
