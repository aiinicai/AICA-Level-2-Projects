from typing import List, Dict, Any, Tuple
from app.reconciliation.normalizer import clean_gstin
from app.database.models import RecoResultModel


class CarryForwardEngine:
    """Matches pending Books invoices carried forward from previous periods with current month GSTR-2B."""

    @staticmethod
    def match_carried_forward(
        current_period_id: int,
        prev_pending_books: List[Dict[str, Any]],
        current_gst_list: List[Dict[str, Any]]
    ) -> Tuple[List[RecoResultModel], List[int], List[int]]:
        """
        Matches carried-forward Books invoices with current 2B.
        Returns (carry_forward_reco_results, matched_books_ids, matched_gst_ids).
        """
        results = []
        matched_books = []
        matched_gst = []

        gst_map = {(g["supplier_gstin"], g["normalized_inv_no"]): g for g in current_gst_list}

        for b in prev_pending_books:
            key = (clean_gstin(b["supplier_gstin"]), b["normalized_inv_no"])
            if key in gst_map:
                g = gst_map[key]
                matched_books.append(b["id"])
                matched_gst.append(g["id"])
                results.append(RecoResultModel(
                    period_id=current_period_id,
                    books_id=b["id"],
                    gst_id=g["id"],
                    match_status="HIGH_CONFIDENCE",
                    match_score=95.0,
                    matching_level="SUBSEQUENT_2B_MATCH",
                    diff_amount=round(abs(b["invoice_value"] - g["invoice_value"]), 2),
                    diff_tax=round(abs(b["total_tax"] - g["total_tax"]), 2),
                    explanation=f"✓ Carried forward Books invoice from period {b.get('carried_forward_from_period', 'previous')} matched in current GSTR-2B filing.",
                    recommendation="Matched in Subsequent GSTR-2B — Eligible for current period ITC claim.",
                    user_action="ACCEPTED"
                ))

        return results, matched_books, matched_gst
