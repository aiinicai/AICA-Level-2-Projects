import re
from typing import Tuple


def normalize_invoice_number(inv_no: str) -> str:
    """
    Normalizes invoice number by stripping non-alphanumeric characters,
    converting to uppercase, removing financial year patterns (e.g., 25-26, 2025-26),
    and stripping leading zeros.
    
    Examples:
    - "INV/001/25-26"  -> "INV1"
    - "inv-001-25-26"  -> "INV1"
    - "000125"         -> "125"
    - "INV/2025-26/99" -> "INV99"
    """
    if not inv_no:
        return ""
    
    raw = str(inv_no).strip().upper()
    
    def check_fy(m):
        try:
            y1, y2 = int(m.group(1)), int(m.group(2))
            if (y2 == y1 + 1) or (y2 == (y1 % 100) + 1):
                return ""
        except ValueError:
            pass
        return m.group(0)

    # 1. Try stripping trailing FY pattern
    cleaned = re.sub(r'[/_\-\s]*(?:FY[/_\-\s]*)?(\d{2,4})[/_\-\s]+(\d{2,4})$', check_fy, raw, flags=re.IGNORECASE)
    if cleaned == raw:
        # 2. Try stripping inner/prefix FY pattern
        cleaned = re.sub(r'[/_\-\s]*(?:FY[/_\-\s]*)?(\d{2,4})[/_\-\s]+(\d{2,4})[/_\-\s]*', check_fy, raw, flags=re.IGNORECASE)

    # 3. Strip non-alphanumeric characters
    alphanumeric = re.sub(r'[^A-Z0-9]', '', cleaned)
    
    if not alphanumeric:
        alphanumeric = re.sub(r'[^A-Z0-9]', '', raw)
        
    # 4. Strip leading zeros if purely numeric
    if alphanumeric.isdigit():
        return str(int(alphanumeric))
        
    # 5. Strip leading zeros in trailing numeric part (e.g. INV0001 -> INV1)
    match = re.match(r'^([A-Z]+)0*(\d+)$', alphanumeric)
    if match:
        prefix, num = match.groups()
        return f"{prefix}{int(num)}"
        
    return alphanumeric


def clean_gstin(gstin: str) -> str:
    """Cleans and formats GSTIN string."""
    if not gstin:
        return ""
    cleaned = re.sub(r'[^A-Z0-9]', '', str(gstin).strip().upper())
    return cleaned


def is_valid_gstin(gstin: str) -> bool:
    """Validates 15-character Indian GSTIN format."""
    cleaned = clean_gstin(gstin)
    if len(cleaned) != 15:
        return False
    # Regex pattern: State code (2 digits) + PAN (5 letters + 4 digits + 1 letter) + Entity code (1 digit/letter) + Z + Check digit
    pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
    return bool(re.match(pattern, cleaned))
