from typing import List, Dict, Any, Tuple
from collections import defaultdict
from app.database.models import RecoResultModel


class DuplicateEngine:
    """Detects duplicates in Books, GSTR-2B, and cross-source potential duplicate ITC."""

    @staticmethod
    def detect_duplicates(
        books_list: List[Dict[str, Any]],
        gst_list: List[Dict[str, Any]]
    ) -> Tuple[List[int], List[int], List[RecoResultModel]]:
        """
        Detects duplicate invoice entries within Books and GSTR-2B datasets.
        Returns (duplicate_books_ids, duplicate_gst_ids, duplicate_reco_results).
        """
        dup_books_ids = set()
        dup_gst_ids = set()
        results = []

        # 1. Books Duplicates
        books_map = defaultdict(list)
        for b in books_list:
            key = (b["supplier_gstin"], b["normalized_inv_no"], round(b["invoice_value"], 2))
            books_map[key].append(b)

        for key, group in books_map.items():
            if len(group) > 1:
                first = group[0]
                for dup in group[1:]:
                    dup_books_ids.add(dup["id"])
                    results.append(RecoResultModel(
                        books_id=dup["id"],
                        gst_id=None,
                        match_status="DUPLICATE",
                        match_score=100.0,
                        matching_level="DUPLICATE_BOOKS",
                        explanation=f"Duplicate invoice entry in Books (same GSTIN {first['supplier_gstin']}, Inv {first['invoice_number']}, ₹{first['invoice_value']:,.2f})",
                        recommendation="Review Books register for accidental double entry.",
                        user_action="OPEN"
                    ))

        # 2. GST Duplicates
        gst_map = defaultdict(list)
        for g in gst_list:
            key = (g["supplier_gstin"], g["normalized_inv_no"], round(g["invoice_value"], 2))
            gst_map[key].append(g)

        for key, group in gst_map.items():
            if len(group) > 1:
                first = group[0]
                for dup in group[1:]:
                    dup_gst_ids.add(dup["id"])
                    results.append(RecoResultModel(
                        books_id=None,
                        gst_id=dup["id"],
                        match_status="DUPLICATE",
                        match_score=100.0,
                        matching_level="DUPLICATE_GST",
                        explanation=f"Duplicate invoice entry in GSTR-2B (same GSTIN {first['supplier_gstin']}, Inv {first['invoice_number']}, ₹{first['invoice_value']:,.2f})",
                        recommendation="Supplier uploaded duplicate invoice to GST portal.",
                        user_action="OPEN"
                    ))

        return list(dup_books_ids), list(dup_gst_ids), results
