from typing import List, Dict, Any


class ITCEngine:
    """Calculates summary metrics for the ITC Control Centre."""

    @staticmethod
    def calculate_itc_control_statement(reco_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculates comprehensive ITC metrics from reconciliation results."""
        summary = {
            "total_books_itc": 0.0,
            "total_2b_itc": 0.0,
            "matched_itc": 0.0,
            "books_only_itc": 0.0,
            "gst_only_itc": 0.0,
            "itc_at_risk": 0.0,
            "ineligible_itc": 0.0,
            "rcm_itc": 0.0,
            "igst": {"books": 0.0, "gst": 0.0, "matched": 0.0},
            "cgst": {"books": 0.0, "gst": 0.0, "matched": 0.0},
            "sgst": {"books": 0.0, "gst": 0.0, "matched": 0.0},
            "cess": {"books": 0.0, "gst": 0.0, "matched": 0.0},
            "total_count": len(reco_results),
            "matched_count": 0,
            "mismatched_count": 0,
            "books_only_count": 0,
            "gst_only_count": 0,
            "match_pct": 0.0
        }

        for r in reco_results:
            status = r.get("match_status", "")
            b_tax = float(r.get("b_tax") or 0.0)
            g_tax = float(r.get("g_tax") or 0.0)
            b_igst = float(r.get("b_igst") or 0.0)
            g_igst = float(r.get("g_igst") or 0.0)
            b_cgst = float(r.get("b_cgst") or 0.0)
            g_cgst = float(r.get("g_cgst") or 0.0)
            b_sgst = float(r.get("b_sgst") or 0.0)
            g_sgst = float(r.get("g_sgst") or 0.0)

            summary["total_books_itc"] += b_tax
            summary["total_2b_itc"] += g_tax

            summary["igst"]["books"] += b_igst
            summary["igst"]["gst"] += g_igst
            summary["cgst"]["books"] += b_cgst
            summary["cgst"]["gst"] += g_cgst
            summary["sgst"]["books"] += b_sgst
            summary["sgst"]["gst"] += g_sgst

            if status in ["EXACT", "HIGH_CONFIDENCE"]:
                summary["matched_count"] += 1
                matched_tax = min(b_tax, g_tax)
                summary["matched_itc"] += matched_tax
                summary["igst"]["matched"] += min(b_igst, g_igst)
                summary["cgst"]["matched"] += min(b_cgst, g_cgst)
                summary["sgst"]["matched"] += min(b_sgst, g_sgst)

            elif status in ["PROBABLE", "PARTIAL", "MISMATCH"]:
                summary["mismatched_count"] += 1
                diff = abs(b_tax - g_tax)
                summary["itc_at_risk"] += diff

            elif status == "BOOKS_ONLY":
                summary["books_only_count"] += 1
                summary["books_only_itc"] += b_tax
                summary["itc_at_risk"] += b_tax

            elif status == "GSTR_ONLY":
                summary["gst_only_count"] += 1
                summary["gst_only_itc"] += g_tax

        # Rounding
        summary["total_books_itc"] = round(summary["total_books_itc"], 2)
        summary["total_2b_itc"] = round(summary["total_2b_itc"], 2)
        summary["matched_itc"] = round(summary["matched_itc"], 2)
        summary["books_only_itc"] = round(summary["books_only_itc"], 2)
        summary["gst_only_itc"] = round(summary["gst_only_itc"], 2)
        summary["itc_at_risk"] = round(summary["itc_at_risk"], 2)

        if summary["total_count"] > 0:
            summary["match_pct"] = round((summary["matched_count"] / summary["total_count"]) * 100, 1)

        return summary
