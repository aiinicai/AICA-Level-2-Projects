from typing import List, Dict, Any
from collections import defaultdict
from app.database.models import SupplierMetricsModel


class SupplierEngine:
    """Computes supplier-wise compliance metrics and Supplier Reliability Score (0-100)."""

    @staticmethod
    def compute_supplier_metrics(gstin_id: int, reco_results: List[Dict[str, Any]]) -> List[SupplierMetricsModel]:
        """Calculates supplier reliability scores and risk metrics."""
        supplier_map = defaultdict(lambda: {
            "name": "",
            "books_cnt": 0,
            "gst_cnt": 0,
            "matched_cnt": 0,
            "mismatched_cnt": 0,
            "missing_cnt": 0,
            "books_itc": 0.0,
            "gst_itc": 0.0,
            "itc_at_risk": 0.0
        })

        for r in reco_results:
            b_gstin = r.get("b_gstin")
            g_gstin = r.get("g_gstin")
            gstin = b_gstin or g_gstin
            if not gstin:
                continue

            supplier_name = r.get("b_supplier") or r.get("g_supplier") or gstin
            s_dict = supplier_map[gstin]
            if not s_dict["name"]:
                s_dict["name"] = supplier_name

            status = r.get("match_status", "")
            b_tax = float(r.get("b_tax") or 0.0)
            g_tax = float(r.get("g_tax") or 0.0)

            if r.get("books_id"):
                s_dict["books_cnt"] += 1
                s_dict["books_itc"] += b_tax
            if r.get("gst_id"):
                s_dict["gst_cnt"] += 1
                s_dict["gst_itc"] += g_tax

            if status in ["EXACT", "HIGH_CONFIDENCE"]:
                s_dict["matched_cnt"] += 1
            elif status in ["PROBABLE", "PARTIAL", "MISMATCH"]:
                s_dict["mismatched_cnt"] += 1
                s_dict["itc_at_risk"] += abs(b_tax - g_tax)
            elif status == "BOOKS_ONLY":
                s_dict["missing_cnt"] += 1
                s_dict["itc_at_risk"] += b_tax

        metrics = []
        for gstin, data in supplier_map.items():
            total_invs = data["books_cnt"] + data["gst_cnt"]
            if total_invs == 0:
                continue

            # Reliability Score Formula (0-100):
            # Base 100 - (missing % * 60) - (mismatched % * 40)
            match_ratio = (data["matched_cnt"] / max(1, data["books_cnt"]))
            missing_ratio = (data["missing_cnt"] / max(1, data["books_cnt"]))
            mismatch_ratio = (data["mismatched_cnt"] / max(1, data["books_cnt"]))

            score = 100.0 - (missing_ratio * 60.0) - (mismatch_ratio * 30.0)
            score = max(0.0, min(100.0, round(score, 1)))

            metrics.append(SupplierMetricsModel(
                gstin_id=gstin_id,
                supplier_gstin=gstin,
                supplier_name=data["name"],
                books_count=data["books_cnt"],
                gst_count=data["gst_cnt"],
                matched_count=data["matched_cnt"],
                mismatched_count=data["mismatched_cnt"],
                missing_count=data["missing_cnt"],
                total_books_itc=round(data["books_itc"], 2),
                total_gst_itc=round(data["gst_itc"], 2),
                itc_at_risk=round(data["itc_at_risk"], 2),
                reliability_score=score
            ))

        return metrics
