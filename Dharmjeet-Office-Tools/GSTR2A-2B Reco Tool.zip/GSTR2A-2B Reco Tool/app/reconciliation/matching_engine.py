import json
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime
from rapidfuzz import fuzz
from app.reconciliation.normalizer import clean_gstin, normalize_invoice_number
from app.reconciliation.candidate_blocker import CandidateBlocker
from app.reconciliation.duplicate_engine import DuplicateEngine
from app.database.models import RecoResultModel


class MatchingEngine:
    """
    8-Level Hierarchical Multi-Stage Reconciliation Engine for GSTR-2A/2B vs Books.
    Provides transparent scoring and explainability for every transaction.
    """

    def __init__(
        self,
        date_tolerance_days: int = 3,
        amount_tolerance_rs: float = 1.0,
        amount_tolerance_pct: float = 0.01,
        fuzzy_threshold_high: float = 90.0,
        fuzzy_threshold_medium: float = 80.0
    ):
        self.date_tol_days = date_tolerance_days
        self.amt_tol_rs = amount_tolerance_rs
        self.amt_tol_pct = amount_tolerance_pct
        self.fuzzy_high = fuzzy_threshold_high
        self.fuzzy_med = fuzzy_threshold_medium

    def reconcile(
        self,
        period_id: int,
        books_list: List[Dict[str, Any]],
        gst_list: List[Dict[str, Any]]
    ) -> List[RecoResultModel]:
        """Runs multi-stage matching on Books and GST lists."""
        results: List[RecoResultModel] = []

        # 1. First, detect duplicates
        dup_books_ids, dup_gst_ids, dup_results = DuplicateEngine.detect_duplicates(books_list, gst_list)
        results.extend(dup_results)

        # Filter out duplicates for matching
        active_books = [b for b in books_list if b["id"] not in dup_books_ids]
        active_gst = [g for g in gst_list if g["id"] not in dup_gst_ids]

        matched_books = set()
        matched_gst = set()

        # 2. Block candidates by GSTIN
        gstin_blocks = CandidateBlocker.block_by_gstin(active_books, active_gst)

        for gstin, (b_recs, g_recs) in gstin_blocks.items():
            if not b_recs or not g_recs:
                continue

            # Run Level 1 to 8 hierarchy for this GSTIN block
            for b in b_recs:
                if b["id"] in matched_books:
                    continue

                best_candidate = None
                best_level = None
                best_score = 0.0
                best_reco = None

                for g in g_recs:
                    if g["id"] in matched_gst:
                        continue

                    reco_candidate = self._evaluate_pair(b, g)
                    if reco_candidate and reco_candidate.match_score > best_score:
                        best_score = reco_candidate.match_score
                        best_candidate = g
                        best_level = reco_candidate.matching_level
                        best_reco = reco_candidate

                # Threshold cutoffs for automatic matching
                if best_reco and best_score >= 60.0:
                    matched_books.add(b["id"])
                    matched_gst.add(best_candidate["id"])
                    best_reco.period_id = period_id
                    results.append(best_reco)

        # 3. Create records for unmatched Books invoices (BOOKS ONLY / GREY)
        for b in active_books:
            if b["id"] not in matched_books:
                results.append(RecoResultModel(
                    period_id=period_id,
                    books_id=b["id"],
                    gst_id=None,
                    match_status="BOOKS_ONLY",
                    match_score=0.0,
                    matching_level="UNMATCHED_BOOKS",
                    diff_amount=b["invoice_value"],
                    diff_tax=b["total_tax"],
                    explanation=f"Invoice present in Books (Inv {b['invoice_number']}, ₹{b['invoice_value']:,.2f}) but missing in GSTR-2B filing.",
                    recommendation="Follow up with supplier to upload invoice or check pending carry-forward status.",
                    user_action="OPEN"
                ))

        # 4. Create records for unmatched GST invoices (2B ONLY / BLUE)
        for g in active_gst:
            if g["id"] not in matched_gst:
                results.append(RecoResultModel(
                    period_id=period_id,
                    books_id=None,
                    gst_id=g["id"],
                    match_status="GSTR_ONLY",
                    match_score=0.0,
                    matching_level="UNMATCHED_GST",
                    diff_amount=g["invoice_value"],
                    diff_tax=g["total_tax"],
                    explanation=f"Invoice uploaded in GSTR-2B by supplier {g['supplier_gstin']} (Inv {g['invoice_number']}, ₹{g['invoice_value']:,.2f}) but not recorded in Books.",
                    recommendation="Verify purchase ledger or post missing purchase entry.",
                    user_action="OPEN"
                ))

        return results

    def _evaluate_pair(self, b: Dict[str, Any], g: Dict[str, Any]) -> Optional[RecoResultModel]:
        """Evaluates a pair of Books and GST records across the 8 levels."""
        b_inv = b["invoice_number"]
        g_inv = g["invoice_number"]
        b_norm = b["normalized_inv_no"]
        g_norm = g["normalized_inv_no"]

        b_val = b["invoice_value"]
        g_val = g["invoice_value"]
        diff_amt = round(abs(b_val - g_val), 2)

        b_tax = b["total_tax"]
        g_tax = g["total_tax"]
        diff_tax = round(abs(b_tax - g_tax), 2)

        b_date_str = b["invoice_date"]
        g_date_str = g["invoice_date"]
        days_diff = self._calc_date_diff(b_date_str, g_date_str)

        inv_sim = round(float(fuzz.WRatio(b_inv, g_inv)), 1)
        norm_inv_sim = round(float(fuzz.WRatio(b_norm, g_norm)), 1)

        is_gstin_exact = (clean_gstin(b["supplier_gstin"]) == clean_gstin(g["supplier_gstin"]))
        is_amt_exact = (diff_amt <= 0.05)
        is_amt_within_tol = self._is_amount_within_tol(b_val, g_val)
        is_date_exact = (days_diff == 0)
        is_date_within_tol = (days_diff <= self.date_tol_days)

        matched_f = []
        mismatched_f = []
        if is_gstin_exact: matched_f.append("GSTIN")
        else: mismatched_f.append("GSTIN")

        if b_inv.strip().upper() == g_inv.strip().upper(): matched_f.append("Invoice Number")
        elif b_norm == g_norm: matched_f.append("Normalized Invoice Number")
        else: mismatched_f.append("Invoice Number")

        if is_date_exact: matched_f.append("Invoice Date")
        else: mismatched_f.append("Invoice Date")

        if is_amt_exact: matched_f.append("Invoice Value")
        else: mismatched_f.append("Invoice Value")

        # --- LEVEL 1: EXACT MATCH ---
        if is_gstin_exact and (b_inv.strip().upper() == g_inv.strip().upper()) and is_date_exact and is_amt_exact and diff_tax <= 0.05:
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="EXACT",
                match_score=100.0,
                matching_level="LEVEL_1",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps([]),
                diff_amount=0.0,
                diff_tax=0.0,
                diff_days=0,
                inv_similarity=100.0,
                explanation="✓ Supplier GSTIN exact\n✓ Invoice Number exact\n✓ Invoice Date exact\n✓ Invoice Value & Tax exact",
                recommendation="Exact Match — High Confidence. Auto-accepted.",
                user_action="ACCEPTED"
            )

        # --- LEVEL 2: NORMALIZED INVOICE NUMBER MATCH ---
        if is_gstin_exact and (b_norm == g_norm) and is_amt_within_tol:
            expl = f"✓ Supplier GSTIN exact\n✓ Invoice Number matched after normalization ('{b_inv}' vs '{g_inv}')\n✓ Invoice Value matched (₹{b_val:,.2f})"
            if not is_date_exact:
                expl += f"\n⚠ Date differs by {days_diff} day(s) ('{b_date_str}' vs '{g_date_str}')"
            
            status = "HIGH_CONFIDENCE" if is_date_within_tol else "PROBABLE"
            score = 98.0 if is_date_within_tol else 92.0
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status=status,
                match_score=score,
                matching_level="LEVEL_2",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=norm_inv_sim,
                explanation=expl,
                recommendation="High confidence match after invoice number normalization.",
                user_action="ACCEPTED" if status == "HIGH_CONFIDENCE" else "OPEN"
            )

        # --- LEVEL 3: INVOICE NUMBER + DATE TOLERANCE ---
        if is_gstin_exact and (b_inv.strip().upper() == g_inv.strip().upper() or b_norm == g_norm) and is_date_within_tol and is_amt_within_tol:
            expl = f"✓ Supplier GSTIN exact\n✓ Invoice Number match\n✓ Date within tolerance ({days_diff} day difference)\n✓ Invoice Value matched within tolerance"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="HIGH_CONFIDENCE",
                match_score=94.0,
                matching_level="LEVEL_3",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Match with minor date variation.",
                user_action="ACCEPTED"
            )

        # --- LEVEL 4: DATE + AMOUNT MATCH (Invoice number formatting difference) ---
        if is_gstin_exact and is_date_within_tol and is_amt_exact and (inv_sim >= 60.0 or norm_inv_sim >= 60.0):
            expl = f"✓ Supplier GSTIN exact\n✓ Date & Invoice Amount exact (₹{b_val:,.2f})\n⚠ Invoice number differs slightly ('{b_inv}' vs '{g_inv}', similarity {inv_sim}%)"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="PROBABLE",
                match_score=88.0,
                matching_level="LEVEL_4",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Probable match — Review invoice number formatting.",
                user_action="OPEN"
            )

        # --- LEVEL 5: TAXABLE + TAX COMPONENT MATCH ---
        b_taxable = b["taxable_value"]
        g_taxable = g["taxable_value"]
        diff_taxable = abs(b_taxable - g_taxable)

        if is_gstin_exact and diff_taxable <= 1.0 and diff_tax <= 1.0 and (inv_sim >= 50.0):
            expl = f"✓ Supplier GSTIN exact\n✓ Taxable Value exact (₹{b_taxable:,.2f}) & Tax exact (₹{b_tax:,.2f})\n⚠ Total invoice value differs by ₹{diff_amt:,.2f}"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="PROBABLE",
                match_score=84.0,
                matching_level="LEVEL_5",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Taxable & Tax components match. Review invoice value difference.",
                user_action="OPEN"
            )

        # --- LEVEL 6: FUZZY INVOICE NUMBER MATCH ---
        if is_gstin_exact and inv_sim >= self.fuzzy_high and is_amt_within_tol:
            expl = f"✓ Supplier GSTIN exact\n✓ Fuzzy Invoice Number {inv_sim}% similarity ('{b_inv}' vs '{g_inv}')\n✓ Invoice Value matched"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="PROBABLE",
                match_score=80.0,
                matching_level="LEVEL_6",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Fuzzy invoice match — Requires CA/User verification.",
                user_action="OPEN"
            )

        # --- LEVEL 7: FUZZY INV + PROXIMITY DATE + AMOUNT TOLERANCE ---
        if is_gstin_exact and (inv_sim >= self.fuzzy_med or norm_inv_sim >= self.fuzzy_med) and days_diff <= 7 and (diff_amt <= (0.02 * b_val) or diff_amt <= 50.0):
            expl = f"✓ Supplier GSTIN exact\n⚠ Invoice Number {inv_sim}% similarity ('{b_inv}' vs '{g_inv}')\n⚠ Date differs by {days_diff} days\n⚠ Invoice value differs by ₹{diff_amt:,.2f}"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="PARTIAL",
                match_score=72.0,
                matching_level="LEVEL_7",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Partial match — Verify amount and date difference.",
                user_action="OPEN"
            )

        # --- LEVEL 8: SUPPLIER NAME + GSTIN + SIMILARITY ---
        if is_gstin_exact and is_amt_within_tol and days_diff <= 15:
            expl = f"✓ Supplier GSTIN exact\n⚠ Invoice Number differs ('{b_inv}' vs '{g_inv}')\n✓ Invoice Value matched (₹{b_val:,.2f})"
            return RecoResultModel(
                books_id=b["id"],
                gst_id=g["id"],
                match_status="PARTIAL",
                match_score=64.0,
                matching_level="LEVEL_8",
                matched_fields=json.dumps(matched_f),
                mismatched_fields=json.dumps(mismatched_f),
                diff_amount=diff_amt,
                diff_tax=diff_tax,
                diff_days=days_diff,
                inv_similarity=inv_sim,
                explanation=expl,
                recommendation="Low confidence partial candidate.",
                user_action="OPEN"
            )

        return None

    def _is_amount_within_tol(self, val1: float, val2: float) -> bool:
        diff = abs(val1 - val2)
        if diff <= self.amt_tol_rs:
            return True
        pct_diff = (diff / val1) if val1 > 0 else 0
        return pct_diff <= self.amt_tol_pct

    @staticmethod
    def _calc_date_diff(d1_str: str, d2_str: str) -> int:
        if not d1_str or not d2_str:
            return 999
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
            try:
                dt1 = datetime.strptime(d1_str[:10], fmt)
                dt2 = datetime.strptime(d2_str[:10], fmt)
                return abs((dt1 - dt2).days)
            except ValueError:
                pass
        return 999
