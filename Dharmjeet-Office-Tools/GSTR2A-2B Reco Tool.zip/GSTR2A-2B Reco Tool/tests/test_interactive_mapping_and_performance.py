import unittest
import os
import tempfile
import pandas as pd
from PySide6.QtWidgets import QApplication
from app.database.connection import DatabaseManager
from app.database.repository import Repository
from app.database.models import ClientModel, GSTINModel
from app.ui.views.import_view import ImportView
from app.ui.views.imported_data_view import ImportedDataView
from app.importers.excel_importer import ExcelImporter

# Ensure QApplication exists for GUI widget tests
app = QApplication.instance() or QApplication([])


class TestInteractiveMappingAndPerformance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db_fd, cls.db_path = tempfile.mkstemp(suffix=".db")
        os.close(cls.db_fd)
        cls.db_manager = DatabaseManager(cls.db_path)
        cls.repo = Repository(cls.db_manager)

        # Setup test client, gstin, fy, period
        c_id = cls.repo.create_client(ClientModel(name="Test Org", pan="ABCDE1234F"))
        g_id = cls.repo.add_gstin(GSTINModel(client_id=c_id, gstin="27ABCDE1234F1Z5", state="Maharashtra"))
        fy_id = cls.repo.get_or_create_fy(g_id, "2026-27")
        cls.period_id, _ = cls.repo.get_or_create_period(fy_id, "April 2026")

        # Create a sample excel file with non-standard column headers to test interactive mapping
        cls.test_excel = os.path.join(tempfile.gettempdir(), "test_custom_columns.xlsx")
        df_data = {
            "Vendor Tax ID": ["27AAAAA1234A1Z5", "27BBBBB5678B2Z6"],
            "Bill Reference": ["INV/2026/001", "INV/2026/002"],
            "Bill Date": ["2026-04-10", "2026-04-12"],
            "Assessable Value": [10000.0, 20000.0],
            "Total Bill Value": [11800.0, 23600.0],
            "IGST Amt": [1800.0, 3600.0],
            "CGST Amt": [0.0, 0.0],
            "SGST Amt": [0.0, 0.0]
        }
        pd.DataFrame(df_data).to_excel(cls.test_excel, index=False)

    @classmethod
    def tearDownClass(cls):
        try:
            if os.path.exists(cls.db_path):
                os.remove(cls.db_path)
            if os.path.exists(cls.test_excel):
                os.remove(cls.test_excel)
        except Exception:
            pass

    def test_import_view_preview_and_interactive_mapping(self):
        navigated = []
        view = ImportView(
            repository=self.repo,
            get_current_period_cb=lambda: self.period_id,
            on_navigate_register_cb=lambda: navigated.append(True)
        )

        # 1. Test previewing file initializes table without AttributeError
        view.selected_file = self.test_excel
        view.preview_file(self.test_excel)

        # Verify mapping table populated
        self.assertGreater(view.table_preview.rowCount(), 0)
        self.assertIn("Vendor Tax ID", view.available_columns)
        self.assertIn("Bill Reference", view.available_columns)

        # 2. Test interactive dropdown correction
        # Let's say user manually corrects/maps "supplier_gstin" -> "Vendor Tax ID"
        row_idx = 0  # supplier_gstin row
        combo = view.table_preview.cellWidget(row_idx, 1)
        self.assertIsNotNone(combo)

        combo.setCurrentText("Vendor Tax ID")
        self.assertEqual(view.current_mapping.get("supplier_gstin"), "Vendor Tax ID")

        # Verify sample value cell updated
        sample_item = view.table_preview.item(row_idx, 2)
        self.assertIsNotNone(sample_item)
        self.assertIn("27AAAAA1234A1Z5", sample_item.text())

        # 3. Test Control Totals button callback
        view.on_view_control_totals_clicked()
        self.assertTrue(navigated[0])

    def test_custom_column_mapping_import(self):
        # Test importing with user-defined custom mapping
        custom_mapping = {
            "supplier_gstin": "Vendor Tax ID",
            "invoice_number": "Bill Reference",
            "invoice_date": "Bill Date",
            "taxable_value": "Assessable Value",
            "invoice_value": "Total Bill Value",
            "igst": "IGST Amt",
            "cgst": "CGST Amt",
            "sgst": "SGST Amt"
        }

        txs, errors, used_map = ExcelImporter.import_purchase_register(
            file_path=self.test_excel,
            column_mapping=custom_mapping
        )

        self.assertEqual(len(txs), 2)
        self.assertEqual(txs[0].supplier_gstin, "27AAAAA1234A1Z5")
        self.assertEqual(txs[0].invoice_number, "INV/2026/001")
        self.assertEqual(txs[0].taxable_value, 10000.0)
        self.assertEqual(txs[0].igst, 1800.0)

    def test_imported_data_view_fast_refresh(self):
        # Test ImportedDataView with debounce and fast batch table updates
        view = ImportedDataView(
            repository=self.repo,
            get_current_period_cb=lambda: self.period_id
        )

        view.refresh_data()
        self.assertTrue(view.table_control.updatesEnabled())
        self.assertTrue(view.table_data.updatesEnabled())


if __name__ == "__main__":
    unittest.main()
