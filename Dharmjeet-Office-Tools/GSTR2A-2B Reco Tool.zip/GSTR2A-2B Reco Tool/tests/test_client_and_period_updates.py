import unittest
import os
from pathlib import Path
from app.database.connection import DatabaseManager
from app.database.repository import Repository
from app.database.models import ClientModel, GSTINModel


class TestClientAndPeriodUpdates(unittest.TestCase):
    """Unit tests for Client deletion, GSTIN addition, and Quarterly/Yearly period creation."""

    def setUp(self):
        self.test_db = Path("test_temp_reco.db")
        if self.test_db.exists():
            try:
                os.remove(self.test_db)
            except PermissionError:
                pass
        self.db_manager = DatabaseManager(str(self.test_db))
        self.repo = Repository(self.db_manager)

    def tearDown(self):
        del self.repo
        del self.db_manager
        if self.test_db.exists():
            try:
                os.remove(self.test_db)
            except PermissionError:
                pass

    def test_create_and_delete_client_with_gstin(self):
        client = ClientModel(name="Test Client CA", trade_name="Test Enterprise", pan="AAACB1234B")
        client_id = self.repo.create_client(client)
        self.assertIsNotNone(client_id)

        gstin = GSTINModel(client_id=client_id, gstin="27AAACB1234B1Z2", state="Maharashtra", books_software="Tally")
        gstin_id = self.repo.add_gstin(gstin)
        self.assertIsNotNone(gstin_id)

        fy_id = self.repo.get_or_create_fy(gstin_id, "2026-27")
        p_id, _ = self.repo.get_or_create_period(fy_id, "Q1 (Apr-Jun 2026)")
        self.assertIsNotNone(p_id)

        # Test deleting client
        deleted = self.repo.delete_client(client_id)
        self.assertTrue(deleted)
        self.assertIsNone(self.repo.get_client(client_id))
        self.assertEqual(len(self.repo.get_gstins_for_client(client_id)), 0)

    def test_delete_gstin(self):
        client = ClientModel(name="Standalone Client", pan="AAACC1234C")
        client_id = self.repo.create_client(client)
        gstin = GSTINModel(client_id=client_id, gstin="07AAACC1234C1Z9", state="Delhi")
        gstin_id = self.repo.add_gstin(gstin)

        deleted = self.repo.delete_gstin(gstin_id)
        self.assertTrue(deleted)
        self.assertEqual(len(self.repo.get_gstins_for_client(client_id)), 0)

    def test_quarterly_and_yearly_periods(self):
        client_id = self.repo.create_client(ClientModel(name="Period Test Client"))
        gstin_id = self.repo.add_gstin(GSTINModel(client_id=client_id, gstin="09AAACD1234D1Z8"))

        fy_id = self.repo.get_or_create_fy(gstin_id, "2026-27")

        q1_id, _ = self.repo.get_or_create_period(fy_id, "Q1 (Apr-Jun 2026)")
        q2_id, _ = self.repo.get_or_create_period(fy_id, "Q2 (Jul-Sep 2026)")
        yearly_id, _ = self.repo.get_or_create_period(fy_id, "FY 2026-27 (Annual)")

        periods = self.repo.get_periods_for_fy(fy_id)
        period_names = [p["period_name"] for p in periods]

        self.assertIn("Q1 (Apr-Jun 2026)", period_names)
        self.assertIn("Q2 (Jul-Sep 2026)", period_names)
        self.assertIn("FY 2026-27 (Annual)", period_names)


if __name__ == "__main__":
    unittest.main()
