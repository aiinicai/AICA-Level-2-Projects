from app.reconciliation.matching_engine import MatchingEngine


def test_level_1_exact_match():
    engine = MatchingEngine()
    books = [{
        "id": 1, "supplier_gstin": "07AAAAA1234A1Z5", "invoice_number": "INV-1001",
        "normalized_inv_no": "INV1001", "invoice_date": "2026-04-10",
        "invoice_value": 118000.0, "total_tax": 18000.0, "taxable_value": 100000.0
    }]
    gst = [{
        "id": 101, "supplier_gstin": "07AAAAA1234A1Z5", "invoice_number": "INV-1001",
        "normalized_inv_no": "INV1001", "invoice_date": "2026-04-10",
        "invoice_value": 118000.0, "total_tax": 18000.0, "taxable_value": 100000.0
    }]

    results = engine.reconcile(1, books, gst)
    assert len(results) == 1
    res = results[0]
    assert res.match_status == "EXACT"
    assert res.match_score == 100.0
    assert res.matching_level == "LEVEL_1"


def test_level_2_normalized_match():
    engine = MatchingEngine()
    books = [{
        "id": 2, "supplier_gstin": "27BBBBB5678B2Z6", "invoice_number": "INV/2001/25-26",
        "normalized_inv_no": "INV2001", "invoice_date": "2026-04-12",
        "invoice_value": 59000.0, "total_tax": 9000.0, "taxable_value": 50000.0
    }]
    gst = [{
        "id": 102, "supplier_gstin": "27BBBBB5678B2Z6", "invoice_number": "INV-2001-25-26",
        "normalized_inv_no": "INV2001", "invoice_date": "2026-04-12",
        "invoice_value": 59000.0, "total_tax": 9000.0, "taxable_value": 50000.0
    }]

    results = engine.reconcile(1, books, gst)
    assert len(results) == 1
    res = results[0]
    assert res.match_status == "HIGH_CONFIDENCE"
    assert res.matching_level == "LEVEL_2"
