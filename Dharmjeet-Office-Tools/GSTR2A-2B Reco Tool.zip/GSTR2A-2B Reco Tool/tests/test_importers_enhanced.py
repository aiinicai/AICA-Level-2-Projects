import unittest
import os
import json
import pandas as pd
from app.importers.column_mapper import ColumnMapper
from app.importers.excel_importer import ExcelImporter
from app.importers.json_importer import JSONImporter


class TestImportersEnhanced(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_dir = os.path.join(os.path.dirname(__file__), "test_data_temp")
        os.makedirs(cls.test_dir, exist_ok=True)

        # 1. Tally Columnar Register (Header at row 4)
        cls.tally_col_file = os.path.join(cls.test_dir, "Tally_Columnar.xlsx")
        tally_col_data = [
            ["ABC TEXTILES PRIVATE LIMITED", "", "", "", "", "", "", "", "", ""],
            ["Plot 45, MIDC Industrial Area, Andheri East, Mumbai", "", "", "", "", "", "", "", "", ""],
            ["Purchase Register", "", "", "", "", "", "", "", "", ""],
            ["For 01-Apr-2026 to 30-Apr-2026", "", "", "", "", "", "", "", "", ""],
            ["Date", "Particulars", "Vch Type", "Vch No.", "GSTIN/UIN", "Gross Total", "Taxable Value", "Integrated Tax", "Central Tax", "State Tax"],
            ["10-Apr-2026", "Alpha Supplies Ltd", "Purchase", "PUR/101", "27AAAAA1234A1Z5", 118000.0, 100000.0, 18000.0, 0.0, 0.0],
            ["14-Apr-2026", "Beta Traders", "Purchase", "PUR/102", "27BBBBB5678B2Z6", 59000.0, 50000.0, 0.0, 4500.0, 4500.0],
            ["18-Apr-2026", "Gamma Systems", "Purchase", "PUR/103", "27CCCCC9012C3Z7", 88500.0, 75000.0, 13500.0, 0.0, 0.0],
            ["", "Grand Total", "", "", "", 265500.0, 225000.0, 31500.0, 4500.0, 4500.0]
        ]
        pd.DataFrame(tally_col_data).to_excel(cls.tally_col_file, header=False, index=False, sheet_name="Purchase Register")

        # 2. Tally Supplier Invoice Details (Header at row 3)
        cls.tally_sup_file = os.path.join(cls.test_dir, "Tally_Supplier_Inv.xlsx")
        tally_sup_data = [
            ["GLOBAL TRADING CO", "", "", "", "", "", "", "", "", "", ""],
            ["Purchase Register with Supplier Invoices", "", "", "", "", "", "", "", "", "", ""],
            ["Period: April 2026", "", "", "", "", "", "", "", "", "", ""],
            ["Date", "Particulars", "Voucher Type", "Voucher No", "Supplier Invoice No.", "Supplier Invoice Date", "GSTIN / UIN", "Total Amount", "Taxable Amount", "IGST", "CGST", "SGST"],
            ["05-04-2026", "Delta Heavy Eng", "Purchase", "1", "INV-8899", "04-04-2026", "27DDDDD3456D4Z8", 23600.0, 20000.0, 3600.0, 0.0, 0.0],
            ["22-04-2026", "Epsilon Info", "Purchase", "2", "EP/2026/45", "20-04-2026", "27EEEEE7890E5Z9", 11800.0, 10000.0, 0.0, 900.0, 900.0],
            ["Total", "", "", "", "", "", "", 35400.0, 30000.0, 3600.0, 900.0, 900.0]
        ]
        pd.DataFrame(tally_sup_data).to_excel(cls.tally_sup_file, header=False, index=False, sheet_name="Sheet1")

        # 3. Official GST Portal GSTR-2B Excel (Multi-Sheet: Readme, Summary, B2B, CDNR)
        cls.gstr_portal_file = os.path.join(cls.test_dir, "GSTR2B_Portal.xlsx")
        gstr_b2b_data = [
            ["GSTIN of Normal Taxpayer", "27ABCDE1234F1Z5", "", "", "", "", "", "", "", "", "", "", "", ""],
            ["Legal Name", "MY DEMO COMPANY", "", "", "", "", "", "", "", "", "", "", "", ""],
            ["Trade Name", "MY DEMO COMPANY", "", "", "", "", "", "", "", "", "", "", "", ""],
            ["Tax Period", "April 2026", "", "", "", "", "", "", "", "", "", "", "", ""],
            ["GSTIN of supplier", "Trade/Legal name", "Invoice number", "Invoice type", "Invoice Date", "Invoice Value(₹)", "Place of supply", "Supply Attract Reverse Charge", "Rate(%)", "Taxable Value (₹)", "Integrated Tax(₹)", "Central Tax(₹)", "State/UT Tax(₹)", "Cess(₹)", "GSTR-1/IFF/GSTR-5 Period", "GSTR-1/IFF/GSTR-5 Filing Date", "ITC Availability", "Reason", "Applicable % of Tax Rate", "Source"],
            ["27AAAAA1234A1Z5", "Alpha Supplies Ltd", "INV-101", "Regular", "10-Apr-2026", 118000.0, "27-Maharashtra", "N", 18.0, 100000.0, 18000.0, 0.0, 0.0, 0.0, "042026", "11-05-2026", "Y", "", 100.0, "GSTR-1"],
            ["27BBBBB5678B2Z6", "Beta Traders", "INV-102", "Regular", "14-Apr-2026", 59000.0, "27-Maharashtra", "N", 18.0, 50000.0, 0.0, 4500.0, 4500.0, 0.0, "042026", "11-05-2026", "Y", "", 100.0, "GSTR-1"]
        ]
        gstr_cdnr_data = [
            ["GSTIN of supplier", "Trade/Legal name", "Note type", "Note number", "Note Date", "Note Value(₹)", "Place of supply", "Supply Attract Reverse Charge", "Rate(%)", "Taxable Value (₹)", "Integrated Tax(₹)", "Central Tax(₹)", "State/UT Tax(₹)", "Cess(₹)"],
            ["27AAAAA1234A1Z5", "Alpha Supplies Ltd", "Credit", "CN-55", "25-Apr-2026", 11800.0, "27-Maharashtra", "N", 18.0, 10000.0, 1800.0, 0.0, 0.0, 0.0]
        ]
        with pd.ExcelWriter(cls.gstr_portal_file, engine='openpyxl') as writer:
            pd.DataFrame([["Instructions Sheet"]]).to_excel(writer, sheet_name="Read me", header=False, index=False)
            pd.DataFrame([["Summary Sheet"]]).to_excel(writer, sheet_name="GSTR-2B Summary", header=False, index=False)
            pd.DataFrame(gstr_b2b_data).to_excel(writer, sheet_name="B2B", header=False, index=False)
            pd.DataFrame(gstr_cdnr_data).to_excel(writer, sheet_name="B2B-CDNR", header=False, index=False)

        # 4. Official GST Portal GSTR-2B JSON (with itm_det)
        cls.gstr_json_file = os.path.join(cls.test_dir, "GSTR2B_Portal.json")
        json_content = {
            "gstin": "27ABCDE1234F1Z5",
            "fp": "042026",
            "gen_date": "14-05-2026",
            "docdata": {
                "b2b": [
                    {
                        "ctin": "27AAAAA1234A1Z5",
                        "trdnm": "Alpha Supplies Ltd",
                        "inv": [
                            {
                                "inum": "INV-101",
                                "idt": "10-04-2026",
                                "val": 118000.0,
                                "pos": "27",
                                "rchrg": "N",
                                "inv_typ": "R",
                                "itcavl": "Y",
                                "itms": [
                                    {
                                        "num": 1,
                                        "itm_det": {
                                            "rt": 18.0,
                                            "txval": 100000.0,
                                            "iamt": 18000.0,
                                            "camt": 0.0,
                                            "samt": 0.0,
                                            "csamt": 0.0
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "cdnr": [
                    {
                        "ctin": "27AAAAA1234A1Z5",
                        "trdnm": "Alpha Supplies Ltd",
                        "nt": [
                            {
                                "ntnum": "CN-55",
                                "ntdt": "25-04-2026",
                                "nt_typ": "C",
                                "val": 11800.0,
                                "pos": "27",
                                "rchrg": "N",
                                "itcavl": "Y",
                                "itms": [
                                    {
                                        "num": 1,
                                        "itm_det": {
                                            "rt": 18.0,
                                            "txval": 10000.0,
                                            "iamt": 1800.0,
                                            "camt": 0.0,
                                            "samt": 0.0,
                                            "csamt": 0.0
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }
        with open(cls.gstr_json_file, "w", encoding="utf-8") as f:
            json.dump(json_content, f, indent=2)

    @classmethod
    def tearDownClass(cls):
        import shutil
        if os.path.exists(cls.test_dir):
            shutil.rmtree(cls.test_dir, ignore_errors=True)

    def test_column_mapper_synonyms(self):
        """Tests that ColumnMapper auto-detects headers across all official formats."""
        # Official GST Portal columns
        gst_cols = [
            "GSTIN of supplier", "Trade/Legal name", "Invoice number", "Invoice type",
            "Invoice Date", "Invoice Value(₹)", "Place of supply", "Supply Attract Reverse Charge",
            "Rate(%)", "Taxable Value (₹)", "Integrated Tax(₹)", "Central Tax(₹)", "State/UT Tax(₹)",
            "Cess(₹)", "ITC Availability"
        ]
        m_gst = ColumnMapper.auto_detect(gst_cols)
        self.assertEqual(m_gst["supplier_gstin"], "GSTIN of supplier")
        self.assertEqual(m_gst["supplier_name"], "Trade/Legal name")
        self.assertEqual(m_gst["invoice_number"], "Invoice number")
        self.assertEqual(m_gst["invoice_date"], "Invoice Date")
        self.assertEqual(m_gst["taxable_value"], "Taxable Value (₹)")
        self.assertEqual(m_gst["igst"], "Integrated Tax(₹)")
        self.assertEqual(m_gst["cgst"], "Central Tax(₹)")
        self.assertEqual(m_gst["sgst"], "State/UT Tax(₹)")

        # Official GST Portal CDNR columns
        cdnr_cols = ["GSTIN of supplier", "Trade/Legal name", "Note number", "Note Date", "Note Value(₹)", "Taxable Value (₹)"]
        m_cdnr = ColumnMapper.auto_detect(cdnr_cols)
        self.assertEqual(m_cdnr["invoice_number"], "Note number")
        self.assertEqual(m_cdnr["invoice_date"], "Note Date")
        self.assertEqual(m_cdnr["invoice_value"], "Note Value(₹)")

        # Tally Columnar Register columns
        tally_cols = ["Date", "Particulars", "Vch Type", "Vch No.", "GSTIN/UIN", "Gross Total", "Taxable Value", "Integrated Tax", "Central Tax", "State Tax"]
        m_tally = ColumnMapper.auto_detect(tally_cols)
        self.assertEqual(m_tally["supplier_gstin"], "GSTIN/UIN")
        self.assertEqual(m_tally["supplier_name"], "Particulars")
        self.assertEqual(m_tally["invoice_number"], "Vch No.")
        self.assertEqual(m_tally["invoice_date"], "Date")
        self.assertEqual(m_tally["invoice_value"], "Gross Total")
        self.assertEqual(m_tally["taxable_value"], "Taxable Value")

    def test_tally_columnar_import(self):
        """Tests that Tally Columnar Excel imports all transactions and skips Grand Total row."""
        txs, errors, mapping = ExcelImporter.import_purchase_register(self.tally_col_file)
        self.assertEqual(len(txs), 3, f"Expected 3 transactions from Tally Columnar register, got {len(txs)}")
        self.assertEqual(txs[0].supplier_gstin, "27AAAAA1234A1Z5")
        self.assertEqual(txs[0].supplier_name, "Alpha Supplies Ltd")
        self.assertEqual(txs[0].invoice_number, "PUR/101")
        self.assertEqual(txs[0].taxable_value, 100000.0)
        self.assertEqual(txs[0].igst, 18000.0)
        self.assertEqual(txs[0].invoice_value, 118000.0)

    def test_tally_supplier_inv_import(self):
        """Tests that Tally register with Supplier Invoice No imports correctly."""
        txs, errors, mapping = ExcelImporter.import_purchase_register(self.tally_sup_file)
        self.assertEqual(len(txs), 2, f"Expected 2 transactions from Tally Supplier Inv register, got {len(txs)}")
        self.assertEqual(txs[0].invoice_number, "INV-8899")
        self.assertEqual(txs[0].taxable_value, 20000.0)
        self.assertEqual(txs[0].igst, 3600.0)
        self.assertEqual(txs[1].invoice_number, "EP/2026/45")
        self.assertEqual(txs[1].cgst, 900.0)
        self.assertEqual(txs[1].sgst, 900.0)

    def test_official_gstr2b_excel_import(self):
        """Tests that official multi-sheet GSTR-2B Excel imports B2B and CDNR sheets."""
        txs, errors = ExcelImporter.import_gstr2b_excel(self.gstr_portal_file)
        self.assertEqual(len(txs), 3, f"Expected 3 transactions from GSTR-2B Excel (2 B2B + 1 CDNR), got {len(txs)}")
        
        # Check B2B
        b2b_txs = [t for t in txs if t.doc_type == "B2B"]
        self.assertEqual(len(b2b_txs), 2)
        self.assertEqual(b2b_txs[0].supplier_name, "Alpha Supplies Ltd")
        self.assertEqual(b2b_txs[0].taxable_value, 100000.0)
        self.assertEqual(b2b_txs[0].igst, 18000.0)
        self.assertEqual(b2b_txs[1].cgst, 4500.0)
        self.assertEqual(b2b_txs[1].sgst, 4500.0)

        # Check CDNR
        cdnr_txs = [t for t in txs if t.doc_type == "CDNR"]
        self.assertEqual(len(cdnr_txs), 1)
        self.assertEqual(cdnr_txs[0].invoice_number, "CN-55")
        self.assertEqual(cdnr_txs[0].taxable_value, 10000.0)
        self.assertEqual(cdnr_txs[0].igst, 1800.0)

    def test_official_gstr2b_json_import(self):
        """Tests that official GST Portal JSON parses itm_det correctly with non-zero tax/taxable values."""
        txs, errors, meta = JSONImporter.import_gstr2b_json(self.gstr_json_file)
        self.assertEqual(len(txs), 2, f"Expected 2 transactions from GSTR-2B JSON, got {len(txs)}")
        self.assertEqual(meta["gstin"], "27ABCDE1234F1Z5")
        self.assertEqual(meta["fp"], "042026")
        self.assertEqual(meta["gen_date"], "14-05-2026")

        # Invoice 1
        inv1 = txs[0]
        self.assertEqual(inv1.supplier_gstin, "27AAAAA1234A1Z5")
        self.assertEqual(inv1.invoice_number, "INV-101")
        self.assertEqual(inv1.taxable_value, 100000.0)
        self.assertEqual(inv1.igst, 18000.0)
        self.assertEqual(inv1.total_tax, 18000.0)
        self.assertEqual(inv1.doc_type, "B2B")

        # Credit Note
        cn = txs[1]
        self.assertEqual(cn.invoice_number, "CN-55")
        self.assertEqual(cn.taxable_value, 10000.0)
        self.assertEqual(cn.igst, 1800.0)
        self.assertEqual(cn.doc_type, "CDNR")


if __name__ == "__main__":
    unittest.main()
