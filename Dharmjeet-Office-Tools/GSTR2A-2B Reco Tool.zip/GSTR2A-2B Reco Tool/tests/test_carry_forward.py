from app.reconciliation.carry_forward import CarryForwardEngine


def test_carry_forward_matching():
    prev_books = [{
        "id": 99,
        "supplier_gstin": "29EEEEE7890E5Z9",
        "invoice_number": "INV-9001",
        "normalized_inv_no": "INV9001",
        "invoice_value": 141600.0,
        "total_tax": 21600.0,
        "carried_forward_from_period": "April 2026"
    }]

    current_gst = [{
        "id": 501,
        "supplier_gstin": "29EEEEE7890E5Z9",
        "invoice_number": "INV-9001",
        "normalized_inv_no": "INV9001",
        "invoice_value": 141600.0,
        "total_tax": 21600.0
    }]

    results, b_ids, g_ids = CarryForwardEngine.match_carried_forward(2, prev_books, current_gst)
    assert len(results) == 1
    assert b_ids == [99]
    assert g_ids == [501]
    assert results[0].matching_level == "SUBSEQUENT_2B_MATCH"
    assert results[0].match_status == "HIGH_CONFIDENCE"
