import unittest
import os
from app.database.connection import DatabaseManager
from app.database.repository import Repository
from app.database.models import ClientModel, GSTINModel, TransactionModel


class TestResetData(unittest.TestCase):
    def setUp(self):
        self.db_path = os.path.join(os.path.dirname(__file__), "test_reset_temp.db")
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        self.db_mgr = DatabaseManager(self.db_path)
        self.repo = Repository(self.db_mgr)

        # Setup Client, GSTIN, FY, Period
        client = ClientModel(name="Test Reset Client")
        client_id = self.repo.create_client(client)
        gstin_id = self.repo.add_gstin(GSTINModel(client_id=client_id, gstin="27AAAAA0000A1Z5"))
        fy_id = self.repo.get_or_create_fy(gstin_id, "2026-27")
        self.period_id, _ = self.repo.get_or_create_period(fy_id, "April 2026")

    def tearDown(self):
        if os.path.exists(self.db_path):
            try:
                os.remove(self.db_path)
            except Exception:
                pass

    def test_reset_data_workflow(self):
        # 1. Check initial summary is 0
        summary0 = self.repo.get_period_data_summary(self.period_id)
        self.assertEqual(summary0["books_count"], 0)
        self.assertEqual(summary0["gst_count"], 0)
        self.assertEqual(summary0["total_imported"], 0)

        # 2. Insert Books records
        tx_books = [
            TransactionModel(
                supplier_gstin="27BBBBB1111B1Z1",
                supplier_name="Vendor 1",
                invoice_number="INV-1",
                normalized_inv_no="INV1",
                invoice_date="2026-04-10",
                invoice_value=1180.0,
                taxable_value=1000.0,
                igst=180.0
            ),
            TransactionModel(
                supplier_gstin="27CCCCC2222C1Z2",
                supplier_name="Vendor 2",
                invoice_number="INV-2",
                normalized_inv_no="INV2",
                invoice_date="2026-04-12",
                invoice_value=2360.0,
                taxable_value=2000.0,
                igst=360.0
            )
        ]
        file_id_b = self.repo.register_import_file(self.period_id, "BOOKS", "books.xlsx", "hash1", 2)
        self.repo.insert_books_transactions(self.period_id, file_id_b, tx_books)

        # 3. Insert GST records
        tx_gst = [
            TransactionModel(
                supplier_gstin="27BBBBB1111B1Z1",
                supplier_name="Vendor 1",
                invoice_number="INV-1",
                normalized_inv_no="INV1",
                invoice_date="2026-04-10",
                invoice_value=1180.0,
                taxable_value=1000.0,
                igst=180.0
            )
        ]
        file_id_g = self.repo.register_import_file(self.period_id, "GSTR2B", "gstr2b.json", "hash2", 1)
        self.repo.insert_gst_transactions(self.period_id, file_id_g, "GSTR2B", tx_gst)

        # Verify summary counts
        summary1 = self.repo.get_period_data_summary(self.period_id)
        self.assertEqual(summary1["books_count"], 2)
        self.assertEqual(summary1["gst_count"], 1)
        self.assertEqual(summary1["files_count"], 2)
        self.assertEqual(summary1["total_imported"], 3)

        # 4. Reset Books Only
        res_b = self.repo.reset_period_data(self.period_id, target="BOOKS")
        self.assertEqual(res_b["books_deleted"], 2)
        summary2 = self.repo.get_period_data_summary(self.period_id)
        self.assertEqual(summary2["books_count"], 0)
        self.assertEqual(summary2["gst_count"], 1)
        self.assertEqual(summary2["total_imported"], 1)

        # 5. Reset All Remaining Data
        res_all = self.repo.reset_period_data(self.period_id, target="ALL")
        self.assertEqual(res_all["gst_deleted"], 1)
        summary3 = self.repo.get_period_data_summary(self.period_id)
        self.assertEqual(summary3["books_count"], 0)
        self.assertEqual(summary3["gst_count"], 0)
        self.assertEqual(summary3["files_count"], 0)
        self.assertEqual(summary3["total_imported"], 0)


if __name__ == "__main__":
    unittest.main()
