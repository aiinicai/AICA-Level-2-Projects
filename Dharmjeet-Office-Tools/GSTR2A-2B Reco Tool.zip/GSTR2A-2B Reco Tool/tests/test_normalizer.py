from app.reconciliation.normalizer import normalize_invoice_number, is_valid_gstin, clean_gstin


def test_normalize_invoice_number():
    assert normalize_invoice_number("INV/001/25-26") == "INV1"
    assert normalize_invoice_number("inv-001-25-26") == "INV1"
    assert normalize_invoice_number("000125") == "125"
    assert normalize_invoice_number("INV/2025-26/99") == "INV99"
    assert normalize_invoice_number("BILL-1001") == "BILL1001"


def test_gstin_validation():
    valid = "07AAAAA1234A1Z5"
    assert is_valid_gstin(valid) == True
    assert clean_gstin(" 07-AAAAA1234A1Z5 ") == valid
    assert is_valid_gstin("INVALID123") == False
