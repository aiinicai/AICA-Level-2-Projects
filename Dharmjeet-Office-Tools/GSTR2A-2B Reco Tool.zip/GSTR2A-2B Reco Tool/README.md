# Professional Offline GSTR-2A / GSTR-2B Reconciliation Desktop Application (CA Edition)

A production-grade, offline-first Windows desktop application built with Python 3.11+, PySide6, SQLite, pandas, rapidfuzz, openpyxl, and reportlab, designed specifically for Indian Chartered Accountants, tax professionals, accountants, and enterprise finance teams.

---

## Key Features

- **Strict Offline-First Security**: 100% offline execution. Client accounting data and GST portal filings stay on your local Windows PC. No external cloud servers or AI APIs are queried.
- **Client & GSTIN Hierarchy**: Supports `Client → GSTIN → Financial Year → Return Period` management with quick switching.
- **Universal Purchase Register Import**: Imports Tally, Busy, Marg, Excel Standard, and custom ERP purchase registers with auto-column detection and reusable custom mapping templates.
- **Official GST Portal Imports**: Directly imports GSTR-2A/2B Excel workbooks and official GST portal JSON downloads (parsing B2B, CDNR, B2BA, CDNRA, ISD sections).
- **8-Level Multi-Stage Matching Engine**:
  - **Level 1 — Exact Match**: GSTIN + Invoice Number + Date + Exact Tax & Invoice Value ($100\%$ score).
  - **Level 2 — Invoice Normalization**: Removes spaces, hyphens, slashes, backslashes, dots, leading zeros, and FY suffixes ($98\%$ score).
  - **Level 3 — Inv No + Date Tolerance**: GSTIN + Inv No + Date within $\pm 3$ days ($94\%$ score).
  - **Level 4 — Date + Amount Match**: GSTIN + Date + Invoice Value exact ($88\%$ score).
  - **Level 5 — Taxable + Tax Component Match**: Taxable value and IGST/CGST/SGST component match ($84\%$ score).
  - **Level 6 — Fuzzy Invoice Number Match**: RapidFuzz WRatio/Token Sort ($\ge 85\%$) ($80\%$ score).
  - **Level 7 — Fuzzy Inv + Proximity Date + Amount Tolerance**: Multi-field similarity scoring ($72\%$ score).
  - **Level 8 — Supplier Name + GSTIN Similarity**: Low confidence partial candidate ($64\%$ score).
- **Explainable Matching**: Outputs itemized evidence for every transaction (e.g. `✓ GSTIN exact`, `✓ Inv No 96% similar after normalization`, `⚠ Date differs by 2 days`).
- **Accounting Logic & Controls**:
  - **Duplicate Detection**: Flags intra-source and cross-period duplicate claims.
  - **Credit & Debit Note Linking**: Links B2B with CDNR, B2BA, CDNRA.
  - **Carry-Forward Engine**: Matches pending Books invoices from previous months with current/subsequent GSTR-2B filings.
  - **Supplier Reliability Score (0-100)**: Evaluates supplier filing timeliness and mismatch ratios.
  - **ITC Control Centre**: Segregates ITC into Claimable, Ineligible, RCM, Blocked, and At Risk.
- **Professional Reporting & CA Workpapers**:
  - Multi-tab Excel Workpapers (`.xlsx`) formatted with openpyxl (header styling, ₹ currency formatting, autofit column widths, freeze panes).
  - Professional PDF Reconciliation Audit Reports (`.pdf`) with CA sign-off blocks.
- **Data Protection & Audit Trail**:
  - Immutable local audit trail log.
  - Compressed ZIP database backup and restore with integrity verification.
  - Period locking to freeze finalized reconciliations.

---

## Quick Start & Installation

### Requirements
- Windows 10 or Windows 11 (64-bit)
- Python 3.11+ (or run standalone `.exe`)

### Step 1: Install Dependencies
Run the installation batch script:
```cmd
install.bat
```

### Step 2: Generate Sample Test Data
Generate sample Books and GSTR-2B Excel & JSON test files:
```cmd
python sample_data/generate_samples.py
```

### Step 3: Launch the Application
Run the desktop application launcher:
```cmd
run.bat
```

### Step 4: Build Standalone Windows Executable (.exe)
Create a standalone `GSTR_Reconciliation.exe` package with PyInstaller:
```cmd
build.bat
```
The compiled application will be generated in `dist/GSTR_Reconciliation/GSTR_Reconciliation.exe`.

---

## Project Structure

```
.
├── app/
│   ├── database/          # SQLite schema, connection, models, repository CRUD
│   ├── importers/         # Column mapper, Excel importer, JSON parser, validator
│   ├── reconciliation/    # Normalizer, candidate blocker, 8-level matching engine,
│   │                      # duplicate engine, carry forward, ITC engine, supplier score
│   ├── reports/           # openpyxl Excel exporter, ReportLab PDF generator
│   ├── security/          # Password hashing, role permissions, audit logging
│   ├── backup/            # Compressed ZIP database backup & restore
│   ├── ui/                # PySide6 desktop interface (MainWindow, Dashboard, Views)
│   └── main.py            # Application entrypoint & demo data seeder
├── sample_data/           # Sample Books & GSTR2B Excel/JSON datasets
├── tests/                 # Pytest automated unit & integrated test suite
├── install.bat            # Environment setup script
├── run.bat                # Application runner script
├── build.bat              # PyInstaller executable build script
└── requirements.txt       # Python dependencies
```

---

## Disclaimer

*This application is a reconciliation and analytical tool. Final determination of ITC eligibility must be made by the taxpayer or professional after considering the applicable provisions of the GST law, rules, notifications, circulars and relevant facts.*
