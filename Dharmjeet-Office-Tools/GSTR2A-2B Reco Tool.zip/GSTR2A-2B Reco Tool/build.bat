@echo off
echo =========================================================================
echo  Building GSTR_Reconciliation.exe Executable using PyInstaller
echo =========================================================================
echo.

if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)

pip install pyinstaller

pyinstaller --noconfirm --onedir --windowed ^
    --name "GSTR_Reconciliation" ^
    --add-data "sample_data;sample_data" ^
    --hidden-import "PySide6.QtCore" ^
    --hidden-import "PySide6.QtGui" ^
    --hidden-import "PySide6.QtWidgets" ^
    --hidden-import "pandas" ^
    --hidden-import "openpyxl" ^
    --hidden-import "rapidfuzz" ^
    --hidden-import "matplotlib" ^
    --hidden-import "reportlab" ^
    app/main.py

echo.
echo =========================================================================
echo  Build finished! Check the 'dist/GSTR_Reconciliation' directory.
echo =========================================================================
pause
