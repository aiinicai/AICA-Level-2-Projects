import os
import json
import pandas as pd


def generate_sample_data():
    sample_dir = os.path.dirname(os.path.abspath(__file__))

    # 1. Books Purchase Register (April 2026)
    books_data = [
        # Exact Match
        {"Party GSTIN": "07AAAAA1234A1Z5", "Party Name": "Alpha Traders Pvt Ltd", "Vch No.": "INV-1001", "Date": "2026-04-10", "Taxable Value": 100000, "Integrated Tax": 18000, "Central Tax": 0, "State Tax": 0, "Gross Total": 118000, "Voucher Type": "B2B"},
        # Normalized Inv Match
        {"Party GSTIN": "27BBBBB5678B2Z6", "Party Name": "Beta Logistics Ltd", "Vch No.": "INV/2001/25-26", "Date": "2026-04-12", "Taxable Value": 50000, "Integrated Tax": 0, "Central Tax": 4500, "State Tax": 4500, "Gross Total": 59000, "Voucher Type": "B2B"},
        # Date Mismatch (2 days)
        {"Party GSTIN": "06CCCCC9012C3Z7", "Party Name": "Gamma Infotech", "Vch No.": "INV-3001", "Date": "2026-04-15", "Taxable Value": 75000, "Integrated Tax": 13500, "Central Tax": 0, "State Tax": 0, "Gross Total": 88500, "Voucher Type": "B2B"},
        # Amount Mismatch (Books 50,000 vs 2B 52,000)
        {"Party GSTIN": "09DDDDD3456D4Z8", "Party Name": "Delta Heavy Engineering", "Vch No.": "INV-4001", "Date": "2026-04-18", "Taxable Value": 50000, "Integrated Tax": 9000, "Central Tax": 0, "State Tax": 0, "Gross Total": 59000, "Voucher Type": "B2B"},
        # Duplicate Invoice in Books
        {"Party GSTIN": "07AAAAA1234A1Z5", "Party Name": "Alpha Traders Pvt Ltd", "Vch No.": "INV-1001", "Date": "2026-04-10", "Taxable Value": 100000, "Integrated Tax": 18000, "Central Tax": 0, "State Tax": 0, "Gross Total": 118000, "Voucher Type": "B2B"},
        # Credit Note
        {"Party GSTIN": "07AAAAA1234A1Z5", "Party Name": "Alpha Traders Pvt Ltd", "Vch No.": "CN-5001", "Date": "2026-04-20", "Taxable Value": 10000, "Integrated Tax": 1800, "Central Tax": 0, "State Tax": 0, "Gross Total": 11800, "Voucher Type": "CDNR"},
        # Books Only (Missing in April 2B -> Carried forward to May 2B)
        {"Party GSTIN": "29EEEEE7890E5Z9", "Party Name": "Epsilon Services Ltd", "Vch No.": "INV-9001", "Date": "2026-04-25", "Taxable Value": 120000, "Integrated Tax": 21600, "Central Tax": 0, "State Tax": 0, "Gross Total": 141600, "Voucher Type": "B2B"}
    ]

    df_books = pd.DataFrame(books_data)
    books_file = os.path.join(sample_dir, "Books_Purchase_Register.xlsx")
    df_books.to_excel(books_file, index=False, sheet_name="Purchase Register")

    # 2. GSTR-2B Excel (April 2026)
    gstr_b2b_data = [
        # Exact Match
        {"GSTIN of Supplier": "07AAAAA1234A1Z5", "Trade/Legal Name": "Alpha Traders Pvt Ltd", "Invoice number": "INV-1001", "Invoice Date": "2026-04-10", "Taxable Value (₹)": 100000, "Integrated Tax (₹)": 18000, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Invoice Value (₹)": 118000, "ITC Available": "Y"},
        # Normalized Match (INV-2001-25-26)
        {"GSTIN of Supplier": "27BBBBB5678B2Z6", "Trade/Legal Name": "Beta Logistics Ltd", "Invoice number": "INV-2001-25-26", "Invoice Date": "2026-04-12", "Taxable Value (₹)": 50000, "Integrated Tax (₹)": 0, "Central Tax (₹)": 4500, "State/UT Tax (₹)": 4500, "Invoice Value (₹)": 59000, "ITC Available": "Y"},
        # Date Mismatch (2026-04-17)
        {"GSTIN of Supplier": "06CCCCC9012C3Z7", "Trade/Legal Name": "Gamma Infotech", "Invoice number": "INV-3001", "Invoice Date": "2026-04-17", "Taxable Value (₹)": 75000, "Integrated Tax (₹)": 13500, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Invoice Value (₹)": 88500, "ITC Available": "Y"},
        # Amount Mismatch (52,000 vs 50,000)
        {"GSTIN of Supplier": "09DDDDD3456D4Z8", "Trade/Legal Name": "Delta Heavy Engineering", "Invoice number": "INV-4001", "Invoice Date": "2026-04-18", "Taxable Value (₹)": 52000, "Integrated Tax (₹)": 9360, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Invoice Value (₹)": 61360, "ITC Available": "Y"},
        # 2B Only Invoice
        {"GSTIN of Supplier": "33FFFFF1122F6Z1", "Trade/Legal Name": "Zeta Tech Corp", "Invoice number": "INV-8001", "Invoice Date": "2026-04-22", "Taxable Value (₹)": 30000, "Integrated Tax (₹)": 5400, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Invoice Value (₹)": 35400, "ITC Available": "Y"}
    ]

    gstr_cdnr_data = [
        {"GSTIN of Supplier": "07AAAAA1234A1Z5", "Trade/Legal Name": "Alpha Traders Pvt Ltd", "Note number": "CN-5001", "Note Date": "2026-04-20", "Taxable Value (₹)": 10000, "Integrated Tax (₹)": 1800, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Note Value (₹)": 11800, "ITC Available": "Y"}
    ]

    gstr_file = os.path.join(sample_dir, "GSTR2B_April_2026.xlsx")
    with pd.ExcelWriter(gstr_file, engine='openpyxl') as writer:
        pd.DataFrame(gstr_b2b_data).to_excel(writer, sheet_name="B2B", index=False)
        pd.DataFrame(gstr_cdnr_data).to_excel(writer, sheet_name="CDNR", index=False)

    # 3. GSTR-2B JSON (April 2026)
    json_data = {
        "gstin": "07AAAAA9999A1Z1",
        "fp": "042026",
        "gen_date": "14-05-2026",
        "docdata": {
            "b2b": [
                {
                    "ctin": "07AAAAA1234A1Z5",
                    "trdnm": "Alpha Traders Pvt Ltd",
                    "inv": [
                        {
                            "inum": "INV-1001",
                            "idt": "10-04-2026",
                            "val": 118000.0,
                            "pos": "07",
                            "rchrg": "N",
                            "itcavl": "Y",
                            "itms": [{"num": 1, "item_det": {"rt": 18.0, "txval": 100000.0, "iamt": 18000.0, "camt": 0.0, "samt": 0.0, "csamt": 0.0}}]
                        }
                    ]
                }
            ]
        }
    }
    json_file = os.path.join(sample_dir, "GSTR2B_April_2026.json")
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2)

    # 4. GSTR-2B May 2026 (Contains carried-forward invoice INV-9001)
    gstr_may_b2b = [
        {"GSTIN of Supplier": "29EEEEE7890E5Z9", "Trade/Legal Name": "Epsilon Services Ltd", "Invoice number": "INV-9001", "Invoice Date": "2026-04-25", "Taxable Value (₹)": 120000, "Integrated Tax (₹)": 21600, "Central Tax (₹)": 0, "State/UT Tax (₹)": 0, "Invoice Value (₹)": 141600, "ITC Available": "Y"}
    ]
    may_file = os.path.join(sample_dir, "GSTR2B_May_2026.xlsx")
    with pd.ExcelWriter(may_file, engine='openpyxl') as writer:
        pd.DataFrame(gstr_may_b2b).to_excel(writer, sheet_name="B2B", index=False)

    print("Sample data generated successfully!")


if __name__ == "__main__":
    generate_sample_data()
