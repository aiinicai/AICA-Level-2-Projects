@echo off
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)
python -m app.main
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited with error code %ERRORLEVEL%.
    pause
)
