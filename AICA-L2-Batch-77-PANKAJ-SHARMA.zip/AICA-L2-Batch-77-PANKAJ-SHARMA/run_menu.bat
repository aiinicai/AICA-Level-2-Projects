@echo off
setlocal
title H P M S & Associates - CA Firm Practice Management System

:MENU
cls
echo ============================================================
echo      H P M S & Associates - Practice Management System
echo ============================================================
echo.
echo   [1] Launch Web Application (Streamlit)
echo   [2] Load Demo Data (Fictional Clients, Tasks & Bills)
echo   [3] Run Acceptance Tests (test_scenarios.py)
echo   [4] Exit
echo.
echo ============================================================
set /p choice="Select an option (1-4): "

if "%choice%"=="1" goto START_APP
if "%choice%"=="2" goto LOAD_DEMO
if "%choice%"=="3" goto RUN_TESTS
if "%choice%"=="4" goto EXIT_APP

echo Invalid choice. Please try again.
ping -n 2 127.0.0.1 >nul
goto MENU

:START_APP
cls
echo ============================================================
echo Launching H P M S Practice Management System...
echo ============================================================
echo.
echo Checking dependencies...
pip install -r requirements.txt
echo.
echo Application will open at http://localhost:8501
echo Press Ctrl+C to return to menu.
echo.
streamlit run app.py
echo.
pause
goto MENU

:LOAD_DEMO
cls
echo ============================================================
echo Loading Demo Data...
echo ============================================================
echo.
python database.py --demo
echo.
pause
goto MENU

:RUN_TESTS
cls
echo ============================================================
echo Running Acceptance Test Scenarios...
echo ============================================================
echo.
python test_scenarios.py
echo.
pause
goto MENU

:EXIT_APP
exit /b 0
