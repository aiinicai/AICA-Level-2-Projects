# H P M S & Associates — Project Prompts Reference Document

This document contains a complete compilation of all user prompts and instructions used to build, refine, and customize the **H P M S & Associates — CA Firm Practice Management System** web application.

---

## 📌 Prompt 1: Main Project Requirements & Architecture

```text
# ROLE

Act as an experienced Python developer and business-process consultant familiar with the day-to-day working of small Chartered Accountant firms in India.

Build a simple, professional and fully working web application for:

# H P M S & Associates

## CA Firm Practice Management – Task, Client, Billing & Collection Tracker

The application is intended for a small Chartered Accountant firm with approximately 5–10 team members.

The primary objective is:

Client → Task → Delegation → Due Date → Work Status → Remarks → Completion → Billing → Payment → Outstanding Collection

This should be a practical office utility, not a complicated ERP.

Prioritise simplicity, reliability and ease of use.

---

# 1. TECHNOLOGY

Build the application using:
* Python
* Streamlit
* SQLite
* Pandas
* Plotly only for simple dashboard charts

The application must:
* Run locally
* Save data permanently in SQLite
* Be suitable for GitHub
* Be easy to demonstrate in a project video
* Have clean, beginner-friendly Python code

Do NOT use paid APIs.
Do NOT require an AI API key.
Do NOT use machine learning.
Do NOT over-engineer the application.

---

# 2. LOGIN & SIGNUP

Create a professional login screen:
H P M S & Associates
Practice Management System

Fields:
* Email
* Password

Buttons:
* Login
* Sign Up

## First User
The first registered user automatically becomes: Admin
After creation of the Admin account, arbitrary public signup must stop.

---

# 3. EMPLOYEE SIGNUP CONTROL

Only employees whose email addresses have first been added by Admin should be allowed to sign up.

Admin enters:
* Employee Name
* Email
* Role
* Mobile Number
* Active/Inactive

Roles: Partner, Manager, Chartered Accountant, Accountant, Paid Assistant, Article Assistant, Audit Assistant, Intern, Other

When an employee signs up, verify the email against the employee list.
If not authorised, display: “This email address has not been authorised by Admin.”

Passwords must be securely hashed. Never store plain-text passwords.

---

# 4. ACCESS CONTROL

## ADMIN
Admin can: View complete dashboard, Add/edit employees, Add/edit clients, Add task types, Delegate tasks, Reassign tasks, View all tasks, View all employees' workload, View all client work, View overdue tasks, View billing, Enter bills, Record payments, Track outstanding collections, View analytics.

## EMPLOYEE
Employee can: Login, View only tasks assigned to them, Update their task status, Update progress, Add remarks, View their own pending/completed tasks.

Employees must NOT be able to view tasks assigned to other employees.
Employees should NOT see client billing/payment information.
Apply these restrictions in the backend/database queries, not merely by hiding buttons.

---

# 5. CLIENT MASTER

Admin can add clients.
Fields: Client Code, Client Name, PAN – optional, GSTIN – optional, Contact Person, Mobile, Email, Client Type, Active/Inactive

Client Type dropdown: Individual, Proprietorship, Partnership Firm, LLP, Private Limited Company, Public Limited Company, Trust, Society, Other.
Provide: Add Client, Edit Client, Search Client, View Client.

---

# 6. TASK MASTER

Preload common CA-firm tasks across GST, Income Tax, Audit, ROC, Accounts, Other.
Admin must also have: + Add New Task Type

---

# 7. TASK DELEGATION

Admin should be able to create a task:
Fields: Client, Task, Assigned To, Priority (Low, Normal, High, Urgent), Assignment Date, Due Date, Financial Year (e.g. 2025-26, 2026-27), Instructions / Notes.
Click: Delegate Task -> Save in SQLite.

---

# 8. TASK STATUS

Available statuses: Not Started, In Progress, Waiting for Client, Waiting for Information, Under Review, Query Raised, On Hold, Completed.
Progress: 0%, 25%, 50%, 75%, 100%. Automatically make progress 100% when task is marked Completed.

---

# 9. EMPLOYEE — MY TASKS

Show: | Client | Task | Due Date | Priority | Progress | Status | Latest Remark |
Employee can open their task and update Status, Progress, Remark. Every update must be saved with date/time.

---

# 10. TASK HISTORY

Maintain an activity history (`task_updates`). Never overwrite remarks. Admin can view complete task history.

---

# 11. ADMIN — MASTER TASK TRACKER

Display: | Client | Task | Delegated Staff | Due Date | Priority | Progress | Current Status | Latest Remark |
Provide filters: Client, Employee, Task, Status, Priority, Due Date, Pending Only, Overdue Only, Completed Only.

---

# 12. DUE DATE TRACKING

Identify: Overdue (🔴), Due Today (🟠), Upcoming (within 7 days).
Colors: 🔴 Overdue, 🟠 Urgent, 🟡 Waiting, 🔵 In Progress, 🟢 Completed.

---

# 13. CLIENT 360° VIEW

Page: Client 360°
Display Client Top details + Work Status table + Billing & Collection table + Summary Cards.

---

# 14. BILLING MODULE

Record: Client, Related Task, Bill Number, Bill Date, Professional Fees, GST Amount, Other Charges, Total Bill Amount, Payment Due Date, Billing Remarks.
Automatically calculate: Total Bill = Professional Fees + GST + Other Charges.

---

# 15. BILLING STATUS & COMPLETED BUT NOT BILLED

Identify tasks where Status = Completed AND No bill has been entered -> Completed – Billing Pending. Highlight on Admin Dashboard.

---

# 16. PAYMENT / PART-PAYMENT

Add Payment: Bill Number, Payment Date, Amount Received, Payment Mode, Reference Number, Remarks. Save every payment separately.

---

# 17. AUTOMATIC PAYMENT STATUS

Total Received = Sum of all payments against the bill
Outstanding = Total Bill - Total Received
Status: Unpaid (Received = 0), Partially Paid (0 < Received < Total), Paid (Received >= Total).

---

# 18. COLLECTION FOLLOW-UP

Record follow-up remarks for unpaid/part-paid bills (Follow-up Date, User, Remark). Maintain collection history.

---

# 19. BILLING & COLLECTION TRACKER

Display: | Client | Bill No. | Bill Date | Bill Amount | Received | Outstanding | Due Date | Payment Status |
Filters: Client, Unpaid, Partially Paid, Paid, Overdue.

---

# 20. CLIENT 360° — BILLING

Display billing summary: Total Billed, Total Received, Total Outstanding per client.

---

# 21. ADMIN DASHBOARD

Work KPI Cards: Active Tasks, Completed, In Progress, Waiting for Client, Due Today, Overdue, Completed but Not Billed.
Financial KPI Cards: Total Billed, Total Collection, Total Outstanding, Partially Paid Bills, Overdue Receivables.

---

# 22. TEAM-WISE DASHBOARD
Display: | Employee | Total Tasks | Pending | Completed | Overdue |

---

# 23. CLIENT-WISE DASHBOARD
Display: | Client | Total Tasks | Pending | Completed | Billing Pending | Outstanding |

---

# 24. SIMPLE ANALYTICS
Plotly charts: Task Status, Employee Workload, Collection Status, Client-wise Outstanding.

---

# 25. DATABASE STRUCTURE
SQLite tables: users, authorised_employees, clients, task_types, tasks, task_updates, bills, payments, collection_followups.

---

# 26. SIDEBAR & SECURITY
Admin vs Employee role-based sidebar menus and backend authorization. PBKDF2 password hashing.

---

# 27. SAMPLE DATA LOADER
Provide fictional demo data (8 employees, 10 clients, 30 tasks, 10 bills, part/full payments, follow-ups).
```

---

## 📌 Prompt 2: Windows Batch File (.bat) Creation

```text
ISKI BAT FILE BANA DO
```
*Purpose:* Create Windows batch files (`run.bat` & `run_menu.bat`) for one-click startup and menu-driven execution of the application, test suite, and demo data loader.

---

## 📌 Prompt 3: Streamlit DataFrame Height Error Fix

```text
ye error ara hai
[Attached screenshots showing StreamlitInvalidHeightError on st.dataframe call inside show_task_table]
```
*Purpose:* Fix Streamlit height validation error when `height=None` was passed into `st.dataframe()`.

---

## 📌 Prompt 4: Automatic 18% GST & Live Total Calculation

```text
in customer bill total not tacking amount and give option to add gst % @18 %
```
*Purpose:* In the bill creation tab, add a GST Rate selector with auto-calculation at 18% (as well as 12%, 5%, 0%, and Custom), and display a live dynamic Total Bill Amount box updating as user types.

---

## 📌 Prompt 5: Client Invoice Preview & Send Provision (WhatsApp / Email / Signatory)

```text
aap isi mai bill karte time .client ko bill bhejne ka provsion daal do. HPMS & ASSOCIATES -AUTHORISED SIGNATORY
```
*Purpose:* Add a full Invoice Preview & Send tab in Billing & Collection with HTML/PDF download, direct WhatsApp share, and Email compose links featuring `HPMS & ASSOCIATES - AUTHORISED SIGNATORY`.

---

## 📌 Prompt 6: Invoice Customization (Firm Address, Contact Numbers, CA Logo & Clean Invoice Format)

```text
dont add unpaid status in customer invoice preview.. add hpms address- A-27, COMMERCIAL MARKET, GOVINDPURAM GHAZIABAD, UP-201013...CONTACT NO . 7290009815, 7290009816... ADD CA INDIA LOGO ALSO
```
*Purpose:* 
1. Remove Unpaid/Received/Outstanding payment status overview from customer Tax Invoice preview.
2. Add firm address: `A-27, COMMERCIAL MARKET, GOVINDPURAM, GHAZIABAD, UP-201013`.
3. Add contact numbers: `7290009815, 7290009816`.
4. Add official CA India Logo (SVG Emblem with CA tick mark and dark blue badge).

---

## 📌 Prompt 7: Prompt Compilation Request

```text
aap mujhe sare prompts ko compile karke de sakte ho mere , i want to save them for my references
```
*Purpose:* Compile all project prompts and customization instructions into a reference file and chat response.

---
*Built & compiled for H P M S & Associates — Practice Management System.*
