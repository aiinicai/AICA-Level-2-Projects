"""
test_scenarios.py
-----------------
H P M S & Associates - Practice Management System

Runs the four acceptance scenarios of the project on a temporary copy of
the database. Nothing here touches your real hpms.db.

Run with:   python test_scenarios.py
"""

import os
import tempfile
from datetime import date, timedelta

import database as db

# ---- Point the application at a throw-away database ----------------------
TEST_DB = os.path.join(tempfile.gettempdir(), "hpms_test.db")
if os.path.exists(TEST_DB):
    os.remove(TEST_DB)
db.DB_PATH = TEST_DB

import auth  # noqa: E402  (imported after DB_PATH is redirected)

PASS, FAIL = 0, 0


def check(label, condition, extra=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {label}")
    else:
        FAIL += 1
        print(f"  FAIL  {label} {extra}")


def heading(text):
    print("\n" + text)
    print("-" * len(text))


db.init_db()

# ==========================================================================
heading("SCENARIO A - Admin sets up the firm")
# ==========================================================================
ok, msg = auth.signup("CA Partner", "admin@hpms.in", "admin123")
check("First account created", ok, msg)

admin, err = auth.login("admin@hpms.in", "admin123")
check("Admin can log in", admin is not None, err or "")
check("First user is Admin", admin and admin["is_admin"])

# Passwords are hashed, never stored in plain text
row = db.fetch_one("SELECT password_hash FROM users WHERE email='admin@hpms.in'")
check("Password is hashed, not plain text", "admin123" not in row["password_hash"])

# Unauthorised signup must be refused
ok2, msg2 = auth.signup("Stranger", "stranger@gmail.com", "secret123")
check("Public signup blocked after Admin exists",
      (not ok2) and msg2 == auth.NOT_AUTHORISED_MSG, msg2)

rahul_emp_id = db.add_employee("Rahul", "rahul@hpms.in", "Chartered Accountant",
                               "9820011001")
sneha_emp_id = db.add_employee("Sneha", "sneha@hpms.in", "Manager", "9820011002")
check("Employees added to master", rahul_emp_id and sneha_emp_id)

client_id = db.add_client("C001", "ABC Pvt Ltd", "AABCA1234K", "27AABCA1234K1Z5",
                          "Mr. Anil", "9821001001", "abc@example.in",
                          "Private Limited Company")
check("Client ABC Pvt Ltd added", client_id is not None)

tax_audit_id = db.fetch_one(
    "SELECT id FROM task_types WHERE task_name='Tax Audit'")["id"]
task_id = db.create_task(client_id, tax_audit_id, rahul_emp_id, admin["id"],
                         date.today().isoformat(),
                         (date.today() + timedelta(days=10)).isoformat(),
                         "High", "2026-27", "Complete the tax audit for FY 2025-26.")
check("Tax Audit delegated to Rahul", task_id is not None)

other_task_id = db.create_task(client_id, tax_audit_id, sneha_emp_id, admin["id"],
                              date.today().isoformat(),
                              (date.today() + timedelta(days=15)).isoformat(),
                              "Normal", "2026-27", "Sneha's own task.")

# ==========================================================================
heading("SCENARIO B - Employee signs up, logs in and updates work")
# ==========================================================================
ok, msg = auth.signup("Rahul", "rahul@hpms.in", "rahul123")
check("Authorised employee can sign up", ok, msg)

rahul, err = auth.login("rahul@hpms.in", "rahul123")
check("Rahul can log in", rahul is not None, err or "")
check("Rahul is not Admin", rahul and not rahul["is_admin"])

rahul_tasks = db.get_tasks_df(rahul)
check("Rahul sees his own Tax Audit task",
      len(rahul_tasks) == 1 and int(rahul_tasks.iloc[0]["id"]) == task_id)
check("Rahul cannot see Sneha's task",
      other_task_id not in rahul_tasks["id"].tolist())
check("Direct fetch of another employee's task is refused",
      db.get_task(rahul, other_task_id) is None)

db.update_task_progress(rahul, task_id, "In Progress", 25,
                        "Data received from client.")
db.update_task_progress(rahul, task_id, "Waiting for Client", 25,
                        "Purchase register requested from client.")
t = db.get_task(rahul, task_id)
check("Status updated to Waiting for Client", t["status"] == "Waiting for Client")
check("Latest remark is the newest one",
      t["latest_remark"] == "Purchase register requested from client.")

hist = db.get_task_history_df(rahul, task_id)
check("History is kept, not overwritten", len(hist) >= 3, f"rows={len(hist)}")

# ==========================================================================
heading("SCENARIO C - Admin review and completion")
# ==========================================================================
admin_tasks = db.get_tasks_df(admin)
check("Admin sees all tasks", len(admin_tasks) == 2)
check("Admin sees Rahul's latest remark",
      admin_tasks[admin_tasks["id"] == task_id].iloc[0]["latest_remark"]
      == "Purchase register requested from client.")

db.update_task_progress(rahul, task_id, "Completed", 25, "Tax audit report filed.")
t = db.get_task(admin, task_id)
check("Completing a task forces progress to 100%", int(t["progress"]) == 100)

nb = db.get_completed_not_billed_df()
check("Task shows as Completed but Not Billed",
      task_id in nb["id"].tolist(), f"ids={nb['id'].tolist()}")

# ==========================================================================
heading("SCENARIO D - Billing, part payment and collection")
# ==========================================================================
bill_id = db.add_bill(client_id, task_id, "HPMS/26-27/001",
                      date.today().isoformat(), 42372.88, 7627.12, 0,
                      (date.today() + timedelta(days=30)).isoformat(),
                      "Tax audit fees.", admin["id"])
bills = db.get_bills_df()
b = bills[bills["id"] == bill_id].iloc[0]
check("Total = fees + GST + other = 50,000", round(b["total_amount"]) == 50000,
      b["total_amount"])
check("Initial outstanding is 50,000", round(b["outstanding"]) == 50000)
check("Initial status is Unpaid", b["payment_status"] == "Unpaid")

nb = db.get_completed_not_billed_df()
check("Task disappears from Completed-but-Not-Billed after billing",
      task_id not in nb["id"].tolist())

db.add_payment(bill_id, date.today().isoformat(), 20000, "Bank Transfer",
               "NEFT/001", "First instalment.", admin["id"])
b = db.get_bills_df()
b = b[b["id"] == bill_id].iloc[0]
check("After 20,000: received = 20,000", round(b["received"]) == 20000)
check("After 20,000: outstanding = 30,000", round(b["outstanding"]) == 30000)
check("After 20,000: status = Partially Paid", b["payment_status"] == "Partially Paid")

db.add_payment(bill_id, date.today().isoformat(), 30000, "UPI",
               "UPI/002", "Balance received.", admin["id"])
b = db.get_bills_df()
b = b[b["id"] == bill_id].iloc[0]
check("After 50,000: received = 50,000", round(b["received"]) == 50000)
check("After 50,000: outstanding = 0", round(b["outstanding"]) == 0)
check("After 50,000: status = Paid", b["payment_status"] == "Paid")
check("Both payments stored separately", len(db.get_payments_df(bill_id)) == 2)

db.add_followup(bill_id, date.today().isoformat(), admin["id"],
                "Called client - payment expected Monday.")
db.add_followup(bill_id, date.today().isoformat(), admin["id"],
                "Balance received, thanked the client.")
check("Collection follow-up history retained",
      len(db.get_followups_df(bill_id)) == 2)

# ==========================================================================
heading("PERSISTENCE - data survives an application restart")
# ==========================================================================
import importlib  # noqa: E402
importlib.reload(db)
db.DB_PATH = TEST_DB
b = db.get_bills_df()
b = b[b["bill_number"] == "HPMS/26-27/001"].iloc[0]
check("Bill still present after reload", round(b["total_amount"]) == 50000)
check("Payments still present after reload", round(b["received"]) == 50000)
check("Task status still Completed",
      db.fetch_one("SELECT status FROM tasks WHERE id=?", (task_id,))["status"]
      == "Completed")

print("\n" + "=" * 46)
print(f"  {PASS} checks passed, {FAIL} failed")
print("=" * 46)
raise SystemExit(1 if FAIL else 0)
