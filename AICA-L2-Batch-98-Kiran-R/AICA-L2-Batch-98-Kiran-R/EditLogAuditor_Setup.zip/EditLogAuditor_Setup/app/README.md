# EditLog Auditor (Rule 11(g))

Helps the auditor form an opinion on the audit-trail requirement of Rule 11(g) of the Companies (Audit and Auditors) Rules, 2014
and the proviso to Rule 3(1) of the Companies (Accounts) Rules, 2014, following the ICAI Implementation Guide (Revised 2024).

Tabs, in working order:
1. **Settings** - company, financial year, test thresholds, the connection to TallyPrime, folders, file format, one-time Tally set-up.
2. **Input** - pull the vouchers and the Edit Log (every version of every voucher) from Tally, or upload files; coverage tracker.
3. **Edit Log Findings** - indicator, tests A-D, exceptions, priority vouchers.
4. **Guided audit (ICAI)** - applicability, software inventory, controls, tests, preservation, representations, conclusion, wording.
5. **Reports** - draft audit opinion paragraphs, AI memo, downloads (Annexure A, working paper, representation letter, findings).
6. **History** - every saved check with its reports; export the register to Excel or PDF.

Run: `streamlit run app.py`. Install on Windows with INSTALL.bat. Nothing here changes data in Tally. All wording is a draft for the
auditor's professional judgement.
