@echo off
setlocal
title EditLog Auditor - Add the Edit Log TDL to TallyPrime
set "TDLDIR=C:\AuditTrail\TDL"
set "SRC=%LOCALAPPDATA%\EditLogAuditor\app\tdl\AuditTrail_EditLog.tdl"
if not exist "%TDLDIR%" mkdir "%TDLDIR%" 2>nul
if not exist "%SRC%" ( echo The checker is not installed. Run INSTALL.bat first. & pause & exit /b 1 )
copy /Y "%SRC%" "%TDLDIR%\AuditTrail_EditLog.tdl" >nul
echo %TDLDIR%\AuditTrail_EditLog.tdl| clip
echo.
echo  The TDL file is ready:   %TDLDIR%\AuditTrail_EditLog.tdl
echo  (the full path is now on your clipboard - paste it in Tally)
echo.
echo  In TallyPrime, once per computer:
echo    1. Press F1 (Help) ^> TDL ^& Add-on ^> Manage Local TDL.
echo    2. Set "Load TDL files on startup" = Yes.
echo    3. In "List of TDL Files to Preload", paste the path above and press Enter.  Accept and restart TallyPrime.
echo    4. Open the client company. Gateway of Tally now shows  "Audit Trail - Edit Log Export".
echo       Press Alt+D there to save a CSV into C:\AuditTrail\Drop, or use EXTRACT_EDITLOG.bat.
echo  (menu names differ slightly between TallyPrime releases; if you cannot find it, search "TDL" in F1 Help)
echo.
echo  Checking whether Tally's port 9000 is open on this computer...
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient('localhost',9000);$c.Close();'  Port 9000: OPEN - Tally is listening.'}catch{'  Port 9000: closed. Turn on F1 Help > Settings > Advanced Configuration > HTTP server, with Tally running.'}"
echo.
explorer "%TDLDIR%"
pause
