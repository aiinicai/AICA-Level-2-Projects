@echo off
setlocal EnableDelayedExpansion
title EditLog Auditor - Extract the Edit Log from TallyPrime
set "BASE=%LOCALAPPDATA%\EditLogAuditor"
set "PY=%BASE%\venv\Scripts\python.exe"
set "LAST=%BASE%\last_extract.txt"
set "DROP=C:\AuditTrail\Drop"
if not exist "%PY%" (
  echo The EditLog Auditor is not installed yet. Run INSTALL.bat first.
  pause & exit /b 1
)
echo.
echo  EXTRACT EDIT LOG FROM TALLYPRIME  (read-only - nothing in Tally is changed)
echo  ---------------------------------------------------------------------------
echo  Before you start:
echo    1. TallyPrime is open and the client company is loaded.
echo    2. The HTTP server is on:  F1 Help ^> Settings ^> Advanced Configuration ^> port 9000.
echo    3. The Audit Trail TDL is loaded (run ADD_TDL_TO_TALLY.bat once if not).
echo.
set "CO=" & set "FROM=" & set "TO=" & set "PORT=9000"
if exist "%LAST%" ( for /f "usebackq tokens=1,* delims==" %%A in ("%LAST%") do set "%%A=%%B" )
set "IN="
set /p IN=Company name exactly as in Tally [%CO%]: 
if not "!IN!"=="" set "CO=!IN!"
set "IN="
set /p IN=Year start YYYY-MM-DD [%FROM%]: 
if not "!IN!"=="" set "FROM=!IN!"
set "IN="
set /p IN=Year end   YYYY-MM-DD [%TO%]: 
if not "!IN!"=="" set "TO=!IN!"
set "IN="
set /p IN=Tally port [%PORT%]: 
if not "!IN!"=="" set "PORT=!IN!"
if "!CO!"=="" ( echo Company name is required. & pause & exit /b 1 )
(
 echo CO=!CO!
 echo FROM=!FROM!
 echo TO=!TO!
 echo PORT=!PORT!
) > "%LAST%"
if not exist "%DROP%" mkdir "%DROP%" 2>nul
echo.
echo  Asking Tally for every version of every voucher, ledger, group, stock item and company activity...
echo  (a large company can take several minutes - please wait)
echo.
"%PY%" "%BASE%\app\tally_connector.py" --extract --company "!CO!" --from !FROM! --to !TO! --port !PORT! --out "%DROP%"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo  DONE. The file is in %DROP%
  echo  In the checker: Pull from Tally ^> Edit-log source ^> "Import the file the TDL saved in the Drop folder".
  choice /C YN /M " Open the EditLog Auditor now"
  if errorlevel 2 goto :end
  start "" wscript.exe "%BASE%\launch.vbs"
) else if "%RC%"=="3" (
  echo  Tally answered but returned no Edit Log rows. Check that Edit Log is ON for this company and the dates cover the year.
) else (
  echo  Could not extract. Read the message above. Common causes: TDL not loaded, HTTP server off, wrong company name.
)
:end
echo.
pause
