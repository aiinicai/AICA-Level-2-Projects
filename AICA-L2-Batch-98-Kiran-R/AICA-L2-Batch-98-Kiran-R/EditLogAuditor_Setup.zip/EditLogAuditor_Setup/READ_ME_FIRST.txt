AUDIT TRAIL CHECKER  -  Rule 11(g), Companies (Audit and Auditors) Rules, 2014
Edit Log TDL for TallyPrime + guided audit workflow based on the ICAI Implementation Guide (Revised 2024)
==========================================================================================================

WHAT IS IN THIS FOLDER
  INSTALL.bat               installs the checker (once per computer, ~10 minutes, internet needed)
  ADD_TDL_TO_TALLY.bat      puts the Edit Log TDL where TallyPrime can load it and shows the 4 steps (once per computer)
  EXTRACT_EDITLOG.bat       asks Tally for EVERY version of the Edit Log and saves a CSV (per client, per year)
  AuditTrail_EditLog.tdl    the TDL itself (also copied to C:\AuditTrail\TDL)
  UNINSTALL.bat             removes the program (your evidence is kept)

STEP 1 - INSTALL
  Right-click the ZIP > Properties > Unblock > OK. Extract All. Double-click INSTALL.bat.
  If Windows says "protected your PC": More info > Run anyway.

STEP 2 - LOAD THE TDL IN TALLYPRIME (once)
  Double-click ADD_TDL_TO_TALLY.bat and follow the 4 lines it prints.
  Check: Gateway of Tally now shows "Audit Trail - Edit Log Export".  Also turn on the HTTP server (port 9000):
  F1 Help > Settings > Advanced Configuration.
  The TDL is written from Tally's documented Edit Log constructs. If your TallyPrime release rejects any line, Tally shows
  the line number: send me that screenshot and the file will be corrected. Try it on a demo company first.

STEP 3 - GET THE EDIT LOG FROM TALLY  (two ways, same result)
  A. Automatic: open the client company in Tally, double-click EXTRACT_EDITLOG.bat, type company name and the year.
     A CSV with every version is saved in C:\AuditTrail\Drop.
  B. Manual: in Tally, Gateway of Tally > Audit Trail - Edit Log Export.  Alt+D saves the CSV to C:\AuditTrail\Drop;
     Alt+V = CSV (ASCII), Alt+X = Excel to a place you choose.
  What it contains (13 columns): vouchers incl. DELETED ones, ledgers, groups, stock items, company activity;
  one row per version with Action, Activity, User and date-time.

STEP 4 - AUDIT IN THE CHECKER  (desktop icon "EditLog Auditor" > tab "Guided audit (ICAI)")
  1 Applicability      entity, books electronic?, year -> which sentences the report needs
  2 Software inventory Appendix I table (Tally, payroll, fixed assets, spreadsheets that feed the books)
  3 Controls           12 controls from paras 20-25 and FAQs, each with how to evidence it in Tally
  4 Edit Log data      import the CSV (tab "Pull from Tally" > Edit-log source) - 14 tests run; master changes shown
  5 Preservation       daily back-up in India (Rule 3(5)), 8 years (s.128(5)), retrievability
  6 Representations    tick the items; download the management representation letter (Appendix II)
  7 Conclusion         suggested: unmodified / modified / unable to comment / adverse, with reasons and open items
  8 Report and file    Rule 11(g) wording, s.143(3)(b) and (h) read-across (FAQ 24), IFCoFR note, working paper (Word)

(Continuous 24x7 monitoring has been removed from the tool.)

HONEST LIMITS
  * The program only READS from Tally. Nothing in your data is changed.
  * Not yet run on a live TallyPrime by the author. Test on a demo company and check the row counts against Tally's own
    Edit Log screen for a few vouchers before relying on it. Tally Edit Log availability depends on the release.
  * Every suggested conclusion and every wording is a DRAFT for your professional judgement (SA 700/705/250).
  * Rule 11(g) is factual reporting, not materiality-based; test checks only choose the sample (ICAI FAQ 9).
  * Evidence folder to back up:  %LOCALAPPDATA%\EditLogAuditor\app\state

IF SOMETHING GOES WRONG
  Send %LOCALAPPDATA%\EditLogAuditor\install.log, and a screenshot of any Tally error, to your support person.


--------------------------------------------------------------------------------
VOUCHER-LEVEL EDIT LOG: THE METHOD THAT WORKS ON YOUR TALLY (v3.7)
--------------------------------------------------------------------------------
Tally's own report gives every version of every voucher (who, when, created/altered/deleted).
1. In Tally: Display More Reports > Edit Log (Audit) > Edit Log Summary - Vouchers.
2. Press F2 and set the period to the whole year. Details of = "All Vouchers for Any Activity - All Versions".
3. Open each voucher type (Payment, Receipt, Journal, Sales, Purchase ...). On each list press Alt+E,
   File Format = ASCII (Comma Delimited), save into C:\AuditTrail\Drop (any file name).
4. In the checker: Pull from Tally tab > Edit log > "Tally's own Edit Log Summary export" > Load.
5. Annexure A (Excel) then holds the version register, deleted vouchers, and a risk-ranked
   "Field-level sample". For each sampled voucher open Tally's "Differences Between Edit Log Versions"
   screen, record what changed (old/new value, reason, authorisation) in the blank columns, keep a screenshot.
The Audit Trail TDL still gives the voucher list, masters and Company Activity; its per-voucher version rows
do not work on Tally Prime EDU.


--------------------------------------------------------------------------------
EXTRACT THE EDIT LOG STRAIGHT FROM TALLY (v4.0) - Pull from Tally page, Step 3
--------------------------------------------------------------------------------
Tally does not release the Edit Log through its data connection (Tally's own help says so). The tool therefore presses
the keys on Tally's Edit Log Summary screens for you: voucher type -> month -> Ctrl+E, one file per type and month, and
checks every file before moving on (right voucher type, right month, one line per version). It stops at the first problem.
Before the first run (once): in Tally Go To > Edit Log Summary > Voucher Types, press F5 and F9; press Ctrl+E then C and set
File Format and Folder Path (the folder named in the tool). Then log in to the company yourself and leave Tally on that list.
Press "Test with the first month". If the file is right, press "Extract everything planned" and do not touch the keyboard or mouse.
The coverage table shows which voucher types and months are still missing.
