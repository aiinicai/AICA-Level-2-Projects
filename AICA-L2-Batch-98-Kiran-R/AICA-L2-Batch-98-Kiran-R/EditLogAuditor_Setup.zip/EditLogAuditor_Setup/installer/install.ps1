﻿# Installs EditLog Auditor for the current Windows user. No administrator rights needed.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkg  = Split-Path -Parent $root
$dest = Join-Path $env:LOCALAPPDATA 'EditLogAuditor'
$oldDest = Join-Path $env:LOCALAPPDATA 'AuditTrailChecker'   # the folder used before the tool was renamed
$appDir = Join-Path $dest 'app'
$venv = Join-Path $dest 'venv'
$log  = Join-Path $dest 'install.log'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Start-Transcript -Path $log -Force | Out-Null

function Step($n, $msg) { Write-Host ("[{0}/6] {1}" -f $n, $msg) -ForegroundColor Cyan }
function Fail($msg) {
  Write-Host ""; Write-Host "INSTALLATION STOPPED: $msg" -ForegroundColor Red
  Write-Host "Send the file  $log  to your support person." -ForegroundColor Yellow
  Stop-Transcript | Out-Null; exit 1
}

# run a program and throw its output away; returns True when it exited with 0 (cmd keeps PowerShell from turning stderr text into errors)
function Quiet($exe, $argline) {
  cmd /c "`"$exe`" $argline >nul 2>nul"
  return ($LASTEXITCODE -eq 0)
}

function Find-Python {
  $cands = @()
  foreach ($ver in '3.12','3.13','3.11','3.10') {
    try { $p = & py "-$ver" -c "import sys;print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { $cands += $p.Trim() } } catch {}
  }
  foreach ($p in @("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe","$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
                   "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe","$env:ProgramFiles\Python312\python.exe")) {
    if (Test-Path $p) { $cands += $p }
  }
  foreach ($p in $cands) {
    try {
      $v = & $p -c "import sys;print('%d.%d' % sys.version_info[:2])" 2>$null
      if ($LASTEXITCODE -eq 0 -and [version]$v -ge [version]'3.10' -and [version]$v -lt [version]'3.14') { return $p }
    } catch {}
  }
  return $null
}

Step 1 'Checking for Python (the engine this tool runs on)'
$py = Find-Python
if (-not $py) {
  Write-Host '   Python not found. Downloading it from python.org (about 25 MB)...'
  $exe = Join-Path $env:TEMP 'python-3.12.10-amd64.exe'
  $local = Join-Path $root 'python-installer.exe'
  if (Test-Path $local) { Copy-Item $local $exe -Force }
  else {
    try { Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $exe -UseBasicParsing }
    catch {
      Write-Host '   Direct download failed. Trying Windows Package Manager (winget)...'
      try { winget install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements } catch {}
    }
  }
  if (Test-Path $exe) {
    Start-Process -FilePath $exe -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_test=0','Include_launcher=1','Include_doc=0' -Wait
  }
  $py = Find-Python
  if (-not $py) { Fail 'Python could not be installed automatically. Install Python 3.12 from python.org (tick "Add python.exe to PATH"), then run INSTALL.bat again.' }
}
Write-Host "   Using: $py" -ForegroundColor Green

# stop a running copy of the tool (also one started from the old, pre-rename folder)
try {
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.ExecutablePath -and $_.ExecutablePath -like "$oldDest*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}
# stop a running copy of the tool (it locks python.exe in the private environment and the program files)
try {
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.ExecutablePath -and $_.ExecutablePath -like "$dest*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Seconds 2
} catch {}
Step 2 'Copying the program files'
$null = robocopy (Join-Path $pkg 'app') $appDir /E /XD state __pycache__ /XF clients.toml secrets.env /NFL /NDL /NJH /NJS /NP
if ($LASTEXITCODE -ge 8) { Fail 'Could not copy program files.' }
# Bring the saved history and engagement evidence over from the old (pre-rename) install; nothing is deleted from the old folder
$oldState = Join-Path $oldDest 'app\state'
$newState = Join-Path $appDir 'state'
if ((Test-Path $oldState) -and -not (Test-Path (Join-Path $newState 'history.db'))) {
  $null = robocopy $oldState $newState /E /NFL /NDL /NJH /NJS /NP
  Write-Host '   Your earlier saved checks were copied across to the new folder.' -ForegroundColor Green
}
# Folders used by the Tally Edit Log TDL and the extract tool (fixed paths because Tally's TDL cannot read environment variables)
foreach ($d in 'C:\AuditTrail\Drop','C:\AuditTrail\TDL') {
  try { New-Item -ItemType Directory -Force -Path $d | Out-Null } catch { Write-Host "   Note: could not create $d (create it by hand if you want the Alt+D save to work)." -ForegroundColor Yellow }
}
try { Copy-Item (Join-Path $appDir 'tdl\AuditTrail_EditLog.tdl') 'C:\AuditTrail\TDL\AuditTrail_EditLog.tdl' -Force } catch {}
$tools = Join-Path $pkg 'tools'
if (Test-Path $tools) { Copy-Item (Join-Path $tools '*.bat') $dest -Force }

Step 3 'Creating a private environment'
$vpy = Join-Path $venv 'Scripts\python.exe'
$cfgf = Join-Path $venv 'pyvenv.cfg'
$healthy = $false
if ((Test-Path $vpy) -and (Test-Path $cfgf)) { if (Quiet $vpy '-m pip --version') { $healthy = $true } }
if (-not $healthy) {
  if (Test-Path $venv) { Write-Host '   Removing an incomplete earlier environment...'; Remove-Item $venv -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $venv) { $old = $venv + '_old_' + (Get-Date -Format yyyyMMddHHmmss); try { Rename-Item $venv $old -ErrorAction Stop } catch { Fail 'The old environment is locked. Restart the computer once, then run INSTALL.bat again.' } } }
  & $py -m venv $venv
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path $cfgf)) { Fail 'Could not create the Python environment. If an antivirus is running, pause it for 10 minutes and run INSTALL.bat again.' }
  # a private environment without pip cannot install anything: add pip to it
  if (-not (Quiet $vpy '-m pip --version')) {
    Write-Host '   Adding the package installer (pip) to the environment...'
    $null = Quiet $vpy '-m ensurepip --upgrade --default-pip'
    if (-not (Quiet $vpy '-m pip --version')) {
      try {
        $gp = Join-Path $env:TEMP 'get-pip.py'
        Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile $gp -UseBasicParsing
        $null = Quiet $vpy "`"$gp`" --no-warn-script-location"
      } catch {}
      if (-not (Quiet $vpy '-m pip --version')) { Fail 'pip could not be added to the environment. Pause the antivirus for 10 minutes, delete the folder %LOCALAPPDATA%\EditLogAuditor\venv and run INSTALL.bat again.' }
    }
  }
}

Step 4 'Installing components (needs internet; the longest step)'
$req = Join-Path $appDir 'requirements.txt'
$wheels = Join-Path $root 'wheels'
if (Test-Path $wheels) { & $vpy -m pip install --no-index --find-links $wheels -r $req }
else { & $vpy -m pip install --disable-pip-version-check -r $req }
if ($LASTEXITCODE -ne 0) { Fail 'Components could not be downloaded. Check the internet connection (or office firewall) and run INSTALL.bat again.' }

Step 5 'Creating desktop icons'
$vbs = Join-Path $dest 'launch.vbs'
@"
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = "$appDir"
sh.Run """$vpy"" -m streamlit run ""$appDir\app.py"" --server.headless true --server.port 8501 --browser.gatherUsageStats false --server.fileWatcherType none", 0, False
WScript.Sleep 6000
sh.Run "http://localhost:8501"
"@ | Set-Content -Path $vbs -Encoding ASCII
$ws = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = $ws.CreateShortcut((Join-Path $folder 'EditLog Auditor.lnk'))
  $lnk.TargetPath = 'wscript.exe'; $lnk.Arguments = "`"$vbs`""; $lnk.WorkingDirectory = $appDir
  $lnk.IconLocation = 'shell32.dll,167'; $lnk.Description = 'EditLog Auditor - Rule 11(g)'; $lnk.Save()
}

# remove the icons of the old name so that there is only one set
foreach ($old in 'Audit Trail Checker.lnk') { foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) { Remove-Item (Join-Path $folder $old) -ErrorAction SilentlyContinue } }
foreach ($old in 'Audit Trail - Extract Edit Log from Tally.lnk','Audit Trail - Add TDL to Tally.lnk') { Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) $old) -ErrorAction SilentlyContinue }
foreach ($b in @(@('EXTRACT_EDITLOG.bat','EditLog Auditor - Extract Edit Log from Tally','shell32.dll,46'), @('ADD_TDL_TO_TALLY.bat','EditLog Auditor - Add TDL to Tally','shell32.dll,21'))) {
  $target = Join-Path $dest $b[0]
  if (Test-Path $target) {
    $l = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) ($b[1] + '.lnk')))
    $l.TargetPath = $target; $l.WorkingDirectory = $dest; $l.IconLocation = $b[2]; $l.Save()
  }
}

Step 6 'Self-check'
Push-Location $appDir
$chk = & $vpy -c "import streamlit, pandas, plotly, openpyxl, docx, opinion, guided, editlog_import, extract, history, reportlab; print('OK')" 2>&1
Pop-Location
if ("$chk" -notmatch 'OK') { Fail "Self-check failed: $chk" }
Write-Host ''
Write-Host 'Installed. Use the "EditLog Auditor" icon on your desktop.' -ForegroundColor Green
Write-Host 'First: run  EditLog Auditor - Add TDL to Tally  (desktop icon) once, then  Extract Edit Log from Tally  for each client.'
Write-Host 'Then open the Guided audit tab. Start with the Settings tab.'
Stop-Transcript | Out-Null
Start-Process wscript.exe -ArgumentList "`"$vbs`""
