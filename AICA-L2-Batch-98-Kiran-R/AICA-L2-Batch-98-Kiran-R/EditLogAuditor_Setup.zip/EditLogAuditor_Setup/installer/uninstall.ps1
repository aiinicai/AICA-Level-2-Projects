﻿$dest = Join-Path $env:LOCALAPPDATA 'EditLogAuditor'
try { Unregister-ScheduledTask -TaskName 'AuditTrail-Rule11g-Monitor' -Confirm:$false -ErrorAction Stop; Write-Host 'Monitoring task removed.' } catch {}
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $folder 'EditLog Auditor.lnk') -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $folder 'Audit Trail Checker.lnk') -ErrorAction SilentlyContinue
}
Remove-Item (Join-Path $dest 'venv') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host "Program removed. Your audit evidence and settings were KEPT in:" -ForegroundColor Yellow
Write-Host "  $dest\app\state   and   $dest\app\config"
Write-Host 'Keep the state folder for at least eight financial years. Delete it yourself only if you are sure.'
