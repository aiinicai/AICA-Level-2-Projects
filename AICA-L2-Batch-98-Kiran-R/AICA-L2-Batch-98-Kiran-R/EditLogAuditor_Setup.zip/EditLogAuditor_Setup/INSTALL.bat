@echo off
title EditLog Auditor - Installer
echo.
echo  Installing EditLog Auditor. Please wait, this takes 5 to 10 minutes the first time.
echo  Do not close this window.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1"
echo.
pause
