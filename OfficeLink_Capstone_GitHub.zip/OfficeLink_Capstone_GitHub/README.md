# OfficeLink — capstone browser demo

An interactive prototype for a small-office LAN messenger. Reviewers can try conversations, document sharing and employee administration directly in a browser, without installing Python or the desktop application.

**Live demo:** https://officelink-capstone-demo.protrackacco-1269.chatgpt.site

This repository contains the **browser demonstration**, not the original Python LAN server/client source. The demo has no backend, real login or cross-device delivery. Every visitor gets separate local demo data. All people, conversations and sample documents are fictional.

## Features you can try

- Send direct messages and switch to the recipient's perspective.
- View unread counts and local read indicators.
- Attach and download files, with a 5 MiB per-file limit and 25 MiB shared demo quota.
- Search colleagues and documents.
- Add, disable and re-enable fictional employees as the demo administrator.
- Reload the page to check local persistence.
- Explore the full LAN system's intended architecture and the demo's scope.
- Reset local demo data from **About the project**.

## Five-minute demonstration

1. Open the live demo. The initial profile is **Mira Patel · Admin**.
2. Select **Daniel Reed**, use a sample message, then press **Send**.
3. Click **Switch to recipient**. Confirm the message appears in Daniel's conversation with Mira.
4. Click **Attach a sample file**, then **Send**. Download the document from its message.
5. Refresh. The message and file should remain when IndexedDB is available.
6. Switch back to Mira. Open **People**, add a fictional employee and try disabling and re-enabling that profile.
7. Open **About the project** to explain how the full office LAN version differs.

Use one tab at a time. Multiple tabs do not synchronize edits and may overwrite each other's local state. Private browsing, browser cleanup and storage eviction can remove data. If persistent storage is unavailable, the app displays a session-only notice.

## Upload to GitHub and publish your own link

1. Extract `OfficeLink_Capstone_GitHub.zip` on your computer.
2. Create a repository named, for example, `officelink-capstone-demo`. A public repository works with GitHub Free.
3. Upload the **contents** of the extracted project folder. The repository root should contain `README.md`, `docs`, `tests` and `project-docs`. Do not upload only the ZIP, and do not nest the whole project inside another folder.
4. In the repository, choose **Settings → Pages → Build and deployment → Source → Deploy from a branch**.
5. Choose **main** and the **/docs** folder, then **Save**. If your branch has a different name, choose that branch instead.
6. When the Pages deployment finishes, copy the URL shown by GitHub and open it in a private/incognito window to verify public access.
7. Add that exact live URL to your repository's About/Website field and your capstone submission.

The usual project-site URL format is `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`. This is a template, not an already-created GitHub address. A GitHub repository has not been created in your account by this package.

GitHub's official setup references, checked 3 November 2026:

- [Configuring a publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [What is GitHub Pages?](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)

## Files

| Path in the GitHub package | Purpose |
| --- | --- |
| `docs/index.html` | App markup and capstone project overview |
| `docs/assets/styles.css` | Responsive desktop and mobile styling |
| `docs/assets/model.js` | Pure domain model, sample data and validation |
| `docs/assets/app.js` | UI events, IndexedDB persistence and downloads |
| `docs/assets/mark.svg` | Original OfficeLink demo icon |
| `docs/.nojekyll` | Serve the static files directly on GitHub Pages |
| `tests/model.test.cjs` | Repeatable domain-model tests |
| `project-docs/CAPSTONE_BRIEF.md` | Problem, scope, architecture and data model |
| `project-docs/EVALUATION_GUIDE.md` | Examiner walkthrough and acceptance checks |
| `project-docs/TEST_RESULTS.md` | Actual verification performed and testing limits |
| `project-docs/SUBMISSION_DETAILS.md` | Fields to complete for your own submission |

The managed live-site checkout uses `dist/` as its static directory; the GitHub export uses the same verified files in `docs/` for branch-based Pages hosting.

## Run locally (optional, for development)

No build step or package installation is required. The hosted demo needs only a modern browser with JavaScript enabled.

If Python is already installed on the development computer, from the extracted GitHub project folder run:

```bash
python -m http.server 8000 --directory docs
```

On Windows, the command may be `py -m http.server 8000 --directory docs`. Open `http://localhost:8000`. Python is only an optional local development server; employees and examiners do not need it for this browser demo.

For the managed live-site checkout, substitute `dist` for `docs`.

## Run the automated tests

With Node.js available on the development computer:

```bash
node --test tests/model.test.cjs
```

The suite uses Node's built-in test runner; there are no npm dependencies. It was executed with Node.js 24.22.1. Tests verify message flow, read state, attachment visibility, quota validation, employee controls and immutable model updates. Browser verification is documented separately.

## Storage and privacy

The demo stores its state and attached file blobs in IndexedDB under the site's origin. File blobs and message metadata are committed together in one transaction. It does not upload documents, call external APIs or contain analytics code. The hosting provider still processes normal page requests.

All role switches and admin controls are simulations. Anyone who can access this browser profile can inspect local demo data. Use fictional/sample material. The demo is not a secure document repository or a backup system.

Limits are deliberately smaller than the full system's 5 GiB shared-storage target. Browser storage availability varies; quota failures leave the pending message unsaved and display an error. Up to 1,000 messages and 25 demo employee profiles are allowed. Individual text messages are limited to 4,000 characters.

## Capstone submission

Complete `project-docs/SUBMISSION_DETAILS.md` with your actual name, institution, course, supervisor and repository URL. Describe your own contributions and the AI assistance used. This package was developed with ChatGPT assistance. Record any additional changes and tests you perform; the included results do not establish production LAN security or multi-device operation.

There is no third-party JavaScript framework, font download or external icon package. No open-source licence has been selected on your behalf; choose one before inviting public reuse if your submission requires it.
