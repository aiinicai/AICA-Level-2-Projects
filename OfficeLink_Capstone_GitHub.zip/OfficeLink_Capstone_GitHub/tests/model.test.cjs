const test=require('node:test');
const assert=require('node:assert/strict');
const M=require('../docs/assets/model.js');

test('message moves between sender and recipient views and read indicator changes',()=>{
  const original=M.seed();const sent=M.send(original,'Please come over to my desk.');
  const m=sent.messages.at(-1);assert.equal(original.messages.length+1,sent.messages.length);
  assert.equal(m.from,'mira');assert.equal(m.to,'daniel');assert.equal(M.unread(sent,'daniel','mira'),1);
  const recipient=M.switchIdentity(sent,'daniel');assert.equal(recipient.selectedPeer,'mira');
  assert.equal(M.conversation(recipient).at(-1).text,m.text);assert.equal(M.unread(recipient,'daniel','mira'),0);
  assert.ok(recipient.messages.at(-1).readBy.includes('daniel'));assert.ok(!sent.messages.at(-1).readBy.includes('daniel'));
});
test('unrelated conversation does not expose attachment in selected employee document list',()=>{
  const sent=M.send(M.seed(),'File attached',{id:'file1',name:'sample.txt',size:13,type:'text/plain'});
  assert.ok(M.documents(sent,'mira').some(m=>m.attachment.id==='file1'));
  assert.ok(M.documents(sent,'daniel').some(m=>m.attachment.id==='file1'));
  assert.ok(!M.documents(sent,'jules').some(m=>m.attachment.id==='file1'));
});
test('empty messages, excessive text, file limits and aggregate quota are enforced',()=>{
  const state=M.seed();assert.throws(()=>M.send(state,'  '),/Write a message/);
  assert.throws(()=>M.send(state,'x'.repeat(4001)),/4,000/);
  assert.throws(()=>M.send(state,'',{id:'large',name:'large.bin',size:M.FILE_LIMIT+1}),/5 MiB/);
  let s={...state,messages:[]};for(let i=0;i<5;i++)s=M.send(s,'',{id:`f${i}`,name:`f${i}.bin`,size:M.FILE_LIMIT});
  assert.equal(M.storageUsed(s),M.QUOTA);assert.throws(()=>M.send(s,'',{id:'extra',name:'extra.txt',size:1}),/quota/);
});
test('only demo admin can manage employees; disabled profiles cannot send or switch',()=>{
  const staff=M.switchIdentity(M.seed(),'daniel');assert.throws(()=>M.addEmployee(staff,'Alex','Associate'),/Mira/);
  assert.throws(()=>M.toggleEmployee(staff,'sofia'),/Mira/);
  const added=M.addEmployee(M.seed(),'Alex Taylor','Associate');assert.equal(added.users.length,7);
  assert.throws(()=>M.addEmployee(added,'alex taylor','Associate'),/already exists/);
  assert.throws(()=>M.toggleEmployee(added,'mira'),/administrator/);
  const disabled=M.toggleEmployee(added,'daniel');assert.throws(()=>M.send(disabled,'hello'),/enabled/);
  assert.throws(()=>M.switchIdentity(disabled,'daniel'),/disabled/);
  const enabled=M.toggleEmployee(disabled,'daniel');assert.doesNotThrow(()=>M.send(enabled,'Hello again'));
});
test('searchable message contents remain plain data and model preserves source state',()=>{
  const state=M.seed();const text='<img src=x onerror=alert(1)>';
  const sent=M.send(state,text);assert.equal(sent.messages.at(-1).text,text);
  assert.notEqual(sent,state);assert.ok(!state.messages.some(m=>m.text===text));
  assert.throws(()=>M.selectPeer(state,'mira'),/another/);
});
