# Verification record

Verification date: 3 November 2026.

## Automated checks performed

Command: `node --test tests/model.test.cjs`.

Environment: Node.js 24.22.1 on the development environment.

Result: **5 tests passed, 0 failed**.

| Test | Verified behavior |
| --- | --- |
| Message flow and read state | Sender/recipient views share the correct conversation; switching to recipient clears unread state |
| Attachment visibility | Files appear for participants and are excluded from an unrelated employee's document view |
| Content and storage limits | Empty messages, excessive text, oversized files and aggregate attachment quota are rejected |
| Employee administration | Non-admin management is rejected by the demo model; disabled profiles cannot send or be selected as active |
| State isolation | State transitions preserve previous state; HTML-like strings remain data in the model |

JavaScript syntax was also checked with `node --check`.

## Browser checks performed

The interactive prototype was exercised in the available Chrome test browser:

- Sent a sample message and confirmed its display.
- Switched to the recipient and confirmed the same message appeared.
- Attached and sent the built-in sample handover file.
- Triggered its download and observed a successful browser download event.
- Reloaded and confirmed the message and file card persisted.
- Confirmed non-admin People view disabled the add-employee button.
- Added Alex Taylor as a fictional employee using the admin view.
- Disabled that profile and observed the re-enable control.
- Inspected the project overview and document view.
- Inspected the messenger and document layouts within a 390 px iframe. The messenger body had no horizontal page overflow; document tables intentionally support horizontal scrolling.

The browser checks are manual verification assisted by browser automation, not a committed end-to-end test suite. The download event confirms a download was produced; no independent byte-for-byte downloaded-file comparison was performed.

## Limits of this record

This is not a penetration test, accessibility certification, exhaustive browser compatibility test, storage-exhaustion test, Windows installer test or 20-user LAN load test. No actual message was delivered between independent computers. Browser-extension diagnostic errors are unrelated to the app code and were not treated as app test failures.

Record additional tests below with the actual environment, steps, expected result, observed result and date. Do not mark tests as passed unless you perform them.
