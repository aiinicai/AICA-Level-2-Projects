# Complete before submitting

| Field | Your details |
| --- | --- |
| Project title | OfficeLink: LAN Messaging and Document Sharing — Browser Demonstration |
| Student name | [Enter your name] |
| Student ID | [Enter your ID] |
| Institution | [Enter institution] |
| Programme / module | [Enter programme and module] |
| Supervisor | [Enter supervisor] |
| Submission date | [Enter date] |
| GitHub repository URL | [Paste your actual repository URL] |
| Your GitHub Pages URL | [Paste the exact published URL from repository Settings → Pages] |
| Supplied demonstration URL | https://officelink-capstone-demo.protrackacco-1269.chatgpt.site |

## Contribution statement

Describe the requirements you defined, design decisions you made, code you changed, testing you performed and conclusions you can defend. The supplied prototype was developed with ChatGPT assistance; identify that assistance and your own work accurately in the format required by your institution.

## Project deliverables

- Browser demonstration and source files.
- Problem statement and scope comparison.
- Architecture and data model description.
- Automated model tests and actual verification record.
- Examiner walkthrough.
- Your own screenshots, presentation, report and findings, if required by your course.
- Full Python LAN source and separate deployment evidence, if submitting the operational desktop system as well.

No institution approval, grade, originality assessment or capstone eligibility is implied by the supplied package.
