# OfficeLink: a small-office messaging and document-sharing system

## Problem statement

A team of approximately 20 people needs quick internal communication and document handovers. Employees should be able to ask a colleague to come to their desk, share a file and keep a conversation history. The application should be independent of a shared Zoho Mail account and should not require client-specific project spaces.

The main operational system is intended for an office LAN, with one designated host computer. A separate browser prototype allows examiners to evaluate the interaction design through a link.

## Aim and objectives

Build a clear, accessible demonstration of individual employee messaging and document exchange. The prototype should make the intended workflow observable, provide repeatable tests and state the distinction between local browser simulation and real network communication.

1. Provide a searchable employee directory and direct conversations.
2. Support message entry, timestamps, unread counts and local read indicators.
3. Support document attachment, size validation and download.
4. Demonstrate administration through fictional employee profiles.
5. Preserve demo data on reload when browser storage is available.
6. Make the source suitable for static hosting on GitHub Pages.

## Scope comparison

| Requirement | Browser prototype delivered here | Full LAN system target |
| --- | --- | --- |
| Individual identity | Switch among fictional employee views | Authenticated employee accounts |
| Direct messages | Stored locally, visible when switching views | Delivered between separate computers |
| Document sharing | Local blobs, downloadable through chat | Server-managed files with per-conversation access checks |
| Capacity | 5 MiB/file, 25 MiB attachment quota | 5 GiB shared storage, enforced on the host |
| Administration | Add/disable/re-enable local fictional profiles | Admin-controlled provisioning and password resets |
| Installation | Browser URL; no client installation | Packaged Windows host/client and desktop shortcuts |
| Security | Demo UI rules, not a security boundary | TLS, server authentication, session expiry and access control |
| Recovery | Reset to fictional sample data | Tested backup, restore and server migration |

The Python host, Windows installer, desktop shortcuts, TLS and real network transport are not implemented by this browser repository. The prior desktop application is a separate codebase and should be submitted separately if required by the course.

## Browser architecture

`index.html` supplies the app structure, `styles.css` the responsive layout, `model.js` the state transitions, and `app.js` the UI and persistence adapter. There is no build pipeline or backend dependency.

When Send is pressed:

1. Capture the current employee, recipient, message and optional file.
2. Validate account state, message length, file size and aggregate quota.
3. Produce a new state without mutating the previous state.
4. Write message metadata and the file blob in one IndexedDB transaction.
5. Update the UI only after the transaction succeeds.
6. When the reviewer switches to the recipient, show the same locally stored conversation and update the local read indicator.

Persistence operations within one tab are serialized. Multi-tab concurrency is outside the prototype scope; use one active tab.

## Data model

| Entity | Principal fields | Purpose |
| --- | --- | --- |
| Employee | id, name, role, admin, disabled, color | Fictional profile and display settings |
| Message | id, from, to, text, time, readBy, attachment | Conversation entry |
| Attachment metadata | id, name, size, type | Display and storage reference |
| Attachment blob | id → Blob | Original local file bytes |
| App state | version, activeUser, selectedPeer, users, messages | Persisted demo workspace |

IndexedDB has `state` and `files` object stores. The built-in sample checklist is seeded as text so it is always available after Reset. Uploaded demo documents use the `files` store. Rendering escapes user-entered strings, and attachments are downloaded rather than executed or embedded as HTML.

## Proposed live architecture

Employee desktop clients communicate with an authenticated Python host over the office network. The host validates each request, authorizes the employee's access to the conversation or file, and stores messages and documents in an office-controlled database. Administrators provision accounts and manage backups. This description is an architecture requirement, not evidence that the public browser demo provides those controls.

For an operational version, assess at least authentication, password hashing, TLS certificate distribution, session revocation, upload limits, file permissions, backup recovery, host availability and concurrent use from separate computers.

## Design choices

- **Static front end:** easy for reviewers to open and for the student to upload to GitHub Pages.
- **Plain JavaScript:** keeps the main logic readable without a framework or build toolchain.
- **IndexedDB:** stores file blobs and state locally and permits transactional updates.
- **Pure domain model:** supports repeatable tests without browser automation.
- **Explicit demo labels:** prevents local simulation from being confused with live multi-user functionality.
- **Fictional data:** demonstrates the workflow without publishing client or employee records.

## Limitations and future development

The prototype does not demonstrate real-time cross-device messaging, actual authentication, encryption of local IndexedDB data, notifications from a background desktop client, file malware scanning or reliable backup. It has no cross-tab conflict resolution. Browser data can be removed by the user or browser. Workload and security testing against a real 20-user LAN deployment remain separate tasks.

Future work may connect the front end to an authenticated backend, implement push delivery, introduce server-side document access controls and evaluate recovery procedures. These are future tasks, not completed demo features.
