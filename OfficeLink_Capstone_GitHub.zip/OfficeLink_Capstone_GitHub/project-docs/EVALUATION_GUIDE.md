# Examiner evaluation guide

Open the supplied live URL in a modern browser. No Python, email sign-in or desktop installation is needed. The initial profile is **Mira Patel · Admin**. All profiles are fictional and every browser has its own local workspace.

## Walkthrough and expected observations

| Step | Action | Expected observation |
| --- | --- | --- |
| 1 | Open Messenger and select Daniel Reed | A seeded conversation and sample checklist appear |
| 2 | Click Use a sample message, then Send | Message appears on Mira's side with a Saved in demo indicator |
| 3 | Click Switch to recipient | Daniel's view shows the same message from Mira |
| 4 | Switch back to Mira | The message indicates Read in demo |
| 5 | Attach a sample file, then Send | A file card appears with name, size and download control |
| 6 | Download the file | Browser downloads a text file containing fictional handover content |
| 7 | Refresh the page | Messages and attached file remain when IndexedDB is available |
| 8 | Open Documents and search for handover | The corresponding file appears; unmatched filenames are filtered out |
| 9 | Switch to Jules Morgan and open Documents | Mira/Daniel files are not listed in Jules's demo view |
| 10 | Switch to Mira, open People and add Alex Taylor | New fictional profile appears in the directory and identity switcher |
| 11 | Disable Alex Taylor | The disabled profile is excluded from the identity switcher; re-enable restores it |
| 12 | Switch to a non-admin employee and open People | Add and management controls are unavailable in the demo UI |
| 13 | Open About the project | Problem statement, architecture, scope comparison and limitations are visible |
| 14 | Click Reset demo data and confirm | Added messages, blobs and profiles are removed locally; examples are restored |

Reset affects only this browser's demo. It does not delete production OfficeLink data. Perform the walkthrough in one tab.

## Boundary tests

- Submit an empty message: it should not send.
- Attach a file larger than 5 MiB: the demo should reject it with a clear message.
- Fill the 25 MiB attachment allowance: further attachments should be rejected. Existing sample files count toward the allowance.
- Enter a duplicate employee name: the demo should reject the duplicate, regardless of case.
- Disable a colleague from Mira's view, then select the conversation: the composer should be disabled until that colleague is re-enabled.
- Enter text that resembles HTML: it should display as text, not run as markup.
- Use a narrow viewport: navigation and messages should remain usable; the documents table scrolls horizontally.

## Questions the student should be able to answer

1. Why does switching a demo employee not establish a real authenticated session?
2. How does a message move through validation, persistence and rendering?
3. Why are file bytes and message metadata saved in one transaction?
4. Which validation rules are tested in the pure model?
5. Why can GitHub Pages host this demonstration but not replace the Python LAN service?
6. What additional server-side controls are needed for real client documents?
7. How would you test delivery, access control and backup recovery on separate office computers?

## Evidence for submission

Provide your actual GitHub repository URL and published demo URL. Add screenshots or a short screen recording from your own walkthrough, your completed test observations, and an accurate statement of your contribution and development assistance. If you include the full desktop system, attach its source and test evidence separately; do not treat the browser demo's results as proof of LAN performance or security.
