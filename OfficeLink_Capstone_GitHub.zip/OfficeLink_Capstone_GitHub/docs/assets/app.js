/* Local interactive prototype. No network messaging or production authentication. */
(() => {
  'use strict';
  const M=window.OfficeLinkModel;
  const $=selector=>document.querySelector(selector);
  const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const initials=name=>name.trim().split(/\s+/).slice(0,2).map(s=>s[0]).join('').toUpperCase();
  const avatar=u=>`<span class="avatar" data-color="${Number(u?.color)||0}" aria-hidden="true">${esc(initials(u?.name||'?'))}</span>`;
  const fileIcon='<span class="file-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 3h9l5 5v13H5zM14 3v6h5M8 13h8M8 17h6"/></svg></span>';
  const size=bytes=>bytes<1024?`${bytes} B`:bytes<1024*1024?`${(bytes/1024).toFixed(1)} KiB`:`${(bytes/1024/1024).toFixed(1)} MiB`;
  const time=value=>new Date(value).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  const date=value=>new Date(value).toLocaleDateString([],{month:'short',day:'numeric'});
  let state=M.seed(),db=null,memoryOnly=false,view='messenger',pendingFile=null,toastTimer,queue=Promise.resolve(),sending=false;
  const memoryFiles=new Map();
  const views={messenger:['01 / THE WORKSPACE','Good conversations. Better teamwork.','A simple place for quick questions, shared documents and everyday work.'],documents:['02 / THE DOCUMENTS','Everything shared. Easy to find.','Sample documents, right alongside the conversations that matter.'],people:['03 / THE PEOPLE','A familiar face at every desk.','Individual employee views, in one shared demo workspace.'],project:['04 / THE CAPSTONE','Designed for a connected office.','The problem, the prototype and the architecture behind OfficeLink.']};
  function notify(message) {$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),5500);}
  function transactionDone(tx) {return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Storage failed.'));tx.onabort=()=>reject(tx.error||new Error('Storage was interrupted.'));});}
  function openDB() {return new Promise((resolve,reject)=>{const request=indexedDB.open('officelink-capstone-v1',1);request.onupgradeneeded=()=>{request.result.createObjectStore('state');request.result.createObjectStore('files');};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(new Error('Browser storage is blocked by another tab.'));});}
  function read(store,key) {return new Promise((resolve,reject)=>{const request=db.transaction(store).objectStore(store).get(key);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
  async function persist(next,attachment=null,reset=false) {
    if(memoryOnly) {if(reset)memoryFiles.clear();if(attachment)memoryFiles.set(attachment.id,attachment.blob);return;}
    const tx=db.transaction(['state','files'],'readwrite');
    const done=transactionDone(tx);
    if(reset)tx.objectStore('files').clear();
    if(attachment)tx.objectStore('files').put(attachment.blob,attachment.id);
    tx.objectStore('state').put(next,'current');
    await done;
  }
  function mutate(action,options={}) {
    queue=queue.then(async()=>{
      const next=action(state);
      await persist(next,options.attachment,options.reset);
      state=next;options.after?.();render();
      return true;
    }).catch(error=>{notify(error.name==='QuotaExceededError'?'Browser storage is full. Your change was not saved. Reset the demo or free browser storage.':error.message||'The change could not be saved.');return false;});
    return queue;
  }
  function clearDraft() {pendingFile=null;$('#message-text').value='';$('#file-input').value='';renderAttachment();}
  function setView(name) {
    if(!views[name])name='messenger';view=name;
    document.querySelectorAll('.view').forEach(el=>el.hidden=el.id!==`view-${name}`);
    document.querySelectorAll('.nav-button').forEach(button=>{button.classList.toggle('active',button.dataset.view===name);if(button.dataset.view===name)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');});
    [$('#section-label'),$('#page-title'),$('#page-subtitle')].forEach((el,i)=>el.textContent=views[name][i]);
    if(location.hash!==`#${name}`)history.replaceState(null,'',`#${name}`);
    render();
  }
  function render() {
    const me=M.active(state);
    $('#identity').innerHTML=state.users.filter(u=>!u.disabled).map(u=>`<option value="${esc(u.id)}" ${u.id===me.id?'selected':''}>${esc(u.name)}${u.admin?' · Admin':''}</option>`).join('');
    $('#people-count').textContent=state.users.filter(u=>!u.disabled).length;
    $('#storage-status').textContent=memoryOnly?'Session only · storage unavailable':'Saved on this browser';
    renderContacts();renderChat();renderDocuments();renderPeople();renderAttachment();
  }
  function renderContacts() {
    const query=$('#employee-search').value.trim().toLowerCase();
    const colleagues=state.users.filter(u=>u.id!==state.activeUser&&(!u.disabled||u.id===state.selectedPeer)&&`${u.name} ${u.role}`.toLowerCase().includes(query));
    $('#conversation-list').innerHTML=colleagues.map(u=>{
      const last=M.conversation(state,state.activeUser,u.id).at(-1),unread=M.unread(state,state.activeUser,u.id);
      const preview=u.disabled?'Account disabled':last?(last.text||`Document: ${last.attachment?.name}`):u.role;
      return `<button class="contact ${u.id===state.selectedPeer?'selected':''}" data-peer="${esc(u.id)}" aria-pressed="${u.id===state.selectedPeer}" aria-label="Chat with ${esc(u.name)}${unread?`, ${unread} unread`:''}">${avatar(u)}<span class="contact-text"><span class="contact-name">${esc(u.name)}</span><span class="contact-preview">${esc(preview)}</span></span>${unread?`<span class="unread">${unread}</span>`:''}</button>`;
    }).join('')||'<div class="empty-state">No colleagues match your search.</div>';
  }
  function renderChat() {
    const peer=M.user(state,state.selectedPeer),me=M.active(state);
    $('#chat-person').innerHTML=`${avatar(peer)}<div><strong>${esc(peer.name)}</strong><small>${esc(peer.role)} · ${peer.disabled?'Disabled demo profile':'Demo employee'}</small></div>`;
    const disabled=peer.disabled||me.disabled;
    $('#message-text').disabled=disabled;$('#attach-file').disabled=disabled;$('#send-message').disabled=disabled||sending;
    $('#message-text').placeholder=disabled?'This demo account is disabled. Enable it from People.':'Write a message…';
    const messages=M.conversation(state);let lastDay='';
    $('#messages').innerHTML=messages.map(m=>{
      const owner=M.user(state,m.from),outgoing=m.from===me.id,day=new Date(m.time).toDateString();let marker='';
      if(day!==lastDay){marker=`<div class="day-marker">${esc(day===new Date().toDateString()?'Today · sample workspace':date(m.time))}</div>`;lastDay=day;}
      const read=m.readBy.includes(m.to);
      return `${marker}<article class="message ${outgoing?'outgoing':'incoming'}" aria-label="Message from ${esc(owner.name)}">${avatar(owner)}<div class="message-content"><div class="bubble">${m.text?`<span>${esc(m.text)}</span>`:''}${m.attachment?`<button class="file-bubble" data-download="${esc(m.id)}" aria-label="Download ${esc(m.attachment.name)}">${fileIcon}<span class="file-details"><strong>${esc(m.attachment.name)}</strong><small>${size(m.attachment.size)} · Download document</small></span><span class="file-download" aria-hidden="true">↓</span></button>`:''}</div><div class="message-meta"><span>${esc(time(m.time))}</span>${outgoing?`<span aria-label="${read?'Read in demo':'Saved in demo'}">${read?'✓✓ Read in demo':'✓ Saved in demo'}</span>`:''}</div></div></article>`;
    }).join('')||`<div class="empty-state"><strong>Say hello to ${esc(peer.name.split(' ')[0])}.</strong>Start this fictional conversation with a message or document.</div>`;
    $('#messages').scrollTop=$('#messages').scrollHeight;
  }
  function renderAttachment() {
    $('#attachment-preview').hidden=!pendingFile;
    $('#attachment-preview').innerHTML=pendingFile?`<span>↳ ${esc(pendingFile.name)} · ${size(pendingFile.size)}</span><button type="button" id="remove-attachment" aria-label="Remove attachment">×</button>`:'';
  }
  function renderDocuments() {
    const used=M.storageUsed(state);$('#storage-value').textContent=`${size(used)} / 25 MiB`;$('#storage-fill').style.width=`${Math.min(100,used/M.QUOTA*100)}%`;
    const query=$('#document-search').value.trim().toLowerCase();
    const docs=M.documents(state).filter(m=>m.attachment.name.toLowerCase().includes(query));
    $('#document-list').innerHTML=docs.length?`<div class="table-wrap"><table class="document-table"><thead><tr><th>DOCUMENT</th><th>CONVERSATION</th><th>SHARED</th><th><span class="sr-only">Download</span></th></tr></thead><tbody>${docs.map(m=>{
      const peer=M.user(state,m.from===state.activeUser?m.to:m.from);
      return `<tr><td><div class="file-cell">${fileIcon}<span><strong>${esc(m.attachment.name)}</strong><small>${size(m.attachment.size)} · ${m.attachment.sampleContent?'Sample document':'Local attachment'}</small></span></div></td><td>${esc(peer.name)}</td><td>${esc(date(m.time))}</td><td><button class="download-button" data-download="${esc(m.id)}" aria-label="Download ${esc(m.attachment.name)}">Download ↓</button></td></tr>`;
    }).join('')}</tbody></table></div>`:'<div class="empty-state"><strong>No documents here yet.</strong>Attach a file in a conversation, or try a different search.</div>';
  }
  function renderPeople() {
    const admin=!!M.active(state).admin;
    $('#add-employee').disabled=!admin;
    $('#admin-note').textContent=admin?'Admin demonstration: add or disable fictional employee profiles. These controls only change local demo data; there are no real passwords or user accounts.':'You are viewing a fictional employee profile. Switch to Mira Patel (Admin) above to try adding or disabling demo employees.';
    $('#people-grid').innerHTML=state.users.map(u=>`<article class="person-card ${u.disabled?'disabled-card':''}"><div class="person-card-top">${avatar(u)}<span class="person-tag ${u.disabled?'disabled':''}">${u.disabled?'DISABLED':u.admin?'DEMO ADMIN':'DEMO EMPLOYEE'}</span></div><h3>${esc(u.name)}</h3><p>${esc(u.role)}</p><div class="person-card-bottom">${u.id!==state.activeUser&&!u.disabled?`<button class="inline-link" data-peer="${esc(u.id)}">Open conversation →</button>`:`<span class="inline-link">${u.id===state.activeUser?'Current demo view':'Account unavailable'}</span>`}${admin&&!u.admin?`<button class="inline-link danger-link" data-toggle-user="${esc(u.id)}">${u.disabled?'Enable':'Disable'} profile</button>`:''}</div></article>`).join('');
  }
  async function download(messageId) {
    const message=M.documents(state).find(m=>m.id===messageId);if(!message){notify('This file is outside the selected demo conversation view.');return;}
    const file=message.attachment;
    try{
      const blob=file.sampleContent!==undefined?new Blob([file.sampleContent],{type:'text/plain;charset=utf-8'}):memoryOnly?memoryFiles.get(file.id):await read('files',file.id);
      if(!blob)throw new Error('The local file is no longer available. Reset the demo or attach it again.');
      const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=file.name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);notify(`Download started: ${file.name}`);
    }catch(error){notify(error.message||'The file could not be downloaded.');}
  }
  function chooseFile(file) {
    if(!file)return;
    try{M.validateFile(state,file);pendingFile=file;renderAttachment();notify('Document attached. Press Send to share it in the demo.');}catch(error){notify(error.message);$('#file-input').value='';}
  }
  document.addEventListener('click',event=>{
    const viewButton=event.target.closest('[data-view]');if(viewButton){setView(viewButton.dataset.view);return;}
    const peer=event.target.closest('[data-peer]');if(peer){mutate(s=>M.selectPeer(s,peer.dataset.peer),{after:()=>{clearDraft();setView('messenger');}});return;}
    const dl=event.target.closest('[data-download]');if(dl){download(dl.dataset.download);return;}
    const toggle=event.target.closest('[data-toggle-user]');if(toggle){mutate(s=>M.toggleEmployee(s,toggle.dataset.toggleUser),{after:()=>notify('Demo employee profile updated.')});return;}
    if(event.target.closest('#remove-attachment')){pendingFile=null;$('#file-input').value='';renderAttachment();}
  });
  $('#identity').addEventListener('change',event=>{const value=event.target.value;mutate(s=>M.switchIdentity(s,value),{after:()=>{clearDraft();notify('Employee view switched. This is a demo, not a sign-in.');}});});
  $('#employee-search').addEventListener('input',renderContacts);$('#document-search').addEventListener('input',renderDocuments);
  $('#view-shared').addEventListener('click',()=>{setView('documents');notify('Showing documents from all your demo conversations.');});
  $('#attach-file').addEventListener('click',()=>$('#file-input').click());$('#file-input').addEventListener('change',event=>chooseFile(event.target.files[0]));
  $('#message-text').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();$('#composer').requestSubmit();}});
  $('#composer').addEventListener('submit',async event=>{
    event.preventDefault();if(sending)return;
    const text=$('#message-text').value,file=pendingFile,from=state.activeUser,to=state.selectedPeer;
    if(!text.trim()&&!file){notify('Write a message or attach a document first.');return;}
    const fileId=file?M.id():null;
    const attachment=file?{id:fileId,name:file.name,size:file.size,type:file.type||'application/octet-stream'}:null;
    sending=true;$('#send-message').disabled=true;
    await mutate(s=>{if(s.activeUser!==from||s.selectedPeer!==to)throw new Error('The conversation changed. Please send the message again.');return M.send(s,text,attachment);},{attachment:file?{id:fileId,blob:file}:null,after:()=>{clearDraft();notify('Message saved. Switch to the recipient to view it.');}});
    sending=false;renderChat();
  });
  $('#sample-message').addEventListener('click',()=>{$('#message-text').value='Could you come over to my desk for a quick discussion?';$('#message-text').focus();});
  $('#sample-file').addEventListener('click',()=>chooseFile(new File(['OFFICELINK SAMPLE HANDOVER\n\nTask: Team discussion\nStatus: Ready for review\nNext step: Meet at the office desk\n\nFictional content for capstone evaluation only.\n'],'Team-handover-demo.txt',{type:'text/plain'})));
  $('#switch-recipient').addEventListener('click',()=>{const recipient=state.selectedPeer;mutate(s=>M.switchIdentity(s,recipient),{after:()=>{clearDraft();notify('Now viewing the recipient’s side of this conversation.');}});});
  $('#add-employee').addEventListener('click',()=>{$('#employee-form').reset();$('#employee-dialog').showModal();});
  $('#close-dialog').addEventListener('click',()=>$('#employee-dialog').close());
  $('#employee-form').addEventListener('submit',event=>{event.preventDefault();const form=new FormData(event.target);mutate(s=>M.addEmployee(s,form.get('name'),form.get('role')),{after:()=>{$('#employee-dialog').close();notify('Fictional employee added to this browser.');}});});
  $('#reset-demo').addEventListener('click',()=>{if(confirm('Reset OfficeLink demo data in this browser? This removes all locally added messages, files and profiles and restores the fictional examples.'))mutate(()=>M.seed(),{reset:true,after:()=>{clearDraft();$('#employee-search').value='';$('#document-search').value='';setView('messenger');notify('The demo has been reset to its sample workspace.');}});});
  window.addEventListener('hashchange',()=>setView(location.hash.slice(1)));
  async function boot(){
    try{db=await openDB();const saved=await read('state','current');if(saved?.version===1&&Array.isArray(saved.users)&&Array.isArray(saved.messages)&&saved.users.some(u=>u.id===saved.activeUser)&&saved.users.some(u=>u.id===saved.selectedPeer)){state=saved;}else await persist(state);db.onversionchange=()=>{db.close();notify('Another version of this demo opened. Refresh this page.');};}
    catch(error){memoryOnly=true;$('#storage-warning').hidden=false;$('#storage-warning').textContent='Persistent browser storage is unavailable. You can still try the demo, but your changes will be lost when this page closes or reloads.';}
    state=M.selectPeer(state,state.selectedPeer);try{await persist(state);}catch(error){notify('Browser storage could not save the current view.');}
    setView(location.hash.slice(1)||'messenger');
  }
  boot();
})();
