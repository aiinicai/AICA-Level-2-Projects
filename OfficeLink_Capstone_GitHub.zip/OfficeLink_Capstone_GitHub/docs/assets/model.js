/* OfficeLink capstone demo: pure, browser-local domain model. No authentication. */
(function (root, factory) {
  const model = factory();
  if (typeof module === 'object' && module.exports) module.exports = model;
  else root.OfficeLinkModel = model;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const FILE_LIMIT = 5 * 1024 * 1024;
  const QUOTA = 25 * 1024 * 1024;
  const MAX_MESSAGES = 1000;
  const clone = value => structuredClone(value);
  const id = () => globalThis.crypto?.randomUUID?.() || `demo-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  function seed() {
    const now = Date.now();
    const users = [
      {id:'mira',name:'Mira Patel',role:'Office administrator',admin:true,color:0,disabled:false},
      {id:'daniel',name:'Daniel Reed',role:'Audit lead',admin:false,color:1,disabled:false},
      {id:'sofia',name:'Sofia Chen',role:'Accounts associate',admin:false,color:2,disabled:false},
      {id:'omar',name:'Omar Hassan',role:'Review manager',admin:false,color:4,disabled:false},
      {id:'leah',name:'Leah Brooks',role:'Operations coordinator',admin:false,color:3,disabled:false},
      {id:'jules',name:'Jules Morgan',role:'Audit associate',admin:false,color:5,disabled:false}
    ];
    const sample = 'OFFICELINK — FICTIONAL DEMO DOCUMENT\n\nAudit preparation checklist\n\n[ ] Confirm the review timetable\n[ ] Prepare the document request list\n[ ] Allocate the review sections\n[ ] Schedule the team discussion\n\nThis file is sample material for a capstone demonstration.\nIt contains no client information and is not professional audit guidance.\n';
    const attachment = {id:'sample-checklist',name:'Audit-preparation-checklist.txt',size:new TextEncoder().encode(sample).length,type:'text/plain',sampleContent:sample};
    const msg = (from,to,text,mins,extra={}) => ({id:id(),from,to,text,time:now-mins*60000,readBy:[from],...extra});
    const messages = [
      msg('daniel','mira','Good morning, Mira. The audit preparation checklist is ready for the team.',42,{readBy:['daniel','mira']}),
      msg('mira','daniel','Thanks, Daniel. Could you share it here? We can review it before the team meeting.',39,{readBy:['mira','daniel']}),
      msg('daniel','mira','Of course. Here is the sample checklist.',37,{attachment,readBy:['daniel','mira']}),
      msg('mira','daniel','Received, thank you. Please come over to my desk when you have a moment.',35,{readBy:['mira','daniel']}),
      msg('daniel','mira','Will do. I’ll bring my review notes too.',33,{readBy:['daniel','mira']}),
      msg('sofia','mira','The sample expense summary is ready to review whenever you are free.',28),
      msg('omar','mira','Can we have a quick catch-up after lunch?',24),
      msg('mira','leah','Please keep the meeting room available for the team discussion.',55,{readBy:['mira','leah']}),
      msg('leah','mira','All set. The room is available from 2 pm.',49,{readBy:['leah','mira']}),
      msg('jules','mira','Hello! I have joined the demo workspace.',12),
      msg('sofia','daniel','Let me know if you need any sample schedules for the review.',18)
    ];
    return {version:1,activeUser:'mira',selectedPeer:'daniel',users,messages};
  }
  function user(state,userId) {return state.users.find(u=>u.id===userId);}
  function active(state) {return user(state,state.activeUser);}
  function conversation(state,a=state.activeUser,b=state.selectedPeer) {return state.messages.filter(m=>(m.from===a&&m.to===b)||(m.from===b&&m.to===a)).sort((x,y)=>x.time-y.time);}
  function unread(state,owner,peer) {return state.messages.filter(m=>m.to===owner&&m.from===peer&&!m.readBy.includes(owner)).length;}
  function documents(state,owner=state.activeUser) {return state.messages.filter(m=>m.attachment&&(m.to===owner||m.from===owner)).sort((a,b)=>b.time-a.time);}
  function storageUsed(state) {return state.messages.reduce((total,m)=>total+(m.attachment?.size||0),0);}
  function validateFile(state,file) {
    if (!file || typeof file.name!=='string' || !file.name.trim() || file.name.length>255) throw new Error('Choose a file with a name of 1–255 characters.');
    if (!Number.isFinite(file.size)||file.size<0) throw new Error('This file could not be read.');
    if (file.size>FILE_LIMIT) throw new Error('The browser demo accepts files up to 5 MiB each.');
    if (storageUsed(state)+file.size>QUOTA) throw new Error('The 25 MiB demo quota is full. Reset the demo to clear its attachments.');
    return true;
  }
  function send(state,text,attachment) {
    const sender=active(state),recipient=user(state,state.selectedPeer);
    if(!sender||sender.disabled||!recipient||recipient.disabled||sender.id===recipient.id) throw new Error('Choose an enabled colleague to send a message.');
    text=String(text||'').trim();
    if(!text&&!attachment) throw new Error('Write a message or attach a document first.');
    if(text.length>4000) throw new Error('Messages can contain up to 4,000 characters.');
    if(state.messages.length>=MAX_MESSAGES) throw new Error('The demo holds up to 1,000 messages. Reset the demo to start again.');
    if(attachment) validateFile(state,attachment);
    const next=clone(state);
    const message={id:id(),from:sender.id,to:recipient.id,text,time:Date.now(),readBy:[sender.id]};
    if(attachment) message.attachment=clone(attachment);
    next.messages.push(message);
    return next;
  }
  function selectPeer(state,peerId) {
    const peer=user(state,peerId);
    if(!peer||peer.id===state.activeUser) throw new Error('Choose another employee.');
    const next=clone(state);next.selectedPeer=peerId;
    next.messages.forEach(m=>{if(m.to===next.activeUser&&m.from===peerId&&!m.readBy.includes(next.activeUser))m.readBy.push(next.activeUser);});
    return next;
  }
  function switchIdentity(state,userId) {
    const target=user(state,userId);
    if(!target||target.disabled) throw new Error('This demo employee is disabled.');
    const next=clone(state),previous=next.activeUser;
    next.activeUser=userId;
    const candidate=userId!==previous?previous:next.selectedPeer;
    const peer=user(next,candidate)?.disabled?next.users.find(u=>u.id!==userId&&!u.disabled)?.id:candidate;
    return selectPeer(next,peer);
  }
  function assertAdmin(state) {if(!active(state)?.admin||active(state)?.disabled) throw new Error('Switch to Mira Patel to try the admin demonstration.');}
  function addEmployee(state,name,role) {
    assertAdmin(state);name=String(name||'').trim();role=String(role||'').trim();
    if(!name||name.length>50||!role||role.length>60) throw new Error('Enter a name (up to 50 characters) and role (up to 60 characters).');
    if(state.users.length>=25) throw new Error('This demo allows up to 25 fictional employees.');
    if(state.users.some(u=>u.name.toLowerCase()===name.toLowerCase())) throw new Error('A demo employee with that name already exists.');
    const next=clone(state);next.users.push({id:id(),name,role,admin:false,disabled:false,color:state.users.length%6});return next;
  }
  function toggleEmployee(state,userId) {
    assertAdmin(state);const target=user(state,userId);
    if(!target||target.admin||target.id===state.activeUser) throw new Error('The demo administrator must remain enabled.');
    const next=clone(state);user(next,userId).disabled=!target.disabled;return next;
  }
  return {FILE_LIMIT,QUOTA,MAX_MESSAGES,id,seed,user,active,conversation,unread,documents,storageUsed,validateFile,send,selectPeer,switchIdentity,addEmployee,toggleEmployee};
});
