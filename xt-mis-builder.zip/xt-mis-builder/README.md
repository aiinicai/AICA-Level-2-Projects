# XT Consolidated MIS Builder

Python tool that prepares the monthly **XT Ships Management India – Consolidated MIS** workbook by populating the prior-month MIS (used as the template) with current-month data. It preserves sheet order, formats, formulas and cross-sheet links.

## What it populates

| Sheet | Source |
|---|---|
| Master | Reporting period dates |
| Cheque issued | Tally Payment vouchers + DBS statement (inward clearing) |
| Petty Cash | Tally `Cash in Hand` ledger |
| Bank book-AXIS | Axis bank statement screenshot (image) |
| Bank Book- DBS | DBS bank statement Excel |
| DE-XT / DE-ICE | Tally Purchase/Debit Note vouchers numbered `/XT/` and `/ICE/` (Reimb ledgers + GST) |
| General / CR | Tally Indirect Expenses ledger lines (excl. depreciation), payroll by employee |
| Inter Company Transfer | Tally ASM inter-company ledger |
| Consolidated CR | Monthly figures from Tally ledgers + REM reimbursement invoices |
| Employees Loan Repayment | Tally payroll voucher – `Loan to Employees` cost-centre allocations |
| Forex | RBI Reference Rate Archive (USD, first published date of next month) |
| CB | Retitled; prior-month crew data cleared (mandays not in Tally) |

## Rules built in
- **Full Tally narrations** are reproduced in the MIS without truncation.
- Repeated figures are **linked by formula**, not hard-coded (e.g. DE exchange rate → `Forex!C2`; CR → `SUMIF` on General).
- Pivot tables in General/CR are replaced by live `SUMIF` summaries.
- Built-in check cells (should read 0): General grand total vs Tally, gross vs net+GST, pivot-replacement total.
- Employee Loan sheet shows only the MIS month.

## Folder structure
```
src/build_mis.py        main builder
data/                   extracted Tally data (confidential – git-ignored)
  de_xt.csv, de_ice.csv   DE vouchers (see *.sample.csv for columns)
  gendata.py              General expense lines
  payroll.py              payroll earnings by employee
  narr.py                 full Tally narrations mapped to MIS rows
templates/Format_Template.xlsx   prior-month MIS (git-ignored)
inputs/April_Book_DBS.xlsx, inputs/axis.png   bank sources (git-ignored)
output/                 generated workbook (git-ignored)
```

## Usage
```bash
pip install -r requirements.txt
python src/build_mis.py
```
Paths can be overridden: `MIS_TEMPLATE`, `MIS_DBS`, `MIS_AXIS_IMG`, `MIS_DATA`, `MIS_OUTPUT`.

After building, open the output in Excel (or recalculate with LibreOffice headless) so formulas calculate:
```bash
soffice --headless --convert-to xlsx --outdir output/recalc "output/XT Consolidated MIS.xlsx"
```

## Monthly process
1. Extract the month's data from Tally Prime (MCP connector): ledger lines, payroll vouchers, cash ledger, inter-company ledger, loan allocations.
2. Update files in `data/`, place the prior-month MIS in `templates/` and bank files in `inputs/`.
3. Obtain the RBI USD reference rate (first published date of the following month) and update `RATE` in `build_mis.py`.
4. Run the builder; review check cells; paste the RBI screenshot into the Forex sheet.

## Current version
Built for **April 2026** (Tally company: XT Ships Management India Pvt Ltd; USD/INR 94.9432 as on 04.05.2026). Month-specific values (period dates, titles, instalment counts, Feb/Mar Consolidated CR figures) are currently set inside `build_mis.py` and should be updated each month.

## Confidentiality
The `data/`, `inputs/`, `templates/` and `output/` folders contain client financial and employee salary data. **Do not commit them.** Use a **private** repository.
