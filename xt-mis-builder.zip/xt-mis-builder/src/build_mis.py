"""XT Consolidated MIS builder - populates the prior-month MIS template with current-month data
extracted from Tally Prime (via MCP), DBS/Axis bank files and the RBI USD reference rate.
Usage:  python src/build_mis.py   (paths configurable via environment variables below)
"""
import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE=os.environ.get('MIS_TEMPLATE',os.path.join(ROOT,'templates','Format_Template.xlsx'))
DBS_FILE=os.environ.get('MIS_DBS',os.path.join(ROOT,'inputs','April_Book_DBS.xlsx'))
AXIS_IMG=os.environ.get('MIS_AXIS_IMG',os.path.join(ROOT,'inputs','axis.png'))
DATA_DIR=os.environ.get('MIS_DATA',os.path.join(ROOT,'data'))
OUTPUT=os.environ.get('MIS_OUTPUT',os.path.join(ROOT,'output','XT Consolidated MIS.xlsx'))
import openpyxl, copy, csv, re, datetime as dt, sys
sys.path.insert(0,DATA_DIR)
from openpyxl.drawing.image import Image as XLImage
from openpyxl.comments import Comment
from gendata import G, DEP
from narr import V, GID, ASSETS, DE, PC, IC
V[49242]='Bill no P00417 dt. 24.04.26 Go pro purchase for parwinder singh , same has been handed over to CC ajinkya badekar at sea bird medicare Centre while PJM on 25.04.26'
import payroll as P
D=lambda s: dt.datetime.strptime(s,'%Y-%m-%d')
RATE=94.9432
wb=openpyxl.load_workbook(TEMPLATE)

def cstyle(ws,src_row,dst_row,c1,c2):
    for c in range(c1,c2+1):
        s=ws.cell(src_row,c); d=ws.cell(dst_row,c)
        if s.has_style: d._style=copy.copy(s._style)
    if ws.row_dimensions[src_row].height: ws.row_dimensions[dst_row].height=ws.row_dimensions[src_row].height
def clear(ws,r1,r2,c1,c2):
    for r in range(r1,r2+1):
        for c in range(c1,c2+1):
            cell=ws.cell(r,c)
            if not isinstance(cell,openpyxl.cell.cell.MergedCell): cell.value=None
def unmerge_from(ws,rmin,rmax=10**7):
    for m in list(ws.merged_cells.ranges):
        if m.min_row>=rmin and m.max_row<=rmax: ws.unmerge_cells(str(m))

# ---------------- Master
m=wb['Master']; m['B5']=D('2026-04-01'); m['B6']=D('2026-04-30')

# ---------------- Cheque issued
ws=wb['Cheque issued']
ws['C2']=' Cheque issued for the month of APR 2026'; ws['C10']=' Cheque issued for the month of APR 2026'
clear(ws,5,6,2,7); clear(ws,13,14,2,7)
ws['B5']=D('2026-04-22'); ws['C5']='000016'; ws['D5']='Universal Currency Exchange (I) Pvt Ltd - 16 BY IWCLG/000016/UNIVERSAL CURRENCY EXCHAN/HDFC BANK LTD.'
ws['E5']=113050; ws['F5']='Travelling Expenses'; ws['G5']=V[49396]
ws['D13']='No cheque issued during the month'; ws['E13']=0

# ---------------- Petty Cash (Tally: Cash in Hand)
ws=wb['Petty Cash']
ws['B7']='Petty Cash for the month of APR 2026'
clear(ws,11,27,2,8)
ws['D10']='Bal Cd fwd of 31.03.26'; ws['H10']=5145
pc=[('01.04.26','Santhana Clyobas Prosper Rajiv','Excess amount returned - transport of spares to vessel Blue Sky (credited to ICE DA)',3400,None),
('07.04.26','Cash Paid','Airtel sim service fee, lunch - chair pick up, knife pick up (MIDC)',None,1151),
('12.04.26','Bajrang Auto Service','Petrol expenses',None,1000),
('14.04.26','Siddhivinayak Medical','Sanitary pad',None,565),
('14.04.26','Sanjay','Fruits - Ambedkar Jayanti',None,870),
('14.04.26','Cash Paid','Dishwash salt & liquid set',None,1201),
('16.04.26','Cash Paid','Lunch for officer',None,340),
('20.04.26','Sai Palace Hotel','Lunch for cadet & officer',None,624),
('21.04.26','Sai Palace Hotel','Lunch for cadet & officer',None,624),
('28.04.26','We Fast','Conversion letter to Axis bank',None,420),
('28.04.26','Sai Palace Hotel','Lunch - Rohit Suthar & officer',None,851),
('30.04.26','Sai Palace Hotel','Lunch - Rohit Suthar & officer',None,926),
('30.04.26','Axis Bank 6132','Cash withdrawal (Contra 4)',20000,None)]
for i,(d,n,t,rc,pd) in enumerate(pc):
    r=11+i; cstyle(ws,11,r,2,8)
    ws.cell(r,2,d); ws.cell(r,3,n); ws.cell(r,4,PC[i])
    if rc: ws.cell(r,6,rc); ws.cell(r,7,0); ws.cell(r,8,f'=H{r-1}+F{r}')
    else: ws.cell(r,7,pd); ws.cell(r,8,f'=H{r-1}-G{r}')
assert 5145+3400+20000-sum(x[4] or 0 for x in pc)==19973

# ---------------- DE sheets
def seq(v):
    s=v.split('/')[-1]; return 1 if s=='1186' else int(s)
def fill_de(ws,fn,last,tot,bank,xt):
    rows=sorted(csv.DictReader(open(fn)),key=lambda r:seq(r['vno']))
    ws['P1']='26 APR'; ws['K12']='Exch rate as on 04.05.2026'
    clear(ws,13,last,1,24)
    for i,x in enumerate(rows+[bank]):
        r=13+i; cstyle(ws,13,r,1,16); ws.row_dimensions[r].hidden=False
        tx=float(x['tx']); g=float(x['gst'])
        ws.cell(r,1,i+1); ws.cell(r,5,DE.get(x['vno'],x['n'])); ws.cell(r,7,D(x['d'])); ws.cell(r,8,x['party']); ws.cell(r,9,x['ref'])
        ws.cell(r,10,tx); ws.cell(r,11,'=Forex!$C$2'); ws.cell(r,12,f'=J{r}/K{r}'); ws.cell(r,13,g); ws.cell(r,14,f'=J{r}+M{r}')
        ws.cell(r,15,'Eligible' if g!=0 else 'Non-GST')
        ws.cell(r,16, x['vno'] if (xt or x is bank) else f'=+$P$1&"/"&$P$2&"/"&A{r}')
    used=13+len(rows)
    for r in range(used+1,last+1): ws.row_dimensions[r].hidden=True
    return len(rows),sum(float(x['tx']) for x in rows)
nx,tx_x=fill_de(wb['DE-XT'],os.path.join(DATA_DIR,'de_xt.csv'),155,156,dict(tx='10800',gst='0',n='Reimb - Bank charges: DBS remittance charges - GST on Fx (USD 689,062.76 inward)',d='2026-04-02',party='DBS Bank Ltd',ref='NA',vno='Payment 2 dt. 02.04.26'),True)
ni,tx_i=fill_de(wb['DE-ICE'],os.path.join(DATA_DIR,'de_ice.csv'),79,80,dict(tx='10800',gst='0',n='Reimb - Bank charges: DBS remittance charges - GST on Fx',d='2026-04-08',party='DBS Bank Ltd',ref='NA',vno='Payment 211 dt. 08.04.26'),False)
assert (nx,round(tx_x,2),ni,tx_i)==(125,3025249.34,49,907750.0)

# ---------------- Bank book-AXIS (screenshot)
ws=wb['Bank book-AXIS ']
ws._images=[]
img=XLImage(AXIS_IMG); img.anchor='B4'; ws.add_image(img)
ws['B3']='AXIS BANK STATEMENT - A/c 455010200006132 (01.04.2026 to 12.05.2026; balance as on 30.04.2026 Rs 4,36,445.38)'

# ---------------- Bank Book- DBS (statement)
ws=wb['Bank Book- DBS']
src=openpyxl.load_workbook(DBS_FILE).active
clear(ws,1,ws.max_row,1,9)
for r in range(1,src.max_row+1):
    if r>=7: cstyle(ws,7,r,1,9)
    for c in range(1,10):
        v=src.cell(r,c).value
        if v not in (None,): ws.cell(r,c,v)

# ---------------- Inter Company Transfer
ws=wb['Inter Company Transfer']
unmerge_from(ws,4)
clear(ws,3,15,2,6)
ws['B3']='ASManagement Operations India Pvt Ltd'; ws['C3']='Opening balance'; ws['D3']=27363.04
ws['E3']='Outstanding as on 31 Mar 26 (Dr - receivable from ASM)'; ws['F3']=D('2026-03-31')
ic=[('Petrol expenses - Ciaz car (Journal 9)','Credit',-2574.87,'Petrol expenses dt. 19.04.26 for Ciaz Car, Bajrang Auto Service','2026-04-19'),
('Swiggy - Go Pro purchase (Journal 2)','Credit',-16011,'Bill P00417 dt. 24.04.26 Go Pro for Parwinder Singh, handed over to CC Ajinkya Badekar','2026-04-28'),
('Airtel group bill - ASM users (Journal 7)','Debit',3896,'Airtel group bill MF2727I001683891 dt. 24.04.26 - users Rohit Suthar, Nair, Priya','2026-04-30'),
('Airtel mobile bills - XT users (Journal 8)','Credit',-4517.46,'Airtel bills Mar-Apr 26 paid by ASM for XT users','2026-04-30'),
('Amazon balance - Go Pro (Journal 10)','Credit',-14990,'Go Pro amount credited to Amazon balance; product not available (order 408-4163378-1768332)','2026-04-30')]
for i,(b,c,d,e,f) in enumerate(ic):
    r=5+i; cstyle(ws,5,r,2,6); ws.cell(r,2,b); ws.cell(r,3,c); ws.cell(r,4,d); ws.cell(r,5,V[IC[i]]); ws.cell(r,6,D(f))
assert round(27363.04+sum(x[2] for x in ic),2)==-6834.29

# ---------------- General
ws=wb['General']; ws._pivots=[]
st_item=[copy.copy(ws.cell(4,c)._style) for c in range(1,13)]
st_sub=[copy.copy(ws.cell(6,c)._style) for c in range(1,13)]
st_gt=[copy.copy(ws.cell(195,c)._style) for c in range(1,13)]
st_t202=[copy.copy(ws.cell(202,c)._style) for c in range(1,13)]
st_h203=[copy.copy(ws.cell(203,c)._style) for c in range(1,13)]
st_pl=[copy.copy(ws.cell(210,c)._style) for c in range(1,13)]
st_pv=[copy.copy(ws.cell(211,c)._style) for c in range(1,13)]
unmerge_from(ws,3)
clear(ws,3,ws.max_row,1,15)
for r in range(3,ws.max_row+1):
    for c in range(1,13): ws.cell(r,c)._style=copy.copy(ws.cell(3,c)._style)
def put(r,styles): 
    for c in range(1,13): ws.cell(r,c)._style=copy.copy(styles[c-1])
order=["PROFESSIONAL FEES","COURIER CHARGES","HOUSEKEEPING CHARGES","SECURITY CHARGES","ADVERTISMENT","PANTRY EXPENSES","PRINTING & STATIONERY",
"ELECTRICITY CHARGES","TRAVEL EXPENSES","Health Insurance","Society Maintainance","PROPERTY TAX","PETROL EXPENSES","OFFICE GENERAL EXPENSES",
"OFFICE STAFF WELFARE","OFFICE EQUIPMENT EXPENSE","REPAIR & MAINTANANCE","OFFICE INTERNET CHARGES","MOBILE & TELEPHONE CHARGES","HOTEL EXPENSES",
"COURSE FEES","LICENSES & RENEWALS","ROC FEES","NETWORKING WORKS","PENALTY & CHARGES","STAFF SALARY","LEAVE ENCASHMENT","REIMBURSMENT",
"BANK CHARGES","EMPLOYER CONTRIBUTION TO PF"]
lines={h:[] for h in order}
for k,(h,party,d,led,net,cg,n) in enumerate(G): lines[h].append((party,D(d),led,net,cg,V[GID[k]]))
for i,nm in enumerate(P.names):
    gross=P.basic[i]+P.hra[i]+P.conv[i]+P.med[i]+P.attire[i]+P.special[i]
    lines["STAFF SALARY"].append((nm,D('2026-04-30'),'Payroll 56 - gross earnings',gross,0,'APR 26'))
for nm,a in P.reimb.items():
    lines["REIMBURSMENT"].append((nm,D('2026-04-30'),'Reimbursements to Employees (Payroll 56)',a,0,'APR 26'))
assert set(lines)==set(order) and all(lines[h] for h in order)
r=4
for h in order:
    L=lines[h]; first=r
    for party,d,led,net,cg,n in L:
        put(r,st_item)
        ws.cell(r,2,h); ws.cell(r,3,party); ws.cell(r,4,f'=K{r}+SUM(H{r}:J{r})'); ws.cell(r,5,n); ws.cell(r,6,d); ws.cell(r,7,led)
        if cg: ws.cell(r,8,cg); ws.cell(r,9,cg)
        ws.cell(r,11,net); r+=1
    if len(L)>1:
        put(r,st_sub); ws.cell(r,3,'SUB TOTAL'); ws.cell(r,4,f'=SUM(D{first}:D{r-1})'); r+=1
    r+=1
last=r-1; GT=r+1
put(GT,st_gt)
ws.cell(GT,3,'GRAND TOTAL'); ws.cell(GT,4,f'=SUMIF($C$4:$C${last},"<>SUB TOTAL",D4:D{last})')
for col in 'HIJK': ws[f'{col}{GT}']=f'=SUM({col}4:{col}{last})'
ws.cell(GT,12,f'=ROUND(D{GT}-SUM(H{GT}:K{GT}),2)'); ws.cell(GT,12).comment=Comment('Check cell: should be 0','MIS')
ws.cell(GT+1,3,'Tally check: Indirect expenses Apr-26 excl. depreciation & round-off = 85,14,846.22'); ws.cell(GT+1,11,f'=ROUND(K{GT}-8514846.22,2)')
# Section 2
t=GT+5; put(t,st_t202); ws.cell(t,2,'Expenses not to be used for calculation of Manday Expenses')
put(t+1,st_h203)
for c,v in zip(range(2,12),['ACCOUNT HEAD ','Company Name','Gross Amt.(Including GST)','REMARKS','BILL RECEIVED DATE','TYPE OF EXPENSES INCLUDED',' CGST ',' SGST ',' IGST ',' Net Amt. (Exluding GST)']): ws.cell(t+1,c,v)
r2=t+2; put(r2,st_item); ws.cell(r2,2,'Depreciation'); ws.cell(r2,4,f'=K{r2}+SUM(H{r2}:J{r2})'); ws.cell(r2,5,'Depreciation entry for APR 26'); ws.cell(r2,6,D('2026-04-30')); ws.cell(r2,7,'Dep'); ws.cell(r2,11,DEP)
DEPROW=r2
for j,(nm,a,nar) in enumerate(ASSETS):
    rr=r2+1+j; put(rr,st_item); ws.cell(rr,2,'ASSET'); ws.cell(rr,3,'Max Computers -MSME'); ws.cell(rr,4,f'=K{rr}+SUM(H{rr}:J{rr})'); ws.cell(rr,5,nar); ws.cell(rr,6,D(['2026-04-06','2026-04-06','2026-04-06','2026-04-22'][j])); ws.cell(rr,7,nm); ws.cell(rr,8,round(a*0.09,2)); ws.cell(rr,9,round(a*0.09,2)); ws.cell(rr,11,a)
s2l=r2+len(ASSETS); g2=s2l+2; put(g2,st_gt); ws.cell(g2,3,'Grand Total')
for col in 'DHIJK': ws[f'{col}{g2}']=f'=SUM({col}{r2}:{col}{s2l})'
# Summary tables (replacing pivots)
p=g2+3; put(p,st_pl); ws.cell(p,2,'Row Labels'); ws.cell(p,3,'Sum of  Net Amt. (Exluding GST)')
for k,h in enumerate(order):
    rr=p+1+k; put(rr,st_pv); ws.cell(rr,2,h); ws.cell(rr,3,f'=SUMIF($B$4:$B${last},B{rr},$K$4:$K${last})')
pe=p+len(order); put(pe+1,st_pl); ws.cell(pe+1,2,'Grand Total'); ws.cell(pe+1,3,f'=SUM(C{p+1}:C{pe})'); ws.cell(pe+1,4,f'=ROUND(C{pe+1}-K{GT},2)')
q=pe+4; put(q-1,st_t202); ws.cell(q-1,2,'Summary for other than Manday Expenses & Assets')
put(q,st_pl); ws.cell(q,2,'Row Labels'); ws.cell(q,3,'Sum of  Net Amt. (Exluding GST)')
for k,h in enumerate(['Depreciation','ASSET']):
    put(q+1+k,st_pv); ws.cell(q+1+k,2,h); ws.cell(q+1+k,3,f'=SUMIF($B${r2}:$B${s2l},B{q+1+k},$K${r2}:$K${s2l})')
put(q+3,st_pl); ws.cell(q+3,2,'Grand Total'); ws.cell(q+3,3,f'=SUM(C{q+1}:C{q+2})')
ASSETROW=q+2
print('General last',last,'GT',GT,'dep',DEPROW,'summary',p,pe,q)

# ---------------- CR
cr=wb['CR']; cr._pivots=[]
for mg in list(cr.merged_cells.ranges):
    if mg.min_row>=6 and mg.min_col>=4: cr.unmerge_cells(str(mg))
st_a=copy.copy(cr['A7']._style); st_b=copy.copy(cr['B7']._style)
clear(cr,7,38,1,9)
for r in range(6,39):
    for c in range(4,9): cr.cell(r,c)._style=copy.copy(cr['J7']._style)
for k,h in enumerate(order):
    r=7+k; cr.cell(r,1,h)._style=copy.copy(st_a); cr.cell(r,2,f'=SUMIF(General!$B$4:$B${last},A{r},General!$K$4:$K${last})')._style=copy.copy(st_b)
cr['D7']='Source: live SUMIF links to General sheet (pivot tables replaced)'
cr['B46']=f'=General!C{ASSETROW}'; cr['B47']=None; cr['B49']=None
cr['B51']=f'=General!K{DEPROW}'
cr['B66']='=IFERROR(B58/B64,"Pending CB")'; cr['B70']='=IFERROR(B66/B68,"Pending CB")'

# ---------------- Consolidated CR: Feb (L) and Mar (M) FY 2025-26 from Tally ledgers
cc=wb['Consolidated CR']
rows={str(cc.cell(r,1).value).strip().upper():r for r in range(9,55) if cc.cell(r,1).value}
feb={"ADVERTISMENT":52978,"BANK CHARGES":150+3754.75,"BUSINESS PROMOTION":74892.84,"COMPUTER CONSUMABLES":11440.26+13500+656.78,
"STAFF SALARY":289531+3469416+57600+1737106+45000+1349762,"ELECTRICITY CHARGES":46160,"EMPLOYER CONTRIBUTION TO PF":27000+25000+11000+5099,
"HOUSEKEEPING CHARGES":40665.3,"TRAVEL EXPENSES":9827+348,"STAFF MEDICAL INSURANCE":27178,"OFFICE EQUIPMENT EXPENSE":29546,
"OFFICE GENERAL EXPENSES":41416,"OFFICE INTERNET CHARGES":6801,"COURSE FEES":55000,"PANTRY EXPENSES":106448,"PETROL EXPENSES":3329.84,
"COURIER CHARGES":380,"PRINTING & STATIONERY":13544+10000,"PROFESSIONAL FEES":158751,"PROPERTY TAX":371807,"REIMBURSMENT":46159,
"OFFICE RENT":420000,"MISC EXPENSES":0.8,"SECURITY CHARGES":21673.3,"OFFICE STAFF WELFARE":93799,"MOBILE & TELEPHONE CHARGES":35716.79+12582,"RENT INCOME":-25000}
mar={"ADVERTISMENT":50628,"STAFF SALARY":275563+3301803+56000+14560+1653299+43750+1282774,"PROFESSIONAL FEES":165000,"BANK CHARGES":150+6565.56,
"BUSINESS PROMOTION":15169,"COMPUTER CONSUMABLES":9125+9661,"ELECTRICITY CHARGES":212530,"EMPLOYER CONTRIBUTION TO PF":25200+25000+11000+5249,
"OFFICE STAFF WELFARE":166075+149808,"HOUSEKEEPING CHARGES":40665.3,"LEAVE ENCASHMENT":80136,"TRAVEL EXPENSES":11900+110858+2375,
"OFFICE GENERAL EXPENSES":102591.92,"OFFICE INTERNET CHARGES":173942,"COURSE FEES":91200,"PANTRY EXPENSES":99919,"PETROL EXPENSES":2812.14,
"COURIER CHARGES":26514.6,"PRINTING & STATIONERY":56007+7585,"MISC EXPENSES":2500+294.55-450.72,"REIMBURSMENT":67736,"OFFICE RENT":210000,
"SECURITY CHARGES":21673.3,"MOBILE & TELEPHONE CHARGES":20382+12390,"RENT INCOME":-25000}
assert round(sum(v for k,v in feb.items() if k!='RENT INCOME'),2)==round(9246971.66-521953,2)
assert round(sum(v for k,v in mar.items() if k!='RENT INCOME'),2)==round(9141893.65-521953,2)
for col,dd in (('L',feb),('M',mar)):
    for k,v in dd.items():
        cc[f'{col}{rows[k]}']=round(v,2)
    cc[f'{col}73']=521953
cc['L78']=956215; cc['M78']=634864; cc['L79']=1560586; cc['M79']=6144428.45
cc['L91']=91.4514; cc['M91']=93.2088
for col in 'BCDEFGHIJKLMN':
    for r,f in ((89,f'={col}81/{col}87'),(93,f'={col}89/{col}91')):
        cc[f'{col}{r}']=f'=IFERROR({f[1:]},"")'

# ---------------- Employees Loan Repayment (APR 2026 - Tally Payroll 54)
ws=wb['Employees Loan Repayment']
tO={r:ws[f'O{r}'].value for r in range(4,15)}
st=[copy.copy(ws.cell(4,c)._style) for c in range(2,16)]; sts=[copy.copy(ws.cell(15,c)._style) for c in range(2,16)]
clear(ws,4,16,2,15)
ws['B2']='       Employee Loan Repayment for the month of APR 2026'
LN=[('Shahina Mohite',13700,500000,'2024-09-01',19,'=6800+(D{r}*L{r})',tO[5]),
('Amit Shinde',12000,432000,'2024-08-01',21,'=L{r}*D{r}',tO[6]),
('Pratik Shiposkar',10000,400000,'2024-08-01',21,'=L{r}*D{r}',tO[7]),
('Sumit Mandavkar',23400,'=842400+342000','2024-12-01',17,'=L{r}*D{r}',tO[8]),
('Sandesh Patil',10000,200000,'2025-09-01',8,'=L{r}*D{r}',tO[10]),
('Rahul Pawar',35000,700000,'2025-12-01',5,'=L{r}*D{r}',tO[11]),
('Pratik Kondvilkar',10000,300000,'2025-12-01',5,'=L{r}*D{r}',tO[12]),
('Shivram R. Singh',20000,400000,'2026-01-01',3,'=L{r}*D{r}','Loan of 4,00,000; 20 monthly instalments of 20,000 from Feb-26 (Tally Payroll 48 narration)'),
('Rohan Gawde',16600,400000,'2026-01-01',3,'=18200+D{r}*(L{r}-1)','Loan of 4,00,000: first deduction 18,200 in Feb-26, balance in 23 instalments of 16,600 from Mar-26 (Tally Payroll 48 narration)'),
('Sampada Shimge',15000,150000,'2026-02-27',2,'=L{r}*D{r}','Sampada was given a loan of 150,000/- Rs. To be paid back in 10 instalments of 15,000/- Rs each, first deduction of 15,000/- Rs to start from March 2026. (Tally Payroll 45 narration; disbursed from DBS on 27.02.26)')]
for i,(nm,d,I,j,l,mf,o) in enumerate(LN):
    r=4+i
    for c in range(2,16): ws.cell(r,c)._style=copy.copy(st[c-2])
    for c,v in zip(range(2,16),['LOAN INSTALLMENT ',nm,d,'Deducted from Salary',D('2026-04-30'),'Monthly Loan Repayment','Nil',I,D(j),D('2026-04-01'),l,mf.format(r=r),f'=I{r}-M{r}',o]): ws.cell(r,c,v)
tr=4+len(LN)
for c in range(2,16): ws.cell(tr,c)._style=copy.copy(sts[c-2])
ws.cell(tr,3,'SUB TOTAL')
for col in 'DIMN': ws[f'{col}{tr}']=f'=SUM({col}4:{col}{tr-1})'
ws.cell(tr+2,3,'Source: Tally Payroll voucher 54 dt. 30.04.26 (narration: APR 26) - Loan to Employees Cr 1,65,700. No loan disbursed in Apr-26. Sunny Palav loan fully recovered in Mar-26.')
assert sum(x[1] for x in LN)==165700

# ---------------- Forex
fx=wb['Forex']; fx._images=[]
fx['C2']=RATE; fx['C2'].comment=Comment('RBI Reference Rate Archive, USD, 04.05.2026 (no rate published 01.05.26 - Maharashtra Day, or 02.05.26 - Saturday). https://www.rbi.org.in/scripts/referenceratearchive.aspx','MIS')
fx['C6']=None; fx['C7']=None
fx['B4']='USD amounts for Apr-26 service-charge invoices not yet raised in Tally - to be entered'
fx['B10']='RBI screenshot (USD, 04.05.2026 = 94.9432) saved at: C:\\Users\\Prasanna\\AppData\\Local\\Temp\\claude-chrome-screenshots-6P8S4V\\screenshot-1790594104620-2.jpg - paste here (shows USD 04/05/2026 = 94.9432)'
fx['R28']='=C2'

# ---------------- CB: clear Jan crew data, retitle, link rate, IFERROR
cb=wb['CB']
for r in range(1,cb.max_row+1):
    for c in range(1,cb.max_column+1):
        v=cb.cell(r,c).value
        if isinstance(v,str) and 'JAN 2026' in v: cb.cell(r,c).value=v.replace('JAN 2026','APR 2026')
for r in range(5,cb.max_row+1):
    cv=cb.cell(r,3).value
    if isinstance(cv,str) and cv.strip() and not cv.startswith('=') and 'TOTAL' not in cv.upper():
        for c in (3,4,5,6,7): 
            cl=cb.cell(r,c)
            if not isinstance(cl,openpyxl.cell.cell.MergedCell) and not str(cl.value).startswith('='): cl.value=None
    jv=cb.cell(r,10).value
    if isinstance(jv,str) and jv.startswith('=') :
        if isinstance(cb.cell(r,10),openpyxl.cell.cell.MergedCell): pass
        elif '91.6443' in jv: cb.cell(r,10).value=jv.replace('91.6443','Forex!$C$2')
        elif '/' in jv and 'IFERROR' not in jv: cb.cell(r,10).value=f'=IFERROR({jv[1:]},0)'
for r in range(5,cb.max_row+1):
    for c in (6,7):
        cl=cb.cell(r,c)
        if not isinstance(cl,openpyxl.cell.cell.MergedCell) and isinstance(cl.value,str) and re.fullmatch(r'=[\d\s\+\-\*/\.\(\)]+',cl.value): cl.value=None
wb.save(OUTPUT); print('saved')
