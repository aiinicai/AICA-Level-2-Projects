export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          actor_identifier: string
          field_changed: string | null
          id: string
          new_value: string | null
          old_value: string | null
          onboarding_id: string | null
          timestamp: string
        }
        Insert: {
          action: string
          actor_identifier: string
          field_changed?: string | null
          id?: string
          new_value?: string | null
          old_value?: string | null
          onboarding_id?: string | null
          timestamp?: string
        }
        Update: {
          action?: string
          actor_identifier?: string
          field_changed?: string | null
          id?: string
          new_value?: string | null
          old_value?: string | null
          onboarding_id?: string | null
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_onboarding_id_fkey"
            columns: ["onboarding_id"]
            isOneToOne: false
            referencedRelation: "vendor_onboardings"
            referencedColumns: ["id"]
          },
        ]
      }
      internal_reviews: {
        Row: {
          controller_comments: string | null
          controller_date: string | null
          controller_status: string | null
          controller_user_id: string | null
          id: string
          onboarding_id: string
          prepare_date: string | null
          prepare_notes: string | null
          prepare_status: string | null
          prepared_by_user_id: string | null
          purchase_head_comments: string | null
          purchase_head_date: string | null
          purchase_head_status: string | null
          purchase_head_user_id: string | null
          tfa_notes: string | null
          tfa_status: string
          tfa_verified_by_user_id: string | null
        }
        Insert: {
          controller_comments?: string | null
          controller_date?: string | null
          controller_status?: string | null
          controller_user_id?: string | null
          id?: string
          onboarding_id: string
          prepare_date?: string | null
          prepare_notes?: string | null
          prepare_status?: string | null
          prepared_by_user_id?: string | null
          purchase_head_comments?: string | null
          purchase_head_date?: string | null
          purchase_head_status?: string | null
          purchase_head_user_id?: string | null
          tfa_notes?: string | null
          tfa_status?: string
          tfa_verified_by_user_id?: string | null
        }
        Update: {
          controller_comments?: string | null
          controller_date?: string | null
          controller_status?: string | null
          controller_user_id?: string | null
          id?: string
          onboarding_id?: string
          prepare_date?: string | null
          prepare_notes?: string | null
          prepare_status?: string | null
          prepared_by_user_id?: string | null
          purchase_head_comments?: string | null
          purchase_head_date?: string | null
          purchase_head_status?: string | null
          purchase_head_user_id?: string | null
          tfa_notes?: string | null
          tfa_status?: string
          tfa_verified_by_user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "internal_reviews_onboarding_id_fkey"
            columns: ["onboarding_id"]
            isOneToOne: true
            referencedRelation: "vendor_onboardings"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          is_active: boolean
        }
        Insert: {
          created_at?: string
          email: string
          full_name?: string
          id: string
          is_active?: boolean
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          is_active?: boolean
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vendor_documents: {
        Row: {
          category: string
          created_at: string
          file_name: string
          file_url: string
          id: string
          onboarding_id: string
          uploaded_by: string
        }
        Insert: {
          category: string
          created_at?: string
          file_name: string
          file_url: string
          id?: string
          onboarding_id: string
          uploaded_by: string
        }
        Update: {
          category?: string
          created_at?: string
          file_name?: string
          file_url?: string
          id?: string
          onboarding_id?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "vendor_documents_onboarding_id_fkey"
            columns: ["onboarding_id"]
            isOneToOne: false
            referencedRelation: "vendor_onboardings"
            referencedColumns: ["id"]
          },
        ]
      }
      vendor_onboardings: {
        Row: {
          created_at: string
          created_by_user_id: string | null
          final_vendor_code: string | null
          id: string
          status: Database["public"]["Enums"]["onboarding_status"]
          temp_vendor_code: string
          token: string
          token_expires_at: string
          updated_at: string
          vendor_email: string
          vendor_name: string
        }
        Insert: {
          created_at?: string
          created_by_user_id?: string | null
          final_vendor_code?: string | null
          id?: string
          status?: Database["public"]["Enums"]["onboarding_status"]
          temp_vendor_code: string
          token?: string
          token_expires_at?: string
          updated_at?: string
          vendor_email: string
          vendor_name: string
        }
        Update: {
          created_at?: string
          created_by_user_id?: string | null
          final_vendor_code?: string | null
          id?: string
          status?: Database["public"]["Enums"]["onboarding_status"]
          temp_vendor_code?: string
          token?: string
          token_expires_at?: string
          updated_at?: string
          vendor_email?: string
          vendor_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "vendor_onboardings_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      vendor_profiles: {
        Row: {
          additional_notes: string | null
          address_line1: string | null
          address_line2: string | null
          agreed_anti_bribery: boolean
          agreed_conflict_disclosure: boolean
          bank_account_number: string | null
          bank_code_swift_ifsc: string | null
          business_type: string | null
          cin: string | null
          city: string | null
          country: string | null
          gstin_entries: Json
          has_conflict_of_interest: boolean
          id: string
          iso_certifications: string[]
          key_persons: Json
          legal_name: string | null
          litigation_details: string | null
          msme_reg_no: string | null
          onboarding_id: string
          other_iso_notes: string | null
          pan: string | null
          postal_code: string | null
          primary_contact_name: string | null
          primary_email: string | null
          primary_phone: string | null
          state: string | null
          trade_name: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          additional_notes?: string | null
          address_line1?: string | null
          address_line2?: string | null
          agreed_anti_bribery?: boolean
          agreed_conflict_disclosure?: boolean
          bank_account_number?: string | null
          bank_code_swift_ifsc?: string | null
          business_type?: string | null
          cin?: string | null
          city?: string | null
          country?: string | null
          gstin_entries?: Json
          has_conflict_of_interest?: boolean
          id?: string
          iso_certifications?: string[]
          key_persons?: Json
          legal_name?: string | null
          litigation_details?: string | null
          msme_reg_no?: string | null
          onboarding_id: string
          other_iso_notes?: string | null
          pan?: string | null
          postal_code?: string | null
          primary_contact_name?: string | null
          primary_email?: string | null
          primary_phone?: string | null
          state?: string | null
          trade_name?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          additional_notes?: string | null
          address_line1?: string | null
          address_line2?: string | null
          agreed_anti_bribery?: boolean
          agreed_conflict_disclosure?: boolean
          bank_account_number?: string | null
          bank_code_swift_ifsc?: string | null
          business_type?: string | null
          cin?: string | null
          city?: string | null
          country?: string | null
          gstin_entries?: Json
          has_conflict_of_interest?: boolean
          id?: string
          iso_certifications?: string[]
          key_persons?: Json
          legal_name?: string | null
          litigation_details?: string | null
          msme_reg_no?: string | null
          onboarding_id?: string
          other_iso_notes?: string | null
          pan?: string | null
          postal_code?: string | null
          primary_contact_name?: string | null
          primary_email?: string | null
          primary_phone?: string | null
          state?: string | null
          trade_name?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vendor_profiles_onboarding_id_fkey"
            columns: ["onboarding_id"]
            isOneToOne: true
            referencedRelation: "vendor_onboardings"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      next_temp_code: { Args: { _user_id: string }; Returns: string }
    }
    Enums: {
      app_role:
        | "ADMIN"
        | "PURCHASE_USER"
        | "PURCHASE_HEAD"
        | "FINANCE_CONTROLLER"
      onboarding_status:
        | "INITIATED"
        | "SUBMITTED_BY_VENDOR"
        | "UNDER_PURCHASE_REVIEW"
        | "PENDING_PURCHASE_HEAD"
        | "PENDING_FINANCE"
        | "APPROVED"
        | "COMPLETED"
        | "SENT_BACK"
        | "REJECTED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "ADMIN",
        "PURCHASE_USER",
        "PURCHASE_HEAD",
        "FINANCE_CONTROLLER",
      ],
      onboarding_status: [
        "INITIATED",
        "SUBMITTED_BY_VENDOR",
        "UNDER_PURCHASE_REVIEW",
        "PENDING_PURCHASE_HEAD",
        "PENDING_FINANCE",
        "APPROVED",
        "COMPLETED",
        "SENT_BACK",
        "REJECTED",
      ],
    },
  },
} as const
