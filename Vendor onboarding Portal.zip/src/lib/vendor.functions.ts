import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { REQUIRED_VENDOR_DOCS } from "./workflow";

const tokenSchema = z.string().min(16).max(128).regex(/^[a-f0-9]+$/);

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function loadByToken(token: string) {
  const db = await admin();
  const { data } = await db.from("vendor_onboardings").select("*").eq("token", token).maybeSingle();
  if (!data) throw new Error("This onboarding link is invalid.");
  if (new Date(data.token_expires_at) < new Date()) throw new Error("This onboarding link has expired. Please contact your purchase representative.");
  return { db, onb: data };
}

export const getVendorSession = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => ({ token: tokenSchema.parse(d.token) }))
  .handler(async ({ data }) => {
    const { db, onb } = await loadByToken(data.token);
    const [{ data: profile }, { data: docs }] = await Promise.all([
      db.from("vendor_profiles").select("*").eq("onboarding_id", onb.id).maybeSingle(),
      db.from("vendor_documents").select("id, category, file_name, created_at").eq("onboarding_id", onb.id).neq("category", "tfa_evidence"),
    ]);
    return {
      vendor_name: onb.vendor_name,
      vendor_email: onb.vendor_email,
      temp_vendor_code: onb.temp_vendor_code,
      locked: onb.status !== "INITIATED",
      submitted_at: onb.updated_at,
      profile,
      documents: docs ?? [],
    };
  });

const docCategory = z.enum(["incorp", "bank_proof", "gst_certs", "msme_cert", "iso_cert"]);

export const vendorUploadUrl = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; category: string; fileName: string }) => ({
    token: tokenSchema.parse(d.token),
    category: docCategory.parse(d.category),
    fileName: z.string().min(1).max(200).parse(d.fileName),
  }))
  .handler(async ({ data }) => {
    const { db, onb } = await loadByToken(data.token);
    if (onb.status !== "INITIATED") throw new Error("Application already submitted.");
    const safe = data.fileName.replace(/[^\w.\-]/g, "_");
    const path = `${onb.id}/${data.category}/${Date.now()}-${safe}`;
    const { data: signed, error } = await db.storage.from("vendor-docs").createSignedUploadUrl(path);
    if (error || !signed) throw new Error("Could not prepare upload.");
    return { path, uploadToken: signed.token };
  });

export const vendorRegisterDoc = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; category: string; fileName: string; path: string }) => ({
    token: tokenSchema.parse(d.token),
    category: docCategory.parse(d.category),
    fileName: z.string().min(1).max(200).parse(d.fileName),
    path: z.string().min(1).max(400).parse(d.path),
  }))
  .handler(async ({ data }) => {
    const { db, onb } = await loadByToken(data.token);
    if (!data.path.startsWith(`${onb.id}/`)) throw new Error("Invalid file path.");
    const { data: doc, error } = await db
      .from("vendor_documents")
      .insert({ onboarding_id: onb.id, category: data.category, file_name: data.fileName, file_url: data.path, uploaded_by: `vendor:${onb.vendor_email}` })
      .select("id, category, file_name, created_at")
      .single();
    if (error) throw new Error("Could not save document.");
    await db.from("audit_logs").insert({ onboarding_id: onb.id, actor_identifier: `vendor:${onb.vendor_email}`, action: "DOCUMENT_UPLOADED", field_changed: data.category, new_value: data.fileName });
    return doc;
  });

const s = (max = 200) => z.string().trim().max(max).optional().nullable();
const profileSchema = z.object({
  legal_name: s(), trade_name: s(), business_type: s(50), pan: s(20), cin: s(30), msme_reg_no: s(40),
  primary_contact_name: s(), primary_email: s(255), primary_phone: s(30), website: s(255),
  address_line1: s(), address_line2: s(), city: s(100), state: s(100), country: s(100), postal_code: s(20),
  bank_account_number: s(40), bank_code_swift_ifsc: s(20),
  gstin_entries: z.array(z.object({ gstin: s(20), address1: s(), address2: s(), postal_code: s(20), city: s(100), state: s(100), country: s(100) })).max(30),
  key_persons: z.array(z.object({ name: s(), designation: s(), email: s(255), phone: s(30), pan: s(20) })).max(30),
  iso_certifications: z.array(z.string().max(30)).max(10),
  other_iso_notes: s(1000), litigation_details: s(2000),
  has_conflict_of_interest: z.boolean(), agreed_conflict_disclosure: z.boolean(), agreed_anti_bribery: z.boolean(),
  additional_notes: s(2000),
});
export type VendorProfileInput = z.infer<typeof profileSchema>;

export const vendorSave = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; profile: unknown; submit: boolean }) => ({
    token: tokenSchema.parse(d.token),
    profile: profileSchema.parse(d.profile),
    submit: Boolean(d.submit),
  }))
  .handler(async ({ data }) => {
    const { db, onb } = await loadByToken(data.token);
    if (onb.status !== "INITIATED") throw new Error("Application already submitted.");
    const p = data.profile;
    if (data.submit) {
      const missing = (["legal_name", "business_type", "pan", "primary_contact_name", "primary_email", "primary_phone", "address_line1", "city", "state", "country", "postal_code", "bank_account_number", "bank_code_swift_ifsc"] as const).filter((k) => !p[k]);
      if (missing.length) throw new Error(`Please complete required fields: ${missing.join(", ")}`);
      if (!p.agreed_anti_bribery || !p.agreed_conflict_disclosure) throw new Error("Please accept all mandatory declarations.");
      const { data: docs } = await db.from("vendor_documents").select("category").eq("onboarding_id", onb.id);
      const have = new Set((docs ?? []).map((d) => d.category));
      const missingDocs = REQUIRED_VENDOR_DOCS.filter((c) => !have.has(c));
      if (missingDocs.length) throw new Error("Please upload the Certificate of Incorporation and Bank Proof.");
    }
    const { error } = await db.from("vendor_profiles").upsert({ ...p, onboarding_id: onb.id, updated_at: new Date().toISOString() } as any, { onConflict: "onboarding_id" });
    if (error) throw new Error("Could not save application.");
    if (data.submit) {
      await db.from("vendor_onboardings").update({ status: "SUBMITTED_BY_VENDOR", updated_at: new Date().toISOString() }).eq("id", onb.id);
      await db.from("audit_logs").insert({ onboarding_id: onb.id, actor_identifier: `vendor:${onb.vendor_email}`, action: "STATUS_CHANGE", field_changed: "status", old_value: onb.status, new_value: "SUBMITTED_BY_VENDOR" });
    }
    return { ok: true };
  });
