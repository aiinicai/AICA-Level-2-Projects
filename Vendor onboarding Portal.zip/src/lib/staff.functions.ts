import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { checkTransition, formatErpCode, validateManualErpCode, RULES, type AppRole, type Status, type WorkflowAction } from "./workflow";

type Ctx = { supabase: any; userId: string };
/* eslint-disable @typescript-eslint/no-explicit-any */

async function me(ctx: Ctx) {
  const [{ data: prof }, { data: roles }] = await Promise.all([
    ctx.supabase.from("profiles").select("email, is_active").eq("id", ctx.userId).single(),
    ctx.supabase.from("user_roles").select("role").eq("user_id", ctx.userId),
  ]);
  if (!prof?.is_active) throw new Error("Your account is inactive.");
  return { email: prof.email as string, roles: (roles ?? []).map((r: any) => r.role as AppRole) };
}

export const workflowAction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; action: string; comment?: string | undefined; erp_code?: string | undefined }) => ({
    id: z.string().uuid().parse(d.id),
    action: z.enum(Object.keys(RULES) as [WorkflowAction, ...WorkflowAction[]]).parse(d.action),
    comment: z.string().max(4000).optional().parse(d.comment),
    erp_code: z.string().trim().max(20).optional().parse(d.erp_code),
  }))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const actor = await me(context);
    const { data: onb } = await db.from("vendor_onboardings").select("*").eq("id", data.id).single();
    if (!onb) throw new Error("Not found");
    const { data: review } = await db.from("internal_reviews").select("*").eq("onboarding_id", data.id).maybeSingle();
    const res = checkTransition(actor.roles, onb.status as Status, data.action, { comment: data.comment, tfaStatus: review?.tfa_status });
    if (!res.ok) throw new Error(res.reason);
    const now = new Date().toISOString();
    const r: any = { onboarding_id: data.id };
    const onbUpdate: any = { status: res.to, updated_at: now };
    switch (data.action) {
      case "route_to_head":
        Object.assign(r, { prepare_status: "Prepared", prepare_notes: data.comment, prepared_by_user_id: context.userId, prepare_date: now, purchase_head_status: null, controller_status: null });
        break;
      case "head_approve":
      case "head_send_back":
        Object.assign(r, { purchase_head_status: data.action === "head_approve" ? "Approved" : "Sent Back", purchase_head_comments: data.comment, purchase_head_user_id: context.userId, purchase_head_date: now });
        break;
      case "finance_approve":
      case "finance_send_back":
      case "finance_reject":
        Object.assign(r, { controller_status: { finance_approve: "Approved", finance_send_back: "Sent Back", finance_reject: "Rejected" }[data.action], controller_comments: data.comment ?? null, controller_user_id: context.userId, controller_date: now });
        break;
      case "return_to_vendor":
        onbUpdate.token_expires_at = new Date(Date.now() + 30 * 86400000).toISOString();
        break;
      case "assign_erp": {
        if (data.erp_code) {
          const v = validateManualErpCode(data.erp_code);
          if (!v.ok) throw new Error(v.reason);
          const { data: dup } = await db.from("vendor_onboardings").select("id").eq("final_vendor_code", v.code).maybeSingle();
          if (dup) throw new Error(`ERP code ${v.code} is already assigned to another vendor`);
          onbUpdate.final_vendor_code = v.code;
        } else {
          const { count } = await db.from("vendor_onboardings").select("id", { count: "exact", head: true }).not("final_vendor_code", "is", null);
          onbUpdate.final_vendor_code = formatErpCode((count ?? 0) + 1);
        }
        break;
      }
    }
    if (Object.keys(r).length > 1) {
      const { error } = await db.from("internal_reviews").upsert(r, { onConflict: "onboarding_id" });
      if (error) throw new Error(error.message);
    }
    const { error } = await db.from("vendor_onboardings").update(onbUpdate).eq("id", data.id);
    if (error) throw new Error(error.message);
    const logs: any[] = [{ onboarding_id: data.id, actor_identifier: actor.email, action: data.action.toUpperCase(), field_changed: "status", old_value: onb.status, new_value: res.to }];
    if (data.comment) logs.push({ onboarding_id: data.id, actor_identifier: actor.email, action: "COMMENT", field_changed: data.action, new_value: data.comment });
    if (onbUpdate.final_vendor_code) logs.push({ onboarding_id: data.id, actor_identifier: actor.email, action: "ERP_CODE_ASSIGNED", field_changed: "final_vendor_code", new_value: onbUpdate.final_vendor_code });
    await db.from("audit_logs").insert(logs);
    return { status: res.to, final_vendor_code: (onbUpdate.final_vendor_code as string) ?? null };
  });

export const nextErpSuggestion = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = context.supabase;
    const { count } = await db.from("vendor_onboardings").select("id", { count: "exact", head: true }).not("final_vendor_code", "is", null);
    return { code: formatErpCode((count ?? 0) + 1) };
  });

export const updateTfa = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; tfa_status: string; tfa_notes?: string | undefined }) => ({
    id: z.string().uuid().parse(d.id),
    tfa_status: z.enum(["Not Started", "Evidence Pending", "Enabled", "Verified", "Exception Required"]).parse(d.tfa_status),
    tfa_notes: z.string().max(2000).optional().parse(d.tfa_notes),
  }))
  .handler(async ({ data, context }) => {
    const actor = await me(context);
    if (!actor.roles.some((r: AppRole) => r === "FINANCE_CONTROLLER" || r === "ADMIN")) throw new Error("Only Finance can update 2FA status");
    const db = context.supabase;
    const { data: prev } = await db.from("internal_reviews").select("tfa_status").eq("onboarding_id", data.id).maybeSingle();
    const { error } = await db.from("internal_reviews").upsert({ onboarding_id: data.id, tfa_status: data.tfa_status, tfa_notes: data.tfa_notes ?? null, tfa_verified_by_user_id: context.userId }, { onConflict: "onboarding_id" });
    if (error) throw new Error(error.message);
    await db.from("audit_logs").insert({ onboarding_id: data.id, actor_identifier: actor.email, action: "TFA_UPDATE", field_changed: "tfa_status", old_value: prev?.tfa_status ?? "Not Started", new_value: data.tfa_status });
    return { ok: true };
  });

export const updateVendorProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; changes: Record<string, string | null> }) => ({
    id: z.string().uuid().parse(d.id),
    changes: z.record(z.string().max(40), z.string().max(2000).nullable()).parse(d.changes),
  }))
  .handler(async ({ data, context }) => {
    const actor = await me(context);
    if (!actor.roles.some((r: AppRole) => r === "PURCHASE_USER" || r === "ADMIN")) throw new Error("Only Purchase can amend vendor data");
    const allowed = ["legal_name", "trade_name", "business_type", "pan", "cin", "msme_reg_no", "primary_contact_name", "primary_email", "primary_phone", "website", "address_line1", "address_line2", "city", "state", "country", "postal_code", "bank_account_number", "bank_code_swift_ifsc"];
    const db = context.supabase;
    const { data: prevRow } = await db.from("vendor_profiles").select("*").eq("onboarding_id", data.id).single();
    const prev = prevRow as any;
    if (!prev) throw new Error("Vendor has not submitted a profile yet");
    const upd: Record<string, string | null> = {};
    const logs: any[] = [];
    for (const [k, v] of Object.entries(data.changes)) {
      if (!allowed.includes(k) || (prev[k] ?? "") === (v ?? "")) continue;
      upd[k] = v;
      logs.push({ onboarding_id: data.id, actor_identifier: actor.email, action: "FIELD_AMENDED", field_changed: k, old_value: prev[k], new_value: v });
    }
    if (!logs.length) return { changed: 0 };
    const { error } = await db.from("vendor_profiles").update({ ...upd, updated_at: new Date().toISOString() }).eq("onboarding_id", data.id);
    if (error) throw new Error(error.message);
    await db.from("audit_logs").insert(logs);
    return { changed: logs.length };
  });

const GMAIL_GATEWAY = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";

function b64utf8(s: string): string {
  const bytes = new TextEncoder().encode(s);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

export const sendInvitationEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { onboardingId: string; to: string; subject: string; body: string }) => ({
    onboardingId: z.string().uuid().parse(d.onboardingId),
    to: z.string().trim().email().max(255).parse(d.to),
    subject: z.string().trim().min(1).max(200).parse(d.subject),
    body: z.string().min(1).max(20000).parse(d.body),
  }))
  .handler(async ({ data, context }) => {
    const actor = await me(context);
    if (!actor.roles.some((r: AppRole) => r === "PURCHASE_USER" || r === "ADMIN")) throw new Error("Only Purchase can send invitations");
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const gmailKey = process.env["GOOGLE_MAIL_API_KEY"];
    if (!lovableKey || !gmailKey) throw new Error("Gmail is not connected yet");
    const header = (v: string) => (/^[\x00-\x7F]*$/.test(v) ? v : `=?UTF-8?B?${b64utf8(v)}?=`);
    const raw = [
      `To: ${data.to}`,
      `Subject: ${header(data.subject)}`,
      "MIME-Version: 1.0",
      'Content-Type: text/plain; charset="UTF-8"',
      "",
      data.body,
    ].join("\r\n");
    const res = await fetch(`${GMAIL_GATEWAY}/users/me/messages/send`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": gmailKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw: b64utf8(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") }),
    });
    if (!res.ok) {
      const errBody = await res.text();
      console.error(`Gmail send failed [${res.status}]: ${errBody}`);
      throw new Error(`Could not send the email (status ${res.status}). Please try again.`);
    }
    await context.supabase.from("audit_logs").insert({ onboarding_id: data.onboardingId, actor_identifier: actor.email, action: "INVITATION_SENT", new_value: data.to });
    return { ok: true };
  });

async function requireAdmin(ctx: Ctx) {
  const actor = await me(ctx);
  if (!actor.roles.includes("ADMIN")) throw new Error("Admins only");
  return actor;
}
const roleEnum = z.enum(["ADMIN", "PURCHASE_USER", "PURCHASE_HEAD", "FINANCE_CONTROLLER"]);

export const createStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { email: string; full_name: string; password: string; role: string }) => ({
    email: z.string().trim().email().max(255).parse(d.email),
    full_name: z.string().trim().min(2).max(100).parse(d.full_name),
    password: z.string().min(8).max(72).parse(d.password),
    role: roleEnum.parse(d.role),
  }))
  .handler(async ({ data, context }) => {
    const actor = await requireAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({ email: data.email, password: data.password, email_confirm: true, user_metadata: { full_name: data.full_name } });
    if (error || !created.user) throw new Error(error?.message ?? "Could not create user");
    await supabaseAdmin.from("user_roles").delete().eq("user_id", created.user.id);
    await supabaseAdmin.from("user_roles").insert({ user_id: created.user.id, role: data.role });
    await supabaseAdmin.from("audit_logs").insert({ actor_identifier: actor.email, action: "STAFF_CREATED", field_changed: "role", new_value: `${data.email}:${data.role}` });
    return { ok: true };
  });

export const setUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; role: string }) => ({ userId: z.string().uuid().parse(d.userId), role: roleEnum.parse(d.role) }))
  .handler(async ({ data, context }) => {
    const actor = await requireAdmin(context);
    if (data.userId === context.userId && data.role !== "ADMIN") throw new Error("You cannot remove your own admin role");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: prev } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", data.userId);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("user_roles").insert({ user_id: data.userId, role: data.role });
    await supabaseAdmin.from("audit_logs").insert({ actor_identifier: actor.email, action: "ROLE_CHANGED", field_changed: data.userId, old_value: (prev ?? []).map((r) => r.role).join(","), new_value: data.role });
    return { ok: true };
  });

export const setUserActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; active: boolean }) => ({ userId: z.string().uuid().parse(d.userId), active: Boolean(d.active) }))
  .handler(async ({ data, context }) => {
    const actor = await requireAdmin(context);
    if (data.userId === context.userId) throw new Error("You cannot deactivate yourself");
    const { error } = await context.supabase.from("profiles").update({ is_active: data.active }).eq("id", data.userId);
    if (error) throw new Error(error.message);
    await context.supabase.from("audit_logs").insert({ actor_identifier: actor.email, action: data.active ? "USER_ACTIVATED" : "USER_DEACTIVATED", field_changed: data.userId });
    return { ok: true };
  });
