export const GEO: Record<string, Record<string, string[]>> = {
  India: {
    Karnataka: ["Bengaluru", "Mysuru", "Mangaluru", "Hubballi"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Hosur"],
    Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik"],
    Telangana: ["Hyderabad", "Warangal"],
    Gujarat: ["Ahmedabad", "Surat", "Vadodara"],
    Delhi: ["New Delhi"],
    Haryana: ["Gurugram", "Faridabad"],
    "Uttar Pradesh": ["Noida", "Lucknow", "Kanpur"],
  },
  "United States": {
    Connecticut: ["Wallingford", "Hartford", "New Haven"],
    California: ["San Jose", "Los Angeles", "San Diego"],
    Texas: ["Austin", "Dallas", "Houston"],
    "New York": ["New York City", "Buffalo"],
  },
  China: { Jiangsu: ["Suzhou", "Nanjing"], Guangdong: ["Shenzhen", "Guangzhou"], Shanghai: ["Shanghai"] },
  Germany: { Bavaria: ["Munich", "Nuremberg"], Hesse: ["Frankfurt"], Berlin: ["Berlin"] },
  "United Kingdom": { England: ["London", "Manchester", "Birmingham"], Scotland: ["Edinburgh", "Glasgow"] },
  Singapore: { Singapore: ["Singapore"] },
};
