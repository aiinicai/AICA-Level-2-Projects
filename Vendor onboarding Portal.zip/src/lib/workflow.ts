export type AppRole = "ADMIN" | "PURCHASE_USER" | "PURCHASE_HEAD" | "FINANCE_CONTROLLER";
export type Status =
  | "INITIATED"
  | "SUBMITTED_BY_VENDOR"
  | "UNDER_PURCHASE_REVIEW"
  | "PENDING_PURCHASE_HEAD"
  | "PENDING_FINANCE"
  | "APPROVED"
  | "COMPLETED"
  | "SENT_BACK"
  | "REJECTED";

export const ROLE_LABELS: Record<AppRole, string> = {
  ADMIN: "Administrator",
  PURCHASE_USER: "Purchase User",
  PURCHASE_HEAD: "Purchase Head (L1)",
  FINANCE_CONTROLLER: "Finance Controller (L2)",
};

export const STATUS_LABELS: Record<Status, string> = {
  INITIATED: "Initiated",
  SUBMITTED_BY_VENDOR: "Submitted by Vendor",
  UNDER_PURCHASE_REVIEW: "Under Purchase Review",
  PENDING_PURCHASE_HEAD: "Pending Purchase Head",
  PENDING_FINANCE: "Pending Finance",
  APPROVED: "Approved",
  COMPLETED: "Completed",
  SENT_BACK: "Sent Back",
  REJECTED: "Rejected",
};

export const ALL_STATUSES = Object.keys(STATUS_LABELS) as Status[];

export const TFA_STATUSES = [
  "Not Started",
  "Evidence Pending",
  "Enabled",
  "Verified",
  "Exception Required",
] as const;

export type WorkflowAction =
  | "start_review"
  | "route_to_head"
  | "return_to_vendor"
  | "head_approve"
  | "head_send_back"
  | "finance_approve"
  | "finance_send_back"
  | "finance_reject"
  | "assign_erp";

type Rule = { from: Status[]; to: Status; roles: AppRole[]; needsComment?: boolean };

export const RULES: Record<WorkflowAction, Rule> = {
  start_review: { from: ["SUBMITTED_BY_VENDOR"], to: "UNDER_PURCHASE_REVIEW", roles: ["PURCHASE_USER", "ADMIN"] },
  route_to_head: {
    from: ["SUBMITTED_BY_VENDOR", "UNDER_PURCHASE_REVIEW", "SENT_BACK"],
    to: "PENDING_PURCHASE_HEAD",
    roles: ["PURCHASE_USER", "ADMIN"],
    needsComment: true,
  },
  return_to_vendor: {
    from: ["SUBMITTED_BY_VENDOR", "UNDER_PURCHASE_REVIEW", "SENT_BACK"],
    to: "INITIATED",
    roles: ["PURCHASE_USER", "ADMIN"],
  },
  head_approve: { from: ["PENDING_PURCHASE_HEAD"], to: "PENDING_FINANCE", roles: ["PURCHASE_HEAD", "ADMIN"], needsComment: true },
  head_send_back: { from: ["PENDING_PURCHASE_HEAD"], to: "SENT_BACK", roles: ["PURCHASE_HEAD", "ADMIN"], needsComment: true },
  finance_approve: { from: ["PENDING_FINANCE"], to: "APPROVED", roles: ["FINANCE_CONTROLLER", "ADMIN"] },
  finance_send_back: { from: ["PENDING_FINANCE"], to: "SENT_BACK", roles: ["FINANCE_CONTROLLER", "ADMIN"], needsComment: true },
  finance_reject: { from: ["PENDING_FINANCE"], to: "REJECTED", roles: ["FINANCE_CONTROLLER", "ADMIN"], needsComment: true },
  assign_erp: { from: ["APPROVED"], to: "COMPLETED", roles: ["PURCHASE_USER", "ADMIN"] },
};

/** Final finance approval is only allowed once 2FA is confirmed or an exception is recorded. */
export const TFA_OK_FOR_APPROVAL = ["Enabled", "Verified", "Exception Required"];

export function checkTransition(
  roles: AppRole[],
  status: Status,
  action: WorkflowAction,
  opts: { comment?: string | null | undefined; tfaStatus?: string | null | undefined } = {},
): { ok: true; to: Status } | { ok: false; reason: string } {
  const rule = RULES[action];
  if (!rule.roles.some((r) => roles.includes(r))) return { ok: false, reason: "Your role cannot perform this action" };
  if (!rule.from.includes(status)) return { ok: false, reason: `Not allowed while status is ${STATUS_LABELS[status]}` };
  if (rule.needsComment && !opts.comment?.trim()) return { ok: false, reason: "Comments are required" };
  if (action === "finance_approve" && !TFA_OK_FOR_APPROVAL.includes(opts.tfaStatus ?? ""))
    return { ok: false, reason: "2FA must be Enabled, Verified or have an Exception recorded" };
  return { ok: true, to: rule.to };
}

export function formatErpCode(n: number) {
  return `TMS-V-${1000 + n}`;
}

/** Manual ERP code override: 3–20 chars, letters/numbers/dashes, stored uppercase. */
export const ERP_CODE_RE = /^[A-Z0-9][A-Z0-9-]{2,19}$/;
export function validateManualErpCode(raw: string): { ok: true; code: string } | { ok: false; reason: string } {
  const code = raw.trim().toUpperCase();
  if (!ERP_CODE_RE.test(code)) return { ok: false, reason: "ERP code must be 3–20 characters using letters, numbers and dashes (e.g. TMS-V-1042)" };
  return { ok: true, code };
}

export const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
/** Client-side preview of the MONTHUSERNO code; the database computes the real one. */
export function tempCodePreview(date: Date, name: string, seq: number) {
  const ini = (name.replace(/[^A-Za-z]/g, "").slice(0, 3).toUpperCase() + "XXX").slice(0, 3);
  return `${MONTHS[date.getMonth()]}${ini}${String(seq).padStart(2, "0")}`;
}

export const DEFAULT_EMAIL_TEMPLATE = `Dear {{vendor_name}},

Times India invites you to complete our vendor onboarding application.

Your temporary vendor reference: {{temp_code}}

Please complete the secure form using the link below:
{{form_link}}

The link is unique to your organisation. Please keep it confidential.

Regards,
Purchase Department
Times India`;

export function renderTemplate(tpl: string, vars: Record<string, string>) {
  return tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, (m, k: string) => (vars[k] ?? m));
}

export const DOC_CATEGORIES: Record<string, string> = {
  incorp: "Certificate of Incorporation",
  bank_proof: "Bank Proof / Cancelled Cheque",
  gst_certs: "GST Certificate(s)",
  msme_cert: "MSME Certificate",
  iso_cert: "ISO Certificate(s)",
  tfa_evidence: "2FA Verification Evidence",
};
export const REQUIRED_VENDOR_DOCS = ["incorp", "bank_proof"];

export const BUSINESS_TYPES = ["Proprietorship", "Partnership", "LLP", "Private Limited", "Public Limited", "Other"];
export const ISO_OPTIONS = ["ISO 9001", "ISO 14001", "ISO/IEC 27001", "ISO 45001", "ISO 13485", "Other"];
