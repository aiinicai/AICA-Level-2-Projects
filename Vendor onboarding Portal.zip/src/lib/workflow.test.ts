import { describe, it, expect } from "vitest";
import { checkTransition, tempCodePreview, formatErpCode, renderTemplate, validateManualErpCode } from "./workflow";

describe("workflow rules", () => {
  it("purchase head cannot approve finance stage", () => {
    expect(checkTransition(["PURCHASE_HEAD"], "PENDING_FINANCE", "finance_approve", { tfaStatus: "Verified" }).ok).toBe(false);
  });
  it("purchase head send back requires comments", () => {
    expect(checkTransition(["PURCHASE_HEAD"], "PENDING_PURCHASE_HEAD", "head_send_back", { comment: "" }).ok).toBe(false);
    expect(checkTransition(["PURCHASE_HEAD"], "PENDING_PURCHASE_HEAD", "head_send_back", { comment: "fix PAN" }).ok).toBe(true);
  });
  it("head approve routes to finance", () => {
    const r = checkTransition(["PURCHASE_HEAD"], "PENDING_PURCHASE_HEAD", "head_approve", { comment: "ok" });
    expect(r.ok && r.to).toBe("PENDING_FINANCE");
  });
  it("finance approval blocked until 2FA confirmed", () => {
    expect(checkTransition(["FINANCE_CONTROLLER"], "PENDING_FINANCE", "finance_approve", { tfaStatus: "Not Started" }).ok).toBe(false);
    expect(checkTransition(["FINANCE_CONTROLLER"], "PENDING_FINANCE", "finance_approve", { tfaStatus: "Verified" }).ok).toBe(true);
  });
  it("ERP code only after APPROVED", () => {
    expect(checkTransition(["PURCHASE_USER"], "PENDING_FINANCE", "assign_erp").ok).toBe(false);
    expect(checkTransition(["PURCHASE_USER"], "APPROVED", "assign_erp").ok).toBe(true);
  });
  it("temp code format MONTHUSERNO", () => {
    expect(tempCodePreview(new Date(2026, 3, 1), "Narayan", 1)).toBe("APRNAR01");
    expect(tempCodePreview(new Date(2026, 9, 1), "Purchase", 12)).toBe("OCTPUR12");
  });
  it("ERP code format", () => {
    expect(formatErpCode(1)).toBe("TMS-V-1001");
  });
  it("manual ERP code accepts letters/numbers/dashes and uppercases, rejects the rest", () => {
    expect(validateManualErpCode("tms-v-1042")).toEqual({ ok: true, code: "TMS-V-1042" });
    expect(validateManualErpCode("VND-0091")).toEqual({ ok: true, code: "VND-0091" });
    expect(validateManualErpCode("VND 9").ok).toBe(false);
    expect(validateManualErpCode("A").ok).toBe(false);
    expect(validateManualErpCode("THIS-CODE-IS-WAY-TOO-LONG-FOR-ERP").ok).toBe(false);
  });
  it("renders template tags", () => {
    expect(renderTemplate("Hi {{vendor_name}} {{temp_code}}", { vendor_name: "Acme", temp_code: "OCTPUR01" })).toBe("Hi Acme OCTPUR01");
  });
});
