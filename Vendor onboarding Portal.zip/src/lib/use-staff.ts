import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppRole } from "./workflow";

export type Staff = { id: string; email: string; full_name: string; is_active: boolean; roles: AppRole[] };

export function useStaff() {
  return useQuery({
    queryKey: ["me"],
    queryFn: async (): Promise<Staff | null> => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const [{ data: p }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", u.user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", u.user.id),
      ]);
      return {
        id: u.user.id,
        email: p?.email ?? u.user.email ?? "",
        full_name: p?.full_name ?? "",
        is_active: p?.is_active ?? false,
        roles: (r ?? []).map((x) => x.role as AppRole),
      };
    },
  });
}

export const hasAny = (s: Staff | null | undefined, roles: AppRole[]) => !!s && s.roles.some((r) => roles.includes(r));
