import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandHeader } from "@/components/app/BrandHeader";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Staff Sign In — TMS Vendor Portal" },
      { name: "description", content: "Sign in to the Times India vendor onboarding and approval portal." },
      { property: "og:title", content: "Staff Sign In — TMS Vendor Portal" },
      { property: "og:description", content: "Internal access to vendor onboarding and approvals." },
    ],
  }),
  component: Login,
});

function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      } else {
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: name }, emailRedirectTo: `${window.location.origin}/dashboard` },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/dashboard" });
        else toast.success("Check your email to confirm your account, then sign in.");
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <BrandHeader />
      <div className="mx-auto grid max-w-5xl gap-10 px-4 py-16 md:grid-cols-2">
        <div className="hidden flex-col justify-center md:flex">
          <div className="mb-4 h-1 w-14 bg-primary" />
          <h1 className="text-3xl font-extrabold leading-tight text-navy">Vendor Onboarding &amp; Approval Portal</h1>
          <p className="mt-4 text-muted-foreground">Initiate vendors, review dossiers, and route approvals through Purchase and Finance with a full audit trail.</p>
          <ul className="mt-6 space-y-2 text-sm text-navy">
            {["Role-based approvals (L1 / L2)", "Secure vendor magic links", "Field-level audit logging"].map((t) => (
              <li key={t} className="flex items-center gap-2"><ShieldCheck className="size-4 text-primary" />{t}</li>
            ))}
          </ul>
        </div>
        <form onSubmit={submit} className="rounded-md border border-t-[3px] border-t-navy bg-card p-8 shadow-sm">
          <h2 className="text-xl font-bold text-navy">{mode === "in" ? "Staff sign in" : "Create staff account"}</h2>
          <p className="mb-6 mt-1 text-sm text-muted-foreground">
            {mode === "in" ? "Use your company credentials." : "The first account becomes the Administrator."}
          </p>
          <div className="space-y-4">
            {mode === "up" && (
              <div><Label>Full name</Label><Input required value={name} onChange={(e) => setName(e.target.value)} maxLength={100} /></div>
            )}
            <div><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <div><Label>Password</Label><Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
            <Button className="w-full" disabled={busy}>{busy ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"}</Button>
          </div>
          <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="mt-4 text-sm font-semibold text-navy-2 hover:underline">
            {mode === "in" ? "Need an account? Register" : "Already registered? Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
