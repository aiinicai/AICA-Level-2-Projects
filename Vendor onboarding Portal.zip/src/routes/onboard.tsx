import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { CheckCircle2, FileCheck2, Plus, Trash2, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BrandHeader } from "@/components/app/BrandHeader";
import { getVendorSession, vendorRegisterDoc, vendorSave, vendorUploadUrl, type VendorProfileInput } from "@/lib/vendor.functions";
import { BUSINESS_TYPES, DOC_CATEGORIES, ISO_OPTIONS, REQUIRED_VENDOR_DOCS } from "@/lib/workflow";
import { GEO } from "@/lib/geo";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboard")({
  validateSearch: (s: Record<string, unknown>) => ({ token: typeof s["token"] === "string" ? (s["token"] as string) : "" }),
  head: () => ({
    meta: [
      { title: "Vendor Application — Times India" },
      { name: "description", content: "Secure vendor onboarding application for Times India." },
      { property: "og:title", content: "Vendor Application — Times India" },
      { property: "og:description", content: "Complete your secure vendor onboarding application." },
      { name: "robots", content: "noindex" },
    ],
  }),
  ssr: false,
  component: Onboard,
});

const EMPTY: VendorProfileInput = {
  legal_name: "", trade_name: "", business_type: "", pan: "", cin: "", msme_reg_no: "", primary_contact_name: "", primary_email: "",
  primary_phone: "", website: "", address_line1: "", address_line2: "", city: "", state: "", country: "", postal_code: "",
  bank_account_number: "", bank_code_swift_ifsc: "", gstin_entries: [], key_persons: [], iso_certifications: [], other_iso_notes: "",
  litigation_details: "", has_conflict_of_interest: false, agreed_conflict_disclosure: false, agreed_anti_bribery: false, additional_notes: "",
};
const SECTIONS = ["Corporate Profile", "GSTINs & Personnel", "Banking & Quality", "Documents & Declarations"];

function Onboard() {
  const { token } = Route.useSearch();
  const getSession = useServerFn(getVendorSession);
  const { data, error, isLoading } = useQuery({
    queryKey: ["vendor-session", token],
    enabled: !!token,
    retry: false,
    queryFn: () => getSession({ data: { token } }),
  });

  return (
    <div className="min-h-screen bg-background">
      <BrandHeader />
      <div className="mx-auto max-w-4xl px-4 py-8">
        {!token ? <Notice title="Invalid link" text="This page requires a secure onboarding link from Times India." />
          : isLoading ? <p className="text-muted-foreground">Loading your application…</p>
          : error ? <Notice title="Link unavailable" text={(error as Error).message} />
          : data?.locked ? <Receipt name={data.vendor_name} code={data.temp_vendor_code} />
          : data && <Wizard token={token} session={data} />}
      </div>
    </div>
  );
}

const Notice = ({ title, text }: { title: string; text: string }) => (
  <div className="rounded-md border border-t-[3px] border-t-primary bg-card p-8 text-center"><h1 className="text-xl font-bold text-navy">{title}</h1><p className="mt-2 text-muted-foreground">{text}</p></div>
);

function Receipt({ name, code }: { name: string; code: string }) {
  return (
    <div className="rounded-md border border-t-[3px] border-t-success bg-card p-10 text-center">
      <CheckCircle2 className="mx-auto size-14 text-success" />
      <h1 className="mt-4 text-2xl font-extrabold text-navy">Application Submitted</h1>
      <p className="mt-2 text-muted-foreground">Thank you, {name}. Your submission has been received and is under review by our Purchase and Finance teams.</p>
      <div className="mx-auto mt-6 inline-block rounded border bg-muted px-6 py-3">
        <div className="text-xs font-semibold uppercase text-muted-foreground">Reference</div>
        <div className="font-mono text-lg font-bold text-navy">{code}</div>
      </div>
      <p className="mt-6 text-xs text-muted-foreground">This link is now locked. We will contact you if anything else is needed.</p>
    </div>
  );
}

type Session = Awaited<ReturnType<typeof getVendorSession>>;

function Wizard({ token, session }: { token: string; session: Session }) {
  const qc = useQueryClient();
  const save = useServerFn(vendorSave);
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState<VendorProfileInput>(() => {
    const p = session.profile as any;
    if (!p) return { ...EMPTY, legal_name: session.vendor_name, primary_email: session.vendor_email };
    const out: any = { ...EMPTY };
    for (const k of Object.keys(EMPTY)) if (p[k] !== null && p[k] !== undefined) out[k] = p[k];
    return out;
  });
  const set = <K extends keyof VendorProfileInput>(k: K, v: VendorProfileInput[K]) => setF((x) => ({ ...x, [k]: v }));

  const persist = async (submit: boolean) => {
    setBusy(true);
    try {
      await save({ data: { token, profile: f, submit } });
      if (submit) { toast.success("Application submitted"); qc.invalidateQueries({ queryKey: ["vendor-session", token] }); }
      else toast.success("Draft saved");
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="mb-3 h-1 w-14 bg-primary" />
        <h1 className="text-2xl font-extrabold text-navy">Vendor Onboarding Application</h1>
        <p className="text-sm text-muted-foreground">{session.vendor_name} · Reference <span className="font-mono font-semibold text-navy">{session.temp_vendor_code}</span></p>
      </div>
      <ol className="grid grid-cols-4 gap-2">
        {SECTIONS.map((s, i) => (
          <li key={s}>
            <button onClick={() => setStep(i)} className={cn("w-full border-t-[3px] pt-2 text-left text-xs font-semibold", i === step ? "border-primary text-navy" : i < step ? "border-navy text-navy/70" : "border-border text-muted-foreground")}>
              <span className="block text-[10px] uppercase tracking-wider">Section {i + 1}</span>{s}
            </button>
          </li>
        ))}
      </ol>
      <div className="rounded-md border bg-card p-6">
        {step === 0 && <Section1 f={f} set={set} />}
        {step === 1 && <Section2 f={f} set={set} />}
        {step === 2 && <Section3 f={f} set={set} />}
        {step === 3 && <Section4 f={f} set={set} token={token} docs={session.documents} />}
      </div>
      <div className="flex flex-wrap justify-between gap-2">
        <Button variant="outline" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</Button>
        <div className="flex gap-2">
          <Button variant="outline" disabled={busy} onClick={() => persist(false)}>Save draft</Button>
          {step < 3 ? <Button variant="navy" onClick={() => setStep(step + 1)}>Continue</Button>
            : <Button disabled={busy} onClick={() => persist(true)}>Submit Application</Button>}
        </div>
      </div>
    </div>
  );
}

type SP = { f: VendorProfileInput; set: <K extends keyof VendorProfileInput>(k: K, v: VendorProfileInput[K]) => void };

function Field({ label, req, children, className }: { label: string; req?: boolean | undefined; children: ReactNode; className?: string | undefined }) {
  return <div className={className}><Label className="text-xs font-semibold text-navy">{label}{req && <span className="text-primary"> *</span>}</Label><div className="mt-1">{children}</div></div>;
}
function TI({ f, set, k, label, req, max = 200, className }: SP & { k: keyof VendorProfileInput; label: string; req?: boolean; max?: number; className?: string }) {
  return <Field label={label} req={req} className={className}><Input value={(f[k] as string) ?? ""} maxLength={max} onChange={(e) => set(k, e.target.value as any)} /></Field>;
}
function Pick({ value, options, onChange, placeholder, disabled }: { value: string; options: string[]; onChange: (v: string) => void; placeholder: string; disabled?: boolean }) {
  return (
    <Select value={value} onValueChange={onChange} disabled={!!disabled}>
      <SelectTrigger><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
    </Select>
  );
}
function GeoPicker({ country, state, city, onChange }: { country: string; state: string; city: string; onChange: (v: { country: string; state: string; city: string }) => void }) {
  const states = country ? Object.keys(GEO[country] ?? {}) : [];
  const cities = country && state ? GEO[country]?.[state] ?? [] : [];
  return (
    <>
      <Field label="Country" req><Pick value={country} options={Object.keys(GEO)} placeholder="Select country" onChange={(v) => onChange({ country: v, state: "", city: "" })} /></Field>
      <Field label="State / Province" req><Pick value={state} options={states} placeholder="Select state" disabled={!country} onChange={(v) => onChange({ country, state: v, city: "" })} /></Field>
      <Field label="City" req><Pick value={city} options={cities} placeholder="Select city" disabled={!state} onChange={(v) => onChange({ country, state, city: v })} /></Field>
    </>
  );
}
const H = ({ children }: { children: ReactNode }) => <h2 className="mb-4 mt-2 border-l-[3px] border-primary pl-3 text-base font-bold text-navy first:mt-0">{children}</h2>;

function Section1(p: SP) {
  const { f, set } = p;
  return (
    <div className="space-y-6">
      <H>Corporate Profile</H>
      <div className="grid gap-4 sm:grid-cols-2">
        <TI {...p} k="legal_name" label="Legal entity name" req />
        <TI {...p} k="trade_name" label="Trade name" />
        <Field label="Business type" req><Pick value={f.business_type ?? ""} options={BUSINESS_TYPES} placeholder="Select type" onChange={(v) => set("business_type", v)} /></Field>
        <TI {...p} k="pan" label="PAN / Tax ID" req max={20} />
        <TI {...p} k="cin" label="CIN" max={30} />
        <TI {...p} k="msme_reg_no" label="MSME registration no." max={40} />
        <TI {...p} k="primary_contact_name" label="Primary contact name" req />
        <TI {...p} k="primary_email" label="Primary email" req max={255} />
        <TI {...p} k="primary_phone" label="Primary phone" req max={30} />
        <TI {...p} k="website" label="Website" max={255} />
      </div>
      <H>Registered Address</H>
      <div className="grid gap-4 sm:grid-cols-3">
        <TI {...p} k="address_line1" label="Address line 1" req className="sm:col-span-3" />
        <TI {...p} k="address_line2" label="Address line 2" className="sm:col-span-3" />
        <GeoPicker country={f.country ?? ""} state={f.state ?? ""} city={f.city ?? ""} onChange={(g) => { set("country", g.country); set("state", g.state); set("city", g.city); }} />
        <TI {...p} k="postal_code" label="Postal code" req max={20} />
      </div>
    </div>
  );
}

function RowTable<T extends Record<string, any>>({ rows, cols, onChange, empty }: { rows: T[]; cols: [keyof T & string, string][]; onChange: (r: T[]) => void; empty: T }) {
  return (
    <div className="space-y-2">
      {rows.map((r, i) => (
        <div key={i} className="grid items-end gap-2 rounded border bg-muted/40 p-3 sm:grid-cols-[repeat(auto-fit,minmax(120px,1fr))_auto]">
          {cols.map(([k, label]) => (
            <Field key={k} label={label}><Input className="h-8" value={r[k] ?? ""} maxLength={200} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)))} /></Field>
          ))}
          <Button size="icon" variant="ghost" onClick={() => onChange(rows.filter((_, j) => j !== i))} aria-label="Remove row"><Trash2 className="text-primary" /></Button>
        </div>
      ))}
      <Button size="sm" variant="outline" onClick={() => onChange([...rows, { ...empty }])}><Plus /> Add Row</Button>
    </div>
  );
}

function Section2({ f, set }: SP) {
  return (
    <div className="space-y-6">
      <H>Operating GSTINs</H>
      <RowTable rows={f.gstin_entries as any[]} onChange={(r) => set("gstin_entries", r)}
        empty={{ gstin: "", address1: "", address2: "", postal_code: "", city: "", state: "", country: "" }}
        cols={[["gstin", "GSTIN"], ["address1", "Address 1"], ["address2", "Address 2"], ["city", "City"], ["state", "State"], ["postal_code", "Postal"], ["country", "Country"]]} />
      <H>Key Personnel</H>
      <RowTable rows={f.key_persons as any[]} onChange={(r) => set("key_persons", r)}
        empty={{ name: "", designation: "", email: "", phone: "", pan: "" }}
        cols={[["name", "Name"], ["designation", "Designation"], ["email", "Email"], ["phone", "Phone"], ["pan", "PAN"]]} />
    </div>
  );
}

function Section3(p: SP) {
  const { f, set } = p;
  const toggle = (iso: string, on: boolean) => set("iso_certifications", on ? [...f.iso_certifications, iso] : f.iso_certifications.filter((x) => x !== iso));
  return (
    <div className="space-y-6">
      <H>Banking Details</H>
      <div className="grid gap-4 sm:grid-cols-2">
        <TI {...p} k="bank_account_number" label="Bank account number" req max={40} />
        <TI {...p} k="bank_code_swift_ifsc" label="IFSC / SWIFT code" req max={20} />
      </div>
      <H>Quality Standards</H>
      <div className="grid gap-3 sm:grid-cols-3">
        {ISO_OPTIONS.map((iso) => (
          <label key={iso} className="flex items-center gap-2 rounded border p-3 text-sm font-semibold text-navy">
            <Checkbox checked={f.iso_certifications.includes(iso)} onCheckedChange={(v) => toggle(iso, !!v)} />{iso}
          </label>
        ))}
      </div>
      {f.iso_certifications.includes("Other") && <Field label="Other ISO details"><Textarea value={f.other_iso_notes ?? ""} maxLength={1000} onChange={(e) => set("other_iso_notes", e.target.value)} /></Field>}
    </div>
  );
}

function Section4({ f, set, token, docs }: SP & { token: string; docs: Session["documents"] }) {
  const [list, setList] = useState(docs);
  useEffect(() => setList(docs), [docs]);
  return (
    <div className="space-y-6">
      <H>Document Uploads</H>
      <div className="grid gap-3 sm:grid-cols-2">
        {(["incorp", "bank_proof", "gst_certs", "msme_cert", "iso_cert"] as const).map((c) => (
          <Uploader key={c} token={token} category={c} files={list.filter((d) => d.category === c)} onUploaded={(d) => setList((l) => [...l, d])} />
        ))}
      </div>
      <H>Declarations</H>
      <div className="space-y-4">
        <Field label="Litigation details (if any)"><Textarea value={f.litigation_details ?? ""} maxLength={2000} onChange={(e) => set("litigation_details", e.target.value)} placeholder="Describe any pending or past litigation, or leave blank" /></Field>
        <Decl checked={f.has_conflict_of_interest} onChange={(v) => set("has_conflict_of_interest", v)} text="We have a potential conflict of interest with Times India employees or affiliates (tick only if applicable)." />
        <Decl req checked={f.agreed_conflict_disclosure} onChange={(v) => set("agreed_conflict_disclosure", v)} text="We agree to disclose any conflict of interest that arises during our relationship with Times India." />
        <Decl req checked={f.agreed_anti_bribery} onChange={(v) => set("agreed_anti_bribery", v)} text="We comply with the Times India anti-bribery and anti-corruption policy and applicable laws (FCPA, UK Bribery Act, Prevention of Corruption Act)." />
        <Field label="Additional notes"><Textarea value={f.additional_notes ?? ""} maxLength={2000} onChange={(e) => set("additional_notes", e.target.value)} /></Field>
      </div>
    </div>
  );
}

const Decl = ({ checked, onChange, text, req }: { checked: boolean; onChange: (v: boolean) => void; text: string; req?: boolean }) => (
  <label className="flex gap-3 rounded border p-3 text-sm"><Checkbox checked={checked} onCheckedChange={(v) => onChange(!!v)} className="mt-0.5" /><span>{text}{req && <span className="font-bold text-primary"> *</span>}</span></label>
);

function Uploader({ token, category, files, onUploaded }: { token: string; category: string; files: Session["documents"]; onUploaded: (d: Session["documents"][number]) => void }) {
  const getUrl = useServerFn(vendorUploadUrl);
  const register = useServerFn(vendorRegisterDoc);
  const [busy, setBusy] = useState(false);
  const req = REQUIRED_VENDOR_DOCS.includes(category);
  const upload = async (file: File) => {
    if (file.size > 20 * 1024 * 1024) { toast.error("Max file size is 20 MB"); return; }
    setBusy(true);
    try {
      const { path, uploadToken } = await getUrl({ data: { token, category, fileName: file.name } });
      const { error } = await supabase.storage.from("vendor-docs").uploadToSignedUrl(path, uploadToken, file);
      if (error) throw error;
      onUploaded(await register({ data: { token, category, fileName: file.name, path } }));
      toast.success(`${file.name} uploaded`);
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className={cn("rounded border p-3", files.length ? "border-success/40 bg-success/5" : "border-dashed")}>
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm font-semibold text-navy">{DOC_CATEGORIES[category]}{req && <span className="text-primary"> *</span>}</div>
        <Label className={cn("inline-flex cursor-pointer items-center gap-1 rounded border bg-card px-2 py-1 text-xs font-semibold hover:bg-muted", busy && "opacity-50")}>
          <Upload className="size-3.5" />{busy ? "Uploading…" : "Upload"}
          <input type="file" className="hidden" accept=".pdf,.png,.jpg,.jpeg" disabled={busy} onChange={(e) => { const fl = e.target.files?.[0]; if (fl) upload(fl); e.target.value = ""; }} />
        </Label>
      </div>
      {files.map((d) => <div key={d.id} className="mt-1 flex items-center gap-1.5 truncate text-xs text-muted-foreground"><FileCheck2 className="size-3.5 text-success" />{d.file_name}</div>)}
    </div>
  );
}
