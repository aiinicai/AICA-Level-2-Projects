import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TMS Vendor Onboarding Portal" },
      { name: "description", content: "Times India vendor onboarding and approval portal." },
      { property: "og:title", content: "TMS Vendor Onboarding Portal" },
      { property: "og:description", content: "Vendor onboarding and multi-stage approvals for Times India." },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/dashboard" });
  },
});
