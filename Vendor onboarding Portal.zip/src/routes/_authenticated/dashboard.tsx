import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Copy, Mail, Plus, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/app/StatusBadge";
import { useStaff, hasAny } from "@/lib/use-staff";
import { sendInvitationEmail } from "@/lib/staff.functions";
import { ALL_STATUSES, DEFAULT_EMAIL_TEMPLATE, STATUS_LABELS, renderTemplate, type Status } from "@/lib/workflow";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — TMS Vendor Portal" },
      { name: "description", content: "Overview of vendor onboarding pipeline and approvals." },
      { property: "og:title", content: "Dashboard — TMS Vendor Portal" },
      { property: "og:description", content: "Vendor onboarding pipeline overview." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { data: staff } = useStaff();
  const [q, setQ] = useState("");
  const [stage, setStage] = useState<string>("ALL");
  const [open, setOpen] = useState(false);
  const { data: rows = [] } = useQuery({
    queryKey: ["onboardings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("vendor_onboardings").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const count = (ss: Status[]) => rows.filter((r) => ss.includes(r.status as Status)).length;
  const metrics = [
    { label: "Initiated", value: count(["INITIATED"]), hint: "Awaiting vendor" },
    { label: "Under Purchase Review", value: count(["SUBMITTED_BY_VENDOR", "UNDER_PURCHASE_REVIEW", "SENT_BACK"]), hint: "Incl. sent back" },
    { label: "Pending L1 / L2", value: count(["PENDING_PURCHASE_HEAD", "PENDING_FINANCE"]), hint: `${count(["PENDING_PURCHASE_HEAD"])} L1 · ${count(["PENDING_FINANCE"])} L2` },
    { label: "Approved / Completed", value: count(["APPROVED", "COMPLETED"]), hint: `${count(["COMPLETED"])} with ERP code` },
  ];

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return rows.filter(
      (r) =>
        (stage === "ALL" || r.status === stage) &&
        (!t || [r.vendor_name, r.vendor_email, r.temp_vendor_code, r.final_vendor_code ?? ""].some((v) => v.toLowerCase().includes(t))),
    );
  }, [rows, q, stage]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">Vendor Onboarding</h1>
          <p className="text-sm text-muted-foreground">Track every vendor from invitation to ERP code assignment.</p>
        </div>
        {hasAny(staff, ["PURCHASE_USER", "ADMIN"]) && (
          <Button onClick={() => setOpen(true)}><Plus /> Initiate New Vendor</Button>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((m) => (
          <div key={m.label} className="rounded-md border border-l-[3px] border-l-primary bg-card p-4">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{m.label}</div>
            <div className="mt-1 text-3xl font-extrabold text-navy">{m.value}</div>
            <div className="text-xs text-muted-foreground">{m.hint}</div>
          </div>
        ))}
      </div>

      <div className="rounded-md border bg-card">
        <div className="flex flex-wrap gap-3 border-b p-3">
          <div className="relative min-w-64 flex-1">
            <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
            <Input className="pl-8" placeholder="Search vendor name, temp code, email…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <Select value={stage} onValueChange={setStage}>
            <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All stages</SelectItem>
              {ALL_STATUSES.map((s) => <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-navy text-left text-xs uppercase tracking-wide text-navy-foreground">
              <tr>{["Temp Code", "Vendor", "Email", "Status", "ERP Code", "Updated"].map((h) => <th key={h} className="px-4 py-2.5 font-semibold">{h}</th>)}</tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.id} className="border-b last:border-0 hover:bg-muted/60">
                  <td className="px-4 py-3 font-mono font-semibold text-navy">
                    <Link to="/vendor/$id" params={{ id: r.id }} className="hover:text-primary">{r.temp_vendor_code}</Link>
                  </td>
                  <td className="px-4 py-3 font-semibold"><Link to="/vendor/$id" params={{ id: r.id }}>{r.vendor_name}</Link></td>
                  <td className="px-4 py-3 text-muted-foreground">{r.vendor_email}</td>
                  <td className="px-4 py-3"><StatusBadge status={r.status as Status} /></td>
                  <td className="px-4 py-3 font-mono">{r.final_vendor_code ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{new Date(r.updated_at).toLocaleDateString()}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-12 text-center text-muted-foreground">No vendors match.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {staff && <InitiateDialog open={open} onOpenChange={setOpen} userId={staff.id} actor={staff.email} />}
    </div>
  );
}

function InitiateDialog({ open, onOpenChange, userId, actor }: { open: boolean; onOpenChange: (o: boolean) => void; userId: string; actor: string }) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [tpl, setTpl] = useState(DEFAULT_EMAIL_TEMPLATE);
  const [created, setCreated] = useState<{ id: string; code: string; link: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const { data: preview } = useQuery({
    queryKey: ["next-code", open],
    enabled: open,
    queryFn: async () => (await supabase.rpc("next_temp_code", { _user_id: userId })).data as string,
  });

  const reset = () => { setName(""); setEmail(""); setTpl(DEFAULT_EMAIL_TEMPLATE); setCreated(null); };
  const vars = { vendor_name: name || "Vendor", temp_code: created?.code ?? preview ?? "", form_link: created?.link ?? "(generated after creation)" };
  const body = renderTemplate(tpl, vars);

  const create = async () => {
    if (!name.trim() || !/^\S+@\S+\.\S+$/.test(email)) { toast.error("Enter a vendor name and valid email"); return; }
    setBusy(true);
    try {
      const { data: code } = await supabase.rpc("next_temp_code", { _user_id: userId });
      const { data, error } = await supabase
        .from("vendor_onboardings")
        .insert({ vendor_name: name.trim(), vendor_email: email.trim(), temp_vendor_code: code as string, created_by_user_id: userId })
        .select("id, token, temp_vendor_code")
        .single();
      if (error) throw error;
      await supabase.from("audit_logs").insert({ onboarding_id: data.id, actor_identifier: actor, action: "VENDOR_INITIATED", field_changed: "status", new_value: "INITIATED" });
      setCreated({ id: data.id, code: data.temp_vendor_code, link: `${window.location.origin}/onboard?token=${data.token}` });
      qc.invalidateQueries({ queryKey: ["onboardings"] });
      toast.success(`Vendor ${data.temp_vendor_code} created`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const send = async () => {
    setBusy(true);
    try {
      await sendInvitationEmail({ data: { onboardingId: created!.id, to: email.trim(), subject: `Vendor Onboarding Invitation — ${created?.code}`, body } });
      toast.success(`Invitation emailed to ${email}`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) reset(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-navy">Initiate New Vendor</DialogTitle>
          <DialogDescription>A unique temporary code and secure form link will be generated.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="sm:col-span-1"><Label>Vendor name</Label><Input value={name} disabled={!!created} maxLength={200} onChange={(e) => setName(e.target.value)} /></div>
          <div className="sm:col-span-1"><Label>Vendor email</Label><Input type="email" value={email} disabled={!!created} maxLength={255} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><Label>Temp vendor code</Label><div className="flex h-9 items-center rounded-md border bg-muted px-3 font-mono font-bold text-navy">{created?.code ?? preview ?? "…"}</div></div>
        </div>
        <div>
          <Label>Invitation email template <span className="font-normal text-muted-foreground">— tags: {"{{vendor_name}}"}, {"{{temp_code}}"}, {"{{form_link}}"}</span></Label>
          <Textarea rows={7} value={tpl} onChange={(e) => setTpl(e.target.value)} className="font-mono text-xs" />
        </div>
        <div className="rounded-md border bg-muted/50 p-3">
          <div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Preview</div>
          <pre className="whitespace-pre-wrap font-sans text-sm">{body}</pre>
        </div>
        <div className="flex justify-end gap-2">
          {!created ? (
            <Button onClick={create} disabled={busy}>{busy ? "Creating…" : "Create & Generate Link"}</Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => { navigator.clipboard.writeText(created.link); toast.success("Link copied"); }}><Copy /> Copy Link</Button>
              <Button onClick={send} disabled={busy}><Mail /> {busy ? "Sending…" : "Send Invitation"}</Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
