import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/audit")({
  head: () => ({
    meta: [
      { title: "Audit Trail — TMS Vendor Portal" },
      { name: "description", content: "Read-only log of all vendor onboarding actions and changes." },
      { property: "og:title", content: "Audit Trail — TMS Vendor Portal" },
      { property: "og:description", content: "Read-only onboarding audit log." },
    ],
  }),
  component: Audit,
});

function Audit() {
  const [q, setQ] = useState("");
  const { data = [] } = useQuery({
    queryKey: ["audit"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*, vendor_onboardings(temp_vendor_code, vendor_name)")
        .order("timestamp", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return data;
    },
  });
  const rows = useMemo(() => {
    const t = q.toLowerCase().trim();
    if (!t) return data;
    return data.filter((r) =>
      [r.actor_identifier, r.action, r.field_changed, r.old_value, r.new_value, r.vendor_onboardings?.temp_vendor_code, r.vendor_onboardings?.vendor_name]
        .some((v) => (v ?? "").toLowerCase().includes(t)),
    );
  }, [data, q]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">Audit Trail</h1>
          <p className="text-sm text-muted-foreground">Every action and field change, read-only.</p>
        </div>
        <Input className="w-80" placeholder="Filter by actor, action, vendor, value…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="overflow-x-auto rounded-md border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-navy text-left text-xs uppercase tracking-wide text-navy-foreground">
            <tr>{["Timestamp", "Vendor", "Actor", "Action", "Field", "Before", "After"].map((h) => <th key={h} className="px-3 py-2.5 font-semibold">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b align-top last:border-0">
                <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">{new Date(r.timestamp).toLocaleString()}</td>
                <td className="px-3 py-2 font-mono text-navy">
                  {r.onboarding_id && r.vendor_onboardings ? <Link to="/vendor/$id" params={{ id: r.onboarding_id }} className="hover:text-primary">{r.vendor_onboardings.temp_vendor_code}</Link> : "—"}
                </td>
                <td className="px-3 py-2">{r.actor_identifier}</td>
                <td className="px-3 py-2 font-semibold">{r.action}</td>
                <td className="px-3 py-2 text-muted-foreground">{r.field_changed ?? ""}</td>
                <td className="max-w-56 break-words px-3 py-2 text-primary/80">{r.old_value ?? ""}</td>
                <td className="max-w-56 break-words px-3 py-2 text-success">{r.new_value ?? ""}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="px-3 py-12 text-center text-muted-foreground">No audit entries.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
