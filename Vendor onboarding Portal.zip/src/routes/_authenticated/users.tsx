import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStaff } from "@/lib/use-staff";
import { ROLE_LABELS, type AppRole } from "@/lib/workflow";
import { createStaff, setUserActive, setUserRole } from "@/lib/staff.functions";

export const Route = createFileRoute("/_authenticated/users")({
  head: () => ({
    meta: [
      { title: "User Management — TMS Vendor Portal" },
      { name: "description", content: "Manage staff accounts and approval roles." },
      { property: "og:title", content: "User Management — TMS Vendor Portal" },
      { property: "og:description", content: "Staff and role administration." },
    ],
  }),
  component: Users,
});

const ROLES = Object.keys(ROLE_LABELS) as AppRole[];

function Users() {
  const { data: me } = useStaff();
  const qc = useQueryClient();
  const create = useServerFn(createStaff);
  const setRole = useServerFn(setUserRole);
  const setActive = useServerFn(setUserActive);
  const [form, setForm] = useState({ email: "", full_name: "", password: "", role: "PURCHASE_USER" });
  const [busy, setBusy] = useState(false);

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const [{ data: p }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at"),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      return (p ?? []).map((u) => ({ ...u, role: (r ?? []).find((x) => x.user_id === u.id)?.role as AppRole | undefined }));
    },
  });

  if (!me?.roles.includes("ADMIN")) return <p className="text-muted-foreground">Only administrators can manage users.</p>;

  const run = async (fn: () => Promise<unknown>, msg: string) => {
    try { await fn(); toast.success(msg); qc.invalidateQueries({ queryKey: ["users"] }); } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">User Management</h1>
        <p className="text-sm text-muted-foreground">Add staff, assign roles, and deactivate accounts.</p>
      </div>
      <form
        className="grid gap-3 rounded-md border border-t-[3px] border-t-navy bg-card p-4 md:grid-cols-5 md:items-end"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          await run(() => create({ data: form }), `${form.email} added`);
          setForm({ email: "", full_name: "", password: "", role: "PURCHASE_USER" });
          setBusy(false);
        }}
      >
        <div><Label>Full name</Label><Input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
        <div><Label>Email</Label><Input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div><Label>Temporary password</Label><Input type="text" minLength={8} required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        <div>
          <Label>Role</Label>
          <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <Button disabled={busy}><UserPlus /> Add staff</Button>
      </form>
      <div className="overflow-x-auto rounded-md border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-navy text-left text-xs uppercase tracking-wide text-navy-foreground">
            <tr>{["Name", "Email", "Role", "Active", "Joined"].map((h) => <th key={h} className="px-4 py-2.5 font-semibold">{h}</th>)}</tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b last:border-0">
                <td className="px-4 py-2 font-semibold">{u.full_name}</td>
                <td className="px-4 py-2 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-2">
                  <Select value={u.role ?? ""} onValueChange={(v) => run(() => setRole({ data: { userId: u.id, role: v } }), "Role updated")}>
                    <SelectTrigger className="w-56"><SelectValue placeholder="No role" /></SelectTrigger>
                    <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
                <td className="px-4 py-2">
                  <Switch checked={u.is_active} disabled={u.id === me.id} onCheckedChange={(v) => run(() => setActive({ data: { userId: u.id, active: v } }), v ? "Activated" : "Deactivated")} />
                </td>
                <td className="px-4 py-2 text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
