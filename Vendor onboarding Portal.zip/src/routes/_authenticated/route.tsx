import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { BrandHeader } from "@/components/app/BrandHeader";
import { useStaff } from "@/lib/use-staff";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/login" });
  },
  component: Layout,
});

function Layout() {
  const { data: staff, isLoading } = useStaff();
  if (isLoading) return <div className="min-h-screen bg-background" />;
  const blocked = !staff || !staff.is_active || staff.roles.length === 0;
  return (
    <div className="min-h-screen bg-background">
      <BrandHeader staff={staff} />
      {blocked ? (
        <div className="mx-auto mt-20 max-w-md rounded-md border bg-card p-8 text-center">
          <h1 className="text-lg font-bold text-navy">Access pending</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {staff && !staff.is_active ? "Your account has been deactivated." : "Your account has no role yet. Ask an administrator to assign one."}
          </p>
        </div>
      ) : (
        <main className="mx-auto max-w-7xl px-4 py-6"><Outlet /></main>
      )}
    </div>
  );
}
