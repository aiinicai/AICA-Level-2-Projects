import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ArrowLeft, Check, Download, KeyRound, Lock, Pencil, Save, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/app/StatusBadge";
import { useStaff, hasAny } from "@/lib/use-staff";
import { DOC_CATEGORIES, TFA_STATUSES, type Status, type WorkflowAction } from "@/lib/workflow";
import { nextErpSuggestion, updateTfa, updateVendorProfile, workflowAction } from "@/lib/staff.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/vendor/$id")({
  head: () => ({
    meta: [
      { title: "Vendor Review — TMS Vendor Portal" },
      { name: "description", content: "Vendor dossier and multi-stage approval workflow." },
      { property: "og:title", content: "Vendor Review — TMS Vendor Portal" },
      { property: "og:description", content: "Vendor dossier and approvals." },
    ],
  }),
  component: VendorPage,
});

const EDITABLE: [string, string][] = [
  ["legal_name", "Legal name"], ["trade_name", "Trade name"], ["business_type", "Business type"], ["pan", "PAN"], ["cin", "CIN"],
  ["msme_reg_no", "MSME reg. no."], ["primary_contact_name", "Primary contact"], ["primary_email", "Primary email"],
  ["primary_phone", "Primary phone"], ["website", "Website"], ["address_line1", "Address line 1"], ["address_line2", "Address line 2"],
  ["city", "City"], ["state", "State"], ["country", "Country"], ["postal_code", "Postal code"],
  ["bank_account_number", "Bank account no."], ["bank_code_swift_ifsc", "IFSC / SWIFT"],
];

function VendorPage() {
  const { id } = Route.useParams();
  const { data: staff } = useStaff();
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["vendor", id],
    queryFn: async () => {
      const [o, p, d, r] = await Promise.all([
        supabase.from("vendor_onboardings").select("*").eq("id", id).single(),
        supabase.from("vendor_profiles").select("*").eq("onboarding_id", id).maybeSingle(),
        supabase.from("vendor_documents").select("*").eq("onboarding_id", id).order("created_at"),
        supabase.from("internal_reviews").select("*").eq("onboarding_id", id).maybeSingle(),
      ]);
      if (o.error) throw o.error;
      return { onb: o.data, profile: p.data, docs: d.data ?? [], review: r.data };
    },
  });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["vendor", id] }); qc.invalidateQueries({ queryKey: ["onboardings"] }); };

  if (isLoading || !data) return <p className="text-muted-foreground">Loading…</p>;
  const { onb, profile, docs, review } = data;
  const status = onb.status as Status;
  const canEdit = hasAny(staff, ["PURCHASE_USER", "ADMIN"]) && !["APPROVED", "COMPLETED", "REJECTED"].includes(status);

  return (
    <div className="space-y-5">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm font-semibold text-navy-2 hover:text-primary"><ArrowLeft className="size-4" /> Back to dashboard</Link>
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-md border border-l-[3px] border-l-primary bg-card p-5">
        <div>
          <div className="font-mono text-sm font-bold text-primary">{onb.temp_vendor_code}{onb.final_vendor_code && <span className="ml-3 text-success">ERP: {onb.final_vendor_code}</span>}</div>
          <h1 className="text-2xl font-extrabold text-navy">{onb.vendor_name}</h1>
          <div className="text-sm text-muted-foreground">{onb.vendor_email} · Initiated {new Date(onb.created_at).toLocaleDateString()}</div>
        </div>
        <StatusBadge status={status} />
      </div>
      <div className="grid gap-5 lg:grid-cols-[1fr_400px]">
        <div className="space-y-5">
          <Dossier id={id} profile={profile} canEdit={canEdit && !!profile} onSaved={refresh} />
          <Documents docs={docs} />
        </div>
        <Stepper id={id} status={status} review={review} staff={staff} onDone={refresh} />
      </div>
    </div>
  );
}

function Panel({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="rounded-md border bg-card">
      <div className="flex items-center justify-between border-b bg-muted/50 px-4 py-2.5">
        <h2 className="text-sm font-bold uppercase tracking-wide text-navy">{title}</h2>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

function Dossier({ id, profile, canEdit, onSaved }: { id: string; profile: any; canEdit: boolean; onSaved: () => void }) {
  const save = useServerFn(updateVendorProfile);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});
  useEffect(() => { if (profile) { setDraft(Object.fromEntries(EDITABLE.map(([k]) => [k, profile[k] ?? ""]))); } }, [profile, editing]);

  if (!profile) return <Panel title="Vendor Dossier"><p className="text-sm text-muted-foreground">The vendor has not submitted their application yet.</p></Panel>;

  const doSave = async () => {
    try {
      const r = await save({ data: { id, changes: draft } });
      toast.success(r.changed ? `${r.changed} field(s) amended` : "No changes");
      setEditing(false);
      onSaved();
    } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <Panel
      title="Vendor Dossier"
      action={canEdit && (editing ? (
        <div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => setEditing(false)}><X /> Cancel</Button><Button size="sm" onClick={doSave}><Save /> Save</Button></div>
      ) : <Button size="sm" variant="outline" onClick={() => setEditing(true)}><Pencil /> Amend</Button>)}
    >
      <div className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
        {EDITABLE.map(([k, label]) => (
          <div key={k}>
            <div className="text-xs font-semibold uppercase text-muted-foreground">{label}</div>
            {editing ? <Input className="mt-1 h-8" value={draft[k] ?? ""} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} /> : <div className={cn("text-sm", k.startsWith("bank") && "font-mono")}>{profile[k] || "—"}</div>}
          </div>
        ))}
      </div>
      <SubTable title="Operating GSTINs" rows={profile.gstin_entries} cols={["gstin", "address1", "city", "state", "postal_code", "country"]} />
      <SubTable title="Key Personnel" rows={profile.key_persons} cols={["name", "designation", "email", "phone", "pan"]} />
      <div className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
        <div><div className="text-xs font-semibold uppercase text-muted-foreground">ISO certifications</div>{(profile.iso_certifications ?? []).join(", ") || "—"}{profile.other_iso_notes && <div className="text-muted-foreground">{profile.other_iso_notes}</div>}</div>
        <div><div className="text-xs font-semibold uppercase text-muted-foreground">Litigation</div>{profile.litigation_details || "None declared"}</div>
        <div><div className="text-xs font-semibold uppercase text-muted-foreground">Declarations</div>
          <Decl ok={!profile.has_conflict_of_interest} label={profile.has_conflict_of_interest ? "Conflict of interest declared" : "No conflict of interest"} />
          <Decl ok={profile.agreed_conflict_disclosure} label="Conflict disclosure policy" />
          <Decl ok={profile.agreed_anti_bribery} label="Anti-bribery policy" />
        </div>
        <div><div className="text-xs font-semibold uppercase text-muted-foreground">Additional notes</div>{profile.additional_notes || "—"}</div>
      </div>
    </Panel>
  );
}

const Decl = ({ ok, label }: { ok: boolean; label: string }) => (
  <div className="flex items-center gap-1.5">{ok ? <Check className="size-4 text-success" /> : <X className="size-4 text-primary" />}{label}</div>
);

function SubTable({ title, rows, cols }: { title: string; rows: any[]; cols: string[] }) {
  return (
    <div className="mt-5">
      <div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">{title}</div>
      {rows?.length ? (
        <div className="overflow-x-auto rounded border">
          <table className="w-full text-xs">
            <thead className="bg-navy text-navy-foreground"><tr>{cols.map((c) => <th key={c} className="px-2 py-1.5 text-left font-semibold capitalize">{c.replace("_", " ")}</th>)}</tr></thead>
            <tbody>{rows.map((r, i) => <tr key={i} className="border-t">{cols.map((c) => <td key={c} className="px-2 py-1.5">{r[c] || "—"}</td>)}</tr>)}</tbody>
          </table>
        </div>
      ) : <div className="text-sm text-muted-foreground">None</div>}
    </div>
  );
}

function Documents({ docs }: { docs: any[] }) {
  const download = async (path: string) => {
    const { data, error } = await supabase.storage.from("vendor-docs").createSignedUrl(path, 120);
    if (error || !data) { toast.error("Could not open file"); return; }
    window.open(data.signedUrl, "_blank", "noopener");
  };
  return (
    <Panel title="Attachments">
      {docs.length === 0 ? <p className="text-sm text-muted-foreground">No documents uploaded.</p> : (
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="py-1">Category</th><th>File</th><th>Uploaded by</th><th></th></tr></thead>
          <tbody>{docs.map((d) => (
            <tr key={d.id} className="border-t">
              <td className="py-2 font-semibold text-navy">{DOC_CATEGORIES[d.category]}</td>
              <td className="max-w-48 truncate">{d.file_name}</td>
              <td className="text-muted-foreground">{d.uploaded_by}</td>
              <td className="text-right"><Button size="sm" variant="ghost" onClick={() => download(d.file_url)}><Download /></Button></td>
            </tr>
          ))}</tbody>
        </table>
      )}
    </Panel>
  );
}

function Stepper({ id, status, review, staff, onDone }: { id: string; status: Status; review: any; staff: any; onDone: () => void }) {
  const act = useServerFn(workflowAction);
  const tfa = useServerFn(updateTfa);
  const [busy, setBusy] = useState(false);
  const [prep, setPrep] = useState(review?.prepare_notes ?? "");
  const [headC, setHeadC] = useState("");
  const [finC, setFinC] = useState("");
  const [tfaStatus, setTfaStatus] = useState(review?.tfa_status ?? "Not Started");
  const [tfaNotes, setTfaNotes] = useState(review?.tfa_notes ?? "");
  const [erpOpen, setErpOpen] = useState(false);
  const [erpCode, setErpCode] = useState("");
  const nextSug = useServerFn(nextErpSuggestion);
  useEffect(() => { setTfaStatus(review?.tfa_status ?? "Not Started"); setTfaNotes(review?.tfa_notes ?? ""); }, [review]);
  useEffect(() => {
    if (erpOpen) nextSug().then((r: { code: string }) => setErpCode(r.code)).catch(() => setErpCode(""));
  }, [erpOpen, nextSug]);

  const run = async (action: WorkflowAction, comment?: string, extra?: Record<string, string | undefined>) => {
    setBusy(true);
    try {
      const r = await act({ data: { id, action, comment, ...extra } });
      toast.success(r.final_vendor_code ? `ERP code ${r.final_vendor_code} assigned` : "Workflow updated");
      setHeadC(""); setFinC(""); setErpOpen(false); setErpCode("");
      onDone();
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };

  const uploadEvidence = async (f: File) => {
    const path = `${id}/tfa_evidence/${Date.now()}-${f.name.replace(/[^\w.\-]/g, "_")}`;
    const { error } = await supabase.storage.from("vendor-docs").upload(path, f);
    if (error) { toast.error(error.message); return; }
    await supabase.from("vendor_documents").insert({ onboarding_id: id, category: "tfa_evidence", file_name: f.name, file_url: path, uploaded_by: staff.email });
    await supabase.from("audit_logs").insert({ onboarding_id: id, actor_identifier: staff.email, action: "DOCUMENT_UPLOADED", field_changed: "tfa_evidence", new_value: f.name });
    toast.success("Evidence uploaded");
    onDone();
  };

  const isPU = hasAny(staff, ["PURCHASE_USER", "ADMIN"]);
  const isPH = hasAny(staff, ["PURCHASE_HEAD", "ADMIN"]);
  const isFC = hasAny(staff, ["FINANCE_CONTROLLER", "ADMIN"]);
  const s1Active = ["SUBMITTED_BY_VENDOR", "UNDER_PURCHASE_REVIEW", "SENT_BACK"].includes(status);
  const order: Status[] = ["PENDING_PURCHASE_HEAD", "PENDING_FINANCE", "APPROVED", "COMPLETED"];
  const reached = (s: Status) => order.indexOf(status) >= order.indexOf(s) && order.includes(status);

  return (
    <aside className="space-y-3">
      {status === "INITIATED" && <div className="rounded-md border border-dashed bg-card p-4 text-sm text-muted-foreground">Waiting for the vendor to submit the application.</div>}
      {status === "REJECTED" && <div className="rounded-md border border-primary bg-primary/5 p-4 text-sm font-semibold text-primary">Rejected by Finance: {review?.controller_comments}</div>}
      {status === "SENT_BACK" && <div className="rounded-md border border-warning bg-warning/10 p-4 text-sm"><b>Sent back:</b> {review?.controller_status === "Sent Back" ? review?.controller_comments : review?.purchase_head_comments}</div>}

      <Step n={1} title="Purchase Review — Prepare 1" done={reached("PENDING_PURCHASE_HEAD")} active={s1Active}
        meta={review?.prepare_date && `Prepared ${new Date(review.prepare_date).toLocaleString()}`}>
        {s1Active && isPU ? (
          <div className="space-y-2">
            <Textarea rows={4} placeholder="Internal assessment notes (required)" value={prep} onChange={(e) => setPrep(e.target.value)} maxLength={4000} />
            <div className="flex flex-wrap gap-2">
              <Button size="sm" disabled={busy} onClick={() => run("route_to_head", prep)}>Route to Purchase Head</Button>
              {status === "SUBMITTED_BY_VENDOR" && <Button size="sm" variant="outline" disabled={busy} onClick={() => run("start_review")}>Mark under review</Button>}
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => run("return_to_vendor")}>Reopen vendor form</Button>
            </div>
          </div>
        ) : review?.prepare_notes && <Note text={review.prepare_notes} />}
      </Step>

      <Step n={2} title="Purchase Head — L1 Approval" done={reached("PENDING_FINANCE")} active={status === "PENDING_PURCHASE_HEAD"}
        meta={review?.purchase_head_status && `${review.purchase_head_status} · ${new Date(review.purchase_head_date).toLocaleString()}`}>
        {status === "PENDING_PURCHASE_HEAD" && isPH ? (
          <div className="space-y-2">
            <Textarea rows={3} placeholder="Comments (required)" value={headC} onChange={(e) => setHeadC(e.target.value)} maxLength={4000} />
            <div className="flex gap-2">
              <Button size="sm" variant="success" disabled={busy} onClick={() => run("head_approve", headC)}>Approve &amp; Route to Finance</Button>
              <Button size="sm" variant="outline" disabled={busy} onClick={() => run("head_send_back", headC)}>Send Back</Button>
            </div>
          </div>
        ) : review?.purchase_head_comments && <Note text={review.purchase_head_comments} />}
      </Step>

      <Step n={3} title="Finance Controller — L2 Approval" done={reached("APPROVED")} active={status === "PENDING_FINANCE"}
        meta={review?.controller_status && `${review.controller_status} · ${new Date(review.controller_date).toLocaleString()}`}>
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase text-muted-foreground">2FA verification: <span className="text-navy">{review?.tfa_status ?? "Not Started"}</span></div>
          {status === "PENDING_FINANCE" && isFC && (
            <>
              <div className="flex gap-2">
                <Select value={tfaStatus} onValueChange={setTfaStatus}>
                  <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                  <SelectContent>{TFA_STATUSES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
                <Button size="sm" variant="navy" onClick={async () => { try { await tfa({ data: { id, tfa_status: tfaStatus, tfa_notes: tfaNotes } }); toast.success("2FA status saved"); onDone(); } catch (e) { toast.error((e as Error).message); } }}>Save</Button>
              </div>
              <Input className="h-8" placeholder="2FA notes" value={tfaNotes} onChange={(e) => setTfaNotes(e.target.value)} />
              <Label className="flex cursor-pointer items-center gap-2 rounded border border-dashed p-2 text-xs font-semibold text-navy-2 hover:bg-muted">
                <Upload className="size-4" /> Upload 2FA evidence
                <input type="file" className="hidden" onChange={(e) => e.target.files?.[0] && uploadEvidence(e.target.files[0])} />
              </Label>
              <Textarea rows={3} placeholder="Controller comments (required for send back / reject)" value={finC} onChange={(e) => setFinC(e.target.value)} maxLength={4000} />
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="success" disabled={busy} onClick={() => run("finance_approve", finC || undefined)}>Final Finance Approval</Button>
                <Button size="sm" variant="outline" disabled={busy} onClick={() => run("finance_send_back", finC)}>Send Back</Button>
                <Button size="sm" disabled={busy} onClick={() => run("finance_reject", finC)}>Reject</Button>
              </div>
            </>
          )}
          {status !== "PENDING_FINANCE" && review?.controller_comments && <Note text={review.controller_comments} />}
        </div>
      </Step>

      <Step n={4} title="ERP Vendor Code Assignment" done={status === "COMPLETED"} active={status === "APPROVED"}>
        {status === "APPROVED" ? (
          isPU ? <Button size="sm" onClick={() => setErpOpen(true)}><KeyRound /> Generate ERP Code</Button> : <p className="text-sm text-muted-foreground">Awaiting Purchase User.</p>
        ) : status !== "COMPLETED" && <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><Lock className="size-3.5" /> Unlocks after final approval</p>}
      </Step>

      <Dialog open={erpOpen} onOpenChange={setErpOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-navy">Assign permanent ERP vendor code</DialogTitle>
            <DialogDescription>The next sequential code is suggested below — edit it if your ERP system uses a different code. Assigning marks the onboarding Completed. This cannot be undone.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="erp-code">ERP vendor code</Label>
            <Input id="erp-code" className="font-mono" value={erpCode} onChange={(e) => setErpCode(e.target.value)} placeholder="TMS-V-####" maxLength={20} />
            <p className="text-xs text-muted-foreground">3–20 characters: letters, numbers and dashes. Duplicated codes are rejected.</p>
          </div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setErpOpen(false)}>Cancel</Button><Button disabled={busy} onClick={() => run("assign_erp", undefined, { erp_code: erpCode.trim() || undefined })}>Generate &amp; Assign</Button></div>
        </DialogContent>
      </Dialog>
    </aside>
  );
}

function Step({ n, title, done, active, meta, children }: { n: number; title: string; done: boolean; active: boolean; meta?: string | false | null; children?: ReactNode }) {
  return (
    <div className={cn("rounded-md border bg-card p-4", active && "border-primary shadow-sm ring-1 ring-primary/30")}>
      <div className="mb-2 flex items-center gap-3">
        <span className={cn("flex size-7 items-center justify-center rounded-full text-xs font-bold", done ? "bg-success text-success-foreground" : active ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>
          {done ? <Check className="size-4" /> : n}
        </span>
        <div>
          <div className="text-sm font-bold text-navy">{title}</div>
          {meta && <div className="text-xs text-muted-foreground">{meta}</div>}
        </div>
      </div>
      {children}
    </div>
  );
}

const Note = ({ text }: { text: string }) => <p className="whitespace-pre-wrap rounded bg-muted p-2 text-sm">{text}</p>;
