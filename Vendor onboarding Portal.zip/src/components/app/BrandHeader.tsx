import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ROLE_LABELS } from "@/lib/workflow";
import type { Staff } from "@/lib/use-staff";

export function Brand() {
  return (
    <div className="flex items-baseline gap-2 leading-none">
      <span className="text-base font-extrabold tracking-[0.12em] text-navy-foreground">TIMES INDIA</span>
    </div>
  );
}

export function BrandHeader({ staff }: { staff?: Staff | null | undefined }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const isAdmin = staff?.roles.includes("ADMIN");
  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  };
  const link = "rounded px-3 py-1.5 text-sm font-semibold text-navy-foreground/80 hover:text-navy-foreground";
  const active = { className: "bg-navy-2 text-navy-foreground" };
  return (
    <header className="sticky top-0 z-40 border-b-[3px] border-primary bg-navy">
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4">
        <Link to={staff ? "/dashboard" : "/"}><Brand /></Link>
        {staff && staff.roles.length > 0 && (
          <nav className="flex gap-1">
            <Link to="/dashboard" className={link} activeProps={active}>Dashboard</Link>
            <Link to="/audit" className={link} activeProps={active}>Audit Trail</Link>
            {isAdmin && <Link to="/users" className={link} activeProps={active}>Users</Link>}
          </nav>
        )}
        {staff && (
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden text-right md:block">
              <div className="text-sm font-semibold text-navy-foreground">{staff.full_name || staff.email}</div>
              <div className="text-xs text-navy-foreground/60">{staff.roles.map((r) => ROLE_LABELS[r]).join(", ") || "No role"}</div>
            </div>
            <Button size="sm" variant="navy" onClick={signOut} className="border border-navy-2"><LogOut /> Sign out</Button>
          </div>
        )}
      </div>
    </header>
  );
}
