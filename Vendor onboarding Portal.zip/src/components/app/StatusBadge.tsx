import { STATUS_LABELS, type Status } from "@/lib/workflow";
import { cn } from "@/lib/utils";

const tone: Record<Status, string> = {
  INITIATED: "bg-muted text-muted-foreground border-border",
  SUBMITTED_BY_VENDOR: "bg-info/10 text-info border-info/30",
  UNDER_PURCHASE_REVIEW: "bg-info/10 text-info border-info/30",
  PENDING_PURCHASE_HEAD: "bg-warning/15 text-warning-foreground border-warning/40",
  PENDING_FINANCE: "bg-warning/15 text-warning-foreground border-warning/40",
  APPROVED: "bg-success/10 text-success border-success/30",
  COMPLETED: "bg-success text-success-foreground border-success",
  SENT_BACK: "bg-primary/10 text-primary border-primary/30",
  REJECTED: "bg-primary text-primary-foreground border-primary",
};

export function StatusBadge({ status }: { status: Status }) {
  return (
    <span className={cn("inline-flex items-center rounded border px-2 py-0.5 text-xs font-semibold uppercase tracking-wide", tone[status])}>
      {STATUS_LABELS[status]}
    </span>
  );
}
