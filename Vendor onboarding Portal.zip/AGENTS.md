<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Workflow transitions are defined once in `src/lib/workflow.ts` (`RULES` + `checkTransition`) and enforced server-side in `src/lib/staff.functions.ts`; why: UI and server must agree and roles can't be bypassed.
- Staff roles live in `public.user_roles` (one role per staff user), checked via `has_role`/`is_staff`; first signup becomes ADMIN via trigger; why: prevent privilege escalation.
- Vendors never authenticate: all vendor reads/writes go through token-validated server functions in `src/lib/vendor.functions.ts` using the admin client; files upload via signed upload URLs to the private `vendor-docs` bucket; why: vendors must not see internal data.
- Every state change or field amendment writes an `audit_logs` row in the same server function; why: complete audit trail.
