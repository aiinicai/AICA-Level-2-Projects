
create type public.app_role as enum ('ADMIN','PURCHASE_USER','PURCHASE_HEAD','FINANCE_CONTROLLER');
create type public.onboarding_status as enum ('INITIATED','SUBMITTED_BY_VENDOR','UNDER_PURCHASE_REVIEW','PENDING_PURCHASE_HEAD','PENDING_FINANCE','APPROVED','COMPLETED','SENT_BACK','REJECTED');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles r join public.profiles p on p.id = r.user_id
    where r.user_id = _user_id and r.role = _role and p.is_active)
$$;
create or replace function public.is_staff(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles r join public.profiles p on p.id = r.user_id
    where r.user_id = _user_id and p.is_active)
$$;

create policy "staff read profiles" on public.profiles for select to authenticated using (public.is_staff(auth.uid()) or id = auth.uid());
create policy "admin update profiles" on public.profiles for update to authenticated using (public.has_role(auth.uid(),'ADMIN'));
create policy "read own or staff roles" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.is_staff(auth.uid()));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)));
  if not exists (select 1 from public.user_roles where role = 'ADMIN') then
    insert into public.user_roles (user_id, role) values (new.id, 'ADMIN');
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.vendor_onboardings (
  id uuid primary key default gen_random_uuid(),
  temp_vendor_code text not null unique,
  final_vendor_code text unique,
  vendor_name text not null,
  vendor_email text not null,
  token text not null unique default replace(gen_random_uuid()::text || gen_random_uuid()::text,'-',''),
  token_expires_at timestamptz not null default now() + interval '30 days',
  status onboarding_status not null default 'INITIATED',
  created_by_user_id uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.vendor_onboardings to authenticated;
grant all on public.vendor_onboardings to service_role;
alter table public.vendor_onboardings enable row level security;
create policy "staff read onboardings" on public.vendor_onboardings for select to authenticated using (public.is_staff(auth.uid()));
create policy "purchase create onboardings" on public.vendor_onboardings for insert to authenticated with check ((public.has_role(auth.uid(),'PURCHASE_USER') or public.has_role(auth.uid(),'ADMIN')) and created_by_user_id = auth.uid());
create policy "staff update onboardings" on public.vendor_onboardings for update to authenticated using (public.is_staff(auth.uid()));

create table public.vendor_profiles (
  id uuid primary key default gen_random_uuid(),
  onboarding_id uuid not null unique references public.vendor_onboardings(id) on delete cascade,
  legal_name text, trade_name text, business_type text, pan text, cin text, msme_reg_no text,
  primary_contact_name text, primary_email text, primary_phone text, website text,
  address_line1 text, address_line2 text, city text, state text, country text, postal_code text,
  bank_account_number text, bank_code_swift_ifsc text,
  gstin_entries jsonb not null default '[]', key_persons jsonb not null default '[]',
  iso_certifications text[] not null default '{}', other_iso_notes text,
  litigation_details text, has_conflict_of_interest boolean not null default false,
  agreed_conflict_disclosure boolean not null default false, agreed_anti_bribery boolean not null default false,
  additional_notes text,
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.vendor_profiles to authenticated;
grant all on public.vendor_profiles to service_role;
alter table public.vendor_profiles enable row level security;
create policy "staff read vp" on public.vendor_profiles for select to authenticated using (public.is_staff(auth.uid()));
create policy "purchase update vp" on public.vendor_profiles for update to authenticated using (public.has_role(auth.uid(),'PURCHASE_USER') or public.has_role(auth.uid(),'ADMIN'));

create table public.vendor_documents (
  id uuid primary key default gen_random_uuid(),
  onboarding_id uuid not null references public.vendor_onboardings(id) on delete cascade,
  category text not null check (category in ('incorp','bank_proof','gst_certs','msme_cert','iso_cert','tfa_evidence')),
  file_name text not null, file_url text not null, uploaded_by text not null,
  created_at timestamptz not null default now()
);
grant select, insert on public.vendor_documents to authenticated;
grant all on public.vendor_documents to service_role;
alter table public.vendor_documents enable row level security;
create policy "staff read docs" on public.vendor_documents for select to authenticated using (public.is_staff(auth.uid()));
create policy "finance insert docs" on public.vendor_documents for insert to authenticated with check (public.has_role(auth.uid(),'FINANCE_CONTROLLER') or public.has_role(auth.uid(),'ADMIN'));

create table public.internal_reviews (
  id uuid primary key default gen_random_uuid(),
  onboarding_id uuid not null unique references public.vendor_onboardings(id) on delete cascade,
  prepare_status text, prepare_notes text, prepared_by_user_id uuid, prepare_date timestamptz,
  tfa_status text not null default 'Not Started', tfa_notes text, tfa_verified_by_user_id uuid,
  purchase_head_status text, purchase_head_comments text, purchase_head_user_id uuid, purchase_head_date timestamptz,
  controller_status text, controller_comments text, controller_user_id uuid, controller_date timestamptz
);
grant select, insert, update on public.internal_reviews to authenticated;
grant all on public.internal_reviews to service_role;
alter table public.internal_reviews enable row level security;
create policy "staff read reviews" on public.internal_reviews for select to authenticated using (public.is_staff(auth.uid()));
create policy "staff insert reviews" on public.internal_reviews for insert to authenticated with check (public.is_staff(auth.uid()));
create policy "staff update reviews" on public.internal_reviews for update to authenticated using (public.is_staff(auth.uid()));

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  onboarding_id uuid references public.vendor_onboardings(id) on delete set null,
  actor_identifier text not null, action text not null,
  field_changed text, old_value text, new_value text,
  timestamp timestamptz not null default now()
);
grant select, insert on public.audit_logs to authenticated;
grant all on public.audit_logs to service_role;
alter table public.audit_logs enable row level security;
create policy "staff read audit" on public.audit_logs for select to authenticated using (public.is_staff(auth.uid()));
create policy "staff insert audit" on public.audit_logs for insert to authenticated with check (public.is_staff(auth.uid()));

create or replace function public.next_temp_code(_user_id uuid)
returns text language plpgsql stable security definer set search_path = public as $$
declare prefix text; ini text; n int;
begin
  select upper(rpad(substr(regexp_replace(coalesce(nullif(full_name,''), email),'[^A-Za-z]','','g'),1,3),3,'X')) into ini from public.profiles where id = _user_id;
  prefix := upper(to_char(now(),'MON')) || ini;
  select count(*) + 1 into n from public.vendor_onboardings where temp_vendor_code like prefix || '%';
  return prefix || lpad(n::text, 2, '0');
end $$;
grant execute on function public.next_temp_code(uuid) to authenticated;

create policy "staff read vendor docs" on storage.objects for select to authenticated using (bucket_id = 'vendor-docs' and public.is_staff(auth.uid()));
create policy "staff upload vendor docs" on storage.objects for insert to authenticated with check (bucket_id = 'vendor-docs' and public.is_staff(auth.uid()));
