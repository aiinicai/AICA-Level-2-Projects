## Overview
Significant restructure of the transaction workflow to support multiple resolutions per meeting, draft-then-lock workflow, and richer document generation. All work is frontend (localStorage-backed) — no backend changes.

## 1. Data Model (`src/lib/types.ts`)
- Extend `ResolutionItem` to include all per-purpose detail fields (currently on `TransactionInput`) and a `meetingType: "BOARD" | "GENERAL"` flag.
- Move shared inputs (company, dates, venues, signatories) to remain on `TransactionInput`; per-resolution data moves under each resolution.
- Add `numberOfResolutions: number` to drive dynamic resolution forms.
- Add `boardVenueType` / `gmVenueType: "REGISTERED_OFFICE" | "OTHER"`.
- Add `shorterNoticeDate`, `shorterNoticePlace` on `TransactionInput`.
- Add `filings: { srn: string; date: string }[]` (multi-SRN).
- Add `status: "DRAFT" | "LOCKED"` on `MeetingRecord`; drafts stored separately or via status flag.

## 2. Transaction Sheet UI (`src/routes/transactions.tsx`)
- Move "Number of Resolutions" selector into the General Information card.
- Render N resolution blocks; each has: Purpose dropdown, Meeting Type (Board/General) toggle, and conditional detail sub-form (director / capital / rights / placement / resignation fields) based on its purpose.
- Venue fields become Select: "Registered Office" auto-fills from company master; "Other" reveals free-text input.
- Add Shorter Notice date + place fields when shorter notice toggled.
- Add multi-row "ROC Filings" section: list of `{srn, date}` with add/remove.
- Two primary actions:
  - **Save as Draft** → writes to drafts store (no docx generated, or generates preview).
  - **Generate Document** → builds docx (current behavior, but no register write yet).
  - **Lock & File** → prompts "Lock data?", on Yes writes to Meeting Register with `LOCKED` status and SRN/date metadata; subsequent edits disabled.

## 3. Drafts Menu (new `src/routes/drafts.tsx`)
- List saved drafts per company; each row has Edit (loads into Transaction Sheet via router state / localStorage handoff) and Re-Print actions.
- Sidebar entry "Drafts".

## 4. Meeting Register (`src/routes/meetings.tsx`)
- Add company filter dropdown — show meetings for selected company only.
- Add Re-Print action per meeting; reprints inject SRN + filing date as a header/footer stamp on every page of the regenerated docx.
- Show SRN and filing date columns.

## 5. Document Generator (`src/lib/document-generator.ts`)
- Iterate over all resolutions, splitting into board-meeting block vs general-meeting block based on each resolution's `meetingType`.
- Auto-add "Calling of GM" board resolution only when at least one resolution is marked GENERAL.
- **Signatures**: drop title prefix (Mr./Mrs./Ms.) from authorised signatory; print `Name` / `Director` / `DIN: xxxxx` on three separate lines.
- **Shorter Notice Consent**: pull shareholder list from `shareholders` master filtered by company — print Name, Folio No., No. of Shares as a table; include date + place from input.
- **Explanatory Statement (§102)**: expand to full statutory format per Companies Act 2013 + Rules — nature of concern/interest of directors/KMP/relatives, financial effect, material facts, documents open for inspection, etc., tailored per purpose.
- **Resignation Letter**: add a new section when purpose is "Resignation of Director" or "Resignation of Auditor" — drafts a full resignation letter on the resigning person's behalf.
- **Re-print with SRN stamp**: add `generateAllInOne(..., { srns, filingDates })` option; when provided, add a header on every page showing "Filed vide SRN: X on DD-MM-YYYY".

## 6. Store (`src/lib/store.ts`)
- Add `drafts: TransactionInput[]` slice with save/update/delete/load actions.
- Add `lockMeeting(id)` to flip status and move from drafts → register.

## 7. Sidebar (`src/components/app-sidebar.tsx`)
- Add "Drafts" entry between Transactions and Meeting Register.

## Technical Notes
- Migration: existing `TransactionInput` field reads continue to work — old fields stay on the type as optional and are mirrored into resolution[0] when loading legacy data, so saved drafts and code paths don't break.
- Re-print stamp implemented via `docx` `Header` on each section.
- Edit-from-draft uses `sessionStorage` handoff key `lex.draft.load` consumed by transactions route on mount.

## Out of Scope
- No backend / auth.
- No PDF export (still .docx).
- Compliance Calendar unchanged.