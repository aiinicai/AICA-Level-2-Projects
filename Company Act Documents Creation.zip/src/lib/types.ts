export const TITLE_OPTIONS = ["Mr.", "Ms.", "Mrs.", "M/s"] as const;
export type Title = (typeof TITLE_OPTIONS)[number] | "";

export interface Company {
  id: string;
  name: string;
  cin: string;
  registeredOffice: string;
  email: string;
  phone: string;
  authorisedCapital: string;
  paidUpCapital: string;
  dateOfIncorporation: string;
  financialYear: string;
  rocJurisdiction: string;
  pan: string;
  gstin: string;
  csName: string;
  csMembershipNo: string;
  auditorName: string;
  auditorFirmRegNo: string;
  auditorId?: string;
}

export type DirectorCategory = "Executive" | "Non-Executive" | "Independent";

export interface Director {
  id: string;
  companyId: string;
  title: Title;
  name: string;
  din: string;
  pan: string;
  address: string;
  email: string;
  mobile: string;
  dateOfAppointment: string;
  category: DirectorCategory;
  designation?: string; // e.g. Director / Managing Director
  dscAvailable: boolean;
}

export interface Shareholder {
  id: string;
  companyId: string;
  title: Title;
  name: string;
  pan: string;
  address: string;
  email: string;
  shares: number;
  shareClass: string;
  folioNo: string;
  percentage: number;
}

export interface Auditor {
  id: string;
  companyId?: string; // legacy — auditor master is now global
  firmName: string;
  frn: string;
  authorizedPersonName: string;
  designation: string; // Partner / Proprietor
  membershipNo: string;
  email: string;
  address: string;
  phone: string;
  place: string;
}

export const PURPOSE_GROUPS = {
  Directors: [
    "Appointment of Additional Director",
    "Appointment of Director",
    "Appointment of Managing Director",
    "Appointment of Whole Time Director",
    "Appointment of Independent Director",
    "Resignation of Director",
    "Change in Designation",
    "Removal of Director",
  ],
  "Share Capital": [
    "Increase in Authorised Share Capital",
    "Reclassification of Capital",
    "Issue of Equity Shares",
    "Issue of Preference Shares",
    "Rights Issue",
    "Bonus Issue",
    "Private Placement",
    "Preferential Allotment",
    "ESOP",
    "Sweat Equity",
  ],
  "Corporate Actions": [
    "Opening Bank Account",
    "Borrowing Powers",
    "Creation of Charge",
    "Change in Registered Office",
    "Change in Name",
    "Adoption of Accounts",
    "Appointment of Auditor",
    "Resignation of Auditor",
    "Related Party Transaction",
    "Loan under Section 186",
    "Investment under Section 186",
  ],
  "Normal Business": [
    "Adoption of Financial Statements",
    "Declaration of Dividend",
    "Appointment of Director in place of Retiring Director",
    "Re-appointment of Retiring Auditor",
    "Ratification of Appointment of Auditor",
    "Consideration of Directors' Report and Auditors' Report",
  ],

} as const;

export type Purpose =
  (typeof PURPOSE_GROUPS)[keyof typeof PURPOSE_GROUPS][number];

export type MeetingTypeRef = "BOARD" | "GENERAL";
export type VenueType = "REGISTERED_OFFICE" | "OTHER";

export interface ResolutionItem {
  id: string;
  purpose: string;
  meetingType: MeetingTypeRef;
  details?: string;
  // Director
  directorTitle?: Title;
  directorName?: string;
  directorDIN?: string;
  directorPAN?: string;
  directorAddress?: string;
  directorEmail?: string;
  directorMobile?: string;
  directorCategory?: DirectorCategory;
  designation?: string;
  appointmentDate?: string;
  termsOfAppointment?: string;
  remuneration?: string;
  resignationDate?: string;
  resignationReason?: string;
  // DIR-2 (consent) — per MCA Form DIR-2
  dir2FathersName?: string;
  dir2Occupation?: string;
  dir2OccupationCategory?: string; // legacy
  dir2AreasOfInterest?: string; // legacy
  dir2EduQualification?: string; // legacy
  dir2DOB?: string; // date
  dir2Nationality?: string;
  dir2OtherDirectorshipsCount?: string;
  dir2KmpCompanies?: string; // names of companies where MD/CEO/WTD/Secretary/CFO/Manager
  dir2MembershipDetails?: string; // Membership No. & COP, or NIL
  dir2SecurityClearance?: "not_required" | "obtained";
  dir2Designation?: string;
  dir2Place?: string;
  dir2Date?: string;
  // DIR-8 (declaration) — per MCA Form DIR-8
  dir8Relation?: "son" | "daughter" | "wife"; // son/daughter/wife of
  dir8RelationName?: string; // father's/husband's name
  dir8Capacity?: "director" | "managing director" | "manager";
  dir8PastDirectorships?: string; // one per line: "Company | dd-mm-yyyy | dd-mm-yyyy"
  dir8Disqualified?: boolean;
  dir8DisqualifiedCompanies?: string; // same format as above
  dir8DisqualificationGround?: string; // 164(1) ground text
  dir8Place?: string;
  dir8Date?: string;
  // Auditor
  auditorId?: string;
  auditorFirmName?: string;
  auditorFirmRegNo?: string;
  auditorAuthorizedPerson?: string;
  auditorMembershipNo?: string;
  // Change in Registered Office
  newRegisteredOffice?: string;
  newRegOfficeChangeRoc?: boolean;
  // Opening Bank Account
  bankName?: string;
  bankBranch?: string;
  bankAccountType?: string;
  // Capital
  existingAuthCapital?: string;
  existingShares?: string;
  newAuthCapital?: string;
  newShares?: string;
  shareType?: string;
  moaAlteration?: boolean;
  // Issue
  numberOfShares?: string;
  faceValue?: string;
  premium?: string;
  issuePrice?: string;
  recordDate?: string;
  offerOpenDate?: string;
  offerCloseDate?: string;
  renunciation?: boolean;
  pas4Date?: string;
  pas5Date?: string;
  allotmentDate?: string;
  investorList?: string;
}

export interface FilingRecord {
  id: string;
  srn: string;
  date: string;
  form?: string;
}

export interface TransactionInput {
  id?: string;
  companyId: string;
  resolutions: ResolutionItem[];
  boardVenueType: VenueType;
  boardMeetingDate: string;
  boardMeetingTime: string;
  boardMeetingVenue: string;
  generalMeetingType: "EGM" | "AGM" | "";
  gmVenueType: VenueType;
  generalMeetingDate: string;
  generalMeetingTime: string;
  generalMeetingVenue: string;
  noticeIssueDate?: string;
  effectiveDate: string;
  authorisedSignatory: string;
  rocFilingPerson: string;
  rocFilingPersonDesignation?: string;
  shorterNotice?: boolean;
  shorterNoticeDate?: string;
  shorterNoticePlace?: string;
  filings: FilingRecord[];
  // legacy compat (older drafts)
  purpose?: string;
  srn?: string;
  additionalResolutions?: ResolutionItem[];
  directorTitle?: Title;
}

export interface DraftRecord {
  id: string;
  companyId: string;
  companyName: string;
  title: string;
  savedAt: string;
  input: TransactionInput;
}

export interface MeetingRecord {
  id: string;
  companyId: string;
  companyName: string;
  type: "Board" | "EGM" | "AGM";
  date: string;
  time: string;
  venue: string;
  agenda: string[];
  shorterNotice?: boolean;
  status: "DRAFT" | "LOCKED";
  filings?: FilingRecord[];
  input?: TransactionInput;
  createdAt: string;
}

export const DIRECTOR_RESIGNATION_REASON =
  "due to personal and unavoidable circumstances";
export const AUDITOR_RESIGNATION_REASON =
  "due to pre-occupation in other assignments, we are not in a position to devote time to the affairs of the Company";
