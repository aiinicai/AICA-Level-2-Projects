import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  LevelFormat,
  BorderStyle,
  PageOrientation,
  PageBreak,
  Table,
  TableRow,
  TableCell,
  WidthType,
  ShadingType,
  Header,
} from "docx";
import type {
  Company,
  Director,
  Shareholder,
  Auditor,
  TransactionInput,
  ResolutionItem,
  MeetingRecord,
  FilingRecord,
} from "./types";
import {
  DIRECTOR_RESIGNATION_REASON,
  AUDITOR_RESIGNATION_REASON,
} from "./types";
import { getRocMapping } from "./roc-mapping";
import { store, uid } from "./store";

const FONT = "Times New Roman";

async function downloadDocx(blob: Blob, filename: string) {
  if (typeof window === "undefined") return;
  const fileSaver = await import("file-saver");
  const saveAs = (fileSaver.default ?? (fileSaver as unknown as { saveAs?: unknown }).saveAs ?? fileSaver) as (
    data: Blob,
    filename: string,
  ) => void;
  saveAs(blob, filename);
}

// ---------- formatting helpers ----------

function ordinal(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

function fmtDate(d: string) {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return d;
  const day = ordinal(dt.getDate());
  const month = dt.toLocaleString("en-IN", { month: "long" });
  return `${day} ${month}, ${dt.getFullYear()}`;
}

function dayOfWeek(d: string) {
  if (!d) return "—";
  try {
    return new Date(d).toLocaleDateString("en-IN", { weekday: "long" });
  } catch {
    return "—";
  }
}

function fmtTime(t: string) {
  if (!t) return "—";
  const m = t.match(/^(\d{1,2}):(\d{2})/);
  if (!m) return t;
  const h = parseInt(m[1], 10);
  const min = m[2];
  const period = h >= 12 ? "PM" : "AM";
  const hh = ((h + 11) % 12) + 1;
  return `${hh}:${min} ${period}`;
}

// strip Mr./Ms./Mrs./M/s prefixes from a name
function stripTitle(name?: string) {
  if (!name) return "";
  return name.replace(/^\s*(Mr\.?|Ms\.?|Mrs\.?|M\/s\.?)\s+/i, "").trim();
}

function p(text: string, opts: { bold?: boolean; center?: boolean; size?: number; underline?: boolean; right?: boolean } = {}) {
  return new Paragraph({
    alignment: opts.right ? AlignmentType.RIGHT : opts.center ? AlignmentType.CENTER : AlignmentType.JUSTIFIED,
    spacing: { after: 120 },
    children: [
      new TextRun({
        text,
        bold: opts.bold,
        size: opts.size ?? 22,
        font: FONT,
        underline: opts.underline ? {} : undefined,
      }),
    ],
  });
}

function heading(text: string) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 200, after: 200 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT, underline: {} })],
  });
}

function spacer() {
  return new Paragraph({ children: [new TextRun({ text: "", font: FONT })] });
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

function companyHeader(c: Company) {
  const contact = [c.email && `Email: ${c.email}`, c.phone && `Phone: ${c.phone}`].filter(Boolean).join("   |   ");
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: c.name.toUpperCase(), bold: true, size: 32, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `CIN: ${c.cin || "—"}`, size: 20, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `Regd. Office: ${c.registeredOffice || "—"}`, size: 20, font: FONT })],
    }),
    ...(contact
      ? [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
            children: [new TextRun({ text: contact, size: 20, font: FONT })],
          }),
        ]
      : []),
    new Paragraph({
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "1e3a5f", space: 1 } },
      children: [new TextRun({ text: "", font: FONT })],
    }),
    spacer(),
  ];
}

// Auditor letterhead with simple "CA" logo mark (text-based)
function auditorLetterhead(a: Auditor) {
  const logo = new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({ text: "❖ CA ❖", bold: true, size: 36, font: FONT, color: "1e3a5f" }),
    ],
  });
  const contact = [a.email && `Email: ${a.email}`, a.phone && `Phone: ${a.phone}`].filter(Boolean).join("   |   ");
  return [
    logo,
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: a.firmName.toUpperCase(), bold: true, size: 30, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "Chartered Accountants", italics: true, size: 22, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `FRN: ${a.frn || "—"}`, size: 20, font: FONT })],
    }),
    ...(a.address
      ? [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: a.address, size: 20, font: FONT })] })]
      : []),
    ...(contact
      ? [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: contact, size: 20, font: FONT })] })]
      : []),
    new Paragraph({
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "1e3a5f", space: 1 } },
      children: [new TextRun({ text: "", font: FONT })],
    }),
    spacer(),
  ];
}

function auditorSignBlock(a: Auditor, dateStr: string) {
  return [
    spacer(), spacer(),
    p(`For ${a.firmName}`),
    p("Chartered Accountants"),
    p(`FRN: ${a.frn || "—"}`),
    spacer(), spacer(), spacer(),
    p(`(${a.authorizedPersonName || "—"})`),
    p(a.designation || "Partner"),
    p(`M. No. ${a.membershipNo || "—"}`),
    spacer(),
    p(`Place: ${a.place || "—"}`),
    p(`Date: ${fmtDate(dateStr)}`),
  ];
}

function bulletList(items: string[]) {
  return items.map(
    (t) =>
      new Paragraph({
        numbering: { reference: "agenda-list", level: 0 },
        children: [new TextRun({ text: t, size: 22, font: FONT })],
      }),
  );
}

// ---- Resolution accessors with legacy fallback ----

function migrateLegacy(t: TransactionInput): TransactionInput {
  if (t.resolutions && t.resolutions.length > 0) return t;
  const main: ResolutionItem = {
    id: "main",
    purpose: t.purpose || "",
    meetingType: "BOARD",
  };
  return { ...t, resolutions: [main, ...(t.additionalResolutions || [])] };
}

function allResolutions(t: TransactionInput): ResolutionItem[] {
  const mt = migrateLegacy(t);
  return mt.resolutions || [];
}

function boardResolutions(t: TransactionInput): ResolutionItem[] {
  return allResolutions(t).filter((r) => r.meetingType === "BOARD");
}

function gmResolutions(t: TransactionInput): ResolutionItem[] {
  return allResolutions(t).filter((r) => r.meetingType === "GENERAL");
}

function primaryPurpose(t: TransactionInput): string {
  return allResolutions(t)[0]?.purpose || t.purpose || "";
}

function boardVenue(c: Company, t: TransactionInput) {
  if (t.boardVenueType === "OTHER") return t.boardMeetingVenue || c.registeredOffice || "—";
  return c.registeredOffice || t.boardMeetingVenue || "—";
}
function gmVenue(c: Company, t: TransactionInput) {
  if (t.gmVenueType === "OTHER") return t.generalMeetingVenue || c.registeredOffice || "—";
  return c.registeredOffice || t.generalMeetingVenue || "—";
}

// ---- Signature ----

function signer(c: Company, t: TransactionInput, directors: Director[]) {
  const compDirs = directors.filter((d) => d.companyId === c.id);
  const sigName = stripTitle(t.authorisedSignatory || "").toLowerCase();
  const matched =
    (sigName && compDirs.find((d) => stripTitle(d.name).toLowerCase() === sigName)) ||
    compDirs[0];
  return {
    name: stripTitle(matched?.name || t.authorisedSignatory) || "[Director Name]",
    din: matched?.din || "[DIN]",
    designation: matched?.designation && !/^executive$/i.test(matched.designation) ? matched.designation : "Director",
  };
}

function rocPersonLine(t: TransactionInput) {
  const name = stripTitle(t.rocFilingPerson) || "[Authorised Person]";
  const desig = t.rocFilingPersonDesignation || "Director";
  return `${name}, ${desig}`;
}

function signatureBlock(c: Company, t: TransactionInput, directors: Director[], opts: { center?: boolean } = {}) {
  const s = signer(c, t, directors);
  return [
    spacer(), spacer(),
    p("For " + c.name, { center: opts.center }),
    spacer(), spacer(),
    p("__________________________", { center: opts.center }),
    p(s.name, { bold: true, center: opts.center }),
    p(s.designation, { center: opts.center }),
    p(`DIN: ${s.din}`, { center: opts.center }),
  ];
}

// ---------- Resolution bodies (per-item) ----------

function resolutionBodyFor(item: ResolutionItem, t: TransactionInput, c: Company): Paragraph[] {
  const purpose = item.purpose;
  const dirName = stripTitle(item.directorName) || "[Director Name]";
  const out: Paragraph[] = [];
  const roc = rocPersonLine(t);
  const resignReason = item.resignationReason && item.resignationReason.trim().length > 0
    ? item.resignationReason
    : purpose === "Resignation of Auditor" ? AUDITOR_RESIGNATION_REASON : DIRECTOR_RESIGNATION_REASON;

  if (purpose.startsWith("Appointment of")) {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Sections 149, 152, 161 and other applicable provisions of the Companies Act, 2013 read with the Companies (Appointment and Qualification of Directors) Rules, 2014 and the Articles of Association of the Company, ${dirName} (DIN: ${item.directorDIN || "[DIN]"}, PAN: ${item.directorPAN || "[PAN]"}), who has submitted his consent in Form DIR-2 and declaration in Form DIR-8 confirming that he is not disqualified to act as a Director under Section 164(2) of the Companies Act, 2013, be and is hereby appointed as ${item.designation || purpose.replace("Appointment of ", "")} of the Company with effect from ${fmtDate(item.appointmentDate || t.effectiveDate)} on the terms and conditions${item.termsOfAppointment ? `: ${item.termsOfAppointment}` : " as may be determined by the Board"}${item.remuneration ? `, on a remuneration of ${item.remuneration}` : ""}.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${roc} of the Company be and is hereby severally authorised to file Form DIR-12 and other necessary returns/forms with the Registrar of Companies and to do all such acts, deeds and things as may be necessary to give effect to the above resolution."`,
      ),
    );
  } else if (purpose === "Resignation of Director" || purpose === "Removal of Director") {
    out.push(
      p(
        `"RESOLVED THAT the resignation tendered by ${dirName} (DIN: ${item.directorDIN || "[DIN]"}) from the office of Director of the Company with effect from the close of business hours on ${fmtDate(item.resignationDate || t.effectiveDate)}, ${resignReason}, be and is hereby accepted, and the Board places on record its appreciation for the valuable services rendered by him during his tenure as a Director of the Company.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${roc} of the Company be and is hereby authorised to file Form DIR-12 with the Registrar of Companies and to take all such steps as may be necessary to give effect to this resolution."`,
      ),
    );
  } else if (purpose === "Resignation of Auditor") {
    out.push(
      p(
        `"RESOLVED THAT the resignation letter dated ${fmtDate(item.resignationDate || t.effectiveDate)} tendered by M/s ${item.auditorFirmName || c.auditorName || "[Auditor Firm]"} (Firm Reg. No.: ${item.auditorFirmRegNo || c.auditorFirmRegNo || "[FRN]"}), Statutory Auditors of the Company, ${resignReason}, be and is hereby taken on record, and the resulting casual vacancy under Section 139(8) of the Companies Act, 2013 shall be filled at the ensuing General Meeting.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${roc} be and is hereby authorised to take note of Form ADT-3 filed by the resigning auditor, to file the necessary intimations with the Registrar of Companies, and to take all consequential actions to give effect to this resolution."`,
      ),
    );
  } else if (purpose === "Increase in Authorised Share Capital") {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Sections 13, 61 and 64 and other applicable provisions of the Companies Act, 2013 read with the rules made thereunder, and subject to the approval of the Members of the Company, the Authorised Share Capital of the Company be and is hereby increased from ₹${item.existingAuthCapital || "[Existing]"} divided into ${item.existingShares || "[N]"} ${item.shareType || "Equity"} Shares of ₹${item.faceValue || "10"} each to ₹${item.newAuthCapital || "[New]"} divided into ${item.newShares || "[N]"} ${item.shareType || "Equity"} Shares of ₹${item.faceValue || "10"} each, ranking pari-passu in all respects with the existing shares of the Company.`,
      ),
      p(
        `RESOLVED FURTHER THAT Clause V of the Memorandum of Association of the Company be substituted accordingly, and ${roc} of the Company be and is hereby authorised to file Form SH-7 and Form MGT-14 with the Registrar of Companies within the prescribed time."`,
      ),
    );
  } else if (purpose === "Rights Issue") {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Section 62(1)(a) of the Companies Act, 2013 read with the Companies (Share Capital and Debentures) Rules, 2014, consent of the Board be and is hereby accorded to offer, issue and allot ${item.numberOfShares || "[N]"} Equity Shares of face value ₹${item.faceValue || "10"} each at a premium of ₹${item.premium || "0"} per share to the existing Equity Shareholders on rights basis, as on the record date ${fmtDate(item.recordDate || "")}, in the proportion of their existing shareholding.`,
      ),
      p(
        `RESOLVED FURTHER THAT the offer shall remain open from ${fmtDate(item.offerOpenDate || "")} to ${fmtDate(item.offerCloseDate || "")} and ${item.renunciation ? "renunciation by the shareholders shall be permitted" : "renunciation shall not be permitted"}, and ${roc} be and is hereby authorised to issue the Letter of Offer, complete the allotment and file Form PAS-3 with the Registrar of Companies within the prescribed time."`,
      ),
    );
  } else if (purpose === "Private Placement" || purpose === "Preferential Allotment") {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Sections 42 and 62(1)(c) read with the Companies (Prospectus and Allotment of Securities) Rules, 2014 and the Companies (Share Capital and Debentures) Rules, 2014, and subject to the approval of the Members by way of Special Resolution, consent be and is hereby accorded to offer, issue and allot up to ${item.numberOfShares || "[N]"} Equity Shares of face value ₹${item.faceValue || "10"} each at an issue price of ₹${item.issuePrice || "[Price]"} per share (including premium of ₹${item.premium || "0"}) on a ${purpose === "Private Placement" ? "private placement" : "preferential allotment"} basis to the identified investors.`,
      ),
      p(
        `RESOLVED FURTHER THAT the Private Placement Offer Letter in Form PAS-4 be circulated to the identified investors and ${roc} be and is hereby authorised to file Form PAS-3 within fifteen (15) days of allotment and to take all such steps as may be necessary."`,
      ),
    );
  } else if (purpose === "Appointment of Auditor") {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Sections 139, 141, 142 and other applicable provisions of the Companies Act, 2013 read with the Companies (Audit and Auditors) Rules, 2014, M/s ${item.auditorFirmName || c.auditorName || "[Auditor Firm]"} (FRN: ${item.auditorFirmRegNo || c.auditorFirmRegNo || "[FRN]"}), Chartered Accountants, be and are hereby appointed as the Statutory Auditors of the Company to hold office from the conclusion of this Meeting until the conclusion of the next Annual General Meeting, on such remuneration as may be mutually agreed between the Board and the Auditors.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${roc} be and is hereby authorised to file Form ADT-1 with the Registrar of Companies within fifteen (15) days of this appointment."`,
      ),
    );
  } else if (purpose === "Opening Bank Account") {
    const acctType = item.bankAccountType || "Current Account";
    const bn = item.bankName || "[Bank Name]";
    const br = item.bankBranch || "[Branch]";
    out.push(
      p(
        `"RESOLVED THAT a ${acctType} be opened in the name of the Company with ${bn}, ${br} Branch, and that the said account be operated by ${stripTitle(t.authorisedSignatory) || "[Authorised Signatory]"} on behalf of the Company.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${bn}, ${br} Branch, be and is hereby authorised to honour all cheques, drafts, bills of exchange, promissory notes and other instruments drawn, accepted or made on behalf of the Company by the said authorised signatory, and to act on any instructions so given relating to the said account, whether the same be in credit or overdrawn.`,
      ),
      p(
        `RESOLVED FURTHER THAT a certified true copy of this resolution be furnished to ${bn}, ${br} Branch, for their records and necessary action."`,
      ),
    );

  } else if (purpose === "Change in Registered Office") {
    out.push(
      p(
        `"RESOLVED THAT pursuant to the provisions of Section 12 and Section 13 (where applicable) of the Companies Act, 2013 read with the Companies (Incorporation) Rules, 2014, the Registered Office of the Company be shifted from "${c.registeredOffice || "[Existing Address]"}" to "${item.newRegisteredOffice || "[New Address]"}" with effect from ${fmtDate(t.effectiveDate)}.`,
      ),
      p(
        `RESOLVED FURTHER THAT ${roc} of the Company be and is hereby authorised to file Form INC-22${item.newRegOfficeChangeRoc ? " and Form INC-23/INC-28 (as applicable for change of ROC jurisdiction)" : ""} and other necessary forms with the Registrar of Companies within thirty (30) days of such change, and to do all such acts, deeds and things as may be necessary to give effect to this resolution."`,
      ),
    );
  } else if (purpose === "Change in Name") {
    out.push(
      p(
        `"RESOLVED THAT subject to the approval of the Central Government / Registrar of Companies and the Members of the Company by way of Special Resolution, the name of the Company be changed and Clause I of the Memorandum of Association be altered accordingly, and ${roc} of the Company be and is hereby authorised to file Form INC-24 and other necessary forms with the Registrar of Companies."`,
      ),
    );
  } else if (purpose === "Borrowing Powers") {
    out.push(
      p(
        `"RESOLVED THAT subject to the provisions of Section 180(1)(c) and other applicable provisions of the Companies Act, 2013, consent of the Members be and is hereby accorded to the Board of Directors of the Company to borrow money from time to time, provided that the total amount of borrowings shall not exceed ₹ ${item.details || "[Limit]"}, and ${roc} of the Company be and is hereby authorised to file Form MGT-14 with the Registrar of Companies."`,
      ),
    );
  } else {
    out.push(
      p(
        `"RESOLVED THAT consent of the ${item.meetingType === "GENERAL" ? "Members" : "Board"} be and is hereby accorded for ${purpose}${item.details ? ` as per the following terms: ${item.details}` : ""} with effect from ${fmtDate(t.effectiveDate)}, and ${roc} of the Company be and is hereby authorised to do all such acts, deeds and things and to file all necessary forms and returns with the Registrar of Companies as may be required to give effect to this resolution."`,
      ),
    );
  }
  return out;
}

function resolutionBlock(items: ResolutionItem[], t: TransactionInput, c: Company, opts: { recommendation?: boolean } = {}): Paragraph[] {
  const out: Paragraph[] = [];
  items.forEach((item, idx) => {
    const label = opts.recommendation
      ? `Item ${idx + 1}: Recommendation for Members' Approval — ${item.purpose.toUpperCase()}`
      : `Item ${idx + 1}: ${item.purpose.toUpperCase()}`;
    out.push(p(label, { bold: true, underline: true }));
    if (opts.recommendation) {
      out.push(p(`The Board considered the proposal in respect of ${item.purpose} and resolved as under:`));
    }
    out.push(...resolutionBodyFor(item, t, c));
    out.push(spacer());
  });
  return out;
}

// ---- Sections ----

const SHARE_ISSUE_PURPOSES = new Set([
  "Issue of Equity Shares",
  "Issue of Preference Shares",
  "Rights Issue",
  "Bonus Issue",
  "Private Placement",
  "Preferential Allotment",
]);

function sectionSummary(c: Company, t: TransactionInput) {
  const items = allResolutions(t);
  const bm = boardResolutions(t);
  const gm = gmResolutions(t);
  const isGM = !!t.generalMeetingDate || gm.length > 0;
  const bmDate = t.boardMeetingDate;
  const bmNoticeDate = (t as unknown as { boardNoticeDate?: string }).boardNoticeDate || bmDate;
  const gmDate = t.generalMeetingDate;
  const gmNoticeDate = t.noticeIssueDate || bmDate;
  const purposesText = items.map((r) => r.purpose).join(", ") || "the business set out in the agenda";
  const gmPurposesText = gm.map((r) => r.purpose).join(", ") || purposesText;
  const gmLabel = t.generalMeetingType === "AGM" ? "Annual General Meeting" : "Extra Ordinary General Meeting";
  const gmShort = t.generalMeetingType || "EGM";

  const rows: { p: string; date: string; day: string; agenda: string }[] = [];

  if (bmDate || bm.length > 0 || isGM) {
    rows.push({
      p: "Notice of Board Meeting",
      date: fmtDate(bmNoticeDate),
      day: dayOfWeek(bmNoticeDate),
      agenda: `To hold Board Meeting for ${isGM ? `recommendation to members for ${gmPurposesText}` : purposesText}`,
    });
    rows.push({
      p: "Board Meeting",
      date: fmtDate(bmDate),
      day: dayOfWeek(bmDate),
      agenda: isGM
        ? `Recommendation to Members for ${gmPurposesText} and Resolution to call the General Meeting and authorize issue of Notice`
        : `To consider and approve: ${purposesText}`,
    });
  }

  if (isGM) {
    rows.push({
      p: `Notice of ${gmLabel}`,
      date: fmtDate(gmNoticeDate),
      day: dayOfWeek(gmNoticeDate),
      agenda: `To hold ${gmShort} for ${gmPurposesText}`,
    });
    if (t.shorterNotice) {
      const sn = t.shorterNoticeDate || gmNoticeDate;
      rows.push({
        p: "Consent for Shorter Notice",
        date: fmtDate(sn),
        day: dayOfWeek(sn),
        agenda: `Consent for holding the ${gmLabel} at Shorter Notice`,
      });
    }
  }

  const dirAppts = items.filter((r) => r.purpose.startsWith("Appointment of") && r.purpose !== "Appointment of Auditor");
  dirAppts.forEach((r) => {
    const nm = r.directorName || "Director";
    rows.push({ p: `Form DIR-2 - (${nm})`, date: fmtDate(bmDate), day: dayOfWeek(bmDate), agenda: "Consent to act as Director" });
    rows.push({ p: `Form DIR-8 - (${nm})`, date: fmtDate(bmDate), day: dayOfWeek(bmDate), agenda: "Intimation by Director" });
  });

  items.filter((r) => SHARE_ISSUE_PURPOSES.has(r.purpose)).forEach((r) => {
    const d = gmDate || bmDate;
    rows.push({ p: `Offer Letter (PAS-4) - ${r.purpose}`, date: fmtDate(d), day: dayOfWeek(d), agenda: `Offer of securities pursuant to ${r.purpose}` });
  });

  items.filter((r) => r.purpose === "Resignation of Director").forEach((r) => {
    rows.push({ p: `Resignation Letter - (${r.directorName || "Director"})`, date: fmtDate(bmDate), day: dayOfWeek(bmDate), agenda: "Resignation from directorship" });
  });
  items.filter((r) => r.purpose === "Resignation of Auditor").forEach(() => {
    rows.push({ p: "Auditor Resignation Letter", date: fmtDate(bmDate), day: dayOfWeek(bmDate), agenda: "Resignation of Statutory Auditor" });
  });

  if (isGM) {
    rows.push({
      p: gmLabel,
      date: fmtDate(gmDate),
      day: dayOfWeek(gmDate),
      agenda: `${gmPurposesText} and Authorization for ROC filings and signing`,
    });
  }

  const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "1e3a5f" };
  const borders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder };
  const headers = ["Particulars", "Date", "Day", "Agenda"];
  const colWidths = [3000, 1600, 1300, 3460];
  const headRow = new TableRow({
    children: headers.map((h, i) =>
      new TableCell({
        borders,
        width: { size: colWidths[i], type: WidthType.DXA },
        shading: { fill: "1e3a5f", type: ShadingType.CLEAR, color: "auto" },
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT, size: 20 })] })],
      }),
    ),
  });
  const dataRows = rows.map((r) =>
    new TableRow({
      children: [r.p, r.date, r.day, r.agenda].map((v, i) =>
        new TableCell({
          borders,
          width: { size: colWidths[i], type: WidthType.DXA },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: v, size: 20, font: FONT })] })],
        }),
      ),
    }),
  );
  const table = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headRow, ...dataRows],
  });

  return [
    ...companyHeader(c),
    heading("MEETING SUMMARY & AGENDA"),
    p(`Generated on: ${fmtDate(new Date().toISOString())}`, { center: true }),
    spacer(),
    table,
    ...(t.shorterNotice
      ? [spacer(), p("Note: General Meeting convened at SHORTER NOTICE — consent of Members under Section 101 attached.", { bold: true })]
      : []),
  ];
}


function sectionBoardNotice(c: Company, t: TransactionInput, directors: Director[]) {
  const items = boardResolutions(t);
  const gm = gmResolutions(t);
  const agenda = [
    "Leave of absence, if any",
    "Confirmation of Minutes of the previous Board Meeting",
    ...items.map((r, i) => `To consider and approve Item ${i + 1}: ${r.purpose}`),
    ...gm.map((r, i) => `To consider, recommend and approve for placing before the Members at the General Meeting: ${r.purpose} (Item B-${i + 1})`),
    ...(gm.length > 0 || t.generalMeetingDate ? ["To approve calling of General Meeting and authorise the issue of Notice"] : []),
    "Any other matter with the permission of the Chair",
  ];
  return [
    ...companyHeader(c),
    heading("NOTICE OF BOARD MEETING"),
    p(`Date: ${fmtDate(new Date().toISOString())}`),
    p("To,"),
    p("All the Directors,"),
    p(c.name),
    spacer(),
    p("Dear Sir/Madam,"),
    p(
      `Notice is hereby given that a Meeting of the Board of Directors of ${c.name} will be held on ${fmtDate(t.boardMeetingDate)} (${dayOfWeek(t.boardMeetingDate)}) at ${fmtTime(t.boardMeetingTime)} at ${boardVenue(c, t)} to transact the following business:`,
    ),
    spacer(),
    p("Agenda", { bold: true, underline: true }),
    ...bulletList(agenda),
    spacer(),
    p("You are requested to make it convenient to attend the meeting."),
    p("By order of the Board"),
    ...signatureBlock(c, t, directors),
  ];
}

function sectionAgenda(c: Company, t: TransactionInput) {
  const items = boardResolutions(t);
  const gm = gmResolutions(t);
  return [
    ...companyHeader(c),
    heading("AGENDA — BOARD MEETING"),
    p(`Date: ${fmtDate(t.boardMeetingDate)} (${dayOfWeek(t.boardMeetingDate)})    Time: ${fmtTime(t.boardMeetingTime)}`),
    p(`Venue: ${boardVenue(c, t)}`),
    spacer(),
    ...bulletList([
      "Chairman to take the Chair",
      "Quorum confirmation",
      "Leave of absence",
      "Confirmation of previous Minutes",
      ...items.map((r, i) => `Item ${i + 1}: Discussion and approval of ${r.purpose}`),
      ...gm.map((r, i) => `Item B-${i + 1}: Recommendation to Members for ${r.purpose}`),
      ...(gm.length > 0 || t.generalMeetingDate ? ["Resolution to call the General Meeting and authorise issue of Notice"] : []),
      "Authorisation for ROC filings and signing",
      "Vote of thanks",
    ]),
  ];
}

function sectionAttendance(c: Company, t: TransactionInput, directors: Director[]) {
  const compDirs = directors.filter((d) => d.companyId === c.id);
  return [
    ...companyHeader(c),
    heading("ATTENDANCE SHEET — BOARD MEETING"),
    p(`Date: ${fmtDate(t.boardMeetingDate)}    Time: ${fmtTime(t.boardMeetingTime)}`),
    p(`Venue: ${boardVenue(c, t)}`),
    spacer(),
    ...compDirs.map(
      (d, i) =>
        new Paragraph({
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: `${i + 1}. ${stripTitle(d.name)} (DIN: ${d.din})    Signature: ______________________`,
              size: 22,
              font: FONT,
            }),
          ],
        }),
    ),
  ];
}

function gmCallResolution(c: Company, t: TransactionInput, idx: number): Paragraph[] {
  return [
    p(`Item ${idx}: Calling of ${t.generalMeetingType === "AGM" ? "Annual" : "Extra-Ordinary"} General Meeting`, { bold: true, underline: true }),
    p(
      `"RESOLVED THAT pursuant to Section 100 of the Companies Act, 2013, an ${t.generalMeetingType === "AGM" ? "Annual" : "Extra-Ordinary"} General Meeting of the Members of ${c.name} be convened on ${fmtDate(t.generalMeetingDate)} (${dayOfWeek(t.generalMeetingDate)}) at ${fmtTime(t.generalMeetingTime)} at ${gmVenue(c, t)} to transact the business set out in the Notice placed before the Board.`,
    ),
    p(
      `RESOLVED FURTHER THAT ${rocPersonLine(t)}, being the person authorised by the Board, be and is hereby authorised to issue the Notice of the said General Meeting along with the Explanatory Statement under Section 102, and to file the necessary forms and returns (including MGT-14, where applicable) with the Registrar of Companies."`,
    ),
    spacer(),
  ];
}

function sectionBoardResolution(c: Company, t: TransactionInput, directors: Director[]) {
  const items = boardResolutions(t);
  const gm = gmResolutions(t);
  const blocks: Paragraph[] = [];
  blocks.push(...resolutionBlock(items, t, c));
  if (gm.length > 0) {
    blocks.push(p("Recommendations to Members — Resolutions to be Placed before the General Meeting", { bold: true, underline: true, center: true }));
    blocks.push(...resolutionBlock(gm, t, c, { recommendation: true }));
  }
  if (gm.length > 0 || t.generalMeetingDate) blocks.push(...gmCallResolution(c, t, items.length + gm.length + 1));
  return [
    ...companyHeader(c),
    heading("EXTRACT OF THE MINUTES OF THE BOARD MEETING"),
    p(
      `Extract of the Minutes of the Meeting of the Board of Directors of ${c.name} held on ${fmtDate(t.boardMeetingDate)} (${dayOfWeek(t.boardMeetingDate)}) at ${fmtTime(t.boardMeetingTime)} at ${boardVenue(c, t)}.`,
    ),
    spacer(),
    ...blocks,
    p("Certified True Copy", { bold: true, center: true }),
    ...signatureBlock(c, t, directors, { center: true }),
  ];
}

function sectionCTC(c: Company, t: TransactionInput, directors: Director[]) {
  const items = boardResolutions(t);
  const gm = gmResolutions(t);
  const blocks: Paragraph[] = [];
  blocks.push(...resolutionBlock(items, t, c));
  if (gm.length > 0) blocks.push(...resolutionBlock(gm, t, c, { recommendation: true }));
  if (gm.length > 0 || t.generalMeetingDate) blocks.push(...gmCallResolution(c, t, items.length + gm.length + 1));
  return [
    ...companyHeader(c),
    heading("CERTIFIED TRUE COPY"),
    p(
      `Certified True Copy of the Resolutions passed at the Meeting of the Board of Directors of ${c.name} held on ${fmtDate(t.boardMeetingDate)} at ${fmtTime(t.boardMeetingTime)} at ${boardVenue(c, t)}.`,
    ),
    spacer(),
    ...blocks,
    ...signatureBlock(c, t, directors),
  ];
}

function sectionMinutes(c: Company, t: TransactionInput, directors: Director[]) {
  const compDirs = directors.filter((d) => d.companyId === c.id);
  const s = signer(c, t, directors);
  const items = boardResolutions(t);
  const gm = gmResolutions(t);
  const out: Paragraph[] = [
    ...companyHeader(c),
    heading("MINUTES OF THE BOARD MEETING"),
    p(
      `Minutes of the Meeting of the Board of Directors of ${c.name} held on ${fmtDate(t.boardMeetingDate)} (${dayOfWeek(t.boardMeetingDate)}) at ${fmtTime(t.boardMeetingTime)} at ${boardVenue(c, t)}.`,
    ),
    spacer(),
    p("Directors Present:", { bold: true }),
    ...compDirs.map(
      (d) =>
        new Paragraph({
          numbering: { reference: "agenda-list", level: 0 },
          children: [new TextRun({ text: `${stripTitle(d.name)} (DIN: ${d.din}) — ${d.category}`, size: 22, font: FONT })],
        }),
    ),
    spacer(),
    p("1. Chairman", { bold: true }),
    p(`${s.name} (DIN: ${s.din}) took the chair and confirmed the presence of quorum.`),
    p("2. Leave of Absence", { bold: true }),
    p("Leave of absence, if any, was granted to the directors who could not attend."),
    p("3. Confirmation of Previous Minutes", { bold: true }),
    p("Minutes of the previous Board Meeting were read, confirmed and signed by the Chairman."),
  ];
  let n = 4;
  items.forEach((it) => {
    out.push(p(`${n}. ${it.purpose.toUpperCase()}`, { bold: true }));
    out.push(p("The Board discussed the matter in detail and passed the following resolution:"));
    out.push(...resolutionBodyFor(it, t, c));
    n++;
  });
  gm.forEach((it) => {
    out.push(p(`${n}. Recommendation to Members — ${it.purpose.toUpperCase()}`, { bold: true }));
    out.push(p("The Board considered the matter and resolved to recommend the following resolution for approval of the Members at the General Meeting:"));
    out.push(...resolutionBodyFor(it, t, c));
    n++;
  });
  if (gm.length > 0 || t.generalMeetingDate) {
    out.push(p(`${n}. Calling of General Meeting`, { bold: true }));
    out.push(p("The Board considered and approved the calling of the General Meeting and authorised the ROC filing person to issue the Notice."));
    out.push(...gmCallResolution(c, t, n));
    n++;
  }
  out.push(
    p(`${n}. Vote of Thanks`, { bold: true }),
    p("There being no other business, the meeting concluded with a vote of thanks to the Chair."),
    spacer(), spacer(),
    p("__________________________"),
    p(s.name, { bold: true }),
    p("Chairman"),
    p(`DIN: ${s.din}    Date: ${fmtDate(t.boardMeetingDate)}`),
  );
  return out;
}

function sectionGMNotice(c: Company, t: TransactionInput, directors: Director[]) {
  const isAGM = t.generalMeetingType === "AGM";
  const items = gmResolutions(t);
  const out: Paragraph[] = [
    ...companyHeader(c),
    heading(`NOTICE OF ${isAGM ? "ANNUAL" : "EXTRA-ORDINARY"} GENERAL MEETING`),
    p(`Date of Issue of Notice: ${fmtDate(t.noticeIssueDate || t.boardMeetingDate)}`, { bold: true, right: true }),
    spacer(),
    p(
      `Notice is hereby given that the ${isAGM ? "Annual" : "Extra-Ordinary"} General Meeting of the Members of ${c.name} will be held on ${fmtDate(t.generalMeetingDate)} (${dayOfWeek(t.generalMeetingDate)}) at ${fmtTime(t.generalMeetingTime)} at ${gmVenue(c, t)} to transact the following business:`,
    ),
    spacer(),
    p("Special Business", { bold: true, underline: true }),
  ];
  items.forEach((it, idx) => {
    const isSpecial = ["Increase in Authorised Share Capital", "Private Placement", "Preferential Allotment", "Change in Name", "Borrowing Powers", "Loan under Section 186", "Investment under Section 186"].includes(it.purpose);
    out.push(p(`Item ${idx + 1}: ${it.purpose}`, { bold: true }));
    out.push(p(`To consider and, if thought fit, to pass with or without modification(s), the following resolution as ${isSpecial ? "a Special Resolution" : "an Ordinary Resolution"}:`));
    out.push(...resolutionBodyFor(it, t, c));
    out.push(spacer());
  });
  out.push(
    p("Notes:", { bold: true }),
    ...bulletList([
      "A Member entitled to attend and vote is entitled to appoint a proxy and the proxy need not be a Member.",
      "Proxy form duly completed should reach the Registered Office at least 48 hours before the meeting.",
      "The Explanatory Statement pursuant to Section 102 of the Companies Act, 2013 is annexed hereto.",
      ...(t.shorterNotice ? ["This Meeting is convened at SHORTER NOTICE with the consent of Members holding requisite majority, in terms of Section 101(1) of the Companies Act, 2013."] : []),
    ]),
    spacer(),
    p(`Place: ${gmVenue(c, t)}`),
    p(`Date: ${fmtDate(t.noticeIssueDate || t.boardMeetingDate)}`),
    spacer(),
    p("By order of the Board"),
    ...signatureBlock(c, t, directors),
  );
  return out;
}

function sectionGMCTC(c: Company, t: TransactionInput, directors: Director[]) {
  const items = gmResolutions(t);
  const isAGM = t.generalMeetingType === "AGM";
  const out: Paragraph[] = [
    ...companyHeader(c),
    heading("CERTIFIED TRUE COPY"),
    p(
      `Certified True Copy of the Resolutions passed at the ${isAGM ? "Annual" : "Extra-Ordinary"} General Meeting of the Members of ${c.name} held on ${fmtDate(t.generalMeetingDate)} (${dayOfWeek(t.generalMeetingDate)}) at ${fmtTime(t.generalMeetingTime)} at ${gmVenue(c, t)}.`,
    ),
    spacer(),
  ];
  items.forEach((it, idx) => {
    const isSpecial = ["Increase in Authorised Share Capital", "Private Placement", "Preferential Allotment", "Change in Name", "Borrowing Powers", "Loan under Section 186", "Investment under Section 186"].includes(it.purpose);
    out.push(p(`Item ${idx + 1}: ${it.purpose.toUpperCase()} — ${isSpecial ? "Special Resolution" : "Ordinary Resolution"}`, { bold: true, underline: true }));
    out.push(...resolutionBodyFor(it, t, c));
    out.push(spacer());
  });
  out.push(p("Certified to be true.", { bold: true }));
  out.push(...signatureBlock(c, t, directors));
  return out;
}

function sectionShorterNoticeConsent(c: Company, t: TransactionInput, shareholders: Shareholder[]) {
  const isAGM = t.generalMeetingType === "AGM";
  const compSh = shareholders.filter((s) => s.companyId === c.id);
  const totalShares = compSh.reduce((s, x) => s + Number(x.shares || 0), 0);

  const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "1e3a5f" };
  const borders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder };
  const cellWidths = [500, 2600, 1200, 1200, 1200, 2660];
  const headRow = new TableRow({
    children: ["S.No.", "Name of Member", "Folio No.", "No. of Shares", "% Holding", "Signature"].map(
      (h, i) =>
        new TableCell({
          borders,
          width: { size: cellWidths[i], type: WidthType.DXA },
          shading: { fill: "1e3a5f", type: ShadingType.CLEAR, color: "auto" },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT, size: 20 })] })],
        }),
    ),
  });
  const list = compSh.length > 0 ? compSh : [{ id: "", title: "" as const, name: "", folioNo: "", shares: 0, percentage: 0 } as Shareholder];
  const dataRows = list.map((s, i) => {
    const pct = s.percentage && s.percentage > 0
      ? s.percentage
      : (totalShares > 0 && s.shares ? (Number(s.shares) / totalShares) * 100 : 0);
    return new TableRow({
      children: [
        String(i + 1),
        s.name ? stripTitle(s.name) : "____________________",
        s.folioNo || "________",
        s.shares ? String(s.shares) : "________",
        pct ? `${pct.toFixed(2)}%` : "________",
        "",
      ].map(
        (v, j) =>
          new TableCell({
            borders,
            width: { size: cellWidths[j], type: WidthType.DXA },
            margins: { top: 100, bottom: 100, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: v, size: 20, font: FONT })] })],
          }),
      ),
    });
  });
  const table = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: cellWidths,
    rows: [headRow, ...dataRows],
  });

  return [
    ...companyHeader(c),
    heading("CONSENT FOR SHORTER NOTICE"),
    p(`(Pursuant to the proviso to Section 101(1) of the Companies Act, 2013)`, { center: true }),
    spacer(),
    p("To,"),
    p("The Board of Directors,"),
    p(c.name),
    p(c.registeredOffice || ""),
    spacer(),
    p(`Sub: Consent for holding the ${isAGM ? "Annual" : "Extra-Ordinary"} General Meeting at Shorter Notice`, { bold: true }),
    spacer(),
    p(
      `We, the undersigned Member(s) of ${c.name}, holding in aggregate not less than the majority in number of Members entitled to vote and representing not less than ninety-five per cent (95%) of such part of the paid-up share capital of the Company as gives a right to vote at the said meeting, hereby give our consent under the proviso to Section 101(1) of the Companies Act, 2013, to the holding of the ${isAGM ? "Annual" : "Extra-Ordinary"} General Meeting of the Company at SHORTER NOTICE on ${fmtDate(t.generalMeetingDate)} (${dayOfWeek(t.generalMeetingDate)}) at ${fmtTime(t.generalMeetingTime)} at ${gmVenue(c, t)}, to transact the business set out in the Notice convening the said meeting.`,
    ),
    spacer(),
    p("We hereby waive our right to receive the Notice of the said Meeting at a longer notice period as prescribed under the Companies Act, 2013."),
    spacer(),
    table,
    spacer(), spacer(),
    p(`Date: ${fmtDate(t.shorterNoticeDate || t.generalMeetingDate)}     Place: ${t.shorterNoticePlace || c.registeredOffice || "____________"}`),
  ];
}

function explanatoryFor(item: ResolutionItem, t: TransactionInput, c: Company): Paragraph[] {
  const purpose = item.purpose;
  const out: Paragraph[] = [];
  const dirName = stripTitle(item.directorName) || "[Director Name]";

  if (purpose === "Increase in Authorised Share Capital") {
    out.push(p(`The Board, at its meeting held on ${fmtDate(t.boardMeetingDate)}, considered it expedient to increase the Authorised Share Capital of the Company from ₹${item.existingAuthCapital || "[Existing]"} divided into ${item.existingShares || "[N]"} ${item.shareType || "Equity"} Shares of ₹${item.faceValue || "10"} each, to ₹${item.newAuthCapital || "[New]"} divided into ${item.newShares || "[N]"} ${item.shareType || "Equity"} Shares of ₹${item.faceValue || "10"} each, to meet the future capital requirements of the Company.`));
    out.push(p(`The proposed increase necessitates consequential alteration of Clause V of the Memorandum of Association of the Company, in terms of Sections 13, 61 and 64 of the Companies Act, 2013 read with the Companies (Share Capital and Debentures) Rules, 2014. Pursuant to Section 64, the Company shall file Form SH-7 with the Registrar of Companies within thirty (30) days of passing of the resolution.`));
  } else if (purpose === "Private Placement" || purpose === "Preferential Allotment") {
    out.push(p(`In terms of Sections 42 and 62(1)(c) of the Companies Act, 2013 read with the Companies (Prospectus and Allotment of Securities) Rules, 2014 and the Companies (Share Capital and Debentures) Rules, 2014, the Company proposes to offer, issue and allot up to ${item.numberOfShares || "[N]"} Equity Shares of face value ₹${item.faceValue || "10"} each at an issue price of ₹${item.issuePrice || "[Price]"} per share (including a premium of ₹${item.premium || "0"}) on a ${purpose === "Private Placement" ? "private placement" : "preferential"} basis to the identified investors.`));
    out.push(p(`Disclosures required under Rule 13 of the Companies (Share Capital and Debentures) Rules, 2014 and Rule 14 of the Companies (Prospectus and Allotment of Securities) Rules, 2014 are as under:`));
    out.push(...bulletList([
      `Objects of the issue: To augment working capital / long-term resources of the Company.`,
      `Total number of shares to be issued: ${item.numberOfShares || "[N]"}`,
      `Price per share / issue price: ₹${item.issuePrice || "[Price]"} (Face value ₹${item.faceValue || "10"} + Premium ₹${item.premium || "0"}).`,
      `Basis on which the price has been arrived at: Valuation Report of a Registered Valuer dated [●].`,
      `Class or classes of persons to whom allotment is proposed to be made: as per list of investors approved by the Board.`,
      `Intention of Promoters / Directors / Key Managerial Personnel to subscribe to the offer: as disclosed in the Board resolution.`,
      `Proposed time within which allotment shall be completed: within 60 days of receipt of application money, in accordance with Section 42(6).`,
      `Names of proposed allottees and percentage of post-preferential issue capital that may be held by them: [●].`,
      `Change in control, if any, consequent to the preferential offer: ${item.details || "No"}`,
      `Pre and post-issue shareholding pattern: as per Annexure.`,
    ]));
  } else if (purpose === "Change in Registered Office") {
    out.push(p(`The Board proposes to shift the Registered Office of the Company from "${c.registeredOffice || "[Existing Address]"}" to "${item.newRegisteredOffice || "[New Address]"}" with effect from ${fmtDate(t.effectiveDate)}, in terms of Section 12 of the Companies Act, 2013 read with the Companies (Incorporation) Rules, 2014.${item.newRegOfficeChangeRoc ? " As the proposed change involves shifting from the jurisdiction of one Registrar of Companies to another, the prior approval of the Regional Director under Section 13(4) read with Rule 30 of the Companies (Incorporation) Rules, 2014 shall also be obtained." : ""} Form INC-22 shall be filed with the Registrar of Companies within thirty (30) days of such change.`));
  } else if (purpose.startsWith("Appointment of")) {
    out.push(p(`The Board, at its meeting held on ${fmtDate(t.boardMeetingDate)}, appointed ${dirName} (DIN: ${item.directorDIN || "[DIN]"}) as ${item.designation || purpose.replace("Appointment of ", "")} of the Company with effect from ${fmtDate(item.appointmentDate || t.effectiveDate)}, in terms of Sections 149, 152, 161 and other applicable provisions of the Companies Act, 2013 and the Companies (Appointment and Qualification of Directors) Rules, 2014. The appointee has furnished consent in Form DIR-2 and declaration in Form DIR-8 confirming that he is not disqualified to be appointed as a Director.`));
    out.push(p(`Brief profile, terms of appointment, remuneration and other particulars are set out in the resolution and the appointee's consent in Form DIR-2 along with declaration in Form DIR-8 form part of the records of the Company available for inspection.`));
  } else if (purpose === "Resignation of Director") {
    out.push(p(`${dirName} (DIN: ${item.directorDIN || "[DIN]"}) has tendered his resignation from the office of Director of the Company with effect from ${fmtDate(item.resignationDate || t.effectiveDate)}, ${item.resignationReason || DIRECTOR_RESIGNATION_REASON}. The resignation has been taken on record by the Board and Form DIR-12 shall be filed with the Registrar of Companies within thirty (30) days under Section 168 of the Companies Act, 2013.`));
  } else {
    out.push(p(`The Board, at its meeting held on ${fmtDate(t.boardMeetingDate)}, considered and approved, subject to the approval of the Members, the proposal pertaining to ${purpose}.${item.details ? ` ${item.details}` : ""} The proposal is in compliance with the applicable provisions of the Companies Act, 2013 and the rules made thereunder.`));
  }

  out.push(spacer());
  out.push(p("Nature of concern or interest of Directors / Key Managerial Personnel / their relatives:", { bold: true }));
  out.push(p(`Save and except to the extent of their shareholding, if any, in the Company, none of the Directors, Key Managerial Personnel of the Company and their relatives are, in any way, concerned or interested, financially or otherwise, in the said resolution${purpose.startsWith("Appointment of") || purpose === "Resignation of Director" ? `, except ${dirName} (DIN: ${item.directorDIN || "[DIN]"}) being the appointee/resigning director, and his relatives to the extent of their shareholding, if any.` : "."}`));
  out.push(p("Documents available for inspection:", { bold: true }));
  out.push(p(`All documents referred to in the Notice and this Explanatory Statement, including the Memorandum and Articles of Association of the Company, Register of Directors and Key Managerial Personnel, Register of Contracts/Arrangements in which Directors are interested, copies of the resolutions passed by the Board, valuation reports (where applicable), consent letters (DIR-2 / DIR-8 / ADT-1, as applicable) and statutory registers, are available for inspection by the Members at the Registered Office of the Company on all working days between 11:00 AM and 1:00 PM up to the date of the Meeting and shall also be available at the venue of the Meeting.`));
  out.push(p("Recommendation:", { bold: true }));
  out.push(p(`The Board recommends the resolution set out at the Item above for the approval of the Members.`));
  out.push(spacer());
  return out;
}

function sectionExplanatory(c: Company, t: TransactionInput, directors: Director[]) {
  const items = gmResolutions(t).length > 0 ? gmResolutions(t) : allResolutions(t);
  const out: Paragraph[] = [
    ...companyHeader(c),
    heading("EXPLANATORY STATEMENT"),
    p("(Pursuant to Section 102 of the Companies Act, 2013)", { center: true }),
    spacer(),
  ];
  items.forEach((it, idx) => {
    out.push(p(`Item No. ${idx + 1}: ${it.purpose}`, { bold: true }));
    out.push(...explanatoryFor(it, t, c));
  });
  out.push(p("By order of the Board"));
  out.push(...signatureBlock(c, t, directors));
  return out;
}

function sectionProxy(c: Company, t: TransactionInput) {
  const isAGM = t.generalMeetingType === "AGM";
  return [
    ...companyHeader(c),
    heading("FORM MGT-11 — PROXY FORM"),
    p("(Pursuant to Section 105(6) of the Companies Act, 2013 and Rule 19(3) of the Companies (Management and Administration) Rules, 2014)", { center: true }),
    spacer(),
    p(`Name of Member(s): ________________________________________________`),
    p(`Registered Address: ________________________________________________`),
    p(`E-mail Id: __________________________   Folio No / DP ID: ____________`),
    spacer(),
    p(`I/We, being the member(s) of ____________ shares of ${c.name}, hereby appoint:`),
    p(`1. Name: ________________________  Address: ________________________`),
    p(`   E-mail: ________________________  Signature: ________________  or failing him/her`),
    p(`2. Name: ________________________  Address: ________________________`),
    spacer(),
    p(`as my/our proxy to attend and vote (on a poll) for me/us and on my/our behalf at the ${isAGM ? "Annual" : "Extra-Ordinary"} General Meeting of the Company to be held on ${fmtDate(t.generalMeetingDate)} at ${fmtTime(t.generalMeetingTime)} at ${gmVenue(c, t)} and at any adjournment thereof.`),
    ...gmResolutions(t).map((r, i) => p(`Resolution ${i + 1}: ${r.purpose}`)),
    spacer(), spacer(),
    p(`Signed this ____ day of __________, 20__`),
    p(`Signature of Shareholder: ____________________   Affix Re. 1 Revenue Stamp`),
    p(`Signature of Proxy holder(s): ____________________`),
  ];
}

function sectionOfferLetter(c: Company, t: TransactionInput, item: ResolutionItem, directors: Director[]) {
  const purpose = item.purpose;
  const isPrivatePlacement = purpose === "Private Placement" || purpose === "Preferential Allotment";
  const formTitle = isPrivatePlacement
    ? "FORM PAS-4 — PRIVATE PLACEMENT OFFER-CUM-APPLICATION LETTER"
    : purpose === "Rights Issue"
      ? "LETTER OF OFFER — RIGHTS ISSUE"
      : purpose === "Bonus Issue"
        ? "LETTER OF OFFER — BONUS ISSUE"
        : "OFFER LETTER FOR ISSUE OF SHARES";

  const statutoryRef = isPrivatePlacement
    ? "(Pursuant to Section 42 of the Companies Act, 2013 read with Rule 14 of the Companies (Prospectus and Allotment of Securities) Rules, 2014)"
    : purpose === "Rights Issue"
      ? "(Pursuant to Section 62(1)(a) of the Companies Act, 2013)"
      : purpose === "Bonus Issue"
        ? "(Pursuant to Section 63 of the Companies Act, 2013)"
        : "(Pursuant to applicable provisions of the Companies Act, 2013)";

  const numShares = item.numberOfShares || "[Number of Shares]";
  const faceVal = item.faceValue || "10";
  const premium = item.premium || "0";
  const issuePrice = item.issuePrice || `${Number(faceVal) + Number(premium) || "[Price]"}`;

  return [
    ...companyHeader(c),
    heading(formTitle),
    p(statutoryRef, { center: true }),
    spacer(),
    p(`Date: ${fmtDate(t.effectiveDate || new Date().toISOString())}`),
    p(`Offer Letter Sr. No.: __________`),
    spacer(),
    p("To,"),
    p("[Name of Allottee/Investor]"),
    p("[Address]"),
    spacer(),
    p(`Dear Sir/Madam,`),
    p(`Sub: Offer for ${isPrivatePlacement ? "private placement / preferential allotment" : purpose.toLowerCase()} of ${numShares} Equity Shares of ${c.name}.`, { bold: true }),
    spacer(),
    p(`Pursuant to the resolution passed by the Board of Directors of the Company at its meeting held on ${fmtDate(t.boardMeetingDate)}${t.generalMeetingDate ? ` and the Special Resolution passed by the Members at the ${t.generalMeetingType || "General"} Meeting held on ${fmtDate(t.generalMeetingDate)}` : ""}, the Company hereby offers to issue and allot Equity Shares on the following terms:`),
    spacer(),
    p("Particulars of the Offer", { bold: true, underline: true }),
    ...bulletList([
      `Name of the Issuer: ${c.name}`,
      `CIN: ${c.cin || "—"}`,
      `Registered Office: ${c.registeredOffice || "—"}`,
      `Email: ${c.email || "—"}  |  Phone: ${c.phone || "—"}`,
      `Authorised Share Capital: ₹${c.authorisedCapital || "—"}`,
      `Paid-up Share Capital: ₹${c.paidUpCapital || "—"}`,
      `Type of Security Offered: Equity Shares`,
      `Number of Shares Offered: ${numShares}`,
      `Face Value: ₹${faceVal} per share`,
      `Premium: ₹${premium} per share`,
      `Issue Price: ₹${issuePrice} per share`,
      `Total Issue Size: ₹${(Number(numShares) * Number(issuePrice)) || "[Amount]"}`,
      ...(purpose === "Rights Issue" || purpose === "Bonus Issue"
        ? [
            `Record Date: ${fmtDate(item.recordDate || "")}`,
            `Offer Opening Date: ${fmtDate(item.offerOpenDate || "")}`,
            `Offer Closing Date: ${fmtDate(item.offerCloseDate || "")}`,
            `Renunciation: ${item.renunciation ? "Permitted" : "Not Permitted"}`,
          ]
        : [
            `Mode of Payment: Cheque / Demand Draft / RTGS / NEFT to the Company's designated bank account`,
            `Date of Allotment (proposed): ${fmtDate(item.allotmentDate || "")}`,
          ]),
    ]),
    spacer(),
    p("TERMS & CONDITIONS", { bold: true, underline: true }),
    ...bulletList([
      "The offer is non-transferable and is being made to identified persons only.",
      "The subscription money shall be paid by way of cheque/demand draft/banking channel from the bank account of the subscriber. Cash payment shall not be accepted.",
      "The Company shall allot the shares within sixty (60) days from the date of receipt of the application money, failing which the application money shall be refunded as per Section 42.",
      "The shares shall rank pari-passu with the existing Equity Shares of the Company in all respects.",
    ]),
    spacer(),
    p("Declaration by the Company", { bold: true }),
    p(`We hereby declare that the Company has complied with the provisions of the Companies Act, 2013 and the rules made thereunder, and that the disclosures made in this offer letter are true and correct.`),
    ...signatureBlock(c, t, directors),
    spacer(),
    p("Acceptance by the Allottee", { bold: true, underline: true }),
    p(`I/We, ____________________________, hereby accept the above offer and apply for ________ Equity Shares of ${c.name} for a total consideration of ₹__________.`),
    p(`Name: ____________________________     PAN: ____________________`),
    p(`Address: __________________________________________________________`),
    p(`Signature: _______________________      Date: _____________________`),
  ];
}

// ---- DIR-2 (Director Consent) & DIR-8 (Director Declaration) ----

function parseDirRows(text?: string): Array<[string, string, string]> {
  if (!text) return [];
  return text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((line) => {
    const parts = line.split("|").map((s) => s.trim());
    return [parts[0] || "", parts[1] || "", parts[2] || ""] as [string, string, string];
  });
}

function dirTable(rows: Array<[string, string, string]>) {
  const header = `Name of the Company        |  Date of Appointment  |  Date of Cessation`;
  const sep = `-------------------------------------------------------------------------------`;
  const body = rows.length === 0
    ? ["1.  ____________________   |  ____________________  |  ____________________",
       "2.  ____________________   |  ____________________  |  ____________________"]
    : rows.map((r, i) => `${i + 1}.  ${r[0] || "____________________"}   |  ${r[1] ? fmtDate(r[1]) : "____________________"}  |  ${r[2] ? fmtDate(r[2]) : "____________________"}`);
  return [
    p(header, { bold: true }),
    p(sep),
    ...body.map((l) => p(l)),
  ];
}

function dir2ParticularsTable(item: ResolutionItem) {
  const name = stripTitle(item.directorName) || "[Director Name]";
  const rows: Array<[string, string, string]> = [
    ["1", "Director Identification Number (DIN)", item.directorDIN || "____________________"],
    ["2", "Name (in full)", name],
    ["3", "Father's Name (in full)", item.dir2FathersName || "____________________"],
    ["4", "Address", item.directorAddress || "____________________"],
    ["5", "E-mail id", item.directorEmail || "____________________"],
    ["6", "Mobile no.", item.directorMobile || "____________________"],
    ["7", "Income-tax PAN", item.directorPAN || "____________________"],
    ["8", "Occupation", item.dir2Occupation || "____________________"],
    ["9", "Date of birth", item.dir2DOB ? fmtDate(item.dir2DOB) : "____________________"],
    ["10", "Nationality", item.dir2Nationality || "Indian"],
    ["11", "No. of other companies in which already a Director / (MD/CEO/WTD/Secretary/CFO/Manager)", `Other Directorships: ${item.dir2OtherDirectorshipsCount || "—"}\nMD/CEO/WTD/Sec/CFO/Manager: ${item.dir2KmpCompanies || "NIL"}`],
    ["12", "Particulars of membership no. & Certificate of practice no. (if any)", item.dir2MembershipDetails || "NIL"],
  ];
  const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "1e3a5f" };
  const borders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder };
  const widths = [700, 3600, 5060];
  const head = new TableRow({
    children: ["S. No.", "Particulars", "Details"].map((h, i) => new TableCell({
      borders,
      width: { size: widths[i], type: WidthType.DXA },
      shading: { fill: "1e3a5f", type: ShadingType.CLEAR, color: "auto" },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT, size: 20 })] })],
    })),
  });
  const dataRows = rows.map((r) => new TableRow({
    children: r.map((v, i) => new TableCell({
      borders,
      width: { size: widths[i], type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: v.split("\n").map((line) => new Paragraph({ children: [new TextRun({ text: line, size: 20, font: FONT })] })),
    })),
  }));
  return new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: widths, rows: [head, ...dataRows] });
}

function sectionDIR2(c: Company, item: ResolutionItem): (Paragraph | Table)[] {
  const name = stripTitle(item.directorName) || "[Director Name]";
  const designation = item.dir2Designation || item.designation || "Director";
  const clearance = item.dir2SecurityClearance || "not_required";
  return [
    heading("FORM DIR-2"),
    p("Consent to act as a Director of a Company", { center: true, bold: true }),
    p("[Pursuant to section 152(5) and rule 8 of Companies (Appointment and Qualification of Directors) Rules, 2014]", { center: true }),
    spacer(),
    p("To"),
    p(c.name),
    p(c.registeredOffice || ""),
    spacer(),
    p(`Subject: Consent to act as a director.`, { bold: true }),
    spacer(),
    p(`I, ${name}, hereby give my consent to act as director of ${c.name}, pursuant to sub-section (5) of section 152 of the Companies Act, 2013 and certify that I am not disqualified to become a director under the Companies Act, 2013.`),
    spacer(),
    p("Particulars:", { bold: true }),
    dir2ParticularsTable(item),
    spacer(),
    p("Declaration", { bold: true, center: true }),
    spacer(),
    p(`(i)  I declare that I have not been convicted of any offence in connection with the promotion, formation or management of any company or LLP and have not been found guilty of any fraud or misfeasance or of any breach of duty to any company under this Act or any previous company law in the last five years. I further declare that if appointed my total Directorship in all the companies shall not exceed the prescribed number of companies in which a person can be appointed as a Director.`),
    spacer(),
    p(`(ii) I further declare that –`),
    p(`    [${clearance === "not_required" ? "X" : " "}] I am not required to obtain the security clearance from the Ministry of Home Affairs, Government of India before seeking appointment as director; or`),
    p(`    [${clearance === "obtained" ? "X" : " "}] I am required to obtain the security clearance from the Ministry of Home Affairs, Government of India before seeking appointment as director and the same has been obtained and is attached.`),
    spacer(), spacer(),
    p(`Signature: __________________________`),
    p(`             ${name}`, { bold: true }),
    p(`Designation: ${designation}`),
    p(`Date: ${fmtDate(item.dir2Date || item.appointmentDate || "")}`),
    p(`Place: ${item.dir2Place || "____________"}`),
    spacer(),
    p("Attachments:", { bold: true }),
    p("1) Proof of identity;"),
    p("2) Proof of residence."),
  ];
}

function sectionDIR8(c: Company, item: ResolutionItem) {
  const name = stripTitle(item.directorName) || "[Director Name]";
  const relation = item.dir8Relation || "son";
  const relationName = item.dir8RelationName || item.dir2FathersName || "____________________";
  const capacity = item.dir8Capacity || "director";
  const disqualified = !!item.dir8Disqualified;
  const dateStr = item.dir8Date || item.appointmentDate || "";
  const d = dateStr ? new Date(dateStr) : null;
  const dayNum = d && !isNaN(d.getTime()) ? String(d.getDate()) : "______";
  const monthYear = d && !isNaN(d.getTime())
    ? d.toLocaleString("en-IN", { month: "long", year: "numeric" })
    : "________________";
  return [
    heading("FORM DIR-8"),
    p("Intimation by Director", { center: true, bold: true }),
    p("[Pursuant to Section 164(1) or 164(2) and rule 14(1) of the Companies (Appointment and Qualification of Directors) Rules, 2014]", { center: true }),
    spacer(),
    p(`Registration No. of Company: ${c.cin || "____________________"}`),
    p(`Nominal Capital Rs.: ${c.authorisedCapital || "____________________"}`),
    p(`Paid-up Capital Rs.: ${c.paidUpCapital || "____________________"}`),
    p(`Name of Company: ${c.name}`),
    p(`Address of its Registered Office: ${c.registeredOffice || "____________________"}`),
    spacer(),
    p("To"),
    p(`The Board of Directors of ${c.name}`),
    spacer(),
    p(`I, ${name}, ${relation} of ${relationName}, resident of ${item.directorAddress || "____________________"}, ${capacity} in the company hereby give notice that I am / was a director in the following companies during the last three years:`),
    spacer(),
    ...dirTable(parseDirRows(item.dir8PastDirectorships)),
    spacer(),
    ...(disqualified
      ? [
          p(`I further confirm that I have incurred disqualification —`),
          p(`(A) under section 164(1) on the following ground(s) in the previous financial year: ${item.dir8DisqualificationGround || "____________________"}; or`),
          p(`(B) under section 164(2) of the Companies Act, 2013 in the following company(s) in the previous financial year, and that I, at present stand disqualified from being a director:`),
          spacer(),
          ...dirTable(parseDirRows(item.dir8DisqualifiedCompanies)),
        ]
      : [
          p(`I further confirm that I have not incurred disqualification under section 164(1) or section 164(2) of the Companies Act, 2013 in any of the above companies, in the previous financial year, and that I, at present, stand free from any disqualification from being a director.`),
        ]),
    spacer(), spacer(),
    p(`Signature: __________________________`),
    p(`(Full Name) ${name}`, { bold: true }),
    p(`DIN: ${item.directorDIN || "[DIN]"}`),
    spacer(),
    p(`Dated this ${dayNum} day of ${monthYear}`),
    p(`Place: ${item.dir8Place || item.dir2Place || "____________"}`),
  ];
}

// ---- Resignation letters ----
// NOTE: per user — DO NOT print company letterhead for Director / Auditor resignation letters.
//       For auditor, print AUDITOR letterhead (CA logo) instead.

function sectionDirectorResignationLetter(c: Company, t: TransactionInput, item: ResolutionItem) {
  const name = stripTitle(item.directorName) || "[Director Name]";
  const reason = (item.resignationReason && item.resignationReason.trim().length > 0) ? item.resignationReason : DIRECTOR_RESIGNATION_REASON;
  return [
    heading("LETTER OF RESIGNATION — DIRECTOR"),
    spacer(),
    p(`Date: ${fmtDate(item.resignationDate || t.effectiveDate)}`),
    p(`Place: ____________`),
    spacer(),
    p("To,"),
    p("The Board of Directors,"),
    p(c.name),
    p(c.registeredOffice || ""),
    spacer(),
    p(`Sub: Resignation from the office of Director of ${c.name}`, { bold: true }),
    spacer(),
    p("Dear Sirs / Madam,"),
    p(`I, ${name} (DIN: ${item.directorDIN || "[DIN]"}${item.directorPAN ? `, PAN: ${item.directorPAN}` : ""}), hereby tender my resignation from the office of Director of ${c.name} with effect from the close of business hours on ${fmtDate(item.resignationDate || t.effectiveDate)}, ${reason}. I confirm that there are no other material reasons for my resignation other than those stated herein.`),
    p(`Kindly take this resignation on record and arrange to file the necessary intimation in Form DIR-12 with the Registrar of Companies. I shall, in terms of Section 168(1) of the Companies Act, 2013, also forward a copy of this resignation along with the prescribed reasons in Form DIR-11 to the Registrar of Companies within the stipulated period.`),
    p(`I place on record my appreciation for the cooperation extended to me during my tenure.`),
    spacer(), spacer(),
    p(`Thanking you,`),
    spacer(),
    p(`Yours faithfully,`),
    spacer(), spacer(),
    p(`__________________________`),
    p(name, { bold: true }),
    p(`DIN: ${item.directorDIN || "[DIN]"}`),
  ];
}

function sectionAuditorResignationLetter(c: Company, t: TransactionInput, item: ResolutionItem, auditor: Auditor | undefined) {
  const firm = item.auditorFirmName || auditor?.firmName || c.auditorName || "[Auditor Firm]";
  const frn = item.auditorFirmRegNo || auditor?.frn || c.auditorFirmRegNo || "[FRN]";
  const reason = (item.resignationReason && item.resignationReason.trim().length > 0) ? item.resignationReason : AUDITOR_RESIGNATION_REASON;
  const a: Auditor = auditor || {
    id: "", companyId: c.id, firmName: firm, frn, authorizedPersonName: item.auditorAuthorizedPerson || "____________",
    designation: "Partner", membershipNo: item.auditorMembershipNo || "____________",
    email: "", address: "", phone: "", place: "____________",
  };
  return [
    ...auditorLetterhead(a),
    heading("LETTER OF RESIGNATION — STATUTORY AUDITOR"),
    spacer(),
    p(`Date: ${fmtDate(item.resignationDate || t.effectiveDate)}`),
    spacer(),
    p("To,"),
    p("The Board of Directors,"),
    p(c.name),
    p(c.registeredOffice || ""),
    spacer(),
    p(`Sub: Resignation from the office of Statutory Auditor of ${c.name}`, { bold: true }),
    spacer(),
    p("Dear Sirs / Madam,"),
    p(`We, M/s ${firm} (Firm Registration No.: ${frn}), Chartered Accountants, the Statutory Auditors of ${c.name}, hereby tender our resignation from the office of Statutory Auditors of the Company with effect from ${fmtDate(item.resignationDate || t.effectiveDate)}, ${reason}.`),
    p(`We shall file Form ADT-3 with the Registrar of Companies within thirty (30) days of this resignation in terms of Section 140(2) of the Companies Act, 2013 read with Rule 8 of the Companies (Audit and Auditors) Rules, 2014. Kindly initiate appropriate steps for filling the resulting casual vacancy under Section 139(8).`),
    p(`We place on record our appreciation for the cooperation extended to us during our tenure as Statutory Auditors of the Company.`),
    spacer(),
    p("Thanking you,"),
    spacer(),
    p("Yours faithfully,"),
    ...auditorSignBlock(a, item.resignationDate || t.effectiveDate),
  ];
}

function sectionRocChecklist(c: Company, t: TransactionInput) {
  const purpose = primaryPurpose(t);
  const m = getRocMapping(purpose);
  const filingLines = (t.filings || []).filter((f) => f.srn || f.date).map((f) => `${f.form || m?.form || "Form"} — SRN: ${f.srn || "—"} | Filed on: ${f.date ? fmtDate(f.date) : "—"}`);
  return [
    ...companyHeader(c),
    heading("ROC COMPLIANCE CHECKLIST"),
    p(`Primary Purpose: ${purpose || "—"}`, { bold: true }),
    spacer(),
    p(`Applicable Form: ${m?.form || "—"}`),
    p(`Statutory Due Period: ${m ? `${m.dueDays} days from event` : "—"}`),
    p(`Description: ${m?.description || "—"}`),
    p(`Filing Fees: ${m?.baseFee || "—"}`),
    p(`Authorised to File / Sign Form: ${rocPersonLine(t)}`, { bold: true }),
    spacer(),
    p("Filings Made:", { bold: true }),
    ...(filingLines.length ? bulletList(filingLines) : [p("— No SRN filed yet —")]),
    spacer(),
    p("Attachments Required:", { bold: true }),
    ...bulletList(m?.attachments ?? ["—"]),
  ];
}

// ---- Build doc ----

function buildDoc(children: (Paragraph | Table)[], headerText?: string) {
  return new Document({
    creator: "CS Compliance Suite",
    styles: { default: { document: { run: { font: FONT, size: 22 } } } },
    numbering: {
      config: [
        {
          reference: "agenda-list",
          levels: [
            {
              level: 0,
              format: LevelFormat.DECIMAL,
              text: "%1.",
              alignment: AlignmentType.LEFT,
              style: { paragraph: { indent: { left: 720, hanging: 360 } } },
            },
          ],
        },
      ],
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 12240, height: 15840, orientation: PageOrientation.PORTRAIT },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
          },
        },
        headers: headerText
          ? {
              default: new Header({
                children: [
                  new Paragraph({
                    alignment: AlignmentType.RIGHT,
                    children: [new TextRun({ text: headerText, italics: true, size: 18, font: FONT, color: "1e3a5f" })],
                  }),
                ],
              }),
            }
          : undefined,
        children,
      },
    ],
  });
}

// ---- Save meeting records ----

function persistMeetings(c: Company, t: TransactionInput, status: "DRAFT" | "LOCKED") {
  const agenda = allResolutions(t).map((r) => r.purpose);
  const filings = t.filings || [];
  const created: MeetingRecord[] = [];
  if (t.boardMeetingDate) {
    created.push({
      id: uid(),
      companyId: c.id,
      companyName: c.name,
      type: "Board",
      date: t.boardMeetingDate,
      time: t.boardMeetingTime || "",
      venue: boardVenue(c, t),
      agenda: [...agenda, ...(t.generalMeetingDate ? ["Calling of General Meeting"] : [])],
      shorterNotice: !!t.shorterNotice,
      status,
      filings,
      input: t,
      createdAt: new Date().toISOString(),
    });
  }
  if (t.generalMeetingDate) {
    created.push({
      id: uid(),
      companyId: c.id,
      companyName: c.name,
      type: (t.generalMeetingType as "EGM" | "AGM") || "EGM",
      date: t.generalMeetingDate,
      time: t.generalMeetingTime || "",
      venue: gmVenue(c, t),
      agenda,
      shorterNotice: !!t.shorterNotice,
      status,
      filings,
      input: t,
      createdAt: new Date().toISOString(),
    });
  }
  if (created.length) store.setMeetings((m) => [...m, ...created]);
}

// ---- Master auto-update on LOCK ----

function applyMasterUpdates(c: Company, t: TransactionInput) {
  const s = store.get();
  allResolutions(t).forEach((r) => {
    if (r.purpose.startsWith("Appointment of") && r.directorName) {
      const exists = s.directors.find((d) => d.companyId === c.id && d.din && r.directorDIN && d.din === r.directorDIN);
      if (!exists) {
        store.setDirectors((ds) => [
          ...ds,
          {
            id: uid(),
            companyId: c.id,
            title: (r.directorTitle as any) || "",
            name: stripTitle(r.directorName),
            din: r.directorDIN || "",
            pan: r.directorPAN || "",
            address: r.directorAddress || "",
            email: r.directorEmail || "",
            mobile: r.directorMobile || "",
            dateOfAppointment: r.appointmentDate || t.effectiveDate || "",
            category: (r.directorCategory as any) || (r.purpose.includes("Independent") ? "Independent" : "Executive"),
            designation: r.designation || "Director",
            dscAvailable: false,
          },
        ]);
      }
    }
    if (r.purpose === "Resignation of Director" || r.purpose === "Removal of Director") {
      if (r.directorDIN) {
        store.setDirectors((ds) => ds.filter((d) => !(d.companyId === c.id && d.din === r.directorDIN)));
      } else if (r.directorName) {
        const target = stripTitle(r.directorName).toLowerCase();
        store.setDirectors((ds) => ds.filter((d) => !(d.companyId === c.id && stripTitle(d.name).toLowerCase() === target)));
      }
    }
    if (r.purpose === "Change in Registered Office" && r.newRegisteredOffice) {
      store.setCompanies((cs) => cs.map((co) => co.id === c.id ? { ...co, registeredOffice: r.newRegisteredOffice! } : co));
    }
    if (r.purpose === "Increase in Authorised Share Capital" && r.newAuthCapital) {
      store.setCompanies((cs) => cs.map((co) => co.id === c.id ? { ...co, authorisedCapital: r.newAuthCapital! } : co));
    }
    if (SHARE_ISSUE_PURPOSES.has(r.purpose) && r.numberOfShares && r.faceValue) {
      const add = Number(r.numberOfShares) * Number(r.faceValue);
      if (!isNaN(add) && add > 0) {
        store.setCompanies((cs) => cs.map((co) => {
          if (co.id !== c.id) return co;
          const existing = Number(co.paidUpCapital || 0);
          return { ...co, paidUpCapital: String((existing || 0) + add) };
        }));
      }
    }
    if (r.purpose === "Appointment of Auditor" && r.auditorFirmName) {
      store.setCompanies((cs) => cs.map((co) => co.id === c.id ? { ...co, auditorName: r.auditorFirmName!, auditorFirmRegNo: r.auditorFirmRegNo || co.auditorFirmRegNo } : co));
      const exists = store.get().auditors.find((a) => a.companyId === c.id && a.frn === (r.auditorFirmRegNo || ""));
      if (!exists) {
        store.setAuditors((as) => [...as, {
          id: uid(), companyId: c.id, firmName: r.auditorFirmName!, frn: r.auditorFirmRegNo || "",
          authorizedPersonName: r.auditorAuthorizedPerson || "", designation: "Partner",
          membershipNo: r.auditorMembershipNo || "", email: "", address: "", phone: "", place: "",
        }]);
      }
    }
    if (r.purpose === "Resignation of Auditor") {
      if (r.auditorFirmRegNo) {
        store.setAuditors((as) => as.filter((a) => !(a.companyId === c.id && a.frn === r.auditorFirmRegNo)));
      }
      store.setCompanies((cs) => cs.map((co) => co.id === c.id ? { ...co, auditorName: "", auditorFirmRegNo: "" } : co));
    }
  });
}

// ---- Public API ----

export interface GenerateOptions {
  skipPersist?: boolean;
  asDraft?: boolean;
  lock?: boolean;
  stamp?: string;
}

export async function generateAllInOne(
  c: Company,
  rawT: TransactionInput,
  directors: Director[],
  shareholders: Shareholder[] = [],
  opts: GenerateOptions = {},
) {
  const t = migrateLegacy(rawT);
  const hasGMResolutions = gmResolutions(t).length > 0;
  const isGM = !!t.generalMeetingDate || hasGMResolutions;
  const shareIssueResolutions = allResolutions(t).filter((r) => SHARE_ISSUE_PURPOSES.has(r.purpose));
  const directorAppointments = allResolutions(t).filter((r) => r.purpose.startsWith("Appointment of") && r.purpose !== "Appointment of Auditor");
  const dirResigns = allResolutions(t).filter((r) => r.purpose === "Resignation of Director");
  const audResigns = allResolutions(t).filter((r) => r.purpose === "Resignation of Auditor");
  const auditors = store.get().auditors;

  const blocks: (Paragraph | Table)[][] = [
    sectionSummary(c, t),
    sectionBoardNotice(c, t, directors),
    sectionAgenda(c, t),
    sectionAttendance(c, t, directors),
    sectionBoardResolution(c, t, directors),
    sectionCTC(c, t, directors),
    sectionMinutes(c, t, directors),
  ];

  if (isGM) {
    blocks.push(sectionGMNotice(c, t, directors));
    blocks.push(sectionExplanatory(c, t, directors));
    blocks.push(sectionProxy(c, t));
    if (t.shorterNotice) blocks.push(sectionShorterNoticeConsent(c, t, shareholders));
    blocks.push(sectionGMCTC(c, t, directors));
  }

  directorAppointments.forEach((r) => {
    blocks.push(sectionDIR2(c, r));
    blocks.push(sectionDIR8(c, r));
  });
  shareIssueResolutions.forEach((r) => blocks.push(sectionOfferLetter(c, t, r, directors)));
  dirResigns.forEach((r) => blocks.push(sectionDirectorResignationLetter(c, t, r)));
  audResigns.forEach((r) => {
    const a = auditors.find((x) => x.companyId === c.id && (x.frn === r.auditorFirmRegNo || x.firmName === r.auditorFirmName)) ||
              auditors.find((x) => x.companyId === c.id);
    blocks.push(sectionAuditorResignationLetter(c, t, r, a));
  });

  blocks.push(sectionRocChecklist(c, t));

  const all: (Paragraph | Table)[] = [];
  blocks.forEach((b, i) => {
    if (i > 0) all.push(pageBreak());
    all.push(...b);
  });

  let stamp = opts.stamp;
  if (!stamp && (opts.lock || (t.filings && t.filings.length > 0))) {
    const lines = (t.filings || []).filter((f) => f.srn || f.date).map((f) => `${f.form ? f.form + " " : ""}SRN ${f.srn || "—"} | ${f.date ? fmtDate(f.date) : "—"}`);
    if (lines.length) stamp = `Filed: ${lines.join("   •   ")}`;
  }

  if (!opts.skipPersist) {
    persistMeetings(c, t, opts.lock ? "LOCKED" : "DRAFT");
  }
  if (opts.lock) {
    applyMasterUpdates(c, t);
  }

  const blob = await Packer.toBlob(buildDoc(all, stamp));
  const slug = `${c.name.replace(/\s+/g, "_")}_${primaryPurpose(t).replace(/\s+/g, "_") || "Document"}`;
  await downloadDocx(blob, `CS_Document_Set_${slug}.docx`);
}

// ---- Meetings summary export (for a period) ----

export async function generateMeetingsSummary(meetings: MeetingRecord[], from: string, to: string) {
  const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "1e3a5f" };
  const borders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder };
  const head = new TableRow({
    children: ["Date", "Day", "Company", "Type", "Time", "Venue", "Agenda"].map(
      (h) =>
        new TableCell({
          borders,
          shading: { fill: "1e3a5f", type: ShadingType.CLEAR, color: "auto" },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT, size: 20 })] })],
        }),
    ),
  });
  const rows = meetings.map((m) => {
    const cells: Array<string | string[]> = [
      fmtDate(m.date),
      dayOfWeek(m.date),
      m.companyName,
      m.type,
      fmtTime(m.time),
      m.venue || "—",
      m.agenda.length ? m.agenda.map((a, i) => `${i + 1}. ${a}`) : ["—"],
    ];
    return new TableRow({
      children: cells.map(
        (v) =>
          new TableCell({
            borders,
            margins: { top: 80, bottom: 80, left: 120, right: 120 },
            children: (Array.isArray(v) ? v : [v]).map(
              (line) => new Paragraph({ children: [new TextRun({ text: line, size: 18, font: FONT })] }),
            ),
          }),
      ),
    });
  });
  const table = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1100, 900, 1700, 700, 800, 1860, 2300],
    rows: [head, ...rows],
  });

  const children: (Paragraph | Table)[] = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "MEETINGS SUMMARY", bold: true, size: 32, font: FONT, underline: {} })],
    }),
    p(`Period: ${from ? fmtDate(from) : "(All)"}  to  ${to ? fmtDate(to) : "(All)"}`, { center: true }),
    p(`Total Meetings: ${meetings.length}`, { center: true }),
    spacer(),
    table,
  ];
  const blob = await Packer.toBlob(buildDoc(children));
  await downloadDocx(blob, `Meetings_Summary_${from || "all"}_${to || "all"}.docx`);
}

// ---- Reprint a saved meeting (with SRN stamp) ----

export async function reprintMeeting(
  m: MeetingRecord,
  c: Company,
  directors: Director[],
  shareholders: Shareholder[],
) {
  if (!m.input) return;
  const stampLines = (m.filings || []).filter((f) => f.srn || f.date).map((f) => `${f.form ? f.form + " " : ""}SRN ${f.srn || "—"} | ${f.date ? fmtDate(f.date) : "—"}`);
  const stamp = stampLines.length ? `Filed: ${stampLines.join("   •   ")}` : "REPRINT";
  await generateAllInOne(c, m.input, directors, shareholders, { skipPersist: true, stamp });
}
