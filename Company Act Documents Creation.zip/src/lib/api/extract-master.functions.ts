import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SCHEMAS: Record<string, string> = {
  company: `{
  "name": string, "cin": string, "registeredOffice": string, "email": string, "phone": string,
  "authorisedCapital": string, "paidUpCapital": string, "dateOfIncorporation": "YYYY-MM-DD",
  "rocJurisdiction": string, "pan": string, "gstin": string,
  "csName": string, "csMembershipNo": string, "auditorName": string, "auditorFirmRegNo": string
}`,
  director: `{
  "title": "Mr."|"Ms."|"Mrs."|"M/s", "name": string, "din": string, "pan": string,
  "address": string, "email": string, "mobile": string, "dateOfAppointment": "YYYY-MM-DD",
  "category": "Executive"|"Non-Executive"|"Independent", "designation": string,
  "fathersName": string, "dob": "YYYY-MM-DD", "nationality": string, "occupation": string
}`,
  shareholder: `{
  "title": "Mr."|"Ms."|"Mrs."|"M/s", "name": string, "pan": string, "address": string,
  "email": string, "folioNo": string, "shares": number,
  "shareClass": "Equity"|"Preference"|"CCPS"|"OCPS", "percentage": number
}`,
  auditor: `{
  "firmName": string, "frn": string, "authorizedPersonName": string,
  "designation": "Partner"|"Proprietor", "membershipNo": string, "email": string,
  "phone": string, "place": string, "address": string
}`,
};

export const extractMasterFromFile = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      entity: z.enum(["company", "director", "shareholder", "auditor"]),
      fileName: z.string(),
      mimeType: z.string(),
      fileBase64: z.string(), // no data: prefix
    }),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI is not configured (LOVABLE_API_KEY missing)");

    const schema = SCHEMAS[data.entity];
    const dataUrl = `data:${data.mimeType};base64,${data.fileBase64}`;

    const systemMsg =
      `You extract structured data from Indian MCA / ROC forms, MCA master-data print-outs, incorporation certificates, PANs, DIN allotment letters, shareholder registers, auditor letters and similar documents. ` +
      `Return ONLY a JSON object matching this TypeScript-like schema (omit unknown fields, do NOT invent values): ${schema}. ` +
      `If the document lists multiple ${data.entity} records, return the FIRST one only. ` +
      `Dates must be ISO YYYY-MM-DD. Capital / share counts as digits only (no commas or ₹).`;


    const mt = data.mimeType.toLowerCase();
    const isImage = mt.startsWith("image/");
    const isPdf = mt.includes("pdf");

    const attachment = isImage
      ? { type: "image_url" as const, image_url: { url: dataUrl } }
      : {
          type: "file" as const,
          file: {
            filename: data.fileName,
            file_data: dataUrl,
          },
        };

    if (!isImage && !isPdf) {
      throw new Error(
        `Unsupported file type "${data.mimeType}". Upload a PDF or image (JPG/PNG/WEBP). Convert Word/Excel to PDF first.`,
      );
    }

    const body = {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemMsg },
        {
          role: "user",
          content: [
            { type: "text", text: `Extract ${data.entity} details from this file (${data.fileName}). Return JSON only. If the document is an MCA master-data print-out, read the director table (DIN, Name, Designation, Date of Appointment, PAN, etc.).` },
            attachment,
          ],
        },
      ],
      response_format: { type: "json_object" },
    };


    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("AI rate limit reached. Try again shortly.");
      if (res.status === 402) throw new Error("AI credits exhausted. Add credits in workspace settings.");
      throw new Error(`AI extraction failed (${res.status}): ${text.slice(0, 200)}`);
    }

    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const content = json.choices?.[0]?.message?.content ?? "{}";
    return { fieldsJson: content };
  });

export const extractMasterListFromFile = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      entity: z.enum(["director", "shareholder"]),
      fileName: z.string(),
      mimeType: z.string(),
      fileBase64: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI is not configured (LOVABLE_API_KEY missing)");

    const schema = SCHEMAS[data.entity];
    const dataUrl = `data:${data.mimeType};base64,${data.fileBase64}`;

    const systemMsg =
      `You extract structured data from Indian MCA / ROC forms, MCA master-data print-outs, incorporation certificates, shareholder registers, share allotment lists, DIR-12 attachments and similar documents. ` +
      `Return ONLY a JSON object of the form {"items": ${schema}[]} containing EVERY ${data.entity} record found in the document. Do not omit rows. Do not invent values (leave unknown fields out). ` +
      `Dates must be ISO YYYY-MM-DD. Capital / share counts as digits only (no commas or ₹).`;

    const mt = data.mimeType.toLowerCase();
    const isImage = mt.startsWith("image/");
    const isPdf = mt.includes("pdf");
    if (!isImage && !isPdf) {
      throw new Error(
        `Unsupported file type "${data.mimeType}". Upload a PDF or image (JPG/PNG/WEBP). Convert Word/Excel to PDF first.`,
      );
    }

    const attachment = isImage
      ? { type: "image_url" as const, image_url: { url: dataUrl } }
      : { type: "file" as const, file: { filename: data.fileName, file_data: dataUrl } };

    const body = {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemMsg },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Extract ALL ${data.entity} records from this file (${data.fileName}) and return JSON of shape {"items":[...]}. Include every row of the ${data.entity} table.`,
            },
            attachment,
          ],
        },
      ],
      response_format: { type: "json_object" },
    };

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("AI rate limit reached. Try again shortly.");
      if (res.status === 402) throw new Error("AI credits exhausted. Add credits in workspace settings.");
      throw new Error(`AI extraction failed (${res.status}): ${text.slice(0, 200)}`);
    }

    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const content = json.choices?.[0]?.message?.content ?? "{}";
    return { itemsJson: content };
  });


