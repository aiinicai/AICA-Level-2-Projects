import { useSyncExternalStore } from "react";
import type { Company, Director, Shareholder, MeetingRecord, DraftRecord, Auditor } from "./types";

type State = {
  companies: Company[];
  directors: Director[];
  shareholders: Shareholder[];
  auditors: Auditor[];
  meetings: MeetingRecord[];
  drafts: DraftRecord[];
};

const KEY = "cs-compliance-store-v1";
const EMPTY: State = { companies: [], directors: [], shareholders: [], auditors: [], meetings: [], drafts: [] };

let state: State = EMPTY;
let initialized = false;
const listeners = new Set<() => void>();

function init() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
  } catch {}
}

function emit() {
  if (typeof window !== "undefined") {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  }
  listeners.forEach((l) => l());
}

export const store = {
  get: () => state,
  setCompanies(fn: (c: Company[]) => Company[]) {
    state = { ...state, companies: fn(state.companies) };
    emit();
  },
  setDirectors(fn: (d: Director[]) => Director[]) {
    state = { ...state, directors: fn(state.directors) };
    emit();
  },
  setShareholders(fn: (s: Shareholder[]) => Shareholder[]) {
    state = { ...state, shareholders: fn(state.shareholders) };
    emit();
  },
  setAuditors(fn: (a: Auditor[]) => Auditor[]) {
    state = { ...state, auditors: fn(state.auditors) };
    emit();
  },
  setMeetings(fn: (m: MeetingRecord[]) => MeetingRecord[]) {
    state = { ...state, meetings: fn(state.meetings) };
    emit();
  },
  setDrafts(fn: (d: DraftRecord[]) => DraftRecord[]) {
    state = { ...state, drafts: fn(state.drafts) };
    emit();
  },
  replaceAll(next: Partial<State>) {
    state = { ...EMPTY, ...next };
    emit();
  },
  reset() {
    state = EMPTY;
    emit();
  },
};

export function subscribeStore(cb: (s: State) => void) {
  init();
  const wrapped = () => cb(state);
  listeners.add(wrapped);
  return () => { listeners.delete(wrapped); };
}

function subscribe(cb: () => void) {
  init();
  listeners.add(cb);
  return () => { listeners.delete(cb); };
}


export function useStore<T>(selector: (s: State) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(state),
    () => selector(EMPTY),
  );
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}
