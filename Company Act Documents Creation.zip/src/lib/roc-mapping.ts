export interface RocMapping {
  form: string;
  dueDays: number;
  description: string;
  attachments: string[];
  baseFee: string;
}

export const ROC_MAP: Record<string, RocMapping> = {
  "Appointment of Director": {
    form: "DIR-12",
    dueDays: 30,
    description: "Particulars of appointment of directors",
    attachments: ["DIR-2 Consent", "Board Resolution", "Letter of Appointment"],
    baseFee: "₹300 – ₹600 (capital based)",
  },
  "Appointment of Additional Director": {
    form: "DIR-12",
    dueDays: 30,
    description: "Particulars of appointment of directors",
    attachments: ["DIR-2 Consent", "Board Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Appointment of Managing Director": {
    form: "DIR-12 + MR-1",
    dueDays: 30,
    description: "MD/WTD appointment particulars",
    attachments: ["Board Resolution", "Special Resolution (if any)", "MR-1"],
    baseFee: "₹300 – ₹600",
  },
  "Appointment of Whole Time Director": {
    form: "DIR-12 + MR-1",
    dueDays: 30,
    description: "WTD appointment particulars",
    attachments: ["Board Resolution", "MR-1"],
    baseFee: "₹300 – ₹600",
  },
  "Appointment of Independent Director": {
    form: "DIR-12",
    dueDays: 30,
    description: "Independent director appointment",
    attachments: ["DIR-2", "Declaration of Independence", "Board Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Resignation of Director": {
    form: "DIR-12",
    dueDays: 30,
    description: "Cessation of director",
    attachments: ["Resignation Letter", "Board Resolution", "DIR-11 (by director)"],
    baseFee: "₹300 – ₹600",
  },
  "Change in Designation": {
    form: "DIR-12",
    dueDays: 30,
    description: "Change in director designation",
    attachments: ["Board Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Removal of Director": {
    form: "DIR-12",
    dueDays: 30,
    description: "Removal under Section 169",
    attachments: ["Special Notice", "Ordinary Resolution", "Representations"],
    baseFee: "₹300 – ₹600",
  },
  "Increase in Authorised Share Capital": {
    form: "SH-7",
    dueDays: 30,
    description: "Notice to ROC of alteration of share capital",
    attachments: ["Altered MOA", "Special Resolution", "Notice & Explanatory Statement"],
    baseFee: "Capital-based stamp duty + filing fee",
  },
  "Rights Issue": {
    form: "PAS-3",
    dueDays: 30,
    description: "Return of allotment",
    attachments: ["List of Allottees", "Board Resolution", "Valuation (if any)"],
    baseFee: "₹300 – ₹600",
  },
  "Private Placement": {
    form: "PAS-3",
    dueDays: 15,
    description: "Return of allotment (15 days from allotment)",
    attachments: ["PAS-4 (Offer Letter)", "Special Resolution", "Valuation Report", "List of Allottees"],
    baseFee: "₹300 – ₹600",
  },
  "Preferential Allotment": {
    form: "PAS-3",
    dueDays: 30,
    description: "Return of allotment for preferential issue",
    attachments: ["Special Resolution", "Valuation Report", "List of Allottees"],
    baseFee: "₹300 – ₹600",
  },
  "Issue of Equity Shares": {
    form: "PAS-3",
    dueDays: 30,
    description: "Return of allotment",
    attachments: ["Board Resolution", "List of Allottees"],
    baseFee: "₹300 – ₹600",
  },
  "Issue of Preference Shares": {
    form: "PAS-3 + MGT-14",
    dueDays: 30,
    description: "Allotment of preference shares",
    attachments: ["Special Resolution", "Terms of Issue", "List of Allottees"],
    baseFee: "₹300 – ₹600",
  },
  "Bonus Issue": {
    form: "PAS-3",
    dueDays: 30,
    description: "Return of allotment for bonus shares",
    attachments: ["Board Resolution", "Ordinary Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "ESOP": {
    form: "MGT-14",
    dueDays: 30,
    description: "Filing of special resolution for ESOP",
    attachments: ["Special Resolution", "ESOP Scheme"],
    baseFee: "₹300 – ₹600",
  },
  "Sweat Equity": {
    form: "PAS-3 + MGT-14",
    dueDays: 30,
    description: "Sweat equity allotment",
    attachments: ["Special Resolution", "Valuation Report"],
    baseFee: "₹300 – ₹600",
  },
  "Change in Name": {
    form: "INC-24",
    dueDays: 60,
    description: "Application for approval of change of name",
    attachments: ["Special Resolution", "Altered MOA & AOA", "Notice & Explanatory Statement"],
    baseFee: "₹1,000",
  },
  "Change in Registered Office": {
    form: "INC-22",
    dueDays: 30,
    description: "Notice of situation of registered office",
    attachments: ["Board/Special Resolution", "Address Proof", "NOC from owner"],
    baseFee: "₹300 – ₹600",
  },
  "Creation of Charge": {
    form: "CHG-1",
    dueDays: 30,
    description: "Registration of creation/modification of charge",
    attachments: ["Charge Document", "Board Resolution"],
    baseFee: "Capital-based",
  },
  "Appointment of Auditor": {
    form: "ADT-1",
    dueDays: 15,
    description: "Notice of appointment of auditor (15 days from AGM)",
    attachments: ["Auditor Consent", "Board Resolution", "Ordinary Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Resignation of Auditor": {
    form: "ADT-3",
    dueDays: 30,
    description: "Notice of resignation by auditor",
    attachments: ["Resignation Letter"],
    baseFee: "₹300 – ₹600",
  },
  "Opening Bank Account": {
    form: "—",
    dueDays: 0,
    description: "Internal board resolution; no ROC filing",
    attachments: ["Certified True Copy of BR"],
    baseFee: "—",
  },
  "Borrowing Powers": {
    form: "MGT-14",
    dueDays: 30,
    description: "Filing of special resolution u/s 180(1)(c)",
    attachments: ["Special Resolution", "Notice & Explanatory Statement"],
    baseFee: "₹300 – ₹600",
  },
  "Loan under Section 186": {
    form: "MGT-14",
    dueDays: 30,
    description: "Special resolution if limits exceeded",
    attachments: ["Special Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Investment under Section 186": {
    form: "MGT-14",
    dueDays: 30,
    description: "Special resolution if limits exceeded",
    attachments: ["Special Resolution"],
    baseFee: "₹300 – ₹600",
  },
  "Related Party Transaction": {
    form: "MGT-14",
    dueDays: 30,
    description: "Special resolution u/s 188 (if limits exceeded)",
    attachments: ["Special Resolution", "Audit Committee Approval"],
    baseFee: "₹300 – ₹600",
  },
  "Adoption of Accounts": {
    form: "AOC-4",
    dueDays: 30,
    description: "Filing of financial statements (30 days from AGM)",
    attachments: ["Audited Financials", "Board's Report", "Auditor's Report"],
    baseFee: "Capital-based",
  },
  "Reclassification of Capital": {
    form: "SH-7",
    dueDays: 30,
    description: "Reclassification of share capital",
    attachments: ["Special Resolution", "Altered MOA"],
    baseFee: "Capital-based",
  },
};

export function getRocMapping(purpose: string): RocMapping | undefined {
  return ROC_MAP[purpose];
}
