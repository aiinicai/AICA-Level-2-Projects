import { useEffect, useRef, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { store, subscribeStore } from "@/lib/store";

// Users sign up with just a username + password. We synthesize an email
// under a reserved local domain so Supabase can store the credentials
// without requiring any private details.
const DOMAIN = "lex.local";
const toEmail = (u: string) => `${u.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "")}@${DOMAIN}`;
const fromEmail = (e?: string | null) => (e ? e.replace(new RegExp(`@${DOMAIN}$`), "") : "");

export function signOut() {
  supabase.auth.signOut().finally(() => {
    store.reset();
    if (typeof window !== "undefined") window.location.reload();
  });
}

export function LoginGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, s) => {
      setSession(s);
      if (!s) setHydrated(false);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  // Cloud sync: on sign-in, load user_data row; subscribe to store to save changes.
  const savingRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suppressSaveRef = useRef(false);
  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("user_data")
        .select("data")
        .eq("user_id", session.user.id)
        .maybeSingle();
      if (cancelled) return;
      if (error) {
        console.error(error);
        toast.error("Could not load your saved data");
        setHydrated(true);
        return;
      }
      suppressSaveRef.current = true;
      if (data?.data) {
        store.replaceAll(data.data as Parameters<typeof store.replaceAll>[0]);
      } else {
        store.reset();
        await supabase.from("user_data").upsert({ user_id: session.user.id, data: {} });
      }
      setTimeout(() => { suppressSaveRef.current = false; }, 0);
      setHydrated(true);
    })();

    const unsub = subscribeStore((s) => {
      if (suppressSaveRef.current) return;
      if (savingRef.current) clearTimeout(savingRef.current);
      savingRef.current = setTimeout(async () => {
        const { error } = await supabase
          .from("user_data")
          .upsert({ user_id: session.user.id, data: JSON.parse(JSON.stringify(s)), updated_at: new Date().toISOString() });

        if (error) console.error("cloud save failed", error);
      }, 600);
    });
    return () => {
      cancelled = true;
      unsub();
      if (savingRef.current) clearTimeout(savingRef.current);
    };
  }, [session]);

  if (!ready) return null;
  if (!session) return <AuthScreen />;
  if (!hydrated) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="text-sm text-muted-foreground">Loading your data…</div>
      </div>
    );
  }
  return <>{children}</>;
}

function AuthScreen() {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [tab, setTab] = useState<"signin" | "signup">("signin");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const u = userId.trim();
    if (!u) return toast.error("User ID is required");
    if (password.length < 6) return toast.error("Password must be at least 6 characters");
    setBusy(true);
    try {
      const email = toEmail(u);
      if (tab === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created — you're signed in");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success(`Welcome back, ${fromEmail(email)}`);
      }
    } catch (err) {
      toast.error((err as Error).message || "Authentication failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm p-6">
        <div className="mb-4">
          <div className="font-serif text-xl font-semibold text-foreground">Lex Secretaria</div>
          <div className="text-xs text-muted-foreground">Corporate Resolution Automation</div>
        </div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as "signin" | "signup")}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label htmlFor="uid">User ID</Label>
              <Input
                id="uid"
                autoComplete="username"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="e.g. rahul"
                required
              />
            </div>
            <div>
              <Label htmlFor="pwd">Password</Label>
              <Input
                id="pwd"
                type="password"
                autoComplete={tab === "signup" ? "new-password" : "current-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <TabsContent value="signin" className="m-0">
              <Button type="submit" className="w-full" disabled={busy}>
                {busy ? "Signing in…" : "Sign In"}
              </Button>
            </TabsContent>
            <TabsContent value="signup" className="m-0">
              <Button type="submit" className="w-full" disabled={busy}>
                {busy ? "Creating account…" : "Create Account"}
              </Button>
            </TabsContent>
          </form>
        </Tabs>
        <p className="mt-4 text-xs text-muted-foreground">
          No email or personal details needed. The same User ID and password work on any computer —
          your saved data follows you automatically.
        </p>
      </Card>
    </div>
  );
}
