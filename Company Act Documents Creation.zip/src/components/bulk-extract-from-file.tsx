import { useRef, useState } from "react";
import { Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useServerFn } from "@tanstack/react-start";
import { extractMasterListFromFile } from "@/lib/api/extract-master.functions";
import { toast } from "sonner";

type Entity = "director" | "shareholder";

const ACCEPT = ".pdf,.jpg,.jpeg,.png,.webp,image/*,application/pdf";

export function BulkExtractFromFileButton({
  entity,
  disabled,
  onExtract,
  label,
}: {
  entity: Entity;
  disabled?: boolean;
  onExtract: (items: Record<string, unknown>[]) => number;
  label?: string;
}) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const extract = useServerFn(extractMasterListFromFile);

  const handle = async (file: File) => {
    if (file.size > 8 * 1024 * 1024) {
      toast.error("File too large (max 8 MB).");
      return;
    }
    setBusy(true);
    const t = toast.loading(`Reading document — extracting all ${entity}s…`);
    try {
      const b64 = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => {
          const s = String(r.result || "");
          const i = s.indexOf(",");
          resolve(i >= 0 ? s.slice(i + 1) : s);
        };
        r.onerror = () => reject(r.error);
        r.readAsDataURL(file);
      });
      const mime = file.type || "application/octet-stream";
      const { itemsJson } = await extract({
        data: { entity, fileName: file.name, mimeType: mime, fileBase64: b64 },
      });
      let parsed: unknown = {};
      try {
        parsed = JSON.parse(itemsJson);
      } catch {
        const m = itemsJson.match(/\{[\s\S]*\}/);
        if (m) parsed = JSON.parse(m[0]);
      }
      const items =
        (parsed as { items?: Record<string, unknown>[] })?.items ??
        (Array.isArray(parsed) ? (parsed as Record<string, unknown>[]) : []);
      if (!items.length) {
        toast.error("No records found in the file.", { id: t });
        return;
      }
      const added = onExtract(items);
      toast.success(`Added ${added} ${entity}${added === 1 ? "" : "s"} — please verify.`, { id: t });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Extraction failed";
      toast.error(msg, { id: t });
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  };

  return (
    <>
      <input
        ref={ref}
        type="file"
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void handle(f);
        }}
      />
      <Button
        type="button"
        variant="outline"
        disabled={busy || disabled}
        onClick={() => ref.current?.click()}
      >
        {busy ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
        {label ?? `Bulk upload ${entity}s`}
      </Button>
    </>
  );
}
