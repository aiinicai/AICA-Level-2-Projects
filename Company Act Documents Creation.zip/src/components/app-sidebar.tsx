import { Link, useRouterState } from "@tanstack/react-router";
import {
  Building2,
  Users,
  PieChart,
  FileText,
  CalendarClock,
  ShieldCheck,
  ScrollText,
  BadgeCheck,
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const masters = [
  { title: "Companies", url: "/companies", icon: Building2 },
  { title: "Directors", url: "/directors", icon: Users },
  { title: "Shareholders", url: "/shareholders", icon: PieChart },
  { title: "Auditors", url: "/auditors", icon: BadgeCheck },
];

const workflow = [
  { title: "Transaction Sheet", url: "/transactions", icon: FileText },
  { title: "Drafts", url: "/drafts", icon: FileText },
  { title: "Meetings Register", url: "/meetings", icon: CalendarClock },
  { title: "ROC Calendar", url: "/calendar", icon: CalendarClock },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const isActive = (p: string) => pathname === p;

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/" className="flex items-center gap-2 px-2 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
            <ScrollText className="h-5 w-5" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-serif text-base font-semibold text-sidebar-foreground">
                Lex Secretaria
              </span>
              <span className="text-[10px] uppercase tracking-widest text-sidebar-foreground/60">
                CS Compliance Suite
              </span>
            </div>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Masters</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {masters.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Workflow</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {workflow.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {!collapsed && (
        <div className="mt-auto border-t border-sidebar-border p-3">
          <div className="flex items-center gap-2 text-xs text-sidebar-foreground/70">
            <ShieldCheck className="h-4 w-4" />
            <span>Companies Act, 2013</span>
          </div>
        </div>
      )}
    </Sidebar>
  );
}
