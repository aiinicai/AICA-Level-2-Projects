import { useRef, useState } from "react";
import { Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useServerFn } from "@tanstack/react-start";
import { extractMasterFromFile } from "@/lib/api/extract-master.functions";
import { toast } from "sonner";

type Entity = "company" | "director" | "shareholder" | "auditor";

const ACCEPT = ".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx,.xls,.xlsx,image/*,application/pdf";

export function ExtractFromFileButton({
  entity,
  onExtract,
  label = "Auto-fill from file",
}: {
  entity: Entity;
  onExtract: (fields: Record<string, unknown>) => void;
  label?: string;
}) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const extract = useServerFn(extractMasterFromFile);

  const handle = async (file: File) => {
    if (file.size > 8 * 1024 * 1024) {
      toast.error("File too large (max 8 MB).");
      return;
    }
    setBusy(true);
    const t = toast.loading("Reading document…");
    try {
      const b64 = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => {
          const s = String(r.result || "");
          const i = s.indexOf(",");
          resolve(i >= 0 ? s.slice(i + 1) : s);
        };
        r.onerror = () => reject(r.error);
        r.readAsDataURL(file);
      });
      const mime = file.type || "application/octet-stream";
      const { fieldsJson } = await extract({
        data: { entity, fileName: file.name, mimeType: mime, fileBase64: b64 },
      });
      let fields: Record<string, unknown> = {};
      try {
        fields = JSON.parse(fieldsJson);
      } catch {
        const m = fieldsJson.match(/\{[\s\S]*\}/);
        if (m) fields = JSON.parse(m[0]);
      }
      onExtract(fields);
      toast.success("Form auto-filled — please verify.", { id: t });

    } catch (e) {
      const msg = e instanceof Error ? e.message : "Extraction failed";
      toast.error(msg, { id: t });
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  };

  return (
    <>
      <input
        ref={ref}
        type="file"
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void handle(f);
        }}
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={busy}
        onClick={() => ref.current?.click()}
      >
        {busy ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
        {label}
      </Button>
    </>
  );
}
