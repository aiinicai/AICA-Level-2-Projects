import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, Users } from "lucide-react";
import { store, uid, useStore } from "@/lib/store";
import type { Director, DirectorCategory, Title } from "@/lib/types";
import { TITLE_OPTIONS } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Field, PageHeader, EmptyState } from "./companies";
import { ExtractFromFileButton } from "@/components/extract-from-file";
import { BulkExtractFromFileButton } from "@/components/bulk-extract-from-file";


export const Route = createFileRoute("/directors")({
  head: () => ({
    meta: [
      { title: "Directors — Lex Secretaria" },
      { name: "description", content: "Manage Director Master with DIN, PAN, category and DSC status." },
    ],
  }),
  component: DirectorsPage,
});

const empty: Director = {
  id: "", companyId: "", title: "Mr.", name: "", din: "", pan: "", address: "",
  email: "", mobile: "", dateOfAppointment: "", category: "Executive", dscAvailable: false,
};

function DirectorsPage() {
  const companies = useStore((s) => s.companies);
  const directors = useStore((s) => s.directors);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Director>(empty);
  const [filter, setFilter] = useState<string>("all");

  const list = filter === "all" ? directors : directors.filter((d) => d.companyId === filter);

  const save = () => {
    if (!draft.name.trim() || !draft.companyId) return toast.error("Name and Company are required");
    if (draft.id) {
      store.setDirectors((ds) => ds.map((d) => (d.id === draft.id ? draft : d)));
      toast.success("Director updated");
    } else {
      store.setDirectors((ds) => [...ds, { ...draft, id: uid() }]);
      toast.success("Director added");
    }
    setOpen(false);
    setDraft(empty);
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Director Master"
        subtitle="DIN, PAN, category and DSC status for every director."
        action={
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-56"><SelectValue placeholder="Filter by company" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <BulkExtractFromFileButton
              entity="director"
              onExtract={(items) => {
                if (filter === "all" || !filter) {
                  toast.error("Select a company from the filter first.");
                  return 0;
                }
                const cats: DirectorCategory[] = ["Executive", "Non-Executive", "Independent"];
                const toAdd: Director[] = items.map((f) => ({
                  id: uid(),
                  companyId: filter,
                  title: (TITLE_OPTIONS as readonly string[]).includes(String(f.title))
                    ? (f.title as Title)
                    : "Mr.",
                  name: typeof f.name === "string" ? f.name : "",
                  din: typeof f.din === "string" ? f.din : "",
                  pan: typeof f.pan === "string" ? f.pan : "",
                  address: typeof f.address === "string" ? f.address : "",
                  email: typeof f.email === "string" ? f.email : "",
                  mobile: typeof f.mobile === "string" ? f.mobile : "",
                  dateOfAppointment: typeof f.dateOfAppointment === "string" ? f.dateOfAppointment : "",
                  category: cats.includes(f.category as DirectorCategory)
                    ? (f.category as DirectorCategory)
                    : "Executive",
                  designation: typeof f.designation === "string" ? f.designation : undefined,
                  dscAvailable: false,
                })).filter((d) => d.name.trim());
                if (!toAdd.length) return 0;
                store.setDirectors((ds) => [...ds, ...toAdd]);
                return toAdd.length;
              }}
            />
            <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setDraft(empty); }}>
              <DialogTrigger asChild>
                <Button disabled={companies.length === 0}><Plus className="h-4 w-4 mr-1" /> Add Director</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle className="font-serif">{draft.id ? "Edit" : "New"} Director</DialogTitle></DialogHeader>
                <div className="flex justify-end">
                  <ExtractFromFileButton
                    entity="director"
                    onExtract={(f) =>
                      setDraft((d) => ({
                        ...d,
                        ...(Object.fromEntries(
                          Object.entries(f).filter(([k, v]) => k in d && typeof v === "string" && v),
                        ) as Partial<Director>),
                      }))
                    }
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2 py-2">
                  <Field label="Company *" className="md:col-span-2">
                    <Select value={draft.companyId} onValueChange={(v) => setDraft({ ...draft, companyId: v })}>
                      <SelectTrigger><SelectValue placeholder="Select company" /></SelectTrigger>
                      <SelectContent>
                        {companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Title">
                    <Select value={draft.title || "Mr."} onValueChange={(v) => setDraft({ ...draft, title: v as Title })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {TITLE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Name *"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
                  <Field label="DIN"><Input value={draft.din} onChange={(e) => setDraft({ ...draft, din: e.target.value })} /></Field>
                  <Field label="PAN"><Input value={draft.pan} onChange={(e) => setDraft({ ...draft, pan: e.target.value })} /></Field>
                  <Field label="Date of Appointment"><Input type="date" value={draft.dateOfAppointment} onChange={(e) => setDraft({ ...draft, dateOfAppointment: e.target.value })} /></Field>
                  <Field label="Email"><Input type="email" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
                  <Field label="Mobile"><Input value={draft.mobile} onChange={(e) => setDraft({ ...draft, mobile: e.target.value })} /></Field>
                  <Field label="Address" className="md:col-span-2"><Textarea rows={2} value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} /></Field>
                  <Field label="Category">
                    <Select value={draft.category} onValueChange={(v) => setDraft({ ...draft, category: v as DirectorCategory })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Executive">Executive</SelectItem>
                        <SelectItem value="Non-Executive">Non-Executive</SelectItem>
                        <SelectItem value="Independent">Independent</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="DSC Available">
                    <div className="flex items-center gap-2 h-10">
                      <Switch checked={draft.dscAvailable} onCheckedChange={(v) => setDraft({ ...draft, dscAvailable: v })} />
                      <span className="text-sm text-muted-foreground">{draft.dscAvailable ? "Yes" : "No"}</span>
                    </div>
                  </Field>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button onClick={save}>Save</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      {list.length === 0 ? (
        <EmptyState icon={<Users className="h-10 w-10" />} text={companies.length === 0 ? "Add a company first." : "No directors yet."} />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Company</th>
                  <th className="px-4 py-3 text-left">DIN</th>
                  <th className="px-4 py-3 text-left">Category</th>
                  <th className="px-4 py-3 text-left">Appointed</th>
                  <th className="px-4 py-3 text-left">DSC</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {list.map((d) => {
                  const co = companies.find((c) => c.id === d.companyId);
                  return (
                    <tr key={d.id} className="border-t hover:bg-muted/30">
                      <td className="px-4 py-3 font-medium">{d.name}</td>
                      <td className="px-4 py-3 text-muted-foreground">{co?.name || "—"}</td>
                      <td className="px-4 py-3 font-mono text-xs">{d.din || "—"}</td>
                      <td className="px-4 py-3"><Badge variant="secondary">{d.category}</Badge></td>
                      <td className="px-4 py-3 text-muted-foreground">{d.dateOfAppointment || "—"}</td>
                      <td className="px-4 py-3">{d.dscAvailable ? <Badge className="bg-success text-success-foreground">Yes</Badge> : <Badge variant="outline">No</Badge>}</td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setDraft(d); setOpen(true); }}>✎</Button>
                        <Button variant="ghost" size="icon" onClick={() => { store.setDirectors((ds) => ds.filter((x) => x.id !== d.id)); toast.success("Removed"); }}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
