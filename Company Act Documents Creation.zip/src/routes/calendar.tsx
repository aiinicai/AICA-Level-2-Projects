import { createFileRoute } from "@tanstack/react-router";
import { ROC_MAP } from "@/lib/roc-mapping";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "./companies";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Search } from "lucide-react";

export const Route = createFileRoute("/calendar")({
  head: () => ({
    meta: [
      { title: "ROC Compliance Reference — Lex Secretaria" },
      { name: "description", content: "Companies Act, 2013 ROC form mapping with due dates and attachments." },
    ],
  }),
  component: CalendarPage,
});

function CalendarPage() {
  const [q, setQ] = useState("");
  const entries = Object.entries(ROC_MAP).filter(
    ([k, v]) =>
      !q ||
      k.toLowerCase().includes(q.toLowerCase()) ||
      v.form.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="ROC Compliance Reference"
        subtitle="Companies Act, 2013 — form, due date and attachments at a glance."
      />

      <div className="mb-6 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-9" placeholder="Search purpose or form (e.g. DIR-12, Rights)" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Purpose</th>
                <th className="px-4 py-3 text-left">Form</th>
                <th className="px-4 py-3 text-left">Due</th>
                <th className="px-4 py-3 text-left">Fee</th>
                <th className="px-4 py-3 text-left">Key Attachments</th>
              </tr>
            </thead>
            <tbody>
              {entries.map(([purpose, m]) => (
                <tr key={purpose} className="border-t hover:bg-muted/20 align-top">
                  <td className="px-4 py-3 font-medium">{purpose}</td>
                  <td className="px-4 py-3"><Badge className="bg-primary text-primary-foreground font-mono">{m.form}</Badge></td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{m.dueDays > 0 ? `${m.dueDays} days` : "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{m.baseFee}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {m.attachments.map((a) => <Badge key={a} variant="secondary" className="text-[10px] font-normal">{a}</Badge>)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <p className="mt-6 text-xs text-muted-foreground">
        Note: Filing fees vary by share capital under the Companies (Registration Offices and Fees) Rules, 2014. Always verify on the MCA portal before filing.
      </p>
    </div>
  );
}
