import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, PieChart } from "lucide-react";
import { store, uid, useStore } from "@/lib/store";
import type { Shareholder, Title } from "@/lib/types";
import { TITLE_OPTIONS } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Field, PageHeader, EmptyState } from "./companies";
import { ExtractFromFileButton } from "@/components/extract-from-file";
import { BulkExtractFromFileButton } from "@/components/bulk-extract-from-file";


export const Route = createFileRoute("/shareholders")({
  head: () => ({
    meta: [
      { title: "Shareholders — Lex Secretaria" },
      { name: "description", content: "Maintain shareholding pattern per company." },
    ],
  }),
  component: ShareholdersPage,
});

const empty: Shareholder = {
  id: "", companyId: "", title: "Mr.", name: "", pan: "", address: "", email: "",
  shares: 0, shareClass: "Equity", folioNo: "", percentage: 0,
};

function ShareholdersPage() {
  const companies = useStore((s) => s.companies);
  const shareholders = useStore((s) => s.shareholders);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Shareholder>(empty);
  const [filter, setFilter] = useState<string>(companies[0]?.id || "all");

  const list = filter === "all" ? shareholders : shareholders.filter((s) => s.companyId === filter);
  const totalShares = list.reduce((s, x) => s + Number(x.shares || 0), 0);

  const save = () => {
    if (!draft.name.trim() || !draft.companyId) return toast.error("Name and Company are required");
    const pct = totalShares + Number(draft.shares || 0) > 0
      ? (Number(draft.shares || 0) / (totalShares + Number(draft.shares || 0))) * 100
      : 0;
    const final = { ...draft, percentage: Number(draft.percentage) || +pct.toFixed(2) };
    if (draft.id) {
      store.setShareholders((ss) => ss.map((s) => (s.id === draft.id ? final : s)));
      toast.success("Shareholder updated");
    } else {
      store.setShareholders((ss) => [...ss, { ...final, id: uid() }]);
      toast.success("Shareholder added");
    }
    setOpen(false);
    setDraft(empty);
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Shareholder Master"
        subtitle="Shareholding pattern, folio numbers and percentages."
        action={
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-56"><SelectValue placeholder="Filter by company" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <BulkExtractFromFileButton
              entity="shareholder"
              onExtract={(items) => {
                if (filter === "all" || !filter) {
                  toast.error("Select a company from the filter first.");
                  return 0;
                }
                const toAdd: Shareholder[] = items.map((f) => ({
                  id: uid(),
                  companyId: filter,
                  title: (TITLE_OPTIONS as readonly string[]).includes(String(f.title))
                    ? (f.title as Title)
                    : "Mr.",
                  name: typeof f.name === "string" ? f.name : "",
                  pan: typeof f.pan === "string" ? f.pan : "",
                  address: typeof f.address === "string" ? f.address : "",
                  email: typeof f.email === "string" ? f.email : "",
                  shares: typeof f.shares === "number" ? f.shares : Number(f.shares) || 0,
                  shareClass: typeof f.shareClass === "string" ? f.shareClass : "Equity",
                  folioNo: typeof f.folioNo === "string" ? f.folioNo : "",
                  percentage: typeof f.percentage === "number" ? f.percentage : Number(f.percentage) || 0,
                })).filter((s) => s.name.trim());
                if (!toAdd.length) return 0;
                const totalAfter = [...shareholders, ...toAdd].reduce((sum, x) => sum + Number(x.shares || 0), 0);
                const withPct = toAdd.map((s) =>
                  s.percentage > 0 || totalAfter <= 0
                    ? s
                    : { ...s, percentage: +((Number(s.shares || 0) / totalAfter) * 100).toFixed(2) },
                );
                store.setShareholders((ss) => [...ss, ...withPct]);
                return withPct.length;
              }}
            />
            <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setDraft(empty); }}>
              <DialogTrigger asChild>
                <Button disabled={companies.length === 0}><Plus className="h-4 w-4 mr-1" /> Add Shareholder</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle className="font-serif">{draft.id ? "Edit" : "New"} Shareholder</DialogTitle></DialogHeader>
                <div className="flex justify-end">
                  <ExtractFromFileButton
                    entity="shareholder"
                    onExtract={(f) =>
                      setDraft((d) => ({
                        ...d,
                        ...(f.title && typeof f.title === "string" ? { title: f.title as Title } : {}),
                        ...(typeof f.name === "string" ? { name: f.name } : {}),
                        ...(typeof f.pan === "string" ? { pan: f.pan } : {}),
                        ...(typeof f.address === "string" ? { address: f.address } : {}),
                        ...(typeof f.email === "string" ? { email: f.email } : {}),
                        ...(typeof f.folioNo === "string" ? { folioNo: f.folioNo } : {}),
                        ...(typeof f.shareClass === "string" ? { shareClass: f.shareClass } : {}),
                        ...(typeof f.shares === "number" ? { shares: f.shares } : {}),
                        ...(typeof f.percentage === "number" ? { percentage: f.percentage } : {}),
                      }))
                    }
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2 py-2">
                  <Field label="Company *" className="md:col-span-2">
                    <Select value={draft.companyId} onValueChange={(v) => setDraft({ ...draft, companyId: v })}>
                      <SelectTrigger><SelectValue placeholder="Select company" /></SelectTrigger>
                      <SelectContent>{companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </Field>
                  <Field label="Title">
                    <Select value={draft.title || "Mr."} onValueChange={(v) => setDraft({ ...draft, title: v as Title })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {TITLE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Name *"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
                  <Field label="PAN"><Input value={draft.pan} onChange={(e) => setDraft({ ...draft, pan: e.target.value })} /></Field>
                  <Field label="Email"><Input value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
                  <Field label="Folio No."><Input value={draft.folioNo} onChange={(e) => setDraft({ ...draft, folioNo: e.target.value })} /></Field>
                  <Field label="No. of Shares"><Input type="number" value={draft.shares} onChange={(e) => setDraft({ ...draft, shares: Number(e.target.value) })} /></Field>
                  <Field label="Share Class">
                    <Select value={draft.shareClass} onValueChange={(v) => setDraft({ ...draft, shareClass: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Equity">Equity</SelectItem>
                        <SelectItem value="Preference">Preference</SelectItem>
                        <SelectItem value="CCPS">CCPS</SelectItem>
                        <SelectItem value="OCPS">OCPS</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="% Holding (optional, auto if blank)"><Input type="number" step="0.01" value={draft.percentage || ""} onChange={(e) => setDraft({ ...draft, percentage: Number(e.target.value) })} /></Field>
                  <Field label="Address" className="md:col-span-2"><Textarea rows={2} value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} /></Field>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button onClick={save}>Save</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      {list.length === 0 ? (
        <EmptyState icon={<PieChart className="h-10 w-10" />} text={companies.length === 0 ? "Add a company first." : "No shareholders yet."} />
      ) : (
        <Card className="overflow-hidden">
          <div className="border-b bg-muted/30 px-4 py-3 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Total shareholders: <b className="text-foreground">{list.length}</b></span>
            <span className="text-muted-foreground">Total shares: <b className="text-foreground">{totalShares.toLocaleString("en-IN")}</b></span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Folio</th>
                  <th className="px-4 py-3 text-left">Class</th>
                  <th className="px-4 py-3 text-right">Shares</th>
                  <th className="px-4 py-3 text-right">% Holding</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {list.map((s) => (
                  <tr key={s.id} className="border-t hover:bg-muted/20">
                    <td className="px-4 py-3 font-medium">{s.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{s.folioNo || "—"}</td>
                    <td className="px-4 py-3">{s.shareClass}</td>
                    <td className="px-4 py-3 text-right font-mono">{s.shares.toLocaleString("en-IN")}</td>
                    <td className="px-4 py-3 text-right font-mono">{s.percentage.toFixed(2)}%</td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="icon" onClick={() => { setDraft(s); setOpen(true); }}>✎</Button>
                      <Button variant="ghost" size="icon" onClick={() => { store.setShareholders((ss) => ss.filter((x) => x.id !== s.id)); toast.success("Removed"); }}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
