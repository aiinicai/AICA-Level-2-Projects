import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Download, Sparkles, CheckCircle2, Plus, X, Save, Lock } from "lucide-react";
import { store, useStore, uid } from "@/lib/store";
import {
  PURPOSE_GROUPS,
  TITLE_OPTIONS,
  type ResolutionItem,
  type TransactionInput,
  type Title,
  type FilingRecord,
  type MeetingTypeRef,
  type VenueType,
  type DraftRecord,
} from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Field, PageHeader } from "./companies";
import { getRocMapping } from "@/lib/roc-mapping";
import { generateAllInOne } from "@/lib/document-generator";
import { toast } from "sonner";
import { ExtractFromFileButton } from "@/components/extract-from-file";


export const Route = createFileRoute("/transactions")({
  head: () => ({
    meta: [
      { title: "Transaction Sheet — Lex Secretaria" },
      { name: "description", content: "Multi-resolution input sheet — drafts, lock, generate every Companies Act document." },
    ],
  }),
  component: TransactionsPage,
});

const directorPurposes = PURPOSE_GROUPS.Directors as readonly string[];
const shareCapitalPurposes = ["Increase in Authorised Share Capital", "Reclassification of Capital"];
const shareIssuePurposes = ["Issue of Equity Shares", "Issue of Preference Shares", "Rights Issue", "Bonus Issue", "Private Placement", "Preferential Allotment"];
const resignationPurposes = ["Resignation of Director", "Resignation of Auditor"];

function newResolution(meetingType: MeetingTypeRef = "BOARD"): ResolutionItem {
  return { id: uid(), purpose: "", meetingType };
}

function emptyInput(): TransactionInput {
  return {
    id: uid(),
    companyId: "",
    resolutions: [newResolution("BOARD")],
    boardVenueType: "REGISTERED_OFFICE",
    boardMeetingDate: "",
    boardMeetingTime: "11:00",
    boardMeetingVenue: "",
    generalMeetingType: "EGM",
    gmVenueType: "REGISTERED_OFFICE",
    generalMeetingDate: "",
    generalMeetingTime: "11:00",
    generalMeetingVenue: "",
    noticeIssueDate: "",
    effectiveDate: "",
    authorisedSignatory: "",
    rocFilingPerson: "",
    shorterNotice: false,
    shorterNoticeDate: "",
    shorterNoticePlace: "",
    filings: [],
  };
}

const DRAFT_LOAD_KEY = "lex.draft.load";

function TransactionsPage() {
  const companies = useStore((s) => s.companies);
  const directors = useStore((s) => s.directors);
  const shareholders = useStore((s) => s.shareholders);
  const navigate = useNavigate();
  const [input, setInput] = useState<TransactionInput>(emptyInput());
  const [busy, setBusy] = useState<string | null>(null);
  const [loadedDraftId, setLoadedDraftId] = useState<string | null>(null);
  const [lockConfirm, setLockConfirm] = useState(false);

  // Load from drafts handoff (sessionStorage)
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(DRAFT_LOAD_KEY);
      if (!raw) return;
      sessionStorage.removeItem(DRAFT_LOAD_KEY);
      const payload = JSON.parse(raw) as { draftId: string; input: TransactionInput };
      setInput({ ...emptyInput(), ...payload.input });
      setLoadedDraftId(payload.draftId);
      toast.success("Draft loaded for editing");
    } catch {}
  }, []);

  const company = useMemo(() => companies.find((c) => c.id === input.companyId), [companies, input.companyId]);
  const primary = input.resolutions[0]?.purpose || "";
  const rocInfo = useMemo(() => getRocMapping(primary), [primary]);
  const set = <K extends keyof TransactionInput>(k: K, v: TransactionInput[K]) => setInput((p) => ({ ...p, [k]: v }));

  const setResolutionCount = (n: number) => {
    setInput((p) => {
      const arr = [...p.resolutions];
      if (arr.length < n) {
        while (arr.length < n) arr.push(newResolution(arr.length === 0 ? "BOARD" : "BOARD"));
      } else if (arr.length > n) {
        arr.length = n;
      }
      return { ...p, resolutions: arr };
    });
  };

  const updateRes = (id: string, patch: Partial<ResolutionItem>) =>
    setInput((p) => ({ ...p, resolutions: p.resolutions.map((r) => (r.id === id ? { ...r, ...patch } : r)) }));

  const hasGmResolutions = input.resolutions.some((r) => r.meetingType === "GENERAL");
  const canGenerate = !!company && input.resolutions.length > 0 && input.resolutions.every((r) => !!r.purpose);

  const addFiling = () => set("filings", [...(input.filings || []), { id: uid(), srn: "", date: "", form: rocInfo?.form || "" } as FilingRecord]);
  const updateFiling = (id: string, patch: Partial<FilingRecord>) =>
    set("filings", (input.filings || []).map((f) => (f.id === id ? { ...f, ...patch } : f)));
  const removeFiling = (id: string) => set("filings", (input.filings || []).filter((f) => f.id !== id));

  const saveDraft = () => {
    if (!company) return toast.error("Select company first");
    const title = `${primary || "Untitled"} — ${input.boardMeetingDate || "(no date)"}`;
    const draft: DraftRecord = {
      id: loadedDraftId || uid(),
      companyId: company.id,
      companyName: company.name,
      title,
      savedAt: new Date().toISOString(),
      input,
    };
    store.setDrafts((d) => {
      const exists = d.find((x) => x.id === draft.id);
      return exists ? d.map((x) => (x.id === draft.id ? draft : x)) : [...d, draft];
    });
    setLoadedDraftId(draft.id);
    toast.success("Draft saved");
  };

  const generateOnly = async () => {
    if (!canGenerate || !company) return toast.error("Pick company and fill every resolution purpose");
    setBusy("ALL");
    try {
      await generateAllInOne(company, input, directors, shareholders, { skipPersist: true });
      toast.success("Document downloaded");
    } catch (e) {
      console.error(e);
      toast.error("Generation failed");
    } finally {
      setBusy(null);
    }
  };

  const askLock = () => {
    if (!canGenerate || !company) return toast.error("Pick company and fill every resolution purpose");
    if (!(input.filings || []).some((f) => f.srn && f.date)) return toast.error("Add at least one SRN with date before locking");
    setLockConfirm(true);
  };

  const lockAndFile = async () => {
    if (!company) return;
    setLockConfirm(false);
    setBusy("LOCK");
    try {
      await generateAllInOne(company, input, directors, shareholders, { lock: true });
      // Remove draft if it was loaded
      if (loadedDraftId) {
        store.setDrafts((d) => d.filter((x) => x.id !== loadedDraftId));
        setLoadedDraftId(null);
      }
      toast.success("Locked & saved to Meeting Register");
      navigate({ to: "/meetings" });
    } catch (e) {
      console.error(e);
      toast.error("Lock failed");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Master Transaction Sheet"
        subtitle="Configure multiple resolutions, split across Board / General Meetings, save as draft, then lock with SRN."
      />

      {loadedDraftId && (
        <div className="mb-4 rounded-md border border-l-4 border-l-accent bg-accent/10 px-3 py-2 text-sm">
          Editing saved draft. Re-saving will update the same draft.
        </div>
      )}

      {companies.length === 0 ? (
        <Card className="p-8 text-center border-dashed">
          <p className="text-muted-foreground">
            Add a <Link to="/companies" className="text-primary underline">Company</Link> first.
          </p>
        </Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-6">
            {/* 1. General */}
            <Card className="p-6">
              <h2 className="font-serif text-lg font-semibold mb-4 flex items-center gap-2">
                <Step n={1} /> General Information
              </h2>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Company *">
                  <Select value={input.companyId} onValueChange={(v) => set("companyId", v)}>
                    <SelectTrigger><SelectValue placeholder="Select company" /></SelectTrigger>
                    <SelectContent>{companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </Field>
                <Field label="Number of Resolutions *">
                  <Select value={String(input.resolutions.length)} onValueChange={(v) => setResolutionCount(Number(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Effective Date"><Input type="date" value={input.effectiveDate} onChange={(e) => set("effectiveDate", e.target.value)} /></Field>
                <Field label="Authorised Signatory">
                  <Select value={input.authorisedSignatory} onValueChange={(v) => set("authorisedSignatory", v)}>
                    <SelectTrigger><SelectValue placeholder="Pick from Directors" /></SelectTrigger>
                    <SelectContent>
                      {directors.filter((d) => d.companyId === input.companyId).map((d) => (
                        <SelectItem key={d.id} value={d.name}>{d.name} (DIN: {d.din})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="ROC Filing & Notice Authority *">
                  <Select
                    value={input.rocFilingPerson}
                    onValueChange={(v) => {
                      const d = directors.find((x) => x.companyId === input.companyId && x.name === v);
                      setInput((p) => ({ ...p, rocFilingPerson: v, rocFilingPersonDesignation: d?.designation || d?.category || "Director" }));
                    }}
                  >
                    <SelectTrigger><SelectValue placeholder="Pick from Directors" /></SelectTrigger>
                    <SelectContent>
                      {directors.filter((d) => d.companyId === input.companyId).map((d) => (
                        <SelectItem key={d.id} value={d.name}>{d.name} ({d.designation || d.category})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="ROC Person Designation">
                  <Input value={input.rocFilingPersonDesignation || ""} onChange={(e) => set("rocFilingPersonDesignation", e.target.value)} placeholder="Director / MD / WTD" />
                </Field>
              </div>
            </Card>

            {/* 2. Resolutions */}
            <Card className="p-6 border-l-4 border-l-accent">
              <h2 className="font-serif text-lg font-semibold mb-1 flex items-center gap-2">
                <Step n={2} /> Resolutions ({input.resolutions.length})
              </h2>
              <p className="text-xs text-muted-foreground mb-4">Each resolution is independent. Tag each to Board Meeting or General Meeting.</p>
              <div className="space-y-4">
                {input.resolutions.map((r, idx) => (
                  <ResolutionCard
                    key={r.id}
                    index={idx}
                    res={r}
                    onChange={(patch) => updateRes(r.id, patch)}
                  />
                ))}
              </div>
            </Card>

            {/* 3. Board Meeting */}
            <Card className="p-6">
              <h2 className="font-serif text-lg font-semibold mb-4 flex items-center gap-2">
                <Step n={3} /> Board Meeting
              </h2>
              <div className="grid gap-4 md:grid-cols-3">
                <Field label="Date"><Input type="date" value={input.boardMeetingDate} onChange={(e) => set("boardMeetingDate", e.target.value)} /></Field>
                <Field label="Time"><Input type="time" value={input.boardMeetingTime} onChange={(e) => set("boardMeetingTime", e.target.value)} /></Field>
                <Field label="Venue">
                  <Select value={input.boardVenueType} onValueChange={(v) => set("boardVenueType", v as VenueType)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="REGISTERED_OFFICE">Registered Office</SelectItem>
                      <SelectItem value="OTHER">Any Other Place</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                {input.boardVenueType === "REGISTERED_OFFICE" && (
                  <Field label="Registered Office (from master)" className="md:col-span-3">
                    <Input value={company?.registeredOffice || "—"} disabled />
                  </Field>
                )}
                {input.boardVenueType === "OTHER" && (
                  <Field label="Other Venue" className="md:col-span-3">
                    <Input value={input.boardMeetingVenue} onChange={(e) => set("boardMeetingVenue", e.target.value)} placeholder="Full address of venue" />
                  </Field>
                )}
              </div>
            </Card>

            {/* 4. General Meeting */}
            {(hasGmResolutions || input.generalMeetingDate) && (
              <Card className="p-6">
                <h2 className="font-serif text-lg font-semibold mb-4 flex items-center gap-2">
                  <Step n={4} /> General Meeting
                </h2>
                <div className="grid gap-4 md:grid-cols-4">
                  <Field label="Type">
                    <Select value={input.generalMeetingType} onValueChange={(v) => set("generalMeetingType", v as "EGM" | "AGM")}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EGM">EGM</SelectItem>
                        <SelectItem value="AGM">AGM</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Date"><Input type="date" value={input.generalMeetingDate} onChange={(e) => set("generalMeetingDate", e.target.value)} /></Field>
                  <Field label="Time"><Input type="time" value={input.generalMeetingTime} onChange={(e) => set("generalMeetingTime", e.target.value)} /></Field>
                  <Field label="Venue">
                    <Select value={input.gmVenueType} onValueChange={(v) => set("gmVenueType", v as VenueType)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="REGISTERED_OFFICE">Registered Office</SelectItem>
                        <SelectItem value="OTHER">Any Other Place</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  {input.gmVenueType === "REGISTERED_OFFICE" ? (
                    <Field label="Registered Office (from master)" className="md:col-span-4">
                      <Input value={company?.registeredOffice || "—"} disabled />
                    </Field>
                  ) : (
                    <Field label="Other Venue" className="md:col-span-4">
                      <Input value={input.generalMeetingVenue} onChange={(e) => set("generalMeetingVenue", e.target.value)} placeholder="Full address" />
                    </Field>
                  )}
                </div>
                {input.generalMeetingDate && (
                  <div className="mt-4 grid gap-3 md:grid-cols-3">
                    <Field label="Date of Issue of Notice"><Input type="date" value={input.noticeIssueDate || ""} onChange={(e) => set("noticeIssueDate", e.target.value)} /></Field>
                    <div className="md:col-span-3 flex items-center gap-3 rounded-md border border-l-4 border-l-accent bg-muted/40 p-3">
                      <Switch checked={!!input.shorterNotice} onCheckedChange={(v) => set("shorterNotice", v)} />
                      <div>
                        <div className="text-sm font-medium">Shorter Notice (Section 101)</div>
                        <div className="text-xs text-muted-foreground">Adds Consent for Shorter Notice with shareholder list from master.</div>
                      </div>
                    </div>
                    {input.shorterNotice && (
                      <>
                        <Field label="Consent Date"><Input type="date" value={input.shorterNoticeDate || ""} onChange={(e) => set("shorterNoticeDate", e.target.value)} /></Field>
                        <Field label="Place of Consent" className="md:col-span-2">
                          <Input value={input.shorterNoticePlace || ""} onChange={(e) => set("shorterNoticePlace", e.target.value)} placeholder="City / Registered Office" />
                        </Field>
                      </>
                    )}
                  </div>
                )}
              </Card>
            )}

            {/* 5. ROC Filings */}
            <Card className="p-6 border-l-4 border-l-gold">
              <div className="flex items-center justify-between mb-1">
                <h2 className="font-serif text-lg font-semibold flex items-center gap-2">
                  <Step n={5} /> ROC Filings (SRN)
                </h2>
                <Button type="button" size="sm" variant="outline" onClick={addFiling}>
                  <Plus className="h-4 w-4 mr-1" /> Add SRN
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mb-4">Add one entry per form filed. After at least one SRN, you can Lock & file to push the meeting into the Register.</p>
              {(input.filings || []).length === 0 ? (
                <p className="text-xs text-muted-foreground">No filings yet.</p>
              ) : (
                <div className="space-y-2">
                  {(input.filings || []).map((f) => (
                    <div key={f.id} className="grid gap-2 md:grid-cols-[1fr_1.5fr_1fr_auto] items-end rounded-md border bg-muted/30 p-3">
                      <Field label="Form"><Input value={f.form || ""} onChange={(e) => updateFiling(f.id, { form: e.target.value })} placeholder="e.g. DIR-12" /></Field>
                      <Field label="SRN"><Input value={f.srn} onChange={(e) => updateFiling(f.id, { srn: e.target.value })} /></Field>
                      <Field label="Filing Date"><Input type="date" value={f.date} onChange={(e) => updateFiling(f.id, { date: e.target.value })} /></Field>
                      <Button variant="ghost" size="icon" onClick={() => removeFiling(f.id)}><X className="h-4 w-4" /></Button>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          {/* Right rail */}
          <div className="space-y-4 lg:sticky lg:top-20 lg:self-start">
            <Card className="overflow-hidden">
              <div className="bg-primary text-primary-foreground p-4">
                <div className="flex items-center gap-2 text-xs uppercase tracking-widest opacity-80">
                  <Sparkles className="h-3.5 w-3.5" /> Workflow
                </div>
                <h3 className="font-serif text-lg mt-1">Draft → Generate → Lock</h3>
                <p className="text-xs opacity-80 mt-1">Save as draft, generate the Word file, then lock with SRN to push to the Meeting Register.</p>
              </div>
              <div className="p-3 space-y-2 border-b">
                <Button variant="outline" className="w-full" onClick={saveDraft} disabled={!company}>
                  <Save className="h-4 w-4 mr-2" /> Save as Draft
                </Button>
                <Button className="w-full" disabled={!canGenerate || busy === "ALL"} onClick={generateOnly}>
                  <Download className="h-4 w-4 mr-2" />
                  {busy === "ALL" ? "Generating..." : "Generate Word Document"}
                </Button>
                <Button variant="secondary" className="w-full" disabled={!canGenerate || busy === "LOCK"} onClick={askLock}>
                  <Lock className="h-4 w-4 mr-2" /> Lock & File to Register
                </Button>
              </div>
              <div className="p-3 space-y-1.5 text-xs text-muted-foreground">
                <div className="text-[10px] uppercase tracking-widest text-foreground/70 mb-1">Included sections</div>
                {[
                  "Cover: Meeting Summary & Agenda",
                  "Notice of Board Meeting",
                  "Agenda & Attendance Sheet",
                  "Board Resolution(s) & CTC",
                  "Minutes of Meeting",
                  "EGM/AGM Notice (if applicable)",
                  "Detailed Explanatory Statement u/s 102",
                  "Proxy Form (MGT-11)",
                  "Consent for Shorter Notice (with shareholder list)",
                  "Offer Letter (for share issues)",
                  "Resignation Letter (Director / Auditor)",
                  "ROC Compliance Checklist",
                ].map((s) => (
                  <div key={s} className="flex items-start gap-1.5">
                    <CheckCircle2 className="h-3 w-3 text-primary shrink-0 mt-0.5" />
                    <span>{s}</span>
                  </div>
                ))}
              </div>
            </Card>

            {rocInfo && (
              <Card className="p-4 border-l-4 border-l-gold">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">ROC Compliance (Primary)</div>
                <h4 className="font-serif font-semibold mt-1">{rocInfo.form}</h4>
                <p className="text-xs text-muted-foreground mt-1">{rocInfo.description}</p>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div><div className="text-muted-foreground">Due</div><div className="font-medium">{rocInfo.dueDays} days</div></div>
                  <div><div className="text-muted-foreground">Fee</div><div className="font-medium">{rocInfo.baseFee}</div></div>
                </div>
                <div className="mt-3">
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Attachments</div>
                  <div className="flex flex-wrap gap-1">
                    {rocInfo.attachments.map((a) => <Badge key={a} variant="secondary" className="text-[10px]">{a}</Badge>)}
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      )}

      <AlertDialog open={lockConfirm} onOpenChange={setLockConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Lock this transaction?</AlertDialogTitle>
            <AlertDialogDescription>
              Once locked, the meeting moves to the Meeting Register with the SRN(s) and filing date(s) you entered, and the draft (if any) will be removed. You can still re-print from the Register.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No</AlertDialogCancel>
            <AlertDialogAction onClick={lockAndFile}>Yes, lock & file</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Step({ n }: { n: number }) {
  return (
    <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">{n}</span>
  );
}

function ResolutionCard({ index, res, onChange }: { index: number; res: ResolutionItem; onChange: (p: Partial<ResolutionItem>) => void }) {
  const isDirector = directorPurposes.includes(res.purpose);
  const isShareCapital = shareCapitalPurposes.includes(res.purpose);
  const isShareIssue = shareIssuePurposes.includes(res.purpose);
  const isResignation = resignationPurposes.includes(res.purpose);

  const knownPurposes = Object.values(PURPOSE_GROUPS).flat() as string[];
  const isCustom = !!res.purpose && !knownPurposes.includes(res.purpose);
  const [customMode, setCustomMode] = useState(isCustom);

  return (
    <div className="rounded-md border bg-muted/20 p-4">
      <div className="grid gap-3 md:grid-cols-[1fr_1fr_180px] mb-3">
        <Field label={`Resolution #${index + 1} — Purpose`}>
          {customMode ? (
            <div className="flex gap-2">
              <Input
                value={res.purpose}
                placeholder="Enter custom resolution subject"
                onChange={(e) => onChange({ purpose: e.target.value })}
              />
              <Button type="button" variant="outline" size="sm" onClick={() => { setCustomMode(false); onChange({ purpose: "" }); }}>List</Button>
            </div>
          ) : (
            <Select
              value={res.purpose}
              onValueChange={(v) => {
                if (v === "__custom__") { setCustomMode(true); onChange({ purpose: "" }); return; }
                onChange({ purpose: v });
              }}
            >
              <SelectTrigger><SelectValue placeholder="Select purpose" /></SelectTrigger>
              <SelectContent className="max-h-80">
                {Object.entries(PURPOSE_GROUPS).map(([group, items]) => (
                  <SelectGroup key={group}>
                    <SelectLabel>{group}</SelectLabel>
                    {items.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectGroup>
                ))}
                <SelectGroup>
                  <SelectLabel>Custom</SelectLabel>
                  <SelectItem value="__custom__">Custom subject…</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          )}
        </Field>
        <Field label="Pass at">
          <Select value={res.meetingType} onValueChange={(v) => onChange({ meetingType: v as MeetingTypeRef })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="BOARD">Board Meeting</SelectItem>
              <SelectItem value="GENERAL">Shareholders' Meeting</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Notes (optional)">
          <Input value={res.details || ""} onChange={(e) => onChange({ details: e.target.value })} placeholder="Key facts" />
        </Field>
      </div>

      {/* Dynamic detail fields */}
      {isDirector && (
        <div className="grid gap-3 md:grid-cols-3 mt-2 rounded-md bg-background p-3 border">
          <div className="md:col-span-3 flex justify-end -mb-1">
            <ExtractFromFileButton
              entity="director"
              label="Auto-fill from DIR-2 / DIN allotment / PAN"
              onExtract={(f) => {
                const s = (k: string) => (typeof f[k] === "string" ? (f[k] as string) : undefined);
                onChange({
                  ...(s("title") ? { directorTitle: s("title") as Title } : {}),
                  ...(s("name") ? { directorName: s("name") } : {}),
                  ...(s("din") ? { directorDIN: s("din") } : {}),
                  ...(s("pan") ? { directorPAN: s("pan") } : {}),
                  ...(s("address") ? { directorAddress: s("address") } : {}),
                  ...(s("email") ? { directorEmail: s("email") } : {}),
                  ...(s("mobile") ? { directorMobile: s("mobile") } : {}),
                  ...(s("designation") ? { designation: s("designation") } : {}),
                  ...(s("dateOfAppointment") ? { appointmentDate: s("dateOfAppointment") } : {}),
                  ...(s("fathersName") ? { dir2FathersName: s("fathersName") } : {}),
                  ...(s("dob") ? { dir2DOB: s("dob") } : {}),
                  ...(s("nationality") ? { dir2Nationality: s("nationality") } : {}),
                  ...(s("occupation") ? { dir2Occupation: s("occupation") } : {}),
                });
              }}
            />
          </div>

          <Field label="Title">
            <Select value={res.directorTitle || "Mr."} onValueChange={(v) => onChange({ directorTitle: v as Title })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{TITLE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Director Name"><Input value={res.directorName || ""} onChange={(e) => onChange({ directorName: e.target.value })} /></Field>
          <Field label="DIN"><Input value={res.directorDIN || ""} onChange={(e) => onChange({ directorDIN: e.target.value })} /></Field>
          <Field label="PAN"><Input value={res.directorPAN || ""} onChange={(e) => onChange({ directorPAN: e.target.value })} /></Field>
          <Field label="Designation"><Input value={res.designation || ""} onChange={(e) => onChange({ designation: e.target.value })} placeholder="Director / MD / WTD / ID" /></Field>
          {res.purpose === "Resignation of Director" ? (
            <>
              <Field label="Date of Resignation"><Input type="date" value={res.resignationDate || ""} onChange={(e) => onChange({ resignationDate: e.target.value })} /></Field>
              <Field label="Reason" className="md:col-span-3"><Textarea rows={2} value={res.resignationReason || ""} onChange={(e) => onChange({ resignationReason: e.target.value })} /></Field>
            </>
          ) : (
            <>
              <Field label="Date of Appointment"><Input type="date" value={res.appointmentDate || ""} onChange={(e) => onChange({ appointmentDate: e.target.value })} /></Field>
              <Field label="Remuneration"><Input value={res.remuneration || ""} onChange={(e) => onChange({ remuneration: e.target.value })} /></Field>
              <Field label="Terms" className="md:col-span-3"><Textarea rows={2} value={res.termsOfAppointment || ""} onChange={(e) => onChange({ termsOfAppointment: e.target.value })} /></Field>

              {/* DIR-2 & DIR-8 specific details */}
              <div className="md:col-span-3 mt-2 pt-3 border-t">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">DIR-2 (Consent) & DIR-8 (Intimation) details</div>
                <div className="grid gap-3 md:grid-cols-3">
                  <Field label="Father's Name"><Input value={res.dir2FathersName || ""} onChange={(e) => onChange({ dir2FathersName: e.target.value })} /></Field>
                  <Field label="Date of Birth"><Input type="date" value={res.dir2DOB || ""} onChange={(e) => onChange({ dir2DOB: e.target.value })} /></Field>
                  <Field label="Nationality"><Input value={res.dir2Nationality || "Indian"} onChange={(e) => onChange({ dir2Nationality: e.target.value })} /></Field>
                  <Field label="Director Address"><Input value={res.directorAddress || ""} onChange={(e) => onChange({ directorAddress: e.target.value })} /></Field>
                  <Field label="Email"><Input value={res.directorEmail || ""} onChange={(e) => onChange({ directorEmail: e.target.value })} /></Field>
                  <Field label="Mobile"><Input value={res.directorMobile || ""} onChange={(e) => onChange({ directorMobile: e.target.value })} /></Field>
                  <Field label="Occupation"><Input value={res.dir2Occupation || ""} onChange={(e) => onChange({ dir2Occupation: e.target.value })} placeholder="Business / Service / Professional" /></Field>
                  <Field label="No. of other Directorships"><Input value={res.dir2OtherDirectorshipsCount || ""} onChange={(e) => onChange({ dir2OtherDirectorshipsCount: e.target.value })} placeholder="e.g. 3" /></Field>
                  <Field label="Membership No. / COP"><Input value={res.dir2MembershipDetails || ""} onChange={(e) => onChange({ dir2MembershipDetails: e.target.value })} placeholder="NIL if not applicable" /></Field>
                  <Field label="Companies where MD/CEO/WTD/CS/CFO/Manager" className="md:col-span-3"><Textarea rows={2} value={res.dir2KmpCompanies || ""} onChange={(e) => onChange({ dir2KmpCompanies: e.target.value })} placeholder="NIL or list companies" /></Field>
                  <Field label="Security Clearance (MHA)">
                    <Select value={res.dir2SecurityClearance || "not_required"} onValueChange={(v) => onChange({ dir2SecurityClearance: v as "not_required" | "obtained" })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="not_required">Not required</SelectItem>
                        <SelectItem value="obtained">Required & obtained</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Place (DIR-2 & DIR-8)"><Input value={res.dir2Place || ""} onChange={(e) => onChange({ dir2Place: e.target.value, dir8Place: e.target.value })} /></Field>
                  <Field label="Signing Date"><Input type="date" value={res.dir2Date || ""} onChange={(e) => onChange({ dir2Date: e.target.value, dir8Date: e.target.value })} /></Field>
                  <Field label="DIR-8: Relation">
                    <Select value={res.dir8Relation || "son"} onValueChange={(v) => onChange({ dir8Relation: v as "son" | "daughter" | "wife" })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="son">Son of</SelectItem>
                        <SelectItem value="daughter">Daughter of</SelectItem>
                        <SelectItem value="wife">Wife of</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="DIR-8: Capacity">
                    <Select value={res.dir8Capacity || "director"} onValueChange={(v) => onChange({ dir8Capacity: v as "director" | "managing director" | "manager" })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="director">Director</SelectItem>
                        <SelectItem value="managing director">Managing Director</SelectItem>
                        <SelectItem value="manager">Manager</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Past Directorships (last 3 years)" className="md:col-span-3">
                    <Textarea rows={3} value={res.dir8PastDirectorships || ""} onChange={(e) => onChange({ dir8PastDirectorships: e.target.value })} placeholder={"One per line: Company Name | YYYY-MM-DD | YYYY-MM-DD"} />
                  </Field>
                  <Field label="Disqualified under s.164?">
                    <div className="flex items-center gap-2 h-10">
                      <Switch checked={!!res.dir8Disqualified} onCheckedChange={(v) => onChange({ dir8Disqualified: v })} />
                      <span className="text-sm text-muted-foreground">{res.dir8Disqualified ? "Yes" : "No"}</span>
                    </div>
                  </Field>
                  {res.dir8Disqualified && (
                    <>
                      <Field label="164(1) Ground" className="md:col-span-2"><Input value={res.dir8DisqualificationGround || ""} onChange={(e) => onChange({ dir8DisqualificationGround: e.target.value })} /></Field>
                      <Field label="164(2) Companies" className="md:col-span-3">
                        <Textarea rows={2} value={res.dir8DisqualifiedCompanies || ""} onChange={(e) => onChange({ dir8DisqualifiedCompanies: e.target.value })} placeholder={"One per line: Company Name | YYYY-MM-DD | YYYY-MM-DD"} />
                      </Field>
                    </>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {res.purpose === "Resignation of Auditor" && (
        <div className="grid gap-3 md:grid-cols-3 mt-2 rounded-md bg-background p-3 border">
          <Field label="Auditor Firm"><Input value={res.auditorFirmName || ""} onChange={(e) => onChange({ auditorFirmName: e.target.value })} /></Field>
          <Field label="Firm Reg. No."><Input value={res.auditorFirmRegNo || ""} onChange={(e) => onChange({ auditorFirmRegNo: e.target.value })} /></Field>
          <Field label="Resignation Date"><Input type="date" value={res.resignationDate || ""} onChange={(e) => onChange({ resignationDate: e.target.value })} /></Field>
          <Field label="Reason" className="md:col-span-3"><Textarea rows={2} value={res.resignationReason || ""} onChange={(e) => onChange({ resignationReason: e.target.value })} /></Field>
        </div>
      )}

      {res.purpose === "Appointment of Auditor" && (
        <div className="grid gap-3 md:grid-cols-2 mt-2 rounded-md bg-background p-3 border">
          <Field label="Auditor Firm"><Input value={res.auditorFirmName || ""} onChange={(e) => onChange({ auditorFirmName: e.target.value })} /></Field>
          <Field label="Firm Reg. No."><Input value={res.auditorFirmRegNo || ""} onChange={(e) => onChange({ auditorFirmRegNo: e.target.value })} /></Field>
        </div>
      )}

      {isShareCapital && (
        <div className="grid gap-3 md:grid-cols-3 mt-2 rounded-md bg-background p-3 border">
          <Field label="Existing Authorised Capital (₹)"><Input value={res.existingAuthCapital || ""} onChange={(e) => onChange({ existingAuthCapital: e.target.value })} /></Field>
          <Field label="Existing No. of Shares"><Input value={res.existingShares || ""} onChange={(e) => onChange({ existingShares: e.target.value })} /></Field>
          <Field label="Face Value (₹)"><Input value={res.faceValue || ""} onChange={(e) => onChange({ faceValue: e.target.value })} /></Field>
          <Field label="New Authorised Capital (₹)"><Input value={res.newAuthCapital || ""} onChange={(e) => onChange({ newAuthCapital: e.target.value })} /></Field>
          <Field label="New No. of Shares"><Input value={res.newShares || ""} onChange={(e) => onChange({ newShares: e.target.value })} /></Field>
          <Field label="Type of Shares"><Input value={res.shareType || ""} onChange={(e) => onChange({ shareType: e.target.value })} placeholder="Equity" /></Field>
        </div>
      )}

      {isShareIssue && (
        <div className="grid gap-3 md:grid-cols-3 mt-2 rounded-md bg-background p-3 border">
          <Field label="No. of Shares"><Input value={res.numberOfShares || ""} onChange={(e) => onChange({ numberOfShares: e.target.value })} /></Field>
          <Field label="Face Value (₹)"><Input value={res.faceValue || ""} onChange={(e) => onChange({ faceValue: e.target.value })} /></Field>
          <Field label="Premium (₹)"><Input value={res.premium || ""} onChange={(e) => onChange({ premium: e.target.value })} /></Field>
          {(res.purpose === "Rights Issue" || res.purpose === "Bonus Issue") ? (
            <>
              <Field label="Record Date"><Input type="date" value={res.recordDate || ""} onChange={(e) => onChange({ recordDate: e.target.value })} /></Field>
              <Field label="Offer Opening"><Input type="date" value={res.offerOpenDate || ""} onChange={(e) => onChange({ offerOpenDate: e.target.value })} /></Field>
              <Field label="Offer Closing"><Input type="date" value={res.offerCloseDate || ""} onChange={(e) => onChange({ offerCloseDate: e.target.value })} /></Field>
              <Field label="Renunciation">
                <div className="flex items-center gap-2 h-10">
                  <Switch checked={!!res.renunciation} onCheckedChange={(v) => onChange({ renunciation: v })} />
                  <span className="text-sm text-muted-foreground">{res.renunciation ? "Yes" : "No"}</span>
                </div>
              </Field>
            </>
          ) : (
            <>
              <Field label="Issue Price (₹)"><Input value={res.issuePrice || ""} onChange={(e) => onChange({ issuePrice: e.target.value })} /></Field>
              <Field label="PAS-4 Date"><Input type="date" value={res.pas4Date || ""} onChange={(e) => onChange({ pas4Date: e.target.value })} /></Field>
              <Field label="Allotment Date"><Input type="date" value={res.allotmentDate || ""} onChange={(e) => onChange({ allotmentDate: e.target.value })} /></Field>
              <Field label="List of Investors" className="md:col-span-3"><Textarea rows={2} value={res.investorList || ""} onChange={(e) => onChange({ investorList: e.target.value })} placeholder="One investor per line" /></Field>
            </>
          )}
        </div>
      )}

      {res.purpose === "Opening Bank Account" && (
        <div className="grid gap-3 md:grid-cols-3 mt-2 rounded-md bg-background p-3 border">
          <Field label="Bank Name"><Input value={res.bankName || ""} onChange={(e) => onChange({ bankName: e.target.value })} placeholder="e.g. HDFC Bank Ltd." /></Field>
          <Field label="Branch"><Input value={res.bankBranch || ""} onChange={(e) => onChange({ bankBranch: e.target.value })} placeholder="e.g. Andheri (E), Mumbai" /></Field>
          <Field label="Account Type"><Input value={res.bankAccountType || ""} onChange={(e) => onChange({ bankAccountType: e.target.value })} placeholder="Current Account" /></Field>
        </div>
      )}

      {res.purpose === "Change in Registered Office" && (
        <div className="grid gap-3 md:grid-cols-2 mt-2 rounded-md bg-background p-3 border">
          <Field label="New Registered Office Address" className="md:col-span-2">
            <Textarea rows={2} value={res.newRegisteredOffice || ""} onChange={(e) => onChange({ newRegisteredOffice: e.target.value })} placeholder="Full new address with PIN" />
          </Field>
          <Field label="Change of ROC Jurisdiction?">
            <div className="flex items-center gap-2 h-10">
              <Switch checked={!!res.newRegOfficeChangeRoc} onCheckedChange={(v) => onChange({ newRegOfficeChangeRoc: v })} />
              <span className="text-sm text-muted-foreground">{res.newRegOfficeChangeRoc ? "Yes" : "No"}</span>
            </div>
          </Field>
        </div>
      )}

      {!isDirector && !isShareCapital && !isShareIssue && !isResignation && res.purpose && res.purpose !== "Opening Bank Account" && res.purpose !== "Change in Registered Office" && (
        <div className="mt-2 rounded-md bg-background p-3 border">
          <Field label="Specific terms / amount / details">
            <Textarea rows={2} value={res.details || ""} onChange={(e) => onChange({ details: e.target.value })} placeholder="Key facts to include in the resolution" />
          </Field>
        </div>
      )}
    </div>
  );
}
