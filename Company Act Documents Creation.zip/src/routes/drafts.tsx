import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download, FileText, Pencil, Trash2 } from "lucide-react";
import { store, useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, PageHeader, EmptyState } from "./companies";
import { generateAllInOne } from "@/lib/document-generator";
import { toast } from "sonner";

export const Route = createFileRoute("/drafts")({
  head: () => ({
    meta: [
      { title: "Drafts — Lex Secretaria" },
      { name: "description", content: "Saved transaction drafts. Edit, re-print, or lock to push into the Meeting Register." },
    ],
  }),
  component: DraftsPage,
});

function DraftsPage() {
  const drafts = useStore((s) => s.drafts);
  const companies = useStore((s) => s.companies);
  const directors = useStore((s) => s.directors);
  const shareholders = useStore((s) => s.shareholders);
  const navigate = useNavigate();
  const [companyFilter, setCompanyFilter] = useState("all");

  const filtered = useMemo(() => {
    return drafts
      .filter((d) => companyFilter === "all" || d.companyId === companyFilter)
      .sort((a, b) => (a.savedAt < b.savedAt ? 1 : -1));
  }, [drafts, companyFilter]);

  const edit = (id: string, input: unknown) => {
    sessionStorage.setItem("lex.draft.load", JSON.stringify({ draftId: id, input }));
    navigate({ to: "/transactions" });
  };

  const reprint = async (companyId: string, input: any) => {
    const c = companies.find((x) => x.id === companyId);
    if (!c) return toast.error("Company not found");
    try {
      await generateAllInOne(c, input, directors, shareholders, { skipPersist: true, stamp: "DRAFT" });
      toast.success("Draft document downloaded");
    } catch (e) {
      console.error(e);
      toast.error("Generation failed");
    }
  };

  const remove = (id: string) => {
    store.setDrafts((d) => d.filter((x) => x.id !== id));
    toast.success("Draft removed");
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Drafts"
        subtitle="Work in progress meetings. Edit details then re-print, or lock from the Transaction Sheet to file."
      />

      <Card className="p-4 mb-6">
        <div className="grid gap-4 md:grid-cols-3 max-w-xl">
          <Field label="Company">
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={<FileText className="h-10 w-10" />} text="No drafts yet. Save a draft from the Transaction Sheet to see it here." />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Company</th>
                  <th className="px-4 py-3 text-left">Title</th>
                  <th className="px-4 py-3 text-left">Resolutions</th>
                  <th className="px-4 py-3 text-left">Saved</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((d) => (
                  <tr key={d.id} className="border-t hover:bg-muted/20">
                    <td className="px-4 py-3">{d.companyName}</td>
                    <td className="px-4 py-3 font-medium">{d.title}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {(d.input.resolutions || []).map((r) => r.purpose || "(empty)").join("; ")}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(d.savedAt).toLocaleString("en-IN")}</td>
                    <td className="px-4 py-3 text-right space-x-1">
                      <Button variant="outline" size="sm" onClick={() => edit(d.id, d.input)}>
                        <Pencil className="h-3.5 w-3.5 mr-1" /> Edit
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => reprint(d.companyId, d.input)}>
                        <Download className="h-3.5 w-3.5 mr-1" /> Re-print
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(d.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
