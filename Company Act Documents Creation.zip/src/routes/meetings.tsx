import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CalendarCheck2, Download, Trash2, Printer } from "lucide-react";
import { store, useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, PageHeader, EmptyState } from "./companies";
import { generateMeetingsSummary, reprintMeeting } from "@/lib/document-generator";
import { toast } from "sonner";

export const Route = createFileRoute("/meetings")({
  head: () => ({
    meta: [
      { title: "Meetings — Lex Secretaria" },
      { name: "description", content: "Locked Meeting Register with SRN-stamped re-print support." },
    ],
  }),
  component: MeetingsPage,
});

function MeetingsPage() {
  const meetings = useStore((s) => s.meetings);
  const companies = useStore((s) => s.companies);
  const directors = useStore((s) => s.directors);
  const shareholders = useStore((s) => s.shareholders);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [companyFilter, setCompanyFilter] = useState<string>("all");

  const filtered = useMemo(() => {
    return meetings
      .filter((m) => companyFilter === "all" || m.companyId === companyFilter)
      .filter((m) => !from || m.date >= from)
      .filter((m) => !to || m.date <= to)
      .sort((a, b) => (a.date < b.date ? 1 : -1));
  }, [meetings, from, to, companyFilter]);

  const download = async () => {
    if (filtered.length === 0) return toast.error("No meetings in selected period");
    await generateMeetingsSummary(filtered, from, to);
    toast.success("Summary downloaded");
  };

  const remove = (id: string) => {
    store.setMeetings((m) => m.filter((x) => x.id !== id));
    toast.success("Meeting removed");
  };

  const reprint = async (id: string) => {
    const m = meetings.find((x) => x.id === id);
    if (!m) return;
    const c = companies.find((x) => x.id === m.companyId);
    if (!c) return toast.error("Company not found");
    try {
      await reprintMeeting(m, c, directors, shareholders);
      toast.success("Re-printed with SRN stamp");
    } catch (e) {
      console.error(e);
      toast.error("Re-print failed");
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Meetings Register"
        subtitle="Locked meetings with SRN/filing-date stamps. Filter by company & period, then re-print or export a summary."
      />

      <Card className="p-4 mb-6">
        <div className="grid gap-4 md:grid-cols-4">
          <Field label="Company">
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="From"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="To"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <div className="flex items-end">
            <Button className="w-full" onClick={download}>
              <Download className="h-4 w-4 mr-2" /> Download Summary
            </Button>
          </div>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={<CalendarCheck2 className="h-10 w-10" />} text="No meetings yet. Lock a transaction from the Transaction Sheet to populate this register." />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Date</th>
                  <th className="px-4 py-3 text-left">Company</th>
                  <th className="px-4 py-3 text-left">Type</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Agenda</th>
                  <th className="px-4 py-3 text-left">SRN / Filing</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((m) => (
                  <tr key={m.id} className="border-t hover:bg-muted/20">
                    <td className="px-4 py-3 font-medium">{m.date}</td>
                    <td className="px-4 py-3">{m.companyName}</td>
                    <td className="px-4 py-3">
                      <Badge variant={m.type === "Board" ? "secondary" : "default"}>{m.type}</Badge>
                      {m.shorterNotice && <Badge variant="outline" className="ml-1 text-[10px]">Shorter Notice</Badge>}
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={m.status === "LOCKED" ? "default" : "outline"} className="text-[10px]">{m.status || "DRAFT"}</Badge>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground max-w-[300px] truncate">{m.agenda.join("; ")}</td>
                    <td className="px-4 py-3 text-xs">
                      {(m.filings || []).length === 0 ? <span className="text-muted-foreground">—</span> :
                        (m.filings || []).map((f) => (
                          <div key={f.id}>{f.form ? `${f.form} • ` : ""}SRN {f.srn || "—"} · {f.date || "—"}</div>
                        ))}
                    </td>
                    <td className="px-4 py-3 text-right space-x-1">
                      <Button variant="outline" size="sm" onClick={() => reprint(m.id)}>
                        <Printer className="h-3.5 w-3.5 mr-1" /> Re-print
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(m.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
