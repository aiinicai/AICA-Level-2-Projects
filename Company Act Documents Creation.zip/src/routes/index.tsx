import { createFileRoute, Link } from "@tanstack/react-router";
import { Building2, Users, PieChart, FileText, CalendarClock, ArrowRight } from "lucide-react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Lex Secretaria" },
      { name: "description", content: "Overview of companies, directors and pending compliance actions." },
    ],
  }),
  component: Dashboard,
});

function Stat({ icon: Icon, label, value, to }: { icon: typeof Building2; label: string; value: number; to: string }) {
  return (
    <Link to={to}>
      <Card className="group p-6 hover:shadow-md transition-all border-l-4 border-l-primary/20 hover:border-l-primary cursor-pointer">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
            <p className="mt-2 text-4xl font-serif font-semibold text-foreground">{value}</p>
          </div>
          <Icon className="h-6 w-6 text-primary/60 group-hover:text-primary transition-colors" />
        </div>
      </Card>
    </Link>
  );
}

function Dashboard() {
  const companies = useStore((s) => s.companies);
  const directors = useStore((s) => s.directors);
  const shareholders = useStore((s) => s.shareholders);

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="mb-10 flex items-end justify-between border-b pb-6">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Welcome to</p>
          <h1 className="mt-2 text-4xl font-serif font-semibold text-foreground">
            Lex Secretaria
          </h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            One master input sheet → every Companies Act, 2013 resolution, notice, minute and ROC checklist.
            Built for Company Secretaries and Chartered Accountants who hate retyping.
          </p>
        </div>
        <div className="hidden md:block text-right">
          <div className="text-xs uppercase tracking-widest text-muted-foreground">Today</div>
          <div className="font-serif text-xl">
            {new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })}
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Stat icon={Building2} label="Companies" value={companies.length} to="/companies" />
        <Stat icon={Users} label="Directors" value={directors.length} to="/directors" />
        <Stat icon={PieChart} label="Shareholders" value={shareholders.length} to="/shareholders" />
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-2">
        <Link to="/transactions">
          <Card className="p-6 hover:shadow-md transition-all bg-gradient-to-br from-primary to-accent text-primary-foreground">
            <FileText className="h-6 w-6 mb-3" />
            <h3 className="font-serif text-xl font-semibold">Master Transaction Sheet</h3>
            <p className="text-sm text-primary-foreground/80 mt-1">
              Fill one form, generate Notice, Agenda, Resolution, Minutes, CTC, Explanatory Statement, Proxy Form and ROC checklist.
            </p>
            <div className="mt-4 inline-flex items-center gap-1 text-sm font-medium">
              Open <ArrowRight className="h-4 w-4" />
            </div>
          </Card>
        </Link>
        <Link to="/calendar">
          <Card className="p-6 hover:shadow-md transition-all">
            <CalendarClock className="h-6 w-6 text-primary mb-3" />
            <h3 className="font-serif text-xl font-semibold">ROC Compliance Reference</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Form mapping for every event — DIR-12, SH-7, PAS-3, ADT-1, MGT-14 and more, with due dates and attachments.
            </p>
            <div className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
              Open <ArrowRight className="h-4 w-4" />
            </div>
          </Card>
        </Link>
      </div>

      {companies.length === 0 && (
        <Card className="mt-10 p-6 border-dashed bg-muted/30">
          <h3 className="font-serif text-lg font-semibold">Get started</h3>
          <ol className="mt-3 space-y-2 text-sm text-muted-foreground list-decimal list-inside">
            <li>Add your first <Link to="/companies" className="text-primary underline underline-offset-4">Company</Link></li>
            <li>Add its <Link to="/directors" className="text-primary underline underline-offset-4">Directors</Link></li>
            <li>Open the <Link to="/transactions" className="text-primary underline underline-offset-4">Transaction Sheet</Link> and generate documents</li>
          </ol>
        </Card>
      )}
    </div>
  );
}
