import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, BadgeCheck } from "lucide-react";
import { store, uid, useStore } from "@/lib/store";
import type { Auditor } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Field, PageHeader, EmptyState } from "./companies";

export const Route = createFileRoute("/auditors")({
  head: () => ({
    meta: [
      { title: "Auditors — Lex Secretaria" },
      { name: "description", content: "Master of statutory auditor firms, FRN, authorised partner and contact details." },
    ],
  }),
  component: AuditorsPage,
});

const empty: Auditor = {
  id: "", firmName: "", frn: "", authorizedPersonName: "",
  designation: "Partner", membershipNo: "", email: "", address: "", phone: "", place: "",
};

function AuditorsPage() {
  const auditors = useStore((s) => s.auditors);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Auditor>(empty);

  const save = () => {
    if (!draft.firmName.trim()) return toast.error("Firm name is required");
    if (draft.id) {
      store.setAuditors((as) => as.map((a) => (a.id === draft.id ? draft : a)));
      // propagate updated details to any company that references this auditor
      store.setCompanies((cs) => cs.map((c) => c.auditorId === draft.id ? { ...c, auditorName: draft.firmName, auditorFirmRegNo: draft.frn } : c));
      toast.success("Auditor updated");
    } else {
      store.setAuditors((as) => [...as, { ...draft, id: uid() }]);
      toast.success("Auditor added");
    }
    setOpen(false);
    setDraft(empty);
  };

  const remove = (id: string) => {
    store.setAuditors((as) => as.filter((x) => x.id !== id));
    store.setCompanies((cs) => cs.map((c) => c.auditorId === id ? { ...c, auditorId: undefined } : c));
    toast.success("Removed");
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Auditor Master"
        subtitle="Global pool of statutory auditor firms — link them to companies from the Company master."
        action={
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setDraft(empty); }}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-1" /> Add Auditor</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader><DialogTitle className="font-serif">{draft.id ? "Edit" : "New"} Auditor</DialogTitle></DialogHeader>
              <div className="grid gap-4 md:grid-cols-2 py-2">
                <Field label="Name of Firm *" className="md:col-span-2"><Input value={draft.firmName} onChange={(e) => setDraft({ ...draft, firmName: e.target.value })} placeholder="e.g. XYZ & Associates" /></Field>
                <Field label="FRN *"><Input value={draft.frn} onChange={(e) => setDraft({ ...draft, frn: e.target.value })} /></Field>
                <Field label="Name of Authorised Person *"><Input value={draft.authorizedPersonName} onChange={(e) => setDraft({ ...draft, authorizedPersonName: e.target.value })} /></Field>
                <Field label="Designation">
                  <Select value={draft.designation} onValueChange={(v) => setDraft({ ...draft, designation: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Partner">Partner</SelectItem>
                      <SelectItem value="Proprietor">Proprietor</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Membership No."><Input value={draft.membershipNo} onChange={(e) => setDraft({ ...draft, membershipNo: e.target.value })} /></Field>
                <Field label="Email"><Input type="email" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
                <Field label="Phone"><Input value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} /></Field>
                <Field label="Place"><Input value={draft.place} onChange={(e) => setDraft({ ...draft, place: e.target.value })} /></Field>
                <Field label="Address" className="md:col-span-2"><Textarea rows={2} value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} /></Field>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={save}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {auditors.length === 0 ? (
        <EmptyState icon={<BadgeCheck className="h-10 w-10" />} text="No auditors yet." />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Firm</th>
                  <th className="px-4 py-3 text-left">FRN</th>
                  <th className="px-4 py-3 text-left">Authorised Person</th>
                  <th className="px-4 py-3 text-left">M. No.</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {auditors.map((a) => (
                  <tr key={a.id} className="border-t hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">{a.firmName}</td>
                    <td className="px-4 py-3 font-mono text-xs">{a.frn || "—"}</td>
                    <td className="px-4 py-3">{a.authorizedPersonName} <span className="text-muted-foreground">({a.designation})</span></td>
                    <td className="px-4 py-3 font-mono text-xs">{a.membershipNo || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="icon" onClick={() => { setDraft(a); setOpen(true); }}>✎</Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(a.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
