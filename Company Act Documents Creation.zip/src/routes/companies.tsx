import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, Building2 } from "lucide-react";
import { store, uid, useStore } from "@/lib/store";
import type { Company, Auditor } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ExtractFromFileButton } from "@/components/extract-from-file";


export const Route = createFileRoute("/companies")({
  head: () => ({
    meta: [
      { title: "Companies — Lex Secretaria" },
      { name: "description", content: "Maintain your Company Master with CIN, capital, ROC jurisdiction and KMP details." },
    ],
  }),
  component: CompaniesPage,
});

const empty: Company = {
  id: "", name: "", cin: "", registeredOffice: "", email: "", phone: "",
  authorisedCapital: "", paidUpCapital: "", dateOfIncorporation: "",
  financialYear: "2024-2025", rocJurisdiction: "", pan: "", gstin: "",
  csName: "", csMembershipNo: "", auditorName: "", auditorFirmRegNo: "",
};

function CompaniesPage() {
  const companies = useStore((s) => s.companies);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Company>(empty);

  const save = () => {
    if (!draft.name.trim()) return toast.error("Company name is required");
    if (draft.id) {
      store.setCompanies((cs) => cs.map((c) => (c.id === draft.id ? draft : c)));
      toast.success("Company updated");
    } else {
      store.setCompanies((cs) => [...cs, { ...draft, id: uid() }]);
      toast.success("Company added");
    }
    setOpen(false);
    setDraft(empty);
  };

  const remove = (id: string) => {
    store.setCompanies((cs) => cs.filter((c) => c.id !== id));
    store.setDirectors((ds) => ds.filter((d) => d.companyId !== id));
    store.setShareholders((ss) => ss.filter((s) => s.companyId !== id));
    toast.success("Company removed");
  };

  const edit = (c: Company) => { setDraft(c); setOpen(true); };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <PageHeader
        title="Company Master"
        subtitle="Single source of truth for every company on your panel."
        action={
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setDraft(empty); }}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-1" /> Add Company</Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="font-serif">{draft.id ? "Edit" : "New"} Company</DialogTitle>
              </DialogHeader>
              <div className="flex justify-end pt-1">
                <ExtractFromFileButton
                  entity="company"
                  onExtract={(f) =>
                    setDraft((d) => ({
                      ...d,
                      ...(Object.fromEntries(
                        Object.entries(f).filter(([, v]) => typeof v === "string" && v),
                      ) as Partial<Company>),
                    }))
                  }
                />
              </div>

              <CompanyForm value={draft} onChange={setDraft} />
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={save}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {companies.length === 0 ? (
        <EmptyState icon={<Building2 className="h-10 w-10" />} text="No companies yet. Add your first one to start drafting." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {companies.map((c) => (
            <Card key={c.id} className="p-5 hover:shadow-md transition-all border-l-4 border-l-primary">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="font-serif text-lg font-semibold truncate">{c.name}</h3>
                  <p className="text-xs text-muted-foreground">CIN: {c.cin || "—"}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => remove(c.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
              <dl className="mt-3 space-y-1 text-xs">
                <Row k="Auth. Capital" v={c.authorisedCapital ? `₹${c.authorisedCapital}` : "—"} />
                <Row k="Paid-up" v={c.paidUpCapital ? `₹${c.paidUpCapital}` : "—"} />
                <Row k="ROC" v={c.rocJurisdiction || "—"} />
                <Row k="FY" v={c.financialYear || "—"} />
              </dl>
              <Button variant="outline" size="sm" className="mt-4 w-full" onClick={() => edit(c)}>Edit Details</Button>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between border-b border-border/50 py-1">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="font-medium truncate ml-2">{v}</dd>
    </div>
  );
}

function CompanyForm({ value, onChange }: { value: Company; onChange: (c: Company) => void }) {
  const auditors = useStore((s) => s.auditors);
  const f = <K extends keyof Company>(k: K) => ({
    value: value[k] as string,
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      onChange({ ...value, [k]: e.target.value }),
  });
  const pickAuditor = (id: string) => {
    const a: Auditor | undefined = auditors.find((x) => x.id === id);
    if (!a) return;
    onChange({ ...value, auditorId: a.id, auditorName: a.firmName, auditorFirmRegNo: a.frn });
  };
  return (
    <div className="grid gap-4 md:grid-cols-2 py-2">
      <Field label="Company Name *"><Input {...f("name")} /></Field>
      <Field label="CIN"><Input {...f("cin")} placeholder="U00000XX0000XXX000000" /></Field>
      <Field label="Registered Office" className="md:col-span-2"><Textarea rows={2} {...f("registeredOffice")} /></Field>
      <Field label="Email"><Input type="email" {...f("email")} /></Field>
      <Field label="Phone"><Input {...f("phone")} placeholder="+91-XXXXXXXXXX" /></Field>
      <Field label="Date of Incorporation"><Input type="date" {...f("dateOfIncorporation")} /></Field>
      <Field label="Authorised Capital (₹)"><Input {...f("authorisedCapital")} /></Field>
      <Field label="Paid-up Capital (₹)"><Input {...f("paidUpCapital")} /></Field>
      <Field label="Financial Year"><Input {...f("financialYear")} placeholder="2024-2025" /></Field>
      <Field label="ROC Jurisdiction"><Input {...f("rocJurisdiction")} placeholder="ROC Mumbai" /></Field>
      <Field label="PAN"><Input {...f("pan")} /></Field>
      <Field label="GSTIN"><Input {...f("gstin")} /></Field>
      <Field label="Company Secretary Name"><Input {...f("csName")} /></Field>
      <Field label="CS Membership No."><Input {...f("csMembershipNo")} /></Field>
      <Field label="Statutory Auditor" className="md:col-span-2">
        {auditors.length > 0 ? (
          <Select value={value.auditorId || ""} onValueChange={pickAuditor}>
            <SelectTrigger><SelectValue placeholder="Select from Auditor Master" /></SelectTrigger>
            <SelectContent>
              {auditors.map((a) => (
                <SelectItem key={a.id} value={a.id}>{a.firmName}{a.frn ? ` — ${a.frn}` : ""}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <p className="text-xs text-muted-foreground">No auditors yet — add one in the Auditor Master first.</p>
        )}
      </Field>
    </div>
  );
}

export function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-1.5 block">{label}</Label>
      {children}
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b pb-6">
      <div>
        <h1 className="font-serif text-3xl font-semibold text-foreground">{title}</h1>
        {subtitle && <p className="text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <Card className="p-12 text-center border-dashed">
      <div className="mx-auto text-muted-foreground/60">{icon}</div>
      <p className="mt-4 text-muted-foreground">{text}</p>
    </Card>
  );
}
