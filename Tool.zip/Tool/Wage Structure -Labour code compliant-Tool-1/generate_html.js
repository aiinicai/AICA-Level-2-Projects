import fs from 'fs';

const mwDataJson = fs.readFileSync('src/data/mw_raw.json', 'utf8');

const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Salary Structuring & Labour Code Compliance Calculator with Minimum Wage Matrix</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<style>
  :root{
    --paper:#F5F4EE; --ink:#0F2F22; --ink-soft:#3C5648;
    --emerald:#1F7A52; --emerald-deep:#0B2E22; --mint:#E4EFE6; --mint-line:#C9DCCB;
    --amber:#B9762A; --amber-mint:#F6ECDD;
    --red:#A13B2E; --red-mint:#F5E4DF;
    --card:#FFFFFF; --shadow:0 1px 3px rgba(11,46,34,.06), 0 6px 18px rgba(11,46,34,.05);
  }
  *{box-sizing:border-box;}
  body{margin:0; background:var(--paper); color:var(--ink); font-family:'IBM Plex Sans',sans-serif; padding:0 0 60px;}
  .topbar{background:var(--emerald-deep); color:var(--paper); padding:10px 22px; font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:.1em; text-transform:uppercase; display:flex; justify-content:space-between;}
  .wrap{max-width:1260px; margin:0 auto; padding:26px 18px 0;}
  header{display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:14px; margin-bottom:22px; border-bottom:2px solid var(--emerald-deep); padding-bottom:16px;}
  .eyebrow{font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:.14em; text-transform:uppercase; color:var(--emerald); margin:0 0 6px;}
  h1{font-family:'Fraunces',serif; font-weight:700; font-size:28px; margin:0; color:var(--emerald-deep);}
  .sub{font-size:12.5px; color:var(--ink-soft); margin-top:5px; max-width:680px; line-height:1.55;}
  .stamp-box{display:flex; gap:10px; flex-wrap:wrap;}
  .stamp{font-family:'IBM Plex Mono',monospace; font-weight:600; font-size:12.5px; letter-spacing:.07em; padding:9px 16px; border:2px solid; border-radius:4px; transform:rotate(-2deg); white-space:nowrap;}
  .stamp.pass{color:var(--emerald-deep); border-color:var(--emerald); background:var(--mint);}
  .stamp.flag{color:var(--amber); border-color:var(--amber); background:var(--amber-mint);}
  .stamp.deficit{color:var(--red); border-color:var(--red); background:var(--red-mint);}

  .card{background:var(--card); border:1px solid var(--mint-line); border-radius:12px; padding:22px; margin-bottom:18px; box-shadow:var(--shadow);}
  .card h2{font-family:'Fraunces',serif; font-size:16.5px; margin:0 0 14px; color:var(--emerald-deep); display:flex; align-items:center; gap:9px;}
  .card h2 .n{font-family:'IBM Plex Mono',monospace; font-size:10.5px; background:var(--emerald-deep); color:var(--paper); padding:3px 8px; border-radius:3px;}

  label{display:block; font-size:11.5px; font-weight:600; color:var(--ink-soft); margin:0 0 4px;}
  input[type=text], input[type=number], select, input[type=file]{
    width:100%; padding:8px 9px; border:1px solid var(--mint-line); border-radius:6px;
    font-family:'IBM Plex Mono',monospace; font-size:13px; background:#FCFDFB; color:var(--ink);
  }
  input:focus, select:focus{outline:2px solid var(--emerald); outline-offset:1px; border-color:var(--emerald);}
  input:disabled, select:disabled {background:#E9EBEA; color:#888; cursor:not-allowed;}

  .toprow{display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:10px;}
  @media(max-width:900px){.toprow{grid-template-columns:1fr 1fr;}}
  @media(max-width:580px){.toprow{grid-template-columns:1fr;}}
  .sectionlabel{font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:.08em; text-transform:uppercase; color:var(--emerald); margin:14px 0 8px; border-top:1px dashed var(--mint-line); padding-top:12px;}

  table.alw{width:100%; border-collapse:collapse; font-size:12px;}
  table.alw th{text-align:left; font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:.05em; text-transform:uppercase; color:var(--ink-soft); border-bottom:1px solid var(--mint-line); padding:7px 5px;}
  table.alw td{padding:6px 5px; border-bottom:1px solid #F0F0EC; vertical-align:middle;}
  table.alw tr:hover td{background:#FBFBF8;}
  table.alw input[type=number]{width:110px; padding:5px 6px; font-size:12px;}
  table.alw input[type=checkbox]{width:16px; height:16px; accent-color:var(--emerald-deep);}
  .grp-row td{background:var(--mint); font-weight:700; color:var(--emerald-deep); font-family:'IBM Plex Mono',monospace; font-size:10.5px; text-transform:uppercase; letter-spacing:.05em;}
  .badge{display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:700; padding:2px 7px; border-radius:10px; white-space:nowrap;}
  .badge.WAGES{background:var(--red-mint); color:var(--red);}
  .badge.CAP{background:var(--mint); color:var(--emerald-deep);}
  
  .note{font-size:10.5px; color:var(--ink-soft); font-style:italic;}
  .freqsel{width:105px; font-size:11px; padding:5px;}

  .btnrow{display:flex; gap:10px; margin-top:18px; flex-wrap:wrap; justify-content: flex-end; padding-top: 15px; border-top: 1px dashed var(--mint-line);}
  button{font-family:'IBM Plex Sans',sans-serif; font-weight:600; font-size:13px; padding:10px 18px; border-radius:6px; border:none; cursor:pointer;}
  .btn-primary{background:var(--emerald-deep); color:var(--paper);}
  .btn-ghost{background:var(--card); color:var(--emerald-deep); border:1px solid var(--emerald);}
  .btn-amber{background:var(--emerald); color:var(--paper);}
  .btn-adjust{background:#8B2516; color:#fff; padding:8px 16px; font-size:12.5px; border-radius:6px; cursor:pointer;}
  button:hover{opacity:0.92;}

  table.ec{width:100%; border-collapse:collapse; font-size:12.5px;}
  table.ec th{text-align:right; font-family:'IBM Plex Mono',monospace; font-size:10px; text-transform:uppercase; letter-spacing:.05em; color:var(--ink-soft); border-bottom:2px solid var(--emerald-deep); padding:8px 6px;}
  table.ec th:first-child{text-align:left;}
  table.ec td{padding:7px 6px; border-bottom:1px solid #F0F0EC; font-family:'IBM Plex Mono',monospace; text-align:right;}
  table.ec td:first-child{text-align:left; font-family:'IBM Plex Sans',sans-serif;}
  table.ec tr.subtotal td{font-weight:700; background:var(--mint); color:var(--emerald-deep); border-top:1px solid var(--emerald); border-bottom:1px solid var(--emerald);}
  table.ec tr.grand td{font-weight:700; background:var(--emerald-deep); color:var(--paper); font-size:13.5px;}
  table.ec tr.sectiongap td{border:none; padding:4px 0;}

  .test-box{border-radius:10px; padding:16px; margin-bottom:14px; border:1px solid;}
  .test-box.pass{background:var(--mint); border-color:var(--emerald);}
  .test-box.flag{background:var(--amber-mint); border-color:var(--amber);}
  .test-box.deficit{background:var(--red-mint); border-color:var(--red);}
  .test-box .tt{font-weight:700; font-size:13.5px; margin-bottom:6px;}
  .test-box.pass .tt{color:var(--emerald-deep);}
  .test-box.flag .tt{color:var(--amber);}
  .test-box.deficit .tt{color:var(--red);}
  .test-box p{font-size:12px; margin:3px 0; line-height:1.55; color:var(--ink-soft);}
  .test-box table{width:100%; margin-top:8px; border-collapse:collapse; font-size:11.5px;}
  .test-box table td{padding:3px 4px; font-family:'IBM Plex Mono',monospace;}
  .test-box table td:first-child{font-family:'IBM Plex Sans',sans-serif; color:var(--ink-soft);}
  .test-box table td:last-child{text-align:right;}
  .test-box table tr.linetotal td{border-top:1px solid; font-weight:700;}
  .test-box table tr.highlight-row td{background:rgba(255,255,255,0.5); font-weight:600;}

  .reconcile{display:flex; gap:14px; flex-wrap:wrap; margin-top:10px;}
  .reconcile .chip{background:var(--card); border:1px solid var(--mint-line); border-radius:8px; padding:10px 14px; font-family:'IBM Plex Mono',monospace; font-size:12px;}
  .reconcile .chip b{display:block; font-family:'Fraunces',serif; font-size:15px; color:var(--emerald-deep);}

  .mw-grid{display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin:14px 0;}
  @media(max-width:800px){.mw-grid{grid-template-columns:1fr 1fr;}}
  .mw-stat-box{background:#FCFDFB; border:1px solid var(--mint-line); border-radius:8px; padding:12px 14px;}
  .mw-stat-label{font-family:'IBM Plex Mono',monospace; font-size:10.5px; text-transform:uppercase; color:var(--ink-soft); margin-bottom:4px;}
  .mw-stat-val{font-family:'Fraunces',serif; font-size:19px; font-weight:700; color:var(--emerald-deep);}
  .mw-stat-sub{font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--ink-soft); margin-top:2px;}
</style>
</head>
<body onload="initAll();">
<div class="topbar">
  <span>Robust Salary Structuring & Compliance Tool</span>
  <span>Engine: Dynamic v11.0 (Pan-India Minimum Wage Matrix & Multi-Currency)</span>
</div>
<div class="wrap">

  <header>
    <div>
      <p class="eyebrow">Comprehensive Wage Structuring</p>
      <h1>Gross → CTC → Net-in-Hand Breakup</h1>
      <p class="sub">Validates against CoSS 2020 definitions, 28-state Pan-India Shop &amp; Establishment Minimum Wage matrix, 16-state event-based LWF rules, gender-mapped PT, and real-time multi-currency conversion.</p>
    </div>
    <div class="stamp-box">
      <div id="mwStampBox" class="stamp pass">MIN WAGE: CHECKING</div>
      <div id="cossStampBox" class="stamp pass">CoSS: CHECKING</div>
    </div>
  </header>

  <!-- CARD 00: BULK PROCESSING ENGINE -->
  <div class="card" id="bulkCard">
    <h2><span class="n">00</span> Bulk Processing Engine (Multi-Currency Excel Upload &amp; ZIP Export)</h2>
    <p class="sub" style="margin-top:-6px; margin-bottom:14px;">Download the template, fill employee roster with individual Currency, ExchangeRate, State, Zone, Category &amp; target CTC/Gross, and upload to generate Master Excel Register, individual Excel files with live formulas, and individual PDF Annexures bundled in a ZIP.</p>
    <div class="toprow" style="align-items:flex-end;">
      <div style="grid-column: span 2;">
        <label>Upload Roster Data (.xlsx)</label>
        <input type="file" id="bulkUpload" accept=".xlsx, .xls" style="padding: 6px; background: #fff;">
      </div>
      <div>
        <button class="btn-primary" style="width:100%; padding:9px 18px;" onclick="processBulk()">Process &amp; Download ZIP</button>
      </div>
      <div>
        <button class="btn-ghost" style="width:100%; padding:9px 18px;" onclick="downloadTemplate()">Download Template</button>
      </div>
    </div>
    <div id="bulkStatus" style="font-size:12.5px; font-weight:600; color:var(--emerald); margin-top:10px;"></div>
  </div>

  <!-- CARD 01: EMPLOYEE, STATUTORY & WORKING PARAMETERS -->
  <div class="card">
    <h2><span class="n">01</span> Employee, Statutory &amp; Working Parameters</h2>

    <!-- Currency Configuration Block -->
    <div style="background:#F8FAF7; border:1px solid var(--mint-line); border-radius:8px; padding:14px; margin-bottom:16px;">
      <div style="font-family:'IBM Plex Mono',monospace; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:var(--emerald-deep); margin-bottom:10px; display:flex; align-items:center; gap:8px;">
        <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--emerald);"></span>
        Currency Configuration &amp; Conversion Engine
      </div>
      <div class="toprow">
        <div>
          <label>Base Input Currency</label>
          <select id="baseCurrency" onchange="onInputCurrencyChange()">
            <option value="INR" selected>INR (₹) — Indian Rupee</option>
            <option value="USD">USD ($) — US Dollar</option>
            <option value="EUR">EUR (€) — Euro</option>
            <option value="GBP">GBP (£) — British Pound</option>
            <option value="AED">AED (AED) — UAE Dirham</option>
            <option value="SGD">SGD (S$) — Singapore Dollar</option>
            <option value="CAD">CAD (C$) — Canadian Dollar</option>
            <option value="AUD">AUD (A$) — Australian Dollar</option>
            <option value="JPY">JPY (¥) — Japanese Yen</option>
          </select>
        </div>
        <div>
          <label id="lblExchangeRate">Exchange Rate (1 FCY = X INR)</label>
          <input type="number" id="exchangeRate" value="1.00" step="0.01" min="0.0001" disabled oninput="calculate()">
        </div>
        <div style="grid-column: span 2;">
          <label>Perform complete end-to-end calculation and display all outputs in:</label>
          <select id="displayCurrency" onchange="calculate()">
            <option value="INR" selected>Option A: INR (₹) [Statutory conversion applied for testing]</option>
            <option value="FCY">Option B: Selected Foreign Currency (FCY) [End-to-end converted]</option>
          </select>
        </div>
      </div>
      <div class="note" style="margin-top:6px;">
        * Note on Indian Statutory Compliance: Statutory testing limits (PF ceiling of ₹15,000, ESI cap of ₹21,000, LWF, PT slabs, and State Minimum Wages) remain strictly pegged to INR, evaluated for legal compliance, and then rendered in your selected display currency.
      </div>
    </div>

    <div class="toprow">
      <div><label>Employee Name</label><input type="text" id="empName" placeholder="e.g. Aditi Sharma" value="Aditi Sharma"></div>
      <div><label>Employee Code</label><input type="text" id="empCode" placeholder="e.g. EMP-1042" value="EMP-1042"></div>
      <div>
        <label>Gender (Drives PT Exemption)</label>
        <select id="gender" onchange="calculate()">
          <option value="M">Male</option>
          <option value="F" selected>Female</option>
          <option value="O">Other</option>
        </select>
      </div>
      <div><label>Working Days / Month</label><input type="number" id="workDays" value="30" min="20" max="31" oninput="calculate()"></div>
    </div>

    <div class="toprow">
      <div><label>Working Hours / Day</label><input type="number" id="workHours" value="8" min="4" max="12" step="0.5" oninput="calculate()"></div>
      <div>
        <label>PF Contribution Strategy</label>
        <select id="pfStrategy" onchange="togglePfLimit()">
          <option value="capped">Capped at Statutory Ceiling (e.g. ₹15,000)</option>
          <option value="full_basic">Uncapped on Basic Pay Only</option>
          <option value="full_wages">Uncapped on Full Wage Base</option>
          <option value="full_gross">Uncapped on Full Gross Salary</option>
        </select>
      </div>
      <div>
        <label>Statutory PF Ceiling Limit (₹)</label>
        <input type="number" id="pfLimitAmt" value="15000" step="1000" min="0" oninput="calculate()">
      </div>
      <div>
        <label>Include Gratuity in Cost to Company?</label>
        <select id="includeGratuity" onchange="calculate()">
          <option value="yes">Yes — add to CTC</option>
          <option value="no">No — costed separately</option>
        </select>
      </div>
    </div>

    <div class="toprow">
      <div>
        <label>State (Drives PT &amp; Event LWF)</label>
        <select id="stateSel" onchange="onStateSelChange()">
          <option value="MH" selected>Maharashtra</option>
          <option value="KA">Karnataka</option>
          <option value="DL">Delhi</option>
          <option value="TS">Telangana</option>
          <option value="AP">Andhra Pradesh</option>
          <option value="GJ">Gujarat</option>
          <option value="TN">Tamil Nadu</option>
          <option value="WB">West Bengal</option>
          <option value="HR">Haryana</option>
          <option value="MP">Madhya Pradesh</option>
          <option value="RJ">Rajasthan</option>
          <option value="PB">Punjab</option>
          <option value="BR">Bihar</option>
          <option value="CG">Chhattisgarh</option>
          <option value="OD">Odisha</option>
          <option value="JH">Jharkhand</option>
          <option value="AS">Assam</option>
          <option value="HP">Himachal Pradesh</option>
          <option value="UK">Uttarakhand</option>
          <option value="CH">Chandigarh</option>
          <option value="JK">Jammu &amp; Kashmir</option>
          <option value="AN">Andaman &amp; Nicobar</option>
          <option value="PY">Puducherry</option>
          <option value="DN">Dadra &amp; Nagar Haveli</option>
          <option value="LA">Ladakh</option>
          <option value="TR">Tripura</option>
          <option value="ML">Meghalaya</option>
          <option value="KL">Kerala</option>
          <option value="GA">Goa</option>
          <option value="OT">Other / Not Applicable</option>
        </select>
      </div>
      <div><label>Professional Tax (₹) — Override</label><input type="number" id="ptOverride" placeholder="Auto-calculated" oninput="calculate()"></div>
      <div>
        <label>Apply State LWF Deduction?</label>
        <select id="applyLwf" onchange="calculate()"><option value="yes">Yes (Checks State Matrix)</option><option value="no">No</option></select>
      </div>
      <div>
        <label>Statutory Wage Definition Base</label>
        <select id="statutoryLogic" onchange="calculate()">
          <option value="coss">CoSS 2020 (50% Inclusion Rule)</option>
          <option value="old">Pre-CoSS / Legacy</option>
        </select>
      </div>
    </div>

    <div class="toprow">
      <div>
        <label>Round Off Figures?</label>
        <select id="roundOff" onchange="calculate()">
          <option value="yes">Yes (No decimals)</option>
          <option value="no" selected>No (Keep decimals)</option>
        </select>
      </div>
    </div>

    <div class="sectionlabel">Leave Upliftment (Optional add-on to CTC)</div>
    <div class="toprow">
      <div><label>Leave Upliftment?</label><select id="leaveUplift" onchange="calculate()"><option value="no">No</option><option value="yes">Yes</option></select></div>
      <div><label>Total Working Days in Year</label><input type="number" id="annualWorkDays" value="225" min="150" max="366" oninput="calculate()"></div>
      <div><label>Total Leaves Eligible (per year)</label><input type="number" id="leavesEligible" value="30" min="0" max="90" oninput="calculate()"></div>
    </div>

    <div class="sectionlabel">Calculation Mode</div>
    <div class="toprow">
      <div>
        <label>Mode</label>
        <select id="calcMode" onchange="toggleMode()"><option value="buildup">Build-up from components</option><option value="reverse">Reverse-calculate from a target</option></select>
      </div>
      <div id="revTargetTypeWrap" style="display:none;"><label>Target Type</label><select id="revTargetType" onchange="calculate()"><option value="ctc">Cost to Company (CTC)</option><option value="gross">Gross Salary</option></select></div>
      <div id="revTargetRateWrap" style="display:none;"><label>Target Rate</label><select id="revTargetRate" onchange="calculate()"><option value="monthly">Monthly</option><option value="daily">Daily</option><option value="hourly">Hourly</option></select></div>
      <div id="revTargetAmtWrap" style="display:none;"><label id="lblRevTargetAmt">Target Amount (₹)</label><input type="number" id="revTargetAmt" value="125000" min="0" oninput="calculate()"></div>
    </div>
    
    <div id="revStrategyWrap" style="display:none; margin-top: 10px;" class="toprow">
      <div>
        <label>Allocation Strategy</label>
        <select id="revStrategy" onchange="toggleStrategy()">
          <option value="default">Default (50% Basic)</option>
          <option value="custom">Custom Percentages</option>
        </select>
      </div>
    </div>
    <div id="customPercWrap" style="display:none; margin-top: 10px;" class="toprow">
      <div><label>Basic % (Min 50%)</label><input type="number" id="custBasicPerc" value="50" min="50" oninput="calculate()"></div>
      <div><label>HRA % (of Target)</label><input type="number" id="custHraPerc" value="20" oninput="calculate()"></div>
      <div><label>Conveyance % (of Target)</label><input type="number" id="custConvPerc" value="3" oninput="calculate()"></div>
    </div>
  </div>

  <!-- CARD 02: SALARY COMPONENTS -->
  <div class="card">
    <h2><span class="n">02</span> Salary Components — Monthly (<span id="compCurrSym">₹</span>)</h2>
    <table class="alw" id="alwTable"></table>
  </div>

  <!-- CARD ·: RECONCILIATION ENGINE CHECK -->
  <div id="reconcileCard" class="card" style="display:none;">
    <h2><span class="n">·</span> Reconciliation Engine Check</h2>
    <div class="reconcile">
      <div class="chip">Target (Monthly)<b id="rcTarget">—</b></div>
      <div class="chip">Computed (Monthly)<b id="rcComputed">—</b></div>
      <div class="chip">Difference<b id="rcDiff">—</b></div>
      <div class="chip">Status<b id="rcStatus">—</b></div>
    </div>
  </div>

  <!-- CARD 03: CONTRACT BREAKUP -->
  <div class="card">
    <h2><span class="n">03</span> Contract Breakup — Standard &amp; Event Months (<span id="breakupCurrHeader">INR</span>)</h2>
    <table class="ec" id="ecTable"></table>
    
    <div class="btnrow">
      <button class="btn-ghost" onclick="resetForm()">Reset Fields</button>
      <button class="btn-ghost" onclick="exportPdf()">Export PDF Summary</button>
      <button class="btn-amber" onclick="downloadExcel()">Export Complete Working to Excel</button>
    </div>
  </div>

  <!-- CARD 03.5: PAN-INDIA MINIMUM WAGE COMPLIANCE & AUDIT MATRIX -->
  <div class="card" id="minWageCard">
    <h2><span class="n">03.5</span> Minimum Wage Compliance &amp; Audit Matrix</h2>
    <p class="sub" style="margin-top:-6px; margin-bottom:14px;">
      Embedded Pan-India Shop &amp; Establishment Minimum Wage matrix across 28 states and union territories. Dynamically validates computed basic &amp; DA against applicable statutory thresholds.
    </p>

    <div class="toprow">
      <div>
        <label>State / Union Territory</label>
        <select id="mwStateSel" onchange="onMwStateChange()"></select>
      </div>
      <div>
        <label>Zone / Region Classification</label>
        <select id="mwZoneSel" onchange="onMwZoneChange()"></select>
      </div>
      <div style="grid-column: span 2;">
        <label>Skill Category</label>
        <select id="mwCatSel" onchange="calculate()"></select>
      </div>
    </div>

    <!-- Metadata strip -->
    <div style="background:#FAFBF9; border:1px solid var(--mint-line); border-radius:8px; padding:12px; margin:10px 0; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; font-size:12px;">
      <div>
        <span style="font-weight:700; color:var(--emerald-deep);">Covered Roles: </span>
        <span id="mwDescription" style="color:var(--ink-soft); font-style:italic;">—</span>
      </div>
      <div style="font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--ink-soft);">
        <span id="mwPeriod">Gazette Period</span>
      </div>
    </div>

    <!-- Minimum Wage Rates Grid -->
    <div class="mw-grid">
      <div class="mw-stat-box">
        <div class="mw-stat-label">Statutory Min. Basic</div>
        <div class="mw-stat-val" id="mwDispBasic">—</div>
        <div class="mw-stat-sub" id="mwInrBasic">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Dearness Allowance (DA)</div>
        <div class="mw-stat-val" id="mwDispDA">—</div>
        <div class="mw-stat-sub" id="mwInrDA">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Total Minimum Wage</div>
        <div class="mw-stat-val" id="mwDispTotal">—</div>
        <div class="mw-stat-sub" id="mwInrTotal">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Current Computed Wage</div>
        <div class="mw-stat-val" id="mwDispComputed" style="color:#1F7A52;">—</div>
        <div class="mw-stat-sub">Basic + DA</div>
      </div>
    </div>

    <!-- Audit Status & Action Banner -->
    <div id="mwAuditBox" class="test-box pass">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div>
          <div class="tt" id="mwAuditTitle">Running Minimum Wage Audit…</div>
          <p id="mwAuditBody"></p>
        </div>
        <div id="mwActionWrap" style="display:none;">
          <button class="btn-adjust" onclick="autoAdjustBasic()">Auto-Adjust Basic to Min Wage</button>
        </div>
      </div>
      <div id="autoAdjustToast" style="display:none; margin-top:8px; font-size:11.5px; font-weight:700; color:var(--emerald-deep); background:rgba(255,255,255,0.7); padding:6px 10px; border-radius:4px;"></div>
    </div>
  </div>

  <!-- CARD 05: STATUTORY TESTING OUTPUT -->
  <div class="card">
    <h2><span class="n">05</span> Statutory Testing Output</h2>
    <div id="testBox" class="test-box pass">
      <div class="tt" id="testTitle">Running test…</div>
      <p id="testBody"></p>
      <table id="testDetail"></table>
    </div>
    <div id="esiBox" class="test-box pass" style="margin-bottom:0;">
      <div class="tt" id="esiTitle">ESI Coverage</div>
      <p id="esiBody"></p>
    </div>
  </div>
</div>

<script>
// Embedded Pan-India Shop & Establishment Minimum Wage Matrix
// [State, Region, Category, Description, Period, [b1, d1, t1], [b2, d2, t2], ...]
const RAW_MW = ${mwDataJson};

const CURRENCIES = {
  INR: { sym: '₹', rate: 1.0, name: 'Indian Rupee' },
  USD: { sym: '$', rate: 83.50, name: 'US Dollar' },
  EUR: { sym: '€', rate: 91.20, name: 'Euro' },
  GBP: { sym: '£', rate: 106.80, name: 'British Pound' },
  AED: { sym: 'AED ', rate: 22.74, name: 'UAE Dirham' },
  SGD: { sym: 'S$', rate: 62.40, name: 'Singapore Dollar' },
  CAD: { sym: 'C$', rate: 61.50, name: 'Canadian Dollar' },
  AUD: { sym: 'A$', rate: 55.20, name: 'Australian Dollar' },
  JPY: { sym: '¥', rate: 0.56, name: 'Japanese Yen' }
};

const els = id => document.getElementById(id);
const isRounded = () => els('roundOff') && els('roundOff').value === 'yes';

function getInputCurrency() { return els('baseCurrency') ? els('baseCurrency').value : 'INR'; }
function getExchangeRate() { 
  const c = getInputCurrency();
  if (c === 'INR') return 1.0;
  return els('exchangeRate') ? (parseFloat(els('exchangeRate').value) || 1.0) : 1.0;
}
function getDisplayCurrencyCode() {
  const mode = els('displayCurrency') ? els('displayCurrency').value : 'INR';
  return mode === 'FCY' ? getInputCurrency() : 'INR';
}

function toINR(valInInputCurr) {
  const c = getInputCurrency();
  if (c === 'INR') return valInInputCurr;
  return valInInputCurr * getExchangeRate();
}
function fromINR(valINR, targetCurr) {
  const t = targetCurr || getDisplayCurrencyCode();
  if (t === 'INR') return valINR;
  const rate = getExchangeRate();
  return rate > 0 ? (valINR / rate) : valINR;
}

function fmt(nINR) {
  const dispCurr = getDisplayCurrencyCode();
  const converted = fromINR(nINR, dispCurr);
  const sym = CURRENCIES[dispCurr] ? CURRENCIES[dispCurr].sym : '₹';
  const r = isRounded();
  let val = r ? Math.round(converted) : Math.round(converted * 100) / 100;
  if (val === -0) val = 0;
  const numStr = Math.abs(val).toLocaleString(dispCurr === 'INR' ? 'en-IN' : 'en-US', {
    minimumFractionDigits: r ? 0 : 2,
    maximumFractionDigits: r ? 0 : 2
  });
  return (val < 0 ? '-' + sym : sym) + numStr;
}

function fmtRaw(amt, currCode) {
  const sym = CURRENCIES[currCode] ? CURRENCIES[currCode].sym : '';
  const r = isRounded();
  let val = r ? Math.round(amt) : Math.round(amt * 100) / 100;
  if (val === -0) val = 0;
  return (val < 0 ? '-' + sym : sym) + Math.abs(val).toLocaleString(currCode === 'INR' ? 'en-IN' : 'en-US', {
    minimumFractionDigits: r ? 0 : 2,
    maximumFractionDigits: r ? 0 : 2
  });
}

const EMPLOYER_PF_RATE = 0.13; 
const EMPLOYEE_PF_RATE = 0.12;
const GRATUITY_RATE = 0.0481;

const CATALOG = [
  {grp:'Statutory Exclusions — Cap-Tested (Sec 2(y), clauses a,d,e,f,h,i)', items:[
    {id:'hra', label:'House Rent Allowance (HRA)', clause:'(f)', classification:'CAP', esiExcluded:false, requiresDoc:false, needsFreq:false, def:25000},
    {id:'conveyance', label:'Conveyance / Transport Allowance', clause:'(d)', classification:'CAP', esiExcluded:false, requiresDoc:false, needsFreq:false, def:1600},
    {id:'lta', label:'Leave Travel Allowance (LTA)', clause:'(d)', classification:'CAP', esiExcluded:true, requiresDoc:true, needsFreq:true, def:0},
    {id:'overtime', label:'Overtime Allowance', clause:'(h)', classification:'CAP', esiExcluded:false, requiresDoc:false, needsFreq:false, def:0},
    {id:'commission', label:'Sales Commission (target-linked)', clause:'(i)', classification:'CAP', esiExcluded:true, requiresDoc:true, needsFreq:false, def:0},
    {id:'statBonus', label:'Statutory / Customary Bonus', clause:'(a)', classification:'CAP', esiExcluded:false, requiresDoc:false, needsFreq:true, def:0},
  ]},
  {grp:'Balancing / Risk Allowances — Not in any exclusion clause = Wages', items:[
    {id:'specialAllow', label:'Special Allowance (CTC balancing)', clause:'—', classification:'WAGES', esiExcluded:false, requiresDoc:false, needsFreq:false, def:20000},
    {id:'otherAllow', label:'Other / Supplementary Allowance', clause:'—', classification:'WAGES', esiExcluded:false, requiresDoc:false, needsFreq:false, def:0},
    {id:'medicalFlat', label:'Medical Allowance (flat)', clause:'—', classification:'WAGES', esiExcluded:false, requiresDoc:false, needsFreq:false, def:0},
  ]},
];
const FREQ_OPTS = ['Monthly','Quarterly','HalfYearly','Annual'];

function buildTable(){
  const tbl = els('alwTable');
  if(!tbl) return;
  const inCurr = getInputCurrency();
  const sym = CURRENCIES[inCurr] ? CURRENCIES[inCurr].sym : '₹';
  if(els('compCurrSym')) els('compCurrSym').textContent = sym;
  if(els('lblRevTargetAmt')) els('lblRevTargetAmt').textContent = 'Target Amount (' + sym + ')';

  let html = '<tr><th style="width:26px;"></th><th>Component</th><th>Clause</th><th>Monthly (' + sym + ')</th><th>Frequency</th><th>Classification</th></tr>';
  html += '<tr class="grp-row"><td colspan="6">Core Wages — always Basic + DA</td></tr>' +
    '<tr><td></td><td>Basic Pay</td><td class="note">—</td><td><input type="number" id="basicIn" value="50000" min="0" step="100" oninput="calculate()"></td><td class="note">Monthly</td><td><span class="badge WAGES">WAGES</span></td></tr>' +
    '<tr><td></td><td>Dearness Allowance (DA)</td><td class="note">—</td><td><input type="number" id="daIn" value="0" min="0" step="100" oninput="calculate()"></td><td class="note">Monthly</td><td><span class="badge WAGES">WAGES</span></td></tr>';
  
  CATALOG.forEach(group=>{
    html += '<tr class="grp-row"><td colspan="6">' + group.grp + '</td></tr>';
    group.items.forEach(it=>{
      const isChecked = (it.id === 'hra' || it.id === 'conveyance' || it.id === 'specialAllow') ? 'checked' : '';
      html += '<tr data-id="' + it.id + '">' +
        '<td><input type="checkbox" id="chk_' + it.id + '" ' + isChecked + ' onchange="calculate()"></td>' +
        '<td>' + it.label + '</td>' +
        '<td class="note">' + it.clause + '</td>' +
        '<td><input type="number" id="amt_' + it.id + '" value="' + it.def + '" min="0" step="100" oninput="calculate()"></td>' +
        '<td>' + (it.needsFreq ? '<select id="freq_' + it.id + '" class="freqsel" onchange="calculate()">' + FREQ_OPTS.map(f=>'<option value="' + f + '">' + f + '</option>').join('') + '</select>' : '<span class="note">Monthly</span>') + '</td>' +
        '<td><span class="badge ' + it.classification + '">' + it.classification + '</span></td>' +
      '</tr>';
    });
  });
  tbl.innerHTML = html;
}

function onInputCurrencyChange() {
  const c = getInputCurrency();
  const cfg = CURRENCIES[c] || CURRENCIES.INR;
  const rateInput = els('exchangeRate');
  if (rateInput) {
    rateInput.value = cfg.rate;
    rateInput.disabled = (c === 'INR');
  }
  buildTable();
  calculate();
}

const STATE_MAP = {
  MH: "Maharashtra", KA: "Karnataka", DL: "Delhi", TS: "Telangana", AP: "Andhra Pradesh",
  GJ: "Gujarat", TN: "Tamil Nadu", WB: "West Bengal", HR: "Haryana", MP: "Madhya Pradesh",
  RJ: "Rajasthan", PB: "Punjab", BR: "Bihar", CG: "Chhattisgarh", OD: "Odisha", JH: "Jharkhand",
  AS: "Assam", HP: "Himachal Pradesh", UK: "Uttarakhand", CH: "Chandigarh", JK: "Jammu & Kashmir",
  AN: "Andaman & Nicobar", PY: "Puducherry", DN: "Dadra & Nagar Haveli and Daman & Diu",
  LA: "Ladakh", TR: "Tripura", ML: "Meghalaya", KL: "Kerala", GA: "Goa"
};

function initMwControls() {
  const stateSel = els('mwStateSel');
  if (!stateSel) return;
  const uniqueStates = [...new Set(RAW_MW.map(r => r[0]))];
  stateSel.innerHTML = uniqueStates.map(s => '<option value="' + s + '">' + s + '</option>').join('');
  stateSel.value = "Maharashtra";
  populateZonesAndCats();
}

function populateZonesAndCats() {
  const st = els('mwStateSel').value;
  const rows = RAW_MW.filter(r => r[0] === st);
  const zoneSel = els('mwZoneSel');
  if (!rows.length) return;
  
  // zones length based on first row rates
  const numZones = rows[0].slice(5).length;
  let zoneNames = ['Zone I'];
  if (numZones === 2) zoneNames = ['Zone I', 'Zone II'];
  else if (numZones === 3) zoneNames = ['Zone I', 'Zone II', 'Zone III'];
  else if (numZones === 4) zoneNames = ['Zone I', 'Zone II', 'Zone III', 'Zone IV'];
  
  if (st === 'Himachal Pradesh') zoneNames = ['Without Benefits (Food/Accomm)', 'With Benefits (Food/Accomm)'];
  if (st === 'Uttarakhand') zoneNames = ['Towns > 1 Lakh Pop', 'Remaining Parts'];
  if (st === 'Jharkhand') zoneNames = ['Area A (Corporations)', 'Area B (Municipalities)', 'Area C (Other Areas)'];

  zoneSel.innerHTML = zoneNames.map((z, idx) => '<option value="' + idx + '">' + z + '</option>').join('');
  populateCats();
}

function populateCats() {
  const st = els('mwStateSel').value;
  const rows = RAW_MW.filter(r => r[0] === st);
  const catSel = els('mwCatSel');
  catSel.innerHTML = rows.map((r, i) => '<option value="' + i + '">' + r[2] + '</option>').join('');
  updateMwDetails();
}

function updateMwDetails() {
  const st = els('mwStateSel').value;
  const rows = RAW_MW.filter(r => r[0] === st);
  const catIdx = parseInt(els('mwCatSel').value) || 0;
  const r = rows[catIdx] || rows[0];
  if (!r) return;
  if (els('mwDescription')) els('mwDescription').textContent = r[3] || 'All covered occupations under Shop & Establishment';
  if (els('mwPeriod')) els('mwPeriod').textContent = r[4] || '';
}

function onStateSelChange() {
  const c = els('stateSel').value;
  if (STATE_MAP[c]) {
    els('mwStateSel').value = STATE_MAP[c];
    populateZonesAndCats();
  }
  calculate();
}
function onMwStateChange() {
  const st = els('mwStateSel').value;
  populateZonesAndCats();
  for (let k in STATE_MAP) {
    if (STATE_MAP[k] === st) {
      els('stateSel').value = k;
      break;
    }
  }
  calculate();
}
function onMwZoneChange() { calculate(); }

function getActiveMinWageRates() {
  const st = els('mwStateSel') ? els('mwStateSel').value : 'Maharashtra';
  const rows = RAW_MW.filter(r => r[0] === st);
  const catIdx = els('mwCatSel') ? (parseInt(els('mwCatSel').value) || 0) : 0;
  const row = rows[catIdx] || rows[0];
  if (!row) return { basic: 0, da: 0, total: 0 };
  const zoneIdx = els('mwZoneSel') ? (parseInt(els('mwZoneSel').value) || 0) : 0;
  const ratesList = row.slice(5);
  const rates = ratesList[zoneIdx] || ratesList[0] || [0, 0, 0];
  return { basic: rates[0], da: rates[1], total: rates[2] };
}

function togglePfLimit() {
  const pfStrat = els('pfStrategy');
  const pfLimit = els('pfLimitAmt');
  if(pfStrat && pfLimit) pfLimit.disabled = pfStrat.value !== 'capped';
  calculate();
}

function getPT(state, gross, gender) {
  const rules = {
    MH: (g, gen) => (gen === 'F' && g <= 25000) ? 0 : (g > 10000 ? 200 : (g > 7500 ? 175 : 0)),
    KA: (g, gen) => g > 15000 ? 200 : (g > 10000 ? 150 : 0),
    WB: (g, gen) => g > 25000 ? 200 : (g > 15000 ? 130 : (g > 10000 ? 110 : (g > 8500 ? 90 : 0))),
    TN: (g, gen) => g > 21000 ? 208 : (g > 12500 ? 182 : (g > 9000 ? 125 : (g > 6000 ? 73 : 0))),
    TS: (g, gen) => g > 20000 ? 200 : (g > 15000 ? 150 : 0),
    AP: (g, gen) => g > 20000 ? 200 : (g > 15000 ? 150 : 0),
    GJ: (g, gen) => g > 12000 ? 200 : (g > 9000 ? 150 : 0),
    MP: (g, gen) => g > 15000 ? 208 : (g > 12500 ? 130 : 0),
    AS: (g, gen) => g > 25000 ? 208 : (g > 20000 ? 180 : 0),
    OD: (g, gen) => g > 20000 ? 200 : (g > 15000 ? 150 : 0),
    CG: (g, gen) => g > 25000 ? 200 : (g > 16667 ? 150 : 0)
  };
  return rules[state] ? rules[state](gross, gender) : 0;
}

function getLWF(state, gross) {
  const rules = {
    AP: {ee: 30, er: 70, freq: 'Annually'},
    CH: {ee: 5, er: 20, freq: 'Monthly'},
    CG: {ee: 15, er: 45, freq: 'Half-Yearly'},
    DL: {ee: 0.75, er: 2.25, freq: 'Half-Yearly'},
    GA: {ee: 60, er: 180, freq: 'Half-Yearly'},
    GJ: {ee: 6, er: 12, freq: 'Half-Yearly'},
    HR: {ee: Math.min(gross*0.002, 34), er: Math.min(gross*0.004, 68), freq: 'Monthly'},
    KA: {ee: 50, er: 100, freq: 'Annually'},
    KL: {ee: 50, er: 50, freq: 'Monthly'},
    MP: {ee: 10, er: 30, freq: 'Half-Yearly'},
    MH: {ee: 25, er: 75, freq: 'Half-Yearly'},
    OD: {ee: 20, er: 40, freq: 'Half-Yearly'},
    PB: {ee: 5, er: 20, freq: 'Monthly'},
    TN: {ee: 20, er: 40, freq: 'Annually'},
    TS: {ee: 2, er: 5, freq: 'Annually'},
    WB: {ee: 3, er: 30, freq: 'Half-Yearly'},
    OT: {ee: 0, er: 0, freq: 'None'}
  };
  return rules[state] || rules['OT'];
}

function toggleStrategy() {
  const stratEl = els('revStrategy');
  const customWrap = els('customPercWrap');
  if(stratEl && customWrap) {
    customWrap.style.display = stratEl.value === 'custom' ? 'grid' : 'none';
  }
  calculate();
}

function toggleMode(){
  const modeEl = els('calcMode');
  if(!modeEl) return;
  const show = modeEl.value === 'reverse';
  if(els('revTargetTypeWrap')) els('revTargetTypeWrap').style.display = show ? '' : 'none';
  if(els('revTargetRateWrap')) els('revTargetRateWrap').style.display = show ? '' : 'none';
  if(els('revTargetAmtWrap')) els('revTargetAmtWrap').style.display = show ? '' : 'none';
  if(els('reconcileCard')) els('reconcileCard').style.display = show ? '' : 'none';
  if(els('revStrategyWrap')) els('revStrategyWrap').style.display = show ? 'grid' : 'none';
  if(show) toggleStrategy();
  calculate();
}

function computeAll(overrideCore){
  const rndFlg = isRounded();
  const R = v => rndFlg ? Math.round(v) : v;

  const pfStrategy = els('pfStrategy') ? els('pfStrategy').value : 'capped';
  const pfLimitAmt = els('pfLimitAmt') ? (parseFloat(els('pfLimitAmt').value) || 15000) : 15000;
  const includeGratuity = els('includeGratuity') ? els('includeGratuity').value === 'yes' : true;
  const workDays = els('workDays') ? (parseFloat(els('workDays').value) || 30) : 30;
  const workHours = els('workHours') ? (parseFloat(els('workHours').value) || 8) : 8;
  const state = els('stateSel') ? els('stateSel').value : 'MH';
  const gender = els('gender') ? els('gender').value : 'F';
  const leaveUpliftOn = els('leaveUplift') ? els('leaveUplift').value === 'yes' : false;
  const annualWorkDays = els('annualWorkDays') ? (parseFloat(els('annualWorkDays').value) || 225) : 225;
  const leavesEligible = els('leavesEligible') ? (parseFloat(els('leavesEligible').value) || 0) : 0;
  
  const applyLwf = els('applyLwf') ? els('applyLwf').value === 'yes' : true;
  const statutoryLogic = els('statutoryLogic') ? els('statutoryLogic').value : 'coss';

  // Read raw inputs in Base Input Currency, convert to INR for statutory evaluation
  const rawBasic = overrideCore ? overrideCore.basic : (els('basicIn') ? (parseFloat(els('basicIn').value) || 0) : 50000);
  const rawDa = els('daIn') ? (parseFloat(els('daIn').value) || 0) : 0;
  const basic = toINR(rawBasic);
  const da = toINR(rawDa);

  const rawHra = overrideCore ? overrideCore.hra : (els('chk_hra') && els('chk_hra').checked ? (parseFloat(els('amt_hra').value)||0) : 0);
  const rawConv = overrideCore ? overrideCore.conveyance : (els('chk_conveyance') && els('chk_conveyance').checked ? (parseFloat(els('amt_conveyance').value)||0) : 0);
  const rawSpecial = overrideCore ? overrideCore.special : (els('chk_specialAllow') && els('chk_specialAllow').checked ? (parseFloat(els('amt_specialAllow').value)||0) : 0);
  
  const hraVal = toINR(rawHra);
  const convVal = toINR(rawConv);
  const specialVal = toINR(rawSpecial);

  let wagesDirect = 0, capBasket = 0, grossCash = 0, esiWageRaw = 0;
  const lines = []; 

  lines.push({label:'Basic Pay', monthly:basic, cls:'WAGES'});
  if(da>0) lines.push({label:'Dearness Allowance (DA)', monthly:da, cls:'WAGES'});
  grossCash += basic+da; esiWageRaw += basic+da;

  if(overrideCore){
    if(hraVal>0){ lines.push({label:'House Rent Allowance (HRA)', monthly:hraVal, cls:'CAP'}); capBasket+=hraVal; grossCash+=hraVal; esiWageRaw+=hraVal; }
    if(convVal>0){ lines.push({label:'Conveyance / Transport Allowance', monthly:convVal, cls:'CAP'}); capBasket+=convVal; grossCash+=convVal; esiWageRaw+=convVal; }
    if(specialVal>0){ lines.push({label:'Special Allowance (CTC balancing)', monthly:specialVal, cls:'WAGES'}); wagesDirect+=specialVal; grossCash+=specialVal; esiWageRaw+=specialVal; }
  }

  CATALOG.forEach(group=>{
    group.items.forEach(it=>{
      if(overrideCore && (it.id==='hra' || it.id==='conveyance' || it.id==='specialAllow')) return; 
      const chk = els('chk_'+it.id);
      if(!chk || !chk.checked) return;
      const amtInCurr = els('amt_'+it.id) ? (parseFloat(els('amt_'+it.id).value) || 0) : 0;
      const amt = toINR(amtInCurr);
      lines.push({label:it.label, monthly:amt, cls:it.classification});
      grossCash += amt;
      let esiExcludedNow = it.esiExcluded;
      if(it.needsFreq && els('freq_'+it.id) && els('freq_'+it.id).value !== 'Monthly') esiExcludedNow = true;
      if(!esiExcludedNow) esiWageRaw += amt;
      if(it.classification === 'WAGES'){ wagesDirect += amt; } else { capBasket += amt; }
    });
  });

  const wagesBase = basic + da + wagesDirect;
  
  let pfWagePrelim = 0;
  if(pfStrategy === 'capped') pfWagePrelim = Math.min(wagesBase, pfLimitAmt);
  else if(pfStrategy === 'full_basic') pfWagePrelim = basic;
  else if(pfStrategy === 'full_gross') pfWagePrelim = grossCash;
  else pfWagePrelim = wagesBase;

  const employerPFprelim = R(pfWagePrelim * EMPLOYER_PF_RATE); 
  const fullBasket = capBasket + employerPFprelim;
  const initialGratuityProvision = R(wagesBase * GRATUITY_RATE);
  
  const totalRemuneration = wagesBase + fullBasket + initialGratuityProvision;
  const threshold = totalRemuneration * 0.5;

  let revisedWagesBase = wagesBase, flagged = false, excess = 0;
  if (statutoryLogic === 'coss' && fullBasket > threshold) {
      excess = fullBasket - threshold;
      revisedWagesBase = wagesBase + excess;
      flagged = true;
  }

  const gratuityProvision = R(revisedWagesBase * GRATUITY_RATE);

  let pfWage = 0;
  if(pfStrategy === 'capped') pfWage = Math.min(revisedWagesBase, pfLimitAmt);
  else if(pfStrategy === 'full_basic') pfWage = basic; 
  else if(pfStrategy === 'full_gross') pfWage = grossCash;
  else pfWage = revisedWagesBase; 

  const employerPF = R(pfWage * EMPLOYER_PF_RATE);      
  const employeePF = R(pfWage * EMPLOYEE_PF_RATE);      

  const esicWageBase = (statutoryLogic === 'coss') ? revisedWagesBase : esiWageRaw;
  const esiApplicable = esicWageBase <= 21000;
  const employerESIC = esiApplicable ? R(esicWageBase * 0.0325) : 0;
  const employeeESIC = esiApplicable ? R(esicWageBase * 0.0075) : 0;

  let lwfEE_cycle = 0, lwfER_cycle = 0, lwfFreqStr = 'None', lwfEE_monthly_standard = 0, lwfER_monthlyCTC = 0;
  if(applyLwf) {
      const rule = getLWF(state, grossCash);
      lwfFreqStr = rule.freq;
      lwfEE_cycle = rule.ee;
      lwfER_cycle = rule.er;
      const mult = rule.freq === 'Half-Yearly' ? 2 : (rule.freq === 'Annually' ? 1 : (rule.freq === 'Monthly' ? 12 : 0));
      lwfER_monthlyCTC = R((rule.er * mult) / 12);
      if (rule.freq === 'Monthly') lwfEE_monthly_standard = rule.ee;
  }

  const ptOverrideEl = els('ptOverride');
  const ptOverride = ptOverrideEl ? ptOverrideEl.value : '';
  const pt = ptOverride !== '' ? parseFloat(ptOverride) : getPT(state, grossCash, gender);

  const grossSalary = grossCash;
  const ctcBaseMonthly = grossSalary + employerPF + employerESIC + lwfER_monthlyCTC;
  const ctcBaseDaily = ctcBaseMonthly / workDays;
  const leaveUpliftMonthly = leaveUpliftOn ? R((ctcBaseDaily / annualWorkDays) * leavesEligible) : 0;
  const gratuityAmt = includeGratuity ? gratuityProvision : 0;
  const ctcMonthly = ctcBaseMonthly + leaveUpliftMonthly + gratuityAmt;

  const netMonthlyStandard = grossSalary - employeePF - employeeESIC - pt - lwfEE_monthly_standard;
  const netMonthlyLWF = (lwfFreqStr !== 'Monthly' && lwfFreqStr !== 'None') ? netMonthlyStandard - lwfEE_cycle : netMonthlyStandard;

  return { lines, basic, da, wagesBase, capBasket, fullBasket, gratuityProvision, totalRemuneration, threshold, 
    flagged, excess, revisedWagesBase, pfWage, pfLimitAmt, employerPF, employeePF, esicWageBase, esiApplicable, 
    employerESIC, employeeESIC, pt, lwfEE_cycle, lwfER_monthlyCTC, lwfFreqStr, grossSalary, leaveUpliftOn, 
    leaveUpliftMonthly, gratuityAmt, ctcMonthly, netMonthlyStandard, netMonthlyLWF, workDays, workHours, 
    includeGratuity, applyLwf, statutoryLogic, employerPFprelim, initialGratuityProvision, rawBasic, rawDa, pfStrategy };
}

function templateFromGross(G, fixedExtras, da){
  const strategy = els('revStrategy') ? els('revStrategy').value : 'default';
  let basic, hra, conveyance, special;
  if (strategy === 'custom') {
    let bPerc = els('custBasicPerc') ? (parseFloat(els('custBasicPerc').value) || 50) : 50;
    if (bPerc < 50) bPerc = 50; 
    basic = (bPerc / 100) * G;
    hra = ((els('custHraPerc') ? parseFloat(els('custHraPerc').value) : 20) || 0) / 100 * G;
    conveyance = ((els('custConvPerc') ? parseFloat(els('custConvPerc').value) : 3) || 0) / 100 * G;
    special = Math.max(0, G - basic - hra - conveyance - da - fixedExtras);
  } else {
    basic = 0.50 * G;
    hra = 0.25 * G;
    conveyance = Math.min(toINR(1600), 0.03 * G);
    special = Math.max(0, G - basic - hra - conveyance - da - fixedExtras);
  }
  return {basic, hra, conveyance, special};
}

function sumFixedExtras(){
  let sum = 0;
  CATALOG.forEach(group=>{ group.items.forEach(it=>{
      if(it.id==='hra' || it.id==='conveyance' || it.id==='specialAllow') return;
      const chk = els('chk_'+it.id);
      if(chk && chk.checked) sum += toINR(els('amt_'+it.id) ? (parseFloat(els('amt_'+it.id).value) || 0) : 0);
  });});
  return sum;
}

function reverseSolve(){
  const targetType = els('revTargetType') ? els('revTargetType').value : 'ctc';
  const rawTargetAmt = els('revTargetAmt') ? (parseFloat(els('revTargetAmt').value) || 0) : 125000;
  const workDays = els('workDays') ? (parseFloat(els('workDays').value) || 30) : 30;
  const workHours = els('workHours') ? (parseFloat(els('workHours').value) || 8) : 8;
  const rawDa = els('daIn') ? (parseFloat(els('daIn').value) || 0) : 0;
  const da = toINR(rawDa);
  
  let targetMonthlyRaw = rawTargetAmt;
  if(els('revTargetRate') && els('revTargetRate').value === 'daily') targetMonthlyRaw = rawTargetAmt * workDays;
  if(els('revTargetRate') && els('revTargetRate').value === 'hourly') targetMonthlyRaw = rawTargetAmt * workDays * workHours;
  const targetMonthly = toINR(targetMonthlyRaw);

  let G;
  if(targetType === 'gross'){ G = targetMonthly; } else {
    let lo = 0, hi = Math.max(targetMonthly*1.5, 1000);
    for(let i=0;i<60;i++){
      const mid = (lo+hi)/2;
      const r = computeAll(templateFromGross(mid, sumFixedExtras(), da));
      if(r.ctcMonthly > targetMonthly) hi = mid; else lo = mid;
    }
    G = (lo+hi)/2;
  }
  
  const rndFlg = isRounded();
  let finalTemplate = templateFromGross(G, sumFixedExtras(), da);
  
  if (rndFlg) {
      finalTemplate.basic = Math.round(finalTemplate.basic);
      finalTemplate.hra = Math.round(finalTemplate.hra);
      finalTemplate.conveyance = Math.round(finalTemplate.conveyance);
      finalTemplate.special = Math.round(finalTemplate.special);
  }
  
  let result = computeAll(finalTemplate);
  let diff = targetMonthly - (targetType === 'gross' ? result.grossSalary : result.ctcMonthly);
  
  if (Math.abs(diff) > 0.0001) {
      finalTemplate.special += diff;
      if (rndFlg) finalTemplate.special = Math.round(finalTemplate.special);
      result = computeAll(finalTemplate);
      diff = targetMonthly - (targetType === 'gross' ? result.grossSalary : result.ctcMonthly);
  }

  // Update inputs in UI (in active Input Currency)
  const inCurr = getInputCurrency();
  const rate = getExchangeRate();
  const toDispInInput = vINR => inCurr === 'INR' ? vINR : (vINR / rate);

  if(els('basicIn')) els('basicIn').value = rndFlg ? Math.round(toDispInInput(finalTemplate.basic)) : toDispInInput(finalTemplate.basic).toFixed(2);
  if(els('chk_hra')) els('chk_hra').checked = finalTemplate.hra > 0; 
  if(els('amt_hra')) els('amt_hra').value = rndFlg ? Math.round(toDispInInput(finalTemplate.hra)) : toDispInInput(finalTemplate.hra).toFixed(2);
  if(els('chk_conveyance')) els('chk_conveyance').checked = finalTemplate.conveyance > 0; 
  if(els('amt_conveyance')) els('amt_conveyance').value = rndFlg ? Math.round(toDispInInput(finalTemplate.conveyance)) : toDispInInput(finalTemplate.conveyance).toFixed(2);
  if(els('chk_specialAllow')) els('chk_specialAllow').checked = true; 
  if(els('amt_specialAllow')) els('amt_specialAllow').value = rndFlg ? Math.round(toDispInInput(finalTemplate.special)) : toDispInInput(finalTemplate.special).toFixed(2);

  if(els('rcTarget')) els('rcTarget').textContent = fmt(targetMonthly) + ' /mo';
  if(els('rcComputed')) els('rcComputed').textContent = fmt(targetType === 'gross' ? result.grossSalary : result.ctcMonthly) + ' /mo';
  if(els('rcDiff')) els('rcDiff').textContent = fmt(diff);
  if(els('rcStatus')) els('rcStatus').textContent = Math.abs(diff) < 0.05 ? '✓ Reconciled' : '⚠ Check inputs';
  return result;
}

function renderResult(r){
  const dispCurr = getDisplayCurrencyCode();
  if(els('breakupCurrHeader')) els('breakupCurrHeader').textContent = dispCurr;

  // Minimum Wage Compliance Check
  const mwRates = getActiveMinWageRates();
  const computedWageINR = r.basic + r.da;
  const isMwCompliant = computedWageINR >= mwRates.total;
  const shortfallINR = isMwCompliant ? 0 : (mwRates.total - computedWageINR);

  // Update Minimum Wage Grid
  if(els('mwDispBasic')) els('mwDispBasic').textContent = fmt(mwRates.basic);
  if(els('mwInrBasic')) els('mwInrBasic').textContent = 'Base INR: ₹' + mwRates.basic.toLocaleString('en-IN');
  if(els('mwDispDA')) els('mwDispDA').textContent = fmt(mwRates.da);
  if(els('mwInrDA')) els('mwInrDA').textContent = 'Base INR: ₹' + mwRates.da.toLocaleString('en-IN');
  if(els('mwDispTotal')) els('mwDispTotal').textContent = fmt(mwRates.total);
  if(els('mwInrTotal')) els('mwInrTotal').textContent = 'Base INR: ₹' + mwRates.total.toLocaleString('en-IN');
  if(els('mwDispComputed')) els('mwDispComputed').textContent = fmt(computedWageINR);

  // Minimum Wage Stamp & Audit Box
  const mwStamp = els('mwStampBox');
  const mwBox = els('mwAuditBox');
  const mwTitle = els('mwAuditTitle');
  const mwBody = els('mwAuditBody');
  const mwAction = els('mwActionWrap');

  if (computedWageINR === 0) {
    if(mwStamp) { mwStamp.className = 'stamp pass'; mwStamp.textContent = 'MIN WAGE: NIL / RESET'; }
    if(mwBox) { mwBox.className = 'test-box pass'; }
    if(mwTitle) { mwTitle.textContent = 'AWAITING SALARY INPUT'; }
    if(mwBody) { mwBody.textContent = 'Salary inputs are NIL. Enter Basic and Allowances or configure Reverse Target to test Minimum Wage compliance.'; }
    if(mwAction) mwAction.style.display = 'none';
  } else if(isMwCompliant){
    if(mwStamp) { mwStamp.className = 'stamp pass'; mwStamp.textContent = 'MIN WAGE: PASS'; }
    if(mwBox) { mwBox.className = 'test-box pass'; }
    if(mwTitle) { mwTitle.textContent = '✓ PASS — COMPLIANT WITH STATE MINIMUM WAGE'; }
    if(mwBody) {
      mwBody.innerHTML = 'Computed Core Wage (' + fmt(computedWageINR) + ') satisfies the statutory minimum wage threshold of ' +
        fmt(mwRates.total) + ' (' + els('mwStateSel').value + ' - ' + els('mwZoneSel').options[els('mwZoneSel').selectedIndex].text + '). Surplus: <b>' + fmt(computedWageINR - mwRates.total) + '</b>.';
    }
    if(mwAction) mwAction.style.display = 'none';
  } else {
    if(mwStamp) { mwStamp.className = 'stamp deficit'; mwStamp.textContent = 'MIN WAGE: DEFICIT'; }
    if(mwBox) { mwBox.className = 'test-box deficit'; }
    if(mwTitle) { mwTitle.textContent = '⚠ DEFICIT — SALARY BELOW STATUTORY MINIMUM WAGE THRESHOLD'; }
    if(mwBody) {
      mwBody.innerHTML = 'Computed Core Wage (' + fmt(computedWageINR) + ') falls short of statutory threshold by <b style="color:var(--red); font-size:13px;">' +
        fmt(shortfallINR) + '</b> (Base INR: ₹' + shortfallINR.toLocaleString('en-IN') + '). Employers are legally mandated to pay at least the statutory minimum wage.';
    }
    if(mwAction) mwAction.style.display = 'block';
  }

  // CoSS Stamp & 50% Audit Box
  const testBox = els('testBox'), cossStamp = els('cossStampBox'), testDetail = els('testDetail');
  if (r.grossSalary === 0 && r.ctcMonthly === 0) {
    if(cossStamp) { cossStamp.className = 'stamp pass'; cossStamp.textContent = 'CoSS: NIL / RESET'; }
    testBox.className = 'test-box pass'; els('testTitle').textContent = 'Awaiting Salary Input';
    els('testBody').textContent = 'Salary inputs are currently NIL.';
  } else if (r.statutoryLogic === 'old') {
      testBox.className = 'test-box'; els('testTitle').textContent = 'Pre-CoSS Mode Active';
      els('testBody').innerHTML = 'Executing via traditional framework (50% rule bypassed).';
      if(cossStamp) { cossStamp.className = 'stamp pass'; cossStamp.textContent = 'CoSS: STANDARD'; }
  } else {
      if(r.flagged){
        testBox.className = 'test-box flag'; els('testTitle').textContent = 'FLAGGED — Exceeds 50% Threshold';
        els('testBody').innerHTML = 'Excess over the 50% ceiling is legally added back into "Wages" base for compliance under Code on Social Security 2020.';
        if(cossStamp) { cossStamp.className = 'stamp flag'; cossStamp.textContent = 'CoSS: FLAGGED'; }
      } else {
        testBox.className = 'test-box pass'; els('testTitle').textContent = 'PASS — Within the 50% Threshold';
        els('testBody').innerHTML = 'Basket stays under 50% of total remuneration.';
        if(cossStamp) { cossStamp.className = 'stamp pass'; cossStamp.textContent = 'CoSS: PASS (50%)'; }
      }
  }

  testDetail.innerHTML = 
    '<tr><td>Wages Base (INR)</td><td>' + fmt(r.wagesBase) + '</td></tr>' +
    '<tr><td>+ (a)-(i) Excluded Allowances Basket</td><td>' + fmt(r.capBasket) + '</td></tr>' +
    '<tr><td>+ (c) Employer PF Contribution (13%)</td><td>' + fmt(r.employerPFprelim) + '</td></tr>' +
    '<tr><td>+ (j) Gratuity Provision (Pre-revision)</td><td>' + fmt(r.initialGratuityProvision) + '</td></tr>' +
    '<tr class="linetotal"><td>= Total Remuneration</td><td>' + fmt(r.totalRemuneration) + '</td></tr>' +
    '<tr><td>50% Threshold Limit</td><td>' + fmt(r.threshold) + '</td></tr>' +
    '<tr class="highlight-row"><td>Total Exclusions against Threshold</td><td>' + fmt(r.fullBasket) + '</td></tr>' +
    (r.flagged ? '<tr><td>Excess re-added to Wages</td><td>' + fmt(r.excess) + '</td></tr>' : '') +
    '<tr class="linetotal"><td>Final Compliant Wage Base</td><td>' + fmt(r.revisedWagesBase) + '</td></tr>' +
    '<tr class="linetotal"><td colspan="2" style="padding-top:12px; color:var(--emerald-deep);">Gratuity Computation Breakdown (Tied-back)</td></tr>' +
    '<tr><td>Final Compliant Wage Base</td><td>' + fmt(r.revisedWagesBase) + '</td></tr>' +
    '<tr><td>Computed Provision (4.81% of Final Base)</td><td><b>' + fmt(r.gratuityProvision) + '</b></td></tr>';

  // ESI Box
  const esiBox = els('esiBox'), esiTitle = els('esiTitle'), esiBody = els('esiBody');
  if(esiBox && esiTitle && esiBody){
    if(r.esiApplicable){
      esiBox.className = 'test-box pass'; esiTitle.textContent = 'ESI Applicable';
      esiBody.innerHTML = 'Wage base ' + fmt(r.esicWageBase) + '/mo is within the ₹21,000 threshold. Employer (3.25%) = ' + fmt(r.employerESIC) + ' | Employee (0.75%) = ' + fmt(r.employeeESIC) + '.';
    } else {
      esiBox.className = 'test-box flag'; esiTitle.textContent = 'ESI Not Applicable';
      esiBody.innerHTML = 'Wage base ' + fmt(r.esicWageBase) + '/mo exceeds the statutory ₹21,000 threshold.';
    }
  }

  // Contract Breakup Table
  const wd = r.workDays, wh = r.workHours;
  const row = (label, monthly) => {
    const dStr = wd > 0 ? fmt(monthly/wd) : '-';
    const hStr = (wd > 0 && wh > 0) ? fmt(monthly/(wd*wh)) : '-';
    return '<tr><td>' + label + '</td><td>' + fmt(monthly) + '</td><td>' + dStr + '</td><td>' + hStr + '</td></tr>';
  };
  let html = '<tr><th>Component</th><th>Monthly (' + dispCurr + ')</th><th>Daily (' + dispCurr + ')</th><th>Hourly (' + dispCurr + ')</th></tr>';
  r.lines.forEach(l => html += row(l.label, l.monthly));
  
  html += '<tr class="subtotal">' + row('Gross Salary', r.grossSalary).replace('<tr>','').replace('</tr>','') + '</tr>';
  if(r.leaveUpliftOn) html += row('+ Leave Upliftment', r.leaveUpliftMonthly);
  const erPfLabel = r.pfStrategy === 'full_gross' ? '+ Employer PF (13% on Gross Salary)' : '+ Employer PF (13%)';
  html += row(erPfLabel, r.employerPF);
  html += row('+ Employer ESIC' + (r.esiApplicable ? '' : ' (N/A)'), r.employerESIC);
  if(r.applyLwf) html += row('+ Employer LWF (Avg into CTC)', r.lwfER_monthlyCTC);
  if(r.includeGratuity) html += row('+ Gratuity Provision', r.gratuityAmt);
  
  html += '<tr class="grand">' + row('Cost to Company', r.ctcMonthly).replace('<tr>','').replace('</tr>','') + '</tr>';
  html += '<tr class="sectiongap"><td colspan="4"></td></tr>';
  
  html += '<tr class="subtotal">' + row('Gross Salary', r.grossSalary).replace('<tr>','').replace('</tr>','') + '</tr>';
  const eePfLabel = r.pfStrategy === 'full_gross' ? '− Employee PF (12% on Gross Salary)' : '− Employee PF (12%)';
  html += row(eePfLabel, -r.employeePF);
  html += row('− Employee ESIC' + (r.esiApplicable ? '' : ' (N/A)'), -r.employeeESIC);
  html += row('− Professional Tax', -r.pt);
  
  if (r.applyLwf && r.lwfEE_cycle > 0) {
      if (r.lwfFreqStr === 'Monthly') {
          html += row('− Employee LWF (Monthly)', -r.lwfEE_cycle);
      } else {
          html += '<tr><td>− Employee LWF (Event: ' + r.lwfFreqStr + ')</td><td>' + fmt(-r.lwfEE_cycle) + ' (Deduction Mth)</td><td>-</td><td>-</td></tr>';
      }
  }

  html += '<tr class="grand">' + row('Net in Hand (Standard Month)', r.netMonthlyStandard).replace('<tr>','').replace('</tr>','') + '</tr>';
  if (r.applyLwf && r.lwfEE_cycle > 0 && r.lwfFreqStr !== 'Monthly') {
      html += '<tr class="grand" style="background-color: var(--ink-soft); font-size: 11.5px;"><td>Net in Hand (During LWF Month)</td><td style="text-align:right">' + fmt(r.netMonthlyLWF) + '</td><td>-</td><td>-</td></tr>';
  }

  const ecTable = els('ecTable');
  if(ecTable) ecTable.innerHTML = html;
  window.__lastResult = r;
}

function autoAdjustBasic() {
  const mwRates = getActiveMinWageRates();
  const currentDaINR = toINR(els('daIn') ? (parseFloat(els('daIn').value) || 0) : 0);
  const neededBasicINR = Math.max(mwRates.basic, mwRates.total - currentDaINR);
  const inCurr = getInputCurrency();
  const neededBasicInInputCurr = inCurr === 'INR' ? neededBasicINR : (neededBasicINR / getExchangeRate());
  
  if (els('basicIn')) {
    els('basicIn').value = isRounded() ? Math.round(neededBasicInInputCurr) : neededBasicInInputCurr.toFixed(2);
  }
  calculate();
  const toast = els('autoAdjustToast');
  if (toast) {
    toast.style.display = 'block';
    toast.textContent = '✓ Basic Pay updated to ' + fmt(neededBasicINR) + ' to satisfy statutory Minimum Wage.';
    setTimeout(() => { toast.style.display = 'none'; }, 5000);
  }
}

function calculate(){ 
  const modeEl = els('calcMode');
  const isReverse = modeEl && modeEl.value === 'reverse';
  updateMwDetails();
  renderResult(isReverse ? reverseSolve() : computeAll(null)); 
}

function resetForm(){
  if(els('calcMode')) els('calcMode').value='buildup'; 
  toggleMode();

  // Reset all employee personal & working parameters to NIL
  if(els('empName')) els('empName').value = '';
  if(els('empCode')) els('empCode').value = '';
  if(els('gender')) els('gender').value = 'M';
  if(els('workDays')) els('workDays').value = '';
  if(els('workHours')) els('workHours').value = '';
  if(els('leaveDays')) els('leaveDays').value = '';

  // Reset statutory options
  if(els('pfStrategy')) els('pfStrategy').value = 'capped';
  if(els('pfLimitAmt')) {
    els('pfLimitAmt').value = '';
    els('pfLimitAmt').disabled = false;
  }
  if(els('includeGratuity')) els('includeGratuity').value = 'no';
  if(els('applyLwf')) els('applyLwf').value = 'no';
  if(els('leaveUpliftOn')) els('leaveUpliftOn').value = 'no';
  if(els('statutoryLogic')) els('statutoryLogic').value = 'coss';
  if(els('roundOff')) els('roundOff').value = 'no';

  // Currency parameters
  if(els('baseCurrency')) els('baseCurrency').value = 'INR';
  if(els('exchangeRate')) {
    els('exchangeRate').value = '1.00';
    els('exchangeRate').disabled = true;
  }
  if(els('displayCurrency')) els('displayCurrency').value = 'INR';

  // Reverse solve targets to NIL
  if(els('revTargetAmt')) els('revTargetAmt').value = '';
  if(els('revTargetType')) els('revTargetType').value = 'ctc';
  if(els('revTargetRate')) els('revTargetRate').value = 'monthly';
  if(els('custBasicPerc')) els('custBasicPerc').value = '';
  if(els('custHraPerc')) els('custHraPerc').value = '';
  if(els('custConvPerc')) els('custConvPerc').value = '';

  // Core wages to NIL
  if(els('basicIn')) els('basicIn').value = '';
  if(els('daIn')) els('daIn').value = '';

  // Reset all catalog allowance items
  CATALOG.forEach(g=>g.items.forEach(it=>{ 
    const chk = els('chk_'+it.id);
    const amt = els('amt_'+it.id);
    const freq = els('freq_'+it.id);
    if(chk) chk.checked = false; 
    if(amt) amt.value = ''; 
    if(freq) freq.value = 'Monthly';
  }));

  onInputCurrencyChange();
  calculate();
}

function downloadExcel() {
  calculate();
  const r = window.__lastResult;
  if (!r) return;
  const XLSX = window.XLSX;
  if (!XLSX) return;

  const wb = XLSX.utils.book_new();
  const ws = {};
  const dispCurr = getDisplayCurrencyCode();
  const sym = CURRENCIES[dispCurr] ? CURRENCIES[dispCurr].sym : '₹';
  const numFmt = isRounded() ? ('"' + sym + '"#,##0') : ('"' + sym + '"#,##0.00');

  let rIdx = 1;
  function setCell(colStr, rowNum, val, formula, nFmt) {
    const addr = colStr + rowNum;
    const cell = { v: val };
    if (typeof val === 'number') { cell.t = 'n'; if (nFmt) cell.z = nFmt; }
    else { cell.t = 's'; }
    if (formula) cell.f = formula;
    ws[addr] = cell;
  }

  setCell('A', rIdx, "SALARY STRUCTURING, MINIMUM WAGE & STATUTORY COMPLIANCE WORKING");
  rIdx += 2;

  // Section 1
  setCell('A', rIdx, "1. EMPLOYEE & PARAMETER INPUTS"); rIdx++;
  setCell('A', rIdx, "Employee Name:"); setCell('B', rIdx, els('empName').value);
  setCell('C', rIdx, "Gender:"); setCell('D', rIdx, els('gender').value);
  setCell('E', rIdx, "State:"); setCell('F', rIdx, els('stateSel').value); rIdx++;

  setCell('A', rIdx, "Employee Code:"); setCell('B', rIdx, els('empCode').value);
  setCell('C', rIdx, "Work Days/Mth:"); setCell('D', rIdx, r.workDays);
  setCell('E', rIdx, "Work Hours/Day:"); setCell('F', rIdx, r.workHours); rIdx++;

  setCell('A', rIdx, "Input Currency:"); setCell('B', rIdx, getInputCurrency());
  setCell('C', rIdx, "Exchange Rate (1 FCY=X INR):"); setCell('D', rIdx, getExchangeRate());
  setCell('E', rIdx, "Display Currency:"); setCell('F', rIdx, dispCurr); rIdx += 2;

  // Section 2
  setCell('A', rIdx, "2. MONTHLY SALARY COMPONENTS & COST TO COMPANY (" + dispCurr + ")"); rIdx++;
  setCell('A', rIdx, "Component");
  setCell('B', rIdx, "Monthly (" + sym + ")");
  setCell('C', rIdx, "Daily (" + sym + ")");
  setCell('D', rIdx, "Hourly (" + sym + ")");
  setCell('E', rIdx, "Classification"); rIdx++;

  const compStart = rIdx;
  r.lines.forEach(l => {
    const monthlyDisp = fromINR(l.monthly, dispCurr);
    setCell('A', rIdx, l.label);
    setCell('B', rIdx, monthlyDisp, null, numFmt);
    setCell('C', rIdx, monthlyDisp / r.workDays, '=B' + rIdx + '/$D$5', numFmt);
    setCell('D', rIdx, monthlyDisp / (r.workDays * r.workHours), '=C' + rIdx + '/$F$5', numFmt);
    setCell('E', rIdx, l.cls);
    rIdx++;
  });
  const compEnd = rIdx - 1;

  const grossRow = rIdx;
  setCell('A', grossRow, "Gross Salary");
  setCell('B', grossRow, fromINR(r.grossSalary, dispCurr), '=SUM(B' + compStart + ':B' + compEnd + ')', numFmt);
  setCell('C', grossRow, fromINR(r.grossSalary, dispCurr) / r.workDays, '=B' + grossRow + '/$D$5', numFmt);
  setCell('D', grossRow, fromINR(r.grossSalary, dispCurr) / (r.workDays * r.workHours), '=C' + grossRow + '/$F$5', numFmt);
  setCell('E', grossRow, "TOTAL GROSS"); rIdx++;

  const erPfRow = rIdx;
  const isFullGross = r.pfStrategy === 'full_gross';
  setCell('A', erPfRow, "+ Employer PF (" + (isFullGross ? "13% on Gross" : "13%") + ")");
  const erPfFormula = isFullGross ? ('=ROUND(B' + grossRow + '*0.13, 0)') : null;
  setCell('B', erPfRow, fromINR(r.employerPF, dispCurr), erPfFormula, numFmt);
  setCell('C', erPfRow, fromINR(r.employerPF, dispCurr) / r.workDays, '=B' + erPfRow + '/$D$5', numFmt);
  setCell('D', erPfRow, fromINR(r.employerPF, dispCurr) / (r.workDays * r.workHours), '=C' + erPfRow + '/$F$5', numFmt); rIdx++;

  const erEsicRow = rIdx;
  setCell('A', erEsicRow, "+ Employer ESIC" + (r.esiApplicable ? "" : " (N/A)"));
  setCell('B', erEsicRow, fromINR(r.employerESIC, dispCurr), null, numFmt);
  setCell('C', erEsicRow, fromINR(r.employerESIC, dispCurr) / r.workDays, '=B' + erEsicRow + '/$D$5', numFmt);
  setCell('D', erEsicRow, fromINR(r.employerESIC, dispCurr) / (r.workDays * r.workHours), '=C' + erEsicRow + '/$F$5', numFmt); rIdx++;

  const ctcRow = rIdx;
  setCell('A', ctcRow, "COST TO COMPANY (CTC)");
  setCell('B', ctcRow, fromINR(r.ctcMonthly, dispCurr), '=B' + grossRow + '+B' + erPfRow + '+B' + erEsicRow, numFmt);
  setCell('C', ctcRow, fromINR(r.ctcMonthly, dispCurr) / r.workDays, '=B' + ctcRow + '/$D$5', numFmt);
  setCell('D', ctcRow, fromINR(r.ctcMonthly, dispCurr) / (r.workDays * r.workHours), '=C' + ctcRow + '/$F$5', numFmt);
  setCell('E', ctcRow, "GRAND TOTAL CTC"); rIdx += 2;

  // Section 3.5: Pan-India Minimum Wage Matrix
  const mwRates = getActiveMinWageRates();
  const computedWageINR = r.basic + r.da;
  const isCompliant = computedWageINR >= mwRates.total;

  setCell('A', rIdx, "3.5 PAN-INDIA MINIMUM WAGE COMPLIANCE AUDIT"); rIdx++;
  setCell('A', rIdx, "State:"); setCell('B', rIdx, els('mwStateSel').value);
  setCell('C', rIdx, "Zone:"); setCell('D', rIdx, els('mwZoneSel').options[els('mwZoneSel').selectedIndex].text);
  setCell('E', rIdx, "Category:"); setCell('F', rIdx, els('mwCatSel').options[els('mwCatSel').selectedIndex].text); rIdx++;

  setCell('A', rIdx, "Statutory Minimum Basic (" + sym + "):"); setCell('B', rIdx, fromINR(mwRates.basic, dispCurr), null, numFmt);
  setCell('C', rIdx, "Dearness Allowance (" + sym + "):"); setCell('D', rIdx, fromINR(mwRates.da, dispCurr), null, numFmt);
  setCell('E', rIdx, "Total Statutory Min Wage (" + sym + "):"); setCell('F', rIdx, fromINR(mwRates.total, dispCurr), null, numFmt); rIdx++;

  setCell('A', rIdx, "Current Computed Wage (Basic+DA):"); setCell('B', rIdx, fromINR(computedWageINR, dispCurr), null, numFmt);
  setCell('C', rIdx, "Audit Status:"); setCell('D', rIdx, isCompliant ? "PASS - COMPLIANT" : "DEFICIT - NON COMPLIANT");
  setCell('E', rIdx, "Shortfall Amount (" + sym + "):"); setCell('F', rIdx, isCompliant ? 0 : fromINR(mwRates.total - computedWageINR, dispCurr), null, numFmt); rIdx += 2;

  // Section 4: CoSS
  setCell('A', rIdx, "4. LABOUR CODE (CoSS 2020) 50% RULE AUDIT TEST (INR Base)"); rIdx++;
  setCell('A', rIdx, "Core Wages Base (INR):"); setCell('B', rIdx, r.wagesBase, null, '"₹"#,##0');
  setCell('C', rIdx, "Excluded Basket (INR):"); setCell('D', rIdx, r.capBasket, null, '"₹"#,##0');
  setCell('E', rIdx, "Status:"); setCell('F', rIdx, r.flagged ? "FLAGGED" : "PASS");

  ws['!ref'] = 'A1:F' + rIdx;
  ws['!cols'] = [{wch:38}, {wch:22}, {wch:22}, {wch:22}, {wch:24}, {wch:22}];
  XLSX.utils.book_append_sheet(wb, ws, "Salary_Working");

  const s = els('empCode').value.replace(/[^a-zA-Z0-9_-]/g, '_');
  XLSX.writeFile(wb, 'Salary_Compliance_' + s + '.xlsx');
}

function exportPdf() {
  calculate();
  const r = window.__lastResult;
  if (!r) return;
  const { jsPDF } = window.jspdf;
  if (!jsPDF) return;
  const doc = new jsPDF();

  const dispCurr = getDisplayCurrencyCode();
  const sym = CURRENCIES[dispCurr] ? CURRENCIES[dispCurr].sym : '₹';
  const mult = dispCurr === 'INR' ? 1 : (1 / getExchangeRate());
  const fmtP = vINR => fmtRaw(vINR * mult, dispCurr);

  doc.setFillColor(11, 46, 34);
  doc.rect(0, 0, 210, 22, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("SALARY BREAKUP & STATUTORY COMPLIANCE STATEMENT", 14, 14);

  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.text("Generated: " + new Date().toLocaleDateString('en-IN') + " | Output: " + dispCurr + " (" + sym + ")", 125, 14);

  doc.setTextColor(15, 47, 34);
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text("1. Employee & Statutory Parameters", 14, 29);

  const empDetails = [
    ["Employee Name: " + els('empName').value, "Employee Code: " + els('empCode').value, "Gender: " + els('gender').value],
    ["State: " + els('stateSel').value, "Working Days: " + r.workDays, "PF Strategy: " + els('pfStrategy').value],
    ["Input Currency: " + getInputCurrency(), "Exchange Rate: 1 FCY = " + getExchangeRate() + " INR", "Display Currency: " + dispCurr]
  ];
  doc.autoTable({ startY: 31, body: empDetails, theme: 'plain', styles: { fontSize: 7.5, cellPadding: 1.4 } });

  let finalY = doc.lastAutoTable.finalY + 4;
  doc.setFontSize(9.5); doc.setFont("helvetica", "bold");
  doc.text("2. Monthly Salary Components & CTC (" + dispCurr + ")", 14, finalY);

  const compRows = [];
  r.lines.forEach(l => compRows.push([l.label, l.cls, fmtP(l.monthly), fmtP(l.monthly/r.workDays), fmtP(l.monthly/(r.workDays*r.workHours))]));
  compRows.push([{content:'GROSS SALARY', fontStyle:'bold'}, '', {content:fmtP(r.grossSalary), fontStyle:'bold'}, {content:fmtP(r.grossSalary/r.workDays), fontStyle:'bold'}, {content:fmtP(r.grossSalary/(r.workDays*r.workHours)), fontStyle:'bold'}]);
  compRows.push(['+ Employer PF (13%)', 'STATUTORY', fmtP(r.employerPF), fmtP(r.employerPF/r.workDays), fmtP(r.employerPF/(r.workDays*r.workHours))]);
  compRows.push(['+ Employer ESIC', 'STATUTORY', fmtP(r.employerESIC), fmtP(r.employerESIC/r.workDays), fmtP(r.employerESIC/(r.workDays*r.workHours))]);
  compRows.push([{content:'COST TO COMPANY (CTC)', fontStyle:'bold'}, '', {content:fmtP(r.ctcMonthly), fontStyle:'bold'}, {content:fmtP(r.ctcMonthly/r.workDays), fontStyle:'bold'}, {content:fmtP(r.ctcMonthly/(r.workDays*r.workHours)), fontStyle:'bold'}]);

  doc.autoTable({
    startY: finalY + 2,
    head: [['Component', 'Classification', 'Monthly (' + sym + ')', 'Daily (' + sym + ')', 'Hourly (' + sym + ')']],
    body: compRows,
    theme: 'striped',
    headStyles: { fillColor: [11, 46, 34], textColor: [255, 255, 255], fontSize: 7.5 },
    styles: { fontSize: 7, cellPadding: 1.5 }
  });

  finalY = doc.lastAutoTable.finalY + 4;
  doc.setFontSize(9.5); doc.setFont("helvetica", "bold");
  doc.text("3. Pan-India Minimum Wage Compliance Audit", 14, finalY);

  const mwRates = getActiveMinWageRates();
  const computedWageINR = r.basic + r.da;
  const isCompliant = computedWageINR >= mwRates.total;

  const mwRows = [
    ["State & Zone", els('mwStateSel').value + " — " + els('mwZoneSel').options[els('mwZoneSel').selectedIndex].text],
    ["Skill Category", els('mwCatSel').options[els('mwCatSel').selectedIndex].text],
    ["Statutory Minimum Basic", fmtP(mwRates.basic)],
    ["Dearness Allowance (DA)", fmtP(mwRates.da)],
    ["Total Minimum Wage", fmtP(mwRates.total)],
    ["Current Computed Wage (Basic+DA)", fmtP(computedWageINR)],
    ["Compliance Status", isCompliant ? "PASS — COMPLIANT" : "DEFICIT — SHORTFALL OF " + fmtP(mwRates.total - computedWageINR)]
  ];
  doc.autoTable({ startY: finalY + 2, body: mwRows, theme: 'plain', styles: { fontSize: 7, cellPadding: 1.5 } });

  const s = els('empCode').value.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save('Salary_Compliance_' + s + '.pdf');
}

function downloadTemplate() {
  const XLSX = window.XLSX;
  if (!XLSX) return;
  const templateData = [
    {
      EmpCode: 'EMP-001', EmpName: 'Aditi Sharma', Gender: 'F', State: 'Maharashtra', Zone: 'Zone I', Category: 'Skilled',
      Currency: 'INR', ExchangeRate: 1.0, DisplayCurrency: 'INR', TargetAmount: 150000, TargetType: 'ctc', TargetRate: 'monthly',
      RoundOff: 'yes', WorkDays: 30, WorkHours: 8, PFStrategy: 'capped', PFLimit: 15000, IncludeGratuity: 'yes', ApplyLWF: 'yes',
      StatutoryLogic: 'coss', BasicPerc: 50, HRAPerc: 20, ConvPerc: 3
    },
    {
      EmpCode: 'EMP-002', EmpName: 'John Miller', Gender: 'M', State: 'Karnataka', Zone: 'Zone I', Category: 'High Skilled Workers',
      Currency: 'USD', ExchangeRate: 83.50, DisplayCurrency: 'USD', TargetAmount: 2500, TargetType: 'ctc', TargetRate: 'monthly',
      RoundOff: 'no', WorkDays: 30, WorkHours: 8, PFStrategy: 'full_gross', PFLimit: 0, IncludeGratuity: 'yes', ApplyLWF: 'yes',
      StatutoryLogic: 'coss', BasicPerc: 50, HRAPerc: 20, ConvPerc: 3
    },
    {
      EmpCode: 'EMP-003', EmpName: 'Rajesh Kumar', Gender: 'M', State: 'Delhi', Zone: 'Zone I', Category: 'Graduate & Above',
      Currency: 'INR', ExchangeRate: 1.0, DisplayCurrency: 'INR', TargetAmount: 75000, TargetType: 'gross', TargetRate: 'monthly',
      RoundOff: 'yes', WorkDays: 26, WorkHours: 8, PFStrategy: 'full_gross', PFLimit: 0, IncludeGratuity: 'yes', ApplyLWF: 'yes',
      StatutoryLogic: 'coss', BasicPerc: 50, HRAPerc: 25, ConvPerc: 3
    }
  ];
  const ws = XLSX.utils.json_to_sheet(templateData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Bulk_Upload");
  XLSX.writeFile(wb, "Bulk_CTC_Compliance_Template.xlsx");
}

function getRowValue(row, keys, fallback) {
  for (let k of keys) {
    if (row[k] !== undefined && row[k] !== null && String(row[k]).trim() !== '') return row[k];
    const foundKey = Object.keys(row).find(rk => rk.trim().toLowerCase() === k.trim().toLowerCase());
    if (foundKey && row[foundKey] !== undefined && row[foundKey] !== null && String(row[foundKey]).trim() !== '') return row[foundKey];
  }
  return fallback;
}

function solveEmployeeRoster(row, idx) {
  const rCode = String(getRowValue(row, ['EmpCode', 'Emp Code', 'Employee Code'], 'EMP-' + (idx + 1))).trim();
  const rName = String(getRowValue(row, ['EmpName', 'Emp Name', 'Employee Name'], 'Employee ' + (idx + 1))).trim();
  const rGender = String(getRowValue(row, ['Gender', 'Sex'], 'M')).trim().toUpperCase().charAt(0) || 'M';
  const rState = String(getRowValue(row, ['State', 'Location'], 'Maharashtra')).trim();
  const rZone = String(getRowValue(row, ['Zone'], 'Zone I')).trim();
  const rCat = String(getRowValue(row, ['Category', 'Skill Category', 'Skill'], 'Skilled')).trim();
  const rCurr = String(getRowValue(row, ['Currency', 'Input Currency'], 'INR')).trim().toUpperCase();
  const rEx = parseFloat(getRowValue(row, ['ExchangeRate', 'Exchange Rate', 'Rate'], 1.0)) || 1.0;
  const rDisp = String(getRowValue(row, ['DisplayCurrency', 'Display Currency'], rCurr)).trim().toUpperCase();
  
  const rawTarget = String(getRowValue(row, ['TargetAmount', 'Target Amount', 'CTC', 'Target'], 100000)).replace(/,/g, '');
  const rTarget = parseFloat(rawTarget) || 0;
  const rType = String(getRowValue(row, ['TargetType', 'Target Type'], 'ctc')).trim().toLowerCase();
  const rRate = String(getRowValue(row, ['TargetRate', 'Target Rate'], 'monthly')).trim().toLowerCase();
  const rRound = String(getRowValue(row, ['RoundOff', 'Round Off'], 'yes')).trim().toLowerCase().startsWith('y');
  const rWorkDays = parseFloat(getRowValue(row, ['WorkDays', 'Work Days'], 30)) || 30;
  const rWorkHours = parseFloat(getRowValue(row, ['WorkHours', 'Work Hours'], 8)) || 8;
  const rPfStrategy = String(getRowValue(row, ['PFStrategy', 'PF Strategy'], 'capped')).trim().toLowerCase();
  const rPfLimit = parseFloat(getRowValue(row, ['PFLimit', 'PF Limit'], 15000)) || 15000;
  const rIncGrat = String(getRowValue(row, ['IncludeGratuity', 'Include Gratuity'], 'yes')).trim().toLowerCase().startsWith('y');
  const rApplyLwf = String(getRowValue(row, ['ApplyLWF', 'Apply LWF'], 'yes')).trim().toLowerCase().startsWith('y');
  const rStatLogic = String(getRowValue(row, ['StatutoryLogic', 'Statutory Logic'], 'coss')).trim().toLowerCase();
  
  const rBasicPerc = Math.max(50, parseFloat(getRowValue(row, ['BasicPerc', 'Basic %'], 50)) || 50);
  const rHraPerc = parseFloat(getRowValue(row, ['HRAPerc', 'HRA %'], 20)) || 20;
  const rConvPerc = parseFloat(getRowValue(row, ['ConvPerc', 'Conv %'], 3)) || 3;

  // Multi-currency & frequency normalizer to INR monthly target
  const targetINR = rCurr === 'INR' ? rTarget : (rTarget * rEx);
  let monthlyTargetINR = targetINR;
  if (rRate === 'daily') monthlyTargetINR = targetINR * rWorkDays;
  if (rRate === 'hourly') monthlyTargetINR = targetINR * rWorkDays * rWorkHours;

  // State Code lookup for PT and LWF
  let stateCode = 'MH';
  for (let k in STATE_MAP) {
    if (STATE_MAP[k].toLowerCase() === rState.toLowerCase() || k.toLowerCase() === rState.toLowerCase()) {
      stateCode = k;
      break;
    }
  }

  // Calculate salary components from Gross
  function calcFromGross(G) {
    const basic = (rBasicPerc / 100) * G;
    const hra = (rHraPerc / 100) * G;
    const conv = Math.min(1600, (rConvPerc / 100) * G);
    const special = Math.max(0, G - basic - hra - conv);
    const wagesBase = basic + special;

    let pfWage = 0;
    if (rPfStrategy === 'full_gross') pfWage = G; // UNCAPPED ON FULL GROSS SALARY
    else if (rPfStrategy === 'full_basic') pfWage = basic;
    else if (rPfStrategy === 'full_wages') pfWage = wagesBase;
    else pfWage = Math.min(wagesBase, rPfLimit);

    const erPF = Math.round(pfWage * EMPLOYER_PF_RATE);
    const eePF = Math.round(pfWage * EMPLOYEE_PF_RATE);

    const fullBasket = hra + conv + erPF;
    const totalRemun = wagesBase + fullBasket + Math.round(wagesBase * GRATUITY_RATE);
    const threshold = totalRemun * 0.5;
    let revisedWages = wagesBase, flagged = false;
    if (rStatLogic === 'coss' && fullBasket > threshold) {
      revisedWages = wagesBase + (fullBasket - threshold);
      flagged = true;
    }

    const grat = rIncGrat ? Math.round(revisedWages * GRATUITY_RATE) : 0;
    const esiApplicable = G <= 21000;
    const erESIC = esiApplicable ? Math.round(G * 0.0325) : 0;
    const eeESIC = esiApplicable ? Math.round(G * 0.0075) : 0;

    const pt = getPT(stateCode, G, rGender);
    const lwfObj = rApplyLwf ? getLWF(stateCode, G) : { ee: 0, er: 0 };
    const lwfER_monthly = lwfObj.freq === 'Monthly' ? lwfObj.er : (lwfObj.er / 12);
    const lwfEE_cycle = lwfObj.ee;

    const ctc = G + erPF + erESIC + grat + lwfER_monthly;
    const net = G - eePF - eeESIC - pt - (lwfObj.freq === 'Monthly' ? lwfEE_cycle : 0);

    return {
      gross: G, basic, hra, conv, special, pfWage, erPF, eePF,
      esiApplicable, erESIC, eeESIC, grat, pt, lwfER_monthly, lwfEE_cycle,
      ctc, net, flagged, wagesBase, revisedWages, fullBasket, threshold
    };
  }

  // Determine Gross Salary based on target type
  let G = monthlyTargetINR;
  if (rType === 'ctc') {
    let lo = 0, hi = Math.max(monthlyTargetINR * 1.5, 1000);
    for (let iter = 0; iter < 45; iter++) {
      const mid = (lo + hi) / 2;
      const res = calcFromGross(mid);
      if (res.ctc > monthlyTargetINR) hi = mid; else lo = mid;
    }
    G = (lo + hi) / 2;
  }

  const res = calcFromGross(G);

  // Minimum Wage Lookup
  const mwRow = RAW_MW.find(m => m[0].toLowerCase() === rState.toLowerCase() && m[2].toLowerCase().includes(rCat.toLowerCase())) ||
                RAW_MW.find(m => m[0].toLowerCase() === rState.toLowerCase()) || RAW_MW[0];
  const mwRates = mwRow ? (mwRow[5] || [0, 0, 0]) : [0, 0, 0];
  const mwTotalINR = mwRates[2];
  const mwBasicINR = mwRates[0];
  const mwDaINR = mwRates[1];

  const isCompliant = res.basic >= mwTotalINR;
  const shortfallINR = isCompliant ? 0 : (mwTotalINR - res.basic);
  const mult = rDisp === 'INR' ? 1 : (1 / rEx);
  const sym = CURRENCIES[rDisp] ? CURRENCIES[rDisp].sym : '₹';

  return {
    rCode, rName, rGender, rState, rZone, rCat, rCurr, rEx, rDisp, sym, mult,
    rTarget, rType, rRate, rRound, rWorkDays, rWorkHours, rPfStrategy, rPfLimit,
    rIncGrat, rApplyLwf, rStatLogic, targetINR, monthlyTargetINR,
    ...res,
    mwBasicINR, mwDaINR, mwTotalINR, isCompliant, shortfallINR
  };
}

function buildIndividualExcel(emp) {
  const XLSX = window.XLSX;
  const wb = XLSX.utils.book_new();
  const ws = {};
  const sym = emp.sym;
  const numFmt = emp.rRound ? ('"' + sym + '"#,##0') : ('"' + sym + '"#,##0.00');

  let rIdx = 1;
  function setCell(col, row, val, formula, nFmt) {
    const addr = col + row;
    const cell = { v: val };
    if (typeof val === 'number') { cell.t = 'n'; if (nFmt) cell.z = nFmt; }
    else { cell.t = 's'; }
    if (formula) cell.f = formula;
    ws[addr] = cell;
  }

  setCell('A', rIdx, "SALARY STRUCTURING, MINIMUM WAGE & STATUTORY COMPLIANCE WORKING"); rIdx += 2;
  setCell('A', rIdx, "1. EMPLOYEE & PARAMETER INPUTS"); rIdx++;
  setCell('A', rIdx, "Employee Name:"); setCell('B', rIdx, emp.rName);
  setCell('C', rIdx, "Gender:"); setCell('D', rIdx, emp.rGender);
  setCell('E', rIdx, "State:"); setCell('F', rIdx, emp.rState); rIdx++;

  setCell('A', rIdx, "Employee Code:"); setCell('B', rIdx, emp.rCode);
  setCell('C', rIdx, "Work Days/Mth:"); setCell('D', rIdx, emp.rWorkDays);
  setCell('E', rIdx, "Work Hours/Day:"); setCell('F', rIdx, emp.rWorkHours); rIdx++;

  setCell('A', rIdx, "Input Currency:"); setCell('B', rIdx, emp.rCurr);
  setCell('C', rIdx, "Exchange Rate (1 FCY=X INR):"); setCell('D', rIdx, emp.rEx);
  setCell('E', rIdx, "Display Currency:"); setCell('F', rIdx, emp.rDisp); rIdx++;

  setCell('A', rIdx, "PF Strategy:"); setCell('B', rIdx, emp.rPfStrategy === 'full_gross' ? 'Uncapped on Full Gross Salary' : emp.rPfStrategy);
  setCell('C', rIdx, "Target Type:"); setCell('D', rIdx, emp.rType.toUpperCase());
  setCell('E', rIdx, "Target Amount:"); setCell('F', rIdx, emp.rTarget); rIdx += 2;

  // Earnings Table
  setCell('A', rIdx, "2. MONTHLY SALARY COMPONENTS & COST TO COMPANY (" + emp.rDisp + ")"); rIdx++;
  setCell('A', rIdx, "Component"); setCell('B', rIdx, "Monthly (" + sym + ")");
  setCell('C', rIdx, "Daily (" + sym + ")"); setCell('D', rIdx, "Hourly (" + sym + ")");
  setCell('E', rIdx, "Classification"); rIdx++;

  const compStart = rIdx;
  const addComp = (lbl, valINR, cls) => {
    const val = valINR * emp.mult;
    setCell('A', rIdx, lbl);
    setCell('B', rIdx, val, null, numFmt);
    setCell('C', rIdx, val / emp.rWorkDays, '=B' + rIdx + '/$D$5', numFmt);
    setCell('D', rIdx, val / (emp.rWorkDays * emp.rWorkHours), '=C' + rIdx + '/$F$5', numFmt);
    setCell('E', rIdx, cls);
    rIdx++;
  };

  addComp('Basic Pay', emp.basic, 'WAGES');
  addComp('House Rent Allowance (HRA)', emp.hra, 'CAP');
  addComp('Conveyance / Transport Allowance', emp.conv, 'CAP');
  if (emp.special > 0) addComp('Special Allowance (CTC balancing)', emp.special, 'WAGES');

  const compEnd = rIdx - 1;
  const grossRow = rIdx;
  setCell('A', grossRow, "Gross Salary");
  setCell('B', grossRow, emp.gross * emp.mult, '=SUM(B' + compStart + ':B' + compEnd + ')', numFmt);
  setCell('C', grossRow, (emp.gross * emp.mult) / emp.rWorkDays, '=B' + grossRow + '/$D$5', numFmt);
  setCell('D', grossRow, (emp.gross * emp.mult) / (emp.rWorkDays * emp.rWorkHours), '=C' + grossRow + '/$F$5', numFmt);
  setCell('E', grossRow, "TOTAL GROSS"); rIdx++;

  const erPfRow = rIdx;
  setCell('A', erPfRow, "+ Employer PF (" + (emp.rPfStrategy === 'full_gross' ? '13% on Gross Salary' : '13%') + ")");
  const erPfForm = emp.rPfStrategy === 'full_gross' ? ('=ROUND(B' + grossRow + '*0.13, 0)') : null;
  setCell('B', erPfRow, emp.erPF * emp.mult, erPfForm, numFmt);
  setCell('C', erPfRow, (emp.erPF * emp.mult) / emp.rWorkDays, '=B' + erPfRow + '/$D$5', numFmt);
  setCell('D', erPfRow, (emp.erPF * emp.mult) / (emp.rWorkDays * emp.rWorkHours), '=C' + erPfRow + '/$F$5', numFmt); rIdx++;

  const erEsicRow = rIdx;
  setCell('A', erEsicRow, "+ Employer ESIC" + (emp.esiApplicable ? " (3.25%)" : " (N/A)"));
  setCell('B', erEsicRow, emp.erESIC * emp.mult, null, numFmt);
  setCell('C', erEsicRow, (emp.erESIC * emp.mult) / emp.rWorkDays, '=B' + erEsicRow + '/$D$5', numFmt);
  setCell('D', erEsicRow, (emp.erESIC * emp.mult) / (emp.rWorkDays * emp.rWorkHours), '=C' + erEsicRow + '/$F$5', numFmt); rIdx++;

  const ctcRow = rIdx;
  setCell('A', ctcRow, "COST TO COMPANY (CTC)");
  setCell('B', ctcRow, emp.ctc * emp.mult, '=B' + grossRow + '+B' + erPfRow + '+B' + erEsicRow, numFmt);
  setCell('C', ctcRow, (emp.ctc * emp.mult) / emp.rWorkDays, '=B' + ctcRow + '/$D$5', numFmt);
  setCell('D', ctcRow, (emp.ctc * emp.mult) / (emp.rWorkDays * emp.rWorkHours), '=C' + ctcRow + '/$F$5', numFmt);
  setCell('E', ctcRow, "GRAND TOTAL CTC"); rIdx += 2;

  // Deductions
  const eePfRow = rIdx;
  setCell('A', eePfRow, "− Employee PF (" + (emp.rPfStrategy === 'full_gross' ? '12% on Gross Salary' : '12%') + ")");
  const eePfForm = emp.rPfStrategy === 'full_gross' ? ('=ROUND(B' + grossRow + '*0.12, 0)') : null;
  setCell('B', eePfRow, emp.eePF * emp.mult, eePfForm, numFmt); rIdx++;

  const eeEsicRow = rIdx;
  setCell('A', eeEsicRow, "− Employee ESIC" + (emp.esiApplicable ? " (0.75%)" : " (N/A)"));
  setCell('B', eeEsicRow, emp.eeESIC * emp.mult, null, numFmt); rIdx++;

  const ptRow = rIdx;
  setCell('A', ptRow, "− Professional Tax (PT)");
  setCell('B', ptRow, emp.pt * emp.mult, null, numFmt); rIdx++;

  const netRow = rIdx;
  setCell('A', netRow, "NET TAKE-HOME SALARY");
  setCell('B', netRow, emp.net * emp.mult, '=B' + grossRow + '-B' + eePfRow + '-B' + eeEsicRow + '-B' + ptRow, numFmt);
  setCell('C', netRow, (emp.net * emp.mult) / emp.rWorkDays, '=B' + netRow + '/$D$5', numFmt);
  setCell('D', netRow, (emp.net * emp.mult) / (emp.rWorkDays * emp.rWorkHours), '=C' + netRow + '/$F$5', numFmt);
  setCell('E', netRow, "NET IN HAND"); rIdx += 2;

  // Minimum Wage section
  setCell('A', rIdx, "3.5 PAN-INDIA MINIMUM WAGE COMPLIANCE AUDIT"); rIdx++;
  setCell('A', rIdx, "State:"); setCell('B', rIdx, emp.rState);
  setCell('C', rIdx, "Zone:"); setCell('D', rIdx, emp.rZone);
  setCell('E', rIdx, "Category:"); setCell('F', rIdx, emp.rCat); rIdx++;

  setCell('A', rIdx, "Statutory Minimum Basic (" + sym + "):"); setCell('B', rIdx, emp.mwBasicINR * emp.mult, null, numFmt);
  setCell('C', rIdx, "Dearness Allowance (" + sym + "):"); setCell('D', rIdx, emp.mwDaINR * emp.mult, null, numFmt);
  setCell('E', rIdx, "Total Statutory Min Wage (" + sym + "):"); setCell('F', rIdx, emp.mwTotalINR * emp.mult, null, numFmt); rIdx++;

  setCell('A', rIdx, "Current Computed Wage (Basic):"); setCell('B', rIdx, emp.basic * emp.mult, null, numFmt);
  setCell('C', rIdx, "Audit Status:"); setCell('D', rIdx, emp.isCompliant ? "PASS - COMPLIANT" : "DEFICIT - NON COMPLIANT");
  setCell('E', rIdx, "Shortfall Amount (" + sym + "):"); setCell('F', rIdx, emp.shortfallINR * emp.mult, null, numFmt); rIdx += 2;

  // CoSS section
  setCell('A', rIdx, "4. LABOUR CODE (CoSS 2020) 50% RULE AUDIT TEST"); rIdx++;
  setCell('A', rIdx, "Core Wages Base (INR):"); setCell('B', rIdx, emp.wagesBase, null, '"₹"#,##0');
  setCell('C', rIdx, "Excluded Basket (INR):"); setCell('D', rIdx, emp.fullBasket, null, '"₹"#,##0');
  setCell('E', rIdx, "Status:"); setCell('F', rIdx, emp.flagged ? "FLAGGED" : "PASS");

  ws['!ref'] = 'A1:F' + rIdx;
  ws['!cols'] = [{wch:38}, {wch:22}, {wch:22}, {wch:22}, {wch:24}, {wch:22}];
  XLSX.utils.book_append_sheet(wb, ws, "Salary_Working");
  return XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
}

function buildIndividualPdf(emp) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const sym = emp.sym;
  const fmtP = vINR => fmtRaw(vINR * emp.mult, emp.rDisp);

  doc.setFillColor(11, 46, 34);
  doc.rect(0, 0, 210, 22, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("SALARY BREAKUP & STATUTORY COMPLIANCE STATEMENT", 14, 14);

  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.text("Generated: " + new Date().toLocaleDateString('en-IN') + " | Output: " + emp.rDisp + " (" + sym + ")", 125, 14);

  doc.setTextColor(15, 47, 34);
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text("1. Employee & Statutory Parameters", 14, 29);

  const empDetails = [
    ["Employee Name: " + emp.rName, "Employee Code: " + emp.rCode, "Gender: " + emp.rGender],
    ["State: " + emp.rState, "Working Days: " + emp.rWorkDays, "PF Strategy: " + (emp.rPfStrategy === 'full_gross' ? 'Uncapped on Full Gross Salary' : emp.rPfStrategy)],
    ["Input Currency: " + emp.rCurr, "Exchange Rate: 1 FCY = " + emp.rEx + " INR", "Display Currency: " + emp.rDisp]
  ];
  doc.autoTable({ startY: 31, body: empDetails, theme: 'plain', styles: { fontSize: 7.5, cellPadding: 1.4 } });

  let finalY = doc.lastAutoTable.finalY + 4;
  doc.setFontSize(9.5); doc.setFont("helvetica", "bold");
  doc.text("2. Monthly Salary Components & CTC (" + emp.rDisp + ")", 14, finalY);

  const wd = emp.rWorkDays, wh = emp.rWorkHours;
  const compRows = [
    ['Basic Pay', 'WAGES', fmtP(emp.basic), fmtP(emp.basic / wd), fmtP(emp.basic / (wd * wh))],
    ['House Rent Allowance (HRA)', 'CAP', fmtP(emp.hra), fmtP(emp.hra / wd), fmtP(emp.hra / (wd * wh))],
    ['Conveyance / Transport Allowance', 'CAP', fmtP(emp.conv), fmtP(emp.conv / wd), fmtP(emp.conv / (wd * wh))]
  ];
  if (emp.special > 0) compRows.push(['Special Allowance (CTC balancing)', 'WAGES', fmtP(emp.special), fmtP(emp.special / wd), fmtP(emp.special / (wd * wh))]);
  
  compRows.push([{content:'GROSS SALARY', fontStyle:'bold'}, '', {content:fmtP(emp.gross), fontStyle:'bold'}, {content:fmtP(emp.gross / wd), fontStyle:'bold'}, {content:fmtP(emp.gross / (wd * wh)), fontStyle:'bold'}]);
  const erPfText = emp.rPfStrategy === 'full_gross' ? '+ Employer PF (13% on Gross Salary)' : '+ Employer PF (13%)';
  compRows.push([erPfText, 'STATUTORY', fmtP(emp.erPF), fmtP(emp.erPF / wd), fmtP(emp.erPF / (wd * wh))]);
  compRows.push(['+ Employer ESIC' + (emp.esiApplicable ? ' (3.25%)' : ' (N/A)'), 'STATUTORY', fmtP(emp.erESIC), fmtP(emp.erESIC / wd), fmtP(emp.erESIC / (wd * wh))]);
  compRows.push([{content:'COST TO COMPANY (CTC)', fontStyle:'bold'}, '', {content:fmtP(emp.ctc), fontStyle:'bold'}, {content:fmtP(emp.ctc / wd), fontStyle:'bold'}, {content:fmtP(emp.ctc / (wd * wh)), fontStyle:'bold'}]);
  
  const eePfText = emp.rPfStrategy === 'full_gross' ? '− Employee PF (12% on Gross Salary)' : '− Employee PF (12%)';
  compRows.push([eePfText, 'DEDUCTION', fmtP(emp.eePF), fmtP(emp.eePF / wd), fmtP(emp.eePF / (wd * wh))]);
  compRows.push(['− Employee ESIC' + (emp.esiApplicable ? ' (0.75%)' : ' (N/A)'), 'DEDUCTION', fmtP(emp.eeESIC), fmtP(emp.eeESIC / wd), fmtP(emp.eeESIC / (wd * wh))]);
  compRows.push(['− Professional Tax (PT)', 'DEDUCTION', fmtP(emp.pt), fmtP(emp.pt / wd), fmtP(emp.pt / (wd * wh))]);
  compRows.push([{content:'NET IN HAND SALARY', fontStyle:'bold'}, '', {content:fmtP(emp.net), fontStyle:'bold'}, {content:fmtP(emp.net / wd), fontStyle:'bold'}, {content:fmtP(emp.net / (wd * wh)), fontStyle:'bold'}]);

  doc.autoTable({
    startY: finalY + 2,
    head: [['Component', 'Classification', 'Monthly (' + sym + ')', 'Daily (' + sym + ')', 'Hourly (' + sym + ')']],
    body: compRows,
    theme: 'striped',
    headStyles: { fillColor: [11, 46, 34], textColor: [255, 255, 255], fontSize: 7.5 },
    styles: { fontSize: 7, cellPadding: 1.5 }
  });

  finalY = doc.lastAutoTable.finalY + 4;
  doc.setFontSize(9.5); doc.setFont("helvetica", "bold");
  doc.text("3. Pan-India Minimum Wage Compliance Audit", 14, finalY);

  const mwRows = [
    ["State & Zone", emp.rState + " — " + emp.rZone],
    ["Skill Category", emp.rCat],
    ["Statutory Minimum Basic", fmtP(emp.mwBasicINR)],
    ["Dearness Allowance (DA)", fmtP(emp.mwDaINR)],
    ["Total Minimum Wage", fmtP(emp.mwTotalINR)],
    ["Current Computed Wage (Basic)", fmtP(emp.basic)],
    ["Compliance Status", emp.isCompliant ? "PASS — COMPLIANT" : "DEFICIT — SHORTFALL OF " + fmtP(emp.shortfallINR)]
  ];
  doc.autoTable({ startY: finalY + 2, body: mwRows, theme: 'plain', styles: { fontSize: 7, cellPadding: 1.5 } });

  return doc.output('arraybuffer');
}

async function processBulk() {
  const fileInput = els('bulkUpload');
  const status = els('bulkStatus');
  if (!fileInput || !fileInput.files.length) { 
    status.innerHTML = '<span style="color:var(--red);">Please select an Excel roster file (.xlsx) first.</span>'; 
    return; 
  }
  status.innerHTML = '<span style="color:var(--emerald);">Reading roster file & initializing bulk engine...</span>';

  try {
    const file = fileInput.files[0];
    const data = await file.arrayBuffer();
    const XLSX = window.XLSX;
    const JSZip = window.JSZip;
    if (!XLSX || !JSZip) {
      status.innerHTML = '<span style="color:var(--red);">XLSX or JSZip library not loaded. Check internet connection.</span>';
      return;
    }

    const wb = XLSX.read(data, { type: 'array' });
    if (!wb.SheetNames || wb.SheetNames.length === 0) {
      status.innerHTML = '<span style="color:var(--red);">Uploaded workbook contains no sheets.</span>';
      return;
    }

    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });

    if (!rows || rows.length === 0) {
      status.innerHTML = '<span style="color:var(--red);">Uploaded Excel sheet contains no employee rows!</span>';
      return;
    }

    const zip = new JSZip();
    const excelFolder = zip.folder("Individual_Excel_Workings");
    const pdfFolder = zip.folder("Individual_PDF_Statements");
    const masterData = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      status.innerHTML = '<span style="color:var(--emerald);">Processing (' + (i + 1) + '/' + rows.length + '): ' + 
        (row['EmpCode'] || row['Emp Code'] || ('EMP-' + (i + 1))) + '...</span>';
      
      // Yield to event loop to allow UI updates
      await new Promise(resolve => setTimeout(resolve, 0));

      const emp = solveEmployeeRoster(row, i);
      const safeCode = emp.rCode.replace(/[^a-zA-Z0-9_-]/g, '_');
      const safeName = emp.rName.replace(/[^a-zA-Z0-9_-]/g, '_');

      // 1. Master Register Row
      masterData.push({
        'Emp Code': emp.rCode,
        'Emp Name': emp.rName,
        'Gender': emp.rGender,
        'State': emp.rState,
        'Zone': emp.rZone,
        'Skill Category': emp.rCat,
        'Input Currency': emp.rCurr,
        'Exchange Rate': emp.rEx,
        'Display Currency': emp.rDisp,
        'Target Amount': emp.rTarget,
        'Target Type': emp.rType.toUpperCase(),
        'PF Strategy': emp.rPfStrategy === 'full_gross' ? 'Uncapped on Full Gross' : emp.rPfStrategy,
        'Basic Pay': Math.round(emp.basic * emp.mult),
        'HRA': Math.round(emp.hra * emp.mult),
        'Conveyance': Math.round(emp.conv * emp.mult),
        'Special Allowance': Math.round(emp.special * emp.mult),
        'Gross Salary': Math.round(emp.gross * emp.mult),
        'Employer PF (13%)': Math.round(emp.erPF * emp.mult),
        'Employer ESIC': Math.round(emp.erESIC * emp.mult),
        'Gratuity': Math.round(emp.grat * emp.mult),
        'Total CTC': Math.round(emp.ctc * emp.mult),
        'Employee PF (12%)': Math.round(emp.eePF * emp.mult),
        'Employee ESIC': Math.round(emp.eeESIC * emp.mult),
        'Professional Tax': Math.round(emp.pt * emp.mult),
        'Net Take Home': Math.round(emp.net * emp.mult),
        'Daily Gross': Math.round((emp.gross * emp.mult) / emp.rWorkDays),
        'Hourly Gross': Math.round((emp.gross * emp.mult) / (emp.rWorkDays * emp.rWorkHours)),
        'Daily CTC': Math.round((emp.ctc * emp.mult) / emp.rWorkDays),
        'Hourly CTC': Math.round((emp.ctc * emp.mult) / (emp.rWorkDays * emp.rWorkHours)),
        'Min Wage Basic': Math.round(emp.mwBasicINR * emp.mult),
        'Min Wage DA': Math.round(emp.mwDaINR * emp.mult),
        'Min Wage Total': Math.round(emp.mwTotalINR * emp.mult),
        'Min Wage Status': emp.isCompliant ? 'PASS' : 'DEFICIT',
        'Min Wage Shortfall': Math.round(emp.shortfallINR * emp.mult),
        'CoSS 50% Audit': emp.flagged ? 'FLAGGED' : 'PASS'
      });

      // 2. Individual Excel Working Workbook with live formulas
      try {
        const empExcelBuf = buildIndividualExcel(emp);
        excelFolder.file(safeCode + '_' + safeName + '_Salary_Working.xlsx', empExcelBuf);
      } catch (eExcel) {
        console.warn('Excel generation error for ' + emp.rCode, eExcel);
      }

      // 3. Individual PDF Statement with autoTable
      try {
        const empPdfBuf = buildIndividualPdf(emp);
        pdfFolder.file(safeCode + '_' + safeName + '_Compliance_Statement.pdf', empPdfBuf);
      } catch (ePdf) {
        console.warn('PDF generation error for ' + emp.rCode, ePdf);
      }
    }

    status.innerHTML = '<span style="color:var(--emerald);">Generating Master Register & packaging ZIP archive...</span>';
    const masterWs = XLSX.utils.json_to_sheet(masterData);
    const masterWb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(masterWb, masterWs, "Master_Register");
    const masterBuf = XLSX.write(masterWb, { bookType: 'xlsx', type: 'array' });
    zip.file("Master_CTC_Compliance_Register.xlsx", masterBuf);

    status.innerHTML = '<span style="color:var(--emerald);">Compressing ZIP package...</span>';
    const zipBlob = await zip.generateAsync({ type: "blob" }, (metadata) => {
      status.innerHTML = '<span style="color:var(--emerald);">Compressing ZIP package: ' + Math.round(metadata.percent) + '%</span>';
    });

    const downloadFileName = 'Bulk_Salary_Compliance_Package_' + new Date().toISOString().slice(0, 10) + '.zip';
    const zipUrl = URL.createObjectURL(zipBlob);
    const link = document.createElement("a");
    link.href = zipUrl;
    link.download = downloadFileName;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => { document.body.removeChild(link); }, 1000);

    status.innerHTML = '<div style="background:var(--mint); border:1px solid var(--emerald); padding:10px 14px; border-radius:6px; margin-top:8px;">' +
      '<div style="font-weight:700; color:var(--emerald-deep); margin-bottom:4px;">' +
      '✅ Successfully processed ' + rows.length + ' employees!</div>' +
      '<div style="font-size:11.5px; color:var(--ink-soft); margin-bottom:8px;">' +
      'ZIP downloaded containing: 1 Master Register Excel, ' + rows.length + ' Individual Excel Workings, and ' + rows.length + ' PDF Statements.' +
      '</div>' +
      '<a href="' + zipUrl + '" download="' + downloadFileName + '" class="btn-primary" style="display:inline-block; font-size:12px; padding:6px 14px; text-decoration:none;">' +
      '⬇ Download ZIP Package Again</a>' +
      '</div>';
  } catch(err) {
    status.innerHTML = '<span style="color:var(--red);">Error processing roster: ' + err.message + '</span>';
    console.error('Bulk processing error:', err);
  }
}

function initAll() {
  buildTable();
  initMwControls();
  calculate();
}

window.addEventListener('DOMContentLoaded', initAll);
</script>
</body>
</html>
`;

fs.writeFileSync('index.html', htmlContent);
console.log('Successfully wrote index.html, size: ' + htmlContent.length + ' bytes');
