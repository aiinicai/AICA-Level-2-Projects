import fs from 'fs';

// Complete Pan-India Minimum Wages Dataset from the CSV
// Format: [State, Region, Category, Description, Period, [b1, d1, t1], [b2, d2, t2], [b3, d3, t3], [b4, d4, t4]]
const MW_DATA = [
  ["Andhra Pradesh","South","OFFICER","MANAGER/ FIELD MANAGER/ Computer Programmer","w.e.f. 01.04.2026 To 30.09.2026",[5557,8947.2,14504.2],[5357,8947.2,14304.2]],
  ["Andhra Pradesh","South","SUPERVISOR","ASST. MANAGER/ ACCOUNTANT/ SUPERVISOR/ STORE KEEPER","w.e.f. 01.04.2026 To 30.09.2026",[4722,8947.2,13669.2],[4302,8947.2,13249.2]],
  ["Andhra Pradesh","South","SKILLED/ TRADES MAN","SALES MAN/ STENOGRAPHER/ RECEPTIONIST/ ELECTRICIAN","w.e.f. 01.04.2026 To 30.09.2026",[4520,8947.2,13467.2],[4302,8947.2,13249.2]],
  ["Andhra Pradesh","South","SEMISKILLED - A","CLERK/ TYPIST/ ASST. SALESMAN/ Xerox Operator","w.e.f. 01.04.2026 To 30.09.2026",[4102,8947.2,13049.2],[3886,8947.2,12833.2]],
  ["Andhra Pradesh","South","SEMISKILLED - B","WEIGH MEN/ KOLAGARI/ Computer Operator","w.e.f. 01.04.2026 To 30.09.2026",[3886,8947.2,12833.2],[3757,8947.2,12704.2]],
  ["Andhra Pradesh","South","UNSKILLED","PEON/ ATTENDER/ WATCH MAN/ HELPER/ MESSENGER","w.e.f. 01.04.2026 To 30.09.2026",[3700,8947.2,12647.2],[3370,8947.2,12317.2]],

  ["Telangana","South","Highly Skilled","Intensive technical competence and independent judgment","w.e.f. 01.06.2026",[20000,0,20000],[19000,0,19000],[18000,0,18000]],
  ["Telangana","South","Skilled","Skill & competence through practical experience","w.e.f. 01.06.2026",[18500,0,18500],[17500,0,17500],[16500,0,16500]],
  ["Telangana","South","Semi-skilled","Skill applied under supervision or guidance","w.e.f. 01.06.2026",[17000,0,17000],[16000,0,16000],[15000,0,15000]],
  ["Telangana","South","Un-skilled","Manual physical effort without prior experience","w.e.f. 01.06.2026",[16000,0,16000],[15000,0,15000],[14000,0,14000]],

  ["Gujarat","West","Skilled","Skilled commercial & shop operations","w.e.f. 01.04.2026 To 30.09.2026",[12324,1573,13897],[12012,1573,13585]],
  ["Gujarat","West","Semi-skilled","Semi-skilled shop employees","w.e.f. 01.04.2026 To 30.09.2026",[12012,1573,13585],[11752,1573,13325]],
  ["Gujarat","West","Un-skilled","Unskilled assistants","w.e.f. 01.04.2026 To 30.09.2026",[11752,1573,13325],[11466,1573,13039]],

  ["Karnataka","South-Western","High Skilled Workers","Manager / Personal Manager","w.e.f 01.04.2026 To 31.03.2027",[15423.4,4549.2,19972.6],[14688.95,4549.2,19238.15],[13989.48,4549.2,18538.68],[13323.31,4549.2,17872.51]],
  ["Karnataka","South-Western","Skilled Workers","Asst. Manager / Asst. Personal Officer","w.e.f 01.04.2026 To 31.03.2027",[14021.27,4549.2,18570.47],[13353.59,4549.2,17902.79],[12717.71,4549.2,17266.91],[12112.1,4549.2,16661.3]],
  ["Karnataka","South-Western","Semi Skilled Workers","Accountant","w.e.f 01.04.2026 To 31.03.2027",[12746.61,4549.2,17295.81],[12139.63,4549.2,16688.83],[11561.55,4549.2,16110.75],[11011,4549.2,15560.2]],
  ["Karnataka","South-Western","Unskilled Workers","Cashier/Stenographer/Computer Opt/Storekeeper","w.e.f 01.04.2026 To 31.03.2027",[11587.83,4549.2,16137.03],[11036.03,4549.2,15585.23],[10510.5,4549.2,15059.7],[10010,4549.2,14559.2]],
  ["Karnataka","South-Western","Office Staff & Incharge","Typist / Data Entry Opt / Clerk","w.e.f 01.04.2026 To 31.03.2027",[16423,4549.2,20972.2],[15688,4549.2,20237.2],[14989,4549.2,19538.2],[14323,4549.2,18872.2]],

  ["Kerala","South","Special Grade-Manager","Special Grade Managerial","July-2026 CPI Index",[9330,6916,16446]],
  ["Kerala","South","Grade A","Grade A Commercial Staff","July-2026 CPI Index",[9120,6916,16236]],
  ["Kerala","South","Grade B","Grade B Commercial Staff","July-2026 CPI Index",[8910,6916,16026]],
  ["Kerala","South","Grade C","Grade C Commercial Staff","July-2026 CPI Index",[8700,6916,15816]],
  ["Kerala","South","Grade D","Grade D Commercial Staff","July-2026 CPI Index",[8490,6916,15606]],
  ["Kerala","South","Grade E","Grade E Commercial Staff","July-2026 CPI Index",[8280,6916,15396]],

  ["Maharashtra","West","Skilled","Skilled personnel","w.e.f 01.07.2026 To 31.12.2026",[11632,4134,15766],[11036,4134,15170],[10440,4134,14574]],
  ["Maharashtra","West","Semi-skilled","Semi-skilled personnel","w.e.f 01.07.2026 To 31.12.2026",[10856,4134,14990],[10260,4134,14394],[9664,4134,13798]],
  ["Maharashtra","West","Un-skilled","Unskilled workforce","w.e.f 01.07.2026 To 31.12.2026",[10021,4134,14155],[9425,4134,13559],[8828,4134,12962]],

  ["Goa","South-Western","Skilled","Skilled craftsmen","w.e.f. 01.04.2026",[13728,3874,17602],[13598,3874,17472]],
  ["Goa","South-Western","Clerical","Clerical & Office Staff","w.e.f. 01.04.2026",[13728,3874,17602],[13598,3874,17472]],
  ["Goa","South-Western","Semi-skilled","Semi-skilled hands","w.e.f. 01.04.2026",[12298,3874,16172],[12168,3874,16042]],
  ["Goa","South-Western","Un-skilled","Unskilled labourers","w.e.f. 01.04.2026",[10712,3874,14586],[10582,3874,14456]],

  ["West Bengal","East","Highly Skilled","Senior Technical & Executives","w.e.f. 01.07.2026 To 31.12.2026",[14054,0,14054],[12990,0,12990]],
  ["West Bengal","East","Skilled","Skilled personnel","w.e.f. 01.07.2026 To 31.12.2026",[12777,0,12777],[11807,0,11807]],
  ["West Bengal","East","Semi-skilled","Semi-skilled operatives","w.e.f. 01.07.2026 To 31.12.2026",[11615,0,11615],[10733,0,10733]],
  ["West Bengal","East","Un-skilled","Unskilled general","w.e.f. 01.07.2026 To 31.12.2026",[10558,0,10558],[9760,0,9760]],

  ["Assam","Northeast","Highly Skilled","Accountant or equivalent","w.e.f. 01.01.2026",[18863.25,846.73,19709.98]],
  ["Assam","Northeast","Skilled","ITI certificate holder / clerical","w.e.f. 01.01.2026",[14671.95,650.79,15322.74]],
  ["Assam","Northeast","Semi-skilled","Semi-skilled workmen","w.e.f. 01.01.2026",[11736.8,520.63,12257.43]],
  ["Assam","Northeast","Un-skilled","General manual workmen","w.e.f. 01.01.2026",[10097.14,446.25,10543.39]],

  ["Haryana","North","Highly Skilled","Highly Skilled technical","w.e.f. 01.04.2026",[19425.85,0,19425.85]],
  ["Haryana","North","Skilled","Skilled operatives","w.e.f. 01.04.2026",[18500.81,0,18500.81]],
  ["Haryana","North","Semi-skilled","Semi-skilled hands","w.e.f. 01.04.2026",[16780.74,0,16780.74]],
  ["Haryana","North","Un-skilled","Un-skilled labourers","w.e.f. 01.04.2026",[15220.71,0,15220.71]],

  ["Madhya Pradesh","Central","Highly Skilled","Senior experts & managers","w.e.f 01.04.2026 To 30.09.2026",[13919,2850,16769]],
  ["Madhya Pradesh","Central","Skilled","Skilled personnel","w.e.f 01.04.2026 To 30.09.2026",[12294,2850,15144]],
  ["Madhya Pradesh","Central","Semi-skilled","Semi-skilled staff","w.e.f 01.04.2026 To 30.09.2026",[10571,2850,13421]],
  ["Madhya Pradesh","Central","Un-skilled","Un-skilled helpers","w.e.f 01.04.2026 To 30.09.2026",[9575,2850,12425]],

  ["Rajasthan","West","Highly Skilled","Highly Skilled personnel","w.e.f. 01.01.2023",[9334,0,9334]],
  ["Rajasthan","West","Skilled","Skilled workforce","w.e.f. 01.01.2023",[8034,0,8034]],
  ["Rajasthan","West","Semi-skilled","Semi-skilled workforce","w.e.f. 01.01.2023",[7722,0,7722]],
  ["Rajasthan","West","Un-skilled","Un-skilled workforce","w.e.f. 01.01.2023",[7410,0,7410]],

  ["Chandigarh","UT (North)","Highly Skilled","Technical Specialists","w.e.f. 01.10.2025 To 31.03.2026",[15637,0,15637]],
  ["Chandigarh","UT (North)","Class I (Staff)","Senior Administrative Staff","w.e.f. 01.10.2025 To 31.03.2026",[15347,0,15347]],
  ["Chandigarh","UT (North)","Skilled-I","Skilled Grade I","w.e.f. 01.10.2025 To 31.03.2026",[15237,0,15237]],
  ["Chandigarh","UT (North)","Skilled-II","Skilled Grade II","w.e.f. 01.10.2025 To 31.03.2026",[15012,0,15012]],
  ["Chandigarh","UT (North)","Class II (Staff)","Class II Clerical","w.e.f. 01.10.2025 To 31.03.2026",[14987,0,14987]],
  ["Chandigarh","UT (North)","Class III (Staff)","Class III Junior Staff","w.e.f. 01.10.2025 To 31.03.2026",[14837,0,14837]],
  ["Chandigarh","UT (North)","Semi-skilled-I","Semi-skilled Grade I","w.e.f. 01.10.2025 To 31.03.2026",[14812,0,14812]],
  ["Chandigarh","UT (North)","Semi-skilled-II","Semi-skilled Grade II","w.e.f. 01.10.2025 To 31.03.2026",[14712,0,14712]],
  ["Chandigarh","UT (North)","Un-skilled","Un-skilled general","w.e.f. 01.10.2025 To 31.03.2026",[14562,0,14562]],

  ["Chhattisgarh","Central","Highly Skilled","Managerial & Specialists","w.e.f. 01.04.2026 To 30.09.2026",[10530,3082,13612],[10270,3082,13352],[10010,3082,13092]],
  ["Chhattisgarh","Central","Skilled","Skilled technicians","w.e.f. 01.04.2026 To 30.09.2026",[9750,3082,12832],[9490,3082,12572],[9230,3082,12312]],
  ["Chhattisgarh","Central","Semi-skilled","Semi-skilled assistants","w.e.f. 01.04.2026 To 30.09.2026",[8970,3082,12052],[8710,3082,11792],[8450,3082,11532]],
  ["Chhattisgarh","Central","Un-skilled","Un-skilled workforce","w.e.f. 01.04.2026 To 30.09.2026",[8320,3082,11402],[8060,3082,11142],[7800,3082,10882]],

  ["Sikkim","North-East","Highly Skilled","Highly Skilled","w.e.f. 11.07.2022",[14690,0,14690]],
  ["Sikkim","North-East","Skilled","Skilled Workers","w.e.f. 11.07.2022",[13910,0,13910]],
  ["Sikkim","North-East","Semi-skilled","Semi-skilled Workers","w.e.f. 11.07.2022",[13520,0,13520]],
  ["Sikkim","North-East","Un-skilled","Un-skilled Labours","w.e.f. 11.07.2022",[13000,0,13000]],

  ["Bihar","East","Highly Skilled","Technical Specialists","w.e.f. 01.04.2026",[17160,312,17472]],
  ["Bihar","East","Skilled","Skilled workforce","w.e.f. 01.04.2026",[14066,260,14326]],
  ["Bihar","East","Semi-skilled","Semi-skilled assistants","w.e.f. 01.04.2026",[11544,208,11752]],
  ["Bihar","East","Un-skilled","Un-skilled labourers","w.e.f. 01.04.2026",[11128,208,11336]],

  ["Jammu & Kashmir","Union Territory","Highly Skilled","Master Craftsmen","w.e.f. 17.10.2022",[14352,0,14352]],
  ["Jammu & Kashmir","Union Territory","Skilled","Skilled personnel","w.e.f. 17.10.2022",[12558,0,12558]],
  ["Jammu & Kashmir","Union Territory","Administrative/Accounts","Accounts & Admin Staff","w.e.f. 17.10.2022",[11674,0,11674]],
  ["Jammu & Kashmir","Union Territory","Semi-Skilled (SRO 460)","Semi-skilled roles","w.e.f. 17.10.2022",[10400,0,10400]],
  ["Jammu & Kashmir","Union Territory","Un-skilled","Un-skilled labourers","w.e.f. 17.10.2022",[8086,0,8086]],

  ["Odisha","East","Highly Skilled","Senior Technical Specialists","w.e.f. 01.04.2026",[15912,260,16172]],
  ["Odisha","East","Skilled / Clerical","Skilled & Office Staff","w.e.f. 01.04.2026",[14612,260,14872]],
  ["Odisha","East","Semi-skilled","Semi-skilled personnel","w.e.f. 01.04.2026",[13312,260,13572]],
  ["Odisha","East","Un-skilled","Unskilled workforce","w.e.f. 01.04.2026",[12012,260,12272]],

  ["Jharkhand","East","Highly Skilled","Zone I: Corp Areas; Zone II: Municipal; Zone III: Others","w.e.f. 01.04.2026",[19396,1950,21346],[18512,1846,20358],[17628,1768,19396]],
  ["Jharkhand","East","Skilled & Clerical","Zone I: Corp Areas; Zone II: Municipal; Zone III: Others","w.e.f. 01.04.2026",[16822,1690,18512],[16042,1612,17654],[15288,1534,16822]],
  ["Jharkhand","East","Semi-skilled","Zone I: Corp Areas; Zone II: Municipal; Zone III: Others","w.e.f. 01.04.2026",[12766,1274,14040],[12168,1222,13390],[11596,1170,12766]],
  ["Jharkhand","East","Un-skilled","Zone I: Corp Areas; Zone II: Municipal; Zone III: Others","w.e.f. 01.04.2026",[12168,1222,13390],[11596,1170,12766],[11050,1092,12142]],

  ["Himachal Pradesh","North","Highly Skilled","Zone I: Without Benefits; Zone II: With Food/Accomm","w.e.f. 01.04.2025",[15390,0,15390],[14250,0,14250]],
  ["Himachal Pradesh","North","Skilled","Zone I: Without Benefits; Zone II: With Food/Accomm","w.e.f. 01.04.2025",[14790,0,14790],[13620,0,13620]],
  ["Himachal Pradesh","North","Semi-skilled","Zone I: Without Benefits; Zone II: With Food/Accomm","w.e.f. 01.04.2025",[13470,0,13470],[13170,0,13170]],
  ["Himachal Pradesh","North","Un-skilled","Zone I: Without Benefits; Zone II: With Food/Accomm","w.e.f. 01.04.2025",[12750,0,12750],[11820,0,11820]],

  ["Delhi","North","Graduates and Above","Clerical / Supervisory (Graduates)","w.e.f. 01.04.2025",[23836,520,24356]],
  ["Delhi","North","Matriculates but not Graduates","Clerical / Supervisory (Matriculates)","w.e.f. 01.04.2025",[21917,494,22411]],
  ["Delhi","North","Non Matriculates","Clerical / Supervisory (Non-Matric)","w.e.f. 01.04.2025",[19929,442,20371]],
  ["Delhi","North","Skilled","All Scheduled Employments (Skilled)","w.e.f. 01.04.2025",[21917,494,22411]],
  ["Delhi","North","Semi-skilled","All Scheduled Employments (Semi-skilled)","w.e.f. 01.04.2025",[19929,442,20371]],
  ["Delhi","North","Un-skilled","All Scheduled Employments (Unskilled)","w.e.f. 01.04.2025",[18066,390,18456]],

  ["Uttarakhand","North","Clerical Category - I","Zone I: Towns >1L Pop; Zone II: Remaining Parts","w.e.f. 01.04.2026",[15275,518,15793],[15035,518,15553]],
  ["Uttarakhand","North","Clerical Category - II","Zone I: Towns >1L Pop; Zone II: Remaining Parts","w.e.f. 01.04.2026",[14340,518,14858],[14139,518,14657]],
  ["Uttarakhand","North","Skilled","Zone I: Towns >1L Pop; Zone II: Remaining Parts","w.e.f. 01.04.2026",[14023,518,14541],[13838,518,14356]],
  ["Uttarakhand","North","Semi-skilled","Zone I: Towns >1L Pop; Zone II: Remaining Parts","w.e.f. 01.04.2026",[13280,518,13798],[13110,518,13628]],
  ["Uttarakhand","North","Unskilled","Zone I: Towns >1L Pop; Zone II: Remaining Parts","w.e.f. 01.04.2026",[12539,518,13057],[12391,518,12909]],

  ["Punjab","North","Staff Category-A","Post Graduate/MBA/Company Secretary","w.e.f. 01.05.2026",[16896.4,2534.6,19431]],
  ["Punjab","North","Staff Category-B","Graduate with Diploma/Stenography","w.e.f. 01.05.2026",[15226.4,2283.6,17510]],
  ["Punjab","North","Staff Category-C","Undergraduate/Data Entry/Salesman","w.e.f. 01.05.2026",[13726.4,2059.6,15786]],
  ["Punjab","North","Staff Category-D","Class-IV Employee/Contractual","w.e.f. 01.05.2026",[12526.4,1879.6,14406]],
  ["Punjab","North","Highly Skilled","Highly Skilled technical","w.e.f. 01.05.2026",[14435.4,2165.6,16601]],
  ["Punjab","North","Skilled","Skilled personnel","w.e.f. 01.05.2026",[13403.4,2010.6,15414]],
  ["Punjab","North","Semi-skilled","Semi-skilled hands","w.e.f. 01.05.2026",[12506.4,1876.6,14383]],
  ["Punjab","North","Un-skilled","Un-skilled general","w.e.f. 01.05.2026",[11726.4,1759.6,13486]],

  ["Tamil Nadu","South","Manager/Sales Manager - Skilled","Managerial / Incharge","w.e.f. 01.04.2026",[7390,7353,14743],[7328,7353,14681],[7264,7353,14617],[7214,7353,14567]],
  ["Tamil Nadu","South","Asst. Manager/Accountant - Skilled","Supervisory / Accounting","w.e.f. 01.04.2026",[6880,7353,14233],[6815,7353,14168],[6753,7353,14106],[6691,7353,14044]],
  ["Tamil Nadu","South","Cashier/Clerk/Typist - Semi Skilled","Clerical / Sales Front","w.e.f. 01.04.2026",[6829,7353,14182],[6753,7353,14106],[6680,7353,14033],[6619,7353,13972]],
  ["Tamil Nadu","South","Receptionist/Driver - Semi Skilled","Support Assistants","w.e.f. 01.04.2026",[6767,7353,14120],[6691,7353,14044],[6619,7353,13972],[6553,7353,13906]],
  ["Tamil Nadu","South","Peon/Helper - Unskilled","General Unskilled Assistants","w.e.f. 01.04.2026",[6691,7353,14044],[6619,7353,13972],[6541,7353,13894],[6470,7353,13823]],

  ["Tripura","North-East","Skilled","Accountant, Welder, Mechanic, Fitter","w.e.f. 01.04.2026",[8739,1170.29,9909.29]],
  ["Tripura","North-East","Semi-skilled","Weight-Man, Hawker, Porter","w.e.f. 01.04.2026",[7814,1046.35,8860.35]],
  ["Tripura","North-East","Un-skilled","Peon, Night Guard, Leader","w.e.f. 01.04.2026",[7123,953.8,8076.8]],

  ["Uttar Pradesh","North","Skilled","Zone I: Noida/Gzb; Zone II: Nagar Nigam; Zone III: Remaining","w.e.f. 01.04.2026 To 30.09.2026",[15876,992,16868],[15082,943,16025],[14328,896,15224]],
  ["Uttar Pradesh","North","Semi-skilled","Zone I: Noida/Gzb; Zone II: Nagar Nigam; Zone III: Remaining","w.e.f. 01.04.2026 To 30.09.2026",[14173,886,15059],[13464,842,14306],[12791,799,13590]],
  ["Uttar Pradesh","North","Un-skilled","Zone I: Noida/Gzb; Zone II: Nagar Nigam; Zone III: Remaining","w.e.f. 01.04.2026 To 30.09.2026",[12885,805,13690],[12241,765,13006],[11629,727,12356]],

  ["Andaman & Nicobar","Union Territory","Highly Skilled","Technical Specialists","w.e.f. 01.07.2026",[24414,0,24414]],
  ["Andaman & Nicobar","Union Territory","Skilled/Clerical","Skilled & Office Staff","w.e.f. 01.07.2026",[22256,0,22256]],
  ["Andaman & Nicobar","Union Territory","Semi Skilled Supervisory","Supervisory Assistants","w.e.f. 01.07.2026",[19058,0,19058]],
  ["Andaman & Nicobar","Union Territory","Un-skilled","Un-skilled workforce","w.e.f. 01.07.2026",[16952,0,16952]],

  ["Arunachal Pradesh","North-East","Skilled","Skilled personnel","w.e.f. 01.04.2016",[6600,0,6600],[7200,0,7200]],
  ["Arunachal Pradesh","North-East","Semi-skilled","Semi-skilled personnel","w.e.f. 01.04.2016",[6300,0,6300],[6900,0,6900]],
  ["Arunachal Pradesh","North-East","Un-skilled","Unskilled personnel","w.e.f. 01.04.2016",[6000,0,6000],[6600,0,6600]],

  ["Manipur","North-East","Skilled","Manager/UDC/Graduate Clerk","w.e.f. 12.03.2025",[14400,0,14400]],
  ["Manipur","North-East","Semi-skilled","Cashier/Accountant/Steno/Typist","w.e.f. 12.03.2025",[13200,0,13200]],
  ["Manipur","North-East","Un-skilled","Chowkidar/Peon/Mali","w.e.f. 12.03.2025",[12000,0,12000]],

  ["Meghalaya","North-East","Highly Skilled","Senior Specialists","w.e.f. 01.04.2026",[16770,962,17732]],
  ["Meghalaya","North-East","Skilled","Skilled crafts","w.e.f. 01.04.2026",[15730,910,16640]],
  ["Meghalaya","North-East","Semi-skilled","Semi-skilled hands","w.e.f. 01.04.2026",[14690,858,15548]],
  ["Meghalaya","North-East","Un-skilled","Un-skilled labours","w.e.f. 01.04.2026",[13650,780,14430]],

  ["Mizoram","North-East","Skilled-I","Senior Skilled Trades","w.e.f. 01.04.2023",[18980,0,18980]],
  ["Mizoram","North-East","Skilled-II","Junior Skilled Trades","w.e.f. 01.04.2023",[14820,0,14820]],
  ["Mizoram","North-East","Semi-skilled","Semi-skilled operatives","w.e.f. 01.04.2023",[11960,0,11960]],
  ["Mizoram","North-East","Un-skilled","Un-skilled general","w.e.f. 01.04.2023",[10920,0,10920]],

  ["Nagaland","North-East","Skilled","Skilled artisans","w.e.f. 12.06.2019",[7050,0,7050]],
  ["Nagaland","North-East","Semi-skilled","Semi-skilled operatives","w.e.f. 12.06.2019",[6300,0,6300]],
  ["Nagaland","North-East","Un-skilled","General manual labour","w.e.f. 12.06.2019",[5280,0,5280]],

  ["Dadra & Nagar Haveli and Daman & Diu","UT (West)","Skilled","Skilled Tradesmen","w.e.f. 01.04.2026",[12012,1573,13585]],
  ["Dadra & Nagar Haveli and Daman & Diu","UT (West)","Semi-skilled","Semi-skilled Operatives","w.e.f. 01.04.2026",[11752,1573,13325]],
  ["Dadra & Nagar Haveli and Daman & Diu","UT (West)","Un-skilled","General Unskilled","w.e.f. 01.04.2026",[11466,1573,13039]],

  ["Puducherry","UT (South)","Category 1","Senior Supervisory / Managerial","w.e.f. 20.09.2024",[11695,0,11695]],
  ["Puducherry","UT (South)","Category 2","Technical Skilled","w.e.f. 20.09.2024",[11283,0,11283]],
  ["Puducherry","UT (South)","Category 3","Clerical & Commercial","w.e.f. 20.09.2024",[11242,0,11242]],
  ["Puducherry","UT (South)","Category 4","Semi-skilled Hands","w.e.f. 20.09.2024",[11192,0,11192]],
  ["Puducherry","UT (South)","Category 5","General Unskilled","w.e.f. 20.09.2024",[11131,0,11131]],

  ["Ladakh","UT (North)","Highly Skilled","Technical Specialists","w.e.f. 04.11.2022",[21710,0,21710]],
  ["Ladakh","UT (North)","Skilled","Skilled Workers","w.e.f. 04.11.2022",[14950,0,14950]],
  ["Ladakh","UT (North)","Administrative/Accounts","Admin / Accounts","w.e.f. 04.11.2022",[13910,0,13910]],
  ["Ladakh","UT (North)","Un-Skilled","Unskilled Helpers","w.e.f. 04.11.2022",[11700,0,11700]]
];

console.log(`Loaded ${MW_DATA.length} minimum wage categories across Pan-India.`);
fs.writeFileSync('src/data/mw_raw.json', JSON.stringify(MW_DATA));
