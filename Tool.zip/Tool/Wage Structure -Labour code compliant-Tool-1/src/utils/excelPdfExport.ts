/**
 * Excel & PDF Export Engine with Multi-Currency & Minimum Wage Compliance Matrix
 */
import { CalculationResult } from './statutoryCompliance';
import { formatCurrency, getCurrencyConfig } from './currency';

declare global {
  interface Window {
    XLSX: any;
    JSZip: any;
    jspdf: any;
  }
}

export function generateEmpExcelWorkbook(
  r: CalculationResult,
  empInfo: {
    name: string;
    code: string;
    gender: string;
    state: string;
    workDays: number;
    pfStrategy: string;
  },
  isRounded: boolean
) {
  const XLSX = window.XLSX;
  if (!XLSX) {
    throw new Error("XLSX library not loaded");
  }

  const wb = XLSX.utils.book_new();
  const ws: Record<string, any> = {};
  const curr = getCurrencyConfig(r.displayCurrency);
  const sym = curr.symbol;
  const numFmt = isRounded ? `"${sym}"#,##0` : `"${sym}"#,##0.00`;

  let rIdx = 1;

  function setCell(colStr: string, rowNum: number, val: any, formula?: string, numFormat?: string) {
    const addr = colStr + rowNum;
    const cell: any = { v: val };
    if (typeof val === 'number') {
      cell.t = 'n';
      if (numFormat) cell.z = numFormat;
    } else {
      cell.t = 's';
    }
    if (formula) cell.f = formula;
    ws[addr] = cell;
  }

  // Row 1: Title
  setCell('A', rIdx, "SALARY STRUCTURING, MINIMUM WAGE & STATUTORY COMPLIANCE WORKING");
  rIdx += 2;

  // Section 1: Inputs
  setCell('A', rIdx, "1. EMPLOYEE & PARAMETER INPUTS");
  rIdx++;
  setCell('A', rIdx, "Employee Name:"); setCell('B', rIdx, empInfo.name);
  setCell('C', rIdx, "Gender:"); setCell('D', rIdx, empInfo.gender);
  setCell('E', rIdx, "State:"); setCell('F', rIdx, empInfo.state);
  
  rIdx++;
  setCell('A', rIdx, "Employee Code:"); setCell('B', rIdx, empInfo.code);
  setCell('C', rIdx, "Work Days/Mth:"); setCell('D', rIdx, r.workDays);
  setCell('E', rIdx, "Work Hours/Day:"); setCell('F', rIdx, r.workHours);
  
  rIdx++;
  const inputRow_PFStrat = rIdx;
  setCell('A', rIdx, "PF Strategy:"); setCell('B', rIdx, r.pfLimitAmt ? "capped" : "uncapped");
  setCell('C', rIdx, "PF Ceiling Limit (₹):"); setCell('D', rIdx, r.pfLimitAmt || 15000, undefined, '"₹"#,##0');
  setCell('E', rIdx, "Include Gratuity?:"); setCell('F', rIdx, r.includeGratuity ? "yes" : "no");
  
  rIdx++;
  const inputRow_Currency = rIdx;
  setCell('A', rIdx, "Base Input Currency:"); setCell('B', rIdx, r.inputCurrency);
  setCell('C', rIdx, "Exchange Rate (1 FCY=X INR):"); setCell('D', rIdx, r.exchangeRate);
  setCell('E', rIdx, "Output Display Currency:"); setCell('F', rIdx, r.displayCurrency);

  const inputRow_WorkDays = 5; 
  const inputRow_WorkHours = 5; 

  rIdx += 2;

  // Section 2: Components & CTC
  setCell('A', rIdx, `2. MONTHLY SALARY COMPONENTS & COST TO COMPANY (${r.displayCurrency})`);
  rIdx++;
  setCell('A', rIdx, "Component");
  setCell('B', rIdx, `Monthly (${sym})`);
  setCell('C', rIdx, `Daily (${sym})`);
  setCell('D', rIdx, `Hourly (${sym})`);
  setCell('E', rIdx, "Classification");

  rIdx++;
  const compStartRow = rIdx;
  const wagesRows: number[] = [];
  const capRows: number[] = [];

  const mult = r.displayCurrency === 'INR' ? 1 : (1 / r.exchangeRate);

  r.lines.forEach(l => {
    const dispMonthly = l.monthly * mult;
    setCell('A', rIdx, l.label);
    setCell('B', rIdx, dispMonthly, undefined, numFmt);
    setCell('C', rIdx, dispMonthly / r.workDays, `=B${rIdx}/$D$${inputRow_WorkDays}`, numFmt);
    setCell('D', rIdx, dispMonthly / (r.workDays * r.workHours), `=C${rIdx}/$F$${inputRow_WorkHours}`, numFmt);
    setCell('E', rIdx, l.cls);

    if (l.cls === 'WAGES') wagesRows.push(rIdx);
    else capRows.push(rIdx);

    rIdx++;
  });

  const compEndRow = rIdx - 1;

  // Gross Salary Row
  const grossRow = rIdx;
  setCell('A', grossRow, "Gross Salary");
  setCell('B', grossRow, r.grossSalary * mult, `=SUM(B${compStartRow}:B${compEndRow})`, numFmt);
  setCell('C', grossRow, (r.grossSalary * mult) / r.workDays, `=B${grossRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', grossRow, (r.grossSalary * mult) / (r.workDays * r.workHours), `=C${grossRow}/$F$${inputRow_WorkHours}`, numFmt);
  setCell('E', grossRow, "TOTAL GROSS");
  rIdx++;

  // Leave Upliftment
  let leaveRow: number | null = null;
  if (r.leaveUpliftOn) {
    leaveRow = rIdx;
    setCell('A', leaveRow, "+ Leave Upliftment");
    setCell('B', leaveRow, r.leaveUpliftMonthly * mult, undefined, numFmt);
    setCell('C', leaveRow, (r.leaveUpliftMonthly * mult) / r.workDays, `=B${leaveRow}/$D$${inputRow_WorkDays}`, numFmt);
    setCell('D', leaveRow, (r.leaveUpliftMonthly * mult) / (r.workDays * r.workHours), `=C${leaveRow}/$F$${inputRow_WorkHours}`, numFmt);
    rIdx++;
  }

  // Statutory Rows
  const erPfRow = rIdx;
  setCell('A', erPfRow, "+ Employer PF (13%)");
  setCell('B', erPfRow, r.employerPF * mult, undefined, numFmt);
  setCell('C', erPfRow, (r.employerPF * mult) / r.workDays, `=B${erPfRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', erPfRow, (r.employerPF * mult) / (r.workDays * r.workHours), `=C${erPfRow}/$F$${inputRow_WorkHours}`, numFmt);
  rIdx++;

  const erEsicRow = rIdx;
  setCell('A', erEsicRow, "+ Employer ESIC" + (r.esiApplicable ? "" : " (N/A)"));
  setCell('B', erEsicRow, r.employerESIC * mult, undefined, numFmt);
  setCell('C', erEsicRow, (r.employerESIC * mult) / r.workDays, `=B${erEsicRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', erEsicRow, (r.employerESIC * mult) / (r.workDays * r.workHours), `=C${erEsicRow}/$F$${inputRow_WorkHours}`, numFmt);
  rIdx++;

  const erLwfRow = rIdx;
  setCell('A', erLwfRow, "+ Employer LWF (Avg Monthly)");
  setCell('B', erLwfRow, r.lwfER_monthlyCTC * mult, undefined, numFmt);
  setCell('C', erLwfRow, (r.lwfER_monthlyCTC * mult) / r.workDays, `=B${erLwfRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', erLwfRow, (r.lwfER_monthlyCTC * mult) / (r.workDays * r.workHours), `=C${erLwfRow}/$F$${inputRow_WorkHours}`, numFmt);
  rIdx++;

  const gratuityRow = rIdx;
  setCell('A', gratuityRow, "+ Gratuity Provision (4.81%)");
  setCell('B', gratuityRow, r.gratuityAmt * mult, undefined, numFmt);
  setCell('C', gratuityRow, (r.gratuityAmt * mult) / r.workDays, `=B${gratuityRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', gratuityRow, (r.gratuityAmt * mult) / (r.workDays * r.workHours), `=C${gratuityRow}/$F$${inputRow_WorkHours}`, numFmt);
  rIdx++;

  const ctcRow = rIdx;
  const ctcAddList = [`B${grossRow}`];
  if (leaveRow) ctcAddList.push(`B${leaveRow}`);
  ctcAddList.push(`B${erPfRow}`, `B${erEsicRow}`, `B${erLwfRow}`, `B${gratuityRow}`);
  
  setCell('A', ctcRow, "COST TO COMPANY (CTC)");
  setCell('B', ctcRow, r.ctcMonthly * mult, `=SUM(${ctcAddList.join(',')})`, numFmt);
  setCell('C', ctcRow, (r.ctcMonthly * mult) / r.workDays, `=B${ctcRow}/$D$${inputRow_WorkDays}`, numFmt);
  setCell('D', ctcRow, (r.ctcMonthly * mult) / (r.workDays * r.workHours), `=C${ctcRow}/$F$${inputRow_WorkHours}`, numFmt);
  setCell('E', ctcRow, "GRAND TOTAL CTC");
  rIdx += 2;

  // Section 3: Deductions
  setCell('A', rIdx, `3. EMPLOYEE DEDUCTIONS & NET TAKE-HOME (${r.displayCurrency})`);
  rIdx++;
  const dedGrossRow = rIdx;
  setCell('A', dedGrossRow, "Gross Salary");
  setCell('B', dedGrossRow, r.grossSalary * mult, `=B${grossRow}`, numFmt);
  rIdx++;

  const eePfRow = rIdx;
  setCell('A', eePfRow, "− Employee PF (12%)");
  setCell('B', eePfRow, r.employeePF * mult, undefined, numFmt);
  rIdx++;

  const eeEsicRow = rIdx;
  setCell('A', eeEsicRow, "− Employee ESIC" + (r.esiApplicable ? "" : " (N/A)"));
  setCell('B', eeEsicRow, r.employeeESIC * mult, undefined, numFmt);
  rIdx++;

  const ptRow = rIdx;
  setCell('A', ptRow, "− Professional Tax (PT)");
  setCell('B', ptRow, r.pt * mult, undefined, numFmt);
  rIdx++;

  const eeLwfRow = rIdx;
  setCell('A', eeLwfRow, "− Employee LWF");
  setCell('B', eeLwfRow, r.lwfEE_cycle * mult, undefined, numFmt);
  rIdx++;

  const netRow = rIdx;
  setCell('A', netRow, "NET IN HAND (Standard Month)");
  setCell('B', netRow, r.netMonthlyStandard * mult, `=B${dedGrossRow}-B${eePfRow}-B${eeEsicRow}-B${ptRow}-B${eeLwfRow}`, numFmt);
  rIdx += 2;

  // Section 3.5: Pan-India Minimum Wage Compliance Matrix
  if (r.minWageAudit) {
    const mw = r.minWageAudit;
    setCell('A', rIdx, "3.5 PAN-INDIA MINIMUM WAGE COMPLIANCE & AUDIT MATRIX");
    rIdx++;
    setCell('A', rIdx, "State:"); setCell('B', rIdx, mw.state);
    setCell('C', rIdx, "Zone / Area:"); setCell('D', rIdx, mw.zone);
    setCell('E', rIdx, "Category:"); setCell('F', rIdx, mw.category);
    rIdx++;
    setCell('A', rIdx, "Notification Period:"); setCell('B', rIdx, mw.notificationPeriod);
    setCell('C', rIdx, "Covered Roles:"); setCell('D', rIdx, mw.description);
    rIdx++;
    setCell('A', rIdx, `Statutory Minimum Basic (${sym}):`); setCell('B', rIdx, mw.minBasic * mult, undefined, numFmt);
    setCell('C', rIdx, `Dearness Allowance (${sym}):`); setCell('D', rIdx, mw.minDA * mult, undefined, numFmt);
    setCell('E', rIdx, `Total Statutory Min Wage (${sym}):`); setCell('F', rIdx, mw.minTotal * mult, undefined, numFmt);
    rIdx++;
    setCell('A', rIdx, `Current Computed Wage (Basic+DA):`); setCell('B', rIdx, mw.computedWage * mult, undefined, numFmt);
    setCell('C', rIdx, "Compliance Status:"); setCell('D', rIdx, mw.compliant ? "PASS - COMPLIANT" : "DEFICIT - NON COMPLIANT");
    setCell('E', rIdx, `Shortfall Amount (${sym}):`); setCell('F', rIdx, mw.compliant ? 0 : mw.shortfallDisplay, undefined, numFmt);
    rIdx += 2;
  }

  // Section 4: CoSS 2020 50% Test
  setCell('A', rIdx, "4. LABOUR CODE (CoSS 2020) 50% RULE AUDIT TEST (INR Base)");
  rIdx++;
  setCell('A', rIdx, "Core Wages Base (Basic + DA + Special)"); setCell('B', rIdx, r.wagesBase, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "Exclusions Basket (Cap Allowances)"); setCell('B', rIdx, r.capBasket, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "+ Employer PF (13%) & Gratuity Provision (Prelim)"); setCell('B', rIdx, r.employerPFprelim + r.initialGratuityProvision, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "Total Remuneration Base"); setCell('B', rIdx, r.totalRemuneration, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "50% Statutory Ceiling Threshold"); setCell('B', rIdx, r.threshold, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "CoSS Compliance Status"); setCell('B', rIdx, r.flagged ? "FLAGGED - Exceeds 50%" : "PASS - Within 50%");
  rIdx++;
  setCell('A', rIdx, "Excess Re-added to Wage Base"); setCell('B', rIdx, r.excess, undefined, '"₹"#,##0');
  rIdx++;
  setCell('A', rIdx, "Final Compliant Wage Base"); setCell('B', rIdx, r.revisedWagesBase, undefined, '"₹"#,##0');

  ws['!ref'] = `A1:F${rIdx}`;
  ws['!cols'] = [
    { wch: 38 }, { wch: 22 }, { wch: 20 }, { wch: 20 }, { wch: 24 }, { wch: 22 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, "Salary_Working");
  return wb;
}

export function generateEmpPdf(
  r: CalculationResult,
  empInfo: {
    name: string;
    code: string;
    gender: string;
    state: string;
    workDays: number;
    pfStrategy: string;
  },
  isRounded: boolean
) {
  const { jsPDF } = window.jspdf;
  if (!jsPDF) throw new Error("jsPDF library not loaded");
  const doc = new jsPDF();
  
  const curr = getCurrencyConfig(r.displayCurrency);
  const sym = curr.symbol;
  const mult = r.displayCurrency === 'INR' ? 1 : (1 / r.exchangeRate);
  const fmt = (amt: number) => formatCurrency(amt * mult, r.displayCurrency, isRounded);
  const fmtRaw = (amtInCurr: number) => formatCurrency(amtInCurr, r.displayCurrency, isRounded);

  // Top header banner
  doc.setFillColor(11, 46, 34); 
  doc.rect(0, 0, 210, 22, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("SALARY BREAKUP & STATUTORY COMPLIANCE STATEMENT", 14, 13);
  
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.text(`Generated: ${new Date().toLocaleDateString('en-IN')} | Currency: ${r.displayCurrency} (${sym})`, 130, 13);
  
  // Section 1: Employee info
  doc.setTextColor(15, 47, 34);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.text("1. Employee & Currency Parameters", 14, 28);
  
  const empDetails = [
    [
      { content: `Employee Name: ${empInfo.name}`, fontStyle: 'bold' },
      `Employee Code: ${empInfo.code}`,
      `Gender: ${empInfo.gender === 'F' ? 'Female' : 'Male'}`
    ],
    [
      `State: ${empInfo.state}`,
      `Working Days: ${empInfo.workDays}`,
      `PF Strategy: ${empInfo.pfStrategy}`
    ],
    [
      `Input Currency: ${r.inputCurrency} | Display: ${r.displayCurrency}`,
      `Exchange Rate: 1 FCY = ${r.exchangeRate} INR`,
      `Statutory Logic: ${r.statutoryLogic === 'coss' ? 'CoSS 2020 (50% Rule)' : 'Pre-CoSS'}`
    ]
  ];
  
  doc.autoTable({
    startY: 30,
    body: empDetails,
    theme: 'plain',
    styles: { fontSize: 7.5, cellPadding: 1.4 },
    columnStyles: { 0: { cellWidth: 70 }, 1: { cellWidth: 65 }, 2: { cellWidth: 55 } }
  });
  
  let finalY = doc.lastAutoTable.finalY + 4;
  
  // Section 2: Components & CTC
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text(`2. Monthly Salary Components & Cost to Company (${r.displayCurrency})`, 14, finalY);
  
  const compRows: any[] = [];
  r.lines.forEach(l => {
    compRows.push([
      l.label,
      l.cls,
      fmt(l.monthly),
      fmt(l.monthly / r.workDays),
      fmt(l.monthly / (r.workDays * r.workHours))
    ]);
  });
  
  compRows.push([
    { content: 'GROSS SALARY', fontStyle: 'bold' },
    '',
    { content: fmt(r.grossSalary), fontStyle: 'bold' },
    { content: fmt(r.grossSalary / r.workDays), fontStyle: 'bold' },
    { content: fmt(r.grossSalary / (r.workDays * r.workHours)), fontStyle: 'bold' }
  ]);
  
  if (r.leaveUpliftOn) {
    compRows.push(['+ Leave Upliftment', 'UPLIFT', fmt(r.leaveUpliftMonthly), fmt(r.leaveUpliftMonthly / r.workDays), fmt(r.leaveUpliftMonthly / (r.workDays * r.workHours))]);
  }
  compRows.push(['+ Employer PF (13%)', 'STATUTORY', fmt(r.employerPF), fmt(r.employerPF / r.workDays), fmt(r.employerPF / (r.workDays * r.workHours))]);
  compRows.push(['+ Employer ESIC' + (r.esiApplicable ? '' : ' (N/A)'), 'STATUTORY', fmt(r.employerESIC), fmt(r.employerESIC / r.workDays), fmt(r.employerESIC / (r.workDays * r.workHours))]);
  if (r.applyLwf) {
    compRows.push(['+ Employer LWF (Avg Monthly)', 'STATUTORY', fmt(r.lwfER_monthlyCTC), fmt(r.lwfER_monthlyCTC / r.workDays), fmt(r.lwfER_monthlyCTC / (r.workDays * r.workHours))]);
  }
  if (r.includeGratuity) {
    compRows.push(['+ Gratuity Provision (4.81%)', 'STATUTORY', fmt(r.gratuityAmt), fmt(r.gratuityAmt / r.workDays), fmt(r.gratuityAmt / (r.workDays * r.workHours))]);
  }
  compRows.push([
    { content: 'COST TO COMPANY (CTC)', fontStyle: 'bold' },
    '',
    { content: fmt(r.ctcMonthly), fontStyle: 'bold' },
    { content: fmt(r.ctcMonthly / r.workDays), fontStyle: 'bold' },
    { content: fmt(r.ctcMonthly / (r.workDays * r.workHours)), fontStyle: 'bold' }
  ]);
  
  doc.autoTable({
    startY: finalY + 2,
    head: [['Component', 'Classification', `Monthly (${sym})`, `Daily (${sym})`, `Hourly (${sym})`]],
    body: compRows,
    theme: 'striped',
    headStyles: { fillColor: [11, 46, 34], textColor: [255, 255, 255], fontSize: 7.5, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1.5 },
    columnStyles: { 0: { cellWidth: 72 }, 1: { cellWidth: 26 }, 2: { halign: 'right' }, 3: { halign: 'right' }, 4: { halign: 'right' } }
  });
  
  finalY = doc.lastAutoTable.finalY + 4;
  
  // Section 3: Deductions
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text(`3. Deductions & Net-in-Hand Breakdown (${r.displayCurrency})`, 14, finalY);
  
  const dedRows: any[] = [
    ['Gross Salary', fmt(r.grossSalary)],
    ['− Employee PF (12%)', fmt(-r.employeePF)],
    ['− Employee ESIC' + (r.esiApplicable ? '' : ' (N/A)'), fmt(-r.employeeESIC)],
    ['− Professional Tax (PT)', fmt(-r.pt)]
  ];
  if (r.applyLwf && r.lwfEE_cycle > 0) {
    dedRows.push([`− Employee LWF (${r.lwfFreqStr === 'Monthly' ? 'Monthly' : 'Event: ' + r.lwfFreqStr})`, fmt(-r.lwfEE_cycle)]);
  }
  dedRows.push([
    { content: 'NET IN HAND (Standard Month)', fontStyle: 'bold' },
    { content: fmt(r.netMonthlyStandard), fontStyle: 'bold' }
  ]);
  if (r.applyLwf && r.lwfEE_cycle > 0 && r.lwfFreqStr !== 'Monthly') {
    dedRows.push([
      { content: `Net In Hand (During LWF Month)`, fontStyle: 'bold' },
      { content: fmt(r.netMonthlyLWF), fontStyle: 'bold' }
    ]);
  }
  
  doc.autoTable({
    startY: finalY + 2,
    head: [['Deduction / Net Computation', `Amount (${sym})`]],
    body: dedRows,
    theme: 'grid',
    headStyles: { fillColor: [60, 86, 72], textColor: [255, 255, 255], fontSize: 7.5 },
    styles: { fontSize: 7, cellPadding: 1.5 },
    columnStyles: { 0: { cellWidth: 120 }, 1: { halign: 'right' } }
  });
  
  finalY = doc.lastAutoTable.finalY + 4;

  // Section 3.5: Pan-India Minimum Wage Audit
  if (r.minWageAudit) {
    const mw = r.minWageAudit;
    if (finalY + 30 > 280) { doc.addPage(); finalY = 14; }
    doc.setFontSize(9.5);
    doc.setFont("helvetica", "bold");
    doc.text(`3.5 Pan-India Minimum Wage Compliance Audit`, 14, finalY);

    const mwRows = [
      [`State & Zone`, `${mw.state} — ${mw.zone}`],
      [`Skill Category`, `${mw.category} (${mw.description})`],
      [`Notification Period`, mw.notificationPeriod],
      [`Statutory Minimum Basic (${sym})`, fmt(mw.minBasic)],
      [`Statutory Dearness Allowance (${sym})`, fmt(mw.minDA)],
      [`Total Minimum Wage Statutory (${sym})`, fmt(mw.minTotal)],
      [`Current Computed Wage (Basic + DA) (${sym})`, fmt(mw.computedWage)],
      [`Compliance Status`, mw.compliant ? 'PASS — COMPLIANT' : `DEFICIT — SHORTFALL OF ${fmtRaw(mw.shortfallDisplay)}`]
    ];

    doc.autoTable({
      startY: finalY + 2,
      body: mwRows,
      theme: 'plain',
      styles: { fontSize: 7, cellPadding: 1.4 },
      columnStyles: { 0: { cellWidth: 85, fontStyle: 'bold' }, 1: { halign: 'right' } }
    });

    finalY = doc.lastAutoTable.finalY + 4;
  }
  
  // Section 4: CoSS 2020 50% Audit
  if (finalY + 30 > 280) { doc.addPage(); finalY = 14; }
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.text("4. Labour Code (CoSS 2020) Compliance Audit (INR Base)", 14, finalY);
  
  const auditRows = [
    ['Core Wages Base (Basic + DA)', formatCurrency(r.wagesBase, 'INR', isRounded)],
    ['Excluded Allowances Basket (HRA, Conveyance, LTA, etc.)', formatCurrency(r.capBasket, 'INR', isRounded)],
    ['+ Employer PF (13%) & Gratuity Provision', formatCurrency(r.employerPFprelim + r.initialGratuityProvision, 'INR', isRounded)],
    ['Total Remuneration Base', formatCurrency(r.totalRemuneration, 'INR', isRounded)],
    ['50% Statutory Ceiling Limit', formatCurrency(r.threshold, 'INR', isRounded)],
    ['Status', r.flagged ? 'FLAGGED — Exceeds 50% Ceiling' : 'PASS — Within 50% Limit'],
    ['Excess Re-added to Wages Base', formatCurrency(r.excess, 'INR', isRounded)],
    ['Final Compliant Wage Base for Statutory Calculations', formatCurrency(r.revisedWagesBase, 'INR', isRounded)]
  ];
  
  doc.autoTable({
    startY: finalY + 2,
    body: auditRows,
    theme: 'plain',
    styles: { fontSize: 7, cellPadding: 1.4 },
    columnStyles: { 0: { cellWidth: 120, fontStyle: 'bold' }, 1: { halign: 'right' } }
  });
  
  return doc.output('arraybuffer');
}

export function downloadBulkTemplate() {
  const XLSX = window.XLSX;
  if (!XLSX) return;
  const templateData = [
    {
      EmpCode: 'EMP-001',
      EmpName: 'Aditi Sharma',
      Gender: 'F',
      State: 'Maharashtra',
      Zone: 'Zone I',
      Category: 'Skilled',
      Currency: 'INR',
      ExchangeRate: 1.0,
      DisplayCurrency: 'INR',
      TargetAmount: 150000,
      TargetType: 'ctc',
      TargetRate: 'monthly',
      RoundOff: 'yes',
      WorkDays: 30,
      WorkHours: 8,
      PFStrategy: 'capped',
      PFLimit: 15000,
      IncludeGratuity: 'yes',
      ApplyLWF: 'yes',
      StatutoryLogic: 'coss',
      LeaveUplift: 'no',
      AnnualWorkDays: 225,
      LeavesEligible: 30,
      BasicPerc: 50,
      HRAPerc: 20,
      ConvPerc: 3
    },
    {
      EmpCode: 'EMP-002',
      EmpName: 'John Miller',
      Gender: 'M',
      State: 'Karnataka',
      Zone: 'Zone I',
      Category: 'High Skilled Workers',
      Currency: 'USD',
      ExchangeRate: 83.50,
      DisplayCurrency: 'USD',
      TargetAmount: 2500,
      TargetType: 'ctc',
      TargetRate: 'monthly',
      RoundOff: 'no',
      WorkDays: 30,
      WorkHours: 8,
      PFStrategy: 'capped',
      PFLimit: 15000,
      IncludeGratuity: 'yes',
      ApplyLWF: 'yes',
      StatutoryLogic: 'coss',
      LeaveUplift: 'no',
      AnnualWorkDays: 225,
      LeavesEligible: 30,
      BasicPerc: 50,
      HRAPerc: 20,
      ConvPerc: 3
    }
  ];
  const ws = XLSX.utils.json_to_sheet(templateData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Bulk_Upload");
  XLSX.writeFile(wb, "Bulk_CTC_Compliance_Template.xlsx");
}
