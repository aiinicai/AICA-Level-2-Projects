/**
 * Dynamic Multi-Currency Configuration & Conversion Engine
 */

export interface CurrencyConfig {
  code: string;
  name: string;
  symbol: string;
  defaultRateToINR: number; // 1 FCY = X INR
}

export const SUPPORTED_CURRENCIES: CurrencyConfig[] = [
  { code: 'INR', name: 'Indian Rupee (₹)', symbol: '₹', defaultRateToINR: 1.0 },
  { code: 'USD', name: 'US Dollar ($)', symbol: '$', defaultRateToINR: 83.50 },
  { code: 'EUR', name: 'Euro (€)', symbol: '€', defaultRateToINR: 91.20 },
  { code: 'GBP', name: 'British Pound (£)', symbol: '£', defaultRateToINR: 106.80 },
  { code: 'AED', name: 'UAE Dirham (AED)', symbol: 'AED ', defaultRateToINR: 22.74 },
  { code: 'SGD', name: 'Singapore Dollar (S$)', symbol: 'S$', defaultRateToINR: 62.40 },
  { code: 'CAD', name: 'Canadian Dollar (C$)', symbol: 'C$', defaultRateToINR: 61.50 },
  { code: 'AUD', name: 'Australian Dollar (A$)', symbol: 'A$', defaultRateToINR: 55.20 },
  { code: 'JPY', name: 'Japanese Yen (¥)', symbol: '¥', defaultRateToINR: 0.56 },
];

export function getCurrencyConfig(code: string): CurrencyConfig {
  return SUPPORTED_CURRENCIES.find(c => c.code === code) || SUPPORTED_CURRENCIES[0];
}

/**
 * Converts value from Base Input Currency to INR
 */
export function convertToINR(amount: number, inputCurrencyCode: string, exchangeRate: number): number {
  if (inputCurrencyCode === 'INR' || exchangeRate <= 0) {
    return amount;
  }
  return amount * exchangeRate;
}

/**
 * Converts value from INR to Output Currency
 */
export function convertFromINR(inrAmount: number, outputCurrencyCode: string, exchangeRate: number): number {
  if (outputCurrencyCode === 'INR' || exchangeRate <= 0) {
    return inrAmount;
  }
  return inrAmount / exchangeRate;
}

/**
 * Format currency amount for display
 */
export function formatCurrency(
  amount: number,
  currencyCode: string,
  isRound: boolean = false
): string {
  const config = getCurrencyConfig(currencyCode);
  const symbol = config.symbol;
  let val = isRound ? Math.round(amount) : Math.round(amount * 100) / 100;
  if (val === -0) val = 0;
  const isNegative = val < 0;
  const absVal = Math.abs(val);

  const formattedNum = absVal.toLocaleString(currencyCode === 'INR' ? 'en-IN' : 'en-US', {
    minimumFractionDigits: isRound ? 0 : 2,
    maximumFractionDigits: isRound ? 0 : 2
  });

  return `${isNegative ? '-' : ''}${symbol}${formattedNum}`;
}
