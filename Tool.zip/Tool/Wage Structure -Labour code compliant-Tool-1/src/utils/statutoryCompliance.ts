/**
 * Indian Corporate Payroll Statutory Compliance Engine
 */

export interface ComponentLine {
  id: string;
  label: string;
  clause: string;
  classification: 'WAGES' | 'CAP';
  monthly: number;
  esiExcluded: boolean;
  needsFreq?: boolean;
}

export interface CalculationResult {
  lines: { label: string; monthly: number; cls: 'WAGES' | 'CAP' }[];
  basic: number;
  da: number;
  wagesBase: number;
  capBasket: number;
  fullBasket: number;
  gratuityProvision: number;
  totalRemuneration: number;
  threshold: number;
  flagged: boolean;
  excess: number;
  revisedWagesBase: number;
  pfWage: number;
  pfLimitAmt: number;
  employerPF: number;
  employeePF: number;
  esicWageBase: number;
  esiApplicable: boolean;
  employerESIC: number;
  employeeESIC: number;
  pt: number;
  lwfEE_cycle: number;
  lwfER_monthlyCTC: number;
  lwfFreqStr: string;
  grossSalary: number;
  leaveUpliftOn: boolean;
  leaveUpliftMonthly: number;
  gratuityAmt: number;
  ctcMonthly: number;
  netMonthlyStandard: number;
  netMonthlyLWF: number;
  workDays: number;
  workHours: number;
  includeGratuity: boolean;
  applyLwf: boolean;
  statutoryLogic: 'coss' | 'old';
  employerPFprelim: number;
  initialGratuityProvision: number;
  // Currency metadata
  inputCurrency: string;
  displayCurrency: string;
  exchangeRate: number;
  // Minimum wage audit metadata
  minWageAudit?: {
    state: string;
    zone: string;
    category: string;
    minBasic: number;
    minDA: number;
    minTotal: number;
    computedWage: number; // Basic + DA
    compliant: boolean;
    shortfall: number; // in INR
    shortfallDisplay: number; // in display currency
    notificationPeriod: string;
    description: string;
  };
}

export const EMPLOYER_PF_RATE = 0.13;
export const EMPLOYEE_PF_RATE = 0.12;
export const GRATUITY_RATE = 0.0481;

export function getPT(state: string, gross: number, gender: string): number {
  const s = state.toUpperCase();
  const rules: Record<string, (g: number, gen: string) => number> = {
    MH: (g, gen) => (gen === 'F' && g <= 25000 ? 0 : g > 10000 ? 200 : g > 7500 ? 175 : 0),
    KA: (g) => (g > 15000 ? 200 : g > 10000 ? 150 : 0),
    WB: (g) => (g > 25000 ? 200 : g > 15000 ? 130 : g > 10000 ? 110 : g > 8500 ? 90 : 0),
    TN: (g) => (g > 21000 ? 208 : g > 12500 ? 182 : g > 9000 ? 125 : g > 6000 ? 73 : 0),
    TS: (g) => (g > 20000 ? 200 : g > 15000 ? 150 : 0),
    AP: (g) => (g > 20000 ? 200 : g > 15000 ? 150 : 0),
    GJ: (g) => (g > 12000 ? 200 : g > 9000 ? 150 : 0),
    MP: (g) => (g > 15000 ? 208 : g > 12500 ? 130 : 0),
    AS: (g) => (g > 25000 ? 208 : g > 20000 ? 180 : g > 15000 ? 150 : 0),
    OD: (g) => (g > 20000 ? 200 : g > 15000 ? 150 : 0),
    CG: (g) => (g > 25000 ? 200 : g > 16667 ? 150 : 0),
  };
  return rules[s] ? rules[s](gross, gender) : 0;
}

export function getLWF(state: string, gross: number) {
  const s = state.toUpperCase();
  const rules: Record<string, { ee: number; er: number; freq: string }> = {
    AP: { ee: 30, er: 70, freq: 'Annually' },
    CH: { ee: 5, er: 20, freq: 'Monthly' },
    CG: { ee: 15, er: 45, freq: 'Half-Yearly' },
    DL: { ee: 0.75, er: 2.25, freq: 'Half-Yearly' },
    GA: { ee: 60, er: 180, freq: 'Half-Yearly' },
    GJ: { ee: 6, er: 12, freq: 'Half-Yearly' },
    HR: { ee: Math.min(gross * 0.002, 34), er: Math.min(gross * 0.004, 68), freq: 'Monthly' },
    KA: { ee: 50, er: 100, freq: 'Annually' },
    KL: { ee: 50, er: 50, freq: 'Monthly' },
    MP: { ee: 10, er: 30, freq: 'Half-Yearly' },
    MH: { ee: 25, er: 75, freq: 'Half-Yearly' },
    OD: { ee: 20, er: 40, freq: 'Half-Yearly' },
    PB: { ee: 5, er: 20, freq: 'Monthly' },
    TN: { ee: 20, er: 40, freq: 'Annually' },
    TS: { ee: 2, er: 5, freq: 'Annually' },
    WB: { ee: 3, er: 30, freq: 'Half-Yearly' },
  };
  return rules[s] || { ee: 0, er: 0, freq: 'None' };
}
