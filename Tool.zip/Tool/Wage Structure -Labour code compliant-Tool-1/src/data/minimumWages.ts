/**
 * Pan-India Shop & Establishment Minimum Wage Matrix
 * Sourced from official state gazette notifications.
 */

export interface MinWageCategory {
  category: string;
  description: string;
  rates: {
    zone1: { basic: number; da: number; total: number };
    zone2?: { basic: number; da: number; total: number };
    zone3?: { basic: number; da: number; total: number };
    zone4?: { basic: number; da: number; total: number };
  };
}

export interface StateMinWageData {
  state: string;
  region: string;
  zones: string[];
  period: string;
  updationDate: string;
  notification: string;
  categories: MinWageCategory[];
}

export const PAN_INDIA_MINIMUM_WAGES: StateMinWageData[] = [
  {
    state: "Andhra Pradesh",
    region: "South",
    zones: ["Zone I", "Zone II"],
    period: "w.e.f. 01.04.2026 To 30.09.2026",
    updationDate: "4/6/2026",
    notification: "Yes",
    categories: [
      {
        category: "OFFICER",
        description: "MANAGER/ FIELD MANAGER/ DEVELOPMENT OFFICER/ Computer Programmer",
        rates: {
          zone1: { basic: 5557.0, da: 8947.2, total: 14504.2 },
          zone2: { basic: 5357.0, da: 8947.2, total: 14304.2 }
        }
      },
      {
        category: "SUPERVISOR",
        description: "ASST. MANAGER/ ACCOUNTANT/ SALES EXECUTIVE/ SUPERVISOR/ STORE KEEPER",
        rates: {
          zone1: { basic: 4722.0, da: 8947.2, total: 13669.2 },
          zone2: { basic: 4302.0, da: 8947.2, total: 13249.2 }
        }
      },
      {
        category: "SKILLED/ TRADES MAN",
        description: "SALES MAN/ STENOGRAPHER/ RECEPTIONIST/ TRADESMAN/ ELECTRICIAN",
        rates: {
          zone1: { basic: 4520.0, da: 8947.2, total: 13467.2 },
          zone2: { basic: 4302.0, da: 8947.2, total: 13249.2 }
        }
      },
      {
        category: "SEMISKILLED - A",
        description: "CLERK/ TYPIST/ ASST. SALESMAN/ GODOWN INCHARGE/ Xerox Machine Operator",
        rates: {
          zone1: { basic: 4102.0, da: 8947.2, total: 13049.2 },
          zone2: { basic: 3886.0, da: 8947.2, total: 12833.2 }
        }
      },
      {
        category: "SEMISKILLED - B",
        description: "WEIGH MEN/ KOLAGARI/ Computer Operator",
        rates: {
          zone1: { basic: 3886.0, da: 8947.2, total: 12833.2 },
          zone2: { basic: 3757.0, da: 8947.2, total: 12704.2 }
        }
      },
      {
        category: "UNSKILLED",
        description: "PEON/ ATTENDER/ WATCH MAN/ WATER BOY/ HELPER/ MESSENGER",
        rates: {
          zone1: { basic: 3700.0, da: 8947.2, total: 12647.2 },
          zone2: { basic: 3370.0, da: 8947.2, total: 12317.2 }
        }
      }
    ]
  },
  {
    state: "Telangana",
    region: "South",
    zones: ["Zone I", "Zone II", "Zone III"],
    period: "w.e.f. 01.06.2026 (Dated:-30.05.2026)",
    updationDate: "6/19/2026",
    notification: "Yes",
    categories: [
      {
        category: "Highly Skilled",
        description: "Intensive technical competence and independent judgment",
        rates: {
          zone1: { basic: 20000.0, da: 0.0, total: 20000.0 },
          zone2: { basic: 19000.0, da: 0.0, total: 19000.0 },
          zone3: { basic: 18000.0, da: 0.0, total: 18000.0 }
        }
      },
      {
        category: "Skilled",
        description: "Operations requiring skill and experience in job performance",
        rates: {
          zone1: { basic: 18500.0, da: 0.0, total: 18500.0 },
          zone2: { basic: 17500.0, da: 0.0, total: 17500.0 },
          zone3: { basic: 16500.0, da: 0.0, total: 16500.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Application of skill gained on job under supervision",
        rates: {
          zone1: { basic: 17000.0, da: 0.0, total: 17000.0 },
          zone2: { basic: 16000.0, da: 0.0, total: 16000.0 },
          zone3: { basic: 15000.0, da: 0.0, total: 15000.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Physical/manual effort with no prior experience required",
        rates: {
          zone1: { basic: 16000.0, da: 0.0, total: 16000.0 },
          zone2: { basic: 15000.0, da: 0.0, total: 15000.0 },
          zone3: { basic: 14000.0, da: 0.0, total: 14000.0 }
        }
      }
    ]
  },
  {
    state: "Gujarat",
    region: "West",
    zones: ["Zone I", "Zone II"],
    period: "w.e.f. 01.04.2026 To 30.09.2026",
    updationDate: "4/7/2026",
    notification: "Yes",
    categories: [
      {
        category: "Skilled",
        description: "Skilled operations under Gujarat Shop & Est.",
        rates: {
          zone1: { basic: 12324.0, da: 1573.0, total: 13897.0 },
          zone2: { basic: 12012.0, da: 1573.0, total: 13585.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled operations under Gujarat Shop & Est.",
        rates: {
          zone1: { basic: 12012.0, da: 1573.0, total: 13585.0 },
          zone2: { basic: 11752.0, da: 1573.0, total: 13325.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Unskilled operations under Gujarat Shop & Est.",
        rates: {
          zone1: { basic: 11752.0, da: 1573.0, total: 13325.0 },
          zone2: { basic: 11466.0, da: 1573.0, total: 13039.0 }
        }
      }
    ]
  },
  {
    state: "Karnataka",
    region: "South-Western",
    zones: ["Zone I", "Zone II", "Zone III", "Zone IV"],
    period: "w.e.f 01.04.2026 To 31.03.2027",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      {
        category: "High Skilled Workers",
        description: "Manager/Personal Manager",
        rates: {
          zone1: { basic: 15423.4, da: 4549.2, total: 19972.6 },
          zone2: { basic: 14688.95, da: 4549.2, total: 19238.15 },
          zone3: { basic: 13989.48, da: 4549.2, total: 18538.68 },
          zone4: { basic: 13323.31, da: 4549.2, total: 17872.51 }
        }
      },
      {
        category: "Skilled Workers",
        description: "Asst.Manager/Asst.Personal Officer",
        rates: {
          zone1: { basic: 14021.27, da: 4549.2, total: 18570.47 },
          zone2: { basic: 13353.59, da: 4549.2, total: 17902.79 },
          zone3: { basic: 12717.71, da: 4549.2, total: 17266.91 },
          zone4: { basic: 12112.1, da: 4549.2, total: 16661.3 }
        }
      },
      {
        category: "Semi Skilled Workers",
        description: "Accountant",
        rates: {
          zone1: { basic: 12746.61, da: 4549.2, total: 17295.81 },
          zone2: { basic: 12139.63, da: 4549.2, total: 16688.83 },
          zone3: { basic: 11561.55, da: 4549.2, total: 16110.75 },
          zone4: { basic: 11011.0, da: 4549.2, total: 15560.2 }
        }
      },
      {
        category: "Unskilled Workers",
        description: "Cashier/Stenographer/Computer Opt/Storekeeper",
        rates: {
          zone1: { basic: 11587.83, da: 4549.2, total: 16137.03 },
          zone2: { basic: 11036.03, da: 4549.2, total: 15585.23 },
          zone3: { basic: 10510.5, da: 4549.2, total: 15059.7 },
          zone4: { basic: 10010.0, da: 4549.2, total: 14559.2 }
        }
      },
      {
        category: "Office Staff, Manager, Personal Officer, Incharge & equivalent job",
        description: "Typist/Data Entry Opt/Clerk",
        rates: {
          zone1: { basic: 16423.0, da: 4549.2, total: 20972.2 },
          zone2: { basic: 15688.0, da: 4549.2, total: 20237.2 },
          zone3: { basic: 14989.0, da: 4549.2, total: 19538.2 },
          zone4: { basic: 14323.0, da: 4549.2, total: 18872.2 }
        }
      }
    ]
  },
  {
    state: "Kerala",
    region: "South",
    zones: ["Zone I"],
    period: "As per CPI Mundakayam July-2026",
    updationDate: "9/11/2026",
    notification: "Yes",
    categories: [
      { category: "Special Grade-Manager", description: "Managerial Grade", rates: { zone1: { basic: 9330.0, da: 6916.0, total: 16446.0 } } },
      { category: "Grade A", description: "Grade A Staff", rates: { zone1: { basic: 9120.0, da: 6916.0, total: 16236.0 } } },
      { category: "Grade B", description: "Grade B Staff", rates: { zone1: { basic: 8910.0, da: 6916.0, total: 16026.0 } } },
      { category: "Grade C", description: "Grade C Staff", rates: { zone1: { basic: 8700.0, da: 6916.0, total: 15816.0 } } },
      { category: "Grade D", description: "Grade D Staff", rates: { zone1: { basic: 8490.0, da: 6916.0, total: 15606.0 } } },
      { category: "Grade E", description: "Grade E Staff", rates: { zone1: { basic: 8280.0, da: 6916.0, total: 15396.0 } } }
    ]
  },
  {
    state: "Maharashtra",
    region: "West",
    zones: ["Zone I", "Zone II", "Zone III"],
    period: "w.e.f 01.07.2026 To 31.12.2026",
    updationDate: "8/6/2026",
    notification: "Yes",
    categories: [
      {
        category: "Skilled",
        description: "Skilled employees in Shops & Commercial Establishments",
        rates: {
          zone1: { basic: 11632.0, da: 4134.0, total: 15766.0 },
          zone2: { basic: 11036.0, da: 4134.0, total: 15170.0 },
          zone3: { basic: 10440.0, da: 4134.0, total: 14574.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled employees in Shops & Commercial Establishments",
        rates: {
          zone1: { basic: 10856.0, da: 4134.0, total: 14990.0 },
          zone2: { basic: 10260.0, da: 4134.0, total: 14394.0 },
          zone3: { basic: 9664.0, da: 4134.0, total: 13798.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Unskilled employees in Shops & Commercial Establishments",
        rates: {
          zone1: { basic: 10021.0, da: 4134.0, total: 14155.0 },
          zone2: { basic: 9425.0, da: 4134.0, total: 13559.0 },
          zone3: { basic: 8828.0, da: 4134.0, total: 12962.0 }
        }
      }
    ]
  },
  {
    state: "Goa",
    region: "South-Western",
    zones: ["Zone I", "Zone II"],
    period: "w.e.f. 01.04.2026",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      {
        category: "Skilled",
        description: "Skilled Tradesmen",
        rates: {
          zone1: { basic: 13728.0, da: 3874.0, total: 17602.0 },
          zone2: { basic: 13598.0, da: 3874.0, total: 17472.0 }
        }
      },
      {
        category: "Clerical",
        description: "Office & Clerical Staff",
        rates: {
          zone1: { basic: 13728.0, da: 3874.0, total: 17602.0 },
          zone2: { basic: 13598.0, da: 3874.0, total: 17472.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled Personnel",
        rates: {
          zone1: { basic: 12298.0, da: 3874.0, total: 16172.0 },
          zone2: { basic: 12168.0, da: 3874.0, total: 16042.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "General Unskilled Workforce",
        rates: {
          zone1: { basic: 10712.0, da: 3874.0, total: 14586.0 },
          zone2: { basic: 10582.0, da: 3874.0, total: 14456.0 }
        }
      }
    ]
  },
  {
    state: "West Bengal",
    region: "East",
    zones: ["Zone I", "Zone II"],
    period: "w.e.f. 01.07.2026 To 31.12.2026",
    updationDate: "01/07/2026",
    notification: "Yes",
    categories: [
      {
        category: "Highly Skilled",
        description: "Executive and Specialist Staff",
        rates: {
          zone1: { basic: 14054.0, da: 0.0, total: 14054.0 },
          zone2: { basic: 12990.0, da: 0.0, total: 12990.0 }
        }
      },
      {
        category: "Skilled",
        description: "Skilled Commercial Employees",
        rates: {
          zone1: { basic: 12777.0, da: 0.0, total: 12777.0 },
          zone2: { basic: 11807.0, da: 0.0, total: 11807.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled Assistants",
        rates: {
          zone1: { basic: 11615.0, da: 0.0, total: 11615.0 },
          zone2: { basic: 10733.0, da: 0.0, total: 10733.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Peon/Cleaners/General Helpers",
        rates: {
          zone1: { basic: 10558.0, da: 0.0, total: 10558.0 },
          zone2: { basic: 9760.0, da: 0.0, total: 9760.0 }
        }
      }
    ]
  },
  {
    state: "Delhi",
    region: "North",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2025",
    updationDate: "01/04/2025",
    notification: "Yes",
    categories: [
      {
        category: "Graduates and Above",
        description: "Clerical & Supervisory Staff (Graduates and Above)",
        rates: { zone1: { basic: 23836.0, da: 520.0, total: 24356.0 } }
      },
      {
        category: "Matriculates but not Graduates",
        description: "Clerical & Supervisory Staff (Matriculates)",
        rates: { zone1: { basic: 21917.0, da: 494.0, total: 22411.0 } }
      },
      {
        category: "Non Matriculates",
        description: "Clerical & Supervisory Staff (Non-Matriculates)",
        rates: { zone1: { basic: 19929.0, da: 442.0, total: 20371.0 } }
      },
      {
        category: "Skilled",
        description: "All Scheduled Employments (Skilled)",
        rates: { zone1: { basic: 21917.0, da: 494.0, total: 22411.0 } }
      },
      {
        category: "Semi-skilled",
        description: "All Scheduled Employments (Semi-skilled)",
        rates: { zone1: { basic: 19929.0, da: 442.0, total: 20371.0 } }
      },
      {
        category: "Un-skilled",
        description: "All Scheduled Employments (Unskilled)",
        rates: { zone1: { basic: 18066.0, da: 390.0, total: 18456.0 } }
      }
    ]
  },
  {
    state: "Haryana",
    region: "North",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Highly Skilled Personnel", rates: { zone1: { basic: 19425.85, da: 0.0, total: 19425.85 } } },
      { category: "Skilled", description: "Skilled Workers", rates: { zone1: { basic: 18500.81, da: 0.0, total: 18500.81 } } },
      { category: "Semi-skilled", description: "Semi-skilled Workers", rates: { zone1: { basic: 16780.74, da: 0.0, total: 16780.74 } } },
      { category: "Un-skilled", description: "Un-skilled Labours", rates: { zone1: { basic: 15220.71, da: 0.0, total: 15220.71 } } }
    ]
  },
  {
    state: "Uttar Pradesh",
    region: "North",
    zones: ["Zone I", "Zone II", "Zone III"],
    period: "w.e.f. 01.04.2026 To 30.09.2026",
    updationDate: "4/28/2026",
    notification: "Yes",
    categories: [
      {
        category: "Skilled",
        description: "Zone I: Noida/Ghaziabad; Zone II: Nagar Nigam; Zone III: Remaining",
        rates: {
          zone1: { basic: 15876.0, da: 992.0, total: 16868.0 },
          zone2: { basic: 15082.0, da: 943.0, total: 16025.0 },
          zone3: { basic: 14328.0, da: 896.0, total: 15224.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Zone I: Noida/Ghaziabad; Zone II: Nagar Nigam; Zone III: Remaining",
        rates: {
          zone1: { basic: 14173.0, da: 886.0, total: 15059.0 },
          zone2: { basic: 13464.0, da: 842.0, total: 14306.0 },
          zone3: { basic: 12791.0, da: 799.0, total: 13590.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Zone I: Noida/Ghaziabad; Zone II: Nagar Nigam; Zone III: Remaining",
        rates: {
          zone1: { basic: 12885.0, da: 805.0, total: 13690.0 },
          zone2: { basic: 12241.0, da: 765.0, total: 13006.0 },
          zone3: { basic: 11629.0, da: 727.0, total: 12356.0 }
        }
      }
    ]
  },
  {
    state: "Tamil Nadu",
    region: "South",
    zones: ["Zone I", "Zone II", "Zone III", "Zone IV"],
    period: "w.e.f. 01.04.2026",
    updationDate: "3/24/2026",
    notification: "Yes",
    categories: [
      {
        category: "Manager, Sales manager, Office incharge - Skilled",
        description: "Managerial / Incharge",
        rates: {
          zone1: { basic: 7390.0, da: 7353.0, total: 14743.0 },
          zone2: { basic: 7328.0, da: 7353.0, total: 14681.0 },
          zone3: { basic: 7264.0, da: 7353.0, total: 14617.0 },
          zone4: { basic: 7214.0, da: 7353.0, total: 14567.0 }
        }
      },
      {
        category: "Asst. Manager, Accountant, Storekeeper - Skilled",
        description: "Supervisory / Accounting",
        rates: {
          zone1: { basic: 6880.0, da: 7353.0, total: 14233.0 },
          zone2: { basic: 6815.0, da: 7353.0, total: 14168.0 },
          zone3: { basic: 6753.0, da: 7353.0, total: 14106.0 },
          zone4: { basic: 6691.0, da: 7353.0, total: 14044.0 }
        }
      },
      {
        category: "Cashier, Clerk, Typist, Salesman - Semi Skilled",
        description: "Clerical / Sales Front",
        rates: {
          zone1: { basic: 6829.0, da: 7353.0, total: 14182.0 },
          zone2: { basic: 6753.0, da: 7353.0, total: 14106.0 },
          zone3: { basic: 6680.0, da: 7353.0, total: 14033.0 },
          zone4: { basic: 6619.0, da: 7353.0, total: 13972.0 }
        }
      },
      {
        category: "Receptionist, Asst Salesman - Semi Skilled",
        description: "Support Assistants",
        rates: {
          zone1: { basic: 6767.0, da: 7353.0, total: 14120.0 },
          zone2: { basic: 6691.0, da: 7353.0, total: 14044.0 },
          zone3: { basic: 6619.0, da: 7353.0, total: 13972.0 },
          zone4: { basic: 6553.0, da: 7353.0, total: 13906.0 }
        }
      },
      {
        category: "Peon, Helper - Unskilled",
        description: "Peon, Helper & General Unskilled",
        rates: {
          zone1: { basic: 6691.0, da: 7353.0, total: 14044.0 },
          zone2: { basic: 6619.0, da: 7353.0, total: 13972.0 },
          zone3: { basic: 6541.0, da: 7353.0, total: 13894.0 },
          zone4: { basic: 6470.0, da: 7353.0, total: 13823.0 }
        }
      }
    ]
  },
  {
    state: "Madhya Pradesh",
    region: "Central",
    zones: ["Zone I"],
    period: "w.e.f 01.04.2026 To 30.09.2026",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Technical & Expert Roles", rates: { zone1: { basic: 13919.0, da: 2850.0, total: 16769.0 } } },
      { category: "Skilled", description: "Skilled Workforce", rates: { zone1: { basic: 12294.0, da: 2850.0, total: 15144.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Roles", rates: { zone1: { basic: 10571.0, da: 2850.0, total: 13421.0 } } },
      { category: "Un-skilled", description: "Manual & Unskilled", rates: { zone1: { basic: 9575.0, da: 2850.0, total: 12425.0 } } }
    ]
  },
  {
    state: "Rajasthan",
    region: "West",
    zones: ["Zone I"],
    period: "w.e.f. 01.01.2023",
    updationDate: "9/6/2023",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Highly Skilled Crafts", rates: { zone1: { basic: 9334.0, da: 0.0, total: 9334.0 } } },
      { category: "Skilled", description: "Skilled Trades", rates: { zone1: { basic: 8034.0, da: 0.0, total: 8034.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Hands", rates: { zone1: { basic: 7722.0, da: 0.0, total: 7722.0 } } },
      { category: "Un-skilled", description: "Un-skilled Workers", rates: { zone1: { basic: 7410.0, da: 0.0, total: 7410.0 } } }
    ]
  },
  {
    state: "Punjab",
    region: "North",
    zones: ["Zone I"],
    period: "w.e.f. 01.05.2026",
    updationDate: "01/05/2026",
    notification: "Yes",
    categories: [
      { category: "Staff Category-A", description: "Post Graduate/MBA/HR/Company Secretary", rates: { zone1: { basic: 16896.4, da: 2534.6, total: 19431.0 } } },
      { category: "Staff Category-B", description: "Graduate with Diploma/Stenography/Supervisory", rates: { zone1: { basic: 15226.4, da: 2283.6, total: 17510.0 } } },
      { category: "Staff Category-C", description: "Undergraduate/Data Entry/Salesman/Storekeeper", rates: { zone1: { basic: 13726.4, da: 2059.6, total: 15786.0 } } },
      { category: "Staff Category-D", description: "Class-IV Employee/Contractual", rates: { zone1: { basic: 12526.4, da: 1879.6, total: 14406.0 } } },
      { category: "Highly Skilled", description: "Highly Skilled Technical", rates: { zone1: { basic: 14435.4, da: 2165.6, total: 16601.0 } } },
      { category: "Skilled", description: "Skilled Industrial/Commercial", rates: { zone1: { basic: 13403.4, da: 2010.6, total: 15414.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Operations", rates: { zone1: { basic: 12506.4, da: 1876.6, total: 14383.0 } } },
      { category: "Un-skilled", description: "Un-skilled General", rates: { zone1: { basic: 11726.4, da: 1759.6, total: 13486.0 } } }
    ]
  },
  {
    state: "Bihar",
    region: "East",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "4/7/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Specialized & Technical roles", rates: { zone1: { basic: 17160.0, da: 312.0, total: 17472.0 } } },
      { category: "Skilled", description: "Skilled trades", rates: { zone1: { basic: 14066.0, da: 260.0, total: 14326.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled assistants", rates: { zone1: { basic: 11544.0, da: 208.0, total: 11752.0 } } },
      { category: "Un-skilled", description: "Unskilled helpers", rates: { zone1: { basic: 11128.0, da: 208.0, total: 11336.0 } } }
    ]
  },
  {
    state: "Chhattisgarh",
    region: "Central",
    zones: ["Zone I", "Zone II", "Zone III"],
    period: "w.e.f. 01.04.2026 To 30.09.2026",
    updationDate: "5/14/2026",
    notification: "Yes",
    categories: [
      {
        category: "Highly Skilled",
        description: "Senior & Professional Roles",
        rates: {
          zone1: { basic: 10530.0, da: 3082.0, total: 13612.0 },
          zone2: { basic: 10270.0, da: 3082.0, total: 13352.0 },
          zone3: { basic: 10010.0, da: 3082.0, total: 13092.0 }
        }
      },
      {
        category: "Skilled",
        description: "Skilled Technical Roles",
        rates: {
          zone1: { basic: 9750.0, da: 3082.0, total: 12832.0 },
          zone2: { basic: 9490.0, da: 3082.0, total: 12572.0 },
          zone3: { basic: 9230.0, da: 3082.0, total: 12312.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled Operatives",
        rates: {
          zone1: { basic: 8970.0, da: 3082.0, total: 12052.0 },
          zone2: { basic: 8710.0, da: 3082.0, total: 11792.0 },
          zone3: { basic: 8450.0, da: 3082.0, total: 11532.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Un-skilled General Labours",
        rates: {
          zone1: { basic: 8320.0, da: 3082.0, total: 11402.0 },
          zone2: { basic: 8060.0, da: 3082.0, total: 11142.0 },
          zone3: { basic: 7800.0, da: 3082.0, total: 10882.0 }
        }
      }
    ]
  },
  {
    state: "Odisha",
    region: "East",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Technical Specialists", rates: { zone1: { basic: 15912.0, da: 260.0, total: 16172.0 } } },
      { category: "Skilled / Clerical", description: "Skilled and Office Staff", rates: { zone1: { basic: 14612.0, da: 260.0, total: 14872.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Hands", rates: { zone1: { basic: 13312.0, da: 260.0, total: 13572.0 } } },
      { category: "Un-skilled", description: "General Unskilled", rates: { zone1: { basic: 12012.0, da: 260.0, total: 12272.0 } } }
    ]
  },
  {
    state: "Jharkhand",
    region: "East",
    zones: ["Zone I (Area A)", "Zone II (Area B)", "Zone III (Area C)"],
    period: "w.e.f. 01.04.2026",
    updationDate: "6/19/2026",
    notification: "Yes",
    categories: [
      {
        category: "Highly Skilled",
        description: "Area A: Corporations; Area B: Municipalities; Area C: Others",
        rates: {
          zone1: { basic: 19396.0, da: 1950.0, total: 21346.0 },
          zone2: { basic: 18512.0, da: 1846.0, total: 20358.0 },
          zone3: { basic: 17628.0, da: 1768.0, total: 19396.0 }
        }
      },
      {
        category: "Skilled & Clerical",
        description: "Area A: Corporations; Area B: Municipalities; Area C: Others",
        rates: {
          zone1: { basic: 16822.0, da: 1690.0, total: 18512.0 },
          zone2: { basic: 16042.0, da: 1612.0, total: 17654.0 },
          zone3: { basic: 15288.0, da: 1534.0, total: 16822.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Area A: Corporations; Area B: Municipalities; Area C: Others",
        rates: {
          zone1: { basic: 12766.0, da: 1274.0, total: 14040.0 },
          zone2: { basic: 12168.0, da: 1222.0, total: 13390.0 },
          zone3: { basic: 11596.0, da: 1170.0, total: 12766.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Area A: Corporations; Area B: Municipalities; Area C: Others",
        rates: {
          zone1: { basic: 12168.0, da: 1222.0, total: 13390.0 },
          zone2: { basic: 11596.0, da: 1170.0, total: 12766.0 },
          zone3: { basic: 11050.0, da: 1092.0, total: 12142.0 }
        }
      }
    ]
  },
  {
    state: "Assam",
    region: "Northeast",
    zones: ["Zone I"],
    period: "w.e.f. 01.01.2026",
    updationDate: "17/06/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Accountant or equivalent", rates: { zone1: { basic: 18863.25, da: 846.73, total: 19709.98 } } },
      { category: "Skilled", description: "ITI certificate holder / clerical", rates: { zone1: { basic: 14671.95, da: 650.79, total: 15322.74 } } },
      { category: "Semi-skilled", description: "Semi-skilled workforce", rates: { zone1: { basic: 11736.8, da: 520.63, total: 12257.43 } } },
      { category: "Un-skilled", description: "General workmen", rates: { zone1: { basic: 10097.14, da: 446.25, total: 10543.39 } } }
    ]
  },
  {
    state: "Himachal Pradesh",
    region: "North",
    zones: ["Without Benefits", "With Benefits (Food/Accomm)"],
    period: "w.e.f. 01.04.2025",
    updationDate: "7/5/2025",
    notification: "Yes",
    categories: [
      {
        category: "Highly Skilled",
        description: "Specialized roles",
        rates: {
          zone1: { basic: 15390.0, da: 0.0, total: 15390.0 },
          zone2: { basic: 14250.0, da: 0.0, total: 14250.0 }
        }
      },
      {
        category: "Skilled",
        description: "Skilled workmen",
        rates: {
          zone1: { basic: 14790.0, da: 0.0, total: 14790.0 },
          zone2: { basic: 13620.0, da: 0.0, total: 13620.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled hands",
        rates: {
          zone1: { basic: 13470.0, da: 0.0, total: 13470.0 },
          zone2: { basic: 13170.0, da: 0.0, total: 13170.0 }
        }
      },
      {
        category: "Un-skilled",
        description: "Un-skilled helpers",
        rates: {
          zone1: { basic: 12750.0, da: 0.0, total: 12750.0 },
          zone2: { basic: 11820.0, da: 0.0, total: 11820.0 }
        }
      }
    ]
  },
  {
    state: "Uttarakhand",
    region: "North",
    zones: ["Towns > 1 Lakh Pop", "Remaining Parts"],
    period: "w.e.f. 01.04.2026",
    updationDate: "4/28/2026",
    notification: "Yes",
    categories: [
      {
        category: "Clerical Category - I",
        description: "Senior Clerical Staff",
        rates: {
          zone1: { basic: 15275.0, da: 518.0, total: 15793.0 },
          zone2: { basic: 15035.0, da: 518.0, total: 15553.0 }
        }
      },
      {
        category: "Clerical Category - II",
        description: "Junior Clerical Staff",
        rates: {
          zone1: { basic: 14340.0, da: 518.0, total: 14858.0 },
          zone2: { basic: 14139.0, da: 518.0, total: 14657.0 }
        }
      },
      {
        category: "Skilled",
        description: "Skilled Operatives",
        rates: {
          zone1: { basic: 14023.0, da: 518.0, total: 14541.0 },
          zone2: { basic: 13838.0, da: 518.0, total: 14356.0 }
        }
      },
      {
        category: "Semi-skilled",
        description: "Semi-skilled Assistants",
        rates: {
          zone1: { basic: 13280.0, da: 518.0, total: 13798.0 },
          zone2: { basic: 13110.0, da: 518.0, total: 13628.0 }
        }
      },
      {
        category: "Unskilled",
        description: "General Unskilled",
        rates: {
          zone1: { basic: 12539.0, da: 518.0, total: 13057.0 },
          zone2: { basic: 12391.0, da: 518.0, total: 12909.0 }
        }
      }
    ]
  },
  {
    state: "Chandigarh",
    region: "UT (North)",
    zones: ["Zone I"],
    period: "w.e.f. 01.10.2025 To 31.03.2026",
    updationDate: "01/10/2025",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Specialist & Supervisors", rates: { zone1: { basic: 15637.0, da: 0.0, total: 15637.0 } } },
      { category: "Class I (Staff)", description: "Class I Administrative Staff", rates: { zone1: { basic: 15347.0, da: 0.0, total: 15347.0 } } },
      { category: "Skilled-I", description: "Skilled Technical - I", rates: { zone1: { basic: 15237.0, da: 0.0, total: 15237.0 } } },
      { category: "Skilled-II", description: "Skilled Technical - II", rates: { zone1: { basic: 15012.0, da: 0.0, total: 15012.0 } } },
      { category: "Class II (Staff)", description: "Class II Clerical Staff", rates: { zone1: { basic: 14987.0, da: 0.0, total: 14987.0 } } },
      { category: "Class III (Staff)", description: "Class III Junior Staff", rates: { zone1: { basic: 14837.0, da: 0.0, total: 14837.0 } } },
      { category: "Semi-skilled-I", description: "Semi-skilled Grade I", rates: { zone1: { basic: 14812.0, da: 0.0, total: 14812.0 } } },
      { category: "Semi-skilled-II", description: "Semi-skilled Grade II", rates: { zone1: { basic: 14712.0, da: 0.0, total: 14712.0 } } },
      { category: "Un-skilled", description: "General Unskilled Attendants", rates: { zone1: { basic: 14562.0, da: 0.0, total: 14562.0 } } }
    ]
  },
  {
    state: "Jammu & Kashmir",
    region: "Union Territory",
    zones: ["Zone I"],
    period: "w.e.f. 17.10.2022",
    updationDate: "10/14/2022",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Master Craftsmen & Incharges", rates: { zone1: { basic: 14352.0, da: 0.0, total: 14352.0 } } },
      { category: "Skilled", description: "Skilled Workers", rates: { zone1: { basic: 12558.0, da: 0.0, total: 12558.0 } } },
      { category: "Administrative/Ministerial/Accounts Staff", description: "Accounts & Admin", rates: { zone1: { basic: 11674.0, da: 0.0, total: 11674.0 } } },
      { category: "Semi-Skilled (SRO 460)", description: "Semi-skilled roles", rates: { zone1: { basic: 10400.0, da: 0.0, total: 10400.0 } } },
      { category: "Un-skilled", description: "Un-skilled labours", rates: { zone1: { basic: 8086.0, da: 0.0, total: 8086.0 } } }
    ]
  },
  {
    state: "Andaman & Nicobar",
    region: "Union Territory",
    zones: ["South Andaman / Nicobar"],
    period: "w.e.f. 01.07.2026",
    updationDate: "1/9/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Highly Skilled Technical", rates: { zone1: { basic: 24414.0, da: 0.0, total: 24414.0 } } },
      { category: "Skilled/Clerical", description: "Skilled / Clerical", rates: { zone1: { basic: 22256.0, da: 0.0, total: 22256.0 } } },
      { category: "Semi Skilled/Unskilled Supervisory", description: "Supervisory / Semi-skilled", rates: { zone1: { basic: 19058.0, da: 0.0, total: 19058.0 } } },
      { category: "Un-skilled", description: "Un-skilled workforce", rates: { zone1: { basic: 16952.0, da: 0.0, total: 16952.0 } } }
    ]
  },
  {
    state: "Puducherry",
    region: "UT (South)",
    zones: ["Zone I"],
    period: "w.e.f. 20.09.2024",
    updationDate: "10/9/2024",
    notification: "Yes",
    categories: [
      { category: "Category 1", description: "Senior Supervisory / Managerial", rates: { zone1: { basic: 11695.0, da: 0.0, total: 11695.0 } } },
      { category: "Category 2", description: "Technical Skilled", rates: { zone1: { basic: 11283.0, da: 0.0, total: 11283.0 } } },
      { category: "Category 3", description: "Clerical & Commercial", rates: { zone1: { basic: 11242.0, da: 0.0, total: 11242.0 } } },
      { category: "Category 4", description: "Semi-skilled Hands", rates: { zone1: { basic: 11192.0, da: 0.0, total: 11192.0 } } },
      { category: "Category 5", description: "General Unskilled", rates: { zone1: { basic: 11131.0, da: 0.0, total: 11131.0 } } }
    ]
  },
  {
    state: "Dadra & Nagar Haveli and Daman & Diu",
    region: "UT (West)",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "5/14/2026",
    notification: "Yes",
    categories: [
      { category: "Skilled", description: "Skilled Tradesmen", rates: { zone1: { basic: 12012.0, da: 1573.0, total: 13585.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Operatives", rates: { zone1: { basic: 11752.0, da: 1573.0, total: 13325.0 } } },
      { category: "Un-skilled", description: "General Unskilled", rates: { zone1: { basic: 11466.0, da: 1573.0, total: 13039.0 } } }
    ]
  },
  {
    state: "Ladakh",
    region: "UT (North)",
    zones: ["Zone I"],
    period: "w.e.f. 04.11.2022",
    updationDate: "11/16/2022",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Technical Specialists", rates: { zone1: { basic: 21710.0, da: 0.0, total: 21710.0 } } },
      { category: "Skilled", description: "Skilled Workers", rates: { zone1: { basic: 14950.0, da: 0.0, total: 14950.0 } } },
      { category: "Administrative/Ministerial/Accounts Staff", description: "Admin / Accounts", rates: { zone1: { basic: 13910.0, da: 0.0, total: 13910.0 } } },
      { category: "Un-Skilled", description: "Unskilled Helpers", rates: { zone1: { basic: 11700.0, da: 0.0, total: 11700.0 } } }
    ]
  },
  {
    state: "Tripura",
    region: "North-East",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "01/04/2026",
    notification: "Yes",
    categories: [
      { category: "Skilled", description: "Accountant, Welder, Mechanic, Fitter", rates: { zone1: { basic: 8739.0, da: 1170.29, total: 9909.29 } } },
      { category: "Semi-skilled", description: "Weight-Man, Hawker, Porter", rates: { zone1: { basic: 7814.0, da: 1046.35, total: 8860.35 } } },
      { category: "Un-skilled", description: "Peon, Night Guard, Leader", rates: { zone1: { basic: 7123.0, da: 953.8, total: 8076.8 } } }
    ]
  },
  {
    state: "Meghalaya",
    region: "North-East",
    zones: ["Zone I"],
    period: "w.e.f. 01.04.2026",
    updationDate: "6/19/2026",
    notification: "Yes",
    categories: [
      { category: "Highly Skilled", description: "Executive & Specialized", rates: { zone1: { basic: 16770.0, da: 962.0, total: 17732.0 } } },
      { category: "Skilled", description: "Skilled Craftsmen", rates: { zone1: { basic: 15730.0, da: 910.0, total: 16640.0 } } },
      { category: "Semi-skilled", description: "Semi-skilled Operatives", rates: { zone1: { basic: 14690.0, da: 858.0, total: 15548.0 } } },
      { category: "Un-skilled", description: "Un-skilled Labours", rates: { zone1: { basic: 13650.0, da: 780.0, total: 14430.0 } } }
    ]
  }
];

export function getStateMinWage(stateName: string): StateMinWageData | undefined {
  const norm = stateName.toLowerCase().replace(/[^a-z]/g, "");
  return PAN_INDIA_MINIMUM_WAGES.find(s => {
    const sNorm = s.state.toLowerCase().replace(/[^a-z]/g, "");
    return sNorm === norm || sNorm.includes(norm) || norm.includes(sNorm);
  });
}
