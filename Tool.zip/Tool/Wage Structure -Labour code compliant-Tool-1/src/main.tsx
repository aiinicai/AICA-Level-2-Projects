// Single file index.html is self-contained.
