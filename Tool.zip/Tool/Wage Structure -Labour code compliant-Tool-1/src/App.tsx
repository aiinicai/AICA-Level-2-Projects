// Standalone mode - index.html contains the full self-contained tool
export default function App() {
  return null;
}
