import fs from 'fs';

// Helper script to build the complete updated index.html with:
// 1. Bulk processing generating Master Excel + individual Excel Workings + individual PDF Annexures in ZIP
// 2. Reset button resetting everything to NIL (all inputs cleared to 0 / empty)
// 3. PF Strategy dropdown including "Uncapped on Full Gross Salary" and calculating PF on Gross Salary

const mwDataJson = fs.readFileSync('src/data/mw_raw.json', 'utf8');

const htmlPart1 = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Salary Structuring & Labour Code Compliance Calculator with Minimum Wage Matrix</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<style>
  :root{
    --paper:#F5F4EE; --ink:#0F2F22; --ink-soft:#3C5648;
    --emerald:#1F7A52; --emerald-deep:#0B2E22; --mint:#E4EFE6; --mint-line:#C9DCCB;
    --amber:#B9762A; --amber-mint:#F6ECDD;
    --red:#A13B2E; --red-mint:#F5E4DF;
    --card:#FFFFFF; --shadow:0 1px 3px rgba(11,46,34,.06), 0 6px 18px rgba(11,46,34,.05);
  }
  *{box-sizing:border-box;}
  body{margin:0; background:var(--paper); color:var(--ink); font-family:'IBM Plex Sans',sans-serif; padding:0 0 60px;}
  .topbar{background:var(--emerald-deep); color:var(--paper); padding:10px 22px; font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:.1em; text-transform:uppercase; display:flex; justify-content:space-between;}
  .wrap{max-width:1260px; margin:0 auto; padding:26px 18px 0;}
  header{display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:14px; margin-bottom:22px; border-bottom:2px solid var(--emerald-deep); padding-bottom:16px;}
  .eyebrow{font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:.14em; text-transform:uppercase; color:var(--emerald); margin:0 0 6px;}
  h1{font-family:'Fraunces',serif; font-weight:700; font-size:28px; margin:0; color:var(--emerald-deep);}
  .sub{font-size:12.5px; color:var(--ink-soft); margin-top:5px; max-width:680px; line-height:1.55;}
  .stamp-box{display:flex; gap:10px; flex-wrap:wrap;}
  .stamp{font-family:'IBM Plex Mono',monospace; font-weight:600; font-size:12.5px; letter-spacing:.07em; padding:9px 16px; border:2px solid; border-radius:4px; transform:rotate(-2deg); white-space:nowrap;}
  .stamp.pass{color:var(--emerald-deep); border-color:var(--emerald); background:var(--mint);}
  .stamp.flag{color:var(--amber); border-color:var(--amber); background:var(--amber-mint);}
  .stamp.deficit{color:var(--red); border-color:var(--red); background:var(--red-mint);}

  .card{background:var(--card); border:1px solid var(--mint-line); border-radius:12px; padding:22px; margin-bottom:18px; box-shadow:var(--shadow);}
  .card h2{font-family:'Fraunces',serif; font-size:16.5px; margin:0 0 14px; color:var(--emerald-deep); display:flex; align-items:center; gap:9px;}
  .card h2 .n{font-family:'IBM Plex Mono',monospace; font-size:10.5px; background:var(--emerald-deep); color:var(--paper); padding:3px 8px; border-radius:3px;}

  label{display:block; font-size:11.5px; font-weight:600; color:var(--ink-soft); margin:0 0 4px;}
  input[type=text], input[type=number], select, input[type=file]{
    width:100%; padding:8px 9px; border:1px solid var(--mint-line); border-radius:6px;
    font-family:'IBM Plex Mono',monospace; font-size:13px; background:#FCFDFB; color:var(--ink);
  }
  input:focus, select:focus{outline:2px solid var(--emerald); outline-offset:1px; border-color:var(--emerald);}
  input:disabled, select:disabled {background:#E9EBEA; color:#888; cursor:not-allowed;}

  .toprow{display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:10px;}
  @media(max-width:900px){.toprow{grid-template-columns:1fr 1fr;}}
  @media(max-width:580px){.toprow{grid-template-columns:1fr;}}
  .sectionlabel{font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:.08em; text-transform:uppercase; color:var(--emerald); margin:14px 0 8px; border-top:1px dashed var(--mint-line); padding-top:12px;}

  table.alw{width:100%; border-collapse:collapse; font-size:12px;}
  table.alw th{text-align:left; font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:.05em; text-transform:uppercase; color:var(--ink-soft); border-bottom:1px solid var(--mint-line); padding:7px 5px;}
  table.alw td{padding:6px 5px; border-bottom:1px solid #F0F0EC; vertical-align:middle;}
  table.alw tr:hover td{background:#FBFBF8;}
  table.alw input[type=number]{width:110px; padding:5px 6px; font-size:12px;}
  table.alw input[type=checkbox]{width:16px; height:16px; accent-color:var(--emerald-deep);}
  .grp-row td{background:var(--mint); font-weight:700; color:var(--emerald-deep); font-family:'IBM Plex Mono',monospace; font-size:10.5px; text-transform:uppercase; letter-spacing:.05em;}
  .badge{display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:700; padding:2px 7px; border-radius:10px; white-space:nowrap;}
  .badge.WAGES{background:var(--red-mint); color:var(--red);}
  .badge.CAP{background:var(--mint); color:var(--emerald-deep);}
  
  .note{font-size:10.5px; color:var(--ink-soft); font-style:italic;}
  .freqsel{width:105px; font-size:11px; padding:5px;}

  .btnrow{display:flex; gap:10px; margin-top:18px; flex-wrap:wrap; justify-content: flex-end; padding-top: 15px; border-top: 1px dashed var(--mint-line);}
  button{font-family:'IBM Plex Sans',sans-serif; font-weight:600; font-size:13px; padding:10px 18px; border-radius:6px; border:none; cursor:pointer;}
  .btn-primary{background:var(--emerald-deep); color:var(--paper);}
  .btn-ghost{background:var(--card); color:var(--emerald-deep); border:1px solid var(--emerald);}
  .btn-amber{background:var(--emerald); color:var(--paper);}
  .btn-adjust{background:#8B2516; color:#fff; padding:8px 16px; font-size:12.5px; border-radius:6px; cursor:pointer;}
  button:hover{opacity:0.92;}

  table.ec{width:100%; border-collapse:collapse; font-size:12.5px;}
  table.ec th{text-align:right; font-family:'IBM Plex Mono',monospace; font-size:10px; text-transform:uppercase; letter-spacing:.05em; color:var(--ink-soft); border-bottom:2px solid var(--emerald-deep); padding:8px 6px;}
  table.ec th:first-child{text-align:left;}
  table.ec td{padding:7px 6px; border-bottom:1px solid #F0F0EC; font-family:'IBM Plex Mono',monospace; text-align:right;}
  table.ec td:first-child{text-align:left; font-family:'IBM Plex Sans',sans-serif;}
  table.ec tr.subtotal td{font-weight:700; background:var(--mint); color:var(--emerald-deep); border-top:1px solid var(--emerald); border-bottom:1px solid var(--emerald);}
  table.ec tr.grand td{font-weight:700; background:var(--emerald-deep); color:var(--paper); font-size:13.5px;}
  table.ec tr.sectiongap td{border:none; padding:4px 0;}

  .test-box{border-radius:10px; padding:16px; margin-bottom:14px; border:1px solid;}
  .test-box.pass{background:var(--mint); border-color:var(--emerald);}
  .test-box.flag{background:var(--amber-mint); border-color:var(--amber);}
  .test-box.deficit{background:var(--red-mint); border-color:var(--red);}
  .test-box .tt{font-weight:700; font-size:13.5px; margin-bottom:6px;}
  .test-box.pass .tt{color:var(--emerald-deep);}
  .test-box.flag .tt{color:var(--amber);}
  .test-box.deficit .tt{color:var(--red);}
  .test-box p{font-size:12px; margin:3px 0; line-height:1.55; color:var(--ink-soft);}
  .test-box table{width:100%; margin-top:8px; border-collapse:collapse; font-size:11.5px;}
  .test-box table td{padding:3px 4px; font-family:'IBM Plex Mono',monospace;}
  .test-box table td:first-child{font-family:'IBM Plex Sans',sans-serif; color:var(--ink-soft);}
  .test-box table td:last-child{text-align:right;}
  .test-box table tr.linetotal td{border-top:1px solid; font-weight:700;}
  .test-box table tr.highlight-row td{background:rgba(255,255,255,0.5); font-weight:600;}

  .reconcile{display:flex; gap:14px; flex-wrap:wrap; margin-top:10px;}
  .reconcile .chip{background:var(--card); border:1px solid var(--mint-line); border-radius:8px; padding:10px 14px; font-family:'IBM Plex Mono',monospace; font-size:12px;}
  .reconcile .chip b{display:block; font-family:'Fraunces',serif; font-size:15px; color:var(--emerald-deep);}

  .mw-grid{display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin:14px 0;}
  @media(max-width:800px){.mw-grid{grid-template-columns:1fr 1fr;}}
  .mw-stat-box{background:#FCFDFB; border:1px solid var(--mint-line); border-radius:8px; padding:12px 14px;}
  .mw-stat-label{font-family:'IBM Plex Mono',monospace; font-size:10.5px; text-transform:uppercase; color:var(--ink-soft); margin-bottom:4px;}
  .mw-stat-val{font-family:'Fraunces',serif; font-size:19px; font-weight:700; color:var(--emerald-deep);}
  .mw-stat-sub{font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--ink-soft); margin-top:2px;}
</style>
</head>
<body onload="initAll();">
<div class="topbar">
  <span>Robust Salary Structuring & Compliance Tool</span>
  <span>Engine: Dynamic v12.0 (Pan-India Minimum Wage Matrix & Multi-Currency)</span>
</div>
<div class="wrap">

  <header>
    <div>
      <p class="eyebrow">Comprehensive Wage Structuring</p>
      <h1>Gross → CTC → Net-in-Hand Breakup</h1>
      <p class="sub">Validates against CoSS 2020 definitions, 28-state Pan-India Shop &amp; Establishment Minimum Wage matrix, 16-state event-based LWF rules, gender-mapped PT, and real-time multi-currency conversion.</p>
    </div>
    <div class="stamp-box">
      <div id="mwStampBox" class="stamp pass">MIN WAGE: CHECKING</div>
      <div id="cossStampBox" class="stamp pass">CoSS: CHECKING</div>
    </div>
  </header>

  <!-- CARD 00: BULK PROCESSING ENGINE -->
  <div class="card" id="bulkCard">
    <h2><span class="n">00</span> Bulk Processing Engine (Multi-Currency Excel Upload &amp; ZIP Export)</h2>
    <p class="sub" style="margin-top:-6px; margin-bottom:14px;">Download the template, fill employee roster with individual Currency, ExchangeRate, State, Zone, Category, PFStrategy &amp; target CTC/Gross, and upload to generate Master Excel Register, individual Excel files with live formulas, and individual PDF Annexures bundled in a ZIP.</p>
    <div class="toprow" style="align-items:flex-end;">
      <div style="grid-column: span 2;">
        <label>Upload Roster Data (.xlsx)</label>
        <input type="file" id="bulkUpload" accept=".xlsx, .xls" style="padding: 6px; background: #fff;">
      </div>
      <div>
        <button class="btn-primary" style="width:100%; padding:9px 18px;" onclick="processBulk()">Process &amp; Download ZIP</button>
      </div>
      <div>
        <button class="btn-ghost" style="width:100%; padding:9px 18px;" onclick="downloadTemplate()">Download Template</button>
      </div>
    </div>
    <div id="bulkStatus" style="font-size:12.5px; font-weight:600; color:var(--emerald); margin-top:10px;"></div>
  </div>

  <!-- CARD 01: EMPLOYEE, STATUTORY & WORKING PARAMETERS -->
  <div class="card">
    <h2><span class="n">01</span> Employee, Statutory &amp; Working Parameters</h2>

    <!-- Currency Configuration Block -->
    <div style="background:#F8FAF7; border:1px solid var(--mint-line); border-radius:8px; padding:14px; margin-bottom:16px;">
      <div style="font-family:'IBM Plex Mono',monospace; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:var(--emerald-deep); margin-bottom:10px; display:flex; align-items:center; gap:8px;">
        <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--emerald);"></span>
        Currency Configuration &amp; Conversion Engine
      </div>
      <div class="toprow">
        <div>
          <label>Base Input Currency</label>
          <select id="baseCurrency" onchange="onInputCurrencyChange()">
            <option value="INR" selected>INR (₹) — Indian Rupee</option>
            <option value="USD">USD ($) — US Dollar</option>
            <option value="EUR">EUR (€) — Euro</option>
            <option value="GBP">GBP (£) — British Pound</option>
            <option value="AED">AED (AED) — UAE Dirham</option>
            <option value="SGD">SGD (S$) — Singapore Dollar</option>
            <option value="CAD">CAD (C$) — Canadian Dollar</option>
            <option value="AUD">AUD (A$) — Australian Dollar</option>
            <option value="JPY">JPY (¥) — Japanese Yen</option>
          </select>
        </div>
        <div>
          <label id="lblExchangeRate">Exchange Rate (1 FCY = X INR)</label>
          <input type="number" id="exchangeRate" value="1.00" step="0.01" min="0.0001" disabled oninput="calculate()">
        </div>
        <div style="grid-column: span 2;">
          <label>Perform complete end-to-end calculation and display all outputs in:</label>
          <select id="displayCurrency" onchange="calculate()">
            <option value="INR" selected>Option A: INR (₹) [Statutory conversion applied for testing]</option>
            <option value="FCY">Option B: Selected Foreign Currency (FCY) [End-to-end converted]</option>
          </select>
        </div>
      </div>
      <div class="note" style="margin-top:6px;">
        * Note on Indian Statutory Compliance: Statutory testing limits (PF ceiling of ₹15,000, ESI cap of ₹21,000, LWF, PT slabs, and State Minimum Wages) remain strictly pegged to INR, evaluated for legal compliance, and then rendered in your selected display currency.
      </div>
    </div>

    <div class="toprow">
      <div><label>Employee Name</label><input type="text" id="empName" placeholder="e.g. Aditi Sharma" value="Aditi Sharma"></div>
      <div><label>Employee Code</label><input type="text" id="empCode" placeholder="e.g. EMP-1042" value="EMP-1042"></div>
      <div>
        <label>Gender (Drives PT Exemption)</label>
        <select id="gender" onchange="calculate()">
          <option value="M">Male</option>
          <option value="F" selected>Female</option>
          <option value="O">Other</option>
        </select>
      </div>
      <div><label>Working Days / Month</label><input type="number" id="workDays" value="30" min="0" max="31" oninput="calculate()"></div>
    </div>

    <div class="toprow">
      <div><label>Working Hours / Day</label><input type="number" id="workHours" value="8" min="0" max="12" step="0.5" oninput="calculate()"></div>
      <div>
        <label>PF Contribution Strategy</label>
        <select id="pfStrategy" onchange="togglePfLimit()">
          <option value="capped">Capped at Statutory Ceiling (e.g. ₹15,000)</option>
          <option value="full_basic">Uncapped on Basic Pay Only</option>
          <option value="full_wages">Uncapped on Full Wage Base</option>
          <option value="full_gross">Uncapped on Full Gross Salary</option>
        </select>
      </div>
      <div>
        <label>Statutory PF Ceiling Limit (₹)</label>
        <input type="number" id="pfLimitAmt" value="15000" step="1000" min="0" oninput="calculate()">
      </div>
      <div>
        <label>Include Gratuity in Cost to Company?</label>
        <select id="includeGratuity" onchange="calculate()">
          <option value="yes">Yes — add to CTC</option>
          <option value="no">No — costed separately</option>
        </select>
      </div>
    </div>

    <div class="toprow">
      <div>
        <label>State (Drives PT &amp; Event LWF)</label>
        <select id="stateSel" onchange="onStateSelChange()">
          <option value="MH" selected>Maharashtra</option>
          <option value="KA">Karnataka</option>
          <option value="DL">Delhi</option>
          <option value="TS">Telangana</option>
          <option value="AP">Andhra Pradesh</option>
          <option value="GJ">Gujarat</option>
          <option value="TN">Tamil Nadu</option>
          <option value="WB">West Bengal</option>
          <option value="HR">Haryana</option>
          <option value="MP">Madhya Pradesh</option>
          <option value="RJ">Rajasthan</option>
          <option value="PB">Punjab</option>
          <option value="BR">Bihar</option>
          <option value="CG">Chhattisgarh</option>
          <option value="OD">Odisha</option>
          <option value="JH">Jharkhand</option>
          <option value="AS">Assam</option>
          <option value="HP">Himachal Pradesh</option>
          <option value="UK">Uttarakhand</option>
          <option value="CH">Chandigarh</option>
          <option value="JK">Jammu &amp; Kashmir</option>
          <option value="AN">Andaman &amp; Nicobar</option>
          <option value="PY">Puducherry</option>
          <option value="DN">Dadra &amp; Nagar Haveli</option>
          <option value="LA">Ladakh</option>
          <option value="TR">Tripura</option>
          <option value="ML">Meghalaya</option>
          <option value="KL">Kerala</option>
          <option value="GA">Goa</option>
          <option value="OT">Other / Not Applicable</option>
        </select>
      </div>
      <div><label>Professional Tax (₹) — Override</label><input type="number" id="ptOverride" placeholder="Auto-calculated" oninput="calculate()"></div>
      <div>
        <label>Apply State LWF Deduction?</label>
        <select id="applyLwf" onchange="calculate()"><option value="yes">Yes (Checks State Matrix)</option><option value="no">No</option></select>
      </div>
      <div>
        <label>Statutory Wage Definition Base</label>
        <select id="statutoryLogic" onchange="calculate()">
          <option value="coss">CoSS 2020 (50% Inclusion Rule)</option>
          <option value="old">Pre-CoSS / Legacy</option>
        </select>
      </div>
    </div>

    <div class="toprow">
      <div>
        <label>Round Off Figures?</label>
        <select id="roundOff" onchange="calculate()">
          <option value="yes">Yes (No decimals)</option>
          <option value="no" selected>No (Keep decimals)</option>
        </select>
      </div>
    </div>

    <div class="sectionlabel">Leave Upliftment (Optional add-on to CTC)</div>
    <div class="toprow">
      <div><label>Leave Upliftment?</label><select id="leaveUplift" onchange="calculate()"><option value="no">No</option><option value="yes">Yes</option></select></div>
      <div><label>Total Working Days in Year</label><input type="number" id="annualWorkDays" value="225" min="0" max="366" oninput="calculate()"></div>
      <div><label>Total Leaves Eligible (per year)</label><input type="number" id="leavesEligible" value="30" min="0" max="90" oninput="calculate()"></div>
    </div>

    <div class="sectionlabel">Calculation Mode</div>
    <div class="toprow">
      <div>
        <label>Mode</label>
        <select id="calcMode" onchange="toggleMode()"><option value="buildup">Build-up from components</option><option value="reverse">Reverse-calculate from a target</option></select>
      </div>
      <div id="revTargetTypeWrap" style="display:none;"><label>Target Type</label><select id="revTargetType" onchange="calculate()"><option value="ctc">Cost to Company (CTC)</option><option value="gross">Gross Salary</option></select></div>
      <div id="revTargetRateWrap" style="display:none;"><label>Target Rate</label><select id="revTargetRate" onchange="calculate()"><option value="monthly">Monthly</option><option value="daily">Daily</option><option value="hourly">Hourly</option></select></div>
      <div id="revTargetAmtWrap" style="display:none;"><label id="lblRevTargetAmt">Target Amount (₹)</label><input type="number" id="revTargetAmt" value="125000" min="0" oninput="calculate()"></div>
    </div>
    
    <div id="revStrategyWrap" style="display:none; margin-top: 10px;" class="toprow">
      <div>
        <label>Allocation Strategy</label>
        <select id="revStrategy" onchange="toggleStrategy()">
          <option value="default">Default (50% Basic)</option>
          <option value="custom">Custom Percentages</option>
        </select>
      </div>
    </div>
    <div id="customPercWrap" style="display:none; margin-top: 10px;" class="toprow">
      <div><label>Basic % (Min 50%)</label><input type="number" id="custBasicPerc" value="50" min="0" oninput="calculate()"></div>
      <div><label>HRA % (of Target)</label><input type="number" id="custHraPerc" value="20" min="0" oninput="calculate()"></div>
      <div><label>Conveyance % (of Target)</label><input type="number" id="custConvPerc" value="3" min="0" oninput="calculate()"></div>
    </div>
  </div>

  <!-- CARD 02: SALARY COMPONENTS -->
  <div class="card">
    <h2><span class="n">02</span> Salary Components — Monthly (<span id="compCurrSym">₹</span>)</h2>
    <table class="alw" id="alwTable"></table>
  </div>

  <!-- CARD ·: RECONCILIATION ENGINE CHECK -->
  <div id="reconcileCard" class="card" style="display:none;">
    <h2><span class="n">·</span> Reconciliation Engine Check</h2>
    <div class="reconcile">
      <div class="chip">Target (Monthly)<b id="rcTarget">—</b></div>
      <div class="chip">Computed (Monthly)<b id="rcComputed">—</b></div>
      <div class="chip">Difference<b id="rcDiff">—</b></div>
      <div class="chip">Status<b id="rcStatus">—</b></div>
    </div>
  </div>

  <!-- CARD 03: CONTRACT BREAKUP -->
  <div class="card">
    <h2><span class="n">03</span> Contract Breakup — Standard &amp; Event Months (<span id="breakupCurrHeader">INR</span>)</h2>
    <table class="ec" id="ecTable"></table>
    
    <div class="btnrow">
      <button class="btn-ghost" onclick="resetForm()">Reset Fields</button>
      <button class="btn-ghost" onclick="exportPdf()">Export PDF Summary</button>
      <button class="btn-amber" onclick="downloadExcel()">Export Complete Working to Excel</button>
    </div>
  </div>

  <!-- CARD 03.5: PAN-INDIA MINIMUM WAGE COMPLIANCE & AUDIT MATRIX -->
  <div class="card" id="minWageCard">
    <h2><span class="n">03.5</span> Minimum Wage Compliance &amp; Audit Matrix</h2>
    <p class="sub" style="margin-top:-6px; margin-bottom:14px;">
      Embedded Pan-India Shop &amp; Establishment Minimum Wage matrix across 28 states and union territories. Dynamically validates computed basic &amp; DA against applicable statutory thresholds.
    </p>

    <div class="toprow">
      <div>
        <label>State / Union Territory</label>
        <select id="mwStateSel" onchange="onMwStateChange()"></select>
      </div>
      <div>
        <label>Zone / Region Classification</label>
        <select id="mwZoneSel" onchange="onMwZoneChange()"></select>
      </div>
      <div style="grid-column: span 2;">
        <label>Skill Category</label>
        <select id="mwCatSel" onchange="calculate()"></select>
      </div>
    </div>

    <!-- Metadata strip -->
    <div style="background:#FAFBF9; border:1px solid var(--mint-line); border-radius:8px; padding:12px; margin:10px 0; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; font-size:12px;">
      <div>
        <span style="font-weight:700; color:var(--emerald-deep);">Covered Roles: </span>
        <span id="mwDescription" style="color:var(--ink-soft); font-style:italic;">—</span>
      </div>
      <div style="font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--ink-soft);">
        <span id="mwPeriod">Gazette Period</span>
      </div>
    </div>

    <!-- Minimum Wage Rates Grid -->
    <div class="mw-grid">
      <div class="mw-stat-box">
        <div class="mw-stat-label">Statutory Min. Basic</div>
        <div class="mw-stat-val" id="mwDispBasic">—</div>
        <div class="mw-stat-sub" id="mwInrBasic">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Dearness Allowance (DA)</div>
        <div class="mw-stat-val" id="mwDispDA">—</div>
        <div class="mw-stat-sub" id="mwInrDA">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Total Minimum Wage</div>
        <div class="mw-stat-val" id="mwDispTotal">—</div>
        <div class="mw-stat-sub" id="mwInrTotal">Base INR: —</div>
      </div>
      <div class="mw-stat-box">
        <div class="mw-stat-label">Current Computed Wage</div>
        <div class="mw-stat-val" id="mwDispComputed" style="color:#1F7A52;">—</div>
        <div class="mw-stat-sub">Basic + DA</div>
      </div>
    </div>

    <!-- Audit Status & Action Banner -->
    <div id="mwAuditBox" class="test-box pass">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div>
          <div class="tt" id="mwAuditTitle">Running Minimum Wage Audit…</div>
          <p id="mwAuditBody"></p>
        </div>
        <div id="mwActionWrap" style="display:none;">
          <button class="btn-adjust" onclick="autoAdjustBasic()">Auto-Adjust Basic to Min Wage</button>
        </div>
      </div>
      <div id="autoAdjustToast" style="display:none; margin-top:8px; font-size:11.5px; font-weight:700; color:var(--emerald-deep); background:rgba(255,255,255,0.7); padding:6px 10px; border-radius:4px;"></div>
    </div>
  </div>

  <!-- CARD 05: STATUTORY TESTING OUTPUT -->
  <div class="card">
    <h2><span class="n">05</span> Statutory Testing Output</h2>
    <div id="testBox" class="test-box pass">
      <div class="tt" id="testTitle">Running test…</div>
      <p id="testBody"></p>
      <table id="testDetail"></table>
    </div>
    <div id="esiBox" class="test-box pass" style="margin-bottom:0;">
      <div class="tt" id="esiTitle">ESI Coverage</div>
      <p id="esiBody"></p>
    </div>
  </div>
</div>
`;

fs.writeFileSync('src/data/html_part1.txt', htmlPart1);
console.log('Part 1 saved');
