(function () {
  var MSG = "__SOP_RECORDER_CLICK__";

  function shortText(s) {
    s = String(s || "").replace(/\s+/g, " ").trim();
    if (s.length > 80) s = s.slice(0, 77) + "...";
    return s;
  }

  function isInteractive(el) {
    if (!el || el.nodeType !== 1) return false;
    var tag = el.tagName.toLowerCase();
    var type = (el.type || "").toLowerCase();
    var role = (el.getAttribute("role") || "").toLowerCase();
    if (["a", "button", "input", "select", "textarea", "option", "summary", "label"].indexOf(tag) !== -1) {
      return true;
    }
    if (
      ["button", "link", "textbox", "searchbox", "combobox", "listbox", "menuitem", "checkbox", "radio", "switch", "tab", "option"].indexOf(role) !== -1
    ) {
      return true;
    }
    if (el.isContentEditable) return true;
    if (type === "button" || type === "submit" || type === "reset") return true;
    return false;
  }

  function findInteractive(el) {
    var cur = el;
    var i;
    for (i = 0; i < 8 && cur && cur.nodeType === 1; i++) {
      if (isInteractive(cur)) return cur;
      cur = cur.parentElement;
    }
    return el && el.nodeType === 1 ? el : null;
  }

  function classify(el) {
    var tag = el.tagName.toLowerCase();
    var type = (el.type || "").toLowerCase();
    var role = (el.getAttribute("role") || "").toLowerCase();
    if (tag === "select" || tag === "option" || role === "listbox" || role === "combobox" || role === "option") {
      return "dropdown";
    }
    if (tag === "a" || role === "link") return "link";
    if (tag === "button" || role === "button" || type === "button" || type === "submit" || type === "reset" || type === "image") {
      return "button";
    }
    if (
      tag === "input" ||
      tag === "textarea" ||
      el.isContentEditable ||
      role === "textbox" ||
      role === "searchbox" ||
      role === "checkbox" ||
      role === "radio" ||
      role === "switch"
    ) {
      return "field";
    }
    return "element";
  }

  function labelFor(el) {
    var aria = el.getAttribute("aria-label");
    if (aria) return shortText(aria);
    var title = el.getAttribute("title");
    if (title) return shortText(title);
    var alt = el.getAttribute("alt");
    if (alt) return shortText(alt);
    var tag = el.tagName.toLowerCase();
    if ((tag === "input" || tag === "textarea") && el.value) return shortText(el.value);
    var ph = el.getAttribute("placeholder");
    if (ph) return shortText(ph);
    var text = shortText(el.innerText || el.textContent);
    if (text) return text;
    var name = el.getAttribute("name") || el.getAttribute("id") || "";
    if (name) return shortText(name);
    return shortText(tag);
  }

  function describe(target) {
    var el = findInteractive(target) || target;
    if (!el || el.nodeType !== 1) {
      return { kind: "element", label: "page" };
    }
    return { kind: classify(el), label: labelFor(el) || el.tagName.toLowerCase() };
  }

  function report(x, y, kind, label) {
    try {
      var w = window.innerWidth || 1;
      var h = window.innerHeight || 1;
      chrome.runtime.sendMessage(
        {
          type: "SOP_CLICK",
          xPct: (x / w) * 100,
          yPct: (y / h) * 100,
          kind: kind || "element",
          label: label || "",
          url: location.href
        },
        function () {
          void chrome.runtime.lastError;
        }
      );
    } catch (err) {}
  }

  function findFrameOffset(sourceWin) {
    function search(win) {
      var list;
      try {
        list = win.document.querySelectorAll("iframe, frame");
      } catch (err) {
        return null;
      }
      var i;
      for (i = 0; i < list.length; i++) {
        var frame = list[i];
        var cw = null;
        try {
          cw = frame.contentWindow;
        } catch (err2) {
          cw = null;
        }
        var rect;
        try {
          rect = frame.getBoundingClientRect();
        } catch (err3) {
          rect = { left: 0, top: 0 };
        }
        if (cw && cw === sourceWin) {
          return { left: rect.left, top: rect.top };
        }
        if (cw) {
          var nested = search(cw);
          if (nested) {
            return { left: rect.left + nested.left, top: rect.top + nested.top };
          }
        }
      }
      return null;
    }
    try {
      return search(window);
    } catch (err) {
      return null;
    }
  }

  document.addEventListener(
    "mousedown",
    function (e) {
      if (e.button !== 0) return;
      var target = e.target;
      if (target && target.nodeType !== 1) target = target.parentElement;
      var info = describe(target);
      if (window === window.top) {
        report(e.clientX, e.clientY, info.kind, info.label);
        return;
      }
      try {
        window.top.postMessage(
          {
            type: MSG,
            clientX: e.clientX,
            clientY: e.clientY,
            kind: info.kind,
            label: info.label
          },
          "*"
        );
      } catch (err) {}
    },
    true
  );

  if (window === window.top) {
    window.addEventListener("message", function (event) {
      var data = event.data;
      if (!data || data.type !== MSG) return;
      var x = Number(data.clientX);
      var y = Number(data.clientY);
      if (!isFinite(x) || !isFinite(y)) return;
      var offset = null;
      try {
        offset = findFrameOffset(event.source);
      } catch (err) {
        offset = null;
      }
      if (!offset) {
        var frames = document.querySelectorAll("iframe, frame");
        var i;
        for (i = 0; i < frames.length; i++) {
          try {
            if (frames[i].contentWindow === event.source) {
              var r = frames[i].getBoundingClientRect();
              offset = { left: r.left, top: r.top };
              break;
            }
          } catch (err2) {}
        }
      }
      if (offset) {
        x += offset.left;
        y += offset.top;
      }
      report(x, y, data.kind || "element", data.label || "");
    });
  }
})();
