const DEFAULTS = {
  recording: false,
  paused: false,
  title: "",
  preparedBy: "",
  steps: []
};

function getState() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(DEFAULTS, function (value) {
      resolve({
        recording: !!value.recording,
        paused: !!value.paused,
        title: typeof value.title === "string" ? value.title : "",
        preparedBy: typeof value.preparedBy === "string" ? value.preparedBy : "",
        steps: Array.isArray(value.steps) ? value.steps : []
      });
    });
  });
}

function setState(patch) {
  return new Promise(function (resolve) {
    chrome.storage.local.set(patch, function () {
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

function clampPct(n) {
  n = Number(n);
  if (!isFinite(n)) return 0;
  if (n < 0) return 0;
  if (n > 100) return 100;
  return n;
}

function sanitizeStep(raw) {
  raw = raw || {};
  return {
    heading: typeof raw.heading === "string" ? raw.heading : "",
    note: typeof raw.note === "string" ? raw.note : "",
    image: typeof raw.image === "string" && raw.image.indexOf("data:image/") === 0 ? raw.image : null,
    x: clampPct(raw.x),
    y: clampPct(raw.y),
    url: typeof raw.url === "string" ? raw.url : ""
  };
}

function renderSteps(steps) {
  var root = document.getElementById("steps");
  var empty = document.getElementById("empty");
  root.textContent = "";
  empty.style.display = steps.length ? "none" : "block";

  steps.forEach(function (step, index) {
    var article = document.createElement("article");
    article.className = "step";

    var tools = document.createElement("div");
    tools.className = "step-tools no-print";

    var up = document.createElement("button");
    up.type = "button";
    up.textContent = "Move up";
    up.disabled = index === 0;
    up.addEventListener("click", function () {
      moveStep(index, -1);
    });

    var down = document.createElement("button");
    down.type = "button";
    down.textContent = "Move down";
    down.disabled = index === steps.length - 1;
    down.addEventListener("click", function () {
      moveStep(index, 1);
    });

    var del = document.createElement("button");
    del.type = "button";
    del.textContent = "Delete";
    del.addEventListener("click", function () {
      deleteStep(index);
    });

    tools.appendChild(up);
    tools.appendChild(down);
    tools.appendChild(del);

    var heading = document.createElement("input");
    heading.className = "heading";
    heading.type = "text";
    heading.value = step.heading || "";
    heading.addEventListener("input", function () {
      saveStepField(index, "heading", heading.value);
    });

    var note = document.createElement("input");
    note.className = "note";
    note.type = "text";
    note.placeholder = "Instruction";
    note.value = step.note || "";
    note.addEventListener("input", function () {
      saveStepField(index, "note", note.value);
    });

    article.appendChild(tools);
    article.appendChild(heading);
    article.appendChild(note);

    if (step.image) {
      var shot = document.createElement("div");
      shot.className = "shot";
      var img = document.createElement("img");
      img.alt = "Step screenshot";
      img.src = step.image;
      var marker = document.createElement("div");
      marker.className = "marker";
      marker.style.left = clampPct(step.x) + "%";
      marker.style.top = clampPct(step.y) + "%";
      shot.appendChild(img);
      shot.appendChild(marker);
      article.appendChild(shot);
    } else {
      var missing = document.createElement("p");
      missing.className = "missing";
      missing.textContent = "Screenshot unavailable (restricted page or capture failed).";
      article.appendChild(missing);
    }

    if (step.url) {
      var url = document.createElement("p");
      url.className = "url";
      url.textContent = step.url;
      article.appendChild(url);
    }

    root.appendChild(article);
  });
}

function renderMeta(state) {
  var title = document.getElementById("sopTitle");
  var preparedBy = document.getElementById("preparedBy");
  if (document.activeElement !== title) title.value = state.title;
  if (document.activeElement !== preparedBy) preparedBy.value = state.preparedBy;
}

async function saveStepField(index, key, value) {
  var state = await getState();
  var steps = state.steps.slice();
  if (!steps[index]) return;
  steps[index] = sanitizeStep(steps[index]);
  steps[index][key] = value;
  await setState({ steps: steps });
}

async function moveStep(index, delta) {
  var state = await getState();
  var steps = state.steps.slice();
  var next = index + delta;
  if (next < 0 || next >= steps.length) return;
  var tmp = steps[index];
  steps[index] = steps[next];
  steps[next] = tmp;
  await setState({ steps: steps });
  renderSteps(steps);
}

async function deleteStep(index) {
  var state = await getState();
  var steps = state.steps.slice();
  steps.splice(index, 1);
  await setState({ steps: steps });
  renderSteps(steps);
}

function exportJson() {
  getState().then(function (state) {
    var data = {
      title: state.title,
      preparedBy: state.preparedBy,
      steps: state.steps.map(sanitizeStep)
    };
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    var a = document.createElement("a");
    var name = (state.title || "sop").replace(/[\\/:*?"<>|]+/g, "_").trim() || "sop";
    a.href = URL.createObjectURL(blob);
    a.download = name + ".json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () {
      URL.revokeObjectURL(a.href);
    }, 1000);
  });
}

function importJson(file) {
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function () {
    try {
      var data = JSON.parse(String(reader.result || "{}"));
      var steps = Array.isArray(data.steps) ? data.steps.map(sanitizeStep) : [];
      setState({
        title: typeof data.title === "string" ? data.title : "",
        preparedBy: typeof data.preparedBy === "string" ? data.preparedBy : "",
        steps: steps
      }).then(getState).then(function (state) {
        renderMeta(state);
        renderSteps(state.steps);
      });
    } catch (err) {}
  };
  reader.readAsText(file);
}

document.getElementById("sopTitle").addEventListener("input", function (e) {
  setState({ title: e.target.value });
});

document.getElementById("preparedBy").addEventListener("input", function (e) {
  setState({ preparedBy: e.target.value });
});

document.getElementById("btnPdf").addEventListener("click", function () {
  window.print();
});

document.getElementById("btnExport").addEventListener("click", exportJson);

document.getElementById("btnImport").addEventListener("click", function () {
  document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", function (e) {
  var file = e.target.files && e.target.files[0];
  importJson(file);
  e.target.value = "";
});

chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== "local") return;
  getState().then(function (state) {
    renderMeta(state);
    var ae = document.activeElement;
    if (ae && (ae.classList.contains("heading") || ae.classList.contains("note"))) {
      return;
    }
    renderSteps(state.steps);
  });
});

getState().then(function (state) {
  renderMeta(state);
  renderSteps(state.steps);
});
