const DEFAULTS = {
  recording: false,
  paused: false,
  title: "",
  preparedBy: "",
  steps: []
};

let captureChain = Promise.resolve();

function storageGet() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(DEFAULTS, function (value) {
      resolve({
        recording: !!value.recording,
        paused: !!value.paused,
        title: typeof value.title === "string" ? value.title : "",
        preparedBy: typeof value.preparedBy === "string" ? value.preparedBy : "",
        steps: Array.isArray(value.steps) ? value.steps : []
      });
    });
  });
}

function storageSet(patch) {
  return new Promise(function (resolve) {
    chrome.storage.local.set(patch, function () {
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

function delay(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms);
  });
}

function isRestrictedUrl(url) {
  if (!url || typeof url !== "string") return true;
  var u = url.toLowerCase();
  return (
    u.indexOf("chrome://") === 0 ||
    u.indexOf("edge://") === 0 ||
    u.indexOf("about:") === 0 ||
    u.indexOf("chrome-extension://") === 0 ||
    u.indexOf("devtools://") === 0 ||
    u.indexOf("chrome.google.com/webstore") !== -1 ||
    u.indexOf("chromewebstore.google.com") !== -1
  );
}

function syncBadge(state) {
  var n = state && Array.isArray(state.steps) ? state.steps.length : 0;
  chrome.action.setBadgeText({ text: n ? String(n) : "" });
  var color = "#5f6368";
  if (state && state.recording) {
    color = state.paused ? "#c9a227" : "#d93025";
  }
  chrome.action.setBadgeBackgroundColor({ color: color });
}

function captureVisible(windowId) {
  return new Promise(function (resolve, reject) {
    try {
      var options = { format: "jpeg", quality: 70 };
      var callback = function (dataUrl) {
        if (chrome.runtime.lastError || !dataUrl) {
          reject(new Error(chrome.runtime.lastError ? chrome.runtime.lastError.message : "capture failed"));
          return;
        }
        resolve(dataUrl);
      };
      if (typeof windowId === "number") {
        chrome.tabs.captureVisibleTab(windowId, options, callback);
      } else {
        chrome.tabs.captureVisibleTab(options, callback);
      }
    } catch (err) {
      reject(err);
    }
  });
}

function clampPct(n) {
  n = Number(n);
  if (!isFinite(n)) return 0;
  if (n < 0) return 0;
  if (n > 100) return 100;
  return n;
}

function buildHeading(index, kind, label) {
  var k = kind || "element";
  var clean = String(label || "").replace(/"/g, "'").trim();
  if (clean) {
    return "Step " + index + ": click " + k + ' "' + clean + '"';
  }
  return "Step " + index + ": click " + k;
}

async function takeAndStore(payload) {
  var state = await storageGet();
  if (!state.recording || state.paused) return;

  var tabUrl = payload.tabUrl || "";
  var image = null;

  if (!isRestrictedUrl(tabUrl)) {
    try {
      image = await captureVisible(payload.windowId);
    } catch (err1) {
      await delay(700);
      try {
        image = await captureVisible(payload.windowId);
      } catch (err2) {
        image = null;
      }
    }
  }

  var latest = await storageGet();
  var steps = latest.steps.slice();
  var n = steps.length + 1;
  steps.push({
    heading: buildHeading(n, payload.kind, payload.label),
    note: "",
    image: image,
    x: clampPct(payload.xPct),
    y: clampPct(payload.yPct),
    url: payload.url || tabUrl || ""
  });
  await storageSet({ steps: steps });
  syncBadge({
    recording: latest.recording,
    paused: latest.paused,
    steps: steps
  });
}

function enqueueCapture(payload) {
  captureChain = captureChain
    .then(function () {
      return delay(300);
    })
    .then(function () {
      return takeAndStore(payload);
    })
    .catch(function () {});
}

function openDashboard() {
  var url = chrome.runtime.getURL("dashboard.html");
  chrome.tabs.query({ url: url }, function (tabs) {
    if (chrome.runtime.lastError) {
      chrome.tabs.create({ url: url });
      return;
    }
    if (tabs && tabs.length) {
      chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId != null) {
        chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    } else {
      chrome.tabs.create({ url: url });
    }
  });
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.storage.local.get(DEFAULTS, function (value) {
    syncBadge({
      recording: !!value.recording,
      paused: !!value.paused,
      steps: Array.isArray(value.steps) ? value.steps : []
    });
  });
});

chrome.runtime.onStartup.addListener(function () {
  chrome.storage.local.get(DEFAULTS, function (value) {
    syncBadge({
      recording: !!value.recording,
      paused: !!value.paused,
      steps: Array.isArray(value.steps) ? value.steps : []
    });
  });
});

chrome.storage.local.get(DEFAULTS, function (value) {
  syncBadge({
    recording: !!value.recording,
    paused: !!value.paused,
    steps: Array.isArray(value.steps) ? value.steps : []
  });
});

chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== "local") return;
  chrome.storage.local.get(DEFAULTS, function (value) {
    syncBadge({
      recording: !!value.recording,
      paused: !!value.paused,
      steps: Array.isArray(value.steps) ? value.steps : []
    });
  });
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg !== "object") return;

  if (msg.type === "SOP_CLICK") {
    try {
      var tab = sender && sender.tab;
      var tabUrl = (tab && tab.url) || msg.url || "";
      if (isRestrictedUrl(tabUrl)) {
        storageGet().then(function (state) {
          if (!state.recording || state.paused) return;
          var steps = state.steps.slice();
          var n = steps.length + 1;
          steps.push({
            heading: buildHeading(n, msg.kind, msg.label),
            note: "",
            image: null,
            x: clampPct(msg.xPct),
            y: clampPct(msg.yPct),
            url: msg.url || tabUrl || ""
          });
          return storageSet({ steps: steps }).then(function () {
            syncBadge({ recording: state.recording, paused: state.paused, steps: steps });
          });
        }).catch(function () {});
        sendResponse({ ok: true });
        return;
      }
      enqueueCapture({
        xPct: msg.xPct,
        yPct: msg.yPct,
        kind: msg.kind,
        label: msg.label,
        url: msg.url || tabUrl,
        tabUrl: tabUrl,
        windowId: tab && typeof tab.windowId === "number" ? tab.windowId : undefined
      });
    } catch (err) {}
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "SOP_OPEN_DASHBOARD") {
    try {
      openDashboard();
    } catch (err) {}
    sendResponse({ ok: true });
    return;
  }
});
