const DEFAULTS = {
  recording: false,
  paused: false,
  title: "",
  preparedBy: "",
  steps: []
};

function getState() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(DEFAULTS, function (value) {
      resolve({
        recording: !!value.recording,
        paused: !!value.paused,
        title: typeof value.title === "string" ? value.title : "",
        preparedBy: typeof value.preparedBy === "string" ? value.preparedBy : "",
        steps: Array.isArray(value.steps) ? value.steps : []
      });
    });
  });
}

function setState(patch) {
  return new Promise(function (resolve) {
    chrome.storage.local.set(patch, function () {
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

function render(state) {
  var title = document.getElementById("title");
  var preparedBy = document.getElementById("preparedBy");
  var indicator = document.getElementById("indicator");
  var statusText = document.getElementById("statusText");
  var stepCount = document.getElementById("stepCount");
  var btnStart = document.getElementById("btnStart");
  var btnPause = document.getElementById("btnPause");

  if (document.activeElement !== title) title.value = state.title;
  if (document.activeElement !== preparedBy) preparedBy.value = state.preparedBy;

  var n = state.steps.length;
  stepCount.textContent = n + (n === 1 ? " step" : " steps");

  indicator.classList.remove("rec", "pause");
  if (state.recording && state.paused) {
    indicator.classList.add("pause");
    statusText.textContent = "Paused";
  } else if (state.recording) {
    indicator.classList.add("rec");
    statusText.textContent = "Recording";
  } else {
    statusText.textContent = "Idle";
  }

  btnStart.disabled = !!state.recording;
  btnPause.disabled = !state.recording;
}

function openDashboard() {
  chrome.runtime.sendMessage({ type: "SOP_OPEN_DASHBOARD" }, function () {
    void chrome.runtime.lastError;
  });
}

document.getElementById("title").addEventListener("input", function (e) {
  setState({ title: e.target.value });
});

document.getElementById("preparedBy").addEventListener("input", function (e) {
  setState({ preparedBy: e.target.value });
});

document.getElementById("btnStart").addEventListener("click", function () {
  setState({ recording: true, paused: false }).then(getState).then(render);
});

document.getElementById("btnPause").addEventListener("click", function () {
  getState().then(function (state) {
    if (!state.recording) return;
    return setState({ paused: !state.paused });
  }).then(getState).then(render);
});

document.getElementById("btnStop").addEventListener("click", function () {
  setState({ recording: false, paused: false }).then(function () {
    openDashboard();
    window.close();
  });
});

document.getElementById("btnOpen").addEventListener("click", function () {
  openDashboard();
  window.close();
});

document.getElementById("btnClear").addEventListener("click", function () {
  setState({
    recording: false,
    paused: false,
    steps: []
  }).then(getState).then(render);
});

chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== "local") return;
  getState().then(render);
});

getState().then(render);
