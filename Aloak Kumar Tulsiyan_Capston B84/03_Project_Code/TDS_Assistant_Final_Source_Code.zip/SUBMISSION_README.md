# AI TDS Compliance Assistant — Submission Source Code

Participant: CA Alok Kumar Tulsiyan  
Membership No.: 094644  
ICAI AI Level 2 Batch: B 84 — Gurugram

## Purpose
A web-based TDS compliance workbench designed to read invoice PDFs, extract invoice data, maintain a vendor-wise TDS register, apply TDS rules, track cumulative positions, flag duplicate invoices, and export results.

## Main technical approach
- React / TypeScript front end
- Supabase-backed data persistence
- PDF text extraction for digitally generated PDFs
- Deterministic invoice parsing and arithmetic validation before AI fallback
- Vendor/history-aware cumulative TDS logic
- Duplicate invoice retention with zero financial effect
- Search and dropdown filters in the TDS Register

## Security note
The original `.env` file is intentionally excluded from this submission archive. Configure deployment credentials separately using `.env.example`.

## Live demonstration
https://tdsassistant.lovable.app
