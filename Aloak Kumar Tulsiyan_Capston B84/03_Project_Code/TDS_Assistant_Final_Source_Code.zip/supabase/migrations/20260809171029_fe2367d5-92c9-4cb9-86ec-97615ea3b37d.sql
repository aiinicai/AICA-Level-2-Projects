CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  email text,
  full_name text,
  firm_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile" ON public.profiles FOR ALL TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  name_key text NOT NULL,
  pan text,
  gstin text,
  payee_type text NOT NULL DEFAULT 'Other',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, name_key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendors TO authenticated;
GRANT ALL ON public.vendors TO service_role;
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own vendors" ON public.vendors FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  vendor_id uuid REFERENCES public.vendors(id) ON DELETE SET NULL,
  ref_no bigserial,
  doc_type text,
  vendor_name text NOT NULL DEFAULT 'Unknown',
  vendor_pan text,
  vendor_gstin text,
  invoice_number text,
  invoice_number_generated boolean NOT NULL DEFAULT false,
  invoice_date date,
  description text,
  printed_total numeric,
  handwritten_adjustment numeric,
  final_settlement numeric,
  gross_amount numeric,
  taxable_value numeric,
  cgst numeric,
  sgst numeric,
  igst numeric,
  tds_base numeric,
  payee_type text NOT NULL DEFAULT 'Other',
  tds_category text,
  confidence numeric,
  field_confidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  previous_cumulative numeric NOT NULL DEFAULT 0,
  new_cumulative numeric NOT NULL DEFAULT 0,
  tds_rate numeric NOT NULL DEFAULT 0,
  catchup_tds numeric NOT NULL DEFAULT 0,
  tds_now numeric NOT NULL DEFAULT 0,
  tds_status text NOT NULL DEFAULT 'PENDING',
  current_section text,
  legacy_section text,
  review_status text NOT NULL DEFAULT 'REVIEW',
  review_reasons text[] NOT NULL DEFAULT '{}',
  extraction_method text,
  source_file text,
  file_path text,
  file_hash text,
  is_duplicate boolean NOT NULL DEFAULT false,
  duplicate_of uuid,
  duplicate_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invoices_user_idx ON public.invoices(user_id);
CREATE INDEX invoices_vendor_idx ON public.invoices(vendor_id);
CREATE INDEX invoices_hash_idx ON public.invoices(user_id, file_hash);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoices TO authenticated;
GRANT ALL ON public.invoices TO service_role;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own invoices" ON public.invoices FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER invoices_updated_at BEFORE UPDATE ON public.invoices
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.app_settings (
  user_id uuid PRIMARY KEY,
  ai_provider text NOT NULL DEFAULT 'builtin',
  model text NOT NULL DEFAULT 'google/gemini-2.5-pro',
  confidence_threshold numeric NOT NULL DEFAULT 0.75,
  enable_vision boolean NOT NULL DEFAULT true,
  has_api_key boolean NOT NULL DEFAULT false,
  api_key text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own settings" ON public.app_settings FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE POLICY "own docs read" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'invoice-docs' AND owner = auth.uid());
CREATE POLICY "own docs insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'invoice-docs' AND owner = auth.uid());
CREATE POLICY "own docs delete" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'invoice-docs' AND owner = auth.uid());