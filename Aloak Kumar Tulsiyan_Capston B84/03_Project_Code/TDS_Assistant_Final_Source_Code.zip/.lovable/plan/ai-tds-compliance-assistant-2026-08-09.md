# AI TDS Compliance Assistant

A web-based TDS compliance workbench for a CA office: upload invoices, extract data with AI vision + OCR, classify under the correct TDS section, track vendor cumulative totals, compute catch-up TDS, flag anything uncertain for review, and export a full register to Excel.

Runs in the browser (desktop-first layout, no installation, no command line). Data is stored in Lovable Cloud so the register persists and survives machine changes.

## Defaults I picked (questions were skipped)

- **AI**: works out of the box with built-in AI vision (Gemini class models) — no key needed. Settings still allows adding your own Gemini or OpenAI key to override, plus a "Local OCR only" mode. Keys are stored encrypted server-side, never in code, never sent to the browser.
- **Access**: email/password login, one private workspace per accountant. Needed for a defensible audit trail.
- **Build order**: phased. Phase 1 delivers a working end-to-end tool; Phase 2 adds bulk import, summaries and Excel export.

## Phase 1 — working end-to-end tool

**Upload & extraction**
- Drag-and-drop single or multiple files: PDF, JPG, PNG, TIFF, WebP.
- Each file is hashed (SHA-256), stored, then sent for extraction.
- Extraction returns the full field set: document type, vendor name, PAN, GSTIN, invoice no., date, nature of payment, printed total, handwritten adjustment, final settlement amount, gross, taxable value, CGST/SGST/IGST, TDS base, payee type, TDS category, overall + field-wise confidence, and reasoning notes.
- Handwritten statements: printed total → adjustment → final settlement are captured separately; the final settlement figure becomes the TDS base when it is clearly the amount payable.
- An unreadable amount is never turned into zero. Missing or unreliable critical fields produce **BLOCKED – REVIEW** with an explicit list of what to check.
- Statements with no invoice number get a generated reference `AUTO-YYYYMMDD-HASH`, visibly marked as generated.

**TDS rule engine (TY 2026–27)**
- Rules live in one editable rules module so sections, rates, thresholds and tax years can be updated later without touching the rest of the app.
- All ten categories from the brief: professional, technical, contractor/work, commission, rent (land/building), rent (plant/machinery), interest, purchase of goods, partner remuneration, immovable property — each with current Income-tax Act 2025 section, legacy section, threshold and rate.
- Contractor rate switches on payee type (1% individual/HUF, 2% others). Goods and property use above-threshold-only logic. Rent uses per-month thresholds.
- GST shown separately is excluded from the TDS base; percentage figures like 9%/18% are never read as amounts.
- Diagnostic/pathology/imaging services default to professional services.

**Cumulative & catch-up**
- Per vendor per category: previous cumulative → current base → new cumulative.
- On threshold crossing, required TDS is computed on the full qualifying cumulative base; the shortfall on earlier bills becomes catch-up TDS, and TDS Now = current + catch-up.

**Duplicates**
- Flagged by file hash and by vendor + invoice no. + amount. Duplicates stay visible in the register (grey) for audit but are excluded from cumulative totals.

**Register & review**
- Scrollable register with the exact column order from the brief, ending in a Delete action with confirmation.
- Row colouring: amber = review, red = short/nil TDS, green = OK, grey = duplicate.
- Review drawer: edit any extracted field, see the "what to review" checklist and confidence per field, then approve. Approval recalculates TDS and the vendor cumulative chain.
- Dashboard KPI cards: total invoices, needs review, duplicates, gross bills, TDS base, TDS required.

**Design**
- Navy/blue/white CA-office theme, left sidebar navigation, branded header, KPI cards, professional filter bar. Serious and dense, not consumer-styled.

## Phase 2

- Folder upload (recursive) and Excel/CSV invoice import with column mapping.
- Filter bar: vendor, section/category, TDS status, review status, date range. Sortable columns, ascending/descending.
- Vendor Summary and Section Summary views.
- Excel export: Sheet 1 TDS Register, Sheet 2 Vendor Master, Sheet 3 TDS Rule Reference, including all the extra columns listed in the brief.
- Settings screen: provider choice, save/test/remove API key, model, confidence threshold, enable AI vision toggle.

## Technical notes

- Frontend TanStack Start + React, Tailwind, shadcn. Backend on Lovable Cloud (Postgres + storage + server functions).
- Tables: `profiles`, `vendors`, `invoices`, `invoice_fields` (field-wise confidence), `review_flags`, `duplicates`, `settings`, `tds_rules` (seeded from the rules module). Row-level security scopes every row to the owning user; role checks use a separate `user_roles` table.
- Extraction runs in a server function so provider keys never reach the browser. Provider adapters: built-in AI, user Gemini key, user OpenAI key, local-OCR-only.
- Rule evaluation is a pure module with unit-testable inputs, so the worked example (25,800 + 30,000 → 5,580 total, 2,580 catch-up) can be asserted directly.
- Excel export generated client-side with SheetJS.
