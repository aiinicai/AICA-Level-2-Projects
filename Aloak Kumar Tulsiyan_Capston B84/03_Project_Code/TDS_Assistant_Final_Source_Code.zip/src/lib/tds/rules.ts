/**
 * TDS rule catalogue — Tax Year 2026-27.
 *
 * This module is intentionally the ONLY place where sections, rates and
 * thresholds live. Updating a rate, a threshold or a tax year is a change to
 * this file alone; nothing else in the application hard-codes tax logic.
 */

export type PayeeType = "Individual/HUF" | "Company" | "Firm/LLP" | "Other";

export const PAYEE_TYPES: PayeeType[] = [
  "Individual/HUF",
  "Company",
  "Firm/LLP",
  "Other",
];

export type ThresholdMode =
  | "aggregate" // cumulative in the year crosses the limit
  | "single_or_aggregate" // single payment limit OR aggregate limit (194C)
  | "monthly" // limit applies per month or part of a month (194I)
  | "excess" // TDS only on the amount above the limit (194Q)
  | "transaction"; // limit applies to the transaction value (194-IA)

export interface TdsRule {
  key: string;
  label: string;
  currentSection: string;
  legacySection: string;
  thresholdMode: ThresholdMode;
  /** Aggregate / monthly / transaction threshold in rupees. */
  threshold: number;
  /** Single-payment threshold, only for single_or_aggregate rules. */
  singleThreshold?: number;
  thresholdText: string;
  /** Rate in percent for a given payee type. */
  rate: (payeeType: PayeeType) => number;
  rateText: string;
  notes?: string;
  keywords: string[];
}

export const TAX_YEAR = "2026-27";

const flat = (r: number) => () => r;

export const TDS_RULES: TdsRule[] = [
  {
    key: "professional",
    label: "Professional Services",
    currentSection: "Sec 393(1), Table Sl. 6(iii)",
    legacySection: "194J",
    thresholdMode: "aggregate",
    threshold: 50000,
    thresholdText: "Rs 50,000 aggregate",
    rate: flat(10),
    rateText: "10%",
    notes:
      "Diagnostic centre / ultrasound / pathology / X-ray / medical diagnostic services are normally professional services.",
    keywords: [
      "professional",
      "consultancy",
      "consulting",
      "audit",
      "legal",
      "advocate",
      "doctor",
      "medical",
      "diagnostic",
      "pathology",
      "ultrasound",
      "x-ray",
      "xray",
      "radiology",
      "scan",
      "architect",
      "chartered accountant",
      "physician",
      "clinic",
    ],
  },
  {
    key: "technical",
    label: "Technical Services",
    currentSection: "Sec 393(1), Table Sl. 6(iii)",
    legacySection: "194J",
    thresholdMode: "aggregate",
    threshold: 50000,
    thresholdText: "Rs 50,000 aggregate",
    rate: flat(2),
    rateText: "2% (subject to classification)",
    keywords: [
      "technical",
      "amc",
      "maintenance service",
      "installation",
      "engineering",
      "calibration",
      "software support",
      "it support",
    ],
  },
  {
    key: "contractor",
    label: "Contractor / Work",
    currentSection: "Sec 393(1), Table Sl. 6(i)",
    legacySection: "194C",
    thresholdMode: "single_or_aggregate",
    threshold: 100000,
    singleThreshold: 30000,
    thresholdText: "Rs 30,000 single payment OR Rs 1,00,000 aggregate",
    rate: (p) => (p === "Individual/HUF" ? 1 : 2),
    rateText: "1% Individual/HUF, 2% others",
    keywords: [
      "contract",
      "contractor",
      "labour",
      "job work",
      "works",
      "civil work",
      "fabrication",
      "printing",
      "transport",
      "housekeeping",
      "security service",
      "catering",
      "courier",
    ],
  },
  {
    key: "commission",
    label: "Commission / Brokerage",
    currentSection: "Sec 393(1), Table Sl. 1(ii)",
    legacySection: "194H",
    thresholdMode: "aggregate",
    threshold: 20000,
    thresholdText: "Rs 20,000 aggregate",
    rate: flat(2),
    rateText: "2%",
    keywords: ["commission", "brokerage", "broker", "agency commission"],
  },
  {
    key: "rent_building",
    label: "Rent - Land / Building / Furniture",
    currentSection: "Sec 393(1), Table Sl. 2(ii)",
    legacySection: "194I",
    thresholdMode: "monthly",
    threshold: 50000,
    thresholdText: "Rs 50,000 per month or part of a month",
    rate: flat(10),
    rateText: "10%",
    keywords: ["rent", "lease", "office rent", "shop rent", "building", "premises", "furniture"],
  },
  {
    key: "rent_plant",
    label: "Rent / Hire - Plant, Machinery, Equipment",
    currentSection: "Sec 393(1), Table Sl. 2(ii)",
    legacySection: "194I",
    thresholdMode: "monthly",
    threshold: 50000,
    thresholdText: "Rs 50,000 per month or part of a month",
    rate: flat(2),
    rateText: "2%",
    keywords: ["machinery", "equipment hire", "plant", "vehicle hire", "generator", "crane", "hire charges"],
  },
  {
    key: "interest",
    label: "Interest - General",
    currentSection: "Sec 393(1), Table Sl. 5(iii)",
    legacySection: "194A",
    thresholdMode: "aggregate",
    threshold: 10000,
    thresholdText: "Rs 10,000 aggregate (general)",
    rate: flat(10),
    rateText: "10%",
    keywords: ["interest", "loan interest", "delayed payment interest"],
  },
  {
    key: "goods",
    label: "Purchase of Goods",
    currentSection: "Sec 393(1), Table Sl. 8(ii)",
    legacySection: "194Q",
    thresholdMode: "excess",
    threshold: 5000000,
    thresholdText: "Rs 50,00,000 aggregate",
    rate: flat(0.1),
    rateText: "0.1% on value above Rs 50 lakh",
    notes:
      "TDS applies only to the amount exceeding Rs 50 lakh and only where the buyer is eligible (turnover test).",
    keywords: ["purchase", "goods", "material", "supply of goods", "trading"],
  },
  {
    key: "partner",
    label: "Partner Remuneration / Commission / Bonus / Interest",
    currentSection: "Sec 393(3), Table Sl. 7",
    legacySection: "194T",
    thresholdMode: "aggregate",
    threshold: 20000,
    thresholdText: "Rs 20,000 aggregate",
    rate: flat(10),
    rateText: "10%",
    keywords: ["partner", "remuneration", "partner salary", "partner interest", "bonus to partner"],
  },
  {
    key: "immovable_property",
    label: "Purchase of Immovable Property",
    currentSection: "Sec 393(1), Table Sl. 3(i)",
    legacySection: "194-IA",
    thresholdMode: "transaction",
    threshold: 5000000,
    thresholdText: "Rs 50,00,000 transaction value",
    rate: flat(1),
    rateText: "1%",
    keywords: ["immovable property", "land purchase", "flat purchase", "property", "sale deed"],
  },
];

export const RULE_BY_KEY: Record<string, TdsRule> = Object.fromEntries(
  TDS_RULES.map((r) => [r.key, r]),
);

/** Category labels are what we store on the invoice row. */
export const CATEGORY_LABELS = TDS_RULES.map((r) => r.label);

export function ruleForCategory(category?: string | null): TdsRule | null {
  if (!category) return null;
  const direct = TDS_RULES.find(
    (r) => r.label.toLowerCase() === category.toLowerCase() || r.key === category,
  );
  if (direct) return direct;
  const lower = category.toLowerCase();
  return TDS_RULES.find((r) => r.keywords.some((k) => lower.includes(k))) ?? null;
}

/** Best-effort classification from free text, used as a fallback only. */
export function guessCategory(text?: string | null): TdsRule | null {
  if (!text) return null;
  const lower = text.toLowerCase();
  let best: { rule: TdsRule; score: number } | null = null;
  for (const rule of TDS_RULES) {
    for (const kw of rule.keywords) {
      if (lower.includes(kw)) {
        const score = kw.length;
        if (!best || score > best.score) best = { rule, score };
      }
    }
  }
  return best?.rule ?? null;
}
