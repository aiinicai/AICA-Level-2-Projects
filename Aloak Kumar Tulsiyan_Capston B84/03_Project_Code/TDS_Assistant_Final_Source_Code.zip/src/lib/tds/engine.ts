import { ruleForCategory, type PayeeType, type TdsRule } from "./rules";

export interface ChainInput {
  id: string;
  vendorKey: string;
  category: string | null;
  tdsBase: number | null;
  payeeType: PayeeType;
  invoiceDate: string | null;
  invoiceNumber?: string | null;
  isDuplicate: boolean;
  reviewStatus: string;
  createdAt: string;
}

export interface ChainResult {
  previous_cumulative: number;
  new_cumulative: number;
  tds_rate: number;
  catchup_tds: number;
  tds_now: number;
  tds_status: string;
  current_section: string | null;
  legacy_section: string | null;
}

export const TDS_STATUS = {
  REQUIRED: "TDS REQUIRED",
  BELOW: "BELOW THRESHOLD",
  BLOCKED: "NEEDS REVIEW",
  DUPLICATE: "DUPLICATE",
} as const;

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Total TDS legally required on the payments made so far under one rule. */
export function requiredTds(payments: number[], rule: TdsRule, payeeType: PayeeType): number {
  const rate = rule.rate(payeeType) / 100;
  const cum = payments.reduce((a, b) => a + b, 0);
  switch (rule.thresholdMode) {
    case "aggregate":
    case "monthly":
      return cum >= rule.threshold ? r2(cum * rate) : 0;
    case "single_or_aggregate": {
      const qualifying =
        cum >= rule.threshold
          ? cum
          : payments.filter((p) => p >= (rule.singleThreshold ?? Infinity)).reduce((a, b) => a + b, 0);
      return qualifying > 0 ? r2(qualifying * rate) : 0;
    }
    case "excess":
      return cum > rule.threshold ? r2((cum - rule.threshold) * rate) : 0;
    case "transaction": {
      const qualifying = payments.filter((p) => p >= rule.threshold).reduce((a, b) => a + b, 0);
      return qualifying > 0 ? r2(qualifying * rate) : 0;
    }
  }
}

/** Financial/tax year key for an ISO date. 2026-05-02 => 2026-27. */
function taxYearKey(row: ChainInput): string {
  const raw = row.invoiceDate ?? row.createdAt.slice(0, 10);
  const m = /^(\d{4})-(\d{2})/.exec(raw);
  if (!m) return "unknown";
  const year = Number(m[1]);
  const month = Number(m[2]);
  const start = month >= 4 ? year : year - 1;
  return `${start}-${String((start + 1) % 100).padStart(2, "0")}`;
}

/**
 * Register cumulative is always financial-year-to-date for the same vendor +
 * TDS rule. This is deliberately separate from the statutory threshold bucket.
 * Example: rent has a monthly threshold, but the register can still show the
 * vendor's full tax-year cumulative across April, June, etc.
 */
function displayChainKey(row: ChainInput, rule: TdsRule): string {
  return `${row.vendorKey}::${rule.key}::${taxYearKey(row)}`;
}

/** Bucket used only for statutory threshold/TDS calculation. */
function thresholdChainKey(row: ChainInput, rule: TdsRule): string {
  const base = displayChainKey(row, rule);
  if (rule.thresholdMode === "monthly") {
    const month = (row.invoiceDate ?? row.createdAt).slice(0, 7);
    return `${base}::${month}`;
  }
  return base;
}

function invoiceSortValue(value?: string | null): string {
  return String(value ?? "").trim().toUpperCase();
}

function sortRows(rows: ChainInput[]): ChainInput[] {
  return [...rows].sort((a, b) => {
    const da = a.invoiceDate ?? a.createdAt.slice(0, 10);
    const db = b.invoiceDate ?? b.createdAt.slice(0, 10);
    if (da !== db) return da < db ? -1 : 1;

    // On the same date, invoice number gives accountants a stable and intuitive
    // cumulative sequence (_29, _30, _31, _32) regardless of parallel upload order.
    const ia = invoiceSortValue(a.invoiceNumber);
    const ib = invoiceSortValue(b.invoiceNumber);
    if (ia !== ib) return ia.localeCompare(ib, undefined, { numeric: true, sensitivity: "base" });

    if (a.createdAt !== b.createdAt) return a.createdAt < b.createdAt ? -1 : 1;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
}

/**
 * Recomputes register cumulative, statutory TDS and catch-up tax.
 *
 * Important:
 * - previous/new cumulative = full tax-year cumulative for vendor + rule;
 * - statutory threshold can still be monthly where the TDS rule requires it;
 * - duplicates remain visible but contribute ZERO to every cumulative/TDS bucket.
 */
export function computeChains(rows: ChainInput[]): Record<string, ChainResult> {
  const out: Record<string, ChainResult> = {};
  const displayChains = new Map<string, number[]>();
  const thresholdChains = new Map<string, number[]>();

  for (const row of sortRows(rows)) {
    const rule = ruleForCategory(row.category);
    const base = typeof row.tdsBase === "number" && isFinite(row.tdsBase) ? row.tdsBase : null;

    if (!rule || base === null || base <= 0) {
      out[row.id] = blank(TDS_STATUS.BLOCKED, rule);
      continue;
    }

    const displayKey = displayChainKey(row, rule);
    const displayPrior = displayChains.get(displayKey) ?? [];
    const prevCum = displayPrior.reduce((a, b) => a + b, 0);
    const rate = rule.rate(row.payeeType);

    if (row.isDuplicate) {
      // Keep the duplicate in the register, show the amount on the document,
      // but make its cumulative and TDS effect exactly NIL.
      out[row.id] = {
        previous_cumulative: r2(prevCum),
        new_cumulative: r2(prevCum),
        tds_rate: rate,
        catchup_tds: 0,
        tds_now: 0,
        tds_status: TDS_STATUS.DUPLICATE,
        current_section: rule.currentSection,
        legacy_section: rule.legacySection,
      };
      continue;
    }

    displayChains.set(displayKey, [...displayPrior, base]);

    const thresholdKey = thresholdChainKey(row, rule);
    const thresholdPrior = thresholdChains.get(thresholdKey) ?? [];
    const priorRequired = requiredTds(thresholdPrior, rule, row.payeeType);
    const thresholdPayments = [...thresholdPrior, base];
    const totalRequired = requiredTds(thresholdPayments, rule, row.payeeType);
    thresholdChains.set(thresholdKey, thresholdPayments);

    const tdsNow = r2(Math.max(0, totalRequired - priorRequired));
    const currentBill = tdsNow > 0 ? r2(Math.min(tdsNow, (base * rate) / 100)) : 0;
    const catchup = r2(Math.max(0, tdsNow - currentBill));

    out[row.id] = {
      previous_cumulative: r2(prevCum),
      new_cumulative: r2(prevCum + base),
      tds_rate: rate,
      catchup_tds: catchup,
      tds_now: tdsNow,
      tds_status: tdsNow > 0 ? TDS_STATUS.REQUIRED : TDS_STATUS.BELOW,
      current_section: rule.currentSection,
      legacy_section: rule.legacySection,
    };
  }

  return out;
}

function blank(status: string, rule: TdsRule | null): ChainResult {
  return {
    previous_cumulative: 0,
    new_cumulative: 0,
    tds_rate: 0,
    catchup_tds: 0,
    tds_now: 0,
    tds_status: status,
    current_section: rule?.currentSection ?? null,
    legacy_section: rule?.legacySection ?? null,
  };
}
