import { describe, expect, it } from "vitest";
import { computeChains, type ChainInput } from "./engine";

const common = {
  vendorKey: "gstin:27AGKPD1282B2ZT",
  category: "Rent / Hire - Plant, Machinery, Equipment",
  payeeType: "Other" as const,
  reviewStatus: "APPROVED",
};

const row = (
  id: string,
  amount: number,
  date: string,
  invoiceNumber: string,
  createdAt: string,
  isDuplicate = false,
): ChainInput => ({
  id,
  ...common,
  tdsBase: amount,
  invoiceDate: date,
  invoiceNumber,
  createdAt,
  isDuplicate,
});

describe("register chain regression", () => {
  it("keeps FY cumulative across earlier SAM invoices and gives duplicate zero effect", () => {
    const rows: ChainInput[] = [
      row("09", 9000, "2026-05-02", "2026-27_09", "2026-05-02T10:00:00Z"),
      row("10", 9000, "2026-05-02", "2026-27_10", "2026-05-02T10:00:01Z"),
      row("11", 10000, "2026-05-02", "2026-27_11", "2026-05-02T10:00:02Z"),
      row("12", 7000, "2026-05-02", "2026-27_12", "2026-05-02T10:00:03Z"),
      row("13", 10000, "2026-05-02", "2026-27_13", "2026-05-02T10:00:04Z"),
      row("29", 9000, "2026-07-02", "2026-27_29", "2026-07-02T10:00:00Z"),
      row("30a", 9000, "2026-07-02", "2026-27_30", "2026-07-02T10:00:01Z"),
      row("30b", 9000, "2026-07-02", "2026-27_30", "2026-07-02T10:00:02Z", true),
      row("31", 10000, "2026-07-02", "2026-27_31", "2026-07-02T10:00:03Z"),
      row("32", 10000, "2026-07-02", "2026-27_32", "2026-07-02T10:00:04Z"),
    ];

    const result = computeChains(rows);
    expect(result["13"]?.new_cumulative).toBe(45000);
    expect(result["29"]?.previous_cumulative).toBe(45000);
    expect(result["29"]?.new_cumulative).toBe(54000);
    expect(result["30a"]?.new_cumulative).toBe(63000);
    expect(result["30b"]?.previous_cumulative).toBe(63000);
    expect(result["30b"]?.new_cumulative).toBe(63000);
    expect(result["30b"]?.tds_now).toBe(0);
    expect(result["30b"]?.tds_status).toBe("DUPLICATE");
    expect(result["31"]?.new_cumulative).toBe(73000);
    expect(result["32"]?.new_cumulative).toBe(83000);

    // Rent/hire threshold remains monthly; FY cumulative is display/audit trail.
    expect(result["32"]?.tds_status).toBe("BELOW THRESHOLD");
  });
});
