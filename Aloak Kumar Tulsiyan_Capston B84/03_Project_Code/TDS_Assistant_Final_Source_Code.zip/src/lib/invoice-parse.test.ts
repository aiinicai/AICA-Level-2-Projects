import { describe, expect, it } from "vitest";
import { parseInvoiceText } from "./invoice-parse";
import { parseIndianAmount } from "./money";

describe("parseIndianAmount", () => {
  it("reads Indian money and rejects reference lists", () => {
    expect(parseIndianAmount("25,000")).toBe(25000);
    expect(parseIndianAmount("₹ 25,000.00")).toBe(25000);
    expect(parseIndianAmount("29,000/-")).toBe(29000);
    expect(parseIndianAmount("9%" )).toBeNull();
    expect(parseIndianAmount("9,10,11")).toBeNull();
  });
});

describe("invoice parser regression", () => {
  it("Moving Visuals 040726", () => {
    const { fields } = parseInvoiceText([
      "MOVING VISUALS PRODUCTIONS",
      "Phone 9819316042 Email movingvisualsp@gmail.com Date:13/07/26",
      "Original for recipient Invoice no. – 040726",
      "Professional fees charged against:",
      "1. Service provided for IIFL AV. 20,000",
      "Total: Twenty thousand only. 20,000",
      "Pan No: ALTPD9693G",
      "Current Ac No. – 60304415856",
    ].join("\n"));
    expect(fields.vendor_name).toBe("MOVING VISUALS PRODUCTIONS");
    expect(fields.invoice_number).toBe("040726");
    expect(fields.tds_base).toBe(20000);
  });

  it("Moving Visuals 030726 ignores episode numbers", () => {
    const { fields } = parseInvoiceText([
      "MOVING VISUALS PRODUCTIONS",
      "Date:13/07/26 Invoice no. – 030726",
      "Professional fees charged against:",
      "1. Service provided for Kirloskar Micro Drama EP 66,666",
      "9,10,11 & 12.",
      "Total: Sixty six thousand six hundred and sixty six only. 66,666",
      "Pan No: ALTPD9693G",
    ].join("\n"));
    expect(fields.invoice_number).toBe("030726");
    expect(fields.tds_base).toBe(66666);
    expect(fields.review_reasons).toEqual([]);
  });

  it("SAM Editing Studio table layout ignores quantity 1 and derives base from GST math", () => {
    const { fields } = parseInvoiceText([
      "INVOICE",
      "SAM EDITING STUDIO Invoice no Date",
      "VAIBHAV DARSHAN BLDG 2026-27_09 02/05/26",
      "GST NO 27AGKPD1282B2ZT",
      "TO,",
      "Kasbah Films and Media Pvt Ltd",
      "GSTIN NO - 27AAJCK6232C1ZP",
      "SN DISCRIPTION RATE QUANTITY TOTAL",
      "Being towards the Hire charges of Monthly 1",
      "UNIT 1 MAC STUDIO M1 9000 9000",
      "CGST@9% 810",
      "SGST@9% 810",
      "HSN CODE-997315 TOTAL 10620",
      "Currant AC NO-30205168469",
    ].join("\n"));
    expect(fields.vendor_name).toBe("SAM EDITING STUDIO");
    expect(fields.invoice_number).toBe("2026-27_09");
    expect(fields.invoice_date).toBe("2026-05-02");
    expect(fields.vendor_gstin).toBe("27AGKPD1282B2ZT");
    expect(fields.vendor_pan).toBe("AGKPD1282B");
    expect(fields.cgst).toBe(810);
    expect(fields.sgst).toBe(810);
    expect(fields.gross_amount).toBe(10620);
    expect(fields.tds_base).toBe(9000);
    expect(fields.tds_category).toBe("Rent / Hire - Plant, Machinery, Equipment");
    expect(fields.review_reasons).toEqual([]);
  });

  it("SAM Editing Studio 10,000 + GST", () => {
    const { fields } = parseInvoiceText([
      "SAM EDITING STUDIO Invoice no Date",
      "VAIBHAV DARSHAN BLDG 2026-27_31 02/07/26",
      "GST NO 27AGKPD1282B2ZT",
      "Being towards the Hire charges of Monthly 1",
      "UNIT 3 MAC STUDIO M1 10000 10000",
      "CGST@9% 900",
      "SGST@9% 900",
      "HSN CODE-997315 TOTAL 11800",
    ].join("\n"));
    expect(fields.vendor_name).toBe("SAM EDITING STUDIO");
    expect(fields.invoice_number).toBe("2026-27_31");
    expect(fields.tds_base).toBe(10000);
    expect(fields.gross_amount).toBe(11800);
  });
});
