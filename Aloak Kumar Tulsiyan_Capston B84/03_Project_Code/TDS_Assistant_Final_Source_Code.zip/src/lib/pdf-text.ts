/**
 * Browser-side PDF text extraction.
 * Used before any AI call so digital invoices never consume vision tokens.
 */

let pdfjsPromise: Promise<typeof import("pdfjs-dist")> | null = null;

async function loadPdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = (async () => {
      const pdfjs = await import("pdfjs-dist");
      const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
      pdfjs.GlobalWorkerOptions.workerSrc = (worker as { default: string }).default;
      return pdfjs;
    })();
  }
  return pdfjsPromise;
}

export interface PdfTextResult {
  text: string;
  pages: number;
  usable: boolean;
}

/** Returns selectable text from a PDF. `usable` is false for scanned documents. */
export async function extractPdfText(file: File, maxPages = 5): Promise<PdfTextResult> {
  try {
    const pdfjs = await loadPdfjs();
    const buffer = await file.arrayBuffer();
    const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
    const limit = Math.min(doc.numPages, maxPages);
    const chunks: string[] = [];
    for (let i = 1; i <= limit; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      // Reconstruct visual lines from X/Y coordinates so invoice tables keep
      // their label ↔ amount relationship instead of collapsing to fragments.
      const rows: { y: number; items: { x: number; str: string }[] }[] = [];
      for (const item of content.items) {
        const it = item as { str?: string; transform?: number[] };
        if (typeof it.str !== "string" || !it.str.trim()) continue;
        const x = it.transform?.[4] ?? 0;
        const y = it.transform?.[5] ?? 0;
        const row = rows.find((r) => Math.abs(r.y - y) <= 2.5);
        if (row) row.items.push({ x, str: it.str });
        else rows.push({ y, items: [{ x, str: it.str }] });
      }
      rows.sort((a, b) => b.y - a.y);
      for (const row of rows) {
        row.items.sort((a, b) => a.x - b.x);
        const line = row.items
          .map((it) => it.str)
          .join(" ")
          .replace(/\s+/g, " ")
          .trim();
        if (line) chunks.push(line);
      }
    }

    await doc.cleanup();
    const text = chunks.filter(Boolean).join("\n");
    const letters = text.replace(/[^a-zA-Z]/g, "").length;
    return { text, pages: doc.numPages, usable: letters >= 80 };
  } catch {
    return { text: "", pages: 0, usable: false };
  }
}
