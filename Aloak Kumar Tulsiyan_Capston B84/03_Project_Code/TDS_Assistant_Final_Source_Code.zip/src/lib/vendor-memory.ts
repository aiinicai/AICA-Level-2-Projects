/**
 * Vendor master memory.
 *
 * Once a vendor has been recorded (preferably by PAN or GSTIN), later invoices
 * reuse the saved name, payee type and TDS category instead of re-classifying.
 */
import { supabase } from "@/integrations/supabase/client";

export interface VendorMemory {
  vendor_name: string | null;
  payee_type: string | null;
  tds_category: string | null;
}

const cache = new Map<string, VendorMemory | null>();

/** Looks up the most recent confirmed invoice for the same PAN / GSTIN / name. */
export async function recallVendor(
  userId: string,
  pan: string | null,
  gstin: string | null,
  name: string | null,
): Promise<VendorMemory | null> {
  const key = `${userId}|${pan ?? ""}|${gstin ?? ""}|${(name ?? "").toLowerCase().trim()}`;
  if (cache.has(key)) return cache.get(key) ?? null;

  const attempts: { column: string; value: string }[] = [];
  if (pan) attempts.push({ column: "vendor_pan", value: pan });
  if (gstin) attempts.push({ column: "vendor_gstin", value: gstin });
  if (name?.trim()) attempts.push({ column: "vendor_name", value: name.trim() });

  let found: VendorMemory | null = null;
  for (const attempt of attempts) {
    const { data } = await supabase
      .from("invoices")
      .select("vendor_name, payee_type, tds_category")
      .eq("user_id", userId)
      .eq(attempt.column, attempt.value)
      .not("tds_category", "is", null)
      .order("created_at", { ascending: false })
      .limit(1);
    const row = data?.[0] as VendorMemory | undefined;
    if (row) {
      found = {
        vendor_name: row.vendor_name ?? null,
        payee_type: row.payee_type ?? null,
        tds_category: row.tds_category ?? null,
      };
      break;
    }
  }

  cache.set(key, found);
  return found;
}

export function clearVendorMemoryCache(): void {
  cache.clear();
}
