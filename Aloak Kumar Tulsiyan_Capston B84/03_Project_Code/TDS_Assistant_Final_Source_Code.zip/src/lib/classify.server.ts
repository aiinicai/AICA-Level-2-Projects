/**
 * Text-only TDS classification.
 * Server-only. Sends a short summary — never the whole document — so a digital
 * invoice costs a fraction of a vision call.
 */
import { TDS_RULES } from "./tds/rules";

const CATEGORIES = TDS_RULES.map((r) => r.label);

export interface ClassificationResult {
  tds_category: string | null;
  payee_type: string | null;
  description: string | null;
  tds_applicable: boolean;
  confidence: number | null;
  notes: string | null;
}

const PROMPT = `You are an Indian Chartered Accountant's TDS classifier. You are given only a short summary of an already-parsed invoice. Do NOT re-estimate any amount.
Return ONE JSON object, no prose, no markdown:
{
  "tds_category": one of ${JSON.stringify(CATEGORIES)} or null,
  "payee_type": "Individual/HUF" | "Company" | "Firm/LLP" | "Other",
  "description": short nature of payment (max 12 words),
  "tds_applicable": boolean,
  "confidence": number 0-1,
  "notes": one short sentence of reasoning
}
Diagnostic centre, pathology, ultrasound, X-ray and radiology are normally "Professional Services".`;

export class AiUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AiUnavailableError";
  }
}

export const AI_UNAVAILABLE_MESSAGE =
  "AI invoice analysis is temporarily unavailable. The invoice has been uploaded successfully and can be analysed once AI service is available.";

function endpointFor(provider: string): string {
  if (provider === "gemini")
    return "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
  if (provider === "openai") return "https://api.openai.com/v1/chat/completions";
  return "https://ai.gateway.lovable.dev/v1/chat/completions";
}

/** A small, cheap model is enough for text-only classification. */
function modelFor(provider: string, configured: string): string {
  if (provider === "builtin") return "google/gemini-2.5-flash-lite";
  return configured;
}

export async function classifyText(
  cfg: { provider: string; model: string; apiKey?: string | null },
  summary: string,
): Promise<ClassificationResult> {
  let key = cfg.apiKey ?? null;
  if (cfg.provider === "builtin") {
    key = process.env["LOVABLE_API_KEY"] ?? null;
    if (!key) throw new AiUnavailableError(AI_UNAVAILABLE_MESSAGE);
  }
  if (!key) throw new AiUnavailableError(AI_UNAVAILABLE_MESSAGE);

  const response = await fetch(endpointFor(cfg.provider), {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: modelFor(cfg.provider, cfg.model),
      messages: [
        { role: "system", content: PROMPT },
        { role: "user", content: summary },
      ],
      temperature: 0,
    }),
  });

  if (response.status === 402 || response.status === 429) {
    throw new AiUnavailableError(AI_UNAVAILABLE_MESSAGE);
  }
  if (!response.ok) {
    console.error("[classify] provider error", response.status, (await response.text()).slice(0, 300));
    throw new AiUnavailableError(AI_UNAVAILABLE_MESSAGE);
  }

  const payload = (await response.json()) as { choices?: { message?: { content?: string } }[] };
  const content = payload.choices?.[0]?.message?.content ?? "";
  const cleaned = content.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  let raw: Record<string, unknown>;
  try {
    raw = JSON.parse(cleaned) as Record<string, unknown>;
  } catch {
    const a = cleaned.indexOf("{");
    const b = cleaned.lastIndexOf("}");
    if (a < 0 || b <= a) throw new AiUnavailableError(AI_UNAVAILABLE_MESSAGE);
    raw = JSON.parse(cleaned.slice(a, b + 1)) as Record<string, unknown>;
  }

  const str = (v: unknown) => {
    const s = v === null || v === undefined ? "" : String(v).trim();
    return s === "" || s.toLowerCase() === "null" ? null : s;
  };
  const cat = str(raw["tds_category"]);
  return {
    tds_category: cat && CATEGORIES.includes(cat) ? cat : cat,
    payee_type: str(raw["payee_type"]),
    description: str(raw["description"]),
    tds_applicable: raw["tds_applicable"] !== false,
    confidence: raw["confidence"] === undefined ? null : Number(raw["confidence"]),
    notes: str(raw["notes"]),
  };
}
