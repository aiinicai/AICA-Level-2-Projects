export const inr = (value: number | null | undefined, dash = "—"): string => {
  if (value === null || value === undefined || !isFinite(Number(value))) return dash;
  return Number(value).toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

export const shortDate = (value: string | null | undefined): string => {
  if (!value) return "—";
  const d = new Date(value);
  if (isNaN(d.getTime())) return value;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
};

export const pct = (value: number | null | undefined): string =>
  value === null || value === undefined ? "—" : `${Number(value)}%`;

export const confidencePct = (value: number | null | undefined): string =>
  value === null || value === undefined ? "—" : `${Math.round(Number(value) * 100)}%`;
