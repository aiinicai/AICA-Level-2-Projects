/**
 * Fast, deterministic document pipeline.
 *
 * Priority order (AI is LAST, never part of the normal path):
 *  1. Reuse an analysis already saved for the identical file.
 *  2. PDF text layer + rule-based parsing + vendor memory + TDS Rules keywords.
 *  3. AI vision fallback ONLY for scanned/image documents with no usable text.
 */
import { extractDocument } from "./extraction.functions";
import { parseInvoiceText } from "./invoice-parse";
import { extractPdfText } from "./pdf-text";
import { recallVendor } from "./vendor-memory";
import { fileToDataUrl } from "./invoices";
import { supabase } from "@/integrations/supabase/client";
import type { ExtractedFields } from "./extraction.server";

export const AI_UNAVAILABLE_MESSAGE =
  "AI invoice analysis is temporarily unavailable. The invoice has been uploaded successfully and can be analysed once AI service is available.";

/**
 * Bump this whenever deterministic extraction rules materially change.
 * Old saved rows are then reparsed on the next upload instead of silently
 * reusing a bad historical extraction.
 */
export const PARSER_VERSION = "deterministic-v5";

export interface ProcessedDocument {
  fields: ExtractedFields;
  extraction_method: string;
  confidence_threshold: number;
  warning?: string;
  aiUsed: boolean;
}

const isPdf = (file: File) =>
  file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");

const mimeOf = (file: File) => file.type || (isPdf(file) ? "application/pdf" : "image/jpeg");

/** Looks for a previously analysed copy of the same file so nothing is re-parsed. */
async function reuseSavedAnalysis(
  userId: string,
  fileHash: string,
): Promise<ExtractedFields | null> {
  const { data } = await supabase
    .from("invoices")
    .select(
      "doc_type, vendor_name, vendor_pan, vendor_gstin, invoice_number, invoice_number_generated, invoice_date, description, printed_total, handwritten_adjustment, final_settlement, gross_amount, taxable_value, cgst, sgst, igst, tds_base, payee_type, tds_category, confidence, field_confidence, notes, extraction_method",
    )
    .eq("user_id", userId)
    .eq("file_hash", fileHash)
    .limit(1);
  const row = data?.[0] as Record<string, unknown> | undefined;
  if (!row) return null;
  const extractionMethod = String(row["extraction_method"] ?? "");
  // Do not reuse rows produced before the current deterministic parser. This
  // is what lets a corrected parser repair a previously misread invoice on
  // the very next upload.
  if (!extractionMethod.includes(PARSER_VERSION)) return null;
  const n = (v: unknown) => (v === null || v === undefined ? null : Number(v));
  const s = (v: unknown) => (v === null || v === undefined ? null : String(v));
  return {
    document_type: s(row["doc_type"]),
    vendor_name: s(row["vendor_name"]),
    vendor_pan: s(row["vendor_pan"]),
    vendor_gstin: s(row["vendor_gstin"]),
    invoice_number: row["invoice_number_generated"] ? null : s(row["invoice_number"]),
    invoice_date: s(row["invoice_date"]),
    description: s(row["description"]),
    printed_total: n(row["printed_total"]),
    handwritten_adjustment: n(row["handwritten_adjustment"]),
    final_settlement_amount: n(row["final_settlement"]),
    gross_amount: n(row["gross_amount"]),
    taxable_value: n(row["taxable_value"]),
    cgst: n(row["cgst"]),
    sgst: n(row["sgst"]),
    igst: n(row["igst"]),
    tds_base: n(row["tds_base"]),
    payee_type: s(row["payee_type"]),
    tds_category: s(row["tds_category"]),
    confidence: n(row["confidence"]),
    field_confidence: (row["field_confidence"] as Record<string, number>) ?? {},
    notes: s(row["notes"]),
    unreadable: false,
    review_reasons: [],
  };
}

/** Fills vendor name, payee type and category from the vendor master. */
async function applyVendorMemory(userId: string, fields: ExtractedFields): Promise<boolean> {
  const memory = await recallVendor(
    userId,
    fields.vendor_pan,
    fields.vendor_gstin,
    fields.vendor_name,
  );
  if (!memory) return false;
  if (!fields.vendor_name && memory.vendor_name) fields.vendor_name = memory.vendor_name;
  if (!fields.payee_type && memory.payee_type) fields.payee_type = memory.payee_type;
  if (!fields.tds_category && memory.tds_category) fields.tds_category = memory.tds_category;
  return true;
}

export async function processDocument(
  userId: string,
  file: File,
  fileHash: string,
): Promise<ProcessedDocument> {
  // 1. Identical file already processed — reuse, zero work.
  const saved = await reuseSavedAnalysis(userId, fileHash);
  if (saved) {
    return {
      fields: saved,
      extraction_method: `Reused saved extraction (${PARSER_VERSION}, no AI)`,
      confidence_threshold: 0,
      aiUsed: false,
    };
  }

  // 2. Text-based PDF — deterministic parse, no AI at all.
  if (isPdf(file)) {
    const { text, usable } = await extractPdfText(file);
    if (usable) {
      const parsed = parseInvoiceText(text);
      const fields = { ...parsed.fields };
      const recalled = await applyVendorMemory(userId, fields);

      return {
        fields,
        extraction_method: recalled
          ? `PDF text + rules + vendor history (${PARSER_VERSION})`
          : `PDF text + rule-based parsing (${PARSER_VERSION})`,
        confidence_threshold: 0,
        aiUsed: false,
      };
    }
  }

  // 3. Scanned document or image — vision fallback (the only heavy path).
  const dataUrl = await fileToDataUrl(file);
  const result = await extractDocument({
    data: { fileName: file.name, mimeType: mimeOf(file), dataUrl },
  });
  return { ...result, aiUsed: true };
}
