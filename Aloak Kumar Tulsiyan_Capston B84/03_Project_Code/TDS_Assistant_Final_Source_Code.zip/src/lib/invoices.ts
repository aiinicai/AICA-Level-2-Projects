import { supabase } from "@/integrations/supabase/client";
import { guessCategory, ruleForCategory, type PayeeType, type TdsRule } from "./tds/rules";
import type { ExtractedFields } from "./extraction.server";

export interface InvoiceRow {
  id: string;
  user_id: string;
  vendor_id: string | null;
  ref_no: number;
  doc_type: string | null;
  vendor_name: string;
  vendor_pan: string | null;
  vendor_gstin: string | null;
  invoice_number: string | null;
  invoice_number_generated: boolean;
  invoice_date: string | null;
  description: string | null;
  printed_total: number | null;
  handwritten_adjustment: number | null;
  final_settlement: number | null;
  gross_amount: number | null;
  taxable_value: number | null;
  cgst: number | null;
  sgst: number | null;
  igst: number | null;
  tds_base: number | null;
  payee_type: string;
  tds_category: string | null;
  confidence: number | null;
  field_confidence: Record<string, number>;
  notes: string | null;
  previous_cumulative: number;
  new_cumulative: number;
  tds_rate: number;
  catchup_tds: number;
  tds_now: number;
  tds_status: string;
  current_section: string | null;
  legacy_section: string | null;
  review_status: string;
  review_reasons: string[];
  extraction_method: string | null;
  source_file: string | null;
  file_path: string | null;
  file_hash: string | null;
  is_duplicate: boolean;
  duplicate_of: string | null;
  duplicate_reason: string | null;
  created_at: string;
  updated_at: string;
}

export const vendorKey = (name: string) =>
  name.trim().toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

/** Stable vendor identity for cumulative chains. PAN/GSTIN beats spelling. */
export const vendorIdentityKey = (row: {
  vendor_name: string;
  vendor_pan?: string | null;
  vendor_gstin?: string | null;
}) => {
  // For register/cumulative purposes the confirmed supplier name is the
  // primary identity. PDF layouts can expose the recipient GSTIN or omit the
  // supplier PAN/GSTIN on some months, which must NOT split one supplier into
  // separate cumulative chains. Tax IDs are fallbacks only when the name is
  // genuinely unavailable.
  const name = vendorKey(row.vendor_name ?? "");
  if (name && name !== "unknown") return `name:${name}`;
  if (row.vendor_pan?.trim()) return `pan:${row.vendor_pan.trim().toUpperCase()}`;
  if (row.vendor_gstin?.trim()) return `gstin:${row.vendor_gstin.trim().toUpperCase()}`;
  return "name:unknown";
};

export async function sha256(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("The file could not be read."));
    reader.readAsDataURL(file);
  });
}

export async function listInvoices(): Promise<InvoiceRow[]> {
  const { data, error } = await supabase
    .from("invoices")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as InvoiceRow[];
}

export interface VendorRow {
  id: string;
  name: string;
  name_key: string;
  pan: string | null;
  gstin: string | null;
  payee_type: string;
}

export async function listVendors(): Promise<VendorRow[]> {
  const { data, error } = await supabase.from("vendors").select("*").order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as VendorRow[];
}

async function ensureVendor(
  userId: string,
  name: string,
  pan: string | null,
  gstin: string | null,
  payeeType: string,
): Promise<string | null> {
  const key = vendorKey(name);
  if (!key) return null;

  // Prefer tax identity over vendor-name spelling. This prevents one supplier
  // from being split into multiple cumulative chains because of OCR/layout
  // variations such as "SAM EDITING STUDIO" vs an address line.
  type ExistingVendor = { id: string; pan: string | null; gstin: string | null };
  let existing: ExistingVendor | null = null;
  if (pan) {
    const { data } = await supabase
      .from("vendors")
      .select("id, pan, gstin")
      .eq("user_id", userId)
      .eq("pan", pan)
      .limit(1);
    existing = (data?.[0] as ExistingVendor | undefined) ?? null;
  }
  if (!existing && gstin) {
    const { data } = await supabase
      .from("vendors")
      .select("id, pan, gstin")
      .eq("user_id", userId)
      .eq("gstin", gstin)
      .limit(1);
    existing = (data?.[0] as ExistingVendor | undefined) ?? null;
  }
  if (!existing) {
    const { data } = await supabase
      .from("vendors")
      .select("id, pan, gstin")
      .eq("user_id", userId)
      .eq("name_key", key)
      .limit(1);
    existing = (data?.[0] as ExistingVendor | undefined) ?? null;
  }
  if (existing) {
    const patch: { pan?: string; gstin?: string } = {};
    if (pan && !existing.pan) patch.pan = pan;
    if (gstin && !existing.gstin) patch.gstin = gstin;
    if (Object.keys(patch).length) {
      await supabase.from("vendors").update(patch).eq("id", existing.id);
    }
    return existing.id;
  }
  const { data, error } = await supabase
    .from("vendors")
    .insert({ user_id: userId, name: name.trim(), name_key: key, pan, gstin, payee_type: payeeType })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  return (data as { id: string }).id;
}

const CRITICAL_REASONS: Record<string, string> = {
  vendor_name: "Confirm Vendor Name",
  invoice_date: "Confirm Invoice Date",
  invoice_number: "Invoice number requires review",
  tds_base: "Confirm TDS Base",
  tds_category: "Confirm nature of payment",
};

/**
 * Review is raised ONLY when a critical field could not be established.
 * Confidence scores play no part in this decision.
 */
export function buildReview(
  row: Partial<InvoiceRow>,
  _confidenceThreshold: number,
  extraReasons: string[] = [],
  unreadable = false,
): { review_status: string; review_reasons: string[] } {
  const reasons = new Set<string>(extraReasons.filter(Boolean));

  if (!row.vendor_name || row.vendor_name === "Unknown") reasons.add(CRITICAL_REASONS["vendor_name"]!);
  if (!row.invoice_date) reasons.add(CRITICAL_REASONS["invoice_date"]!);
  if (!row.invoice_number) reasons.add(CRITICAL_REASONS["invoice_number"]!);
  if (row.tds_base === null || row.tds_base === undefined || !(row.tds_base > 0))
    reasons.add(CRITICAL_REASONS["tds_base"]!);
  if (!row.tds_category || !ruleForCategory(row.tds_category))
    reasons.add(CRITICAL_REASONS["tds_category"]!);
  if (row.handwritten_adjustment) reasons.add("Confirm handwritten settlement amount");
  if (row.is_duplicate) reasons.add("Confirm duplicate");

  // An invoice is NEVER blocked from the register — uncertain fields only
  // raise "Needs Review" so the row stays visible and editable.
  const list = Array.from(reasons);
  if (unreadable) list.push("Document could not be read automatically");
  if (list.length) return { review_status: "REVIEW", review_reasons: list };
  return { review_status: "APPROVED", review_reasons: [] };
}


function normalisePayee(value: string | null | undefined): PayeeType {
  const allowed: PayeeType[] = ["Individual/HUF", "Company", "Firm/LLP", "Other"];
  const match = allowed.find((a) => a.toLowerCase() === String(value ?? "").toLowerCase());
  return match ?? "Other";
}

/** Derives the TDS base when the model did not supply a reliable one. */
export function deriveBase(f: ExtractedFields): number | null {
  if (f.tds_base !== null && f.tds_base > 0) return f.tds_base;
  if (f.final_settlement_amount !== null && f.final_settlement_amount > 0)
    return f.final_settlement_amount;
  if (f.taxable_value !== null && f.taxable_value > 0) return f.taxable_value;
  const gst = (f.cgst ?? 0) + (f.sgst ?? 0) + (f.igst ?? 0);
  if (f.gross_amount !== null && f.gross_amount > 0 && gst > 0) return f.gross_amount - gst;
  // Last resort: a single identifiable invoice amount is used, flagged for review.
  if (f.gross_amount !== null && f.gross_amount > 0) return f.gross_amount;
  if (f.printed_total !== null && f.printed_total > 0) return f.printed_total;
  return null;
}

export interface SaveArgs {
  userId: string;
  fields: ExtractedFields;
  extractionMethod: string;
  confidenceThreshold: number;
  fileName: string;
  filePath: string | null;
  fileHash: string;
}

export async function saveExtractedInvoice(args: SaveArgs): Promise<InvoiceRow> {
  const { fields } = args;
  const vendorName = fields.vendor_name?.trim() || "Unknown";
  const payeeType = normalisePayee(fields.payee_type);

  const categoryRule =
    ruleForCategory(fields.tds_category) ??
    guessCategory(`${fields.description ?? ""} ${fields.document_type ?? ""}`);

  const tdsBase = deriveBase(fields);

  // Every upload gets its own register row. A duplicate is evidence that a
  // duplicate document was received, so it must remain visible rather than be
  // silently deleted or merged into the original.
  const extraReasons = [...fields.review_reasons];
  let isDuplicate = false;
  let duplicateOf: string | null = null;
  let duplicateReason: string | null = null;

  // Fast best-effort duplicate detection for immediate UI feedback. The full
  // register is reconciled again after the batch, which also handles parallel
  // uploads where two identical files arrive at exactly the same time.
  const { data: sameHash } = await supabase
    .from("invoices")
    .select("id")
    .eq("user_id", args.userId)
    .eq("file_hash", args.fileHash)
    .order("created_at", { ascending: true })
    .limit(1);
  if (sameHash?.length) {
    isDuplicate = true;
    duplicateOf = (sameHash[0] as { id: string }).id;
    duplicateReason = "Exact same file already recorded";
  }

  if (!isDuplicate && fields.invoice_number && tdsBase) {
    let query = supabase
      .from("invoices")
      .select("id, invoice_date, tds_base")
      .eq("user_id", args.userId)
      .eq("invoice_number", fields.invoice_number)
      .order("created_at", { ascending: true })
      .limit(10);
    if (fields.vendor_pan) query = query.eq("vendor_pan", fields.vendor_pan);
    else if (fields.vendor_gstin) query = query.eq("vendor_gstin", fields.vendor_gstin);
    else query = query.eq("vendor_name", vendorName);
    const { data: sameKey } = await query;
    const match = (sameKey ?? []).find((r) => {
      const row = r as { id: string; tds_base: number | null; invoice_date: string | null };
      const sameAmount = Number(row.tds_base ?? 0) === tdsBase;
      const sameDate =
        !fields.invoice_date || !row.invoice_date || row.invoice_date === fields.invoice_date;
      return sameAmount && sameDate;
    }) as { id: string } | undefined;
    if (match) {
      isDuplicate = true;
      duplicateOf = match.id;
      duplicateReason = "Same vendor, invoice number, date and amount already recorded";
    }
  }

  // Never manufacture an invoice number — leave it blank for review instead.
  const invoiceNumber = fields.invoice_number?.trim() || null;
  const generated = false;

  const draft: Partial<InvoiceRow> = {
    vendor_name: vendorName,
    invoice_number: invoiceNumber,
    invoice_number_generated: generated,
    invoice_date: fields.invoice_date,
    description: fields.description,
    tds_base: tdsBase,
    tds_category: categoryRule?.label ?? null,
    handwritten_adjustment: fields.handwritten_adjustment,
    confidence: fields.confidence,
    is_duplicate: isDuplicate,
  };
  const review = buildReview(draft, args.confidenceThreshold, extraReasons, fields.unreadable);

  const vendorId = await ensureVendor(
    args.userId,
    vendorName,
    fields.vendor_pan,
    fields.vendor_gstin,
    payeeType,
  );

  const insert = {
    user_id: args.userId,
    vendor_id: vendorId,
    doc_type: fields.document_type,
    vendor_name: vendorName,
    vendor_pan: fields.vendor_pan,
    vendor_gstin: fields.vendor_gstin,
    invoice_number: invoiceNumber,
    invoice_number_generated: generated,
    invoice_date: fields.invoice_date,
    description: fields.description,
    printed_total: fields.printed_total,
    handwritten_adjustment: fields.handwritten_adjustment,
    final_settlement: fields.final_settlement_amount,
    gross_amount: fields.gross_amount,
    taxable_value: fields.taxable_value,
    cgst: fields.cgst,
    sgst: fields.sgst,
    igst: fields.igst,
    tds_base: tdsBase,
    payee_type: payeeType,
    tds_category: categoryRule?.label ?? null,
    confidence: fields.confidence,
    field_confidence: fields.field_confidence,
    notes: fields.notes,
    current_section: categoryRule?.currentSection ?? null,
    legacy_section: categoryRule?.legacySection ?? null,
    review_status: review.review_status,
    review_reasons: review.review_reasons,
    extraction_method: args.extractionMethod,
    source_file: args.fileName,
    file_path: args.filePath,
    file_hash: args.fileHash,
    is_duplicate: isDuplicate,
    duplicate_of: duplicateOf,
    duplicate_reason: duplicateReason,
  };

  const { data, error } = await supabase.from("invoices").insert(insert).select("*").single();
  if (error) throw new Error(error.message);
  return data as unknown as InvoiceRow;
}

const rowCreatedOrder = (a: InvoiceRow, b: InvoiceRow) => {
  if (a.created_at !== b.created_at) return a.created_at < b.created_at ? -1 : 1;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
};

const duplicateBusinessKey = (row: InvoiceRow): string | null => {
  if (!row.invoice_number || !row.invoice_date || !(Number(row.tds_base ?? 0) > 0)) return null;
  const invoice = row.invoice_number.trim().toUpperCase().replace(/\s+/g, "");
  const amount = Number(row.tds_base ?? 0).toFixed(2);
  return `${vendorIdentityKey(row)}::${invoice}::${row.invoice_date}::${amount}`;
};

/**
 * Authoritative duplicate reconciliation for the whole register.
 *
 * - NOTHING is deleted.
 * - the oldest occurrence is the original;
 * - every later exact-hash or business-key match stays visible as DUPLICATE;
 * - duplicate rows contribute zero to cumulative/TDS calculations.
 *
 * This post-batch pass also makes duplicate detection race-safe when folder
 * uploads are processed in parallel.
 */
async function reconcileDuplicateFlags(rows: InvoiceRow[]): Promise<void> {
  const desired = new Map<
    string,
    { isDuplicate: boolean; duplicateOf: string | null; reason: string | null }
  >();
  for (const row of rows) {
    desired.set(row.id, { isDuplicate: false, duplicateOf: null, reason: null });
  }

  const exactHashGroups = new Map<string, InvoiceRow[]>();
  for (const row of rows) {
    if (!row.file_hash) continue;
    const group = exactHashGroups.get(row.file_hash) ?? [];
    group.push(row);
    exactHashGroups.set(row.file_hash, group);
  }
  for (const group of exactHashGroups.values()) {
    if (group.length < 2) continue;
    group.sort(rowCreatedOrder);
    const original = group[0]!;
    for (const dup of group.slice(1)) {
      desired.set(dup.id, {
        isDuplicate: true,
        duplicateOf: original.id,
        reason: "Exact same file already recorded",
      });
    }
  }

  const businessGroups = new Map<string, InvoiceRow[]>();
  for (const row of rows) {
    const key = duplicateBusinessKey(row);
    if (!key) continue;
    const group = businessGroups.get(key) ?? [];
    group.push(row);
    businessGroups.set(key, group);
  }
  for (const group of businessGroups.values()) {
    if (group.length < 2) continue;
    group.sort(rowCreatedOrder);
    const original = group[0]!;
    for (const dup of group.slice(1)) {
      const current = desired.get(dup.id)!;
      if (!current.isDuplicate) {
        desired.set(dup.id, {
          isDuplicate: true,
          duplicateOf: original.id,
          reason: "Same vendor, invoice number, date and amount already recorded",
        });
      }
    }
  }

  const updates: PromiseLike<unknown>[] = [];
  for (const row of rows) {
    const d = desired.get(row.id)!;
    const reasonsWithoutDuplicate = (row.review_reasons ?? []).filter(
      (r) => r !== "Confirm duplicate",
    );
    const review = buildReview(
      { ...row, is_duplicate: d.isDuplicate },
      0,
      reasonsWithoutDuplicate,
      false,
    );

    const changed =
      row.is_duplicate !== d.isDuplicate ||
      row.duplicate_of !== d.duplicateOf ||
      row.duplicate_reason !== d.reason ||
      row.review_status !== review.review_status ||
      JSON.stringify(row.review_reasons ?? []) !== JSON.stringify(review.review_reasons);
    if (!changed) continue;

    updates.push(
      supabase
        .from("invoices")
        .update({
          is_duplicate: d.isDuplicate,
          duplicate_of: d.duplicateOf,
          duplicate_reason: d.reason,
          review_status: review.review_status,
          review_reasons: review.review_reasons,
        })
        .eq("id", row.id),
    );
  }
  await Promise.all(updates);
}

/** Round monetary calculations to paise. */
const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

interface LocalChainInput {
  id: string;
  vendorKey: string;
  category: string | null;
  tdsBase: number | null;
  payeeType: PayeeType;
  invoiceDate: string | null;
  invoiceNumber: string | null;
  isDuplicate: boolean;
  createdAt: string;
}

interface LocalChainResult {
  previous_cumulative: number;
  new_cumulative: number;
  tds_rate: number;
  catchup_tds: number;
  tds_now: number;
  tds_status: string;
  current_section: string | null;
  legacy_section: string | null;
}

function taxYearKey(row: LocalChainInput): string {
  const raw = row.invoiceDate ?? row.createdAt.slice(0, 10);
  const match = /^(\d{4})-(\d{2})/.exec(raw);
  if (!match) return "unknown";
  const year = Number(match[1]);
  const month = Number(match[2]);
  const start = month >= 4 ? year : year - 1;
  return `${start}-${String((start + 1) % 100).padStart(2, "0")}`;
}

function displayChainKey(row: LocalChainInput, rule: TdsRule): string {
  // FULL FY cumulative for same supplier + TDS category/rule.
  return `${row.vendorKey}::${rule.key}::${taxYearKey(row)}`;
}

function thresholdChainKey(row: LocalChainInput, rule: TdsRule): string {
  const base = displayChainKey(row, rule);
  if (rule.thresholdMode === "monthly") {
    const month = (row.invoiceDate ?? row.createdAt).slice(0, 7);
    return `${base}::${month}`;
  }
  return base;
}

function requiredTdsLocal(payments: number[], rule: TdsRule, payeeType: PayeeType): number {
  const rate = rule.rate(payeeType) / 100;
  const cum = payments.reduce((a, b) => a + b, 0);
  switch (rule.thresholdMode) {
    case "aggregate":
    case "monthly":
      return cum >= rule.threshold ? r2(cum * rate) : 0;
    case "single_or_aggregate": {
      const qualifying =
        cum >= rule.threshold
          ? cum
          : payments
              .filter((p) => p >= (rule.singleThreshold ?? Infinity))
              .reduce((a, b) => a + b, 0);
      return qualifying > 0 ? r2(qualifying * rate) : 0;
    }
    case "excess":
      return cum > rule.threshold ? r2((cum - rule.threshold) * rate) : 0;
    case "transaction": {
      const qualifying = payments.filter((p) => p >= rule.threshold).reduce((a, b) => a + b, 0);
      return qualifying > 0 ? r2(qualifying * rate) : 0;
    }
  }
}

function invoiceSortValue(value: string | null): string {
  return String(value ?? "").trim().toUpperCase();
}

function sortChainRows(rows: LocalChainInput[]): LocalChainInput[] {
  return [...rows].sort((a, b) => {
    const da = a.invoiceDate ?? a.createdAt.slice(0, 10);
    const db = b.invoiceDate ?? b.createdAt.slice(0, 10);
    if (da !== db) return da < db ? -1 : 1;
    const ia = invoiceSortValue(a.invoiceNumber);
    const ib = invoiceSortValue(b.invoiceNumber);
    if (ia !== ib) return ia.localeCompare(ib, undefined, { numeric: true, sensitivity: "base" });
    if (a.createdAt !== b.createdAt) return a.createdAt < b.createdAt ? -1 : 1;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
}

/**
 * Self-contained V7 cumulative engine.
 *
 * This deliberately lives in invoices.ts so the register works correctly even
 * if an older tds/engine.ts file is still present in the Lovable project.
 * - FY cumulative never resets merely because the invoice month changes.
 * - monthly statutory thresholds still use a separate month bucket.
 * - duplicates stay visible and have exactly ZERO effect.
 */
function computeRegisterChains(rows: LocalChainInput[]): Record<string, LocalChainResult> {
  const out: Record<string, LocalChainResult> = {};
  const displayChains = new Map<string, number[]>();
  const thresholdChains = new Map<string, number[]>();

  for (const row of sortChainRows(rows)) {
    const rule = ruleForCategory(row.category);
    const base = typeof row.tdsBase === "number" && Number.isFinite(row.tdsBase) ? row.tdsBase : null;

    if (!rule || base === null || base <= 0) {
      out[row.id] = {
        previous_cumulative: 0,
        new_cumulative: 0,
        tds_rate: 0,
        catchup_tds: 0,
        tds_now: 0,
        tds_status: "NEEDS REVIEW",
        current_section: rule?.currentSection ?? null,
        legacy_section: rule?.legacySection ?? null,
      };
      continue;
    }

    const displayKey = displayChainKey(row, rule);
    const displayPrior = displayChains.get(displayKey) ?? [];
    const prevCum = displayPrior.reduce((a, b) => a + b, 0);
    const rate = rule.rate(row.payeeType);

    if (row.isDuplicate) {
      out[row.id] = {
        previous_cumulative: r2(prevCum),
        new_cumulative: r2(prevCum),
        tds_rate: rate,
        catchup_tds: 0,
        tds_now: 0,
        tds_status: "DUPLICATE",
        current_section: rule.currentSection,
        legacy_section: rule.legacySection,
      };
      continue;
    }

    displayChains.set(displayKey, [...displayPrior, base]);

    const thresholdKey = thresholdChainKey(row, rule);
    const thresholdPrior = thresholdChains.get(thresholdKey) ?? [];
    const priorRequired = requiredTdsLocal(thresholdPrior, rule, row.payeeType);
    const thresholdPayments = [...thresholdPrior, base];
    const totalRequired = requiredTdsLocal(thresholdPayments, rule, row.payeeType);
    thresholdChains.set(thresholdKey, thresholdPayments);

    const tdsNow = r2(Math.max(0, totalRequired - priorRequired));
    const currentBill = tdsNow > 0 ? r2(Math.min(tdsNow, (base * rate) / 100)) : 0;
    const catchup = r2(Math.max(0, tdsNow - currentBill));

    out[row.id] = {
      previous_cumulative: r2(prevCum),
      new_cumulative: r2(prevCum + base),
      tds_rate: rate,
      catchup_tds: catchup,
      tds_now: tdsNow,
      tds_status: tdsNow > 0 ? "TDS REQUIRED" : "BELOW THRESHOLD",
      current_section: rule.currentSection,
      legacy_section: rule.legacySection,
    };
  }

  return out;
}

async function recalculateRegisterOnce(): Promise<void> {
  const before = await listInvoices();
  await reconcileDuplicateFlags(before);
  const rows = await listInvoices();

  const inputs: LocalChainInput[] = rows.map((r) => ({
    id: r.id,
    // NAME-FIRST identity prevents one SAM EDITING STUDIO chain from being
    // split merely because different invoices expose different GST/PAN fields.
    vendorKey: vendorIdentityKey(r),
    category: r.tds_category,
    tdsBase: r.tds_base === null ? null : Number(r.tds_base),
    payeeType: normalisePayee(r.payee_type),
    invoiceDate: r.invoice_date,
    invoiceNumber: r.invoice_number,
    isDuplicate: r.is_duplicate,
    createdAt: r.created_at,
  }));
  const results = computeRegisterChains(inputs);

  const updates = rows
    .map((row) => {
      const res = results[row.id];
      if (!res) return null;
      const changed =
        Number(row.previous_cumulative) !== res.previous_cumulative ||
        Number(row.new_cumulative) !== res.new_cumulative ||
        Number(row.tds_rate) !== res.tds_rate ||
        Number(row.catchup_tds) !== res.catchup_tds ||
        Number(row.tds_now) !== res.tds_now ||
        row.tds_status !== res.tds_status ||
        row.current_section !== res.current_section ||
        row.legacy_section !== res.legacy_section;
      return changed ? { id: row.id, res } : null;
    })
    .filter(Boolean) as { id: string; res: LocalChainResult }[];

  await Promise.all(updates.map((u) => supabase.from("invoices").update(u.res).eq("id", u.id)));
}

// Older Upload pages call recalculateRegister once per parallel worker. Queue
// those calls so an earlier calculation can never finish later and overwrite a
// newer, complete batch calculation.
let recalcQueue: Promise<void> = Promise.resolve();

/** Recomputes duplicates + complete FY cumulative in a race-safe queue. */
export function recalculateRegister(): Promise<void> {
  const next = recalcQueue.catch(() => undefined).then(() => recalculateRegisterOnce());
  recalcQueue = next;
  return next;
}

export async function deleteInvoice(row: InvoiceRow): Promise<void> {
  if (row.file_path) {
    // A storage object can be referenced by more than one duplicate row. Only
    // remove it when this is the last register row using that path.
    const { data: otherRefs } = await supabase
      .from("invoices")
      .select("id")
      .eq("file_path", row.file_path)
      .neq("id", row.id)
      .limit(1);
    if (!otherRefs?.length) {
      await supabase.storage.from("invoice-docs").remove([row.file_path]);
    }
  }
  const { error } = await supabase.from("invoices").delete().eq("id", row.id);
  if (error) throw new Error(error.message);
  await recalculateRegister();
}

export async function updateInvoice(
  row: InvoiceRow,
  patch: Partial<InvoiceRow>,
  approve: boolean,
  confidenceThreshold: number,
): Promise<void> {
  const merged = { ...row, ...patch };
  const rule = ruleForCategory(merged.tds_category);
  const review = approve
    ? { review_status: "APPROVED", review_reasons: [] as string[] }
    : buildReview(merged, confidenceThreshold, []);

  const vendorId = await ensureVendor(
    row.user_id,
    merged.vendor_name,
    merged.vendor_pan,
    merged.vendor_gstin,
    merged.payee_type,
  );

  const { error } = await supabase
    .from("invoices")
    .update({
      ...patch,
      vendor_id: vendorId,
      current_section: rule?.currentSection ?? null,
      legacy_section: rule?.legacySection ?? null,
      review_status: review.review_status,
      review_reasons: review.review_reasons,
    })
    .eq("id", row.id);
  if (error) throw new Error(error.message);
  await recalculateRegister();
}
