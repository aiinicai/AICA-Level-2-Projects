import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const extractInput = z.object({
  fileName: z.string().min(1),
  mimeType: z.string().min(1),
  dataUrl: z.string().min(10),
});

export const extractDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => extractInput.parse(data))
  .handler(async ({ data, context }) => {
    const { runExtraction } = await import("./extraction-runner.server");
    return runExtraction(context.supabase, context.userId, data);
  });

const pingInput = z.object({
  provider: z.enum(["builtin", "gemini", "openai", "local"]),
  model: z.string().min(1),
  apiKey: z.string().optional().nullable(),
});

export const testAiConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => pingInput.parse(data))
  .handler(async ({ data, context }) => {
    const { runPing } = await import("./extraction-runner.server");
    return runPing(context.supabase, context.userId, data);
  });

const classifyInput = z.object({ summary: z.string().min(10).max(4000) });

/** Cheap, text-only classification used when the PDF has a usable text layer. */
export const classifyInvoice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => classifyInput.parse(data))
  .handler(async ({ data, context }) => {
    const { runClassify } = await import("./extraction-runner.server");
    return runClassify(context.supabase, context.userId, data);
  });

/** Threshold + AI-enabled flags, used when no AI call is needed at all. */
export const getProcessingSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { runSettingsOnly } = await import("./extraction-runner.server");
    return runSettingsOnly(context.supabase, context.userId);
  });
