import * as XLSX from "xlsx";
import type { ExtractedFields } from "./extraction.server";

/** Logical fields an imported spreadsheet can map onto. */
export const SHEET_FIELDS = [
  { key: "vendor_name", label: "Vendor Name", type: "text" as const, required: true },
  { key: "vendor_pan", label: "PAN", type: "text" as const },
  { key: "vendor_gstin", label: "GSTIN", type: "text" as const },
  { key: "invoice_number", label: "Invoice No", type: "text" as const },
  { key: "invoice_date", label: "Invoice Date", type: "date" as const },
  { key: "description", label: "Description / Nature of Payment", type: "text" as const },
  { key: "gross_amount", label: "Gross Amount", type: "number" as const },
  { key: "taxable_value", label: "Taxable Value", type: "number" as const },
  { key: "cgst", label: "CGST", type: "number" as const },
  { key: "sgst", label: "SGST", type: "number" as const },
  { key: "igst", label: "IGST", type: "number" as const },
  { key: "tds_base", label: "TDS Base", type: "number" as const },
  { key: "payee_type", label: "Payee Type", type: "text" as const },
  { key: "tds_category", label: "TDS Category", type: "text" as const },
];

export type SheetFieldKey = (typeof SHEET_FIELDS)[number]["key"];
export type Mapping = Partial<Record<SheetFieldKey, string>>;

const ALIASES: Record<SheetFieldKey, string[]> = {
  vendor_name: ["vendor", "vendor name", "party", "party name", "supplier", "name", "payee"],
  vendor_pan: ["pan", "pan no", "pan number"],
  vendor_gstin: ["gstin", "gst no", "gst number", "gstin/uin"],
  invoice_number: ["invoice no", "invoice number", "bill no", "bill number", "voucher no", "inv no", "doc no"],
  invoice_date: ["date", "invoice date", "bill date", "voucher date"],
  description: ["description", "particulars", "nature of payment", "narration", "service", "remarks"],
  gross_amount: ["gross", "gross amount", "total", "invoice amount", "bill amount", "total amount", "amount"],
  taxable_value: ["taxable", "taxable value", "taxable amount", "net amount", "basic", "base amount"],
  cgst: ["cgst", "cgst amount"],
  sgst: ["sgst", "sgst amount", "utgst"],
  igst: ["igst", "igst amount"],
  tds_base: ["tds base", "base", "amount for tds", "tds amount base"],
  payee_type: ["payee type", "status", "constitution", "type"],
  tds_category: ["tds category", "category", "section", "nature", "tds section"],
};

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

export interface ParsedSheet {
  headers: string[];
  rows: Record<string, unknown>[];
  sheetNames: string[];
  sheetName: string;
}

export async function parseSpreadsheet(file: File, sheetName?: string): Promise<ParsedSheet> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { cellDates: true });
  const name = sheetName && wb.SheetNames.includes(sheetName) ? sheetName : wb.SheetNames[0]!;
  const ws = wb.Sheets[name]!;
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: null, raw: true });
  const headers = rows.length
    ? Array.from(new Set(rows.flatMap((r) => Object.keys(r))))
    : (XLSX.utils.sheet_to_json<string[]>(ws, { header: 1 })[0] ?? []).map(String);
  return { headers, rows, sheetNames: wb.SheetNames, sheetName: name };
}

export function autoMap(headers: string[]): Mapping {
  const mapping: Mapping = {};
  const used = new Set<string>();
  for (const field of SHEET_FIELDS) {
    const aliases = ALIASES[field.key as SheetFieldKey] ?? [];
    const hit =
      headers.find((h) => !used.has(h) && aliases.includes(norm(h))) ??
      headers.find((h) => !used.has(h) && aliases.some((a) => norm(h).includes(a)));
    if (hit) {
      mapping[field.key as SheetFieldKey] = hit;
      used.add(hit);
    }
  }
  return mapping;
}

function toNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const cleaned = String(value).replace(/[₹,\s]/g, "").replace(/[()]/g, "");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

function toDate(value: unknown): string | null {
  if (!value && value !== 0) return null;
  if (value instanceof Date && !Number.isNaN(value.getTime()))
    return new Date(value.getTime() - value.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const s = String(value).trim();
  const dmy = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (dmy) {
    const [, d, m, y] = dmy;
    const year = y!.length === 2 ? `20${y}` : y!;
    return `${year}-${m!.padStart(2, "0")}-${d!.padStart(2, "0")}`;
  }
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return iso[0]!;
  const parsed = new Date(s);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString().slice(0, 10);
}

const text = (v: unknown) => {
  const s = v === null || v === undefined ? "" : String(v).trim();
  return s === "" ? null : s;
};

export function rowToFields(row: Record<string, unknown>, mapping: Mapping): ExtractedFields {
  const get = (key: SheetFieldKey) => (mapping[key] ? row[mapping[key]!] : null);

  const gross = toNumber(get("gross_amount"));
  const taxable = toNumber(get("taxable_value"));
  const cgst = toNumber(get("cgst"));
  const sgst = toNumber(get("sgst"));
  const igst = toNumber(get("igst"));
  let base = toNumber(get("tds_base"));
  if (base === null) {
    const gst = (cgst ?? 0) + (sgst ?? 0) + (igst ?? 0);
    base = taxable ?? (gross !== null ? gross - gst : null);
  }

  const reasons: string[] = ["Imported from spreadsheet — verify against the source document"];

  return {
    document_type: "Spreadsheet row",
    vendor_name: text(get("vendor_name")),
    vendor_pan: text(get("vendor_pan")),
    vendor_gstin: text(get("vendor_gstin")),
    invoice_number: text(get("invoice_number")),
    invoice_date: toDate(get("invoice_date")),
    description: text(get("description")),
    printed_total: gross,
    handwritten_adjustment: null,
    final_settlement_amount: null,
    gross_amount: gross,
    taxable_value: taxable,
    cgst,
    sgst,
    igst,
    tds_base: base,
    payee_type: text(get("payee_type")),
    tds_category: text(get("tds_category")),
    confidence: 0.75,
    field_confidence: {},
    notes: "Imported from spreadsheet",
    unreadable: false,
    review_reasons: reasons,
  };
}

export async function hashRow(fileName: string, row: Record<string, unknown>): Promise<string> {
  const payload = `${fileName}|${JSON.stringify(row)}`;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(payload));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const isSpreadsheet = (file: File) => /\.(xlsx|xls|csv)$/i.test(file.name);
