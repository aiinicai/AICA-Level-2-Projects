/**
 * Indian money parsing helpers shared by the deterministic invoice parser.
 * Percentages (9%, 18%) and comma-separated reference lists (9,10,11) are
 * never treated as monetary values.
 */

const CURRENCY = /(₹|rs\.?|inr)/gi;

/** Parses "₹ 25,000.00", "Rs. 25,000", "29,000/-", "29000.00" → number. */
export function parseIndianAmount(raw: string): number | null {
  if (!raw) return null;
  let s = String(raw).trim();
  if (/%/.test(s)) return null;

  s = s.replace(CURRENCY, "").replace(/\/-\s*$/, "").replace(/\s/g, "");
  s = s.replace(/^[(\[]|[)\]]$/g, "");

  // If commas are present, require a genuine thousands-grouping pattern.
  // This deliberately rejects description/reference lists such as 9,10,11.
  if (s.includes(",")) {
    const western = /^\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?$/;
    const indian = /^\d{1,2}(?:,\d{2})*,\d{3}(?:\.\d{1,2})?$/;
    if (!western.test(s) && !indian.test(s)) return null;
    s = s.replace(/,/g, "");
  }

  if (!/^\d+(?:\.\d{1,2})?$/.test(s)) return null;
  const n = Number(s);
  return isFinite(n) ? n : null;
}

// Capture a complete numeric/comma token first. parseIndianAmount then decides
// whether its comma grouping is a real amount or merely a list such as 9,10,11.
const TOKEN_RE = /(?:₹|rs\.?|inr)?\s*\d[\d,]*(?:\.\d{1,2})?/gi;

/** All monetary amounts on a line, skipping percentages and rate/reference figures. */
export function amountsInLine(line: string): number[] {
  const out: number[] = [];
  TOKEN_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = TOKEN_RE.exec(line))) {
    const token = m[0];
    const after = line.slice(m.index + token.length, m.index + token.length + 2);
    if (/^\s*%/.test(after)) continue; // rate such as "9 %"
    const value = parseIndianAmount(token);
    if (value === null || value <= 0) continue;
    out.push(value);
  }
  return out;
}

export const approxEqual = (a: number, b: number, tol = 2) =>
  Math.abs(a - b) <= Math.max(tol, b * 0.01);
