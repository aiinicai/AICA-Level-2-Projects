import * as XLSX from "xlsx";
import type { InvoiceRow } from "./invoices";
import { inr } from "./format";
import { TAX_YEAR } from "./tds/rules";

const registerRow = (r: InvoiceRow, i: number) => ({
  "Sr No": i + 1,
  "Invoice Date": r.invoice_date ?? "",
  "Vendor Name": r.vendor_name,
  PAN: r.vendor_pan ?? "",
  GSTIN: r.vendor_gstin ?? "",
  "Payee Type": r.payee_type,
  "Invoice No": r.invoice_number ?? "",
  "Auto Reference": r.invoice_number_generated ? "Yes" : "No",
  Description: r.description ?? "",
  "Gross Amount": r.gross_amount ?? "",
  CGST: r.cgst ?? "",
  SGST: r.sgst ?? "",
  IGST: r.igst ?? "",
  "TDS Base (excl. GST)": r.tds_base ?? "",
  "TDS Category": r.tds_category ?? "",
  "Current Section": r.current_section ?? "",
  "Legacy Section": r.legacy_section ?? "",
  "Previous Cumulative": r.previous_cumulative,
  "New Cumulative": r.new_cumulative,
  "Rate %": r.tds_rate,
  "Catch-up TDS": r.catchup_tds,
  "TDS Now": r.tds_now,
  "TDS Status": r.tds_status,
  "Review Status": r.review_status,
  "Review Points": r.review_reasons.join("; "),
  Duplicate: r.is_duplicate ? r.duplicate_reason ?? "Yes" : "",
  Confidence: r.confidence === null ? "" : Math.round(r.confidence * 100) / 100,
  "Extraction Method": r.extraction_method ?? "",
  "Source File": r.source_file ?? "",
  Notes: r.notes ?? "",
});

export function exportRegister(rows: InvoiceRow[]) {
  const wb = XLSX.utils.book_new();

  const register = XLSX.utils.json_to_sheet(rows.map(registerRow));
  XLSX.utils.book_append_sheet(wb, register, "TDS Register");

  const byVendor = new Map<
    string,
    { vendor: string; pan: string; base: number; tds: number; catchup: number; bills: number }
  >();
  for (const r of rows) {
    const k = r.vendor_name;
    const cur =
      byVendor.get(k) ?? { vendor: k, pan: r.vendor_pan ?? "", base: 0, tds: 0, catchup: 0, bills: 0 };
    cur.base += r.is_duplicate ? 0 : r.tds_base ?? 0;
    cur.tds += r.tds_now;
    cur.catchup += r.catchup_tds;
    cur.bills += 1;
    if (!cur.pan && r.vendor_pan) cur.pan = r.vendor_pan;
    byVendor.set(k, cur);
  }
  const vendorSheet = XLSX.utils.json_to_sheet(
    Array.from(byVendor.values()).map((v) => ({
      Vendor: v.vendor,
      PAN: v.pan,
      Documents: v.bills,
      "Total Base": v.base,
      "Catch-up TDS": v.catchup,
      "Total TDS": v.tds,
    })),
  );
  XLSX.utils.book_append_sheet(wb, vendorSheet, "Vendor Summary");

  const bySection = new Map<string, { section: string; base: number; tds: number; count: number }>();
  for (const r of rows) {
    if (!r.current_section) continue;
    const cur = bySection.get(r.current_section) ?? {
      section: r.current_section,
      base: 0,
      tds: 0,
      count: 0,
    };
    cur.base += r.is_duplicate ? 0 : r.tds_base ?? 0;
    cur.tds += r.tds_now;
    cur.count += 1;
    bySection.set(r.current_section, cur);
  }
  const sectionSheet = XLSX.utils.json_to_sheet(
    Array.from(bySection.values()).map((s) => ({
      Section: s.section,
      Documents: s.count,
      "Total Base": s.base,
      "Total TDS": s.tds,
    })),
  );
  XLSX.utils.book_append_sheet(wb, sectionSheet, "Section Summary");

  const review = rows.filter((r) => r.review_status !== "APPROVED");
  const reviewSheet = XLSX.utils.json_to_sheet(
    review.length
      ? review.map((r, i) => registerRow(r, i))
      : [{ Note: "No documents pending review." }],
  );
  XLSX.utils.book_append_sheet(wb, reviewSheet, "Pending Review");

  const total = rows.reduce((a, r) => a + r.tds_now, 0);
  const info = XLSX.utils.json_to_sheet([
    { Field: "Tax Year", Value: TAX_YEAR },
    { Field: "Generated On", Value: new Date().toLocaleString("en-IN") },
    { Field: "Documents", Value: rows.length },
    { Field: "Total TDS Payable", Value: inr(total) },
  ]);
  XLSX.utils.book_append_sheet(wb, info, "Report Info");

  XLSX.writeFile(wb, `TDS-Register-${TAX_YEAR}-${new Date().toISOString().slice(0, 10)}.xlsx`);
}
