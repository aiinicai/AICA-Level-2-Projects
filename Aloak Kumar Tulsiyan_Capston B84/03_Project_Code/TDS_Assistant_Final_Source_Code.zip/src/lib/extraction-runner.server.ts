import type { SupabaseClient } from "@supabase/supabase-js";
import { callVisionProvider, pingProvider, type ExtractedFields } from "./extraction.server";

interface SettingsRow {
  ai_provider: string;
  model: string;
  confidence_threshold: number;
  enable_vision: boolean;
  api_key: string | null;
}

const DEFAULTS: SettingsRow = {
  ai_provider: "builtin",
  model: "google/gemini-2.5-pro",
  confidence_threshold: 0.75,
  enable_vision: true,
  api_key: null,
};

/* eslint-disable @typescript-eslint/no-explicit-any */
async function loadSettings(supabase: SupabaseClient<any>, userId: string): Promise<SettingsRow> {
  const { data } = await supabase
    .from("app_settings")
    .select("ai_provider, model, confidence_threshold, enable_vision, api_key")
    .eq("user_id", userId)
    .maybeSingle();
  if (!data) return DEFAULTS;
  return {
    ai_provider: (data as SettingsRow).ai_provider ?? DEFAULTS.ai_provider,
    model: (data as SettingsRow).model ?? DEFAULTS.model,
    confidence_threshold: Number((data as SettingsRow).confidence_threshold ?? 0.75),
    enable_vision: (data as SettingsRow).enable_vision ?? true,
    api_key: (data as SettingsRow).api_key ?? null,
  };
}

export interface ExtractionResult {
  fields: ExtractedFields;
  extraction_method: string;
  confidence_threshold: number;
}

const MANUAL: ExtractedFields = {
  document_type: null,
  vendor_name: null,
  vendor_pan: null,
  vendor_gstin: null,
  invoice_number: null,
  invoice_date: null,
  description: null,
  printed_total: null,
  handwritten_adjustment: null,
  final_settlement_amount: null,
  gross_amount: null,
  taxable_value: null,
  cgst: null,
  sgst: null,
  igst: null,
  tds_base: null,
  payee_type: null,
  tds_category: null,
  confidence: 0,
  field_confidence: {},
  notes: "AI reading is switched off, so this document must be keyed in and confirmed manually.",
  unreadable: true,
  review_reasons: [
    "Confirm Vendor Name",
    "Confirm Invoice Date",
    "Confirm Invoice Number",
    "Confirm TDS Base",
    "Confirm nature of payment",
    "Confirm TDS category",
  ],
};

export async function runExtraction(
  supabase: SupabaseClient<any>,
  userId: string,
  input: { fileName: string; mimeType: string; dataUrl: string },
): Promise<ExtractionResult> {
  const settings = await loadSettings(supabase, userId);

  if (settings.ai_provider === "local" || !settings.enable_vision) {
    return {
      fields: { ...MANUAL },
      extraction_method: "Manual entry (AI reading off)",
      confidence_threshold: settings.confidence_threshold,
    };
  }

  const fields = await callVisionProvider(
    {
      provider: settings.ai_provider,
      model: settings.model,
      apiKey: settings.api_key,
    },
    input.fileName,
    input.mimeType,
    input.dataUrl,
  );

  const providerLabel =
    settings.ai_provider === "builtin"
      ? "Built-in AI Vision"
      : settings.ai_provider === "gemini"
        ? "Google Gemini"
        : "OpenAI";

  return {
    fields,
    extraction_method: `${providerLabel} (${settings.model})`,
    confidence_threshold: settings.confidence_threshold,
  };
}

export async function runPing(
  supabase: SupabaseClient<any>,
  userId: string,
  input: { provider: string; model: string; apiKey?: string | null | undefined },
): Promise<{ message: string }> {
  if (input.provider === "local") {
    return { message: "Local mode needs no connection — documents are keyed in manually." };
  }
  let key = input.apiKey ?? null;
  if (!key && input.provider !== "builtin") {
    const settings = await loadSettings(supabase, userId);
    key = settings.api_key;
  }
  const message = await pingProvider({
    provider: input.provider,
    model: input.model,
    apiKey: key,
  });
  return { message };
}

export async function runClassify(
  supabase: SupabaseClient<any>,
  userId: string,
  input: { summary: string },
): Promise<{
  classification: import("./classify.server").ClassificationResult;
  extraction_method: string;
  confidence_threshold: number;
}> {
  const settings = await loadSettings(supabase, userId);
  const { classifyText } = await import("./classify.server");
  const classification = await classifyText(
    { provider: settings.ai_provider, model: settings.model, apiKey: settings.api_key },
    input.summary,
  );
  return {
    classification,
    extraction_method: "PDF text + AI classification",
    confidence_threshold: settings.confidence_threshold,
  };
}

export async function runSettingsOnly(
  supabase: SupabaseClient<any>,
  userId: string,
): Promise<{ ai_enabled: boolean; confidence_threshold: number }> {
  const settings = await loadSettings(supabase, userId);
  return {
    ai_enabled: settings.ai_provider !== "local" && settings.enable_vision,
    confidence_threshold: settings.confidence_threshold,
  };
}
