/**
 * Deterministic invoice parser for selectable PDF text.
 *
 * Design goals:
 * - normal digital PDFs NEVER require AI;
 * - identifiers (bank A/c, phone, HSN, GSTIN, dates, serial numbers) can never
 *   become invoice amounts;
 * - where GST and gross total are available, arithmetic is the final authority;
 * - PDF table headers/quantities are treated as layout noise, not money;
 * - common Indian invoice layouts are supported without vendor-specific hardcoding.
 */
import type { ExtractedFields } from "./extraction.server";
import { guessCategory } from "./tds/rules";
import { amountsInLine, approxEqual } from "./money";

const GSTIN_RE = /\b\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]\b/;
const PAN_RE = /\b[A-Z]{5}\d{4}[A-Z]\b/;

const TAXABLE_LABELS =
  /(taxable\s*(value|amount)|basic\s*(value|amount)|sub\s*-?\s*total|subtotal|amount\s*before\s*tax|total\s*before\s*tax|professional\s*fees?|consultancy\s*fees?|consulting\s*fees?|service\s*charges?|professional\s*charges?|hire\s*charges?|rental\s*charges?|\bcharges?\b|\bfees?\b)/i;

const GROSS_LABELS =
  /(grand\s*total|total\s*invoice\s*value|invoice\s*total|amount\s*payable|total\s*amount|bill\s*total|net\s*payable|total\s*after\s*tax|\btotal\b)/i;

const GST_LABELS = /\b(c\s?gst|s\s?gst|ut\s?gst|i\s?gst|gst)\b/i;

const EXPLICIT_INVOICE_NO_RE =
  /(?:tax\s*invoice\s*(?:no|number|#)|invoice\s*(?:no|number|#)|bill\s*(?:no|number|#)|inv\s*(?:no|number|#))[\s.:#\-\u2010-\u2015]*([A-Za-z0-9][A-Za-z0-9/_\-.]{1,39})/i;

const FISCAL_INVOICE_RE = /\b20\d{2}\s*[-/]\s*\d{2}\s*[_/-]\s*[A-Za-z0-9][A-Za-z0-9_-]*\b/i;

const RESERVED_INVOICE_TOKENS = new Set([
  "date",
  "no",
  "number",
  "invoice",
  "bill",
  "tax",
]);

/** Lines that contain identifiers rather than commercial invoice amounts. */
const IDENTIFIER_LINE_RE =
  /(\bbank\s*details?\b|\bbank\s*name\b|\bcurrent\s*(?:a\/c|ac|account)\b|\bsavings?\s*(?:a\/c|ac|account)\b|\baccount\s*(?:no|number)\b|\ba\/c\s*(?:no|number)\b|\bac\s*(?:no|number)\b|\bifsc\b|\bmicr\b|\bswift\b|\bupi\b|\bgpay\b|\bphone\b|\bmobile\b|\btel(?:ephone)?\b|\bemail\b|\be-mail\b|\bgstin?\b|\bpan\s*(?:no|number)?\b|\bpin\s*code\b|\bpincode\b|\bpostal\s*code\b|\binvoice\s*(?:no|number|#)\b|\bbill\s*(?:no|number|#)\b|\bhsn\b|\bsac\b|\bbranch\b)/i;

const LINE_ITEM_HINT_RE =
  /(service|professional|consult|fee|fees|charges?|hire|rental|work|editing|production|advertis|design|audit|legal|technical|rent|commission|brokerage|transport|contract|labour|supply|goods|material|job\s*work|studio|equipment|machinery)/i;

const TABLE_HEADER_RE =
  /(?:description|discription|particulars).*\b(?:rate|qty|quantity)\b.*\btotal\b|\bsn\b.*\b(?:description|discription)\b.*\btotal\b/i;

const DATE_TOKEN_RE = /\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})\b/;

export interface AmountCandidate {
  value: number;
  label: string;
  lineIndex: number;
}

function normaliseLines(text: string): string[] {
  return text
    .split(/\n+/)
    .map((l) => l.replace(/\s+/g, " ").trim())
    .filter(Boolean);
}

/**
 * Values near a commercial label. Small numbers on a label line (e.g.
 * "Monthly 1") are treated as quantity/serial noise and the parser continues
 * to the next visual row until it finds a plausible money amount.
 */
function labelledCandidates(
  lines: string[],
  labels: RegExp,
  options: { skip?: RegExp; minDirect?: number; minForward?: number; forward?: number } = {},
): AmountCandidate[] {
  const out: AmountCandidate[] = [];
  const minDirect = options.minDirect ?? 100;
  const minForward = options.minForward ?? 100;
  const forward = options.forward ?? 6;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (!labels.test(line)) continue;
    if (options.skip && options.skip.test(line)) continue;
    if (TABLE_HEADER_RE.test(line)) continue;

    const direct = amountsInLine(line).filter((v) => v >= minDirect);
    if (direct.length) {
      out.push({ value: direct[direct.length - 1]!, label: line.slice(0, 90), lineIndex: i });
      continue;
    }

    for (let j = i + 1; j < Math.min(i + 1 + forward, lines.length); j++) {
      const nextLine = lines[j]!;
      if (GST_LABELS.test(nextLine) || GROSS_LABELS.test(nextLine)) {
        // For taxable labels we must not jump through GST/total rows.
        break;
      }
      if (IDENTIFIER_LINE_RE.test(nextLine)) continue;
      const values = amountsInLine(nextLine).filter((v) => v >= minForward);
      if (!values.length) continue;

      // Prefer the right-most / final number in an invoice table row. This is
      // normally the line total (e.g. "UNIT 1 ... 9000 9000" -> 9000).
      out.push({ value: values[values.length - 1]!, label: `${line} -> ${nextLine}`.slice(0, 90), lineIndex: j });
      break;
    }
  }

  return out;
}

function taxCandidates(lines: string[], labels: RegExp): AmountCandidate[] {
  const out: AmountCandidate[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (!labels.test(line)) continue;
    const values = amountsInLine(line);
    if (!values.length) continue;
    // 9% is filtered by money.ts; the final remaining value is the tax amount.
    out.push({ value: values[values.length - 1]!, label: line.slice(0, 90), lineIndex: i });
  }
  return out;
}

function grossCandidates(lines: string[]): AmountCandidate[] {
  const out: AmountCandidate[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (!GROSS_LABELS.test(line)) continue;
    if (/(before\s*tax|sub\s*-?\s*total|subtotal|taxable)/i.test(line)) continue;
    if (TABLE_HEADER_RE.test(line)) continue;

    const values = amountsInLine(line).filter((v) => v >= 100);
    if (values.length) {
      out.push({ value: values[values.length - 1]!, label: line.slice(0, 90), lineIndex: i });
      continue;
    }

    // If "Grand Total" is on one visual row and the amount on the next, allow
    // only a very short forward scan and never cross an identifier line.
    for (let j = i + 1; j < Math.min(i + 3, lines.length); j++) {
      const nextLine = lines[j]!;
      if (IDENTIFIER_LINE_RE.test(nextLine)) break;
      const next = amountsInLine(nextLine).filter((v) => v >= 100);
      if (next.length) {
        out.push({ value: next[next.length - 1]!, label: `${line} -> ${nextLine}`.slice(0, 90), lineIndex: j });
        break;
      }
    }
  }
  return out;
}

function pickLargest(cands: AmountCandidate[]): AmountCandidate | null {
  if (!cands.length) return null;
  return cands.reduce((a, b) => (b.value > a.value ? b : a));
}

function firstMatch(text: string, re: RegExp): string | null {
  const m = text.match(re);
  return m ? (m[1] ?? m[0]).trim() : null;
}

function validInvoiceNumber(raw: string | null): string | null {
  if (!raw) return null;
  const clean = raw.trim().replace(/[.,:;]+$/, "");
  if (clean.length < 2 || clean.length > 40) return null;
  if (RESERVED_INVOICE_TOKENS.has(clean.toLowerCase())) return null;
  if (!/\d/.test(clean)) return null;
  if (DATE_TOKEN_RE.test(clean)) return null;
  return clean;
}

function parseInvoiceNumber(lines: string[], joined: string): string | null {
  const explicit = validInvoiceNumber(firstMatch(joined, EXPLICIT_INVOICE_NO_RE));
  if (explicit) return explicit;

  // Very common Indian FY format: 2026-27_09, 2026-27/123, etc.
  for (const line of lines.slice(0, 12)) {
    const m = line.match(FISCAL_INVOICE_RE);
    if (m) return m[0].replace(/\s+/g, "");
  }

  // Header may be a separate PDF table cell: "Invoice no Date" on one row,
  // followed by the invoice number/date on the next visual row.
  const header = lines.findIndex((l) => /invoice\s*(?:no|number|#)/i.test(l));
  if (header >= 0) {
    for (let i = header; i <= Math.min(header + 2, lines.length - 1); i++) {
      const line = lines[i]!;
      const tokens = line.match(/[A-Za-z0-9][A-Za-z0-9/_\-.]{1,39}/g) ?? [];
      for (const token of tokens) {
        const candidate = validInvoiceNumber(token);
        if (!candidate) continue;
        if (/^20\d{2}$/.test(candidate)) continue;
        if (/^\d{5,6}$/.test(candidate) || /[_/-]/.test(candidate)) return candidate;
      }
    }
  }
  return null;
}

function toIsoDate(d: number, m: number, y: number): string | null {
  if (y < 100) y += 2000;
  if (!d || !m || d > 31 || m > 12 || y < 2000 || y > 2100) return null;
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function parseDate(lines: string[], joined: string): string | null {
  const labelled = joined.match(
    /(?:invoice\s*date|bill\s*date|dated|date)\s*[:\-]?\s*(\d{1,2})[/\-.\s]([A-Za-z]{3,9}|\d{1,2})[/\-.\s](\d{2,4})/i,
  );
  const months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  if (labelled) {
    const rawM = labelled[2]!;
    const month = /^\d+$/.test(rawM)
      ? Number(rawM)
      : months.findIndex((mm) => rawM.toLowerCase().startsWith(mm)) + 1;
    const iso = toIsoDate(Number(labelled[1]), month, Number(labelled[3]));
    if (iso) return iso;
  }

  // Prefer the document header. This avoids mistaking service-period dates
  // (1/4/26 to 30/4/26) for the invoice date.
  for (const line of lines.slice(0, 12)) {
    const m = line.match(DATE_TOKEN_RE);
    if (!m) continue;
    const iso = toIsoDate(Number(m[1]), Number(m[2]), Number(m[3]));
    if (iso) return iso;
  }
  return null;
}

function isLikelyVendorName(line: string): boolean {
  const clean = line.trim();
  if (clean.length < 3 || clean.length > 100) return false;
  if (!/[A-Za-z]{3}/.test(clean)) return false;
  if (/^(invoice|tax invoice|bill|original for recipient|to,?|for,?)$/i.test(clean)) return false;
  if (/gstin?|pan\b|phone|mobile|email|address|date\b|invoice\s*(?:no|number)|place of supply|bank|ifsc/i.test(clean)) return false;
  if (/\b(road|street|nagar|complex|tower|building|bldg|gala|near|mumbai|thane|road\s*[,-]|\d{6})\b/i.test(clean)) return false;
  return true;
}

function parseVendor(lines: string[], text: string): string | null {
  const labelled = firstMatch(text, /(?:vendor|supplier|seller|billed?\s*by|from)\s*(?:name)?\s*[:\-]\s*(.+)/i);
  if (labelled) return labelled.split(/\s{2,}|\|/)[0]!.trim().slice(0, 120);

  // PDF table headers often collapse vendor name + "Invoice no Date" into one line.
  for (const line of lines.slice(0, 8)) {
    const m = line.match(/^(.+?)\s+invoice\s*(?:no|number|#)?\b/i);
    if (m) {
      const prefix = m[1]!.trim();
      if (isLikelyVendorName(prefix)) return prefix.slice(0, 120);
    }
  }

  for (const line of lines.slice(0, 8)) {
    if (isLikelyVendorName(line)) return line.trim().slice(0, 120);
  }
  return null;
}

function parseVendorTaxIdentity(lines: string[], joined: string): { pan: string | null; gstin: string | null } {
  const labelledPan =
    joined.match(/\bpan\s*(?:no\.?|number)?\s*[:\-\u2010-\u2015]?\s*([A-Z]{5}\d{4}[A-Z])\b/i)?.[1]?.toUpperCase() ??
    null;

  // Prefer a GSTIN appearing before the buyer/customer section ("TO").
  const toIndex = lines.findIndex((l) => /^to\s*[,.:\-]?$/i.test(l.trim()) || /^bill(?:ed)?\s+to\b/i.test(l));
  const vendorRegion = (toIndex > 0 ? lines.slice(0, toIndex) : lines.slice(0, 12)).join("\n");
  const vendorGstinCandidate = vendorRegion.match(GSTIN_RE)?.[0] ?? joined.match(GSTIN_RE)?.[0] ?? null;

  const gstin =
    vendorGstinCandidate && (!labelledPan || vendorGstinCandidate.slice(2, 12) === labelledPan)
      ? vendorGstinCandidate
      : null;
  const pan = labelledPan ?? gstin?.slice(2, 12) ?? joined.match(PAN_RE)?.[0] ?? null;
  return { pan, gstin };
}

function descriptionFrom(lines: string[]): string | null {
  const natureIndex = lines.findIndex((l) =>
    /(being\s+towards|professional\s*fees?|consultancy|service\s+provided|service\s+rendered|hire\s*charges?|rental\s*charges?|nature\s*of\s*(service|work|payment)|technical\s*services?|commission|brokerage|contract\s*work)/i.test(l),
  );
  if (natureIndex >= 0) {
    return [lines[natureIndex], lines[natureIndex + 1] ?? "", lines[natureIndex + 2] ?? ""]
      .join(" ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 350);
  }

  const generic = lines.findIndex((l) => /\b(description|discription|particulars)\b/i.test(l) && !TABLE_HEADER_RE.test(l));
  if (generic >= 0) {
    return [lines[generic], lines[generic + 1] ?? "", lines[generic + 2] ?? ""]
      .join(" ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 350);
  }
  return null;
}

export interface DeterministicParse {
  fields: ExtractedFields;
  summary: string;
  amountsReliable: boolean;
  complete: boolean;
}

const EMPTY: ExtractedFields = {
  document_type: null,
  vendor_name: null,
  vendor_pan: null,
  vendor_gstin: null,
  invoice_number: null,
  invoice_date: null,
  description: null,
  printed_total: null,
  handwritten_adjustment: null,
  final_settlement_amount: null,
  gross_amount: null,
  taxable_value: null,
  cgst: null,
  sgst: null,
  igst: null,
  tds_base: null,
  payee_type: null,
  tds_category: null,
  confidence: null,
  field_confidence: {},
  notes: null,
  unreadable: false,
  review_reasons: [],
};

export function parseInvoiceText(text: string): DeterministicParse {
  const lines = normaliseLines(text);
  const joined = lines.join("\n");

  const taxableCands = labelledCandidates(lines, TAXABLE_LABELS, {
    skip: GST_LABELS,
    minDirect: 100,
    minForward: 100,
    forward: 6,
  });
  const cgst = pickLargest(taxCandidates(lines, /\bc\s?gst\b/i))?.value ?? null;
  const sgst = pickLargest(taxCandidates(lines, /\b(s\s?gst|ut\s?gst)\b/i))?.value ?? null;
  const igst = pickLargest(taxCandidates(lines, /\bi\s?gst\b/i))?.value ?? null;
  const grossCands = grossCandidates(lines);

  // Line-item fallback for invoices with no explicit "taxable/basic" label.
  const lineItemCands: AmountCandidate[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (GST_LABELS.test(line) || GROSS_LABELS.test(line) || IDENTIFIER_LINE_RE.test(line)) continue;
    if (TABLE_HEADER_RE.test(line) || !LINE_ITEM_HINT_RE.test(line)) continue;
    const values = amountsInLine(line).filter((v) => v >= 100);
    if (!values.length) continue;
    lineItemCands.push({ value: values[values.length - 1]!, label: line.slice(0, 90), lineIndex: i });
  }

  const gst = (cgst ?? 0) + (sgst ?? 0) + (igst ?? 0);
  const taxablePick = pickLargest(taxableCands);
  const grossPick = pickLargest(grossCands);
  let taxableValue = taxablePick?.value ?? null;
  let grossValue = grossPick?.value ?? null;
  let reason = "";
  const reviewReasons: string[] = [];

  if (taxableValue !== null) reason = `Base ${taxableValue} matched ${taxablePick!.label}`;

  // Arithmetic is stronger evidence than a nearby small quantity/rate. If GST
  // and gross are known, gross-GST must win whenever the labelled candidate is
  // absent or fails the arithmetic cross-check.
  if (grossValue !== null && gst > 0) {
    const arithmeticBase = grossValue - gst;
    if (arithmeticBase > 0 && (taxableValue === null || !approxEqual(taxableValue + gst, grossValue, 1))) {
      taxableValue = arithmeticBase;
      reason = `Base derived arithmetically: ${grossValue} - GST ${gst} = ${arithmeticBase}`;
    }
  }

  if (taxableValue === null && lineItemCands.length) {
    // Avoid double counting repeated RATE/TOTAL values by using distinct visual
    // line totals rather than blindly summing every numeric token.
    const byLine = new Map<number, number>();
    for (const c of lineItemCands) byLine.set(c.lineIndex, Math.max(byLine.get(c.lineIndex) ?? 0, c.value));
    const values = [...byLine.values()];
    taxableValue = values.reduce((sum, v) => sum + v, 0);
    reason = `Base ${taxableValue} derived from ${values.length} commercial line item(s)`;
  }

  if (taxableValue === null && grossValue !== null) {
    taxableValue = grossValue;
    reason = `GST not separately identifiable — gross ${grossValue} used as base`;
    reviewReasons.push("TDS Base requires review");
  }

  if (grossValue === null && taxableValue !== null) grossValue = taxableValue + gst;

  let amountsReliable = false;
  if (taxableValue !== null && grossValue !== null) {
    amountsReliable = approxEqual(taxableValue + gst, grossValue, 1);
    if (!amountsReliable && gst > 0) {
      const arithmeticBase = grossValue - gst;
      if (arithmeticBase > 0) {
        taxableValue = arithmeticBase;
        amountsReliable = true;
        reason = `Base corrected by GST cross-check: ${grossValue} - ${gst} = ${arithmeticBase}`;
      }
    }
  } else if (taxableValue !== null) {
    amountsReliable = true;
  }

  const invoiceNumber = parseInvoiceNumber(lines, joined);
  const invoiceDate = parseDate(lines, joined);
  const vendorName = parseVendor(lines, joined);
  const identity = parseVendorTaxIdentity(lines, joined);
  const description = descriptionFrom(lines);
  const rule = guessCategory(`${description ?? ""}\n${joined.slice(0, 2500)}`);

  const fields: ExtractedFields = {
    ...EMPTY,
    document_type: /tax\s*invoice/i.test(joined)
      ? "Tax Invoice"
      : /invoice/i.test(joined)
        ? "Invoice"
        : /receipt/i.test(joined)
          ? "Receipt"
          : null,
    vendor_name: vendorName,
    vendor_gstin: identity.gstin,
    vendor_pan: identity.pan,
    invoice_number: invoiceNumber,
    invoice_date: invoiceDate,
    description,
    taxable_value: taxableValue,
    cgst,
    sgst,
    igst,
    gross_amount: grossValue,
    tds_base: taxableValue,
    tds_category: rule?.label ?? null,
    notes: `Deterministic PDF parser. ${reason || "Amounts extracted from labelled invoice rows."}`,
    review_reasons: reviewReasons,
  };

  const complete =
    Boolean(fields.vendor_name) &&
    Boolean(fields.invoice_date) &&
    Boolean(fields.invoice_number) &&
    Boolean(fields.tds_base && fields.tds_base > 0) &&
    Boolean(fields.tds_category);

  if (import.meta.env?.DEV) {
    console.debug("[invoice-parse:v5]", {
      vendorName,
      invoiceNumber,
      invoiceDate,
      taxableCandidates: taxableCands,
      grossCandidates: grossCands,
      lineItemCandidates: lineItemCands,
      cgst,
      sgst,
      igst,
      selectedBase: taxableValue,
      selectedGross: grossValue,
      category: fields.tds_category,
      reason,
    });
  }

  const contextLines = lines
    .filter((l) => /(description|discription|particulars|nature|service|work|professional|rent|hire|commission|contract|interest|goods|consult|fee|charges|supply|hsn|sac)/i.test(l))
    .slice(0, 14);
  const summary = [
    `Vendor: ${fields.vendor_name ?? "unknown"}`,
    `Invoice: ${fields.invoice_number ?? "unknown"}`,
    `Date: ${fields.invoice_date ?? "unknown"}`,
    `Taxable value: ${taxableValue ?? "unknown"}`,
    `GST: ${gst || "0"}`,
    `Gross: ${grossValue ?? "unknown"}`,
    "Commercial lines:",
    ...(contextLines.length ? contextLines : lines.slice(0, 12)),
  ]
    .join("\n")
    .slice(0, 2000);

  return { fields, summary, amountsReliable, complete };
}
