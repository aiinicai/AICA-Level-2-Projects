import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const settingsInput = z.object({
  ai_provider: z.enum(["builtin", "gemini", "openai", "local"]),
  model: z.string().min(1),
  confidence_threshold: z.number().min(0.1).max(1),
  enable_vision: z.boolean(),
  api_key: z.string().optional().nullable(),
  clear_api_key: z.boolean().optional(),
});

export const saveAppSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => settingsInput.parse(data))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const payload: Record<string, unknown> = {
      user_id: context.userId,
      ai_provider: data.ai_provider,
      model: data.model,
      confidence_threshold: data.confidence_threshold,
      enable_vision: data.enable_vision,
      updated_at: new Date().toISOString(),
    };

    const key = data.api_key?.trim();
    if (data.clear_api_key) {
      payload["api_key"] = null;
      payload["has_api_key"] = false;
    } else if (key) {
      payload["api_key"] = key;
      payload["has_api_key"] = true;
    }

    const { error } = await supabaseAdmin
      .from("app_settings")
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .upsert(payload as any, { onConflict: "user_id" });
    if (error) throw new Error(error.message);

    return { ok: true, has_api_key: data.clear_api_key ? false : Boolean(key) };
  });
