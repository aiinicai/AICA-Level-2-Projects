/**
 * Provider adapters for document extraction.
 * Never import this from a component — it is server-only.
 */

export interface ExtractedFields {
  document_type: string | null;
  vendor_name: string | null;
  vendor_pan: string | null;
  vendor_gstin: string | null;
  invoice_number: string | null;
  invoice_date: string | null;
  description: string | null;
  printed_total: number | null;
  handwritten_adjustment: number | null;
  final_settlement_amount: number | null;
  gross_amount: number | null;
  taxable_value: number | null;
  cgst: number | null;
  sgst: number | null;
  igst: number | null;
  tds_base: number | null;
  payee_type: string | null;
  tds_category: string | null;
  confidence: number | null;
  field_confidence: Record<string, number>;
  notes: string | null;
  unreadable: boolean;
  review_reasons: string[];
}

const CATEGORY_LIST = [
  "Professional Services",
  "Technical Services",
  "Contractor / Work",
  "Commission / Brokerage",
  "Rent - Land / Building / Furniture",
  "Rent / Hire - Plant, Machinery, Equipment",
  "Interest - General",
  "Purchase of Goods",
  "Partner Remuneration / Commission / Bonus / Interest",
  "Purchase of Immovable Property",
];

export const EXTRACTION_PROMPT = `You are a senior Indian Chartered Accountant's document analyst. Read the attached document (it may be a digital invoice, a scanned bill, a photograph, a service statement or a handwritten note) and return ONE JSON object only. No prose, no markdown fences.

JSON shape (use null when a value is genuinely not present or not readable):
{
  "document_type": string,
  "vendor_name": string,
  "vendor_pan": string,
  "vendor_gstin": string,
  "invoice_number": string,
  "invoice_date": "YYYY-MM-DD",
  "description": string,
  "printed_total": number,
  "handwritten_adjustment": number,
  "final_settlement_amount": number,
  "gross_amount": number,
  "taxable_value": number,
  "cgst": number,
  "sgst": number,
  "igst": number,
  "tds_base": number,
  "payee_type": "Individual/HUF" | "Company" | "Firm/LLP" | "Other",
  "tds_category": one of ${JSON.stringify(CATEGORY_LIST)},
  "confidence": number between 0 and 1,
  "field_confidence": { "<field name>": number between 0 and 1 },
  "notes": string explaining your reasoning,
  "unreadable": boolean,
  "review_reasons": string[]
}

Hard rules:
1. NEVER convert an unreadable or uncertain amount to 0. Use null and add a review reason.
2. If the document has printed charges and handwritten settlement figures, report printed_total, handwritten_adjustment and final_settlement_amount separately. When the final handwritten figure clearly represents the amount payable/credited to the vendor, use it as tds_base.
3. Where GST is shown separately, exclude it from tds_base (tds_base is normally the taxable value / amount credited before GST).
4. Never read a GST rate such as 9%, 18% or 2.5% as a money amount.
5. Diagnostic centre, ultrasound, pathology, X-ray and other medical diagnostic services are normally "Professional Services" unless the facts clearly say otherwise.
6. If the document is not readable, is blurred, or any critical field (vendor name, date, amount, nature of payment) is unreliable, set "unreadable": true and list precisely what a human must confirm in review_reasons, e.g. "Confirm Vendor Name", "Confirm Invoice Date", "Confirm Invoice Number", "Confirm TDS Base", "Confirm handwritten settlement amount", "Confirm nature of payment", "Confirm TDS category".
7. Amounts must be plain numbers without commas or currency symbols.`;

type Part =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } }
  | { type: "file"; file: { filename: string; file_data: string } };

function buildParts(fileName: string, mimeType: string, dataUrl: string): Part[] {
  const parts: Part[] = [{ type: "text", text: EXTRACTION_PROMPT }];
  if (mimeType === "application/pdf") {
    parts.push({ type: "file", file: { filename: fileName, file_data: dataUrl } });
  } else {
    parts.push({ type: "image_url", image_url: { url: dataUrl } });
  }
  return parts;
}

interface ProviderConfig {
  provider: string;
  model: string;
  apiKey?: string | null;
}

function endpointFor(provider: string): { url: string; key: string } {
  if (provider === "gemini") {
    return {
      url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
      key: "",
    };
  }
  if (provider === "openai") {
    return { url: "https://api.openai.com/v1/chat/completions", key: "" };
  }
  return { url: "https://ai.gateway.lovable.dev/v1/chat/completions", key: "" };
}

function resolveKey(cfg: ProviderConfig): string {
  if (cfg.provider === "builtin") {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("The built-in AI service is not available right now.");
    return key;
  }
  if (!cfg.apiKey) {
    throw new Error("No API key is saved for the selected AI provider. Add one in Settings.");
  }
  return cfg.apiKey;
}

function parseJson(text: string): Record<string, unknown> {
  const cleaned = text
    .trim()
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  try {
    return JSON.parse(cleaned) as Record<string, unknown>;
  } catch {
    const first = cleaned.indexOf("{");
    const last = cleaned.lastIndexOf("}");
    if (first >= 0 && last > first) {
      return JSON.parse(cleaned.slice(first, last + 1)) as Record<string, unknown>;
    }
    throw new Error("The AI reply could not be read as structured data.");
  }
}

const num = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(String(v).replace(/[,\s₹Rs]/gi, ""));
  return isFinite(n) ? n : null;
};
const str = (v: unknown): string | null => {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s === "" || s.toLowerCase() === "null" ? null : s;
};

export function normalise(raw: Record<string, unknown>): ExtractedFields {
  const fc = (raw["field_confidence"] ?? {}) as Record<string, unknown>;
  const reasons = Array.isArray(raw["review_reasons"])
    ? (raw["review_reasons"] as unknown[]).map((r) => String(r)).filter(Boolean)
    : [];
  return {
    document_type: str(raw["document_type"]),
    vendor_name: str(raw["vendor_name"]),
    vendor_pan: str(raw["vendor_pan"]),
    vendor_gstin: str(raw["vendor_gstin"]),
    invoice_number: str(raw["invoice_number"]),
    invoice_date: str(raw["invoice_date"]),
    description: str(raw["description"]),
    printed_total: num(raw["printed_total"]),
    handwritten_adjustment: num(raw["handwritten_adjustment"]),
    final_settlement_amount: num(raw["final_settlement_amount"]),
    gross_amount: num(raw["gross_amount"]),
    taxable_value: num(raw["taxable_value"]),
    cgst: num(raw["cgst"]),
    sgst: num(raw["sgst"]),
    igst: num(raw["igst"]),
    tds_base: num(raw["tds_base"]),
    payee_type: str(raw["payee_type"]),
    tds_category: str(raw["tds_category"]),
    confidence: num(raw["confidence"]),
    field_confidence: Object.fromEntries(
      Object.entries(fc).map(([k, v]) => [k, num(v) ?? 0]),
    ),
    notes: str(raw["notes"]),
    unreadable: raw["unreadable"] === true,
    review_reasons: reasons,
  };
}

export async function callVisionProvider(
  cfg: ProviderConfig,
  fileName: string,
  mimeType: string,
  dataUrl: string,
): Promise<ExtractedFields> {
  const { url } = endpointFor(cfg.provider);
  const key = resolveKey(cfg);

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: cfg.model,
      messages: [{ role: "user", content: buildParts(fileName, mimeType, dataUrl) }],
    }),
  });

  if (response.status === 429) {
    throw new Error("The AI service is busy. Please wait a moment and try again.");
  }
  if (response.status === 402) {
    throw new Error("AI credits are exhausted. Please top up your workspace to continue.");
  }
  if (!response.ok) {
    const detail = await response.text();
    console.error("[extraction] provider error", response.status, detail.slice(0, 500));
    throw new Error("The document could not be read by the AI service. Please try again.");
  }

  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = payload.choices?.[0]?.message?.content ?? "";
  if (!content) throw new Error("The AI service returned an empty reply.");
  return normalise(parseJson(content));
}

export async function pingProvider(cfg: ProviderConfig): Promise<string> {
  const { url } = endpointFor(cfg.provider);
  const key = resolveKey(cfg);
  const response = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: cfg.model,
      messages: [{ role: "user", content: "Reply with the single word: ready" }],
    }),
  });
  if (!response.ok) {
    const detail = await response.text();
    console.error("[extraction] ping failed", response.status, detail.slice(0, 300));
    if (response.status === 401 || response.status === 403) {
      throw new Error("That API key was not accepted by the provider.");
    }
    throw new Error(`The provider replied with an error (${response.status}).`);
  }
  return "Connection successful.";
}
