import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TAX_YEAR, TDS_RULES } from "@/lib/tds/rules";

export const Route = createFileRoute("/rules")({
  head: () => ({
    meta: [
      { title: "TDS Rules 2026-27 | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Section-wise TDS rates and thresholds applied by the assistant for tax year 2026-27, including 194C, 194J, 194H, 194I, 194A, 194Q, 194T and 194-IA.",
      },
      { property: "og:title", content: "TDS Rules 2026-27 | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "Rates and thresholds for 194C, 194J, 194H, 194I, 194A, 194Q, 194T and 194-IA.",
      },
    ],
  }),
  component: RulesPage,
});

function RulesPage() {
  return (
    <AppShell
      title="TDS Rules"
      subtitle={`Rates and thresholds applied by the engine for tax year ${TAX_YEAR}`}
    >
      <div className="grid gap-4 lg:grid-cols-2">
        {TDS_RULES.map((rule) => (
          <Card key={rule.key}>
            <CardHeader className="pb-2">
              <CardTitle className="flex flex-wrap items-baseline gap-2 text-base">
                {rule.label}
                <span className="rounded bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground">
                  {rule.currentSection}
                </span>
                <span className="text-xs font-normal text-muted-foreground">
                  earlier {rule.legacySection}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5 text-sm text-muted-foreground">
              <p>
                <span className="font-medium text-foreground">Rate:</span> {rule.rateText}
              </p>
              <p>
                <span className="font-medium text-foreground">Threshold:</span> {rule.thresholdText}
              </p>
              {rule.notes ? <p>{rule.notes}</p> : null}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">How cumulative and catch-up TDS is computed</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>
            Every vendor has one running chain per section. Each new bill adds its GST-excluded base
            to the chain, so the register always shows the previous cumulative and the new cumulative.
          </p>
          <p>
            When the chain crosses the threshold, the engine works out the tax legally required on the
            whole qualifying amount, subtracts what was already required earlier, and books the
            difference. The part relating to earlier bills is shown separately as catch-up TDS.
          </p>
          <p>
            Rent under 194-I is chained month by month, purchases under 194Q are taxed only on the
            excess over the threshold, and property purchases under 194-IA are judged per transaction.
          </p>
        </CardContent>
      </Card>
    </AppShell>
  );
}
