import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { listInvoices } from "@/lib/invoices";
import { inr } from "@/lib/format";

export const Route = createFileRoute("/summary")({
  head: () => ({
    meta: [
      { title: "Vendor & Section Summary | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Vendor-wise and section-wise TDS summaries showing cumulative base, catch-up deductions and total tax payable.",
      },
      { property: "og:title", content: "Vendor & Section Summary | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "Vendor-wise and section-wise cumulative TDS totals for the tax year.",
      },
    ],
  }),
  component: SummaryPage,
});

function SummaryPage() {
  const { data: rows = [] } = useQuery({ queryKey: ["invoices"], queryFn: listInvoices });
  const active = rows.filter((r) => !r.is_duplicate);

  const vendors = new Map<
    string,
    { pan: string | null; docs: number; base: number; catchup: number; tds: number; sections: Set<string> }
  >();
  for (const r of active) {
    const cur =
      vendors.get(r.vendor_name) ??
      { pan: r.vendor_pan, docs: 0, base: 0, catchup: 0, tds: 0, sections: new Set<string>() };
    cur.docs += 1;
    cur.base += r.tds_base ?? 0;
    cur.catchup += r.catchup_tds;
    cur.tds += r.tds_now;
    if (r.current_section) cur.sections.add(r.current_section);
    if (!cur.pan && r.vendor_pan) cur.pan = r.vendor_pan;
    vendors.set(r.vendor_name, cur);
  }

  const sections = new Map<string, { docs: number; base: number; tds: number }>();
  for (const r of active) {
    const key = r.current_section ?? "Unclassified";
    const cur = sections.get(key) ?? { docs: 0, base: 0, tds: 0 };
    cur.docs += 1;
    cur.base += r.tds_base ?? 0;
    cur.tds += r.tds_now;
    sections.set(key, cur);
  }

  return (
    <AppShell title="Summaries" subtitle="Vendor-wise and section-wise position for the tax year">
      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Vendor summary</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                  <th className="py-2 pr-3 font-medium">Vendor</th>
                  <th className="py-2 pr-3 font-medium">Sections</th>
                  <th className="py-2 pr-3 text-right font-medium">Docs</th>
                  <th className="py-2 pr-3 text-right font-medium">Base</th>
                  <th className="py-2 pr-3 text-right font-medium">Catch-up</th>
                  <th className="py-2 text-right font-medium">TDS</th>
                </tr>
              </thead>
              <tbody>
                {vendors.size === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-muted-foreground">
                      No vendor activity yet.
                    </td>
                  </tr>
                ) : (
                  Array.from(vendors.entries())
                    .sort((a, b) => b[1].base - a[1].base)
                    .map(([name, v]) => (
                      <tr key={name} className="border-b border-border/60 last:border-0">
                        <td className="max-w-[190px] py-2 pr-3">
                          <div className="truncate font-medium">{name}</div>
                          <div className="text-xs text-muted-foreground">{v.pan ?? "PAN not captured"}</div>
                        </td>
                        <td className="py-2 pr-3 text-xs text-muted-foreground">
                          {Array.from(v.sections).join(", ") || "—"}
                        </td>
                        <td className="py-2 pr-3 text-right tabular-nums">{v.docs}</td>
                        <td className="py-2 pr-3 text-right tabular-nums">{inr(v.base)}</td>
                        <td className="py-2 pr-3 text-right tabular-nums text-status-review-fg">
                          {v.catchup ? inr(v.catchup) : "—"}
                        </td>
                        <td className="py-2 text-right font-medium tabular-nums">{inr(v.tds)}</td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Section summary</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                  <th className="py-2 pr-3 font-medium">Section</th>
                  <th className="py-2 pr-3 text-right font-medium">Docs</th>
                  <th className="py-2 pr-3 text-right font-medium">Base</th>
                  <th className="py-2 text-right font-medium">TDS</th>
                </tr>
              </thead>
              <tbody>
                {sections.size === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted-foreground">
                      Nothing classified yet.
                    </td>
                  </tr>
                ) : (
                  Array.from(sections.entries())
                    .sort((a, b) => b[1].tds - a[1].tds)
                    .map(([name, s]) => (
                      <tr key={name} className="border-b border-border/60 last:border-0">
                        <td className="py-2 pr-3 font-medium">{name}</td>
                        <td className="py-2 pr-3 text-right tabular-nums">{s.docs}</td>
                        <td className="py-2 pr-3 text-right tabular-nums">{inr(s.base)}</td>
                        <td className="py-2 text-right font-medium tabular-nums">{inr(s.tds)}</td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
