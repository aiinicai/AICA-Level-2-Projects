import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Download, Search, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { AppShell } from "@/components/AppShell";
import { StatusBadge } from "@/components/StatusBadge";
import { InvoiceEditor } from "@/components/InvoiceEditor";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { deleteInvoice, listInvoices, type InvoiceRow } from "@/lib/invoices";
import { exportRegister } from "@/lib/export";
import { inr, shortDate } from "@/lib/format";

const search = z.object({ view: z.enum(["all", "review", "duplicates"]).optional() });

export const Route = createFileRoute("/register")({
  validateSearch: search,
  head: () => ({
    meta: [
      { title: "TDS Register | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Complete TDS register with cumulative vendor totals, catch-up deductions, review queue and Excel export.",
      },
      { property: "og:title", content: "TDS Register | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "Cumulative vendor totals, catch-up TDS, review queue and one-click Excel export.",
      },
    ],
  }),
  component: RegisterPage,
});

function RegisterPage() {
  const { view = "all" } = Route.useSearch();
  const navigate = Route.useNavigate();
  const qc = useQueryClient();
  const { data: rows = [], isLoading } = useQuery({ queryKey: ["invoices"], queryFn: listInvoices });
  const [query, setQuery] = useState("");
  const [searchField, setSearchField] = useState<
    "all" | "vendor" | "invoice" | "category" | "section" | "tds_status" | "review_status"
  >("all");
  const [dropdownValue, setDropdownValue] = useState("all");
  const [selected, setSelected] = useState<InvoiceRow | null>(null);

  const dropdownOptions = useMemo(() => {
    if (searchField === "all") return [];

    const values = rows
      .map((r) => {
        switch (searchField) {
          case "vendor":
            return r.vendor_name;
          case "invoice":
            return r.invoice_number;
          case "category":
            return r.tds_category;
          case "section":
            return r.current_section;
          case "tds_status":
            return r.is_duplicate ? "DUPLICATE" : r.tds_status;
          case "review_status":
            return r.review_status;
          default:
            return null;
        }
      })
      .filter((value): value is string => Boolean(value && String(value).trim()))
      .map((value) => String(value).trim());

    return Array.from(new Set(values)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  }, [rows, searchField]);

  const clearSearchFilters = () => {
    setQuery("");
    setSearchField("all");
    setDropdownValue("all");
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (view === "review" && r.review_status === "APPROVED") return false;
      if (view === "duplicates" && !r.is_duplicate) return false;

      if (searchField !== "all" && dropdownValue !== "all") {
        let rowValue: string | null | undefined;
        switch (searchField) {
          case "vendor":
            rowValue = r.vendor_name;
            break;
          case "invoice":
            rowValue = r.invoice_number;
            break;
          case "category":
            rowValue = r.tds_category;
            break;
          case "section":
            rowValue = r.current_section;
            break;
          case "tds_status":
            rowValue = r.is_duplicate ? "DUPLICATE" : r.tds_status;
            break;
          case "review_status":
            rowValue = r.review_status;
            break;
        }
        if (String(rowValue ?? "").trim() !== dropdownValue) return false;
      }

      if (!q) return true;

      const searchableValues =
        searchField === "all"
          ? [r.vendor_name, r.invoice_number, r.tds_category, r.description, r.current_section]
          : searchField === "vendor"
            ? [r.vendor_name]
            : searchField === "invoice"
              ? [r.invoice_number]
              : searchField === "category"
                ? [r.tds_category]
                : searchField === "section"
                  ? [r.current_section]
                  : searchField === "tds_status"
                    ? [r.is_duplicate ? "DUPLICATE" : r.tds_status]
                    : [r.review_status];

      return searchableValues
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q));
    });
  }, [rows, view, query, searchField, dropdownValue]);

  const remove = async (row: InvoiceRow) => {
    try {
      await deleteInvoice(row);
      await qc.invalidateQueries({ queryKey: ["invoices"] });
      toast.success("Document removed and register recalculated.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The document could not be removed.");
    }
  };

  const totals = filtered.reduce(
    (a, r) => ({
      base: a.base + (r.is_duplicate ? 0 : r.tds_base ?? 0),
      catchup: a.catchup + r.catchup_tds,
      tds: a.tds + r.tds_now,
    }),
    { base: 0, catchup: 0, tds: 0 },
  );

  return (
    <AppShell
      title="TDS Register"
      subtitle="Every document, its cumulative position and the tax to be deducted"
      actions={
        <Button onClick={() => exportRegister(rows)} disabled={!rows.length}>
          <Download className="size-4" /> Export to Excel
        </Button>
      }
    >
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[240px] flex-1">
              <Search className="absolute top-2.5 left-3 size-4 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Type to search the register"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>

            <Select
              value={searchField}
              onValueChange={(v) => {
                setSearchField(
                  v as "all" | "vendor" | "invoice" | "category" | "section" | "tds_status" | "review_status",
                );
                setDropdownValue("all");
              }}
            >
              <SelectTrigger className="w-[170px]">
                <SelectValue placeholder="Search by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All fields</SelectItem>
                <SelectItem value="vendor">Vendor</SelectItem>
                <SelectItem value="invoice">Invoice No.</SelectItem>
                <SelectItem value="category">Category</SelectItem>
                <SelectItem value="section">Section</SelectItem>
                <SelectItem value="tds_status">TDS Status</SelectItem>
                <SelectItem value="review_status">Review Status</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={dropdownValue}
              disabled={searchField === "all"}
              onValueChange={setDropdownValue}
            >
              <SelectTrigger className="w-[220px]">
                <SelectValue placeholder="Select value" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  {searchField === "all" ? "Choose a field first" : "All values"}
                </SelectItem>
                {dropdownOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={view}
              onValueChange={(v) =>
                navigate({ search: { view: v as "all" | "review" | "duplicates" } })
              }
            >
              <SelectTrigger className="w-[170px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All documents</SelectItem>
                <SelectItem value="review">Pending review</SelectItem>
                <SelectItem value="duplicates">Duplicates</SelectItem>
              </SelectContent>
            </Select>

            {(query || searchField !== "all" || dropdownValue !== "all") && (
              <Button variant="outline" onClick={clearSearchFilters}>
                <X className="size-4" /> Clear
              </Button>
            )}
          </div>

          <div className="mt-2 text-xs text-muted-foreground">
            Showing {filtered.length} of {rows.length} documents
          </div>

          <div className="mt-4 -mx-6 overflow-x-auto px-6">
            <table className="w-full min-w-[1200px] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs whitespace-nowrap text-muted-foreground uppercase">
                  <th className="py-2 pr-3 font-medium">Date</th>
                  <th className="py-2 pr-3 font-medium">Vendor</th>
                  <th className="py-2 pr-3 font-medium">Invoice</th>
                  <th className="py-2 pr-3 font-medium">Category</th>
                  <th className="py-2 pr-3 font-medium">Section</th>
                  <th className="py-2 pr-3 text-right font-medium">Base</th>
                  <th className="py-2 pr-3 text-right font-medium">Prev. cum.</th>
                  <th className="py-2 pr-3 text-right font-medium">New cum.</th>
                  <th className="py-2 pr-3 text-right font-medium">Rate</th>
                  <th className="py-2 pr-3 text-right font-medium">Catch-up</th>
                  <th className="py-2 pr-3 text-right font-medium">TDS now</th>
                  <th className="py-2 pr-3 font-medium">TDS status</th>
                  <th className="py-2 pr-3 font-medium">Review</th>
                  <th className="py-2 font-medium" />
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={14} className="py-10 text-center text-muted-foreground">
                      Loading register…
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={14} className="py-10 text-center text-muted-foreground">
                      No documents match this view.
                    </td>
                  </tr>
                ) : (
                  filtered.map((r) => (
                    <tr
                      key={r.id}
                      className="cursor-pointer border-b border-border/60 hover:bg-accent/40"
                      onClick={() => setSelected(r)}
                    >
                      <td className="py-2 pr-3 whitespace-nowrap text-muted-foreground">
                        {shortDate(r.invoice_date)}
                      </td>
                      <td className="max-w-[190px] truncate py-2 pr-3 font-medium">{r.vendor_name}</td>
                      <td className="max-w-[140px] truncate py-2 pr-3 text-muted-foreground">
                        {r.invoice_number ?? "—"}

                      </td>
                      <td className="max-w-[170px] truncate py-2 pr-3">{r.tds_category ?? "—"}</td>
                      <td className="py-2 pr-3 whitespace-nowrap text-muted-foreground">
                        {r.current_section ?? "—"}
                      </td>
                      <td className="py-2 pr-3 text-right tabular-nums">{inr(r.tds_base)}</td>
                      <td className="py-2 pr-3 text-right tabular-nums text-muted-foreground">
                        {inr(r.previous_cumulative)}
                      </td>
                      <td className="py-2 pr-3 text-right tabular-nums">{inr(r.new_cumulative)}</td>
                      <td className="py-2 pr-3 text-right tabular-nums">{r.tds_rate ? `${r.tds_rate}%` : "—"}</td>
                      <td className="py-2 pr-3 text-right tabular-nums text-status-review-fg">
                        {r.catchup_tds ? inr(r.catchup_tds) : "—"}
                      </td>
                      <td className="py-2 pr-3 text-right font-medium tabular-nums">{inr(r.tds_now)}</td>
                      <td className="py-2 pr-3">
                        <StatusBadge value={r.is_duplicate ? "DUPLICATE" : r.tds_status} />
                      </td>
                      <td className="py-2 pr-3">
                        <StatusBadge value={r.review_status} />
                      </td>
                      <td className="py-2 text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            void remove(r);
                          }}
                        >
                          <Trash2 className="size-4 text-muted-foreground" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {filtered.length ? (
                <tfoot>
                  <tr className="border-t-2 border-border font-medium">
                    <td className="py-2 pr-3" colSpan={5}>
                      Totals ({filtered.length} documents)
                    </td>
                    <td className="py-2 pr-3 text-right tabular-nums">{inr(totals.base)}</td>
                    <td colSpan={3} />
                    <td className="py-2 pr-3 text-right tabular-nums">{inr(totals.catchup)}</td>
                    <td className="py-2 pr-3 text-right tabular-nums">{inr(totals.tds)}</td>
                    <td colSpan={3} />
                  </tr>
                </tfoot>
              ) : null}
            </table>
          </div>
        </CardContent>
      </Card>

      <InvoiceEditor
        row={selected}
        open={!!selected}
        onOpenChange={(o) => !o && setSelected(null)}
        onSaved={() => qc.invalidateQueries({ queryKey: ["invoices"] })}
      />
    </AppShell>
  );
}
