import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { CheckCircle2, FileWarning, Loader2, UploadCloud, X } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { StatusBadge } from "@/components/StatusBadge";
import { SpreadsheetImport } from "@/components/SpreadsheetImport";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AI_UNAVAILABLE_MESSAGE, processDocument } from "@/lib/process-upload";
import { recalculateRegister, saveExtractedInvoice, sha256 } from "@/lib/invoices";
import { inr } from "@/lib/format";


export const Route = createFileRoute("/upload")({
  head: () => ({
    meta: [
      { title: "Upload Documents | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Upload invoices, scanned bills, photographs and handwritten notes for AI extraction and TDS classification.",
      },
      { property: "og:title", content: "Upload Documents | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "AI extraction for invoices, scans, photos and handwritten bills.",
      },
    ],
  }),
  component: UploadPage,
});

interface Job {
  name: string;
  state: "queued" | "reading" | "extracting" | "done" | "error";
  message?: string;
  vendor?: string;
  base?: number | null;
  status?: string;
  review?: string;
}

const ACCEPT = ".pdf,.png,.jpg,.jpeg,.webp,.heic,.tif,.tiff";

function UploadPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [running, setRunning] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const folderInput = useRef<HTMLInputElement>(null);

  const update = (index: number, patch: Partial<Job>) =>
    setJobs((prev) => prev.map((j, i) => (i === index ? { ...j, ...patch } : j)));

  const CONCURRENCY = 4;

  const runOne = async (file: File, index: number) => {
    if (!user) return;
    try {
      update(index, { state: "reading" });
      const hash = await sha256(file);

      const path = `${user.id}/${hash}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const uploadPromise = supabase.storage
        .from("invoice-docs")
        .upload(path, file, { upsert: true, contentType: file.type || "application/octet-stream" });

      update(index, { state: "extracting" });
      const [result, upload] = await Promise.all([
        processDocument(user.id, file, hash),
        uploadPromise,
      ]);
      if (result.warning) toast.warning(result.warning);

      const saved = await saveExtractedInvoice({
        userId: user.id,
        fields: result.fields,
        extractionMethod: result.extraction_method,
        confidenceThreshold: result.confidence_threshold,
        fileName: file.name,
        filePath: upload.error ? null : path,
        fileHash: hash,
      });

      update(index, {
        state: "done",
        vendor: saved.vendor_name,
        base: saved.tds_base,
        status: saved.is_duplicate ? "DUPLICATE" : saved.review_status,
        review: saved.review_reasons.join(", "),
      });
      if (saved.is_duplicate) toast.warning(`${file.name}: duplicate invoice — not analysed again.`);
    } catch (error) {
      const raw = error instanceof Error ? error.message : "";
      const creditIssue = /credit|quota|busy|429|402|unavailable/i.test(raw);
      update(index, {
        state: "error",
        message: creditIssue ? AI_UNAVAILABLE_MESSAGE : raw || "The document could not be processed.",
      });
    }
  };

  const process = async (files: File[]) => {
    if (!user) return;
    const usable = files.filter((f) => /pdf|image/i.test(f.type) || /\.(pdf|png|jpe?g|webp|tiff?|heic)$/i.test(f.name));
    if (!usable.length) {
      toast.error("No readable documents found. Upload PDFs or images.");
      return;
    }
    setJobs(usable.map((f) => ({ name: f.name, state: "queued" as const })));
    setRunning(true);

    // Independent, parallel processing with a safe concurrency limit:
    // one difficult invoice never blocks the rest.
    let cursor = 0;
    const worker = async () => {
      while (cursor < usable.length) {
        const index = cursor++;
        await runOne(usable[index]!, index);
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(CONCURRENCY, usable.length) }, () => worker()),
    );

    // Reconcile duplicates and cumulative chains ONCE after the whole batch.
    // This avoids parallel recalculations racing with each other and ensures
    // historical invoices already in the register are included consistently.
    await recalculateRegister();
    await qc.invalidateQueries({ queryKey: ["invoices"] });

    setRunning(false);
    toast.success(
      usable.length === 1
        ? "Invoice processed and added to TDS Register."
        : `${usable.length} invoices processed and added to TDS Register.`,
    );
  };

  const done = jobs.filter((j) => j.state === "done" || j.state === "error").length;
  const successful = jobs.filter(
    (j) => j.state === "done" && j.status !== "REVIEW",
  ).length;
  const needsReview = jobs.filter(
    (j) => j.state === "done" && j.status === "REVIEW",
  ).length;

  return (
    <AppShell
      title="Upload Documents"
      subtitle="PDFs read locally and posted straight to the TDS Register — no AI in the normal path"
    >

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent className="pt-6">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                void process(Array.from(e.dataTransfer.files));
              }}
              className={`flex flex-col items-center justify-center rounded border-2 border-dashed px-6 py-14 text-center transition-colors ${
                dragOver ? "border-primary bg-accent/50" : "border-border bg-muted/40"
              }`}
            >
              <UploadCloud className="size-8 text-muted-foreground" />
              <p className="mt-3 font-medium text-foreground">Drop invoices here</p>
              <p className="mt-1 text-sm text-muted-foreground">
                PDF, JPG, PNG, TIFF or WEBP · single files, a batch, or a whole folder
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                <Button disabled={running} onClick={() => fileInput.current?.click()}>
                  Select files
                </Button>
                <Button variant="outline" disabled={running} onClick={() => folderInput.current?.click()}>
                  Select folder
                </Button>
              </div>
              <input
                ref={fileInput}
                type="file"
                multiple
                accept={ACCEPT}
                className="hidden"
                onChange={(e) => {
                  void process(Array.from(e.target.files ?? []));
                  e.target.value = "";
                }}
              />
              <input
                ref={folderInput}
                type="file"
                multiple
                className="hidden"
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                {...({ webkitdirectory: "", directory: "" } as any)}
                onChange={(e) => {
                  void process(Array.from(e.target.files ?? []));
                  e.target.value = "";
                }}
              />
            </div>

            {jobs.length ? (
              <div className="mt-6">
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    Processed {done} / {jobs.length} · Successful {successful} · Review required{" "}
                    {needsReview}
                  </span>

                  {running ? (
                    <span className="flex items-center gap-2 text-muted-foreground">
                      <Loader2 className="size-4 animate-spin" /> Working…
                    </span>
                  ) : (
                    <Button variant="ghost" size="sm" onClick={() => setJobs([])}>
                      <X className="size-4" /> Clear
                    </Button>
                  )}
                </div>
                <Progress value={(done / jobs.length) * 100} />

                <ul className="mt-4 divide-y divide-border rounded border border-border">
                  {jobs.map((j, i) => (
                    <li key={`${j.name}-${i}`} className="flex flex-wrap items-center gap-3 px-3 py-2 text-sm">
                      <span className="min-w-0 flex-1 truncate">{j.name}</span>
                      {j.state === "done" ? (
                        <>
                          <span className="truncate text-muted-foreground">
                            {j.vendor} · ₹ {inr(j.base)}
                          </span>
                          <StatusBadge value={j.status ?? "APPROVED"} />
                        </>
                      ) : j.state === "error" ? (
                        <span className="flex items-center gap-1 text-destructive">
                          <FileWarning className="size-4" /> {j.message}
                        </span>
                      ) : j.state === "queued" ? (
                        <span className="text-muted-foreground">Queued</span>
                      ) : (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Loader2 className="size-3.5 animate-spin" />
                          {j.state === "reading" ? "Hashing & uploading" : "Reading PDF text"}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">How each document is handled</CardTitle>
            <CardDescription>Nothing is assumed silently.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            {[
              "Duplicate invoices remain visible in the register but have zero cumulative/TDS effect",
              "Text PDFs are read locally with label-anchored parsing — no AI, no credits",
              "GST is stripped so TDS is computed on the taxable value",
              "Nature of payment comes from vendor history and the TDS Rules master",
              "Vendor cumulative totals update and catch-up TDS is raised on threshold crossing",
              "AI vision is used only for scanned pages with no selectable text",

            ].map((line) => (
              <p key={line} className="flex gap-2">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-status-ok-fg" />
                {line}
              </p>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <SpreadsheetImport />
      </div>
    </AppShell>

  );
}
