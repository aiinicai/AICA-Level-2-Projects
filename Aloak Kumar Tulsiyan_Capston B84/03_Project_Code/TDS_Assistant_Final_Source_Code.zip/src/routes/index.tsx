import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  ArrowRight,
  Copy,
  FileStack,
  IndianRupee,
  TrendingUp,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { listInvoices, type InvoiceRow } from "@/lib/invoices";
import { inr, shortDate } from "@/lib/format";
import { TAX_YEAR } from "@/lib/tds/rules";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TDS Dashboard | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Track vendor-wise TDS liability, threshold crossings and catch-up deductions for Indian tax year 2026-27.",
      },
      { property: "og:title", content: "TDS Dashboard | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "Vendor-wise TDS liability, threshold crossings and catch-up deductions at a glance.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

function Kpi({
  label,
  value,
  hint,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: "default" | "alert" | "warn";
}) {
  const toneClass =
    tone === "alert"
      ? "text-status-short-fg"
      : tone === "warn"
        ? "text-status-review-fg"
        : "text-foreground";
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{label}</p>
            <p className={`mt-2 font-serif text-2xl font-semibold ${toneClass}`}>{value}</p>
            {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
          </div>
          <Icon className="size-5 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}

function Dashboard() {
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["invoices"],
    queryFn: listInvoices,
  });

  const active = rows.filter((r) => !r.is_duplicate);
  const totalBase = active.reduce((a, r) => a + (r.tds_base ?? 0), 0);
  const totalTds = rows.reduce((a, r) => a + r.tds_now, 0);
  const catchup = rows.reduce((a, r) => a + r.catchup_tds, 0);
  const pending = rows.filter((r) => r.review_status !== "APPROVED");
  const duplicates = rows.filter((r) => r.is_duplicate);
  const crossed = rows.filter((r) => r.tds_status === "TDS REQUIRED");

  const vendors = new Map<string, { base: number; tds: number }>();
  for (const r of active) {
    const cur = vendors.get(r.vendor_name) ?? { base: 0, tds: 0 };
    cur.base += r.tds_base ?? 0;
    cur.tds += r.tds_now;
    vendors.set(r.vendor_name, cur);
  }
  const topVendors = Array.from(vendors.entries())
    .sort((a, b) => b[1].base - a[1].base)
    .slice(0, 6);

  const recent: InvoiceRow[] = rows.slice(0, 8);

  return (
    <AppShell
      title="TDS Dashboard"
      subtitle={`Tax year ${TAX_YEAR} · deduction position across all vendors`}
      actions={
        <Button asChild>
          <Link to="/upload">
            Upload documents <ArrowRight className="size-4" />
          </Link>
        </Button>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Documents processed" value={String(rows.length)} icon={FileStack} hint={`${duplicates.length} duplicate(s) parked`} />
        <Kpi label="Total TDS base" value={`₹ ${inr(totalBase)}`} icon={IndianRupee} hint="GST excluded" />
        <Kpi label="TDS payable" value={`₹ ${inr(totalTds)}`} icon={TrendingUp} tone="alert" hint={`${crossed.length} bill(s) above threshold`} />
        <Kpi label="Catch-up TDS" value={`₹ ${inr(catchup)}`} icon={AlertTriangle} tone="warn" hint="On earlier below-threshold bills" />
      </div>

      {pending.length ? (
        <Card className="mt-6 border-status-review-fg/30 bg-status-review/40">
          <CardContent className="flex flex-wrap items-center justify-between gap-3 pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 size-5 text-status-review-fg" />
              <div>
                <p className="font-medium text-foreground">
                  {pending.length} document(s) need your confirmation
                </p>
                <p className="text-sm text-muted-foreground">
                  Nothing is guessed silently — uncertain readings wait for a CA sign-off before they
                  enter the cumulative totals.
                </p>
              </div>
            </div>
            <Button variant="outline" asChild>
              <Link to="/register" search={{ view: "review" }}>
                Open review queue
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : null}

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Recent documents</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="py-8 text-center text-sm text-muted-foreground">Loading register…</p>
            ) : recent.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No documents yet. Upload an invoice to begin the register.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase">
                      <th className="py-2 pr-3 font-medium">Date</th>
                      <th className="py-2 pr-3 font-medium">Vendor</th>
                      <th className="py-2 pr-3 text-right font-medium">Base</th>
                      <th className="py-2 pr-3 text-right font-medium">TDS</th>
                      <th className="py-2 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recent.map((r) => (
                      <tr key={r.id} className="border-b border-border/60 last:border-0">
                        <td className="py-2 pr-3 whitespace-nowrap text-muted-foreground">
                          {shortDate(r.invoice_date)}
                        </td>
                        <td className="max-w-[220px] truncate py-2 pr-3">{r.vendor_name}</td>
                        <td className="py-2 pr-3 text-right tabular-nums">{inr(r.tds_base)}</td>
                        <td className="py-2 pr-3 text-right tabular-nums">{inr(r.tds_now)}</td>
                        <td className="py-2">
                          <StatusBadge value={r.is_duplicate ? "DUPLICATE" : r.tds_status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Top vendors by base</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {topVendors.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No vendor activity yet.</p>
            ) : (
              topVendors.map(([name, v]) => (
                <div key={name}>
                  <div className="flex items-baseline justify-between gap-3 text-sm">
                    <span className="truncate">{name}</span>
                    <span className="tabular-nums text-muted-foreground">₹ {inr(v.base)}</span>
                  </div>
                  <div className="mt-1 h-1.5 w-full rounded bg-secondary">
                    <div
                      className="h-1.5 rounded bg-chart-1"
                      style={{
                        width: `${Math.max(4, (v.base / (topVendors[0]?.[1].base || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              ))
            )}
            {duplicates.length ? (
              <p className="flex items-center gap-2 pt-2 text-xs text-muted-foreground">
                <Copy className="size-3.5" /> {duplicates.length} duplicate document(s) excluded from
                totals
              </p>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
