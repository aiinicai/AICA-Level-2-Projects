import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { KeyRound, Loader2, PlugZap } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { testAiConnection } from "@/lib/extraction.functions";
import { saveAppSettings } from "@/lib/settings.functions";
import { recalculateRegister } from "@/lib/invoices";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "AI Settings | AI TDS Compliance Assistant" },
      {
        name: "description",
        content:
          "Choose the AI vision provider and model, set the confidence threshold for review, and manage your own API key.",
      },
      { property: "og:title", content: "AI Settings | AI TDS Compliance Assistant" },
      {
        property: "og:description",
        content: "Provider, model, confidence threshold and API key management.",
      },
    ],
  }),
  component: SettingsPage,
});

const MODELS: Record<string, { value: string; label: string }[]> = {
  builtin: [
    { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro — most accurate on scans" },
    { value: "google/gemini-3.5-flash", label: "Gemini 3.5 Flash — fast and economical" },
    { value: "openai/gpt-5.4", label: "GPT-5.4 — strong reasoning" },
  ],
  gemini: [
    { value: "gemini-2.5-pro", label: "gemini-2.5-pro" },
    { value: "gemini-2.5-flash", label: "gemini-2.5-flash" },
  ],
  openai: [
    { value: "gpt-4.1", label: "gpt-4.1" },
    { value: "gpt-4o", label: "gpt-4o" },
  ],
  local: [{ value: "manual", label: "Manual entry only" }],
};

interface SettingsState {
  ai_provider: string;
  model: string;
  confidence_threshold: number;
  enable_vision: boolean;
  has_key: boolean;
}

const DEFAULTS: SettingsState = {
  ai_provider: "builtin",
  model: "google/gemini-2.5-pro",
  confidence_threshold: 0.75,
  enable_vision: true,
  has_key: false,
};

function SettingsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [state, setState] = useState<SettingsState>(DEFAULTS);
  const [apiKey, setApiKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);

  const { data } = useQuery({
    queryKey: ["app_settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("ai_provider, model, confidence_threshold, enable_vision, has_api_key")
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });

  useEffect(() => {
    if (!data) return;
    const d = data as unknown as Record<string, unknown>;
    setState({
      ai_provider: String(d["ai_provider"] ?? DEFAULTS.ai_provider),
      model: String(d["model"] ?? DEFAULTS.model),
      confidence_threshold: Number(d["confidence_threshold"] ?? DEFAULTS.confidence_threshold),
      enable_vision: Boolean(d["enable_vision"] ?? true),
      has_key: Boolean(d["has_api_key"]),
    });
  }, [data]);

  const save = async () => {
    if (!user) return;
    if (!state.model.trim()) {
      toast.error("Enter a model name before saving.");
      return;
    }
    setBusy(true);
    try {
      const res = await saveAppSettings({
        data: {
          ai_provider: state.ai_provider as "builtin" | "gemini" | "openai" | "local",
          model: state.model.trim(),
          confidence_threshold: state.confidence_threshold,
          enable_vision: state.enable_vision,
          api_key: apiKey.trim() || null,
          clear_api_key: state.ai_provider === "builtin" || state.ai_provider === "local",
        },
      });
      setApiKey("");
      setState((s) => ({ ...s, has_key: res.has_api_key }));
      await qc.invalidateQueries({ queryKey: ["app_settings"] });
      toast.success("AI settings saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save the settings.");
    } finally {
      setBusy(false);
    }
  };


  const test = async () => {
    setTesting(true);
    try {
      const res = await testAiConnection({
        data: {
          provider: state.ai_provider as "builtin" | "gemini" | "openai" | "local",
          model: state.model,
          apiKey: apiKey.trim() || null,
        },
      });
      toast.success(res.message);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The connection test failed.");
    } finally {
      setTesting(false);
    }
  };

  const models = MODELS[state.ai_provider] ?? MODELS["builtin"]!;

  return (
    <AppShell title="Settings" subtitle="Document reading, confidence and recalculation controls">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">AI document reading</CardTitle>
            <CardDescription>
              The built-in vision service works without any key. You can switch to your own Gemini or
              OpenAI key if your firm requires it.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Provider</Label>
                <Select
                  value={state.ai_provider}
                  onValueChange={(v) =>
                    setState((s) => ({ ...s, ai_provider: v, model: MODELS[v]?.[0]?.value ?? s.model }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="builtin">Built-in AI vision (no key needed)</SelectItem>
                    <SelectItem value="gemini">Google Gemini (your key)</SelectItem>
                    <SelectItem value="openai">OpenAI (your key)</SelectItem>
                    <SelectItem value="local">Manual entry only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Model</Label>
                <Select
                  value={models.some((m) => m.value === state.model) ? state.model : "__custom"}
                  onValueChange={(v) =>
                    setState((s) => ({ ...s, model: v === "__custom" ? "" : v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose or type a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {models.map((m) => (
                      <SelectItem key={m.value} value={m.value}>
                        {m.label}
                      </SelectItem>
                    ))}
                    <SelectItem value="__custom">Other — type a model name</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  value={state.model}
                  placeholder="e.g. gemini-2.5-flash-lite"
                  onChange={(e) => setState((s) => ({ ...s, model: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">
                  Pick a listed model or type any model name your provider supports.
                </p>
              </div>
            </div>

            {state.ai_provider === "gemini" || state.ai_provider === "openai" ? (
              <div className="space-y-1.5">
                <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <KeyRound className="size-3.5" /> API key
                  {state.has_key ? <span className="text-status-ok-fg">· a key is already saved</span> : null}
                </Label>
                <Input
                  type="password"
                  placeholder={state.has_key ? "Enter a new key to replace the saved one" : "Paste your API key"}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Keys are stored server-side against your account and are never sent back to the browser.
                </p>
              </div>
            ) : null}

            <div className="flex items-center justify-between rounded border border-border p-3">
              <div>
                <p className="text-sm font-medium">Read documents with AI</p>
                <p className="text-xs text-muted-foreground">
                  Turn off to key in every document manually.
                </p>
              </div>
              <Switch
                checked={state.enable_vision}
                onCheckedChange={(v) => setState((s) => ({ ...s, enable_vision: v }))}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">
                Review threshold — flag anything read below {Math.round(state.confidence_threshold * 100)}%
                confidence
              </Label>
              <Slider
                value={[state.confidence_threshold * 100]}
                min={40}
                max={99}
                step={1}
                onValueChange={([v]) =>
                  setState((s) => ({ ...s, confidence_threshold: (v ?? 75) / 100 }))
                }
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <Button onClick={save} disabled={busy}>
                Save settings
              </Button>
              <Button variant="outline" onClick={test} disabled={testing}>
                {testing ? <Loader2 className="size-4 animate-spin" /> : <PlugZap className="size-4" />}
                Test connection
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Register maintenance</CardTitle>
            <CardDescription>
              Recalculate every vendor chain if you have edited several documents.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="outline"
              className="w-full"
              onClick={async () => {
                await recalculateRegister();
                await qc.invalidateQueries({ queryKey: ["invoices"] });
                toast.success("Cumulative totals and catch-up TDS recalculated.");
              }}
            >
              Recalculate register
            </Button>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
