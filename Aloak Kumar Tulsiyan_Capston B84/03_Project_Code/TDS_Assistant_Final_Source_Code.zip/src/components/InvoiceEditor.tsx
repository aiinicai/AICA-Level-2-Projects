import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { InvoiceRow } from "@/lib/invoices";
import { updateInvoice } from "@/lib/invoices";
import { CATEGORY_LABELS, PAYEE_TYPES, ruleForCategory } from "@/lib/tds/rules";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { inr } from "@/lib/format";

const num = (v: string): number | null => {
  if (v.trim() === "") return null;
  const n = Number(v.replace(/,/g, ""));
  return isFinite(n) ? n : null;
};

export function InvoiceEditor({
  row,
  open,
  onOpenChange,
  onSaved,
}: {
  row: InvoiceRow | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const [draft, setDraft] = useState<InvoiceRow | null>(row);
  const [busy, setBusy] = useState(false);

  useEffect(() => setDraft(row), [row]);
  if (!draft) return null;

  const set = <K extends keyof InvoiceRow>(key: K, value: InvoiceRow[K]) =>
    setDraft((d) => (d ? { ...d, [key]: value } : d));

  const rule = ruleForCategory(draft.tds_category);

  const save = async (approve: boolean) => {
    setBusy(true);
    try {
      await updateInvoice(
        row!,
        {
          vendor_name: draft.vendor_name,
          vendor_pan: draft.vendor_pan,
          vendor_gstin: draft.vendor_gstin,
          invoice_number: draft.invoice_number,
          invoice_number_generated: draft.invoice_number_generated,
          invoice_date: draft.invoice_date,
          description: draft.description,
          gross_amount: draft.gross_amount,
          cgst: draft.cgst,
          sgst: draft.sgst,
          igst: draft.igst,
          tds_base: draft.tds_base,
          payee_type: draft.payee_type,
          tds_category: draft.tds_category,
          notes: draft.notes,
          is_duplicate: draft.is_duplicate,
        },
        approve,
        0.75,
      );
      toast.success(approve ? "Document approved and register recalculated." : "Changes saved.");
      onSaved();
      onOpenChange(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The document could not be saved.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="font-serif">Invoice details</SheetTitle>
          <SheetDescription>
            {draft.source_file ?? "Manual entry"} · read by {draft.extraction_method ?? "—"}
          </SheetDescription>

        </SheetHeader>

        <div className="space-y-5 px-4 pb-4">
          {draft.review_reasons.length ? (
            <div className="rounded border border-status-review-fg/30 bg-status-review/50 p-3 text-sm">
              <p className="font-medium text-foreground">Points to confirm</p>
              <ul className="mt-1 list-disc pl-5 text-muted-foreground">
                {draft.review_reasons.map((r) => (
                  <li key={r}>{r}</li>
                ))}
              </ul>
            </div>
          ) : null}

          {draft.is_duplicate ? (
            <div className="flex items-center justify-between gap-3 rounded border border-border bg-muted/50 p-3 text-sm">
              <span className="text-muted-foreground">{draft.duplicate_reason}</span>
              <Button size="sm" variant="outline" onClick={() => set("is_duplicate", false)}>
                Not a duplicate
              </Button>
            </div>
          ) : null}

          {draft.handwritten_adjustment ? (
            <div className="rounded border border-border p-3 text-sm">
              <p className="font-medium">Handwritten settlement detected</p>
              <p className="text-muted-foreground">
                Printed total ₹ {inr(draft.printed_total)} · handwritten adjustment ₹{" "}
                {inr(draft.handwritten_adjustment)} · final settlement ₹{" "}
                {inr(draft.final_settlement)}
              </p>
            </div>
          ) : null}

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Vendor name">
              <Input value={draft.vendor_name} onChange={(e) => set("vendor_name", e.target.value)} />
            </Field>
            <Field label="Payee type">
              <Select value={draft.payee_type} onValueChange={(v) => set("payee_type", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYEE_TYPES.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="PAN">
              <Input value={draft.vendor_pan ?? ""} onChange={(e) => set("vendor_pan", e.target.value || null)} />
            </Field>
            <Field label="GSTIN">
              <Input value={draft.vendor_gstin ?? ""} onChange={(e) => set("vendor_gstin", e.target.value || null)} />
            </Field>
            <Field label="Invoice number">
              <Input
                value={draft.invoice_number ?? ""}
                onChange={(e) => {
                  set("invoice_number", e.target.value || null);
                  set("invoice_number_generated", false);
                }}
              />
            </Field>
            <Field label="Invoice date">
              <Input
                type="date"
                value={draft.invoice_date ?? ""}
                onChange={(e) => set("invoice_date", e.target.value || null)}
              />
            </Field>
          </div>

          <Field label="Description / nature of payment">
            <Textarea
              rows={2}
              value={draft.description ?? ""}
              onChange={(e) => set("description", e.target.value || null)}
            />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Gross amount (incl. GST)">
              <Input
                inputMode="decimal"
                value={draft.gross_amount ?? ""}
                onChange={(e) => set("gross_amount", num(e.target.value))}
              />
            </Field>
            <Field label="TDS base (excl. GST)">
              <Input
                inputMode="decimal"
                value={draft.tds_base ?? ""}
                onChange={(e) => set("tds_base", num(e.target.value))}
              />
            </Field>
            <Field label="CGST">
              <Input inputMode="decimal" value={draft.cgst ?? ""} onChange={(e) => set("cgst", num(e.target.value))} />
            </Field>
            <Field label="SGST">
              <Input inputMode="decimal" value={draft.sgst ?? ""} onChange={(e) => set("sgst", num(e.target.value))} />
            </Field>
            <Field label="IGST">
              <Input inputMode="decimal" value={draft.igst ?? ""} onChange={(e) => set("igst", num(e.target.value))} />
            </Field>
            <Field label="TDS category">
              <Select
                value={draft.tds_category ?? ""}
                onValueChange={(v) => set("tds_category", v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_LABELS.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>

          {rule ? (
            <div className="rounded border border-border bg-muted/40 p-3 text-sm text-muted-foreground">
              <span className="font-medium text-foreground">
                {rule.currentSection} (earlier {rule.legacySection})
              </span>{" "}
              · {rule.rateText} · {rule.thresholdText}
              {rule.notes ? <span> · {rule.notes}</span> : null}
            </div>
          ) : null}

          <Field label="Notes for the file">
            <Textarea rows={3} value={draft.notes ?? ""} onChange={(e) => set("notes", e.target.value || null)} />
          </Field>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            Current status <StatusBadge value={draft.review_status} />
            <StatusBadge value={draft.tds_status} />
          </div>
        </div>

        <SheetFooter className="flex-row gap-2">
          <Button variant="outline" className="flex-1" disabled={busy} onClick={() => save(false)}>
            Save changes
          </Button>
          <Button className="flex-1" disabled={busy} onClick={() => save(true)}>
            Approve document
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
