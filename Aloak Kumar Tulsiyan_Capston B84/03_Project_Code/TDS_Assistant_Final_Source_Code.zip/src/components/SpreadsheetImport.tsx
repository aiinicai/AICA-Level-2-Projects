import { useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { FileSpreadsheet, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { recalculateRegister, saveExtractedInvoice } from "@/lib/invoices";
import {
  autoMap,
  hashRow,
  parseSpreadsheet,
  rowToFields,
  SHEET_FIELDS,
  type Mapping,
  type ParsedSheet,
  type SheetFieldKey,
} from "@/lib/sheet-import";

const NONE = "__none__";

export function SpreadsheetImport() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [sheet, setSheet] = useState<ParsedSheet | null>(null);
  const [mapping, setMapping] = useState<Mapping>({});
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);

  const load = async (f: File, sheetName?: string) => {
    try {
      const parsed = await parseSpreadsheet(f, sheetName);
      setFile(f);
      setSheet(parsed);
      setMapping(autoMap(parsed.headers));
      if (!parsed.rows.length) toast.error("That sheet has no data rows.");
    } catch {
      toast.error("The spreadsheet could not be read. Use .xlsx, .xls or .csv.");
    }
  };

  const runImport = async () => {
    if (!user || !file || !sheet) return;
    if (!mapping["vendor_name"]) {
      toast.error("Map the Vendor Name column before importing.");
      return;
    }
    setBusy(true);
    setProgress(0);
    let ok = 0;
    let failed = 0;

    for (let i = 0; i < sheet.rows.length; i++) {
      const row = sheet.rows[i]!;
      try {
        const fields = rowToFields(row, mapping);
        if (!fields.vendor_name) {
          failed++;
        } else {
          await saveExtractedInvoice({
            userId: user.id,
            fields,
            extractionMethod: "Spreadsheet import",
            confidenceThreshold: 0.8,
            fileName: file.name,
            filePath: null,
            fileHash: await hashRow(file.name, row),
          });
          ok++;
        }
      } catch {
        failed++;
      }
      setProgress(Math.round(((i + 1) / sheet.rows.length) * 100));
    }

    await recalculateRegister();
    await qc.invalidateQueries({ queryKey: ["invoices"] });
    setBusy(false);
    toast.success(`${ok} row(s) imported${failed ? `, ${failed} skipped` : ""}. Review flagged rows in the register.`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="size-4" /> Import from Excel / CSV
        </CardTitle>
        <CardDescription>
          Bring in an existing bill register (.xlsx, .xls, .csv). Columns are matched automatically —
          adjust anything that looks wrong before importing.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <Button variant="outline" disabled={busy} onClick={() => input.current?.click()}>
            Choose spreadsheet
          </Button>
          <span className="text-sm text-muted-foreground">
            {file ? `${file.name} · ${sheet?.rows.length ?? 0} row(s)` : "No file selected"}
          </span>
          <input
            ref={input}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void load(f);
              e.target.value = "";
            }}
          />
        </div>

        {sheet ? (
          <>
            {sheet.sheetNames.length > 1 ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-muted-foreground">Worksheet</span>
                <Select
                  value={sheet.sheetName}
                  onValueChange={(v) => file && void load(file, v)}
                >
                  <SelectTrigger className="w-56">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sheet.sheetNames.map((n) => (
                      <SelectItem key={n} value={n}>
                        {n}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}

            <div className="grid gap-3 sm:grid-cols-2">
              {SHEET_FIELDS.map((f) => (
                <div key={f.key} className="flex items-center justify-between gap-3">
                  <label className="text-sm">
                    {f.label}
                    {f.required ? <span className="text-destructive"> *</span> : null}
                  </label>
                  <Select
                    value={mapping[f.key as SheetFieldKey] ?? NONE}
                    onValueChange={(v) =>
                      setMapping((m) => ({
                        ...m,
                        [f.key]: v === NONE ? undefined : v,
                      }))
                    }
                  >
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Not mapped" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>Not mapped</SelectItem>
                      {sheet.headers.map((h) => (
                        <SelectItem key={h} value={h}>
                          {h}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>

            {busy ? <Progress value={progress} /> : null}

            <div className="flex items-center gap-3">
              <Button disabled={busy || !sheet.rows.length} onClick={() => void runImport()}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : null}
                Import {sheet.rows.length} row(s)
              </Button>
              <p className="text-xs text-muted-foreground">
                Imported rows are flagged for review, run through the TDS rule engine and included in
                vendor cumulative totals.
              </p>
            </div>
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}
