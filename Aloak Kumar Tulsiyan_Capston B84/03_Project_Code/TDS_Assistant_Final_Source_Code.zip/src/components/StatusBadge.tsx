import { cn } from "@/lib/utils";

const STYLES: Record<string, string> = {
  "TDS REQUIRED": "bg-status-short text-status-short-fg",
  "BELOW THRESHOLD": "bg-status-ok text-status-ok-fg",
  "NEEDS REVIEW": "bg-status-review text-status-review-fg",
  DUPLICATE: "bg-status-dup text-status-dup-fg",
  APPROVED: "bg-status-ok text-status-ok-fg",
  REVIEW: "bg-status-review text-status-review-fg",
  BLOCKED: "bg-status-short text-status-short-fg",
};

export function StatusBadge({ value, className }: { value: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded px-2 py-0.5 text-xs font-medium whitespace-nowrap",
        STYLES[value] ?? "bg-secondary text-secondary-foreground",
        className,
      )}
    >
      {value}
    </span>
  );
}
