"""AEC offline physician agreement and calculation application."""
