"""Revenue file parsing and line-level validation."""
from __future__ import annotations

import csv
import hashlib
import io
import json
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook

from .engine import dec, money, serial

FIELDS = {
    "line_id": "Line ID", "hospital": "Hospital", "service_date": "Service Date",
    "posting_month": "Posting Month", "claim_id": "Claim ID", "physician": "Physician",
    "service_category": "Service Category", "service_code": "Service Code",
    "revenue_component": "Revenue Component", "department": "Department", "payer_type": "Payer Type",
    "gross": "Gross Charges (AED)", "discount": "Self-pay Discount (AED)",
    "adjustment": "Payer Adjustment (AED)", "denied": "Denied Amount (AED)",
    "net_allowed": "Net Allowed Charge (AED)", "payer_collection": "Payer Collection (AED)",
    "patient_collection": "Patient Collection (AED)", "refund": "Refund (AED)",
    "recoupment": "Payer Recoupment (AED)", "net_cash": "Net Cash Collected (AED)",
    "direct_cost": "Direct Cost (AED)", "net_after_cost": "Net Revenue After Cost (AED)",
    "collection_date": "Collection Date",
}
REQUIRED = {"line_id", "hospital", "service_date", "physician", "service_category",
            "revenue_component", "gross", "discount", "adjustment", "denied",
            "net_allowed", "payer_collection", "patient_collection", "refund",
            "recoupment", "net_cash", "direct_cost", "net_after_cost"}
AMOUNTS = {"gross", "discount", "adjustment", "denied", "net_allowed",
           "payer_collection", "patient_collection", "refund", "recoupment",
           "net_cash", "direct_cost", "net_after_cost"}


def file_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _date(value) -> str:
    if value is None or value == "":
        return ""
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (int, float)):
        from openpyxl.utils.datetime import from_excel
        return from_excel(value).date().isoformat()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%b-%Y"):
        try:
            return datetime.strptime(text[:10], fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError(f"Invalid date: {text}")


def read_rows(filename: str, data: bytes) -> tuple[list[str], list[dict]]:
    suffix = Path(filename).suffix.lower()
    if suffix == ".csv":
        text = data.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        headers = list(reader.fieldnames or [])
        return headers, list(reader)
    if suffix == ".xlsx":
        book = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        sheet = book["Revenue Dump"] if "Revenue Dump" in book.sheetnames else book.active
        iterator = sheet.iter_rows(values_only=True)
        headers = [str(x).strip() if x is not None else "" for x in next(iterator)]
        rows = [dict(zip(headers, values)) for values in iterator if any(v is not None for v in values)]
        book.close()
        return headers, rows
    raise ValueError("Upload a .xlsx or .csv file.")


def default_mapping(headers: list[str]) -> dict[str, str]:
    by_fold = {h.casefold(): h for h in headers}
    return {key: by_fold.get(label.casefold(), "") for key, label in FIELDS.items()}


def validate_rows(rows: list[dict], mapping: dict[str, str], expected_hospital: str,
                  existing_ids: set[str]) -> tuple[list[dict], list[dict], list[str]]:
    missing = sorted(key for key in REQUIRED if not mapping.get(key))
    if missing:
        raise ValueError("Missing required column mappings: " + ", ".join(missing))
    valid: list[dict] = []
    rejected: list[dict] = []
    warnings: list[str] = []
    seen = set(existing_ids)
    for number, raw in enumerate(rows, 2):
        issues = []
        item = {key: raw.get(header) if header else None for key, header in mapping.items()}
        item = {key: ("" if value is None else value) for key, value in item.items()}
        item["raw_json"] = json.dumps(raw, default=str, ensure_ascii=False)
        for key in ("line_id", "hospital", "physician", "service_category", "revenue_component"):
            item[key] = str(item.get(key, "")).strip()
        if not item["line_id"]:
            issues.append("Missing Line ID")
        if item["hospital"].casefold() != expected_hospital.strip().casefold():
            issues.append("Hospital does not match selected hospital")
        if not item["physician"]:
            issues.append("Missing physician")
        if item["line_id"] in seen:
            issues.append("Duplicate Line ID")
        try:
            item["service_date"] = _date(item.get("service_date"))
            if not item["service_date"]:
                issues.append("Missing service date")
        except ValueError as exc:
            issues.append(str(exc))
        try:
            item["collection_date"] = _date(item.get("collection_date"))
        except ValueError as exc:
            issues.append(str(exc))
        item["posting_month"] = str(item.get("posting_month", ""))[:7]
        for key in AMOUNTS:
            try:
                item[key] = serial(money(item.get(key)))
            except (InvalidOperation, ValueError):
                issues.append(f"Invalid {key}")
                item[key] = "0.00"
        if not issues:
            if abs(dec(item["net_allowed"]) - (dec(item["gross"]) - dec(item["discount"])
                                                   - dec(item["adjustment"]) - dec(item["denied"]))) > Decimal("0.01"):
                issues.append("Net allowed does not reconcile")
            if abs(dec(item["net_cash"]) - (dec(item["payer_collection"]) + dec(item["patient_collection"])
                                                - dec(item["refund"]) - dec(item["recoupment"]))) > Decimal("0.01"):
                issues.append("Net cash does not reconcile")
            if abs(dec(item["net_after_cost"]) - (dec(item["net_cash"]) - dec(item["direct_cost"]))) > Decimal("0.01"):
                issues.append("Net after cost does not reconcile")
        if issues:
            rejected.append({"row": number, "line_id": item["line_id"], "issues": issues})
        else:
            seen.add(item["line_id"])
            for key in ("claim_id", "service_code", "department", "payer_type"):
                item[key] = str(item.get(key, "")).strip()
            valid.append(item)
    if not rows:
        warnings.append("The file has no data rows.")
    return valid, rejected, warnings
