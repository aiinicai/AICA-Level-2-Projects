from __future__ import annotations

import hashlib
import hmac
import csv
import io
import json
import os
import re
import secrets
import smtplib
import time
import uuid
from contextlib import closing
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import parse_qs, quote

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import documents, importer
from .db import DATA, SIGNED, UPLOADS, audit, connect, init_db, now, transaction
from .engine import calculate, validate_terms

BASE = Path(__file__).resolve().parent.parent
TEMPLATES = Jinja2Templates(directory=str(BASE / "templates"))
app = FastAPI(title="AEC Offline", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
MAX_UPLOAD = 25 * 1024 * 1024


@app.on_event("startup")
def startup():
    init_db()
    local_user()


def secret_key() -> bytes:
    DATA.mkdir(parents=True, exist_ok=True)
    path = DATA / "session.key"
    if not path.exists():
        path.write_bytes(secrets.token_bytes(32))
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    return path.read_bytes()


def local_user() -> dict:
    """Use one audit identity for every person at this offline workstation."""
    with closing(connect()) as db:
        row = db.execute("SELECT id,username,role FROM users WHERE username='Local operator'").fetchone()
        if row:
            return dict(row)
    with transaction() as db:
        db.execute("""INSERT OR IGNORE INTO users(username,password_hash,role,created_at)
                      VALUES('Local operator','login disabled','admin',?)""", (now(),))
        row = db.execute("SELECT id,username,role FROM users WHERE username='Local operator'").fetchone()
        return dict(row)


def csrf(request: Request) -> str:
    return hmac.new(secret_key(), b"csrf:local", hashlib.sha256).hexdigest()


def multipart_csrf(body: bytes) -> str:
    match = re.search(rb'name="csrf"[^\r\n]*\r?\n(?:[^\r\n]+\r?\n)*\r?\n([0-9a-f]{64})', body)
    return match.group(1).decode() if match else ""


@app.middleware("http")
async def guard(request: Request, call_next):
    if request.url.path.startswith("/static/"):
        return await call_next(request)
    request.state.user = local_user()
    if request.method in {"POST", "PUT", "DELETE"}:
        body = await request.body()
        content_type = request.headers.get("content-type", "")
        if "multipart/form-data" in content_type:
            submitted = multipart_csrf(body)
        else:
            submitted = parse_qs(body.decode("utf-8", "replace")).get("csrf", [""])[0]
        if not hmac.compare_digest(submitted, csrf(request)):
            return HTMLResponse("Invalid form token. Reload the page and try again.", status_code=403)
    return await call_next(request)


def view(request: Request, name: str, **context):
    context.update({"request": request, "user": request.state.user, "csrf": csrf(request),
                    "title": context.get("title", "AEC"), "message": request.query_params.get("message", "")})
    return TEMPLATES.TemplateResponse(request=request, name=name, context=context)


def require(request: Request, *roles: str) -> dict:
    return request.state.user


def go(path: str, message: str = ""):
    return RedirectResponse(path + (("?" if "?" not in path else "&") + "message=" + quote(message) if message else ""),
                            status_code=303)


def rows_as_dict(cursor) -> list[dict]:
    return [dict(row) for row in cursor.fetchall()]


@app.get("/setup", response_class=HTMLResponse)
def setup_page(request: Request):
    return go("/")


@app.post("/setup")
def setup(request: Request):
    return go("/")


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return go("/")


@app.post("/login")
def login(request: Request):
    return go("/")


@app.post("/logout")
def logout(request: Request):
    return go("/")


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    with closing(connect()) as db:
        stats = {
            "agreements": db.execute("SELECT COUNT(*) FROM agreements").fetchone()[0],
            "active": db.execute("SELECT COUNT(*) FROM agreement_versions WHERE status='active'").fetchone()[0],
            "imports": db.execute("SELECT COUNT(*) FROM revenue_imports").fetchone()[0],
            "pending": db.execute("SELECT COUNT(*) FROM calculation_runs WHERE status IN ('draft','needs_data')").fetchone()[0],
        }
        recent = rows_as_dict(db.execute("""SELECT r.*,a.specialty FROM calculation_runs r
            LEFT JOIN agreement_versions v ON r.agreement_version_id=v.id
            LEFT JOIN agreements a ON v.agreement_id=a.id ORDER BY r.id DESC LIMIT 8"""))
    return view(request, "dashboard.html", title="Dashboard", stats=stats, recent=recent,
                exam_mode=os.environ.get("AEC_EXAM_MODE") == "1")


@app.post("/demo/load")
def load_sample_agreements(request: Request):
    if os.environ.get("AEC_EXAM_MODE") == "1":
        raise HTTPException(404, "Sample agreements are not included in this reviewer copy")
    user = require(request, "admin")
    samples = json.loads((BASE / "examples" / "sample_agreements.json").read_text(encoding="utf-8"))
    added = 0
    with transaction() as db:
        for sample in samples:
            if db.execute("SELECT id FROM agreements WHERE lower(hospital)=lower(?) AND lower(physician)=lower(?)",
                          (sample["hospital"], sample["physician"])).fetchone():
                continue
            terms = {key: value for key, value in sample.items()
                     if key not in {"hospital", "physician", "specialty", "effective_from"}}
            terms.update({"collection_delay_days": 0, "statement_due_days": 10, "payment_delay_days": 30})
            errors = validate_terms(terms)
            if errors:
                raise HTTPException(500, "Invalid bundled sample: " + " ".join(errors))
            cursor = db.execute("INSERT INTO agreements(hospital,physician,specialty,created_at,created_by) VALUES(?,?,?,?,?)",
                                (sample["hospital"], sample["physician"], sample["specialty"], now(), user["id"]))
            agreement_id = cursor.lastrowid
            version = db.execute("""INSERT INTO agreement_versions
                (agreement_id,version,effective_from,status,terms_json,created_at,created_by)
                VALUES(?,1,?,'draft',?,?,?)""",
                (agreement_id, sample["effective_from"], json.dumps(terms), now(), user["id"]))
            audit(db, user["id"], "load_sample", "agreement_version", version.lastrowid,
                  {"agreement_id": agreement_id})
            added += 1
    return go("/agreements", f"Loaded {added} synthetic agreement drafts. Sign and activate before calculation.")


@app.get("/users", response_class=HTMLResponse)
def user_list(request: Request):
    return go("/")


@app.post("/users")
def add_user(request: Request):
    return go("/")


def agreement_context(version: dict | None = None) -> dict:
    if version:
        terms = json.loads(version["terms_json"])
        return {"terms": terms, "rules_json": json.dumps(terms.get("rules", []), ensure_ascii=False)}
    return {"terms": {"arrangement": "OP clinic", "practice_scope": "", "settlement": "additive", "notes": "",
                       "collection_delay_days": 0, "statement_due_days": 10, "payment_delay_days": 30,
                       "ancillary_approved": False, "ancillary_approval_reference": "",
                       "allocation_method": "", "service_code_definition": ""},
            "rules_json": "[]"}


@app.get("/agreements", response_class=HTMLResponse)
def agreement_list(request: Request):
    with connect() as db:
        agreements = rows_as_dict(db.execute("""SELECT a.*,
            (SELECT status FROM agreement_versions v WHERE v.agreement_id=a.id ORDER BY version DESC LIMIT 1) status,
            (SELECT version FROM agreement_versions v WHERE v.agreement_id=a.id ORDER BY version DESC LIMIT 1) version,
            (SELECT effective_from FROM agreement_versions v WHERE v.agreement_id=a.id ORDER BY version DESC LIMIT 1) effective_from
            FROM agreements a WHERE a.archived_at IS NULL ORDER BY a.physician"""))
    return view(request, "agreements.html", title="Agreement master", agreements=agreements)


@app.get("/agreements/removed", response_class=HTMLResponse)
def agreement_removed_list(request: Request):
    with closing(connect()) as db:
        agreements = rows_as_dict(db.execute("""SELECT id,hospital,physician,specialty,archived_at,archive_reason
            FROM agreements WHERE archived_at IS NOT NULL ORDER BY archived_at DESC"""))
    return view(request, "agreements_removed.html", title="Removed agreements", agreements=agreements)


@app.get("/agreements/new", response_class=HTMLResponse)
def agreement_new(request: Request):
    require(request, "admin", "finance")
    return view(request, "agreement_form.html", title="New agreement", agreement=None, version=None,
                default_effective_from=date.today().replace(day=1).isoformat(), **agreement_context())


@app.get("/agreements/{agreement_id}/amend", response_class=HTMLResponse)
def agreement_amend(request: Request, agreement_id: int, correction: bool = False):
    require(request, "admin", "finance")
    with connect() as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        version = db.execute("SELECT * FROM agreement_versions WHERE agreement_id=? ORDER BY version DESC LIMIT 1",
                             (agreement_id,)).fetchone()
    if not agreement or not version:
        raise HTTPException(404)
    if agreement["archived_at"]:
        raise HTTPException(409, "Restore this agreement before amending it")
    if version["status"] == "draft":
        return go(f"/agreements/{agreement_id}/versions/{version['id']}/edit",
                  "Edit the existing unsigned draft before creating another version.")
    latest_start = date.fromisoformat(version["effective_from"])
    next_month = (latest_start.replace(day=28) + timedelta(days=4)).replace(day=1)
    suggested_start = max(date.today().replace(day=1), next_month)
    return view(request, "agreement_form.html", title="Amend agreement", agreement=dict(agreement),
                version=dict(version), editing_draft=False, correction=correction,
                suggested_effective_from=suggested_start.isoformat(), **agreement_context(dict(version)))


@app.get("/agreements/{agreement_id}/versions/{version_id}/edit", response_class=HTMLResponse)
def agreement_edit_draft(request: Request, agreement_id: int, version_id: int):
    require(request, "admin", "finance")
    with connect() as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        version = db.execute("""SELECT * FROM agreement_versions WHERE id=? AND agreement_id=?
            AND status='draft' AND version=(SELECT MAX(version) FROM agreement_versions WHERE agreement_id=?)""",
            (version_id, agreement_id, agreement_id)).fetchone()
    if not agreement or not version:
        raise HTTPException(404, "Only the latest unsigned draft can be edited")
    if agreement["archived_at"]:
        raise HTTPException(409, "Restore this agreement before editing it")
    return view(request, "agreement_form.html", title="Edit unsigned draft", agreement=dict(agreement),
                version=dict(version), editing_draft=True, **agreement_context(dict(version)))


def locked_calculations_from(db, agreement_id: int, effective_from: str) -> int:
    return db.execute("""SELECT COUNT(*) FROM calculation_runs WHERE status IN ('approved','issued')
        AND period>=? AND agreement_version_id IN
        (SELECT id FROM agreement_versions WHERE agreement_id=?)""",
        (effective_from[:7], agreement_id)).fetchone()[0]


@app.post("/agreements/save")
def agreement_save(request: Request, hospital: str = Form(...), physician: str = Form(...),
                   specialty: str = Form(""), effective_from: str = Form(...),
                   effective_to: str = Form(""), arrangement: str = Form(""),
                   practice_scope: str = Form(""), settlement: str = Form(...),
                   notes: str = Form(""), rules_json: str = Form(...),
                   collection_delay_days: int = Form(0), statement_due_days: int = Form(10),
                   payment_delay_days: int = Form(30),
                   hospital_legal_name: str = Form(""), hospital_licence: str = Form(""),
                   hospital_address: str = Form(""), physician_legal_name: str = Form(""),
                   physician_licence: str = Form(""), employment_contract_ref: str = Form(""),
                   ancillary_approved: str = Form(""), ancillary_approval_reference: str = Form(""),
                   allocation_method: str = Form(""), service_code_definition: str = Form(""),
                   agreement_id: int = Form(0), draft_version_id: int = Form(0),
                   amendment_reason: str = Form("")):
    user = require(request, "admin", "finance")
    try:
        start = date.fromisoformat(effective_from)
        if start.day != 1:
            raise ValueError("Agreement versions must begin on the first day of a month for monthly reconciliation.")
        if effective_to and date.fromisoformat(effective_to) < start:
            raise ValueError("End date precedes start date.")
        rules = json.loads(rules_json)
    except (ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(400, str(exc)) from exc
    if min(collection_delay_days, statement_due_days, payment_delay_days) < 0:
        raise HTTPException(400, "Delay values cannot be negative")
    if ancillary_approved == "yes" and not ancillary_approval_reference.strip():
        raise HTTPException(400, "Enter the counsel/compliance approval reference for ancillary categories")
    if ancillary_approved == "yes" and not allocation_method.strip():
        raise HTTPException(400, "Enter the signed ancillary allocation and direct-cost method")
    terms = {"arrangement": arrangement.strip(), "practice_scope": practice_scope.strip(),
             "settlement": settlement, "notes": notes.strip(), "rules": rules,
             "collection_delay_days": collection_delay_days, "statement_due_days": statement_due_days,
             "payment_delay_days": payment_delay_days,
             "hospital_legal_name": hospital_legal_name.strip(), "hospital_licence": hospital_licence.strip(),
             "hospital_address": hospital_address.strip(), "physician_legal_name": physician_legal_name.strip(),
             "physician_licence": physician_licence.strip(), "employment_contract_ref": employment_contract_ref.strip(),
             "ancillary_approved": ancillary_approved == "yes",
             "ancillary_approval_reference": ancillary_approval_reference.strip(),
             "allocation_method": allocation_method.strip(),
             "service_code_definition": service_code_definition.strip()}
    errors = validate_terms(terms)
    if errors:
        raise HTTPException(400, " ".join(errors))
    if not hospital.strip() or not physician.strip():
        raise HTTPException(400, "Hospital and physician are required")
    with transaction() as db:
        if agreement_id:
            prior = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
            latest = db.execute("SELECT * FROM agreement_versions WHERE agreement_id=? ORDER BY version DESC LIMIT 1",
                                (agreement_id,)).fetchone()
            if not prior or not latest:
                raise HTTPException(404)
            if prior["archived_at"]:
                raise HTTPException(409, "Restore this agreement before editing it")
            if prior["hospital"] != hospital.strip() or prior["physician"] != physician.strip():
                raise HTTPException(400, "Hospital and physician cannot change in an amendment")
            if draft_version_id:
                if latest["id"] != draft_version_id or latest["status"] != "draft":
                    raise HTTPException(400, "Only the latest unsigned draft can be edited")
                previous = db.execute("""SELECT effective_from FROM agreement_versions WHERE agreement_id=?
                    AND version<? ORDER BY version DESC LIMIT 1""",
                    (agreement_id, latest["version"])).fetchone()
                if previous and effective_from < previous["effective_from"]:
                    raise HTTPException(400, "Draft cannot start before the preceding agreement version")
                if previous and effective_from == previous["effective_from"] and locked_calculations_from(db, agreement_id, effective_from):
                    raise HTTPException(409, "Approved or issued calculations prevent a same-month correction")
                db.execute("""UPDATE agreement_versions SET effective_from=?,effective_to=?,terms_json=?
                    WHERE id=?""", (effective_from, effective_to or None,
                                    json.dumps(terms, ensure_ascii=False), draft_version_id))
                db.execute("UPDATE agreements SET specialty=? WHERE id=?", (specialty.strip(), agreement_id))
                audit(db, user["id"], "edit_draft", "agreement_version", draft_version_id,
                      {"agreement_id": agreement_id, "version": latest["version"]})
                return go(f"/agreements/{agreement_id}", "Unsigned draft updated.")
            if latest["status"] == "draft":
                raise HTTPException(409, "Edit the existing unsigned draft before creating another version")
            if effective_from < latest["effective_from"]:
                raise HTTPException(400, "Amendment cannot start before the preceding version")
            if effective_from == latest["effective_from"] and locked_calculations_from(db, agreement_id, effective_from):
                raise HTTPException(409, "Approved or issued calculations prevent a same-month correction")
            if not amendment_reason.strip():
                raise HTTPException(400, "Enter an amendment reason")
            number = latest["version"] + 1
        else:
            if db.execute("SELECT id FROM agreements WHERE lower(hospital)=lower(?) AND lower(physician)=lower(?)",
                          (hospital.strip(), physician.strip())).fetchone():
                raise HTTPException(409, "This physician already has an agreement at this hospital. Create an amendment instead.")
            cursor = db.execute("INSERT INTO agreements(hospital,physician,specialty,created_at,created_by) VALUES(?,?,?,?,?)",
                                (hospital.strip(), physician.strip(), specialty.strip(), now(), user["id"]))
            agreement_id = cursor.lastrowid
            number = 1
        cursor = db.execute("""INSERT INTO agreement_versions
            (agreement_id,version,effective_from,effective_to,status,terms_json,amendment_reason,created_at,created_by)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (agreement_id, number, effective_from, effective_to or None, "draft",
             json.dumps(terms, ensure_ascii=False), amendment_reason.strip(), now(), user["id"]))
        audit(db, user["id"], "create_version", "agreement_version", cursor.lastrowid,
              {"agreement_id": agreement_id, "version": number})
    return go(f"/agreements/{agreement_id}", "Draft agreement saved.")


def agreement_removal_impact(db, agreement_id: int) -> dict:
    rows = rows_as_dict(db.execute("""SELECT status,COUNT(*) count FROM calculation_runs
        WHERE agreement_version_id IN (SELECT id FROM agreement_versions WHERE agreement_id=?)
        GROUP BY status""", (agreement_id,)))
    return {row["status"]: row["count"] for row in rows}


@app.get("/agreements/{agreement_id}/remove", response_class=HTMLResponse)
def agreement_remove_page(request: Request, agreement_id: int):
    with closing(connect()) as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        if not agreement:
            raise HTTPException(404)
        impact = agreement_removal_impact(db, agreement_id)
        version_count = db.execute("SELECT COUNT(*) FROM agreement_versions WHERE agreement_id=?",
                                   (agreement_id,)).fetchone()[0]
    return view(request, "agreement_remove.html", title="Remove agreement",
                agreement=dict(agreement), impact=impact, version_count=version_count)


@app.post("/agreements/{agreement_id}/remove")
def agreement_remove(request: Request, agreement_id: int, confirm: str = Form(""), reason: str = Form("")):
    user = require(request, "admin")
    if confirm != "remove":
        raise HTTPException(400, "Confirm removal on the review page")
    with transaction() as db:
        db.execute("BEGIN IMMEDIATE")
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        if not agreement:
            raise HTTPException(404)
        if agreement["archived_at"]:
            raise HTTPException(409, "This agreement has already been removed")
        impact = agreement_removal_impact(db, agreement_id)
        db.execute("UPDATE agreements SET archived_at=?,archived_by=?,archive_reason=? WHERE id=?",
                   (now(), user["id"], reason.strip() or "Removed from active master", agreement_id))
        audit(db, user["id"], "remove", "agreement", agreement_id,
              {"hospital": agreement["hospital"], "physician": agreement["physician"],
               "reason": reason.strip() or "Removed from active master", "calculation_counts": impact})
    return go("/agreements", "Agreement removed from the active master. Its history remains available.")


@app.post("/agreements/{agreement_id}/restore")
def agreement_restore(request: Request, agreement_id: int, confirm: str = Form("")):
    user = require(request, "admin")
    if confirm != "restore":
        raise HTTPException(400, "Confirm restoration")
    with transaction() as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        if not agreement:
            raise HTTPException(404)
        if not agreement["archived_at"]:
            raise HTTPException(409, "This agreement is already active in the master")
        db.execute("UPDATE agreements SET archived_at=NULL,archived_by=NULL,archive_reason='' WHERE id=?",
                   (agreement_id,))
        audit(db, user["id"], "restore", "agreement", agreement_id,
              {"hospital": agreement["hospital"], "physician": agreement["physician"]})
    return go(f"/agreements/{agreement_id}", "Agreement restored to the active master.")


@app.get("/agreements/{agreement_id}", response_class=HTMLResponse)
def agreement_detail(request: Request, agreement_id: int):
    with connect() as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        versions = rows_as_dict(db.execute("SELECT * FROM agreement_versions WHERE agreement_id=? ORDER BY version DESC",
                                       (agreement_id,)))
    if not agreement:
        raise HTTPException(404)
    for version in versions:
        version["terms"] = json.loads(version["terms_json"])
    return view(request, "agreement_detail.html", title="Agreement", agreement=dict(agreement), versions=versions)


@app.get("/agreements/{agreement_id}/compare", response_class=HTMLResponse)
def agreement_compare(request: Request, agreement_id: int, period: str = ""):
    with connect() as db:
        agreement = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        versions = rows_as_dict(db.execute("SELECT * FROM agreement_versions WHERE agreement_id=? ORDER BY version DESC LIMIT 2",
                                       (agreement_id,)))
        if not agreement or len(versions) < 2:
            raise HTTPException(404, "Two versions are needed for comparison")
        if not period:
            period = versions[0]["effective_from"][:7]
        try:
            month = date.fromisoformat(period + "-01")
        except ValueError as exc:
            raise HTTPException(400, "Invalid month") from exc
        quarter_start = (month.month-1)//3*3+1
        qperiod = f"{month.year}-{quarter_start:02d}"
        lines = rows_as_dict(db.execute("""SELECT * FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND lower(physician)=lower(?) AND substr(service_date,1,7)=? ORDER BY id""",
            (agreement["hospital"], agreement["physician"], period)))
        qlines = rows_as_dict(db.execute("""SELECT * FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND lower(physician)=lower(?) AND substr(service_date,1,7)>=? AND substr(service_date,1,7)<=? ORDER BY id""",
            (agreement["hospital"], agreement["physician"], qperiod, period)))
    comparison=[]
    for version in versions:
        terms=json.loads(version["terms_json"])
        try:
            projected=calculate(terms,period,lines,qlines)
            calc_error=""
        except ValueError as exc:
            projected=None;calc_error=str(exc)
        comparison.append({"version":version,"terms":terms,"projected":projected,"error":calc_error})
    return view(request,"agreement_compare.html",title="Compare agreement versions",
                agreement=dict(agreement),comparison=comparison,period=period,line_count=len(lines))


@app.get("/agreements/{agreement_id}/versions/{version_id}/pdf")
def agreement_download(request: Request, agreement_id: int, version_id: int):
    with connect() as db:
        a = db.execute("SELECT * FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        v = db.execute("SELECT * FROM agreement_versions WHERE id=? AND agreement_id=?", (version_id, agreement_id)).fetchone()
    if not a or not v:
        raise HTTPException(404)
    content = documents.agreement_pdf(dict(a), dict(v))
    return Response(content, media_type="application/pdf", headers={"Content-Disposition":
                    f'attachment; filename="agreement_{agreement_id}_v{v["version"]}.pdf"'})


@app.post("/agreements/{agreement_id}/versions/{version_id}/activate")
async def agreement_activate(request: Request, agreement_id: int, version_id: int,
                             signed_copy: UploadFile = File(...)):
    user = require(request, "admin", "approver")
    data = await signed_copy.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD or not data.startswith(b"%PDF-"):
        raise HTTPException(400, "Upload a signed PDF under 25 MB")
    stored = SIGNED / f"agreement_{agreement_id}_v{version_id}_{uuid.uuid4().hex}.pdf"
    stored.write_bytes(data)
    with transaction() as db:
        version = db.execute("SELECT * FROM agreement_versions WHERE id=? AND agreement_id=?", (version_id, agreement_id)).fetchone()
        agreement = db.execute("SELECT archived_at FROM agreements WHERE id=?", (agreement_id,)).fetchone()
        if agreement and agreement["archived_at"]:
            stored.unlink(missing_ok=True)
            raise HTTPException(409, "Restore this agreement before activating it")
        if not version or version["status"] != "draft":
            stored.unlink(missing_ok=True)
            raise HTTPException(400, "Only a draft version can be activated")
        previous = db.execute("SELECT * FROM agreement_versions WHERE agreement_id=? AND status='active'",
                              (agreement_id,)).fetchone()
        if previous and version["effective_from"] < previous["effective_from"]:
            stored.unlink(missing_ok=True)
            raise HTTPException(400, "New effective date cannot precede the active version")
        if previous and version["effective_from"] == previous["effective_from"] and locked_calculations_from(db, agreement_id, version["effective_from"]):
            stored.unlink(missing_ok=True)
            raise HTTPException(409, "Approved or issued calculations prevent a same-month correction")
        if previous:
            end = (date.fromisoformat(version["effective_from"]) - timedelta(days=1)).isoformat()
            db.execute("UPDATE agreement_versions SET status='retired',effective_to=? WHERE id=?", (end, previous["id"]))
        db.execute("UPDATE agreement_versions SET status='active',signed_path=? WHERE id=?",
                   (str(stored), version_id))
        audit(db, user["id"], "activate", "agreement_version", version_id,
              {"signed_sha256": hashlib.sha256(data).hexdigest(),
               "replaces_version_id": previous["id"] if previous else None,
               "same_month_correction": bool(previous and version["effective_from"] == previous["effective_from"])})
    return go(f"/agreements/{agreement_id}", "Signed agreement activated.")


@app.get("/agreements/{agreement_id}/versions/{version_id}/signed")
def signed_download(request: Request, agreement_id: int, version_id: int):
    with connect() as db:
        v = db.execute("SELECT signed_path FROM agreement_versions WHERE id=? AND agreement_id=?",
                       (version_id, agreement_id)).fetchone()
    if not v or not v["signed_path"]:
        raise HTTPException(404)
    return Response(Path(v["signed_path"]).read_bytes(), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="signed_agreement_{agreement_id}_{version_id}.pdf"'})


@app.get("/revenue/upload", response_class=HTMLResponse)
def upload_page(request: Request):
    require(request, "admin", "finance")
    return view(request, "upload.html", title="Upload revenue")


@app.post("/revenue/preview", response_class=HTMLResponse)
async def revenue_preview(request: Request, hospital: str = Form(...), file: UploadFile = File(...)):
    require(request, "admin", "finance")
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(400, "File exceeds 25 MB")
    try:
        headers, rows = importer.read_rows(file.filename or "", data)
    except Exception as exc:
        raise HTTPException(400, f"Cannot read revenue file: {exc}") from exc
    token = uuid.uuid4().hex
    (UPLOADS / f"pending_{token}").write_bytes(data)
    (UPLOADS / f"pending_{token}.json").write_text(
        json.dumps({"filename": Path(file.filename or "upload").name, "hospital": hospital.strip(),
                    "created": time.time()}), encoding="utf-8")
    return view(request, "mapping.html", title="Map and review columns", token=token, hospital=hospital,
                headers=headers, fields=importer.FIELDS, required=importer.REQUIRED,
                mapping=importer.default_mapping(headers), preview=rows[:5], row_count=len(rows))


@app.post("/revenue/commit", response_class=HTMLResponse)
async def revenue_commit(request: Request, token: str = Form(...)):
    user = require(request, "admin", "finance")
    if len(token) != 32 or any(c not in "0123456789abcdef" for c in token):
        raise HTTPException(400, "Invalid upload token")
    pending = UPLOADS / f"pending_{token}"
    meta_path = UPLOADS / f"pending_{token}.json"
    if not pending.exists() or not meta_path.exists():
        raise HTTPException(404, "Upload preview expired")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if time.time() - meta["created"] > 3600:
        raise HTTPException(400, "Upload preview expired. Upload the file again.")
    form = await request.form()
    mapping = {key: str(form.get("map_" + key, "")) for key in importer.FIELDS}
    data = pending.read_bytes()
    sha = importer.file_hash(data)
    with connect() as db:
        if db.execute("SELECT id FROM revenue_imports WHERE sha256=?", (sha,)).fetchone():
            raise HTTPException(409, "This exact file has already been imported")
        existing = {row[0] for row in db.execute("SELECT line_id FROM revenue_lines WHERE hospital=?",
                                                 (meta["hospital"],))}
        doctors = {row[0].casefold() for row in db.execute("SELECT physician FROM agreements WHERE hospital=? AND archived_at IS NULL",
                                                           (meta["hospital"],))}
    headers, rows = importer.read_rows(meta["filename"], data)
    if any(column and column not in headers for column in mapping.values()):
        raise HTTPException(400, "A mapped column is not in this file")
    try:
        accepted, rejected, warnings = importer.validate_rows(rows, mapping, meta["hospital"], existing)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    unknown = sorted({r["physician"] for r in accepted if r["physician"].casefold() not in doctors})
    if unknown:
        warnings.append("No agreement currently exists for: " + ", ".join(unknown))
    stored = UPLOADS / f"import_{token}{Path(meta['filename']).suffix.lower()}"
    stored.write_bytes(data)
    with transaction() as db:
        cursor = db.execute("""INSERT INTO revenue_imports
            (hospital,filename,sha256,stored_path,imported_at,imported_by,accepted_count,rejected_count,warnings_json)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (meta["hospital"], meta["filename"], sha, str(stored), now(), user["id"],
             len(accepted), len(rejected), json.dumps({"warnings": warnings, "rejected": rejected})))
        import_id = cursor.lastrowid
        for line in accepted:
            db.execute("""INSERT INTO revenue_lines
                (import_id,hospital,line_id,physician,service_date,posting_month,collection_date,
                service_category,revenue_component,department,service_code,payer_type,claim_id,
                gross,discount,adjustment,denied,net_allowed,payer_collection,patient_collection,
                refund,recoupment,net_cash,direct_cost,net_after_cost,raw_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (import_id, *[line.get(key, "") for key in (
                    "hospital","line_id","physician","service_date","posting_month","collection_date",
                    "service_category","revenue_component","department","service_code","payer_type","claim_id",
                    "gross","discount","adjustment","denied","net_allowed","payer_collection","patient_collection",
                    "refund","recoupment","net_cash","direct_cost","net_after_cost","raw_json")]))
        audit(db, user["id"], "import", "revenue_import", import_id,
              {"accepted": len(accepted), "rejected": len(rejected), "sha256": sha})
    pending.unlink(missing_ok=True); meta_path.unlink(missing_ok=True)
    return go(f"/revenue/imports/{import_id}", "Revenue file imported.")


@app.get("/revenue/imports", response_class=HTMLResponse)
def import_list(request: Request):
    with connect() as db:
        imports = rows_as_dict(db.execute("SELECT * FROM revenue_imports ORDER BY id DESC"))
    return view(request, "imports.html", title="Revenue imports", imports=imports)


@app.get("/revenue/imports/{import_id}", response_class=HTMLResponse)
def import_detail(request: Request, import_id: int):
    with connect() as db:
        imp = db.execute("SELECT * FROM revenue_imports WHERE id=?", (import_id,)).fetchone()
        if not imp: raise HTTPException(404)
        lines = rows_as_dict(db.execute("""SELECT line_id,physician,service_date,service_category,
            revenue_component,gross,net_cash,net_after_cost FROM revenue_lines WHERE import_id=? ORDER BY id LIMIT 100""",
                                       (import_id,)))
    report = json.loads(imp["warnings_json"])
    return view(request, "import_detail.html", title="Import report", imp=dict(imp), lines=lines, report=report)


def import_delete_impact(db, imp: dict) -> dict:
    """Find calculations that can depend on any service month in this upload."""
    source = rows_as_dict(db.execute(
        "SELECT DISTINCT physician,service_date FROM revenue_lines WHERE import_id=?",
        (imp["id"],)))
    quarters = set()
    for line in source:
        service = date.fromisoformat(line["service_date"])
        first_month = (service.month - 1) // 3 * 3 + 1
        quarters.add((line["physician"], f"{service.year}-{first_month:02d}",
                      f"{service.year}-{first_month + 2:02d}"))
    runs = {}
    for physician, first, last in quarters:
        for run in rows_as_dict(db.execute("""SELECT id,status,physician,period FROM calculation_runs
            WHERE lower(hospital)=lower(?) AND lower(physician)=lower(?) AND period BETWEEN ? AND ?""",
            (imp["hospital"], physician, first, last))):
            runs[run["id"]] = run
    approved = [run for run in runs.values() if run["status"] == "approved"]
    issued = [run for run in runs.values() if run["status"] == "issued"]
    drafts = [run for run in runs.values() if run["status"] in ("draft", "needs_data")]
    return {"protected": sorted(approved + issued, key=lambda r: r["id"]),
            "approved": sorted(approved, key=lambda r: r["id"]),
            "issued": sorted(issued, key=lambda r: r["id"]),
            "drafts": sorted(drafts, key=lambda r: r["id"]),
            "physicians": len({physician.casefold() for physician, _, _ in quarters}),
            "quarters": len(quarters)}


@app.get("/revenue/imports/{import_id}/delete", response_class=HTMLResponse)
def import_delete_page(request: Request, import_id: int):
    require(request, "admin")
    with connect() as db:
        imp = db.execute("SELECT * FROM revenue_imports WHERE id=?", (import_id,)).fetchone()
        if not imp:
            raise HTTPException(404)
        impact = import_delete_impact(db, dict(imp))
    return view(request, "import_delete.html", title="Delete revenue import",
                imp=dict(imp), impact=impact)


def archive_approved_run(db, run_id: int, actor_id: int, reason: str,
                         import_id: int | None = None) -> None:
    row = db.execute("SELECT * FROM calculation_runs WHERE id=?", (run_id,)).fetchone()
    if not row or row["status"] != "approved":
        raise HTTPException(409, "Only an approved, unissued calculation can be reopened")
    run = dict(row)
    db.execute("""INSERT INTO calculation_run_archive
        (original_run_id,revenue_import_id,snapshot_json,reason,archived_at,archived_by)
        VALUES(?,?,?,?,?,?)""",
        (run_id, import_id, json.dumps(run, sort_keys=True), reason, now(), actor_id))
    db.execute("DELETE FROM calculation_runs WHERE id=?", (run_id,))
    audit(db, actor_id, "reopen", "calculation_run", run_id,
          {"hospital": run["hospital"], "physician": run["physician"],
           "period": run["period"], "archive_original_run_id": run_id,
           "revenue_import_id": import_id, "reason": reason})


@app.post("/revenue/imports/{import_id}/delete")
def import_delete(request: Request, import_id: int, confirm: str = Form(""),
                  override_approved: str = Form(""), reason: str = Form("")):
    user = require(request, "admin")
    if confirm != "delete":
        raise HTTPException(400, "Confirm deletion on the review page")
    reason_text = reason.strip() if isinstance(reason, str) else ""
    with transaction() as db:
        db.execute("BEGIN IMMEDIATE")
        imp = db.execute("SELECT * FROM revenue_imports WHERE id=?", (import_id,)).fetchone()
        if not imp:
            raise HTTPException(404)
        imp = dict(imp)
        impact = import_delete_impact(db, imp)
        if impact["issued"]:
            raise HTTPException(409, "This import affects an issued statement and cannot be deleted.")
        if impact["approved"] and override_approved != "yes":
            raise HTTPException(409, "Acknowledge the approved calculations before deleting this import.")
        approved_ids = [run["id"] for run in impact["approved"]]
        for run_id in approved_ids:
            archive_approved_run(db, run_id, user["id"],
                                 reason_text or "Revenue import replacement", import_id)
        draft_ids = [run["id"] for run in impact["drafts"]]
        for run_id in draft_ids:
            db.execute("DELETE FROM calculation_runs WHERE id=?", (run_id,))
        db.execute("DELETE FROM revenue_lines WHERE import_id=?", (import_id,))
        db.execute("DELETE FROM revenue_imports WHERE id=?", (import_id,))
        audit(db, user["id"], "delete", "revenue_import", import_id,
              {"filename": imp["filename"], "sha256": imp["sha256"],
               "accepted": imp["accepted_count"], "rejected": imp["rejected_count"],
               "invalidated_draft_runs": draft_ids,
               "reopened_approved_runs": approved_ids,
               "reason": reason_text or "Revenue import replacement"})
    stored = Path(imp["stored_path"]).resolve()
    if stored.parent != UPLOADS.resolve() or not stored.name.startswith("import_"):
        return go("/revenue/imports", "Import rows removed. Stored file path needs administrator review.")
    try:
        stored.unlink(missing_ok=True)
    except OSError:
        return go("/revenue/imports", "Import rows removed. Stored file could not be removed; check the data/uploads folder.")
    return go("/revenue/imports", "Revenue import deleted. Affected calculations must be run and approved again.")


@app.get("/revenue/export")
def revenue_export(request: Request, hospital: str, period: str):
    require(request, "admin", "finance", "auditor")
    with connect() as db:
        rows = rows_as_dict(db.execute("""SELECT raw_json FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND substr(service_date,1,7)=? ORDER BY physician,service_date,id""", (hospital, period)))
    raw = [json.loads(item["raw_json"]) for item in rows]
    if not raw:
        raise HTTPException(404, "No revenue rows for this period")
    headers = list(dict.fromkeys(key for row in raw for key in row))
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=headers, extrasaction="ignore")
    writer.writeheader(); writer.writerows(raw)
    return Response("\ufeff" + output.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="revenue_only_{period}.csv"'})


@app.get("/calculations", response_class=HTMLResponse)
def calculation_list(request: Request, period: str = "", hospital: str = "ABC Hospital"):
    if not period:
        period = date.today().strftime("%Y-%m")
    with closing(connect()) as db:
        physicians = rows_as_dict(db.execute("""SELECT physician,COUNT(*) line_count,
            ROUND(SUM(CAST(net_cash AS REAL)),2) net_cash FROM revenue_lines
            WHERE hospital=? AND substr(service_date,1,7)=? GROUP BY physician ORDER BY physician""",
            (hospital, period)))
        available_months = rows_as_dict(db.execute("""SELECT substr(service_date,1,7) month,
            COUNT(*) line_count FROM revenue_lines WHERE lower(hospital)=lower(?)
            GROUP BY substr(service_date,1,7) ORDER BY month""", (hospital,)))
        runs = rows_as_dict(db.execute("""SELECT * FROM calculation_runs WHERE hospital=? AND period=? ORDER BY id DESC""",
                                   (hospital, period)))
        agreements = rows_as_dict(db.execute("""SELECT a.id agreement_id,a.physician,v.status,v.signed_path,
            v.terms_json,v.effective_from,v.effective_to FROM agreements a JOIN agreement_versions v
            ON v.agreement_id=a.id WHERE a.archived_at IS NULL AND lower(a.hospital)=lower(?) AND v.effective_from<=?
            AND (v.effective_to IS NULL OR v.effective_to>=?) ORDER BY v.effective_from DESC,v.version DESC""",
            (hospital, period + "-01", period + "-01")))
        by_agreement = {}
        for agreement in agreements:
            by_agreement.setdefault(agreement["agreement_id"], agreement)
        agreements = list(by_agreement.values())
    latest = {}
    for run in runs:
        latest.setdefault(run["physician"], run)
    matched_agreements = set()
    for physician in physicians:
        name = physician["physician"].casefold()
        matches = [agreement for agreement in agreements if name in {
            agreement["physician"].casefold(),
            str(json.loads(agreement["terms_json"]).get("physician_legal_name", "")).strip().casefold()}]
        physician["agreement_status"] = "ambiguous" if len(matches) > 1 else (
            "signed" if matches and matches[0]["status"] in ("active", "retired") and matches[0]["signed_path"]
            else "draft" if matches else "none")
        physician["has_agreement"] = physician["agreement_status"] == "signed"
        matched_agreements.update(agreement["agreement_id"] for agreement in matches)
        physician["run"] = latest.get(physician["physician"])
    for agreement in agreements:
        if agreement["agreement_id"] in matched_agreements:
            continue
        status = ("signed" if agreement["status"] in ("active", "retired") and agreement["signed_path"]
                  else "draft")
        physicians.append({"physician": agreement["physician"], "line_count": 0, "net_cash": 0,
                           "agreement_status": status, "has_agreement": status == "signed",
                           "run": latest.get(agreement["physician"]), "no_revenue": True,
                           "legal_name": json.loads(agreement["terms_json"]).get("physician_legal_name", "")})
    physicians.sort(key=lambda row: row["physician"].casefold())
    return view(request, "calculations.html", title="Monthly calculations", physicians=physicians,
                period=period, hospital=hospital, available_months=available_months,
                selected_line_count=sum(row["line_count"] for row in physicians))


def selected_version(db, hospital: str, physician: str, period: str):
    candidates = db.execute("""SELECT v.*,a.specialty,a.physician agreement_physician FROM agreements a
        JOIN agreement_versions v ON v.agreement_id=a.id
        WHERE a.archived_at IS NULL AND lower(a.hospital)=lower(?) AND v.effective_from<=?
        AND (v.effective_to IS NULL OR v.effective_to>=?) ORDER BY v.effective_from DESC,v.version DESC""",
        (hospital, period + "-01", period + "-01")).fetchall()
    name = physician.strip().casefold()
    matches_by_agreement = {}
    for row in candidates:
        if name in {row["agreement_physician"].strip().casefold(),
                    str(json.loads(row["terms_json"]).get("physician_legal_name", "")).strip().casefold()}:
            matches_by_agreement.setdefault(row["agreement_id"], row)
    matches = list(matches_by_agreement.values())
    if len(matches) > 1:
        raise HTTPException(409, "More than one signed agreement matches this physician. Resolve the name overlap.")
    return matches[0] if matches and matches[0]["status"] in ("active", "retired") and matches[0]["signed_path"] else None


@app.post("/calculations/run")
async def calculation_run(request: Request, hospital: str = Form(...), physician: str = Form(...), period: str = Form(...)):
    user = require(request, "admin", "finance")
    try:
        month = date.fromisoformat(period + "-01")
    except ValueError as exc:
        raise HTTPException(400, "Invalid calculation month") from exc
    form = await request.form()
    counts = {}
    for key, value in form.items():
        if key.startswith("session_") and str(value).strip() != "":
            try:
                counts[key[8:]] = int(str(value))
            except ValueError as exc:
                raise HTTPException(400, "Session count must be a whole number") from exc
    quarter_start = (month.month - 1)//3*3 + 1
    qperiod = f"{month.year}-{quarter_start:02d}"
    with transaction() as db:
        version = selected_version(db, hospital, physician, period)
        if not version:
            raise HTTPException(400, "No signed agreement version applies to this physician and month")
        month_lines = rows_as_dict(db.execute("""SELECT * FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND lower(physician)=lower(?) AND substr(service_date,1,7)=? ORDER BY id""",
            (hospital, physician, period)))
        if not month_lines:
            raise HTTPException(400, f"No imported revenue lines for {physician} in {period}. Upload that service month first.")
        quarter_lines = rows_as_dict(db.execute("""SELECT * FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND lower(physician)=lower(?) AND substr(service_date,1,7)>=? AND substr(service_date,1,7)<=? ORDER BY id""",
            (hospital, physician, qperiod, period)))
        try:
            result = calculate(json.loads(version["terms_json"]), period, month_lines, quarter_lines, counts)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        status = "needs_data" if result["pending"] else "draft"
        cursor = db.execute("""INSERT INTO calculation_runs
            (hospital,physician,period,agreement_version_id,status,result_json,source_digest,created_at,created_by)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (hospital, physician, period, version["id"], status, json.dumps(result), result["source_digest"],
             now(), user["id"]))
        audit(db, user["id"], "calculate", "calculation_run", cursor.lastrowid,
              {"agreement_version_id": version["id"], "status": status})
    return go(f"/calculations/{cursor.lastrowid}", "Calculation created.")


@app.get("/calculations/{run_id}", response_class=HTMLResponse)
def calculation_detail(request: Request, run_id: int):
    with closing(connect()) as db:
        run = db.execute("""SELECT r.*,a.id agreement_id,a.specialty,v.version agreement_version,
            v.terms_json FROM calculation_runs r
            LEFT JOIN agreement_versions v ON v.id=r.agreement_version_id
            LEFT JOIN agreements a ON a.id=v.agreement_id WHERE r.id=?""", (run_id,)).fetchone()
        month_lines = rows_as_dict(db.execute("""SELECT service_category,revenue_component,department,
            service_code,payer_type FROM revenue_lines WHERE lower(hospital)=lower(?)
            AND lower(physician)=lower(?) AND substr(service_date,1,7)=?""",
            (run["hospital"], run["physician"], run["period"]))) if run else []
    if not run: raise HTTPException(404)
    result = json.loads(run["result_json"])
    diagnostics = unmatched_filter_diagnostics(json.loads(run["terms_json"]), result, month_lines) if run["terms_json"] else []
    return view(request, "calculation_detail.html", title="Calculation review", run=dict(run),
                result=result, filter_diagnostics=diagnostics)


def unmatched_filter_diagnostics(terms: dict, result: dict, lines: list[dict]) -> list[dict]:
    """Show why a variable rule found no source lines without changing signed terms."""
    fields = (
        ("categories", "service_category", "Revenue category"),
        ("components", "revenue_component", "Revenue component"),
        ("departments", "department", "Department"),
        ("service_codes", "service_code", "Service code"),
        ("payer_types", "payer_type", "Payer type"),
    )
    by_name = {rule.get("name"): rule for rule in terms.get("rules", [])}
    diagnostics = []
    for outcome in result.get("rules", []):
        if outcome.get("type") not in ("percentage", "threshold") or outcome.get("line_count") != 0:
            continue
        rule = by_name.get(outcome.get("name"), {})
        for key, line_key, label in fields:
            allowed = [str(value).strip() for value in rule.get(key, []) if str(value).strip()]
            observed = sorted({str(line.get(line_key, "")).strip() for line in lines if str(line.get(line_key, "")).strip()})
            if allowed and observed and not ({value.casefold() for value in allowed} &
                                             {value.casefold() for value in observed}):
                diagnostics.append({"rule": outcome["name"], "filter": label,
                                    "configured": ", ".join(allowed), "observed": ", ".join(observed[:8])})
    return diagnostics


@app.post("/calculations/{run_id}/approve")
def calculation_approve(request: Request, run_id: int, approve_pending: str = Form("")):
    user = require(request, "admin", "approver")
    with transaction() as db:
        run = db.execute("SELECT * FROM calculation_runs WHERE id=?", (run_id,)).fetchone()
        if not run or run["status"] not in ("draft", "needs_data"):
            raise HTTPException(400, "Only a draft calculation can be approved")
        result = json.loads(run["result_json"])
        if result["pending"] and approve_pending != "yes":
            raise HTTPException(400, "Acknowledge that this is a provisional share statement with pending inputs")
        current = rows_as_dict(db.execute("""SELECT id,line_id,gross,net_cash,net_after_cost FROM revenue_lines
            WHERE lower(hospital)=lower(?) AND lower(physician)=lower(?) AND substr(service_date,1,7)=? ORDER BY id""",
            (run["hospital"], run["physician"], run["period"])))
        from .engine import source_digest
        if source_digest(current) != run["source_digest"]:
            raise HTTPException(409, "Revenue data changed. Recalculate before approval.")
        db.execute("UPDATE calculation_runs SET status='approved',approved_at=?,approved_by=? WHERE id=?",
                   (now(), user["id"], run_id))
        audit(db, user["id"], "approve", "calculation_run", run_id,
              {"provisional": bool(result["pending"])})
    return go(f"/calculations/{run_id}", "Calculation approved.")


@app.post("/calculations/{run_id}/reopen")
def calculation_reopen(request: Request, run_id: int, confirm: str = Form(""), reason: str = Form("")):
    user = require(request, "admin", "approver")
    if confirm != "reopen":
        raise HTTPException(400, "Confirm that the approved calculation should be reopened")
    with transaction() as db:
        db.execute("BEGIN IMMEDIATE")
        archive_approved_run(db, run_id, user["id"], reason.strip() or "Calculation correction")
    return go("/calculations", "Approved calculation reopened. Recalculate and approve the corrected result.")


def approved_runs(db, hospital: str, physician: str, start: str, end: str):
    runs = rows_as_dict(db.execute("""SELECT * FROM calculation_runs WHERE lower(hospital)=lower(?)
        AND lower(physician)=lower(?) AND period>=? AND period<=? AND status IN ('approved','issued')
        ORDER BY period,id DESC""", (hospital, physician, start, end)))
    latest = {}
    for run in runs: latest.setdefault(run["period"], run)
    return [latest[p] for p in sorted(latest)]


def specialty_for_runs(db, runs: list[dict]) -> str:
    if not runs:
        return ""
    row = db.execute("""SELECT a.specialty FROM agreement_versions v JOIN agreements a
        ON a.id=v.agreement_id WHERE v.id=?""", (runs[-1]["agreement_version_id"],)).fetchone()
    return row["specialty"] if row else ""


@app.get("/statements", response_class=HTMLResponse)
def statements_page(request: Request):
    with closing(connect()) as db:
        doctors = rows_as_dict(db.execute("""SELECT hospital,physician FROM agreements
            WHERE archived_at IS NULL
            UNION SELECT hospital,physician FROM calculation_runs WHERE status IN ('approved','issued')
            ORDER BY physician"""))
        approved = rows_as_dict(db.execute("""SELECT hospital,physician,period FROM calculation_runs
            WHERE status IN ('approved','issued') ORDER BY period"""))
    months_by_doctor = {}
    for row in approved:
        months_by_doctor.setdefault((row["hospital"], row["physician"]), set()).add(row["period"])
    for doctor in doctors:
        doctor["approved_months"] = sorted(months_by_doctor.get((doctor["hospital"], doctor["physician"]), set()))
    return view(request, "statements.html", title="Physician statements", doctors=doctors,
                hospitals=sorted({doctor["hospital"] for doctor in doctors}))


@app.get("/statements/pdf")
def statement_download(request: Request, hospital: str, physician: str, start: str, end: str):
    with connect() as db:
        runs = approved_runs(db, hospital, physician, start, end)
        specialty = specialty_for_runs(db, runs)
    if not runs: raise HTTPException(404, "No approved calculation in the selected period")
    content = documents.statement_pdf(hospital, physician, specialty, runs)
    return Response(content, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="physician_statement.pdf"'})


@app.get("/statements/excel")
def excel_download(request: Request, hospital: str, physician: str, start: str, end: str):
    with connect() as db:
        runs = approved_runs(db, hospital, physician, start, end)
    if not runs: raise HTTPException(404)
    content = documents.calculation_xlsx(hospital, physician, runs)
    return Response(content, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": 'attachment; filename="physician_calculations.xlsx"'})


@app.get("/statements/email-draft")
def eml_download(request: Request, hospital: str, physician: str, start: str, end: str, to: str):
    require(request, "admin", "finance", "approver")
    if "@" not in to or "\n" in to or "\r" in to:
        raise HTTPException(400, "Enter a valid email address")
    with connect() as db:
        runs = approved_runs(db, hospital, physician, start, end)
        specialty = specialty_for_runs(db, runs)
    if not runs: raise HTTPException(404)
    pdf = documents.statement_pdf(hospital, physician, specialty, runs)
    content = documents.email_draft(to, physician, pdf, "physician_statement.pdf")
    return Response(content, media_type="message/rfc822",
                    headers={"Content-Disposition": 'attachment; filename="physician_statement_email.eml"'})


@app.post("/statements/send")
def send_statement(request: Request, hospital: str = Form(...), physician: str = Form(...),
                   start: str = Form(...), end: str = Form(...), to: str = Form(...)):
    user = require(request, "admin", "approver")
    host = os.getenv("AEC_SMTP_HOST", "")
    from_address = os.getenv("AEC_SMTP_FROM", "")
    if not host or not from_address:
        raise HTTPException(400, "SMTP is not configured. Download an email draft instead.")
    if "@" not in to or any(x in to for x in "\r\n"):
        raise HTTPException(400, "Invalid recipient")
    with connect() as db:
        runs = approved_runs(db, hospital, physician, start, end)
        specialty = specialty_for_runs(db, runs)
    if not runs: raise HTTPException(404)
    pdf = documents.statement_pdf(hospital, physician, specialty, runs)
    message = EmailMessage()
    message["From"] = from_address; message["To"] = to
    message["Subject"] = f"Physician calculation statement - {physician}"
    message.set_content(f"Dear {physician},\n\nPlease find your approved statement attached.\n\nRegards,\n{hospital} Finance")
    message.add_attachment(pdf, maintype="application", subtype="pdf", filename="physician_statement.pdf")
    port = int(os.getenv("AEC_SMTP_PORT", "587"))
    with smtplib.SMTP(host, port, timeout=20) as smtp:
        smtp.starttls()
        login = os.getenv("AEC_SMTP_USER", "")
        if login:
            smtp.login(login, os.getenv("AEC_SMTP_PASSWORD", ""))
        smtp.send_message(message)
    with transaction() as db:
        for run in runs:
            db.execute("UPDATE calculation_runs SET status='issued',issued_at=? WHERE id=?", (now(), run["id"]))
            audit(db, user["id"], "send", "calculation_run", run["id"],
                  {"recipient": to, "pdf_sha256": hashlib.sha256(pdf).hexdigest()})
    return go("/statements", "Statement sent.")


@app.get("/audit", response_class=HTMLResponse)
def audit_page(request: Request):
    require(request, "admin", "auditor")
    with connect() as db:
        events = rows_as_dict(db.execute("""SELECT e.*,u.username FROM audit_events e
            LEFT JOIN users u ON u.id=e.user_id ORDER BY e.id DESC LIMIT 200"""))
    return view(request, "audit.html", title="Audit trail", events=events)
