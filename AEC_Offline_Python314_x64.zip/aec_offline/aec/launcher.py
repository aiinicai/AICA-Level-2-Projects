"""One-click localhost launcher for Windows and other desktop systems."""
from __future__ import annotations

import socket
import subprocess
import sys
import time
import webbrowser


def main() -> int:
    command = [sys.executable, "-m", "uvicorn", "aec.app:app", "--host", "127.0.0.1", "--port", "8765"]
    server = subprocess.Popen(command)
    try:
        for _ in range(80):
            if server.poll() is not None:
                return server.returncode or 1
            try:
                with socket.create_connection(("127.0.0.1", 8765), timeout=0.3):
                    webbrowser.open("http://127.0.0.1:8765")
                    print("AEC is ready at http://127.0.0.1:8765")
                    return server.wait()
            except OSError:
                time.sleep(0.2)
        print("AEC did not start within 16 seconds. Check the messages above.")
        return 1
    except KeyboardInterrupt:
        server.terminate()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
