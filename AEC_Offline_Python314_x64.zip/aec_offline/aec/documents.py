"""Local PDF, Excel, and email-draft generation."""
from __future__ import annotations

import io
import json
from decimal import Decimal
from email.message import EmailMessage

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from .agreement_document import build_agreement_pdf
from .engine import money


def _wrap(c: canvas.Canvas, text: str, x: float, y: float, width: float,
          font: str = "Helvetica", size: float = 9, leading: float = 14) -> float:
    from reportlab.pdfbase.pdfmetrics import stringWidth
    c.setFont(font, size)
    words = str(text).split()
    line = ""
    for word in words:
        candidate = (line + " " + word).strip()
        if stringWidth(candidate, font, size) > width and line:
            c.drawString(x, y, line)
            y -= leading
            line = word
        else:
            line = candidate
    if line:
        c.drawString(x, y, line)
        y -= leading
    return y


def agreement_pdf(agreement: dict, version: dict) -> bytes:
    return build_agreement_pdf(agreement, version)


def statement_pdf(hospital: str, physician: str, specialty: str,
                  runs: list[dict]) -> bytes:
    if not runs:
        raise ValueError("Select at least one approved calculation.")
    rows = [(r["period"], json.loads(r["result_json"])) for r in runs]
    w, h = 960, 540
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(w, h))
    navy, teal, gray = HexColor("#17324D"), HexColor("#087E83"), HexColor("#526273")
    c.setFillColor(HexColor("#F7FAFB")); c.rect(0, 0, w, h, fill=1, stroke=0)
    c.setFillColor(navy); c.rect(0, h-110, w, 110, fill=1, stroke=0)
    c.setFillColor(HexColor("#FFFFFF")); c.setFont("Helvetica-Bold", 22)
    c.drawString(40, h-48, hospital)
    c.setFont("Helvetica", 12); c.drawString(40, h-75, f"{physician}  |  {specialty}")
    c.setFont("Helvetica", 10); c.drawString(40, h-95, "Physician calculation summary  |  AED")
    total_gross = sum((Decimal(result["reconciliation"]["gross"]) for _,result in rows), Decimal(0))
    total_cash = sum((Decimal(result["reconciliation"]["net_cash"]) for _,result in rows), Decimal(0))
    total_share = sum((Decimal(result["variable_total"]) for _,result in rows), Decimal(0))
    cards = [("Gross charges - all lines", total_gross), ("Net cash - all lines", total_cash),
             ("Variable/share amount", total_share)]
    for i, (label, amount) in enumerate(cards):
        x = 40 + i*300
        c.setFillColor(HexColor("#FFFFFF")); c.roundRect(x, 327, 280, 78, 9, fill=1, stroke=0)
        c.setFillColor(gray); c.setFont("Helvetica", 10); c.drawString(x+16, 380, label)
        c.setFillColor(teal if i == 2 else navy); c.setFont("Helvetica-Bold", 21)
        c.drawString(x+16, 348, f"{money(amount):,.2f}")
    c.setFillColor(navy); c.roundRect(40, 262, 880, 36, 5, fill=1, stroke=0)
    c.setFillColor(HexColor("#FFFFFF")); c.setFont("Helvetica-Bold", 9)
    for x, text in ((52,"Month"),(235,"Gross charges"),(410,"Net cash"),(590,"Variable/share"),(785,"Final total")):
        c.drawString(x, 275, text)
    if len(rows) > 4:
        raise ValueError("A one-page statement supports up to four months.")
    y = 225
    pending = []
    for period, result in rows:
        c.setFillColor(navy); c.setFont("Helvetica", 10)
        c.drawString(52, y, period)
        c.drawRightString(375, y, f"{money(result['reconciliation']['gross']):,.2f}")
        c.drawRightString(560, y, f"{money(result['reconciliation']['net_cash']):,.2f}")
        c.drawRightString(755, y, f"{money(result['variable_total']):,.2f}")
        final = result["final_total"]
        c.drawRightString(908, y, f"{money(final):,.2f}" if final is not None else "Pending")
        pending.extend(result.get("pending", []))
        c.setStrokeColor(HexColor("#D9E3E8")); c.line(40, y-12, 920, y-12)
        y -= 38
    c.setFillColor(gray); c.setFont("Helvetica", 9)
    if pending:
        _wrap(c, "Pending: " + "; ".join(dict.fromkeys(pending)), 40, 80, 880, size=9)
    c.drawString(40, 45, "Based on approved calculations. Source lines and agreement rules remain available in AEC.")
    c.setFont("Helvetica", 8); c.drawString(40, 27, "Physician-specific statement  |  Patient identifiers excluded")
    c.save()
    return buf.getvalue()


def calculation_xlsx(hospital: str, physician: str, runs: list[dict]) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)
    for run in runs:
        result = json.loads(run["result_json"])
        ws = wb.create_sheet(run["period"])
        ws.append([hospital, physician, run["period"], run["status"]])
        ws.append([])
        ws.append(["Reconciliation", "AED"])
        for key, value in result["reconciliation"].items():
            ws.append([key.replace("_", " ").title(), float(value)])
        ws.append([])
        ws.append(["Agreement rule", "Type", "Base", "Rate", "Amount"])
        for rule in result["rules"]:
            is_percent = rule["type"] in ("percentage", "threshold")
            ws.append([rule["name"], rule["type"], rule["base"],
                       float(rule["rate"]) if is_percent else rule["rate"],
                       float(rule["amount"]) if rule["amount"] is not None else "Pending"])
            if is_percent:
                ws.cell(ws.max_row, 4).number_format = "0.00%"
        ws.append(["Final total", "", "", "", result["final_total"] or "Pending"])
        ws.append([])
        ws.append(["Line ID", "Claim ID", "Service date", "Category", "Component", "Gross",
                   "Net cash", "Direct cost", "Net after cost", "Matched rules", "Decision"])
        for line in result["details"]:
            ws.append([line["line_id"], line["claim_id"], line["service_date"], line["category"],
                       line["component"], float(line["gross"]), float(line["net_cash"]),
                       float(line["direct_cost"]), float(line["net_after_cost"]),
                       ", ".join(line["rules"]), line["decision"]])
        ws.freeze_panes = "A3"
        for col in "ABCDEFGHIJK":
            ws.column_dimensions[col].width = 19 if col != "K" else 31
        for cell in ws[1]:
            cell.fill = PatternFill("solid", fgColor="17324D")
            cell.font = Font(color="FFFFFF", bold=True)
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top")
    stream = io.BytesIO(); wb.save(stream); return stream.getvalue()


def email_draft(to_address: str, physician: str, pdf: bytes, filename: str) -> bytes:
    message = EmailMessage()
    message["To"] = to_address
    message["Subject"] = f"Physician calculation statement - {physician}"
    message.set_content(
        f"Dear {physician},\n\nPlease find your approved calculation statement attached. "
        "For any question, please contact the hospital finance team.\n\nRegards,\nABC Hospital Finance\n"
    )
    message.add_attachment(pdf, maintype="application", subtype="pdf", filename=filename)
    return message.as_bytes()
