"""Detailed, version-aware physician remuneration schedule (PDF)."""
from __future__ import annotations

import io
import json
from decimal import Decimal
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (
    PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

NAVY = colors.HexColor("#17324D")
TEAL = colors.HexColor("#087E83")
MUTED = colors.HexColor("#526273")
LINE = colors.HexColor("#D9E3E8")


def _text(value, placeholder="[complete before signing]") -> str:
    value = str(value or "").strip()
    return escape(value) if value else escape(placeholder)


def _list(values) -> str:
    return ", ".join(escape(str(value)) for value in (values or [])) or "All recorded items in this field"


def _money(value) -> str:
    return f"AED {Decimal(str(value)):,.2f}"


def _label_base(base: str) -> str:
    return {
        "gross": "gross eligible charges",
        "net_allowed": "net allowed charges",
        "net_cash": "net cash collected",
        "net_after_cost": "net cash after documented direct cost",
    }.get(base, escape(base or "[specify base]"))


def _percent(value) -> str:
    return f"{(Decimal(str(value)) * 100).normalize():f}%"


def _rule_description(rule: dict) -> str:
    kind = rule.get("type")
    if kind == "percentage":
        core = f"{_percent(rule.get('rate', 0))} of {_label_base(rule.get('base'))}"
    elif kind == "fixed":
        core = f"fixed monthly amount of {_money(rule.get('amount', 0))}"
    elif kind == "session":
        core = f"{_money(rule.get('amount', 0))} per verified completed session"
    elif kind == "threshold":
        core = (f"{_percent(rule.get('rate', 0))} of quarterly "
                f"{_label_base(rule.get('base'))} above {_money(rule.get('threshold', 0))}; "
                f"payable {escape(str(rule.get('payment_timing', 'quarter_end')).replace('_', ' '))}")
    else:
        core = "[complete rule]"
    allocation = Decimal(str(rule.get("allocation_pct", 1)))
    if kind in ("percentage", "threshold") and allocation != 1:
        core += f"; {_percent(allocation)} allocation of the selected base"
    return core


def build_agreement_pdf(agreement: dict, version: dict) -> bytes:
    terms = json.loads(version["terms_json"])
    rules = terms.get("rules", [])
    hospital = _text(agreement.get("hospital"))
    physician = _text(agreement.get("physician"))
    specialty = _text(agreement.get("specialty"), "[specialty]")
    has_ancillary = any(
        category.casefold() in {"laboratory", "pharmacy", "radiology"}
        for rule in rules for category in (rule.get("categories") or [])
    )
    ancillary_approved = bool(terms.get("ancillary_approved"))

    styles = {
        "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=16, leading=20,
                                textColor=NAVY, spaceAfter=6),
        "subtitle": ParagraphStyle("subtitle", fontName="Helvetica", fontSize=8.3, leading=12,
                                   textColor=MUTED, spaceAfter=12),
        "heading": ParagraphStyle("heading", fontName="Helvetica-Bold", fontSize=10.2, leading=13,
                                  textColor=TEAL, spaceBefore=10, spaceAfter=5, keepWithNext=True),
        "body": ParagraphStyle("body", fontName="Helvetica", fontSize=8.7, leading=12.6,
                               textColor=NAVY, spaceAfter=6, allowWidows=0, allowOrphans=0),
        "small": ParagraphStyle("small", fontName="Helvetica", fontSize=7.7, leading=10.6,
                                textColor=NAVY, spaceAfter=5),
        "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=7.4, leading=10,
                               textColor=NAVY),
        "cell_head": ParagraphStyle("cell_head", fontName="Helvetica-Bold", fontSize=7.5, leading=10,
                                    textColor=colors.white),
        "note": ParagraphStyle("note", fontName="Helvetica", fontSize=7.7, leading=10.8,
                               textColor=MUTED, spaceAfter=6),
    }
    p = lambda value, style="body": Paragraph(value, styles[style])
    story = []

    def heading(title, *paragraphs):
        story.append(p(title, "heading"))
        story.extend(p(item) for item in paragraphs if item)

    def clause(number, text):
        story.append(p(f"<b>{number}</b> {text}"))

    def table(data, widths):
        t = Table(data, colWidths=widths, repeatRows=1 if len(data) > 1 else 0, hAlign="LEFT")
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F4F8F9")]),
            ("LINEBELOW", (0, -1), (-1, -1), 0.4, LINE),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(t)

    # PAGE 1 - appointment, eligibility, and negotiated remuneration.
    story.append(p("PHYSICIAN REVENUE-LINKED REMUNERATION SCHEDULE", "title"))
    story.append(p("Draft for review  |  Complete commercial particulars before signing", "subtitle"))
    particulars = [
        ("Hospital", _text(terms.get("hospital_legal_name"), agreement.get("hospital", "[legal name]"))),
        ("Hospital licence / address", _text(terms.get("hospital_licence"), "[licence number]") + "  |  " +
         _text(terms.get("hospital_address"), "[licensed branch/address]")),
        ("Physician", _text(terms.get("physician_legal_name"), agreement.get("physician", "[legal name]")) +
         f"  |  {specialty}"),
        ("Physician DoH licence", _text(terms.get("physician_licence"), "[licence number]")),
        ("Effective term", _text(version.get("effective_from")) + " to " +
         _text(version.get("effective_to"), "[open until amended/terminated]")),
        ("Related employment contract", _text(terms.get("employment_contract_ref"), "[date/reference]")),
    ]
    table([[p("Particular", "cell_head"), p("Agreed detail", "cell_head")]] +
          [[p(label, "cell"), p(value, "cell")] for label, value in particulars], [153, 348])
    story.append(Spacer(1, 7))
    story.append(p("This Schedule is intended to accompany the signed employment or professional engagement documentation. It records the commercial method for the physician's eligible services. Any mandatory requirement that applies to the parties takes precedence; the parties should revise an affected term in writing.", "small"))

    heading("1. Appointment and clinical practice")
    clause("1.1", f"The Physician will provide services for {hospital} under the { _text(terms.get('arrangement'), '[describe arrangement]') } arrangement. Practice scope: {_text(terms.get('practice_scope'), '[describe clinical scope, site and schedule]')}. Services must be within the Physician's active licence, approved clinical privileges, payer rules and Hospital policies.")
    clause("1.2", "The Physician retains independent clinical judgment. No revenue target requires an unnecessary service, referral, order, code or procedure. Care and referral decisions must be based on clinical need and the patient's interests.")

    heading("2. Remuneration structure")
    settlement = terms.get("settlement", "additive")
    if settlement == "higher_of":
        clause("2.1", "The fixed monthly wage is a floor against the calculated variable share. Total under this Schedule is the greater of the agreed fixed wage and the eligible variable amount; any variable top-up is the excess above the fixed wage. Session fees, if separately listed, are additive. The fixed wage is not reduced solely because collections are low or a claim is denied.")
    else:
        clause("2.1", "The specifically listed fixed, percentage, session and threshold components are added, subject to their eligibility filters, allocation fractions, caps and timing. No unlisted service or revenue line creates an entitlement under this Schedule.")
    if settlement == "higher_of" and not any(rule.get("type") == "fixed" for rule in rules):
        clause("2.2", "The fixed monthly wage has not yet been entered. A share amount may be calculated for review, but the final variable top-up and payroll amount remain undetermined until the wage is completed in a signed amendment.")
    else:
        clause("2.2", "The precise commercial components, rates, calculation bases and filters appear in Schedule A. A completed session must be supported by the Hospital's session record. Statutory and contractual benefits outside this Schedule remain governed by the underlying employment documentation.")
    clause("2.3", "A hybrid in-house and revenue-linked arrangement applies only to the allocation, duties and revenue categories expressly stated in Schedule A. A stated fraction of working time is not automatically the same as a fraction of revenue or a share rate.")

    heading("3. Eligible services and attribution")
    clause("3.1", "Eligible services are those personally performed or otherwise expressly attributed to the Physician, recorded under the correct identifier and satisfying the category, component, department, code and payer filters in Schedule A. Revenue attributable to another clinician is excluded unless a signed allocation method specifically provides otherwise.")
    clause("3.2", "A bundled charge or payer payment containing physician, facility and ancillary elements must be separated using a consistent, documented allocation method. A line may not be counted twice merely because it meets more than one description. Any intentional overlap must be expressly identified in Schedule A.")
    if has_ancillary:
        status = "recorded" if ancillary_approved else "not recorded"
        clause("3.3", f"Laboratory, pharmacy or radiology categories are selected. Written counsel/compliance approval for their payable inclusion is {status} in this version. Unless that approval and the signed allocation method are recorded in Schedule A, these categories remain reference-only and are excluded from the variable calculation. No payment is made solely for ordering or referring an ancillary service.")
    else:
        clause("3.3", "Laboratory, pharmacy and radiology margin is not payable under this version unless later activated through a signed amendment with a defined attribution and direct-cost method and documented counsel/compliance review.")

    story.append(PageBreak())

    # PAGE 2 - accounting definitions, reconciliation, and later adjustments.
    story.append(p("CALCULATION AND RECONCILIATION TERMS", "title"))
    story.append(p(f"{hospital}  |  {physician}  |  Agreement version {version.get('version', 1)}", "subtitle"))
    heading("4. Calculation base and adjustments")
    clause("4.1", "Gross eligible charges are the invoiced charges for lines meeting Schedule A before payer or self-pay reductions. Net allowed charges equal gross charges less applicable self-pay discount, payer adjustment and denied amount. Charges alone do not establish that cash has been received.")
    clause("4.2", "Net cash collected equals payer collections plus patient collections less refunds and payer recoupments. Net cash after cost equals net cash collected less the documented direct cost assigned to the same eligible line. The selected base for each rule is stated in Schedule A; a rule based on gross or net allowed charges may produce an amount before actual cash receipt.")
    clause("4.3", "Each discount, denial, refund, recoupment and cost is recognised once only. General overhead, rent, ordinary staffing, marketing and depreciation are excluded from direct-cost deductions unless an exact agreed method is recorded in Schedule A. A negative eligible line remains visible in the reconciliation.")
    clause("4.4", "The Hospital will reconcile claim-level and line-level records using the applicable service date, posting date and collection date. A correction or late recovery is documented as a traceable adjustment; an approved historical statement is not silently overwritten.")

    heading("5. Monthly statement and payment")
    clause("5.1", f"The Hospital will target delivery of a monthly statement within {int(terms.get('statement_due_days', 10))} days after month end. It will show eligible gross charges, reductions, denials, collections, refunds, recoupments, documented direct costs where relevant, each rule's base and rate, fixed or session amounts, prior-period adjustments and the resulting amount. Patient identifiers will be limited to what is necessary for verification.")
    clause("5.2", f"The operational collection delay is {int(terms.get('collection_delay_days', 0))} days and the payment target is {int(terms.get('payment_delay_days', 30))} days after month end, subject to the signed employment or engagement terms and applicable payroll requirements. A pending input, including an unspecified fixed wage or unverified session count, must be labelled pending rather than presented as a final payroll amount.")
    clause("5.3", "The Physician may query a statement within the objection period recorded in the underlying employment documentation. The Hospital will explain the source lines, allocation and adjustments, subject to patient confidentiality, and correct an established error in a subsequent reviewed cycle.")

    heading("6. Denials, appeals and reversals")
    clause("6.1", "The Hospital manages claim submission, follow-up and appeals under its ordinary revenue-cycle process. A denied line is reduced in a net allowed or cash-based calculation as defined in Schedule A. A successful later appeal is recognised according to the rule's selected base and the documented adjustment record.")
    clause("6.2", "A later refund, credit note or payer recoupment is matched to the relevant claim. Any corresponding reversal of variable remuneration must be specifically identified and reviewed; it does not by itself authorise a deduction from protected fixed wages or any other amount contrary to the governing employment terms.")

    heading("7. Leave, termination and open claims")
    clause("7.1", "Leave, notice, end-of-service and other employment entitlements are handled under the employment contract and applicable requirements. This Schedule does not replace those provisions.")
    clause("7.2", "On termination, the Hospital will identify open claims for services performed before the last working day and continue the agreed reconciliation process as those claims settle. The parties will retain a contact point for later statements and document any final adjustment without introducing a new retrospective allocation method.")

    story.append(PageBreak())

    # PAGE 3 - negotiated Schedule A and execution.
    story.append(p("SCHEDULE A - COMMERCIAL PARTICULARS", "title"))
    story.append(p("Complete every applicable field and initial this schedule before the arrangement starts. Attach a signed continuation sheet for additional rules or service codes.", "subtitle"))
    heading("8. Records, changes and disputes")
    clause("8.1", "The Hospital will keep auditable source, billing, collection, adjustment, cost and allocation records. Both parties will follow applicable professional conduct, employment, privacy, insurance-billing and Hospital requirements. Suspected coding or claim errors should be reported and corrected.")
    clause("8.2", "A change in rate, eligible category, calculation base, cost method, allocation, threshold or payment treatment requires a dated written amendment signed by both parties. Earlier signed versions and approved statements remain available for audit. A retroactive effect requires a separately reviewed adjustment.")
    clause("8.3", "The parties will first raise an accounting dispute with Hospital finance and medical leadership. The underlying employment documentation and applicable process govern any formal resolution. Neither party waives a mandatory right by signing this Schedule.")

    story.append(p("A1. Rule matrix", "heading"))
    rule_rows = [[p("Component", "cell_head"), p("Amount / method", "cell_head"), p("Eligibility and allocation", "cell_head")]]
    for rule in rules:
        filters = []
        for key, label in (("categories", "Categories"), ("components", "Revenue components"),
                           ("departments", "Departments"), ("service_codes", "Codes"),
                           ("payer_types", "Payer types")):
            if rule.get(key):
                filters.append(f"{label}: {_list(rule[key])}")
        if not filters:
            filters.append("All recorded services within the agreed practice scope")
        if rule.get("stackable"):
            filters.append("Intentional overlap allowed - verify signed allocation")
        rule_rows.append([p(_text(rule.get("name"), "[name]"), "cell"),
                          p(_rule_description(rule), "cell"),
                          p("<br/>".join(filters), "cell")])
    table(rule_rows, [110, 175, 216])
    story.append(Spacer(1, 7))

    operation = [
        ("Settlement", "Higher of fixed wage or variable amount" if settlement == "higher_of" else "Add separately eligible components"),
        ("Statement / payment", f"{int(terms.get('statement_due_days', 10))} / {int(terms.get('payment_delay_days', 30))} days after month end; collection delay {int(terms.get('collection_delay_days', 0))} days"),
        ("Ancillary inclusion", ("Approved - " + _text(terms.get("ancillary_approval_reference"), "[approval reference]"))
         if ancillary_approved else "Conditional / excluded until written counsel and compliance approval"),
        ("Bundled allocation / cost method", _text(terms.get("allocation_method"), "[describe and sign if applicable]")),
        ("EMDM / service code definition", _text(terms.get("service_code_definition"), "[define and list codes if applicable]")),
    ]
    table([[p("Item", "cell_head"), p("Agreed treatment", "cell_head")]] +
          [[p(label, "cell"), p(value, "cell")] for label, value in operation], [153, 348])
    if terms.get("notes"):
        story.append(Spacer(1, 6))
        story.append(p("Special conditions: " + _text(terms["notes"]), "small"))
    if version.get("amendment_reason"):
        story.append(p("Amendment reason: " + _text(version["amendment_reason"]), "small"))
    story.append(Spacer(1, 13))
    signature = Table([
        [p("For the Hospital", "cell"), p("For the Physician", "cell")],
        [p("Signature: ______________________________", "cell"), p("Signature: ______________________________", "cell")],
        [p("Name / title: ____________________________", "cell"), p("Name: __________________________________", "cell")],
        [p("Date: __________________________________", "cell"), p("Date: __________________________________", "cell")],
    ], colWidths=[250, 251], hAlign="LEFT")
    signature.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                   ("LINEABOVE", (0, 0), (-1, 0), 0.7, TEAL),
                                   ("TOPPADDING", (0, 0), (-1, -1), 6),
                                   ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    story.append(signature)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=47, rightMargin=47,
                            topMargin=66, bottomMargin=45, title="Physician remuneration schedule",
                            author="AEC Offline")

    def decorate(canvas, document):
        width, height = A4
        canvas.saveState()
        canvas.setFillColor(NAVY)
        canvas.rect(0, height - 42, width, 42, fill=1, stroke=0)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica-Bold", 8)
        canvas.drawString(47, height - 25, "PHYSICIAN REMUNERATION | DRAFT FOR REVIEW")
        canvas.setFont("Helvetica", 8)
        canvas.drawRightString(width - 47, height - 25, f"Version {version.get('version', 1)}")
        canvas.setStrokeColor(LINE)
        canvas.line(47, 35, width - 47, 35)
        canvas.setFillColor(MUTED)
        canvas.setFont("Helvetica", 7.2)
        canvas.drawString(47, 24, "Verify legal, HR and clinical particulars before signing")
        canvas.drawRightString(width - 47, 24, f"Page {document.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buffer.getvalue()
