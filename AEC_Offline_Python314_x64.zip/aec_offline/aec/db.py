from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("AEC_DATA_DIR", str(BASE / "data"))).resolve()
DB_PATH = DATA / "aec.sqlite3"
UPLOADS = DATA / "uploads"
SIGNED = DATA / "signed"


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    DATA.mkdir(parents=True, exist_ok=True)
    UPLOADS.mkdir(parents=True, exist_ok=True)
    SIGNED.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


@contextmanager
def transaction():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with transaction() as db:
        version = db.execute("PRAGMA user_version").fetchone()[0]
        if version > 4:
            raise RuntimeError(f"Database version {version} is newer than this application")
        if version == 0:
            db.executescript("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL, role TEXT NOT NULL
                CHECK(role IN ('admin','finance','approver','auditor')),
            active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE agreements (
            id INTEGER PRIMARY KEY, hospital TEXT NOT NULL, physician TEXT NOT NULL,
            specialty TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
            created_by INTEGER REFERENCES users(id)
        );
        CREATE TABLE agreement_versions (
            id INTEGER PRIMARY KEY, agreement_id INTEGER NOT NULL REFERENCES agreements(id),
            version INTEGER NOT NULL, effective_from TEXT NOT NULL,
            effective_to TEXT, status TEXT NOT NULL
                CHECK(status IN ('draft','active','retired')),
            terms_json TEXT NOT NULL, amendment_reason TEXT NOT NULL DEFAULT '',
            signed_path TEXT, created_at TEXT NOT NULL, created_by INTEGER REFERENCES users(id),
            UNIQUE(agreement_id,version)
        );
        CREATE INDEX idx_agreement_lookup ON agreements(hospital,physician);
        CREATE TABLE revenue_imports (
            id INTEGER PRIMARY KEY, hospital TEXT NOT NULL, filename TEXT NOT NULL,
            sha256 TEXT NOT NULL UNIQUE, stored_path TEXT NOT NULL,
            imported_at TEXT NOT NULL, imported_by INTEGER REFERENCES users(id),
            accepted_count INTEGER NOT NULL, rejected_count INTEGER NOT NULL,
            warnings_json TEXT NOT NULL
        );
        CREATE TABLE revenue_lines (
            id INTEGER PRIMARY KEY, import_id INTEGER NOT NULL REFERENCES revenue_imports(id),
            hospital TEXT NOT NULL, line_id TEXT NOT NULL, physician TEXT NOT NULL,
            service_date TEXT NOT NULL, posting_month TEXT, collection_date TEXT,
            service_category TEXT NOT NULL DEFAULT '', revenue_component TEXT NOT NULL DEFAULT '',
            department TEXT NOT NULL DEFAULT '', service_code TEXT NOT NULL DEFAULT '',
            payer_type TEXT NOT NULL DEFAULT '', claim_id TEXT NOT NULL DEFAULT '',
            gross TEXT NOT NULL, discount TEXT NOT NULL, adjustment TEXT NOT NULL,
            denied TEXT NOT NULL, net_allowed TEXT NOT NULL, payer_collection TEXT NOT NULL,
            patient_collection TEXT NOT NULL, refund TEXT NOT NULL, recoupment TEXT NOT NULL,
            net_cash TEXT NOT NULL, direct_cost TEXT NOT NULL, net_after_cost TEXT NOT NULL,
            raw_json TEXT NOT NULL, UNIQUE(hospital,line_id)
        );
        CREATE INDEX idx_revenue_match ON revenue_lines(hospital,physician,service_date);
        CREATE TABLE calculation_runs (
            id INTEGER PRIMARY KEY, hospital TEXT NOT NULL, physician TEXT NOT NULL,
            period TEXT NOT NULL, agreement_version_id INTEGER REFERENCES agreement_versions(id),
            status TEXT NOT NULL CHECK(status IN ('draft','needs_data','approved','issued')),
            result_json TEXT NOT NULL, source_digest TEXT NOT NULL,
            created_at TEXT NOT NULL, created_by INTEGER REFERENCES users(id),
            approved_at TEXT, approved_by INTEGER REFERENCES users(id),
            issued_at TEXT
        );
        CREATE INDEX idx_runs_lookup ON calculation_runs(hospital,physician,period);
        CREATE TABLE audit_events (
            id INTEGER PRIMARY KEY, occurred_at TEXT NOT NULL, user_id INTEGER REFERENCES users(id),
            action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER,
            details_json TEXT NOT NULL
        );
        PRAGMA user_version=1;
        """)
            version = 1
        if version == 1:
            db.executescript("""
            CREATE TABLE calculation_run_archive (
                id INTEGER PRIMARY KEY,
                original_run_id INTEGER NOT NULL UNIQUE,
                revenue_import_id INTEGER,
                snapshot_json TEXT NOT NULL,
                reason TEXT NOT NULL,
                archived_at TEXT NOT NULL,
                archived_by INTEGER REFERENCES users(id)
            );
            PRAGMA user_version=2;
            """)
            version = 2
        if version == 2:
            db.executescript("""
            CREATE TABLE calculation_run_archive_new (
                id INTEGER PRIMARY KEY,
                original_run_id INTEGER NOT NULL,
                revenue_import_id INTEGER,
                snapshot_json TEXT NOT NULL,
                reason TEXT NOT NULL,
                archived_at TEXT NOT NULL,
                archived_by INTEGER REFERENCES users(id)
            );
            INSERT INTO calculation_run_archive_new
                (id,original_run_id,revenue_import_id,snapshot_json,reason,archived_at,archived_by)
                SELECT id,original_run_id,revenue_import_id,snapshot_json,reason,archived_at,archived_by
                FROM calculation_run_archive;
            DROP TABLE calculation_run_archive;
            ALTER TABLE calculation_run_archive_new RENAME TO calculation_run_archive;
            PRAGMA user_version=3;
            """)
            version = 3
        if version == 3:
            db.executescript("""
            ALTER TABLE agreements ADD COLUMN archived_at TEXT;
            ALTER TABLE agreements ADD COLUMN archived_by INTEGER REFERENCES users(id);
            ALTER TABLE agreements ADD COLUMN archive_reason TEXT NOT NULL DEFAULT '';
            PRAGMA user_version=4;
            """)


def audit(db: sqlite3.Connection, user_id: int | None, action: str,
          entity_type: str, entity_id: int | None, details: dict | None = None) -> None:
    db.execute(
        "INSERT INTO audit_events(occurred_at,user_id,action,entity_type,entity_id,details_json) VALUES(?,?,?,?,?,?)",
        (now(), user_id, action, entity_type, entity_id, json.dumps(details or {}, sort_keys=True)),
    )
