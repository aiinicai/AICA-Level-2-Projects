"""Deterministic AED remuneration calculations. No executable user formulas."""
from __future__ import annotations

import hashlib
import json
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Any

CENT = Decimal("0.01")
BASE_FIELDS = {"gross", "net_allowed", "net_cash", "net_after_cost"}
RULE_TYPES = {"percentage", "fixed", "session", "threshold"}


def dec(value: Any) -> Decimal:
    if value is None or value == "":
        return Decimal("0")
    return Decimal(str(value))


def money(value: Any) -> Decimal:
    return dec(value).quantize(CENT, rounding=ROUND_HALF_UP)


def serial(value: Decimal | None) -> str | None:
    return None if value is None else f"{money(value):.2f}"


def validate_terms(terms: dict) -> list[str]:
    errors: list[str] = []
    if terms.get("settlement") not in ("additive", "higher_of"):
        errors.append("Settlement must be additive or higher_of.")
    if terms.get("ancillary_approved") and not str(terms.get("ancillary_approval_reference", "")).strip():
        errors.append("An ancillary approval reference is required when ancillary pay is activated.")
    if terms.get("ancillary_approved") and not str(terms.get("allocation_method", "")).strip():
        errors.append("An ancillary allocation and direct-cost method is required when ancillary pay is activated.")
    rules = terms.get("rules")
    if not isinstance(rules, list) or not rules:
        errors.append("Add at least one remuneration rule.")
        return errors
    names: set[str] = set()
    for index, rule in enumerate(rules, 1):
        name = str(rule.get("name", "")).strip()
        if not name or name in names:
            errors.append(f"Rule {index} needs a unique name.")
        names.add(name)
        kind = rule.get("type")
        if kind not in RULE_TYPES:
            errors.append(f"Rule {index} has an unsupported type.")
            continue
        if kind in ("percentage", "threshold"):
            if rule.get("base") not in BASE_FIELDS:
                errors.append(f"Rule {index} has an invalid calculation base.")
            try:
                if rule.get("rate") in (None, ""):
                    raise ValueError("Missing rate")
                rate = dec(rule.get("rate"))
                if not 0 <= rate <= 1:
                    errors.append(f"Rule {index} rate must be between 0 and 1.")
            except Exception:
                errors.append(f"Rule {index} rate is invalid.")
        if kind in ("fixed", "session"):
            try:
                if rule.get("amount") in (None, ""):
                    raise ValueError("Missing amount")
                if dec(rule.get("amount")) < 0:
                    errors.append(f"Rule {index} amount cannot be negative.")
            except Exception:
                errors.append(f"Rule {index} amount is invalid.")
        if kind == "threshold":
            try:
                if dec(rule.get("threshold")) < 0:
                    errors.append(f"Rule {index} threshold cannot be negative.")
            except Exception:
                errors.append(f"Rule {index} threshold is invalid.")
            if rule.get("period", "quarter") != "quarter":
                errors.append(f"Rule {index} supports a quarterly threshold only.")
        for key in ("categories", "components", "departments", "service_codes", "payer_types"):
            if rule.get(key, []) is not None and not isinstance(rule.get(key, []), list):
                errors.append(f"Rule {index} {key} must be a list.")
        try:
            allocation = dec(rule.get("allocation_pct", 1))
            if not 0 <= allocation <= 1:
                errors.append(f"Rule {index} allocation must be between 0 and 1.")
        except Exception:
            errors.append(f"Rule {index} allocation is invalid.")
    return errors


def matches(rule: dict, line: dict) -> bool:
    for rule_key, line_key in (
        ("categories", "service_category"), ("components", "revenue_component"),
        ("departments", "department"), ("service_codes", "service_code"),
        ("payer_types", "payer_type"),
    ):
        allowed = rule.get(rule_key) or []
        if allowed and str(line.get(line_key, "")).casefold() not in {str(x).casefold() for x in allowed}:
            return False
    return True


def source_digest(lines: list[dict]) -> str:
    payload = [(r["id"], r["line_id"], r["gross"], r["net_cash"], r["net_after_cost"]) for r in lines]
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def _line_amount(line: dict, base: str) -> Decimal:
    return dec(line[base])


def calculate(terms: dict, period: str, lines: list[dict],
              quarter_lines: list[dict] | None = None,
              session_counts: dict[str, int] | None = None) -> dict:
    """Calculate one service month; quarter_lines include current and prior quarter months."""
    errors = validate_terms(terms)
    if errors:
        raise ValueError(" ".join(errors))
    session_counts = session_counts or {}
    quarter_lines = quarter_lines if quarter_lines is not None else lines
    month_start = date.fromisoformat(period + "-01")
    month_number = month_start.month
    current_lines = [r for r in lines if str(r["service_date"])[:7] == period]
    conditional = {"laboratory", "pharmacy", "radiology"}
    def eligible_for_variable(rule: dict, line: dict) -> bool:
        if not terms.get("ancillary_approved", False) and line["service_category"].casefold() in conditional:
            return False
        return matches(rule, line)
    occupied: dict[int, str] = {}
    outcomes: list[dict] = []
    included: dict[int, list[str]] = {}
    fixed_total = Decimal("0")
    variable_total = Decimal("0")
    session_total = Decimal("0")
    pending: list[str] = []

    for rule in terms["rules"]:
        kind = rule["type"]
        label = rule["name"]
        eligible = [line for line in current_lines if eligible_for_variable(rule, line)]
        if kind in ("percentage", "threshold"):
            if not rule.get("stackable", False):
                for line in eligible:
                    if line["id"] in occupied:
                        raise ValueError(
                            f"Overlapping rules '{occupied[line['id']]}' and '{label}' on line {line['line_id']}."
                        )
                    occupied[line["id"]] = label
            for line in eligible:
                included.setdefault(line["id"], []).append(label)
        allocation = dec(rule.get("allocation_pct", 1))
        if kind == "percentage":
            base = sum((_line_amount(r, rule["base"]) for r in eligible), Decimal("0")) * allocation
            amount = money(base * dec(rule["rate"]))
            variable_total += amount
            outcomes.append({"name": label, "type": kind, "base": serial(base),
                             "rate": str(rule["rate"]), "amount": serial(amount),
                             "line_count": len(eligible)})
        elif kind == "fixed":
            amount = money(rule["amount"])
            fixed_total += amount
            outcomes.append({"name": label, "type": kind, "base": None,
                             "rate": None, "amount": serial(amount), "line_count": 0})
        elif kind == "session":
            count = session_counts.get(label)
            if count is None:
                pending.append(f"Completed sessions missing for {label}.")
                amount = None
            elif not isinstance(count, int) or count < 0:
                raise ValueError(f"Completed sessions for {label} must be a non-negative integer.")
            else:
                amount = money(dec(rule["amount"]) * count)
                session_total += amount
            outcomes.append({"name": label, "type": kind, "base": str(count) if count is not None else None,
                             "rate": str(rule["amount"]), "amount": serial(amount), "line_count": 0})
        elif kind == "threshold":
            quarter_start = (month_number - 1) // 3 * 3 + 1
            start = f"{month_start.year}-{quarter_start:02d}"
            q_lines = [r for r in quarter_lines if start <= str(r["service_date"])[:7] <= period and eligible_for_variable(rule, r)]
            prior = [r for r in q_lines if str(r["service_date"])[:7] < period]
            qtd_base = sum((_line_amount(r, rule["base"]) for r in q_lines), Decimal("0")) * allocation
            prior_base = sum((_line_amount(r, rule["base"]) for r in prior), Decimal("0")) * allocation
            threshold = dec(rule["threshold"])
            rate = dec(rule["rate"])
            current_incentive = money(max(Decimal("0"), qtd_base - threshold) * rate)
            prior_incentive = money(max(Decimal("0"), prior_base - threshold) * rate)
            accrual = current_incentive - prior_incentive
            payment_timing = rule.get("payment_timing", "quarter_end")
            payable = accrual if payment_timing == "monthly" else (current_incentive if month_number % 3 == 0 else Decimal("0"))
            variable_total += payable
            outcomes.append({"name": label, "type": kind, "base": serial(qtd_base),
                             "rate": str(rule["rate"]), "threshold": serial(threshold),
                             "accrual": serial(accrual), "amount": serial(payable),
                             "line_count": len(eligible)})

    if terms["settlement"] == "higher_of":
        if not any(r["type"] == "fixed" for r in terms["rules"]):
            pending.append("Fixed monthly wage is not specified; final variable top-up is pending.")
            final = None
            topup = None
        else:
            topup = max(Decimal("0"), variable_total - fixed_total)
            final = fixed_total + topup + session_total
    else:
        topup = variable_total
        final = fixed_total + variable_total + session_total
    if pending:
        final = None

    sums = {}
    for field in ("gross", "discount", "adjustment", "denied", "net_allowed", "payer_collection",
                  "patient_collection", "refund", "recoupment", "net_cash", "direct_cost", "net_after_cost"):
        sums[field] = serial(sum((dec(r[field]) for r in current_lines), Decimal("0")))
    ancillary = {}
    for category in ("Laboratory", "Pharmacy", "Radiology"):
        ancillary[category] = serial(sum((dec(r["net_after_cost"]) for r in current_lines
                                          if r["service_category"].casefold() == category.casefold()), Decimal("0")))
    details = [{"line_id": r["line_id"], "claim_id": r["claim_id"], "service_date": r["service_date"],
                "category": r["service_category"], "component": r["revenue_component"],
                "gross": r["gross"], "net_cash": r["net_cash"], "direct_cost": r["direct_cost"],
                "net_after_cost": r["net_after_cost"], "rules": included.get(r["id"], []),
                "decision": "Included" if r["id"] in included else
                ("Conditional ancillary category - approval not recorded"
                 if not terms.get("ancillary_approved", False) and r["service_category"].casefold() in conditional
                 else "Excluded from variable rules")}
               for r in current_lines]
    warnings = [f"Rule '{r['name']}' matched no source lines. Check its category, revenue component, department, service code and payer filters against the imported data."
                for r in outcomes if r["type"] == "percentage" and r["line_count"] == 0 and current_lines]
    return {"period": period, "reconciliation": sums, "ancillary_margins": ancillary,
            "rules": outcomes, "fixed_total": serial(fixed_total),
            "variable_total": serial(variable_total), "session_total": serial(session_total),
            "variable_topup": serial(topup), "final_total": serial(final), "warnings": warnings,
            "pending": pending, "details": details, "line_count": len(current_lines),
            "source_digest": source_digest(current_lines)}
