@echo off
cd /d "%~dp0"
set "AEC_DATA_DIR=%~dp0data"
set "AEC_EXAM_MODE=1"
if not exist ".venv\Scripts\python.exe" (
  echo AEC is not installed in this folder. Run install_offline.bat first.
  pause
  exit /b 1
)
set "AEC_PYTHON=%~dp0.venv\Scripts\python.exe"
echo AEC is starting at http://127.0.0.1:8765
"%AEC_PYTHON%" -m aec.launcher
pause
