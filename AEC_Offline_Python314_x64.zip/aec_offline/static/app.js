document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#agreement-form');
  if (form) {
    const container = document.querySelector('#rules-list');
    const errorBox = document.querySelector('#agreement-error');
    const saveButton = form.querySelector('button[type="submit"]');
    const saveLabel = saveButton.textContent;
    function showError(message, field){
      errorBox.textContent=message; errorBox.hidden=false;
      errorBox.scrollIntoView({behavior:'smooth',block:'center'});
      if(field) field.focus(); else errorBox.focus();
    }
    function clearError(){errorBox.textContent='';errorBox.hidden=true;}
    const initial = JSON.parse(document.querySelector('#initial-rules').textContent || '[]');
    const escape = value => String(value ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
    function rateFraction(value){
      const input=String(value).trim();
      if(!input)return NaN;
      const explicitPercent=input.endsWith('%');
      const number=Number(explicitPercent?input.slice(0,-1).trim():input);
      if(!Number.isFinite(number)||number<0||number>100)return NaN;
      return explicitPercent||number>=1?number/100:number;
    }
    function updatePreview(){
      const base=Number(document.querySelector('#sample-base')?.value || 0),sessions=Number(document.querySelector('#sample-sessions')?.value || 0);
      let fixed=0,variable=0,missing=false;
      for(const card of container.querySelectorAll('.rule-card')){
        const get=key=>card.querySelector(`[data-field="${key}"]`).value.trim();
        const type=get('type'),allocation=Number(get('allocation_pct')||1);
        if(type==='fixed')fixed+=Number(get('amount')||0);
        if(type==='session')variable+=Number(get('amount')||0)*sessions;
        if(type==='percentage')variable+=base*allocation*rateFraction(get('rate'));
        if(type==='threshold')variable+=Math.max(0,base*allocation-Number(get('threshold')||0))*rateFraction(get('rate'));
        if((type==='percentage'||type==='threshold')&&!Number.isFinite(rateFraction(get('rate'))))missing=true;
      }
      const settlement=form.querySelector('[name="settlement"]').value;
      const estimate=settlement==='higher_of'?Math.max(fixed,variable):fixed+variable;
      document.querySelector('#preview-total').textContent=missing?'Enter rates':`AED ${estimate.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}`;
    }
    function addRule(rule={}) {
      const card = document.createElement('div'); card.className='rule-card';
      const fields = [
        ['name','Rule name','text',rule.name || 'Revenue share'],['type','Type','select',rule.type || 'percentage'],
        ['base','Calculation base','select',rule.base || 'net_cash'],['rate','Share rate (0.35 or 35 = 35%)','text',rule.rate === undefined || rule.rate === '' ? '' : Number(rule.rate)*100],
        ['amount','Fixed / session AED','number',rule.amount ?? ''],['threshold','Quarterly threshold AED','number',rule.threshold ?? ''],
        ['allocation_pct','Allocation fraction (1 = 100%)','number',rule.allocation_pct ?? 1],
        ['payment_timing','Threshold payment','select',rule.payment_timing || 'quarter_end'],
        ['categories','Eligible revenue categories','multiselect',rule.categories || []],
        ['components','Revenue components (comma separated)','text',(rule.components || []).join(', ')],
        ['departments','Departments (comma separated)','text',(rule.departments || []).join(', ')],
        ['service_codes','Service codes (comma separated)','text',(rule.service_codes || []).join(', ')],
        ['payer_types','Payer types (comma separated)','text',(rule.payer_types || []).join(', ')],
      ];
      const options = {type:['percentage','fixed','session','threshold'],base:['net_cash','gross','net_allowed','net_after_cost'],payment_timing:['quarter_end','monthly']};
      const categories=['Consultation','EMDM Case','EMDM Procedure','Cardiology Procedure','Pulmonology Procedure','Orthopaedic Procedure','Dermatology Procedure','Procedure','Follow-up','Interpretation','Laboratory','Pharmacy','Radiology','Theatre'];
      const cells = fields.map(([key,label,type,value]) => {
        if(type==='multiselect'){
          const selected=new Set(value);
          const custom=value.filter(v=>!categories.includes(v)).join(', ');
          return `<label>${escape(label)}<select data-field="categories" multiple size="5">${categories.map(v=>`<option value="${escape(v)}" ${selected.has(v)?'selected':''}>${escape(v)}</option>`).join('')}</select><small>Use Ctrl-click for several categories. Leave all unselected for all categories.</small><input data-field="categories_custom" placeholder="Other categories, comma separated" value="${escape(custom)}"></label>`;
        }
        return `<label>${escape(label)}${type==='select'?`<select data-field="${key}">${options[key].map(v=>`<option value="${v}" ${v===value?'selected':''}>${v.replaceAll('_',' ')}</option>`).join('')}</select>`:`<input data-field="${key}" type="${type}" ${type==='number'?'step="any" min="0"':''} value="${escape(value)}">`}</label>`;
      }).join('');
      card.innerHTML=`<div class="rule-card-head"><strong>Remuneration component</strong><button type="button" class="button ghost mini remove-rule">Remove</button></div><div class="rule-fields">${cells}<label class="check"><input data-field="stackable" type="checkbox" ${rule.stackable?'checked':''}> Allow overlap intentionally</label></div>`;
      card.querySelector('.remove-rule').addEventListener('click',()=>{card.remove();updatePreview();}); container.append(card);updatePreview();
    }
    initial.forEach(addRule);
    if (!initial.length) addRule();
    document.querySelector('#add-rule').addEventListener('click',()=>addRule());
    container.addEventListener('input',updatePreview);
    container.addEventListener('change',updatePreview);
    document.querySelector('#sample-base').addEventListener('input',updatePreview);
    document.querySelector('#sample-sessions').addEventListener('input',updatePreview);
    form.querySelector('[name="settlement"]').addEventListener('change',updatePreview);
    form.addEventListener('submit',async event=>{
      event.preventDefault(); clearError();
      const effective=form.querySelector('[name="effective_from"]');
      if(effective.value && !effective.value.endsWith('-01')){
        showError('Choose the first day of the effective month. The date stored for September 2026 is 2026-09-01.',effective);return;
      }
      const ancillary=form.querySelector('[name="ancillary_approved"]');
      if(ancillary.checked){
        const approval=form.querySelector('[name="ancillary_approval_reference"]');
        const method=form.querySelector('[name="allocation_method"]');
        if(!approval.value.trim()){showError('Enter the written ancillary approval reference, or untick ancillary approval.',approval);return;}
        if(!method.value.trim()){showError('Describe the ancillary allocation and direct-cost method, or untick ancillary approval.',method);return;}
      }
      const cards=[...container.querySelectorAll('.rule-card')];
      if(!cards.length){showError('Add at least one remuneration rule.');return;}
      for(const [index,card] of cards.entries()){
        const name=card.querySelector('[data-field="name"]');
        const type=card.querySelector('[data-field="type"]').value;
        const rate=card.querySelector('[data-field="rate"]');
        const amount=card.querySelector('[data-field="amount"]');
        if(!name.value.trim()){showError(`Rule ${index+1}: enter a name.`,name);return;}
        if((type==='percentage'||type==='threshold')&&!Number.isFinite(rateFraction(rate.value))){
          showError(`Rule ${index+1}: enter 0.35 or 35 for 35%. To enter 0.35%, include the % sign.`,rate);return;
        }
        if((type==='fixed'||type==='session')&&amount.value.trim()===''){
          showError(`Rule ${index+1}: enter the fixed or session amount in AED.`,amount);return;
        }
      }
      const rules=[...container.querySelectorAll('.rule-card')].map(card=>{
        const get=key=>card.querySelector(`[data-field="${key}"]`).value.trim();
        const list=key=>get(key).split(',').map(x=>x.trim()).filter(Boolean);
        const categories=[...card.querySelector('[data-field="categories"]').selectedOptions].map(o=>o.value)
          .concat(list('categories_custom'));
        const rule={name:get('name'),type:get('type'),base:get('base'),allocation_pct:get('allocation_pct')||'1',
          categories:[...new Set(categories)],components:list('components'),departments:list('departments'),
          service_codes:list('service_codes'),payer_types:list('payer_types'),
          stackable:card.querySelector('[data-field="stackable"]').checked};
        if(rule.type==='percentage'||rule.type==='threshold') rule.rate=String(rateFraction(get('rate')));
        if(rule.type==='fixed'||rule.type==='session') rule.amount=get('amount');
        if(rule.type==='threshold'){rule.threshold=get('threshold');rule.period='quarter';rule.payment_timing=get('payment_timing');}
        return rule;
      });
      document.querySelector('#rules-json').value=JSON.stringify(rules);
      saveButton.disabled=true;saveButton.textContent='Saving…';
      try{
        const response=await fetch(form.action,{method:'POST',body:new FormData(form),credentials:'same-origin'});
        if(response.ok){window.location.assign(response.url);return;}
        const contentType=response.headers.get('content-type')||'';
        const details=contentType.includes('application/json')?await response.json():await response.text();
        const message=typeof details==='string'?details:typeof details.detail==='string'?details.detail:
          Array.isArray(details.detail)?details.detail.map(item=>item.msg).join(' '):'Please review the agreement fields.';
        showError(`Agreement was not saved: ${message}`);
      }catch(error){showError('Agreement was not saved. Check that AEC is still running, then try again.');}
      finally{saveButton.disabled=false;saveButton.textContent=saveLabel;}
    });
  }
  const statement=document.querySelector('#statement-form');
  if(statement){
    const hospital=statement.querySelector('[name="hospital"]'),physician=statement.querySelector('[name="physician"]');
    const availability=document.querySelector('#statement-availability');
    const buttons=[...statement.querySelectorAll('[data-statement]')];
    function updateAvailability(){
      const option=physician.selectedOptions[0];
      const months=(option?.dataset.months||'').split(',').filter(Boolean);
      const ready=months.length>0;
      availability.textContent=ready?`Approved months: ${months.join(', ')}. Select a month in this range.`:
        (option?`${option.value} has no approved calculation yet. Calculate and approve a month before downloading a statement.`:'No physician is available.');
      buttons.forEach(button=>{button.disabled=!ready;});
      const sendButton=document.querySelector('#send-form button[type="submit"]');
      if(sendButton)sendButton.disabled=!ready;
      if(ready){
        const start=statement.querySelector('[name="start"]'),end=statement.querySelector('[name="end"]');
        if(!start.value)start.value=months[0];
        if(!end.value)end.value=months[months.length-1];
      }
    }
    function filterDoctors(){for(const option of physician.options){option.hidden=option.dataset.hospital!==hospital.value;}if(physician.selectedOptions[0]?.hidden){physician.value=[...physician.options].find(o=>!o.hidden)?.value || '';}updateAvailability();}
    hospital.addEventListener('change',filterDoctors);physician.addEventListener('change',updateAvailability);filterDoctors();
    statement.querySelectorAll('[data-statement]').forEach(button=>button.addEventListener('click',()=>{
      if(!statement.reportValidity())return;
      const action=button.dataset.statement,params=new URLSearchParams(new FormData(statement));
      if(action==='email-draft'&&!params.get('to')){alert('Enter the doctor email for the email draft.');return;}
      if(action!=='email-draft')params.delete('to');
      location.href='/statements/'+action+'?'+params.toString();
    }));
    const send=document.querySelector('#send-form');
    if(send){
      const sync=()=>{statement.querySelectorAll('input,select').forEach(field=>{
        const target=send.querySelector(`[name="${field.name}"]`);if(target)target.value=field.value;
      });};
      statement.querySelectorAll('input,select').forEach(field=>field.addEventListener('change',sync));
      sync();
    }
  }
});
