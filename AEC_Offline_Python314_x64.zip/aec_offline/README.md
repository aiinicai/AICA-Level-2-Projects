AEC offline reviewer copy

This package starts with no agreements, revenue imports, or calculations.
The sample-agreement loader is disabled so you can create the agreements yourself.

Requirements: Windows 64-bit and Python 3.14 64-bit, already installed.
1. Extract the entire ZIP to a normal folder on the reviewer's PC.
2. Inside aec_offline, double-click install_offline.bat. It installs only from
   the bundled wheelhouse and does not need internet.
3. Double-click start_aec.bat. Keep its black window open.
4. Open http://127.0.0.1:8765 on the same PC. No login is needed.
5. Create a physician agreement, upload a signed PDF when ready, then upload
   the separately supplied ABC_Hospital_Synthetic_Revenue_Exam.xlsx workbook.
6. Run a service-month calculation and review the result.

The app uses a local database created on the reviewer's PC. No records from
the sender's installation are included. Each PC is independent.
