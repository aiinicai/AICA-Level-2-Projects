$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
python -m venv .venv
if (Test-Path -LiteralPath 'wheelhouse') {
  & .\.venv\Scripts\python.exe -m pip install --no-index --find-links .\wheelhouse -r requirements.txt
} else {
  & .\.venv\Scripts\python.exe -m pip install -r requirements.txt
}
Write-Host 'Installed. Run start_aec.bat to open AEC.'
