$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
New-Item -ItemType Directory -Path wheelhouse -Force | Out-Null
python -m pip download -r requirements.txt -d wheelhouse
Write-Host 'Copy this folder, including wheelhouse, to the offline PC and run install.ps1.'
