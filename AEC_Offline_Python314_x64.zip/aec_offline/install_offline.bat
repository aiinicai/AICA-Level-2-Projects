@echo off
setlocal
cd /d "%~dp0"
echo AEC offline setup for Windows 64-bit and Python 3.14
echo.
if not exist "wheelhouse\*.whl" (
  echo ERROR: The wheelhouse folder is missing. Extract the complete offline ZIP first.
  goto :failed
)
python -c "import sys,struct; print('Python',sys.version.split()[0],'-',struct.calcsize('P')*8,'bit'); raise SystemExit(0 if sys.version_info[:2]==(3,14) and struct.calcsize('P')*8==64 else 1)"
if errorlevel 1 (
  echo ERROR: This bundle requires 64-bit Python 3.14 available as the python command.
  goto :failed
)
if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
  if errorlevel 1 (
    echo ERROR: Python could not create the local environment.
    goto :failed
  )
)
".venv\Scripts\python.exe" -m pip install --no-index --find-links ".\wheelhouse" -r requirements.txt
if errorlevel 1 (
  echo ERROR: Offline library installation failed. Send a screenshot of this window.
  goto :failed
)
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,jinja2,multipart,openpyxl,reportlab"
if errorlevel 1 (
  echo ERROR: Installed libraries did not pass the startup check.
  goto :failed
)
echo.
echo AEC is installed. Double-click start_aec.bat to run it.
pause
exit /b 0
:failed
echo.
echo Setup stopped. Please capture the complete error shown above.
pause
exit /b 1
