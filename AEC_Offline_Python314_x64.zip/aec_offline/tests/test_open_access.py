"""Check the no-login middleware and preserved database records."""
import importlib
import gc
import sys
import tempfile
import unittest
from pathlib import Path
from contextlib import closing
from unittest.mock import patch

from starlette.requests import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def request(path: str, method: str = "GET", body: bytes = b"") -> Request:
    scope = {"type": "http", "method": method, "path": path, "raw_path": path.encode(),
             "root_path": "", "query_string": b"", "headers": [], "scheme": "http",
             "server": ("127.0.0.1", 8765), "client": ("127.0.0.1", 10000)}

    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}

    return Request(scope, receive)


class OpenAccessTests(unittest.TestCase):
    def test_open_access_and_existing_records(self):
        dbm = importlib.import_module("aec.db")
        appm = importlib.import_module("aec.app")
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as directory:
            root = Path(directory)
            with patch.object(dbm, "DATA", root), patch.object(dbm, "DB_PATH", root / "aec.sqlite3"), \
                 patch.object(dbm, "UPLOADS", root / "uploads"), patch.object(dbm, "SIGNED", root / "signed"), \
                 patch.object(appm, "DATA", root):
                dbm.init_db()
                with dbm.transaction() as db:
                    db.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                               ("Old administrator", "stored password", "admin", "2026-09-01"))
                appm.local_user()
                self.assertEqual(appm.local_user()["username"], "Local operator")

                page = request("/")
                page.state.user = appm.local_user()
                self.assertEqual(page.state.user["role"], "admin")
                self.assertEqual(appm.dashboard(page).status_code, 200)
                self.assertIn("Local operator", appm.dashboard(page).body.decode())
                self.assertEqual(appm.login_page(page).headers["location"], "/")
                self.assertEqual(len(appm.csrf(page)), 64)
                self.assertEqual(appm.load_sample_agreements(page).status_code, 303)
                with closing(dbm.connect()) as db:
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 2)
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM agreements").fetchone()[0], 4)
                    self.assertEqual(db.execute("SELECT username FROM users WHERE id=1").fetchone()[0],
                                     "Old administrator")
                del page
                gc.collect()


if __name__ == "__main__":
    unittest.main()
