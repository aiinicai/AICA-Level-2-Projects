"""Exercise the browser's agreement save path against an isolated local database."""
import json
import gc
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from fastapi import HTTPException

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class AgreementSaveTests(unittest.TestCase):
    def test_save_with_optional_fields_blank_and_validation_error(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as directory:
            previous = os.environ.get("AEC_DATA_DIR")
            os.environ["AEC_DATA_DIR"] = directory
            try:
                from aec.app import (agreement_save, selected_version, calculation_list,
                                     agreement_amend, agreement_remove, agreement_remove_page,
                                     agreement_removed_list, agreement_restore, statements_page,
                                     unmatched_filter_diagnostics)
                from aec.db import init_db, transaction
                from starlette.requests import Request
                init_db()
                with transaction() as db:
                    db.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                               ("admin", "test", "admin", "2026-09-01"))
                request = SimpleNamespace(state=SimpleNamespace(user={"id": 1, "role": "admin"}))
                data = {"request": request, "hospital": "ABC Hospital", "physician": "Dr Test",
                        "specialty": "", "effective_from": "2026-09-01", "effective_to": "",
                        "arrangement": "", "practice_scope": "", "settlement": "additive", "notes": "",
                        "rules_json": json.dumps([{"name": "Revenue share", "type": "percentage",
                                                   "base": "net_allowed", "rate": "0.35"}]),
                        "collection_delay_days": 0, "statement_due_days": 10, "payment_delay_days": 30,
                        "hospital_legal_name": "", "hospital_licence": "", "hospital_address": "",
                        "physician_legal_name": "", "physician_licence": "", "employment_contract_ref": "",
                        "ancillary_approved": "", "ancillary_approval_reference": "",
                        "allocation_method": "", "service_code_definition": "",
                        "agreement_id": 0, "draft_version_id": 0, "amendment_reason": ""}
                response = agreement_save(**data)
                self.assertEqual(response.status_code, 303)
                self.assertIn("/agreements/", response.headers["location"])
                invalid = dict(data, physician="Dr Invalid", rules_json=json.dumps([
                    {"name": "Revenue share", "type": "percentage", "base": "net_allowed", "rate": "35"}]))
                with self.assertRaises(HTTPException) as error:
                    agreement_save(**invalid)
                self.assertEqual(error.exception.status_code, 400)
                self.assertIn("rate must be between 0 and 1", error.exception.detail)
                revised = dict(data, agreement_id=1, draft_version_id=1,
                               rules_json=json.dumps([{"name": "Share", "type": "percentage",
                                                       "base": "net_cash", "rate": "0.35"}]))
                self.assertEqual(agreement_save(**revised).status_code, 303)
                with transaction() as db:
                    version = db.execute("SELECT id,terms_json FROM agreement_versions WHERE agreement_id=1").fetchone()
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM agreement_versions").fetchone()[0], 1)
                    terms = json.loads(version["terms_json"])
                    self.assertEqual(terms["rules"][0]["base"], "net_cash")
                    terms["physician_legal_name"] = "Dr Test Full Name"
                    db.execute("UPDATE agreement_versions SET status='active',signed_path=?,terms_json=? WHERE id=?",
                               ("test_signed.pdf", json.dumps(terms), version["id"]))
                with transaction() as db:
                    matched = selected_version(db, "ABC Hospital", "Dr Test Full Name", "2026-09")
                    self.assertEqual(matched["id"], version["id"])
                scope = {"type": "http", "method": "GET", "path": "/calculations", "raw_path": b"/calculations",
                         "root_path": "", "query_string": b"", "headers": [], "scheme": "http",
                         "server": ("testserver", 80), "client": ("127.0.0.1", 0)}
                page_request = Request(scope)
                page_request.state.user = {"id": 1, "username": "admin", "role": "admin"}
                page = calculation_list(page_request, "2026-09", "ABC Hospital")
                body = page.body.decode("utf-8")
                self.assertIn("No imported revenue lines", body)
                self.assertIn("Dr Test Full Name", body)
                statement = statements_page(page_request)
                self.assertIn("Dr Test", statement.body.decode())
                self.assertIn("No approved calculations yet", statement.body.decode())
                diagnostics = unmatched_filter_diagnostics(
                    {"rules": [{"name": "Share", "categories": ["A"],
                                "components": ["All Eligible CPT codes"]}]},
                    {"rules": [{"name": "Share", "type": "percentage", "line_count": 0}]},
                    [{"service_category": "Consultation", "revenue_component": "Professional"}])
                self.assertEqual({item["filter"] for item in diagnostics},
                                 {"Revenue category", "Revenue component"})
                amended = dict(data, agreement_id=1, draft_version_id=0,
                               effective_from="2026-10-01", amendment_reason="Correct eligible categories")
                amend_page = agreement_amend(page_request, 1)
                self.assertIn('name="effective_from" value="', amend_page.body.decode())
                self.assertNotIn('name="effective_from" value="2026-09-01"', amend_page.body.decode())
                self.assertEqual(agreement_save(**amended).status_code, 303)
                with transaction() as db:
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM agreement_versions WHERE agreement_id=1").fetchone()[0], 2)
                    self.assertEqual(db.execute("SELECT status FROM agreement_versions WHERE agreement_id=1 AND version=2").fetchone()[0], "draft")
                removal_page = agreement_remove_page(page_request, 1)
                self.assertIn("Remove agreement", removal_page.body.decode())
                self.assertIn("2</strong>", removal_page.body.decode())
                self.assertEqual(agreement_remove(request, 1, confirm="remove", reason="Duplicate agreement").status_code, 303)
                self.assertIn("Dr Test", agreement_removed_list(page_request).body.decode())
                with transaction() as db:
                    self.assertIsNone(selected_version(db, "ABC Hospital", "Dr Test Full Name", "2026-09"))
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM agreement_versions WHERE agreement_id=1").fetchone()[0], 2)
                self.assertEqual(agreement_restore(request, 1, confirm="restore").status_code, 303)
                with transaction() as db:
                    self.assertIsNotNone(selected_version(db, "ABC Hospital", "Dr Test Full Name", "2026-09"))
                correction = dict(data, physician="Dr Correction", physician_legal_name="",
                                  effective_from="2026-09-01")
                self.assertEqual(agreement_save(**correction).status_code, 303)
                with transaction() as db:
                    db.execute("UPDATE agreement_versions SET status='active',signed_path='original.pdf' WHERE agreement_id=2")
                correction = dict(correction, agreement_id=2, amendment_reason="Correct same-month filters")
                self.assertEqual(agreement_save(**correction).status_code, 303)
                with transaction() as db:
                    replacement_id = db.execute("SELECT id FROM agreement_versions WHERE agreement_id=2 AND version=2").fetchone()[0]
                    self.assertIsNone(selected_version(db, "ABC Hospital", "Dr Correction", "2026-09"))
                with transaction() as db:
                    db.execute("UPDATE agreement_versions SET status='retired',effective_to='2026-08-31' WHERE agreement_id=2 AND version=1")
                    db.execute("UPDATE agreement_versions SET status='active',signed_path='replacement.pdf' WHERE id=?", (replacement_id,))
                    self.assertEqual(selected_version(db, "ABC Hospital", "Dr Correction", "2026-09")["id"], replacement_id)
                    self.assertEqual(db.execute("SELECT status FROM agreement_versions WHERE agreement_id=2 AND version=1").fetchone()[0], "retired")
                del page
                del statement
                gc.collect()
            finally:
                if previous is None:
                    os.environ.pop("AEC_DATA_DIR", None)
                else:
                    os.environ["AEC_DATA_DIR"] = previous


if __name__ == "__main__":
    unittest.main()
