import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from aec.engine import calculate, validate_terms
from aec.importer import default_mapping, read_rows, validate_rows


def line(number, month, amount, category="Consultation", component="Professional"):
    return dict(id=number, line_id=f"L{number}", claim_id=f"C{number}", service_date=f"2026-{month:02d}-10",
                service_category=category, revenue_component=component, department="OP", service_code="X",
                payer_type="Insurance", gross=str(amount), discount="0", adjustment="0", denied="0",
                net_allowed=str(amount), payer_collection=str(amount), patient_collection="0", refund="0",
                recoupment="0", net_cash=str(amount), direct_cost="0", net_after_cost=str(amount))


class RuleEngineTests(unittest.TestCase):
    def test_riyaz_share_pending_fixed(self):
        terms={"settlement":"higher_of","rules":[{"name":"Professional share","type":"percentage",
               "rate":"0.33","base":"net_cash","components":["Professional"]}]}
        result=calculate(terms,"2026-07",[line(1,7,"100.00"),line(2,7,"40.00","Laboratory","Ancillary")])
        self.assertEqual(result["variable_total"],"33.00")
        self.assertIsNone(result["final_total"])
        self.assertEqual(result["ancillary_margins"]["Laboratory"],"40.00")

    def test_fixed_wage_floor(self):
        terms={"settlement":"higher_of","rules":[{"name":"Share","type":"percentage","rate":"0.25","base":"net_cash"},
               {"name":"Wage","type":"fixed","amount":"18000"}]}
        result=calculate(terms,"2026-07",[line(1,7,"1000")])
        self.assertEqual(result["variable_topup"],"0.00")
        self.assertEqual(result["final_total"],"18000.00")

    def test_sessions_need_actual_count(self):
        terms={"settlement":"additive","rules":[{"name":"Surgeon","type":"percentage","rate":"0.30","base":"net_cash"},
               {"name":"Clinic sessions","type":"session","amount":"1500"}]}
        self.assertIsNone(calculate(terms,"2026-07",[line(1,7,"1000")])["final_total"])
        result=calculate(terms,"2026-07",[line(1,7,"1000")],session_counts={"Clinic sessions":2})
        self.assertEqual(result["final_total"],"3300.00")

    def test_quarterly_threshold(self):
        terms={"settlement":"additive","rules":[{"name":"Wage","type":"fixed","amount":"20000"},
               {"name":"Quarterly incentive","type":"threshold","rate":"0.20","threshold":"180000",
                "base":"net_cash","period":"quarter"}]}
        q=[line(1,7,"70000"),line(2,8,"80000"),line(3,9,"50000")]
        result=calculate(terms,"2026-09",[q[-1]],q)
        self.assertEqual(result["rules"][1]["accrual"],"4000.00")
        self.assertEqual(result["final_total"],"24000.00")

    def test_hybrid_and_overlap(self):
        terms={"settlement":"additive","rules":[{"name":"Half-time wage","type":"fixed","amount":"12000"},
               {"name":"OP share","type":"percentage","rate":"0.20","base":"net_cash",
                "categories":["Consultation"],"allocation_pct":"0.50"}]}
        result=calculate(terms,"2026-07",[line(1,7,"1000")])
        self.assertEqual(result["final_total"],"12100.00")
        terms["rules"].append({"name":"Duplicate share","type":"percentage","rate":"0.10","base":"net_cash"})
        with self.assertRaisesRegex(ValueError,"Overlapping rules"):
            calculate(terms,"2026-07",[line(1,7,"1000")])

    def test_refund_and_recoupment_use_net_cash(self):
        x=line(1,7,"1000");x.update(refund="100",recoupment="50",net_cash="850",net_after_cost="850")
        terms={"settlement":"additive","rules":[{"name":"Share","type":"percentage","rate":"0.33","base":"net_cash"}]}
        self.assertEqual(calculate(terms,"2026-07",[x])["variable_total"],"280.50")

    def test_ancillary_requires_recorded_approval_and_method(self):
        terms={"settlement":"additive","rules":[{"name":"Lab margin","type":"percentage",
               "rate":"0.33","base":"net_after_cost","categories":["Laboratory"]}]}
        lab=line(1,7,"1000","Laboratory","Ancillary")
        lab.update(direct_cost="400",net_after_cost="600")
        self.assertEqual(calculate(terms,"2026-07",[lab])["variable_total"],"0.00")
        terms["ancillary_approved"]=True
        self.assertTrue(validate_terms(terms))
        terms["ancillary_approval_reference"]="Compliance review 2026-07-01"
        terms["allocation_method"]="Documented line attribution; deduct supplier cost only."
        self.assertFalse(validate_terms(terms))
        self.assertEqual(calculate(terms,"2026-07",[lab])["variable_total"],"198.00")

    def test_unmatched_filter_is_visible_in_result(self):
        terms={"settlement":"additive","rules":[{"name":"Share","type":"percentage",
               "rate":"0.35","base":"net_cash","categories":["A"]}]}
        result=calculate(terms,"2026-09",[line(1,9,"1000","Consultation")])
        self.assertEqual(result["variable_total"],"0.00")
        self.assertIn("matched no source lines",result["warnings"][0])

    def test_sample_july_to_september(self):
        root=Path(__file__).resolve().parents[2]
        folder=root/"outputs"/"01a14b0a-f0d9-74d0-9c4b-f2ffd5496378"
        if not folder.exists(): self.skipTest("Project sample files are not present")
        all_lines=[]
        for month in (7,8,9):
            path=folder/f"abc_hospital_revenue_dump_2026-{month:02d}.xlsx"
            headers,rows=read_rows(path.name,path.read_bytes())
            valid,rejected,_=validate_rows(rows,default_mapping(headers),"ABC Hospital",set())
            self.assertEqual(len(valid),99);self.assertFalse(rejected)
            all_lines.extend(valid)
        for i,row in enumerate(all_lines,1):row["id"]=i
        terms={"settlement":"higher_of","rules":[{"name":"Professional share","type":"percentage",
               "rate":"0.33","base":"net_cash","components":["Professional"]}]}
        amounts=[]
        for month in (7,8,9):
            period=f"2026-{month:02d}"
            doctor=[r for r in all_lines if r["physician"]=="Dr. Riyaz" and r["service_date"][:7]==period]
            amounts.append(calculate(terms,period,doctor)["variable_total"])
        self.assertEqual(amounts,["9544.75","5326.04","9381.46"])


if __name__=="__main__": unittest.main()
