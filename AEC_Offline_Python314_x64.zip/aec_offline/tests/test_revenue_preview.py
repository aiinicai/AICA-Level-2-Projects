"""Check that an uploaded revenue file reaches the column mapping page."""
import importlib
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from starlette.requests import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class RevenuePreviewTests(unittest.TestCase):
    def test_multipart_token_with_optional_part_header(self):
        appm = importlib.import_module("aec.app")
        token = "a" * 64
        for extra in (b"", b"Content-Type: text/plain; charset=utf-8\r\n"):
            body = b'Content-Disposition: form-data; name="csrf"\r\n' + extra + b"\r\n" + token.encode()
            self.assertEqual(appm.multipart_csrf(body), token)

    def test_csv_upload_opens_mapping_page(self):
        appm = importlib.import_module("aec.app")
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as directory:
            root = Path(directory)
            uploads = root / "uploads"
            uploads.mkdir()
            scope = {"type": "http", "method": "POST", "path": "/revenue/preview",
                     "raw_path": b"/revenue/preview", "root_path": "", "query_string": b"",
                     "headers": [], "scheme": "http", "server": ("127.0.0.1", 8765),
                     "client": ("127.0.0.1", 10000)}
            request = Request(scope)
            request.state.user = {"id": 1, "username": "Local operator", "role": "admin"}
            class SampleUpload:
                filename = "revenue.csv"

                async def read(self, limit):
                    return b"Line ID,Hospital\nL1,ABC Hospital\n"

            upload = SampleUpload()
            with patch.object(appm, "UPLOADS", uploads), patch.object(appm, "DATA", root):
                coroutine = appm.revenue_preview(request, "ABC Hospital", upload)
                with self.assertRaises(StopIteration) as completed:
                    coroutine.send(None)
                response = completed.exception.value
                self.assertEqual(response.status_code, 200)
                self.assertIn("Map revenue columns", response.body.decode())
                self.assertEqual(len(list(uploads.glob("pending_*.json"))), 1)


if __name__ == "__main__":
    unittest.main()
