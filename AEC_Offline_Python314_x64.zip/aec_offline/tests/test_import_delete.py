import importlib
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from fastapi import HTTPException

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class ImportDeleteTests(unittest.TestCase):
    def test_delete_invalidates_drafts_and_blocks_approved_calculations(self):
        dbm = importlib.import_module("aec.db")
        appm = importlib.import_module("aec.app")
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as directory:
            root = Path(directory)
            with patch.object(dbm, "DATA", root), patch.object(dbm, "DB_PATH", root / "aec.sqlite3"), \
                 patch.object(dbm, "UPLOADS", root / "uploads"), patch.object(dbm, "SIGNED", root / "signed"), \
                 patch.object(appm, "UPLOADS", root / "uploads"):
                dbm.init_db()
                with dbm.transaction() as db:
                    db.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                               ("admin", "test", "admin", "2026-09-01"))
                request = SimpleNamespace(state=SimpleNamespace(user={"id": 1, "role": "admin"}))

                def insert_import(filename, sha, status):
                    stored = root / "uploads" / f"import_{sha}.xlsx"
                    stored.write_bytes(b"sample")
                    with dbm.transaction() as db:
                        cursor = db.execute("""INSERT INTO revenue_imports
                            (hospital,filename,sha256,stored_path,imported_at,imported_by,accepted_count,rejected_count,warnings_json)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                            ("ABC Hospital", filename, sha, str(stored), "2026-10-18", 1, 1, 0, "{}"))
                        import_id = cursor.lastrowid
                        db.execute("""INSERT INTO revenue_lines
                            (import_id,hospital,line_id,physician,service_date,gross,discount,adjustment,denied,
                             net_allowed,payer_collection,patient_collection,refund,recoupment,net_cash,direct_cost,
                             net_after_cost,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (import_id, "ABC Hospital", f"L{sha}", "Dr Test", "2026-07-10",
                             "100", "0", "0", "0", "100", "100", "0", "0", "0", "100", "0", "100", "{}"))
                        run = db.execute("""INSERT INTO calculation_runs
                            (hospital,physician,period,status,result_json,source_digest,created_at,created_by)
                            VALUES(?,?,?,?,?,?,?,?)""",
                            ("ABC Hospital", "Dr Test", "2026-09", status, "{}", "test", "2026-10-18", 1))
                    return import_id, stored, run.lastrowid

                first_id, first_file, draft_id = insert_import("draft.xlsx", "sha1", "draft")
                response = appm.import_delete(request, first_id, confirm="delete")
                self.assertEqual(response.status_code, 303)
                self.assertFalse(first_file.exists())
                with closing(dbm.connect()) as db:
                    self.assertIsNone(db.execute("SELECT id FROM revenue_imports WHERE id=?", (first_id,)).fetchone())
                    self.assertIsNone(db.execute("SELECT id FROM calculation_runs WHERE id=?", (draft_id,)).fetchone())
                    self.assertEqual(db.execute("SELECT action FROM audit_events ORDER BY id DESC LIMIT 1").fetchone()[0], "delete")

                second_id, second_file, approved_id = insert_import("approved.xlsx", "sha2", "approved")
                with self.assertRaises(HTTPException) as blocked:
                    appm.import_delete(request, second_id, confirm="delete")
                self.assertEqual(blocked.exception.status_code, 409)
                self.assertTrue(second_file.exists())
                with closing(dbm.connect()) as db:
                    self.assertIsNotNone(db.execute("SELECT id FROM revenue_imports WHERE id=?", (second_id,)).fetchone())
                    self.assertIsNotNone(db.execute("SELECT id FROM calculation_runs WHERE id=?", (approved_id,)).fetchone())

                self.assertEqual(appm.import_delete(request, second_id, confirm="delete",
                                                    override_approved="yes", reason="Correct session inputs").status_code, 303)
                self.assertFalse(second_file.exists())
                with closing(dbm.connect()) as db:
                    self.assertIsNone(db.execute("SELECT id FROM revenue_imports WHERE id=?", (second_id,)).fetchone())
                    self.assertIsNone(db.execute("SELECT id FROM calculation_runs WHERE id=?", (approved_id,)).fetchone())
                    archived = db.execute("SELECT snapshot_json,reason,revenue_import_id FROM calculation_run_archive WHERE original_run_id=?",
                                          (approved_id,)).fetchone()
                    self.assertEqual(archived[1], "Correct session inputs")
                    self.assertEqual(archived[2], second_id)
                    self.assertIn('"status": "approved"', archived[0])

                issued_id, issued_file, issued_run_id = insert_import("issued.xlsx", "sha-issued", "issued")
                with self.assertRaises(HTTPException) as issued_block:
                    appm.import_delete(request, issued_id, confirm="delete", override_approved="yes")
                self.assertEqual(issued_block.exception.status_code, 409)
                self.assertTrue(issued_file.exists())
                with closing(dbm.connect()) as db:
                    self.assertIsNotNone(db.execute("SELECT id FROM calculation_runs WHERE id=?", (issued_run_id,)).fetchone())

                reopened_import_id, reopened_file, reopened_run_id = insert_import(
                    "session.xlsx", "sha-session", "approved")
                self.assertEqual(appm.calculation_reopen(request, reopened_run_id,
                                                          confirm="reopen", reason="Add completed session").status_code, 303)
                with closing(dbm.connect()) as db:
                    self.assertIsNone(db.execute("SELECT id FROM calculation_runs WHERE id=?", (reopened_run_id,)).fetchone())
                    self.assertIsNotNone(db.execute("SELECT id FROM revenue_imports WHERE id=?", (reopened_import_id,)).fetchone())
                    self.assertEqual(db.execute("SELECT reason FROM calculation_run_archive WHERE original_run_id=?",
                                                (reopened_run_id,)).fetchone()[0], "Add completed session")
                with dbm.transaction() as db:
                    db.execute("""INSERT INTO calculation_runs
                        (id,hospital,physician,period,status,result_json,source_digest,created_at,created_by)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                        (reopened_run_id, "ABC Hospital", "Dr Test", "2026-09", "approved",
                         "{}", "new digest", "2026-10-19", 1))
                self.assertEqual(appm.calculation_reopen(request, reopened_run_id,
                                                          confirm="reopen", reason="Second correction").status_code, 303)
                with closing(dbm.connect()) as db:
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM calculation_run_archive WHERE original_run_id=?",
                                                (reopened_run_id,)).fetchone()[0], 2)

                rejected_file = root / "uploads" / "import_rejected.xlsx"
                rejected_file.write_bytes(b"rejected sample")
                with dbm.transaction() as db:
                    rejected_id = db.execute("""INSERT INTO revenue_imports
                        (hospital,filename,sha256,stored_path,imported_at,imported_by,accepted_count,rejected_count,warnings_json)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                        ("ABC Hospital", "rejected.xlsx", "sha3", str(rejected_file),
                         "2026-10-18", 1, 0, 594, "{}" )).lastrowid
                self.assertEqual(appm.import_delete(request, rejected_id, confirm="delete").status_code, 303)
                self.assertFalse(rejected_file.exists())


if __name__ == "__main__":
    unittest.main()
