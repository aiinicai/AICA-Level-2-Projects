import React from 'react';
import { ArrowLeft, ArrowRight, Info } from 'lucide-react';
import { StressCategory } from '../types';

interface StressCheckinScreenProps {
  selectedCategory: StressCategory | null;
  userInput: string;
  intensity: number;
  onIntensityChange: (level: number) => void;
  onContinue: () => void;
  onBack: () => void;
  language?: 'en' | 'hi';
}

const SCALE_LEVELS = [
  {
    level: 1,
    labelEn: 'Light',
    labelHi: 'हल्का',
    descEn: 'Mild passing friction, easily handled',
    descHi: 'सामान्य सा तनाव, जिसे सरलता से संभाला जा सकता है',
    color: 'from-emerald-500/20 to-teal-500/10',
    selectedBg: 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white border-emerald-500 shadow-md shadow-emerald-500/25',
    activeTag: 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/80 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-300',
  },
  {
    level: 2,
    labelEn: 'Mild',
    labelHi: 'सामान्य',
    descEn: 'Noticeable distraction or concern',
    descHi: 'ध्यान भटकना या मन में हल्की चिंता की उपस्थिति',
    color: 'from-teal-500/20 to-cyan-500/10',
    selectedBg: 'bg-gradient-to-br from-teal-600 to-cyan-700 text-white border-teal-500 shadow-md shadow-teal-500/25',
    activeTag: 'border-teal-300 dark:border-teal-800 bg-teal-50/80 dark:bg-teal-950/50 text-teal-900 dark:text-teal-300',
  },
  {
    level: 3,
    labelEn: 'Moderate',
    labelHi: 'मध्यम',
    descEn: 'Active mental loop, noticeable tension',
    descHi: 'मन में लगातार विचार चलना और शरीर में खिंचाव',
    color: 'from-amber-500/20 to-orange-500/10',
    selectedBg: 'bg-gradient-to-br from-amber-600 to-orange-700 text-white border-amber-500 shadow-md shadow-amber-500/25',
    activeTag: 'border-amber-300 dark:border-amber-800 bg-amber-50/80 dark:bg-amber-950/50 text-amber-900 dark:text-amber-300',
  },
  {
    level: 4,
    labelEn: 'High',
    labelHi: 'तीव्र',
    descEn: 'Significant heaviness, hard to focus',
    descHi: 'भारीपन और अशांति, ध्यान केंद्रित करने में कठिनाई',
    color: 'from-orange-500/20 to-rose-500/10',
    selectedBg: 'bg-gradient-to-br from-orange-600 to-rose-700 text-white border-orange-500 shadow-md shadow-orange-500/25',
    activeTag: 'border-orange-300 dark:border-orange-800 bg-orange-50/80 dark:bg-orange-950/50 text-orange-900 dark:text-orange-300',
  },
  {
    level: 5,
    labelEn: 'Very High',
    labelHi: 'अत्यधिक',
    descEn: 'Intense overwhelm or acute agitation',
    descHi: 'अत्यधिक मानसिक बोझ या गहरी व्याकुलता',
    color: 'from-rose-500/20 to-pink-500/10',
    selectedBg: 'bg-gradient-to-br from-rose-600 to-pink-700 text-white border-rose-500 shadow-md shadow-rose-500/25',
    activeTag: 'border-rose-300 dark:border-rose-800 bg-rose-50/80 dark:bg-rose-950/50 text-rose-900 dark:text-rose-300',
  },
];

export const StressCheckinScreen: React.FC<StressCheckinScreenProps> = ({
  selectedCategory,
  userInput,
  intensity,
  onIntensityChange,
  onContinue,
  onBack,
  language = 'en',
}) => {
  const isHi = language === 'hi';
  const currentObj = SCALE_LEVELS.find((l) => l.level === intensity) || SCALE_LEVELS[2];

  return (
    <div className="max-w-xl mx-auto px-4 py-8 md:py-12 animate-fadeIn">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200 mb-6 transition cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>{isHi ? 'वापस अपनी स्थिति पर जाएं' : 'Back to my situation'}</span>
      </button>

      <div className="bg-white/90 dark:bg-[#15120f] rounded-3xl p-6 sm:p-8 shadow-2xl border border-stone-200/80 dark:border-amber-950/60 backdrop-blur-xs zen-glow text-stone-900 dark:text-stone-100">
        {/* Context snippet if available */}
        {(userInput || selectedCategory) && (
          <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-[#0e0c0a] border border-stone-100 dark:border-stone-800/80 mb-6">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 block mb-1">
              {isHi ? 'आपका चुना हुआ विषय / संदर्भ' : 'Context'}
            </span>
            <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2 italic">
              “{userInput || selectedCategory}”
            </p>
          </div>
        )}

        {/* Primary Question */}
        <h2 className="text-xl sm:text-2xl font-bold font-serif text-stone-900 dark:text-stone-100 mb-2">
          {isHi ? 'यह तनाव अभी आपको कितना तीव्र महसूस हो रहा है?' : 'How intense does this feel right now?'}
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mb-8 font-light">
          {isHi
            ? 'अपने शरीर और मन की वर्तमान स्थिति को परखें। जो स्तर आपकी वर्तमान स्थिति को दर्शाता है उसे चुनें।'
            : 'Tune in to your current body and mind. Select the level that reflects your immediate state.'}
        </p>

        {/* Interactive 1-5 Scale Buttons */}
        <div className="grid grid-cols-5 gap-2 sm:gap-3 mb-6">
          {SCALE_LEVELS.map((item) => {
            const isSelected = intensity === item.level;
            return (
              <button
                key={item.level}
                type="button"
                onClick={() => onIntensityChange(item.level)}
                className={`flex flex-col items-center justify-center py-4 px-2 rounded-2xl border transition-all zen-card cursor-pointer select-none ${
                  isSelected
                    ? `${item.selectedBg} scale-105`
                    : `bg-gradient-to-br ${item.color} bg-white dark:bg-[#1a1511] border-stone-200/60 dark:border-stone-800 hover:scale-[1.02]`
                }`}
              >
                <span
                  className={`text-xl font-bold mb-1 ${
                    isSelected ? 'text-white' : 'text-stone-800 dark:text-stone-200'
                  }`}
                >
                  {item.level}
                </span>
                <span
                  className={`text-[11px] font-medium truncate w-full text-center ${
                    isSelected ? 'text-white font-semibold' : 'text-stone-500 dark:text-stone-400'
                  }`}
                >
                  {isHi ? item.labelHi : item.labelEn}
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected level explanation banner */}
        <div className={`p-4 rounded-2xl border text-center mb-6 transition-colors ${currentObj.activeTag}`}>
          <div className="text-xs font-semibold mb-0.5">
            {isHi ? `स्तर ${currentObj.level}: ${currentObj.labelHi}` : `Level ${currentObj.level}: ${currentObj.labelEn}`}
          </div>
          <div className="text-xs opacity-90">
            {isHi ? currentObj.descHi : currentObj.descEn}
          </div>
        </div>

        {/* Non-clinical clarity note */}
        <div className="flex items-start gap-2 text-[11px] text-stone-400 dark:text-stone-500 mb-8 px-1">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-stone-400" />
          <span>
            {isHi
              ? 'यह आपके आत्म-अवलोकन और तनाव परिवर्तन को ट्रैक करने के लिए एक चिंतनशील पैमाना है।'
              : 'This is a personal self-reflection scale to help you observe changes in your own stress state, not a clinical assessment.'}
          </span>
        </div>

        {/* Continue Button */}
        <button
          onClick={onContinue}
          className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl font-semibold text-sm bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:via-orange-500 hover:to-amber-600 text-white transition-all shadow-md shadow-amber-600/25 active:scale-[0.99] cursor-pointer"
        >
          <span>{isHi ? 'मार्गदर्शन की ओर बढ़ें' : 'Continue to Guidance'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

