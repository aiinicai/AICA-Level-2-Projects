import React, { useState, useRef, useEffect } from 'react';
import {
  LogIn,
  LogOut,
  User,
  Shield,
  LayoutDashboard,
  CheckCircle2,
  Lock,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AuthButtonProps {
  language?: 'en' | 'hi';
}

export const AuthButton: React.FC<AuthButtonProps> = ({ language = 'en' }) => {
  const { user, profile, isLoading, isAdmin, signIn, signOut, openAdminDashboard } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const isHi = language === 'hi';

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  if (isLoading) {
    return (
      <div className="h-8 w-20 rounded-xl bg-stone-200/60 dark:bg-stone-800/60 animate-pulse" />
    );
  }

  if (!user) {
    return (
      <button
        onClick={() => signIn()}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold shadow-xs hover:shadow-md transition active:scale-95 cursor-pointer"
        title={isHi ? 'गूगल से साइन इन करें' : 'Sign in with Google'}
      >
        <LogIn className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">{isHi ? 'साइन इन' : 'Sign In'}</span>
      </button>
    );
  }

  const displayName = profile?.displayName || user.displayName || user.email?.split('@')[0] || 'Seeker';
  const initial = displayName.charAt(0).toUpperCase();

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setDropdownOpen((prev) => !prev)}
        className="flex items-center gap-1.5 p-1 sm:px-2.5 sm:py-1 rounded-xl border border-stone-200/80 dark:border-stone-800 bg-white/80 dark:bg-stone-900/80 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition cursor-pointer"
        aria-expanded={dropdownOpen}
      >
        {user.photoURL ? (
          <img
            src={user.photoURL}
            alt={displayName}
            className="w-6 h-6 rounded-full object-cover ring-1 ring-amber-500/50"
          />
        ) : (
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-amber-600 to-orange-500 text-white text-xs font-bold flex items-center justify-center shadow-xs">
            {initial}
          </div>
        )}
        <span className="text-xs font-medium max-w-[90px] truncate hidden sm:inline">
          {displayName}
        </span>
        <ChevronDown className="w-3 h-3 text-stone-400" />
      </button>

      {/* User Dropdown Menu */}
      {dropdownOpen && (
        <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-[#16120e] border border-amber-500/30 dark:border-amber-900/40 shadow-2xl p-3 z-50 animate-fadeIn text-stone-800 dark:text-stone-100 space-y-2.5">
          {/* User Info Header */}
          <div className="flex items-center gap-2.5 pb-2.5 border-b border-stone-100 dark:border-stone-800">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={displayName}
                className="w-9 h-9 rounded-full object-cover ring-2 ring-amber-500/40"
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 to-orange-500 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                {initial}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold truncate block">{displayName}</span>
                {isAdmin ? (
                  <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 border border-amber-500/40 text-amber-700 dark:text-amber-300 text-[9px] font-bold">
                    Admin
                  </span>
                ) : (
                  <span className="px-1.5 py-0.2 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-500 text-[9px] font-medium">
                    Seeker
                  </span>
                )}
              </div>
              <span className="text-[10px] text-stone-500 dark:text-stone-400 truncate block">
                {user.email}
              </span>
            </div>
          </div>

          {/* Privacy & Cloud Vault Badge */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/50 dark:border-amber-900/40 text-[11px] text-amber-800 dark:text-amber-300">
            <Lock className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
            <span className="leading-tight">
              {isHi
                ? 'निजी साधना डायरी सुरक्षित है'
                : 'Private Journal Vault active'}
            </span>
          </div>

          {/* Admin Dashboard Action (if user is admin) */}
          {isAdmin && (
            <button
              onClick={() => {
                setDropdownOpen(false);
                openAdminDashboard();
              }}
              className="w-full flex items-center gap-2 px-2.5 py-2 rounded-xl bg-gradient-to-r from-amber-600/10 to-orange-600/10 hover:from-amber-600/20 hover:to-orange-600/20 text-amber-900 dark:text-amber-200 border border-amber-500/30 text-xs font-semibold transition text-left cursor-pointer"
            >
              <LayoutDashboard className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>{isHi ? 'प्रशासक डैशबोर्ड (Admin)' : 'Admin Dashboard'}</span>
            </button>
          )}

          {/* Sign Out Button */}
          <button
            onClick={() => {
              setDropdownOpen(false);
              signOut();
            }}
            className="w-full flex items-center gap-2 px-2.5 py-2 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 text-xs font-medium transition text-left cursor-pointer"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>{isHi ? 'साइन आउट (Sign Out)' : 'Sign Out'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
