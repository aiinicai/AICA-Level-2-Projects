import React, { useState } from 'react';
import { Sun, Moon, Volume2, VolumeX, Globe } from 'lucide-react';
import { PWAInstallButton } from './pwa/PWAInstallButton';
import { AuthButton } from './auth/AuthButton';
import { UserPreferences } from '../types';
import { meditationAudio } from '../services/meditationAudio';

interface HeaderProps {
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  preferences,
  onUpdatePreferences,
  activeScreen,
  onNavigate,
}) => {
  const [isPlayingSound, setIsPlayingSound] = useState(false);

  const toggleTheme = () => {
    const nextTheme = preferences.theme === 'dark' ? 'light' : 'dark';
    onUpdatePreferences({ theme: nextTheme });
  };

  const toggleLanguage = () => {
    const nextLang = preferences.language === 'en' ? 'hi' : 'en';
    onUpdatePreferences({ language: nextLang });
  };

  const handleSoundClick = () => {
    setIsPlayingSound(true);
    meditationAudio.playMotivatingChime();
    setTimeout(() => setIsPlayingSound(false), 3500);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-amber-200/50 dark:border-amber-900/30 bg-[#FAF7F2]/90 dark:bg-[#0e0c0a]/90 backdrop-blur-xl transition-colors shadow-xs">
      <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Brand / Logo */}
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-3 text-left group focus:outline-hidden cursor-pointer"
        >
          {/* Exact Logo from Screenshot: Warm orange sunset gradient with elegant lotus droplet emblem */}
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 via-orange-500 to-rose-400 text-white flex items-center justify-center shadow-md shadow-orange-500/25 group-hover:scale-105 active:scale-95 transition-transform border border-amber-300/40">
            <svg
              className="w-5 h-5 text-amber-50 drop-shadow-xs"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 3c-1.5 3-4.5 5.5-4.5 9a4.5 4.5 0 0 0 9 0c0-3.5-3-6-4.5-9z" />
              <path d="M12 12c-2 1-3.5 3-3.5 5a3.5 3.5 0 0 0 7 0c0-2-1.5-4-3.5-5z" opacity="0.75" />
              <circle cx="12" cy="7" r="1.2" fill="currentColor" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xl tracking-tight text-stone-900 dark:text-stone-100 font-serif">
                Geeta Gyan
              </span>
            </div>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-2xl bg-amber-100/40 dark:bg-stone-900/80 border border-amber-200/40 dark:border-stone-800">
          <button
            onClick={() => onNavigate('home')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'home'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            {preferences.language === 'hi' ? 'गृह' : 'Home'}
          </button>
          <button
            onClick={() => onNavigate('daily')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'daily'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            {preferences.language === 'hi' ? 'दैनिक शांति' : 'Daily Calm'}
          </button>
          <button
            onClick={() => onNavigate('chapters')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'chapters'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            {preferences.language === 'hi' ? '१८ अध्याय' : 'Chapters'}
          </button>
          <button
            onClick={() => onNavigate('reset')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'reset'
                ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-teal-800 dark:hover:text-teal-300'
            }`}
          >
            {preferences.language === 'hi' ? '२-मिनट विराम' : '2-Min Reset'}
          </button>
          <button
            onClick={() => onNavigate('journal')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'journal'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            {preferences.language === 'hi' ? 'डायरी' : 'Journal'}
          </button>
          <button
            onClick={() => onNavigate('journey')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeScreen === 'journey'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-300 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            {preferences.language === 'hi' ? 'आत्म-यात्रा' : 'My Journey'}
          </button>
        </nav>

        {/* Controls: Sound, Theme, Language, PWA */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* PWA In-App Install Button */}
          <PWAInstallButton variant="header" />

          {/* Soothing & Motivating Sound Chime Button (Matching Screenshot icon) */}
          <button
            onClick={handleSoundClick}
            title={preferences.language === 'hi' ? 'प्रेरक एवं शांत ध्वनि सुनें' : 'Play soothing & motivating sound'}
            className={`p-2 rounded-xl border transition cursor-pointer ${
              isPlayingSound
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 animate-pulse'
                : 'border-stone-200/80 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900'
            }`}
          >
            <Volume2 className="w-4 h-4 text-amber-500 dark:text-amber-400" />
          </button>

          {/* Theme Toggle (Moon / Sun from screenshot) */}
          <button
            onClick={toggleTheme}
            aria-label="Toggle light and dark theme"
            className="p-2 rounded-xl border border-stone-200/80 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900 transition cursor-pointer"
          >
            {preferences.theme === 'dark' ? (
              <Moon className="w-4 h-4 text-amber-300" />
            ) : (
              <Sun className="w-4 h-4 text-amber-600" />
            )}
          </button>

          {/* Language Toggle (Default Hindi <-> English) */}
          <button
            onClick={toggleLanguage}
            title={preferences.language === 'en' ? 'Switch to हिन्दी' : 'Switch to English'}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-stone-200/80 dark:border-stone-800 text-xs font-semibold text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900 transition cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            <span>{preferences.language === 'hi' ? 'हिन्दी' : 'EN'}</span>
          </button>

          {/* User Sign In / Profile / Admin Badge */}
          <AuthButton language={preferences.language} />
        </div>
      </div>
    </header>
  );
};
