import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  Sparkles,
  Clock,
  Compass,
  Volume2,
  VolumeX,
  Shuffle,
  Copy,
  Check,
  Quote,
  Briefcase,
  Brain,
  AlertCircle,
  HelpCircle,
  Shield,
  Coins,
  Home as HomeIcon,
  Layers,
  Flame,
  Users,
  X,
  BookOpen,
  Heart,
  HeartHandshake,
  UserX,
  Activity,
  RotateCcw,
  GitBranch,
  Moon,
  Sun,
  TrendingUp,
} from 'lucide-react';
import { StressCategory, ReadingProgress } from '../types';
import { DAILY_AFFIRMATIONS, DailyAffirmation } from '../data/verses';
import { meditationAudio } from '../services/meditationAudio';
import {
  getReadingProgress,
  getNextVerseToRead,
  getOverallReadStats,
  subscribeToReadingProgress,
} from '../services/readingProgressService';
import { StatusImageGeneratorModal, StatusVerseData } from './StatusImageGeneratorModal';

interface HomeScreenProps {
  selectedCategory: StressCategory | null;
  onSelectCategory: (cat: StressCategory | null) => void;
  userInput: string;
  onUserInputChange: (val: string) => void;
  onSubmit: () => void;
  onQuickReset: () => void;
  onExploreChapters?: (chapterNumber?: number, verseNumber?: number) => void;
  language?: 'en' | 'hi';
  spokenLanguage?: 'hi' | 'en';
}

interface StressChipDef {
  id: string;
  category: StressCategory;
  labelEn: string;
  labelHi: string;
  icon: React.ComponentType<{ className?: string }>;
  borderStyle: string;
  bgStyle: string;
  textStyle: string;
  iconColor: string;
}

// Exactly 11 Color-Coded Chips matching the user's reference screenshot
const STRESS_CHIPS: StressChipDef[] = [
  {
    id: 'work',
    category: 'Work Pressure',
    labelEn: 'Work Pressure',
    labelHi: 'काम का दबाव',
    icon: Briefcase,
    borderStyle: 'border-[#3b82f6]/70 dark:border-[#3b82f6]/70',
    bgStyle: 'bg-blue-950/30 dark:bg-[#1e293b]/40',
    textStyle: 'text-blue-700 dark:text-[#93c5fd]',
    iconColor: 'text-[#3b82f6]',
  },
  {
    id: 'overthinking',
    category: 'Overthinking',
    labelEn: 'Overthinking',
    labelHi: 'अति-विचार',
    icon: Brain,
    borderStyle: 'border-[#8b5cf6]/70 dark:border-[#8b5cf6]/70',
    bgStyle: 'bg-purple-950/30 dark:bg-[#2e1065]/40',
    textStyle: 'text-purple-700 dark:text-[#c4b5fd]',
    iconColor: 'text-[#8b5cf6]',
  },
  {
    id: 'failure',
    category: 'Fear of Failure',
    labelEn: 'Fear of Failure',
    labelHi: 'असफलता का भय',
    icon: AlertCircle,
    borderStyle: 'border-[#d97706]/80 dark:border-[#d97706]/80',
    bgStyle: 'bg-amber-950/30 dark:bg-[#451a03]/40',
    textStyle: 'text-amber-800 dark:text-[#fcd34d]',
    iconColor: 'text-[#d97706]',
  },
  {
    id: 'uncertainty',
    category: 'Uncertainty',
    labelEn: 'Uncertainty',
    labelHi: 'अनिश्चितता',
    icon: HelpCircle,
    borderStyle: 'border-[#06b6d4]/70 dark:border-[#06b6d4]/70',
    bgStyle: 'bg-cyan-950/30 dark:bg-[#083344]/40',
    textStyle: 'text-cyan-700 dark:text-[#67e8f9]',
    iconColor: 'text-[#06b6d4]',
  },
  {
    id: 'conflict',
    category: 'Conflict',
    labelEn: 'Conflict & Hurt',
    labelHi: 'टकराव और आहत',
    icon: Shield,
    borderStyle: 'border-[#10b981]/70 dark:border-[#10b981]/70',
    bgStyle: 'bg-emerald-950/30 dark:bg-[#064e3b]/40',
    textStyle: 'text-emerald-700 dark:text-[#6ee7b7]',
    iconColor: 'text-[#10b981]',
  },
  {
    id: 'money',
    category: 'Money Worries',
    labelEn: 'Financial Worry',
    labelHi: 'आर्थिक चिंता',
    icon: Coins,
    borderStyle: 'border-[#14b8a6]/70 dark:border-[#14b8a6]/70',
    bgStyle: 'bg-teal-950/30 dark:bg-[#134e4a]/40',
    textStyle: 'text-teal-700 dark:text-[#5eead4]',
    iconColor: 'text-[#14b8a6]',
  },
  {
    id: 'family',
    category: 'Family Pressure',
    labelEn: 'Family Expectations',
    labelHi: 'पारिवारिक अपेक्षाएँ',
    icon: HomeIcon,
    borderStyle: 'border-[#e11d48]/70 dark:border-[#e11d48]/70',
    bgStyle: 'bg-rose-950/30 dark:bg-[#4c0519]/40',
    textStyle: 'text-rose-700 dark:text-[#fda4af]',
    iconColor: 'text-[#e11d48]',
  },
  {
    id: 'overwhelmed',
    category: 'Feeling Overwhelmed',
    labelEn: 'Feeling Overwhelmed',
    labelHi: 'अत्यधिक मानसिक बोझ',
    icon: Layers,
    borderStyle: 'border-[#6366f1]/70 dark:border-[#6366f1]/70',
    bgStyle: 'bg-indigo-950/30 dark:bg-[#1e1b4b]/40',
    textStyle: 'text-indigo-700 dark:text-[#a5b4fc]',
    iconColor: 'text-[#6366f1]',
  },
  {
    id: 'anger',
    category: 'Anger',
    labelEn: 'Anger & Frustration',
    labelHi: 'क्रोध और अशांति',
    icon: Flame,
    borderStyle: 'border-[#0d9488]/70 dark:border-[#0d9488]/70',
    bgStyle: 'bg-teal-950/30 dark:bg-[#134e4a]/40',
    textStyle: 'text-teal-700 dark:text-[#5eead4]',
    iconColor: 'text-[#0d9488]',
  },
  {
    id: 'comparison',
    category: 'Comparison',
    labelEn: 'Comparison & Envy',
    labelHi: 'तुलना और ईर्ष्या',
    icon: Users,
    borderStyle: 'border-[#a855f7]/80 dark:border-[#a855f7]/80',
    bgStyle: 'bg-purple-950/40 dark:bg-[#3b0764]/40',
    textStyle: 'text-purple-700 dark:text-[#d8b4fe]',
    iconColor: 'text-[#a855f7]',
  },
  {
    id: 'motivation',
    category: 'Lack of Motivation',
    labelEn: 'Need Motivation',
    labelHi: 'प्रेरणा की आवश्यकता',
    icon: Compass,
    borderStyle: 'border-[#b45309]/80 dark:border-[#b45309]/80',
    bgStyle: 'bg-amber-950/30 dark:bg-[#451a03]/40',
    textStyle: 'text-amber-800 dark:text-[#fde68a]',
    iconColor: 'text-[#b45309]',
  },
];

const MORE_STRESS_CHIPS: StressChipDef[] = [
  {
    id: 'relationship',
    category: 'Relationship Stress',
    labelEn: 'Relationship & Heartbreak',
    labelHi: 'संबंध और वैवाहिक तनाव',
    icon: Heart,
    borderStyle: 'border-[#ec4899]/70 dark:border-[#ec4899]/70',
    bgStyle: 'bg-pink-950/30 dark:bg-[#500724]/40',
    textStyle: 'text-pink-700 dark:text-[#f472b6]',
    iconColor: 'text-[#ec4899]',
  },
  {
    id: 'grief',
    category: 'Grief & Loss',
    labelEn: 'Grief & Mourning',
    labelHi: 'शोक और विछोह',
    icon: HeartHandshake,
    borderStyle: 'border-[#94a3b8]/70 dark:border-[#94a3b8]/70',
    bgStyle: 'bg-slate-950/30 dark:bg-[#0f172a]/40',
    textStyle: 'text-slate-600 dark:text-[#94a3b8]',
    iconColor: 'text-[#64748b]',
  },
  {
    id: 'loneliness',
    category: 'Loneliness',
    labelEn: 'Loneliness & Solitude',
    labelHi: 'अकेलापन और उपेक्षा',
    icon: UserX,
    borderStyle: 'border-[#818cf8]/70 dark:border-[#818cf8]/70',
    bgStyle: 'bg-indigo-950/30 dark:bg-[#1e1b4b]/40',
    textStyle: 'text-indigo-600 dark:text-[#818cf8]',
    iconColor: 'text-[#6366f1]',
  },
  {
    id: 'health',
    category: 'Health & Illness',
    labelEn: 'Health & Physical Pain',
    labelHi: 'स्वास्थ्य और शारीरिक कष्ट',
    icon: Activity,
    borderStyle: 'border-[#10b981]/70 dark:border-[#10b981]/70',
    bgStyle: 'bg-emerald-950/30 dark:bg-[#064e3b]/40',
    textStyle: 'text-emerald-700 dark:text-[#6ee7b7]',
    iconColor: 'text-[#10b981]',
  },
  {
    id: 'guilt',
    category: 'Guilt & Regret',
    labelEn: 'Guilt & Past Remorse',
    labelHi: 'पछतावा और अपराधबोध',
    icon: RotateCcw,
    borderStyle: 'border-[#f59e0b]/70 dark:border-[#f59e0b]/70',
    bgStyle: 'bg-amber-950/30 dark:bg-[#451a03]/40',
    textStyle: 'text-amber-700 dark:text-[#fbbf24]',
    iconColor: 'text-[#f59e0b]',
  },
  {
    id: 'decision',
    category: 'Decision Paralysis',
    labelEn: 'Decision Dilemma',
    labelHi: 'निर्णय में असमंजस',
    icon: GitBranch,
    borderStyle: 'border-[#06b6d4]/70 dark:border-[#06b6d4]/70',
    bgStyle: 'bg-cyan-950/30 dark:bg-[#083344]/40',
    textStyle: 'text-cyan-700 dark:text-[#22d3ee]',
    iconColor: 'text-[#06b6d4]',
  },
  {
    id: 'sleep',
    category: 'Sleep & Exhaustion',
    labelEn: 'Sleep & Burnout',
    labelHi: 'अनिद्रा, थकान और बर्नआउट',
    icon: Moon,
    borderStyle: 'border-[#6366f1]/70 dark:border-[#6366f1]/70',
    bgStyle: 'bg-indigo-950/30 dark:bg-[#1e1b4b]/40',
    textStyle: 'text-indigo-700 dark:text-[#a5b4fc]',
    iconColor: 'text-[#6366f1]',
  },
  {
    id: 'purpose',
    category: 'Purpose & Inner Peace',
    labelEn: 'Purpose & Meaning',
    labelHi: 'जीवन का उद्देश्य और शांति',
    icon: Sun,
    borderStyle: 'border-[#eab308]/70 dark:border-[#eab308]/70',
    bgStyle: 'bg-yellow-950/30 dark:bg-[#422006]/40',
    textStyle: 'text-yellow-700 dark:text-[#fde047]',
    iconColor: 'text-[#eab308]',
  },
  {
    id: 'career',
    category: 'Career Uncertainty',
    labelEn: 'Career Direction',
    labelHi: 'करियर और भविष्य का संशय',
    icon: TrendingUp,
    borderStyle: 'border-[#3b82f6]/70 dark:border-[#3b82f6]/70',
    bgStyle: 'bg-blue-950/30 dark:bg-[#172554]/40',
    textStyle: 'text-blue-700 dark:text-[#93c5fd]',
    iconColor: 'text-[#3b82f6]',
  },
];

const SAMPLE_PROMPT_EN = 'I have too many deadlines and I keep worrying that I will make a mistake.';
const SAMPLE_PROMPT_HI = 'मेरे पास कई जिम्मेदारियां हैं और मुझे भय है कि कहीं कोई चूक न हो जाए।';

export const HomeScreen: React.FC<HomeScreenProps> = ({
  selectedCategory,
  onSelectCategory,
  userInput,
  onUserInputChange,
  onSubmit,
  onQuickReset,
  onExploreChapters,
  language = 'en',
  spokenLanguage = 'hi',
}) => {
  const isHi = language === 'hi';

  const [show10sBreath, setShow10sBreath] = useState(false);
  const [breathTimer, setBreathTimer] = useState(10);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [showMoreTopics, setShowMoreTopics] = useState(false);

  // Handle 10s Breath Mode
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (show10sBreath) {
      setBreathTimer(10);
      setBreathPhase('Inhale');
      meditationAudio.playMotivatingChime();
      meditationAudio.speakBreathCue('Inhale', 'simple', spokenLanguage);

      interval = setInterval(() => {
        setBreathTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setTimeout(() => setShow10sBreath(false), 900);
            return 0;
          }
          const next = prev - 1;
          if (next === 6) {
            setBreathPhase('Hold');
            meditationAudio.speakBreathCue('Hold', 'simple', spokenLanguage);
          } else if (next === 4) {
            setBreathPhase('Exhale');
            meditationAudio.speakBreathCue('Exhale', 'simple', spokenLanguage);
          }
          return next;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [show10sBreath, spokenLanguage]);

  const handleChipClick = (cat: StressCategory) => {
    if (selectedCategory === cat) {
      onSelectCategory(null);
    } else {
      onSelectCategory(cat);
      // Play soft soothing confirmation chime
      meditationAudio.playSingingBowl(288, 2.0);
    }
  };

  const handleUseExample = () => {
    onUserInputChange(isHi ? SAMPLE_PROMPT_HI : SAMPLE_PROMPT_EN);
    onSelectCategory('Work Pressure');
  };

  const isReady = userInput.trim().length > 0 || selectedCategory !== null;

  // Daily Affirmation State
  const initialAffirmationIdx = React.useMemo(() => {
    const today = new Date();
    const dayOfYear = Math.floor(
      (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
    );
    return Math.abs(dayOfYear) % DAILY_AFFIRMATIONS.length;
  }, []);

  const [affirmationIdx, setAffirmationIdx] = useState(initialAffirmationIdx);
  const [affirmationLang, setAffirmationLang] = useState<'en' | 'hi'>(language);
  const [isAffirmationSpeaking, setIsAffirmationSpeaking] = useState(false);
  const [copiedAffirmation, setCopiedAffirmation] = useState(false);

  // Reading progress state
  const [readingProgress, setReadingProgress] = useState<ReadingProgress>(getReadingProgress);
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [statusModalVerse, setStatusModalVerse] = useState<StatusVerseData | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToReadingProgress((newProgress) => {
      setReadingProgress(newProgress);
    });
    return unsubscribe;
  }, []);

  const overallStats = React.useMemo(() => {
    return getOverallReadStats(readingProgress);
  }, [readingProgress]);

  const nextVerseToRead = React.useMemo(() => {
    return getNextVerseToRead(readingProgress);
  }, [readingProgress]);

  const handleOpenAffirmationStatus = () => {
    setStatusModalVerse({
      chapter: currentAffirmation.chapter,
      verse: currentAffirmation.verseNumber,
      sanskrit: currentAffirmation.sanskrit,
      transliteration: currentAffirmation.transliteration,
      hindi: currentAffirmation.affirmationHi,
      english: currentAffirmation.affirmationEn,
      positiveMessage: isHi
        ? `आज का प्रेरक विचार: ${currentAffirmation.affirmationHi}`
        : `Thought for Today: ${currentAffirmation.affirmationEn}`,
    });
    setStatusModalOpen(true);
  };

  useEffect(() => {
    setAffirmationLang(language);
  }, [language]);

  const currentAffirmation: DailyAffirmation =
    DAILY_AFFIRMATIONS[affirmationIdx] || DAILY_AFFIRMATIONS[0];

  const handleNextAffirmation = () => {
    setIsAffirmationSpeaking(false);
    meditationAudio.stopSpeaking();
    setAffirmationIdx((prev) => (prev + 1) % DAILY_AFFIRMATIONS.length);
    meditationAudio.playMotivatingChime();
  };

  const handleToggleAffirmationAudio = () => {
    if (isAffirmationSpeaking) {
      setIsAffirmationSpeaking(false);
      meditationAudio.stopSpeaking();
    } else {
      setIsAffirmationSpeaking(true);
      const speechLang = spokenLanguage || 'hi';
      const textToSpeak =
        speechLang === 'hi'
          ? `${currentAffirmation.affirmationHi}। श्रीमद्भगवद्गीता अध्याय ${currentAffirmation.chapter}, श्लोक ${currentAffirmation.verseNumber}।`
          : `${currentAffirmation.affirmationEn}. From the Bhagavad Gita, Chapter ${currentAffirmation.chapter}, Verse ${currentAffirmation.verseNumber}.`;
      meditationAudio.speakAffirmation(textToSpeak, speechLang, () => {
        setIsAffirmationSpeaking(false);
      });
    }
  };

  const handleCopyAffirmation = () => {
    const textToCopy = `${currentAffirmation.sanskrit}\n\n"${
      affirmationLang === 'hi' ? currentAffirmation.affirmationHi : currentAffirmation.affirmationEn
    }"\n— Bhagavad Gita ${currentAffirmation.chapter}.${currentAffirmation.verseNumber}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedAffirmation(true);
    setTimeout(() => setCopiedAffirmation(false), 2200);
  };

  // Time of day greeting pill matching screenshot exactly
  const timeGreeting = React.useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 20 || hour < 5) {
      return {
        icon: '🌙',
        hindi: 'शान्त रात्रि',
        english: 'Shant Ratri • Restful Stillness',
      };
    }
    if (hour < 12) {
      return {
        icon: '🌅',
        hindi: 'शान्त प्रभात',
        english: 'Shant Prabhat • Morning Calm',
      };
    }
    if (hour < 17) {
      return {
        icon: '☀️',
        hindi: 'शान्त मध्याह्न',
        english: 'Shant Madhyahan • Afternoon Stillness',
      };
    }
    return {
      icon: '🌇',
      hindi: 'शान्त संध्या',
      english: 'Shant Sandhya • Evening Peace',
    };
  }, []);

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 animate-fadeIn space-y-6">
      {/* 1. Time-of-Day Greeting Pill from Screenshot */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-stone-900/80 dark:bg-[#171310] border border-amber-600/40 text-xs shadow-md">
          <span className="text-amber-400 text-sm">{timeGreeting.icon}</span>
          <span className="font-bold text-amber-400 tracking-wide font-serif">{timeGreeting.hindi}</span>
          <span className="text-stone-400 font-light">•</span>
          <span className="text-stone-300 font-medium text-[11px]">{timeGreeting.english}</span>
        </div>
      </div>

      {/* 2. Hero Title & Subtitle */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight font-serif bg-gradient-to-r from-[#fed7aa] via-[#fde047] to-[#fdba74] bg-clip-text text-transparent drop-shadow-sm">
          Geeta Gyan
        </h1>
        <p className="text-base sm:text-lg text-stone-600 dark:text-stone-300 font-light max-w-lg mx-auto leading-relaxed">
          {isHi
            ? 'अपने विचारों को विराम दें। सब कुछ अपने समय पर शांत होगा।'
            : 'Lay down your thoughts. Everything will be met in its time.'}
        </p>
      </div>

      {/* 3. Featured Scenic Card: "GENTLE TRUTH FOR THIS HOUR" with scenic dawn lake & 🌸 10s Breath */}
      <div className="relative rounded-3xl overflow-hidden border border-amber-500/40 shadow-2xl bg-[#0c0907] text-stone-100 cinema-glow group">
        {/* Scenic Background Illustration (Misty lake, pagoda, mountains & glowing lotus) */}
        <div className="relative aspect-[16/9] sm:aspect-[2.1/1] w-full overflow-hidden select-none bg-gradient-to-b from-[#1c130d] via-[#140e0a] to-[#0a0705]">
          <svg className="absolute inset-0 w-full h-full object-cover" viewBox="0 0 800 420" preserveAspectRatio="xMidYMid slice">
            <defs>
              <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#2e1a12" />
                <stop offset="45%" stopColor="#451e14" />
                <stop offset="75%" stopColor="#b45309" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#1e130c" />
              </linearGradient>
              <radialGradient id="sunGlow" cx="50%" cy="40%" r="50%">
                <stop offset="0%" stopColor="#fef08a" stopOpacity="0.85" />
                <stop offset="35%" stopColor="#f59e0b" stopOpacity="0.45" />
                <stop offset="80%" stopColor="#ea580c" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1a120c" />
                <stop offset="50%" stopColor="#120c08" />
                <stop offset="100%" stopColor="#070503" />
              </linearGradient>
            </defs>

            {/* Sky */}
            <rect width="800" height="420" fill="url(#skyGrad)" />

            {/* Radiant Sunrise Aura */}
            <circle cx="430" cy="180" r="160" fill="url(#sunGlow)" />

            {/* Distant Mountain Silhouettes */}
            <path d="M 0 230 Q 140 140 310 200 T 560 170 Q 680 130 800 210 L 800 420 L 0 420 Z" fill="#1b110a" opacity="0.85" />
            <path d="M 0 250 Q 180 180 390 235 T 800 240 L 800 420 L 0 420 Z" fill="#130b06" opacity="0.95" />

            {/* Traditional Asian Temple Pagoda Silhouette on Lake Shore */}
            <g transform="translate(560, 160)" opacity="0.85">
              {/* Roof tiers */}
              <path d="M 40 45 L 5 62 L 75 62 Z" fill="#2b1a11" />
              <path d="M 40 25 L 15 42 L 65 42 Z" fill="#24150d" />
              <path d="M 40 10 L 25 22 L 55 22 Z" fill="#1f110a" />
              <line x1="40" y1="2" x2="40" y2="12" stroke="#d97706" strokeWidth="2" />
              {/* Base */}
              <rect x="22" y="62" width="36" height="35" fill="#190e08" />
              <circle cx="40" cy="74" r="4" fill="#fef08a" opacity="0.7" />
            </g>

            {/* Pine tree silhouettes on shore */}
            <path d="M 680 230 L 665 270 L 695 270 Z" fill="#0d0805" />
            <path d="M 720 220 L 700 270 L 740 270 Z" fill="#0b0604" />
            <path d="M 755 235 L 740 275 L 770 275 Z" fill="#0a0503" />

            {/* Tranquil Lake Water with Soft Golden Mist Reflections */}
            <rect y="260" width="800" height="160" fill="url(#waterGrad)" />
            {/* Water Ripple Reflections of Sunrise */}
            <ellipse cx="430" cy="280" rx="140" ry="10" fill="#f59e0b" opacity="0.25" />
            <ellipse cx="430" cy="305" rx="110" ry="8" fill="#f59e0b" opacity="0.2" />
            <ellipse cx="430" cy="335" rx="80" ry="6" fill="#fef08a" opacity="0.15" />

            {/* Glowing Lotus Blossoms Floating on Water */}
            <g transform="translate(320, 310)" opacity="0.95">
              <ellipse cx="0" cy="4" rx="20" ry="5" fill="#064e3b" opacity="0.8" />
              {/* Lotus Petals in Glowing Rose Pink */}
              <path d="M 0 -8 C -8 -4 -8 4 0 5 C 8 4 8 -4 0 -8 Z" fill="#fb7185" />
              <path d="M -7 -4 C -14 -1 -12 5 -4 5 C -2 3 -4 -1 -7 -4 Z" fill="#f43f5e" />
              <path d="M 7 -4 C 14 -1 12 5 4 5 C 2 3 4 -1 7 -4 Z" fill="#f43f5e" />
              <circle cx="0" cy="1" r="2.5" fill="#fef08a" />
            </g>
          </svg>

          {/* Vignette Overlay for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/35 pointer-events-none" />

          {/* Text and Actions Inside Card */}
          <div className="absolute inset-0 p-5 sm:p-7 flex flex-col justify-between z-10">
            {/* Top Tag: GENTLE TRUTH FOR THIS HOUR */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs sm:text-sm tracking-wider uppercase drop-shadow-md">
                <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400/40" />
                <span>{isHi ? 'इस पहर का सौम्य सत्य' : 'GENTLE TRUTH FOR THIS HOUR'}</span>
              </div>

              <div className="flex items-center gap-1.5">
                {/* Create Status Image Button */}
                <button
                  type="button"
                  onClick={handleOpenAffirmationStatus}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[11px] font-bold shadow-xs hover:from-amber-400 hover:to-orange-400 transition cursor-pointer"
                  title="Create WhatsApp / Instagram Status"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{isHi ? 'स्टेटस बनाएं' : 'Status'}</span>
                </button>

                {/* Soothing narration toggle */}
                <button
                  type="button"
                  onClick={handleToggleAffirmationAudio}
                  className="p-1.5 rounded-full bg-black/60 hover:bg-black/80 border border-amber-500/40 text-amber-300 transition cursor-pointer"
                  title={isAffirmationSpeaking ? 'रोकें (Stop)' : 'सुनें (Listen)'}
                >
                  {isAffirmationSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Main Sacred Quote */}
            <div className="my-auto py-2">
              <p className="text-base sm:text-xl font-serif text-amber-50 font-normal leading-relaxed drop-shadow-lg max-w-xl">
                {isHi
                  ? `“${currentAffirmation.affirmationHi}”`
                  : `“${currentAffirmation.affirmationEn}”`}
              </p>
              <p className="text-[11px] text-amber-300/80 mt-1 font-mono">
                — श्रीमद्भगवद्गीता {currentAffirmation.chapter}.{currentAffirmation.verseNumber}
              </p>
            </div>

            {/* Bottom Row: Next Affirmation & 🌸 10s Breath Pill Button */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleNextAffirmation}
                className="inline-flex items-center gap-1 text-[11px] text-stone-300 hover:text-amber-200 transition bg-black/50 px-2.5 py-1 rounded-xl border border-stone-700/60"
              >
                <Shuffle className="w-3 h-3 text-amber-400" />
                <span>{isHi ? 'अगला विचार' : 'Next Insight'}</span>
              </button>

              {/* Exact 🌸 10s Breath Pill Button from Screenshot */}
              <button
                onClick={() => setShow10sBreath(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-stone-900/90 to-amber-950/90 text-amber-200 text-xs sm:text-sm font-semibold border border-amber-500/60 shadow-lg hover:border-amber-400 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <span>🌸</span>
                <span>{isHi ? '१० सेकण्ड श्वास' : '10s Breath'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3.5. Gita Reading Progress & Resume Swadhyaya Card */}
      <div className="rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-[#1f1710] via-[#17120e] to-[#0f0c09] border border-amber-500/50 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-600/30">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  {isHi ? 'गीता स्वाध्याय एवं प्रगति' : 'Gita Swadhyaya & Progress'}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {overallStats.percent}% {isHi ? 'पूर्ण' : 'Done'}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-stone-100 font-serif mt-0.5">
                {isHi
                  ? `अंतिम पढ़ा: अध्याय ${readingProgress.lastReadChapter}, श्लोक ${readingProgress.lastReadVerse}`
                  : `Last Read: Chapter ${readingProgress.lastReadChapter}, Verse ${readingProgress.lastReadVerse}`}
              </h3>
              <p className="text-xs text-stone-400 font-light mt-0.5">
                {isHi
                  ? `अगला श्लोक: अध्याय ${nextVerseToRead.chapter}, श्लोक ${nextVerseToRead.verse} • कुल ${overallStats.totalRead} / ${overallStats.totalVerses} श्लोक पढ़े गए`
                  : `Up next: Chapter ${nextVerseToRead.chapter}, Verse ${nextVerseToRead.verse} • ${overallStats.totalRead} of ${overallStats.totalVerses} Verses Completed`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              onClick={() => onExploreChapters && onExploreChapters(nextVerseToRead.chapter, nextVerseToRead.verse)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-md shadow-amber-600/30 active:scale-95 transition cursor-pointer"
            >
              <span>{isHi ? `श्लोक ${nextVerseToRead.chapter}.${nextVerseToRead.verse} से जारी रखें` : `Resume Ch ${nextVerseToRead.chapter}.${nextVerseToRead.verse}`}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onExploreChapters && onExploreChapters()}
              className="px-3 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-300 hover:text-white text-xs font-semibold hover:bg-stone-800 transition cursor-pointer"
              title="All Chapters"
            >
              {isHi ? 'सभी १८ अध्याय' : 'All 18 Ch'}
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-stone-900 overflow-hidden border border-amber-900/40">
          <div
            className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-700 ease-out"
            style={{ width: `${Math.max(2, overallStats.percent)}%` }}
          />
        </div>
      </div>

      {/* 4. Main Guidance Container ("What is weighing on your mind today?") */}
      <div className="rounded-3xl p-5 sm:p-7 bg-[#15120f] border border-amber-950/60 shadow-2xl relative text-stone-100">
        {/* Header with Title and Safe & Confidential Badge */}
        <div className="flex items-start justify-between gap-3 mb-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-serif text-stone-100">
              {isHi ? 'आज आपके मन पर क्या भारी है?' : 'What is weighing on your mind today?'}
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-1 leading-normal font-light">
              {isHi
                ? 'कोई विषय चुनें या अपने शब्दों में लिखें। हम उपयुक्त श्लोक और व्यावहारिक समाधान साझा करेंगे।'
                : 'Select a topic or type in your own words. We will share matching verses and practical steps.'}
            </p>
          </div>

          {/* Safe & Confidential Capsule Badge from Screenshot */}
          <div className="shrink-0 px-3 py-1 rounded-full bg-[#291e14] text-[#f59e0b] border border-[#78350f]/70 text-[11px] font-semibold tracking-wide shadow-xs">
            {isHi ? 'सुरक्षित और गोपनीय' : 'Safe & Confidential'}
          </div>
        </div>

        {/* 5. Color-Coded Chips and Extended Categories */}
        <div className="space-y-3 my-6">
          <div className="flex flex-wrap gap-2.5">
            {STRESS_CHIPS.map((chip) => {
              const isSelected = selectedCategory === chip.category;
              const Icon = chip.icon;
              return (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => handleChipClick(chip.category)}
                  className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-medium border transition-all cursor-pointer select-none active:scale-95 ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white border-amber-400 shadow-md shadow-amber-600/30 scale-[1.03] font-semibold'
                      : `${chip.bgStyle} ${chip.borderStyle} ${chip.textStyle} hover:scale-[1.02]`
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : chip.iconColor}`} />
                  <span>{isHi ? chip.labelHi : chip.labelEn}</span>
                </button>
              );
            })}

            {/* Explicit "Other Life Concerns" Chip */}
            <button
              type="button"
              onClick={() => handleChipClick('Other')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-medium border transition-all cursor-pointer select-none active:scale-95 ${
                selectedCategory === 'Other'
                  ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white border-amber-400 shadow-md shadow-amber-600/30 scale-[1.03] font-semibold'
                  : 'bg-stone-900/60 border-stone-700/80 text-amber-200 hover:scale-[1.02]'
              }`}
            >
              <HelpCircle className={`w-4 h-4 shrink-0 ${selectedCategory === 'Other' ? 'text-white' : 'text-amber-400'}`} />
              <span>{isHi ? 'अन्य समस्याएँ एवं जीवन मार्गदर्शन' : 'Other Life Concerns'}</span>
            </button>
          </div>

          {/* Toggle for More Life Topics */}
          <div className="pt-0.5">
            <button
              type="button"
              onClick={() => setShowMoreTopics(!showMoreTopics)}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-400 hover:text-amber-300 transition cursor-pointer px-2 py-1 rounded-lg hover:bg-amber-950/20"
            >
              <span>
                {showMoreTopics
                  ? (isHi ? 'कम विषय दिखाएं ▲' : 'Show Fewer Topics ▲')
                  : (isHi ? '+ अन्य ९ जीवन विषय देखें (संबंध, शोक, अकेलापन, स्वास्थ्य, आदि) ▼' : '+ View 9 More Life Topics (Relationship, Grief, Loneliness, Health, etc.) ▼')}
              </span>
            </button>
          </div>

          {/* Expandable Extended Topics */}
          {showMoreTopics && (
            <div className="flex flex-wrap gap-2.5 pt-3 p-3.5 rounded-2xl bg-black/30 border border-stone-800/80 animate-fadeIn">
              {MORE_STRESS_CHIPS.map((chip) => {
                const isSelected = selectedCategory === chip.category;
                const Icon = chip.icon;
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => handleChipClick(chip.category)}
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-medium border transition-all cursor-pointer select-none active:scale-95 ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white border-amber-400 shadow-md shadow-amber-600/30 scale-[1.03] font-semibold'
                        : `${chip.bgStyle} ${chip.borderStyle} ${chip.textStyle} hover:scale-[1.02]`
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : chip.iconColor}`} />
                    <span>{isHi ? chip.labelHi : chip.labelEn}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* 6. Free text input */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-400">
              {isHi ? 'या अपने शब्दों में लिखें' : 'Or tell me in your own words'}
            </span>
            <button
              type="button"
              onClick={handleUseExample}
              className="text-xs text-amber-400 hover:text-amber-300 hover:underline font-medium cursor-pointer"
            >
              {isHi ? 'नमूना स्थिति आजमाएं' : 'Try sample scenario'}
            </button>
          </div>
          <textarea
            rows={3}
            value={userInput}
            onChange={(e) => onUserInputChange(e.target.value)}
            placeholder={
              isHi
                ? 'उदाहरण: मेरे पास बहुत सारे काम हैं और मुझे गलती होने का डर सता रहा है...'
                : 'Example: I have too many deadlines and I keep worrying that I will make a mistake.'
            }
            className="w-full px-4 py-3 rounded-2xl border border-stone-800 bg-[#0d0a08] text-stone-100 placeholder-stone-500 focus:outline-hidden focus:border-amber-500/70 focus:ring-1 focus:ring-amber-500/50 text-sm leading-relaxed transition resize-none"
          />
        </div>

        {/* 7. Primary Action Button */}
        <button
          onClick={onSubmit}
          disabled={!isReady}
          className={`w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl font-semibold text-sm transition-all shadow-md ${
            isReady
              ? 'bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:via-orange-500 hover:to-amber-600 text-white shadow-amber-600/30 active:scale-[0.99] cursor-pointer'
              : 'bg-stone-800/80 text-stone-500 cursor-not-allowed shadow-none border border-stone-800'
          }`}
        >
          <span>{isHi ? 'समाधान एवं मार्गदर्शन प्राप्त करें' : 'Find Guidance'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        {/* 8. Quick 2-Minute Reset */}
        <div className="mt-5 text-center">
          <button
            onClick={onQuickReset}
            className="inline-flex items-center gap-2 text-xs font-semibold px-4 py-2 rounded-full bg-[#1e1712] text-amber-300 border border-amber-800/60 hover:bg-[#281e17] transition shadow-xs cursor-pointer"
          >
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>{isHi ? 'मुझे बस २ मिनट का शांत विराम चाहिए' : 'I just need a 2-minute reset'}</span>
          </button>
        </div>
      </div>

      {/* 9. Peaceful Assurance Footer line */}
      <div className="flex items-center justify-center gap-2 text-xs text-stone-500">
        <Compass className="w-3.5 h-3.5 text-amber-500/70" />
        <span>
          {isHi
            ? 'वैदिक दर्शन • प्रामाणिक श्लोक • व्यावहारिक दैनिक समाधान'
            : 'Grounded philosophy • Verified verses • Practical daily actions'}
        </span>
      </div>

      {/* 10. MODAL: 10s Breath Meditation Overlay (Triggered by 🌸 10s Breath) */}
      {show10sBreath && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fadeIn">
          <div className="relative max-w-sm w-full bg-[#18130f] border-2 border-amber-500/60 rounded-3xl p-6 text-center text-stone-100 shadow-2xl cinema-glow">
            {/* Close button */}
            <button
              onClick={() => setShow10sBreath(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-stone-900 text-stone-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <span className="text-2xl">🌸</span>
            <h3 className="text-xl font-bold font-serif text-amber-200 mt-2">
              {isHi ? '१० सेकण्ड शांत श्वास' : '10-Second Calming Breath'}
            </h3>
            <p className="text-xs text-stone-400 mt-1">
              {isHi ? 'अपनी आँखें कोमलता से बंद करें या वृत्त का अनुसरण करें' : 'Rest your gaze gently on the pulse'}
            </p>

            {/* Pulsing Breathing Sphere */}
            <div className="my-8 flex items-center justify-center">
              <div
                className={`w-32 h-32 rounded-full border-2 border-amber-400 flex flex-col items-center justify-center transition-all duration-1000 ${
                  breathPhase === 'Inhale'
                    ? 'scale-125 bg-amber-500/30 shadow-[0_0_35px_rgba(245,158,11,0.5)]'
                    : breathPhase === 'Hold'
                    ? 'scale-125 bg-amber-500/40 shadow-[0_0_40px_rgba(251,191,36,0.6)]'
                    : 'scale-90 bg-amber-500/10 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                }`}
              >
                <span className="text-3xl font-bold font-mono text-amber-200">{breathTimer}s</span>
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-300 mt-1">
                  {breathPhase === 'Inhale'
                    ? isHi
                      ? 'श्वास लें'
                      : 'Inhale'
                    : breathPhase === 'Hold'
                    ? isHi
                      ? 'रोकें'
                      : 'Hold'
                    : isHi
                    ? 'छोड़ें'
                    : 'Exhale'}
                </span>
              </div>
            </div>

            <p className="text-sm font-medium text-amber-100 font-serif">
              {breathPhase === 'Inhale'
                ? isHi
                  ? 'गहरी श्वास भीतर लें... स्वयं में शक्ति भरें।'
                  : 'Breathe in deep courage and stillness.'
                : breathPhase === 'Hold'
                ? isHi
                  ? 'शांति में विराम करें... आप सुरक्षित हैं।'
                  : 'Rest in the pause. You are safe.'
                : isHi
                ? 'धीरे से श्वास छोड़ें... सारा तनाव विसर्जित करें।'
                : 'Slowly exhale all tension and worry.'}
            </p>

            <button
              onClick={() => setShow10sBreath(false)}
              className="mt-6 text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer"
            >
              {isHi ? 'समाप्त करें' : 'Done'}
            </button>
          </div>
        </div>
      )}

      {/* WHATSAPP & INSTAGRAM STATUS GENERATOR MODAL */}
      {statusModalOpen && statusModalVerse && (
        <StatusImageGeneratorModal
          isOpen={statusModalOpen}
          onClose={() => setStatusModalOpen(false)}
          verseData={statusModalVerse}
          language={language}
          onShowToast={(msg) => console.log(msg)}
        />
      )}
    </div>
  );
};
