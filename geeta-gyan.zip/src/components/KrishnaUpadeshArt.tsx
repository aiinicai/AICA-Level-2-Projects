import React from 'react';

interface KrishnaUpadeshArtProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showBanner?: boolean;
  language?: 'en' | 'hi';
}

export const KrishnaUpadeshArt: React.FC<KrishnaUpadeshArtProps> = ({
  className = '',
  size = 'md',
  showBanner = true,
  language = 'en',
}) => {
  const isHi = language === 'hi';

  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-36 h-36',
    lg: 'w-48 h-48 sm:w-56 sm:h-56',
    hero: 'w-64 h-64 sm:w-80 sm:h-80',
  };

  return (
    <div className={`relative flex flex-col items-center justify-center ${className}`}>
      {/* Radiant Glowing Background Halo */}
      <div className="absolute inset-0 -m-3 bg-gradient-to-tr from-amber-500/25 via-yellow-400/20 to-orange-500/25 rounded-full blur-2xl pointer-events-none animate-pulse" />

      {/* Sacred SVG Art of Lord Shri Krishna Speaking Gita Wisdom */}
      <svg
        viewBox="0 0 240 240"
        className={`${sizeClasses[size]} relative z-10 drop-shadow-xl select-none`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Golden Solar Aura Halo Gradient */}
          <radialGradient id="divyaHalo" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#fffbeb" stopOpacity="0.95" />
            <stop offset="35%" stopColor="#fef08a" stopOpacity="0.85" />
            <stop offset="65%" stopColor="#f59e0b" stopOpacity="0.5" />
            <stop offset="85%" stopColor="#ea580c" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#78350f" stopOpacity="0" />
          </radialGradient>

          {/* Crown Gold Gradient */}
          <linearGradient id="crownGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>

          {/* Morpankh Peacock Feather Gradients */}
          <linearGradient id="peacockOuter" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="peacockBlue" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="100%" stopColor="#0284c7" />
          </linearGradient>
          <linearGradient id="peacockCore" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#312e81" />
            <stop offset="100%" stopColor="#1e1b4b" />
          </linearGradient>

          {/* Pitambara Silk Robe Gradient */}
          <linearGradient id="pitambaraSilk" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="60%" stopColor="#eab308" />
            <stop offset="100%" stopColor="#ca8a04" />
          </linearGradient>

          {/* Divine Shyam Complexion */}
          <linearGradient id="shyamComplexion" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="40%" stopColor="#0284c7" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>
        </defs>

        {/* 1. Divine Aura Rays & Halo */}
        <circle cx="120" cy="115" r="95" fill="url(#divyaHalo)" />

        {/* Outer Halo Decorative Rays */}
        <g stroke="#fbbf24" strokeWidth="1" strokeOpacity="0.45" strokeDasharray="3 4">
          <circle cx="120" cy="115" r="80" />
          <circle cx="120" cy="115" r="72" />
        </g>

        {/* 16 Sacred Rays of Light */}
        <g stroke="#fef08a" strokeWidth="1.2" strokeOpacity="0.5">
          {[0, 22.5, 45, 67.5, 90, 112.5, 135, 157.5, 180, 202.5, 225, 247.5, 270, 292.5, 315, 337.5].map((angle, i) => {
            const rad = (angle * Math.PI) / 180;
            const x1 = 120 + Math.cos(rad) * 65;
            const y1 = 115 + Math.sin(rad) * 65;
            const x2 = 120 + Math.cos(rad) * 92;
            const y2 = 115 + Math.sin(rad) * 92;
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} />;
          })}
        </g>

        {/* 2. Lord Krishna Form */}
        {/* Shoulders & Pitambara Silk Robes */}
        <path
          d="M65 210 C70 180 85 168 105 160 C112 157 128 157 135 160 C155 168 170 180 175 210 Z"
          fill="url(#pitambaraSilk)"
          stroke="#b45309"
          strokeWidth="1.5"
        />

        {/* Golden Silk Folds & Borders */}
        <path
          d="M85 175 Q120 200 155 175"
          stroke="#b45309"
          strokeWidth="2"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M92 188 Q120 210 148 188"
          stroke="#fef08a"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Pearl Necklace & Kaustubha Gem */}
        <path
          d="M100 166 Q120 182 140 166"
          stroke="#fef08a"
          strokeWidth="2.5"
          strokeDasharray="2 3"
          fill="none"
        />
        <circle cx="120" cy="176" r="3.5" fill="#dc2626" stroke="#fef08a" strokeWidth="1" />

        {/* Divine Neck */}
        <path
          d="M110 142 L110 160 C114 163 126 163 130 160 L130 142 Z"
          fill="url(#shyamComplexion)"
        />

        {/* Serene Divine Face & Profile */}
        <path
          d="M105 105 C105 85 135 85 135 105 C135 125 128 145 120 146 C112 145 105 125 105 105 Z"
          fill="url(#shyamComplexion)"
        />

        {/* Saffron & White Chandan Tilak (Urdhva Pundra) */}
        <path
          d="M118 90 L118 106 M122 90 L122 106"
          stroke="#ffffff"
          strokeWidth="1.2"
          strokeLinecap="round"
        />
        <path
          d="M120 95 L120 110"
          stroke="#ea580c"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        <circle cx="120" cy="112" r="1.2" fill="#ea580c" />

        {/* Peaceful, Loving Eyes (Half-Closed Contemplative Gaze) */}
        <path
          d="M111 114 Q116 112 119 116"
          stroke="#1e1b4b"
          strokeWidth="1.6"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M121 116 Q124 112 129 114"
          stroke="#1e1b4b"
          strokeWidth="1.6"
          strokeLinecap="round"
          fill="none"
        />

        {/* Gentle Compassionate Smile */}
        <path
          d="M116 128 Q120 132 124 128"
          stroke="#f43f5e"
          strokeWidth="1.8"
          strokeLinecap="round"
          fill="none"
        />

        {/* Golden Earrings (Makara Kundala) */}
        <circle cx="103" cy="120" r="3" fill="url(#crownGold)" stroke="#fef08a" strokeWidth="0.8" />
        <circle cx="137" cy="120" r="3" fill="url(#crownGold)" stroke="#fef08a" strokeWidth="0.8" />

        {/* 3. Royal Golden Crown (Mukut) */}
        <path
          d="M102 92 L106 68 L120 58 L134 68 L138 92 C130 96 110 96 102 92 Z"
          fill="url(#crownGold)"
          stroke="#b45309"
          strokeWidth="1.5"
        />
        {/* Crown Gems */}
        <circle cx="120" cy="74" r="3" fill="#dc2626" stroke="#fef08a" strokeWidth="0.8" />
        <circle cx="112" cy="80" r="2" fill="#0284c7" />
        <circle cx="128" cy="80" r="2" fill="#0284c7" />

        {/* 4. Sacred Morpankh (Peacock Feather on Crown) */}
        <g transform="translate(122, 58) rotate(14)">
          {/* Feather Stem */}
          <path d="M0 0 Q-4 -20 -8 -45" stroke="#fef08a" strokeWidth="1.5" fill="none" />

          {/* Outer Emerald Feather Shape */}
          <ellipse cx="-7" cy="-35" rx="14" ry="20" fill="url(#peacockOuter)" transform="rotate(-10 -7 -35)" />

          {/* Turquoise Blue Layer */}
          <ellipse cx="-7" cy="-34" rx="10" ry="14" fill="url(#peacockBlue)" transform="rotate(-10 -7 -34)" />

          {/* Deep Indigo Core */}
          <ellipse cx="-7" cy="-33" rx="6" ry="9" fill="url(#peacockCore)" transform="rotate(-10 -7 -33)" />

          {/* Golden Center Eye */}
          <ellipse cx="-6" cy="-33" rx="3" ry="4.5" fill="#fde047" transform="rotate(-10 -6 -33)" />
        </g>

        {/* 5. Upadesha / Jnana Mudra (Right Hand of Divine Instruction) */}
        <g transform="translate(142, 142)">
          {/* Gentle hand raised in wisdom gesture */}
          <ellipse cx="14" cy="8" rx="8" ry="11" fill="url(#shyamComplexion)" />
          {/* Fingers in Chin/Upadesha Mudra */}
          <path
            d="M8 4 Q12 -4 16 0 Q18 4 15 8"
            stroke="#38bdf8"
            strokeWidth="2"
            strokeLinecap="round"
            fill="none"
          />
          <path
            d="M14 -2 Q19 -6 22 2 Q22 7 18 10"
            stroke="#38bdf8"
            strokeWidth="1.8"
            strokeLinecap="round"
            fill="none"
          />
          {/* Golden Bracelet (Kangan) */}
          <rect x="6" y="16" width="16" height="4" rx="2" fill="url(#crownGold)" stroke="#b45309" strokeWidth="0.5" />

          {/* Divine Wisdom Sparkle from Fingers */}
          <circle cx="21" cy="-2" r="2.5" fill="#fef08a" className="animate-ping" opacity="0.8" />
          <circle cx="21" cy="-2" r="1.5" fill="#ffffff" />
        </g>

        {/* Sacred Flute (Bansuri) resting peacefully */}
        <g transform="translate(74, 168) rotate(-22)">
          <rect x="0" y="0" width="70" height="4.5" rx="2" fill="url(#crownGold)" stroke="#78350f" strokeWidth="0.8" />
          <circle cx="16" cy="2.2" r="1" fill="#78350f" />
          <circle cx="26" cy="2.2" r="1" fill="#78350f" />
          <circle cx="36" cy="2.2" r="1" fill="#78350f" />
          <circle cx="46" cy="2.2" r="1" fill="#78350f" />
          {/* Silk tassel */}
          <path d="M68 2.2 C72 6 74 12 75 16" stroke="#ea580c" strokeWidth="1.5" fill="none" />
          <circle cx="75" cy="17" r="2" fill="#ea580c" />
        </g>
      </svg>

      {/* Feel-Good Tag Banner */}
      {showBanner && (
        <div className="mt-1 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-orange-500/25 to-amber-500/20 border border-amber-400/40 text-amber-900 dark:text-amber-200 text-[11px] font-bold tracking-wide shadow-xs flex items-center gap-1.5 animate-fadeIn">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
          <span className="font-serif">
            {isHi ? '॥ श्रीभगवानुवाच • भगवान श्री कृष्ण का पावन उपदेश ॥' : '॥ Sri Bhagavan Uvacha • Words of Lord Krishna ॥'}
          </span>
        </div>
      )}
    </div>
  );
};
