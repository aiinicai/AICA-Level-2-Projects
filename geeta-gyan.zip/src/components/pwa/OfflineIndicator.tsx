import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 md:bottom-6 md:left-auto md:right-6 z-50 flex items-center justify-center gap-2 rounded-xl bg-amber-800/95 dark:bg-amber-900/95 backdrop-blur-md px-4 py-2 text-xs font-medium text-amber-50 shadow-xl border border-amber-600/30">
      <WifiOff className="w-3.5 h-3.5 text-amber-200 shrink-0" />
      <span>Offline Mode — All verified Gita wisdom and your journal are fully accessible offline.</span>
    </div>
  );
};
