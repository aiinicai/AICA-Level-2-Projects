import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  Filter,
  Plus,
  Trash2,
  TrendingDown,
  Sparkles,
  ArrowRight,
  X,
  CheckCircle2,
  Lock,
  ShieldCheck,
  Cloud,
  LogIn,
  RefreshCw,
} from 'lucide-react';
import { JournalEntry, StressCategory } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  subscribeUserJournalEntries,
  addFirestoreJournalEntry,
  deleteFirestoreJournalEntry,
  migrateLocalJournalEntries,
} from '../services/firestoreJournalService';

interface JournalScreenProps {
  entries?: JournalEntry[];
  onAddEntry?: (entry: Omit<JournalEntry, 'id' | 'createdAt'>) => void;
  onDeleteEntry?: (id: string) => void;
  onShowToast: (msg: string) => void;
  onNavigateToPublic?: () => void;
  language?: 'en' | 'hi';
}

const CATEGORY_FILTERS = [
  'All',
  'Work Pressure',
  'Overthinking',
  'Fear of Failure',
  'Anger',
  'Conflict',
  'Money Worries',
  'Family Pressure',
  'Relationship Stress',
  'Other',
];

export const JournalScreen: React.FC<JournalScreenProps> = ({
  onShowToast,
  onNavigateToPublic,
  language = 'en',
}) => {
  const { user, signIn, isLoading: authLoading } = useAuth();
  const isHi = language === 'hi';

  const [activeFilter, setActiveFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
  const [cloudEntries, setCloudEntries] = useState<JournalEntry[]>([]);
  const [isSyncing, setIsSyncing] = useState<boolean>(true);
  const [isMigrating, setIsMigrating] = useState<boolean>(false);

  // Form State for new entry
  const [formCategory, setFormCategory] = useState<StressCategory>('Work Pressure');
  const [formInput, setFormInput] = useState('');
  const [formStressBefore, setFormStressBefore] = useState(3);
  const [formConcept, setFormConcept] = useState('Karma Yoga (Focus on Action)');
  const [formActionTaken, setFormActionTaken] = useState('');
  const [formReflection, setFormReflection] = useState('');
  const [formStressAfter, setFormStressAfter] = useState(2);

  // Real-time Firestore sync & Safe Local Migration for signed-in user
  useEffect(() => {
    if (!user) {
      setCloudEntries([]);
      setIsSyncing(false);
      return;
    }

    setIsSyncing(true);

    // Run safe local migration in background on sign-in
    migrateLocalJournalEntries(user.uid)
      .then(({ migratedCount }) => {
        if (migratedCount > 0) {
          onShowToast(
            isHi
              ? `${migratedCount} स्थानीय प्रविष्टियाँ आपकी निजी क्लाउड डायरी में सुरक्षित रूप से स्थानांतरित कर दी गईं।`
              : `${migratedCount} local journal entries safely migrated to your private cloud vault.`
          );
        }
      })
      .catch((err) => console.warn('Migration check completed with notice:', err));

    // Subscribe to user's private Firestore collection
    const unsubscribe = subscribeUserJournalEntries(
      user.uid,
      (entries) => {
        setCloudEntries(entries);
        setIsSyncing(false);
      },
      (error) => {
        console.error('Failed to subscribe to user journal:', error);
        setIsSyncing(false);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Unauthenticated Visitor State: Require Google Sign-In for My Journal
  if (!user) {
    return (
      <div className="max-w-xl mx-auto px-4 py-10 md:py-16 animate-fadeIn space-y-6 text-center">
        {/* Sacred Icon & Title */}
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-600 via-orange-500 to-rose-400 text-white flex items-center justify-center mx-auto shadow-xl shadow-orange-500/20 border border-amber-300/40">
          <BookOpen className="w-8 h-8 drop-shadow-xs" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif">
            {isHi ? 'व्यक्तिगत साधना डायरी' : 'My Reflection Journal'}
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 max-w-md mx-auto leading-relaxed">
            {isHi
              ? 'आपकी निजी आध्यात्मिक डायरी जहाँ आप अपने दैनिक तनाव, गीता सिद्धांतों और मन की शांति का व्यक्तिगत लेखा-जोखा रख सकते हैं।'
              : 'Your private spiritual sanctuary to record personal challenges, apply Gita wisdom, and track emotional shifts with complete privacy.'}
          </p>
        </div>

        {/* Google Sign In Call-To-Action Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white/90 dark:bg-stone-900/90 border border-amber-200/70 dark:border-stone-800 shadow-xl space-y-5">
          <div className="space-y-1">
            <span className="text-xs font-bold font-serif text-amber-800 dark:text-amber-300 uppercase tracking-wider">
              {isHi ? 'प्रमाणीकरण एवं शून्य-ज्ञान गोपनीयता' : 'Authentication & Private Vault'}
            </span>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {isHi
                ? 'अपनी डायरी खोलने के लिए कृपया अपने गूगल खाते से साइन इन करें'
                : 'Please sign in with Google to access your private encrypted journal.'}
            </p>
          </div>

          {/* Sign In Button */}
          <button
            onClick={() => signIn()}
            disabled={authLoading}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 active:scale-98 transition flex items-center justify-center gap-2.5 mx-auto cursor-pointer"
          >
            {authLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <LogIn className="w-4 h-4" />
            )}
            <span>{isHi ? 'गूगल से साइन इन करें' : 'Sign in with Google'}</span>
          </button>

          {/* Privacy & Architecture Features */}
          <div className="pt-4 border-t border-stone-100 dark:border-stone-800/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/20 text-xs">
              <Lock className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
              <div>
                <strong className="block text-stone-900 dark:text-stone-100">
                  {isHi ? 'डेटाबेस सुरक्षा नियम' : 'Database-Level Privacy'}
                </strong>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  {isHi
                    ? 'केवल आप ही अपनी डायरी पढ़ या लिख सकते हैं। व्यवस्थापक भी इसे नहीं देख सकते।'
                    : 'Restricted to your UID via Firestore Security Rules. Admins cannot read entries.'}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/20 text-xs">
              <Cloud className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
              <div>
                <strong className="block text-stone-900 dark:text-stone-100">
                  {isHi ? 'सुरक्षित क्लाउड सिंक' : 'Safe Migration & Sync'}
                </strong>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  {isHi
                    ? 'इस डिवाइस पर पहले से लिखी गई प्रविष्टियाँ सुरक्षित रूप से क्लाउड में आ जाएंगी।'
                    : 'Existing local reflections on this device are safely preserved & synced.'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Public Gita Notice */}
        <p className="text-[11px] text-stone-400 dark:text-stone-500">
          {isHi
            ? '१८ अध्याय, श्लोक पठन एवं दैनिक शांति बिना किसी लॉगिन के सभी के लिए निःशुल्क उपलब्ध हैं।'
            : 'Bhagavad Gita chapters, shlokas, and daily calm exercises remain 100% public and free without login.'}
        </p>
      </div>
    );
  }

  // Authenticated State: Full Journal View with Firestore CRUD
  const filteredEntries = cloudEntries.filter((entry) => {
    if (activeFilter === 'All') return true;
    return entry.stressCategory === activeFilter;
  });

  const handleSubmitNew = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formInput.trim()) {
      onShowToast(isHi ? 'कृपया स्थिति का संक्षिप्त विवरण लिखें।' : 'Please provide a short description.');
      return;
    }

    try {
      await addFirestoreJournalEntry(user.uid, {
        stressCategory: formCategory,
        userInput: formInput.trim(),
        stressBefore: formStressBefore,
        concept: formConcept,
        actionTaken: formActionTaken.trim() || 'Applied mindful pause and focused on immediate action.',
        reflection: formReflection.trim() || 'Felt more grounded after separating effort from outcome.',
        stressAfter: formStressAfter,
      });

      setShowAddModal(false);
      setFormInput('');
      setFormActionTaken('');
      setFormReflection('');
      onShowToast(isHi ? 'चिंतन आपकी निजी क्लाउड डायरी में सहेजा गया।' : 'Reflection saved to your private cloud journal.');
    } catch (err) {
      console.error('Failed to add entry:', err);
      onShowToast(isHi ? 'प्रविष्टि सहेजने में त्रुटि।' : 'Error saving journal entry.');
    }
  };

  const handleDelete = async (entryId: string) => {
    if (confirm(isHi ? 'क्या आप इस चिंतन को हटाना चाहते हैं?' : 'Delete this reflection?')) {
      try {
        await deleteFirestoreJournalEntry(user.uid, entryId);
        onShowToast(isHi ? 'चिंतन हटा दिया गया।' : 'Reflection deleted.');
      } catch (err) {
        console.error('Failed to delete entry:', err);
        onShowToast('Could not delete entry.');
      }
    }
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Recent';
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Header & Vault Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif">
              {isHi ? 'व्यक्तिगत साधना डायरी' : 'Reflection Journal'}
            </h1>
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
              <Lock className="w-2.5 h-2.5" />
              <span>{isHi ? 'सुरक्षित क्लाउड' : 'Private Cloud Vault'}</span>
            </span>
          </div>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-0.5">
            {isHi
              ? 'आपकी व्यक्तिगत प्रविष्टियाँ केवल आपके गूगल खाते से सुरक्षित हैं।'
              : 'Your private record of stress situations, Gita perspectives, and before/after shifts.'}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-600 text-white text-xs font-semibold shadow-md shadow-amber-600/20 transition active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{isHi ? 'नया चिंतन जोड़ें' : 'New Entry'}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
        {CATEGORY_FILTERS.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveFilter(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer ${
              activeFilter === cat
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white font-semibold shadow-xs'
                : 'bg-white dark:bg-stone-900 text-stone-600 dark:text-stone-400 border border-stone-200 dark:border-stone-800 hover:bg-stone-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Entries List */}
      {isSyncing ? (
        <div className="p-8 text-center text-xs text-stone-400 space-y-2">
          <RefreshCw className="w-5 h-5 animate-spin mx-auto text-amber-600" />
          <p>{isHi ? 'आपकी निजी डायरी लोड हो रही है...' : 'Loading private cloud reflections...'}</p>
        </div>
      ) : filteredEntries.length === 0 ? (
        <div className="p-8 text-center bg-white/60 dark:bg-stone-900/60 rounded-3xl border border-stone-200 dark:border-stone-800 space-y-2">
          <BookOpen className="w-8 h-8 text-stone-300 dark:text-stone-600 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-stone-800 dark:text-stone-200">
            {isHi ? 'इस श्रेणी में कोई प्रविष्टि नहीं है' : 'No reflections found in this category'}
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 max-w-sm mx-auto">
            {isHi
              ? 'नया चिंतन जोड़ने के लिए ऊपर दिए गए बटन पर क्लिक करें।'
              : 'Take a moment to record your thoughts, or complete a guidance check-in from the Home tab.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              onClick={() => setSelectedEntry(entry)}
              className="p-5 rounded-3xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs hover:border-amber-300 dark:hover:border-stone-700 cursor-pointer transition zen-card"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100/70 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                    {entry.stressCategory}
                  </span>
                  {entry.verseReference && (
                    <span className="text-[10px] font-semibold text-stone-500 dark:text-stone-400">
                      {entry.verseReference}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[11px] text-stone-400">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(entry.createdAt)}</span>
                </div>
              </div>

              {/* User situation quote */}
              <p className="text-sm font-semibold text-stone-900 dark:text-stone-100 line-clamp-2 mb-2">
                “{entry.userInput}”
              </p>

              {/* Gita concept */}
              <div className="text-xs text-amber-900 dark:text-amber-300 font-medium mb-3">
                {isHi ? 'सिद्धांत:' : 'Principle:'} {entry.concept}
              </div>

              {/* Stress shift indicator */}
              <div className="flex items-center justify-between pt-2 border-t border-stone-100 dark:border-stone-800 text-xs">
                <div className="flex items-center gap-3">
                  <span className="text-stone-500 dark:text-stone-400">
                    {isHi ? 'तनाव पूर्व:' : 'Stress:'} <strong className="text-stone-800 dark:text-stone-200">{entry.stressBefore}/5</strong>
                  </span>
                  {entry.stressAfter !== undefined && (
                    <>
                      <ArrowRight className="w-3 h-3 text-stone-400" />
                      <span className="text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" />
                        <span>{isHi ? 'उपरांत:' : 'After:'} {entry.stressAfter}/5</span>
                      </span>
                    </>
                  )}
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(entry.id);
                  }}
                  className="p-1 rounded-lg text-stone-400 hover:text-rose-600 transition cursor-pointer"
                  title="Delete entry"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Entry Details Modal */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-stone-900 p-6 shadow-2xl border border-stone-200 dark:border-stone-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400">
                  {selectedEntry.stressCategory}
                </span>
                <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif">
                  {isHi ? 'चिंतन विवरण' : 'Reflection Detail'}
                </h3>
              </div>
              <button
                onClick={() => setSelectedEntry(null)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-100 dark:border-stone-800">
                <span className="text-[10px] font-bold text-stone-400 uppercase block mb-1">
                  {isHi ? 'क्या हुआ था' : 'What Happened'}
                </span>
                <p className="text-stone-800 dark:text-stone-200 leading-relaxed font-medium">
                  {selectedEntry.userInput}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-stone-800/50 border border-amber-200/60 dark:border-stone-700">
                <span className="text-[10px] font-bold text-amber-800 dark:text-amber-400 uppercase block mb-1">
                  {isHi ? 'प्रयुक्त गीता सिद्धांत' : 'Gita Principle Applied'}
                </span>
                <p className="font-serif font-bold text-stone-900 dark:text-stone-100">
                  {selectedEntry.concept}
                </p>
              </div>

              {selectedEntry.actionTaken && (
                <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-100 dark:border-stone-800">
                  <span className="text-[10px] font-bold text-stone-400 uppercase block mb-1">
                    {isHi ? 'उठाया गया व्यावहारिक कदम' : 'Action Taken'}
                  </span>
                  <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
                    {selectedEntry.actionTaken}
                  </p>
                </div>
              )}

              {selectedEntry.reflection && (
                <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-100 dark:border-stone-800">
                  <span className="text-[10px] font-bold text-stone-400 uppercase block mb-1">
                    {isHi ? 'उपरांत मनःस्थिति एवं शांति' : 'What Changed Afterward'}
                  </span>
                  <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
                    {selectedEntry.reflection}
                  </p>
                </div>
              )}

              <div className="p-3 rounded-2xl bg-stone-100 dark:bg-stone-800 flex items-center justify-around text-center">
                <div>
                  <div className="text-[10px] text-stone-500">{isHi ? 'तनाव पूर्व' : 'Stress Before'}</div>
                  <div className="text-base font-bold text-stone-800 dark:text-stone-200">
                    {selectedEntry.stressBefore} / 5
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400" />
                <div>
                  <div className="text-[10px] text-stone-500">{isHi ? 'तनाव उपरांत' : 'Stress After'}</div>
                  <div className="text-base font-bold text-emerald-600 dark:text-emerald-400">
                    {selectedEntry.stressAfter || '-'} / 5
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => setSelectedEntry(null)}
              className="mt-6 w-full py-2.5 rounded-2xl bg-stone-900 dark:bg-amber-600 text-white text-xs font-semibold cursor-pointer"
            >
              {isHi ? 'बंद करें' : 'Close'}
            </button>
          </div>
        </div>
      )}

      {/* Add New Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-stone-900 p-6 shadow-2xl border border-stone-200 dark:border-stone-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif">
                {isHi ? 'नया चिंतन सहेजें' : 'Record Reflection'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitNew} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isHi ? 'तनाव श्रेणी' : 'Situation Category'}
                </label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as StressCategory)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs"
                >
                  {CATEGORY_FILTERS.filter((c) => c !== 'All').map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isHi ? 'क्या हुआ था? (संक्षेप में)' : 'What Happened?'}
                </label>
                <textarea
                  rows={2}
                  value={formInput}
                  onChange={(e) => setFormInput(e.target.value)}
                  placeholder={isHi ? 'स्थिति का संक्षिप्त वर्णन...' : 'Briefly describe the trigger or concern...'}
                  className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isHi ? 'प्रयुक्त गीता सिद्धांत' : 'Gita Principle Used'}
                </label>
                <input
                  type="text"
                  value={formConcept}
                  onChange={(e) => setFormConcept(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isHi ? 'व्यावहारिक कदम' : 'Action Taken'}
                </label>
                <input
                  type="text"
                  value={formActionTaken}
                  onChange={(e) => setFormActionTaken(e.target.value)}
                  placeholder={isHi ? 'उदा: ३ शांत श्वास एवं कर्म पर ध्यान' : 'e.g., Paused 1 minute, focused on duty'}
                  className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  {isHi ? 'चिंतन / अनुभव' : 'Your Reflection'}
                </label>
                <textarea
                  rows={2}
                  value={formReflection}
                  onChange={(e) => setFormReflection(e.target.value)}
                  placeholder={isHi ? 'इस दृष्टिकोण से आपके मन में क्या बदलाव आया?' : 'How did your inner state shift?'}
                  className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    {isHi ? 'तनाव पूर्व (1-5)' : 'Stress Before (1-5)'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={5}
                    value={formStressBefore}
                    onChange={(e) => setFormStressBefore(parseInt(e.target.value, 10))}
                    className="w-full p-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-xs text-center font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    {isHi ? 'तनाव उपरांत (1-5)' : 'Stress After (1-5)'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={5}
                    value={formStressAfter}
                    onChange={(e) => setFormStressAfter(parseInt(e.target.value, 10))}
                    className="w-full p-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-xs text-center font-bold"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 text-xs font-semibold cursor-pointer"
                >
                  {isHi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 text-white text-xs font-semibold shadow-md cursor-pointer"
                >
                  {isHi ? 'सुरक्षित सहेजें' : 'Save to Cloud'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
