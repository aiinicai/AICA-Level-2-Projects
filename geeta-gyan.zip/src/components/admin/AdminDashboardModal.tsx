import React, { useState, useEffect } from 'react';
import {
  X,
  Users,
  ShieldCheck,
  Activity,
  Lock,
  Calendar,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getAdminPlatformStats, AdminAppStats } from '../../services/adminService';

interface AdminDashboardModalProps {
  language?: 'en' | 'hi';
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({ language = 'en' }) => {
  const { isAdminDashboardOpen, closeAdminDashboard, isAdmin, user } = useAuth();
  const [stats, setStats] = useState<AdminAppStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isHi = language === 'hi';

  const fetchStats = async () => {
    if (!isAdmin) return;
    try {
      setLoading(true);
      setError(null);
      const data = await getAdminPlatformStats();
      setStats(data);
    } catch (err: any) {
      console.error('Failed to load admin stats:', err);
      setError(err?.message || 'Access denied or error loading stats');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminDashboardOpen && isAdmin) {
      fetchStats();
    }
  }, [isAdminDashboardOpen, isAdmin]);

  if (!isAdminDashboardOpen || !isAdmin) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-2xl bg-[#FDFBF7] dark:bg-[#15110d] rounded-3xl border border-amber-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-amber-200/40 dark:border-stone-800 flex items-center justify-between bg-amber-50/50 dark:bg-stone-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 text-white flex items-center justify-center shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-stone-900 dark:text-stone-100">
                {isHi ? 'प्रशासक डैशबोर्ड (Admin Dashboard)' : 'Gita Gyan Admin Dashboard'}
              </h3>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                {isHi ? 'अनुप्रयोग उपयोग एवं गैर-संवेदनशील सांख्यिकी' : 'Application usage and non-sensitive platform statistics'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchStats}
              disabled={loading}
              className="p-2 rounded-xl text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-200/50 dark:hover:bg-stone-800 transition cursor-pointer"
              title="Refresh Stats"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={closeAdminDashboard}
              className="p-2 rounded-xl text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-200/50 dark:hover:bg-stone-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Strict Privacy Architecture Banner */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-amber-900 dark:text-amber-200">
            <Lock className="w-5 h-5 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-bold">
                {isHi
                  ? '🔒 डेटाबेस-स्तरीय शून्य-ज्ञान गोपनीयता (Database Zero-Knowledge Privacy)'
                  : '🔒 Database-Level Zero-Knowledge Privacy Enforced'}
              </p>
              <p className="text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed">
                {isHi
                  ? 'उपयोगकर्ताओं की व्यक्तिगत साधना डायरी और चिंतन पूरी तरह से सुरक्षित हैं। फायरबेस सुरक्षा नियम (Firebase Security Rules) व्यवस्थापक को भी किसी अन्य उपयोगकर्ता की डायरी पढ़ने की अनुमति नहीं देते।'
                  : "All seekers' personal journal reflections, prayers, and entries are cryptographically restricted to their unique UID. Firebase Security Rules prevent anyone, including administrators, from reading user journals."}
              </p>
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Total Users */}
            <div className="p-4 rounded-2xl bg-white dark:bg-stone-900/80 border border-stone-200/70 dark:border-stone-800 shadow-xs">
              <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
                <span className="text-xs font-medium">
                  {isHi ? 'पंजीकृत साधक' : 'Registered Seekers'}
                </span>
                <Users className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 dark:text-stone-100">
                {loading ? '...' : stats?.totalRegisteredUsers ?? 0}
              </p>
              <span className="text-[10px] text-stone-400">
                {isHi ? 'गूगल साइन-इन द्वारा प्रमाणित' : 'Authenticated via Google'}
              </span>
            </div>

            {/* Active Users */}
            <div className="p-4 rounded-2xl bg-white dark:bg-stone-900/80 border border-stone-200/70 dark:border-stone-800 shadow-xs">
              <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
                <span className="text-xs font-medium">
                  {isHi ? 'सक्रिय साधक (३० दिन)' : 'Active (30 Days)'}
                </span>
                <Activity className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 dark:text-stone-100">
                {loading ? '...' : stats?.recentActiveUsersCount ?? 0}
              </p>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
                {isHi ? 'नियमित गीता अध्ययन' : 'Recent spiritual activity'}
              </span>
            </div>

            {/* Security Rules */}
            <div className="p-4 rounded-2xl bg-white dark:bg-stone-900/80 border border-stone-200/70 dark:border-stone-800 shadow-xs">
              <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
                <span className="text-xs font-medium">
                  {isHi ? 'सुरक्षा नियम' : 'Security Layer'}
                </span>
                <ShieldCheck className="w-4 h-4 text-teal-600" />
              </div>
              <p className="text-sm font-bold font-serif text-teal-700 dark:text-teal-300 mt-1">
                Rules Version 2
              </p>
              <span className="text-[10px] text-stone-400 block mt-1">
                {isHi ? 'सर्वर-स्तरीय आरबीएसी सक्रिय' : 'Server-side RBAC deployed'}
              </span>
            </div>
          </div>

          {/* User Roster (Non-sensitive details only) */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 font-serif">
              {isHi ? 'साधक सूची (गैर-संवेदनशील जानकारी)' : 'Registered Seekers (Non-Sensitive Roster)'}
            </h4>

            {loading ? (
              <div className="p-8 text-center text-xs text-stone-400">
                {isHi ? 'सांख्यिकी लोड हो रही है...' : 'Loading statistics...'}
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 text-xs">
                {error}
              </div>
            ) : stats?.usersList.length === 0 ? (
              <div className="p-6 text-center text-xs text-stone-400 bg-stone-50 dark:bg-stone-900/40 rounded-2xl">
                {isHi ? 'कोई उपयोगकर्ता नहीं मिला' : 'No registered users found yet'}
              </div>
            ) : (
              <div className="rounded-2xl border border-stone-200/80 dark:border-stone-800 overflow-hidden divide-y divide-stone-100 dark:divide-stone-800/60 bg-white/70 dark:bg-stone-900/70">
                {stats?.usersList.map((u) => (
                  <div key={u.uid} className="p-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-stone-800 dark:text-stone-200">
                          {u.displayName}
                        </span>
                        {u.role === 'admin' && (
                          <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[9px] font-bold">
                            Owner / Admin
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-stone-400">{u.email}</span>
                    </div>

                    <div className="text-right text-[10px] text-stone-400">
                      <span>{isHi ? 'पंजीकृत:' : 'Joined:'} </span>
                      <span>
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'N/A'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-amber-200/40 dark:border-stone-800 bg-amber-50/30 dark:bg-stone-900/30 flex items-center justify-end">
          <button
            onClick={closeAdminDashboard}
            className="px-4 py-2 rounded-xl bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 text-xs font-semibold hover:opacity-90 transition cursor-pointer"
          >
            {isHi ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
