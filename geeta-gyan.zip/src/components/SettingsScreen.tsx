import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  Sun,
  Moon,
  Laptop,
  Bell,
  Shield,
  Info,
  Trash2,
  AlertTriangle,
  Download,
  Heart,
  CheckCircle2,
  Volume2,
  Play,
  Square,
} from 'lucide-react';
import { UserPreferences } from '../types';
import { PWAInstallButton } from './pwa/PWAInstallButton';
import { meditationAudio } from '../services/meditationAudio';

interface SettingsScreenProps {
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
  onClearAllData: () => void;
  onShowToast: (msg: string) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  preferences,
  onUpdatePreferences,
  onClearAllData,
  onShowToast,
}) => {
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [isTestingVoice, setIsTestingVoice] = useState(false);

  const handleLanguageChange = (lang: 'en' | 'hi') => {
    onUpdatePreferences({ language: lang });
    onShowToast(`Language set to ${lang === 'en' ? 'English' : 'हिन्दी'}.`);
  };

  const handleTestSpokenVoice = (lang: 'hi' | 'en') => {
    if (isTestingVoice) {
      meditationAudio.stopSpeaking();
      setIsTestingVoice(false);
      return;
    }

    setIsTestingVoice(true);
    const testPhrase =
      lang === 'hi'
        ? 'ॐ नमो भगवते वासुदेवाय। आपका मन शांत, स्थिर और एकाग्र रहे।'
        : 'Om Namo Bhagavate Vasudevaya. May your mind remain peaceful and centered.';

    meditationAudio.speakCue(testPhrase, lang, false, () => {
      setIsTestingVoice(false);
    });
    onShowToast(lang === 'hi' ? 'Testing Hindi voice on your device...' : 'Testing English voice on your device...');
  };

  const handleThemeChange = (theme: 'light' | 'dark' | 'system') => {
    onUpdatePreferences({ theme });
    onShowToast(`Theme set to ${theme}.`);
  };

  const handleReminderToggle = () => {
    const nextVal = !preferences.dailyReminderEnabled;
    if (nextVal && 'Notification' in window) {
      Notification.requestPermission().then((perm) => {
        if (perm === 'granted') {
          onUpdatePreferences({ dailyReminderEnabled: true });
          onShowToast('Morning reflection reminder active.');
        } else {
          onUpdatePreferences({ dailyReminderEnabled: true });
          onShowToast('Reminder preference set.');
        }
      });
    } else {
      onUpdatePreferences({ dailyReminderEnabled: nextVal });
      onShowToast(nextVal ? 'Daily reminder enabled.' : 'Daily reminder disabled.');
    }
  };

  const handleConfirmClear = () => {
    onClearAllData();
    setShowConfirmDelete(false);
    onShowToast('All local data has been permanently cleared.');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif">
          Settings & Preferences
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-1">
          Customize your experience, language, privacy, and device storage.
        </p>
      </div>

      {/* SECTION 1: Language Settings */}
      <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-5">
        {/* Written Language */}
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1.5">
            <Globe className="w-4 h-4" />
            <span>Written Language (लिखित भाषा • Default: English)</span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">
            Choose whether cards, labels, and text explanations appear in English or Hindi.
          </p>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => handleLanguageChange('en')}
              className={`p-3 rounded-2xl border text-sm font-semibold transition ${
                preferences.language === 'en'
                  ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
              }`}
            >
              English (Default)
            </button>
            <button
              onClick={() => handleLanguageChange('hi')}
              className={`p-3 rounded-2xl border text-sm font-semibold transition ${
                preferences.language === 'hi'
                  ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
              }`}
            >
              हिन्दी (Hindi)
            </button>
          </div>
        </div>

        {/* Spoken Voice Language */}
        <div className="pt-3 border-t border-stone-200/70 dark:border-stone-800/80">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1.5">
            <Volume2 className="w-4 h-4" />
            <span>Spoken Voice Language (उच्चारण / स्वर • Default: हिन्दी)</span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">
            Choose the spoken audio voice for breath meditation cues, verse recitation, and video dialogue narration.
          </p>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                onUpdatePreferences({ spokenLanguage: 'hi' });
                onShowToast('Spoken voice language set to हिन्दी.');
              }}
              className={`p-3 rounded-2xl border text-sm font-semibold transition ${
                (preferences.spokenLanguage || 'hi') === 'hi'
                  ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
              }`}
            >
              हिन्दी (Default)
            </button>
            <button
              onClick={() => {
                onUpdatePreferences({ spokenLanguage: 'en' });
                onShowToast('Spoken voice language set to English.');
              }}
              className={`p-3 rounded-2xl border text-sm font-semibold transition ${
                preferences.spokenLanguage === 'en'
                  ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
              }`}
            >
              English
            </button>
          </div>

          {/* Test Voice Button */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => handleTestSpokenVoice(preferences.spokenLanguage || 'hi')}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl border text-xs font-semibold transition active:scale-98 shadow-xs ${
                isTestingVoice
                  ? 'bg-rose-50 border-rose-300 text-rose-700 dark:bg-rose-950/40 dark:border-rose-800 dark:text-rose-300'
                  : 'bg-amber-50/80 border-amber-200 dark:bg-amber-950/40 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 hover:bg-amber-100/80'
              }`}
            >
              {isTestingVoice ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop Voice Test</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>
                    Test Spoken Voice ({preferences.spokenLanguage === 'en' ? 'English' : 'हिन्दी'})
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 2: Appearance / Theme */}
      <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-3">
          <Sun className="w-4 h-4" />
          <span>Appearance</span>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={() => handleThemeChange('light')}
            className={`flex flex-col items-center gap-2 p-3 rounded-2xl border text-xs font-medium transition ${
              preferences.theme === 'light'
                ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
            }`}
          >
            <Sun className="w-4 h-4 text-amber-600" />
            <span>Light</span>
          </button>

          <button
            onClick={() => handleThemeChange('dark')}
            className={`flex flex-col items-center gap-2 p-3 rounded-2xl border text-xs font-medium transition ${
              preferences.theme === 'dark'
                ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
            }`}
          >
            <Moon className="w-4 h-4 text-stone-700 dark:text-stone-300" />
            <span>Dark</span>
          </button>

          <button
            onClick={() => handleThemeChange('system')}
            className={`flex flex-col items-center gap-2 p-3 rounded-2xl border text-xs font-medium transition ${
              preferences.theme === 'system'
                ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 shadow-xs'
                : 'border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
            }`}
          >
            <Laptop className="w-4 h-4 text-stone-500" />
            <span>System</span>
          </button>
        </div>
      </div>

      {/* SECTION 3: Daily Calm Reminder */}
      <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                Daily Morning Reminder
              </div>
              <div className="text-xs text-stone-500 dark:text-stone-400">
                A gentle reminder to pause and read your daily principle
              </div>
            </div>
          </div>

          <button
            onClick={handleReminderToggle}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
              preferences.dailyReminderEnabled ? 'bg-amber-600' : 'bg-stone-300 dark:bg-stone-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                preferences.dailyReminderEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* SECTION 4: Install PWA */}
      <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
              Install Geeta Gyan App
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
              Install as a native Progressive Web App for fast, offline access right from your home screen.
            </p>
          </div>
          <PWAInstallButton variant="settings" />
        </div>
      </div>

      {/* SECTION 4.5: GitHub Source Code Zip Export (Desktop Only - Hidden on Mobile) */}
      <div className="hidden md:block bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                GitHub Repository Package (.ZIP)
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Clean source code archive ready for GitHub upload or release
              </p>
            </div>
          </div>
          <a
            href="/geeta-gyan.zip"
            download="geeta-gyan.zip"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold shadow-xs transition"
          >
            <Download className="w-4 h-4" />
            <span>Download .ZIP</span>
          </a>
        </div>
        <div className="p-3 rounded-2xl bg-stone-50 dark:bg-stone-800/50 border border-stone-200/60 dark:border-stone-700/60 text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
          <p className="font-semibold text-stone-800 dark:text-stone-200 mb-1">
            📦 Ready for GitHub:
          </p>
          <ul className="list-disc list-inside space-y-0.5 text-stone-600 dark:text-stone-400">
            <li>Includes complete React 19 + TypeScript source code, PWA config & README.md</li>
            <li>Cleaned archive with <code>node_modules</code> and build artifacts excluded (~200 KB)</li>
            <li>Ready to attach to a GitHub Release or commit as a repository</li>
          </ul>
        </div>
      </div>

      {/* SECTION 5: Privacy & Local Data */}
      <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400">
          <Shield className="w-4 h-4" />
          <span>Privacy & Data Guarantee</span>
        </div>
        <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
          <strong>100% On-Device Privacy:</strong> All your reflections, stress check-ins, journal notes, and preferences are stored exclusively on your local device (in your browser’s LocalStorage). No personal journal text is transmitted to or stored on external servers.
        </p>

        {/* Delete All Data Button */}
        <div className="pt-2">
          <button
            onClick={() => setShowConfirmDelete(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-400 text-xs font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete All My Data</span>
          </button>
        </div>
      </div>

      {/* SECTION 6: Comprehensive Non-Medical Disclaimer */}
      <div className="bg-stone-50/90 dark:bg-stone-900/40 rounded-3xl p-6 border border-stone-200 dark:border-stone-800 space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-600 dark:text-stone-400">
          <Info className="w-4 h-4" />
          <span>Philosophical Wellbeing Disclaimer</span>
        </div>
        <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
          Geeta Gyan is designed solely for spiritual reflection, philosophical exploration, and general personal wellbeing. It does not provide medical advice, psychiatric assessment, clinical diagnosis, or therapy. The Bhagavad Gita teachings presented here are intended to inspire mindful living and disciplined action for everyday stress. If you are experiencing acute psychological distress, please seek support from licensed mental health professionals or emergency crisis services.
        </p>
      </div>

      {/* SECTION 7: About Geeta Gyan */}
      <div className="text-center py-4 text-xs text-stone-400 dark:text-stone-500 space-y-1">
        <p className="font-serif text-stone-600 dark:text-stone-400">
          Geeta Gyan — Ancient wisdom for a calmer mind.
        </p>
        <p>Curated canonical verses from Bhagavad Gita • Built with precision</p>
      </div>

      {/* Delete Confirmation Modal */}
      {showConfirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-stone-900 p-6 shadow-2xl border border-stone-200 dark:border-stone-800">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif mb-2">
              Permanently Clear All Data?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed mb-6">
              This will erase all your journal entries, check-in history, saved guidances, and custom preferences from this device. This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirmDelete(false)}
                className="flex-1 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmClear}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs"
              >
                Delete Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
