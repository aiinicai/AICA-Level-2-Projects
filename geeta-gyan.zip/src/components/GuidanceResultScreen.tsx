import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  CheckCircle2,
  Copy,
  Globe,
  HelpCircle,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  Volume2,
  BookOpen,
  RefreshCw,
  Clock,
  ShieldCheck,
  Film,
} from 'lucide-react';
import { GuidanceResult, UserPreferences } from '../types';
import { logFeedback } from '../services/guidanceService';
import { meditationAudio } from '../services/meditationAudio';
import { MahabharatVideo } from './MahabharatVideo';
import { StatusImageGeneratorModal, StatusVerseData } from './StatusImageGeneratorModal';
import { KrishnaUpadeshArt } from './KrishnaUpadeshArt';

interface GuidanceResultScreenProps {
  guidance: GuidanceResult;
  userInput?: string;
  initialStressLevel: number;
  preferences: UserPreferences;
  onSaveToggle: (guidance: GuidanceResult) => boolean;
  isSaved: boolean;
  onAnotherPerspective: () => void;
  onJournalAboutThis: (guidance: GuidanceResult) => void;
  onBackToHome: () => void;
  onShowToast: (message: string) => void;
  onExploreChapter?: (chapterNumber: number) => void;
}

export const GuidanceResultScreen: React.FC<GuidanceResultScreenProps> = ({
  guidance,
  userInput,
  initialStressLevel,
  preferences,
  onSaveToggle,
  isSaved,
  onAnotherPerspective,
  onJournalAboutThis,
  onBackToHome,
  onShowToast,
  onExploreChapter,
}) => {
  const [showHindi, setShowHindi] = useState(preferences.language === 'hi');
  const [feedbackGiven, setFeedbackGiven] = useState<'helped' | 'not_relevant' | null>(null);
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});
  const [statusModalOpen, setStatusModalOpen] = useState(false);

  // Text-to-Speech Engine State for Bhagavad Gita Verse Recitation
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [speechSpeed, setSpeechSpeed] = useState<number>(0.8);
  const [speechLang, setSpeechLang] = useState<'hi' | 'en'>(preferences.spokenLanguage || 'hi');

  // Interactive Action Timer State
  const initialSeconds = (guidance.action.timerMinutes || 10) * 60;
  const [timeLeft, setTimeLeft] = useState(initialSeconds);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerFinished, setTimerFinished] = useState(false);

  useEffect(() => {
    setShowHindi(preferences.language === 'hi');
  }, [preferences.language]);

  // Recite the displayed Bhagavad Gita verse in a soothing, motivating Hindi voice
  const cancelRecitationRef = React.useRef<(() => void) | null>(null);

  const startVerseSpeech = (speed: number = speechSpeed, lang: 'hi' | 'en' = speechLang) => {
    setIsSpeaking(true);
    setIsPaused(false);

    if (cancelRecitationRef.current) {
      cancelRecitationRef.current();
      cancelRecitationRef.current = null;
    }

    cancelRecitationRef.current = meditationAudio.reciteBhagavadGitaVerse({
      chapter: guidance.verse.chapter,
      verseNumber: guidance.verse.verseNumber,
      sanskrit: guidance.verse.sanskrit,
      translationHindi: guidance.verse.translationHindi,
      motivatingTakeaway: guidance.whatThisMeansForYou,
      lang: lang,
      rate: speed,
      onStart: () => {
        setIsSpeaking(true);
        setIsPaused(false);
      },
      onEnd: () => {
        setIsSpeaking(false);
        setIsPaused(false);
      },
      onError: () => {
        setIsSpeaking(false);
        setIsPaused(false);
      },
    }) || null;
  };

  const handlePauseResumeSpeech = () => {
    if (isPaused) {
      meditationAudio.resumeSpeaking();
      setIsPaused(false);
      setIsSpeaking(true);
      onShowToast('Resumed soothing Hindi recitation.');
    } else if (isSpeaking) {
      meditationAudio.pauseSpeaking();
      setIsPaused(true);
      onShowToast('Recitation paused.');
    } else {
      startVerseSpeech(speechSpeed, speechLang);
      onShowToast('Playing soothing verse recitation in Hindi.');
    }
  };

  const handleStopSpeech = () => {
    if (cancelRecitationRef.current) {
      cancelRecitationRef.current();
      cancelRecitationRef.current = null;
    }
    meditationAudio.stopSpeaking();
    setIsSpeaking(false);
    setIsPaused(false);
  };

  const handleReplaySpeech = () => {
    startVerseSpeech(speechSpeed, speechLang);
    onShowToast('Replaying soothing Hindi verse recitation.');
  };

  // Clean up audio on unmount without aggressive un-gestured mobile autoplay
  useEffect(() => {
    return () => {
      if (cancelRecitationRef.current) {
        cancelRecitationRef.current();
        cancelRecitationRef.current = null;
      }
      meditationAudio.stopSpeaking();
    };
  }, [guidance.verse.id]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (timerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerRunning) {
      setTimerRunning(false);
      setTimerFinished(true);
      onShowToast('Action timer completed! Take a mindful breath.');
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerRunning, timeLeft]);

  const toggleStep = (idx: number) => {
    setCompletedSteps((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const handleFeedback = (type: 'helped' | 'not_relevant') => {
    logFeedback(guidance.verse.id, type);
    setFeedbackGiven(type);
    if (type === 'helped') {
      onShowToast('Thank you for your feedback. Glad this principle resonated.');
    } else {
      onShowToast('Feedback noted. You can tap "Another Perspective" below.');
    }
  };

  const handleSave = () => {
    const saved = onSaveToggle(guidance);
    onShowToast(saved ? 'Guidance saved to your library.' : 'Guidance removed from saved.');
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const resetTimer = () => {
    setTimerRunning(false);
    setTimeLeft(initialSeconds);
    setTimerFinished(false);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Top Header & Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>New check-in</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Save button */}
          <button
            onClick={handleSave}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition ${
              isSaved
                ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800'
                : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:bg-stone-50'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-amber-600 text-amber-600' : ''}`} />
            <span>{isSaved ? 'Saved' : 'Save This'}</span>
          </button>
        </div>
      </div>

      {/* SECTION A: What I Understand */}
      <div className="bg-gradient-to-br from-teal-50/90 via-emerald-50/60 to-cyan-50/70 dark:from-stone-900/90 dark:via-teal-950/40 dark:to-stone-900/90 rounded-3xl p-6 shadow-xs border border-teal-200/80 dark:border-teal-900/50 backdrop-blur-xs zen-glow">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-900 dark:text-teal-300 mb-2.5">
          <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
          <span>Section A • What I Understand</span>
        </div>
        <p className="text-stone-800 dark:text-stone-200 text-sm sm:text-base leading-relaxed">
          {guidance.understanding}
        </p>
      </div>

      {/* SECTION B: Geeta Perspective */}
      <div className="bg-gradient-to-br from-amber-50/95 via-orange-50/80 to-rose-50/70 dark:from-stone-900 dark:via-stone-900/95 dark:to-amber-950/30 rounded-3xl p-6 shadow-sm border border-amber-200/90 dark:border-amber-900/50 zen-glow relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-300/20 via-orange-300/10 to-transparent rounded-full blur-xl pointer-events-none" />
        <div className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1.5 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>Section B • Geeta Perspective</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 font-serif mb-2 bg-gradient-to-r from-amber-900 to-orange-800 dark:from-amber-200 dark:to-orange-200 bg-clip-text text-transparent">
          {guidance.perspectiveConcept}
        </h3>
        <p className="text-stone-700 dark:text-stone-300 text-sm leading-relaxed">
          {guidance.perspectiveExplanation}
        </p>
      </div>

      {/* SECTION C: Relevant Verse */}
      <div className="bg-gradient-to-b from-white/95 to-amber-50/30 dark:from-stone-900/95 dark:to-stone-950 rounded-3xl p-6 shadow-sm border border-amber-200/70 dark:border-stone-800 relative overflow-hidden">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs font-bold tracking-wide shadow-xs">
              BG {guidance.verse.chapter}.{guidance.verse.verseNumber}
            </span>
            {onExploreChapter && (
              <button
                onClick={() => onExploreChapter(guidance.verse.chapter)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-100/80 dark:bg-amber-950/60 hover:bg-amber-200/80 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-300 text-xs font-semibold border border-amber-300/60 dark:border-amber-800/60 transition shadow-xs"
                title={`Explore all verses and summary of Chapter ${guidance.verse.chapter}`}
              >
                <span>{showHindi ? `अध्याय ${guidance.verse.chapter} का अन्वेषण` : `Explore Chapter ${guidance.verse.chapter}`}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
            <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Canonical</span>
            </span>
          </div>

          {/* Translation display toggle & Status Generator */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setStatusModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white shadow-xs transition active:scale-95 cursor-pointer"
              title="Create WhatsApp / Instagram Status"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{showHindi ? 'स्टेटस बनाएं' : 'Status Image'}</span>
            </button>

            <button
              onClick={() => setShowHindi(!showHindi)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border border-amber-300/80 dark:border-amber-700/60 bg-amber-50/80 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition shadow-xs cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
              <span>{showHindi ? 'Show English' : 'हिंदी अनुवाद'}</span>
            </button>
          </div>
        </div>

        {/* Dedicated Soothing & Motivating Hindi TTS Voice Recitation Player */}
        <div
          className={`p-3.5 sm:p-4 rounded-2xl border transition-all mb-4 ${
            isSpeaking
              ? 'bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/15 border-amber-400 dark:border-amber-600 shadow-xs'
              : isPaused
              ? 'bg-amber-50/80 dark:bg-stone-800/70 border-amber-300 dark:border-stone-700'
              : 'bg-stone-50/80 dark:bg-stone-800/40 border-stone-200/80 dark:border-stone-800'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Animated pulsating speaker */}
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 transition-all ${
                  isSpeaking
                    ? 'bg-gradient-to-br from-amber-600 to-orange-600 text-white shadow-md shadow-amber-500/25 ring-2 ring-amber-400/40 animate-pulse'
                    : isPaused
                    ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                }`}
              >
                {isSpeaking ? (
                  <div className="flex items-end gap-0.5 h-4">
                    <span className="w-1 bg-white rounded-full animate-bounce [animation-delay:0ms] h-2.5" />
                    <span className="w-1 bg-white rounded-full animate-bounce [animation-delay:150ms] h-4" />
                    <span className="w-1 bg-white rounded-full animate-bounce [animation-delay:300ms] h-3" />
                  </div>
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-stone-900 dark:text-stone-100 font-serif">
                    {isSpeaking
                      ? 'Reciting in Soothing Hindi Voice...'
                      : isPaused
                      ? 'Recitation Paused'
                      : 'Bhagavad Gita Verse Voice Recitation'}
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.2 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60">
                    {speechLang === 'hi' ? 'हिन्दी (Default)' : 'English'}
                  </span>
                </div>
                <p className="text-[11px] text-stone-600 dark:text-stone-400 mt-0.5">
                  {isSpeaking
                    ? 'Sacred Sanskrit shloka + Gita Press Hindi meaning & wisdom'
                    : 'Acoustic singing bowl chime + calming motivating voice'}
                </p>
              </div>
            </div>

            {/* TTS Audio Controls */}
            <div className="flex items-center gap-1.5 self-end sm:self-center">
              <button
                type="button"
                onClick={handlePauseResumeSpeech}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold shadow-xs transition active:scale-95"
                title={isSpeaking ? 'Pause voice recitation' : 'Play/Resume voice recitation'}
              >
                {isSpeaking ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isPaused ? 'Resume' : 'Listen'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleReplaySpeech}
                className="p-1.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 text-xs transition active:scale-95 shadow-xs"
                title="Replay from start with Tibetan singing bowl"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              {/* Speed pace toggle */}
              <button
                type="button"
                onClick={() => {
                  const nextSpeed = speechSpeed === 0.8 ? 1.0 : 0.8;
                  setSpeechSpeed(nextSpeed);
                  if (isSpeaking) {
                    startVerseSpeech(nextSpeed, speechLang);
                  }
                  onShowToast(nextSpeed === 0.8 ? 'Soothing pace (0.8x) selected.' : 'Normal pace (1.0x) selected.');
                }}
                className="px-2.5 py-1.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-[11px] font-medium transition hover:bg-stone-100 dark:hover:bg-stone-700 shadow-xs"
                title="Change reading speed"
              >
                {speechSpeed === 0.8 ? '0.8x Soothing' : '1.0x Normal'}
              </button>
            </div>
          </div>
        </div>

        {/* Divine Image of Lord Shri Krishna Speaking Sacred Gita Words */}
        <div className="flex justify-center my-3">
          <KrishnaUpadeshArt
            size="sm"
            showBanner={true}
            language={showHindi ? 'hi' : 'en'}
          />
        </div>

        {/* Sanskrit Devanagari */}
        <div className="p-5 rounded-2xl bg-gradient-to-b from-amber-100/60 via-amber-50/50 to-orange-50/40 dark:from-stone-950/80 dark:to-stone-900/60 border border-amber-200/80 dark:border-amber-900/40 text-center mb-3.5 shadow-xs">
          <p className="text-lg sm:text-xl font-medium text-stone-900 dark:text-amber-100 font-serif whitespace-pre-line leading-relaxed tracking-wide">
            {guidance.verse.sanskrit}
          </p>
        </div>

        {/* Roman Transliteration */}
        <p className="text-xs text-stone-500 dark:text-stone-400 italic text-center mb-4 leading-relaxed font-sans px-2">
          {guidance.verse.transliteration}
        </p>

        {/* Translation (English or Hindi) */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50/80 via-white to-orange-50/80 dark:from-stone-800/40 dark:via-stone-900/60 dark:to-stone-800/40 border border-amber-100 dark:border-stone-800 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 block mb-1">
            {showHindi ? 'हिंदी अनुवाद (Gita Press)' : 'English Translation'}
          </span>
          <p className="text-sm text-stone-800 dark:text-stone-200 leading-relaxed font-medium">
            {showHindi ? guidance.verse.translationHindi : guidance.verse.translationEnglish}
          </p>
        </div>

        <div className="mt-3 text-[11px] text-stone-400 dark:text-stone-500 text-right">
          Source: {guidance.verse.source}
        </div>
      </div>

      {/* SECTION D: What This Means for You */}
      <div className="bg-gradient-to-br from-orange-50/70 via-rose-50/50 to-amber-50/60 dark:from-stone-900/90 dark:via-orange-950/30 dark:to-stone-900/90 rounded-3xl p-6 shadow-xs border border-orange-200/70 dark:border-orange-900/40">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-orange-900 dark:text-orange-300 mb-2">
          Section D • What This Means for You
        </div>
        <p className="text-stone-800 dark:text-stone-200 text-sm sm:text-base leading-relaxed">
          {guidance.whatThisMeansForYou}
        </p>
      </div>

      {/* CINEMATIC VIDEO (AFTER SECTION D): Kurukshetra Scene & Divine Dialogue */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400">
            <Film className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>Cinematic Mahabharata Scene • 40s Divine Wisdom</span>
          </div>
          <span className="text-[11px] text-amber-800/80 dark:text-amber-300/80 font-medium">
            Lord Krishna & Arjuna • Kurukshetra
          </span>
        </div>
        <MahabharatVideo
          category={guidance.matchedCategory}
          principle={guidance.perspectiveConcept}
          verseRef={`BG ${guidance.verse.chapter}.${guidance.verse.verseNumber}`}
          chapter={guidance.verse.chapter}
          verseNumber={guidance.verse.verseNumber}
          userInput={userInput}
          guidanceUnderstanding={guidance.understanding}
          whatThisMeansForYou={guidance.whatThisMeansForYou}
          verse={guidance.verse}
          initialLang={preferences.language || 'en'}
          spokenLang={preferences.spokenLanguage || 'hi'}
        />
      </div>

      {/* SECTION E: Try This Now (Practical Action with checklist + timer) */}
      <div className="bg-gradient-to-b from-white/95 via-emerald-50/20 to-teal-50/20 dark:from-stone-900/95 dark:via-stone-900 dark:to-emerald-950/30 rounded-3xl p-6 shadow-xs border border-emerald-200/70 dark:border-emerald-900/40">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-800 dark:text-emerald-400">
            Section E • Try This Now
          </div>
          {guidance.action.timerMinutes && (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-stone-600 dark:text-stone-400 bg-stone-100 dark:bg-stone-800 px-2.5 py-0.5 rounded-full">
              <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{guidance.action.timerMinutes} min practice</span>
            </span>
          )}
        </div>

        <h4 className="text-lg font-bold text-stone-900 dark:text-stone-100 mb-4 font-serif">
          {guidance.action.title}
        </h4>

        {/* Step-by-step checklist */}
        <div className="space-y-3 mb-6">
          {guidance.action.steps.map((step, idx) => {
            const isDone = !!completedSteps[idx];
            return (
              <button
                key={idx}
                type="button"
                onClick={() => toggleStep(idx)}
                className={`w-full flex items-start gap-3 p-3.5 rounded-2xl border text-left transition ${
                  isDone
                    ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-900/40 text-stone-500 dark:text-stone-400'
                    : 'bg-white/80 dark:bg-stone-950/40 border-stone-200 dark:border-stone-800 text-stone-800 dark:text-stone-200 hover:bg-stone-50/90'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 transition ${
                    isDone
                      ? 'bg-emerald-600 text-white'
                      : 'border border-stone-300 dark:border-stone-600 text-stone-400'
                  }`}
                >
                  {isDone ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : <span className="text-xs">{idx + 1}</span>}
                </div>
                <span className={`text-xs sm:text-sm leading-relaxed ${isDone ? 'line-through' : ''}`}>
                  {step}
                </span>
              </button>
            );
          })}
        </div>

        {/* Optional Action Countdown Timer */}
        {guidance.action.timerMinutes && (
          <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-stone-800/60 border border-amber-200/60 dark:border-stone-700/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-2xl font-mono font-bold text-stone-900 dark:text-stone-100">
                {formatTimer(timeLeft)}
              </div>
              <span className="text-xs text-stone-500 dark:text-stone-400">
                {timerFinished ? 'Complete' : timerRunning ? 'Focusing...' : 'Ready'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setTimerRunning(!timerRunning)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold shadow-xs transition"
              >
                {timerRunning ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>{timeLeft < initialSeconds ? 'Resume' : 'Start Timer'}</span>
                  </>
                )}
              </button>
              <button
                onClick={resetTimer}
                title="Reset timer"
                className="p-1.5 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-700 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* SECTION F: Reflection Question */}
      <div className="bg-gradient-to-r from-purple-50/70 via-pink-50/40 to-amber-50/50 dark:from-stone-900/95 dark:via-purple-950/30 dark:to-stone-900 rounded-3xl p-6 shadow-xs border border-purple-200/60 dark:border-purple-900/40">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-purple-900 dark:text-purple-300 mb-2">
          Section F • Reflection Question
        </div>
        <p className="text-base sm:text-lg font-serif italic text-stone-900 dark:text-stone-100 leading-relaxed mb-4">
          “{guidance.reflectionQuestion}”
        </p>

        {/* Feedback Buttons */}
        <div className="pt-2 border-t border-purple-200/50 dark:border-stone-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 dark:text-stone-400">Did this perspective help?</span>
            <button
              onClick={() => handleFeedback('helped')}
              disabled={feedbackGiven !== null}
              className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border transition ${
                feedbackGiven === 'helped'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
                  : 'border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-white dark:hover:bg-stone-800'
              }`}
            >
              <ThumbsUp className="w-3 h-3" />
              <span>This Helped</span>
            </button>
            <button
              onClick={() => handleFeedback('not_relevant')}
              disabled={feedbackGiven !== null}
              className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border transition ${
                feedbackGiven === 'not_relevant'
                  ? 'bg-stone-200 text-stone-800 border-stone-400 dark:bg-stone-800 dark:text-stone-300'
                  : 'border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-white dark:hover:bg-stone-800'
              }`}
            >
              <ThumbsDown className="w-3 h-3" />
              <span>Not Relevant</span>
            </button>
          </div>

          <button
            onClick={onAnotherPerspective}
            className="flex items-center gap-1.5 text-xs text-amber-800 dark:text-amber-400 hover:underline font-semibold"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Another Perspective</span>
          </button>
        </div>
      </div>

      {/* Bottom Main Action: Journal About This */}
      <div className="pt-2">
        <button
          onClick={() => onJournalAboutThis(guidance)}
          className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl font-semibold text-sm bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:via-orange-500 hover:to-amber-600 text-white transition-all shadow-md shadow-amber-600/25 active:scale-[0.99] cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
          <span>Journal About This (Record Before & After Stress)</span>
        </button>
      </div>

      {/* WHATSAPP & INSTAGRAM STATUS GENERATOR MODAL */}
      {statusModalOpen && (
        <StatusImageGeneratorModal
          isOpen={statusModalOpen}
          onClose={() => setStatusModalOpen(false)}
          verseData={{
            chapter: guidance.verse.chapter,
            verse: guidance.verse.verseNumber,
            sanskrit: guidance.verse.sanskrit,
            transliteration: guidance.verse.transliteration,
            hindi: guidance.verse.translationHindi,
            english: guidance.verse.translationEnglish,
            positiveMessage: showHindi
              ? `${guidance.verse.primaryConcept}: अपने कर्तव्य पर स्थिर रहें और आंतरिक शांति पाएं।`
              : `${guidance.verse.primaryConcept}: Stay anchored in what is within your control and rest in inner peace.`,
          }}
          language={preferences.language}
          onShowToast={onShowToast}
        />
      )}
    </div>
  );
};
