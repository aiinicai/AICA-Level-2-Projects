import React from 'react';
import { Sparkles, Compass, BookOpen, Heart, Settings, BookMarked } from 'lucide-react';

interface BottomNavProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
  language?: 'en' | 'hi';
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate, language = 'en' }) => {
  const isHi = language === 'hi';

  const navItems = [
    { id: 'home', label: isHi ? 'गृह' : 'Home', icon: Sparkles },
    { id: 'chapters', label: isHi ? '१८ अध्याय' : 'Chapters', icon: BookOpen },
    { id: 'daily', label: isHi ? 'दैनिक' : 'Daily', icon: Compass },
    { id: 'journal', label: isHi ? 'डायरी' : 'Journal', icon: BookMarked },
    { id: 'journey', label: isHi ? 'यात्रा' : 'Journey', icon: Heart },
    { id: 'settings', label: isHi ? 'सेटिंग्स' : 'Settings', icon: Settings },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 dark:bg-[#0c0907]/95 border-t border-amber-200/50 dark:border-amber-900/30 backdrop-blur-xl pb-safe">
      <div className="grid grid-cols-6 h-16 max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            activeScreen === item.id ||
            (item.id === 'home' && (activeScreen === 'checkin' || activeScreen === 'guidance'));

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 transition-all relative py-1 cursor-pointer select-none ${
                isActive
                  ? 'text-amber-500 dark:text-amber-400 font-bold'
                  : 'text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition ${
                  isActive ? 'scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''
                }`}
              >
                <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive ? 'stroke-[2.4] fill-amber-500/20' : 'stroke-[1.8]'}`} />
              </div>
              <span className="text-[9px] sm:text-[10px] tracking-tight">{item.label}</span>

              {/* Active Dot */}
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400 shadow-[0_0_6px_#f59e0b] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

