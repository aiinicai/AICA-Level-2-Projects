import React, { useState, useEffect } from 'react';
import {
  Wind,
  Columns3,
  CheckCircle,
  ShieldAlert,
  HelpCircle,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Trash2,
  ArrowRight,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { RESET_EXERCISES } from '../data/exercises';
import { meditationAudio } from '../services/meditationAudio';

type ExerciseId = 'one-minute-pause' | 'control-vs-outcome' | 'one-action' | 'anger-pause' | 'thought-reset';

export const ResetScreen: React.FC = () => {
  const [selectedId, setSelectedId] = useState<ExerciseId>('one-minute-pause');

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Header */}
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100/70 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 text-xs font-semibold mb-2">
          <Wind className="w-3.5 h-3.5" />
          <span>Quick Relief Mode</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif">
          2-Minute Reset
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-1">
          Simple practical exercises grounded in Gita psychology to regain steady footing.
        </p>
      </div>

      {/* Exercise Selector Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {RESET_EXERCISES.map((ex) => {
          const isSelected = selectedId === ex.id;
          return (
            <button
              key={ex.id}
              onClick={() => setSelectedId(ex.id as ExerciseId)}
              className={`p-3 rounded-2xl text-left border transition ${
                isSelected
                  ? 'bg-amber-700 text-white border-amber-800 shadow-xs'
                  : 'bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800/60'
              }`}
            >
              <div className="text-xs font-bold truncate mb-0.5">{ex.title}</div>
              <div className={`text-[10px] ${isSelected ? 'text-amber-200' : 'text-stone-400'}`}>
                {ex.duration}
              </div>
            </button>
          );
        })}
      </div>

      {/* Render Active Exercise */}
      {selectedId === 'one-minute-pause' && <OneMinutePauseExercise />}
      {selectedId === 'control-vs-outcome' && <ControlVsOutcomeExercise />}
      {selectedId === 'one-action' && <OneActionExercise />}
      {selectedId === 'anger-pause' && <AngerPauseExercise />}
      {selectedId === 'thought-reset' && <ThoughtResetExercise />}
    </div>
  );
};

/* ----------------------------------------------------
   Exercise 1: 2-Minute Meditation (Breathing Guide)
---------------------------------------------------- */
function OneMinutePauseExercise() {
  const [totalDurationOption, setTotalDurationOption] = useState<120 | 60>(120);
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Pause'>('Inhale');
  const [secondsLeftInPhase, setSecondsLeftInPhase] = useState(4);
  const [totalSecondsRemaining, setTotalSecondsRemaining] = useState(120);
  const [cycleCount, setCycleCount] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [voiceGuidance, setVoiceGuidance] = useState(true);
  const [voiceMode, setVoiceMode] = useState<'simple' | 'descriptive'>('simple'); // 'simple' says "Inhale", "Pause", "Exhale"
  const [voiceLang, setVoiceLang] = useState<'en' | 'hi'>('hi'); // Default spoken language: Hindi

  // Trigger soothing voice & singing bowl on phase transition
  useEffect(() => {
    if (!isActive) return;

    if (voiceGuidance) {
      if (phase === 'Inhale') {
        meditationAudio.playSingingBowl(216, 3.5);
        meditationAudio.speakBreathCue('Inhale', voiceMode, voiceLang);
      } else if (phase === 'Hold' || phase === 'Pause') {
        meditationAudio.playSingingBowl(256, 3.0);
        meditationAudio.speakBreathCue('Pause', voiceMode, voiceLang);
      } else if (phase === 'Exhale') {
        meditationAudio.playSingingBowl(174, 4.0);
        meditationAudio.speakBreathCue('Exhale', voiceMode, voiceLang);
      }
    }
  }, [phase, isActive, voiceGuidance, voiceMode, voiceLang]);

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isActive) {
      timer = setInterval(() => {
        setTotalSecondsRemaining((prevTotal) => {
          if (prevTotal <= 1) {
            setIsActive(false);
            setIsCompleted(true);
            meditationAudio.stopAmbientHum();
            meditationAudio.playSingingBowl(288, 5.0);
            return 0;
          }
          return prevTotal - 1;
        });

        setSecondsLeftInPhase((prev) => {
          if (prev <= 1) {
            // 4-Phase Rhythmic Sequence: Inhale(4s) -> Hold/Pause(4s) -> Exhale(6s) -> Rest/Pause(2s) = 16s per cycle
            if (phase === 'Inhale') {
              setPhase('Hold');
              return 4;
            } else if (phase === 'Hold') {
              setPhase('Exhale');
              return 6;
            } else if (phase === 'Exhale') {
              setPhase('Pause');
              return 2;
            } else {
              setPhase('Inhale');
              setCycleCount((c) => c + 1);
              return 4;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isActive, phase]);

  const toggleActive = () => {
    if (!isActive) {
      setIsActive(true);
      setIsCompleted(false);
      meditationAudio.startAmbientHum();
      if (voiceGuidance) {
        meditationAudio.playSingingBowl(216, 3.5);
        meditationAudio.speakBreathCue(phase === 'Hold' ? 'Pause' : phase, voiceMode, voiceLang);
      }
    } else {
      setIsActive(false);
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    }
  };

  const handleSelectDuration = (duration: 120 | 60) => {
    setIsActive(false);
    setIsCompleted(false);
    setTotalDurationOption(duration);
    setTotalSecondsRemaining(duration);
    setPhase('Inhale');
    setSecondsLeftInPhase(4);
    setCycleCount(0);
    meditationAudio.stopAmbientHum();
    meditationAudio.stopSpeaking();
  };

  const reset = () => {
    setIsActive(false);
    setIsCompleted(false);
    setPhase('Inhale');
    setSecondsLeftInPhase(4);
    setTotalSecondsRemaining(totalDurationOption);
    setCycleCount(0);
    meditationAudio.stopAmbientHum();
    meditationAudio.stopSpeaking();
  };

  const toggleVoice = () => {
    const next = !voiceGuidance;
    setVoiceGuidance(next);
    meditationAudio.setVoiceMuted(!next);
  };

  const formatMinSec = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 sm:p-8 border border-amber-200/70 dark:border-amber-900/50 text-center zen-glow relative overflow-hidden">
      {/* Decorative serene aura glow in background */}
      <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-gradient-to-b from-teal-400/20 via-amber-300/15 to-transparent blur-3xl pointer-events-none" />

      {/* Top Header & Settings */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-4 relative z-10">
        {/* Duration toggle: 2-Minute (Recommended) vs 1-Minute */}
        <div className="flex items-center gap-1 p-0.5 rounded-full bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700">
          <button
            onClick={() => handleSelectDuration(120)}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition ${
              totalDurationOption === 120
                ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            2 Minutes (Full Reset)
          </button>
          <button
            onClick={() => handleSelectDuration(60)}
            className={`px-2.5 py-1 rounded-full text-xs font-semibold transition ${
              totalDurationOption === 60
                ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            1 Minute
          </button>
        </div>

        {/* Audio voice controls: Voice Style, Language, Mute */}
        <div className="flex items-center gap-1.5">
          {/* Voice Prompt Mode */}
          {voiceGuidance && (
            <button
              onClick={() => setVoiceMode(voiceMode === 'simple' ? 'descriptive' : 'simple')}
              className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-50 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 transition"
              title="Toggle voice prompt style"
            >
              {voiceMode === 'simple' ? 'Cue: Inhale • Pause • Exhale' : 'Guided: Gentle Phrases'}
            </button>
          )}

          {/* Voice Language Switch (Default: Hindi) */}
          <button
            onClick={() => setVoiceLang(voiceLang === 'en' ? 'hi' : 'en')}
            className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:bg-stone-200 transition"
            title="Switch Voice Language"
          >
            {voiceLang === 'hi' ? 'Voice: हिन्दी' : 'Voice: EN'}
          </button>

          {/* Sound On / Muted */}
          <button
            onClick={toggleVoice}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border transition ${
              voiceGuidance
                ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                : 'bg-stone-100 text-stone-500 border-stone-200 dark:bg-stone-800 dark:text-stone-400'
            }`}
          >
            {voiceGuidance ? <Volume2 className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{voiceGuidance ? 'Voice On' : 'Muted'}</span>
          </button>
        </div>
      </div>

      <h2 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 font-serif mb-1 bg-gradient-to-r from-amber-900 via-orange-900 to-amber-800 dark:from-amber-100 dark:via-orange-200 dark:to-amber-200 bg-clip-text text-transparent">
        {totalDurationOption === 120 ? '2-Minute Meditation & Reset' : '1-Minute Mindful Reset'}
      </h2>
      <p className="text-xs text-stone-600 dark:text-stone-300 max-w-md mx-auto mb-6">
        Soothing meditation voice softly speaking <span className="font-semibold text-amber-800 dark:text-amber-300">“Inhale... Pause... Exhale... Pause...”</span> with Tibetan singing bowls and harmonic Om drone.
      </p>

      {/* Completion Banner */}
      {isCompleted && (
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/10 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 animate-fadeIn">
          <p className="text-sm font-bold flex items-center justify-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Meditation Complete • Savor this stillness</span>
          </p>
          <p className="text-xs text-stone-600 dark:text-stone-300 mt-1">
            Notice how your shoulders have dropped and the breath has naturally deepened.
          </p>
        </div>
      )}

      {/* Visual Colorful Breathing Circle */}
      <div className="relative w-64 h-64 mx-auto mb-6 flex items-center justify-center select-none">
        {/* Colorful Outer Aura Ripple */}
        <div
          className={`absolute inset-0 rounded-full transition-all duration-1000 ease-in-out ${
            phase === 'Inhale'
              ? 'scale-115 bg-gradient-to-tr from-teal-300/40 via-cyan-200/35 to-emerald-300/35 blur-md'
              : phase === 'Hold'
              ? 'scale-110 bg-gradient-to-tr from-amber-300/50 via-yellow-200/45 to-orange-300/45 blur-md'
              : phase === 'Exhale'
              ? 'scale-90 bg-gradient-to-tr from-rose-300/40 via-pink-200/35 to-orange-300/35 blur-md'
              : 'scale-95 bg-gradient-to-tr from-sky-300/40 via-indigo-200/30 to-teal-300/30 blur-md'
          }`}
        />

        {/* Inner Colorful Breathing Core */}
        <div
          className={`absolute inset-4 rounded-full transition-all duration-1000 ease-in-out shadow-lg flex items-center justify-center ${
            phase === 'Inhale'
              ? 'scale-105 bg-gradient-to-br from-teal-100 via-emerald-50 to-cyan-100 dark:from-teal-950/85 dark:via-emerald-950/65 dark:to-cyan-950/85 border-4 border-teal-400 dark:border-teal-500 shadow-teal-500/25'
              : phase === 'Hold'
              ? 'scale-105 bg-gradient-to-br from-amber-100 via-yellow-50 to-orange-100 dark:from-amber-950/85 dark:via-yellow-950/65 dark:to-orange-950/85 border-4 border-amber-400 dark:border-amber-500 shadow-amber-500/30'
              : phase === 'Exhale'
              ? 'scale-90 bg-gradient-to-br from-rose-100 via-pink-50 to-amber-50 dark:from-rose-950/85 dark:via-pink-950/65 dark:to-stone-900 border-4 border-rose-300 dark:border-rose-500 shadow-rose-500/25'
              : 'scale-95 bg-gradient-to-br from-sky-100 via-indigo-50 to-teal-50 dark:from-sky-950/85 dark:via-indigo-950/65 dark:to-teal-950/85 border-4 border-sky-400 dark:border-sky-500 shadow-sky-500/25'
          }`}
        />

        {/* Text Center Display */}
        <div className="relative z-10 text-center">
          <div className="text-[11px] uppercase tracking-widest font-semibold text-stone-500 dark:text-stone-400">
            {isActive ? (phase === 'Hold' || phase === 'Pause' ? 'Pause & Rest' : phase) : `${totalDurationOption / 60}m Meditation`}
          </div>
          <div className="text-2xl font-bold font-serif text-stone-900 dark:text-stone-100 mt-1">
            {isActive ? (phase === 'Hold' || phase === 'Pause' ? 'Pause' : phase) : 'Begin Meditation'}
          </div>
          <div className="text-4xl font-mono font-extrabold text-amber-900 dark:text-amber-300 my-1">
            {isActive ? `${secondsLeftInPhase}s` : formatMinSec(totalDurationOption)}
          </div>
          <div className="text-[11px] font-medium text-stone-600 dark:text-stone-300 px-4">
            {isActive
              ? phase === 'Inhale'
                ? 'Breathe in peace'
                : phase === 'Hold'
                ? 'Hold the stillness'
                : phase === 'Exhale'
                ? 'Release all tension'
                : 'Rest in this moment'
              : 'Tap to start soothing guided voice'}
          </div>
        </div>
      </div>

      {/* Live Timer & Cycle Progress Counter */}
      <div className="flex items-center justify-center gap-4 text-xs font-semibold text-stone-600 dark:text-stone-400 mb-6">
        <span className="px-3 py-1 rounded-full bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700">
          Remaining: <strong className="text-amber-800 dark:text-amber-300 font-mono">{formatMinSec(totalSecondsRemaining)}</strong>
        </span>
        <span className="px-3 py-1 rounded-full bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700">
          Cycle: <strong className="text-amber-800 dark:text-amber-300">Breath {cycleCount + 1}</strong>
        </span>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={toggleActive}
          className="flex items-center gap-2 px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:via-orange-500 hover:to-amber-600 text-white font-semibold text-sm shadow-md shadow-amber-600/25 transition active:scale-[0.98]"
        >
          {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
          <span>{isActive ? 'Pause Meditation' : `Begin ${totalDurationOption / 60}-Minute Meditation`}</span>
        </button>
        <button
          onClick={reset}
          title="Reset timer"
          className="p-3 rounded-2xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   Exercise 2: Control vs Outcome (3-Column Organizer)
---------------------------------------------------- */
function ControlVsOutcomeExercise() {
  const [situation, setSituation] = useState('');
  const [newItemText, setNewItemText] = useState('');
  const [targetColumn, setTargetColumn] = useState<'control' | 'influence' | 'no-control'>('control');

  const [controlItems, setControlItems] = useState<string[]>([
    'How thoroughly I prepare my notes',
    'My tone and listening posture',
  ]);
  const [influenceItems, setInfluenceItems] = useState<string[]>([
    'Timeline of team responses',
  ]);
  const [noControlItems, setNoControlItems] = useState<string[]>([
    'What other people think or assume',
    'Market changes or company policy',
  ]);

  const addItem = () => {
    if (!newItemText.trim()) return;
    if (targetColumn === 'control') setControlItems([...controlItems, newItemText.trim()]);
    if (targetColumn === 'influence') setInfluenceItems([...influenceItems, newItemText.trim()]);
    if (targetColumn === 'no-control') setNoControlItems([...noControlItems, newItemText.trim()]);
    setNewItemText('');
  };

  const removeItem = (col: 'control' | 'influence' | 'no-control', idx: number) => {
    if (col === 'control') setControlItems(controlItems.filter((_, i) => i !== idx));
    if (col === 'influence') setInfluenceItems(influenceItems.filter((_, i) => i !== idx));
    if (col === 'no-control') setNoControlItems(noControlItems.filter((_, i) => i !== idx));
  };

  return (
    <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 border border-stone-200/80 dark:border-stone-800 zen-glow space-y-5">
      <div>
        <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif mb-1">
          Control vs Outcome
        </h2>
        <p className="text-xs text-stone-500 dark:text-stone-400">
          Rooted in Bhagavad Gita 2.47: Separate your direct sphere of effort from external outcomes.
        </p>
      </div>

      {/* Input row */}
      <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-950/40 border border-stone-100 dark:border-stone-800 flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={newItemText}
          onChange={(e) => setNewItemText(e.target.value)}
          placeholder="Add an element of your situation..."
          className="flex-1 px-3 py-2 text-xs bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200 focus:outline-hidden"
          onKeyDown={(e) => e.key === 'Enter' && addItem()}
        />
        <select
          value={targetColumn}
          onChange={(e) => setTargetColumn(e.target.value as any)}
          className="text-xs bg-white dark:bg-stone-900 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300"
        >
          <option value="control">What I Control</option>
          <option value="influence">What I Can Influence</option>
          <option value="no-control">What I Cannot Control</option>
        </select>
        <button
          onClick={addItem}
          className="px-3 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold flex items-center justify-center gap-1 transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add</span>
        </button>
      </div>

      {/* 3 Columns Display */}
      <div className="grid sm:grid-cols-3 gap-3">
        {/* Column 1: I Control */}
        <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/40">
          <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300 mb-2 flex items-center justify-between">
            <span>What I Control</span>
            <span className="text-[10px] bg-emerald-200/80 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded-full">
              Focus Here
            </span>
          </div>
          <div className="space-y-1.5 min-h-[90px]">
            {controlItems.map((item, idx) => (
              <div
                key={idx}
                className="text-xs bg-white/90 dark:bg-stone-900 p-2 rounded-xl border border-emerald-100 dark:border-emerald-950/60 text-stone-800 dark:text-stone-200 flex justify-between items-center group"
              >
                <span>{item}</span>
                <button
                  onClick={() => removeItem('control', idx)}
                  className="text-stone-400 hover:text-stone-600 opacity-60 group-hover:opacity-100"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Column 2: I Can Influence */}
        <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40">
          <div className="text-xs font-bold text-amber-900 dark:text-amber-300 mb-2 flex items-center justify-between">
            <span>I Can Influence</span>
            <span className="text-[10px] bg-amber-200/80 dark:bg-amber-900/60 px-1.5 py-0.5 rounded-full">
              Guide Gently
            </span>
          </div>
          <div className="space-y-1.5 min-h-[90px]">
            {influenceItems.map((item, idx) => (
              <div
                key={idx}
                className="text-xs bg-white/90 dark:bg-stone-900 p-2 rounded-xl border border-amber-100 dark:border-amber-950/60 text-stone-800 dark:text-stone-200 flex justify-between items-center group"
              >
                <span>{item}</span>
                <button
                  onClick={() => removeItem('influence', idx)}
                  className="text-stone-400 hover:text-stone-600 opacity-60 group-hover:opacity-100"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Column 3: I Cannot Control */}
        <div className="p-4 rounded-2xl bg-stone-100/70 dark:bg-stone-800/40 border border-stone-200 dark:border-stone-700">
          <div className="text-xs font-bold text-stone-700 dark:text-stone-300 mb-2 flex items-center justify-between">
            <span>I Cannot Control</span>
            <span className="text-[10px] bg-stone-200 dark:bg-stone-700 px-1.5 py-0.5 rounded-full">
              Release
            </span>
          </div>
          <div className="space-y-1.5 min-h-[90px]">
            {noControlItems.map((item, idx) => (
              <div
                key={idx}
                className="text-xs bg-white/90 dark:bg-stone-900 p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-400 flex justify-between items-center group"
              >
                <span>{item}</span>
                <button
                  onClick={() => removeItem('no-control', idx)}
                  className="text-stone-400 hover:text-stone-600 opacity-60 group-hover:opacity-100"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-3 bg-amber-50/60 dark:bg-stone-800/50 rounded-xl text-xs text-stone-600 dark:text-stone-300 leading-relaxed text-center">
        💡 <strong>Key Takeaway:</strong> Invest 90% of your energy on the green column. Let the gray column unfold as it will.
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   Exercise 3: One Action (10-Minute Focus Step)
---------------------------------------------------- */
function OneActionExercise() {
  const [task, setTask] = useState('');
  const [timeLeft, setTimeLeft] = useState(600); // 10 mins
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRunning, timeLeft]);

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;

  return (
    <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 sm:p-8 border border-stone-200/80 dark:border-stone-800 text-center zen-glow space-y-4">
      <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif mb-1">
        One Action Focus
      </h2>
      <p className="text-xs text-stone-500 dark:text-stone-400 max-w-md mx-auto">
        “What is the smallest useful action you can take in the next 10 minutes?”
      </p>

      <div className="max-w-md mx-auto">
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="E.g., Outline the first 3 bullet points of the report..."
          className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-xs sm:text-sm text-stone-800 dark:text-stone-200 text-center focus:outline-hidden"
        />
      </div>

      <div className="text-4xl sm:text-5xl font-mono font-bold text-amber-900 dark:text-amber-300 py-4">
        {mins.toString().padStart(2, '0')}:{secs.toString().padStart(2, '0')}
      </div>

      <div className="flex items-center justify-center gap-3">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs sm:text-sm shadow-xs transition"
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isRunning ? 'Pause' : 'Start 10-Min Sprint'}</span>
        </button>
        <button
          onClick={() => {
            setIsRunning(false);
            setTimeLeft(600);
          }}
          className="p-2.5 rounded-2xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   Exercise 4: Anger Pause (4 Stages)
---------------------------------------------------- */
function AngerPauseExercise() {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'Stage 1: Pause',
      instruction: 'Freeze your hands. Do not hit send. Do not utter the retort on the tip of your tongue. Take a step away from the device or person.',
      timeAdvice: 'Freeze immediately',
    },
    {
      title: 'Stage 2: Notice',
      instruction: 'Scan your physical sensations. Notice where anger is gathering: tight jaw, clenched fists, heat in the face, or tight breath.',
      timeAdvice: 'Observe without judgment',
    },
    {
      title: 'Stage 3: Delay Reaction',
      instruction: 'Remind yourself of Gita 2.63: anger obscures memory and intellect. Institute a 5-minute cooling rule before communicating.',
      timeAdvice: '5-minute delay rule',
    },
    {
      title: 'Stage 4: Choose Response',
      instruction: 'Ask yourself: "What response reflects who I wish to be tomorrow, rather than who my injured pride wants to punish right now?"',
      timeAdvice: 'Speak from clarity, not heat',
    },
  ];

  return (
    <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 sm:p-8 border border-stone-200/80 dark:border-stone-800 zen-glow space-y-6">
      <div>
        <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif mb-1">
          Anger Pause
        </h2>
        <p className="text-xs text-stone-500 dark:text-stone-400">
          Four-stage conscious interrupter to prevent clouded intellect and regretful reactions.
        </p>
      </div>

      {/* Stepper display */}
      <div className="grid grid-cols-4 gap-1.5 mb-2">
        {steps.map((s, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentStep(idx)}
            className={`h-2 rounded-full transition-all ${
              idx === currentStep
                ? 'bg-amber-600 dark:bg-amber-400'
                : idx < currentStep
                ? 'bg-amber-300 dark:bg-amber-800'
                : 'bg-stone-200 dark:bg-stone-800'
            }`}
          />
        ))}
      </div>

      {/* Active Stage Card */}
      <div className="p-6 rounded-2xl bg-amber-50/60 dark:bg-stone-950/40 border border-amber-200/60 dark:border-stone-800 text-center">
        <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 block mb-1">
          {steps[currentStep].timeAdvice}
        </span>
        <h3 className="text-xl font-bold text-stone-900 dark:text-stone-100 mb-3 font-serif">
          {steps[currentStep].title}
        </h3>
        <p className="text-sm text-stone-700 dark:text-stone-300 leading-relaxed max-w-lg mx-auto">
          {steps[currentStep].instruction}
        </p>
      </div>

      <div className="flex justify-between items-center pt-2">
        <button
          onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
          disabled={currentStep === 0}
          className="text-xs text-stone-500 dark:text-stone-400 disabled:opacity-30"
        >
          Previous Stage
        </button>
        <button
          onClick={() => setCurrentStep((prev) => Math.min(steps.length - 1, prev + 1))}
          disabled={currentStep === steps.length - 1}
          className="px-4 py-2 rounded-xl bg-stone-900 dark:bg-amber-600 text-white text-xs font-semibold disabled:opacity-40"
        >
          Next Stage
        </button>
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   Exercise 5: Thought Reset (3 Questions)
---------------------------------------------------- */
function ThoughtResetExercise() {
  const [q1, setQ1] = useState('');
  const [q2, setQ2] = useState('');
  const [q3, setQ3] = useState('');

  return (
    <div className="bg-white/90 dark:bg-stone-900/90 rounded-3xl p-6 sm:p-8 border border-stone-200/80 dark:border-stone-800 zen-glow space-y-6">
      <div>
        <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif mb-1">
          Thought Reset
        </h2>
        <p className="text-xs text-stone-500 dark:text-stone-400">
          Differentiate verifiable objective reality from catastrophic stories spun by an overstimulated mind.
        </p>
      </div>

      <div className="space-y-4">
        {/* Question 1 */}
        <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-950/40 border border-stone-100 dark:border-stone-800">
          <label className="block text-xs font-bold text-stone-800 dark:text-stone-200 mb-1.5">
            1. What fact do I know for certain right now?
          </label>
          <input
            type="text"
            value={q1}
            onChange={(e) => setQ1(e.target.value)}
            placeholder="Only concrete facts (e.g., 'I have an email to answer', not 'They hate me')"
            className="w-full text-xs p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 focus:outline-hidden"
          />
        </div>

        {/* Question 2 */}
        <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-950/40 border border-stone-100 dark:border-stone-800">
          <label className="block text-xs font-bold text-stone-800 dark:text-stone-200 mb-1.5">
            2. What am I assuming or predicting?
          </label>
          <input
            type="text"
            value={q2}
            onChange={(e) => setQ2(e.target.value)}
            placeholder="Identify the unverified worry (e.g., 'I am assuming they will reject my pitch')"
            className="w-full text-xs p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 focus:outline-hidden"
          />
        </div>

        {/* Question 3 */}
        <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40">
          <label className="block text-xs font-bold text-amber-900 dark:text-amber-300 mb-1.5">
            3. What action is actually required of me today?
          </label>
          <input
            type="text"
            value={q3}
            onChange={(e) => setQ3(e.target.value)}
            placeholder="Your immediate duty today (e.g., 'Draft a calm, clear reply')"
            className="w-full text-xs p-2.5 rounded-xl border border-amber-300 dark:border-amber-700 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 focus:outline-hidden"
          />
        </div>
      </div>

      <div className="text-center">
        <p className="text-xs text-stone-500 dark:text-stone-400 italic font-serif">
          “When you strip away imagination, reality is almost always manageable.”
        </p>
      </div>
    </div>
  );
}
