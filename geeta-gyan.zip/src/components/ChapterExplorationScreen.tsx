import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  BookOpen,
  Search,
  Volume2,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  Bookmark,
  CheckCircle2,
  Circle,
  Share2,
  Filter,
  ArrowRight,
  Heart,
  Globe,
  ListFilter,
  Check,
  Smartphone,
  Eye,
  ChevronDown,
  ChevronUp,
  Square,
} from 'lucide-react';
import { GITA_CHAPTERS } from '../data/chapters';
import { GitaChapter, ChapterKeyVerse, UserPreferences, FullGitaVerse, ReadingProgress } from '../types';
import {
  meditationAudio,
  AudioPlaybackState,
} from '../services/meditationAudio';
import { getFullVersesByChapter, CHAPTER_VERSE_COUNTS, TOTAL_GITA_VERSES } from '../services/fullGitaService';
import {
  getReadingProgress,
  recordVerseRead,
  toggleVerseRead,
  getNextVerseToRead,
  getChapterReadStats,
  getOverallReadStats,
  subscribeToReadingProgress,
  markChapterAllVersesRead,
} from '../services/readingProgressService';
import { StatusImageGeneratorModal, StatusVerseData } from './StatusImageGeneratorModal';
import { KrishnaUpadeshArt } from './KrishnaUpadeshArt';

interface ChapterExplorationScreenProps {
  preferences: UserPreferences;
  onShowToast: (msg: string) => void;
  onNavigateToHome?: () => void;
  initialChapterNumber?: number;
  initialVerseNumber?: number;
}

const STORAGE_SAVED_CHAPTERS_KEY = 'geeta_gyan_saved_chapters';

export const ChapterExplorationScreen: React.FC<ChapterExplorationScreenProps> = ({
  preferences,
  onShowToast,
  onNavigateToHome,
  initialChapterNumber,
  initialVerseNumber,
}) => {
  const isHi = preferences.language === 'hi';
  const spokenVoiceLang = preferences.spokenLanguage || 'hi';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<'All' | 'Karma' | 'Bhakti' | 'Jnana'>('All');
  const [activeChapter, setActiveChapter] = useState<GitaChapter | null>(null);

  // Active view tab inside chapter modal: 'all-verses' (default) or 'essence'
  const [activeTab, setActiveTab] = useState<'all-verses' | 'essence'>('all-verses');
  const [verseSearchQuery, setVerseSearchQuery] = useState('');
  const [expandedWordMeanings, setExpandedWordMeanings] = useState<Record<string, boolean>>({});

  // Reading progress state
  const [readingProgress, setReadingProgress] = useState<ReadingProgress>(getReadingProgress);

  // Status Generator Modal State
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [statusModalVerse, setStatusModalVerse] = useState<StatusVerseData | null>(null);

  // Bookmarking in localStorage
  const [savedChapters, setSavedChapters] = useState<number[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_SAVED_CHAPTERS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Audio Playback State from meditationAudio
  const [audioState, setAudioState] = useState<AudioPlaybackState>(meditationAudio.getPlaybackState());

  useEffect(() => {
    const unsub = meditationAudio.subscribe((st) => {
      setAudioState(st);
    });
    return unsub;
  }, []);

  // Subscribe to reading progress updates
  useEffect(() => {
    const unsubscribe = subscribeToReadingProgress((newProgress) => {
      setReadingProgress(newProgress);
    });
    return unsubscribe;
  }, []);

  // Set initial chapter and scroll to verse if provided
  useEffect(() => {
    if (initialChapterNumber && initialChapterNumber >= 1 && initialChapterNumber <= 18) {
      const ch = GITA_CHAPTERS.find((c) => c.chapterNumber === initialChapterNumber);
      if (ch) {
        setActiveChapter(ch);
        setActiveTab('all-verses');

        if (initialVerseNumber) {
          setTimeout(() => {
            const el = document.getElementById(`verse-card-${initialChapterNumber}-${initialVerseNumber}`);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              // Highlight flash
              el.classList.add('ring-2', 'ring-amber-500', 'bg-amber-50/70', 'dark:bg-amber-950/40');
              setTimeout(() => {
                el.classList.remove('ring-2', 'ring-amber-500', 'bg-amber-50/70', 'dark:bg-amber-950/40');
              }, 2500);
            }
          }, 350);
        }
      }
    }
  }, [initialChapterNumber, initialVerseNumber]);

  // Clean up audio on unmount or when changing chapter
  useEffect(() => {
    return () => {
      meditationAudio.stopSpeaking();
    };
  }, [activeChapter?.chapterNumber]);

  // Toggle bookmark
  const toggleSaveChapter = (chNum: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSavedChapters((prev) => {
      const next = prev.includes(chNum) ? prev.filter((n) => n !== chNum) : [...prev, chNum];
      try {
        localStorage.setItem(STORAGE_SAVED_CHAPTERS_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      onShowToast(
        next.includes(chNum)
          ? isHi
            ? `अध्याय ${chNum} सहेजा गया!`
            : `Chapter ${chNum} saved to bookmarks!`
          : isHi
          ? `अध्याय ${chNum} हटाया गया।`
          : `Chapter ${chNum} removed from bookmarks.`
      );
      return next;
    });
  };

  // Toggle verse read status
  const handleToggleVerseRead = (chapter: number, verse: number) => {
    const { isNowRead } = toggleVerseRead(chapter, verse);
    onShowToast(
      isNowRead
        ? isHi
          ? `श्लोक ${chapter}.${verse} पढ़ा हुआ चिह्नित किया गया!`
          : `Verse ${chapter}.${verse} marked as read!`
        : isHi
          ? `श्लोक ${chapter}.${verse} अपठित किया गया।`
          : `Verse ${chapter}.${verse} marked unread.`
    );
  };

  // Mark verse read and advance to next verse
  const handleMarkAndAdvance = (chapter: number, verse: number, totalVersesInChapter: number) => {
    recordVerseRead(chapter, verse, true);
    if (verse < totalVersesInChapter) {
      const nextVerseNum = verse + 1;
      const nextEl = document.getElementById(`verse-card-${chapter}-${nextVerseNum}`);
      if (nextEl) {
        nextEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      onShowToast(isHi ? `श्लोक ${chapter}.${nextVerseNum} पर आगे बढ़ें` : `Moving to Verse ${chapter}.${nextVerseNum}`);
    } else if (chapter < 18) {
      onShowToast(
        isHi
          ? `बधाई! अध्याय ${chapter} पूर्ण हुआ। अध्याय ${chapter + 1} प्रारंभ करें!`
          : `Congratulations! Chapter ${chapter} completed. Starting Chapter ${chapter + 1}!`
      );
      const nextCh = GITA_CHAPTERS.find((c) => c.chapterNumber === chapter + 1);
      if (nextCh) {
        setActiveChapter(nextCh);
      }
    }
  };

  // Mark all verses in active chapter as read
  const handleMarkChapterCompleted = (chapter: number) => {
    markChapterAllVersesRead(chapter);
    onShowToast(
      isHi
        ? `अध्याय ${chapter} के सभी श्लोक पूर्ण चिह्नित किए गए!`
        : `All verses in Chapter ${chapter} marked as completed!`
    );
  };

  // Resume reading from next unread verse
  const handleResumeReading = () => {
    const next = getNextVerseToRead(readingProgress);
    const targetCh = GITA_CHAPTERS.find((c) => c.chapterNumber === next.chapter);
    if (targetCh) {
      setActiveChapter(targetCh);
      setActiveTab('all-verses');
      setTimeout(() => {
        const el = document.getElementById(`verse-card-${next.chapter}-${next.verse}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          el.classList.add('ring-2', 'ring-amber-500', 'bg-amber-50/70', 'dark:bg-amber-950/40');
          setTimeout(() => {
            el.classList.remove('ring-2', 'ring-amber-500', 'bg-amber-50/70', 'dark:bg-amber-950/40');
          }, 2500);
        }
      }, 350);
      onShowToast(
        isHi
          ? `स्वाध्याय जारी रखें: अध्याय ${next.chapter}, श्लोक ${next.verse}`
          : `Resuming: Chapter ${next.chapter}, Verse ${next.verse}`
      );
    }
  };

  // Open Status Image Generator Modal
  const handleOpenStatusGenerator = (verse: FullGitaVerse) => {
    setStatusModalVerse({
      chapter: verse.chapter,
      verse: verse.verse,
      sanskrit: verse.sanskrit,
      transliteration: verse.transliteration,
      hindi: verse.hindi,
      english: verse.english,
      positiveMessage: isHi
        ? `अध्याय ${verse.chapter}, श्लोक ${verse.verse}: अपने कर्तव्य पर स्थिर रहें, फल की चिंता से मुक्त होकर शांति से कर्म करें।`
        : `Chapter ${verse.chapter}, Verse ${verse.verse}: Dedicate yourself fully to sincere action, and let your inner spirit rest in peace.`,
    });
    setStatusModalOpen(true);
  };

  // Filter chapters based on search query & group tab
  const filteredChapters = useMemo(() => {
    return GITA_CHAPTERS.filter((ch) => {
      // Group filter
      if (selectedGroup === 'Karma' && !ch.sectionGroup.startsWith('Karma')) return false;
      if (selectedGroup === 'Bhakti' && !ch.sectionGroup.startsWith('Bhakti')) return false;
      if (selectedGroup === 'Jnana' && !ch.sectionGroup.startsWith('Jnana')) return false;

      // Search query filter
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      const matchNum = ch.chapterNumber.toString().includes(q);
      const matchSanskrit = ch.sanskritName.toLowerCase().includes(q);
      const matchTitleEn = ch.englishTitle.toLowerCase().includes(q);
      const matchTitleHi = ch.hindiTitle.toLowerCase().includes(q);
      const matchSummary = ch.summaryEn.toLowerCase().includes(q) || ch.summaryHi.toLowerCase().includes(q);
      const matchThemes =
        ch.keyThemes.some((t) => t.toLowerCase().includes(q)) ||
        ch.keyThemesHi.some((t) => t.toLowerCase().includes(q));

      return matchNum || matchSanskrit || matchTitleEn || matchTitleHi || matchSummary || matchThemes;
    });
  }, [searchQuery, selectedGroup]);

  // Full verses of the currently active chapter
  const currentChapterFullVerses = useMemo(() => {
    if (!activeChapter) return [];
    return getFullVersesByChapter(activeChapter.chapterNumber);
  }, [activeChapter]);

  // Filtered verses inside the active chapter
  const filteredChapterVerses = useMemo(() => {
    if (!verseSearchQuery.trim()) return currentChapterFullVerses;
    const q = verseSearchQuery.trim().toLowerCase();
    return currentChapterFullVerses.filter((v) => {
      return (
        v.verse.toString() === q ||
        v.id.includes(q) ||
        v.sanskrit.toLowerCase().includes(q) ||
        v.hindi.toLowerCase().includes(q) ||
        v.english.toLowerCase().includes(q) ||
        v.transliteration.toLowerCase().includes(q)
      );
    });
  }, [currentChapterFullVerses, verseSearchQuery]);

  // Overall read statistics
  const overallStats = useMemo(() => {
    return getOverallReadStats(readingProgress);
  }, [readingProgress]);

  // Next verse to read
  const nextVerseToRead = useMemo(() => {
    return getNextVerseToRead(readingProgress);
  }, [readingProgress]);

  // Audio: Recite Chapter Summary in Soothing Guru Voice
  const handleReciteChapterSummary = (chapter: GitaChapter) => {
    if (audioState.isPlaying) {
      meditationAudio.pauseSpeaking();
      return;
    }

    if (audioState.isPaused) {
      meditationAudio.resumeSpeaking();
      return;
    }

    meditationAudio.playSingingBowl(216, 2.5);

    const textToSpeak =
      spokenVoiceLang === 'hi'
        ? `श्रीमद्भगवद्गीता, अध्याय ${chapter.chapterNumber}, ${chapter.sanskritName}। ${chapter.hindiTitle}।\n\nअध्याय का सार: ${chapter.summaryHi}\n\nदैनिक जीवन में इसकी प्रासंगिकता: ${chapter.relevanceHi}`
        : `Bhagavad Gita, Chapter ${chapter.chapterNumber}, ${chapter.sanskritName}. ${chapter.englishTitle}.\n\nChapter essence: ${chapter.summaryEn}\n\nRelevance for daily life: ${chapter.relevanceEn}`;

    meditationAudio.speakSceneDialogue({
      text: textToSpeak,
      lang: spokenVoiceLang,
      rate: 0.82,
    });

    onShowToast(isHi ? 'अध्याय का सार सुनाया जा रहा है...' : 'Playing chapter overview narration...');
  };

  // Audio: Recite a specific full verse in Sanskrit + Hindi with Guru style
  const handleReciteFullVerse = (verse: FullGitaVerse) => {
    // Also mark as current read location
    recordVerseRead(verse.chapter, verse.verse, false);

    meditationAudio.reciteBhagavadGitaVerse({
      chapter: verse.chapter,
      verseNumber: verse.verse,
      sanskrit: verse.sanskrit,
      translationHindi: verse.hindi,
      motivatingTakeaway: verse.english ? `Takeaway: ${verse.english.slice(0, 140)}` : '',
      lang: spokenVoiceLang,
      rate: 0.80,
    });

    onShowToast(
      isHi
        ? `श्लोक ${verse.chapter}.${verse.verse} का सस्वर पाठ...`
        : `Reciting Verse ${verse.chapter}.${verse.verse}...`
    );
  };

  const handleStopAudio = () => {
    meditationAudio.stopSpeaking();
  };

  // Next / Previous Chapter navigation
  const navigateChapter = (offset: -1 | 1) => {
    if (!activeChapter) return;
    const curIdx = GITA_CHAPTERS.findIndex((c) => c.chapterNumber === activeChapter.chapterNumber);
    const nextIdx = Math.max(0, Math.min(GITA_CHAPTERS.length - 1, curIdx + offset));
    handleStopAudio();
    setActiveChapter(GITA_CHAPTERS[nextIdx]);
    setVerseSearchQuery('');
  };

  // Active chapter reading stats
  const activeChapterStats = useMemo(() => {
    if (!activeChapter) return { readCount: 0, totalCount: 0, percent: 0, isCompleted: false };
    return getChapterReadStats(activeChapter.chapterNumber, readingProgress);
  }, [activeChapter, readingProgress]);

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 md:py-10 animate-fadeIn space-y-6 pb-28">
      {/* Hero Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100/80 dark:bg-amber-950/60 border border-amber-300/80 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-semibold shadow-xs">
          <BookOpen className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>{isHi ? 'संपूर्ण गीता स्वाध्याय • १८ अध्याय एवं ७०१ श्लोक' : 'Complete Bhagavad Gita • 18 Chapters & 701 Verses'}</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-stone-900 dark:text-stone-100 font-serif tracking-tight">
          {isHi ? 'श्रीमद्भगवद्गीता के १८ अध्याय' : 'The 18 Chapters of Bhagavad Gita'}
        </h1>

        <p className="text-sm sm:text-base text-stone-600 dark:text-stone-300 max-w-2xl mx-auto font-light leading-relaxed">
          {isHi
            ? 'गीता के संपूर्ण ७०१ श्लोक संस्कृत, हिंदी और अंग्रेजी अनुवाद सहित। जहाँ पिछली बार पढ़ना छोड़ा था, वहीं से अगले श्लोक पर निरंतर स्वाध्याय जारी रखें।'
            : 'Explore all 701 verses with Sanskrit, Hindi, and English translations. Track your reading progress and seamlessly resume where you left off.'}
        </p>
      </div>

      {/* READING PROGRESS & RESUME SWADHYAYA BANNER */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/15 border-2 border-amber-400/60 dark:border-amber-700/60 p-5 sm:p-6 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-300">
                {isHi ? 'गीता स्वाध्याय प्रगति (Reading Progress)' : 'Your Gita Reading Journey'}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold font-serif text-stone-900 dark:text-stone-100 mt-1">
              {isHi
                ? `${overallStats.totalRead} / ${overallStats.totalVerses} श्लोक पढ़े गए (${overallStats.percent}% पूर्ण)`
                : `${overallStats.totalRead} of ${overallStats.totalVerses} Verses Completed (${overallStats.percent}%)`}
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400">
              {isHi
                ? `अंतिम पढ़ा गया श्लोक: अध्याय ${readingProgress.lastReadChapter}, श्लोक ${readingProgress.lastReadVerse} • अगला श्लोक: अध्याय ${nextVerseToRead.chapter}, श्लोक ${nextVerseToRead.verse}`
                : `Last read: Chapter ${readingProgress.lastReadChapter}, Verse ${readingProgress.lastReadVerse} • Up next: Chapter ${nextVerseToRead.chapter}, Verse ${nextVerseToRead.verse}`}
            </p>
          </div>

          <button
            onClick={handleResumeReading}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-amber-600/30 active:scale-95 transition cursor-pointer self-start sm:self-center"
          >
            <span>
              {isHi
                ? `अगले श्लोक (${nextVerseToRead.chapter}.${nextVerseToRead.verse}) से पढ़ें`
                : `Resume from Verse ${nextVerseToRead.chapter}.${nextVerseToRead.verse}`}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Full Gita Overall Progress Bar */}
        <div className="space-y-1.5">
          <div className="w-full h-3 rounded-full bg-stone-200/80 dark:bg-stone-800 overflow-hidden p-0.5 border border-amber-300/40 dark:border-amber-900/40">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-700 ease-out"
              style={{ width: `${Math.max(2, overallStats.percent)}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 font-mono">
            <span>{isHi ? 'अध्याय १.१ (आरंभ)' : 'Ch 1.1 (Start)'}</span>
            <span>{overallStats.completedChaptersCount} / 18 {isHi ? 'अध्याय पूर्ण' : 'Chapters Done'}</span>
            <span>{isHi ? 'अध्याय १८.७८ (मोक्ष)' : 'Ch 18.78 (Liberation)'}</span>
          </div>
        </div>
      </div>

      {/* Search & Yoga Section Filters */}
      <div className="space-y-3">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isHi
                ? 'अध्याय, नाम, विषय या संख्या खोजें (उदा: 2, कर्मयोग, ध्यान, आत्मा, शांति)...'
                : 'Search chapters by name, number, or theme (e.g. 2, Karma, Knowledge, Soul, Equanimity)...'
            }
            className="w-full pl-11 pr-10 py-3 rounded-2xl border border-stone-200 dark:border-stone-800 bg-white/90 dark:bg-stone-900/90 text-stone-900 dark:text-stone-100 placeholder-stone-400 text-xs sm:text-sm focus:outline-hidden focus:border-amber-500/70 focus:ring-2 focus:ring-amber-500/20 shadow-xs transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* 3 Yoga Divisions Tabs */}
        <div className="flex flex-wrap gap-2 pt-1">
          {[
            { id: 'All', labelEn: 'All 18 Chapters', labelHi: 'सभी १८ अध्याय' },
            { id: 'Karma', labelEn: 'Karma Yoga (Ch 1-6)', labelHi: 'कर्मयोग (अध्याय १-६)' },
            { id: 'Bhakti', labelEn: 'Bhakti Yoga (Ch 7-12)', labelHi: 'भक्तियोग (अध्याय ७-१२)' },
            { id: 'Jnana', labelEn: 'Jnana Yoga (Ch 13-18)', labelHi: 'ज्ञानयोग (अध्याय १३-१८)' },
          ].map((tab) => {
            const isSelected = selectedGroup === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedGroup(tab.id as any)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition active:scale-95 cursor-pointer shadow-xs ${
                  isSelected
                    ? 'bg-amber-600 text-white shadow-amber-600/30'
                    : 'bg-white/80 dark:bg-stone-900/80 border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                {isHi ? tab.labelHi : tab.labelEn}
              </button>
            );
          })}
        </div>
      </div>

      {/* CHAPTER CARDS GRID (18 Chapters) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredChapters.map((ch) => {
          const isSaved = savedChapters.includes(ch.chapterNumber);
          const chStats = getChapterReadStats(ch.chapterNumber, readingProgress);
          const isCompleted = chStats.isCompleted;

          return (
            <div
              key={ch.chapterNumber}
              onClick={() => {
                handleStopAudio();
                setActiveChapter(ch);
                setActiveTab('all-verses');
              }}
              className="group relative bg-white/90 dark:bg-stone-900/90 rounded-3xl p-5 border border-stone-200/80 dark:border-stone-800 hover:border-amber-400 dark:hover:border-amber-600/70 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              {/* Top metadata row */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 text-white font-bold text-xs flex items-center justify-center shadow-xs font-mono">
                      {ch.chapterNumber}
                    </span>
                    <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-400 uppercase tracking-wider">
                      {ch.sectionGroup.split(' ')[0]} Yoga
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Read indicator */}
                    <div
                      title={isCompleted ? 'Chapter Completed' : `${chStats.readCount}/${chStats.totalCount} read`}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-medium transition ${
                        isCompleted
                          ? 'text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/40 font-bold'
                          : chStats.readCount > 0
                          ? 'text-amber-700 dark:text-amber-400 bg-amber-100/70 dark:bg-amber-950/40'
                          : 'text-stone-400 bg-stone-100 dark:bg-stone-800'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Circle className="w-3 h-3" />}
                      <span>{chStats.percent}%</span>
                    </div>

                    {/* Bookmark indicator */}
                    <button
                      onClick={(e) => toggleSaveChapter(ch.chapterNumber, e)}
                      title={isSaved ? 'Remove bookmark' : 'Bookmark this chapter'}
                      className={`p-1.5 rounded-lg transition ${
                        isSaved
                          ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40'
                          : 'text-stone-300 dark:text-stone-600 hover:text-stone-500'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Sanskrit & Hindi/English Name */}
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 font-serif leading-snug group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                  {ch.sanskritName}
                </h3>
                <p className="text-xs font-medium text-stone-600 dark:text-stone-300 mt-0.5 line-clamp-1">
                  {isHi ? ch.hindiTitle : ch.englishTitle}
                </p>

                {/* Short Essence snippet */}
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 line-clamp-2 leading-relaxed font-light">
                  {isHi ? ch.summaryHi : ch.summaryEn}
                </p>

                {/* Mini Progress Bar */}
                <div className="mt-3 w-full h-1.5 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isCompleted ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${chStats.percent}%` }}
                  />
                </div>
              </div>

              {/* Bottom metadata tags */}
              <div className="pt-3 border-t border-stone-100 dark:border-stone-800/80 mt-3 flex items-center justify-between text-[11px]">
                <span className="text-stone-400 dark:text-stone-500 font-mono">
                  {ch.verseCount} {isHi ? 'श्लोक (संपूर्ण)' : 'Verses (Full)'}
                </span>

                <div className="flex items-center gap-1 font-semibold text-amber-700 dark:text-amber-400 group-hover:translate-x-1 transition-transform">
                  <span>{isHi ? 'श्लोक पढ़ें' : 'Read Verses'}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredChapters.length === 0 && (
        <div className="text-center py-16 bg-white/60 dark:bg-stone-900/60 rounded-3xl border border-stone-200 dark:border-stone-800 p-8 space-y-3">
          <BookOpen className="w-10 h-10 text-stone-400 mx-auto" />
          <h3 className="text-base font-bold text-stone-700 dark:text-stone-200">
            {isHi ? 'कोई अध्याय नहीं मिला' : 'No matching chapters found'}
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {isHi
              ? 'कृपया दूसरा शब्द या संख्या खोजें (उदा: कर्म, ध्यान, ज्ञान, 2, 6, 18)'
              : 'Try searching with a different term like "Karma", "Meditation", "Duty", or chapter number (e.g. 2, 6, 18).'}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedGroup('All');
            }}
            className="px-4 py-2 rounded-xl bg-amber-600 text-white text-xs font-semibold shadow-xs"
          >
            {isHi ? 'सभी १८ अध्याय दिखाएं' : 'Reset Filters & Show All'}
          </button>
        </div>
      )}

      {/* FULL CHAPTER DETAIL MODAL / DRAWER */}
      {activeChapter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-2 sm:p-5 overflow-y-auto">
          <div className="relative w-full max-w-4xl max-h-[94vh] overflow-y-auto bg-[#FDFBF7] dark:bg-[#120e0a] rounded-3xl border border-amber-300/60 dark:border-amber-900/50 shadow-2xl p-4 sm:p-8 space-y-6">
            {/* Top Close & Navigation Bar */}
            <div className="flex items-center justify-between gap-2 border-b border-stone-200 dark:border-stone-800 pb-4">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => navigateChapter(-1)}
                  disabled={activeChapter.chapterNumber <= 1}
                  className="p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900 disabled:opacity-30 disabled:cursor-not-allowed transition"
                  title="Previous chapter"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => navigateChapter(1)}
                  disabled={activeChapter.chapterNumber >= 18}
                  className="p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900 disabled:opacity-30 disabled:cursor-not-allowed transition"
                  title="Next chapter"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-400 ml-1">
                  {isHi ? `अध्याय ${activeChapter.chapterNumber} / १८` : `Chapter ${activeChapter.chapterNumber} of 18`}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleMarkChapterCompleted(activeChapter.chapterNumber)}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs font-medium hover:bg-emerald-100 transition"
                  title="Mark all verses in chapter read"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isHi ? 'अध्याय पूर्ण चिह्नित करें' : 'Mark Chapter Done'}</span>
                </button>

                <button
                  onClick={(e) => toggleSaveChapter(activeChapter.chapterNumber, e)}
                  className={`p-2 rounded-xl border transition ${
                    savedChapters.includes(activeChapter.chapterNumber)
                      ? 'border-amber-400 bg-amber-100 dark:bg-amber-950 text-amber-600'
                      : 'border-stone-200 dark:border-stone-800 text-stone-400 hover:text-stone-600'
                  }`}
                  title="Bookmark"
                >
                  <Bookmark className={`w-4 h-4 ${savedChapters.includes(activeChapter.chapterNumber) ? 'fill-current' : ''}`} />
                </button>

                <button
                  onClick={() => {
                    handleStopAudio();
                    setActiveChapter(null);
                  }}
                  className="p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Chapter Header Titles */}
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400">
                <span>{activeChapter.sectionGroup}</span>
                <span>•</span>
                <span>
                  {activeChapter.verseCount} {isHi ? 'श्लोक (संपूर्ण)' : 'Verses'}
                </span>
                <span>•</span>
                <span className="text-emerald-600 dark:text-emerald-400">
                  {activeChapterStats.readCount}/{activeChapterStats.totalCount} {isHi ? 'पढ़े गए' : 'read'}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 dark:text-stone-100 font-serif">
                {activeChapter.sanskritName}
              </h2>
              <p className="text-sm sm:text-base font-semibold text-amber-700 dark:text-amber-400">
                {isHi ? activeChapter.hindiTitle : activeChapter.englishTitle}
              </p>
            </div>

            {/* Dedicated Audio Narration Bar for Chapter with Indian Guru Voice Selector */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/15 border border-amber-300/80 dark:border-amber-800 space-y-3 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 transition-all ${
                      audioState.isPlaying
                        ? 'bg-amber-600 text-white shadow-md shadow-amber-500/25 ring-2 ring-amber-400/40 animate-pulse'
                        : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                    }`}
                  >
                    <Volume2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900 dark:text-stone-100 font-serif">
                      {audioState.isPlaying
                        ? isHi
                          ? 'अध्याय का संपूर्ण सार सुनाया जा रहा है...'
                          : 'Reciting Chapter Overview in Soothing Hindi Voice...'
                        : audioState.isPaused
                        ? isHi
                          ? 'वाचन रुका हुआ है (Paused)'
                          : 'Recitation Paused'
                        : isHi
                        ? 'अध्याय का सार एवं मुख्य श्लोक सुनें'
                        : 'Listen to Chapter Essence & Verses in Hindi'}
                    </h4>
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      {isHi
                        ? 'तिब्बती सिंगिंग बाउल ध्वनि और शांत स्वर में'
                        : 'Singing bowl resonance + authentic contemplative cadence'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleReciteChapterSummary(activeChapter)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold shadow-xs transition active:scale-95 cursor-pointer"
                  >
                    {audioState.isPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>{isHi ? 'रोकें' : 'Pause'}</span>
                      </>
                    ) : audioState.isPaused ? (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{isHi ? 'पुनः सुनें' : 'Resume'}</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{isHi ? 'सार सुनें' : 'Listen Essence'}</span>
                      </>
                    )}
                  </button>

                  {(audioState.isPlaying || audioState.isPaused) && (
                    <button
                      onClick={handleStopAudio}
                      className="p-1.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 text-xs hover:bg-stone-100 transition cursor-pointer"
                      title="Stop Audio"
                    >
                      <Square className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* TAB SELECTOR: All Verses (Full Gita) vs Essence & Key Insights */}
            <div className="flex border-b border-stone-200 dark:border-stone-800">
              <button
                type="button"
                onClick={() => setActiveTab('all-verses')}
                className={`flex-1 py-3 text-xs sm:text-sm font-bold border-b-2 text-center transition flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'all-verses'
                    ? 'border-amber-600 text-amber-700 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/20'
                    : 'border-transparent text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>
                  {isHi
                    ? `संपूर्ण श्लोक (${currentChapterFullVerses.length} श्लोक)`
                    : `All Verses (${currentChapterFullVerses.length} Verses)`}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('essence')}
                className={`flex-1 py-3 text-xs sm:text-sm font-bold border-b-2 text-center transition flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'essence'
                    ? 'border-amber-600 text-amber-700 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/20'
                    : 'border-transparent text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>{isHi ? 'अध्याय का सार एवं मुख्य शिक्षाएं' : 'Chapter Essence & Insights'}</span>
              </button>
            </div>

            {/* TAB 1: ALL VERSES OF FULL GITA */}
            {activeTab === 'all-verses' && (
              <div className="space-y-4">
                {/* Search & Quick Jump Verse Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                    <input
                      type="text"
                      value={verseSearchQuery}
                      onChange={(e) => setVerseSearchQuery(e.target.value)}
                      placeholder={
                        isHi
                          ? `इस अध्याय में श्लोक संख्या या शब्द खोजें (१-${currentChapterFullVerses.length})...`
                          : `Filter verses by number (1-${currentChapterFullVerses.length}) or words...`
                      }
                      className="w-full pl-9 pr-8 py-2 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-xs text-stone-900 dark:text-stone-100 focus:outline-hidden focus:border-amber-400"
                    />
                    {verseSearchQuery && (
                      <button
                        onClick={() => setVerseSearchQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Quick Jump Buttons (1 to N) */}
                  <div className="flex items-center gap-1.5 overflow-x-auto py-1 max-w-full text-xs text-stone-500">
                    <span className="shrink-0 text-[11px] font-bold text-stone-400">
                      {isHi ? 'श्लोक पर जाएं:' : 'Jump to:'}
                    </span>
                    {[1, 10, 20, 30, 40, 50, 60, 70]
                      .filter((n) => n <= currentChapterFullVerses.length)
                      .map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => {
                            const el = document.getElementById(`verse-card-${activeChapter.chapterNumber}-${num}`);
                            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                          }}
                          className="px-2 py-0.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-amber-100 dark:hover:bg-amber-950 text-stone-700 dark:text-stone-300 font-mono text-[11px]"
                        >
                          {num}
                        </button>
                      ))}
                  </div>
                </div>

                {/* Verses List */}
                <div className="space-y-4">
                  {filteredChapterVerses.map((verse) => {
                    const isThisActive = audioState.currentVerseId === `${verse.chapter}.${verse.verse}`;
                    const isRead = readingProgress.readVerseIds.includes(`${verse.chapter}.${verse.verse}`);
                    const isLastRead =
                      readingProgress.lastReadChapter === verse.chapter &&
                      readingProgress.lastReadVerse === verse.verse;
                    const showWordMeanings = expandedWordMeanings[`${verse.chapter}.${verse.verse}`];

                    return (
                      <div
                        key={verse.verse}
                        id={`verse-card-${verse.chapter}-${verse.verse}`}
                        className={`p-4 sm:p-5 rounded-2xl bg-white dark:bg-stone-900 border transition-all space-y-3.5 shadow-xs ${
                          isLastRead
                            ? 'border-amber-500 ring-2 ring-amber-400/40'
                            : isRead
                            ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/20 dark:bg-emerald-950/10'
                            : 'border-amber-200/60 dark:border-stone-800'
                        }`}
                      >
                        {/* Verse Card Header */}
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-mono font-bold text-xs">
                              BG {verse.chapter}.{verse.verse}
                            </span>

                            {isLastRead && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-500 text-white font-bold text-[10px] uppercase tracking-wider animate-pulse">
                                {isHi ? 'अंतिम पढ़ा गया' : 'Last Read'}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            {/* Read / Unread Toggle */}
                            <button
                              type="button"
                              onClick={() => handleToggleVerseRead(verse.chapter, verse.verse)}
                              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-medium transition cursor-pointer ${
                                isRead
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:bg-stone-200'
                              }`}
                            >
                              <CheckCircle2 className={`w-3.5 h-3.5 ${isRead ? 'text-emerald-600 fill-current' : ''}`} />
                              <span>{isRead ? (isHi ? 'पढ़ा हुआ' : 'Read') : isHi ? 'पढ़ा हुआ चिह्नित करें' : 'Mark Read'}</span>
                            </button>

                            {/* Listen Button with Play, Pause & Stop */}
                            {(() => {
                              const isThisActive = audioState.currentVerseId === `${verse.chapter}.${verse.verse}`;
                              const isThisPlaying = isThisActive && audioState.isPlaying;
                              const isThisPaused = isThisActive && audioState.isPaused;

                              if (isThisPlaying) {
                                return (
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => meditationAudio.pauseSpeaking()}
                                      className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-600 text-white shadow-xs animate-pulse cursor-pointer"
                                      title={isHi ? 'विराम (Pause)' : 'Pause recitation'}
                                    >
                                      <Pause className="w-3.5 h-3.5" />
                                      <span>{isHi ? 'विराम' : 'Pause'}</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => meditationAudio.stopSpeaking()}
                                      className="p-1 rounded-xl bg-stone-900 border border-stone-700 text-stone-300 hover:text-white cursor-pointer"
                                      title={isHi ? 'रोकें (Stop)' : 'Stop recitation'}
                                    >
                                      <Square className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                );
                              }

                              if (isThisPaused) {
                                return (
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => meditationAudio.resumeSpeaking()}
                                      className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-600 text-white shadow-xs cursor-pointer"
                                      title={isHi ? 'पुनः सुनें (Resume)' : 'Resume recitation'}
                                    >
                                      <Play className="w-3.5 h-3.5 fill-current" />
                                      <span>{isHi ? 'पुनः सुनें' : 'Resume'}</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => meditationAudio.stopSpeaking()}
                                      className="p-1 rounded-xl bg-stone-900 border border-stone-700 text-stone-300 hover:text-white cursor-pointer"
                                      title={isHi ? 'रोकें (Stop)' : 'Stop recitation'}
                                    >
                                      <Square className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                );
                              }

                              return (
                                <button
                                  type="button"
                                  onClick={() => handleReciteFullVerse(verse)}
                                  className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-medium transition cursor-pointer shadow-xs bg-amber-50 dark:bg-stone-800 text-amber-900 dark:text-amber-200 border border-amber-200 dark:border-stone-700 hover:bg-amber-100"
                                >
                                  <Volume2 className="w-3.5 h-3.5" />
                                  <span>{isHi ? 'सुनें' : 'Listen'}</span>
                                </button>
                              );
                            })()}

                            {/* CREATE STATUS IMAGE BUTTON */}
                            <button
                              type="button"
                              onClick={() => handleOpenStatusGenerator(verse)}
                              className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer"
                              title="Create WhatsApp / Instagram Status Image"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>{isHi ? 'स्टेटस बनाएं' : 'Status Image'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Sanskrit Calligraphy Box */}
                        <div className="p-3.5 rounded-xl bg-amber-50/60 dark:bg-stone-950/60 border border-amber-200/70 dark:border-stone-800 text-center space-y-1.5">
                          <p className="font-serif text-base sm:text-lg font-bold text-amber-950 dark:text-amber-100 whitespace-pre-line leading-relaxed">
                            {verse.sanskrit}
                          </p>
                          {verse.transliteration && (
                            <p className="text-xs text-stone-500 dark:text-stone-400 font-serif italic whitespace-pre-line">
                              {verse.transliteration}
                            </p>
                          )}
                        </div>

                        {/* Word Meanings (Expandable) */}
                        {verse.wordMeanings && (
                          <div>
                            <button
                              type="button"
                              onClick={() => {
                                const key = `${verse.chapter}.${verse.verse}`;
                                setExpandedWordMeanings((prev) => ({ ...prev, [key]: !prev[key] }));
                              }}
                              className="flex items-center gap-1 text-[11px] font-semibold text-amber-700 dark:text-amber-400 hover:underline cursor-pointer"
                            >
                              <span>{isHi ? 'शब्दार्थ (Word Meanings)' : 'Word Meanings'}</span>
                              {showWordMeanings ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                            {showWordMeanings && (
                              <div className="mt-1.5 p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950/50 border border-stone-200 dark:border-stone-800 text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed font-mono">
                                {verse.wordMeanings}
                              </div>
                            )}
                          </div>
                        )}

                        {/* Hindi Meaning */}
                        <div>
                          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-0.5">
                            हिंदी अनुवाद:
                          </div>
                          <p className="text-xs sm:text-sm text-stone-800 dark:text-stone-200 leading-relaxed font-serif">
                            {verse.hindi}
                          </p>
                        </div>

                        {/* English Meaning */}
                        {verse.english && (
                          <div>
                            <div className="text-[10px] font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 mb-0.5">
                              English Meaning:
                            </div>
                            <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
                              {verse.english}
                            </p>
                          </div>
                        )}

                        {/* Quick Action: Mark as read and jump to next verse */}
                        <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100 dark:border-stone-800/80">
                          <button
                            type="button"
                            onClick={() => handleMarkAndAdvance(verse.chapter, verse.verse, currentChapterFullVerses.length)}
                            className="flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300 font-semibold cursor-pointer"
                          >
                            <span>{isHi ? 'पढ़ा हुआ चिह्नित कर अगले श्लोक पर जाएं' : 'Mark as Read & Next Verse'}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: CHAPTER ESSENCE & KEY INSIGHTS */}
            {activeTab === 'essence' && (
              <div className="space-y-6">
                {/* Chapter Essence / Overview */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400">
                    {isHi ? 'अध्याय का मूल सार (Essence)' : 'Chapter Essence & Summary'}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 leading-relaxed font-light">
                    {isHi ? activeChapter.summaryHi : activeChapter.summaryEn}
                  </p>
                </div>

                {/* Modern Relevance & Everyday Stress Takeaway */}
                <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200/80 dark:border-stone-800 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-400 uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>
                      {isHi
                        ? 'आज के तनाव और जीवन में इसका महत्व'
                        : 'Relevance for Everyday Stress & Mindfulness'}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                    {isHi ? activeChapter.relevanceHi : activeChapter.relevanceEn}
                  </p>
                </div>

                {/* Key Themes Chips */}
                <div>
                  <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mb-2">
                    {isHi ? 'प्रमुख विषय (Themes):' : 'Key Core Themes:'}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(isHi ? activeChapter.keyThemesHi : activeChapter.keyThemes).map((theme, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/60 text-amber-900 dark:text-amber-300 text-xs font-medium"
                      >
                        #{theme}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Key Verses of this Chapter */}
                <div className="space-y-4 pt-2">
                  <div className="flex flex-col items-center justify-center my-2">
                    <KrishnaUpadeshArt size="sm" showBanner={true} language={isHi ? 'hi' : 'en'} />
                  </div>

                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-serif">
                      {isHi ? 'इस अध्याय के मुख्य चयनित श्लोक' : 'Signature Verses of this Chapter'}
                    </h3>
                  </div>

                  <div className="space-y-4">
                    {activeChapter.keyVerses.map((verse) => (
                      <div
                        key={verse.verseNumber}
                        className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-stone-900 border border-amber-200/60 dark:border-stone-800 shadow-xs space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-mono font-bold text-xs">
                            BG {activeChapter.chapterNumber}.{verse.verseNumber}
                          </span>

                          <button
                            onClick={() => {
                              const fullV = currentChapterFullVerses.find((v) => v.verse === verse.verseNumber);
                              if (fullV) handleOpenStatusGenerator(fullV);
                            }}
                            className="flex items-center gap-1 px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>{isHi ? 'स्टेटस बनाएं' : 'Status Image'}</span>
                          </button>
                        </div>

                        <div className="p-3 rounded-xl bg-amber-50/50 dark:bg-stone-950/50 border border-amber-100 dark:border-stone-800/80 text-center">
                          <p className="font-serif text-sm sm:text-base font-bold text-amber-950 dark:text-amber-100 whitespace-pre-line leading-relaxed">
                            {verse.sanskrit}
                          </p>
                          <p className="text-[11px] text-stone-500 dark:text-stone-400 font-serif italic mt-1.5">
                            {verse.transliteration}
                          </p>
                        </div>

                        <div>
                          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-0.5">
                            हिंदी अनुवाद:
                          </div>
                          <p className="text-xs sm:text-sm text-stone-800 dark:text-stone-200 leading-relaxed font-serif">
                            {verse.translationHindi}
                          </p>
                        </div>

                        <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/50 dark:border-amber-900/40 text-xs text-amber-950 dark:text-amber-200">
                          <strong>{isHi ? 'जीवन सूत्र: ' : 'Takeaway: '}</strong>
                          {isHi ? verse.significanceHi : verse.significanceEn}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Modal Actions */}
            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigateChapter(-1)}
                  disabled={activeChapter.chapterNumber <= 1}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold hover:bg-stone-100 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>{isHi ? 'पिछला अध्याय' : 'Previous'}</span>
                </button>
                <button
                  onClick={() => navigateChapter(1)}
                  disabled={activeChapter.chapterNumber >= 18}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold hover:bg-stone-100 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                >
                  <span>{isHi ? 'अगला अध्याय' : 'Next Chapter'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <button
                onClick={() => {
                  handleStopAudio();
                  setActiveChapter(null);
                }}
                className="w-full sm:w-auto px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs transition cursor-pointer"
              >
                {isHi ? 'वापस सूची पर जाएं' : 'Back to Chapter Grid'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WHATSAPP & INSTAGRAM STATUS GENERATOR MODAL */}
      {statusModalOpen && statusModalVerse && (
        <StatusImageGeneratorModal
          isOpen={statusModalOpen}
          onClose={() => setStatusModalOpen(false)}
          verseData={statusModalVerse}
          language={preferences.language}
          onShowToast={onShowToast}
        />
      )}
    </div>
  );
};
