import React, { useState } from 'react';
import { PhoneCall, HeartHandshake, ShieldAlert, ArrowLeft, MessageSquare, ExternalLink } from 'lucide-react';
import { VERIFIED_CRISIS_RESOURCES } from '../services/safetyService';

interface SafetyScreenProps {
  onBackToSafety: () => void;
}

export const SafetyScreen: React.FC<SafetyScreenProps> = ({ onBackToSafety }) => {
  const [selectedCountry, setSelectedCountry] = useState<'India' | 'United States & Canada' | 'United Kingdom' | 'International'>('India');

  const filteredResources = VERIFIED_CRISIS_RESOURCES.filter(
    (r) => r.country.includes(selectedCountry) || (selectedCountry === 'International' && r.country === 'International')
  );

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-amber-50/90 dark:bg-stone-900 border border-amber-200/80 dark:border-amber-900/50 shadow-sm mb-6">
        <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-400 flex items-center justify-center mb-4">
          <HeartHandshake className="w-6 h-6" />
        </div>
        <h1 className="text-2xl font-bold text-stone-900 dark:text-stone-100 mb-2">
          You deserve immediate human support.
        </h1>
        <p className="text-stone-700 dark:text-stone-300 text-sm leading-relaxed mb-4">
          What you described sounds very heavy and may require care beyond what a self-reflection app can safely provide.
          Please reach out to someone you trust, a healthcare professional, or a free crisis service. You do not have to carry this alone.
        </p>

        {/* Quick Direct Actions */}
        <div className="grid sm:grid-cols-2 gap-3 pt-2">
          <a
            href="tel:"
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-stone-900 dark:bg-amber-500 text-white dark:text-stone-950 text-sm font-semibold hover:bg-stone-800 dark:hover:bg-amber-400 transition shadow-xs"
          >
            <PhoneCall className="w-4 h-4" />
            <span>Contact Someone I Trust</span>
          </a>

          <a
            href="#hotlines"
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-800 dark:text-stone-200 text-sm font-semibold hover:bg-white dark:hover:bg-stone-800 transition"
          >
            <ShieldAlert className="w-4 h-4 text-amber-700 dark:text-amber-400" />
            <span>View Verified Helplines</span>
          </a>
        </div>
      </div>

      {/* Verified Helplines Section */}
      <div id="hotlines" className="p-6 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100">
            Free & Confidential Crisis Support
          </h2>
          <span className="text-xs text-stone-500 dark:text-stone-400">Verified official lines</span>
        </div>

        {/* Country Selector Tabs */}
        <div className="flex gap-1.5 p-1 bg-stone-100 dark:bg-stone-800/80 rounded-xl mb-4 overflow-x-auto">
          {(['India', 'United States & Canada', 'United Kingdom', 'International'] as const).map((country) => (
            <button
              key={country}
              onClick={() => setSelectedCountry(country)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                selectedCountry === country
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs font-semibold'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              {country}
            </button>
          ))}
        </div>

        {/* Helpline Cards */}
        <div className="space-y-3">
          {filteredResources.map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl border border-stone-100 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-950/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="font-semibold text-stone-900 dark:text-stone-100 text-sm">
                  {item.serviceName}
                </div>
                <div className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                  {item.description}
                </div>
                <div className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 mt-1">
                  {item.available}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {item.isTel ? (
                  <a
                    href={`tel:${item.contact.replace(/\s+/g, '')}`}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs transition"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call {item.contact}</span>
                  </a>
                ) : (
                  <a
                    href={item.contact.startsWith('http') ? item.contact : `https://${item.contact}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 text-xs font-medium hover:bg-stone-200 dark:hover:bg-stone-800 transition"
                  >
                    <span>{item.contact}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gentle Spiritual Reflection Anchor (As permitted by prompt) */}
      <div className="p-6 rounded-3xl bg-[#F6F1EA] dark:bg-stone-900/60 border border-amber-200/50 dark:border-stone-800/80 mb-6">
        <p className="text-xs uppercase tracking-wider text-amber-800 dark:text-amber-400 font-semibold mb-2">
          A Gentle Reminder
        </p>
        <p className="text-sm italic text-stone-700 dark:text-stone-300 leading-relaxed mb-2 font-serif">
          “In the fiercest thunderstorm, your sacred duty is not to fight the wind alone, but to protect your breath and reach toward a steady, caring hand.”
        </p>
        <p className="text-xs text-stone-500 dark:text-stone-400">
          This reflection is offered for comfort and does not replace human care. Please connect with someone today.
        </p>
      </div>

      {/* Return Option */}
      <div className="text-center">
        <button
          onClick={onBackToSafety}
          className="inline-flex items-center gap-2 text-xs font-medium text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200 py-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>I would like to return to the main app</span>
        </button>
      </div>
    </div>
  );
};
