import React from 'react';
import {
  BarChart3,
  TrendingDown,
  Compass,
  BookOpen,
  Calendar,
  Sparkles,
  Award,
  Layers,
  ArrowRight,
  Info,
} from 'lucide-react';
import { calculateJourneyStats, getJournalEntries } from '../services/storageService';

export const MyJourneyScreen: React.FC = () => {
  const stats = calculateJourneyStats();
  const entries = getJournalEntries();

  // Compute 5 most recent before/after pairs for the trend visualizer
  const recentEntries = [...entries].reverse().slice(0, 5);

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100/70 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 text-xs font-semibold mb-2">
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Self-Reflection Patterns</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif">
          My Journey
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-1">
          Gentle, non-clinical observations from your practice and stress check-ins.
        </p>
      </div>

      {/* Compassionate Summary Card */}
      <div className="bg-gradient-to-br from-[#FBF8F2] via-white to-amber-50/60 dark:from-stone-900 dark:via-stone-900 dark:to-stone-950 rounded-3xl p-6 shadow-xs border border-amber-200/80 dark:border-stone-800 zen-glow">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Practice Observation</span>
        </div>
        <p className="text-base sm:text-lg font-serif italic text-stone-800 dark:text-stone-200 leading-relaxed mb-4">
          “{stats.summaryMessage}”
        </p>
        <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400">
          <Info className="w-3.5 h-3.5 shrink-0" />
          <span>
            These trends reflect your own subjective check-in ratings before and after applying practical Gita principles.
          </span>
        </div>
      </div>

      {/* Key Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Metric 1 */}
        <div className="p-4 rounded-2xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 block mb-1">
            Check-ins Completed
          </span>
          <div className="text-2xl font-bold text-stone-900 dark:text-stone-100 font-serif">
            {stats.totalCheckins}
          </div>
          <span className="text-[10px] text-amber-700 dark:text-amber-400 mt-0.5 block">
            Intentional pauses
          </span>
        </div>

        {/* Metric 2 */}
        <div className="p-4 rounded-2xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 block mb-1">
            Journal Reflections
          </span>
          <div className="text-2xl font-bold text-stone-900 dark:text-stone-100 font-serif">
            {stats.journalEntriesCount}
          </div>
          <span className="text-[10px] text-stone-400 mt-0.5 block">
            Saved reflections
          </span>
        </div>

        {/* Metric 3 */}
        <div className="p-4 rounded-2xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 block mb-1">
            Avg Stress Before
          </span>
          <div className="text-2xl font-bold text-stone-800 dark:text-stone-200 font-serif">
            {stats.avgStressBefore !== null ? `${stats.avgStressBefore} / 5` : '—'}
          </div>
          <span className="text-[10px] text-stone-400 mt-0.5 block">
            Initial check-in
          </span>
        </div>

        {/* Metric 4 */}
        <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/40 shadow-xs">
          <span className="text-[11px] font-semibold text-emerald-900 dark:text-emerald-300 block mb-1">
            Avg Stress After
          </span>
          <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-400 font-serif">
            {stats.avgStressAfter !== null ? `${stats.avgStressAfter} / 5` : '—'}
          </div>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-500 mt-0.5 block flex items-center gap-0.5">
            <TrendingDown className="w-3 h-3" />
            <span>Post reflection</span>
          </span>
        </div>
      </div>

      {/* Principle & Category Highlights */}
      <div className="grid sm:grid-cols-2 gap-3.5">
        <div className="p-5 rounded-3xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1.5">
            <Layers className="w-3.5 h-3.5" />
            <span>Most Common Stress Category</span>
          </div>
          <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif">
            {stats.mostCommonCategory}
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            The recurring friction pattern you have brought to reflection most frequently.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-1.5">
            <Compass className="w-3.5 h-3.5" />
            <span>Most Frequently Used Principle</span>
          </div>
          <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 font-serif">
            {stats.mostCommonPrinciple}
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            The philosophical anchor that has repeatedly guided your practical actions.
          </p>
        </div>
      </div>

      {/* Simple Clean Stress Shift Trend Visualization */}
      <div className="p-6 rounded-3xl bg-white/90 dark:bg-stone-900/90 border border-stone-200/80 dark:border-stone-800 shadow-xs">
        <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 font-serif mb-1">
          Recent Reflection Shifts
        </h3>
        <p className="text-xs text-stone-500 dark:text-stone-400 mb-6">
          Comparing self-reported intensity before applying the Gita teaching (Amber) vs after taking action (Green).
        </p>

        {recentEntries.length === 0 ? (
          <div className="text-center py-6 text-xs text-stone-400">
            No reflections recorded yet. Complete a check-in to see your shift timeline.
          </div>
        ) : (
          <div className="space-y-4">
            {recentEntries.map((e, idx) => (
              <div key={e.id || idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-stone-800 dark:text-stone-200 truncate max-w-[200px]">
                    {e.stressCategory}
                  </span>
                  <span className="text-stone-400">
                    {e.stressBefore}/5 → {e.stressAfter !== undefined ? `${e.stressAfter}/5` : '—'}
                  </span>
                </div>

                {/* Comparative bar */}
                <div className="h-3 w-full bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden flex">
                  {/* Before bar */}
                  <div
                    style={{ width: `${(e.stressBefore / 5) * 50}%` }}
                    className="h-full bg-amber-500/80 rounded-l-full"
                    title={`Before: ${e.stressBefore}/5`}
                  />
                  {/* After bar */}
                  {e.stressAfter !== undefined && (
                    <div
                      style={{ width: `${(e.stressAfter / 5) * 50}%` }}
                      className="h-full bg-emerald-500/80 rounded-r-full"
                      title={`After: ${e.stressAfter}/5`}
                    />
                  )}
                </div>
              </div>
            ))}

            <div className="flex items-center justify-center gap-6 pt-3 text-[11px] text-stone-500">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                <span>Stress Before Reflection</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                <span>Stress After Taking Action</span>
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
