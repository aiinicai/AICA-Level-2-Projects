import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Square,
  Volume2,
} from 'lucide-react';
import {
  meditationAudio,
  AudioPlaybackState,
} from '../services/meditationAudio';

interface GuruAudioPlayerBarProps {
  language?: 'en' | 'hi';
}

export const GuruAudioPlayerBar: React.FC<GuruAudioPlayerBarProps> = ({ language = 'en' }) => {
  const isHi = language === 'hi';
  const [audioState, setAudioState] = useState<AudioPlaybackState>(meditationAudio.getPlaybackState());

  useEffect(() => {
    const unsubscribe = meditationAudio.subscribe((state) => {
      setAudioState(state);
    });
    return unsubscribe;
  }, []);

  if (!audioState.isPlaying && !audioState.isPaused) {
    return null;
  }

  return (
    <div className="fixed bottom-16 md:bottom-4 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-lg animate-fadeIn">
      {/* Clean Sticky Bottom Audio Player Bar - No extra popups or option drawers */}
      <div className="relative rounded-2xl bg-gradient-to-r from-[#1c120a]/95 via-[#26180c]/95 to-[#1c120a]/95 border-2 border-amber-500/70 p-3 sm:p-3.5 shadow-2xl backdrop-blur-md text-stone-100 flex items-center justify-between gap-3">
        {/* Left: Avatar & Playing Info */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-lg shadow-md">
              🌸
            </div>
            {audioState.isPlaying && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-stone-900 animate-pulse" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-amber-200 font-serif truncate">
                {audioState.currentTitle || (isHi ? 'गीता श्लोक पाठ' : 'Gita Shloka Recitation')}
              </span>
            </div>
            <p className="text-[11px] text-stone-400 truncate">
              {audioState.isPaused
                ? isHi
                  ? '⏸ वाचन रुका हुआ है (Paused)'
                  : '⏸ Recitation Paused'
                : isHi
                ? '▶ शांत ध्यान मुद्रा में श्रवण करें...'
                : '▶ Listening in peaceful meditative stillness...'}
            </p>
          </div>
        </div>

        {/* Right: Audio Play/Pause and Stop Controls */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Pause / Resume Button */}
          <button
            type="button"
            onClick={() => meditationAudio.togglePlayPause()}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-md shadow-amber-600/30 active:scale-95 transition cursor-pointer"
            title={audioState.isPaused ? (isHi ? 'पुनः सुनें' : 'Resume') : isHi ? 'विराम' : 'Pause'}
          >
            {audioState.isPaused ? (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isHi ? 'पुनः सुनें' : 'Resume'}</span>
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>{isHi ? 'विराम' : 'Pause'}</span>
              </>
            )}
          </button>

          {/* Stop Button */}
          <button
            type="button"
            onClick={() => meditationAudio.stopSpeaking()}
            className="p-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-300 hover:text-white hover:bg-stone-800 transition cursor-pointer"
            title={isHi ? 'बंद करें (Stop)' : 'Stop Recitation'}
          >
            <Square className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
