import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Sparkles,
  Feather,
  Shield,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Music,
  Compass,
} from 'lucide-react';
import { GitaPrinciple, StressCategory, Verse } from '../types';
import { meditationAudio } from '../services/meditationAudio';
import {
  generateCinematicScript,
  DialogScene,
  SceneTheme,
} from '../services/cinematicScriptService';

interface MahabharatVideoProps {
  category: StressCategory;
  principle: GitaPrinciple;
  verseRef: string;
  chapter: number;
  verseNumber: number;
  userInput?: string;
  guidanceUnderstanding?: string;
  whatThisMeansForYou?: string;
  verse?: Verse;
  initialLang?: 'en' | 'hi';
  spokenLang?: 'hi' | 'en';
  onFinished?: () => void;
}

export const MahabharatVideo: React.FC<MahabharatVideoProps> = ({
  category,
  principle,
  verseRef,
  chapter,
  verseNumber,
  userInput = '',
  guidanceUnderstanding = '',
  whatThisMeansForYou = '',
  verse,
  initialLang = 'en',
  spokenLang = 'hi',
  onFinished,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [sceneProgress, setSceneProgress] = useState(0); // 0 to 1 for active scene
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [subtitleLang, setSubtitleLang] = useState<'en' | 'hi'>(initialLang || 'en');
  const [voiceLang, setVoiceLang] = useState<'hi' | 'en'>(spokenLang || 'hi');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // References to coordinate voice speech and natural sentence transitions
  const cancelSpeechRef = React.useRef<(() => void) | null>(null);
  const pauseTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
  const progressTimerRef = React.useRef<NodeJS.Timeout | null>(null);
  const isPlayingRef = React.useRef(isPlaying);
  isPlayingRef.current = isPlaying;
  const currentSceneIdxRef = React.useRef(currentSceneIdx);
  currentSceneIdxRef.current = currentSceneIdx;

  // Dynamically generate script scenes strictly tailored to the specific problem raised by the user
  const scriptPackage = React.useMemo(() => {
    return generateCinematicScript({
      category,
      principle,
      verseRef,
      chapter,
      verseNumber,
      userInput,
      guidanceUnderstanding,
      whatThisMeansForYou,
      verse,
    });
  }, [
    category,
    principle,
    verseRef,
    chapter,
    verseNumber,
    userInput,
    guidanceUnderstanding,
    whatThisMeansForYou,
    verse,
  ]);

  const scenes: DialogScene[] = scriptPackage.scenes;
  const currentTheme: SceneTheme = scriptPackage.theme;

  const themeVisuals: Record<
    SceneTheme,
    {
      bgClass: string;
      auraClass: string;
      rayStops: [string, string, string];
    }
  > = {
    'radiant-gold': {
      bgClass: 'bg-gradient-to-b from-[#2a1708] via-[#1a0e05] to-[#0a0502]',
      auraClass: 'from-amber-400/40 via-orange-500/25 to-transparent',
      rayStops: ['#fef08a', '#f59e0b', '#d97706'],
    },
    'calm-ocean': {
      bgClass: 'bg-gradient-to-b from-[#0a1526] via-[#060e1a] to-[#03060d]',
      auraClass: 'from-sky-400/35 via-indigo-500/20 to-transparent',
      rayStops: ['#bae6fd', '#38bdf8', '#0284c7'],
    },
    'cooling-twilight': {
      bgClass: 'bg-gradient-to-b from-[#201018] via-[#120a10] to-[#070407]',
      auraClass: 'from-rose-400/35 via-teal-500/20 to-transparent',
      rayStops: ['#fecdd3', '#2dd4bf', '#0f766e'],
    },
    'peaceful-green': {
      bgClass: 'bg-gradient-to-b from-[#081e14] via-[#05130d] to-[#020704]',
      auraClass: 'from-emerald-400/35 via-teal-500/20 to-transparent',
      rayStops: ['#a7f3d0', '#10b981', '#047857'],
    },
    'sacred-violet': {
      bgClass: 'bg-gradient-to-b from-[#1c0f2b] via-[#11081b] to-[#06030a]',
      auraClass: 'from-purple-400/35 via-amber-500/20 to-transparent',
      rayStops: ['#e9d5ff', '#a855f7', '#7e22ce'],
    },
    'grounded-amber': {
      bgClass: 'bg-gradient-to-b from-[#24140a] via-[#150a04] to-[#090401]',
      auraClass: 'from-amber-500/40 via-orange-600/25 to-transparent',
      rayStops: ['#fed7aa', '#f97316', '#c2410c'],
    },
  };

  const activeTheme = themeVisuals[currentTheme] || themeVisuals['radiant-gold'];

  // Clean up any ongoing speech, intervals, and timeouts
  const clearPlaybackTimers = () => {
    if (cancelSpeechRef.current) {
      cancelSpeechRef.current();
      cancelSpeechRef.current = null;
    }
    if (pauseTimeoutRef.current) {
      clearTimeout(pauseTimeoutRef.current);
      pauseTimeoutRef.current = null;
    }
    if (progressTimerRef.current) {
      clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
  };

  // Play a specific scene and wait until the complete sentence finishes before advancing
  const playScene = React.useCallback(
    (sceneIndex: number, currentVoice: 'hi' | 'en' = voiceLang) => {
      clearPlaybackTimers();
      setCurrentSceneIdx(sceneIndex);
      setSceneProgress(0);
      setIsSpeaking(true);

      const scene = scenes[sceneIndex];
      if (!scene) return;

      // Soft transition chime
      if (!isAudioMuted) {
        meditationAudio.playSingingBowl(scene.speaker === 'Lord Krishna' ? 288 : 216, 2.4);
      }

      const dialogToSpeak = currentVoice === 'hi' ? scene.textHi : scene.textEn;
      const wordCount = dialogToSpeak.trim().split(/\s+/).length;
      // Realistic duration estimate for progress bar animation
      const estimatedTotalSec = Math.max(6, wordCount * 0.42);

      const startTime = Date.now();
      progressTimerRef.current = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const p = Math.min(0.96, elapsed / estimatedTotalSec);
        setSceneProgress(p);
      }, 100);

      // Function called when the sentence is 100% finished
      const onSentenceComplete = () => {
        if (!isPlayingRef.current) return;
        if (progressTimerRef.current) {
          clearInterval(progressTimerRef.current);
          progressTimerRef.current = null;
        }
        setSceneProgress(1);
        setIsSpeaking(false);

        // Peaceful 1.2-second pause before moving to the next scene so listener can absorb the words
        pauseTimeoutRef.current = setTimeout(() => {
          if (!isPlayingRef.current) return;

          if (sceneIndex < scenes.length - 1) {
            playScene(sceneIndex + 1, currentVoice);
          } else {
            // Reached end of 4th chapter
            setIsPlaying(false);
            meditationAudio.stopAmbientHum();
            if (onFinished) onFinished();
          }
        }, 1200);
      };

      if (!isAudioMuted) {
        cancelSpeechRef.current = meditationAudio.speakSceneDialogue({
          text: dialogToSpeak,
          lang: currentVoice,
          rate: 0.80,
          onStart: () => setIsSpeaking(true),
          onEnd: onSentenceComplete,
        });
      } else {
        // Voice is muted: run comfortable readable reading timer (8 seconds)
        pauseTimeoutRef.current = setTimeout(() => {
          onSentenceComplete();
        }, Math.max(7000, estimatedTotalSec * 1000));
      }
    },
    [scenes, voiceLang, isAudioMuted, onFinished]
  );

  const togglePlay = () => {
    if (!isPlaying) {
      setIsPlaying(true);
      if (!isAudioMuted) {
        meditationAudio.startAmbientHum();
      }
      // If at end, start from scene 0; otherwise continue current scene from start of sentence
      const startIdx = currentSceneIdx === scenes.length - 1 && sceneProgress >= 1 ? 0 : currentSceneIdx;
      playScene(startIdx, voiceLang);
    } else {
      setIsPlaying(false);
      setIsSpeaking(false);
      clearPlaybackTimers();
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    }
  };

  const handleSelectScene = (idx: number) => {
    clearPlaybackTimers();
    setCurrentSceneIdx(idx);
    setSceneProgress(0);

    if (isPlaying) {
      playScene(idx, voiceLang);
    } else {
      setIsSpeaking(false);
    }
  };

  const handleSkip = (direction: -1 | 1) => {
    const nextIdx = Math.max(0, Math.min(scenes.length - 1, currentSceneIdx + direction));
    handleSelectScene(nextIdx);
  };

  const handleReset = () => {
    setIsPlaying(false);
    setIsSpeaking(false);
    clearPlaybackTimers();
    setCurrentSceneIdx(0);
    setSceneProgress(0);
    meditationAudio.stopAmbientHum();
    meditationAudio.stopSpeaking();
  };

  const toggleMute = () => {
    const next = !isAudioMuted;
    setIsAudioMuted(next);
    meditationAudio.setVoiceMuted(next);

    if (next) {
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    } else if (isPlaying) {
      meditationAudio.startAmbientHum();
      // Restart current sentence so it can be heard fully
      playScene(currentSceneIdx, voiceLang);
    }
  };

  const handleVoiceLangChange = (nextLang: 'hi' | 'en') => {
    setVoiceLang(nextLang);
    if (isPlaying) {
      // Re-speak the current sentence completely in the chosen language
      playScene(currentSceneIdx, nextLang);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearPlaybackTimers();
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    };
  }, []);

  const currentScene = scenes[currentSceneIdx] || scenes[0];

  return (
    <div
      className={`rounded-3xl overflow-hidden bg-gradient-to-b from-[#140e0a] via-[#0d0906] to-[#080503] border-2 border-amber-500/50 shadow-2xl text-stone-100 cinema-glow relative select-none transition-all ${
        isFullscreen ? 'fixed inset-4 z-50 rounded-3xl flex flex-col justify-between max-w-5xl mx-auto' : ''
      }`}
    >
      {/* Decorative Ornate Vedic Corner Flourishes */}
      <div className="absolute top-2.5 left-3 z-20 pointer-events-none text-amber-400/60 text-sm select-none">
        ✦
      </div>
      <div className="absolute top-2.5 right-3 z-20 pointer-events-none text-amber-400/60 text-sm select-none">
        ✦
      </div>
      <div className="absolute bottom-2.5 left-3 z-20 pointer-events-none text-amber-400/60 text-sm select-none">
        ✦
      </div>
      <div className="absolute bottom-2.5 right-3 z-20 pointer-events-none text-amber-400/60 text-sm select-none">
        ✦
      </div>

      {/* Visual Canvas Area with SVG Cinematic Animation (16:9 Widescreen) */}
      <div className={`relative aspect-video w-full overflow-hidden select-none transition-colors duration-1000 ${activeTheme.bgClass}`}>
        {/* Cinematic Vignette */}
        <div className="absolute inset-0 pointer-events-none z-1 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(8,5,3,0.85)_100%)]" />

        {/* Animated Kurukshetra Sky with Celestial Radiant Sun */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Luminous Solar Aura */}
          <div
            className={`absolute top-2 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-gradient-to-b ${activeTheme.auraClass} blur-3xl transition-all duration-1000 ${
              isPlaying ? 'scale-125 opacity-100' : 'scale-100 opacity-80'
            }`}
          />

          {/* Celestial God Rays */}
          <svg className="absolute inset-0 w-full h-full opacity-45" viewBox="0 0 800 450" preserveAspectRatio="none">
            <defs>
              <linearGradient id="rayGradGold" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={activeTheme.rayStops[0]} stopOpacity="0.85" />
                <stop offset="60%" stopColor={activeTheme.rayStops[1]} stopOpacity="0.35" />
                <stop offset="100%" stopColor={activeTheme.rayStops[2]} stopOpacity="0" />
              </linearGradient>
            </defs>
            <polygon points="400,20 120,450 240,450" fill="url(#rayGradGold)" opacity={isPlaying ? '0.75' : '0.45'} />
            <polygon points="400,20 300,450 420,450" fill="url(#rayGradGold)" opacity={isPlaying ? '0.85' : '0.55'} />
            <polygon points="400,20 480,450 600,450" fill="url(#rayGradGold)" opacity={isPlaying ? '0.9' : '0.55'} />
            <polygon points="400,20 640,450 760,450" fill="url(#rayGradGold)" opacity={isPlaying ? '0.65' : '0.35'} />
          </svg>
        </div>

        {/* Kurukshetra Battleground Chariot Scene (High-Fidelity Artistic Illustration) */}
        <div className="absolute inset-0 flex items-center justify-center p-2 sm:p-4">
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full max-h-[400px] drop-shadow-2xl transition-transform duration-1000"
            style={{
              transform: currentScene.cameraAngle === 'krishna'
                ? 'scale(1.08) translate(-14px, -5px)'
                : currentScene.cameraAngle === 'arjuna'
                ? 'scale(1.08) translate(14px, -5px)'
                : 'scale(1)',
            }}
          >
            <defs>
              <radialGradient id="sunCoreGold" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="35%" stopColor="#fef08a" />
                <stop offset="70%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#b45309" stopOpacity="0" />
              </radialGradient>
              <radialGradient id="haloShineDiv" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="55%" stopColor="#fef08a" stopOpacity="0.8" />
                <stop offset="85%" stopColor="#f59e0b" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#d97706" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="chariotGoldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fffbeb" />
                <stop offset="25%" stopColor="#fde047" />
                <stop offset="65%" stopColor="#d97706" />
                <stop offset="100%" stopColor="#451a03" />
              </linearGradient>
            </defs>

            {/* Distant Kurukshetra Terrain Layers */}
            <path d="M 0 355 Q 200 315 400 340 T 800 325 L 800 450 L 0 450 Z" fill="#25170f" opacity="0.95" />
            <path d="M 0 375 Q 250 350 550 370 T 800 365 L 800 450 L 0 450 Z" fill="#150e09" />

            {/* Golden Radiant Sun Disc */}
            <circle cx="400" cy="85" r="56" fill="url(#sunCoreGold)" />
            {/* Rotating Sun Chakra Ray Motif */}
            <g transform="translate(400, 85)">
              {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
                <line
                  key={deg}
                  x1="0"
                  y1="0"
                  x2={74 * Math.cos((deg * Math.PI) / 180)}
                  y2={74 * Math.sin((deg * Math.PI) / 180)}
                  stroke="#fde047"
                  strokeWidth="1.6"
                  strokeDasharray="2 3"
                  opacity="0.65"
                />
              ))}
            </g>

            {/* Sacred Chariot (Ratha / Nandighosha) */}
            <g transform="translate(180, 140)">
              {/* Flag / Kapi Dhwaja with Hanuman Emblem */}
              <line x1="280" y1="12" x2="280" y2="240" stroke="#92400e" strokeWidth="5" />
              <path d="M 280 16 Q 340 32 380 18 L 350 60 Q 315 70 280 54 Z" fill="#ea580c" opacity="0.95">
                {isPlaying && (
                  <animate
                    attributeName="d"
                    dur="2.4s"
                    repeatCount="indefinite"
                    values="M 280 16 Q 340 32 380 18 L 350 60 Q 315 70 280 54 Z; M 280 16 Q 340 12 380 24 L 350 64 Q 315 52 280 54 Z; M 280 16 Q 340 32 380 18 L 350 60 Q 315 70 280 54 Z"
                  />
                )}
              </path>
              {/* Golden Hanuman emblem atop flag */}
              <circle cx="280" cy="11" r="5.5" fill="#fef08a" stroke="#d97706" strokeWidth="1" />

              {/* Chariot Dome Canopy */}
              <path d="M 115 115 Q 220 35 325 115 L 310 170 L 130 170 Z" fill="url(#chariotGoldGrad)" opacity="0.95" />
              <circle cx="220" cy="60" r="12" fill="#fffbeb" stroke="#d97706" strokeWidth="2.5" />

              {/* Chariot Body with Golden Railing */}
              <path d="M 90 170 L 350 170 L 330 260 L 70 260 Z" fill="#2d1a0f" stroke="#b45309" strokeWidth="3.2" />
              <path d="M 110 186 Q 220 180 315 186" stroke="#fbbf24" strokeWidth="2.8" fill="none" />
              <path d="M 105 208 Q 220 202 320 208" stroke="#d97706" strokeWidth="2" fill="none" opacity="0.8" />

              {/* Four Noble White Horses Silhouettes (Front of Chariot) */}
              <g transform="translate(-65, 155)" opacity="0.9">
                {/* Horse Heads & Manes */}
                <path d="M 12 45 Q -25 35 -40 60 Q -50 85 -30 95 Q -10 95 20 85 Z" fill="#fffbeb" />
                <path d="M 28 35 Q -10 25 -25 50 Q -35 75 -15 85 Q 5 85 35 75 Z" fill="#fef08a" opacity="0.85" />
                {/* Golden reins connecting to Krishna's hands */}
                <line x1="145" y1="52" x2="-20" y2="72" stroke="#fef08a" strokeWidth="2" opacity="0.85" />
                <line x1="145" y1="57" x2="-35" y2="77" stroke="#fef08a" strokeWidth="2" opacity="0.85" />
              </g>

              {/* Grand Chariot Wheel (Chakra with dynamic rotation) */}
              <g transform="translate(180, 255)">
                {/* Rotating Spoke Wheel */}
                <g>
                  {isPlaying && (
                    <animateTransform
                      attributeName="transform"
                      type="rotate"
                      from="0"
                      to="360"
                      dur="8s"
                      repeatCount="indefinite"
                    />
                  )}
                  <circle cx="0" cy="0" r="50" fill="#180e07" stroke="#fbbf24" strokeWidth="5.5" />
                  <circle cx="0" cy="0" r="16" fill="#d97706" stroke="#fffbeb" strokeWidth="2.5" />
                  {/* 12 Auspicious Spokes */}
                  {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
                    <line
                      key={deg}
                      x1="0"
                      y1="0"
                      x2={46 * Math.cos((deg * Math.PI) / 180)}
                      y2={46 * Math.sin((deg * Math.PI) / 180)}
                      stroke="#d97706"
                      strokeWidth="3"
                    />
                  ))}
                </g>
              </g>
            </g>

            {/* Lord Krishna (Divine Charioteer / Parthasarathy) */}
            <g
              transform="translate(240, 200)"
              className={`transition-opacity duration-700 ${
                currentScene.speaker === 'Lord Krishna' ? 'opacity-100' : 'opacity-90'
              }`}
            >
              {/* Radiating Divine Halo (Prabhamandala) */}
              <circle cx="50" cy="45" r="48" fill="url(#haloShineDiv)">
                {isPlaying && (
                  <animate attributeName="r" dur="3.2s" values="46;52;46" repeatCount="indefinite" />
                )}
              </circle>
              {/* Crown / Peacock Feather (Mayur Pankh) with glowing eye */}
              <ellipse cx="50" cy="14" rx="9" ry="18" fill="#0d9488" stroke="#fbbf24" strokeWidth="2" />
              <circle cx="50" cy="12" r="4" fill="#38bdf8" />
              <circle cx="50" cy="12" r="1.8" fill="#1e1b4b" />
              <path d="M 40 32 Q 50 18 60 32 Z" fill="#d97706" />

              {/* Krishna's Divine Form: Azure/Cyan Radiance */}
              <circle cx="50" cy="45" r="15" fill="#38bdf8" stroke="#0284c7" strokeWidth="1" />
              {/* Pitambara Silk (Yellow Robe) */}
              <path d="M 32 60 Q 50 54 68 60 L 78 120 L 22 120 Z" fill="#eab308" />
              {/* Blue Torso */}
              <path d="M 38 60 L 62 60 L 58 88 L 42 88 Z" fill="#0284c7" />
              {/* Right Hand raised in Gyan Mudra (Teaching / Wisdom) */}
              <path d="M 60 70 Q 76 74 84 64" stroke="#7dd3fc" strokeWidth="6" strokeLinecap="round" fill="none" />
              <circle cx="85" cy="63" r="5" fill="#bae6fd" />
              {/* Light rays emanating from Krishna's blessing hand */}
              {isPlaying && (
                <circle cx="85" cy="63" r="14" fill="none" stroke="#fef08a" strokeWidth="1.2" strokeDasharray="2 2" opacity="0.85">
                  <animate attributeName="r" dur="1.8s" values="9;18;9" repeatCount="indefinite" />
                </circle>
              )}
            </g>

            {/* Warrior Arjuna (Listening earnestly with lowered bow) */}
            <g
              transform="translate(380, 210)"
              className={`transition-opacity duration-700 ${
                currentScene.speaker === 'Arjuna' ? 'opacity-100' : 'opacity-85'
              }`}
            >
              {/* Gandiva Bow resting peacefully */}
              <path d="M 90 20 Q 68 80 85 130" stroke="#b45309" strokeWidth="4.8" fill="none" strokeLinecap="round" />
              <line x1="90" y1="20" x2="85" y2="130" stroke="#fef3c7" strokeWidth="1.4" opacity="0.65" />

              {/* Arjuna Crown & Head */}
              <polygon points="40,25 33,42 47,42" fill="#d97706" />
              <circle cx="40" cy="50" r="13.5" fill="#d4b499" />
              {/* Armor (Kavacha) */}
              <path d="M 24 65 Q 40 60 56 65 L 62 120 L 18 120 Z" fill="#78350f" stroke="#b45309" strokeWidth="2.8" />
              {/* Folded hands in Anjali Mudra */}
              <path d="M 28 75 Q 14 80 8 74" stroke="#d4b499" strokeWidth="5.5" strokeLinecap="round" fill="none" />
            </g>

            {/* Floating Golden Lotus Petals & Light Motes */}
            {isPlaying && (
              <g opacity="0.9">
                <circle cx="280" cy="170" r="3.2" fill="#fef08a">
                  <animate attributeName="cy" dur="3.8s" values="170;130;170" repeatCount="indefinite" />
                  <animate attributeName="opacity" dur="3.8s" values="0.3;1;0.3" repeatCount="indefinite" />
                </circle>
                <circle cx="350" cy="185" r="3.8" fill="#fde047">
                  <animate attributeName="cy" dur="4.6s" values="185;140;185" repeatCount="indefinite" />
                  <animate attributeName="opacity" dur="4.6s" values="0.4;0.95;0.4" repeatCount="indefinite" />
                </circle>
                <circle cx="460" cy="165" r="2.8" fill="#fed7aa">
                  <animate attributeName="cy" dur="4.2s" values="165;125;165" repeatCount="indefinite" />
                </circle>
              </g>
            )}
          </svg>
        </div>

        {/* Top Video Overlay Bar */}
        <div className="absolute top-0 left-0 right-0 p-3 bg-gradient-to-b from-black/95 via-black/60 to-transparent flex items-center justify-between text-xs z-10">
          <div className="flex items-center gap-2 max-w-[55%] truncate">
            <span className="px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/35 via-orange-500/35 to-amber-500/35 text-amber-100 font-semibold border border-amber-400/70 text-[11px] flex items-center gap-1.5 shadow-md truncate">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="truncate">
                {subtitleLang === 'hi' ? scriptPackage.issueBadgeHi : scriptPackage.issueBadgeEn}
              </span>
            </span>
            <span className="text-amber-300/90 font-medium text-[11px] hidden md:inline font-serif shrink-0">
              • {verseRef}
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Spoken Voice Language Indicator / Switch (Default: Hindi) */}
            <button
              onClick={() => handleVoiceLangChange(voiceLang === 'hi' ? 'en' : 'hi')}
              title="Click to toggle spoken voice language"
              className="px-2 sm:px-2.5 py-1 rounded-xl bg-amber-950/80 hover:bg-amber-900/90 text-[10px] sm:text-[11px] font-semibold border border-amber-500/70 text-amber-200 shadow-xs transition active:scale-95 flex items-center gap-1"
            >
              <Volume2 className="w-3 h-3 text-amber-400" />
              <span>{voiceLang === 'hi' ? 'Voice: हिन्दी' : 'Voice: EN'}</span>
            </button>

            {/* Written Subtitles Language Switch (Default: English) */}
            <button
              onClick={() => setSubtitleLang(subtitleLang === 'en' ? 'hi' : 'en')}
              title="Click to toggle written subtitles language"
              className="px-2 sm:px-2.5 py-1 rounded-xl bg-stone-900/90 hover:bg-stone-800 text-[10px] sm:text-[11px] font-semibold border border-stone-700 text-stone-200 shadow-xs transition active:scale-95"
            >
              <span>{subtitleLang === 'en' ? 'Subtitles: EN' : 'Subtitles: हिन्दी'}</span>
            </button>

            {/* Mute/Unmute */}
            <button
              onClick={toggleMute}
              title={isAudioMuted ? 'Unmute voice' : 'Mute voice'}
              className="p-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-800 text-stone-200 border border-amber-500/40 shadow-sm transition active:scale-95"
            >
              {isAudioMuted ? <VolumeX className="w-4 h-4 text-stone-400" /> : <Volume2 className="w-4 h-4 text-amber-300" />}
            </button>

            {/* Fullscreen / Theater expand */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              title={isFullscreen ? 'Exit Theater Mode' : 'Theater Fullscreen Mode'}
              className="p-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-800 text-stone-200 border border-amber-500/40 shadow-sm transition active:scale-95"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4 text-amber-300" /> : <Maximize2 className="w-4 h-4 text-stone-300" />}
            </button>
          </div>
        </div>

        {/* Central Play button when paused */}
        {!isPlaying && (
          <div
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/55 backdrop-blur-2xs cursor-pointer z-10 p-4 text-center transition-all group"
            onClick={togglePlay}
          >
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-orange-500 to-amber-400 group-hover:from-amber-500 group-hover:to-orange-400 text-white flex items-center justify-center shadow-2xl pl-1 transform group-hover:scale-110 active:scale-95 transition-all duration-300 border-2 border-amber-200/90">
              <Play className="w-9 h-9 fill-white" />
            </div>
            <p className="mt-4 text-xs sm:text-sm font-bold text-amber-100 tracking-wide bg-stone-950/90 px-4 py-1.5 rounded-full border border-amber-500/60 shadow-xl max-w-md mx-auto truncate flex items-center gap-1.5 justify-center">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="truncate">{subtitleLang === 'hi' ? scriptPackage.issueBadgeHi : scriptPackage.issueBadgeEn}</span>
            </p>
            <p className="text-[11px] sm:text-xs text-stone-300 mt-1.5 font-light max-w-md mx-auto">
              {subtitleLang === 'hi'
                ? 'भगवान श्रीकृष्ण का दिव्य संवाद आपके संशय का समाधान करते हुए • हिन्दी वाणी'
                : 'Lord Krishna’s divine dialogue resolving your specific dilemma • Spoken voice in Hindi/EN'}
            </p>
          </div>
        )}

        {/* Floating Subtitle & Dialogue Card */}
        <div className="absolute bottom-2 left-3 right-3 sm:left-6 sm:right-6 pointer-events-none z-10">
          <div className="max-w-xl mx-auto p-3 sm:p-4 rounded-2xl bg-black/85 backdrop-blur-md border border-amber-500/50 shadow-2xl text-center">
            {/* Speaker Tag with Character Avatar Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider mb-1.5 bg-gradient-to-r from-amber-950 via-stone-900 to-amber-950 border border-amber-500/70 text-amber-300 shadow-md">
              {currentScene.speaker === 'Lord Krishna' ? (
                <Feather className="w-3.5 h-3.5 text-teal-400" />
              ) : (
                <Shield className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span>{subtitleLang === 'hi' ? currentScene.speakerHindi : currentScene.speaker}</span>
              <span className="text-amber-500/90 font-normal">• {subtitleLang === 'hi' ? currentScene.titleHindi : currentScene.title}</span>
            </div>

            {/* Subtitle Dialogue Line */}
            <p className="text-xs sm:text-sm font-medium text-stone-100 font-serif leading-relaxed drop-shadow-md">
              “{subtitleLang === 'hi' ? currentScene.textHi : currentScene.textEn}”
            </p>
          </div>
        </div>
      </div>

      {/* 4-Chapter Navigation Pills (Interactive Timeline Chapters) */}
      <div className="px-3 py-2 bg-[#120d09] border-t border-amber-900/50 grid grid-cols-4 gap-1.5 text-[10px]">
        {scenes.map((scene, idx) => {
          const isCurrent = currentSceneIdx === idx;
          const isPast = idx < currentSceneIdx;
          const chapterFill = isPast ? 100 : isCurrent ? Math.min(100, Math.round(sceneProgress * 100)) : 0;

          return (
            <button
              key={idx}
              onClick={() => handleSelectScene(idx)}
              className={`p-2 sm:p-2.5 rounded-xl text-left transition relative overflow-hidden border ${
                isCurrent
                  ? 'bg-amber-950/80 border-amber-400 text-amber-100 shadow-md ring-1 ring-amber-400/40'
                  : isPast
                  ? 'bg-amber-950/40 border-amber-900/60 text-amber-300/80 hover:bg-amber-900/40'
                  : 'bg-stone-950/70 border-stone-800/80 text-stone-400 hover:text-stone-200'
              }`}
            >
              {/* Progress bar fill for active chapter */}
              <div
                className="absolute left-0 bottom-0 top-0 bg-amber-500/25 pointer-events-none transition-all duration-100"
                style={{ width: `${chapterFill}%` }}
              />
              <span className="block font-semibold truncate relative z-1 text-[10px] sm:text-[11px]">
                {idx + 1}. {subtitleLang === 'hi' ? scene.titleHindi : scene.title}
              </span>
              <div className="flex items-center justify-between text-[9px] relative z-1 mt-0.5">
                <span className="text-amber-400 font-mono">
                  {isPast ? '✓ Complete' : isCurrent ? (isSpeaking ? '✦ Speaking' : '✦ Active') : `Part ${idx + 1}`}
                </span>
                <span className="text-stone-400 hidden sm:inline">
                  {scene.speaker === 'Lord Krishna' ? 'श्रीकृष्ण' : 'अर्जुन'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Media Transport Controls Bar */}
      <div className="p-3 bg-[#0a0705] border-t border-amber-900/40 flex items-center justify-between gap-2 sm:gap-3 text-xs">
        {/* Play/Pause & Skip Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={togglePlay}
            className="p-2 sm:px-3 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white transition flex items-center gap-1.5 font-semibold shadow-md active:scale-95"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
            <span className="hidden sm:inline">{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          {/* Previous Scene */}
          <button
            onClick={() => handleSkip(-1)}
            title="Previous scene"
            className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition active:scale-95"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Next Scene */}
          <button
            onClick={() => handleSkip(1)}
            title="Next scene"
            className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition active:scale-95"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Restart from beginning */}
          <button
            onClick={handleReset}
            title="Replay from start"
            className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Scene Scrubber & Indicator */}
        <div className="flex-1 max-w-sm sm:max-w-md mx-2 flex items-center gap-2">
          <div
            className="flex-1 h-2 bg-stone-900 rounded-full overflow-hidden cursor-pointer relative border border-stone-800/80"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
              const targetIdx = Math.min(scenes.length - 1, Math.floor(pos * scenes.length));
              handleSelectScene(targetIdx);
            }}
          >
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-orange-400 to-amber-300 rounded-full transition-all duration-100"
              style={{
                width: `${Math.min(100, (((currentSceneIdx + sceneProgress) / scenes.length) * 100))}%`,
              }}
            />
          </div>
          <span className="text-[11px] text-amber-300 font-mono font-bold shrink-0">
            Scene {currentSceneIdx + 1} of {scenes.length}
          </span>
        </div>

        {/* Guidance Concept Tag */}
        <div className="text-[11px] text-stone-400 font-medium shrink-0 hidden lg:block">
          <span className="text-amber-400 font-semibold">{verseRef}</span> • {category}
        </div>
      </div>
    </div>
  );
};

