import React, { useState, useEffect } from 'react';
import { Sunrise, Sparkles, CheckCircle2, Bell, Share2, Globe, ShieldCheck, Volume2, VolumeX, Pause, Play } from 'lucide-react';
import { DAILY_CALM_COLLECTION } from '../data/verses';
import { UserPreferences } from '../types';
import { meditationAudio } from '../services/meditationAudio';

interface DailyCalmScreenProps {
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
  onApplyToday: (reflection: typeof DAILY_CALM_COLLECTION[0]) => void;
  onShowToast: (msg: string) => void;
}

export const DailyCalmScreen: React.FC<DailyCalmScreenProps> = ({
  preferences,
  onUpdatePreferences,
  onApplyToday,
  onShowToast,
}) => {
  // Determine daily item based on date
  const todayIndex = new Date().getDay() % DAILY_CALM_COLLECTION.length;
  const [selectedDay, setSelectedDay] = useState(todayIndex);
  const [applied, setApplied] = useState(false);
  const [showHindi, setShowHindi] = useState(preferences.language === 'hi');
  const [isMeditatingAudio, setIsMeditatingAudio] = useState(false);

  const todayItem = DAILY_CALM_COLLECTION[selectedDay];

  useEffect(() => {
    return () => {
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    };
  }, []);

  const toggleMeditationAudio = () => {
    if (!isMeditatingAudio) {
      setIsMeditatingAudio(true);
      meditationAudio.startAmbientHum();
      meditationAudio.playSingingBowl(216, 4.0);

      // Speak calming contemplative meditation cue (Hindi by default)
      const spokenLang = preferences.spokenLanguage || 'hi';
      const meditationPrompt = spokenLang === 'hi'
        ? `आज का सिद्धांत है: ${todayItem.principle}। मन को शांत करें। श्वास लें, और केवल अपने कर्म पर ध्यान केंद्रित करें।`
        : `Today's principle is: ${todayItem.principle}. Settle your breathing. Inhale gently, exhale slowly, and let go of the fruits of action.`;

      meditationAudio.speakCue(meditationPrompt, spokenLang);
      onShowToast('Playing guided meditation audio.');
    } else {
      setIsMeditatingAudio(false);
      meditationAudio.stopAmbientHum();
      meditationAudio.stopSpeaking();
    }
  };

  const handleApply = () => {
    setApplied(true);
    onApplyToday(todayItem);
    onShowToast('Applied to today! Saved in your reflection journal.');
  };

  const toggleReminders = () => {
    if (!preferences.dailyReminderEnabled) {
      if ('Notification' in window) {
        Notification.requestPermission().then((permission) => {
          if (permission === 'granted') {
            onUpdatePreferences({ dailyReminderEnabled: true });
            onShowToast('Daily morning reminder enabled.');
          } else {
            onShowToast('Notification permission was not granted.');
          }
        });
      } else {
        onUpdatePreferences({ dailyReminderEnabled: true });
        onShowToast('Daily reminder preference saved.');
      }
    } else {
      onUpdatePreferences({ dailyReminderEnabled: false });
      onShowToast('Daily reminders turned off.');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-10 animate-fadeIn space-y-6 pb-24">
      {/* Top Banner */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-100 via-orange-100 to-rose-100 dark:from-amber-950/80 dark:via-orange-950/60 dark:to-rose-950/80 text-amber-900 dark:text-amber-300 text-xs font-semibold mb-2 border border-amber-200/60 dark:border-amber-900/60 shadow-xs">
          <Sunrise className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>Daily Wisdom Anchor</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 font-serif bg-gradient-to-r from-amber-900 via-orange-900 to-amber-800 dark:from-amber-100 dark:via-orange-200 dark:to-amber-200 bg-clip-text text-transparent">
          Daily Calm
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 mt-1">
          One foundational Gita principle to anchor your mind for today.
        </p>
      </div>

      {/* Main Daily Card */}
      <div className="bg-gradient-to-b from-white/95 via-amber-50/20 to-orange-50/20 dark:from-stone-900/95 dark:via-stone-900/90 dark:to-stone-950 rounded-3xl p-6 sm:p-8 shadow-md border border-amber-200/80 dark:border-amber-900/40 backdrop-blur-md zen-glow space-y-6 relative overflow-hidden">
        {/* Subtle decorative inner corner aura */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-300/20 via-orange-300/10 to-transparent rounded-full blur-xl pointer-events-none" />

        {/* Today's Principle */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400">
              Today’s Principle
            </span>
            <div className="flex items-center gap-2">
              {/* Soothing Meditation Audio Button */}
              <button
                onClick={toggleMeditationAudio}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition shadow-xs ${
                  isMeditatingAudio
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white border-amber-700 shadow-md'
                    : 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-800 hover:bg-amber-100'
                }`}
              >
                {isMeditatingAudio ? <Pause className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />}
                <span>{isMeditatingAudio ? 'Pause Voice' : 'Soothing Voice'}</span>
              </button>

              <span className="text-[11px] px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hidden sm:inline">
                Day {(selectedDay + 1)} of 7
              </span>
              <button
                onClick={() => setShowHindi(!showHindi)}
                className="text-[11px] px-2.5 py-0.5 rounded-full border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                {showHindi ? 'English' : 'हिन्दी'}
              </button>
            </div>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 font-serif">
            {todayItem.principle}
          </h2>
          <p className="text-stone-700 dark:text-stone-300 text-sm sm:text-base mt-2 leading-relaxed">
            “{todayItem.teaching}”
          </p>
        </div>

        {/* Verse Reference Card */}
        <div className="p-5 rounded-2xl bg-gradient-to-b from-amber-100/50 via-amber-50/40 to-orange-50/30 dark:bg-stone-950/60 border border-amber-200/80 dark:border-amber-900/40 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-900 dark:text-amber-300">
              Bhagavad Gita {todayItem.verse.chapter}.{todayItem.verse.verseNumber}
            </span>
            <span className="text-[10px] text-emerald-700 dark:text-emerald-400 flex items-center gap-1 font-semibold bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
              <ShieldCheck className="w-3 h-3" />
              <span>Verified canonical</span>
            </span>
          </div>
          <p className="text-sm font-medium text-stone-900 dark:text-amber-100 font-serif whitespace-pre-line mb-2 leading-relaxed">
            {todayItem.verse.sanskrit}
          </p>
          <p className="text-xs text-stone-600 dark:text-stone-300 italic leading-relaxed">
            {showHindi ? todayItem.verse.translationHindi : todayItem.verse.translationEnglish}
          </p>
        </div>

        {/* Practical Action */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-teal-50/70 via-emerald-50/50 to-teal-50/70 dark:from-teal-950/40 dark:via-emerald-950/30 dark:to-teal-950/40 border border-teal-200/70 dark:border-teal-900/50 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800 dark:text-teal-300 block mb-1">
            Practical Action for Today
          </span>
          <p className="text-xs sm:text-sm text-stone-800 dark:text-stone-200 leading-relaxed font-medium">
            {todayItem.practicalAction}
          </p>
        </div>

        {/* Reflection Question */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-50/70 via-pink-50/50 to-purple-50/70 dark:from-purple-950/40 dark:via-pink-950/30 dark:to-purple-950/40 border border-purple-200/70 dark:border-purple-900/50 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 block mb-1">
            Reflection Question
          </span>
          <p className="text-xs sm:text-sm text-stone-800 dark:text-stone-200 italic font-serif leading-relaxed">
            “{todayItem.reflectionQuestion}”
          </p>
        </div>

        {/* Action Button: Apply This Today */}
        <div className="pt-2 flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleApply}
            disabled={applied}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-2xl font-semibold text-sm transition shadow-xs ${
              applied
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-stone-900 dark:bg-amber-600 text-white hover:bg-stone-800 dark:hover:bg-amber-500 cursor-pointer active:scale-[0.99]'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{applied ? 'Applied to Your Day' : 'Apply This Today'}</span>
          </button>

          <button
            onClick={toggleReminders}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 text-xs font-semibold hover:bg-stone-50 dark:hover:bg-stone-800 transition"
          >
            <Bell className={`w-3.5 h-3.5 ${preferences.dailyReminderEnabled ? 'text-amber-600 fill-amber-600' : ''}`} />
            <span>{preferences.dailyReminderEnabled ? 'Morning Reminder On' : 'Set Daily Reminder'}</span>
          </button>
        </div>
      </div>

      {/* Week Selector Carousel */}
      <div className="bg-white/80 dark:bg-stone-900/80 rounded-2xl p-4 border border-stone-200/70 dark:border-stone-800">
        <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 block mb-2 text-center">
          Explore Other Principles for the Week
        </span>
        <div className="flex gap-2 overflow-x-auto pb-1 justify-start sm:justify-center">
          {DAILY_CALM_COLLECTION.map((item, idx) => (
            <button
              key={idx}
              onClick={() => {
                setSelectedDay(idx);
                setApplied(false);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition ${
                selectedDay === idx
                  ? 'bg-amber-700 text-white font-semibold'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-stone-700'
              }`}
            >
              Day {idx + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
