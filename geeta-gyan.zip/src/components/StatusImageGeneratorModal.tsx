import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Download,
  Share2,
  Copy,
  Sparkles,
  Check,
  Smartphone,
  Square,
  Palette,
  MessageCircle,
  RefreshCw,
  Sun,
  Flame,
  Moon,
  Leaf,
  Heart,
  Target,
  Compass,
  Smile,
  Shield,
  Zap,
} from 'lucide-react';

export interface StatusVerseData {
  chapter: number;
  verse: number;
  sanskrit: string;
  transliteration?: string;
  hindi: string;
  english?: string;
  positiveMessage?: string;
}

interface StatusImageGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  verseData: StatusVerseData;
  language?: 'en' | 'hi';
  onShowToast: (msg: string) => void;
}

type AspectRatio = '9:16' | '1:1';
type ThemeKey = 'surya-gold' | 'cosmic-krishna' | 'sacred-saffron' | 'lotus-grace' | 'vrindavan-forest';
type ArtworkType = 'krishna-upadesh' | 'surya-yogi' | 'morpankh-flute' | 'sacred-lotus' | 'gandiva-bow' | 'sacred-diya';
type LayoutMode = 'art-and-steps' | 'practical-steps' | 'meditative-shloka';
type LanguageOption = 'hi' | 'en' | 'both';

interface ThemeConfig {
  id: ThemeKey;
  nameEn: string;
  nameHi: string;
  icon: React.ComponentType<{ className?: string }>;
  bgColors: [string, string, string]; // Top, Middle, Bottom
  accentColor: string;
  subtleColor: string;
  cardBg: string;
  cardBorder: string;
  buttonSwatch: string;
}

const THEMES: ThemeConfig[] = [
  {
    id: 'surya-gold',
    nameEn: 'Surya Gold',
    nameHi: 'सूर्योदय स्वर्ण',
    icon: Sun,
    bgColors: ['#1c1008', '#381a04', '#150a03'],
    accentColor: '#fef08a',
    subtleColor: '#fde047',
    cardBg: 'rgba(245, 158, 11, 0.12)',
    cardBorder: 'rgba(251, 191, 36, 0.35)',
    buttonSwatch: 'from-amber-600 to-yellow-500',
  },
  {
    id: 'cosmic-krishna',
    nameEn: 'Cosmic Krishna',
    nameHi: 'विश्वरूप नील',
    icon: Moon,
    bgColors: ['#050b16', '#0d1629', '#02050e'],
    accentColor: '#93c5fd',
    subtleColor: '#fde047',
    cardBg: 'rgba(59, 130, 246, 0.12)',
    cardBorder: 'rgba(147, 197, 253, 0.35)',
    buttonSwatch: 'from-blue-700 to-indigo-600',
  },
  {
    id: 'sacred-saffron',
    nameEn: 'Sacred Saffron',
    nameHi: 'भगवा चंदन',
    icon: Flame,
    bgColors: ['#220a04', '#3d1602', '#180602'],
    accentColor: '#fdba74',
    subtleColor: '#fef08a',
    cardBg: 'rgba(234, 88, 12, 0.12)',
    cardBorder: 'rgba(251, 146, 60, 0.35)',
    buttonSwatch: 'from-orange-600 to-amber-700',
  },
  {
    id: 'lotus-grace',
    nameEn: 'Lotus Grace',
    nameHi: 'कमल कृपा',
    icon: Heart,
    bgColors: ['#1a0611', '#3b0a24', '#10030a'],
    accentColor: '#fbcfe8',
    subtleColor: '#fde047',
    cardBg: 'rgba(219, 39, 119, 0.12)',
    cardBorder: 'rgba(244, 114, 182, 0.35)',
    buttonSwatch: 'from-rose-600 to-pink-700',
  },
  {
    id: 'vrindavan-forest',
    nameEn: 'Vrindavan Peepal',
    nameHi: 'वृंदावन शांति',
    icon: Leaf,
    bgColors: ['#04150c', '#053f2f', '#020f08'],
    accentColor: '#a7f3d0',
    subtleColor: '#fde047',
    cardBg: 'rgba(16, 185, 129, 0.12)',
    cardBorder: 'rgba(110, 231, 183, 0.35)',
    buttonSwatch: 'from-emerald-700 to-teal-800',
  },
];

interface PracticalActionPreset {
  id: string;
  nameHi: string;
  nameEn: string;
  stepsHi: [string, string, string];
  stepsEn: [string, string, string];
}

const PRACTICAL_ACTION_PRESETS: PracticalActionPreset[] = [
  {
    id: 'karma-yoga',
    nameHi: 'कर्मयोग एवं एकाग्रता (Action & Focus)',
    nameEn: 'Action & Focus (Karma Yoga)',
    stepsHi: [
      '१. नतीजे की चिंता छोड़ें: भविष्य के डर को कागज पर लिखकर मन से विसर्जित करें।',
      '२. पूर्ण एकाग्रता: अगले २५ मिनट बिना विचलित हुए वर्तमान कार्य में १००% दें।',
      '३. समत्व भाव: कार्य पूरा होने पर परिणाम जो भी हो, मन में शांति बनाए रखें।',
    ],
    stepsEn: [
      '1. Surrender Outcome Anxiety: Write down your future worry and consciously let it go.',
      '2. Full Present Focus: Dedicate the next 25 minutes completely to your effort.',
      '3. Practice Equanimity: Whatever the outcome, keep your inner spirit undisturbed.',
    ],
  },
  {
    id: 'calm-mind',
    nameHi: 'तनाव मुक्ति एवं आंतरिक शांति (Inner Calm)',
    nameEn: 'Inner Calm & Anxiety Release',
    stepsHi: [
      '१. विचारों को देखना: मन में चल रहे विचारों को बिना लड़े केवल एक साक्षी बनकर देखें।',
      '२. ३ गहरी श्वास: छाती और कंधों को ढीला छोड़ते हुए शांत श्वास भीतर लें और छोड़ें।',
      '३. आत्म-संकल्प: स्वयं से कहें - "बाहरी परिस्थितियां अस्थाई हैं, शांति मेरा स्वभाव है।"',
    ],
    stepsEn: [
      '1. Witness the Mind: Observe spinning thoughts without judgment as a calm witness.',
      '2. 3 Conscious Breaths: Relax shoulders, inhale deep stillness, exhale all tension.',
      '3. Sacred Affirmation: Affirm - "Outer situations pass; peace is my true power."',
    ],
  },
  {
    id: 'courage',
    nameHi: 'निर्भयता एवं आत्म-विश्वास (Courage & Strength)',
    nameEn: 'Courage & Overcoming Fear',
    stepsHi: [
      '१. सच का सामना: याद रखें सुख-दुख और कठिनाइयां केवल गुजरने वाले मौसम हैं।',
      '२. छोटा साहसी कदम: जिस काम से डर लग रहा है, उसकी शुरुआत का पहला कदम अभी उठाएं।',
      '३. ईश्वर पर विश्वास: प्रभु श्रीकृष्ण कहते हैं - "जो निष्ठा से कर्म करता है, उसका कभी पतन नहीं होता।"',
    ],
    stepsEn: [
      '1. Face Reality: Remember pleasure and pain are transient seasons of life.',
      '2. Take 1 Brave Step: Begin the single task you have been avoiding right now.',
      '3. Unshakeable Faith: Sri Krishna assures: "No one who strives with sincerity is ever lost."',
    ],
  },
  {
    id: 'relationships',
    nameHi: 'संबंध, क्षमा एवं सौहार्द (Harmony & Forgiveness)',
    nameEn: 'Harmony & Letting Go of Anger',
    stepsHi: [
      '१. क्रोध पर विराम: कड़वी बात कहने से पहले १० सेकण्ड का मौन विराम रखें।',
      '२. क्षमा का उपहार: दूसरों की भूल को अपने मन पर बोझ न बनने दें, उन्हें क्षमा करें।',
      '३. प्रेमपूर्ण व्यवहार: आज किसी एक व्यक्ति को बिना किसी स्वार्थ के सहयोग या प्रोत्साहन दें।',
    ],
    stepsEn: [
      '1. Pause on Anger: Take a 10-second silence before reacting to heated words.',
      '2. Gift of Forgiveness: Do not carry other people\'s mistakes as poison in your heart.',
      '3. Act with Love: Offer sincere kindness or encouragement to someone today.',
    ],
  },
];

export const StatusImageGeneratorModal: React.FC<StatusImageGeneratorModalProps> = ({
  isOpen,
  onClose,
  verseData,
  language = 'en',
  onShowToast,
}) => {
  const isHi = language === 'hi';
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('9:16');
  const [selectedTheme, setSelectedTheme] = useState<ThemeKey>('surya-gold');
  const [selectedArtwork, setSelectedArtwork] = useState<ArtworkType>('krishna-upadesh');
  const [layoutMode, setLayoutMode] = useState<LayoutMode>('art-and-steps');
  const [langOption, setLangOption] = useState<LanguageOption>('both');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('karma-yoga');

  // Custom step edits
  const currentPreset = PRACTICAL_ACTION_PRESETS.find((p) => p.id === selectedPresetId) || PRACTICAL_ACTION_PRESETS[0];
  const [step1, setStep1] = useState(isHi ? currentPreset.stepsHi[0] : currentPreset.stepsEn[0]);
  const [step2, setStep2] = useState(isHi ? currentPreset.stepsHi[1] : currentPreset.stepsEn[1]);
  const [step3, setStep3] = useState(isHi ? currentPreset.stepsHi[2] : currentPreset.stepsEn[2]);

  const [positiveQuote, setPositiveQuote] = useState<string>(
    verseData.positiveMessage ||
      (isHi
        ? 'अपने कर्तव्य में शत-प्रतिशत समर्पण करें, परिणामों की चिंता छोड़कर शांति में रहें।'
        : 'Pour your full heart into your duty today, and release all anxiety about results.')
  );

  const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  // Sync steps when preset or language changes
  useEffect(() => {
    const p = PRACTICAL_ACTION_PRESETS.find((item) => item.id === selectedPresetId) || PRACTICAL_ACTION_PRESETS[0];
    setStep1(isHi ? p.stepsHi[0] : p.stepsEn[0]);
    setStep2(isHi ? p.stepsHi[1] : p.stepsEn[1]);
    setStep3(isHi ? p.stepsHi[2] : p.stepsEn[2]);
  }, [selectedPresetId, isHi]);

  // Clean strings
  const cleanSanskrit = (verseData.sanskrit || '')
    .replace(/^[\s\u0964\u0965|।\.]*\d+[\.\-\s]+\d+[\s\u0964\u0965|।\.]*/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  const cleanHindi = (verseData.hindi || '')
    .replace(/^।।\s*\d+\.\d+\s*।।\s*/, '')
    .trim();

  const cleanEnglish = (verseData.english || '').trim();

  const currentTheme = THEMES.find((t) => t.id === selectedTheme) || THEMES[0];

  useEffect(() => {
    if (!isOpen) return;
    drawCanvas();
  }, [
    isOpen,
    aspectRatio,
    selectedTheme,
    selectedArtwork,
    layoutMode,
    langOption,
    step1,
    step2,
    step3,
    positiveQuote,
    verseData,
  ]);

  // -------------------------------------------------------------
  // CANVAS DRAWING ENGINE WITH RICH SPIRITUAL SCENES & ACTION STEPS
  // -------------------------------------------------------------
  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = 1080;
    const height = aspectRatio === '9:16' ? 1920 : 1080;

    canvas.width = width;
    canvas.height = height;

    // 1. Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
    bgGrad.addColorStop(0, currentTheme.bgColors[0]);
    bgGrad.addColorStop(0.45, currentTheme.bgColors[1]);
    bgGrad.addColorStop(1, currentTheme.bgColors[2]);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // 2. Ambient Radiant Aura
    const auraGrad = ctx.createRadialGradient(
      width / 2,
      aspectRatio === '9:16' ? 360 : 260,
      20,
      width / 2,
      aspectRatio === '9:16' ? 360 : 260,
      width * 0.7
    );
    auraGrad.addColorStop(0, 'rgba(251, 191, 36, 0.28)');
    auraGrad.addColorStop(0.5, 'rgba(245, 158, 11, 0.08)');
    auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = auraGrad;
    ctx.fillRect(0, 0, width, height);

    // 3. Sacred Double Border with Corner Ornaments
    const pad = 44;
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, width - pad * 2, height - pad * 2);

    ctx.strokeStyle = 'rgba(251, 191, 36, 0.16)';
    ctx.lineWidth = 1;
    ctx.strokeRect(pad + 10, pad + 10, width - (pad + 10) * 2, height - (pad + 10) * 2);

    const drawCornerKnot = (x: number, y: number, angle: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((angle * Math.PI) / 180);
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(0, 0, 4.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-16, 0);
      ctx.lineTo(16, 0);
      ctx.moveTo(0, -16);
      ctx.lineTo(0, 16);
      ctx.stroke();
      ctx.restore();
    };

    drawCornerKnot(pad, pad, 0);
    drawCornerKnot(width - pad, pad, 90);
    drawCornerKnot(width - pad, height - pad, 180);
    drawCornerKnot(pad, height - pad, 270);

    // 4. Header Bar: Sacred Om & Chapter Citation
    let currentY = aspectRatio === '9:16' ? 120 : 80;

    ctx.textAlign = 'center';
    ctx.font = 'bold 44px serif';
    ctx.fillStyle = currentTheme.subtleColor;
    ctx.fillText('ॐ', width / 2, currentY);

    currentY += 40;

    ctx.font = 'bold 21px sans-serif';
    ctx.fillStyle = '#fbbf24';
    ctx.letterSpacing = '2.5px';
    ctx.fillText(`श्रीमद्भगवद्गीता • अध्याय ${verseData.chapter}, श्लोक ${verseData.verse}`, width / 2, currentY);

    currentY += 24;

    ctx.font = '600 15px sans-serif';
    ctx.fillStyle = 'rgba(254, 240, 138, 0.85)';
    ctx.letterSpacing = '1.5px';
    ctx.fillText(`BHAGAVAD GITA ${verseData.chapter}.${verseData.verse}`, width / 2, currentY);

    currentY += 28;

    // Divider Line
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(width / 2 - 120, currentY);
    ctx.lineTo(width / 2 + 120, currentY);
    ctx.stroke();

    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(width / 2, currentY, 3.5, 0, Math.PI * 2);
    ctx.fill();

    currentY += 25;

    // Helper: Wrap Text
    const wrapText = (
      text: string,
      x: number,
      startY: number,
      maxWidth: number,
      lineHeight: number,
      font: string,
      color: string,
      align: CanvasTextAlign = 'center'
    ): number => {
      ctx.font = font;
      ctx.fillStyle = color;
      ctx.textAlign = align;

      const paragraphs = text.split('\n');
      let y = startY;

      for (const p of paragraphs) {
        if (!p.trim()) {
          y += lineHeight * 0.4;
          continue;
        }
        const words = p.split(' ');
        let line = '';

        for (let n = 0; n < words.length; n++) {
          const testLine = line + words[n] + ' ';
          const metrics = ctx.measureText(testLine);
          const testWidth = metrics.width;
          if (testWidth > maxWidth && n > 0) {
            ctx.fillText(line.trim(), x, y);
            line = words[n] + ' ';
            y += lineHeight;
          } else {
            line = testLine;
          }
        }
        ctx.fillText(line.trim(), x, y);
        y += lineHeight;
      }
      return y;
    };

    // 5. ARTWORK SECTION (Rich Vector Scene Illustration)
    if (layoutMode !== 'practical-steps') {
      const artHeight = aspectRatio === '9:16' ? 220 : 160;
      const artCenterY = currentY + artHeight / 2;

      ctx.save();

      if (selectedArtwork === 'krishna-upadesh') {
        // SCENE 0: Bhagavan Lord Shri Krishna Imparting Gita Upadesh
        const kY = artCenterY - 14;
        const centerX = width / 2;

        // 1. Radiant Solar Aura / Divya Halo
        const haloGrad = ctx.createRadialGradient(centerX, kY, 8, centerX, kY, 94);
        haloGrad.addColorStop(0, '#fffbeb');
        haloGrad.addColorStop(0.3, '#fef08a');
        haloGrad.addColorStop(0.65, '#f59e0b');
        haloGrad.addColorStop(0.85, 'rgba(234, 88, 12, 0.45)');
        haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = haloGrad;
        ctx.beginPath();
        ctx.arc(centerX, kY, 94, 0, Math.PI * 2);
        ctx.fill();

        // Delicate Golden Ray Lines
        ctx.strokeStyle = 'rgba(254, 240, 138, 0.45)';
        ctx.lineWidth = 1.2;
        for (let i = 0; i < 16; i++) {
          const a = (i * Math.PI) / 8;
          ctx.beginPath();
          ctx.moveTo(centerX + Math.cos(a) * 62, kY + Math.sin(a) * 62);
          ctx.lineTo(centerX + Math.cos(a) * 98, kY + Math.sin(a) * 98);
          ctx.stroke();
        }

        // 2. Lord Krishna Torso & Pitambara (Golden Silk Robe)
        const yBase = kY + 68;
        ctx.fillStyle = '#ca8a04';
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(centerX - 46, yBase + 15);
        ctx.quadraticCurveTo(centerX - 28, yBase - 22, centerX - 12, yBase - 26);
        ctx.lineTo(centerX + 12, yBase - 26);
        ctx.quadraticCurveTo(centerX + 28, yBase - 22, centerX + 46, yBase + 15);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Pitambara Silk Folds
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(centerX - 24, yBase - 8);
        ctx.quadraticCurveTo(centerX, yBase + 12, centerX + 24, yBase - 8);
        ctx.stroke();

        // Vaijayanti Pearl Mala (Necklace)
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        ctx.moveTo(centerX - 18, yBase - 22);
        ctx.quadraticCurveTo(centerX, yBase + 4, centerX + 18, yBase - 22);
        ctx.stroke();
        ctx.setLineDash([]);

        // Kaustubha Jewel
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(centerX, yBase - 6, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // 3. Divine Shyam Complexioned Face & Neck
        const shyamGrad = ctx.createLinearGradient(centerX - 15, kY - 25, centerX + 15, kY + 25);
        shyamGrad.addColorStop(0, '#38bdf8');
        shyamGrad.addColorStop(0.5, '#0284c7');
        shyamGrad.addColorStop(1, '#0f172a');

        // Neck
        ctx.fillStyle = shyamGrad;
        ctx.fillRect(centerX - 8, yBase - 36, 16, 14);

        // Face Contour
        ctx.beginPath();
        ctx.ellipse(centerX, kY + 6, 18, 22, 0, 0, Math.PI * 2);
        ctx.fill();

        // Saffron & White Chandan Tilak
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(centerX - 2.5, kY - 9);
        ctx.lineTo(centerX - 2.5, kY + 4);
        ctx.moveTo(centerX + 2.5, kY - 9);
        ctx.lineTo(centerX + 2.5, kY + 4);
        ctx.stroke();

        ctx.strokeStyle = '#ea580c';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(centerX, kY - 6);
        ctx.lineTo(centerX, kY + 8);
        ctx.stroke();

        // Peaceful Lotus Eyes
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(centerX - 7, kY + 6, 5, Math.PI * 0.1, Math.PI * 0.9);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(centerX + 7, kY + 6, 5, Math.PI * 0.1, Math.PI * 0.9);
        ctx.stroke();

        // Reassuring, Gentle Divine Smile
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(centerX, kY + 16, 6, Math.PI * 0.2, Math.PI * 0.8);
        ctx.stroke();

        // Golden Earrings (Kundala)
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(centerX - 19, kY + 12, 3.5, 0, Math.PI * 2);
        ctx.arc(centerX + 19, kY + 12, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // 4. Golden Crown (Mukut)
        ctx.fillStyle = '#f59e0b';
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(centerX - 19, kY - 8);
        ctx.lineTo(centerX - 14, kY - 32);
        ctx.lineTo(centerX, kY - 44);
        ctx.lineTo(centerX + 14, kY - 32);
        ctx.lineTo(centerX + 19, kY - 8);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Crown Rubies & Pearls
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(centerX, kY - 26, 3, 0, Math.PI * 2);
        ctx.fill();

        // 5. Morpankh (Peacock Feather on Crown)
        ctx.save();
        ctx.translate(centerX + 2, kY - 44);
        ctx.rotate(0.2);

        // Outer Emerald Green Feather
        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.ellipse(0, -22, 13, 20, 0, 0, Math.PI * 2);
        ctx.fill();

        // Peacock Cyan Blue
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.ellipse(0, -21, 9, 14, 0, 0, Math.PI * 2);
        ctx.fill();

        // Deep Indigo Eye
        ctx.fillStyle = '#1e1b4b';
        ctx.beginPath();
        ctx.ellipse(0, -20, 5, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Golden Center Dot
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(0, -20, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // 6. Upadesha / Jnana Mudra (Right Hand raised in teaching/blessing)
        ctx.fillStyle = shyamGrad;
        ctx.beginPath();
        ctx.ellipse(centerX + 32, yBase - 12, 7, 10, 0.2, 0, Math.PI * 2);
        ctx.fill();

        // Golden Wrist Kangan
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(centerX + 26, yBase - 4, 12, 3.5);

        // Wisdom Sparkles Emanating from Hand
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(centerX + 36, yBase - 22, 2.5, 0, Math.PI * 2);
        ctx.arc(centerX + 44, yBase - 28, 1.8, 0, Math.PI * 2);
        ctx.arc(centerX + 28, yBase - 30, 1.5, 0, Math.PI * 2);
        ctx.fill();

        // 7. Flute (Murali) Resting on Left
        ctx.save();
        ctx.translate(centerX - 35, yBase - 4);
        ctx.rotate(-0.35);
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(0, 0, 52, 4);
        ctx.fillStyle = '#78350f';
        ctx.beginPath();
        ctx.arc(10, 2, 1, 0, Math.PI * 2);
        ctx.arc(18, 2, 1, 0, Math.PI * 2);
        ctx.arc(26, 2, 1, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // 8. Sacred Banner Ribbon: "॥ श्रीभगवानुवाच ॥"
        const bannerW = 240;
        const bannerH = 26;
        const bannerX = centerX - bannerW / 2;
        const bannerY = yBase + 16;

        ctx.fillStyle = 'rgba(180, 83, 9, 0.9)';
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        // Fallback for older canvas roundRect
        if (ctx.roundRect) {
          ctx.roundRect(bannerX, bannerY, bannerW, bannerH, 13);
        } else {
          ctx.rect(bannerX, bannerY, bannerW, bannerH);
        }
        ctx.fill();
        ctx.stroke();

        ctx.font = 'bold 12px "Noto Sans Devanagari", sans-serif';
        ctx.fillStyle = '#fef08a';
        ctx.textAlign = 'center';
        ctx.fillText(
          isHi ? '॥ श्रीभगवानुवाच • भगवान श्री कृष्ण का पावन उपदेश ॥' : '॥ SRI BHAGAVAN UVACHA • WORDS OF LORD KRISHNA ॥',
          centerX,
          bannerY + 18
        );
      } else if (selectedArtwork === 'surya-yogi') {
        // SCENE 1: Dawn Surya & Meditating Yogi Silhouette
        // Golden Sun Disc
        const sunGrad = ctx.createRadialGradient(width / 2, artCenterY - 15, 10, width / 2, artCenterY - 15, 85);
        sunGrad.addColorStop(0, '#fef08a');
        sunGrad.addColorStop(0.3, '#f59e0b');
        sunGrad.addColorStop(0.8, 'rgba(234, 88, 12, 0.4)');
        sunGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = sunGrad;
        ctx.beginPath();
        ctx.arc(width / 2, artCenterY - 15, 85, 0, Math.PI * 2);
        ctx.fill();

        // Sun corona rays
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.3)';
        ctx.lineWidth = 1.5;
        for (let r = 0; r < 12; r++) {
          const angle = (r * Math.PI) / 6;
          ctx.beginPath();
          ctx.moveTo(width / 2 + Math.cos(angle) * 70, artCenterY - 15 + Math.sin(angle) * 70);
          ctx.lineTo(width / 2 + Math.cos(angle) * 105, artCenterY - 15 + Math.sin(angle) * 105);
          ctx.stroke();
        }

        // Meditating Yogi Silhouette in Padmasana
        const yBase = artCenterY + 45;
        ctx.fillStyle = '#140c06';
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2;

        // Head & Usnisha
        ctx.beginPath();
        ctx.arc(width / 2, yBase - 52, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Crown Aura
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(width / 2, yBase - 72, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Torso & Arms in Dhyana Mudra
        ctx.fillStyle = '#140c06';
        ctx.beginPath();
        ctx.moveTo(width / 2 - 18, yBase - 36);
        ctx.quadraticCurveTo(width / 2, yBase - 42, width / 2 + 18, yBase - 36);
        ctx.lineTo(width / 2 + 32, yBase - 10);
        ctx.quadraticCurveTo(width / 2 + 42, yBase + 12, width / 2 + 25, yBase + 18);
        ctx.lineTo(width / 2 - 25, yBase + 18);
        ctx.quadraticCurveTo(width / 2 - 42, yBase + 12, width / 2 - 32, yBase - 10);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Crossed Legs Padmasana base
        ctx.beginPath();
        ctx.ellipse(width / 2, yBase + 20, 52, 16, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Calm water ripples under yogi
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(width / 2, yBase + 32, 85, 9, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (selectedArtwork === 'sacred-lotus') {
        // SCENE 2: Sacred Lotus Bloom (Untouched by Water / Nishkama Karma)
        const lY = artCenterY + 15;
        // Water ripples
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(width / 2, lY + 30, 95, 12, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Lotus Leaves
        ctx.fillStyle = '#065f46';
        ctx.beginPath();
        ctx.ellipse(width / 2 - 60, lY + 20, 40, 14, -0.15, 0, Math.PI * 2);
        ctx.ellipse(width / 2 + 60, lY + 20, 40, 14, 0.15, 0, Math.PI * 2);
        ctx.fill();

        // Lotus Petals Layered
        const drawPetal = (x: number, y: number, w: number, h: number, rot: number, color: string) => {
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(rot);
          ctx.fillStyle = color;
          ctx.strokeStyle = '#fbcfe8';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(0, -h);
          ctx.quadraticCurveTo(w, -h / 2, 0, 0);
          ctx.quadraticCurveTo(-w, -h / 2, 0, -h);
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        };

        // Outer petals
        drawPetal(width / 2, lY + 10, 24, 60, -0.65, '#be185d');
        drawPetal(width / 2, lY + 10, 24, 60, 0.65, '#be185d');
        drawPetal(width / 2, lY + 10, 26, 68, -0.35, '#db2777');
        drawPetal(width / 2, lY + 10, 26, 68, 0.35, '#db2777');

        // Central sacred petal
        drawPetal(width / 2, lY + 10, 28, 76, 0, '#f472b6');

        // Golden pollen core
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(width / 2, lY - 10, 7, 0, Math.PI * 2);
        ctx.fill();
      } else if (selectedArtwork === 'gandiva-bow') {
        // SCENE 3: Gandiva Bow & Kurukshetra Wheel of Duty
        const cY = artCenterY;
        // Wheel of Dharma
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.5)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(width / 2, cY, 48, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 1.5;
        for (let sp = 0; sp < 8; sp++) {
          const a = (sp * Math.PI) / 4;
          ctx.beginPath();
          ctx.moveTo(width / 2, cY);
          ctx.lineTo(width / 2 + Math.cos(a) * 48, cY + Math.sin(a) * 48);
          ctx.stroke();
        }

        // Golden Bow Arc
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(width / 2 - 25, cY, 65, -Math.PI * 0.45, Math.PI * 0.45);
        ctx.stroke();

        // Bowstring
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(width / 2 - 25 + Math.cos(-Math.PI * 0.45) * 65, cY + Math.sin(-Math.PI * 0.45) * 65);
        ctx.lineTo(width / 2 - 25 + Math.cos(Math.PI * 0.45) * 65, cY + Math.sin(Math.PI * 0.45) * 65);
        ctx.stroke();

        // Arrow with glowing tip
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(width / 2 - 60, cY);
        ctx.lineTo(width / 2 + 75, cY);
        ctx.stroke();

        // Arrow head
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.moveTo(width / 2 + 75, cY - 8);
        ctx.lineTo(width / 2 + 92, cY);
        ctx.lineTo(width / 2 + 75, cY + 8);
        ctx.closePath();
        ctx.fill();
      } else if (selectedArtwork === 'sacred-diya') {
        // SCENE 4: Sacred Diya & Radiant Flame of Inner Light
        const dY = artCenterY + 25;

        // Brass Diya Base
        ctx.fillStyle = '#78350f';
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.5;

        ctx.beginPath();
        ctx.ellipse(width / 2, dY + 12, 58, 16, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(width / 2 - 58, dY + 10);
        ctx.quadraticCurveTo(width / 2, dY - 8, width / 2 + 58, dY + 10);
        ctx.quadraticCurveTo(width / 2, dY + 22, width / 2 - 58, dY + 10);
        ctx.fill();
        ctx.stroke();

        // Warm Aura Glow
        const flameGlow = ctx.createRadialGradient(width / 2, dY - 30, 5, width / 2, dY - 30, 80);
        flameGlow.addColorStop(0, 'rgba(254, 240, 138, 0.7)');
        flameGlow.addColorStop(0.3, 'rgba(245, 158, 11, 0.3)');
        flameGlow.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = flameGlow;
        ctx.beginPath();
        ctx.arc(width / 2, dY - 30, 80, 0, Math.PI * 2);
        ctx.fill();

        // Teardrop Flame (Outer Orange, Inner Yellow/White)
        ctx.fillStyle = '#ea580c';
        ctx.beginPath();
        ctx.moveTo(width / 2, dY - 55);
        ctx.quadraticCurveTo(width / 2 + 20, dY - 20, width / 2, dY - 5);
        ctx.quadraticCurveTo(width / 2 - 20, dY - 20, width / 2, dY - 55);
        ctx.fill();

        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.moveTo(width / 2, dY - 45);
        ctx.quadraticCurveTo(width / 2 + 11, dY - 20, width / 2, dY - 10);
        ctx.quadraticCurveTo(width / 2 - 11, dY - 20, width / 2, dY - 45);
        ctx.fill();
      } else {
        // SCENE 5: Morpankh (Peacock Feather) & Flute with Om
        const mY = artCenterY;

        // Golden Flute angled
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 7;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(width / 2 - 75, mY + 28);
        ctx.lineTo(width / 2 + 75, mY - 28);
        ctx.stroke();

        // Peacock Feather Eye
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.ellipse(width / 2 - 10, mY - 25, 26, 38, -0.4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.ellipse(width / 2 - 10, mY - 25, 18, 28, -0.4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1e1b4b';
        ctx.beginPath();
        ctx.ellipse(width / 2 - 10, mY - 25, 10, 16, -0.4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(width / 2 - 8, mY - 25, 4, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      currentY += artHeight + 10;
    }

    // 6. SANSKRIT SHLOKA SECTION
    const shlokaFontSize = aspectRatio === '9:16' ? (layoutMode === 'art-and-steps' ? 27 : 32) : 22;
    const shlokaLineHeight = shlokaFontSize * 1.45;
    const maxBoxWidth = width - 180;

    currentY = wrapText(
      cleanSanskrit,
      width / 2,
      currentY + 10,
      maxBoxWidth,
      shlokaLineHeight,
      `bold ${shlokaFontSize}px 'Noto Sans Devanagari', 'Martel', serif`,
      '#ffffff'
    );

    currentY += 12;

    // Translation (Hindi / English)
    if (langOption === 'hi' || langOption === 'both') {
      const transFontSize = aspectRatio === '9:16' ? 20 : 16;
      currentY = wrapText(
        cleanHindi,
        width / 2,
        currentY + 5,
        maxBoxWidth,
        transFontSize * 1.4,
        `${transFontSize}px 'Noto Sans Devanagari', sans-serif`,
        '#f3f4f6'
      );
      currentY += 10;
    }

    if (langOption === 'en' && cleanEnglish) {
      const transFontSize = aspectRatio === '9:16' ? 18 : 15;
      currentY = wrapText(
        cleanEnglish,
        width / 2,
        currentY + 5,
        maxBoxWidth,
        transFontSize * 1.4,
        `${transFontSize}px sans-serif`,
        'rgba(243, 244, 246, 0.92)'
      );
      currentY += 10;
    }

    // 7. PRACTICAL ACTION STEPS BOX (Requested by user: "with message some practical thing can be shown")
    const stepBoxWidth = width - 140;
    const stepBoxX = 70;
    const stepBoxY = currentY + 12;
    const stepBoxHeight = aspectRatio === '9:16' ? (layoutMode === 'art-and-steps' ? 320 : 380) : 220;

    // Rounded Box
    ctx.fillStyle = currentTheme.cardBg;
    ctx.strokeStyle = currentTheme.cardBorder;
    ctx.lineWidth = 2;
    const r = 24;

    ctx.beginPath();
    ctx.moveTo(stepBoxX + r, stepBoxY);
    ctx.lineTo(stepBoxX + stepBoxWidth - r, stepBoxY);
    ctx.quadraticCurveTo(stepBoxX + stepBoxWidth, stepBoxY, stepBoxX + stepBoxWidth, stepBoxY + r);
    ctx.lineTo(stepBoxX + stepBoxWidth, stepBoxY + stepBoxHeight - r);
    ctx.quadraticCurveTo(stepBoxX + stepBoxWidth, stepBoxY + stepBoxHeight, stepBoxX + stepBoxWidth - r, stepBoxY + stepBoxHeight);
    ctx.lineTo(stepBoxX + r, stepBoxY + stepBoxHeight);
    ctx.quadraticCurveTo(stepBoxX, stepBoxY + stepBoxHeight, stepBoxX, stepBoxY + stepBoxHeight - r);
    ctx.lineTo(stepBoxX, stepBoxY + r);
    ctx.quadraticCurveTo(stepBoxX, stepBoxY, stepBoxX + r, stepBoxY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Box Header: "🎯 आज का व्यावहारिक कदम / Practical Steps"
    ctx.font = 'bold 18px sans-serif';
    ctx.fillStyle = '#fde047';
    ctx.textAlign = 'center';
    const boxHeader = isHi ? '🎯 आज के ३ व्यावहारिक कदम (Practical Action Steps)' : '🎯 3 Practical Action Steps for Today';
    ctx.fillText(boxHeader, width / 2, stepBoxY + 36);

    // Step Lines
    const stepFontSize = aspectRatio === '9:16' ? 18 : 14;
    const stepLineHeight = stepFontSize * 1.4;
    let sY = stepBoxY + 70;

    [step1, step2, step3].forEach((stepText) => {
      sY = wrapText(
        stepText,
        width / 2,
        sY,
        stepBoxWidth - 60,
        stepLineHeight,
        `500 ${stepFontSize}px 'Noto Sans Devanagari', sans-serif`,
        '#ffffff'
      );
      sY += aspectRatio === '9:16' ? 14 : 8;
    });

    // 8. Footer Branding & Positive Message
    const footerY = height - (aspectRatio === '9:16' ? 70 : 45);
    ctx.font = 'bold 15px sans-serif';
    ctx.fillStyle = '#fbbf24';
    ctx.textAlign = 'center';
    ctx.letterSpacing = '1px';
    ctx.fillText('गीता ज्ञान • GEETA GYAN', width / 2, footerY);

    ctx.font = '500 12px sans-serif';
    ctx.fillStyle = 'rgba(254, 240, 138, 0.75)';
    ctx.letterSpacing = '0.5px';
    ctx.fillText('Ancient Wisdom for Daily Action • geetagyan.app', width / 2, footerY + 20);

    // Generate Preview URL
    try {
      const dataUrl = canvas.toDataURL('image/png');
      setImagePreviewUrl(dataUrl);
    } catch (err) {
      console.error('Error generating preview:', err);
    }
  };

  // Download high-resolution PNG
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsGenerating(true);

    try {
      canvas.toBlob((blob) => {
        setIsGenerating(false);
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `GeetaGyan_CreativeStatus_BG_${verseData.chapter}_${verseData.verse}_${aspectRatio.replace(':', '_')}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        onShowToast(isHi ? 'रचनात्मक स्टेटस इमेज डाउनलोड हो गई!' : 'Creative status image downloaded successfully!');
      }, 'image/png');
    } catch {
      setIsGenerating(false);
      onShowToast(isHi ? 'डाउनलोड करने में असमर्थ' : 'Failed to download image');
    }
  };

  // WhatsApp Share with Native Web Share File Payload
  const handleShareWhatsApp = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const shareText = `*श्रीमद्भगवद्गीता ${verseData.chapter}.${verseData.verse}*\n\n${cleanSanskrit}\n\n_${cleanHindi || cleanEnglish}_\n\n🎯 *आज के ३ व्यावहारिक कदम:*\n• ${step1}\n• ${step2}\n• ${step3}\n\n— Geeta Gyan App (geetagyan.app)`;

    if (navigator.canShare && canvas.toBlob) {
      canvas.toBlob(async (blob) => {
        if (blob) {
          const file = new File([blob], `Gita_Status_${verseData.chapter}_${verseData.verse}.png`, {
            type: 'image/png',
          });

          if (navigator.canShare({ files: [file] })) {
            try {
              await navigator.share({
                title: `Bhagavad Gita ${verseData.chapter}.${verseData.verse}`,
                text: shareText,
                files: [file],
              });
              onShowToast(isHi ? 'व्हाट्सएप / इंस्टाग्राम पर साझा किया गया!' : 'Shared successfully!');
              return;
            } catch (shareErr: any) {
              if (shareErr.name !== 'AbortError') {
                console.log('Share dismissed');
              }
            }
          }
        }

        handleDownload();
        const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
        window.open(waUrl, '_blank');
      }, 'image/png');
    } else {
      handleDownload();
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
      window.open(waUrl, '_blank');
    }
  };

  // Copy Image to Clipboard
  const handleCopyImage = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      canvas.toBlob(async (blob) => {
        if (!blob) return;
        if (navigator.clipboard && (window as any).ClipboardItem) {
          try {
            await navigator.clipboard.write([new (window as any).ClipboardItem({ 'image/png': blob })]);
            setCopied(true);
            setTimeout(() => setCopied(false), 2500);
            onShowToast(isHi ? 'रचनात्मक इमेज क्लिपबोर्ड में कॉपी हो गई!' : 'Image copied to clipboard!');
            return;
          } catch {
            // fallback
          }
        }
        navigator.clipboard.writeText(
          `श्रीमद्भगवद्गीता ${verseData.chapter}.${verseData.verse}\n${cleanSanskrit}\n${cleanHindi}\n\nव्यावहारिक कदम:\n${step1}\n${step2}\n${step3}`
        );
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
        onShowToast(isHi ? 'श्लोक और व्यावहारिक कदम कॉपी किए गए!' : 'Copied to clipboard!');
      }, 'image/png');
    } catch {
      onShowToast(isHi ? 'कॉपी करने में विफल' : 'Failed to copy');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-5 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[94vh] overflow-y-auto bg-[#140e0a] border-2 border-amber-500/60 rounded-3xl shadow-2xl text-stone-100 p-4 sm:p-6 space-y-5">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-serif text-amber-200">
                {isHi ? 'रचनात्मक स्टेटस एवं व्यावहारिक कदम कार्ड' : 'Creative Status & Practical Action Card'}
              </h2>
              <p className="text-[11px] text-stone-400">
                {isHi
                  ? `अध्याय ${verseData.chapter}, श्लोक ${verseData.verse} • सचित्र कला एवं व्यावहारिक जीवन सूत्र`
                  : `Chapter ${verseData.chapter}, Verse ${verseData.verse} • Visual artwork + practical action steps`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-400 hover:text-white hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hidden Canvas used for high-res drawing */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Main Grid: Live Preview on Left, Creative Controls on Right */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          {/* Left Preview Column */}
          <div className="md:col-span-6 flex flex-col items-center justify-center space-y-3">
            <div className="w-full flex items-center justify-between px-1 text-xs text-stone-400 font-medium">
              <span>{isHi ? 'सचित्र स्टेटस पूर्वावलोकन' : 'Illustrated Status Preview'}</span>
              <span className="text-amber-400 font-mono text-[11px]">
                {aspectRatio === '9:16' ? '1080 × 1920 (Story)' : '1080 × 1080 (Square)'}
              </span>
            </div>

            {/* Visual Phone Frame Preview */}
            <div
              className={`relative overflow-hidden rounded-2xl border-2 border-amber-500/50 shadow-2xl bg-black flex items-center justify-center ${
                aspectRatio === '9:16' ? 'w-[250px] sm:w-[280px] aspect-[9/16]' : 'w-[280px] sm:w-[320px] aspect-square'
              }`}
            >
              {imagePreviewUrl ? (
                <img
                  src={imagePreviewUrl}
                  alt="Creative Status Preview"
                  className="w-full h-full object-contain select-none"
                />
              ) : (
                <div className="flex flex-col items-center justify-center p-4 text-stone-500 space-y-2">
                  <RefreshCw className="w-6 h-6 animate-spin text-amber-500" />
                  <span className="text-xs">{isHi ? 'कलाकृति तैयार हो रही है...' : 'Rendering artwork...'}</span>
                </div>
              )}
            </div>

            <p className="text-[11px] text-stone-400 text-center max-w-xs">
              {isHi
                ? 'केवल शब्दों के बजाय व्यावहारिक कदम और दिव्य दृश्य के साथ तैयार, ताकि देखने वालों को तुरंत प्रेरणा मिले।'
                : 'Features practical life steps alongside sacred artwork, giving your viewers immediate actionable inspiration.'}
            </p>
          </div>

          {/* Right Controls Column */}
          <div className="md:col-span-6 space-y-4 text-xs">
            {/* 1. Creative Artwork Scene Selector */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isHi ? '१. दिव्य कलाकृति दृश्य (Artwork Scene):' : '1. Sacred Artwork Scene:'}</span>
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'krishna-upadesh', icon: '🪷', nameHi: 'भगवान श्री कृष्ण (उपदेश)', nameEn: 'Lord Krishna (Upadesh)' },
                  { id: 'surya-yogi', icon: '🌅', nameHi: 'सूर्योदय व योगी', nameEn: 'Surya & Yogi' },
                  { id: 'morpankh-flute', icon: '🪶', nameHi: 'मयूरपंख व बंसुरी', nameEn: 'Peacock & Flute' },
                  { id: 'sacred-lotus', icon: '🌸', nameHi: 'पवित्र कमल', nameEn: 'Sacred Lotus' },
                  { id: 'gandiva-bow', icon: '🏹', nameHi: 'गांडीव व चक्र', nameEn: 'Bow & Wheel' },
                  { id: 'sacred-diya', icon: '🪔', nameHi: 'पावन दीपक', nameEn: 'Sacred Diya' },
                ].map((art) => (
                  <button
                    key={art.id}
                    type="button"
                    onClick={() => setSelectedArtwork(art.id as ArtworkType)}
                    className={`flex items-center gap-1.5 px-2 py-2 rounded-xl border text-left transition cursor-pointer ${
                      selectedArtwork === art.id
                        ? 'bg-amber-600/30 border-amber-400 text-amber-200 ring-1 ring-amber-400/50'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:bg-stone-800'
                    }`}
                  >
                    <span className="text-base">{art.icon}</span>
                    <span className="text-[10px] font-bold line-clamp-1">{isHi ? art.nameHi : art.nameEn}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Format & Layout Mode */}
            <div className="grid grid-cols-2 gap-3">
              {/* Aspect Ratio */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                  {isHi ? '२. प्रारूप (Format):' : '2. Format:'}
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setAspectRatio('9:16')}
                    className={`flex items-center justify-center gap-1 py-2 px-2 rounded-xl font-bold border transition ${
                      aspectRatio === '9:16'
                        ? 'bg-amber-600 text-white border-amber-400'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:bg-stone-800'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>9:16</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setAspectRatio('1:1')}
                    className={`flex items-center justify-center gap-1 py-2 px-2 rounded-xl font-bold border transition ${
                      aspectRatio === '1:1'
                        ? 'bg-amber-600 text-white border-amber-400'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:bg-stone-800'
                    }`}
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>1:1</span>
                  </button>
                </div>
              </div>

              {/* Layout Mode */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                  {isHi ? '३. शैली (Style):' : '3. Layout Style:'}
                </label>
                <select
                  value={layoutMode}
                  onChange={(e) => setLayoutMode(e.target.value as LayoutMode)}
                  className="w-full py-2 px-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs font-semibold focus:outline-hidden focus:border-amber-400"
                >
                  <option value="art-and-steps">{isHi ? 'सचित्र कला + व्यावहारिक कदम' : 'Artwork + Action Steps'}</option>
                  <option value="practical-steps">{isHi ? 'केवल व्यावहारिक कदम फोकस' : 'Practical Steps Only'}</option>
                  <option value="meditative-shloka">{isHi ? 'श्लोक एवं ध्यान दृश्य' : 'Meditative Shloka & Art'}</option>
                </select>
              </div>
            </div>

            {/* 3. Spiritual Theme Colors */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                {isHi ? '४. आध्यात्मिक रंग थीम (Theme):' : '4. Spiritual Color Theme:'}
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {THEMES.map((theme) => {
                  const isSelected = selectedTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() => setSelectedTheme(theme.id)}
                      className={`flex flex-col items-center justify-center p-1.5 rounded-xl border text-center transition ${
                        isSelected
                          ? 'border-amber-400 bg-amber-950/60 ring-2 ring-amber-400/40 text-amber-200'
                          : 'border-stone-800 bg-stone-900/80 text-stone-400 hover:bg-stone-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-gradient-to-tr ${theme.buttonSwatch} mb-0.5`} />
                      <span className="text-[9px] font-medium leading-tight line-clamp-1">
                        {isHi ? theme.nameHi.split(' ')[0] : theme.nameEn.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Practical Action Steps Customization */}
            <div className="space-y-2 p-3 rounded-2xl bg-stone-950 border border-stone-800/80">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isHi ? '५. व्यावहारिक कदम (Practical Steps):' : '5. Practical Action Steps:'}</span>
                </label>
              </div>

              {/* Preset Selector */}
              <div className="flex flex-wrap gap-1.5">
                {PRACTICAL_ACTION_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setSelectedPresetId(preset.id)}
                    className={`px-2 py-1 rounded-lg border text-[10px] font-medium transition ${
                      selectedPresetId === preset.id
                        ? 'bg-amber-600 text-white border-amber-400'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    {isHi ? preset.nameHi.split(' ')[0] : preset.nameEn.split(' ')[0]}
                  </button>
                ))}
              </div>

              {/* Editable 3 Step Inputs */}
              <div className="space-y-1.5 pt-1">
                <input
                  type="text"
                  value={step1}
                  onChange={(e) => setStep1(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-400"
                  placeholder="Step 1"
                />
                <input
                  type="text"
                  value={step2}
                  onChange={(e) => setStep2(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-400"
                  placeholder="Step 2"
                />
                <input
                  type="text"
                  value={step3}
                  onChange={(e) => setStep3(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-400"
                  placeholder="Step 3"
                />
              </div>
            </div>

            {/* Action Buttons: WhatsApp Share & Download */}
            <div className="pt-1 space-y-2">
              <button
                type="button"
                onClick={handleShareWhatsApp}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs shadow-md shadow-emerald-700/25 active:scale-98 transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{isHi ? 'व्हाट्सएप स्टेटस पर लगाएं (Share to WhatsApp)' : 'Share to WhatsApp Status'}</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleDownload}
                  disabled={isGenerating}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-md shadow-amber-600/20 active:scale-98 transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{isHi ? 'HD इमेज डाउनलोड' : 'Download HD Image'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyImage}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-stone-900 border border-stone-700 hover:bg-stone-800 text-stone-200 font-semibold text-xs active:scale-98 transition cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? (isHi ? 'कॉपी हो गया!' : 'Copied!') : isHi ? 'इमेज कॉपी करें' : 'Copy Image'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
