import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-auto border-t border-stone-200/60 dark:border-stone-800/60 bg-[#FAF7F2]/60 dark:bg-stone-900/60 py-6 px-4 text-center text-xs text-stone-500 dark:text-stone-400">
      <div className="max-w-2xl mx-auto space-y-2">
        <p className="font-medium text-stone-600 dark:text-stone-300">
          Geeta Gyan provides spiritual reflection and general wellbeing guidance. It does not provide medical diagnosis, therapy, or emergency services.
        </p>
        <p className="text-[11px] text-stone-400 dark:text-stone-500">
          © {new Date().getFullYear()} Geeta Gyan. Ancient wisdom for a calmer mind.
        </p>
      </div>
    </footer>
  );
};
