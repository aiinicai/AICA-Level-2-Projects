import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  UserProfile,
  subscribeToAuth,
  signInWithGoogle,
  signOutUser,
  isOwnerEmail,
} from '../services/firebase';

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  isLoading: boolean;
  isAdmin: boolean;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  isAdminDashboardOpen: boolean;
  openAdminDashboard: () => void;
  closeAdminDashboard: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribe = subscribeToAuth((authUser, authProfile) => {
      setUser(authUser);
      setProfile(authProfile);
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  const handleSignIn = async () => {
    try {
      setIsLoading(true);
      await signInWithGoogle();
    } catch (err: any) {
      console.error('Google Sign In error:', err);
      // If user closed popup, don't crash
      if (err?.code !== 'auth/popup-closed-by-user') {
        throw err;
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      setIsLoading(true);
      await signOutUser();
      setIsAdminDashboardOpen(false);
    } catch (err) {
      console.error('Sign Out error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const isAdmin = Boolean(
    profile?.role === 'admin' || isOwnerEmail(user?.email)
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isLoading,
        isAdmin,
        signIn: handleSignIn,
        signOut: handleSignOut,
        isAdminDashboardOpen,
        openAdminDashboard: () => setIsAdminDashboardOpen(true),
        closeAdminDashboard: () => setIsAdminDashboardOpen(false),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
