import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { HomeScreen } from './components/HomeScreen';
import { StressCheckinScreen } from './components/StressCheckinScreen';
import { GuidanceResultScreen } from './components/GuidanceResultScreen';
import { ResetScreen } from './components/ResetScreen';
import { DailyCalmScreen } from './components/DailyCalmScreen';
import { ChapterExplorationScreen } from './components/ChapterExplorationScreen';
import { JournalScreen } from './components/JournalScreen';
import { MyJourneyScreen } from './components/MyJourneyScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { SafetyScreen } from './components/SafetyScreen';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { GuruAudioPlayerBar } from './components/GuruAudioPlayerBar';
import { AdminDashboardModal } from './components/admin/AdminDashboardModal';

import { GuidanceResult, JournalEntry, StressCategory, UserPreferences } from './types';
import { checkSafety } from './services/safetyService';
import { getGuidance } from './services/guidanceService';
import {
  getJournalEntries,
  saveJournalEntry,
  deleteJournalEntry,
  getUserPreferences,
  saveUserPreferences,
  clearAllLocalData,
  isGuidanceSaved,
  toggleSaveGuidance,
} from './services/storageService';
import { meditationAudio } from './services/meditationAudio';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<string>('home');
  const [preferences, setPreferences] = useState<UserPreferences>(getUserPreferences);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(getJournalEntries);

  // User input flow state
  const [selectedCategory, setSelectedCategory] = useState<StressCategory | null>(null);
  const [userInput, setUserInput] = useState<string>('');
  const [stressIntensity, setStressIntensity] = useState<number>(3);
  const [currentGuidance, setCurrentGuidance] = useState<GuidanceResult | null>(null);
  const [perspectiveOffset, setPerspectiveOffset] = useState<number>(0);
  const [selectedChapterForExploration, setSelectedChapterForExploration] = useState<number | undefined>(undefined);
  const [selectedVerseForExploration, setSelectedVerseForExploration] = useState<number | undefined>(undefined);

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Dark mode effect
  useEffect(() => {
    const root = document.documentElement;
    if (preferences.theme === 'dark') {
      root.classList.add('dark');
    } else if (preferences.theme === 'light') {
      root.classList.remove('dark');
    } else {
      // System
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [preferences.theme]);

  // Warm up audio and voices on first user gesture for mobile browser compliance
  useEffect(() => {
    const handleFirstGesture = () => {
      meditationAudio.warmUp();
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };
    window.addEventListener('pointerdown', handleFirstGesture, { passive: true });
    window.addEventListener('touchstart', handleFirstGesture, { passive: true });
    return () => {
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };
  }, []);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage((cur) => (cur === message ? null : cur));
    }, 3800);
  };

  const handleUpdatePreferences = (updated: Partial<UserPreferences>) => {
    const next = saveUserPreferences(updated);
    setPreferences(next);
  };

  const handleClearAllData = () => {
    clearAllLocalData();
    setJournalEntries([]);
    setSelectedCategory(null);
    setUserInput('');
    setCurrentGuidance(null);
    setActiveScreen('home');
    setPreferences(getUserPreferences());
  };

  // Home submit -> check safety, then proceed to Stress Check-in
  const handleHomeSubmit = () => {
    const safety = checkSafety(userInput);
    if (safety.isCrisis) {
      setActiveScreen('safety');
      return;
    }
    setActiveScreen('checkin');
  };

  // Check-in continue -> calculate guidance, move to Guidance screen
  const handleCheckinContinue = async () => {
    const response = await getGuidance(
      {
        userInput,
        categoryChip: selectedCategory || undefined,
        stressIntensity,
      },
      perspectiveOffset
    );

    if (response.safetyAlert) {
      setActiveScreen('safety');
      return;
    }

    if (response.result) {
      setCurrentGuidance(response.result);
      setActiveScreen('guidance');
    }
  };

  // Switch to another perspective on the same problem
  const handleAnotherPerspective = async () => {
    const nextOffset = perspectiveOffset + 1;
    setPerspectiveOffset(nextOffset);
    const response = await getGuidance(
      {
        userInput,
        categoryChip: selectedCategory || undefined,
        stressIntensity,
      },
      nextOffset
    );

    if (response.result) {
      setCurrentGuidance(response.result);
      showToast('Loaded an alternate Bhagavad Gita perspective.');
    }
  };

  // Handle Journal action from guidance screen
  const handleJournalAboutThis = (guidance: GuidanceResult) => {
    const newEntry = saveJournalEntry({
      stressCategory: guidance.matchedCategory,
      userInput: userInput || `Reflecting on ${guidance.matchedCategory}`,
      stressBefore: stressIntensity,
      verseId: guidance.verse.id,
      verseReference: `BG ${guidance.verse.chapter}.${guidance.verse.verseNumber}`,
      concept: guidance.perspectiveConcept,
      actionTaken: guidance.action.title,
      reflection: guidance.whatThisMeansForYou.slice(0, 120) + '...',
      stressAfter: Math.max(1, stressIntensity - 1),
    });

    setJournalEntries(getJournalEntries());
    setActiveScreen('journal');
    showToast('Saved to your journal! You can update your post-reflection stress.');
  };

  const handleAddJournalEntry = (entry: Omit<JournalEntry, 'id' | 'createdAt'>) => {
    saveJournalEntry(entry);
    setJournalEntries(getJournalEntries());
  };

  const handleDeleteJournalEntry = (id: string) => {
    deleteJournalEntry(id);
    setJournalEntries(getJournalEntries());
  };

  const handleApplyDaily = (dailyItem: any) => {
    saveJournalEntry({
      stressCategory: 'Other',
      userInput: `Applied Daily Principle: ${dailyItem.principle}`,
      stressBefore: 3,
      verseId: dailyItem.verse.id,
      verseReference: `BG ${dailyItem.verse.chapter}.${dailyItem.verse.verseNumber}`,
      concept: dailyItem.principle,
      actionTaken: dailyItem.practicalAction,
      reflection: dailyItem.teaching,
      stressAfter: 2,
    });
    setJournalEntries(getJournalEntries());
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#FDFBF7] via-[#F8F5EE] to-[#F1ECE1] dark:from-[#0b0907] dark:via-[#120e0a] dark:to-[#080604] text-stone-800 dark:text-stone-100 transition-colors relative overflow-x-hidden">
      {/* Serene Floating Ambient Aura Glows (Calming visual environment) */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {/* Soft Dawn Amber Aura (Upper Center) */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[620px] h-[480px] bg-gradient-to-b from-amber-300/25 via-orange-300/15 to-transparent rounded-full blur-3xl animate-dawn-glow" />

        {/* Serene Teal / Turquoise Water Aura (Top Left - symbolizes peace & clarity) */}
        <div className="absolute top-24 -left-36 w-[450px] h-[450px] bg-gradient-to-br from-teal-300/20 via-emerald-200/15 to-transparent rounded-full blur-3xl animate-serene-float" />

        {/* Soft Golden Lotus / Rose Aura (Right Side - symbolizes warmth & compassion) */}
        <div className="absolute top-80 -right-28 w-[480px] h-[480px] bg-gradient-to-bl from-amber-400/20 via-rose-300/15 to-transparent rounded-full blur-3xl animate-serene-float" style={{ animationDelay: '-5s' }} />

        {/* Deep Grounding Indigo / Sky Blue Aura (Bottom) */}
        <div className="absolute bottom-10 left-1/4 w-[520px] h-[400px] bg-gradient-to-tr from-sky-300/15 via-indigo-200/10 to-transparent rounded-full blur-3xl opacity-75" />
      </div>

      {/* Top Header */}
      <Header
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16 md:pb-6 relative z-10">
        {activeScreen === 'safety' && (
          <SafetyScreen onBackToSafety={() => setActiveScreen('home')} />
        )}

        {activeScreen === 'home' && (
          <HomeScreen
            selectedCategory={selectedCategory}
            onSelectCategory={(cat) => setSelectedCategory(cat)}
            userInput={userInput}
            onUserInputChange={(val) => setUserInput(val)}
            onSubmit={handleHomeSubmit}
            onQuickReset={() => setActiveScreen('reset')}
            onExploreChapters={(chNum, vNum) => {
              setSelectedChapterForExploration(chNum);
              setSelectedVerseForExploration(vNum);
              setActiveScreen('chapters');
            }}
            language={preferences.language}
            spokenLanguage={preferences.spokenLanguage || 'hi'}
          />
        )}

        {activeScreen === 'checkin' && (
          <StressCheckinScreen
            selectedCategory={selectedCategory}
            userInput={userInput}
            intensity={stressIntensity}
            onIntensityChange={(lvl) => setStressIntensity(lvl)}
            onContinue={handleCheckinContinue}
            onBack={() => setActiveScreen('home')}
            language={preferences.language}
          />
        )}

        {activeScreen === 'guidance' && currentGuidance && (
          <GuidanceResultScreen
            guidance={currentGuidance}
            userInput={userInput}
            initialStressLevel={stressIntensity}
            preferences={preferences}
            onSaveToggle={(g) => toggleSaveGuidance(g)}
            isSaved={isGuidanceSaved(currentGuidance.verse.id)}
            onAnotherPerspective={handleAnotherPerspective}
            onJournalAboutThis={handleJournalAboutThis}
            onBackToHome={() => {
              setSelectedCategory(null);
              setUserInput('');
              setPerspectiveOffset(0);
              setActiveScreen('home');
            }}
            onShowToast={showToast}
            onExploreChapter={(chapterNumber) => {
              setSelectedChapterForExploration(chapterNumber);
              setSelectedVerseForExploration(undefined);
              setActiveScreen('chapters');
            }}
          />
        )}

        {activeScreen === 'chapters' && (
          <ChapterExplorationScreen
            preferences={preferences}
            onShowToast={showToast}
            onNavigateToHome={() => setActiveScreen('home')}
            initialChapterNumber={selectedChapterForExploration}
            initialVerseNumber={selectedVerseForExploration}
          />
        )}

        {activeScreen === 'reset' && <ResetScreen />}

        {activeScreen === 'daily' && (
          <DailyCalmScreen
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            onApplyToday={handleApplyDaily}
            onShowToast={showToast}
          />
        )}

        {activeScreen === 'journal' && (
          <JournalScreen
            onShowToast={showToast}
            onNavigateToPublic={() => setActiveScreen('chapters')}
            language={preferences.language}
          />
        )}

        {activeScreen === 'journey' && <MyJourneyScreen />}

        {activeScreen === 'settings' && (
          <SettingsScreen
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            onClearAllData={handleClearAllData}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Disclaimers Footer */}
      <Footer />

      {/* Persistent Indian Guru Audio Player Bar with Pause/Resume & Voice Switcher */}
      <GuruAudioPlayerBar language={preferences.language} />

      {/* Bottom Navigation for Mobile */}
      <BottomNav
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
        language={preferences.language}
      />

      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Admin Dashboard Modal (Authorized App Owner Only) */}
      <AdminDashboardModal language={preferences.language} />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 md:bottom-8 z-50 px-4 py-2.5 rounded-2xl bg-stone-900/95 dark:bg-amber-100/95 text-white dark:text-stone-900 text-xs font-medium shadow-2xl backdrop-blur-md animate-fadeIn border border-white/10 dark:border-stone-800">
          {toastMessage}
        </div>
      )}
    </div>
  );
}
