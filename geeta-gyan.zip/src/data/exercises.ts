import { ResetExercise } from '../types';

export const RESET_EXERCISES: ResetExercise[] = [
  {
    id: 'one-minute-pause',
    title: '2-Minute Meditation',
    subtitle: 'Soothing voice guide: Inhale, Pause, Exhale with Tibetan singing bowls',
    duration: '2 min',
    category: 'Breathing',
    linkedConcept: 'Steadiness of Mind (Sthitaprajna)',
    suitableFor: ['Overthinking', 'Feeling Overwhelmed', 'Work Pressure', 'Anger'],
    instructions: [
      'Sit comfortably and let your shoulders drop naturally.',
      'Inhale softly through your nose for 4 seconds as the luminous circle expands.',
      'Pause and hold the quiet stillness for 4 seconds.',
      'Exhale slowly and completely for 6 seconds as tension releases.',
      'Pause for 2 seconds in tranquil rest before the next breath.'
    ]
  },
  {
    id: 'control-vs-outcome',
    title: 'Control vs Outcome',
    subtitle: 'Separate your direct agency from external variables',
    duration: '3 min',
    category: 'Cognitive',
    linkedConcept: 'Karma Yoga (Focus on Action)',
    suitableFor: ['Fear of Failure', 'Uncertainty', 'Work Pressure', 'Money Worries'],
    instructions: [
      'Type or mentally identify the situation causing worry.',
      'Sort elements into: What I Control, What I Can Influence, What I Cannot Control.',
      'Release mental ownership of what you cannot control.',
      'Commit to one small concrete step within what you directly control.'
    ]
  },
  {
    id: 'one-action',
    title: 'One Action',
    subtitle: 'The smallest useful step in the next 10 minutes',
    duration: '10 min',
    category: 'Action',
    linkedConcept: 'Disciplined Action (Abhyasa)',
    suitableFor: ['Feeling Overwhelmed', 'Lack of Motivation', 'Overthinking', 'Work Pressure'],
    instructions: [
      'Break through paralysis by asking: "What is the smallest 5% step I can do right now?"',
      'It could be typing one email, opening a document, or washing a single glass.',
      'Start the 10-minute timer.',
      'Focus solely on this single step without evaluating whether the whole mountain is climbed.'
    ]
  },
  {
    id: 'anger-pause',
    title: 'Anger Pause',
    subtitle: 'Four-stage conscious interrupter before reacting',
    duration: '2 min',
    category: 'Emotional Regulation',
    linkedConcept: 'Self-Mastery & Anger Regulation',
    suitableFor: ['Anger', 'Conflict', 'Relationship Stress', 'Family Pressure'],
    instructions: [
      'Stage 1 (Pause): Stop moving, typing, or speaking immediately.',
      'Stage 2 (Notice): Feel where tension lives in your body (jaw, throat, fists).',
      'Stage 3 (Delay Reaction): Commit to a 60-second buffer before sending any reply.',
      'Stage 4 (Choose Response): Ask: "What response reflects who I wish to be?"'
    ]
  },
  {
    id: 'thought-reset',
    title: 'Thought Reset',
    subtitle: 'Distinguish facts from catastrophic assumptions',
    duration: '2 min',
    category: 'Cognitive',
    linkedConcept: 'Equanimity (Samatvam)',
    suitableFor: ['Overthinking', 'Fear of Failure', 'Uncertainty', 'Comparison'],
    instructions: [
      'Step 1: "What objective fact do I know for certain right now?"',
      'Step 2: "What story or catastrophe is my anxious mind assuming?"',
      'Step 3: "What action is actually required of me today?"'
    ]
  }
];
