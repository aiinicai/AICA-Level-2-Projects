import { GitaChapter } from '../types';

export const GITA_CHAPTERS: GitaChapter[] = [
  {
    chapterNumber: 1,
    sanskritName: 'अर्जुनविषादयोग',
    englishTitle: "Arjuna's Despair & Moral Crisis",
    hindiTitle: 'अर्जुन का विषाद और आंतरिक द्वंद्व',
    verseCount: 47,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'Standing between the two vast armies on the holy battlefield of Kurukshetra, Arjuna looks upon revered teachers, grandfathers, and kin. Overwhelmed by empathy and sorrow, his bow Gandiva slips from his trembling hand, and he collapses into despair, refusing to fight.',
    summaryHi:
      'कुरुक्षेत्र के युद्धभूमि में दोनों सेनाओं के मध्य उपस्थित होकर अर्जुन अपने गुरुओं, पिताओं और सगे-संबंधियों को देखते हैं। करुणा और शोक से व्याकुल होकर उनका गांडीव धनुष हाथ से गिर जाता है और वे विषादग्रस्त होकर रथ के पिछले भाग में बैठ जाते हैं।',
    relevanceEn:
      'When faced with overwhelming dilemmas, burnout, or moral confusion, grief and paralysis are natural human reactions. Acknowledging your emotional crisis is the essential first step toward genuine awakening and transformation.',
    relevanceHi:
      'गंभीर संकट, असमंजस या तनाव में घबराहट और अवसाद होना स्वाभाविक है। अपनी दुर्बलता और द्वंद्व को स्वीकार करना ही मार्गदर्शन और समाधान की पहली सीढ़ी है।',
    keyThemes: ['Moral Dilemma', 'Vulnerability', 'Surrender of Ego', 'Grief'],
    keyThemesHi: ['नैतिक संकट', 'भावुकता', 'शोक', 'मार्गदर्शन की आवश्यकता'],
    keyVerses: [
      {
        verseNumber: 28,
        sanskrit: 'दृष्ट्वेमं स्वजनं कृष्ण युयुत्सुं समुपस्थितम्।\nसीदन्ति मम गात्राणि मुखं च परिशुष्यति॥',
        transliteration: 'dṛṣṭvemaṁ svajanaṁ kṛṣṇa yuyutsuṁ samupasthitam\nsīdanti mama gātrāṇi mukhaṁ ca pariśuṣyati',
        translationEnglish: 'Seeing these my kinsmen gathered here eager to battle, my limbs fail and my mouth is parched.',
        translationHindi: 'हे कृष्ण! युद्ध की इच्छा से उपस्थित इस स्वजन समुदाय को देखकर मेरे अंग शिथिल हो रहे हैं और मुख सूख रहा है।',
        significanceEn: 'Captures the raw physical sensation of acute anxiety and somatic panic under crushing responsibility.',
        significanceHi: 'तीव्र चिंता और मानसिक दबाव के शारीरिक लक्षणों का सजीव चित्रण।',
      },
      {
        verseNumber: 47,
        sanskrit: 'एवमुक्त्वार्जुनः संख्ये रथोपस्थ उपाविशत्।\nविसृज्य सशरं चापं शोकसंविग्नमानसः॥',
        transliteration: 'evam uktvārjunaḥ saṅkhye rathopastha upāviśat\nvisṛjya sa-śaraṁ cāpaṁ śoka-saṁvigna-mānasaḥ',
        translationEnglish: 'Having spoken thus in the midst of battle, Arjuna cast aside his bow and arrows, and sat down on the seat of the chariot, his heart overwhelmed with sorrow.',
        translationHindi: 'युद्धभूमि में ऐसा कहकर शोकाकुल मन वाले अर्जुन बाणसहित धनुष को त्यागकर रथ के पिछले भाग में बैठ गए।',
        significanceEn: 'The low point of existential paralysis that creates the opening for Lord Krishna’s transformative counsel.',
        significanceHi: 'विषाद का वह बिंदु जहाँ से ज्ञान और आत्म-जागरण की यात्रा प्रारंभ होती है।',
      },
    ],
  },
  {
    chapterNumber: 2,
    sanskritName: 'सांख्ययोग',
    englishTitle: 'The Yoga of Knowledge & The Steady Mind',
    hindiTitle: 'सांख्ययोग: आत्मज्ञान और स्थितप्रज्ञता',
    verseCount: 72,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'The philosophical core and synopsis of the entire Bhagavad Gita. Sri Krishna reveals the eternal, indestructible nature of the soul (Atman), dispels grief, introduces Karma Yoga (selfless duty without obsession over results), and describes the attributes of the Sthitaprajna (one anchored in unshakable equanimity).',
    summaryHi:
      'संपूर्ण गीता का सार-संग्रह। श्रीकृष्ण आत्मा की अमरता और अविनाशिता का उद्घाटन करते हैं, अर्जुन के मोह का निवारण करते हैं, निष्काम कर्मयोग का मार्ग दिखाते हैं, और स्थितप्रज्ञ (शांत एवं स्थिर बुद्धि वाले महापुरुष) के लक्षणों का वर्णन करते हैं।',
    relevanceEn:
      'Separates your core essence from changing external circumstances. Teaches you to pour total focus into effort while relinquishing anxiety over uncontrollable outcomes.',
    relevanceHi:
      'आपको यह सिखाता है कि परिस्थितियों में बदलाव आने पर भी आंतरिक शांति कैसे बनाए रखें, और कर्म करते हुए फल की चिंता से मुक्त रहें।',
    keyThemes: ['Immortal Soul', 'Karma Yoga', 'Equanimity (Samatvam)', 'Sthitaprajna'],
    keyThemesHi: ['आत्मज्ञान', 'कर्मयोग', 'समत्व', 'स्थितप्रज्ञ'],
    keyVerses: [
      {
        verseNumber: 47,
        sanskrit: 'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥',
        transliteration: 'karmaṇy-evādhikāras te mā phaleṣhu kadāchana\nmā karma-phala-hetur bhūr mā te saṅgo ’stv akarmaṇi',
        translationEnglish: 'You have a right only to work, never to its fruits. Let not the fruit of action be your motive, nor let your attachment be to inaction.',
        translationHindi: 'तुम्हारा अधिकार केवल कर्म करने में है, उसके फलों में कभी नहीं। फल की वासना वाले मत बनो और न ही तुम्हारी अकर्मण्यता में आसक्ति हो।',
        significanceEn: 'The definitive manifesto of mindfulness: full ownership of effort, total detachment from anxious outcome-craving.',
        significanceHi: 'कर्म पर पूर्ण नियंत्रण और परिणाम की चिंता से मुक्ति का अमर सूत्र।',
      },
      {
        verseNumber: 70,
        sanskrit: 'आपूर्यमाणमचलप्रतिष्ठं समुद्रमापः प्रविशन्ति यद्वत्।\nतद्वत्कामा यं प्रविशन्ति सर्वे स शान्तिमप्नोति न कामकामी॥',
        transliteration: 'āpūryamāṇam achala-pratiṣhṭhaṁ samudram āpaḥ praviśhanti yadvat\ntadvat kāmā yaṁ praviśhanti sarve sa śhāntim āpnoti na kāma-kāmī',
        translationEnglish: 'Just as the ocean remains undisturbed while waters continuously enter it from all sides, so does the person attain peace into whom all desires enter without disturbing the mind.',
        translationHindi: 'जैसे सभी नदियों का जल अचल समुद्र में विलीन होकर उसे विचलित नहीं करता, वैसे ही जिसके मन में समस्त विचार विकार उत्पन्न किए बिना समा जाते हैं, वही शांति पाता है।',
        significanceEn: 'An inspiring metaphor for emotional stability in the midst of life’s chaotic demands.',
        significanceHi: 'हजारों बाहरी हलचलों के बीच भी समुद्र जैसी अगाध शांति का आदर्श।',
      },
    ],
  },
  {
    chapterNumber: 3,
    sanskritName: 'कर्मयोग',
    englishTitle: 'The Yoga of Dedicated Action',
    hindiTitle: 'कर्मयोग: निःस्वार्थ कर्म का विज्ञान',
    verseCount: 43,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'Krishna explains why fleeing from duty into false renunciation brings neither peace nor freedom. All living beings are compelled to act by nature. By transforming every work into selfless contribution (Yajna) and honoring your authentic duty (Svadharma), action itself becomes a vehicle for liberation.',
    summaryHi:
      'श्रीकृष्ण बताते हैं कि कर्म से पलायन या संन्यास का ढोंग करने से शांति नहीं मिलती। प्रकृति के गुणों के कारण कोई क्षण भर भी अकर्मण्य नहीं रह सकता। निष्काम भाव से लोककल्याणार्थ कर्म करना ही सर्वोत्तम मार्ग है।',
    relevanceEn:
      'Counteracts procrastination, burnout, and social comparison. Reminds you that sincere, imperfect personal responsibility is far more liberating than mimicking others.',
    relevanceHi:
      'आलस्य और दूसरों से तुलना करने की प्रवृत्ति को मिटाता है। अपने स्वाभाविक दायित्व को ईमानदारी से निभाने की प्रेरणा देता है।',
    keyThemes: ['Svadharma', 'Yajna (Contribution)', 'Leadership by Example', 'Overcoming Lust & Greed'],
    keyThemesHi: ['स्वधर्म', 'यज्ञीय कर्म', 'श्रेष्ठ आचरण', 'कामनाओं पर नियंत्रण'],
    keyVerses: [
      {
        verseNumber: 35,
        sanskrit: 'श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात्।\nस्वधर्मे निधनं श्रेयः परधर्मो भयावहः॥',
        transliteration: 'śhreyān sva-dharmo viguṇaḥ para-dharmāt sv-anuṣhṭhitāt\nsva-dharme nidhanaṁ śhreyaḥ para-dharmo bhayāvahaḥ',
        translationEnglish: 'Better is one’s own duty, though destitute of merit, than the well-executed duty of another. The path of another is fraught with danger and fear.',
        translationHindi: 'दूसरों के कर्तव्य को उत्तमता से करने की अपेक्षा अपना कर्तव्य चाहे त्रुटिपूर्ण ही क्यों न हो, श्रेष्ठ है। अपने मार्ग पर चलना कल्याणकारी है, दूसरों का मार्ग भयभीत करने वाला है।',
        significanceEn: 'The supreme antidote to social envy, impostor syndrome, and destructive peer comparison.',
        significanceHi: 'दूसरों की नकल और हीनभावना से मुक्ति पाने का सबसे शक्तिशाली संदेश।',
      },
    ],
  },
  {
    chapterNumber: 4,
    sanskritName: 'ज्ञानकर्मसंन्यासयोग',
    englishTitle: 'The Yoga of Wisdom in Action',
    hindiTitle: 'ज्ञानकर्मसंन्यासयोग: कर्म में ज्ञान का प्रकाश',
    verseCount: 42,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'Krishna reveals the ancient lineage of spiritual wisdom and explains how divine consciousness incarnates age after age to protect virtue. He elucidates how action performed with spiritual wisdom binds no one, and how the blazing fire of knowledge consumes all anxiety and doubt.',
    summaryHi:
      'श्रीकृष्ण इस सनातन ज्ञान की परंपरा और धर्म-संस्थापनार्थ अपने अवतार का रहस्य प्रकट करते हैं। वे बताते हैं कि ज्ञानी व्यक्ति कर्म करते हुए भी उसमें लिप्त नहीं होता, और ज्ञान की अग्नि समस्त संशयों को भस्म कर देती है।',
    relevanceEn:
      'Transforms daily chores and professional tasks into meaningful, purpose-driven service. Wisdom dissolves debilitating paralysis of analysis.',
    relevanceHi:
      'दैनिक कार्यों को उद्देश्यपूर्ण बनाकर तनावमुक्त करता है और आत्म-विश्वास के साथ संशयों को दूर करता है।',
    keyThemes: ['Avatar Doctrine', 'Wisdom Fire (Jnanagni)', 'Doubt Destruction', 'Detached Engagement'],
    keyThemesHi: ['अवतार रहस्य', 'ज्ञानाग्नि', 'संशय निवारण', 'निःस्वार्थ सेवा'],
    keyVerses: [
      {
        verseNumber: 38,
        sanskrit: 'न हि ज्ञानेन सदृशं पवित्रमिह विद्यते।\nतत्स्वयं योगसंसिद्धः कालेनात्मनि विन्दति॥',
        transliteration: 'na hi jñānena sadṛśaṁ pavitram iha vidyate\ntat svayaṁ yoga-saṁsiddhaḥ kālenātmani vindati',
        translationEnglish: 'Certainly, there is nothing in this world as purifying as divine wisdom. One perfected in Yoga attains it naturally within themselves in due time.',
        translationHindi: 'इस संसार में ज्ञान के समान पवित्र करने वाला निःसंदेह कुछ भी नहीं है। कर्मयोग में सिद्ध हुआ मनुष्य समय पाकर उसे अपने आप में पा लेता है।',
        significanceEn: 'Truth and self-knowledge alone possess the purity to cleanse psychological burdens and inherited fears.',
        significanceHi: 'ज्ञान ही अंतःकरण के समस्त मलों और संतापों को शांत करने वाली परम औषधि है।',
      },
    ],
  },
  {
    chapterNumber: 5,
    sanskritName: 'कर्मसंन्यासयोग',
    englishTitle: 'The Yoga of Renunciation & Inner Freedom',
    hindiTitle: 'कर्मसंन्यासयोग: अंतर्मुखी शांति और कर्म',
    verseCount: 29,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'Arjuna asks whether physical renunciation of work or dedicated action in the world is superior. Krishna establishes that true renunciation is an internal state: remaining like a lotus leaf untouched by the water it rests upon. The wise see with equal vision in a learned scholar, a cow, or an outcaste.',
    summaryHi:
      'अर्जुन पूछते हैं कि संन्यास और कर्मयोग में कौन श्रेष्ठ है। श्रीकृष्ण समझाते हैं कि वास्तविक संन्यास मन का अनासक्त भाव है—जैसे कमल का पत्ता जल में रहकर भी गीला नहीं होता। ज्ञानीजन सबमें एक ही आत्मतत्त्व देखते हैं।',
    relevanceEn:
      'You do not need to quit your career or withdraw to a cave to find serenity. Serenity is being fully engaged in the world while internally unperturbed.',
    relevanceHi:
      'शांति पाने के लिए काम छोड़ने की आवश्यकता नहीं; कमल की तरह संसार में रहकर भी निर्लिप्त रहने की कला सीखें।',
    keyThemes: ['Lotus Leaf Metaphor', 'Samadarshana (Equal Vision)', 'Inner Freedom', 'Brahma-Nirvana'],
    keyThemesHi: ['कमलपत्रवत जीवन', 'समदृष्टि', 'आंतरिक मुक्ति', 'परम शांति'],
    keyVerses: [
      {
        verseNumber: 10,
        sanskrit: 'ब्रह्मण्याधाय कर्माणि सङ्गं त्यक्त्वा करोति यः।\nलिप्यते न स पापेन पद्मपत्रमिवाम्भसा॥',
        transliteration: 'brahmaṇy-ādhāya karmāṇi saṅgaṁ tyaktvā karoti yaḥ\nlipyate na sa pāpena padma-patram ivāmbhasā',
        translationEnglish: 'One who acts offering all deeds to the Divine, casting off attachment, is untouched by negativity, as a lotus leaf is untouched by water.',
        translationHindi: 'जो व्यक्ति सब कर्मों को परमात्मा में अर्पण करके और आसक्ति त्यागकर कर्म करता है, वह पाप या दोष से उसी प्रकार अछूता रहता है जैसे कमल का पत्ता जल से।',
        significanceEn: 'A timeless visual anchor for building emotional resilience amid toxic environments.',
        significanceHi: 'तनावपूर्ण वातावरण में भी अपनी पवित्रता और शांति बनाए रखने का अनुपम दृष्टांत।',
      },
    ],
  },
  {
    chapterNumber: 6,
    sanskritName: 'आत्मसंयमयोग (ध्यानयोग)',
    englishTitle: 'The Yoga of Meditation & Self-Mastery',
    hindiTitle: 'आत्मसंयमयोग: ध्यान और मन की साधना',
    verseCount: 47,
    sectionGroup: 'Karma Yoga (Ch 1-6)',
    summaryEn:
      'Detailed, practical instructions on posture, breathing, mental training, and meditation. Krishna declares that the mind can be your greatest friend or your deadliest enemy. When Arjuna protests that the restless mind is as hard to catch as the hurricane wind, Krishna assures him it is tamed through regular practice (Abhyasa) and patient detachment (Vairagya).',
    summaryHi:
      'ध्यान, आसन, प्राणायाम और चित्त की एकाग्रता का क्रियात्मक मार्गदर्शन। मन स्वयं का परम मित्र भी है और घोर शत्रु भी। अर्जुन के संशय पर श्रीकृष्ण आश्वस्त करते हैं कि निरंतर अभ्यास और वैराग्य से इस चंचल मन को वश में किया जा सकता है।',
    relevanceEn:
      'The foundational guidebook for breathwork, meditation, and habit training. Provides gentle compassion for attention wanderings without guilt.',
    relevanceHi:
      'ध्यान और तनावमुक्ति का प्रत्यक्ष सूत्र। चंचल विचारों को बिना चिढ़े प्रेमपूर्वक वर्तमान में लौटाने का अभ्यास।',
    keyThemes: ['Mind as Friend or Foe', 'Practice (Abhyasa)', 'Detachment (Vairagya)', 'Flickerless Flame'],
    keyThemesHi: ['मन: मित्र या शत्रु', 'अभ्यास और वैराग्य', 'स्थिर दीपक', 'ध्यान की विधि'],
    keyVerses: [
      {
        verseNumber: 5,
        sanskrit: 'उद्धरेदात्मनात्मानं नात्मानमवसादयेत्।\nआत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः॥',
        transliteration: 'uddhared ātmanātmānaṁ nātmānam avasādayet\nātmaiva hyātmano bandhur ātmaiva ripur ātmanaḥ',
        translationEnglish: 'Let a person elevate themselves by their own mind, and not degrade themselves. For the mind alone is the friend of the self, and the mind alone is the enemy of the self.',
        translationHindi: 'मनुष्य अपने मन द्वारा अपना उद्धार करे, अपने आपको नीचे न गिराए। क्योंकि मन ही आत्मा का मित्र है और मन ही अपना शत्रु है।',
        significanceEn: 'The supreme declaration of self-empowerment and mindful self-compassion.',
        significanceHi: 'आत्म-सम्मान और स्वयं के प्रति दयालु रहने की सबसे बड़ी प्रेरणा।',
      },
      {
        verseNumber: 26,
        sanskrit: 'यतो यतो निश्चरति मनश्चञ्चलमस्थिरम्।\nततस्ततो नियम्यैतदात्मन्येव वशं नयेत्॥',
        transliteration: 'yato yato niśhcharati manaśh chañchalam asthiram\ntatas tato niyamyaitad ātmanyeva vaśhaṁ nayet',
        translationEnglish: 'From whatever cause the restless and unsteady mind wanders away, from that one should gently restrain it and bring it back under the control of the Self.',
        translationHindi: 'यह चंचल और अस्थिर मन जहाँ-जहाँ भटकता है, वहाँ-वहाँ से इसे रोककर बार-बार आत्मा के ही वश में लाना चाहिए।',
        significanceEn: 'The gentle psychological technique of noticing distraction without anger and returning to breath.',
        significanceHi: 'मन भटकने पर बिना हताश हुए उसे शांति से वर्तमान में लौटाने का सरल उपाय।',
      },
    ],
  },
  {
    chapterNumber: 7,
    sanskritName: 'ज्ञानविज्ञानयोग',
    englishTitle: 'The Yoga of Knowledge and Discernment',
    hindiTitle: 'ज्ञानविज्ञानयोग: तत्वज्ञान और अनुभव',
    verseCount: 30,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'Krishna reveals His material nature (the five elements, mind, intellect, and ego) and His higher spiritual nature by which the universe is animated. He describes the four types of seekers who turn to the Divine (the distressed, the inquirer, the seeker of wealth, and the wise) and praises the steadfast seeker of truth.',
    summaryHi:
      'श्रीकृष्ण अपनी अपरा प्रकृति (पंचमहाभूत, मन, बुद्धि, अहंकार) और चेतन परा प्रकृति का रहस्य खोलते हैं। वे चार प्रकार के भक्तों (आर्त, जिज्ञासु, अर्थार्थी, ज्ञानी) का वर्णन करते हैं और ज्ञानी भक्त को अपना ही स्वरूप बताते हैं।',
    relevanceEn:
      'Recognizing that suffering or distress (Arta) is a legitimate gateway to deeper wisdom and spiritual grounding rather than a sign of failure.',
    relevanceHi:
      'संकट और जिज्ञासा को आत्मिक उन्नति का अवसर मानना और प्रकृति के नियमों को समझकर जीवन में सामंजस्य बिठाना।',
    keyThemes: ['Higher & Lower Nature', 'Four Types of Seekers', 'The Fragrance in Earth', 'Overcoming Maya'],
    keyThemesHi: ['परा एवं अपरा प्रकृति', 'चार प्रकार के साधक', 'ईश्वरीय आभा', 'माया तरण'],
    keyVerses: [
      {
        verseNumber: 16,
        sanskrit: 'चतुर्विधा भजन्ते मां जनाः सुकृतिनोऽर्जुन।\nआर्तो जिज्ञासुरर्थार्थी ज्ञानी च भरतर्षभ॥',
        transliteration: 'catur-vidhā bhajante māṁ janāḥ sukṛtino ’rjuna\nārto jijñāsur arthārthī jñānī ca bharatarṣabha',
        translationEnglish: 'Four kinds of noble souls seek Me, O Arjuna: the distressed, the seeker of knowledge, the seeker of prosperity, and the person of wisdom.',
        translationHindi: 'हे भरतवंशी अर्जुन! उत्तम कर्म करने वाले चार प्रकार के मनुष्य मेरा भजन करते हैं—संकटग्रस्त (आर्त), ज्ञान पिपासु (जिज्ञासु), धनार्थी, और ज्ञानी।',
        significanceEn: 'Validates that seeking help in moments of anxiety or distress is a sacred and noble human impulse.',
        significanceHi: 'कठिन समय में शरण और शांति की खोज करना पूर्णतः स्वाभाविक और पवित्र है।',
      },
    ],
  },
  {
    chapterNumber: 8,
    sanskritName: 'अक्षरब्रह्मयोग',
    englishTitle: 'The Yoga of the Imperishable Absolute',
    hindiTitle: 'अक्षरब्रह्मयोग: शाश्वत चेतना और ध्यान',
    verseCount: 28,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'In response to Arjuna’s fundamental questions about Brahman, Karma, and death, Krishna explains the sacred science of conscious living and dying. What one meditates upon throughout life shapes one’s ultimate state of awareness. He describes the path to the supreme unmanifest realm beyond all decay.',
    summaryHi:
      'ब्रह्म, कर्म, अध्यात्म और अंतकाल की चेतना पर अर्जुन के प्रश्नों का समाधान। जीवन भर जिन भावों का चिंतन किया जाता है, अंत समय में वही चेतना उभरती है। ओंकार का स्मरण करते हुए प्राण त्यागने की उच्चतर अवस्था का वर्णन।',
    relevanceEn:
      'What you feed your mind daily becomes your mental default in times of crisis. Habitual mindfulness creates calm resilience under stress.',
    relevanceHi:
      'दैनिक चिंतन ही संकट के समय आपकी शक्ति बनता है। सकारात्मक विचार और निरंतर अभ्यास मानसिक सुरक्षा कवच हैं।',
    keyThemes: ['Mind at Transition', 'The Sacred Om', 'Cyclic Time (Yugas)', 'Imperishable State'],
    keyThemesHi: ['अंतिम चेतना', 'ओंकार साधना', 'काल चक्र', 'अविनाशी पद'],
    keyVerses: [
      {
        verseNumber: 7,
        sanskrit: 'तस्मात्सर्वेषु कालेषु मामनुस्मर युध्य च।\nमय्यर्पितमनोबुद्धिर्मामेवैष्यस्यसंशयम्॥',
        transliteration: 'tasmāt sarveṣu kāleṣu mām anusmara yudhya ca\nmayy arpita-mano-buddhir mām evaiṣyasy asaṁśayaḥ',
        translationEnglish: 'Therefore, remember Me at all times and fight your battle. With your mind and intellect fixed on Me, you shall undoubtedly attain Me.',
        translationHindi: 'इसलिए तुम सब समय में मेरा स्मरण करो और अपना कर्तव्य-युद्ध करो। मुझमें मन और बुद्धि अर्पित करके तुम निःसंदेह मुझे ही प्राप्त होगे।',
        significanceEn: 'The perfect synthesis of practical action and internal peace: engage in life’s challenges while keeping your heart anchored in stillness.',
        significanceHi: 'बाहर कर्तव्य का संघर्ष और भीतर असीम शांति का सुंदर समन्वय।',
      },
    ],
  },
  {
    chapterNumber: 9,
    sanskritName: 'राजविद्याराजगुह्ययोग',
    englishTitle: 'The Sovereign Science & Supreme Secret',
    hindiTitle: 'राजविद्याराजगुह्ययोग: परम विश्वास और सुरक्षा',
    verseCount: 34,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'The crown jewel of spiritual realization. Sri Krishna reveals how the infinite spirit pervades everything yet is untangled by it. He offers the glorious assurance of divine grace: even a simple leaf, flower, fruit, or drop of water offered with pure love is joyfully received, and no sincere seeker ever perishes.',
    summaryHi:
      'ज्ञान का राजा और परम गोपनीय रहस्य। श्रीकृष्ण बताते हैं कि परमात्मा प्रेम का भूखा है। पत्र, पुष्प, फल या जल भी यदि निष्कपट प्रेम से अर्पित किया जाए, तो वह उसे स्वीकार करते हैं। निष्ठावान भक्त का कभी पतन नहीं होता।',
    relevanceEn:
      'Releases feelings of worthlessness and inadequacy. Teaches that intention, love, and sincerity far outweigh lavish, outward perfectionism.',
    relevanceHi:
      'दिखावे और पूर्णतावाद के तनाव से मुक्ति। सच्ची भावना और सादगी ही सबसे बड़ा मूल्य है।',
    keyThemes: ['Sovereign Science', 'Loving Devotion', 'Universal Acceptance', 'Divine Protection (Yoga-Kshema)'],
    keyThemesHi: ['राजविद्या', 'निर्मल प्रेम', 'सबके लिए खुला द्वार', 'योगक्षेम का आश्वासन'],
    keyVerses: [
      {
        verseNumber: 22,
        sanskrit: 'अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते।\nतेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम्॥',
        transliteration: 'ananyāś cintayanto māṁ ye janāḥ paryupāsate\nteṣāṁ nityābhiyuktānāṁ yoga-kṣemaṁ vahāmy aham',
        translationEnglish: 'To those who are ever steadfast in devotion, meditating on Me with unbroken focus, I secure what they lack and preserve what they have.',
        translationHindi: 'जो अनन्य भाव से मेरा निरंतर चिंतन करते हुए भजते हैं, उन नित्य-युक्त पुरुषों के योग और क्षेम (सुरक्षा और संवर्धन) का वहन मैं स्वयं करता हूँ।',
        significanceEn: 'The ultimate comforting pledge against scarcity mindset, chronic insecurity, and existential dread.',
        significanceHi: 'जीवन की सुरक्षा और भरण-पोषण के प्रति असीम विश्वास जगाने वाला वचन।',
      },
      {
        verseNumber: 26,
        sanskrit: 'पत्रं पुष्पं फलं तोयं यो मे भक्त्या प्रयच्छति।\nतदहं भक्त्युपहृतमश्नामि प्रयतात्मनः॥',
        transliteration: 'patraṁ puṣpaṁ phalaṁ toyaṁ yo me bhaktyā prayacchati\ntad ahaṁ bhakty-upahṛtam aśnāmi prayatātmanaḥ',
        translationEnglish: 'Whoever offers to Me with devotion a leaf, a flower, a fruit, or even water, that offering made with love by the pure-hearted, I joyfully accept.',
        translationHindi: 'जो कोई भक्त प्रेमपूर्वक मुझे एक पत्ता, एक फूल, एक फल या केवल जल भी अर्पण करता है, उस शुद्ध चित्त भक्त का वह प्रेम-उपहार मैं स्वीकार करता हूँ।',
        significanceEn: 'Simplicity and heartfelt sincerity outweigh complex, perfectionist expectations.',
        significanceHi: 'सादगी और निर्मल भाव ही सबसे बड़ी संपदा है।',
      },
    ],
  },
  {
    chapterNumber: 10,
    sanskritName: 'विभूतियोग',
    englishTitle: 'The Yoga of Divine Splendors & Grandeur',
    hindiTitle: 'विभूतियोग: सृष्टि में ईश्वरीय ऐश्वर्य',
    verseCount: 42,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'Sri Krishna describes how all majesty, beauty, radiance, and power in the cosmos are sparks of the supreme truth. He is the stillness of the Himalayas, the wisdom of the sage, the radiance of the sun, and the silence of secret wisdom.',
    summaryHi:
      'श्रीकृष्ण अपनी अलौकिक विभूतियों का दिग्दर्शन कराते हैं। पर्वत में हिमालय, वृक्षों में पीपल, प्रकाश में सूर्य और वीरों में अर्जुन वे स्वयं हैं। जहाँ भी कुछ भव्य, सुंदर या शक्तिशाली है, वह उन्हीं का अंश है।',
    relevanceEn:
      'Inspires awe and wonder, which neurobiology shows immediately downregulates anxiety, shrinks acute ego distress, and fosters mental calm.',
    relevanceHi:
      'प्रकृति और ब्रह्मांड की विशालता का अनुभव करने से हमारा अहंकार और दैनिक चिंताएं अत्यंत छोटी प्रतीत होने लगती हैं।',
    keyThemes: ['Universal Splendor', 'Cosmic Wonder', 'Source of All Creativity', 'Awe and Humility'],
    keyThemesHi: ['विभूति दर्शन', 'आश्चर्य और विस्मय', 'समस्त शक्तियों का स्रोत', 'अहंकार की निवृत्ति'],
    keyVerses: [
      {
        verseNumber: 41,
        sanskrit: 'यद़्यद्विभूतिमत्सत्त्वं श्रीमदूर्जितमेव वा।\nतत्तदेवावगच्छ त्वं मम तेजोंऽशसम्भवम्॥',
        transliteration: 'yad yad vibhūtimat sattvaṁ śrīmad ūrjitam eva vā\ntat tad evāvagaccha tvaṁ mama tejo-’ṁśa-sambhavam',
        translationEnglish: 'Whatever being is glorious, prosperous, or mighty, know that to be born of only a fraction of My splendor.',
        translationHindi: 'जो-जो भी ऐश्वर्ययुक्त, कांतियुक्त और शक्ति से संपन्न वस्तु या प्राणी है, उसे तुम मेरे ही तेज के अंश से उत्पन्न हुआ जानो।',
        significanceEn: 'A mindset shift from petty jealousy to celebrating brilliance as an expression of universal magnificence.',
        significanceHi: 'ईर्ष्या छोड़कर दूसरों की प्रतिभा और सुंदरता में परमात्मा का रूप देखने की दृष्टि।',
      },
    ],
  },
  {
    chapterNumber: 11,
    sanskritName: 'विश्वरूपदर्शनयोग',
    englishTitle: 'The Vision of the Cosmic Universal Form',
    hindiTitle: 'विश्वरूपदर्शनयोग: विराट रूप का साक्षात्कार',
    verseCount: 55,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'Arjuna is granted divine sight (Divya Chakshu) to witness the terrifying, awe-inspiring Vishwarupa—all galaxies, suns, gods, time itself, and the destiny of warriors entering the cosmic mouth. Awe-struck and humbled, Arjuna asks for forgiveness and begs Krishna to return to His gentle, beloved form.',
    summaryHi:
      'दिव्य दृष्टि पाकर अर्जुन श्रीकृष्ण के विराट विश्वरूप का दर्शन करते हैं। समस्त ब्रह्मांड, काल चक्र, और भविष्य का प्रवाह उन्हें एक साथ दिखाई देता है। भय और विस्मय से भरकर अर्जुन अपनी क्षमा याचना करते हैं और सौम्य रूप में लौटने की प्रार्थना करते हैं।',
    relevanceEn:
      'Reminds us that time (Kala) is the great leveler. Human arrogance and the illusion of controlling every outcome dissolve when contextualized against eternity.',
    relevanceHi:
      'समय के विराट प्रवाह के सामने हमारी व्यर्थ की हठ और नियंत्रण का भ्रम मिट जाता है। विनम्रता और शांति की प्राप्ति।',
    keyThemes: ['Divine Vision', 'Time as the Great Mover', 'Cosmic Perspective', 'Gentle Compassion'],
    keyThemesHi: ['विराट रूप', 'काल का प्रवाह', 'वैश्विक दृष्टि', 'सौम्य रूप की शरण'],
    keyVerses: [
      {
        verseNumber: 32,
        sanskrit: 'कालोऽस्मि लोकक्षयकृत्प्रवृद्धो लोकान्समाहर्तुमिह प्रवृत्ततः॥',
        transliteration: 'kālo ’smi loka-kṣaya-kṛt pravṛddho lokān samāhartum iha pravṛttaḥ',
        translationEnglish: 'I am Time, the great destroyer of the worlds, engaged here in extinguishing all mortal things.',
        translationHindi: 'मैं लोकों का नाश करने वाला महाकाल हूँ, जो इस समय इन समस्त सेनाओं का संहार करने के लिए प्रवृत्त हुआ हूँ।',
        significanceEn: 'Realizing that all circumstances, both joyful and stressful, are subject to time helps you release clinging.',
        significanceHi: 'सुख और दुःख दोनों ही समय के अधीन हैं—यह बोध मानसिक अनासक्ति देता है।',
      },
    ],
  },
  {
    chapterNumber: 12,
    sanskritName: 'भक्तियोग',
    englishTitle: 'The Yoga of Devotion & Emotional Harmony',
    hindiTitle: 'भक्तियोग: प्रेम, समर्पण और समता',
    verseCount: 20,
    sectionGroup: 'Bhakti Yoga (Ch 7-12)',
    summaryEn:
      'A sweet, concise chapter delineating practical spiritual devotion. Krishna outlines the ladder of spiritual practice: complete absorption, regular meditation, dedication of actions, and renunciation of the anxiety of results. He details the virtues of the devotee dearest to Him—free from malice, forgiving, gentle, and unagitated.',
    summaryHi:
      'अत्यंत मधुर और सुगम अध्याय। श्रीकृष्ण भक्ति और साधना के क्रमिक सोपान बताते हैं। वे अपने प्रिय भक्त के सुंदर लक्षण बताते हैं: जो किसी से द्वेष नहीं करता, जो सबके प्रति दयालु और क्षमाशील है, तथा जो न किसी को उद्वेग देता है और न स्वयं उद्विग्न होता है।',
    relevanceEn:
      'The definitive psychology of emotional health and healthy relationships. Teaches non-reactivity and mutual kindness.',
    relevanceHi:
      'मानसिक स्वास्थ्य और संबंधों में मधुरता का स्वर्णिम सूत्र। न किसी को पीड़ा पहुंचाना और न दूसरों के व्यवहार से स्वयं पीड़ित होना।',
    keyThemes: ['Forgiveness (Kshama)', 'Freedom from Resentment', 'Inner Warmth', 'Unshakable Center'],
    keyThemesHi: ['क्षमा भाव', 'ईर्ष्या और द्वेष से मुक्ति', 'मैत्री और करुणा', 'संतोष'],
    keyVerses: [
      {
        verseNumber: 15,
        sanskrit: 'यस्मान्नोद्विजते लोको लोकान्नोद्विजते च यः।\nहर्षामर्षभयोद्वेगैर्मुक्तो यः स च मे प्रियः॥',
        transliteration: 'yasmān nodvijate loko lokān nodvijate cha yaḥ\nharṣhāmarṣha-bhayodvegair mukto yaḥ sa cha me priyaḥ',
        translationEnglish: 'One by whom the world is not agitated, and who is not agitated by the world, and who is freed from delight, envy, fear, and anxiety—that one is dear to Me.',
        translationHindi: 'जिससे संसार को कोई उद्वेग या भय नहीं होता, और जो स्वयं भी संसार से उद्विग्न नहीं होता, तथा जो हर्ष, अमर्ष, भय और चिंता से मुक्त है, वह मुझे अत्यंत प्रिय है।',
        significanceEn: 'A masterclass in emotional boundaries: staying centered without absorbing toxic environmental stress.',
        significanceHi: 'दूसरों की नकारात्मकता को अपने भीतर प्रवेश न करने देने की अचूक कला।',
      },
    ],
  },
  {
    chapterNumber: 13,
    sanskritName: 'क्षेत्रक्षेत्रज्ञविभागयोग',
    englishTitle: 'The Field & The Knower of the Field',
    hindiTitle: 'क्षेत्रक्षेत्रज्ञविभागयोग: शरीर और साक्षी चेतना',
    verseCount: 35,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'Krishna differentiates between the Field (Kshetra—the body, thoughts, desires, fears, physical senses) and the Knower of the Field (Kshetrajna—the pure, witnessing conscious self). True knowledge is knowing that you are the silent witness, not the agitated physical or mental content.',
    summaryHi:
      'शरीर, मन, इंद्रियां और विकार "क्षेत्र" (खेत) हैं, और इनको जानने वाली साक्षी चेतना "क्षेत्रज्ञ" है। वास्तविक ज्ञान यह समझना है कि हम इन अस्थिर विचारों और विकारों के द्रष्टा हैं, न कि स्वयं विकार।',
    relevanceEn:
      'The root foundation of modern Cognitive Behavioral Therapy (CBT) and defusion: "You are not your thoughts; you are the awareness that observes your thoughts."',
    relevanceHi:
      'आधुनिक मनोविज्ञान का मूल आधार: "आप अपने विचार नहीं हैं, आप उन विचारों को देखने वाली शांत चेतना हैं।"',
    keyThemes: ['Observer vs Content', 'Humility & Non-Violence', 'Witness Consciousness', 'True Wisdom'],
    keyThemesHi: ['साक्षी भाव', 'अहिंसा और सरलता', 'द्रष्टा चेतना', 'विवेक ज्ञान'],
    keyVerses: [
      {
        verseNumber: 27,
        sanskrit: 'समं सर्वेषु भूतेषु तिष्ठन्तं परमेश्वरम्।\nविनश्यत्स्वविनश्यन्तं यः पश्यति स पश्यति॥',
        transliteration: 'samaṁ sarveṣu bhūteṣu tiṣṭhantaṁ parameśvaram\nvinaśyatsv avinaśyantaṁ yaḥ paśyati sa paśyati',
        translationEnglish: 'One who sees the Supreme Truth dwelling equally in all beings, imperishable amid the perishable—that person truly sees.',
        translationHindi: 'जो मनुष्य सब नश्वर प्राणियों में अविनाशी परमात्मा को समभाव से स्थित देखता है, वही वास्तव में सही देखता है।',
        significanceEn: 'Seeing the timeless light in all beings eradicates loneliness, prejudice, and separation anxiety.',
        significanceHi: 'सबके भीतर एक ही शाश्वत प्राण शक्ति का अनुभव करना अकेलेपन को दूर करता है।',
      },
    ],
  },
  {
    chapterNumber: 14,
    sanskritName: 'गुणत्रयविभागयोग',
    englishTitle: 'The Yoga of the Three Gunas (Qualities of Nature)',
    hindiTitle: 'गुणत्रयविभागयोग: सत्व, रज और तम का विज्ञान',
    verseCount: 27,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'A masterly analysis of human psychology. Nature operates through three qualities (Gunas): Sattva (purity, clarity, calmness, light), Rajas (passion, restless craving, greed, agitation), and Tamas (inertia, sloth, darkness, dullness). Krishna teaches how to rise above their pull into serene transcendence (Gunatita).',
    summaryHi:
      'मानव स्वभाव का मनोवैज्ञानिक विश्लेषण। प्रकृति तीन गुणों से संचालित होती है: सत्त्व (प्रकाश, निर्मलता, सुख), रजस् (कामना, लोभ, चंचलता), और तमस् (आलस्य, प्रमाद, अज्ञान)। इन तीनों गुणों से ऊपर उठकर गुणातीत बनने का मार्ग।',
    relevanceEn:
      'Diagnose your current mental state: Is it lethargic inertia (Tamas)? Agitated hustle/anxiety (Rajas)? Or clear, mindful balance (Sattva)? Empowers proactive mood regulation.',
    relevanceHi:
      'अपनी मानसिक स्थिति को पहचानें: क्या यह सुस्ती (तमस) है, बेचैनी (रजस) है, या शांत स्पष्टता (सत्त्व)? मानसिक संतुलन साधने का उपाय।',
    keyThemes: ['Sattva, Rajas, Tamas', 'Transcending Conditioning', 'Recognizing Mood Swings', 'Freedom from Compulsion'],
    keyThemesHi: ['त्रिगुण विज्ञान', 'गुणातीत अवस्था', 'मनोदशा का संतुलन', 'स्वतंत्र चेतना'],
    keyVerses: [
      {
        verseNumber: 22,
        sanskrit: 'प्रकाशं च प्रवृत्तिं च मोहमेव च पाण्डव।\nन द्वेष्टि सम्प्रवृत्तानि न निवृत्तानि काङ्क्षति॥',
        transliteration: 'prakāśaṁ ca pravṛttiṁ ca moham eva ca pāṇḍava\nna dveṣṭi sampravṛttāni na nivṛttāni kāṅkṣati',
        translationEnglish: 'One who does not hate illumination, activity, or delusion when they arise, nor longs for them when they cease—that person is said to have transcended the gunas.',
        translationHindi: 'जो प्रकाश (सत्त्व), प्रवृत्ति (रजस्), और मोह (तमस्) के प्रकट होने पर उनसे द्वेष नहीं करता और उनके निवृत्त होने पर उनकी लालसा नहीं करता, वह गुणातीत कहलाता है।',
        significanceEn: 'Radical non-judgmental acceptance of mental weather patterns without self-punishment.',
        significanceHi: 'मन की अवस्थाओं को बिना लड़े शांत भाव से देखना और तटस्थ रहना।',
      },
    ],
  },
  {
    chapterNumber: 15,
    sanskritName: 'पुरुषोत्तमयोग',
    englishTitle: 'The Yoga of the Supreme Divine Person',
    hindiTitle: 'पुरुषोत्तमयोग: संसार-वृक्ष और परम चेतना',
    verseCount: 20,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'Sri Krishna uses the profound ancient metaphor of the inverted Ashvattha tree (with roots above in spirit and branches below in worldly experience). He urges us to cut this entangling tree with the strong axe of detachment, and reveals the supreme transcendent reality that illumines all minds.',
    summaryHi:
      'ऊर्ध्वमूल वाले अश्वत्थ (पीपल) रूपी संसार-वृक्ष का रहस्यमय रूपक। इसे वैराग्य रूपी दृढ़ कुल्हाड़ी से काटकर उस परम पद की खोज करने का आह्वान, जहाँ पहुँचकर कोई लौटता नहीं। वही परमात्मा सबका पोषण करने वाला पुरुषोत्तम है।',
    relevanceEn:
      'Reminds us that outward attachments and worldly validations are mere branches. Rooting yourself in your true inner essence cures insecurity and fear of loss.',
    relevanceHi:
      'बाहरी प्रशंसा और वस्तुओं की क्षणभंगुरता को पहचानकर अपनी आंतरिक शक्ति से जुड़ना।',
    keyThemes: ['The Cosmic Inverted Tree', 'Axe of Non-Attachment', 'Inner Light', 'Purushottama'],
    keyThemesHi: ['संसार वृक्ष', 'वैराग्य का शस्त्र', 'अंतरज्योति', 'पुरुषोत्तम तत्त्व'],
    keyVerses: [
      {
        verseNumber: 15,
        sanskrit: 'सर्वस्य चाहं हृदि सन्निविष्टो मत्तः स्मृतिर्ज्ञानमपोहनं च॥',
        transliteration: 'sarvasya cāhaṁ hṛdi sanniviṣṭo mattaḥ smṛtir jñānam apohanaṁ ca',
        translationEnglish: 'I am seated in the hearts of all living beings; from Me arise memory, knowledge, and their loss.',
        translationHindi: 'मैं ही समस्त प्राणियों के हृदय में अंतर्यामी रूप से स्थित हूँ; मुझसे ही स्मृति, ज्ञान और उनका अभाव होता है।',
        significanceEn: 'Reassurance that wisdom, calm, and clarity reside within your own heart, accessible in any moment.',
        significanceHi: 'सच्चा मार्गदर्शन और शक्ति आपके अपने ही हृदय में स्थित है।',
      },
    ],
  },
  {
    chapterNumber: 16,
    sanskritName: 'दैवासुरसम्पद्विभागयोग',
    englishTitle: 'The Divine & Demonic Qualities',
    hindiTitle: 'दैवासुरसम्पद्विभागयोग: दैवी और आसुरी प्रवृत्तियाँ',
    verseCount: 24,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'A sharp moral contrast between constructive, liberating virtues (Fearlessness, purity of heart, charity, self-restraint, gentle speech, forgiveness) and destructive, toxic traits (Arrogance, wrath, harshness, deceit, insatiable greed). Krishna identifies lust, anger, and greed as the three ruinous gates to darkness.',
    summaryHi:
      'सकारात्मक मुक्तिदायक सद्गुणों (अभय, अंतःकरण की शुद्धि, अहिंसा, सत्य, अक्रोध, शांति) और विनाशकारी दुर्गुणों (दंभ, घमंड, क्रोध, कठोरता) का स्पष्ट भेद। काम, क्रोध और लोभ को आत्मा का नाश करने वाले तीन प्रमुख द्वार बताया गया है।',
    relevanceEn:
      'Provides a diagnostic ethical mirror. Protects against narcissistic impulses, toxic aggression, and ethical burnout.',
    relevanceHi:
      'अपने स्वभाव का निष्पक्ष मूल्यांकन। क्रोध, अहंकार और लोभ से बचकर जीवन में निर्भयता और सरलता अपनाना।',
    keyThemes: ['Fearlessness (Abhayam)', 'The Three Poisonous Gates', 'Inner Integrity', 'Cultivating Nobility'],
    keyThemesHi: ['अभय', 'काम-क्रोध-लोभ', 'सदाचार', 'सद्गुणों का विकास'],
    keyVerses: [
      {
        verseNumber: 1,
        sanskrit: 'अभयं सत्त्वसंशुद्धिर्ज्ञानयोगव्यवस्थितिः।\nदानं दमश्च यज्ञश्च स्वाध्यायस्तप आर्जवम्॥',
        transliteration: 'abhayaṁ sattva-saṁśuddhir jñāna-yoga-vyavasthitiḥ\ndānaṁ damaś ca yajñaś ca svādhyāyas tapa ārjavam',
        translationEnglish: 'Fearlessness, purity of heart, steadfastness in knowledge, charity, self-control, sacrifice, study of wisdom, austerity, and uprightness...',
        translationHindi: 'भय का सर्वथा अभाव (अभय), अंतःकरण की पूर्ण शुद्धि, ज्ञानयोग में निरंतर स्थिति, दान, इंद्रिय-संयम, स्वाध्याय, और सरलता...',
        significanceEn: 'Fearlessness (Abhayam) is ranked as the foremost spiritual virtue, the bedrock of all peace and self-actualization.',
        significanceHi: 'समस्त सद्गुणों में "अभय" (निर्भयता) को प्रथम स्थान देकर जीवन की नींव बनाया गया है।',
      },
      {
        verseNumber: 21,
        sanskrit: 'त्रिविधं नरकस्येदं द्वारं नाशनमात्मनः।\nकामः क्रोधस्तथा लोभस्तस्मादेतत्त्रयं त्यजेत्॥',
        transliteration: 'tri-vidhaṁ narakasyedaṁ dvāraṁ nāśanam ātmanaḥ\nkāmaḥ krodhas tathā lobhas tasmād etat trayaṁ tyajet',
        translationEnglish: 'Threefold is the gate to self-ruin and misery: lust, anger, and greed. Therefore, one must abandon these three.',
        translationHindi: 'काम, क्रोध और लोभ—ये आत्मा का पतन करने वाले नरक के तीन द्वार हैं। इसलिए इन तीनों का त्याग कर देना चाहिए।',
        significanceEn: 'A timeless warning against reactive impulsivity, rage, and insatiable consumerist craving.',
        significanceHi: 'क्रोध और लोभ के जाल में फंसकर अपना विवेक न खोने की चेतावनी।',
      },
    ],
  },
  {
    chapterNumber: 17,
    sanskritName: 'श्रद्धात्रयविभागयोग',
    englishTitle: 'The Threefold Faith & Mindful Living',
    hindiTitle: 'श्रद्धात्रयविभागयोग: श्रद्धा, आहार और विचार',
    verseCount: 28,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'Krishna explains how human faith, food habits, charity, and discipline are shaped by the three Gunas. Pure (Sattvic) food promotes longevity, vitality, strength, and joy. He defines the discipline of speech: words that cause no agitation, are truthful, pleasant, beneficial, and rooted in wisdom.',
    summaryHi:
      'मनुष्य की श्रद्धा, आहार, दान और तप के तीन भेदों की व्याख्या। सात्त्विक भोजन आयु, बुद्धि, बल, स्वास्थ्य और सुख को बढ़ाने वाला होता है। वाणी का तप: ऐसे शब्द जो किसी को उद्वेग न दें, जो सत्य, प्रिय और हितकारी हों। "ॐ तत्सत्" का रहस्य।',
    relevanceEn:
      'Mindful speech and conscious nourishment: directly links gut-health and what we consume to our mental clarity and emotional serenity.',
    relevanceHi:
      'आहार और वाणी का मानसिक स्वास्थ्य से सीधा संबंध। शांत, सत्य और प्रिय बोलने का अभ्यास जो विवादों को समाप्त करता है।',
    keyThemes: ['Mindful Nutrition', 'Discipline of Speech (Vak-Tapas)', 'Om Tat Sat', 'Living in Harmony'],
    keyThemesHi: ['सात्त्विक आहार', 'वाणी की शुद्धि', 'ॐ तत् सत्', 'संतुलित जीवन'],
    keyVerses: [
      {
        verseNumber: 15,
        sanskrit: 'अनुद्वेगकरं वाक्यं सत्यं प्रियहितं च यत्।\nस्वाध्यायाभ्यसनं चैव वाङ्मयं तप उच्यते॥',
        transliteration: 'anudvega-karaṁ vākyaṁ satyaṁ priya-hitaṁ ca yat\nsvādhyāyābhyasanaṁ caiva vāṅmayaṁ tapa ucyate',
        translationEnglish: 'Speech that causes no agitation, that is truthful, pleasant, and beneficial, and the regular practice of studying wisdom—this is called the austerity of speech.',
        translationHindi: 'जो वाक्य किसी को उद्वेग न पहुंचाने वाला हो, जो सत्य, प्रिय और हितकारक हो, तथा स्वाध्याय का नियमित अभ्यास हो—यही वाणी का तप कहलाता है।',
        significanceEn: 'The golden rule of communication: speak what is true, kind, non-provocative, and helpful.',
        significanceHi: 'संवाद और भाषा की शुद्धता का स्वर्णिम नियम जो संबंधों को बिखरने से बचाता है।',
      },
    ],
  },
  {
    chapterNumber: 18,
    sanskritName: 'मोक्षसंन्यासयोग',
    englishTitle: 'The Yoga of Liberation Through Surrender',
    hindiTitle: 'मोक्षसंन्यासयोग: संन्यास, शरणागति और परम मुक्ति',
    verseCount: 78,
    sectionGroup: 'Jnana Yoga (Ch 13-18)',
    summaryEn:
      'The grand synthesis and climax of the Gita. Krishna clarifies the true definition of Tyaga (abandoning fruit of action, not the action itself). He analyzes knowledge, action, intellect, and resolve through the three Gunas. Finally, with infinite love, He speaks His parting promise: surrender all borrowed burdens and take refuge in Truth alone; He will deliver you from all fear. Arjuna rises, his doubts shattered, fully ready to act.',
    summaryHi:
      'संपूर्ण गीता का उपसंहार और भव्य शिखर। त्याग का वास्तविक अर्थ समझाते हुए श्रीकृष्ण कर्म के फल की आसक्ति छोड़ने को सच्चा त्याग कहते हैं। वे अपना सबसे गुप्त और प्रिय वचन कहते हैं: "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज"—सब चिंताओं को छोड़कर मेरी शरण में आओ, मैं तुम्हें समस्त भयों से मुक्त कर दूँगा। अर्जुन का संशय समाप्त होता है और वे विजय पथ पर अग्रसर होते हैं।',
    relevanceEn:
      'The supreme antidote to paralyzing decision-anxiety and existential fear. Giving your highest effort, surrendering the result, and moving forward with quiet, unshakeable courage.',
    relevanceHi:
      'भय, असमंजस और भारीपन से पूर्ण मुक्ति। सब बोझ परमात्मा को सौंपकर शांत चित्त और निर्भय होकर कर्तव्य पथ पर आगे बढ़ना।',
    keyThemes: ['True Renunciation (Tyaga)', 'Three Types of Resolve (Dhriti)', 'Final Promise', 'Shattered Doubt (Nashto Mohah)'],
    keyThemesHi: ['सच्चा त्याग', 'धृति और निश्चय', 'परम शरणागति', 'मोह का नाश'],
    keyVerses: [
      {
        verseNumber: 66,
        sanskrit: 'सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज।\nअहं त्वां सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः॥',
        transliteration: 'sarva-dharmān parityajya mām ekaṁ śaraṇaṁ vraja\nahaṁ tvāṁ sarva-pāpebhyo mokṣayiṣyāmi mā śucaḥ',
        translationEnglish: 'Abandoning all secondary notions of duty, take refuge in Me alone. I shall liberate you from all distress and negativity; grieve not!',
        translationHindi: 'सब धर्मों और चिंताओं को मुझमें समर्पित करके केवल मेरी ही शरण में आ जाओ। मैं तुम्हें समस्त बंधनों और संतापों से मुक्त कर दूँगा, शोक मत करो!',
        significanceEn: 'The supreme reassurance in the entire Gita: surrender false burdens of total control and rest in tranquil trust.',
        significanceHi: 'गीता का परम आश्वस्तकारी श्लोक: नियंत्रण का झूठा बोझ छोड़ें और शांत विश्वास में विश्राम करें।',
      },
      {
        verseNumber: 73,
        sanskrit: 'नष्टो मोहः स्मृतिर्लब्धा त्वत्प्रसादान्मयाच्युत।\nस्थितोऽस्मि गतसन्देहः करिष्ये वचनं तव॥',
        transliteration: 'naṣṭo mohaḥ smṛtir labdhā tvat-prasādān mayācyuta\nsthito ’smi gata-sandehaḥ kariṣye vacanaṁ tava',
        translationEnglish: 'My delusion is destroyed! I have regained my clear memory through Your grace, O Infallible One. I stand firm, with all doubts dispelled. I shall act according to Your word.',
        translationHindi: 'हे अच्युत! आपकी कृपा से मेरा मोह नष्ट हो गया और मुझे आत्म-स्मृति प्राप्त हो गई है। अब मैं संशयरहित होकर स्थिर हूँ और आपकी आज्ञा का पालन करूँगा।',
        significanceEn: 'The triumphant return of clarity, resolve, and purposeful action after mental paralysis.',
        significanceHi: 'संशय और भय का अंत होकर दृढ निश्चय और शांति से कर्तव्य में प्रवृत्त होने का क्षण।',
      },
    ],
  },
];
