export type StressCategory =
  | 'Work Pressure'
  | 'Overthinking'
  | 'Fear of Failure'
  | 'Uncertainty'
  | 'Conflict'
  | 'Money Worries'
  | 'Family Pressure'
  | 'Feeling Overwhelmed'
  | 'Anger'
  | 'Comparison'
  | 'Lack of Motivation'
  | 'Relationship Stress'
  | 'Career Uncertainty'
  | 'Grief & Loss'
  | 'Loneliness'
  | 'Health & Illness'
  | 'Guilt & Regret'
  | 'Decision Paralysis'
  | 'Sleep & Exhaustion'
  | 'Purpose & Inner Peace'
  | 'Other';

export type GitaPrinciple =
  | 'Karma Yoga (Focus on Action)'
  | 'Equanimity (Samatvam)'
  | 'Steadiness of Mind (Sthitaprajna)'
  | 'Self-Mastery & Anger Regulation'
  | 'Svadharma (Authentic Duty)'
  | 'Disciplined Action (Abhyasa)'
  | 'Present-Focused Action'
  | 'Non-Attachment (Vairagya)'
  | 'Soul Immortality & Release of Grief'
  | 'Divine Fellowship & Love'
  | 'Endurance of Transience (Titiksha)'
  | 'Surrender of Past Guilt (Sharanagati)'
  | 'Clarity of Intellect (Buddhi Yoga)'
  | 'Balanced Living (Yukta-Ahara-Vihara)';

export type VerificationStatus =
  | 'VERIFIED_CANONICAL'
  | 'REQUIRES_EXPERT_REVIEW';

export interface Verse {
  id: string;
  chapter: number;
  verseNumber: number;
  sanskrit: string;
  transliteration: string;
  translationEnglish: string;
  translationHindi: string;
  primaryConcept: GitaPrinciple;
  secondaryConcepts: string[];
  stressCategories: StressCategory[];
  practicalInterpretation: string;
  caution: string;
  source: string;
  verificationStatus: VerificationStatus;
}

export interface ResetExercise {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  category: 'Breathing' | 'Cognitive' | 'Action' | 'Emotional Regulation';
  instructions: string[];
  linkedConcept: GitaPrinciple;
  suitableFor: StressCategory[];
  caution?: string;
}

export interface JournalEntry {
  id: string;
  createdAt: string;
  stressCategory: StressCategory;
  userInput: string;
  stressBefore: number; // 1 to 5
  verseId?: string;
  verseReference?: string;
  concept: string;
  actionTaken: string;
  reflection: string;
  stressAfter?: number; // 1 to 5
}

export interface GuidanceResult {
  understanding: string;
  perspectiveConcept: GitaPrinciple;
  perspectiveExplanation: string;
  verse: Verse;
  whatThisMeansForYou: string;
  action: {
    title: string;
    steps: string[];
    timerMinutes?: number;
  };
  reflectionQuestion: string;
  matchedCategory: StressCategory;
}

export interface CrisisResource {
  country: string;
  serviceName: string;
  contact: string;
  description: string;
  available: string;
  isTel?: boolean;
}

export interface SafetyCheckResult {
  isCrisis: boolean;
  reason?: string;
  detectedTerms?: string[];
  resources: CrisisResource[];
}

export interface ChapterKeyVerse {
  verseNumber: number;
  sanskrit: string;
  transliteration: string;
  translationEnglish: string;
  translationHindi: string;
  significanceEn: string;
  significanceHi: string;
}

export interface GitaChapter {
  chapterNumber: number;
  sanskritName: string;
  englishTitle: string;
  hindiTitle: string;
  verseCount: number;
  sectionGroup: 'Karma Yoga (Ch 1-6)' | 'Bhakti Yoga (Ch 7-12)' | 'Jnana Yoga (Ch 13-18)';
  summaryEn: string;
  summaryHi: string;
  relevanceEn: string;
  relevanceHi: string;
  keyThemes: string[];
  keyThemesHi: string[];
  keyVerses: ChapterKeyVerse[];
}

export interface UserPreferences {
  language: 'en' | 'hi'; // Written text / UI language (default: 'en')
  spokenLanguage?: 'hi' | 'en'; // Spoken audio / voice narration language (default: 'hi')
  theme: 'light' | 'dark' | 'system';
  dailyReminderEnabled: boolean;
  reminderTime: string; // e.g. "08:00"
}

export interface FullGitaVerse {
  id: string; // e.g. "2.47"
  chapter: number;
  verse: number;
  sanskrit: string;
  transliteration: string;
  wordMeanings?: string;
  hindi: string;
  english: string;
}

export interface ReadingProgress {
  lastReadChapter: number;
  lastReadVerse: number;
  readVerseIds: string[]; // List of "chapter.verse" strings, e.g. ["1.1", "1.2", "2.47"]
  lastReadTimestamp: number;
}

