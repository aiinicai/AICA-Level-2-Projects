import { VERIFIED_VERSES } from '../data/verses';
import { GitaPrinciple, GuidanceResult, StressCategory, Verse } from '../types';
import { checkSafety } from './safetyService';

interface GuidanceRequest {
  userInput: string;
  categoryChip?: StressCategory;
  stressIntensity?: number; // 1-5
}

/**
 * Rule-based intelligent stress classifier with bilingual (English & Hindi) keyword matching.
 * Matches explicit user chips and free-form typed problems to authentic canonical categories.
 */
export function classifyStress(input: string, chip?: StressCategory): StressCategory {
  const text = (input || '').toLowerCase().trim();

  // 1. Explicit user chip takes precedence if not 'Other'
  if (chip && chip !== 'Other') {
    return chip;
  }

  // 2. If user typed custom text or selected 'Other', examine text with rich bilingual matching
  if (text.length > 0) {
    // A. Explicit mention of unlisted / other problems
    if (/(other problem|other issue|different problem|something else|not listed|another issue|अन्य समस्या|अन्य परेशानी|कुछ और)/i.test(text)) {
      return 'Other';
    }

    // B. Grief, Bereavement, Mourning & Loss
    if (/(grief|loss|mourn|died|death|passed away|bereave|funeral|heartbroken|lost someone|sorrow|tearful|crying|शोक|विछोह|निधन|मृत्यु|चले गए|खो दिया|रोना|उदास|बिछड़|मातम|दुख)/i.test(text)) {
      return 'Grief & Loss';
    }

    // C. Loneliness, Isolation & Feeling Unseen
    if (/(lonely|alone|isolated|isolation|nobody cares|no friends|abandoned|disconnected|solitude|emptiness|alienat|अकेला|अकेलापन|सूनापन|कोई नहीं है|उपेक्षा|तन्हा)/i.test(text)) {
      return 'Loneliness';
    }

    // D. Health, Chronic Illness & Physical Pain
    if (/(health|sick|illness|pain|ache|disease|doctor|hospital|physical|injury|chronic|body|fever|medical|headache|stomach|migraine|बीमारी|रोग|दर्द|शरीर|अस्वस्थ|स्वास्थ्य|पीड़ा|दवा|तबीयत)/i.test(text)) {
      return 'Health & Illness';
    }

    // E. Sleep, Insomnia, Burnout & Exhaustion
    if (/(sleep|insomnia|cannot sleep|nightmare|restless night|exhaust|tired|fatigue|drained|burn out|burnout|lethargic|low energy|sleepless|नींद|सो नहीं|थकान|अनिद्रा|सुस्ती|ऊब|थकावट)/i.test(text)) {
      return 'Sleep & Exhaustion';
    }

    // F. Guilt, Regret, Remorse & Past Blame
    if (/(guilt|regret|ashamed|shame|made a mistake|blunder|remorse|forgive myself|fault|blame|confess|sin|self-hate|hate myself|पछतावा|गलती|ग्लानि|अपराधबोध|क्षमा|दोष|पाप|प्रायश्चित)/i.test(text)) {
      return 'Guilt & Regret';
    }

    // G. Decision Paralysis, Confusion & Crossroads
    if (/(decision|confused|dilemma|choice|choose|which path|crossroad|doubt|unsure|stuck between|can'?t decide|paralyzed by choice|निर्णय|फैसला|असमंजस|क्या करूं|संशय|दुविधा|चुनाव)/i.test(text)) {
      return 'Decision Paralysis';
    }

    // H. Purpose, Meaning of Life & Spiritual Seeking
    if (/(purpose|meaning of life|who am i|spiritual|inner peace|soul|god|meditation|truth|peace of mind|calm|existential|hopelessness|empty inside|शांति|उद्देश्य|आत्मा|जीवन का अर्थ|परमात्मा|ध्यान|सत्य|मुक्ति)/i.test(text)) {
      return 'Purpose & Inner Peace';
    }

    // I. Anger, Rage, Temper & Frustration
    if (/(angry|furious|rage|temper|irritat|infuriat|mad at|hate|resent|frustrat|गुस्सा|क्रोध|चिड़चिड़ा|नाराज|आक्रोश|रोष|झुंझलाहट)/i.test(text)) {
      return 'Anger';
    }

    // J. Conflict, Arguments, Disputes & Toxicity
    if (/(conflict|fight|argument|screaming|dispute|yelling|hostile|quarrel|toxic|clash|blaming me|disagree|झगड़ा|लड़ाई|बहस|विवाद|आहत|क्लेश|मतभेद|तकरार)/i.test(text)) {
      return 'Conflict';
    }

    // K. Relationship Stress, Love, Heartbreak & Divorce
    if (/(relationship|partner|husband|wife|boyfriend|girlfriend|breakup|broken up|marriage|divorce|cheated|cheating|betray|affair|ex-|love life|संबंध|साथी|पति|पत्नी|विवाह|प्रेम|तलाक|धोखा|रिश्ता)/i.test(text)) {
      return 'Relationship Stress';
    }

    // L. Career Uncertainty, Job Search & Direction
    if (/(career|job offer|layoff|laid off|fired|switch job|profession|calling|resignation|interview|curriculum|नौकरी|करियर|रोजगार|दफ्तर का संशय|पेशा)/i.test(text)) {
      return 'Career Uncertainty';
    }

    // M. Fear of Failure & Exam/Performance Anxiety
    if (/(fail|failure|embarrass|mistake|ruin|mess up|afraid I will|fear of failing|rejection|exam|test|grade|score|marks|defeated|lose|असफल|फेल|परीक्षा|हार|डर|भय|हारने का डर)/i.test(text)) {
      return 'Fear of Failure';
    }

    // N. Work Pressure, Deadlines & Boss
    if (/(deadline|boss|manager|workload|presentation|client|office|meeting|project|promotion|target|overtime|काम का दबाव|टारगेट|बॉस|कार्यक्षेत्र|असाइनमेंट)/i.test(text)) {
      return 'Work Pressure';
    }

    // O. Overthinking, Racing Thoughts & Rumination
    if (/(overthinking|racing thoughts|spiraling|can'?t stop thinking|loop in my head|obsessing|rumination|racing mind|mind won'?t stop|अति-विचार|ज्यादा सोचना|विचारों का चक्र|बेचैनी|दिमाग चलना)/i.test(text)) {
      return 'Overthinking';
    }

    // P. Feeling Overwhelmed & Crushing Demands
    if (/(overwhelm|too much to do|drowning|suffocating|crushing|can'?t handle|burden|heavy|heavy heart|exhausted with everything|भारीपन|बोझ|बहुत ज्यादा|दबाव|दम घुटना)/i.test(text)) {
      return 'Feeling Overwhelmed';
    }

    // Q. Uncertainty, Unknown Future & Ambiguity
    if (/(uncertain|don'?t know what will happen|unpredictable|future anxiety|ambiguity|future|what next|अनिश्चितता|भविष्य की चिंता|अज्ञात|आगे क्या होगा)/i.test(text)) {
      return 'Uncertainty';
    }

    // R. Comparison & Envy
    if (/(compare|comparing|everyone else is ahead|behind in life|jealous|envy|benchmarks|peer pressure|ईर्ष्या|जलन|तुलना|पीछे छूट|होड़|दूसरों से तुलना)/i.test(text)) {
      return 'Comparison';
    }

    // S. Lack of Motivation & Procrastination
    if (/(procrastinat|stuck|no motivation|lack of motivation|can'?t start|unmotivated|lazy|sloth|inertia|आलस्य|मन नहीं लगता|टालमटोल|प्रेरणा|उदासीन|रुकावट)/i.test(text)) {
      return 'Lack of Motivation';
    }

    // T. Money & Financial Stress
    if (/(money|financial|debt|bills|expenses|salary|broke|savings|loan|poverty|rent|cost|पैसा|धन|आर्थिक|कर्ज|खर्चा|वेतन|गरीबी|किराया)/i.test(text)) {
      return 'Money Worries';
    }

    // U. Family Pressure & Relatives
    if (/(family|parents|relatives|in-laws|mother|father|expectations from family|mom|dad|brother|sister|परिवार|माता|पिता|सास|ससुराल|रिश्तेदार|कुटुंब)/i.test(text)) {
      return 'Family Pressure';
    }

    // V. General Distress / Depression / Sadness
    if (/(sad|depressed|depression|hopeless|unhappy|miserable|down|troubled|suffering|दुखी|परेशान|हताश|निराश|कष्ट)/i.test(text)) {
      return 'Other';
    }
  }

  // 3. Fallback to chip if provided
  if (chip) {
    return chip;
  }

  // 4. Default for unclassified or other problems
  return 'Other';
}

/**
 * Maps StressCategory to the most therapeutic Bhagavad Gita principle.
 */
export function mapCategoryToPrinciple(category: StressCategory): GitaPrinciple {
  switch (category) {
    case 'Work Pressure':
      return 'Karma Yoga (Focus on Action)';
    case 'Fear of Failure':
      return 'Equanimity (Samatvam)';
    case 'Overthinking':
      return 'Steadiness of Mind (Sthitaprajna)';
    case 'Anger':
    case 'Conflict':
      return 'Self-Mastery & Anger Regulation';
    case 'Uncertainty':
      return 'Equanimity (Samatvam)';
    case 'Comparison':
      return 'Svadharma (Authentic Duty)';
    case 'Lack of Motivation':
      return 'Disciplined Action (Abhyasa)';
    case 'Feeling Overwhelmed':
      return 'Present-Focused Action';
    case 'Money Worries':
      return 'Present-Focused Action';
    case 'Family Pressure':
      return 'Svadharma (Authentic Duty)';
    case 'Relationship Stress':
      return 'Self-Mastery & Anger Regulation';
    case 'Career Uncertainty':
      return 'Clarity of Intellect (Buddhi Yoga)';
    case 'Grief & Loss':
      return 'Soul Immortality & Release of Grief';
    case 'Loneliness':
      return 'Divine Fellowship & Love';
    case 'Health & Illness':
      return 'Endurance of Transience (Titiksha)';
    case 'Guilt & Regret':
      return 'Surrender of Past Guilt (Sharanagati)';
    case 'Decision Paralysis':
      return 'Clarity of Intellect (Buddhi Yoga)';
    case 'Sleep & Exhaustion':
      return 'Balanced Living (Yukta-Ahara-Vihara)';
    case 'Purpose & Inner Peace':
      return 'Steadiness of Mind (Sthitaprajna)';
    case 'Other':
    default:
      return 'Steadiness of Mind (Sthitaprajna)';
  }
}

/**
 * Selects an authentic canonical verse from the verified database.
 * NEVER fabricated or hallucinations. Ensures varied, context-specific results
 * rather than statically falling back to BG 2.47 for "Other" or unlisted queries.
 */
export function findCuratedVerse(category: StressCategory, principle: GitaPrinciple, offset = 0): Verse {
  // 1. If category is 'Other' or unlisted, provide diverse, foundational life wisdom verses
  // (BG 6.5, BG 2.14, BG 9.22, BG 18.66, BG 2.70, BG 4.38, BG 18.63)
  // CRITICAL: BG 2.47 is NEVER returned for 'Other' or general unlisted issues.
  if (category === 'Other') {
    const otherVerses = VERIFIED_VERSES.filter((v) => v.stressCategories.includes('Other') && v.id !== 'bg-2-47');
    if (otherVerses.length > 0) {
      return otherVerses[offset % otherVerses.length];
    }
  }

  // 2. Specific tailored priority overrides to avoid 2.47 dominating multi-category matches:
  if (category === 'Fear of Failure') {
    // For Fear of Failure, prioritize BG 2.48 (Samatvam in success & failure), BG 2.38, BG 18.47, BG 6.5
    const failureVerses = VERIFIED_VERSES.filter(
      (v) => v.stressCategories.includes('Fear of Failure') && v.id !== 'bg-2-47'
    );
    if (failureVerses.length > 0) {
      return failureVerses[offset % failureVerses.length];
    }
  }

  if (category === 'Feeling Overwhelmed') {
    // For Overwhelmed, prioritize BG 2.70 (Ocean of stillness), BG 18.58 (Crossing all obstacles), BG 6.16-17, BG 6.19
    const overwhelmVerses = VERIFIED_VERSES.filter(
      (v) => v.stressCategories.includes('Feeling Overwhelmed') && v.id !== 'bg-2-47'
    );
    if (overwhelmVerses.length > 0) {
      return overwhelmVerses[offset % overwhelmVerses.length];
    }
  }

  if (category === 'Overthinking') {
    // For Overthinking, prioritize BG 6.26 (Gentle restraint of wandering mind), BG 6.5, BG 2.70
    const overthinkingVerses = VERIFIED_VERSES.filter(
      (v) => v.stressCategories.includes('Overthinking') && v.id !== 'bg-2-47'
    );
    if (overthinkingVerses.length > 0) {
      return overthinkingVerses[offset % overthinkingVerses.length];
    }
  }

  // 3. Exact match on stressCategory
  const matchingCategory = VERIFIED_VERSES.filter((v) => v.stressCategories.includes(category));
  if (matchingCategory.length > 0) {
    return matchingCategory[offset % matchingCategory.length];
  }

  // 4. Match on primaryConcept
  const matchingPrinciple = VERIFIED_VERSES.filter((v) => v.primaryConcept === principle && v.id !== 'bg-2-47');
  if (matchingPrinciple.length > 0) {
    return matchingPrinciple[offset % matchingPrinciple.length];
  }

  // 5. Ultimate fallback: cycle through universally comforting life verses without defaulting to 2.47
  const fallbackVerses = VERIFIED_VERSES.filter((v) => v.id !== 'bg-2-47');
  return fallbackVerses[offset % fallbackVerses.length] || VERIFIED_VERSES[1];
}

/**
 * Core Guidance Service
 * 
 * Provides calm, verified Bhagavad Gita guidance tailored to everyday stress.
 * Works 100% offline out-of-the-box.
 * 
 * AI EXTENSION NOTE:
 * When connecting to Gemini via server route (`/api/guidance`), this function can
 * provide the system prompt:
 * "You are an empathetic, grounded philosopher-mentor. The user is experiencing [Category].
 * Use ONLY the canonical verse BG [Ch].[V]. Summarize their problem in 2-3 empathetic non-diagnostic
 * sentences, explain the practical Gita principle in 100-180 words, give one concrete action,
 * and provide one self-reflection question. DO NOT INVENT VERSES."
 */
export async function getGuidance(
  request: GuidanceRequest,
  perspectiveOffset = 0
): Promise<{ safetyAlert?: boolean; result?: GuidanceResult }> {
  // 1. Safety check is absolute prerequisite
  const safety = checkSafety(request.userInput);
  if (safety.isCrisis) {
    return { safetyAlert: true };
  }

  // 2. Classify Stress Category
  const category = classifyStress(request.userInput, request.categoryChip);

  // 3. Map to Gita Principle
  const principle = mapCategoryToPrinciple(category);

  // 4. Retrieve canonical verified verse
  const verse = findCuratedVerse(category, principle, perspectiveOffset);

  // 5. Generate tailored empathetic understanding & practical action
  const result = generateTailoredGuidance(request.userInput, category, principle, verse);

  return { safetyAlert: false, result };
}

function generateTailoredGuidance(
  userInput: string,
  category: StressCategory,
  principle: GitaPrinciple,
  verse: Verse
): GuidanceResult {
  const hasText = userInput && userInput.trim().length > 8;

  // Section A: Empathetic understanding (2-3 sentences, non-diagnostic)
  let understanding = '';
  if (hasText && userInput.toLowerCase().includes('presentation')) {
    understanding =
      'You seem to be spending significant mental energy anticipating how tomorrow’s presentation will be received. That anticipatory worry makes preparation feel more exhausting than the work itself.';
  } else if (hasText && userInput.toLowerCase().includes('deadline')) {
    understanding =
      'You are carrying the combined pressure of multiple pressing deadlines alongside the fear of making a costly mistake. Your attention may be shifting away from the immediate task toward what might go wrong.';
  } else {
    switch (category) {
      case 'Work Pressure':
        understanding =
          'You are carrying an intense workload where expectations and deadlines feel compressed. When the mind constantly evaluates how bosses, clients, or colleagues will react, work feels twice as exhausting as it truly is.';
        break;
      case 'Fear of Failure':
        understanding =
          'You are experiencing heavy outcome-anxiety where the anticipation of falling short or being judged paralyzes your confidence. The Gita reminds us that outcomes fluctuate, but your dignity and sincerity remain untouchable.';
        break;
      case 'Overthinking':
        understanding =
          'You are caught in a mental loop where the mind continuously replays "what-if" scenarios without finding resolution. This mental spinning drains your vital energy even when you are sitting completely still.';
        break;
      case 'Anger':
        understanding =
          'You are dealing with an intense internal heat where a perceived wrong or friction has triggered an urgent impulse to retaliate or vent. That surge narrows your vision and threatens your hard-earned composure.';
        break;
      case 'Conflict':
        understanding =
          'You are experiencing relational friction where sharp words or misunderstandings have left you feeling defensive or wounded. The mind naturally wants to win the argument, even at the cost of peace.';
        break;
      case 'Relationship Stress':
        understanding =
          'You are navigating emotional turbulence in a relationship where affection, expectations, or trust have experienced friction. Pain in relationships touches our deepest vulnerabilities, making patience feel demanding.';
        break;
      case 'Uncertainty':
        understanding =
          'You are facing a crossroad where critical variables remain invisible and outside your direct command. When the future is opaque, the mind instinctively attempts to solve problems that do not yet exist.';
        break;
      case 'Comparison':
        understanding =
          'You seem to be measuring your current life stage against someone else’s highlight reel. That comparison creates an illusion of falling behind and obscures the authentic path that belongs solely to you.';
        break;
      case 'Feeling Overwhelmed':
        understanding =
          'You are facing an avalanche of demands landing simultaneously, leaving you unsure of where to place your feet. When everything screams for top priority, the nervous system naturally freezes in paralysis.';
        break;
      case 'Grief & Loss':
        understanding =
          'You are enduring the profound ache of loss where something or someone deeply cherished is no longer physically present. Grief is the sacred testimony of love, and your sadness deserves gentle, honoring space.';
        break;
      case 'Loneliness':
        understanding =
          'You are feeling an isolating ache of disconnection, as though you are walking this road completely unseen and unsupported. The Gita gently reminds you that the supreme conscious presence is forever holding you within.';
        break;
      case 'Health & Illness':
        understanding =
          'You are coping with physical discomfort, illness, or bodily vulnerability that tests your mental patience. Physical suffering is tough, yet your deepest conscious Self remains untouched by bodily sensations.';
        break;
      case 'Guilt & Regret':
        understanding =
          'You are carrying the crushing weight of past remorse or a painful mistake that your mind will not let you put down. Self-condemnation only freezes growth; sincere renewal and self-compassion heal the heart.';
        break;
      case 'Decision Paralysis':
        understanding =
          'You are standing before multiple paths, terrified that choosing one will permanently ruin the other. Seeking absolute certainty before acting traps you in stagnation; clarity emerges through courageous steps.';
        break;
      case 'Sleep & Exhaustion':
        understanding =
          'Your nervous system has been running on high alert for too long without deep restorative rest. When the mind is depleted, every minor task feels like an insurmountable hill.';
        break;
      case 'Purpose & Inner Peace':
        understanding =
          'You are feeling an existential emptiness or a longing for deeper meaning beyond the repetitive surface rituals of daily survival. This sacred discontent is an invitation to discover your true spiritual ground.';
        break;
      case 'Career Uncertainty':
        understanding =
          'You are questioning your professional direction or feeling insecure about job stability and career growth. Trusting your authentic gifts is far wiser than forcing yourself into a mold that violates your nature.';
        break;
      case 'Money Worries':
        understanding =
          'You are experiencing economic anxiety where bills, scarcity thoughts, or unexpected expenses threaten your sense of security. Scarcity panic clouds resourceful thinking; calm prudence restores agency.';
        break;
      case 'Lack of Motivation':
        understanding =
          'You are feeling an emotional numbness or inertia where taking even the first step feels heavy and meaningless. Motivation is not a precondition for action; tiny, gentle movements awaken inner momentum.';
        break;
      case 'Family Pressure':
        understanding =
          'You are bearing the heavy weight of family expectations and traditions that conflict with your personal peace. Fulfilling family duties with love does not require abandoning your authentic integrity.';
        break;
      case 'Other':
      default:
        understanding =
          'You are encountering a life situation that brings mental friction, uncertainty, or emotional heaviness. The timeless wisdom of the Gita offers a grounded anchor to steady your inner compass today.';
    }
  }

  // Section B: Gita Perspective Explanation
  let perspectiveExplanation = '';
  switch (principle) {
    case 'Karma Yoga (Focus on Action)':
      perspectiveExplanation =
        'Karma Yoga teaches the liberation of total commitment to the effort while deliberately surrendering attachment to the scoreboard. You own your effort; results belong to the cosmic order.';
      break;
    case 'Equanimity (Samatvam)':
      perspectiveExplanation =
        'Equanimity (Samatvam) is the supreme art of maintaining an unshakeable inner balance whether today brings victory or defeat, praise or critique. Your worth is never decided by external fluctuations.';
      break;
    case 'Steadiness of Mind (Sthitaprajna)':
      perspectiveExplanation =
        'Steadiness of Mind invites you to become like an ocean reservoir. Noisy surface currents and incoming demands arrive, but your foundational depth remains untouched and still.';
      break;
    case 'Self-Mastery & Anger Regulation':
      perspectiveExplanation =
        'Self-Mastery interrupts the destructive mechanical chain reaction from hurt to fury to self-ruin. Inserting a conscious pause preserves your personal dignity and protects your long-term peace.';
      break;
    case 'Svadharma (Authentic Duty)':
      perspectiveExplanation =
        'Svadharma is your authentic calling and natural responsibility. The moment you stop borrowing other people’s scripts and walk your honest path, the exhausting poison of comparison dissolves.';
      break;
    case 'Disciplined Action (Abhyasa)':
      perspectiveExplanation =
        'Disciplined Action relies on gentle, patient repetition (Abhyasa). Instead of waiting for fleeting waves of motivation, you perform one small micro-action to awaken clarity.';
      break;
    case 'Soul Immortality & Release of Grief':
      perspectiveExplanation =
        'The Gita reveals that physical bodies change like worn garments, but the radiant, conscious soul (Atman) is eternal and unbreakable. Love and spirit never perish; let this truth soothe your grieving heart.';
      break;
    case 'Divine Fellowship & Love':
      perspectiveExplanation =
        'Sri Krishna assures us that the Divine is intimately seated within the heart of every being. You are never an isolated speck adrift in a cold cosmos; you are eternally seen, held, and cherished.';
      break;
    case 'Endurance of Transience (Titiksha)':
      perspectiveExplanation =
        'Titiksha is the patient, dignified endurance of transient sensations—heat and cold, pleasure and pain. Remembering that every storm has a beginning and an end frees you from panic.';
      break;
    case 'Surrender of Past Guilt (Sharanagati)':
      perspectiveExplanation =
        'Sri Krishna’s ultimate promise is "Mā Śhucaḥ" (Do not grieve!). The moment you turn toward truth and sincere action, all past mistakes are surrendered into grace. Put down the stone of guilt.';
      break;
    case 'Clarity of Intellect (Buddhi Yoga)':
      perspectiveExplanation =
        'Buddhi Yoga is applying refined, values-grounded intellect. When faced with crossroads, reflect deeply (Vimrishya), gather wisdom, and step forward with conscious, courageous freedom.';
      break;
    case 'Balanced Living (Yukta-Ahara-Vihara)':
      perspectiveExplanation =
        'Yoga is the destroyer of sorrow when life is lived with temperance: balanced food, balanced rest, rhythmic sleep, and purposeful work. Honoring your biological container heals your mental state.';
      break;
    case 'Present-Focused Action':
    default:
      perspectiveExplanation =
        'The Bhagavad Gita reminds you that peace is not the absence of difficulty; it is the presence of grounded clarity right in the center of life’s responsibilities.';
  }

  // Section D: What This Means for You (100–180 words, practical everyday language)
  const whatThisMeansForYou =
    verse.practicalInterpretation ||
    `This teaching invites you to separate your immediate agency from the turbulent waves of external circumstances. Worrying about variables outside your direct control drains vital energy away from your real life. When you anchor yourself in the present moment and perform your duty with sincerity, an extraordinary sense of calm emerges. You do not need to resolve every mystery of tomorrow right now; simply take the next honest, compassionate step.`;

  // Section E: Try This Now (Tailored practical action with steps & timer)
  let action = {
    title: '2-Minute Centering Practice',
    steps: [
      'Take three slow, conscious breaths, feeling your chest expand and settle.',
      'Acknowledge the situation you are facing without judging yourself for feeling strained.',
      'Separate what lies directly in your hands right now from what belongs to the outer world.',
      'Take one small, grounded action with full presence, releasing all outcome anxiety.'
    ],
    timerMinutes: 10,
  };

  if (category === 'Fear of Failure' || (hasText && userInput.toLowerCase().includes('exam'))) {
    action = {
      title: 'Equanimity Reset: Victory & Setback Alike',
      steps: [
        'Write down the worst possible scenario you fear regarding this outcome.',
        'Silently remind yourself: "Win or lose, success or delay, my core dignity and worth remain whole."',
        'Identify the single preparation step you can do right now with steady focus.',
        'Work on that preparation for 15 minutes, completely ignoring the scoreboard.'
      ],
      timerMinutes: 15,
    };
  } else if (category === 'Feeling Overwhelmed') {
    action = {
      title: 'Ocean of Stillness: The Single-Task Anchor',
      steps: [
        'Close or minimize every open window and app except the immediate one you need.',
        'Write down the one single 5-minute task that will give you the cleanest entry point.',
        'Visualize your mind as a vast, quiet ocean that easily absorbs incoming river waves.',
        'Focus exclusively on that single task until the 10-minute timer sounds.'
      ],
      timerMinutes: 10,
    };
  } else if (category === 'Anger' || category === 'Conflict') {
    action = {
      title: '60-Second Reaction Buffer',
      steps: [
        'Physically step back from your screen, phone, or the other person right now.',
        'Unclench your jaw, soften your shoulders, and take 3 deep, cooling abdominal breaths.',
        'Ask yourself: "Will speaking in this heated state bring peace, or only escalate regret?"',
        'Institute a mandatory 5-minute pause before sending any response.'
      ],
      timerMinutes: 5,
    };
  } else if (category === 'Grief & Loss') {
    action = {
      title: 'Sacred Soul Connection & Loving Breath',
      steps: [
        'Place a gentle hand on your heart and close your eyes in a quiet space.',
        'Allow whatever tears or grief arise to flow without suppression or self-judgment.',
        'Remember that the spirit and love you shared are eternal, transcending physical form.',
        'Send a silent prayer or thought of gratitude and peace into the boundless cosmos.'
      ],
      timerMinutes: 8,
    };
  } else if (category === 'Loneliness') {
    action = {
      title: 'Inner Fellowship Communion',
      steps: [
        'Sit comfortably, feel your feet on the ground, and notice the rhythm of your breathing.',
        'Recognize that you are never truly alone; the Divine Presence witnesses your every breath.',
        'Speak to your own heart as you would speak to a deeply loved friend.',
        'Send one kind, unprompted message of appreciation or care to someone you know.'
      ],
      timerMinutes: 5,
    };
  } else if (category === 'Health & Illness') {
    action = {
      title: 'Titiksha Fortitude & Body Healing Pause',
      steps: [
        'Lie down or sit comfortably with your head and spine gently supported.',
        'Breathe into the area of tension or discomfort without fighting or resisting the sensation.',
        'Silently remind yourself: "This body experiences temporary sensation, but my inner peace is whole."',
        'Drink a warm glass of water or tea and grant yourself permission to rest without guilt.'
      ],
      timerMinutes: 12,
    };
  } else if (category === 'Guilt & Regret') {
    action = {
      title: 'Surrender into Grace (Mā Śhucaḥ)',
      steps: [
        'Write down the past mistake or guilt that has been haunting your thoughts.',
        'Read Sri Krishna’s promise aloud: "Mā Śhucaḥ—Do not grieve; surrender it into truth."',
        'Mentally release that past moment, recognizing that you cannot rewrite yesterday.',
        'Commit to one clean, honest, kind action today as your living renewal.'
      ],
      timerMinutes: 7,
    };
  } else if (category === 'Decision Paralysis' || category === 'Career Uncertainty') {
    action = {
      title: 'Buddhi Clarity: The 3-Column Decision Grid',
      steps: [
        'Write down your top 2 competing choices on a fresh piece of paper.',
        'List which choice aligns best with your deepest inner values (Dharma), not just temporary ego.',
        'Acknowledge that no choice is 100% risk-free, and that growth happens through courage.',
        'Make the best decision you can right now, and dedicate the outcome to the higher truth.'
      ],
      timerMinutes: 12,
    };
  } else if (category === 'Sleep & Exhaustion') {
    action = {
      title: 'Digital Sunset & Restorative Wind-Down',
      steps: [
        'Turn off bright screens or switch to warm night mode; dim the room lights.',
        'Take 5 long exhales, making each out-breath twice as long as the in-breath.',
        'Mentally deposit all of today’s unfinished tasks into a mental drawer until tomorrow.',
        'Repeat the sacred phrase "Shanti, Shanti, Shanti" as you settle into restorative rest.'
      ],
      timerMinutes: 15,
    };
  } else if (category === 'Purpose & Inner Peace') {
    action = {
      title: 'The Silent Reservoir: Reconnecting with the Self',
      steps: [
        'Step away from social media, notifications, and chatter for 10 minutes.',
        'Sit quietly and ask: "Who is the peaceful awareness observing these transient thoughts?"',
        'Reflect on one core value that genuinely makes your heart feel alive and purposeful.',
        'Dedicate one small act of selfless service or generosity to someone today.'
      ],
      timerMinutes: 10,
    };
  } else if (category === 'Relationship Stress') {
    action = {
      title: 'Compassionate Boundary & Maitri Pause',
      steps: [
        'Take a 5-minute break from interaction to let your emotional pulse settle.',
        'Separate the person from their momentary reaction or unkind words.',
        'Clarify what you need to express with dignity, free from passive aggression or blame.',
        'Communicate your boundary or feelings with calm, honest firmness.'
      ],
      timerMinutes: 10,
    };
  }

  // Section F: Reflection Question
  let reflectionQuestion = 'Am I working on my immediate duty right now, or am I mentally rehearsing the result?';
  if (category === 'Comparison') {
    reflectionQuestion = 'Whose benchmarks am I measuring myself against right now, and why do I give them authority over my worth?';
  } else if (category === 'Anger' || category === 'Conflict') {
    reflectionQuestion = 'Am I reacting to protect my fragile ego, or am I responding to protect my enduring peace?';
  } else if (category === 'Uncertainty') {
    reflectionQuestion = 'What is one grounded truth about my immediate surroundings right now that I can feel grateful for?';
  } else if (category === 'Overthinking') {
    reflectionQuestion = 'Is this spinning thought a verified fact, or a catastrophic prediction made by an anxious mind?';
  } else if (category === 'Grief & Loss') {
    reflectionQuestion = 'How can I honor the love and memory of what departed through kindness in my life today?';
  } else if (category === 'Loneliness') {
    reflectionQuestion = 'Can I allow this quiet solitude to become a sacred sanctuary for deep self-friendship?';
  } else if (category === 'Health & Illness') {
    reflectionQuestion = 'Can I offer gentle patience to my physical body today, remembering that sensation is impermanent?';
  } else if (category === 'Guilt & Regret') {
    reflectionQuestion = 'What would change today if I accepted Sri Krishna’s invitation to put down my guilt and start anew?';
  } else if (category === 'Decision Paralysis') {
    reflectionQuestion = 'Which path allows me to act with the greatest sincerity, integrity, and courage?';
  } else if (category === 'Purpose & Inner Peace') {
    reflectionQuestion = 'What is one meaningful truth that truly matters to my soul when all outer noise fades away?';
  } else if (category === 'Other') {
    reflectionQuestion = 'What is the single most constructive step within my direct agency right now?';
  }

  return {
    understanding,
    perspectiveConcept: principle,
    perspectiveExplanation,
    verse,
    whatThisMeansForYou,
    action,
    reflectionQuestion,
    matchedCategory: category,
  };
}

/**
 * Log user feedback on guidance results for future personalization
 */
export function logFeedback(verseId: string, feedbackType: 'helped' | 'not_relevant'): void {
  try {
    const key = 'geeta_gyan_feedback';
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    existing.push({
      verseId,
      feedbackType,
      timestamp: new Date().toISOString(),
    });
    localStorage.setItem(key, JSON.stringify(existing));
  } catch {
    // LocalStorage fallback
  }
}
