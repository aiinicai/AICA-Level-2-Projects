import { StressCategory, GitaPrinciple, Verse } from '../types';

export interface DialogScene {
  title: string;
  titleHindi: string;
  speaker: 'Lord Krishna' | 'Arjuna';
  speakerHindi: string;
  textEn: string;
  textHi: string;
  cameraAngle: 'wide' | 'krishna' | 'arjuna' | 'divine';
}

export type SceneTheme =
  | 'radiant-gold'
  | 'calm-ocean'
  | 'cooling-twilight'
  | 'peaceful-green'
  | 'sacred-violet'
  | 'grounded-amber';

export interface CinematicScriptPackage {
  issueBadgeEn: string;
  issueBadgeHi: string;
  theme: SceneTheme;
  scenes: DialogScene[];
}

/**
 * Clean and summarize user input to weave smoothly into Arjuna's dialogue
 */
function sanitizeUserInputSnippet(input: string, maxLen = 120): string {
  if (!input) return '';
  const cleaned = input
    .trim()
    .replace(/^(i am|i'm|i feel|i have|feeling)\s+/i, '')
    .replace(/[.!?]+$/, '');
  if (cleaned.length <= maxLen) return cleaned;
  return cleaned.substring(0, maxLen).trim() + '...';
}

/**
 * Builds rich, fully customized Kurukshetra cinematic dialogues
 * that directly reflect the user's specific problem, chosen category,
 * and the canonical Bhagavad Gita verse assigned.
 */
export function generateCinematicScript(params: {
  category: StressCategory;
  principle: GitaPrinciple;
  verseRef: string;
  chapter: number;
  verseNumber: number;
  userInput?: string;
  guidanceUnderstanding?: string;
  whatThisMeansForYou?: string;
  verse?: Verse;
}): CinematicScriptPackage {
  const {
    category,
    verseRef,
    userInput = '',
    guidanceUnderstanding = '',
    whatThisMeansForYou = '',
    verse,
  } = params;

  const rawText = (userInput || '').toLowerCase().trim();
  const userSnippet = sanitizeUserInputSnippet(userInput);
  const verseMeaningEn = verse?.practicalInterpretation || whatThisMeansForYou || 'Equanimity of mind in all circumstances';
  const verseTranslationHi = verse?.translationHindi || 'अपने कर्तव्य को निष्ठापूर्वक करो और फल की आसक्ति त्यागो।';

  // 1. SPECIFIC SUB-TOPIC DETECTION (Takes highest priority if user typed specific real-life issues)

  // A. Exams, Interviews, Presentations, Academic & Assessment Anxiety
  if (/(exam|test|interview|grade|score|marks|presentation|assessment|quiz|entrance|prelims|viva|audition)/i.test(rawText)) {
    const detailEn = userSnippet ? `this testing trial regarding "${userSnippet}"` : 'this upcoming examination and trial of evaluation';
    const detailHi = userSnippet ? `इस परीक्षा और मूल्यांकन (${userSnippet})` : 'इस कठिन परीक्षा और मूल्यांकन';
    return {
      issueBadgeEn: 'Academic & Assessment Pressure • Overcoming Exam Fear',
      issueBadgeHi: 'परीक्षा और साक्षात्कार का भय • एकाग्रता और आत्म-विश्वास',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Trial of Assessment',
          titleHindi: 'कठिन परीक्षा का संशय',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, my heart trembles before ${detailEn}. The dread of falling short, failing expectations, and facing harsh judgment paralyzes my hands. What if all my sincere preparation is not enough?`,
          textHi: `हे माधव! ${detailHi} के भय से मेरा मन कांप रहा है। यदि मैं असफल हुआ और अपेक्षाओं पर खरा न उतरा, तो क्या होगा? परिणाम के भय से मेरी बुद्धि शिथिल हो रही है।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'Mastery Over Preparation',
          titleHindi: 'परिणाम के मोह से मुक्ति',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, outcome-anxiety divides your intellect. You possess sovereign agency over your sincere preparation and quiet focus today, but never over tomorrow’s final scoreboard. Do not let future imagined failure steal your present strength.',
          textHi: 'हे पार्थ! परिणाम की चिंता तुम्हारी बुद्धि को विभक्त कर रही है। तुम्हारा अधिकार केवल तुम्हारी सच्ची तैयारी और निष्ठा में है, परीक्षा के अंकों में कभी नहीं। भविष्य की कल्पना में अपने वर्तमान का पुरुषार्थ मत खोओ।',
          cameraAngle: 'krishna',
        },
        {
          title: `Equanimity in Performance • ${verseRef}`,
          titleHindi: `समत्व योग का प्रकाश • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Established in the wisdom of ${verseRef}: Regard success and delay with an even mind. Pour your entire being into each question and each task with calm joy; this steady composure is true Yoga.`,
          textHi: `स्मरण करो ${verseRef} का दिव्य संदेश: सिद्धि और असिद्धि में समान भाव रखकर शांत मन से परीक्षा दो। समत्व बुद्धि ही कर्म की वास्तविक कुशलता है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Fearless Execution',
          titleHindi: 'निर्भय होकर कर्म करो',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! Silence the noisy fear of judgment. Walk into your trial with peaceful dignity and courage. Give your honest best, and rest secure in Truth.',
          textHi: 'उठो, हे धनंजय! संशय का त्याग करो। शांत विश्वास के साथ परीक्षा कक्ष में प्रवेश करो और अपना सर्वश्रेष्ठ दो; विजय तुम्हारे अंतःकरण में है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // B. Job Loss, Layoffs, Career Crisis & Unemployment
  if (/(laid off|layoff|lost job|fired|unemployed|unemployment|career crisis|resigned|no job|interview rejection)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Career Disruption & Job Loss • Rebuilding with Courage',
      issueBadgeHi: 'नौकरी का संकट और करियर • नव-संकल्प और आत्म-विश्वास',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Shattered Livelihood',
          titleHindi: 'आजीविका का संकट',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, my professional ground has crumbled beneath my feet. With the loss of my livelihood, feelings of worthlessness, humiliation, and terror for the future cloud my soul.',
          textHi: 'हे माधव! आजीविका छिन जाने से मेरे पैरों तले जमीन खिसक गई है। असहायता और भविष्य के अंधकार से मेरा मन व्याकुल है; मैं स्वयं को असमर्थ अनुभव कर रहा हूँ।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'Your Worth Beyond a Title',
          titleHindi: 'पद से परे तुम्हारी क्षमता',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, a company title or position was merely an outer role you played; it was never your true essence. Your intellect, resilience, and sacred capability remain completely intact within you.',
          textHi: 'हे पार्थ! कोई पद या नौकरी तुम्हारी पहचान नहीं थी; वह केवल एक बाह्य भूमिका थी। तुम्हारा विवेक, सामर्थ्य और अंतर्निहित शक्ति आज भी तुम्हारे भीतर अक्षुण्ण है।',
          cameraAngle: 'krishna',
        },
        {
          title: `The Eternal Provider • ${verseRef}`,
          titleHindi: `योगक्षेम और नव-आरंभ • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Heed the divine assurance of ${verseRef}: When one door closes, the universe opens the gateway to your higher potential. Do not dwell in shame; channel your energy into purposeful renewal.`,
          textHi: `स्मरण करो ${verseRef}: जब एक द्वार बंद होता है, तो परमात्मा तुम्हारी उन्नति के नए मार्ग खोलता है। शोक मत करो; अपनी ऊर्जा को नए पुरुषार्थ में लगाओ।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Arise and Rebuild',
          titleHindi: 'नव-निर्माण का आह्वान',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, noble warrior! Dust off your shoulders. Craft your next steps with calm strategy and persistent courage. You are meant for greater things; move forward without hesitation.',
          textHi: 'उठो, हे धनंजय! निराशा की धूल झाड़कर खड़े हो जाओ। शांत बुद्धि से नए अवसरों की ओर कदम बढ़ाओ; तुम्हारी प्रतिभा को कोई रोक नहीं सकता।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // C. In-laws, Marriage Pressure, Relatives, Family Expectations
  if (/(in-laws|mother-in-law|father-in-law|sasural|forced marriage|marriage pressure|relatives|taunts|family expectation)/i.test(rawText) || category === 'Family Pressure') {
    const familyContextEn = userSnippet ? `these familial trials regarding "${userSnippet}"` : 'the suffocating expectations, judgments, and taunts from family';
    const familyContextHi = userSnippet ? `परिजनों और संबंधियों के दबाव (${userSnippet})` : 'परिजनों के ताने, भारी अपेक्षाएं और दबाव';
    return {
      issueBadgeEn: 'Family & In-Laws Friction • Preserving Dignity & Svadharma',
      issueBadgeHi: 'पारिवारिक दबाव और संबंध • आत्म-सम्मान और स्वधर्म',
      theme: 'grounded-amber',
      scenes: [
        {
          title: 'The Weight of Expectations',
          titleHindi: 'पारिवारिक अपेक्षाओं का भार',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, my soul suffocates under ${familyContextEn}. I fear causing painful disappointment, yet living someone else's bitter script is crushing my spirit.`,
          textHi: `हे माधव! ${familyContextHi} से मेरा हृदय घुट रहा है। अपनों को आहत किए बिना मैं अपनी शांति और आत्म-सम्मान की रक्षा कैसे करूं?`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'Svadharma over Borrowed Scripts',
          titleHindi: 'स्वधर्म और मर्यादा',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, honoring your relatives with courteous respect does not require you to sacrifice your soul’s truth. Living to please others’ unending demands leads only to sorrow.',
          textHi: 'हे पार्थ! परिजनों का सम्मान करना आवश्यक है, किन्तु दूसरों की अनुचित मांगों की वेदी पर अपनी अंतरात्मा की बलि देना धर्म नहीं है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Your Sacred Path • ${verseRef}`,
          titleHindi: `स्वधर्मे निधनं श्रेयः • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Remember ${verseRef}: Better is one’s own duty, though performed with simplicity, than the borrowed path of another. Fulfill your natural duty with calm boundaries.`,
          textHi: `स्मरण करो ${verseRef}: दूसरों के दबाव में जीने की अपेक्षा अपने स्वभाव और मर्यादा के अनुसार चलना ही श्रेष्ठ है। शांत चित्त से अपनी सीमाएं निर्धारित करो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Dignified Composure',
          titleHindi: 'शांत आत्म-सम्मान',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! Respond with soft spoken words but an unshakable inner spine. Serve with genuine kindness, while protecting the sacred temple of your inner peace.',
          textHi: 'उठो, हे अर्जुन! विनम्र वाणी किन्तु अडिग आत्म-बल के साथ खड़े रहो। कटुता का उत्तर मौन और मर्यादा से दो; तुम्हारी आंतरिक शांति ही तुम्हारी शक्ति है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // D. Relationship Heartbreak, Betrayal, Breakup, Marriage Conflict
  if (category === 'Relationship Stress' || /(breakup|broken up|cheated|cheating|divorce|partner|husband|wife|boyfriend|girlfriend|unfaithful|betrayal|toxic relationship|ex-)/i.test(rawText)) {
    const relDetailEn = userSnippet ? `the heartbreak of "${userSnippet}"` : 'broken trust and deep heartache in my relationship';
    const relDetailHi = userSnippet ? `संबंधों के इस आघात (${userSnippet})` : 'विश्वासघात और बिछोह के इस असह्य दर्द';
    return {
      issueBadgeEn: 'Relationship Heartbreak & Conflict • Reclaiming Wholeness',
      issueBadgeHi: 'संबंधों का क्लेश और विश्वासघात • आंतरिक पूर्णता',
      theme: 'sacred-violet',
      scenes: [
        {
          title: 'The Wounded Heart',
          titleHindi: 'संबंध और आहत हृदय',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${relDetailEn} has pierced my spirit. The affection I gave has been met with cold pain, betrayal, and distance. I feel shattered and rejected.`,
          textHi: `हे मधुसूदन! ${relDetailHi} ने मेरे हृदय को छलनी कर दिया है। जिसे मैंने अपना सब कुछ माना, उसी से मुझे असह्य पीड़ा मिली है; मैं बिखर गया हूँ।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Illusion of External Completeness',
          titleHindi: 'आसक्ति और अपेक्षा का भ्रम',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, human minds are volatile and transient. When you place the anchor of your entire self-worth into another mortal person, every wave will drown you. Your wholeness is already within.',
          textHi: 'हे पार्थ! संसार के संबंध परिवर्तनशील हैं। अपनी आत्मा की शांति को किसी और के स्वभाव पर निर्भर मत करो। तुम स्वयं में पूर्ण और अमूल्य हो।',
          cameraAngle: 'krishna',
        },
        {
          title: `Compassionate Freedom • ${verseRef}`,
          titleHindi: `द्वेष से मुक्ति और आत्म-गौरव • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Embody ${verseRef}: Release the poison of resentment and obsessive longing. Let go of what was never yours to possess, and stand in your untouched divinity.`,
          textHi: `धारण करो ${verseRef} का पावन विवेक: प्रतिशोध और आत्म-दया के विष को त्यागो। जो बीत गया उसे क्षमा करो और आत्म-सम्मान के साथ आगे बढ़ो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Arise in Sovereign Dignity',
          titleHindi: 'आत्म-सम्मान का सूर्योदय',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, noble soul! No person possesses the power to diminish your divine light unless you hand them the key. Close this painful chapter, forgive, and walk forward in peace.',
          textHi: 'उठो, हे धनंजय! अपनी गरिमा को पुनः प्राप्त करो। अतीत की जंजीरों को तोड़ो; सच्चा प्रेम और शांति तुम्हारे ही भीतर प्रतीक्षा कर रहे हैं।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // E. Health, Illness, Chronic Pain, Medical Anxiety
  if (category === 'Health & Illness' || /(health|sick|illness|pain|ache|disease|hospital|physical|injury|chronic|body|fever|medical|headache|migraine|surgery|cancer|doctor)/i.test(rawText)) {
    const healthContextEn = userSnippet ? `this physical suffering (${userSnippet})` : 'bodily agony and physical vulnerability';
    const healthContextHi = userSnippet ? `इस शारीरिक व्याधि (${userSnippet})` : 'शारीरिक पीड़ा और दुर्बलता';
    return {
      issueBadgeEn: 'Health & Physical Resilience • The Immortal Observer',
      issueBadgeHi: 'स्वास्थ्य और शारीरिक पीड़ा • तितिक्षा और आत्म-बल',
      theme: 'peaceful-green',
      scenes: [
        {
          title: 'The Fragility of the Vessel',
          titleHindi: 'शारीरिक दुर्बलता और पीड़ा',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${healthContextEn} has shaken my body and strength. My limbs tremble with distress, and physical suffering is casting a dark shadow over my mind.`,
          textHi: `हे माधव! ${healthContextHi} ने मेरी देह को दुर्बल कर दिया है। इस वेदना से मेरा मन भी भयभीत हो रहा है और शांति छिन गई है।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Transience of Physical Sensations',
          titleHindi: 'तितिक्षा और देह-बोध',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Bharata, sensations of pain and comfort, heat and cold, are temporary visitors that come and go. Endure them with patient fortitude (Titiksha), knowing you are not just this garment of flesh.',
          textHi: 'हे भारत! सुख और दुःख, सर्दी और गर्मी की तरह शारीरिक वेदना भी अनित्य है। देह का उपचार करो, किन्तु मन को भय और संताप से मुक्त रखो।',
          cameraAngle: 'krishna',
        },
        {
          title: `The Untouched Soul • ${verseRef}`,
          titleHindi: `अविनाशी आत्म-स्वरूप • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Anchor in ${verseRef}: The body may experience temporary infirmity, but your eternal conscious soul remains whole, pure, and untouched by disease.`,
          textHi: `स्मरण करो ${verseRef}: देह रोगग्रस्त हो सकती है, किन्तु तुम्हारी अंतरात्मा अजर, अमर और दिव्य है। अपने आत्म-स्वरूप में स्थिर रहो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Fortitude & Healing',
          titleHindi: 'धैर्य और नवजीवन',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rest your body, take your medicine with quiet faith, and breathe deep healing light. Your inner spirit is greater than any physical affliction; endure with grace.',
          textHi: 'शांत चित्त से शरीर का उपचार करो, मन में भय मत आने दो। तुम्हारा आत्म-बल हर व्याधि से बड़ा है; धैर्य और विश्वास रखो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // F. Grief, Mourning, Death of a Loved One
  if (category === 'Grief & Loss' || /(grief|mourn|died|death|passed away|bereave|funeral|lost someone|lost my father|lost my mother|departed)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Grief & Bereavement • Eternal Immortality of the Soul',
      issueBadgeHi: 'शोक और प्रियजन का वियोग • आत्मा की अमरता',
      theme: 'sacred-violet',
      scenes: [
        {
          title: 'The Piercing Sorrow',
          titleHindi: 'शोक का गहन अंधकार',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, tears blind my eyes and an agonizing void fills my chest. My beloved has departed from this mortal realm, leaving an unbearable silence behind.',
          textHi: 'हे माधव! आंसुओं से मेरी दृष्टि धुंधली है। मेरे प्रियजन मुझे छोड़कर चले गए हैं; इस असह्य शोक और रिक्तता को मैं कैसे सहन करूं?',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Eternal Truth of the Spirit',
          titleHindi: 'शाश्वत सत्य का प्रकाश',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, you grieve for that which cannot truly die. Just as a person casts off worn-out garments to put on new ones, the soul casts off mortal bodies and continues its eternal journey.',
          textHi: 'हे पार्थ! तुम उनके लिए शोक करते हो जो कभी नष्ट नहीं होते। जैसे मनुष्य पुराने वस्त्र त्यागकर नए वस्त्र धारण करता है, वैसे ही आत्मा नई यात्रा पर अग्रसर होती है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Love Transcends Form • ${verseRef}`,
          titleHindi: `मा शुचः • शोक से मुक्ति • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Taught in ${verseRef}: The soul was never born, nor does it ever perish. The pure bond of love and consciousness you shared transcends physical boundaries forever.`,
          textHi: `स्मरण करो ${verseRef}: न जायते म्रियते वा कदाचित्—आत्मा न कभी जन्मती है, न कभी मरती है। तुम्हारा प्रेम देह की सीमाओं से परे सदा जीवित है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Honor Their Memory with Courage',
          titleHindi: 'मा शुचः • कर्तव्य पथ पर आगे बढ़ो',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Mā Śhucaḥ—Do not grieve, Partha! Honor their cherished memory by living a noble, kind, and courageous life. Carry their blessing in your heart and rise.',
          textHi: 'मा शुचः—शोक मत करो! उनके आशीर्वाद को अपने हृदय में धारण करो और प्रेमपूर्वक अपने धर्म और कर्तव्य का पालन करो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // G. Loneliness, Isolation, Abandonment
  if (category === 'Loneliness' || /(lonely|alone|isolated|nobody cares|no friends|abandoned|disconnected|solitude)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Loneliness & Solitude • The Ever-Present Divine Companion',
      issueBadgeHi: 'अकेलापन और एकांत • हृदयस्थ परमात्मा का सहारा',
      theme: 'sacred-violet',
      scenes: [
        {
          title: 'The Solitary Void',
          titleHindi: 'अकेलेपन की व्यथा',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, an isolating coldness surrounds my days. In this crowded world, I feel utterly alone and forgotten, with no one to truly listen to my heart.',
          textHi: 'हे माधव! अकेलापन मेरे प्राणों को साल रहा है। इस विशाल संसार में मुझे लगता है कि मैं नितांत अकेला हूँ और कोई मुझे नहीं समझता।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Unfailing Witness Within',
          titleHindi: 'हृदयस्थ परम सखा',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, you are never alone for a single breath. I am seated in the deepest chamber of your heart as your eternal witness, constant guardian, and truest friend.',
          textHi: 'हे पार्थ! तुम कभी अकेले नहीं हो। तुम्हारे अंतःकरण में मैं नित्य निवास करता हूँ। समस्त सृष्टि की प्रेममयी शक्ति सदैव तुम्हारे साथ है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Universal Fellowship • ${verseRef}`,
          titleHindi: `दिव्य संगति का ज्ञान • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `As revealed in ${verseRef}: He who sees the Divine in all beings and all beings in the Divine is never separated. Solitude is your sacred sanctuary to know yourself.`,
          textHi: `स्मरण करो ${verseRef}: जो मुझे सबमें देखता है और सब कुछ मुझमें देखता है, वह कभी अकेला नहीं होता। एकांत को आत्म-शांति का साधन बनाओ।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Step Forth in Connection',
          titleHindi: 'सद्भाव और नव-आरंभ',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arise, dear friend! Let go of the feeling of lack. Open your heart to the world, offer quiet kindness to someone in need today, and discover fellowship all around you.',
          textHi: 'उठो, हे सखा! अकेलेपन के भ्रम को त्यागो। निस्वार्थ प्रेम से संसार से जुड़ो और दृढ़ विश्वास के साथ आगे बढ़ो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // H. Guilt, Regret, Past Blunders, Remorse
  if (category === 'Guilt & Regret' || /(guilt|regret|ashamed|shame|made a mistake|blunder|remorse|forgive myself|fault|blame)/i.test(rawText)) {
    const blunderEn = userSnippet ? `the agony of my past mistake ("${userSnippet}")` : 'the crushing regret of past blunders';
    const blunderHi = userSnippet ? `अपनी भूल और पछतावे (${userSnippet})` : 'अतीत की भूल और अपराधबोध';
    return {
      issueBadgeEn: 'Guilt & Self-Forgiveness • Surrendering Past Remorse',
      issueBadgeHi: 'अपराधबोध और आत्म-क्षमा • प्रायश्चित और नव-जीवन',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Fire of Remorse',
          titleHindi: 'अपराधबोध की ज्वाला',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${blunderEn} burns like a slow fire within me. Guilt whispers that I am unworthy of peace and forever stained by what occurred.`,
          textHi: `हे माधव! ${blunderHi} मुझे रात-दिन जला रहा है। आत्म-ग्लानि का यह भारी बोझ मेरे मन को शांति नहीं लेने देता; मैं स्वयं को कैसे क्षमा करूं?`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Trap of Yesterday',
          titleHindi: 'अतीत की जंजीरों से मुक्ति',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, self-flagellation is an ego trap that chains you to yesterday. The past cannot be rewritten, but wholehearted righteous resolve purifies your soul this very instant.',
          textHi: 'हे पार्थ! पश्चाताप में घुटते रहना अज्ञान है। बीता हुआ कल बदला नहीं जा सकता, किन्तु सत्य और धर्म की ओर मुड़ते ही तुम्हारा उद्धार हो जाता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Surrender All Guilt • ${verseRef}`,
          titleHindi: `समर्पण और अभय • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Heed the promise of ${verseRef}: Surrender all past errors unto Truth. The moment you resolve to walk with righteousness and pure intent, you are restored to grace.`,
          textHi: `स्मरण करो ${verseRef}: सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज—समस्त अपराधबोध को समर्पित कर दो। शोक मत करो, तुम शुद्ध और मुक्त हो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'A Pure Clean Slate',
          titleHindi: 'नव-संकल्प और पवित्रता',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Drop the heavy stone of remorse, Dhananjaya! Rise with a purified heart. Live this fresh day with honesty, humble service, and quiet courage.',
          textHi: 'उठो, हे धनंजय! पश्चाताप के पत्थर को उतार फेंको। आज से एक नया, पावन और निष्काम कर्मनिष्ठ जीवन आरंभ करो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // I. Decision Paralysis, Confusion, Crossroads
  if (category === 'Decision Paralysis' || /(decision|confused|dilemma|choice|choose|crossroad|which path|stuck between|can'?t decide)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Decision Paralysis • Clear Intellect (Buddhi Yoga)',
      issueBadgeHi: 'निर्णय का असमंजस • बुद्धि योग और स्पष्टता',
      theme: 'calm-ocean',
      scenes: [
        {
          title: 'The Paralyzing Dilemma',
          titleHindi: 'निर्णय का असमंजस',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, my intellect is paralyzed at this critical crossroads. Fear of making the wrong choice and facing irreversible regret holds me captive in doubt.',
          textHi: 'हे कृष्ण! धर्म और कर्म के इस चौराहे पर मेरी बुद्धि भ्रमित हो गई है। गलत निर्णय के भय से मैं कोई कदम नहीं उठा पा रहा हूँ।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Myth of Zero Risk',
          titleHindi: 'विवेक और साहस',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, waiting for absolute zero risk before taking a step is the very nature of delusion. True clarity does not come from endless hesitation; it comes from aligning with your highest duty.',
          textHi: 'हे पार्थ! पूर्णतः संशय-मुक्त स्थिति की प्रतीक्षा करना ही सबसे बड़ा भ्रम है। अपने मूल मूल्यों और धर्म के आधार पर विचार करो और आगे बढ़ो।',
          cameraAngle: 'krishna',
        },
        {
          title: `Reflect & Act • ${verseRef}`,
          titleHindi: `विमृश्यैतदशेषेण • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `As taught in ${verseRef}: Deliberate thoroughly with a calm, unagitated mind, and then act decisively according to your conscience.`,
          textHi: `विमृश्यैतदशेषेण यथेच्छसि तथा कुरु—सत्य और धर्म का शांत मन से विचार करके निर्भय होकर अपने मार्ग का चयन करो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Decisive Courage',
          titleHindi: 'साहसी कदम उठाओ',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! Action cures hesitation. Make your choice with sincerity, dedicate the outcome to the Divine, and move forward without looking back.',
          textHi: 'उठो, हे अर्जुन! संशय का त्याग करो। निष्ठा से निर्णय लो और कर्म में प्रवृत्त हो जाओ; मार्ग स्वतः प्रशस्त होगा।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // J. Sleep, Insomnia, Exhaustion, Burnout
  if (category === 'Sleep & Exhaustion' || /(sleep|insomnia|cannot sleep|nightmare|restless night|exhaust|tired|fatigue|drained|burn out|burnout)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Sleep & Burnout • Sacred Rest & Balanced Living',
      issueBadgeHi: 'अनिद्रा और मानसिक थकान • युक्ताहारविहार और शांति',
      theme: 'calm-ocean',
      scenes: [
        {
          title: 'The Exhausted Spirit',
          titleHindi: 'अनिद्रा और निरंतर थकान',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, restless nights and burning exhaustion have sapped my vitality. The mind races relentlessly even in darkness, and deep restorative sleep eludes me.',
          textHi: 'हे माधव! अनिद्रा और निरंतर थकान ने मेरी शक्ति हर ली है। रात में भी मन शांत नहीं होता और मुझे कोई विश्राम नहीं मिल रहा है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Law of Harmony',
          titleHindi: 'जीवन का संतुलन',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, driving the vessel beyond its natural limits invites suffering. Yoga is the destroyer of all grief only when rhythm and balance are lovingly restored to life.',
          textHi: 'हे पार्थ! शरीर और प्रकृति के नियमों की उपेक्षा से ही संताप बढ़ता है। संतुलित जीवन ही दुःखों का नाश करता है; विश्राम को भी साधना मानो।',
          cameraAngle: 'krishna',
        },
        {
          title: `Restorative Harmony • ${verseRef}`,
          titleHindi: `युक्ताहारविहारस्य • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Rooted in ${verseRef}: For one who is disciplined in food, recreation, work, and sleep, Yoga removes all pain. Give your body and mind sacred permission to rest.`,
          textHi: `युक्ताहारविहारस्य—उचित आहार, संतुलित कर्म और नियमित निद्रा से ही मन और देह को नवजीवन प्राप्त होता है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Surrender into Silence',
          titleHindi: 'गहरे मौन में विश्राम',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Lay down your striving for tonight, Partha. Dissolve all burdens into the quiet ocean of Divine protection, and awaken refreshed for tomorrow’s duty.',
          textHi: 'आज की सब चिंताओं को मुझे समर्पित कर दो। गहरे मौन में शांत विश्राम करो और कल प्रातः एक नई स्फूर्ति के साथ जागो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // K. Money Worries, Financial Strain, Scarcity
  if (category === 'Money Worries' || /(money|financial|debt|bills|expenses|salary|broke|savings|loan|poverty)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Financial Stress & Scarcity • Practical Diligence & Trust',
      issueBadgeHi: 'आर्थिक चिंता और अभाव • पुरुषार्थ और योगक्षेम',
      theme: 'grounded-amber',
      scenes: [
        {
          title: 'The Grip of Financial Fear',
          titleHindi: 'आर्थिक चिंता का संताप',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, worries of livelihood, debt, and scarce resources weigh upon my chest. The terror of poverty and inability to provide clouds my peace.',
          textHi: 'हे माधव! आजीविका, ऋण और आर्थिक अभाव की चिंता मुझे घेरे हुए है। साधनहीन होने का भय मेरे चित्त को निरंतर बेचैन कर रहा है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'Shifting from Panic to Prudence',
          titleHindi: 'भय से पुरुषार्थ की ओर',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, panic and scarcity mindset freeze constructive action. Do your honest work with disciplined diligence; the supportive order of creation sustains all life.',
          textHi: 'हे पार्थ! भय और अभाव की चिंता तुम्हारी बुद्धि को संकुचित कर देती है। शांत मन से पुरुषार्थ करो; सृष्टि सबका पोषण करती है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Divine Support • ${verseRef}`,
          titleHindi: `योगक्षेमं वहाम्यहम् • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Proclaimed in ${verseRef}: For those who perform duty with steadfast faith, I myself provide what is lacking and protect what they possess.`,
          textHi: `अनन्याश्चिन्तयन्तो मां... योगक्षेमं वहाम्यहम्—जो निष्ठा से कर्म करते हैं, उनके अभाव की पूर्ति और रक्षा का भार मैं स्वयं संभालता हूँ।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Disciplined Diligence',
          titleHindi: 'शांत और कुशल कर्म',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! Replace anxiety with methodical effort. Spend with wisdom, work with honesty, and trust the unfolding path.',
          textHi: 'उठो, हे धनंजय! भय त्यागो और पुरुषार्थ करो। शांत चित्त से किए गए प्रयास में ही समृद्धि का वास है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // L. Anger, Frustration, Insults, Provocation
  if (category === 'Anger' || /(angry|furious|rage|temper|irritat|infuriat|mad at|hate|resent)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Anger & Frustration • Mastering Reactive Impulses',
      issueBadgeHi: 'क्रोध और उत्तेजना • आत्म-संयम और आंतरिक शांति',
      theme: 'cooling-twilight',
      scenes: [
        {
          title: 'The Burning Flare',
          titleHindi: 'क्रोध की तीव्र ज्वाला',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, harsh words and unfair provocations pierce deep like poisoned arrows. A burning fury is consuming my judgment and destroying my calm.',
          textHi: 'हे मधुसूदन! कटु वचन बाणों की तरह चुभ रहे हैं। क्रोध मेरे विवेक और मन की शांति को भस्म कर रहा है; मैं कैसे शांत होऊं?',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Chain of Destruction',
          titleHindi: 'क्रोध का विनाशकारी चक्र',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'From anger arises delusion; from delusion comes loss of memory. When memory is lost, intellect is ruined, and when intellect is ruined, a person falls.',
          textHi: 'क्रोधाद्भवति संमोहः संमोहात्स्मृतिविभ्रमः—क्रोध से मूढ़ता आती है, जिससे स्मृति भ्रमित होती है और बुद्धि का नाश हो जाता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `The Cooling Pause • ${verseRef}`,
          titleHindi: `शांत समत्व का कवच • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Heed ${verseRef}: Step back, Dhananjaya. Take a deep, grounded breath. Do not surrender your royal peace of mind to another person’s unconscious provocation.`,
          textHi: `ठहरो, हे अर्जुन! एक गहरा शांत श्वास लो। किसी और की कटुता के लिए अपनी आंतरिक शांति को मत त्यागो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Triumph of Composure',
          titleHindi: 'धैर्य और आत्म-संयम',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'He who conquers his own reaction wins the greatest battle in all the worlds. Patient dignity is your strongest armor; rise in peace.',
          textHi: 'जो अपनी प्रतिक्रिया पर विजय पा लेता है, वह सब जीत लेता है। धैर्य और शांति ही तुम्हारी सबसे बड़ी शक्ति है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // M. Conflict, Arguments, Disputes, Clashing Egos
  if (category === 'Conflict' || /(conflict|fight|argument|screaming|dispute|hostile|quarrel|toxic|clash)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Conflict & Friction • Non-Agitation & Calm Dignity',
      issueBadgeHi: 'विवाद और कलह • उद्वेग-रहित गरिमापूर्ण आचरण',
      theme: 'cooling-twilight',
      scenes: [
        {
          title: 'The Poison of Friction',
          titleHindi: 'विवाद और टकराव',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, heated disputes and hostility have poisoned the atmosphere. The urge to lash back and prove myself right is tearing my inner serenity away.',
          textHi: 'हे कृष्ण! कटु विवाद और कलह ने वातावरण को विषाक्त कर दिया है। स्वयं को सही सिद्ध करने की होड़ में मेरी शांति छिन गई है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Emptiness of Petty Victories',
          titleHindi: 'अहंकार की जीत व्यर्थ है',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Winning an argument while losing your noble peace is an utter defeat, Arjuna. Harsh attacks reveal their inner turbulence, not your worth.',
          textHi: 'हे पार्थ! अपनी शांति खोकर बहस जीतना वास्तव में पराजय है। दूसरों की कटुता उनके अशांत मन का दर्पण है, तुम्हारा स्वरूप नहीं।',
          cameraAngle: 'krishna',
        },
        {
          title: `Non-Agitation • ${verseRef}`,
          titleHindi: `यस्मान्नोद्विजते लोको • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Embody ${verseRef}: One who does not agitate the world, and who is not agitated by the world, is truly dearest to Me.`,
          textHi: `जिससे संसार उद्विग्न न हो और जो संसार से उद्विग्न न हो—वही समत्व-युक्त ज्ञानी मुझे अत्यंत प्रिय है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Rise in Noble Quietude',
          titleHindi: 'गरिमापूर्ण शांति',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arise with quiet strength! Speak only truth with kindness, hold firm boundaries, and refuse to step into their whirlwind of conflict.',
          textHi: 'उठो, हे धनंजय! गरिमा और शांति के साथ खड़े रहो। सत्य और संयम ही तुम्हारा सबसे बड़ा रक्षक है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // N. Comparison, Envy, Feeling Behind in Life
  if (category === 'Comparison' || /(compare|comparing|everyone else is ahead|behind in life|jealous|envy)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Comparison & Envy • Honoring Your Unique Path',
      issueBadgeHi: 'तुलना और ईर्ष्या • अपने अद्वितीय पथ का आदर',
      theme: 'grounded-amber',
      scenes: [
        {
          title: 'The Sting of Comparison',
          titleHindi: 'तुलना और हीनभावना का संताप',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, witnessing others advance while I seem delayed fills me with bitter inadequacy. Am I falling permanently behind in this life?',
          textHi: 'हे माधव! दूसरों की चमक-दमक देखकर मुझे लगता है कि मैं पीछे छूट गया हूँ। यह तुलना मेरे आत्म-विश्वास को तोड़ रही है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Illusion of Others’ Highlights',
          titleHindi: 'दूसरों की होड़ व्यर्थ है',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, you are comparing your vulnerable inner struggles against their polished outer mask. Each soul arrives on this earth with an individual karmic timeline.',
          textHi: 'हे पार्थ! हर जीवात्मा का मार्ग और समय भिन्न है। दूसरों के बाह्य प्रदर्शन से अपनी तुलना करना केवल भ्रम और दुःख उत्पन्न करता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Your Unique Assignment • ${verseRef}`,
          titleHindi: `स्वधर्मे स्थिति • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `As taught in ${verseRef}: Better is your own imperfect path than a borrowed life. Performing duty according to your own authentic nature incurs no fault.`,
          textHi: `अपने स्वाभाविक कर्म में निष्ठा रखो। दूसरों की नकल करने की अपेक्षा अपने पथ पर दृढ़ता से चलना ही कल्याणकारी है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Celebrate Your Journey',
          titleHindi: 'आत्म-विश्वास का मार्ग',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Partha! Drop the borrowed benchmarks of the world. Walk your sacred journey with dedication, and pour your love into your own work.',
          textHi: 'उठो, हे धनंजय! दूसरों की दौड़ छोड़ो। अपनी अंतर्निहित शक्ति को पहचानो और अपने मार्ग पर निष्ठा से बढ़ो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // O. Lack of Motivation, Procrastination, Lethargy
  if (category === 'Lack of Motivation' || /(procrastinat|stuck|no motivation|lack of motivation|can'?t start|unmotivated|lazy|inertia)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Overcoming Lethargy & Procrastination • Igniting the Will',
      issueBadgeHi: 'आलस्य और मानसिक जड़ता • आत्म-उत्थान और पुरुषार्थ',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Paralyzing Inertia',
          titleHindi: 'आलस्य और मानसिक जड़ता',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, my bow slips from my hands and all desire to act has evaporated. A heavy lethargy grips my will, leaving me feeling stagnant.',
          textHi: 'हे कृष्ण! गाण्डीव मेरे हाथ से फिसल रहा है। उत्साह समाप्त हो गया है और एक भारी आलस्य ने मुझे जकड़ लिया है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'Shake Off Weakness',
          titleHindi: 'हृदय-दौर्बल्य का त्याग',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Yield not to unmanliness, O son of Pritha! It does not befit your noble nature. Cast off this petty faint-heartedness and arise!',
          textHi: 'क्लैब्यं मा स्म गमः पार्थ—कायरता और दुर्बलता को मत प्राप्त हो। हृदय की इस तुच्छ दुर्बलता को त्यागकर खड़े हो जाओ!',
          cameraAngle: 'krishna',
        },
        {
          title: `Elevate Yourself • ${verseRef}`,
          titleHindi: `उद्धरेदात्मनात्मानं • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Rooted in ${verseRef}: Elevate yourself through the power of your mind; do not pull yourself down. The mind alone is your truest friend or bitterest enemy.`,
          textHi: `उद्धरेदात्मनात्मानं नात्मानमवसादयेत्—मनुष्य अपने मन से अपना उद्धार करे, अपने को नीचे न गिराए।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Take the First Small Step',
          titleHindi: 'पहला कदम उठाओ',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Do not wait for fleeting motivation to arrive, Partha! Take one small courageous action right now, and the sleeping power within will ignite.',
          textHi: 'उठो, हे पार्थ! कर्म आरंभ करने के लिए प्रेरणा की प्रतीक्षा मत करो। पहला कदम उठाओ, शक्ति स्वतः जागृत होगी।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // P. Purpose & Meaning of Life, Spiritual Seeking
  if (category === 'Purpose & Inner Peace' || /(purpose|meaning of life|who am i|spiritual|inner peace|soul|god|truth|empty life)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Purpose & Meaning • Awakening to the Radiant Self',
      issueBadgeHi: 'जीवन का उद्देश्य और शांति • आत्म-ज्ञान का प्रकाश',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Quest for Meaning',
          titleHindi: 'जीवन के उद्देश्य की खोज',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'O Krishna, superficial pursuits feel hollow and fleeting. What is the ultimate purpose of this human existence? My soul yearns for enduring truth.',
          textHi: 'हे मधुसूदन! सांसारिक उपलब्धियों की चमक व्यर्थ लग रही है। इस जीवन का वास्तविक उद्देश्य क्या है? मेरी आत्मा सच्ची शांति खोज रही है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Sacred Awakening',
          titleHindi: 'वैराग्य और दिव्य बोध',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, blessed is this holy questioning. When outer achievements cease to satisfy, your spirit is ripe to discover its immortal nature.',
          textHi: 'हे पार्थ! यह वैराग्य कल्याणकारी है। जब बाहरी वस्तुएं तृप्त नहीं करतीं, तब अंतरात्मा अपने अमर स्वरूप को जानने के लिए जागती है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Purifying Knowledge • ${verseRef}`,
          titleHindi: `न हि ज्ञानेन सदृशं • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `As taught in ${verseRef}: There is nothing in this world as purifying as self-knowledge. Dedicated to Truth, you discover untroubled peace within.`,
          textHi: `न हि ज्ञानेन सदृशं पवित्रमिह विद्यते—आत्म-ज्ञान के समान पावन कुछ भी नहीं है। अंतःकरण में ही सच्ची शांति का वास है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Live as Divine Light',
          titleHindi: 'दिव्य स्वरूप की पहचान',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, seeker of Truth! Live with selfless service and awareness. You are not a creature of dust; you are the radiant light of the cosmos.',
          textHi: 'उठो, हे धनंजय! निष्काम भाव से जीवन जियो। तुम परमात्मा का ही अंश हो; अपने दिव्य स्वरूप को पहचानो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // Q. Feeling Overwhelmed, Crushing Tasks & Chaos
  if (category === 'Feeling Overwhelmed' || /(overwhelm|too much to do|drowning|suffocating|crushing|can'?t handle|burden|heavy)/i.test(rawText)) {
    const ovContextEn = userSnippet ? `this heavy burden ("${userSnippet}")` : 'this crushing avalanche of demands and responsibilities';
    const ovContextHi = userSnippet ? `इस भारी दबाव (${userSnippet})` : 'जिम्मेदारियों और कार्यों के इस भारी दबाव';
    return {
      issueBadgeEn: 'Feeling Overwhelmed • The Grounded Calm of the Ocean',
      issueBadgeHi: 'अत्यधिक मानसिक बोझ • अचल समुद्र समता और शांति',
      theme: 'calm-ocean',
      scenes: [
        {
          title: 'The Crushing Avalanche',
          titleHindi: 'अत्यधिक मानसिक बोझ',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${ovContextEn} is drowning me. Countless demands storm at me from every direction, and I cannot catch my breath.`,
          textHi: `हे माधव! ${ovContextHi} से मेरा दम घुट रहा है। सब दिशाओं से अपेक्षाएं मुझ पर टूट पड़ी हैं और मुझे कोई मार्ग नहीं दिख रहा है।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Illusion of Solitary Carrying',
          titleHindi: 'अकेले बोझ उठाने का भ्रम',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, you suffer because you believe you alone must carry the weight of the universe. Surrender the illusion of solitary omnipotence.',
          textHi: 'हे पार्थ! तुम इसलिए व्यथित हो क्योंकि तुम्हें लगता है कि सारा बोझ केवल तुम्हें ही उठाना है। ईश्वर की कृपा पर विश्वास रखो।',
          cameraAngle: 'krishna',
        },
        {
          title: `The Ocean of Stillness • ${verseRef}`,
          titleHindi: `अचल समुद्र समता • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Embody ${verseRef}: Just as the ocean remains undisturbed while rivers continuously pour into it, let tasks enter without disturbing your inner stillness.`,
          textHi: `जैसे नदियां समुद्र में समाकर भी उसे विचलित नहीं करतीं, वैसे ही सब परिस्थितियों को शांत चित्त से स्वीकार करो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'One Grounded Step',
          titleHindi: 'एक समय में एक कदम',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Partha! You do not need to conquer the entire world today. Choose the single next duty before you, and execute it with pure calm.',
          textHi: 'उठो, हे धनंजय! सब कुछ एक साथ करने की चिंता छोड़ो। जो कार्य सामने है, उसे शांत मन से पूरा करो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // R. Fear of Failure (Standard chip or typed)
  if (category === 'Fear of Failure' || /(fear of failure|fail|scared of failing|failing|what if i fail|ruined)/i.test(rawText)) {
    const fofDetailEn = userSnippet ? `my deep terror regarding "${userSnippet}"` : 'this paralyzing fear of failure';
    const fofDetailHi = userSnippet ? `असफलता का यह भय (${userSnippet})` : 'असफलता और पराजय का यह तीव्र भय';
    return {
      issueBadgeEn: 'Fear of Failure • Equalizing Victory & Defeat',
      issueBadgeHi: 'असफलता का भय • जय-पराजय में समत्व योग',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Fear of Falling Short',
          titleHindi: 'असफलता और पराजय का भय',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${fofDetailEn} grips my throat. The imagined shame of failing, disappointing others, and losing everything leaves me trembling.`,
          textHi: `हे माधव! ${fofDetailHi} मुझे जकड़े हुए है। यदि मैं असफल हो गया और सब व्यर्थ हो गया, तो मैं इस अपमान को कैसे सहन करूंगा?`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'Dissolving the Monster of Outcome',
          titleHindi: 'परिणाम के भय से मुक्ति',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Partha, failure is not a verdict upon your soul; it is merely an event in time. When you detach your identity from external victory, fear vanishes completely.',
          textHi: 'हे पार्थ! असफलता तुम्हारी आत्मा की पराजय नहीं, केवल समय की एक परिस्थिति है। जब तुम परिणाम के मोह से मुक्त हो जाते हो, तो भय स्वतः समाप्त हो जाता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Equalize Gain & Loss • ${verseRef}`,
          titleHindi: `सुखदुःखे समे कृत्वा • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Remember ${verseRef}: Holding pleasure and pain, gain and loss, victory and defeat with an equal mind—gird yourself for the battle. Thus you incur no fault.`,
          textHi: `सुखदुःखे समे कृत्वा लाभालाभौ जयाजयौ—सुख-दुःख, लाभ-हानि, जय-पराजय को समान समझकर कर्म करो। इससे तुम पर कोई दोष नहीं लगेगा।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Rise in Fearless Valor',
          titleHindi: 'निर्भय संकल्प',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! A warrior fights for righteousness, not for praise. Cast off all trembling, pour your heart into noble duty, and stand triumphant within.',
          textHi: 'उठो, हे धनंजय! फल की चिंता त्यागकर अपने धर्म के लिए खड़े हो जाओ। शांत चित्त से कर्म करो; आत्म-विजय ही वास्तविक विजय है।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // S. Career Uncertainty & Future Direction
  if (category === 'Career Uncertainty' || /(career|future|job direction|startup|business|unclear path|what will happen to me)/i.test(rawText)) {
    const careerContextEn = userSnippet ? `my uncertainty regarding "${userSnippet}"` : 'uncertainty about my future and career path';
    const careerContextHi = userSnippet ? `करियर और भविष्य का संशय (${userSnippet})` : 'करियर और भविष्य की अनिश्चितता';
    return {
      issueBadgeEn: 'Career Uncertainty • Cultivating Clarity & Resilience',
      issueBadgeHi: 'करियर और भविष्य का संशय • बुद्धि योग और धैर्य',
      theme: 'radiant-gold',
      scenes: [
        {
          title: 'The Fog of Future',
          titleHindi: 'करियर और भविष्य का संशय',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${careerContextEn} casts a heavy shadow over my steps. The road ahead is shrouded in mist, and I do not know where my efforts will lead.`,
          textHi: `हे माधव! ${careerContextHi} से मेरा मन अशांत है। आगे का मार्ग धुंधला है और मुझे समझ नहीं आ रहा कि मेरा प्रयास मुझे कहाँ ले जाएगा।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'Clarity in the Immediate Step',
          titleHindi: 'वर्तमान कर्म में स्पष्टता',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, no human is granted sight of the entire tapestry of tomorrow. You are only required to illuminate the single next honest step with your pure intellect.',
          textHi: 'हे पार्थ! कल का संपूर्ण चित्र कोई नहीं देख सकता। तुम्हें केवल अपने वर्तमान कर्तव्य को निष्ठा और विवेक से पूरा करने की आवश्यकता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Steady Intellect • ${verseRef}`,
          titleHindi: `व्यवसायात्मिका बुद्धिः • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Anchored in ${verseRef}: For the resolute seeker, the intellect is one-pointed and resolute. Many-branched and endless are the thoughts of the irresolute.`,
          textHi: `व्यवसायात्मिका बुद्धिरेकेह—निश्चयात्मक बुद्धि को एक लक्ष्य पर एकाग्र करो। भविष्य के अंतहीन संशयों को त्याग कर वर्तमान में कार्य करो।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Walk the Path with Trust',
          titleHindi: 'अडिग विश्वास से आगे बढ़ो',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Dhananjaya! Trust the unfolding wisdom of life. Build your skills with patient dedication, and your rightful place in the world will reveal itself.',
          textHi: 'उठो, हे धनंजय! संशय का त्याग करो। निष्ठा से अपनी क्षमताओं को निखारो; तुम्हारी सत्यनिष्ठा ही तुम्हें सही दिशा में ले जाएगी।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // T. Work Pressure, Deadlines, Professional Expectations
  if (category === 'Work Pressure' || /(deadline|boss|manager|workload|client|office|meeting|project|work pressure)/i.test(rawText)) {
    const wpContextEn = userSnippet ? `the crushing workload of "${userSnippet}"` : 'heavy deadlines and relentless professional demands';
    const wpContextHi = userSnippet ? `काम का भारी दबाव (${userSnippet})` : 'दफ्तर का भारी दबाव और समय-सीमा की चिंता';
    return {
      issueBadgeEn: 'Workplace Pressure & Deadlines • Karma Yoga in Action',
      issueBadgeHi: 'काम का दबाव और समय-सीमा • कर्मण्येवाधिकारस्ते',
      theme: 'grounded-amber',
      scenes: [
        {
          title: 'The Tyranny of Outcomes',
          titleHindi: 'काम का दबाव और चिंता',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: `O Krishna, ${wpContextEn} presses heavily upon my head. Worrying about the deadline and outcomes drains all the joy from my duty.`,
          textHi: `हे कृष्ण! ${wpContextHi} मेरे मन को बेचैन कर रहा है। परिणाम की चिंता और काम के बोझ से मेरा प्रयास कुंठित हो रहा है।`,
          cameraAngle: 'arjuna',
        },
        {
          title: 'The Separation of Effort and Outcome',
          titleHindi: 'कर्म और फल का भेद',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Arjuna, you possess complete authority over preparation and execution, but never over how others react. Make a clean separation between effort and result.',
          textHi: 'हे पार्थ! तुम्हारा अधिकार केवल कर्म करने में है, फल में कभी नहीं। परिणाम के भय से अपने कर्तव्य को मत रोको।',
          cameraAngle: 'krishna',
        },
        {
          title: `Focus Solely on Action • ${verseRef}`,
          titleHindi: `कर्मण्येवाधिकारस्ते • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `Heed ${verseRef}: Let not the fruit of action be your motive, nor let your attachment be to inaction. Pour yourself fully into the work with calm mastery.`,
          textHi: `कर्मण्येवाधिकारस्ते मा फलेषु कदाचन—फल की आसक्ति त्याग कर एकाग्र चित्त से कर्म करो। यही कार्य की सच्ची कुशलता है।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Quiet Professional Mastery',
          titleHindi: 'शांत कार्य कुशलता',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, warrior! Silence the noisy scoreboard of tomorrow. Bring your complete presence to this immediate task, and excellence will follow naturally.',
          textHi: 'उठो, हे धनंजय! कल की चिंता छोड़ो। अपने वर्तमान कर्म में पूरी निष्ठा लगाओ; सफलता स्वतः तुम्हारा अनुसरण करेगी।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // U. Overthinking, Racing Thoughts, Mental Chatter
  if (category === 'Overthinking' || /(overthinking|racing thoughts|spiraling|can'?t stop thinking|loop in my head|obsessing)/i.test(rawText)) {
    return {
      issueBadgeEn: 'Overthinking & Mental Restlessness • Calming the Storm',
      issueBadgeHi: 'अति-विचार और चंचल मन • अभ्यास और वैराग्य',
      theme: 'calm-ocean',
      scenes: [
        {
          title: 'The Restless Whirlwind',
          titleHindi: 'चंचल मन की व्यथा',
          speaker: 'Arjuna',
          speakerHindi: 'अर्जुन',
          textEn: 'My mind is endlessly turbulent and unsteady, Krishna. Subduing its runaway thoughts feels as impossible as catching the roaring wind.',
          textHi: 'हे कृष्ण! यह मन अत्यंत चंचल और अशांत है। इन अनगिनत विचारों को रोकना वायु को मुट्ठी में बांधने जैसा कठिन है।',
          cameraAngle: 'arjuna',
        },
        {
          title: 'Practice & Detachment',
          titleHindi: 'अभ्यास और वैराग्य',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Without doubt, O mighty-armed, the mind is difficult to tame. Yet through steady practice (Abhyasa) and gentle detachment (Vairagya), it becomes peaceful.',
          textHi: 'निस्संदेह, हे महाबाहो! मन चंचल और हठी है। किन्तु निरंतर अभ्यास और वैराग्य से यह शांत हो जाता है।',
          cameraAngle: 'krishna',
        },
        {
          title: `Gently Bring It Back • ${verseRef}`,
          titleHindi: `यतो यतो निश्चरति • ${verseRef}`,
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: `As taught in ${verseRef}: From whatever cause the restless mind wanders away, gently restrain it and bring it back under the control of the Self.`,
          textHi: `यतो यतो निश्चरति मनश्चञ्चलमस्थिरम्—जहाँ-जहाँ यह मन भटके, इसे प्रेम से लौटाकर आत्मा के वश में लाओ।`,
          cameraAngle: 'divine',
        },
        {
          title: 'Present Sanctuary',
          titleHindi: 'वर्तमान की शांति',
          speaker: 'Lord Krishna',
          speakerHindi: 'भगवान श्रीकृष्ण',
          textEn: 'Rise, Partha! Do not fight thoughts with anger. Notice them with calm detachment, breathe deeply, and anchor yourself in this present moment.',
          textHi: 'उठो, हे पार्थ! विचारों से युद्ध मत करो। उन्हें साक्षी भाव से देखो और वर्तमान के शांत क्षण में विश्राम करो।',
          cameraAngle: 'wide',
        },
      ],
    };
  }

  // V. OTHER / FREE-FORM USER TOPIC (Custom user issues that explicitly mention the user's situation)
  const customIssueEn = userSnippet ? `this profound trial: "${userSnippet}"` : 'this life challenge and inner struggle';
  const customIssueHi = userSnippet ? `इस समस्या ("${userSnippet}")` : 'जीवन की इस विषम परिस्थिति';

  return {
    issueBadgeEn: userSnippet ? `Resolving: "${userSnippet}"` : `Life Concern • ${category}`,
    issueBadgeHi: userSnippet ? `समाधान: "${userSnippet}"` : `जीवन का संशय • ${category}`,
    theme: 'radiant-gold',
    scenes: [
      {
        title: 'The Agony of this Trial',
        titleHindi: 'परिस्थिति की व्यथा और संशय',
        speaker: 'Arjuna',
        speakerHindi: 'अर्जुन',
        textEn: `O Krishna, my heart is burdened by ${customIssueEn}. The uncertainty of this dilemma clouds my intellect, and I seek Your grounded clarity on what I must do.`,
        textHi: `हे माधव! ${customIssueHi} से मेरा मन अशांत और व्याकुल है। आगे का मार्ग स्पष्ट नहीं दिख रहा; कृपया मुझे बताइए कि इस घड़ी में मेरा क्या कर्तव्य है?`,
        cameraAngle: 'arjuna',
      },
      {
        title: 'The Witness of the Self',
        titleHindi: 'आत्म-विवेक का प्रकाश',
        speaker: 'Lord Krishna',
        speakerHindi: 'भगवान श्रीकृष्ण',
        textEn: `Partha, every trial you encounter is an invitation to deepen your spiritual strength. External storms cannot touch the radiant light of your inner Self. Understand: ${verseMeaningEn}.`,
        textHi: `हे पार्थ! जीवन की हर कठिनाई तुम्हारी आत्मिक शक्ति को जगाने का अवसर है। बाहरी परिस्थितियां तुम्हारे आत्म-प्रकाश को नहीं डिगा सकतीं। शांत चित्त से विवेक का आश्रय लो।`,
        cameraAngle: 'krishna',
      },
      {
        title: `The Divine Truth • ${verseRef}`,
        titleHindi: `शाश्वत गीता ज्ञान • ${verseRef}`,
        speaker: 'Lord Krishna',
        speakerHindi: 'भगवान श्रीकृष्ण',
        textEn: `Anchored in ${verseRef}: Elevate your mind through wisdom and steadfast composure. Surrender all anxiety to Truth and perform your duty with honor.`,
        textHi: `स्मरण करो ${verseRef}: ${verseTranslationHi} उद्धरेदात्मनात्मानं—अपने मन को ज्ञान और समत्व से ऊंचा उठाओ। चिंता का त्याग करके धर्मपूर्वक अपना कर्तव्य निभाओ।`,
        cameraAngle: 'divine',
      },
      {
        title: 'Courageous Awakening',
        titleHindi: 'कुरुक्षेत्र का संकल्प',
        speaker: 'Lord Krishna',
        speakerHindi: 'भगवान श्रीकृष्ण',
        textEn: `Rise, Dhananjaya! Reclaim your quiet power. Take the next honest step with peace in your heart, for you are ever protected by Divine grace.`,
        textHi: `उठो, हे धनंजय! अपने आत्म-बल को पहचानो। शांत चित्त से आगे बढ़ो, परमात्मा की कृपा सदैव तुम्हारे साथ है।`,
        cameraAngle: 'wide',
      },
    ],
  };
}
