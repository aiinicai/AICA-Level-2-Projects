import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfigData from '../../firebase-applet-config.json';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: 'user' | 'admin';
  createdAt?: string;
  lastLoginAt?: string;
  stats?: {
    journalCount?: number;
    bookmarksCount?: number;
  };
}

// Application owner email with administrative authorization
export const APP_OWNER_EMAIL = 'khushinew24@gmail.com';

// Initialize Firebase App
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfigData);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Initialize Cloud Firestore using the configured database ID
export const db = firebaseConfigData.firestoreDatabaseId
  ? getFirestore(app, firebaseConfigData.firestoreDatabaseId)
  : getFirestore(app);

// Google Auth Provider setup
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

/**
 * Checks whether an email address belongs to the application owner.
 */
export function isOwnerEmail(email?: string | null): boolean {
  if (!email) return false;
  return email.trim().toLowerCase() === APP_OWNER_EMAIL.toLowerCase();
}

/**
 * Initiates Google Sign-In via popup.
 */
export async function signInWithGoogle(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  await ensureUserProfile(result.user);
  return result.user;
}

/**
 * Signs out the currently authenticated user.
 */
export async function signOutUser(): Promise<void> {
  await fbSignOut(auth);
}

/**
 * Ensures a user document exists in Firestore and updates login timestamp.
 * Assigns 'admin' role to the app owner and 'user' to all other seekers.
 */
export async function ensureUserProfile(user: FirebaseUser): Promise<UserProfile> {
  const userDocRef = doc(db, 'users', user.uid);
  const snap = await getDoc(userDocRef);

  const isOwner = isOwnerEmail(user.email);
  const nowIso = new Date().toISOString();

  if (!snap.exists()) {
    const newProfile: UserProfile = {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || user.email?.split('@')[0] || 'Seeker',
      photoURL: user.photoURL || undefined,
      role: isOwner ? 'admin' : 'user',
      createdAt: nowIso,
      lastLoginAt: nowIso,
      stats: {
        journalCount: 0,
        bookmarksCount: 0,
      },
    };

    try {
      await setDoc(userDocRef, {
        ...newProfile,
        serverCreatedAt: serverTimestamp(),
        serverLastLoginAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Could not write initial user doc to Firestore:', err);
    }

    return newProfile;
  } else {
    const existing = snap.data() as UserProfile;
    // If user is owner, ensure role is 'admin'
    const role: 'user' | 'admin' = isOwner ? 'admin' : existing.role || 'user';

    try {
      await updateDoc(userDocRef, {
        lastLoginAt: nowIso,
        displayName: user.displayName || existing.displayName,
        photoURL: user.photoURL || existing.photoURL,
        role,
        serverLastLoginAt: serverTimestamp(),
      });
    } catch {
      // ignore
    }

    return {
      ...existing,
      role,
      lastLoginAt: nowIso,
    };
  }
}

/**
 * Fetches user profile from Firestore.
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userDocRef = doc(db, 'users', uid);
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
  } catch (err) {
    console.error('Failed to get user profile:', err);
  }
  return null;
}

/**
 * Subscribes to Firebase Auth state changes.
 */
export function subscribeToAuth(
  callback: (user: FirebaseUser | null, profile: UserProfile | null) => void
): () => void {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      try {
        const profile = await ensureUserProfile(user);
        callback(user, profile);
      } catch {
        callback(user, {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || 'Seeker',
          photoURL: user.photoURL || undefined,
          role: isOwnerEmail(user.email) ? 'admin' : 'user',
        });
      }
    } else {
      callback(null, null);
    }
  });
}
