import { JournalEntry, StressCategory, UserPreferences } from '../types';

const STORAGE_KEYS = {
  JOURNAL: 'geeta_gyan_journal_entries',
  SAVED_GUIDANCE: 'geeta_gyan_saved_guidance',
  PREFERENCES: 'geeta_gyan_user_preferences',
  CHECKIN_COUNT: 'geeta_gyan_checkin_count',
  FEEDBACK: 'geeta_gyan_feedback',
};

const DEFAULT_PREFERENCES: UserPreferences = {
  language: 'en', // writing by default in english
  spokenLanguage: 'hi', // spoken language only by default in hindi
  theme: 'dark',
  dailyReminderEnabled: false,
  reminderTime: '08:00',
};

// Seed sample reflection data if storage is completely empty so the demo "My Journey" & "Journal" looks alive and demonstrates the before/after stress analytics
const INITIAL_JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: 'sample-entry-1',
    createdAt: new Date(Date.now() - 3600 * 1000 * 48).toISOString(),
    stressCategory: 'Work Pressure',
    userInput: 'Multiple project deliverables due at the same time and anxiety about disappointing the team.',
    stressBefore: 4,
    verseId: 'bg-2-47',
    verseReference: 'BG 2.47',
    concept: 'Karma Yoga (Focus on Action)',
    actionTaken: 'Separated the tasks into what I control today vs outcomes. Worked 20 minutes solely on the primary slide deck.',
    reflection: 'Releasing the need to guarantee praise reduced my tight chest feeling.',
    stressAfter: 2,
  },
  {
    id: 'sample-entry-2',
    createdAt: new Date(Date.now() - 3600 * 1000 * 24).toISOString(),
    stressCategory: 'Overthinking',
    userInput: 'Could not stop replaying a difficult discussion with a colleague.',
    stressBefore: 4,
    verseId: 'bg-2-70',
    verseReference: 'BG 2.70',
    concept: 'Steadiness of Mind (Sthitaprajna)',
    actionTaken: 'One-Minute Pause and thought reset: acknowledged that their reaction belongs to them.',
    reflection: 'The ocean metaphor helped me see the comment as a surface wave.',
    stressAfter: 2,
  }
];

export function getJournalEntries(): JournalEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.JOURNAL);
    if (!raw) {
      // Seed initial sample entries for demo
      localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(INITIAL_JOURNAL_ENTRIES));
      return INITIAL_JOURNAL_ENTRIES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_JOURNAL_ENTRIES;
  }
}

export function saveJournalEntry(entry: Omit<JournalEntry, 'id' | 'createdAt'>): JournalEntry {
  const entries = getJournalEntries();
  const newEntry: JournalEntry = {
    ...entry,
    id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    createdAt: new Date().toISOString(),
  };

  const updated = [newEntry, ...entries];
  try {
    localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(updated));
    incrementCheckinCount();
  } catch (err) {
    console.error('Failed to save journal entry', err);
  }
  return newEntry;
}

export function deleteJournalEntry(id: string): void {
  const entries = getJournalEntries().filter((e) => e.id !== id);
  try {
    localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(entries));
  } catch (err) {
    console.error('Failed to delete journal entry', err);
  }
}

export function getSavedGuidances(): any[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SAVED_GUIDANCE);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleSaveGuidance(guidance: any): boolean {
  try {
    const list = getSavedGuidances();
    const existingIndex = list.findIndex((g) => g.verse?.id === guidance.verse?.id && g.matchedCategory === guidance.matchedCategory);
    let isSaved = false;

    if (existingIndex >= 0) {
      list.splice(existingIndex, 1);
      isSaved = false;
    } else {
      list.unshift({ ...guidance, savedAt: new Date().toISOString() });
      isSaved = true;
    }
    localStorage.setItem(STORAGE_KEYS.SAVED_GUIDANCE, JSON.stringify(list));
    return isSaved;
  } catch {
    return false;
  }
}

export function isGuidanceSaved(verseId: string): boolean {
  const list = getSavedGuidances();
  return list.some((g) => g.verse?.id === verseId);
}

export function getUserPreferences(): UserPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
    if (!raw) return DEFAULT_PREFERENCES;
    const parsed = JSON.parse(raw);
    const writingLanguage: 'en' | 'hi' = parsed.explicitWritingChoice
      ? parsed.language
      : 'en'; // writing by default in english

    return {
      ...DEFAULT_PREFERENCES,
      ...parsed,
      language: writingLanguage,
      spokenLanguage: parsed.spokenLanguage || 'hi', // spoken language only by default hindi
    };
  } catch {
    return DEFAULT_PREFERENCES;
  }
}

export function saveUserPreferences(prefs: Partial<UserPreferences>): UserPreferences {
  const current = getUserPreferences();
  const updated = {
    ...current,
    ...prefs,
    explicitWritingChoice: prefs.language !== undefined ? true : (current as unknown as { explicitWritingChoice?: boolean }).explicitWritingChoice,
  };
  try {
    localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save preferences', err);
  }
  return updated;
}

export function incrementCheckinCount(): number {
  try {
    const current = parseInt(localStorage.getItem(STORAGE_KEYS.CHECKIN_COUNT) || '0', 10);
    const updated = current + 1;
    localStorage.setItem(STORAGE_KEYS.CHECKIN_COUNT, updated.toString());
    return updated;
  } catch {
    return 1;
  }
}

export function getCheckinCount(): number {
  try {
    return parseInt(localStorage.getItem(STORAGE_KEYS.CHECKIN_COUNT) || '2', 10);
  } catch {
    return 2;
  }
}

export interface JourneyStats {
  totalCheckins: number;
  journalEntriesCount: number;
  mostCommonCategory: string;
  mostCommonPrinciple: string;
  avgStressBefore: number | null;
  avgStressAfter: number | null;
  stressReduction: number | null;
  categoryBreakdown: { category: string; count: number }[];
  summaryMessage: string;
}

export function calculateJourneyStats(): JourneyStats {
  const entries = getJournalEntries();
  const totalCheckins = Math.max(getCheckinCount(), entries.length);

  if (entries.length === 0) {
    return {
      totalCheckins,
      journalEntriesCount: 0,
      mostCommonCategory: 'None yet',
      mostCommonPrinciple: 'Karma Yoga',
      avgStressBefore: null,
      avgStressAfter: null,
      stressReduction: null,
      categoryBreakdown: [],
      summaryMessage: 'Complete your first check-in to observe your self-reported stress reflections over time.',
    };
  }

  // Category counts
  const catMap: Record<string, number> = {};
  const principleMap: Record<string, number> = {};
  let totalBefore = 0;
  let beforeCount = 0;
  let totalAfter = 0;
  let afterCount = 0;

  for (const e of entries) {
    catMap[e.stressCategory] = (catMap[e.stressCategory] || 0) + 1;
    if (e.concept) {
      principleMap[e.concept] = (principleMap[e.concept] || 0) + 1;
    }
    if (typeof e.stressBefore === 'number') {
      totalBefore += e.stressBefore;
      beforeCount++;
    }
    if (typeof e.stressAfter === 'number') {
      totalAfter += e.stressAfter;
      afterCount++;
    }
  }

  const sortedCats = Object.entries(catMap).sort((a, b) => b[1] - a[1]);
  const mostCommonCategory = sortedCats[0] ? sortedCats[0][0] : 'Work Pressure';

  const sortedPrinciples = Object.entries(principleMap).sort((a, b) => b[1] - a[1]);
  const mostCommonPrinciple = sortedPrinciples[0] ? sortedPrinciples[0][0] : 'Karma Yoga (Focus on Action)';

  const avgStressBefore = beforeCount > 0 ? parseFloat((totalBefore / beforeCount).toFixed(1)) : null;
  const avgStressAfter = afterCount > 0 ? parseFloat((totalAfter / afterCount).toFixed(1)) : null;
  const stressReduction =
    avgStressBefore !== null && avgStressAfter !== null ? parseFloat((avgStressBefore - avgStressAfter).toFixed(1)) : null;

  let summaryMessage = 'Your self-reported reflections show steady engagement with the teachings.';
  if (stressReduction !== null && stressReduction > 0) {
    summaryMessage = 'Your self-reported stress after reflection has generally been lower than before reflection.';
  } else if (stressReduction !== null && stressReduction === 0) {
    summaryMessage = 'Your self-reported stress has remained even before and after reflection.';
  }

  const categoryBreakdown = sortedCats.map(([category, count]) => ({ category, count }));

  return {
    totalCheckins,
    journalEntriesCount: entries.length,
    mostCommonCategory,
    mostCommonPrinciple,
    avgStressBefore,
    avgStressAfter,
    stressReduction,
    categoryBreakdown,
    summaryMessage,
  };
}

export function clearAllLocalData(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.JOURNAL);
    localStorage.removeItem(STORAGE_KEYS.SAVED_GUIDANCE);
    localStorage.removeItem(STORAGE_KEYS.PREFERENCES);
    localStorage.removeItem(STORAGE_KEYS.CHECKIN_COUNT);
    localStorage.removeItem(STORAGE_KEYS.FEEDBACK);
  } catch (err) {
    console.error('Failed to clear data', err);
  }
}
