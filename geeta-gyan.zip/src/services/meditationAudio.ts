// Soothing, calm meditation voice synthesizer and gentle acoustic singing bowl/ambient drone generator
// Uses browser Web Audio API + SpeechSynthesis API tailored for Indian listeners (Calming Lady Voice)
// Hardened for mobile browsers by queueing short natural utterances synchronously inside user gesture.

export interface AudioPlaybackState {
  isPlaying: boolean;
  isPaused: boolean;
  currentVerseId?: string;
  currentTitle?: string;
  speed: number;
}

type AudioStateListener = (state: AudioPlaybackState) => void;

function cleanTextForSpeech(text: string, lang = 'hi'): string {
  if (!text) return '';
  return text
    .replace(/[#*_~`^]/g, '')
    .replace(/[\[\](){}<>]/g, ' ')
    .replace(/[""]/g, '"')
    .replace(/['']/g, "'")
    .replace(/॥/g, '।')
    .replace(/[-–—]+/g, ', ')
    .replace(/\s*:\s*/g, lang === 'hi' ? ' - ' : ': ')
    .replace(/\n+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function cleanSanskritForSpeech(sanskrit: string): string {
  if (!sanskrit) return '';
  return sanskrit
    .replace(/[\u0951\u0952\u0953\u0954]/g, '')
    .replace(/॥\s*[०-९0-9\s-]+\s*॥/g, '।')
    .replace(/॥/g, '।')
    .replace(/ऽ/g, 'अ')
    .replace(/\n+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Splits longer paragraphs into natural spoken sentences.
 */
function splitIntoSpeechChunks(text: string): string[] {
  if (!text) return [];
  const rawParts = text.split(/([।\n\r.?!]+)/);
  const chunks: string[] = [];
  let buffer = '';

  for (let i = 0; i < rawParts.length; i++) {
    const part = rawParts[i].trim();
    if (!part) continue;

    if (/^[।\n\r.?!]+$/.test(part)) {
      buffer += (buffer ? ' ' : '') + part;
      if (buffer.trim().length > 0) {
        chunks.push(buffer.trim());
        buffer = '';
      }
    } else {
      if (buffer.length + part.length > 100) {
        if (buffer.trim().length > 0) chunks.push(buffer.trim());
        buffer = part;
      } else {
        buffer += (buffer ? ' ' : '') + part;
      }
    }
  }

  if (buffer.trim().length > 0) {
    chunks.push(buffer.trim());
  }

  return chunks.filter((c) => c.length > 0);
}

class MeditationAudioEngine {
  private ctx: AudioContext | null = null;
  private isVoiceMuted: boolean = false;
  private isAmbientMuted: boolean = false;
  private droneGain: GainNode | null = null;
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private cancelCurrentSpeech: (() => void) | null = null;

  // Active Playback State
  private activeState: AudioPlaybackState = {
    isPlaying: false,
    isPaused: false,
    currentVerseId: undefined,
    currentTitle: undefined,
    speed: 0.78,
  };

  private listeners = new Set<AudioStateListener>();

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        // Pre-warm voices
      };
      try {
        window.speechSynthesis.getVoices();
      } catch {
        // ignore
      }
    }
  }

  public subscribe(listener: AudioStateListener): () => void {
    this.listeners.add(listener);
    listener(this.activeState);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => {
      try {
        fn({ ...this.activeState });
      } catch (err) {
        console.error('Audio state listener error:', err);
      }
    });
  }

  public getPlaybackState(): AudioPlaybackState {
    return { ...this.activeState };
  }

  public setSpeed(speed: number) {
    this.activeState.speed = speed;
    this.notify();
  }

  // Pre-warms Web Audio and SpeechSynthesis on user gesture
  public warmUp() {
    try {
      this.initAudio();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.getVoices();
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
    } catch {
      // ignore
    }
  }

  private initAudio() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Subtle acoustic audio carrier: Keeps mobile audio session active so browser never sleeps
  public startDrone(freq = 216) {
    if (this.isAmbientMuted) return;
    try {
      this.initAudio();
      if (!this.ctx) return;
      this.stopDrone();

      const now = this.ctx.currentTime;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.02, now + 1.0); // Gentle subtle ambient presence

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);

      const osc1 = this.ctx.createOscillator();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(freq, now);

      const osc2 = this.ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(freq * 1.5, now);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc1.start(now);
      osc2.start(now);

      this.droneOsc1 = osc1;
      this.droneOsc2 = osc2;
      this.droneGain = gain;
    } catch {
      // Audio fallback
    }
  }

  public stopDrone() {
    try {
      if (this.droneGain && this.ctx) {
        const now = this.ctx.currentTime;
        this.droneGain.gain.linearRampToValueAtTime(0.0001, now + 0.5);
        setTimeout(() => {
          if (this.droneOsc1) {
            try { this.droneOsc1.stop(); this.droneOsc1.disconnect(); } catch {}
            this.droneOsc1 = null;
          }
          if (this.droneOsc2) {
            try { this.droneOsc2.stop(); this.droneOsc2.disconnect(); } catch {}
            this.droneOsc2 = null;
          }
          this.droneGain = null;
        }, 600);
      }
    } catch {
      // ignore
    }
  }

  public startAmbientHum(freq = 108) {
    this.startDrone(freq);
  }

  public stopAmbientHum() {
    this.stopDrone();
  }

  public playSingingBowl(freq = 216, duration = 3.0) {
    if (this.isAmbientMuted) return;
    try {
      this.initAudio();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const oscHarmonic = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(650, now);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.997, now + duration);

      oscHarmonic.type = 'sine';
      oscHarmonic.frequency.setValueAtTime(freq * 2.01, now);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.25);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(filter);
      oscHarmonic.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      oscHarmonic.start(now);
      osc.stop(now + duration);
      oscHarmonic.stop(now + duration);
    } catch {
      // Audio fallback
    }
  }

  public playMotivatingChime() {
    this.playSingingBowl(288, 2.0);
  }

  // Finds the best natural soothing lady's voice (calm, warm, peaceful feminine cadence)
  public getBestVoice(lang = 'hi'): SpeechSynthesisVoice | null {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    const isHindi = (lang || '').toLowerCase().startsWith('hi');

    // Strict filter to reject ANY male voices across all platforms
    const isMaleVoice = (v: SpeechSynthesisVoice) => {
      const name = (v.name || '').toLowerCase();
      return (
        name.includes('male') ||
        name.includes('madhur') ||
        name.includes('rishi') ||
        name.includes('prabhat') ||
        name.includes('david') ||
        name.includes('george') ||
        name.includes('mark') ||
        name.includes('guy') ||
        name.includes('stefan') ||
        name.includes('james') ||
        name.includes('daniel') ||
        name.includes('richard') ||
        name.includes('martin') ||
        name.includes('alex')
      );
    };

    const ladyVoices = voices.filter((v) => !isMaleVoice(v));

    if (isHindi) {
      const hindiLadyVoices = ladyVoices.filter((v) => {
        const vl = (v.lang || '').toLowerCase().replace('_', '-');
        const vn = (v.name || '').toLowerCase();
        return (
          vl.startsWith('hi') ||
          vl.includes('hi-in') ||
          vl.includes('hin') ||
          vn.includes('hindi') ||
          vn.includes('devanagari') ||
          vn.includes('lekha') ||
          vn.includes('kavya') ||
          vn.includes('swara') ||
          vn.includes('kalpana') ||
          vn.includes('हिन्दी')
        );
      });

      // Priority 1: High quality natural soothing Indian lady voices
      const preferredIndianLadies = [
        'swara', // Microsoft Swara Online (Natural) - Hindi (India) - exceptionally soothing
        'lekha', // Apple Lekha - Hindi female (peaceful and calm)
        'kavya', // Apple Kavya - Hindi female
        'kalpana', // Microsoft Kalpana - Hindi female
        'female', // Explicitly marked female
        'google', // Google Hindi female
      ];

      for (const pref of preferredIndianLadies) {
        const found = hindiLadyVoices.find((v) => v.name.toLowerCase().includes(pref));
        if (found) return found;
      }

      if (hindiLadyVoices.length > 0) return hindiLadyVoices[0];

      // Priority 2: Indian English calming lady voice (e.g. Neerja / Veena) if Hindi voice not installed
      const indianEnglishLadies = ladyVoices.filter((v) => {
        const vl = (v.lang || '').toLowerCase().replace('_', '-');
        const vn = (v.name || '').toLowerCase();
        return (
          (vl.includes('en-in') || vn.includes('india')) &&
          (vn.includes('neerja') || vn.includes('veena') || vn.includes('heera') || vn.includes('female') || vn.includes('google'))
        );
      });
      if (indianEnglishLadies.length > 0) return indianEnglishLadies[0];

      // Allow native mobile OS Hindi engine via utterance.lang = 'hi-IN'
      return null;
    } else {
      // English: Prioritize calming Indian lady voices, then global soothing voices
      const indianLadies = ladyVoices.filter((v) => {
        const vl = (v.lang || '').toLowerCase().replace('_', '-');
        const vn = (v.name || '').toLowerCase();
        return (
          (vl.includes('en-in') || vn.includes('india')) &&
          (vn.includes('neerja') || vn.includes('veena') || vn.includes('heera') || vn.includes('female'))
        );
      });
      if (indianLadies.length > 0) return indianLadies[0];

      const soothingLadies = ladyVoices.filter((v) => {
        const vn = v.name.toLowerCase();
        return (
          vn.includes('jenny') ||
          vn.includes('aria') ||
          vn.includes('samantha') ||
          vn.includes('victoria') ||
          vn.includes('karen') ||
          vn.includes('female') ||
          vn.includes('natural')
        );
      });
      if (soothingLadies.length > 0) return soothingLadies[0];

      const enVoices = ladyVoices.filter((v) => (v.lang || '').toLowerCase().startsWith('en'));
      return enVoices[0] || ladyVoices[0] || null;
    }
  }

  /**
   * Continuous, Non-Stopping Mobile Speech Recitation:
   * Queues all verse segments synchronously into the native SpeechSynthesis queue during the user gesture.
   * Eliminates the destructive interval timers that caused Android/iOS to cut off after a few seconds.
   */
  public reciteBhagavadGitaVerse({
    chapter,
    verseNumber,
    sanskrit,
    translationHindi,
    motivatingTakeaway,
    lang = 'hi',
    rate,
    onStart,
    onEnd,
    onError,
  }: {
    chapter: number;
    verseNumber: number;
    sanskrit: string;
    translationHindi: string;
    motivatingTakeaway?: string;
    lang?: string;
    rate?: number;
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err: unknown) => void;
  }): () => void {
    if (this.isVoiceMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return () => {};
    }

    const verseId = `${chapter}.${verseNumber}`;

    // Update active playback state
    this.activeState.isPlaying = true;
    this.activeState.isPaused = false;
    this.activeState.currentVerseId = verseId;
    this.activeState.currentTitle = `अध्याय ${chapter}, श्लोक ${verseNumber}`;
    this.notify();

    let isCancelled = false;

    const stopAll = () => {
      isCancelled = true;
      this.stopDrone();
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
      this.activeState.isPlaying = false;
      this.activeState.isPaused = false;
      this.activeState.currentVerseId = undefined;
      this.activeState.currentTitle = undefined;
      (window as any).__activeGitaUtterances = [];
      this.notify();
    };

    try {
      this.warmUp();
      window.speechSynthesis.cancel();
      this.startDrone(216);

      const isHindi = (lang || '').toLowerCase().startsWith('hi');
      const voice = this.getBestVoice(lang);
      const chosenRate = rate || this.activeState.speed || 0.78;

      // Construct clear, structured sequential segments
      const segments: string[] = [];

      if (isHindi) {
        segments.push(`श्रीमद्भगवद्गीता, अध्याय ${chapter}, श्लोक ${verseNumber}।`);
        const cleanedShloka = cleanSanskritForSpeech(sanskrit);
        if (cleanedShloka) {
          segments.push(cleanedShloka);
        }
        const cleanedMeaning = cleanTextForSpeech(translationHindi, 'hi');
        if (cleanedMeaning) {
          // If meaning is long, split on sentence boundary for graceful delivery
          const meaningChunks = splitIntoSpeechChunks(cleanedMeaning);
          if (meaningChunks.length > 0) {
            segments.push(`श्लोक का भावार्थ - ${meaningChunks[0]}`);
            for (let i = 1; i < meaningChunks.length; i++) {
              segments.push(meaningChunks[i]);
            }
          } else {
            segments.push(`श्लोक का भावार्थ - ${cleanedMeaning}।`);
          }
        }
        if (motivatingTakeaway) {
          const cleanedTakeaway = cleanTextForSpeech(motivatingTakeaway, 'hi');
          if (cleanedTakeaway) {
            segments.push(`जीवन संदेश - ${cleanedTakeaway}।`);
          }
        }
        segments.push(`ॐ शांति, शांति, शांतिः।`);
      } else {
        segments.push(`Bhagavad Gita, Chapter ${chapter}, Verse ${verseNumber}.`);
        const cleanedShloka = cleanSanskritForSpeech(sanskrit);
        if (cleanedShloka) {
          segments.push(cleanedShloka);
        }
        const cleanedMeaning = cleanTextForSpeech(translationHindi, 'en');
        if (cleanedMeaning) {
          segments.push(`Meaning: ${cleanedMeaning}.`);
        }
        if (motivatingTakeaway) {
          const cleanedTakeaway = cleanTextForSpeech(motivatingTakeaway, 'en');
          if (cleanedTakeaway) {
            segments.push(`Guidance: ${cleanedTakeaway}.`);
          }
        }
        segments.push(`Om Shanti.`);
      }

      // Synchronously build and queue all utterances into the native SpeechSynthesis queue
      // This is the golden standard for mobile: all utterances enter the queue during the user gesture!
      const utterances: SpeechSynthesisUtterance[] = segments.map((segText, idx) => {
        const u = new SpeechSynthesisUtterance(segText);
        u.lang = isHindi ? 'hi-IN' : 'en-US';
        u.rate = isHindi ? Math.max(0.76, Math.min(0.85, chosenRate)) : chosenRate;
        u.pitch = 1.05; // Soothing, warm calming lady voice pitch
        u.volume = 0.95;

        if (voice) {
          u.voice = voice;
        }

        if (idx === 0) {
          u.onstart = () => {
            if (!isCancelled && onStart) {
              onStart();
            }
          };
        }

        if (idx === segments.length - 1) {
          u.onend = () => {
            if (!isCancelled) {
              stopAll();
              if (onEnd) onEnd();
            }
          };
        }

        u.onerror = (e) => {
          if (!isCancelled && idx === segments.length - 1) {
            stopAll();
            if (onError) onError(e);
            if (onEnd) onEnd();
          }
        };

        return u;
      });

      // Pin the array to global window to defeat mobile V8 garbage collection
      (window as any).__activeGitaUtterances = utterances;

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      // Queue every utterance synchronously into the mobile OS speech synthesis queue
      utterances.forEach((u) => {
        window.speechSynthesis.speak(u);
      });

      this.cancelCurrentSpeech = stopAll;
      return stopAll;
    } catch (err) {
      stopAll();
      if (onError) onError(err);
      if (onEnd) onEnd();
      return () => {};
    }
  }

  // Recite Chapter Overview / Summary with the same mobile-safe synchronous queue
  public speakSceneDialogue({
    text,
    lang = 'hi',
    rate,
    onStart,
    onEnd,
  }: {
    text: string;
    lang?: string;
    rate?: number;
    onStart?: () => void;
    onEnd?: () => void;
  }): () => void {
    if (this.isVoiceMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return () => {};
    }

    this.activeState.isPlaying = true;
    this.activeState.isPaused = false;
    this.notify();

    let isCancelled = false;

    const stopAll = () => {
      isCancelled = true;
      this.stopDrone();
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
      this.activeState.isPlaying = false;
      this.activeState.isPaused = false;
      (window as any).__activeDialogueUtterances = [];
      this.notify();
    };

    try {
      this.warmUp();
      window.speechSynthesis.cancel();
      this.startDrone(216);

      const isHindi = (lang || '').toLowerCase().startsWith('hi');
      const voice = this.getBestVoice(lang);
      const chosenRate = rate || this.activeState.speed || 0.78;
      const cleaned = cleanTextForSpeech(text, lang);
      const chunks = splitIntoSpeechChunks(cleaned);

      const utterances: SpeechSynthesisUtterance[] = chunks.map((chunkText, idx) => {
        const u = new SpeechSynthesisUtterance(chunkText);
        u.lang = isHindi ? 'hi-IN' : 'en-US';
        u.rate = isHindi ? Math.max(0.76, Math.min(0.85, chosenRate)) : chosenRate;
        u.pitch = 1.05;
        u.volume = 0.95;

        if (voice) u.voice = voice;

        if (idx === 0) {
          u.onstart = () => {
            if (!isCancelled && onStart) onStart();
          };
        }

        if (idx === chunks.length - 1) {
          u.onend = () => {
            if (!isCancelled) {
              stopAll();
              if (onEnd) onEnd();
            }
          };
        }

        u.onerror = () => {
          if (!isCancelled && idx === chunks.length - 1) {
            stopAll();
            if (onEnd) onEnd();
          }
        };

        return u;
      });

      (window as any).__activeDialogueUtterances = utterances;

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      utterances.forEach((u) => {
        window.speechSynthesis.speak(u);
      });

      this.cancelCurrentSpeech = stopAll;
      return stopAll;
    } catch {
      stopAll();
      if (onEnd) onEnd();
      return () => {};
    }
  }

  public speakAffirmation(affirmation: string, lang = 'hi', onEnd?: () => void) {
    this.speakCue(affirmation, lang, false, onEnd);
  }

  public speakBreathCue(
    phase: 'Inhale' | 'Hold' | 'Pause' | 'Exhale',
    mode: 'simple' | 'mindful' | 'descriptive' = 'simple',
    lang = 'hi'
  ) {
    if (this.isVoiceMuted) return;

    let text = '';
    if (lang === 'hi') {
      if (phase === 'Inhale') text = mode === 'simple' ? 'श्वास भीतर लें...' : 'धीरे से गहरी श्वास भीतर लें, स्वयं में शक्ति भरें...';
      else if (phase === 'Hold' || phase === 'Pause') text = mode === 'simple' ? 'विराम...' : 'शांति में श्वास को थामें, स्थिर रहें...';
      else if (phase === 'Exhale') text = mode === 'simple' ? 'श्वास छोड़ें...' : 'धीरे से श्वास बाहर छोड़ें, सारा तनाव विसर्जित करें...';
      else text = mode === 'simple' ? 'विराम...' : 'शांति और आत्म-विश्वास में विश्राम करें...';
    } else {
      if (phase === 'Inhale') text = mode === 'simple' ? 'Inhale...' : 'Inhale gently... breathe in courage and calm.';
      else if (phase === 'Hold' || phase === 'Pause') text = mode === 'simple' ? 'Pause...' : 'Pause... resting in quiet strength.';
      else if (phase === 'Exhale') text = mode === 'simple' ? 'Exhale...' : 'Exhale slowly... release all hesitation and stress.';
      else text = mode === 'simple' ? 'Pause...' : 'Pause... and settle into inner peace.';
    }

    this.speakCue(text, lang, true);
  }

  public speakCue(text: string, lang = 'hi', isBreathPrompt = false, onEnd?: () => void) {
    if (this.isVoiceMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }

    try {
      this.warmUp();
      window.speechSynthesis.cancel();

      const cleaned = cleanTextForSpeech(text, lang);
      const utterance = new SpeechSynthesisUtterance(cleaned);
      const isHindi = (lang || '').toLowerCase().startsWith('hi');

      utterance.lang = isHindi ? 'hi-IN' : 'en-US';
      utterance.rate = isHindi ? (isBreathPrompt ? 0.78 : 0.80) : (isBreathPrompt ? 0.74 : 0.80);
      utterance.pitch = 1.05;
      utterance.volume = 0.95;

      const preferredVoice = this.getBestVoice(lang);
      if (preferredVoice) utterance.voice = preferredVoice;

      utterance.onend = () => {
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        if (onEnd) onEnd();
      };

      (window as any).__activeCueUtterance = utterance;
      if (window.speechSynthesis.paused) window.speechSynthesis.resume();
      window.speechSynthesis.speak(utterance);
    } catch {
      if (onEnd) onEnd();
    }
  }

  // Explicit Pause, Resume, Stop Methods for UI
  public pauseSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.activeState.isPaused = true;
      this.notify();
      window.speechSynthesis.pause();
    }
  }

  public resumeSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.activeState.isPaused = false;
      this.notify();
      window.speechSynthesis.resume();
    }
  }

  public togglePlayPause() {
    if (this.activeState.isPaused) {
      this.resumeSpeaking();
    } else if (this.activeState.isPlaying) {
      this.pauseSpeaking();
    }
  }

  public stopSpeaking() {
    this.stopDrone();
    if (this.cancelCurrentSpeech) {
      this.cancelCurrentSpeech();
      this.cancelCurrentSpeech = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
    }
    this.activeState.isPlaying = false;
    this.activeState.isPaused = false;
    this.activeState.currentVerseId = undefined;
    this.activeState.currentTitle = undefined;
    (window as any).__activeGitaUtterances = [];
    (window as any).__activeDialogueUtterances = [];
    this.notify();
  }

  public setVoiceMuted(muted: boolean) {
    this.isVoiceMuted = muted;
    if (muted) {
      this.stopSpeaking();
    }
  }

  public getVoiceMuted(): boolean {
    return this.isVoiceMuted;
  }
}

export const meditationAudio = new MeditationAudioEngine();
