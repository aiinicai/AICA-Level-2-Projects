import rawVerses from '../data/fullGitaVerses.json';
import { FullGitaVerse } from '../types';

export const ALL_FULL_VERSES: FullGitaVerse[] = rawVerses as FullGitaVerse[];

// Pre-indexed map by chapter
const versesByChapterMap = new Map<number, FullGitaVerse[]>();
const versesByIdMap = new Map<string, FullGitaVerse>();

ALL_FULL_VERSES.forEach((v) => {
  if (!versesByChapterMap.has(v.chapter)) {
    versesByChapterMap.set(v.chapter, []);
  }
  versesByChapterMap.get(v.chapter)!.push(v);
  versesByIdMap.set(`${v.chapter}.${v.verse}`, v);
});

// Canonical verse counts for all 18 chapters
export const CHAPTER_VERSE_COUNTS: Record<number, number> = {
  1: 47,
  2: 72,
  3: 43,
  4: 42,
  5: 29,
  6: 47,
  7: 30,
  8: 28,
  9: 34,
  10: 42,
  11: 55,
  12: 20,
  13: 35,
  14: 27,
  15: 20,
  16: 24,
  17: 28,
  18: 78,
};

export const TOTAL_GITA_VERSES = 701;

export function getFullVersesByChapter(chapterNumber: number): FullGitaVerse[] {
  return versesByChapterMap.get(chapterNumber) || [];
}

export function getFullVerse(chapterNumber: number, verseNumber: number): FullGitaVerse | undefined {
  return versesByIdMap.get(`${chapterNumber}.${verseNumber}`);
}

export function searchFullGita(query: string): FullGitaVerse[] {
  if (!query || !query.trim()) return [];
  const q = query.trim().toLowerCase();

  // If query is e.g. "2.47" or "2:47"
  const colonMatch = q.match(/^(\d{1,2})[\.:\s]+(\d{1,3})$/);
  if (colonMatch) {
    const ch = parseInt(colonMatch[1], 10);
    const v = parseInt(colonMatch[2], 10);
    const found = getFullVerse(ch, v);
    return found ? [found] : [];
  }

  return ALL_FULL_VERSES.filter((v) => {
    return (
      v.id.includes(q) ||
      v.sanskrit.toLowerCase().includes(q) ||
      v.transliteration.toLowerCase().includes(q) ||
      v.hindi.toLowerCase().includes(q) ||
      v.english.toLowerCase().includes(q) ||
      (v.wordMeanings && v.wordMeanings.toLowerCase().includes(q))
    );
  }).slice(0, 50); // limit to top 50 results
}
