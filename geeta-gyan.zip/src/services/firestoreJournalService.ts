import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  getDocs,
} from 'firebase/firestore';
import { db } from './firebase';
import { JournalEntry } from '../types';
import { getJournalEntries } from './storageService';

/**
 * Real-time listener for the authenticated user's private journal entries.
 * Enforced by Firestore Security Rules: only the user with request.auth.uid == userId
 * can read or receive snapshots from this path.
 */
export function subscribeUserJournalEntries(
  userId: string,
  onUpdate: (entries: JournalEntry[]) => void,
  onError?: (err: Error) => void
): () => void {
  const entriesRef = collection(db, 'users', userId, 'journal_entries');
  const q = query(entriesRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: JournalEntry[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          createdAt: data.createdAt || new Date().toISOString(),
          stressCategory: data.stressCategory || 'Other',
          userInput: data.userInput || '',
          stressBefore: typeof data.stressBefore === 'number' ? data.stressBefore : 3,
          verseId: data.verseId || undefined,
          verseReference: data.verseReference || undefined,
          concept: data.concept || 'Karma Yoga (Focus on Action)',
          actionTaken: data.actionTaken || '',
          reflection: data.reflection || '',
          stressAfter: typeof data.stressAfter === 'number' ? data.stressAfter : undefined,
        });
      });
      onUpdate(items);
    },
    (error) => {
      console.error('Firestore journal subscription error:', error);
      if (onError) onError(error);
    }
  );
}

/**
 * Saves a new journal entry to the authenticated user's private collection.
 */
export async function addFirestoreJournalEntry(
  userId: string,
  entry: Omit<JournalEntry, 'id' | 'createdAt'>
): Promise<JournalEntry> {
  const entriesRef = collection(db, 'users', userId, 'journal_entries');
  const newDocRef = doc(entriesRef);
  const nowIso = new Date().toISOString();

  const newEntry: JournalEntry = {
    ...entry,
    id: newDocRef.id,
    createdAt: nowIso,
  };

  await setDoc(newDocRef, {
    ...newEntry,
    userId,
    serverTimestamp: serverTimestamp(),
  });

  return newEntry;
}

/**
 * Updates an existing journal entry in the authenticated user's private collection.
 */
export async function updateFirestoreJournalEntry(
  userId: string,
  entryId: string,
  updates: Partial<Omit<JournalEntry, 'id' | 'createdAt'>>
): Promise<void> {
  const entryDocRef = doc(db, 'users', userId, 'journal_entries', entryId);
  await updateDoc(entryDocRef, {
    ...updates,
    updatedAt: new Date().toISOString(),
    serverTimestamp: serverTimestamp(),
  });
}

/**
 * Deletes a journal entry from the authenticated user's private collection.
 */
export async function deleteFirestoreJournalEntry(
  userId: string,
  entryId: string
): Promise<void> {
  const entryDocRef = doc(db, 'users', userId, 'journal_entries', entryId);
  await deleteDoc(entryDocRef);
}

/**
 * Safe Migration:
 * When an existing user signs in with Google for the first time, safely copies
 * any existing local journal entries stored in the browser's localStorage into their
 * private Cloud Firestore vault.
 *
 * Local storage data is preserved and not deleted, ensuring complete safety.
 */
export async function migrateLocalJournalEntries(
  userId: string
): Promise<{ migratedCount: number; alreadyMigrated: boolean }> {
  const migrationKey = `geeta_gyan_journal_migrated_${userId}`;
  if (localStorage.getItem(migrationKey) === 'true') {
    return { migratedCount: 0, alreadyMigrated: true };
  }

  const localEntries = getJournalEntries();
  if (!localEntries || localEntries.length === 0) {
    localStorage.setItem(migrationKey, 'true');
    return { migratedCount: 0, alreadyMigrated: false };
  }

  try {
    // Check existing remote entries to avoid duplicates
    const entriesRef = collection(db, 'users', userId, 'journal_entries');
    const existingSnap = await getDocs(entriesRef);
    const existingIds = new Set(existingSnap.docs.map((d) => d.id));

    let count = 0;
    for (const entry of localEntries) {
      // Use existing entry ID or generate new doc ID
      const targetDocId = entry.id || `entry-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      if (!existingIds.has(targetDocId)) {
        const targetDocRef = doc(db, 'users', userId, 'journal_entries', targetDocId);
        await setDoc(targetDocRef, {
          ...entry,
          id: targetDocId,
          userId,
          migratedFromLocal: true,
          migratedAt: new Date().toISOString(),
          serverTimestamp: serverTimestamp(),
        });
        count++;
      }
    }

    localStorage.setItem(migrationKey, 'true');
    return { migratedCount: count, alreadyMigrated: false };
  } catch (err) {
    console.error('Safe journal migration error:', err);
    return { migratedCount: 0, alreadyMigrated: false };
  }
}
