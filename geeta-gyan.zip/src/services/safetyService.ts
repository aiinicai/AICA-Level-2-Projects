import { CrisisResource, SafetyCheckResult } from '../types';

/**
 * Authentic, verified national crisis helplines and mental health emergency lines.
 * Strictly NO fabricated numbers.
 */
export const VERIFIED_CRISIS_RESOURCES: CrisisResource[] = [
  // India
  {
    country: 'India',
    serviceName: 'Tele-MANAS (Govt of India 24/7 Mental Health Helpline)',
    contact: '14416',
    description: 'Toll-free 24/7 tele-mental health support across all Indian states and languages.',
    available: '24/7, Free, Confidential',
    isTel: true,
  },
  {
    country: 'India',
    serviceName: 'KIRAN (National Mental Health Helpline)',
    contact: '1800-599-0019',
    description: 'Government 24/7 helpline providing psychological first aid and crisis management.',
    available: '24/7, Toll-free',
    isTel: true,
  },
  {
    country: 'India',
    serviceName: 'Vandrevala Foundation',
    contact: '+91 9999 666 555',
    description: 'Free, professional 24/7 counseling helpline by mental health professionals.',
    available: '24/7, Free',
    isTel: true,
  },

  // United States & Canada
  {
    country: 'United States & Canada',
    serviceName: '988 Suicide & Crisis Lifeline',
    contact: '988',
    description: 'Call or text 988 for free, confidential support anytime.',
    available: '24/7, Free, Confidential',
    isTel: true,
  },
  {
    country: 'United States',
    serviceName: 'Crisis Text Line',
    contact: 'HOME to 741741',
    description: 'Text support from trained crisis volunteers.',
    available: '24/7, Free',
    isTel: false,
  },

  // United Kingdom
  {
    country: 'United Kingdom',
    serviceName: 'Samaritans UK',
    contact: '116 123',
    description: 'Free, compassionate 24/7 support line for anyone in distress or needing to talk.',
    available: '24/7, Free from any phone',
    isTel: true,
  },
  {
    country: 'United Kingdom',
    serviceName: 'NHS Urgent Mental Health Services',
    contact: '111',
    description: 'Call 111 for immediate mental health clinical triage and advice.',
    available: '24/7, Free',
    isTel: true,
  },

  // International
  {
    country: 'International',
    serviceName: 'Befrienders Worldwide',
    contact: 'befrienders.org',
    description: 'Global directory of confidential emotional support centers worldwide.',
    available: 'Online Directory',
    isTel: false,
  },
  {
    country: 'International',
    serviceName: 'Find A Helpline (IASP Verified)',
    contact: 'findahelpline.com',
    description: 'Free, confidential support from local helplines in over 130 countries.',
    available: 'Global Search',
    isTel: false,
  }
];

const CRISIS_TRIGGER_PATTERNS: RegExp[] = [
  /suicid/i,
  /kill\s+(myself|me)/i,
  /end\s+(my\s+life|it\s+all)/i,
  /want\s+to\s+die/i,
  /better\s+off\s+dead/i,
  /self[- ]harm/i,
  /cutting\s+myself/i,
  /hurt\s+myself/i,
  /hang\s+myself/i,
  /overdose/i,
  /jump\s+off/i,
  /take\s+my\s+(own\s+)?life/i,
  /don'?t\s+want\s+to\s+live/i,
  /can'?t\s+go\s+on\s+living/i,
  /no\s+reason\s+to\s+live/i,
  /abuse|abused|abusive\s+partner/i,
  /domestic\s+violence/i,
  /being\s+hit|being\s+beaten/i,
  /physical\s+danger/i
];

/**
 * Checks user input for acute crisis, self-harm, or immediate danger.
 * Returns true if crisis patterns are detected so the UI can instantly divert
 * away from regular spiritual reflection to the dedicated Calm Safety Screen.
 */
export function checkSafety(input: string): SafetyCheckResult {
  if (!input || typeof input !== 'string') {
    return {
      isCrisis: false,
      resources: VERIFIED_CRISIS_RESOURCES,
    };
  }

  const normalized = input.trim().toLowerCase();
  const matchedPatterns: string[] = [];

  for (const regex of CRISIS_TRIGGER_PATTERNS) {
    if (regex.test(normalized)) {
      matchedPatterns.push(regex.source);
    }
  }

  if (matchedPatterns.length > 0) {
    return {
      isCrisis: true,
      reason: 'Acute crisis, self-harm, or severe safety concern detected.',
      detectedTerms: matchedPatterns,
      resources: VERIFIED_CRISIS_RESOURCES,
    };
  }

  return {
    isCrisis: false,
    resources: VERIFIED_CRISIS_RESOURCES,
  };
}
