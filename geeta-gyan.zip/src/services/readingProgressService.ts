import { ReadingProgress } from '../types';
import { CHAPTER_VERSE_COUNTS, TOTAL_GITA_VERSES } from './fullGitaService';

const STORAGE_READING_PROGRESS_KEY = 'geeta_gyan_reading_progress';

const DEFAULT_PROGRESS: ReadingProgress = {
  lastReadChapter: 1,
  lastReadVerse: 1,
  readVerseIds: [],
  lastReadTimestamp: Date.now(),
};

type ProgressListener = (progress: ReadingProgress) => void;
const listeners = new Set<ProgressListener>();

export function subscribeToReadingProgress(listener: ProgressListener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifyListeners(progress: ReadingProgress) {
  listeners.forEach((fn) => {
    try {
      fn(progress);
    } catch (err) {
      console.error('Error in progress listener:', err);
    }
  });
}

export function getReadingProgress(): ReadingProgress {
  try {
    const raw = localStorage.getItem(STORAGE_READING_PROGRESS_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw);
    return {
      lastReadChapter: typeof parsed.lastReadChapter === 'number' ? parsed.lastReadChapter : 1,
      lastReadVerse: typeof parsed.lastReadVerse === 'number' ? parsed.lastReadVerse : 1,
      readVerseIds: Array.isArray(parsed.readVerseIds) ? parsed.readVerseIds : [],
      lastReadTimestamp: typeof parsed.lastReadTimestamp === 'number' ? parsed.lastReadTimestamp : Date.now(),
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

function persistProgress(progress: ReadingProgress): ReadingProgress {
  try {
    localStorage.setItem(STORAGE_READING_PROGRESS_KEY, JSON.stringify(progress));
  } catch (err) {
    console.error('Failed to persist reading progress:', err);
  }
  notifyListeners(progress);
  return progress;
}

/**
 * Record that the user is currently reading this verse, and optionally mark it as read.
 */
export function recordVerseRead(chapter: number, verse: number, markAsRead: boolean = true): ReadingProgress {
  const current = getReadingProgress();
  const verseId = `${chapter}.${verse}`;
  const readVerseIdsSet = new Set(current.readVerseIds);

  if (markAsRead) {
    readVerseIdsSet.add(verseId);
  }

  const updated: ReadingProgress = {
    lastReadChapter: chapter,
    lastReadVerse: verse,
    readVerseIds: Array.from(readVerseIdsSet),
    lastReadTimestamp: Date.now(),
  };

  return persistProgress(updated);
}

/**
 * Toggle whether a specific verse is marked as read.
 */
export function toggleVerseRead(chapter: number, verse: number): { progress: ReadingProgress; isNowRead: boolean } {
  const current = getReadingProgress();
  const verseId = `${chapter}.${verse}`;
  const readVerseIdsSet = new Set(current.readVerseIds);

  let isNowRead = false;
  if (readVerseIdsSet.has(verseId)) {
    readVerseIdsSet.delete(verseId);
    isNowRead = false;
  } else {
    readVerseIdsSet.add(verseId);
    isNowRead = true;
  }

  const updated: ReadingProgress = {
    ...current,
    lastReadChapter: chapter,
    lastReadVerse: verse,
    readVerseIds: Array.from(readVerseIdsSet),
    lastReadTimestamp: Date.now(),
  };

  return { progress: persistProgress(updated), isNowRead };
}

/**
 * Mark all verses in a chapter as read.
 */
export function markChapterAllVersesRead(chapter: number): ReadingProgress {
  const current = getReadingProgress();
  const maxVerses = CHAPTER_VERSE_COUNTS[chapter] || 47;
  const readVerseIdsSet = new Set(current.readVerseIds);

  for (let v = 1; v <= maxVerses; v++) {
    readVerseIdsSet.add(`${chapter}.${v}`);
  }

  const updated: ReadingProgress = {
    ...current,
    lastReadChapter: chapter,
    lastReadVerse: maxVerses,
    readVerseIds: Array.from(readVerseIdsSet),
    lastReadTimestamp: Date.now(),
  };

  return persistProgress(updated);
}

/**
 * Mark all verses up to a specific verse as read (e.g. read sequentially).
 */
export function markAllUpToVerseRead(chapter: number, verse: number): ReadingProgress {
  const current = getReadingProgress();
  const readVerseIdsSet = new Set(current.readVerseIds);

  // Mark all previous chapters fully read
  for (let c = 1; c < chapter; c++) {
    const cMax = CHAPTER_VERSE_COUNTS[c] || 0;
    for (let v = 1; v <= cMax; v++) {
      readVerseIdsSet.add(`${c}.${v}`);
    }
  }

  // Mark current chapter up to verse
  for (let v = 1; v <= verse; v++) {
    readVerseIdsSet.add(`${chapter}.${v}`);
  }

  const updated: ReadingProgress = {
    lastReadChapter: chapter,
    lastReadVerse: verse,
    readVerseIds: Array.from(readVerseIdsSet),
    lastReadTimestamp: Date.now(),
  };

  return persistProgress(updated);
}

/**
 * Calculate the next verse to read.
 * If current is at the end of a chapter, moves to verse 1 of next chapter.
 */
export function getNextVerseToRead(progress: ReadingProgress): { chapter: number; verse: number } {
  const currentCh = progress.lastReadChapter || 1;
  const currentV = progress.lastReadVerse || 1;
  const maxVersesInCurrentCh = CHAPTER_VERSE_COUNTS[currentCh] || 47;

  if (currentV < maxVersesInCurrentCh) {
    return { chapter: currentCh, verse: currentV + 1 };
  } else if (currentCh < 18) {
    return { chapter: currentCh + 1, verse: 1 };
  } else {
    // Finished Gita! Return 1.1 or 18.78
    return { chapter: 18, verse: maxVersesInCurrentCh };
  }
}

/**
 * Get read statistics for a specific chapter.
 */
export function getChapterReadStats(
  chapter: number,
  progress: ReadingProgress
): { readCount: number; totalCount: number; percent: number; isCompleted: boolean } {
  const totalCount = CHAPTER_VERSE_COUNTS[chapter] || 47;
  const prefix = `${chapter}.`;
  const readCount = progress.readVerseIds.filter((id) => id.startsWith(prefix)).length;
  const percent = totalCount > 0 ? Math.min(100, Math.round((readCount / totalCount) * 100)) : 0;
  return {
    readCount,
    totalCount,
    percent,
    isCompleted: readCount >= totalCount,
  };
}

/**
 * Get overall Gita read statistics across all 701 verses.
 */
export function getOverallReadStats(progress: ReadingProgress): {
  totalRead: number;
  totalVerses: number;
  percent: number;
  completedChaptersCount: number;
} {
  const totalRead = progress.readVerseIds.length;
  const totalVerses = TOTAL_GITA_VERSES;
  const percent = Math.min(100, Math.round((totalRead / totalVerses) * 100));

  let completedChaptersCount = 0;
  for (let c = 1; c <= 18; c++) {
    if (getChapterReadStats(c, progress).isCompleted) {
      completedChaptersCount++;
    }
  }

  return {
    totalRead,
    totalVerses,
    percent,
    completedChaptersCount,
  };
}

export function resetReadingProgress(): ReadingProgress {
  localStorage.removeItem(STORAGE_READING_PROGRESS_KEY);
  notifyListeners(DEFAULT_PROGRESS);
  return DEFAULT_PROGRESS;
}
