import { collection, getDocs, doc, getDoc, setDoc } from 'firebase/firestore';
import { db, UserProfile } from './firebase';

export interface AdminAppStats {
  totalRegisteredUsers: number;
  adminUsersCount: number;
  recentActiveUsersCount: number;
  usersList: Array<{
    uid: string;
    displayName: string;
    email: string;
    role: string;
    createdAt?: string;
    lastLoginAt?: string;
  }>;
}

/**
 * Fetches non-sensitive platform statistics for the administrator.
 * Protected by Firestore Security Rules: only an authenticated user matching
 * isAdmin() can read the users collection roster.
 *
 * CRITICAL PRIVACY ARCHITECTURE:
 * This service explicitly does NOT and CANNOT query any user's private journal entries.
 * The Firestore Security Rules strictly forbid any administrator from reading another user's journal.
 */
export async function getAdminPlatformStats(): Promise<AdminAppStats> {
  const usersRef = collection(db, 'users');
  const snap = await getDocs(usersRef);

  let totalUsers = 0;
  let adminCount = 0;
  let recentActive = 0;
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;

  const usersList: AdminAppStats['usersList'] = [];

  snap.forEach((docSnap) => {
    totalUsers++;
    const data = docSnap.data() as UserProfile;
    if (data.role === 'admin') {
      adminCount++;
    }

    if (data.lastLoginAt) {
      const loginTime = new Date(data.lastLoginAt).getTime();
      if (!isNaN(loginTime) && loginTime > thirtyDaysAgo) {
        recentActive++;
      }
    }

    usersList.push({
      uid: docSnap.id,
      displayName: data.displayName || 'Seeker',
      email: data.email ? `${data.email.slice(0, 3)}***@${data.email.split('@')[1] || 'domain.com'}` : 'Private',
      role: data.role || 'user',
      createdAt: data.createdAt,
      lastLoginAt: data.lastLoginAt,
    });
  });

  return {
    totalRegisteredUsers: totalUsers,
    adminUsersCount: adminCount,
    recentActiveUsersCount: recentActive,
    usersList,
  };
}
