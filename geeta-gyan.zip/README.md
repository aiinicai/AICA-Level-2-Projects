# Geeta Gyan — Ancient Wisdom for Modern Peace

> **Practical, authentic Bhagavad Gita insights and actionable resets for everyday stress.**

Geeta Gyan bridges timeless wisdom from the Bhagavad Gita with modern mindfulness techniques, designed to help you navigate modern life's anxieties, career dilemmas, relationship strains, and burnout.

---

## 🌟 Key Features

- **Categorized Guidance**: 11 carefully mapped real-life stress situations (Work Pressure, Overthinking, Relationship Strain, Fear of Failure, Burnout, Loneliness, Decision Paralysis, Anger & Resentment, Grief, Envy & Comparison, Health Anxiety).
- **Chapter-wise Exploration (18 Chapters)**: Comprehensive exploration of all 18 chapters of the Bhagavad Gita (Karma Yoga Ch 1–6, Bhakti Yoga Ch 7–12, Jnana Yoga Ch 13–18). Features chapter essences, modern psychological takeaways, search/filters, bookmarking, and soothing Hindi voice audio narration.
- **Authentic Verses**: Direct Sanskrit shlokas from the Bhagavad Gita along with classical interpretations (Gita Press tradition) and modern actionable takeaways.
- **Bilingual Experience**:
  - **Spoken Audio**: Defaults to Hindi for authentic Vedic resonance and comforting voice cues.
  - **Written UI**: Defaults to clean English typography for clarity and readability.
  - Both customizable independently in **Settings**.
- **Mahabharata Visual Stories**: Interactive canvas re-enactment of Arjuna's dialogue with Sri Krishna on the battlefield of Kurukshetra with voice cues and synchronized subtitles.
- **Audio Recitation & Meditation**:
  - Web Audio synthetic Tibetan singing bowls (528 Hz, 432 Hz).
  - 10-Second Quick Calming Breath mode with gentle audio prompts.
  - 2-Minute Reset with 4-4-4 box breathing visualization.
- **Daily Calm & Affirmations**: Daily verse cards and reflections to start or end your day grounded.
- **PWA & Offline-Ready**: Fast, responsive Progressive Web App that works on desktop and mobile.
- **Privacy First**: 100% client-side storage for saved verses, notes, and preferences. No tracking.

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or bun

### Installation

1. Clone or extract the repository:
```bash
git clone https://github.com/<your-username>/geeta-gyan.git
cd geeta-gyan
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Building for Production

```bash
npm run build
```
The production bundle will be generated in the `dist/` directory.

---

## 🛠️ Tech Stack

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4
- **Icons**: Lucide React
- **Audio Engine**: Web Audio API (real-time harmonic synthesis for singing bowls) & Web Speech API
- **PWA**: `vite-plugin-pwa`

---

## 📜 License

MIT License. Free to use, share, and build upon.
