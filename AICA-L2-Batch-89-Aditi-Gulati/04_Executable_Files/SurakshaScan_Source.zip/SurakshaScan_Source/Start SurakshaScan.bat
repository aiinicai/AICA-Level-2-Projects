@echo off
REM ===================================================================
REM  Run SurakshaScan from source - double-click this file.
REM
REM  For a machine that has Python but no .exe built yet. Sets up the
REM  virtual environment on first run, then just opens the app.
REM ===================================================================
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo  First run - setting up. This takes a few minutes...
    python -m venv .venv
    if errorlevel 1 (
        echo.
        echo  Python was not found. Install it from python.org and tick
        echo  "Add python.exe to PATH" during installation.
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo  Setup failed. Read the messages above.
        pause
        exit /b 1
    )
)

start "" ".venv\Scripts\pythonw.exe" run.py
exit /b 0
