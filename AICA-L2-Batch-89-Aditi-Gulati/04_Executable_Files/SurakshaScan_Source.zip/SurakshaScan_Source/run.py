"""
Launcher.

Running from source:   python run.py
Running from a build:  double-click SurakshaScan.exe

A windowed PyInstaller build has no console, so an unhandled exception would
otherwise vanish silently and the app would appear to do nothing when
double-clicked. Everything is wrapped so a failure produces a readable
message and a log file the user can send on.
"""

from __future__ import annotations

import sys
import traceback
from datetime import datetime
from pathlib import Path


def _crash_log_path() -> Path:
    directory = Path.home() / ".surakshascan"
    directory.mkdir(parents=True, exist_ok=True)
    return directory / "last_error.txt"


def _report(exc: BaseException) -> None:
    details = "".join(traceback.format_exception(type(exc), exc,
                                                 exc.__traceback__))
    log = _crash_log_path()
    try:
        log.write_text(
            f"SurakshaScan error\n{datetime.now():%d %B %Y %H:%M:%S}\n"
            f"Python {sys.version}\nFrozen: {getattr(sys, 'frozen', False)}\n\n"
            f"{details}", encoding="utf-8")
    except OSError:
        pass

    message = (
        "SurakshaScan could not start.\n\n"
        f"{type(exc).__name__}: {exc}\n\n"
        f"The full details were written to:\n{log}\n\n"
        "Send that file on if you need help with it.")
    print(message, file=sys.stderr)
    try:
        import tkinter
        from tkinter import messagebox
        root = tkinter.Tk()
        root.withdraw()
        messagebox.showerror("SurakshaScan", message)
        root.destroy()
    except Exception:
        pass


def main() -> int:
    try:
        from surakshascan.ui.app import main as run_app
        run_app()
        return 0
    except BaseException as exc:            # noqa: BLE001 - last line of defence
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        _report(exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
