# Building and running

## Run from source

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
pip install -r requirements.txt
python run.py                    # the desktop app
```

Command line:

```bash
python -m surakshascan.cli scan --name "My School" --url https://myschool.edu.in \
    --docx report.docx --xlsx workings.xlsx --html dashboard.html --verbose
```

## Tests

```bash
pytest tests -q
```

If pytest is not available, `python tests/run_tests.py` runs the same suite
with a small bundled shim. All 28 tests run against local HTML fixtures and
touch no network.

## Build the executable

```bash
pyinstaller SurakshaScan.spec
```

`dist/SurakshaScan.exe` is the result. Test it on a machine that has no Python
installed — a PyInstaller build that works on the build machine and nowhere
else is the usual first bug. Keep the source: the executable is an artefact of
the repository, not a replacement for it.

## The API key

The AI layer and the vision document review need an Anthropic API key. It is
never stored by the application and never written into the evidence file.

Preferred — the OS credential store:

```python
import keyring
keyring.set_password("surakshascan", "anthropic_api_key", "sk-...")
```

Or the environment:

```bash
setx ANTHROPIC_API_KEY "sk-..."     # Windows, new shell needed
export ANTHROPIC_API_KEY="sk-..."   # macOS and Linux
```

Without a key the tool runs in full and says so in the report. It does not
print a placeholder and call it analysis.

## The MCP server

```bash
pip install "mcp[cli]"
python -m surakshascan.mcp_server
```

Read-only by default. To allow it to write report files:

```bash
set SURAKSHASCAN_MCP_ALLOW_WRITE=1
set SURAKSHASCAN_MCP_OUTPUT_DIR=C:\Users\you\SurakshaScan_reports
```

Grant the narrowest scope that works, and connect read-only first.
