# The ERP, the accounts, and AI

## Why this is the biggest surface

The website is a brochure. The social feed is a shop window. The ERP is where
every student's date of birth, parent phone number, medical note, fee ledger
and often a biometric template actually sits.

Three provisions do the work:

**Section 8(1)** — the school stays the Data Fiduciary even though a vendor
runs the system. Buying the software does not transfer the duty. If the vendor
is breached, **section 8(6) and Rule 7** make *the school* notify every
affected parent and report to the Board.

**Section 8(2)** — a processor may be engaged *only under a valid contract*.
Most school ERP arrangements are a purchase order plus the vendor's standard
terms, with no data-processing clauses at all. That is a gap today, not one
that waits for 14 May 2027.

**The Fourth Schedule does not rescue this.** It touches only sections 9(1)
and 9(3). Necessity, notice, security, breach, retention, grievance and the
data principal rights all apply in full. And fee collection is commercial
administration, which is harder to call an academic activity than teaching is.

## The design rule

> **This module reads structure, not children.**

An export is analysed for its column headers, its row counts and its
staleness. The tool reports that a column called `Aadhaar No` exists and is
populated in 80 of 120 rows. It does not read, store, transmit or retain the
numbers, and nothing from the file reaches the evidence file.

A compliance tool that accumulated a second copy of every school's student
database would be a worse risk than the one it was brought in to assess.
There is a test — `test_no_value_from_the_export_is_retained` — that takes a
row of the fixture and fails if any distinctive value from it appears anywhere
in the output.

The same rule governs the accounting side: field *presence* is counted, never
a ledger name, phone number, PAN, bank particular or balance.

## What it looks for in an export

| Category | Example columns | Why it matters |
|---|---|---|
| Government identifier | Aadhaar, PAN, passport | Rarely necessary in a school database; the most damaging field to lose |
| Student identifier | APAAR, UDISE | Permanent national identifiers; purpose should be stated |
| Special category | Caste, religion | Needs a statutory reason, not a habit |
| Possible caste category | A column named `Category` | In an Indian school record this usually means caste — confirm |
| Health | Blood group, medical notes, allergies, disability | Health data about a child |
| Biometric | Fingerprint, face template | Cannot be reissued if it leaks |
| Financial | Bank account, IFSC, UPI, card | Parent and staff financial data |
| Location | GPS, pickup point | Continuous location of a child |
| Credential | Password columns | Should be hashed, never exportable |
| Date of birth, home address, contact, photograph | | Ordinary but still personal data |

It also estimates **staleness** — how many records belong to students who have
left — from a status or leaving-date column, and reports the oldest year it
can see in the data.

## Running it

**An ERP or fee export:**

```powershell
python -m surakshascan.cli scan --name "My School" --url https://myschool.edu.in `
    --system-export "students.csv" --docx report.docx
```

CSV and XLSX both work. Ask the school for an export with *all* columns, not
a tidied one — the point is to see what the database actually holds.

**TallyPrime**, read-only, from its own local interface:

```powershell
python -m surakshascan.cli scan --name "My School" --url https://myschool.edu.in `
    --tally --tally-port 9000
```

Open a **test or backup company** first, as the course material advises, and
enable the connectivity setting in TallyPrime. The request sent is an
`Export`/`Collection` for ledger masters. A test asserts that no `IMPORT`,
`ALTER`, `DELETE` or `CREATE` verb appears in it.

In the desktop app, both live on the **Core systems** tab.

## AI

Two different problems, and only one is visible from outside.

**On the website** — a chatbot, an admissions assistant or a proctoring widget
receives whatever a visitor types, which on a school site may be a child, and
sends it to a third party. The scanner detects sixteen common vendors and
finding S6 checks whether they are named in the published notice.

**Inside the school** — a teacher pasting a class list into a general-purpose
chatbot to draft report-card comments. This is the fastest-growing unrecorded
disclosure in schools and the hardest to undo: the data is with a third party,
usually abroad, usually on consumer terms permitting the provider to use the
input, with no section 8(2) contract and no record that it happened. Once
pasted, the school cannot withdraw it, cannot answer an erasure request about
it, and cannot say where it went.

No scan can see this, so it is covered in the working paper — questions Q35 to
Q39 on the **Core Systems and AI** tab, including one that simply asks staff
whether they already do it. Ask that one without blame; the purpose is to find
out, not to discipline.

**On profiling:** the Fourth Schedule permits tracking and behavioural
monitoring for academic activity and for the safety of enrolled students.
Learning analytics that informs teaching can sit inside that. Scoring a
child's attention, emotion or behaviour as a product feature does not.

## The obligations this feeds

| Ref | Obligation | Decided by |
|---|---|---|
| S1 | The student database holds only categories with a stated purpose | The export's structure |
| S2 | Records of former students are not retained indefinitely | The export, plus the questionnaire |
| S3 | Accounting records holding parent and staff data are governed | Tally masters, plus the questionnaire |
| S4 | AI tools used with student data are approved and contracted | Questionnaire |
| S5 | Student personal data is not entered into general-purpose AI tools | Questionnaire |
| S6 | AI features on the site are disclosed, and AI is not used to profile students | The website, plus the questionnaire |

## What to tell the school

- Print the ERP column list and write the purpose beside each one. The blank
  rows are the finding.
- Ask the vendor **in writing** how a student record is deleted — then delete
  one, so you know it works.
- Bring the accounting system into the register of processing. It is usually
  the least governed system in the building because it sits with the
  accountant.
- Decide which AI tools are permitted, on a paid tier whose terms exclude
  training on inputs.
- Issue one page on what never goes into an AI tool — and say what staff
  should do instead. A prohibition with no alternative is ignored within a
  term.
