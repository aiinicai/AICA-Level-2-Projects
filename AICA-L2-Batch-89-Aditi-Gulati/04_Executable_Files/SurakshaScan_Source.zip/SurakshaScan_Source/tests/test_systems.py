"""
The core-systems analyser must read the shape of the data and never the data.
"""

from pathlib import Path

import pytest

from surakshascan import evidence, rules_engine, scoring, systems
from surakshascan.config import Settings
from surakshascan.dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from surakshascan.scanner import Scanner

from test_scanner import FIXTURES, FakeSession

ERP = FIXTURES / "erp_students.csv"
LMS = FIXTURES / "lms_classroom.csv"


@pytest.fixture
def systems_review():
    return systems.build(export_paths=[
        ("Student records / ERP", str(ERP)),
        ("Learning platform (Classroom)", str(LMS))])


@pytest.fixture
def plain_scan():
    settings = Settings()
    settings.crawl_delay = 0.0
    settings.max_retries = 0
    settings.respect_robots = False
    session = FakeSession({
        "https://x.example": (FIXTURES / "weak_school.html").read_text()})
    return Scanner(settings=settings, session=session).scan(
        "X", "https://x.example")


# --------------------------------------------------------- classification

@pytest.mark.parametrize if False else (lambda f: f)
def test_columns_are_classified_correctly():
    expected = {
        "Student Name": "Name",
        "DOB": "Date of birth",
        "Aadhaar No": "Government identifier",
        "APAAR ID": "Student identifier",
        "Category": "Possible caste category",
        "Blood Group": "Health",
        "Portal Password": "Credential",
        "Teacher Remarks": "Behavioural note",
        "Bus Stop": "Location",
        "Father Mobile": "Contact",
        "Marks Obtained": "Academic performance",
        "Status": "Record status",
    }
    for header, category in expected.items():
        assert systems.classify_column(header)[0] == category, header


def test_remarks_is_not_mistaken_for_marks():
    """'Remarks' contains 'marks' - word boundaries must hold."""
    assert systems.classify_column("Remarks")[0] == "Behavioural note"
    assert systems.classify_column("Teacher Remarks")[0] == "Behavioural note"
    assert systems.classify_column("Marks Obtained")[0] == "Academic performance"


def test_an_unknown_column_is_not_guessed_at():
    assert systems.classify_column("XQ7 Field")[0] is None


# ------------------------------------------------------------- the shape

def test_the_export_shape_is_reported(systems_review):
    erp = next(s for s in systems_review.systems if "ERP" in s["system_name"])
    assert erp["rows"] == 5
    assert erp["columns"] == 24
    assert erp["inactive_rows"] == 2
    assert erp["oldest_year"] == 2018
    aadhaar = next(f for f in erp["findings"] if f["column"] == "Aadhaar No")
    assert aadhaar["populated"] == 5
    assert aadhaar["fill_rate"] == 100.0


def test_a_partly_filled_column_reports_its_fill_rate(systems_review):
    erp = next(s for s in systems_review.systems if "ERP" in s["system_name"])
    medical = next(f for f in erp["findings"] if f["column"] == "Medical Notes")
    assert medical["populated"] == 2
    assert medical["fill_rate"] == 40.0


def test_high_harm_categories_are_surfaced(systems_review):
    found = systems_review.counts["high_harm_categories"]
    for category in ("Government identifier", "Student identifier", "Health",
                     "Credential", "Possible caste category"):
        assert category in found


def test_unclassified_columns_are_listed_for_manual_review(systems_review):
    lms = next(s for s in systems_review.systems if "Learning" in s["system_name"])
    assert lms["unclassified_columns"]
    assert any("could not be classified" in n for n in lms["notes"])


def test_a_missing_export_does_not_raise():
    result = systems.build(export_paths=["/no/such/file.csv"])
    assert result.systems[0]["errors"]
    assert result.counts["systems_reviewed"] == 0


def test_an_unsupported_format_is_refused_clearly(tmp_path):
    path = tmp_path / "export.pdf"
    path.write_bytes(b"%PDF-1.4")
    result = systems.analyse_export(path)
    assert any("unsupported export format" in e for e in result["errors"])


# ------------------------------------------- the data itself never escapes

def test_no_cell_value_appears_anywhere_in_the_output(systems_review):
    """
    The whole design rests on this. Column names and counts may travel;
    a child's name, Aadhaar number or address may not.
    """
    blob = repr(systems_review.to_dict())
    for value in ("Aarav", "Sharma", "Priya", "Ishaan", "123456789012",
                  "9876543210", "Civil Lines", "Peanut allergy", "x9f2",
                  "aarav@school.example"):
        assert value not in blob, f"{value!r} leaked into the output"


def test_no_cell_value_reaches_the_evidence_file(tmp_path, systems_review):
    path = evidence.save("X School", {"systems": systems_review.to_dict()},
                         directory=tmp_path)
    text = path.read_text(encoding="utf-8")
    for value in ("Aarav", "123456789012", "Peanut allergy", "x9f2"):
        assert value not in text, f"{value!r} reached the evidence file"
    assert "Aadhaar No" in text, "column names should still be recorded"


# ---------------------------------------------------- rules integration

def test_systems_findings_are_not_assessed_without_an_export(plain_scan):
    findings = {f.obligation_id: f for f in rules_engine.assess(plain_scan)}
    for ref in ("S1", "S2", "S4"):
        assert findings[ref].status == NOT_ASSESSED


def test_high_harm_columns_fail_S1(plain_scan, systems_review):
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, systems=systems_review)}
    assert findings["S1"].status == GAP
    assert findings["S1"].decided_by == "systems"
    assert any("Aadhaar" in e for e in findings["S1"].evidence)


def test_retained_leavers_fail_S2(plain_scan, systems_review):
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, systems=systems_review)}
    assert findings["S2"].status == GAP
    assert "left" in findings["S2"].rationale


def test_the_learning_platform_is_assessed(plain_scan, systems_review):
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, systems=systems_review)}
    assert findings["S4"].status in (PARTIAL, GAP)
    assert findings["S4"].decided_by == "systems"


def test_reviewing_systems_widens_coverage(plain_scan, systems_review):
    without = scoring.score_findings("x", "t", rules_engine.assess(plain_scan))
    with_systems = scoring.score_findings(
        "x", "t", rules_engine.assess(plain_scan, systems=systems_review))
    assert with_systems.coverage_percent > without.coverage_percent


# ------------------------------------------------------------ accounting

def test_tally_is_read_only_and_degrades_quietly():
    """No TallyPrime is running here, so this must fail without raising."""
    result = systems.read_accounting(host="127.0.0.1", port=59999)
    assert result["reachable"] is False
    assert result["errors"]
    assert result["ledgers"] == 0


def test_the_tally_request_writes_nothing():
    request = systems.TALLY_REQUEST
    assert "<TALLYREQUEST>Export</TALLYREQUEST>" in request
    assert 'ISMODIFY="No"' in request
    for forbidden in ("Import", "ALTER", "DELETE", "CREATE"):
        assert forbidden not in request, f"{forbidden} appears in the request"


def test_accounting_not_reached_means_S3_is_not_assessed(plain_scan, systems_review):
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, systems=systems_review)}
    assert findings["S3"].status == NOT_ASSESSED


def test_tally_ledgers_are_parsed_into_counts_only():
    """Exercise the parser against a saved response, with no Tally running."""
    payload = (FIXTURES / "tally_ledgers.xml").read_text(encoding="utf-8")
    parsed = systems.parse_ledgers(payload)
    assert not parsed["error"]
    assert parsed["ledgers"] >= 3
    assert parsed["party_ledgers"] >= 3
    fields = parsed["fields"]
    assert fields["Mobile number"]["populated"] >= 3
    assert fields["Mobile number"]["category"] == "Contact"
    assert "Postal address" in fields
    # Only counts come back - no ledger name, number or address.
    blob = repr(parsed)
    for value in ("9812345670", "p1@example.com", "House 1", "ABCDE1234F",
                  "Parent - ADM2001", "123456789012"):
        assert value not in blob, f"{value!r} leaked out of the parser"


def test_a_malformed_tally_reply_is_refused_not_guessed_at():
    parsed = systems.parse_ledgers("this is not xml at all")
    assert parsed["error"]
    assert parsed["ledgers"] == 0


def test_S1_counts_and_names_the_same_high_harm_columns(plain_scan):
    """The sentence once said '2 columns' and then named four categories."""
    review = systems.build(export_paths=[str(FIXTURES / "erp_export.csv")])
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, systems=review)}
    s1 = findings["S1"]
    count = int(s1.rationale.split()[0])
    assert count == len(s1.evidence), (s1.rationale, len(s1.evidence))
    for category in review.counts["high_harm_categories"]:
        assert any(category in e for e in s1.evidence), category
