"""
A stand-in for tkinter, so the desktop window can be built on a machine with
no display.

It does not test that the app LOOKS right - nothing can do that without eyes
on a screen. It tests that building the window runs to completion: no typo in
an attribute name, no widget referenced before it is created, no handler
wired to a method that does not exist. That is the class of mistake that
turns into "the app opens to a blank screen" on someone else's machine.

Real tkinter is used when it is importable, so on Windows the same test
exercises the real toolkit.
"""

from __future__ import annotations

import sys
import types

BOTH = "both"; END = "end"; LEFT = "left"; RIGHT = "right"
W = "w"; X = "x"; Y = "y"; CENTER = "center"


class _Var:
    def __init__(self, master=None, value=None, **kwargs):
        self._value = value if value is not None else ""

    def get(self):
        return self._value

    def set(self, value):
        self._value = value


class StringVar(_Var):
    pass


class BooleanVar(_Var):
    def __init__(self, master=None, value=False, **kwargs):
        super().__init__(master, value)


class _Widget:
    """Accepts any construction, any method, any attribute."""

    def __init__(self, *args, **kwargs):
        self._children = []
        self._rows: list = []

    def __getattr__(self, name):
        def anything(*args, **kwargs):
            return _Widget()
        return anything

    # The handful of calls whose return value the app actually uses.
    def get_children(self):
        return list(self._rows)

    def insert(self, *args, **kwargs):
        if args and args[0] == "":
            self._rows.append(kwargs.get("iid", str(len(self._rows))))
        return ""

    def delete(self, *args, **kwargs):
        self._rows = []

    def selection(self):
        return ()

    def index(self, *args, **kwargs):
        return 0

    def winfo_exists(self):
        return 1


class Tk(_Widget):
    def mainloop(self):
        raise AssertionError("mainloop must not run in a test")

    def after(self, delay, callback=None, *args):
        return "after#1"


Text = _Widget
Canvas = _Widget
Toplevel = _Widget
Frame = _Widget


class _TtkModule(types.ModuleType):
    Frame = _Widget
    Label = _Widget
    Button = _Widget
    Entry = _Widget
    Notebook = _Widget
    Treeview = _Widget
    Scrollbar = _Widget
    Checkbutton = _Widget
    Combobox = _Widget
    Progressbar = _Widget
    Separator = _Widget
    PanedWindow = _Widget
    Style = _Widget


def install() -> None:
    """Put the stub in sys.modules under the tkinter names."""
    tkinter = types.ModuleType("tkinter")
    for name in ("BOTH", "END", "LEFT", "RIGHT", "W", "X", "Y", "CENTER"):
        setattr(tkinter, name, globals()[name])
    tkinter.StringVar = StringVar
    tkinter.BooleanVar = BooleanVar
    tkinter.Tk = Tk
    tkinter.Text = Text
    tkinter.Canvas = Canvas
    tkinter.Frame = Frame
    tkinter.Toplevel = Toplevel

    ttk = _TtkModule("tkinter.ttk")
    tkinter.ttk = ttk

    filedialog = types.ModuleType("tkinter.filedialog")
    filedialog.askopenfilename = lambda **kwargs: ""
    filedialog.askopenfilenames = lambda **kwargs: ()
    filedialog.asksaveasfilename = lambda **kwargs: ""
    tkinter.filedialog = filedialog

    messagebox = types.ModuleType("tkinter.messagebox")
    for name in ("showerror", "showinfo", "showwarning"):
        setattr(messagebox, name, lambda *a, **k: None)
    messagebox.askyesno = lambda *a, **k: False
    tkinter.messagebox = messagebox

    sys.modules["tkinter"] = tkinter
    sys.modules["tkinter.ttk"] = ttk
    sys.modules["tkinter.filedialog"] = filedialog
    sys.modules["tkinter.messagebox"] = messagebox
