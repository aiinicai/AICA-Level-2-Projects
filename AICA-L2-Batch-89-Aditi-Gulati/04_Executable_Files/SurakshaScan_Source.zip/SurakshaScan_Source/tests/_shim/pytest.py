"""
A very small stand-in for pytest, used only where pytest cannot be installed.

It supports exactly what this test suite uses: @pytest.fixture (function
scope, including fixtures that depend on other fixtures), pytest.raises, and
the tmp_path and monkeypatch built-ins. On any machine with real pytest
installed, that one is found first and this file is never imported.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

_FIXTURES: dict[str, object] = {}


def fixture(func=None, **_kwargs):
    def wrap(f):
        _FIXTURES[f.__name__] = f
        f.__is_fixture__ = True
        return f
    return wrap(func) if func else wrap


class _Raises:
    def __init__(self, expected):
        self.expected = expected
        self.value = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None:
            raise AssertionError(f"{self.expected.__name__} was not raised")
        self.value = exc
        return issubclass(exc_type, self.expected)


def raises(expected):
    return _Raises(expected)


class MonkeyPatch:
    def __init__(self):
        self._undo = []

    def setattr(self, target, name, value=None):
        if value is None and isinstance(target, str):
            module_name, _, attribute = target.rpartition(".")
            target, name, value = sys.modules[module_name], attribute, name
        old = getattr(target, name, _MISSING)
        self._undo.append(lambda: (setattr(target, name, old)
                                   if old is not _MISSING
                                   else delattr(target, name)))
        setattr(target, name, value)

    def setitem(self, mapping, key, value):
        had = key in mapping
        old = mapping.get(key)
        self._undo.append(lambda: mapping.__setitem__(key, old) if had
                          else mapping.pop(key, None))
        mapping[key] = value

    def delenv(self, name, raising=True):
        if name in os.environ:
            old = os.environ[name]
            self._undo.append(lambda: os.environ.__setitem__(name, old))
            del os.environ[name]
        elif raising:
            raise KeyError(name)

    def setenv(self, name, value):
        self.delenv(name, raising=False)
        os.environ[name] = value
        self._undo.append(lambda: os.environ.pop(name, None))

    def undo(self):
        for action in reversed(self._undo):
            action()
        self._undo.clear()


class _Missing:
    pass


_MISSING = _Missing()


def _resolve(name, cache, cleanups):
    if name in cache:
        return cache[name]
    if name == "tmp_path":
        path = Path(tempfile.mkdtemp(prefix="shimtmp_"))
        cleanups.append(lambda: shutil.rmtree(path, ignore_errors=True))
        cache[name] = path
        return path
    if name == "monkeypatch":
        patcher = MonkeyPatch()
        cleanups.append(patcher.undo)
        cache[name] = patcher
        return patcher
    if name not in _FIXTURES:
        raise LookupError(f"no fixture named '{name}'")
    func = _FIXTURES[name]
    args = {a: _resolve(a, cache, cleanups)
            for a in func.__code__.co_varnames[:func.__code__.co_argcount]}
    value = func(**args)
    cache[name] = value
    return value


def run(modules) -> int:
    passed, failures = 0, []
    for module in modules:
        names = [n for n in dir(module) if n.startswith("test_")]
        for name in sorted(names):
            func = getattr(module, name)
            if getattr(func, "__is_fixture__", False):
                continue
            cache, cleanups = {}, []
            label = f"{module.__name__}::{name}"
            try:
                args = {a: _resolve(a, cache, cleanups) for a in
                        func.__code__.co_varnames[:func.__code__.co_argcount]}
                func(**args)
                passed += 1
                print(f"  PASS  {label}")
            except Exception:
                failures.append((label, traceback.format_exc()))
                print(f"  FAIL  {label}")
            finally:
                for cleanup in reversed(cleanups):
                    try:
                        cleanup()
                    except Exception:
                        pass
    print(f"\n{passed} passed, {len(failures)} failed")
    for label, tb in failures:
        print(f"\n--- {label} ---\n{tb}")
    return 1 if failures else 0
