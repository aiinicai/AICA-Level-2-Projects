"""
The desktop window must build without error.

This cannot tell whether the layout LOOKS right - only eyes on a screen can.
What it does catch is the mistake that makes the app open to nothing on
someone else's machine: a widget referenced before it is created, a handler
wired to a method that does not exist, a typo in an attribute name.
"""

import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "_shim"))


def _load_app():
    try:
        import tkinter  # noqa: F401  - real toolkit when one is available
    except ImportError:
        import tkstub
        tkstub.install()
    for module in [m for m in sys.modules if m.startswith("surakshascan.ui")]:
        del sys.modules[module]
    return importlib.import_module("surakshascan.ui.app")


def test_the_window_builds():
    app_module = _load_app()
    root = app_module.Tk()
    app = app_module.SurakshaScanApp(root)

    # Every tab's render path must exist and run on an empty review.
    for method in ("_render_review", "_render_documents", "_render_social",
                   "_render_systems", "refresh_history"):
        assert hasattr(app, method), f"missing {method}"
    app._render_documents()
    app._render_social()
    app._render_systems()

    # The pieces the Activity log depends on.
    assert app._log_lines == 0
    assert app.log is not None
    assert app.log_hint is not None


def test_a_pasted_page_url_is_reduced_to_a_page_id():
    """People paste the whole address bar, usually URL-encoded."""
    app_module = _load_app()
    page_id = app_module._page_id
    assert page_id(
        "https://www.facebook.com/little%20flower%20house%20schools"
    ) == "little flower house schools"
    assert page_id("facebook.com/LittleFlowerHouse") == "LittleFlowerHouse"
    assert page_id("https://www.instagram.com/lfh_varanasi/") == "lfh_varanasi"
    assert page_id("123456789012345") == "123456789012345"
    assert page_id("   ") is None
    assert page_id("") is None


def test_dropped_paths_are_split_correctly():
    """
    Tk hands dropped files over as one string, brace-quoting any path with a
    space in it. Windows paths have spaces constantly.
    """
    app_module = _load_app()
    split = app_module.SurakshaScanApp._split_dropped
    assert split("C:/a.png") == ["C:/a.png"]
    assert split("{C:/My Folder/a post.png}") == ["C:/My Folder/a post.png"]
    assert split("{C:/My Folder/a.png} C:/b.png") == [
        "C:/My Folder/a.png", "C:/b.png"]
    assert split("{C:/one two/a.png} {D:/three four/b.png}") == [
        "C:/one two/a.png", "D:/three four/b.png"]
    assert split("") == []


def test_the_drop_handler_ignores_non_images():
    app_module = _load_app()
    root = app_module.Tk()
    app = app_module.SurakshaScanApp(root)
    app.social_screenshots.clear()

    class Event:
        data = "{C:/x/post.png} C:/x/notes.txt C:/x/second.JPG"

    app._on_drop(Event())
    assert len(app.social_screenshots) == 2
    assert all(p.lower().endswith((".png", ".jpg"))
               for p in app.social_screenshots)


def test_ctrl_v_is_bound_on_the_application_not_a_frame():
    """
    A ttk.Frame never receives keyboard focus, so a Ctrl+V binding on one
    silently never fires. This was a real bug; the binding must live on the
    application.
    """
    source = (Path(__file__).parents[1] / "surakshascan" / "ui" /
              "app.py").read_text(encoding="utf-8")
    assert "bind_all" in source, "Ctrl+V must be bound application-wide"
    assert "_install_paste_binding" in source
    # And it must not steal Ctrl+V from text fields.
    assert '"Entry", "TEntry", "Text"' in source


def test_paste_is_ignored_when_another_tab_is_open():
    app_module = _load_app()
    root = app_module.Tk()
    app = app_module.SurakshaScanApp(root)
    app.social_screenshots.clear()
    app._social_tab_index = 99          # pretend the Social tab is elsewhere
    app._maybe_paste()
    assert app.social_screenshots == []


def test_a_dropped_browser_link_is_explained_not_silently_dropped():
    app_module = _load_app()
    root = app_module.Tk()
    app = app_module.SurakshaScanApp(root)
    app.social_screenshots.clear()

    class Event:
        data = "https://www.facebook.com/photo/?fbid=123"

    app._on_drop(Event())
    assert app.social_screenshots == []
