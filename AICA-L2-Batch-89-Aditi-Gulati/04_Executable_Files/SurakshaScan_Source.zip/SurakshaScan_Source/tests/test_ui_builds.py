"""
The desktop window must build without error.

This cannot tell whether the layout LOOKS right - only eyes on a screen can.
What it does catch is the mistake that makes the app open to nothing on
someone else's machine: a widget referenced before it is created, a handler
wired to a method that does not exist, a typo in an attribute name.
"""

import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "_shim"))


def _load_app():
    try:
        import tkinter  # noqa: F401  - real toolkit when one is available
    except ImportError:
        import tkstub
        tkstub.install()
    for module in [m for m in sys.modules if m.startswith("surakshascan.ui")]:
        del sys.modules[module]
    return importlib.import_module("surakshascan.ui.app")


def test_the_window_builds():
    app_module = _load_app()
    root = app_module.Tk()
    app = app_module.SurakshaScanApp(root)

    # Every tab's render path must exist and run on an empty review.
    for method in ("_render_review", "_render_documents", "refresh_history"):
        assert hasattr(app, method), f"missing {method}"
    app._render_documents()

    # The pieces the Activity log depends on.
    assert app._log_lines == 0
    assert app.log is not None
    assert app.log_hint is not None


def test_capstone_build_has_no_social_or_systems_tabs():
    """The capstone scans the website only; social and ERP review are held
    back for the hackathon build."""
    source = (Path(__file__).parents[1] / "surakshascan" / "ui" /
              "app.py").read_text(encoding="utf-8")
    for gone in ("_tab_social", "_tab_systems", "tkinterdnd2", "ImageGrab"):
        assert gone not in source, gone
