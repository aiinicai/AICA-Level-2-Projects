"""The tool must record who authorised a review, and refuse without it."""

import pytest

from surakshascan.authorisation import (
    Authorisation, AuthorisationError, fixture)
from surakshascan.engine import run_review


def test_a_name_is_enough():
    assert Authorisation(authorised_by="Sr. Anne, Principal").problems() == []


def test_a_blank_name_is_refused():
    assert Authorisation().problems()
    assert Authorisation(authorised_by="   ").problems()


def test_the_summary_is_what_the_report_prints():
    assert (Authorisation(authorised_by="Sr. Anne, Principal").summary()
            == "Authorised by Sr. Anne, Principal.")


def test_the_engine_refuses_with_no_authorisation():
    with pytest.raises(AuthorisationError):
        run_review("X", "https://127.0.0.1:1", write_evidence=False)


def test_the_engine_refuses_a_blank_name():
    with pytest.raises(AuthorisationError):
        run_review("X", "https://127.0.0.1:1", write_evidence=False,
                   authorisation=Authorisation(authorised_by=""))


def test_the_refusal_happens_before_anything_is_fetched(monkeypatch):
    import surakshascan.engine as engine

    def fail(*args, **kwargs):
        raise AssertionError("the scanner ran before authorisation was checked")

    monkeypatch.setattr(engine.Scanner, "scan", fail)
    with pytest.raises(AuthorisationError):
        run_review("X", "https://example.org", write_evidence=False)


def test_the_self_test_is_authorised():
    fixture().require()
