"""The rules engine and the score must be deterministic and conservative."""

from pathlib import Path

import pytest

from surakshascan import rules_engine, scoring
from surakshascan.config import Settings
from surakshascan.dpdp_catalogue import CATALOGUE, GAP, MET, NOT_ASSESSED, PARTIAL
from surakshascan.questionnaire import (
    QUESTIONS, STATUS_COMPLETED, blank_responses, finalise, to_answer_map,
    validate,
)
from surakshascan.scanner import Scanner

from test_scanner import FIXTURES, FakeSession


@pytest.fixture
def settings():
    s = Settings()
    s.crawl_delay = 0.0
    s.max_retries = 0
    s.respect_robots = False
    return s


@pytest.fixture
def weak_scan(settings):
    session = FakeSession({
        "https://sunrise.example": (FIXTURES / "weak_school.html").read_text()})
    return Scanner(settings=settings, session=session).scan(
        "Sunrise Public School", "https://sunrise.example")


@pytest.fixture
def strong_scan(settings):
    session = FakeSession({
        "https://little.example": (FIXTURES / "strong_school.html").read_text(),
        "https://little.example/privacy-policy":
            (FIXTURES / "strong_policy.html").read_text()})
    return Scanner(settings=settings, session=session).scan(
        "Little Model School", "https://little.example")


def test_every_obligation_produces_exactly_one_finding(weak_scan):
    findings = rules_engine.assess(weak_scan)
    assert len(findings) == len(CATALOGUE)
    assert len({f.obligation_id for f in findings}) == len(CATALOGUE)


def test_the_weak_site_scores_below_the_strong_one(weak_scan, strong_scan):
    weak = scoring.score_findings("w", "t", rules_engine.assess(weak_scan))
    strong = scoring.score_findings("s", "t", rules_engine.assess(strong_scan))
    assert strong.score > weak.score


def test_advertising_pixel_fails_the_children_check(weak_scan):
    findings = {f.obligation_id: f for f in rules_engine.assess(weak_scan)}
    assert findings["C2"].status == GAP
    assert any("facebook" in e.lower() for e in findings["C2"].evidence)


def test_http_form_action_fails_the_security_check(weak_scan):
    findings = {f.obligation_id: f for f in rules_engine.assess(weak_scan)}
    assert findings["D1"].status == GAP


def test_policy_matchers_find_real_clauses(strong_scan):
    findings = {f.obligation_id: f for f in rules_engine.assess(strong_scan)}
    for ref in ("A4", "A5", "A6", "E1"):
        assert findings[ref].status == MET, f"{ref} should be met"
        assert findings[ref].evidence, f"{ref} must quote the policy"


def test_assessment_is_deterministic(weak_scan):
    first = rules_engine.assess(weak_scan)
    second = rules_engine.assess(weak_scan)
    assert [(f.obligation_id, f.status) for f in first] == \
           [(f.obligation_id, f.status) for f in second]


def test_not_assessed_is_excluded_from_the_denominator(weak_scan):
    findings = rules_engine.assess(weak_scan)
    assessment = scoring.score_findings("x", "t", findings)
    excluded = sum(f.weight for f in findings if f.status == NOT_ASSESSED)
    assert assessment.weight_assessed == assessment.weight_total - excluded
    assert assessment.coverage_percent < 100


def test_questionnaire_answers_change_the_score(weak_scan):
    baseline = scoring.score_findings("x", "t", rules_engine.assess(weak_scan))
    responses = blank_responses()
    for question in QUESTIONS:
        responses[question.id].answer = "yes"
        responses[question.id].status = STATUS_COMPLETED
        responses[question.id].reviewer = "A Gulati"
        responses[question.id].confidence = "document seen"
    improved = scoring.score_findings(
        "x", "t", rules_engine.assess(weak_scan, to_answer_map(responses)))
    assert improved.score > baseline.score
    assert improved.coverage_percent > baseline.coverage_percent


def test_the_weakest_answer_governs_an_obligation():
    responses = blank_responses()
    for question in QUESTIONS:
        if question.obligation_id == "F3":
            responses[question.id].answer = "yes"
    first = next(q for q in QUESTIONS if q.obligation_id == "F3")
    responses[first.id].answer = "no"
    assert to_answer_map(responses)["F3"] == "no"


def test_remediation_is_ordered_by_impact_then_cost(weak_scan):
    assessment = scoring.score_findings("x", "t", rules_engine.assess(weak_scan))
    gains = [r.score_gain for r in assessment.remediation]
    assert gains == sorted(gains, reverse=True)
    assert all(r.action for r in assessment.remediation)


def test_working_paper_requires_a_reviewer_before_completion():
    responses = blank_responses()
    question = QUESTIONS[0]
    response = responses[question.id]
    response.status = STATUS_COMPLETED
    response.answer = "yes"
    response.confidence = "document seen"
    errors = validate(response, question)
    assert any("reviewer" in e for e in errors)
    response.reviewer = "A Gulati"
    assert validate(response, question) == []


def test_a_completed_line_gets_a_neutral_remark():
    responses = blank_responses()
    question = QUESTIONS[0]
    response = responses[question.id]
    response.status = STATUS_COMPLETED
    response.answer = "yes"
    response.reviewer = "A Gulati"
    response.confidence = "document seen"
    finalise(response, question)
    assert "A Gulati" in response.remark
    assert "no further exception" in response.remark.lower()
