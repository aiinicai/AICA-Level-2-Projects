"""
Run the suite with pytest if it is installed, otherwise with the bundled shim.

    python tests/run_tests.py
"""

import importlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

MODULES = ["test_scanner", "test_rules_and_scoring", "test_ai_guards",
           "test_evidence_and_reports", "test_social", "test_systems", "test_ui_builds", "test_authorisation"]


def main() -> int:
    try:
        import pytest  # noqa: F401
        import subprocess
        return subprocess.call([sys.executable, "-m", "pytest", str(HERE), "-q"])
    except ImportError:
        pass
    sys.path.insert(0, str(HERE / "_shim"))
    import pytest as shim
    print("pytest is not installed; running with the bundled shim.\n")
    return shim.run([importlib.import_module(m) for m in MODULES])


if __name__ == "__main__":
    raise SystemExit(main())
