"""The AI layer must never be able to assert something the policy does not say."""

import json

from surakshascan import ai_analyzer
from surakshascan.ai_analyzer import AIAnalysis, analyze_policy, build_prompt
from surakshascan.config import Settings

POLICY = ("We collect the student name and parent contact details. "
          "You may withdraw consent at any time by writing to the school "
          "office. " * 20)


class FakeBlock:
    type = "text"

    def __init__(self, text):
        self.text = text


class FakeResponse:
    def __init__(self, text):
        self.content = [FakeBlock(text)]


def _client_returning(payload):
    class FakeMessages:
        def create(self, **kwargs):
            return FakeResponse(json.dumps(payload))

    class FakeClient:
        def __init__(self, api_key=None):
            self.messages = FakeMessages()

    return FakeClient


def test_no_key_means_no_fake_analysis(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr(ai_analyzer, "resolve_api_key", lambda s: None)
    result = analyze_policy("X", POLICY)
    assert result.used is False
    assert "no api key" in result.reason_not_used.lower()
    assert result.findings == []


def test_a_met_finding_without_a_real_quotation_is_rejected(monkeypatch):
    monkeypatch.setattr(ai_analyzer, "resolve_api_key", lambda s: "test-key")
    fake = type("m", (), {"Anthropic": _client_returning({"findings": [
        {"id": "A6", "status": "MET",
         "quotation": "You may complain to the Data Protection Board.",
         "reasoning": "invented", "confidence": "high"}]})})
    monkeypatch.setitem(__import__("sys").modules, "anthropic", fake)
    result = analyze_policy("X", POLICY)
    assert result.used
    rejected = [f for f in result.findings if not f.accepted]
    assert len(rejected) == 1
    assert "does not appear" in rejected[0].rejected_because


def test_a_met_finding_with_a_real_quotation_is_accepted(monkeypatch):
    monkeypatch.setattr(ai_analyzer, "resolve_api_key", lambda s: "test-key")
    fake = type("m", (), {"Anthropic": _client_returning({"findings": [
        {"id": "A4", "status": "MET",
         "quotation": "You may withdraw consent at any time",
         "reasoning": "the policy names a channel", "confidence": "high"}]})})
    monkeypatch.setitem(__import__("sys").modules, "anthropic", fake)
    result = analyze_policy("X", POLICY)
    assert [f.accepted for f in result.findings] == [True]


def test_an_invented_obligation_id_is_rejected(monkeypatch):
    monkeypatch.setattr(ai_analyzer, "resolve_api_key", lambda s: "test-key")
    fake = type("m", (), {"Anthropic": _client_returning({"findings": [
        {"id": "Z99", "status": "GAP", "quotation": "",
         "reasoning": "made up", "confidence": "high"}]})})
    monkeypatch.setitem(__import__("sys").modules, "anthropic", fake)
    result = analyze_policy("X", POLICY)
    assert result.findings[0].accepted is False
    assert "not in the catalogue" in result.findings[0].rejected_because


def test_malformed_json_is_discarded_not_guessed_at(monkeypatch):
    monkeypatch.setattr(ai_analyzer, "resolve_api_key", lambda s: "test-key")

    class FakeMessages:
        def create(self, **kwargs):
            return FakeResponse("I think the policy is probably fine.")

    fake = type("m", (), {"Anthropic": type(
        "c", (), {"__init__": lambda self, api_key=None: setattr(
            self, "messages", FakeMessages())})})
    monkeypatch.setitem(__import__("sys").modules, "anthropic", fake)
    result = analyze_policy("X", POLICY)
    assert result.used is False
    assert "not valid json" in result.reason_not_used.lower()


def test_the_prompt_carries_the_required_structure():
    prompt = build_prompt("X School", "https://x/privacy", POLICY)
    for heading in ("## Role", "## Context", "## Objective",
                    "## Output format", "## Examples"):
        assert heading in prompt
    assert "do not infer" in prompt.lower()
    assert "Fourth Schedule" in prompt
