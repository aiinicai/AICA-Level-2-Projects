"""Scanner tests against local fixtures - no network is touched."""

from pathlib import Path

import pytest
import requests

from surakshascan.config import Settings
from surakshascan.scanner import Scanner

FIXTURES = Path(__file__).parent / "fixtures"


class FakeResponse:
    def __init__(self, url, text, status_code=200):
        self.url, self.text, self.status_code = url, text, status_code
        self.history = []


class FakeSession:
    """Serves the fixture files and records what was requested."""

    def __init__(self, routes):
        self.routes = routes
        self.requested = []
        self.headers = {}

    def get(self, url, **kwargs):
        self.requested.append(url)
        if url in self.routes:
            return FakeResponse(url, self.routes[url])
        if url.endswith("/robots.txt"):
            return FakeResponse(url, "", status_code=404)
        raise requests.RequestException("404")


@pytest.fixture
def settings():
    s = Settings()
    s.crawl_delay = 0.0
    s.max_retries = 0
    s.respect_robots = False
    return s


def test_weak_site_findings(settings):
    session = FakeSession({
        "https://sunrise.example": (FIXTURES / "weak_school.html").read_text(),
    })
    scan = Scanner(settings=settings, session=session).scan(
        "Sunrise Public School", "https://sunrise.example")

    assert scan.pages[0]["reachable"]
    assert scan.insecure_form_actions, "an http:// form action must be caught"
    assert scan.child_risk_trackers, "the facebook pixel must be caught"
    categories = {t["category"] for t in scan.all_trackers}
    assert "advertising pixel" in categories
    names = {f["field"] for f in scan.sensitive_fields_seen}
    assert "aadhaar_number" in names
    assert "dob" in names
    assert "blood_group" in names
    assert scan.pages[0]["implied_consent_wording"], \
        "'by continuing to use' must be flagged as implied consent"


def test_strong_site_reads_the_policy(settings):
    session = FakeSession({
        "https://little.example": (FIXTURES / "strong_school.html").read_text(),
        "https://little.example/privacy-policy":
            (FIXTURES / "strong_policy.html").read_text(),
    })
    scan = Scanner(settings=settings, session=session).scan(
        "Little Model School", "https://little.example")

    assert scan.policy_pages, "the policy page must be discovered and read"
    assert "verifiable consent" in scan.policy_text.lower()
    assert scan.policy_source_url.endswith("/privacy-policy")
    assert not scan.insecure_form_actions
    assert "dpo@little.example" in scan.contact_emails


def test_robots_disallow_stops_the_scan():
    class RobotsSession(FakeSession):
        def get(self, url, **kwargs):
            self.requested.append(url)
            if url.endswith("/robots.txt"):
                return FakeResponse(url, "User-agent: *\nDisallow: /")
            return FakeResponse(url, "<html></html>")

    settings = Settings()
    settings.crawl_delay = 0.0
    scan = Scanner(settings=settings,
                   session=RobotsSession({})).scan("X", "https://x.example")
    assert not scan.robots_allowed
    assert scan.errors
    assert len(scan.pages) == 0, "nothing may be fetched when robots says no"


def test_unreachable_site_does_not_raise(settings):
    scan = Scanner(settings=settings, session=FakeSession({})).scan(
        "Gone", "https://gone.example")
    assert scan.errors
    assert scan.pages[0]["error"]


def test_common_policy_paths_hang_off_the_site_root(settings):
    """A base URL pointing at a page must not produce /index.html/privacy."""
    session = FakeSession({
        "https://s.example/index.html":
            (FIXTURES / "weak_school.html").read_text()})
    Scanner(settings=settings, session=session).scan(
        "S", "https://s.example/index.html")
    bad = [u for u in session.requested if "index.html/" in u]
    assert not bad, f"policy paths were appended to the page path: {bad[:3]}"
    assert "https://s.example/privacy-policy" in session.requested
