"""
The social module must find the real risk, invent nothing, and never scrape.
"""

from pathlib import Path

import pytest

from surakshascan import rules_engine, social
from surakshascan.dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from surakshascan.config import Settings
from surakshascan.scanner import Scanner

from test_scanner import FIXTURES, FakeSession


@pytest.fixture
def export_review():
    return social.load_export(FIXTURES / "social_posts.csv")


@pytest.fixture
def plain_scan():
    settings = Settings()
    settings.crawl_delay = 0.0
    settings.max_retries = 0
    settings.respect_robots = False
    session = FakeSession({
        "https://x.example": (FIXTURES / "weak_school.html").read_text()})
    return Scanner(settings=settings, session=session).scan(
        "X", "https://x.example")


# ------------------------------------------------------ caption analysis

def test_a_name_with_a_class_is_flagged():
    flags, identifiers = social.analyse_caption(
        "Congratulations Aarav Sharma of Class 5-B on winning the quiz!")
    assert any("identifies and locates" in f for f in flags)
    assert "Aarav Sharma" in identifiers


def test_greeting_words_are_not_mistaken_for_a_name():
    """'Congratulations Aarav Sharma' must not be reported as the name."""
    _, identifiers = social.analyse_caption(
        "Congratulations Aarav Sharma of Class 5-B!")
    assert "Aarav Sharma" in identifiers
    assert not any(i.lower().startswith("congratulations") for i in identifiers)
    assert not any(i.lower().endswith(" of") for i in identifiers)


def test_a_roll_number_is_flagged():
    flags, identifiers = social.analyse_caption(
        "Well done Priya Verma, Class 10 A, Roll No 24")
    assert any("identifier" in f for f in flags)
    assert any("roll" in i.lower() for i in identifiers)


def test_a_class_without_a_name_is_weaker_but_still_noted():
    flags, _ = social.analyse_caption(
        "Class VIII went on a field trip to the museum today.")
    assert any("narrows the child" in f for f in flags)
    assert not any("identifies and locates" in f for f in flags)


def test_an_innocuous_caption_is_not_flagged():
    flags, identifiers = social.analyse_caption(
        "Independence Day celebrations at our school. A wonderful morning.")
    assert flags == []
    assert identifiers == []


def test_no_phantom_child_from_pure_congratulation():
    _, identifiers = social.analyse_caption(
        "Congratulations to all our students on a wonderful result!")
    assert identifiers == []


# --------------------------------------------------------- export route

def test_export_is_read_and_scored(export_review):
    assert export_review.source == "export"
    counts = export_review.counts
    assert counts["posts"] == 5
    assert counts["names_with_class"] == 2
    assert counts["identifiers"] == 1
    assert counts["promoted"] == 2
    assert counts["high_risk"] >= 2


def test_a_boosted_post_featuring_a_child_is_escalated(export_review):
    promoted_with_child = [
        p for p in export_review.posts
        if p["is_promoted"] and p["identifiers_found"]]
    assert promoted_with_child
    assert all(p["risk"] == "high" for p in promoted_with_child)
    assert any("targeted-advertising" in f
               for p in promoted_with_child for f in p["flags"])


def test_a_boosted_post_without_children_is_not_penalised(export_review):
    admissions = next(p for p in export_review.posts
                      if "Admissions open" in p["caption"])
    assert admissions["is_promoted"]
    assert admissions["risk"] == "low"


def test_a_missing_export_does_not_raise():
    review = social.load_export("/no/such/file.csv")
    assert review.errors
    assert review.posts == []


# ---------------------------------------------------- rules integration

def test_social_findings_are_not_assessed_without_a_review(plain_scan):
    findings = {f.obligation_id: f for f in rules_engine.assess(plain_scan)}
    assert findings["C5"].status == NOT_ASSESSED
    assert "website scan does not reach it" in findings["C5"].rationale
    assert findings["C6"].status == NOT_ASSESSED


def test_social_findings_use_the_review_when_present(plain_scan, export_review):
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, social=export_review)}
    assert findings["C5"].status == GAP
    assert findings["C5"].decided_by == "social"
    assert findings["C5"].evidence
    assert findings["C6"].status == GAP


def test_a_clean_feed_passes(plain_scan):
    clean = social.load_export(FIXTURES / "social_posts.csv")
    clean.posts = [p for p in clean.posts if not p["identifiers_found"]]
    clean = social._count(clean)
    findings = {f.obligation_id: f
                for f in rules_engine.assess(plain_scan, social=clean)}
    assert findings["C5"].status in (MET, PARTIAL)


def test_reviewing_social_changes_the_score(plain_scan, export_review):
    from surakshascan import scoring
    without = scoring.score_findings("x", "t", rules_engine.assess(plain_scan))
    with_social = scoring.score_findings(
        "x", "t", rules_engine.assess(plain_scan, social=export_review))
    assert with_social.coverage_percent > without.coverage_percent


# ------------------------------------------------------------- guardrails

def test_the_module_never_scrapes_a_public_feed():
    """
    There must be no code path that fetches someone's public profile. Every
    route reads the school's own posts: a token it owns, a file it exported,
    or screenshots it supplied.
    """
    source = Path(social.__file__).read_text(encoding="utf-8")
    for forbidden in ("instagram.com/", "www.facebook.com/", "BeautifulSoup",
                      "scrape"):
        assert forbidden not in source.replace("does not scrape", "") \
            .replace("not scrape", ""), f"{forbidden} appears in social.py"
    assert "graph.facebook.com" in source, "the official interface is expected"


def test_a_token_is_never_written_to_the_evidence_file(tmp_path):
    from surakshascan import evidence
    path = evidence.save("X", {"social": {"token": "EAAG-secret",
                                          "page_id": "123"}},
                         directory=tmp_path)
    text = path.read_text()
    assert "EAAG-secret" not in text
    assert "123" in text


# ------------------------------------------------------- Devanagari

def test_a_hindi_class_reference_is_found():
    """An English-only matcher would report a Hindi feed as clean."""
    flags, identifiers = social.analyse_caption(
        "कक्षा 5 के छात्रों ने विज्ञान प्रदर्शनी में भाग लिया")
    assert any("कक्षा" in i for i in identifiers)
    assert any("narrows the child" in f for f in flags)


def test_a_hindi_achievement_post_is_flagged_for_human_reading():
    """
    Devanagari has no capital letters, so the name matcher cannot work on it.
    Rather than guess - and risk printing a stray word as a child's name in a
    compliance report - it says a person must read the caption.
    """
    flags, _ = social.analyse_caption(
        "बधाई! आरव शर्मा, कक्षा 8-B ने जिला प्रतियोगिता जीती")
    assert any("Hindi caption" in f and "Read it" in f for f in flags)
    assert any("individual achievement" in f for f in flags)


def test_an_ordinary_hindi_post_is_not_over_flagged():
    flags, identifiers = social.analyse_caption(
        "विद्यालय में वार्षिक समारोह का आयोजन किया गया")
    assert flags == []
    assert identifiers == []
