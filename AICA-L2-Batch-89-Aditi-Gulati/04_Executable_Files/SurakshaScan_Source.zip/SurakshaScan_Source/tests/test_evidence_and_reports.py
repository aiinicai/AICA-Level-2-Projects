"""Evidence must redact secrets; reports must actually be produced."""

import json
from pathlib import Path

import pytest

from surakshascan import evidence, report_docx, report_html, report_xlsx
from surakshascan import rules_engine, scoring, perspectives
from surakshascan.config import Settings
from surakshascan.engine import Review
from surakshascan.questionnaire import blank_responses, completion_stats
from surakshascan.scanner import Scanner

from test_scanner import FIXTURES, FakeSession


@pytest.fixture
def review():
    settings = Settings()
    settings.crawl_delay = 0.0
    settings.respect_robots = False
    session = FakeSession({
        "https://sunrise.example": (FIXTURES / "weak_school.html").read_text()})
    scan = Scanner(settings=settings, session=session).scan(
        "Sunrise Public School", "https://sunrise.example")
    findings = rules_engine.assess(scan)
    return Review(
        scan=scan, findings=findings,
        assessment=scoring.score_findings("Sunrise Public School",
                                          scan.scanned_at, findings),
        perspectives=perspectives.build_perspectives(findings),
        working_paper_stats=completion_stats(blank_responses()))


def test_secrets_are_redacted_from_the_evidence_file(tmp_path):
    path = evidence.save("X School", {
        "settings": {"api_key": "sk-secret", "timeout": 10},
        "nested": [{"authorization": "Bearer abc"}]}, directory=tmp_path)
    text = path.read_text()
    assert "sk-secret" not in text
    assert "Bearer abc" not in text
    assert "[redacted]" in text
    assert json.loads(text)["payload"]["settings"]["timeout"] == 10


def test_evidence_history_reads_back_the_score(tmp_path, review):
    evidence.save("Sunrise Public School",
                  {"assessment": review.assessment.to_dict()},
                  directory=tmp_path)
    history = evidence.history("Sunrise Public School", directory=tmp_path)
    assert len(history) == 1
    assert history[0]["score"] == review.assessment.score


def test_word_report_is_written(tmp_path, review):
    out = report_docx.generate(review, tmp_path / "r.docx", prepared_by="CA A G")
    assert Path(out).exists() and Path(out).stat().st_size > 20000


def test_excel_workbook_has_every_sheet(tmp_path, review):
    from openpyxl import load_workbook
    out = report_xlsx.generate(review, tmp_path / "r.xlsx")
    wb = load_workbook(out)
    for sheet in ("Overview", "By domain", "Findings", "Remediation",
                  "Working paper", "Trackers", "Evidence log"):
        assert sheet in wb.sheetnames


def test_html_dashboard_is_self_contained(tmp_path, review):
    out = report_html.generate(review, tmp_path / "r.html")
    text = Path(out).read_text()
    assert "data:image/png;base64," in text
    assert "<script src=" not in text
    assert "not a certificate of compliance" in text.lower()


def test_two_perspective_panels_are_built_for_contested_findings(review):
    assert review.perspectives
    for pair in review.perspectives:
        assert pair.institution_position and pair.regulator_position
        assert pair.institution_position != pair.regulator_position
        assert pair.agreed_facts


def test_every_obligation_has_its_own_argument():
    """A domain-level fallback means three findings read identically."""
    from surakshascan.dpdp_catalogue import CATALOGUE
    from surakshascan.perspectives import ARGUMENTS
    missing = [o.id for o in CATALOGUE if o.id not in ARGUMENTS]
    assert not missing, f"no obligation-specific argument for {missing}"


def test_perspective_panels_are_not_duplicated(review):
    """C1, C2 and C4 previously shared one domain argument word for word."""
    institution = [p.institution_position for p in review.perspectives]
    regulator = [p.regulator_position for p in review.perspectives]
    assert len(set(institution)) == len(institution), \
        "two findings carry identical institution arguments"
    assert len(set(regulator)) == len(regulator), \
        "two findings carry identical regulator arguments"
    assert all(p.argument_source == "obligation" for p in review.perspectives)


def test_a_script_matching_several_signatures_is_counted_once(settings=None):
    """fbevents.js matches facebook.net, connect.facebook AND fbevents."""
    from surakshascan.config import Settings
    from surakshascan.scanner import Scanner
    s = Settings()
    s.crawl_delay = 0.0
    s.max_retries = 0
    s.respect_robots = False
    session = FakeSession({
        "https://x.example": (FIXTURES / "weak_school.html").read_text()})
    scan = Scanner(settings=s, session=session).scan("X", "https://x.example")
    urls = [t["url"] for t in scan.all_trackers]
    assert len(urls) == len(set(urls)), "the same script was recorded twice"
    assert len(scan.all_trackers) == 2, \
        f"expected 2 distinct scripts, got {len(scan.all_trackers)}"
    pixel = next(t for t in scan.all_trackers if "facebook" in t["url"])
    assert pixel["category"] == "advertising pixel", \
        "the most serious matching category must win"
    assert len(pixel["matched_signatures"]) == 3
    assert len(scan.child_risk_trackers) == 1
