# SurakshaScan 2.0

**A DPDP readiness scanner for educational institutions.**
AICA AI Level 2 capstone · CA Aditi Gulati

---

## What it does

Schools in India hold more children's personal data than almost any other kind
of organisation, and under the Digital Personal Data Protection Act, 2023
everyone below eighteen is a child. SurakshaScan reviews a school against 25
obligations drawn from the Act and the DPDP Rules, 2025, scores it, and hands
back a prioritised plan with the evidence behind every finding.

It reviews five things a school actually has:

1. **The website** — a polite, robots-aware crawl that finds and reads the
   published policy, catalogues forms and the data they ask for, and detects
   third-party trackers.
2. **The documents** — the admission form, the consent slip, the CCTV signage
   photograph, read offline from a PDF text layer or by a vision model.
3. **The internal practice** — a 24-line working paper covering the ERP, the
   vendor contracts, the retention schedule and the breach procedure, which no
   website scan can see.

It produces a Word report with charts, an Excel workbook, a self-contained
HTML dashboard, and a timestamped evidence file that lets any finding be
re-performed months later.

## What makes it defensible

Every rating comes from a deterministic rules engine, not from a language
model. The same website and the same working paper always produce the same
score. The AI layer is real but advisory: it adds quoted evidence and drafting
help, it is never allowed to change the score, and any finding whose quoted
passage does not actually appear in the policy is rejected and the rejection is
printed in the report.

This is the central difference from v1, whose `ai_analyzer.py` returned
hardcoded placeholder text and whose report presented it as analysis. The v1
source, recovered from the old executable, is kept in `legacy_v1/` as the
documented baseline.

## Quick start

**Without typing a command** — double-click one of these in the project folder:

| File | What it does |
|---|---|
| `Start SurakshaScan.bat` | Opens the app. Sets everything up on first run. |
| `Run self-test.bat` | Proves the installation works, offline. |
| `build_exe.bat` | Builds `dist\SurakshaScan.exe`, which runs on a machine with no Python at all. |

**From a terminal:**

```bash
pip install -r requirements.txt
python run.py                                    # desktop app

python -m surakshascan.cli scan \
    --name "My School" --url https://myschool.edu.in \
    --docx report.docx --xlsx workings.xlsx --html dashboard.html
```

`docs/SHARING.md` covers distributing the executable, including the Windows
SmartScreen warning recipients will see.

## The obligation catalogue

35 obligations across eight domains, each carrying the provision it comes from
and the date that provision commences, so what is due today is never confused
with what is due on 14 May 2027:

| Domain | Weight | The heart of it |
|---|---|---|
| Notice and transparency | 28 | Is there one document a parent can read that says what is collected, why, how to withdraw and how to complain |
| Consent | 13 | Can the school produce the consent artefact for a named student |
| Children's data | 48 | Verifiable parental consent, the section 9(3) prohibition, what the school publishes on social media, and how far the Fourth Schedule exemption really reaches |
| Security and breach | 17 | HTTPS, access control, and whether the school could answer within a day who was affected |
| Retention and erasure | 10 | A written schedule with a legal basis, and evidence anything was ever deleted |
| Governance and grievance | 20 | A published, monitored contact and a dated register |
| Core systems | 23 | What the ERP actually holds, whether leavers are erased, the accounts retention conflict, and the learning platform |
| Processors and third parties | 14 | A signed data-processing clause per vendor holding student data |
| Core systems and AI | 34 | What the ERP and the accounts actually hold, and what staff put into AI tools |

The full table with matchers and remediation is in
`skill/dpdp-readiness-review/references/obligations.md`, generated from the
code so the two cannot drift apart.

## The Fourth Schedule point

Rule 12 read with Part A of the Fourth Schedule relieves an educational
institution of section 9(1) (verifiable parental consent) and section 9(3)
(tracking, behavioural monitoring and targeted advertising) — but only for
academic activities, for tracking and behavioural monitoring, and for the
safety of enrolled students.

It does not reach marketing, promotional photographs, alumni contact, a
prospective student who is not yet enrolled, or an advertising pixel on a
public page. Getting this boundary right is most of the value the tool adds,
and it is why every children's-data finding carries a note explaining where
the exemption stops.

## Project layout

```
surakshascan/
  dpdp_catalogue.py   25 obligations: provision, commencement, weight, matchers
  scanner.py          polite crawler, policy discovery, evidence capture
  rules_engine.py     deterministic assessment — authoritative
  ai_analyzer.py      optional AI layer with anti-hallucination guards
  vision.py           admission forms, consent slips, signage
  social.py           the school's own posts - never a scrape
  systems.py          ERP, accounts and LMS - shape, never the data
  systems.py          ERP and Tally structure - never the children in it
  perspectives.py     the institution's case and the Board's case
  questionnaire.py    39-line internal-practices working paper
  scoring.py          weighted score, coverage, prioritised remediation
  charts.py           donut and bar charts
  report_docx.py      Word report
  report_xlsx.py      Excel workbook, seven sheets
  report_html.py      self-contained responsive dashboard
  evidence.py         timestamped audit trail, secrets redacted
  engine.py           one orchestration path for all four front ends
  cli.py              scan / watch / compare
  mcp_server.py       MCP tools, read-only by default
  scheduler.py        quarterly re-scan with a human approval gate
  ui/app.py           tabbed Tkinter desktop application
skill/                a packaged, reusable DPDP review skill
integrations/         the n8n quarterly workflow
tests/                28 tests against local fixtures, no network
docs/                 architecture, build, scheduling, syllabus map
legacy_v1/            the v1 source, recovered from the old executable
```

`docs/SYLLABUS_MAP.md` maps every module back to the day of the course it
demonstrates. `docs/SOCIAL_MEDIA.md` covers the social review and
`docs/CORE_SYSTEMS_AND_AI.md` the ERP, Tally and AI review - including why
neither scrapes nor retains.

## Scope and limitations

This tool records a point-in-time readiness review. It is not a certificate of
compliance with the DPDP Act, 2023 or the DPDP Rules, 2025, and it is not legal
advice. Automated checks reach publicly accessible pages only — never a login,
never an internal system. Absence of a finding is not evidence of absence.

The tool records who authorised each review and refuses to run without it. See `docs/AUTHORISATION.md`.

Verify every commencement date, Schedule reference and penalty figure against
the notified text at meity.gov.in before the report leaves your desk. The law
is young and it is still moving.
