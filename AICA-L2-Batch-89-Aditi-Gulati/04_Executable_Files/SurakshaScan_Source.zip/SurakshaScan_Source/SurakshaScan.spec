# PyInstaller spec for SurakshaScan.
#
# Build with:  pyinstaller SurakshaScan.spec
# Or just double-click build_exe.bat, which does the same thing with checks.
#
# Produces dist/SurakshaScan.exe - a single file that runs on a Windows
# machine with no Python installed.

import sys
from PyInstaller.utils.hooks import collect_data_files

block_cipher = None

# Read-only files that must travel inside the executable.
datas = [
    ('assets', 'assets'),                              # window and taskbar icon
    ('tests/fixtures/site', 'tests/fixtures/site'),    # the built-in self-test
    ('tests/fixtures/social_posts.csv', 'tests/fixtures'),  # self-test data
    ('tests/fixtures/erp_export.csv', 'tests/fixtures'),    # synthetic only
    ('tests/fixtures/tally_ledgers.xml', 'tests/fixtures'),
    ('skill', 'skill'),                                # the packaged skill
    ('docs', 'docs'),                                  # so help ships with it
]
# matplotlib needs its own data files or charts fail at runtime.
datas += collect_data_files('matplotlib', subdir='mpl-data')

# tkinterdnd2 ships Tcl libraries that must travel with the build, or
# drag-and-drop silently disappears in the .exe even though it worked from
# source. It is optional: if it is not installed on the build machine the
# build still succeeds, and the Social tab says drag-and-drop is unavailable.
hiddenimports_dnd = []
try:
    from PyInstaller.utils.hooks import collect_all
    dnd_datas, dnd_binaries, dnd_hidden = collect_all('tkinterdnd2')
    datas += dnd_datas
    hiddenimports_dnd = dnd_hidden
    print('spec: bundling tkinterdnd2 (drag-and-drop enabled)')
except Exception as exc:
    dnd_binaries = []
    print(f'spec: tkinterdnd2 not bundled ({exc}); paste will still work')

a = Analysis(
    ['run.py'],
    pathex=[],
    binaries=dnd_binaries,
    datas=datas,
    hiddenimports=[
        'surakshascan.ui.app',
        'surakshascan.tools.demo',
        'surakshascan.tools.clipcheck',
        'matplotlib.backends.backend_agg',
        'openpyxl.cell._writer',
        'bs4', 'docx', 'PIL._tkinter_finder', 'PIL.ImageGrab',
    ] + hiddenimports_dnd,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # None of these is used at runtime; excluding them keeps the build smaller
    # and the startup faster.
    excludes=[
        'pytest', 'pyinstaller', 'numpy.f2py', 'pandas', 'IPython',
        'jupyter', 'notebook', 'tkinter.test', 'test', 'unittest',
        'matplotlib.tests', 'PyQt5', 'PyQt6', 'PySide2', 'PySide6', 'wx',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name='SurakshaScan',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,              # UPX trips several antivirus engines; not worth it
    runtime_tmpdir=None,
    console=False,          # windowed - no black console box behind the app
    disable_windowed_traceback=False,
    icon='assets/surakshascan.ico' if sys.platform == 'win32' else None,
    version='version_info.txt' if sys.platform == 'win32' else None,
)
