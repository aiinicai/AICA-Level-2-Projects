# PyInstaller spec for SurakshaScan.
#
# Build with:  pyinstaller SurakshaScan.spec
# Or just double-click build_exe.bat, which does the same thing with checks.
#
# Produces dist/SurakshaScan.exe - a single file that runs on a Windows
# machine with no Python installed.

import sys
from PyInstaller.utils.hooks import collect_data_files

block_cipher = None

# Read-only files that must travel inside the executable.
datas = [
    ('assets', 'assets'),                              # window and taskbar icon
    ('tests/fixtures/site', 'tests/fixtures/site'),    # the built-in self-test
    ('skill', 'skill'),                                # the packaged skill
    ('docs', 'docs'),                                  # so help ships with it
]
# matplotlib needs its own data files or charts fail at runtime.
datas += collect_data_files('matplotlib', subdir='mpl-data')

a = Analysis(
    ['run.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=[
        'surakshascan.ui.app',
        'surakshascan.tools.demo',
        'matplotlib.backends.backend_agg',
        'openpyxl.cell._writer',
        'bs4', 'docx', 'PIL._tkinter_finder',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # None of these is used at runtime; excluding them keeps the build smaller
    # and the startup faster.
    excludes=[
        'pytest', 'pyinstaller', 'numpy.f2py', 'pandas', 'IPython',
        'jupyter', 'notebook', 'tkinter.test', 'test', 'unittest',
        'matplotlib.tests', 'PyQt5', 'PyQt6', 'PySide2', 'PySide6', 'wx',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name='SurakshaScan',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,              # UPX trips several antivirus engines; not worth it
    runtime_tmpdir=None,
    console=False,          # windowed - no black console box behind the app
    disable_windowed_traceback=False,
    icon='assets/surakshascan.ico' if sys.platform == 'win32' else None,
    version='version_info.txt' if sys.platform == 'win32' else None,
)
