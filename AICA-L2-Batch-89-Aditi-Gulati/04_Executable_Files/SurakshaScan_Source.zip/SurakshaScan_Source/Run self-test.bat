@echo off
REM  Proves the installation works: scans a bundled fixture school and
REM  writes all three reports. No internet, nobody's permission needed.
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
"%PY%" -m surakshascan.tools.demo
echo.
pause
