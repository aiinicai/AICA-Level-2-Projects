@echo off
REM ===================================================================
REM  Build SurakshaScan.exe - double-click this file.
REM
REM  Produces dist\SurakshaScan.exe, which runs on any Windows machine
REM  with no Python installed. Takes two to five minutes.
REM ===================================================================
setlocal
cd /d "%~dp0"

echo.
echo  Building SurakshaScan
echo  =====================
echo.

if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
    echo  Using the project's virtual environment.
) else (
    set "PY=python"
    echo  No .venv found - using the system Python.
)

echo.
echo  [1/4] Checking PyInstaller...
"%PY%" -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo        Not installed. Installing it now...
    "%PY%" -m pip install pyinstaller
    if errorlevel 1 goto :failed
)

echo  [2/4] Running the tests first...
"%PY%" -m pytest tests -q
if errorlevel 1 (
    echo.
    echo  *** Tests failed. Fix that before shipping a build. ***
    goto :failed
)

echo  [3/4] Clearing the previous build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo  [4/4] Building. This takes a few minutes...
"%PY%" -m PyInstaller SurakshaScan.spec --noconfirm
if errorlevel 1 goto :failed

echo.
echo  ============================================
echo   Done.  dist\SurakshaScan.exe
echo  ============================================
echo.
echo   Test it on a machine with NO Python installed
echo   before you send it to anyone.
echo.
if exist dist\SurakshaScan.exe explorer /select,"%CD%\dist\SurakshaScan.exe"
pause
exit /b 0

:failed
echo.
echo  *** The build did not finish. Read the messages above. ***
echo.
pause
exit /b 1
