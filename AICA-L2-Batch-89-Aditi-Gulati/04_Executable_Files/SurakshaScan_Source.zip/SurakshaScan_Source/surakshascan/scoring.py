"""
Turn findings into a score, a rating and a prioritised plan.

The score is deliberately conservative:

* an obligation that could not be assessed is excluded from the denominator
  rather than counted as met, so a thin scan cannot flatter a school;
* the proportion of the catalogue actually assessed is reported alongside
  the score, because a 90 percent score over a third of the catalogue is not
  a 90 percent score;
* a provision not yet in force still counts, but is labelled, so the school
  can see what is due now and what is due by 14 May 2027.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict

from .dpdp_catalogue import (
    CREDIT, DOMAIN_ORDER, GAP, MET, NOT_ASSESSED, PARTIAL, by_id,
)

BANDS = (
    (85, "Strong", "Controls are largely in place. Maintain and evidence them."),
    (70, "Adequate", "The framework exists with identified gaps to close."),
    (50, "Developing", "Core obligations are recognised but not yet operating."),
    (30, "Weak", "Substantial gaps across several domains. Prioritise the "
                 "children's-data and notice items."),
    (0, "Critical", "The institution has little of the DPDP framework in "
                    "place. Treat this as a project, not a task list."),
)

EFFORT_ORDER = {"low": 0, "medium": 1, "high": 2}


@dataclass
class DomainScore:
    domain: str
    weight_assessed: int
    weight_earned: float
    percent: float
    met: int = 0
    partial: int = 0
    gap: int = 0
    not_assessed: int = 0


@dataclass
class RemediationItem:
    rank: int
    obligation_id: str
    title: str
    provision: str
    provision_status: str
    status: str
    action: str
    effort: str
    weight: int
    score_gain: float
    domain: str


@dataclass
class Assessment:
    institution_name: str
    scanned_at: str
    score: float
    band: str
    band_note: str
    coverage_percent: float
    weight_assessed: int
    weight_total: int
    counts: dict = field(default_factory=dict)
    domains: list[DomainScore] = field(default_factory=list)
    remediation: list[RemediationItem] = field(default_factory=list)
    due_now: list[str] = field(default_factory=list)
    due_by_may_2027: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def band_for(score: float) -> tuple[str, str]:
    for threshold, name, note in BANDS:
        if score >= threshold:
            return name, note
    return BANDS[-1][1], BANDS[-1][2]


def score_findings(institution_name: str, scanned_at: str,
                   findings) -> Assessment:
    assessed = [f for f in findings if f.status in CREDIT]
    weight_assessed = sum(f.weight for f in assessed)
    weight_total = sum(f.weight for f in findings)
    earned = sum(f.weight * CREDIT[f.status] for f in assessed)
    score = round(100.0 * earned / weight_assessed, 1) if weight_assessed else 0.0
    band, note = band_for(score)

    counts = {MET: 0, PARTIAL: 0, GAP: 0, NOT_ASSESSED: 0}
    for finding in findings:
        counts[finding.status] = counts.get(finding.status, 0) + 1

    domains: list[DomainScore] = []
    for domain in DOMAIN_ORDER:
        in_domain = [f for f in findings if f.domain == domain]
        scored = [f for f in in_domain if f.status in CREDIT]
        dw = sum(f.weight for f in scored)
        de = sum(f.weight * CREDIT[f.status] for f in scored)
        domains.append(DomainScore(
            domain=domain,
            weight_assessed=dw,
            weight_earned=round(de, 1),
            percent=round(100.0 * de / dw, 1) if dw else 0.0,
            met=sum(1 for f in in_domain if f.status == MET),
            partial=sum(1 for f in in_domain if f.status == PARTIAL),
            gap=sum(1 for f in in_domain if f.status == GAP),
            not_assessed=sum(1 for f in in_domain if f.status == NOT_ASSESSED),
        ))

    # Prioritise: biggest score gain first, cheapest first on a tie.
    open_items = [f for f in findings if f.status in (GAP, PARTIAL)]
    open_items.sort(key=lambda f: (
        -(f.weight * (1.0 - CREDIT[f.status])),
        EFFORT_ORDER.get(f.effort, 1),
        f.obligation_id,
    ))
    remediation: list[RemediationItem] = []
    for rank, finding in enumerate(open_items, start=1):
        gain = finding.weight * (1.0 - CREDIT[finding.status])
        remediation.append(RemediationItem(
            rank=rank,
            obligation_id=finding.obligation_id,
            title=finding.title,
            provision=finding.provision,
            provision_status=finding.provision_status,
            status=finding.status,
            action=finding.remediation,
            effort=finding.effort,
            weight=finding.weight,
            score_gain=round(100.0 * gain / weight_assessed, 1)
            if weight_assessed else 0.0,
            domain=finding.domain,
        ))

    due_now, due_later = [], []
    for finding in open_items:
        label = f"{finding.obligation_id} - {finding.title}"
        (due_now if finding.provision_status == "in force"
         else due_later).append(label)

    return Assessment(
        institution_name=institution_name,
        scanned_at=scanned_at,
        score=score,
        band=band,
        band_note=note,
        coverage_percent=round(100.0 * weight_assessed / weight_total, 1)
        if weight_total else 0.0,
        weight_assessed=weight_assessed,
        weight_total=weight_total,
        counts=counts,
        domains=domains,
        remediation=remediation,
        due_now=due_now,
        due_by_may_2027=due_later,
    )


def quick_wins(assessment: Assessment, limit: int = 5) -> list[RemediationItem]:
    """Low-effort items with real score impact - what to do this month."""
    items = [r for r in assessment.remediation if r.effort == "low"]
    items.sort(key=lambda r: -r.score_gain)
    return items[:limit]


def compare(assessments: list[Assessment]) -> dict:
    """Benchmark several institutions against each other."""
    rows = []
    for a in assessments:
        row = {"institution": a.institution_name, "score": a.score,
               "band": a.band, "coverage": a.coverage_percent}
        for domain in a.domains:
            row[domain.domain] = domain.percent
        rows.append(row)
    rows.sort(key=lambda r: -r["score"])
    averages = {}
    if rows:
        for domain in DOMAIN_ORDER:
            values = [r[domain] for r in rows if domain in r]
            averages[domain] = round(sum(values) / len(values), 1) if values else 0.0
    return {"rows": rows, "peer_average_by_domain": averages,
            "peer_average_score": round(
                sum(r["score"] for r in rows) / len(rows), 1) if rows else 0.0}
