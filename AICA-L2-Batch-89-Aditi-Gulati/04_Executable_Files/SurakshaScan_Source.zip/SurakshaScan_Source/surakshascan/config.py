"""Runtime configuration. No secret is ever written to the evidence store."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path

APP_NAME = "SurakshaScan"
USER_AGENT = (
    "SurakshaScan/2.0 (DPDP readiness self-assessment; "
    "+https://example.org/surakshascan; contact: dpo@your-school.edu.in)"
)

CONFIG_DIR = Path(os.environ.get("SURAKSHASCAN_HOME",
                                 Path.home() / ".surakshascan"))
CONFIG_FILE = CONFIG_DIR / "config.json"
EVIDENCE_DIR = CONFIG_DIR / "evidence"


@dataclass
class Settings:
    request_timeout: int = 12
    max_pages: int = 25
    crawl_delay: float = 1.0
    respect_robots: bool = True
    max_retries: int = 2
    ai_enabled: bool = False
    ai_model: str = "claude-sonnet-4-6"
    # The key is read from the environment first so it need not be stored.
    api_key_env: str = "ANTHROPIC_API_KEY"

    @property
    def api_key(self) -> str | None:
        return os.environ.get(self.api_key_env) or None

    @classmethod
    def load(cls) -> "Settings":
        if CONFIG_FILE.exists():
            try:
                raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                known = {f: raw[f] for f in cls.__dataclass_fields__ if f in raw}
                return cls(**known)
            except (json.JSONDecodeError, TypeError, OSError):
                pass
        return cls()

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(asdict(self), indent=2),
                               encoding="utf-8")
