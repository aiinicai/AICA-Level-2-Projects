"""
Orchestration - one call that runs the whole review and returns one object.

Order matters and is deliberate:

    scan -> deterministic rules -> questionnaire overlay -> score
                                -> AI layer (optional, cannot change the score)
                                -> two-perspective analysis
                                -> document review (optional)
                                -> evidence written to disk

The AI layer runs after the rules engine and is given the rules findings, so
it can be checked against them rather than trusted ahead of them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from . import (ai_analyzer, evidence, perspectives, rules_engine, scoring,
               social as social_module, systems as systems_module,
               vision)
from .authorisation import Authorisation, AuthorisationError
from .config import Settings
from .questionnaire import Response, to_answer_map, completion_stats
from .scanner import Scanner


@dataclass
class Review:
    scan: object
    findings: list = field(default_factory=list)
    assessment: object = None
    ai: object = None
    perspectives: list = field(default_factory=list)
    documents: list = field(default_factory=list)
    document_summary: dict = field(default_factory=dict)
    social: object = None
    systems: object = None
    authorisation: object = None
    working_paper_stats: dict = field(default_factory=dict)
    evidence_path: str = ""

    def to_dict(self) -> dict:
        return {
            "scan": self.scan.to_dict() if self.scan else {},
            "findings": [f.to_dict() for f in self.findings],
            "assessment": self.assessment.to_dict() if self.assessment else {},
            "ai": self.ai.to_dict() if self.ai else {},
            "perspectives": [p.to_dict() for p in self.perspectives],
            "documents": [d.to_dict() for d in self.documents],
            "social": self.social.to_dict() if self.social else {},
            "systems": self.systems.to_dict() if self.systems else {},
            "authorisation": (self.authorisation.to_dict()
                              if self.authorisation else {}),
            "document_summary": self.document_summary,
            "working_paper_stats": self.working_paper_stats,
        }


def run_review(institution_name: str,
               base_url: str,
               extra_pages: list[str] | None = None,
               responses: dict[str, Response] | None = None,
               document_paths: list[str] | None = None,
               social_page_id: str | None = None,
               social_export: str | None = None,
               social_screenshots: list[str] | None = None,
               system_exports: list[str] | None = None,
               include_tally: bool = False,
               tally_host: str = "localhost",
               tally_port: int = 9000,
               settings: Settings | None = None,
               use_ai: bool = False,
               progress=None,
               write_evidence: bool = True,
               authorisation: Authorisation | None = None) -> Review:
    settings = settings or Settings()
    say = progress or (lambda msg: None)

    # Refuse before touching anything. Every front end - the desktop app,
    # the command line, the MCP server - comes through here, so none of them
    # can scan an institution without a recorded authorisation.
    if authorisation is None:
        raise AuthorisationError(
            "No authorisation was recorded. Enter the name and designation "
            "of the person who authorised this review.")
    authorisation.require()
    say(authorisation.summary())

    say("Scanning the website")
    scan = Scanner(settings=settings, progress=say).scan(
        institution_name, base_url, extra_pages)

    social = None
    if social_page_id:
        say("Reading the school's own social media page")
        social = social_module.fetch_connected_pages(
            social_page_id, settings=settings)
    elif social_export:
        say("Reading the social media export the school supplied")
        social = social_module.load_export(social_export)
    elif social_screenshots:
        say(f"Reviewing {len(social_screenshots)} social media screenshot(s)")
        social = social_module.review_screenshots(social_screenshots,
                                                  settings=settings)

    systems = None
    if system_exports or include_tally:
        say("Reviewing the school's core systems")
        systems = systems_module.build(
            export_paths=system_exports, tally=include_tally,
            tally_host=tally_host, tally_port=tally_port, settings=settings)

    say("Applying the DPDP rules engine")
    answers = to_answer_map(responses) if responses else {}
    findings = rules_engine.assess(scan, answers, social=social,
                                  systems=systems)

    say("Scoring")
    assessment = scoring.score_findings(
        institution_name, scan.scanned_at, findings)

    ai = None
    if use_ai:
        say("Running the AI policy analysis")
        ai = ai_analyzer.analyze_policy(
            institution_name, scan.policy_text, scan.policy_source_url,
            rules_findings=findings, settings=settings)

    say("Building the two-perspective analysis")
    pairs = perspectives.build_perspectives(findings)

    documents, doc_summary = [], {}
    if document_paths:
        say(f"Reviewing {len(document_paths)} supporting document(s)")
        documents = vision.review_documents(document_paths, settings)
        doc_summary = vision.summarise(documents)

    review = Review(
        scan=scan, findings=findings, assessment=assessment, ai=ai,
        perspectives=pairs, documents=documents, document_summary=doc_summary,
        social=social, systems=systems, authorisation=authorisation,
        working_paper_stats=completion_stats(responses) if responses else {},
    )

    if write_evidence:
        say("Writing the evidence file")
        path = evidence.save(institution_name, review.to_dict())
        review.evidence_path = str(path)

    say("Done")
    return review
