"""
Deterministic assessment of a scan against the DPDP obligation catalogue.

Every finding produced here is reproducible: the same scan and the same
questionnaire always yield the same rating, and each rating carries the
evidence that produced it. That property is what lets the report be defended
to a school's management committee, and it is what the optional AI layer is
deliberately not allowed to override.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict

from .systems import HIGH_HARM
from .dpdp_catalogue import (
    CATALOGUE, GAP, MET, NOT_ASSESSED, PARTIAL, POLICY, SELF, SOCIAL,
    SYSTEMS, WEB, Obligation,
)


@dataclass
class Finding:
    obligation_id: str
    title: str
    domain: str
    provision: str
    provision_status: str
    weight: int
    status: str
    confidence: str            # high | medium | low
    rationale: str
    evidence: list[str] = field(default_factory=list)
    remediation: str = ""
    effort: str = ""
    school_note: str = ""
    decided_by: str = "rules"  # rules | questionnaire | ai-assisted

    def to_dict(self) -> dict:
        return asdict(self)


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).lower()


def _quote(text: str, phrase: str, width: int = 160) -> str | None:
    """Return a short quotation around `phrase` so a finding can be checked."""
    idx = text.find(phrase)
    if idx == -1:
        return None
    start = max(0, idx - width // 2)
    end = min(len(text), idx + len(phrase) + width // 2)
    snippet = text[start:end].strip()
    return ("..." if start else "") + snippet + ("..." if end < len(text) else "")


def _match_policy(ob: Obligation, policy: str) -> tuple[str, list[str], str]:
    """Apply the catalogue's matchers to the policy text."""
    hits: list[str] = []
    if ob.all_of:
        satisfied_groups = 0
        for group in ob.all_of:
            for phrase in group:
                q = _quote(policy, phrase)
                if q:
                    hits.append(f'"{phrase}" - {q}')
                    satisfied_groups += 1
                    break
        if satisfied_groups == len(ob.all_of):
            return MET, hits, "every required element was found in the policy text"
        if satisfied_groups:
            return PARTIAL, hits, (
                f"{satisfied_groups} of {len(ob.all_of)} required elements were "
                "found in the policy text")
        return GAP, hits, "no required element was found in the policy text"

    if ob.any_of:
        for phrase in ob.any_of:
            q = _quote(policy, phrase)
            if q:
                hits.append(f'"{phrase}" - {q}')
        if hits:
            return MET, hits, "the policy addresses this point"
        return GAP, hits, "the policy does not address this point"

    return NOT_ASSESSED, hits, "no deterministic matcher is defined"


# ---------------------------------------------------------------------------
# Web-evidence checks, keyed by obligation id. Each returns
# (status, rationale, evidence lines).
# ---------------------------------------------------------------------------

def _check_A1(scan) -> tuple[str, str, list[str]]:
    if scan.policy_pages:
        urls = [p["url"] for p in scan.policy_pages]
        return (MET,
                f"{len(urls)} policy page(s) were located and read",
                urls)
    linked = [l for p in scan.pages for l in p.get("policy_links", [])]
    if linked:
        return (PARTIAL,
                "links that look like a policy exist but none resolved to a "
                "readable policy page of meaningful length",
                sorted(set(linked))[:8])
    return (GAP, "no privacy or data-protection page could be found on the site", [])


def _check_B1(scan) -> tuple[str, str, list[str]]:
    implied = sorted({w for p in scan.pages
                      for w in p.get("implied_consent_wording", [])})
    pre_ticked = [f["action"] for p in scan.pages for f in p.get("forms", [])
                  if f.get("has_pre_ticked_checkbox")]
    forms = [f for p in scan.pages for f in p.get("forms", [])]
    with_consent = [f for f in forms if f.get("has_consent_checkbox")]
    ev: list[str] = []
    if implied:
        ev.append("implied-consent wording found: " + ", ".join(implied))
    if pre_ticked:
        ev.append("pre-ticked checkbox on: " + ", ".join(sorted(set(pre_ticked))))
    if implied or pre_ticked:
        return (GAP,
                "consent appears to be assumed rather than taken by a clear "
                "affirmative action", ev)
    if not forms:
        return (NOT_ASSESSED, "no data-collection form was found on the pages scanned", [])
    if with_consent:
        ev.append(f"{len(with_consent)} of {len(forms)} form(s) carry an "
                  "unticked consent control")
        if len(with_consent) < len(forms):
            return (PARTIAL, "some forms collect data without any consent control", ev)
        return (MET, "every form found carries an affirmative consent control", ev)
    return (GAP,
            f"{len(forms)} form(s) collect personal data with no consent control",
            [f["action"] for f in forms][:8])


def _check_B2(scan) -> tuple[str, str, list[str]]:
    sensitive = scan.sensitive_fields_seen
    if not sensitive:
        forms = [f for p in scan.pages for f in p.get("forms", [])]
        if not forms:
            return (NOT_ASSESSED, "no public form was found to review", [])
        return (MET,
                "no field asking for a sensitive or identifier category was "
                "found on the public forms", [])
    ev = [f"{s['field']} ({s['why']}) on {s['page']}" for s in sensitive]
    status = GAP if len(sensitive) > 2 else PARTIAL
    return (status,
            f"{len(sensitive)} public form field(s) ask for a sensitive or "
            "identifier category; each needs a stated purpose or removal", ev)


def _check_C2(scan) -> tuple[str, str, list[str]]:
    risky = scan.child_risk_trackers
    if risky:
        # Count distinct scripts, not pages they appear on - the same pixel on
        # four pages is one problem to fix, and saying "four trackers" would
        # overstate it.
        scripts = sorted({t["url"] for t in risky})
        hosts = sorted({t["host"] for t in risky})
        ev = [f"{t['category']}: {t['url']} (on {t['found_on']})" for t in risky]
        count = len(scripts)
        return (GAP,
                f"{count} advertising, social or session-recording "
                f"script{'s' if count != 1 else ''} "
                f"from {len(hosts)} host{'s' if len(hosts) != 1 else ''} "
                f"load{'' if count != 1 else 's'} on a site aimed at children "
                "and their parents",
                ev)
    other = scan.all_trackers
    if other:
        ev = [f"{t['category']}: {t['host']}" for t in other]
        return (PARTIAL,
                "analytics or tag-manager scripts are present; confirm "
                "advertising features are switched off and a purpose is recorded",
                ev)
    return (MET, "no advertising, social or session-recording tracker was found", [])


def _check_C4(scan) -> tuple[str, str, list[str]]:
    hosts = [h for h in scan.all_third_party_hosts
             if any(s in h for s in ("facebook", "instagram", "youtube",
                                     "twitter", "x.com", "linkedin"))]
    galleries = [p.get("final_url") or p["url"] for p in scan.pages
                 if any(k in (p.get("title", "") + (p.get("final_url") or "")).lower()
                        for k in ("gallery", "achievement", "topper", "result",
                                  "event", "photo"))]
    ev = []
    if galleries:
        ev.append("pages likely to carry student images: " + ", ".join(galleries[:6]))
    if hosts:
        ev.append("social embeds present: " + ", ".join(sorted(set(hosts))))
    if galleries or hosts:
        return (PARTIAL,
                "the site carries pages or embeds likely to publish images of "
                "identifiable children; confirm a media consent covers each one",
                ev)
    return (NOT_ASSESSED,
            "no page obviously publishing student images was found; confirm "
            "against the school's own gallery and social accounts", [])


def _check_D1(scan) -> tuple[str, str, list[str]]:
    ev: list[str] = []
    if scan.insecure_form_actions:
        ev = sorted(set(scan.insecure_form_actions))
        return (GAP,
                "a form posts personal data to a plain http:// address", ev)
    if not scan.site_is_https:
        return (GAP, "the site is not served over HTTPS",
                [scan.base_url])
    unencrypted = [p.get("final_url") or p["url"] for p in scan.pages
                   if p.get("reachable") and not p.get("https")]
    if unencrypted:
        return (PARTIAL, "some pages are served without HTTPS", unencrypted)
    return (MET, "every page reached was served over HTTPS with secure form actions",
            [scan.base_url])


def _check_F1(scan) -> tuple[str, str, list[str]]:
    officer_addresses = [e for e in scan.contact_emails
                         if any(k in e.lower() for k in
                                ("dpo", "privacy", "dataprotection", "grievance",
                                 "compliance"))]
    if officer_addresses:
        return (MET,
                "a dedicated data-protection or grievance address is published",
                officer_addresses)
    if scan.contact_emails:
        return (PARTIAL,
                "contact addresses are published but none is identifiable as "
                "the data-protection or grievance contact",
                scan.contact_emails[:8])
    return (GAP, "no contact address for data questions was found on the site", [])


def _check_G2(scan) -> tuple[str, str, list[str]]:
    if not scan.all_trackers:
        return (MET, "no third-party tracker was detected", [])
    named_in_policy = []
    policy = _normalise(scan.policy_text)
    for tracker in scan.all_trackers:
        stem = tracker["host"].split(".")[0]
        if policy and stem and stem in policy:
            named_in_policy.append(tracker["host"])
    hosts = sorted({t["host"] for t in scan.all_trackers})
    ev = [f"detected: {', '.join(hosts)}"]
    if named_in_policy:
        ev.append("named in the policy: " + ", ".join(sorted(set(named_in_policy))))
        if len(set(named_in_policy)) == len(hosts):
            return (MET, "every detected tracker is named in the policy", ev)
        return (PARTIAL, "some detected trackers are not named in the policy", ev)
    return (GAP,
            f"{len(hosts)} third-party tracker host(s) load but none is named "
            "in the published policy", ev)


# ---------------------------------------------------------------------------
# Social-media checks. These run over the school's OWN posts, obtained through
# a connected account, an export the school supplied, or screenshots. Nothing
# is scraped.
# ---------------------------------------------------------------------------

def _check_C5(social) -> tuple[str, str, list[str]]:
    counts = social.counts or {}
    posts = social.posts or []
    if not posts:
        return (NOT_ASSESSED,
                "the school's social media was not reviewed, and a website "
                "scan does not reach it", [])
    named = counts.get("names_with_class", 0)
    identifiers = counts.get("identifiers", 0)
    ev = [f"{p.get('url') or p.get('post_id') or '(post)'}: "
          f"{', '.join(p['identifiers_found'][:3])}"
          for p in posts
          if any("identifies and locates" in f for f in p["flags"])][:8]
    if identifiers:
        ev.append(f"{identifiers} post(s) carry a roll or admission number")
    if named or identifiers:
        return (GAP,
                f"{named} of {len(posts)} post(s) reviewed name a child "
                "together with a class or section" +
                (f", and {identifiers} carry a student identifier"
                 if identifiers else ""),
                ev)
    narrowed = sum(1 for p in posts
                   if any("narrows the child" in f for f in p["flags"]))
    if narrowed:
        return (PARTIAL,
                f"{narrowed} post(s) give a class or section without a name, "
                "which narrows the child to a small group",
                [p.get("url", "") for p in posts
                 if any("narrows the child" in f for f in p["flags"])][:6])
    return (MET,
            f"none of the {len(posts)} post(s) reviewed identifies an "
            "individual child by name and class", [])


def _check_C6(social) -> tuple[str, str, list[str]]:
    posts = social.posts or []
    if not posts:
        return (NOT_ASSESSED,
                "the school's social media was not reviewed", [])
    promoted = [p for p in posts if p.get("is_promoted")]
    risky = [p for p in promoted if p["flags"] or p.get("has_people")]
    if risky:
        return (GAP,
                f"{len(risky)} boosted or paid post(s) feature students",
                [p.get("url", "") for p in risky][:6])
    if promoted:
        return (MET,
                f"{len(promoted)} post(s) were promoted, none of them "
                "featuring identifiable students", [])
    return (MET, "no promoted post was found in the posts reviewed", [])


SOCIAL_CHECKS = {"C5": _check_C5, "C6": _check_C6}


# ---------------------------------------------------------------------------
# Core-system checks. These read the STRUCTURE of an export - its column
# headers and row counts - never the children in it.
# ---------------------------------------------------------------------------

def _check_S1(systems) -> tuple[str, str, list[str]]:
    reviewed = [s for s in systems.systems if not s.get("errors")]
    if not reviewed:
        return (NOT_ASSESSED,
                "no ERP or fee-software export was reviewed", [])
    high_harm = systems.counts.get("high_harm_categories", [])
    ev = []
    # The same HIGH_HARM set decides both the count and the category list,
    # so the sentence can never say "2 columns" and then name four categories.
    for system in reviewed:
        for finding in system["findings"]:
            if finding["category"] in HIGH_HARM and finding["populated"]:
                ev.append(
                    f"{system['system_name']}: column '{finding['column']}' "
                    f"({finding['category']}), populated in "
                    f"{finding['populated']} of {finding['total']} rows")
    if ev:
        return (GAP,
                f"{len(ev)} populated column(s) hold high-harm categories "
                f"({', '.join(high_harm)}). Each needs a stated purpose or "
                "removal",
                ev[:10])
    categories = sorted({c for s in reviewed
                         for c in s["categories_present"]})
    return (PARTIAL,
            "no government identifier, biometric or special-category column "
            "was found; confirm every remaining category has a stated purpose",
            [f"categories held: {', '.join(categories)}"] if categories else [])


def _check_S2(systems) -> tuple[str, str, list[str]]:
    reviewed = [s for s in systems.systems if not s.get("errors")]
    if not reviewed:
        return (NOT_ASSESSED, "no export was reviewed", [])
    stale = systems.counts.get("stale_records", 0)
    ev = []
    for system in reviewed:
        if system.get("inactive_rows"):
            ev.append(f"{system['system_name']}: {system['inactive_rows']} of "
                      f"{system['rows']} records look inactive or left")
        if system.get("oldest_year"):
            ev.append(f"{system['system_name']}: dates as old as "
                      f"{system['oldest_year']} appear in the data")
    if stale:
        return (GAP,
                f"{stale} record(s) appear to belong to students who have "
                "left and are still held in full", ev)
    if any(s.get("oldest_year") and s["oldest_year"] < 2015 for s in reviewed):
        return (PARTIAL,
                "the export contains dates going back more than a decade; "
                "confirm what is retained and why", ev)
    return (PARTIAL,
            "no status column was found, so staleness could not be measured "
            "from the export; confirm the retention position directly", ev)


def _check_S3(systems) -> tuple[str, str, list[str]]:
    accounting = systems.accounting or {}
    if not accounting or not accounting.get("reachable"):
        return (NOT_ASSESSED,
                "the accounting system was not reviewed", [])
    fields = accounting.get("fields", {})
    ev = [f"{tag}: populated in {info['populated']} ledger(s) - {info['why']}"
          for tag, info in fields.items()]
    personal = [tag for tag, info in fields.items()
                if info["category"] in ("Contact", "Home address",
                                        "Government identifier", "Financial")]
    if personal:
        return (PARTIAL,
                f"{accounting.get('ledgers', 0)} ledger(s) were read, of "
                f"which {accounting.get('party_ledgers', 0)} look like party "
                f"or staff accounts; {len(personal)} personal-data field(s) "
                "are populated and must be governed like any other system",
                ev[:10])
    return (MET,
            "no personal-data field was found populated in the ledger masters",
            ev[:6])


def _check_S4(systems) -> tuple[str, str, list[str]]:
    """The learning platform, where one was exported."""
    platforms = [s for s in systems.systems if not s.get("errors") and any(
        word in (s["system_name"] + s["source_file"]).lower()
        for word in ("lms", "learning", "classroom", "teachmint", "moodle",
                     "canvas", "portal"))]
    if not platforms:
        return (NOT_ASSESSED,
                "no learning-platform export was reviewed; answer this in the "
                "Core Systems working paper", [])
    ev, categories = [], set()
    for platform in platforms:
        categories.update(platform["categories_present"])
        ev.append(f"{platform['system_name']}: {platform['rows']} records, "
                  f"{platform['columns']} columns")
    sensitive = sorted(categories & HIGH_HARM)
    if sensitive:
        return (GAP,
                "the learning platform holds high-harm categories "
                f"({', '.join(sensitive)}), which needs a contract and a "
                "stated purpose", ev)
    return (PARTIAL,
            f"{len(platforms)} learning platform(s) reviewed; confirm a "
            "data-processing agreement is in place and what happens to "
            "student content when a class is archived",
            ev + [f"categories held: {', '.join(sorted(categories))}"])


SYSTEMS_CHECKS = {"S1": _check_S1, "S2": _check_S2, "S3": _check_S3,
                  "S4": _check_S4}


WEB_CHECKS = {
    "A1": _check_A1, "B1": _check_B1, "B2": _check_B2,
    "C2": _check_C2, "C4": _check_C4, "D1": _check_D1,
    "F1": _check_F1, "G2": _check_G2,
}


def assess(scan, answers: dict[str, str] | None = None,
           social=None, systems=None) -> list[Finding]:
    """
    Produce one Finding per obligation.

    `answers` maps an obligation id to one of 'yes', 'partly', 'no', 'unknown',
    coming from the internal-practices questionnaire. Questionnaire evidence
    outranks a web guess, because the school knows its own practice; web
    evidence outranks a questionnaire 'yes' only when it directly contradicts
    it, which is reported rather than silently resolved.
    """
    answers = answers or {}
    policy = _normalise(getattr(scan, "policy_text", "") or "")
    findings: list[Finding] = []

    for ob in CATALOGUE:
        status, rationale, evidence, decided_by = NOT_ASSESSED, "", [], "rules"
        confidence = "medium"

        # 0a. Core-system evidence, from an export's structure.
        if SYSTEMS in ob.evidence and ob.id in SYSTEMS_CHECKS:
            if systems is None or not systems.assessed:
                status = NOT_ASSESSED
                rationale = ("no ERP, fee-software or accounting review was "
                             "supplied. This is where a school's personal "
                             "data actually lives, so leaving it unassessed "
                             "understates the position.")
                confidence = "low"
            else:
                status, rationale, evidence = SYSTEMS_CHECKS[ob.id](systems)
                confidence = "high"
                decided_by = "systems"

        # 0b. Social evidence, for the obligations only a feed can show.
        if SOCIAL in ob.evidence and ob.id in SOCIAL_CHECKS:
            if social is None:
                status = NOT_ASSESSED
                rationale = ("the school's social media was not reviewed. "
                             "This is usually the largest publication surface "
                             "for children's photographs and a website scan "
                             "does not reach it.")
                confidence = "low"
            else:
                status, rationale, evidence = SOCIAL_CHECKS[ob.id](social)
                confidence = ("high" if social.source == "connected"
                              else "medium")
                decided_by = "social"

        # 1. Web evidence, where the catalogue says the web can decide it.
        if WEB in ob.evidence and ob.id in WEB_CHECKS:
            status, rationale, evidence = WEB_CHECKS[ob.id](scan)
            confidence = "high"

        # 2. Policy text, where the catalogue defines matchers.
        if POLICY in ob.evidence and (ob.all_of or ob.any_of):
            if not policy:
                if status == NOT_ASSESSED:
                    status = NOT_ASSESSED
                    rationale = ("no policy text could be read, so this could "
                                 "not be assessed from the website")
                    confidence = "low"
            else:
                p_status, p_hits, p_reason = _match_policy(ob, policy)
                if status == NOT_ASSESSED:
                    status, rationale, evidence = p_status, p_reason, p_hits
                    confidence = "medium"
                else:
                    # Combine web and policy: the weaker of the two governs.
                    order = {MET: 2, PARTIAL: 1, GAP: 0, NOT_ASSESSED: 3}
                    if order.get(p_status, 3) < order.get(status, 3):
                        status = p_status
                    rationale = f"{rationale}; {p_reason}"
                    evidence = evidence + p_hits

        # 3. Questionnaire, which is authoritative for internal practice.
        answer = (answers.get(ob.id) or "").strip().lower()
        if SELF in ob.evidence and answer in ("yes", "partly", "no"):
            mapped = {"yes": MET, "partly": PARTIAL, "no": GAP}[answer]
            if status in (NOT_ASSESSED, "") or SELF == ob.evidence[0]:
                decided_by = "questionnaire"
                note = f"self-assessed: {answer}"
                if status not in (NOT_ASSESSED, "") and status != mapped:
                    note += (f" - note that the website evidence suggested "
                             f"'{status}', which should be reconciled")
                    evidence = evidence + [f"website evidence indicated {status}"]
                rationale = f"{note}. {rationale}" if rationale else note
                status = mapped
                confidence = "high" if status != PARTIAL else "medium"
            else:
                order = {MET: 2, PARTIAL: 1, GAP: 0, NOT_ASSESSED: 3}
                if order.get(mapped, 3) < order.get(status, 3):
                    status = mapped
                    decided_by = "questionnaire"
                rationale = f"{rationale}; self-assessed: {answer}"
        elif SELF in ob.evidence and status == NOT_ASSESSED:
            rationale = ("this cannot be seen from a website; answer it in the "
                         "internal-practices questionnaire")
            confidence = "low"

        findings.append(Finding(
            obligation_id=ob.id,
            title=ob.title,
            domain=ob.domain,
            provision=ob.provision,
            provision_status=ob.status_of_provision,
            weight=ob.weight,
            status=status,
            confidence=confidence,
            rationale=rationale or "not assessed",
            evidence=evidence,
            remediation=ob.remediation,
            effort=ob.effort,
            school_note=ob.school_note,
            decided_by=decided_by,
        ))

    return findings
