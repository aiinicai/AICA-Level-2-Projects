"""Regenerate the skill's reference table from the catalogue, so the two
cannot drift apart. Run: python -m surakshascan.tools.export_catalogue"""

from __future__ import annotations

from pathlib import Path

from ..dpdp_catalogue import CATALOGUE, DOMAIN_ORDER, TOTAL_WEIGHT

TARGET = (Path(__file__).resolve().parents[2]
          / "skill" / "dpdp-readiness-review" / "references" / "obligations.md")


def render() -> str:
    lines = [
        "# Obligation catalogue",
        "",
        "Generated from `surakshascan/dpdp_catalogue.py`. Do not edit by hand -",
        "run `python -m surakshascan.tools.export_catalogue` instead.",
        "",
        f"{len(CATALOGUE)} obligations, total weight {TOTAL_WEIGHT}.",
        "",
    ]
    for domain in DOMAIN_ORDER:
        items = [o for o in CATALOGUE if o.domain == domain]
        lines += [f"## {domain}", "",
                  "| Ref | Obligation | Provision | Commences | Weight | Evidence |",
                  "|---|---|---|---|---|---|"]
        for o in items:
            lines.append(
                f"| {o.id} | {o.title} | {o.provision} | "
                f"{o.commences:%d %b %Y} | {o.weight} | "
                f"{', '.join(o.evidence)} |")
        lines.append("")
    lines += [
        "## Notes for schools", "",
    ]
    for o in CATALOGUE:
        if o.school_note:
            lines += [f"**{o.id}** — {o.school_note}", ""]
    return "\n".join(lines)


def main() -> None:
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    TARGET.write_text(render(), encoding="utf-8")
    print("wrote", TARGET)


if __name__ == "__main__":
    main()
