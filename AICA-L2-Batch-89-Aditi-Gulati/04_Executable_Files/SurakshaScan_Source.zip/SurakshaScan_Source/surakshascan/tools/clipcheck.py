"""
Check whether pasting and drag-and-drop can work on this machine.

    python -m surakshascan.tools.clipcheck

Run it with a screenshot on the clipboard. It reports what Python can
actually see, which turns "it isn't pasting" into a specific answer rather
than a guess.
"""

from __future__ import annotations

import sys
from pathlib import Path


def _line(label: str, value: str) -> None:
    print(f"  {label:<26} {value}")


def main() -> int:
    print("\n  SurakshaScan clipboard and drag-and-drop check")
    print("  " + "-" * 52)
    _line("Python", sys.version.split()[0])
    _line("Platform", sys.platform)

    ok = True

    # --- Pillow, which is what reads an image off the clipboard.
    try:
        import PIL
        _line("Pillow", PIL.__version__)
    except ImportError:
        _line("Pillow", "NOT INSTALLED  ->  pip install pillow")
        ok = False
        PIL = None

    grabbed = None
    if PIL is not None:
        try:
            from PIL import ImageGrab
            grabbed = ImageGrab.grabclipboard()
        except Exception as exc:
            _line("Clipboard read", f"FAILED  {type(exc).__name__}: {exc}")
            ok = False
        else:
            if grabbed is None:
                _line("Clipboard holds", "no image")
                print("\n  The clipboard has no image on it right now.")
                print("  Press Win+Shift+S, snip a post, then run this again.")
            elif isinstance(grabbed, list):
                _line("Clipboard holds", f"{len(grabbed)} file path(s)")
                for item in grabbed[:3]:
                    _line("", str(item))
            else:
                size = getattr(grabbed, "size", ("?", "?"))
                _line("Clipboard holds", f"an image, {size[0]}x{size[1]} px")
                try:
                    out = Path.home() / ".surakshascan" / "clipcheck.png"
                    out.parent.mkdir(parents=True, exist_ok=True)
                    grabbed.save(out, "PNG")
                    _line("Saved a copy to", str(out))
                except Exception as exc:
                    _line("Could not save it",
                          f"{type(exc).__name__}: {exc}")
                    ok = False

    # --- tkinterdnd2, which is what allows files to be dragged in.
    try:
        import tkinterdnd2
        _line("tkinterdnd2",
              getattr(tkinterdnd2, "__version__", "installed"))
    except ImportError:
        _line("tkinterdnd2",
              "NOT INSTALLED  ->  pip install tkinterdnd2")
        print("\n  Drag-and-drop will be unavailable. Pasting still works.")

    print()
    if grabbed is not None and not isinstance(grabbed, list):
        print("  Pasting should work. If Ctrl+V does nothing in the app,")
        print("  click the 'Paste screenshot' button instead and tell me")
        print("  what happens.")
    print("  Note: dragging an image out of a browser passes a link, not a")
    print("  file. Save the image first, or snip it and paste.\n")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
