"""
Self-test: run a complete review against a school site bundled with the
project, with no internet connection and nobody's permission required.

    python -m surakshascan.tools.demo

It serves the fixture site on localhost, runs the full pipeline - scan, rules
engine, working paper, scoring, two-perspective analysis, evidence file - and
writes all three reports to output_reports/. If this works, the installation
works.
"""

from __future__ import annotations

import functools
import http.server
import socketserver
import sys
import threading
import time
from pathlib import Path

from .. import report_docx, report_html, report_xlsx
from ..authorisation import fixture as fixture_authorisation
from ..config import Settings
from ..engine import run_review
from ..questionnaire import QUESTIONS, STATUS_COMPLETED, blank_responses, finalise

from ..resources import output_root, resource

SITE = resource("tests", "fixtures", "site")
SOCIAL_EXPORT = resource("tests", "fixtures", "social_posts.csv")
LMS_EXPORT = resource("tests", "fixtures", "lms_classroom.csv")
ERP_EXPORT = resource("tests", "fixtures", "erp_export.csv")
OUT = output_root()
PORT = 8931

# A part-completed working paper, as a reviewer would have it mid-engagement.
SAMPLE_ANSWERS = {
    "Q01": "no", "Q03": "no", "Q05": "partly", "Q09": "no", "Q11": "no",
    "Q14": "partly", "Q17": "no", "Q18": "no", "Q20": "no", "Q22": "no",
}


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


class QuietServer(socketserver.TCPServer):
    allow_reuse_address = True

    def handle_error(self, *args):
        pass


def main() -> int:
    if not SITE.exists():
        print(f"The fixture site is missing at {SITE}", file=sys.stderr)
        return 1

    server = QuietServer(("127.0.0.1", PORT),
                         functools.partial(QuietHandler, directory=str(SITE)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    time.sleep(0.3)
    base = f"http://127.0.0.1:{PORT}/"
    print(f"Serving the fixture school at {base}\n")

    settings = Settings()
    settings.crawl_delay = 0.0
    settings.max_retries = 0

    responses = blank_responses()
    for question_id, answer in SAMPLE_ANSWERS.items():
        response = responses[question_id]
        response.answer = answer
        response.status = STATUS_COMPLETED
        response.reviewer = "Demo reviewer"
        response.confidence = "document seen"
        finalise(response, next(q for q in QUESTIONS if q.id == question_id))

    try:
        review = run_review(
            "Sunrise Public School (demonstration)", base,
            [base + "contact.html", base + "gallery.html"],
            responses=responses, settings=settings, use_ai=False,
            authorisation=fixture_authorisation(),
            social_export=str(SOCIAL_EXPORT) if SOCIAL_EXPORT.exists()
            else None,
            system_exports=[
                ("Student records / ERP", str(ERP_EXPORT)),
                ("Learning platform", str(LMS_EXPORT)),
            ] if ERP_EXPORT.exists() else None,
            progress=lambda message: print("  ", message))
    finally:
        server.shutdown()

    setattr(review, "_responses", responses)
    OUT.mkdir(parents=True, exist_ok=True)
    print()
    for label, path in (
            ("Word report  ", report_docx.generate(
                review, OUT / "Sample_DPDP_Readiness_Report.docx",
                prepared_by="Demo reviewer")),
            ("Excel workings", report_xlsx.generate(
                review, OUT / "Sample_DPDP_Workings.xlsx")),
            ("HTML dashboard", report_html.generate(
                review, OUT / "Sample_DPDP_Dashboard.html"))):
        print(f"  {label}  {path}")

    assessment = review.assessment
    print(f"\n  Score {assessment.score:.0f}/100 ({assessment.band})")
    print(f"  Coverage {assessment.coverage_percent:.0f}% of the catalogue")
    print(f"  {assessment.counts.get('GAP', 0)} gaps, "
          f"{assessment.counts.get('PARTIAL', 0)} partly met, "
          f"{assessment.counts.get('NOT_ASSESSED', 0)} not assessed")
    print(f"  Evidence file: {review.evidence_path}")
    print("\n  Expected for this fixture: a Critical band with the Facebook "
          "pixel,\n  the http:// form action and the Aadhaar field all caught.")

    if review.social and review.social.posts:
        counts = review.social.counts
        print(f"\n  Social media: {counts['posts']} posts reviewed, "
              f"{counts['high_risk']} high risk, "
              f"{counts['names_with_class']} naming a child with a class")

    if review.systems and review.systems.assessed:
        counts = review.systems.counts
        print(f"  Core systems: {counts['systems_reviewed']} export(s), "
              f"{counts['rows']} records, "
              f"{counts['stale_records']} leaver record(s) still held")
        if counts["high_harm_categories"]:
            print("                high harm: "
                  + ", ".join(counts["high_harm_categories"]))

    caught = {
        "advertising pixel": bool(review.scan.child_risk_trackers),
        "insecure form action": bool(review.scan.insecure_form_actions),
        "sensitive form fields": bool(review.scan.sensitive_fields_seen),
        "no policy page found": not review.scan.policy_pages,
        "social post naming a child with a class": bool(
            review.social and review.social.counts.get("names_with_class")),
        "high-harm column in the ERP export": bool(
            review.systems
            and review.systems.counts.get("high_harm_categories")),
        "leaver records still held": bool(
            review.systems and review.systems.counts.get("stale_records")),
        "boosted post featuring a child": bool(
            review.social and any(
                p["is_promoted"] and p["identifiers_found"]
                for p in review.social.posts)),
    }
    print()
    for check, passed in caught.items():
        print(f"  [{'x' if passed else ' '}] {check}")
    if all(caught.values()):
        print("\n  Self-test passed.")
        return 0
    print("\n  Self-test FAILED - something did not behave as expected.",
          file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
