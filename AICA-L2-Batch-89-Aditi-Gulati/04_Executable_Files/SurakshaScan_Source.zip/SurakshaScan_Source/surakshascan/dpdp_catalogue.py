"""
DPDP obligation catalogue for educational institutions.

Every obligation carries the provision it comes from, the date that provision
commences, the weight it contributes to the readiness score, the evidence
sources that can decide it, and the remediation to offer when it is not met.

Legal basis
-----------
* Digital Personal Data Protection Act, 2023 ("the Act").
* Digital Personal Data Protection Rules, 2025 ("the Rules"), notified
  13 November 2025. There are TWENTY-THREE rules. Compliance is phased over
  eighteen months: the Board and procedural rules operate from notification,
  Consent Manager registration follows about twelve months later, and the
  substantive duties on Data Fiduciaries - notice, security, breach,
  retention, children's data, rights and transfers - land at the end of the
  eighteen-month window, around 14 May 2027.

  A NOTE ON RULE NUMBERS. Secondary commentaries disagree with each other on
  the numbering: at least one widely-cited summary lists only twenty-two
  rules and shifts every number after Rule 11 by one, which turns the
  children's exemption into "Rule 13". The numbering used here follows the
  twenty-three-rule structure, in which:
      Rule 10 - verifiable consent for a child
      Rule 11 - verifiable consent for a person with a disability
      Rule 12 - exemptions from certain obligations for a child's data
      Rule 13 - additional obligations of a Significant Data Fiduciary
  Before any report leaves the reviewer's desk, the rule numbers and the
  commencement dates relied on should be checked against the notified text
  in the Gazette. This module makes that easy by keeping every citation in
  one place.
* Fourth Schedule, Part A of the Rules read with Rule 12 exempts an
  educational institution from section 9(1) (verifiable parental consent) and
  section 9(3) (tracking, behavioural monitoring and targeted advertising)
  for academic activities, for tracking and behavioural monitoring, and for
  ensuring the safety of enrolled students - strictly limited to those
  purposes. Processing beyond them is not exempt.

Nothing in this module is legal advice; it is a structured checklist that a
qualified person reviews.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Sequence

# --------------------------------------------------------------------------
# Commencement dates, used to label an obligation as in force or forthcoming.
# --------------------------------------------------------------------------
PHASE_1 = date(2025, 11, 13)
PHASE_2 = date(2026, 11, 14)
PHASE_3 = date(2027, 5, 14)

# The Act's substantive duties bind a Data Fiduciary from enactment; the Rules
# put procedure around them on the dates above. We surface both.
ACT_IN_FORCE = date(2023, 8, 11)

# Evidence sources.
WEB = "web"            # decided from the crawl (headers, HTML, trackers, forms)
POLICY = "policy"      # decided from the text of the published policy
SELF = "questionnaire"  # decided from the internal-practices questionnaire
SOCIAL = "social"      # decided from the school's own social media posts
SYSTEMS = "systems"    # decided from an export of a core system
SYSTEMS = "systems"    # decided from an ERP export or the accounting masters

# Rating bands.
MET = "MET"
PARTIAL = "PARTIAL"
GAP = "GAP"
NOT_ASSESSED = "NOT_ASSESSED"
NOT_APPLICABLE = "NOT_APPLICABLE"

CREDIT = {MET: 1.0, PARTIAL: 0.5, GAP: 0.0}


@dataclass(frozen=True)
class Obligation:
    id: str
    domain: str
    title: str
    provision: str
    commences: date
    weight: int
    evidence: Sequence[str]
    why_it_matters: str
    remediation: str
    effort: str                      # low | medium | high
    # Deterministic matchers applied to the policy text. `all_of` groups are
    # AND-ed; within a group any one phrase satisfies it.
    all_of: Sequence[Sequence[str]] = field(default_factory=tuple)
    any_of: Sequence[str] = field(default_factory=tuple)
    school_note: str = ""

    @property
    def in_force(self) -> bool:
        return date.today() >= self.commences

    @property
    def status_of_provision(self) -> str:
        return "in force" if self.in_force else f"from {self.commences:%d %b %Y}"


CATALOGUE: tuple[Obligation, ...] = (

    # ---------------------------------------------------------------- notice
    Obligation(
        id="A1",
        domain="Notice and transparency",
        title="A privacy notice is published and reachable from the website",
        provision="s.5, Act; Rule 3, Rules",
        commences=ACT_IN_FORCE,
        weight=6,
        evidence=(WEB,),
        why_it_matters=(
            "A Data Fiduciary must give the Data Principal a notice with every "
            "request for consent. If no notice is published, no consent the "
            "school collects online can be informed consent."
        ),
        remediation=(
            "Publish a DPDP notice at /privacy-policy and link it from the "
            "footer of every page, the admission enquiry form and the fee "
            "portal."
        ),
        effort="low",
        school_note="Checked by locating a policy page during the crawl.",
    ),
    Obligation(
        id="A2",
        domain="Notice and transparency",
        title="The notice itemises the categories of personal data collected",
        provision="s.5(1)(i), Act; Rule 3(1)(a)",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(POLICY,),
        why_it_matters=(
            "The notice must describe the personal data, itemised. A generic "
            "line such as 'we collect your information' does not satisfy s.5."
        ),
        remediation=(
            "List each category actually collected: student name, date of "
            "birth, photograph, Aadhaar-linked APAAR/UDISE identifiers, "
            "parent contact, medical and allergy notes, transport pickup "
            "point, biometric attendance, CCTV footage, fee and bank details."
        ),
        effort="medium",
        all_of=(
            ("categories of personal data", "personal data we collect",
             "information we collect", "data we collect", "types of data"),
        ),
    ),
    Obligation(
        id="A3",
        domain="Notice and transparency",
        title="The notice states the specified purpose for each category",
        provision="s.5(1)(i), Act; Rule 3(1)(a)",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(POLICY,),
        why_it_matters=(
            "Consent is valid only for the specified purpose. Purpose has to be "
            "stated against the data, not described in the abstract."
        ),
        remediation=(
            "Set out a table of category against purpose, and drop any "
            "category with no purpose behind it."
        ),
        effort="medium",
        all_of=(
            ("purpose", "purposes"),
            ("we use", "used for", "in order to", "processed for", "for the purpose"),
        ),
    ),
    Obligation(
        id="A4",
        domain="Notice and transparency",
        title="The notice explains how to withdraw consent",
        provision="s.5(1)(ii), Act; Rule 3(1)(b)",
        commences=ACT_IN_FORCE,
        weight=4,
        evidence=(POLICY,),
        why_it_matters=(
            "Withdrawal must be as easy as giving consent, and the means has "
            "to be communicated in the notice."
        ),
        remediation=(
            "Add a withdrawal paragraph naming the channel - a link, an email "
            "address, or the school office - and state that withdrawal does "
            "not affect processing already carried out lawfully."
        ),
        effort="low",
        any_of=("withdraw consent", "withdrawal of consent", "revoke consent",
                "withdraw your consent", "opt out of processing"),
    ),
    Obligation(
        id="A5",
        domain="Notice and transparency",
        title="The notice explains Data Principal rights and how to exercise them",
        provision="s.5(1)(ii), ss.11-14, Act; Rule 14",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(POLICY,),
        why_it_matters=(
            "Parents and students have rights of access, correction, erasure, "
            "grievance redressal and nomination. The notice must say how to "
            "use them."
        ),
        remediation=(
            "Name the four rights, give one channel to exercise all of them, "
            "and publish the period within which the school will respond."
        ),
        effort="low",
        any_of=("right to access", "right to correction", "right of erasure",
                "right to erasure", "data principal rights", "your rights",
                "right to nominate", "rights of the data principal"),
    ),
    Obligation(
        id="A6",
        domain="Notice and transparency",
        title="The notice gives the route to complain to the Data Protection Board",
        provision="s.5(1)(iii), Act",
        commences=ACT_IN_FORCE,
        weight=3,
        evidence=(POLICY,),
        why_it_matters=(
            "The notice must tell the Data Principal how to complain to the "
            "Board. This is routinely the single missing line in school "
            "policies."
        ),
        remediation=(
            "Add: 'If your grievance is not resolved, you may complain to the "
            "Data Protection Board of India.' State that the school's own "
            "grievance route must be exhausted first."
        ),
        effort="low",
        any_of=("data protection board", "board of india", "dpb"),
    ),

    # --------------------------------------------------------------- consent
    Obligation(
        id="B1",
        domain="Consent",
        title="Consent is collected by clear affirmative action, not assumed",
        provision="s.6(1), Act",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(WEB, SELF),
        why_it_matters=(
            "Consent must be free, specific, informed, unconditional and "
            "unambiguous with a clear affirmative action. Pre-ticked boxes, "
            "'by continuing you agree' banners and silence are not consent."
        ),
        remediation=(
            "Replace any implied-consent banner with an unticked checkbox "
            "beside a link to the notice, and log the consent artefact."
        ),
        effort="medium",
    ),
    Obligation(
        id="B2",
        domain="Consent",
        title="Only data necessary for the stated purpose is collected",
        provision="s.6(1) proviso, Act",
        commences=ACT_IN_FORCE,
        weight=4,
        evidence=(WEB, SELF),
        why_it_matters=(
            "Consent extends only to personal data necessary for the specified "
            "purpose. Enquiry forms that ask for a date of birth, caste, "
            "mother's maiden name or Aadhaar without a purpose exceed it."
        ),
        remediation=(
            "Review every public form field against its purpose and delete the "
            "fields that cannot be justified."
        ),
        effort="low",
    ),
    Obligation(
        id="B3",
        domain="Consent",
        title="Consent records are kept and are auditable",
        provision="s.6(1), s.8(1), Act",
        commences=ACT_IN_FORCE,
        weight=4,
        evidence=(SELF,),
        why_it_matters=(
            "The school must be able to demonstrate that valid consent was "
            "obtained. A paper admission form with no consent clause leaves "
            "nothing to demonstrate."
        ),
        remediation=(
            "Add a dated, signed DPDP consent block to the admission form and "
            "keep a register mapping student to consent version."
        ),
        effort="medium",
    ),

    # -------------------------------------------------------------- children
    Obligation(
        id="C1",
        domain="Children's data",
        title="Verifiable parental consent before processing a child's data",
        provision="s.9(1), Act; Rule 10",
        commences=PHASE_3,
        weight=8,
        evidence=(SELF, POLICY),
        why_it_matters=(
            "Everyone below eighteen is a child under the Act, so effectively "
            "the whole student body. Consent must be that of the parent and "
            "must be verifiable, with due diligence that the parent is an "
            "identifiable adult."
        ),
        remediation=(
            "Capture parental consent against a verified parent identity - "
            "details already held in the admission record, or a virtual token "
            "from an authorised entity such as a DigiLocker provider - and "
            "retain the verification evidence."
        ),
        effort="high",
        any_of=("parental consent", "verifiable consent", "consent of the parent",
                "guardian consent", "parent or guardian"),
        school_note=(
            "Rule 12 with Part A of the Fourth Schedule relieves an "
            "educational institution of s.9(1) for academic activities and "
            "student safety. It does not relieve the school for anything else "
            "- alumni marketing, photographs in promotional material, an "
            "EdTech app the school resells, or a third-party feed."
        ),
    ),
    Obligation(
        id="C2",
        domain="Children's data",
        title="No tracking, behavioural monitoring or targeted advertising to children",
        provision="s.9(3), Act",
        commences=PHASE_3,
        weight=8,
        evidence=(WEB, SELF),
        why_it_matters=(
            "Section 9(3) forbids tracking, behavioural monitoring and "
            "targeted advertising directed at children. An advertising pixel "
            "on a school website is the clearest form of this."
        ),
        remediation=(
            "Remove advertising and social pixels from all pages. Keep only "
            "analytics that is necessary and configured without advertising "
            "features, and document the safety or academic purpose relied on."
        ),
        effort="low",
        school_note=(
            "The Fourth Schedule exemption covers tracking and behavioural "
            "monitoring for academic activity and for the safety of enrolled "
            "students. A Meta or DoubleClick pixel on a public page serves "
            "neither purpose and sits outside the exemption."
        ),
    ),
    Obligation(
        id="C3",
        domain="Children's data",
        title="Reliance on the Fourth Schedule exemption is documented and purpose-limited",
        provision="Rule 12 read with Fourth Schedule, Part A",
        commences=PHASE_3,
        weight=5,
        evidence=(SELF,),
        why_it_matters=(
            "The exemption is conditional. It holds only while processing "
            "stays inside the enumerated purposes, and the school carries the "
            "burden of showing that it does."
        ),
        remediation=(
            "Record, per processing activity, whether it is academic, safety "
            "or neither; for the 'neither' column, obtain verifiable parental "
            "consent."
        ),
        effort="medium",
    ),
    Obligation(
        id="C4",
        domain="Children's data",
        title="Student photographs and names are not published without consent",
        provision="s.6(1), s.9(1), Act",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(WEB, SELF),
        why_it_matters=(
            "Gallery pages, result boards and social feeds carrying named "
            "children are processing of a child's personal data for a "
            "promotional purpose, which no academic or safety exemption "
            "reaches."
        ),
        remediation=(
            "Take a separate, revocable media consent at admission, keep a "
            "do-not-publish list, and honour it across website, brochures and "
            "social media."
        ),
        effort="medium",
    ),

    Obligation(
        id="C5",
        domain="Children's data",
        title="Social media posts do not identify an individual child",
        provision="s.6(1), s.9(1), Act",
        commences=ACT_IN_FORCE,
        weight=7,
        evidence=(SOCIAL,),
        why_it_matters=(
            "A photograph is personal data. A photograph captioned with a "
            "full name and a class identifies a specific child and says where "
            "that child can be found every weekday morning. This is the "
            "combination child-safety guidance warns about, and a school feed "
            "produces it weekly without anyone deciding to."
        ),
        remediation=(
            "Stop publishing a child's full name, class and photograph "
            "together. Use a first name only, or the class without the name, "
            "or the name without the class - and never a roll or admission "
            "number."
        ),
        effort="low",
        school_note=(
            "The Fourth Schedule exemption does not reach a promotional post. "
            "Rule 12 with Part A covers academic activity and the safety of "
            "enrolled students; celebrating a result on Instagram is neither, "
            "so section 9(1) applies in full and verifiable parental consent "
            "is required."
        ),
    ),
    Obligation(
        id="C6",
        domain="Children's data",
        title="Posts featuring children are not paid for or boosted",
        provision="s.9(3), Act",
        commences=PHASE_3,
        weight=4,
        evidence=(SOCIAL, SELF),
        why_it_matters=(
            "Paying a platform to push a post featuring children into other "
            "people's feeds is the clearest thing a school does that looks "
            "like advertising directed at and using children's data."
        ),
        remediation=(
            "Never boost or promote a post that features students. Promote "
            "posts about facilities, admissions dates or staff instead."
        ),
        effort="low",
    ),
    Obligation(
        id="C7",
        domain="Children's data",
        title="Media consent is separate, granular and genuinely revocable",
        provision="s.6(1), s.6(4), s.9(1), Act",
        commences=ACT_IN_FORCE,
        weight=7,
        evidence=(SELF,),
        why_it_matters=(
            "A line inside the admission form saying the school may use "
            "photographs is bundled consent attached to admission: a parent "
            "cannot refuse it without appearing to refuse the admission. "
            "Section 6(1) requires consent to be specific and unconditional, "
            "and section 6(4) requires withdrawal to be as easy as giving it."
        ),
        remediation=(
            "Take media consent on its own form, channel by channel - website, "
            "social media, prospectus, press, parent groups - with a tick "
            "against each. State how a parent withdraws and the period within "
            "which the school will take the content down."
        ),
        effort="medium",
        school_note=(
            "Withdrawal has to actually work. Deleting a post does not recall "
            "reshares, screenshots or forwards, so the school should promise "
            "only what it can deliver and say so plainly on the form."
        ),
    ),
    Obligation(
        id="C8",
        domain="Children's data",
        title="Staff do not publish student data from personal accounts",
        provision="s.8(1), s.8(5), Act",
        commences=ACT_IN_FORCE,
        weight=4,
        evidence=(SELF,),
        why_it_matters=(
            "The school remains the Data Fiduciary for school activity "
            "whoever's phone the photograph came from. A teacher posting a "
            "class picture to their own Instagram, or a class list into a "
            "parent WhatsApp group, is processing the school cannot see, "
            "cannot withdraw and cannot account for."
        ),
        remediation=(
            "Issue a one-page rule: student photographs and lists go out only "
            "from the school's official accounts, by a named person. Say what "
            "staff should do instead, not only what they must not do."
        ),
        effort="low",
    ),

    # ------------------------------------------------------ security, breach
    Obligation(
        id="D1",
        domain="Security and breach",
        title="The site and its forms are served over HTTPS",
        provision="s.8(5), Act; Rule 6(1)",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(WEB,),
        why_it_matters=(
            "Encryption in transit is the baseline reasonable security "
            "safeguard. A form that posts admission data over plain HTTP is an "
            "unprotected transfer of a child's personal data."
        ),
        remediation=(
            "Install a TLS certificate, redirect HTTP to HTTPS, and confirm no "
            "form posts to an http:// action.",
        )[0],
        effort="low",
    ),
    Obligation(
        id="D2",
        domain="Security and breach",
        title="Reasonable security safeguards are in place and documented",
        provision="s.8(5), Act; Rule 6",
        commences=PHASE_3,
        weight=6,
        evidence=(SELF,),
        why_it_matters=(
            "Rule 6 sets a floor: encryption or masking, access control, "
            "logging and monitoring retained for one year, backups, and "
            "contractual security terms with processors."
        ),
        remediation=(
            "Write a one-page security standard covering access control on the "
            "ERP, encryption of exports, a one-year log retention setting and "
            "a tested backup."
        ),
        effort="high",
    ),
    Obligation(
        id="D3",
        domain="Security and breach",
        title="A personal data breach response procedure exists",
        provision="s.8(6), Act; Rule 7",
        commences=PHASE_3,
        weight=6,
        evidence=(SELF, POLICY),
        why_it_matters=(
            "On a breach the school must intimate each affected Data Principal "
            "without delay and report to the Board, with a fuller report "
            "following. Without a procedure the clock is missed."
        ),
        remediation=(
            "Adopt a breach procedure naming who declares a breach, the "
            "notification templates for parents and for the Board, and a "
            "breach register."
        ),
        effort="medium",
        any_of=("data breach", "breach of personal data", "security incident",
                "breach notification"),
    ),

    # ---------------------------------------------------- retention, erasure
    Obligation(
        id="E1",
        domain="Retention and erasure",
        title="A retention schedule exists and data is erased when the purpose ends",
        provision="s.8(7), Act; Rule 8",
        commences=PHASE_3,
        weight=6,
        evidence=(SELF, POLICY),
        why_it_matters=(
            "Personal data must be erased once the purpose is no longer served "
            "and retention is not required by law. Schools typically hold "
            "enquiry data and ex-student records indefinitely."
        ),
        remediation=(
            "Set a period per record class - unsuccessful enquiries, withdrawn "
            "students, alumni, CCTV, biometric attendance - and schedule the "
            "deletion. Keep only what a records rule requires."
        ),
        effort="high",
        any_of=("retention period", "how long we keep", "retain your data",
                "data retention", "erasure of data", "we will delete"),
    ),
    Obligation(
        id="E2",
        domain="Retention and erasure",
        title="CCTV and biometric data are handled under a stated rule",
        provision="s.8(7), Act; Rule 6, Rule 8",
        commences=PHASE_3,
        weight=4,
        evidence=(SELF,),
        why_it_matters=(
            "CCTV footage and biometric attendance are personal data of "
            "children held continuously. They attract the safety purpose but "
            "not an unlimited retention period."
        ),
        remediation=(
            "Fix a CCTV overwrite cycle, restrict who can export footage, log "
            "every export, and confirm the biometric vendor's contract and "
            "deletion terms."
        ),
        effort="medium",
    ),

    # -------------------------------------------- governance and grievance
    Obligation(
        id="F1",
        domain="Governance and grievance",
        title="Contact details of the person answering data questions are published",
        provision="s.5(1)(iii), s.8(9), Act; Rule 9",
        commences=ACT_IN_FORCE,
        weight=6,
        evidence=(POLICY, WEB),
        why_it_matters=(
            "The school must publish the business contact of the Data "
            "Protection Officer, or of the person able to answer questions "
            "about the processing, prominently on the website and in the "
            "notice."
        ),
        remediation=(
            "Name a role - not an individual's personal mobile - publish a "
            "dedicated address such as dpo@school.edu.in on the policy page "
            "and the contact page, and route it to a monitored inbox."
        ),
        effort="low",
        any_of=("data protection officer", "grievance officer", "dpo@",
                "privacy officer", "nodal officer"),
    ),
    Obligation(
        id="F2",
        domain="Governance and grievance",
        title="A grievance redressal mechanism with a stated response period",
        provision="s.8(10), Act; Rule 9(2)",
        commences=PHASE_3,
        weight=5,
        evidence=(POLICY, SELF),
        why_it_matters=(
            "A readily available means of grievance redressal is a standalone "
            "duty, and the period within which the school responds must be "
            "published."
        ),
        remediation=(
            "Publish the grievance route and a response period, and keep a "
            "dated register of requests and outcomes."
        ),
        effort="low",
        any_of=("grievance", "complaint", "redressal", "raise a concern"),
    ),
    Obligation(
        id="F3",
        domain="Governance and grievance",
        title="A record of processing activities exists",
        provision="s.8(1), Act (accountability)",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(SELF,),
        why_it_matters=(
            "The Data Fiduciary is responsible for compliance whether it "
            "processes itself or through a processor. Nothing can be governed "
            "that has not first been listed."
        ),
        remediation=(
            "Build a register of every system holding student or staff data - "
            "ERP, transport GPS, biometric, CCTV, LMS, WhatsApp groups, exam "
            "portal - with owner, purpose, categories and vendor."
        ),
        effort="high",
    ),
    Obligation(
        id="F4",
        domain="Governance and grievance",
        title="Staff who handle student data have been trained",
        provision="s.8(1), s.8(5), Act",
        commences=ACT_IN_FORCE,
        weight=4,
        evidence=(SELF,),
        why_it_matters=(
            "Most school data incidents are a teacher forwarding a class list "
            "on WhatsApp, not an external attack."
        ),
        remediation=(
            "Run a short annual briefing for teaching and office staff, and "
            "issue a one-page rule on sharing student data."
        ),
        effort="low",
    ),

    # ----------------------------------------------------------- core systems
    Obligation(
        id="S1",
        domain="Core systems",
        title="The student records system holds no category without a purpose",
        provision="s.6(1) proviso, s.5(1)(i), Act",
        commences=ACT_IN_FORCE,
        weight=7,
        evidence=(SYSTEMS, SELF),
        why_it_matters=(
            "The ERP is where the school's children's data actually lives, "
            "and fields accumulate in it for years - a caste column for a "
            "return that stopped, an Aadhaar field nobody can explain, a "
            "free-text remarks box. Consent extends only to data necessary "
            "for the stated purpose, and the notice must itemise what is "
            "held."
        ),
        remediation=(
            "Export the student master, list every column, and write the "
            "purpose beside each. Remove or mask the columns where the "
            "purpose column stays blank, starting with identifiers and "
            "free-text remarks."
        ),
        effort="medium",
        school_note=(
            "Fee data is commercial administration rather than an academic "
            "activity, so the Fourth Schedule is a weaker shield over the "
            "fee side of the ERP than over the academic side."
        ),
    ),
    Obligation(
        id="S2",
        domain="Core systems",
        title="Leavers are erased from the student system when retention ends",
        provision="s.8(7), Act; Rule 8",
        commences=PHASE_3,
        weight=6,
        evidence=(SYSTEMS, SELF),
        why_it_matters=(
            "Most school ERPs have no delete function and nobody has ever "
            "tried. Students who left years ago sit there with full parent "
            "contact details, long after any purpose is spent, which is also "
            "what makes a breach so much larger than it needed to be."
        ),
        remediation=(
            "Fix a retention period per record class, ask the vendor in "
            "writing how a record is erased, and actually run the first "
            "deletion. Keep a deletion log."
        ),
        effort="high",
    ),
    Obligation(
        id="S3",
        domain="Core systems",
        title="Student data in the accounts is minimised and the retention "
              "conflict is recorded",
        provision="s.6(1) proviso, s.8(7), Act",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(SYSTEMS, SELF),
        why_it_matters=(
            "Fee receipts are usually posted with the student's name against "
            "them, so a slice of children's data sits in the books of "
            "account - a system more people can open, and one that must be "
            "preserved for years under the Income-tax and Companies Act "
            "record rules. A school that erases a leaver from the ERP has "
            "therefore usually not erased them."
        ),
        remediation=(
            "Record the conflict openly in the retention schedule: the ERP "
            "record is erased, the accounting entry is preserved under the "
            "record-keeping rules. Then ask whether the ledger needs the "
            "name at all - a receipt number reconciling to the ERP gives the "
            "same audit trail with less personal data."
        ),
        effort="low",
        school_note=(
            "Statutory preservation is a lawful basis for retention. The "
            "failure is not keeping the books; it is keeping more than the "
            "books need, and never writing down why."
        ),
    ),
    Obligation(
        id="S4",
        domain="Core systems",
        title="The learning platform is governed as a data processor",
        provision="s.8(1), s.8(2), Act",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(SYSTEMS, SELF),
        why_it_matters=(
            "A learning platform holds student work, attendance, assessment "
            "and often a photograph and a parent email. It is a processor "
            "engaged by the school, so section 8(2) requires a valid "
            "contract and section 8(1) leaves the school answerable for it - "
            "including for the teacher-created classes nobody approved."
        ),
        remediation=(
            "List every learning platform actually in use, including the free "
            "ones teachers signed up for. Put a data-processing addendum in "
            "place, restrict who can create a class, and confirm what happens "
            "to student content when a class is archived."
        ),
        effort="medium",
    ),

    # ------------------------------------------------ processors and vendors
    Obligation(
        id="G1",
        domain="Processors and third parties",
        title="A written contract is in place with every data processor",
        provision="s.8(2), Act",
        commences=ACT_IN_FORCE,
        weight=6,
        evidence=(SELF,),
        why_it_matters=(
            "A Data Fiduciary may engage a processor only under a valid "
            "contract. School ERP, fee gateway, transport tracking, biometric "
            "and LMS vendors are all processors."
        ),
        remediation=(
            "Add a data-processing addendum to each vendor agreement covering "
            "purpose limitation, security, sub-processing, breach reporting "
            "and deletion on exit."
        ),
        effort="high",
    ),
    Obligation(
        id="G2",
        domain="Processors and third parties",
        title="Third-party trackers on the website are disclosed and justified",
        provision="s.5, s.6, s.9(3), Act",
        commences=ACT_IN_FORCE,
        weight=5,
        evidence=(WEB, POLICY),
        why_it_matters=(
            "Every third-party script loading on a school page is a disclosure "
            "of visitor data to that third party, and must be named in the "
            "notice and consented to."
        ),
        remediation=(
            "Inventory the scripts, remove what is not needed, name the rest "
            "in the notice, and gate non-essential ones behind consent."
        ),
        effort="medium",
    ),
    Obligation(
        id="G3",
        domain="Processors and third parties",
        title="Cross-border transfer position is known",
        provision="s.16, Act; Rule 15",
        commences=PHASE_3,
        weight=3,
        evidence=(SELF, POLICY),
        why_it_matters=(
            "Transfer outside India is permitted except to a restricted "
            "territory. Most school SaaS stores data abroad, so the school "
            "should at least know where."
        ),
        remediation=(
            "Ask each vendor in writing where student data is hosted and "
            "record the answer."
        ),
        effort="medium",
        any_of=("outside india", "cross-border", "transferred abroad",
                "international transfer", "stored outside"),
    ),

    # ------------------------------------------------- core systems and AI

)


DOMAIN_ORDER = (
    "Notice and transparency",
    "Consent",
    "Children's data",
    "Security and breach",
    "Retention and erasure",
    "Governance and grievance",
    "Processors and third parties",
    "Core systems",
)

TOTAL_WEIGHT = sum(o.weight for o in CATALOGUE)


def by_id(obligation_id: str) -> Obligation:
    for o in CATALOGUE:
        if o.id == obligation_id:
            return o
    raise KeyError(obligation_id)


def in_domain(domain: str) -> list[Obligation]:
    return [o for o in CATALOGUE if o.domain == domain]
