"""
The AI layer - Day 1 prompting method applied to a compliance problem.

Design rules, taken from the course's safe working method and carried into
code rather than left in a slide:

1. The prompt is built as Role + Context + Objective + Output Format +
   Examples. It is assembled in one place so it can be reviewed.
2. The model is required to quote the exact passage it relied on. A finding
   with no quotation is downgraded, not trusted.
3. The model is required to declare what is missing and how certain it is.
   Gap-filling is explicitly forbidden in the instruction and enforced by
   discarding any obligation id the model invented.
4. The deterministic rules engine is authoritative. The AI may add nuance,
   quotations and drafting suggestions; it may not silently overturn a
   rules-engine rating. Where it disagrees, both are reported.
5. The API key is read from the environment or the OS keyring. It is never
   written into the source, the config file or the evidence store.
6. If no key is present the tool still runs, and says plainly that the AI
   layer was not used - rather than printing a placeholder and calling it
   analysis, which is what v1 did.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field, asdict

from .config import Settings
from .dpdp_catalogue import CATALOGUE, GAP, MET, PARTIAL, by_id

MAX_POLICY_CHARS = 24000


# --------------------------------------------------------------------------
# Prompt construction - Role + Context + Objective + Output Format + Examples
# --------------------------------------------------------------------------

ROLE = (
    "You are assisting a Chartered Accountant who is conducting a data "
    "protection readiness review of an Indian school under the Digital "
    "Personal Data Protection Act, 2023 and the DPDP Rules, 2025. You are a "
    "reviewer, not an advocate. You do not reassure."
)

CONTEXT_TEMPLATE = (
    "Institution: {institution}\n"
    "Policy document read from: {source_url}\n"
    "Everyone below eighteen is a child under the Act, so substantially the "
    "whole student body is a child Data Principal. Rule 12 with Part A of the "
    "Fourth Schedule relieves an educational institution of section 9(1) and "
    "section 9(3) only for academic activities, for tracking and behavioural "
    "monitoring, and for the safety of enrolled students; processing outside "
    "those purposes is not exempt."
)

OBJECTIVE = (
    "For each obligation listed below, decide whether the policy text "
    "satisfies it, partly satisfies it, or does not address it, using ONLY "
    "the policy text supplied. For every obligation you must quote the exact "
    "words of the policy you relied on. If the policy does not contain "
    "language on the point, say so and leave the quotation empty - do not "
    "infer, do not assume a reasonable school would have it, and do not "
    "draw on any other document. Separately, list what a reviewer still "
    "needs to see that the policy text cannot show."
)

OUTPUT_FORMAT = (
    "Reply with a single JSON object and nothing else:\n"
    "{\n"
    '  "findings": [\n'
    "    {\n"
    '      "id": "<obligation id exactly as given>",\n'
    '      "status": "MET" | "PARTIAL" | "GAP",\n'
    '      "quotation": "<exact words from the policy, or empty string>",\n'
    '      "reasoning": "<one or two sentences>",\n'
    '      "confidence": "high" | "medium" | "low"\n'
    "    }\n"
    "  ],\n"
    '  "missing_information": ["<what the reviewer must obtain separately>"],\n'
    '  "drafting_suggestions": [\n'
    '    {"obligation_id": "<id>", "suggested_clause": "<text the school '
    'could adopt>"}\n'
    "  ]\n"
    "}"
)

EXAMPLES = (
    "Example of a good finding, where the policy did contain the language:\n"
    '{"id": "A4", "status": "MET", "quotation": "You may withdraw your '
    'consent at any time by writing to the school office.", "reasoning": '
    '"The policy names a withdrawal channel.", "confidence": "high"}\n\n'
    "Example of a good finding, where it did not:\n"
    '{"id": "A6", "status": "GAP", "quotation": "", "reasoning": "The policy '
    'contains no reference to the Data Protection Board or to any external '
    'complaint route.", "confidence": "high"}\n\n'
    "Example of what NOT to do - this invents a protection the policy never "
    "states, and must never be produced:\n"
    '{"id": "A6", "status": "MET", "quotation": "", "reasoning": "Schools '
    'are generally required to allow complaints, so this is likely covered."}'
)


def build_prompt(institution: str, source_url: str | None,
                 policy_text: str,
                 obligation_ids: list[str] | None = None) -> str:
    obligations = [by_id(i) for i in obligation_ids] if obligation_ids else [
        o for o in CATALOGUE if o.all_of or o.any_of]
    lines = [
        f"- {o.id}: {o.title}  [{o.provision}]" for o in obligations]
    policy = policy_text[:MAX_POLICY_CHARS]
    truncated = len(policy_text) > MAX_POLICY_CHARS
    return "\n\n".join([
        "## Role\n" + ROLE,
        "## Context\n" + CONTEXT_TEMPLATE.format(
            institution=institution, source_url=source_url or "(not found)"),
        "## Objective\n" + OBJECTIVE,
        "## Obligations to assess\n" + "\n".join(lines),
        "## Output format\n" + OUTPUT_FORMAT,
        "## Examples\n" + EXAMPLES,
        "## Policy text\n<policy>\n" + policy + "\n</policy>"
        + ("\n\n[Note: the policy text was truncated for length. Say so in "
           "missing_information.]" if truncated else ""),
    ])


# --------------------------------------------------------------------------
# Result types
# --------------------------------------------------------------------------

@dataclass
class AIFinding:
    obligation_id: str
    status: str
    quotation: str
    reasoning: str
    confidence: str
    accepted: bool = True
    rejected_because: str = ""


@dataclass
class AIAnalysis:
    used: bool
    model: str = ""
    reason_not_used: str = ""
    findings: list[AIFinding] = field(default_factory=list)
    missing_information: list[str] = field(default_factory=list)
    drafting_suggestions: list[dict] = field(default_factory=list)
    disagreements: list[dict] = field(default_factory=list)
    raw_response_chars: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


# --------------------------------------------------------------------------
# Key handling - environment first, then OS keyring. Never the source tree.
# --------------------------------------------------------------------------

def resolve_api_key(settings: Settings) -> str | None:
    key = os.environ.get(settings.api_key_env)
    if key:
        return key.strip()
    try:
        import keyring  # optional dependency
        stored = keyring.get_password("surakshascan", "anthropic_api_key")
        if stored:
            return stored.strip()
    except Exception:
        pass
    return None


def _extract_json(text: str) -> dict | None:
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    candidate = fenced.group(1) if fenced else None
    if candidate is None:
        start, end = text.find("{"), text.rfind("}")
        candidate = text[start:end + 1] if start != -1 and end > start else None
    if not candidate:
        return None
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        return None


VALID_STATUS = {MET, PARTIAL, GAP}
VALID_IDS = {o.id for o in CATALOGUE}


def analyze_policy(institution: str, policy_text: str,
                   source_url: str | None = None,
                   rules_findings: list | None = None,
                   settings: Settings | None = None) -> AIAnalysis:
    """Run the AI layer if a key is available; otherwise say so honestly."""
    settings = settings or Settings()

    if not policy_text or len(policy_text) < 400:
        return AIAnalysis(
            used=False,
            reason_not_used=("No policy text of usable length was retrieved, "
                             "so there was nothing for the AI layer to read. "
                             "The deterministic checks still ran."))

    key = resolve_api_key(settings)
    if not key:
        return AIAnalysis(
            used=False,
            reason_not_used=(
                "No API key was available, so the AI layer did not run. Every "
                "rating in this report comes from the deterministic rules "
                f"engine. Set {settings.api_key_env} in the environment, or "
                "store the key in the OS keyring, to enable it."))

    try:
        import anthropic
    except ImportError:
        return AIAnalysis(
            used=False,
            reason_not_used=("The anthropic package is not installed, so the "
                             "AI layer did not run. Deterministic checks "
                             "still applied."))

    prompt = build_prompt(institution, source_url, policy_text)
    try:
        client = anthropic.Anthropic(api_key=key)
        response = client.messages.create(
            model=settings.ai_model,
            max_tokens=4000,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = "".join(block.text for block in response.content
                      if getattr(block, "type", "") == "text")
    except Exception as exc:
        return AIAnalysis(
            used=False,
            reason_not_used=(f"The AI layer failed to run ({type(exc).__name__}"
                             f": {exc}). Deterministic checks still applied."))

    payload = _extract_json(raw)
    if payload is None:
        return AIAnalysis(
            used=False, model=settings.ai_model, raw_response_chars=len(raw),
            reason_not_used=("The AI layer returned something that was not "
                             "valid JSON, so it was discarded rather than "
                             "guessed at."))

    analysis = AIAnalysis(used=True, model=settings.ai_model,
                          raw_response_chars=len(raw))

    for item in payload.get("findings", []):
        oid = str(item.get("id", "")).strip()
        status = str(item.get("status", "")).strip().upper()
        quotation = str(item.get("quotation", "") or "").strip()
        finding = AIFinding(
            obligation_id=oid, status=status,
            quotation=quotation,
            reasoning=str(item.get("reasoning", "")).strip(),
            confidence=str(item.get("confidence", "low")).strip().lower(),
        )
        # Guard 1: the model may not invent an obligation.
        if oid not in VALID_IDS:
            finding.accepted = False
            finding.rejected_because = "obligation id is not in the catalogue"
        # Guard 2: the model may not invent a status.
        elif status not in VALID_STATUS:
            finding.accepted = False
            finding.rejected_because = f"status '{status}' is not a valid rating"
        # Guard 3: a positive finding must be backed by a real quotation that
        # actually appears in the policy. This is the anti-hallucination check.
        elif status in (MET, PARTIAL):
            normalised_policy = re.sub(r"\s+", " ", policy_text).lower()
            normalised_quote = re.sub(r"\s+", " ", quotation).lower()
            if not quotation:
                finding.accepted = False
                finding.rejected_because = (
                    "claimed the obligation was met but quoted nothing")
            elif normalised_quote not in normalised_policy:
                finding.accepted = False
                finding.rejected_because = (
                    "the quoted passage does not appear in the policy text")
        analysis.findings.append(finding)

    analysis.missing_information = [
        str(m) for m in payload.get("missing_information", [])][:20]
    analysis.drafting_suggestions = [
        d for d in payload.get("drafting_suggestions", [])
        if isinstance(d, dict) and d.get("obligation_id") in VALID_IDS][:20]

    # Report, rather than resolve, any disagreement with the rules engine.
    if rules_findings:
        rules_by_id = {f.obligation_id: f for f in rules_findings}
        for ai_finding in analysis.findings:
            if not ai_finding.accepted:
                continue
            rule = rules_by_id.get(ai_finding.obligation_id)
            if rule and rule.status in VALID_STATUS and rule.status != ai_finding.status:
                analysis.disagreements.append({
                    "obligation_id": ai_finding.obligation_id,
                    "rules_engine": rule.status,
                    "ai_layer": ai_finding.status,
                    "ai_quotation": ai_finding.quotation,
                    "note": ("The deterministic rating governs the score. "
                             "This difference is flagged for the reviewer to "
                             "settle against the policy document."),
                })

    return analysis


def suggest_policy_clause(obligation_id: str) -> str:
    """Offline drafting help - no API needed, no invention."""
    ob = by_id(obligation_id)
    return (f"[{ob.id}] {ob.title}\n"
            f"Provision: {ob.provision} ({ob.status_of_provision})\n"
            f"Action: {ob.remediation}")
