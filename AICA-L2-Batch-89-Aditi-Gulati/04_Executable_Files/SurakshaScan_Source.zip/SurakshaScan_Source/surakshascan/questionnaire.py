"""
The internal-practices working paper - Day 4 audit working paper method.

A website scan sees the shop window. Most of a school's DPDP risk is behind
it: the ERP, the transport GPS, the biometric machine, the WhatsApp groups,
the vendor contracts nobody has read. This module is the working paper that
covers that, and it borrows the audit checklist discipline directly:

* five tabs, one per review area;
* a status per line - Completed / In Progress / Pending / NA;
* the reviewer's name is mandatory before a line can be marked Completed,
  because an unattributed conclusion is not a working paper;
* where a line is marked Completed with no remark, a neutral remark is
  generated that records what was done - it never asserts work that was not
  performed;
* a confidence flag per line, so a line answered from memory is visibly
  weaker than one answered from a document;
* every line names the document the reviewer should have seen.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

STATUS_COMPLETED = "Completed"
STATUS_IN_PROGRESS = "In Progress"
STATUS_PENDING = "Pending"
STATUS_NA = "NA"
STATUSES = (STATUS_COMPLETED, STATUS_IN_PROGRESS, STATUS_PENDING, STATUS_NA)

ANSWERS = ("yes", "partly", "no", "unknown")
CONFIDENCE = ("document seen", "stated by school", "not verified")

TABS = (
    "Records and Systems",
    "Consent and Notice",
    "Children and Safeguarding",
    "Security and Retention",
    "Vendors and Governance",
)


@dataclass
class Question:
    id: str
    tab: str
    obligation_id: str
    text: str
    evidence_to_see: str
    guidance: str = ""


@dataclass
class Response:
    question_id: str
    answer: str = "unknown"          # yes | partly | no | unknown
    status: str = STATUS_PENDING
    reviewer: str = ""
    confidence: str = "not verified"
    remark: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


QUESTIONS: tuple[Question, ...] = (
    # ----------------------------------------- Records and Systems
    Question("Q01", "Records and Systems", "F3",
             "Does a written list exist of every system that holds student, "
             "parent or staff personal data?",
             "The register itself - ERP, LMS, fee gateway, transport GPS, "
             "biometric attendance, CCTV, exam portal, WhatsApp groups.",
             "If the list has never been made, the answer is no, however well "
             "the systems are run."),
    Question("Q02", "Records and Systems", "F3",
             "For each system, is the purpose, the data categories and the "
             "owner recorded?",
             "The completed columns of the register.",
             ""),
    Question("Q03", "Records and Systems", "B3",
             "Can the school produce, for a named student, the consent it "
             "relies on and show which purposes it covers?",
             "One sample admission file, picked by the reviewer, not by the "
             "school.",
             "Pick the file yourself. A specimen form is not evidence that it "
             "was used."),
    Question("Q04", "Records and Systems", "F4",
             "Have teaching and office staff been briefed on handling student "
             "data in the last twelve months?",
             "Attendance sheet or circular with dates.",
             ""),

    # ------------------------------------------ Consent and Notice
    Question("Q05", "Consent and Notice", "B1",
             "Does the admission form carry a distinct data protection consent "
             "clause, separate from the general terms?",
             "The current admission form.",
             "A clause inside 'I agree to the school rules' is bundled consent."),
    Question("Q06", "Consent and Notice", "B2",
             "Has every field on the admission and enquiry forms been tested "
             "against a stated purpose, with unjustified fields removed?",
             "The field-by-field purpose mapping.",
             "Caste, mother's maiden name and blood group each need a purpose "
             "or need to go."),
    Question("Q07", "Consent and Notice", "A4",
             "Is there a working channel by which a parent can withdraw "
             "consent, and has it ever been used?",
             "The channel, and the register of withdrawals.",
             ""),
    Question("Q08", "Consent and Notice", "F2",
             "Is there a dated register of data-related requests and "
             "grievances with the response given?",
             "The register.",
             "An empty register that exists is better than no register."),

    # ----------------------------------- Children and Safeguarding
    Question("Q09", "Children and Safeguarding", "C1",
             "Is parental consent taken against a verified parent identity, "
             "rather than from whoever filled in the form?",
             "The verification step - identity document held, or the parent "
             "record already on file, matched at the time of consent.",
             "Rule 10 requires due diligence that the person consenting is an "
             "identifiable adult."),
    Question("Q10", "Children and Safeguarding", "C3",
             "Has each processing activity been classified as academic, "
             "safety, or neither?",
             "The classification list.",
             "This is what the Fourth Schedule exemption stands or falls on."),
    Question("Q11", "Children and Safeguarding", "C4",
             "Is a separate, revocable media consent taken before a student's "
             "photograph or name is published?",
             "The media consent form and the do-not-publish list.",
             "Prospectus, website, social media and newspaper coverage all "
             "count."),
    Question("Q12", "Children and Safeguarding", "C2",
             "Is the school satisfied that no advertising or profiling tool "
             "processes student data?",
             "The tag list from the website and the ERP's integrations page.",
             "Section 9(3) is a prohibition, not a balancing exercise."),
    Question("Q13", "Children and Safeguarding", "E2",
             "Is there a stated rule for CCTV footage - who may view it, who "
             "may export it, and when it is overwritten?",
             "The CCTV policy and the DVR retention setting.",
             ""),
    Question("Q14", "Children and Safeguarding", "C4",
             "Is a do-not-publish list maintained and checked before a "
             "photograph goes out?",
             "The list, and whoever checks it.",
             "Some parents have reasons they should not have to explain, such "
             "as a custody arrangement."),

    # -------------------------------------- Security and Retention
    Question("Q15", "Security and Retention", "D2",
             "Is access to the student database restricted by named user "
             "accounts rather than a shared login?",
             "The ERP user list.",
             "A shared 'admin' password means no audit trail exists."),
    Question("Q16", "Security and Retention", "D2",
             "Are exports of student data - Excel downloads, mark sheets, "
             "address lists - controlled and logged?",
             "The export log, or the absence of one.",
             ""),
    Question("Q17", "Security and Retention", "D2",
             "Are backups taken and has a restore been tested in the last "
             "year?",
             "The backup schedule and the date of the last restore test.",
             ""),
    Question("Q18", "Security and Retention", "D3",
             "Is there a written procedure saying who declares a data breach "
             "and who must be told?",
             "The procedure and the breach register.",
             "Rule 7 requires intimation to affected persons and to the Board."),
    Question("Q19", "Security and Retention", "E1",
             "Is there a retention schedule fixing how long each class of "
             "record is kept, with the reason?",
             "The schedule.",
             "Unsuccessful enquiries and withdrawn students are the usual "
             "problem."),
    Question("Q20", "Security and Retention", "E1",
             "Has anything actually been deleted under that schedule in the "
             "last year?",
             "The deletion log.",
             "A schedule never acted on is a document, not a control."),

    # -------------------------------------- Vendors and Governance
    Question("Q21", "Vendors and Governance", "G1",
             "Does every vendor holding student data have a signed contract "
             "with data protection terms?",
             "The contracts, listed against the system register.",
             "Purpose limitation, security, sub-processing, breach reporting, "
             "deletion on exit."),
    Question("Q22", "Vendors and Governance", "G3",
             "Is it known, for each vendor, where the student data is hosted?",
             "The vendor's written answer.",
             ""),
    Question("Q23", "Vendors and Governance", "F1",
             "Has a person been named to answer data protection questions, "
             "with a published address that is monitored?",
             "The published address and evidence that mail to it is read.",
             ""),
    Question("Q24", "Vendors and Governance", "C3",
             "Does the management committee receive a periodic report on data "
             "protection?",
             "Minutes referring to it.",
             "Accountability sits with the Data Fiduciary, which is the "
             "institution, not the IT vendor."),
    Question("Q25", "Vendors and Governance", "G1",
             "When a vendor contract ends, is deletion of the school's data "
             "confirmed in writing?",
             "The last exit confirmation, if any.",
             ""),
    Question("Q26", "Vendors and Governance", "G1",
             "Are the ERP's integrations known - SMS gateway, payment "
             "gateway, biometric device, transport GPS?",
             "The integrations or API settings page of the ERP.",
             "Each integration is a further processor receiving parent "
             "numbers or child data, usually enabled once and never "
             "reviewed."),
)


def questions_for_tab(tab: str) -> list[Question]:
    return [q for q in QUESTIONS if q.tab == tab]


def blank_responses() -> dict[str, Response]:
    return {q.id: Response(question_id=q.id) for q in QUESTIONS}


NEUTRAL_REMARK = (
    "Reviewed by {reviewer} on {date}. The evidence described for this line "
    "was inspected and the answer recorded above reflects it. No further "
    "exception was noted."
)


def validate(response: Response, question: Question) -> list[str]:
    """Return a list of validation errors. Empty means the line is sound."""
    errors: list[str] = []
    if response.status not in STATUSES:
        errors.append(f"status must be one of {', '.join(STATUSES)}")
    if response.answer not in ANSWERS:
        errors.append(f"answer must be one of {', '.join(ANSWERS)}")
    if response.status == STATUS_COMPLETED and not response.reviewer.strip():
        errors.append("a reviewer name is required before a line is marked "
                      "Completed")
    if response.status == STATUS_COMPLETED and response.answer == "unknown":
        errors.append("a line marked Completed cannot leave the answer unknown")
    if response.confidence not in CONFIDENCE:
        errors.append(f"confidence must be one of {', '.join(CONFIDENCE)}")
    if (response.answer == "yes" and response.confidence == "not verified"
            and response.status == STATUS_COMPLETED):
        errors.append("a 'yes' recorded as Completed must be supported by a "
                      "document seen or at least attributed to the school")
    return errors


def finalise(response: Response, question: Question) -> Response:
    """Apply the working-paper conventions to a line before it is stored."""
    response.updated_at = datetime.now(timezone.utc).isoformat(
        timespec="seconds")
    if response.status == STATUS_COMPLETED and not response.remark.strip():
        response.remark = NEUTRAL_REMARK.format(
            reviewer=response.reviewer.strip() or "(unnamed)",
            date=datetime.now().strftime("%d %B %Y"))
    return response


def to_answer_map(responses: dict[str, Response]) -> dict[str, str]:
    """
    Collapse the working paper into the obligation-level answers the rules
    engine consumes. Where several questions map to one obligation, the
    weakest answer governs - an audit does not average away an exception.
    """
    rank = {"no": 0, "partly": 1, "unknown": 2, "yes": 3}
    worst: dict[str, str] = {}
    for question in QUESTIONS:
        response = responses.get(question.id)
        if response is None or response.answer == "unknown":
            continue
        if response.status == STATUS_NA:
            continue
        current = worst.get(question.obligation_id)
        if current is None or rank[response.answer] < rank[current]:
            worst[question.obligation_id] = response.answer
    return worst


def completion_stats(responses: dict[str, Response]) -> dict:
    counts = {s: 0 for s in STATUSES}
    by_tab: dict[str, dict[str, int]] = {t: {s: 0 for s in STATUSES}
                                         for t in TABS}
    for question in QUESTIONS:
        response = responses.get(question.id)
        status = response.status if response else STATUS_PENDING
        counts[status] = counts.get(status, 0) + 1
        by_tab[question.tab][status] = by_tab[question.tab].get(status, 0) + 1
    assessable = len(QUESTIONS) - counts[STATUS_NA]
    return {
        "total": len(QUESTIONS),
        "by_status": counts,
        "by_tab": by_tab,
        "percent_complete": round(
            100.0 * counts[STATUS_COMPLETED] / assessable, 1) if assessable else 0.0,
    }
