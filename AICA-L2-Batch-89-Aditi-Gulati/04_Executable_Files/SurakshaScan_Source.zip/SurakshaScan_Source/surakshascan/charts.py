"""Charts for the dashboard and the Word report. Matplotlib, Agg backend."""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

# Deep blue, amber, red, grey - readable in print and colour-blind safe enough
# for a status chart where the label is also written out.
INK = "#1F3B57"
TEAL = "#2E7D8F"
COLOURS = {
    "MET": "#2E7D5B",
    "PARTIAL": "#C98A16",
    "GAP": "#B3321E",
    "NOT_ASSESSED": "#9AA5AD",
}
LABELS = {
    "MET": "Met",
    "PARTIAL": "Partly met",
    "GAP": "Gap",
    "NOT_ASSESSED": "Not assessed",
}


def _finish(fig, path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return str(path)


def donut_of_statuses(counts: dict, score: float, out_path) -> str:
    """Status mix with the readiness score in the hole."""
    out_path = Path(out_path)
    order = ["MET", "PARTIAL", "GAP", "NOT_ASSESSED"]
    values = [counts.get(k, 0) for k in order]
    present = [(LABELS[k], v, COLOURS[k]) for k, v in zip(order, values) if v]
    if not present:
        present = [("No data", 1, COLOURS["NOT_ASSESSED"])]

    fig, ax = plt.subplots(figsize=(4.6, 4.6))
    wedges, _ = ax.pie(
        [p[1] for p in present],
        colors=[p[2] for p in present],
        startangle=90,
        wedgeprops={"width": 0.36, "edgecolor": "white", "linewidth": 2},
    )
    ax.text(0, 0.10, f"{score:.0f}", ha="center", va="center",
            fontsize=34, fontweight="bold", color=INK)
    ax.text(0, -0.20, "readiness score", ha="center", va="center",
            fontsize=9, color="#5A6B78")
    ax.legend(wedges, [f"{p[0]} ({p[1]})" for p in present],
              loc="upper center", bbox_to_anchor=(0.5, 0.02),
              ncol=2, frameon=False, fontsize=8.5)
    ax.set_aspect("equal")
    return _finish(fig, out_path)


def bar_of_domains(domains, out_path) -> str:
    """Percentage met by domain, worst at the top."""
    out_path = Path(out_path)
    rows = sorted(domains, key=lambda d: d.percent)
    names = [d.domain for d in rows]
    values = [d.percent for d in rows]
    colours = [COLOURS["GAP"] if v < 50 else
               COLOURS["PARTIAL"] if v < 80 else COLOURS["MET"]
               for v in values]

    fig, ax = plt.subplots(figsize=(7.6, 0.55 * len(rows) + 1.4))
    bars = ax.barh(names, values, color=colours, height=0.58)
    ax.set_xlim(0, 100)
    ax.set_xlabel("Weighted obligations met (%)", fontsize=9, color="#5A6B78")
    ax.bar_label(bars, fmt="%.0f%%", padding=4, fontsize=9, color=INK)
    ax.tick_params(axis="y", labelsize=9)
    ax.tick_params(axis="x", labelsize=8, colors="#5A6B78")
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#D6DCE1")
    ax.grid(axis="x", color="#EDF1F3", linewidth=1)
    ax.set_axisbelow(True)
    return _finish(fig, out_path)


def bar_of_working_paper(stats: dict, out_path) -> str:
    """Working-paper completion by tab."""
    out_path = Path(out_path)
    tabs = list(stats["by_tab"].keys())
    statuses = ["Completed", "In Progress", "Pending", "NA"]
    palette = {"Completed": COLOURS["MET"], "In Progress": TEAL,
               "Pending": COLOURS["PARTIAL"], "NA": COLOURS["NOT_ASSESSED"]}

    fig, ax = plt.subplots(figsize=(7.6, 0.55 * len(tabs) + 1.6))
    left = [0.0] * len(tabs)
    for status in statuses:
        values = [stats["by_tab"][t].get(status, 0) for t in tabs]
        ax.barh(tabs, values, left=left, color=palette[status],
                label=status, height=0.58)
        left = [l + v for l, v in zip(left, values)]
    ax.set_xlabel("Working paper lines", fontsize=9, color="#5A6B78")
    ax.legend(ncol=4, frameon=False, fontsize=8.5,
              loc="upper center", bbox_to_anchor=(0.5, -0.18))
    ax.tick_params(labelsize=9)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#D6DCE1")
    ax.grid(axis="x", color="#EDF1F3", linewidth=1)
    ax.set_axisbelow(True)
    return _finish(fig, out_path)


def bar_of_comparison(comparison: dict, out_path) -> str:
    """Benchmark this school against the others scanned."""
    out_path = Path(out_path)
    rows = comparison["rows"]
    if not rows:
        return ""
    names = [r["institution"][:34] for r in rows]
    scores = [r["score"] for r in rows]
    average = comparison["peer_average_score"]

    fig, ax = plt.subplots(figsize=(7.6, 0.55 * len(rows) + 1.4))
    bars = ax.barh(names, scores, color=TEAL, height=0.55)
    ax.axvline(average, color=COLOURS["GAP"], linestyle="--", linewidth=1.2)
    ax.text(average, -0.75, f"peer average {average:.0f}",
            fontsize=8, color=COLOURS["GAP"], ha="center")
    ax.bar_label(bars, fmt="%.0f", padding=4, fontsize=9, color=INK)
    ax.set_xlim(0, 100)
    ax.invert_yaxis()
    ax.set_xlabel("Readiness score", fontsize=9, color="#5A6B78")
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#D6DCE1")
    ax.grid(axis="x", color="#EDF1F3", linewidth=1)
    ax.set_axisbelow(True)
    return _finish(fig, out_path)
