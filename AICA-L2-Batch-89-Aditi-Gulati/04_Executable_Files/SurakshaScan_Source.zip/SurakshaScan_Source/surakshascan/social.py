"""
The social media surface.

A school's website is a brochure it controls. Its social feed is a continuous
publication of children's photographs, usually run by whoever is free, and it
is where the real exposure sits. The Fourth Schedule does not reach it:
Rule 12 with Part A relieves an educational institution of section 9(1) for
academic activities and for the safety of enrolled students, and a promotional
post is neither. So verifiable parental consent under Rule 10 applies in full.

Design constraint, stated plainly because it shaped everything here:

    This module does not scrape social media.

Scraping public Instagram or Facebook breaches those platforms' terms, is
actively blocked, and - the real objection - a compliance tool that harvests
children's photographs in order to check whether children's photographs are
being over-shared is doing the thing it audits. That is not defensible.

Three routes are offered instead, in descending order of confidence:

1. **Connected account.** The school owns its pages, so it can authorise
   read-only access to its OWN posts with its OWN token. Nothing belonging to
   anyone else is ever read.
2. **Export file.** The school downloads its posts from the platform's own
   data-export tool and hands over the file.
3. **Manual sample.** The reviewer supplies screenshots, which `vision.py`
   reads. Lowest confidence, always available, and honest about being a
   sample rather than a census.

What is analysed is the caption and the metadata, not the faces. This tool
does not attempt face recognition on children, which would be a worse
intrusion than the one being reviewed.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

from .config import Settings

# --------------------------------------------------------------------------
# Caption patterns. A photograph alone is personal data; a photograph with a
# full name and a class identifies AND locates a specific child every weekday
# morning, which is the combination child-safety guidance warns about.
# --------------------------------------------------------------------------

CLASS_PATTERNS = (
    # Devanagari - a school feed in Varanasi is as likely to say
    # "कक्षा 5" as "Class 5", and an English-only matcher would report a
    # clean feed simply because it could not read the caption.
    r"कक्षा\s*[-:]?\s*[0-9१-९IVX]+",
    r"\bवर्ग\s*[-:]?\s*[0-9१-९]+",
    r"नर्सरी|केजी|प्राथमिक",
    r"\bclass\s*[-:]?\s*(?:[1-9]|1[0-2]|[IVX]{1,4})\s*[-–]?\s*[A-F]?\b",
    r"\bstd\.?\s*[-:]?\s*(?:[1-9]|1[0-2]|[IVX]{1,4})\b",
    r"\bgrade\s*[-:]?\s*(?:[1-9]|1[0-2])\b",
    r"\b(?:nursery|lkg|ukg|kindergarten|pre-?primary)\b",
    r"\b(?:section)\s*[-:]?\s*[A-F]\b",
)
ROLL_PATTERNS = (
    r"\broll\s*(?:no\.?|number)\s*[-:]?\s*\d+",
    r"\badmission\s*(?:no\.?|number)\s*[-:]?\s*\w+",
    r"\bapaar\b", r"\budise\b",
)
# A capitalised two-or-three word name sitting next to a class reference.
NAME_NEAR_CLASS = re.compile(
    r"([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{1,})+)"          # Aarav Sharma
    r"[\s,–-]*(?:of|from|,)?[\s,]*"
    r"(?:class|std\.?|grade)", re.IGNORECASE)
CLASS_NEAR_NAME = re.compile(
    r"(?:class|std\.?|grade)\s*[-:]?\s*(?:[1-9]|1[0-2]|[IVX]{1,4})"
    r"\s*[-–]?\s*[A-F]?[\s,–-]*"
    r"([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{1,})+)")

# Words that are capitalised in a caption but are not part of a child's name.
# Without this, "Congratulations Aarav Sharma of Class 5-B" yields the name
# "Congratulations Aarav Sharma", which is wrong in the report and looks
# careless to anyone reading it.
NAME_STOPWORDS = {
    "congratulations", "congratulation", "congrats", "well", "done", "proud",
    "heartiest", "hearty", "best", "wishes", "wishing", "kudos", "bravo",
    "our", "the", "we", "students", "student", "dear", "shri", "smt",
    "master", "miss", "mr", "mrs", "ms", "kum", "baby", "winner", "topper",
    "first", "second", "third", "rank", "annual", "day", "school", "today",
    "special", "many", "congratulating", "felicitating", "presenting",
    "inter", "school", "competition", "annual", "function", "celebration",
    # Connectors that sit between the name and the class reference.
    "of", "from", "in", "to", "at", "for", "and", "is", "was", "by",
}

ACHIEVEMENT_WORDS = (
    "congratulations", "congratulate", "topper", "rank", "winner", "won",
    "first prize", "gold medal", "scored", "result", "proud of", "felicitat",
    # Devanagari equivalents seen constantly on Indian school pages.
    "बधाई", "हार्दिक", "प्रथम", "विजेता", "शुभकामना", "सम्मानित", "गौरव",
)
LOCATION_WORDS = (
    "campus", "branch", "road", "nagar", "colony", "sector", "block",
    "pin code", "pincode",
)
DEVANAGARI = re.compile(r"[\u0900-\u097F]")

MEDICAL_WORDS = (
    "special needs", "differently abled", "divyang", "therapy", "counselling",
    "counseling", "allergy", "medical", "wheelchair", "autis",
)

PLATFORMS = ("facebook", "instagram", "youtube", "x", "linkedin", "whatsapp",
             "other")


@dataclass
class SocialPost:
    platform: str
    post_id: str = ""
    url: str = ""
    posted_at: str = ""
    caption: str = ""
    media_count: int = 0
    has_people: bool | None = None     # the reviewer's judgement, not the tool's
    is_promoted: bool = False          # a paid boost engages s.9(3) more directly
    source: str = "manual"             # connected | export | manual
    # Filled by analyse()
    flags: list[str] = field(default_factory=list)
    identifiers_found: list[str] = field(default_factory=list)
    risk: str = "low"                  # high | medium | low

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class SocialReview:
    handles: list[dict] = field(default_factory=list)
    posts: list[dict] = field(default_factory=list)
    reviewed_at: str = ""
    source: str = "none"
    coverage_note: str = ""
    counts: dict = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    @property
    def assessed(self) -> bool:
        return bool(self.posts)

    def to_dict(self) -> dict:
        return asdict(self)


# --------------------------------------------------------------------------
# Caption analysis
# --------------------------------------------------------------------------

def _clean_name(candidate: str) -> str:
    """
    Trim greeting words off the front of a captured name and keep what looks
    like an actual name. Returns an empty string when nothing survives, so a
    caption of pure congratulation does not produce a phantom child.
    """
    words = [w for w in candidate.split() if w]
    while words and words[0].lower().strip(",.!") in NAME_STOPWORDS:
        words.pop(0)
    while words and words[-1].lower().strip(",.!") in NAME_STOPWORDS:
        words.pop()
    if len(words) < 2:
        return ""
    return " ".join(words[-3:]).strip(" ,.-")


def analyse_caption(caption: str) -> tuple[list[str], list[str]]:
    """Return (flags, identifiers) found in a post caption."""
    text = caption or ""
    lowered = text.lower()
    flags: list[str] = []
    identifiers: list[str] = []

    class_hits = [m.group(0).strip() for pattern in CLASS_PATTERNS
                  for m in re.finditer(pattern, lowered, re.IGNORECASE)]
    if class_hits:
        identifiers.extend(sorted(set(class_hits))[:4])

    raw_names = [m.group(1) for m in NAME_NEAR_CLASS.finditer(text)]
    raw_names += [m.group(1) for m in CLASS_NEAR_NAME.finditer(text)]
    names = sorted({cleaned for cleaned in
                    (_clean_name(n) for n in raw_names) if cleaned})
    if names:
        identifiers.extend(names[:4])
        flags.append(
            "names a child together with a class or section, which identifies "
            "and locates a specific student")
    elif class_hits:
        flags.append(
            "gives a class or section, which narrows the child to a small "
            "group even without a name")

    for pattern in ROLL_PATTERNS:
        for m in re.finditer(pattern, lowered, re.IGNORECASE):
            identifiers.append(m.group(0).strip())
            flags.append(
                "carries a roll, admission or student identifier, which should "
                "never appear in a public post")
            break

    achievement = any(w in lowered for w in ACHIEVEMENT_WORDS)
    if achievement and (names or class_hits):
        flags.append(
            "celebrates an individual achievement, which is a promotional "
            "purpose and sits outside the Fourth Schedule exemption")

    # Devanagari has no capital letters, so the name matcher above cannot
    # find a Hindi name the way it finds an English one. Rather than guess at
    # one - and risk reporting "छात्रों ने" as a child's name in a compliance
    # report - say plainly that a person needs to read this caption.
    if DEVANAGARI.search(text) and class_hits and achievement:
        flags.append(
            "is a Hindi caption celebrating an achievement alongside a class "
            "reference, so it probably names an individual child. Read it "
            "and confirm - the name matcher only reads Latin script")

    if any(w in lowered for w in MEDICAL_WORDS):
        flags.append(
            "may reference a health or disability characteristic of a child, "
            "which needs separate consideration before publication")

    if any(w in lowered for w in LOCATION_WORDS) and (names or class_hits):
        flags.append(
            "combines a child reference with a location detail")

    return sorted(set(flags)), sorted(set(identifiers))


def _risk_of(post: SocialPost) -> str:
    serious = [f for f in post.flags if (
        "identifies and locates" in f or "identifier" in f)]
    if serious:
        return "high"
    if post.is_promoted and post.flags:
        return "high"
    if post.flags:
        return "medium"
    if post.has_people:
        return "medium"
    return "low"


def analyse(posts: list[SocialPost]) -> list[SocialPost]:
    for post in posts:
        post.flags, post.identifiers_found = analyse_caption(post.caption)
        if post.is_promoted and (post.flags or post.has_people):
            post.flags.append(
                "is a paid or boosted post featuring children, which moves it "
                "towards the targeted-advertising prohibition in s.9(3)")
        post.risk = _risk_of(post)
    return posts


# --------------------------------------------------------------------------
# Route 1 - the school's own connected pages
# --------------------------------------------------------------------------

GRAPH_BASE = "https://graph.facebook.com/v21.0"


def fetch_connected_pages(page_id: str, token: str | None = None,
                          limit: int = 50,
                          settings: Settings | None = None) -> SocialReview:
    """
    Read the school's OWN Facebook or Instagram page posts.

    The token belongs to the school and authorises only its own pages. It is
    read from the environment so it is never written into the project, the
    config file or the evidence store. Nothing outside the school's own pages
    is requested.
    """
    settings = settings or Settings()
    review = SocialReview(
        reviewed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        source="connected")
    token = token or os.environ.get("SURAKSHASCAN_META_TOKEN")
    if not token:
        review.source = "none"
        review.errors.append(
            "No page token was available, so the connected route did not run. "
            "The school sets SURAKSHASCAN_META_TOKEN with a token for its own "
            "page, or supplies an export file instead.")
        return review

    try:
        import requests
        response = requests.get(
            f"{GRAPH_BASE}/{page_id}/posts",
            params={"fields": "id,message,created_time,permalink_url,"
                              "is_eligible_for_promotion,attachments{media_type}",
                    "limit": min(limit, 100), "access_token": token},
            timeout=settings.request_timeout)
        payload = response.json()
    except Exception as exc:
        review.errors.append(f"{type(exc).__name__}: {exc}")
        return review

    if "error" in payload:
        review.errors.append(
            "The platform refused the request: "
            f"{payload['error'].get('message', 'no message given')}")
        return review

    posts = []
    for item in payload.get("data", [])[:limit]:
        attachments = (item.get("attachments") or {}).get("data") or []
        posts.append(SocialPost(
            platform="facebook",
            post_id=str(item.get("id", "")),
            url=item.get("permalink_url", ""),
            posted_at=item.get("created_time", ""),
            caption=item.get("message", "") or "",
            media_count=len(attachments),
            has_people=None,
            source="connected"))
    review.handles = [{"platform": "facebook", "page_id": page_id}]
    review.posts = [p.to_dict() for p in analyse(posts)]
    review.coverage_note = (
        f"The {len(posts)} most recent posts on the school's own page were "
        "read through the platform's official interface. Older posts, other "
        "handles, and posts made from staff personal accounts were not "
        "covered.")
    return _count(review)


# --------------------------------------------------------------------------
# Route 2 - an export file the school downloaded from the platform
# --------------------------------------------------------------------------

def load_export(path, platform: str = "other") -> SocialReview:
    """
    Read a posts export. Accepts the JSON the platforms produce, or a simple
    CSV with columns: url, posted_at, caption, media_count, promoted.
    """
    path = Path(path)
    review = SocialReview(
        reviewed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        source="export")
    if not path.exists():
        review.errors.append(f"file not found: {path}")
        return review

    posts: list[SocialPost] = []
    try:
        if path.suffix.lower() == ".csv":
            import csv
            with path.open(encoding="utf-8-sig", newline="") as handle:
                for row in csv.DictReader(handle):
                    lowered = {(k or "").strip().lower(): (v or "")
                               for k, v in row.items()}
                    posts.append(SocialPost(
                        platform=lowered.get("platform", platform) or platform,
                        url=lowered.get("url", ""),
                        posted_at=lowered.get("posted_at",
                                              lowered.get("date", "")),
                        caption=lowered.get("caption",
                                            lowered.get("message", "")),
                        media_count=int(lowered.get("media_count") or 0),
                        is_promoted=str(lowered.get("promoted", "")).strip()
                        .lower() in ("yes", "true", "1"),
                        source="export"))
        else:
            data = json.loads(path.read_text(encoding="utf-8"))
            items = data if isinstance(data, list) else data.get("data", [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                posts.append(SocialPost(
                    platform=item.get("platform", platform) or platform,
                    post_id=str(item.get("id", "")),
                    url=item.get("permalink_url", item.get("url", "")),
                    posted_at=item.get("created_time",
                                       item.get("timestamp", "")),
                    caption=(item.get("message") or item.get("caption")
                             or item.get("text") or ""),
                    media_count=len(item.get("media", []) or []),
                    source="export"))
    except Exception as exc:
        review.errors.append(f"{type(exc).__name__}: {exc}")
        return review

    review.posts = [p.to_dict() for p in analyse(posts)]
    review.coverage_note = (
        f"{len(posts)} post(s) were read from an export the school supplied "
        f"({path.name}). Coverage is whatever the export contained.")
    return _count(review)


# --------------------------------------------------------------------------
# Route 3 - screenshots, read by the vision module
# --------------------------------------------------------------------------

def review_screenshots(paths, platform: str = "other",
                       settings: Settings | None = None) -> SocialReview:
    """Read post screenshots through vision.py and analyse their captions."""
    from . import vision
    review = SocialReview(
        reviewed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        source="manual")
    documents = vision.review_documents(list(paths), settings)
    posts: list[SocialPost] = []
    for document in documents:
        if document.error:
            review.errors.append(f"{document.file_name}: {document.error}")
            continue
        posts.append(SocialPost(
            platform=platform, url=document.file_name,
            posted_at=document.extracted_at, caption=document.text,
            media_count=1, has_people=None, source="manual"))
    review.posts = [p.to_dict() for p in analyse(posts)]
    review.coverage_note = (
        f"{len(posts)} screenshot(s) were reviewed. This is a sample chosen "
        "by the reviewer, not a complete picture of the school's feed, and "
        "the findings should be read that way.")
    return _count(review)


def _count(review: SocialReview) -> SocialReview:
    posts = review.posts
    review.counts = {
        "posts": len(posts),
        "high_risk": sum(1 for p in posts if p["risk"] == "high"),
        "medium_risk": sum(1 for p in posts if p["risk"] == "medium"),
        "names_with_class": sum(
            1 for p in posts
            if any("identifies and locates" in f for f in p["flags"])),
        "identifiers": sum(
            1 for p in posts
            if any("identifier" in f for f in p["flags"])),
        "promoted": sum(1 for p in posts if p["is_promoted"]),
    }
    return review


def empty() -> SocialReview:
    return SocialReview(
        reviewed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        source="none",
        coverage_note=(
            "The school's social media was not reviewed. This is usually the "
            "largest publication surface for children's photographs, and a "
            "website scan does not reach it."))
