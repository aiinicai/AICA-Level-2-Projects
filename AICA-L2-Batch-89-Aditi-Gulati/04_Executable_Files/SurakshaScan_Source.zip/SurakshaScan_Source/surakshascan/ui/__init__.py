"""Desktop interface."""
