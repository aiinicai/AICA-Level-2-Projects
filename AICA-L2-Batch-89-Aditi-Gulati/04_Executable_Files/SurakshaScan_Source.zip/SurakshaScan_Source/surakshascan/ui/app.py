"""
SurakshaScan desktop application.

Tabbed, themed, and built on the audit working-paper pattern from Day 4:

    Scan          set up and run the review
    Working paper five tabs of internal-practices lines with status and reviewer
    Findings      every obligation, its rating and its evidence
    Two views     the institution's case and the Board's case, side by side
    Documents     admission forms, consent slips and signage, read by vision
    Reports       Word, Excel and HTML output, and the scan history

The long-running scan is done on a worker thread so the window stays alive,
and the UI is only ever touched from the main thread through a queue.
"""

from __future__ import annotations

import queue
import threading
import webbrowser
from datetime import date, datetime
from pathlib import Path
from tkinter import (
    BOTH, END, LEFT, RIGHT, W, X, Y, BooleanVar, StringVar, Tk, Text,
    filedialog, messagebox, ttk,
)

from .. import evidence, report_docx, report_html, report_xlsx, scoring
from ..authorisation import Authorisation, AuthorisationError
from ..config import CONFIG_DIR, Settings
from ..dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from ..engine import run_review
from ..resources import icon_path, output_root
from ..questionnaire import (
    ANSWERS, CONFIDENCE, QUESTIONS, STATUSES, STATUS_COMPLETED, TABS,
    blank_responses, completion_stats, finalise, validate,
)

INK = "#1F3B57"
TEAL = "#2E7D8F"
BG = "#F2F5F7"
CARD = "#FFFFFF"
MUTED = "#5A6B78"
STATUS_WORDS = {MET: "Met", PARTIAL: "Partly met", GAP: "Gap",
                NOT_ASSESSED: "Not assessed"}
ROW_TAGS = {MET: "met", PARTIAL: "partial", GAP: "gap", NOT_ASSESSED: "na"}


class SurakshaScanApp:
    def __init__(self, root: Tk):
        self.root = root
        self.settings = Settings.load()
        self.responses = blank_responses()
        self.review = None
        self.document_paths: list[str] = []
        self.social_screenshots: list[str] = []
        self.system_exports: list[str] = []
        self.messages: queue.Queue = queue.Queue()
        self._log_lines = 0

        root.title("SurakshaScan — DPDP Readiness Scanner for Educational "
                   "Institutions")
        root.geometry("1120x760")
        root.minsize(940, 640)
        root.configure(bg=BG)
        self._set_icon()
        self._style()
        self._header()

        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill=BOTH, expand=True, padx=14, pady=(0, 6))
        self._tab_scan()
        self._tab_working_paper()
        self._tab_findings()
        self._tab_perspectives()
        self._tab_documents()
        self._tab_social()
        self._tab_systems()
        self._tab_reports()
        self._statusbar()
        self._install_paste_binding()
        self.root.after(120, self._drain)

    # --------------------------------------------------------------- chrome
    def _set_icon(self):
        icon = icon_path()
        if icon is None:
            return
        try:
            self.root.iconbitmap(str(icon))
        except Exception:
            # Tk on macOS and some Linux builds rejects .ico. Not worth
            # failing to open the application over a missing icon.
            pass

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=BG, foreground=INK,
                        font=("Segoe UI", 10))
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9),
                        font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", CARD), ("!selected", "#DFE6EA")],
                  foreground=[("selected", INK), ("!selected", MUTED)])
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD, relief="flat")
        style.configure("TLabel", background=BG, foreground=INK)
        style.configure("Card.TLabel", background=CARD, foreground=INK)
        style.configure("Muted.TLabel", background=BG, foreground=MUTED,
                        font=("Segoe UI", 9))
        style.configure("CardMuted.TLabel", background=CARD, foreground=MUTED,
                        font=("Segoe UI", 9))
        style.configure("H2.TLabel", background=BG, foreground=INK,
                        font=("Segoe UI", 12, "bold"))
        style.configure("Accent.TButton", background=TEAL, foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=(16, 8),
                        borderwidth=0)
        style.map("Accent.TButton",
                  background=[("active", INK), ("disabled", "#B9C6CD")])
        style.configure("TButton", padding=(12, 6))
        style.configure("Treeview", rowheight=26, fieldbackground=CARD,
                        background=CARD)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"),
                        background=INK, foreground="white")
        style.configure("Drop.TLabel", background="#E7EEF2", foreground=MUTED,
                        font=("Segoe UI", 10), relief="solid", borderwidth=1)

    def _header(self):
        bar = ttk.Frame(self.root)
        bar.pack(fill=X, padx=14, pady=(14, 10))
        left = ttk.Frame(bar)
        left.pack(side=LEFT)
        ttk.Label(left, text="SurakshaScan",
                  font=("Segoe UI", 20, "bold")).pack(anchor=W)
        ttk.Label(left, style="Muted.TLabel",
                  text="DPDP readiness for schools · Act 2023 and Rules 2025 · "
                       "Powered by Aditi").pack(anchor=W)
        right = ttk.Frame(bar)
        right.pack(side=RIGHT)
        self.score_label = ttk.Label(right, text="—",
                                     font=("Segoe UI", 30, "bold"))
        self.score_label.pack(anchor="e")
        self.band_label = ttk.Label(right, style="Muted.TLabel",
                                    text="no scan yet")
        self.band_label.pack(anchor="e")

    def _statusbar(self):
        bar = ttk.Frame(self.root)
        bar.pack(fill=X, padx=14, pady=(0, 10))
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=180)
        self.progress.pack(side=LEFT)
        self.status = ttk.Label(bar, style="Muted.TLabel", text="Ready.")
        self.status.pack(side=LEFT, padx=10)

    def _say(self, message: str):
        self.messages.put(("status", message))

    def _drain(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "status":
                    self.status.configure(text=payload)
                    self._log_lines += 1
                    self.log.configure(state="normal")
                    self.log.insert(END, f"{self._log_lines:>3}  {payload}\n")
                    self.log.see(END)
                    self.log.configure(state="disabled")
                    self.log_hint.configure(
                        text=f"{self._log_lines} step(s) — latest at the "
                             "bottom")
                elif kind == "done":
                    self._scan_finished(payload)
                elif kind == "error":
                    self.progress.stop()
                    self.scan_button.configure(state="normal")
                    self.status.configure(text="Scan failed.")
                    messagebox.showerror("Scan failed", payload)
        except queue.Empty:
            pass
        self.root.after(120, self._drain)

    # ------------------------------------------------------------ scan tab
    def _tab_scan(self):
        """
        Laid out so the Activity log always gets the leftover height.

        The inputs are compact and fixed; the log expands. On a short screen
        the log shrinks last rather than first, because watching the scan run
        is the whole point of this tab while a review is in progress.
        """
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Scan  ")

        top = ttk.Frame(frame)
        top.pack(fill=X)

        card = ttk.Frame(top, style="Card.TFrame", padding=14)
        card.pack(fill=X)
        ttk.Label(card, text="Institution", style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=4, sticky=W, pady=(0, 8))
        self.name_var = StringVar()
        self.url_var = StringVar(value="https://")
        self.extra_var = StringVar()
        self.reviewer_var = StringVar()
        self.ai_var = BooleanVar(value=False)

        # Two fields per row keeps the card half the height it used to be.
        pairs = (
            (("Institution name", self.name_var, 32),
             ("Reviewer name", self.reviewer_var, 26)),
            (("Website URL", self.url_var, 32),
             ("Extra pages (comma separated)", self.extra_var, 26)),
        )
        for row, pair in enumerate(pairs, start=1):
            for half, (label, var, width) in enumerate(pair):
                ttk.Label(card, text=label, style="Card.TLabel").grid(
                    row=row, column=half * 2, sticky=W,
                    padx=(0 if not half else 18, 8), pady=4)
                ttk.Entry(card, textvariable=var, width=width).grid(
                    row=row, column=half * 2 + 1, sticky=W, pady=4)

        ttk.Checkbutton(
            card, variable=self.ai_var,
            text="Also run the AI policy analysis (needs an API key; it never "
                 "changes the score)").grid(
            row=3, column=0, columnspan=4, sticky=W, pady=(10, 0))

        # ---- Who authorised this review.
        auth = ttk.Frame(top, style="Card.TFrame", padding=14)
        auth.pack(fill=X, pady=(10, 0))
        self.auth_by_var = StringVar()
        ttk.Label(auth, text="Authorised by", style="Card.TLabel",
                  font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky=W, padx=(0, 10))
        ttk.Entry(auth, textvariable=self.auth_by_var, width=48).grid(
            row=0, column=1, sticky=W)
        ttk.Label(auth, style="CardMuted.TLabel",
                  text="name and designation, e.g. Sr. Anne, Principal").grid(
            row=0, column=2, sticky=W, padx=(10, 0))

        social = ttk.Frame(top, style="Card.TFrame", padding=14)
        social.pack(fill=X, pady=(10, 0))
        ttk.Label(social, text="Social media and core systems (optional)",
                  style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=3, sticky=W, pady=(0, 8))
        self.social_page_var = StringVar()
        self.social_export_var = StringVar()
        ttk.Label(social, text="The school's own page id",
                  style="Card.TLabel").grid(row=1, column=0, sticky=W,
                                            padx=(0, 8), pady=4)
        ttk.Entry(social, textvariable=self.social_page_var, width=30).grid(
            row=1, column=1, sticky=W, pady=4)
        ttk.Label(social, style="CardMuted.TLabel",
                  text="a numeric id or page name — not a full URL").grid(
            row=1, column=2, sticky=W, padx=(10, 0))
        ttk.Label(social, text="or an export the school downloaded",
                  style="Card.TLabel").grid(row=2, column=0, sticky=W,
                                            padx=(0, 8), pady=4)
        export_row = ttk.Frame(social, style="Card.TFrame")
        export_row.grid(row=2, column=1, columnspan=2, sticky=W, pady=4)
        ttk.Entry(export_row, textvariable=self.social_export_var,
                  width=30).pack(side=LEFT)
        ttk.Button(export_row, text="Browse…",
                   command=self.pick_social_export).pack(side=LEFT, padx=6)
        ttk.Label(
            social, style="CardMuted.TLabel", justify=LEFT, wraplength=780,
            text="Never scrapes social media — only the school's own posts. "
                 "Add ERP, fee or learning-platform exports on the Core "
                 "systems tab, and post screenshots on the Social tab."
        ).grid(row=3, column=0, columnspan=3, sticky=W, pady=(8, 0))

        buttons = ttk.Frame(top)
        buttons.pack(fill=X, pady=10)
        self.scan_button = ttk.Button(buttons, text="Run the review",
                                      style="Accent.TButton",
                                      command=self.start_scan)
        self.scan_button.pack(side=LEFT)
        ttk.Button(buttons, text="Load a previous scan",
                   command=self.load_history).pack(side=LEFT, padx=8)
        ttk.Label(
            buttons, style="Muted.TLabel", justify=LEFT, wraplength=540,
            text="Scan only a site you are authorised to scan. Reads "
                 "robots.txt, rate-limits itself, public pages only, never "
                 "logs in.").pack(side=LEFT, padx=(18, 0))

        # Everything below this point takes the remaining height.
        log_header = ttk.Frame(frame)
        log_header.pack(fill=X, pady=(6, 4))
        ttk.Label(log_header, text="Activity", style="H2.TLabel").pack(side=LEFT)
        self.log_hint = ttk.Label(log_header, style="Muted.TLabel", text="")
        self.log_hint.pack(side=RIGHT)

        log_holder = ttk.Frame(frame)
        log_holder.pack(fill=BOTH, expand=True)
        self.log = Text(log_holder, height=8, wrap="word", relief="flat",
                        bg=CARD, fg=INK, font=("Consolas", 9),
                        padx=12, pady=8)
        log_scroll = ttk.Scrollbar(log_holder, orient="vertical",
                                   command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.pack(side=LEFT, fill=BOTH, expand=True)
        log_scroll.pack(side=RIGHT, fill=Y)
        self.log.tag_configure("step", foreground=INK)
        self.log.configure(state="disabled")

    # --------------------------------------------------- working paper tab
    def _tab_working_paper(self):
        outer = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(outer, text="  Working paper  ")
        ttk.Label(outer, style="Muted.TLabel", justify=LEFT,
                  text="What a website scan cannot see. A line cannot be marked "
                       "Completed without a reviewer name. Where a line is "
                       "Completed with no remark, a neutral remark recording "
                       "what was inspected is written for you.").pack(
            anchor=W, pady=(0, 10))

        inner = ttk.Notebook(outer)
        inner.pack(fill=BOTH, expand=True)
        self.wp_widgets: dict[str, dict] = {}

        for tab in TABS:
            page = ttk.Frame(inner, padding=10)
            inner.add(page, text=tab)
            canvas_frame = ttk.Frame(page)
            canvas_frame.pack(fill=BOTH, expand=True)
            tree = ttk.Treeview(
                canvas_frame,
                columns=("ref", "question", "answer", "status", "reviewer",
                         "confidence"),
                show="headings", height=11)
            for column, heading, width in (
                    ("ref", "Ref", 52), ("question", "Question", 430),
                    ("answer", "Answer", 80), ("status", "Status", 100),
                    ("reviewer", "Reviewer", 120),
                    ("confidence", "Confidence", 120)):
                tree.heading(column, text=heading)
                tree.column(column, width=width,
                            anchor=W if column == "question" else "center")
            scroll = ttk.Scrollbar(canvas_frame, orient="vertical",
                                   command=tree.yview)
            tree.configure(yscrollcommand=scroll.set)
            tree.pack(side=LEFT, fill=BOTH, expand=True)
            scroll.pack(side=RIGHT, fill=Y)

            for question in (q for q in QUESTIONS if q.tab == tab):
                tree.insert("", END, iid=question.id,
                            values=(question.id, question.text, "unknown",
                                    "Pending", "", "not verified"))

            editor = ttk.Frame(page, style="Card.TFrame", padding=12)
            editor.pack(fill=X, pady=(10, 0))
            answer_var = StringVar(value="unknown")
            status_var = StringVar(value="Pending")
            conf_var = StringVar(value="not verified")
            remark_var = StringVar()
            for column, (label, var, values, width) in enumerate((
                    ("Answer", answer_var, ANSWERS, 10),
                    ("Status", status_var, STATUSES, 13),
                    ("Confidence", conf_var, CONFIDENCE, 16))):
                ttk.Label(editor, text=label, style="Card.TLabel").grid(
                    row=0, column=column * 2, sticky=W, padx=(0 if not column else 14, 6))
                ttk.Combobox(editor, textvariable=var, values=list(values),
                             width=width, state="readonly").grid(
                    row=0, column=column * 2 + 1, sticky=W)
            ttk.Label(editor, text="Remark", style="Card.TLabel").grid(
                row=1, column=0, sticky=W, pady=(10, 0))
            ttk.Entry(editor, textvariable=remark_var, width=74).grid(
                row=1, column=1, columnspan=4, sticky=W, pady=(10, 0))
            ttk.Button(editor, text="Save line", style="Accent.TButton",
                       command=lambda t=tab: self.save_line(t)).grid(
                row=1, column=5, padx=(14, 0), pady=(10, 0))

            self.wp_widgets[tab] = {
                "tree": tree, "answer": answer_var, "status": status_var,
                "confidence": conf_var, "remark": remark_var,
            }
            tree.bind("<<TreeviewSelect>>",
                      lambda _event, t=tab: self.load_line(t))

        footer = ttk.Frame(outer)
        footer.pack(fill=X, pady=(10, 0))
        self.wp_summary = ttk.Label(footer, style="Muted.TLabel",
                                    text="0 of 24 lines completed.")
        self.wp_summary.pack(side=LEFT)
        ttk.Button(footer, text="Re-score with the working paper",
                   command=self.rescore).pack(side=RIGHT)

    def load_line(self, tab: str):
        widgets = self.wp_widgets[tab]
        selection = widgets["tree"].selection()
        if not selection:
            return
        response = self.responses[selection[0]]
        widgets["answer"].set(response.answer)
        widgets["status"].set(response.status)
        widgets["confidence"].set(response.confidence)
        widgets["remark"].set(response.remark)

    def save_line(self, tab: str):
        widgets = self.wp_widgets[tab]
        selection = widgets["tree"].selection()
        if not selection:
            messagebox.showinfo("Select a line",
                                "Choose a line in the table above first.")
            return
        question_id = selection[0]
        question = next(q for q in QUESTIONS if q.id == question_id)
        response = self.responses[question_id]
        response.answer = widgets["answer"].get()
        response.status = widgets["status"].get()
        response.confidence = widgets["confidence"].get()
        response.remark = widgets["remark"].get()
        response.reviewer = self.reviewer_var.get().strip()

        errors = validate(response, question)
        if errors:
            messagebox.showwarning(
                "This line is not complete",
                "\n".join("• " + e for e in errors))
            return
        finalise(response, question)
        widgets["tree"].item(question_id, values=(
            question.id, question.text, response.answer, response.status,
            response.reviewer, response.confidence))
        widgets["remark"].set(response.remark)
        stats = completion_stats(self.responses)
        self.wp_summary.configure(
            text=f"{stats['by_status'][STATUS_COMPLETED]} of {stats['total']} "
                 f"lines completed ({stats['percent_complete']:.0f}% of "
                 f"assessable lines).")

    # -------------------------------------------------------- findings tab
    def _tab_findings(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Findings  ")
        holder = ttk.Frame(frame)
        holder.pack(fill=BOTH, expand=True)
        self.findings_tree = ttk.Treeview(
            holder,
            columns=("ref", "domain", "obligation", "provision", "status",
                     "basis"),
            show="headings")
        for column, heading, width in (
                ("ref", "Ref", 50), ("domain", "Domain", 150),
                ("obligation", "Obligation", 330),
                ("provision", "Provision", 170), ("status", "Status", 95),
                ("basis", "Why", 300)):
            self.findings_tree.heading(column, text=heading)
            self.findings_tree.column(
                column, width=width,
                anchor=W if column in ("obligation", "basis", "domain") else "center")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.findings_tree.yview)
        self.findings_tree.configure(yscrollcommand=scroll.set)
        self.findings_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)
        self.findings_tree.tag_configure("met", background="#E8F4EE")
        self.findings_tree.tag_configure("partial", background="#FDF4E0")
        self.findings_tree.tag_configure("gap", background="#FAE6E2")
        self.findings_tree.tag_configure("na", background="#F1F4F5")

        self.finding_detail = Text(frame, height=8, wrap="word", relief="flat",
                                   bg=CARD, fg=INK, padx=12, pady=10,
                                   font=("Segoe UI", 9))
        self.finding_detail.pack(fill=X, pady=(12, 0))
        self.finding_detail.configure(state="disabled")
        self.findings_tree.bind("<<TreeviewSelect>>", self.show_finding)

    def show_finding(self, _event=None):
        selection = self.findings_tree.selection()
        if not selection or not self.review:
            return
        finding = next((f for f in self.review.findings
                        if f.obligation_id == selection[0]), None)
        if finding is None:
            return
        lines = [
            f"{finding.obligation_id} — {finding.title}",
            f"{finding.provision} ({finding.provision_status}) · weight "
            f"{finding.weight} · confidence {finding.confidence} · decided by "
            f"{finding.decided_by}",
            "",
            finding.rationale, "",
        ]
        if finding.evidence:
            lines.append("Evidence:")
            lines += [f"  • {str(e)[:300]}" for e in finding.evidence[:6]]
            lines.append("")
        lines += ["Remediation:", f"  {finding.remediation}",
                  f"  Effort: {finding.effort}"]
        if finding.school_note:
            lines += ["", "Note for schools:", "  " + finding.school_note]
        self.finding_detail.configure(state="normal")
        self.finding_detail.delete("1.0", END)
        self.finding_detail.insert(END, "\n".join(lines))
        self.finding_detail.configure(state="disabled")

    # ---------------------------------------------------- perspectives tab
    def _tab_perspectives(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Two views  ")
        ttk.Label(frame, style="Muted.TLabel", justify=LEFT,
                  text="The same facts, read two ways. The panels differ "
                       "because the perspective differs, not because the facts "
                       "changed.").pack(anchor=W, pady=(0, 10))
        self.perspective_text = Text(frame, wrap="word", relief="flat",
                                     bg=CARD, fg=INK, padx=16, pady=14,
                                     font=("Segoe UI", 10))
        self.perspective_text.pack(fill=BOTH, expand=True)
        self.perspective_text.tag_configure(
            "h", font=("Segoe UI", 11, "bold"), foreground=INK,
            spacing1=12, spacing3=4)
        self.perspective_text.tag_configure(
            "sub", font=("Segoe UI", 9), foreground=MUTED, spacing3=6)
        self.perspective_text.tag_configure(
            "panel", font=("Segoe UI", 9, "bold"), foreground=TEAL,
            spacing1=6)
        self.perspective_text.configure(state="disabled")

    # ------------------------------------------------------ documents tab
    def _tab_documents(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Documents  ")
        ttk.Label(frame, style="Muted.TLabel", justify=LEFT,
                  text="Add the admission form, the consent slip, the CCTV "
                       "signage photograph or the transport app screenshot. "
                       "PDFs are read offline with PyMuPDF; images are read by "
                       "the vision model when a key is available.").pack(
            anchor=W, pady=(0, 10))
        buttons = ttk.Frame(frame)
        buttons.pack(fill=X, pady=(0, 10))
        ttk.Button(buttons, text="Add documents…",
                   command=self.add_documents).pack(side=LEFT)
        ttk.Button(buttons, text="Clear",
                   command=self.clear_documents).pack(side=LEFT, padx=8)
        self.documents_list = Text(frame, wrap="word", relief="flat", bg=CARD,
                                   fg=INK, padx=12, pady=10,
                                   font=("Segoe UI", 9))
        self.documents_list.pack(fill=BOTH, expand=True)
        self.documents_list.configure(state="disabled")

    def add_documents(self):
        paths = filedialog.askopenfilenames(
            title="Choose supporting documents",
            filetypes=[("Documents and images",
                        "*.pdf *.png *.jpg *.jpeg *.webp"),
                       ("All files", "*.*")])
        self.document_paths.extend(paths)
        self._render_documents()

    def clear_documents(self):
        self.document_paths.clear()
        self._render_documents()

    def _render_documents(self):
        self.documents_list.configure(state="normal")
        self.documents_list.delete("1.0", END)
        if not self.document_paths:
            self.documents_list.insert(END, "No documents added.")
        for path in self.document_paths:
            self.documents_list.insert(END, f"• {Path(path).name}\n")
        if self.review and self.review.documents:
            self.documents_list.insert(END, "\nReviewed:\n")
            for document in self.review.documents:
                self.documents_list.insert(
                    END, f"\n{document.file_name} ({document.method})\n")
                if document.error:
                    self.documents_list.insert(END, f"   {document.error}\n")
                    continue
                for element in document.elements_absent:
                    self.documents_list.insert(END, f"   missing: {element}\n")
                for note in document.uncertainty:
                    self.documents_list.insert(END, f"   uncertainty: {note}\n")
        self.documents_list.configure(state="disabled")

    # -------------------------------------------------------- systems tab
    def _tab_systems(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Core systems  ")
        ttk.Label(
            frame, style="Muted.TLabel", justify=LEFT, wraplength=1000,
            text="The ERP, the fee software and the accounts are where the "
                 "school's personal data actually lives. Only the structure "
                 "of an export is read - its column headers and row counts. "
                 "No value from a student database is shown here, stored, or "
                 "written to the evidence file."
        ).pack(anchor=W, pady=(0, 10))

        buttons = ttk.Frame(frame)
        buttons.pack(fill=X, pady=(0, 10))
        ttk.Button(buttons, text="Add an ERP or fee export…",
                   command=self.add_system_export).pack(side=LEFT)
        ttk.Button(buttons, text="Clear",
                   command=self.clear_system_exports).pack(side=LEFT, padx=8)
        self.tally_var = BooleanVar(value=False)
        ttk.Checkbutton(
            buttons, variable=self.tally_var,
            text="Also read TallyPrime ledger masters (read-only, "
                 "localhost:9000)").pack(side=LEFT, padx=16)

        holder = ttk.Frame(frame)
        holder.pack(fill=BOTH, expand=True)
        self.systems_tree = ttk.Treeview(
            holder, columns=("system", "column", "category", "populated",
                             "why"), show="headings")
        for column, heading, width in (("system", "System", 150),
                                       ("column", "Column", 170),
                                       ("category", "Category", 160),
                                       ("populated", "Populated", 100),
                                       ("why", "Why it matters", 470)):
            self.systems_tree.heading(column, text=heading)
            self.systems_tree.column(
                column, width=width,
                anchor=W if column in ("why", "column", "system") else "center")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.systems_tree.yview)
        self.systems_tree.configure(yscrollcommand=scroll.set)
        self.systems_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)
        self.systems_tree.tag_configure("high", background="#FAE6E2")
        self.systems_tree.tag_configure("normal", background="#FFFFFF")

        self.systems_summary = ttk.Label(
            frame, style="Muted.TLabel", text="No export added yet.")
        self.systems_summary.pack(anchor=W, pady=(10, 0))

    def add_system_export(self):
        paths = filedialog.askopenfilenames(
            title="Choose an ERP or fee-software export",
            filetypes=[("Spreadsheets and CSV", "*.csv *.xlsx *.xlsm"),
                       ("All files", "*.*")])
        self.system_exports.extend(paths)
        self.systems_summary.configure(
            text=f"{len(self.system_exports)} export(s) queued. Run the "
                 "review to analyse their structure.")

    def clear_system_exports(self):
        self.system_exports.clear()
        self.systems_summary.configure(text="No export added.")

    def _render_systems(self):
        for row in self.systems_tree.get_children():
            self.systems_tree.delete(row)
        systems = getattr(self.review, "systems", None) if self.review else None
        if systems is None or not systems.assessed:
            self.systems_summary.configure(
                text="Core systems were not reviewed for this run. Add an "
                     "export, or tick the TallyPrime box.")
            return
        from ..systems import HIGH_HARM
        index = 0
        for system in systems.systems:
            for finding in system["findings"]:
                tag = "high" if finding["category"] in HIGH_HARM else "normal"
                self.systems_tree.insert(
                    "", END, iid=str(index), tags=(tag,),
                    values=(system["system_name"], finding["column"],
                            finding["category"],
                            f"{finding['populated']}/{finding['total']}",
                            finding["why"]))
                index += 1
        counts = systems.counts
        summary = (f"{counts['systems_reviewed']} export(s) · "
                   f"{counts['rows']} rows · {counts['categories']} "
                   f"categories · {counts['stale_records']} stale record(s)")
        if counts["high_harm_categories"]:
            summary += " · high harm: " + ", ".join(
                counts["high_harm_categories"])
        if counts["tally_ledgers"]:
            summary += (f" · Tally: {counts['tally_ledgers']} ledgers, "
                        f"{counts['tally_party_ledgers']} party/staff")
        self.systems_summary.configure(text=summary)

    # --------------------------------------------------------- social tab
    def _tab_social(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Social  ")
        self._social_tab_index = self.tabs.index("end") - 1
        ttk.Label(
            frame, style="Muted.TLabel", justify=LEFT, wraplength=1000,
            text="For most schools this is where children's photographs are "
                 "actually published, and a website scan does not reach it. "
                 "The Fourth Schedule exemption covers academic activity and "
                 "student safety - not a promotional post - so section 9(1) "
                 "applies in full."
        ).pack(anchor=W, pady=(0, 10))

        buttons = ttk.Frame(frame)
        buttons.pack(fill=X, pady=(0, 8))
        ttk.Button(buttons, text="Add post screenshots…",
                   command=self.add_social_screenshots).pack(side=LEFT)
        ttk.Button(buttons, text="Paste screenshot  (Ctrl+V)",
                   style="Accent.TButton",
                   command=self.paste_social_screenshot).pack(side=LEFT,
                                                              padx=8)
        ttk.Button(buttons, text="Clear",
                   command=self.clear_social_screenshots).pack(side=LEFT)

        # A visible target, so drag-and-drop is discoverable rather than a
        # hidden trick, and so the same panel can say when it is unavailable.
        self.social_drop = ttk.Label(
            frame, style="Drop.TLabel", anchor="center", justify="center",
            text="Drop screenshots here, or press Ctrl+V to paste one")
        self.social_drop.pack(fill=X, ipady=18, pady=(0, 10))
        self.social_drop.bind("<Button-1>",
                              lambda _e: self.add_social_screenshots())
        dnd = self._enable_drop(self.social_drop) or self._enable_drop(frame)
        if not dnd:
            self.social_drop.configure(
                text="Press Ctrl+V to paste a screenshot, or click here to "
                     "browse.\nDrag-and-drop needs the tkinterdnd2 package "
                     "(pip install tkinterdnd2).")
        # The Ctrl+V binding lives on the application, not on this frame - a
        # ttk.Frame never receives keyboard focus, so a binding on it never
        # fires. See _install_paste_binding.

        holder = ttk.Frame(frame)
        holder.pack(fill=BOTH, expand=True)
        self.social_tree = ttk.Treeview(
            holder, columns=("risk", "posted", "found", "identifiers"),
            show="headings")
        for column, heading, width in (("risk", "Risk", 80),
                                       ("posted", "Posted", 120),
                                       ("found", "What was found", 560),
                                       ("identifiers", "Identifiers", 220)):
            self.social_tree.heading(column, text=heading)
            self.social_tree.column(
                column, width=width,
                anchor=W if column in ("found", "identifiers") else "center")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.social_tree.yview)
        self.social_tree.configure(yscrollcommand=scroll.set)
        self.social_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)
        self.social_tree.tag_configure("high", background="#FAE6E2")
        self.social_tree.tag_configure("medium", background="#FDF4E0")
        self.social_tree.tag_configure("low", background="#F1F4F5")

        self.social_summary = ttk.Label(
            frame, style="Muted.TLabel",
            text="No social media reviewed yet.")
        self.social_summary.pack(anchor=W, pady=(10, 0))

    def pick_social_export(self):
        path = filedialog.askopenfilename(
            title="Choose the posts export the school downloaded",
            filetypes=[("Export files", "*.json *.csv"), ("All files", "*.*")])
        if path:
            self.social_export_var.set(path)

    def _install_paste_binding(self):
        """
        Ctrl+V anywhere in the app pastes a screenshot - but only when the
        Social tab is open and the cursor is not in a text box, so ordinary
        pasting into the URL and name fields still behaves normally.
        """
        for sequence in ("<Control-v>", "<Control-V>"):
            try:
                self.root.bind_all(sequence, self._maybe_paste)
            except Exception:
                pass

    def _maybe_paste(self, event=None):
        try:
            if self.tabs.index("current") != self._social_tab_index:
                return None
        except Exception:
            return None
        # Never steal Ctrl+V from a field the person is typing in.
        try:
            focused = self.root.focus_get()
            if focused is not None and focused.winfo_class() in (
                    "Entry", "TEntry", "Text", "TCombobox", "Spinbox"):
                return None
        except Exception:
            pass
        self.paste_social_screenshot()
        return "break"

    def _enable_drop(self, widget) -> bool:
        """Wire drag-and-drop if tkinterdnd2 is installed; say so if not."""
        try:
            from tkinterdnd2 import DND_FILES
        except ImportError:
            return False
        try:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", self._on_drop)
            return True
        except Exception:
            # The package is present but the root window was not created as a
            # TkinterDnD root. Paste still works, so this is not fatal.
            return False

    @staticmethod
    def _split_dropped(data: str) -> list[str]:
        """
        Tk hands dropped paths over as one string, brace-quoting any path
        that contains a space: '{C:/My Folder/a.png} C:/b.png'.
        """
        paths, current, in_brace = [], "", False
        for char in data or "":
            if char == "{":
                in_brace, current = True, ""
            elif char == "}":
                in_brace = False
                if current.strip():
                    paths.append(current.strip())
                current = ""
            elif char == " " and not in_brace:
                if current.strip():
                    paths.append(current.strip())
                current = ""
            else:
                current += char
        if current.strip():
            paths.append(current.strip())
        return paths

    IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")

    def _on_drop(self, event):
        raw = getattr(event, "data", "") or ""
        entries = self._split_dropped(raw)
        images = [p for p in entries
                  if Path(p).suffix.lower() in self.IMAGE_SUFFIXES]
        ignored = len(entries) - len(images)

        if not images:
            # Say what actually arrived. A silent rejection is the worst
            # outcome, because there is no way to tell it apart from a drop
            # that never registered at all.
            if raw.strip().lower().startswith(("http://", "https://")):
                message = ("That was a link, not a file. Dragging an image "
                           "straight out of a browser passes its address "
                           "rather than the picture.\n\nSave the image "
                           "first, or snip it with Win+Shift+S and press "
                           "Ctrl+V here.")
            elif entries:
                message = ("Nothing dropped was an image file.\n\n"
                           "Received: " + ", ".join(entries[:3])[:300])
            else:
                message = ("The drop arrived but carried nothing this "
                           "application could read.\n\nRaw value: "
                           + raw[:200])
            messagebox.showinfo("Nothing to add", message)
            self.social_summary.configure(
                text="Last drop added nothing — see the message for what "
                     "arrived.")
            return

        self.social_screenshots.extend(images)
        self._note_screenshots(
            f"{len(images)} dropped"
            + (f", {ignored} ignored (not an image)" if ignored else ""))

    def paste_social_screenshot(self, event=None):
        """
        Take an image straight off the clipboard.

        This is how a reviewer actually works: Win+Shift+S to snip a post,
        then paste. Saving to a file first is a step that earns nothing.
        """
        try:
            from PIL import ImageGrab
        except ImportError:
            messagebox.showinfo(
                "Paste needs Pillow",
                "Install it with:  pip install pillow\n\n"
                "Until then, use Add post screenshots… to browse for a "
                "saved image.")
            return
        try:
            grabbed = ImageGrab.grabclipboard()
        except Exception as exc:
            messagebox.showwarning(
                "Could not read the clipboard",
                f"{type(exc).__name__}: {exc}")
            return

        if grabbed is None:
            self.social_summary.configure(
                text="Clipboard held no image when Ctrl+V was pressed.")
            messagebox.showinfo(
                "Nothing to paste",
                "The clipboard holds no image.\n\nOn Windows, press "
                "Win+Shift+S to snip the post, then come back and press "
                "Ctrl+V.")
            return

        # Copying image FILES in Explorer puts paths on the clipboard, not
        # pixels. Both are reasonable things for someone to do.
        if isinstance(grabbed, list):
            images = [p for p in grabbed if Path(str(p)).suffix.lower()
                      in (".png", ".jpg", ".jpeg", ".webp", ".gif")]
            if not images:
                messagebox.showinfo(
                    "Nothing to paste",
                    "The clipboard holds files, but none of them is an image.")
                return
            self.social_screenshots.extend(str(p) for p in images)
            self._note_screenshots(f"{len(images)} pasted from files")
            return

        folder = CONFIG_DIR / "pasted"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"pasted_{datetime.now():%Y%m%d_%H%M%S_%f}.png"
        try:
            grabbed.save(path, "PNG")
        except Exception as exc:
            messagebox.showwarning(
                "Could not save the pasted image",
                f"{type(exc).__name__}: {exc}")
            return
        self.social_screenshots.append(str(path))
        self._note_screenshots("1 pasted from the clipboard")

    def _note_screenshots(self, what: str):
        self.social_summary.configure(
            text=f"{what}. {len(self.social_screenshots)} screenshot(s) "
                 "queued — run the review to read them.")
        self.tabs.select(self._social_tab_index)

    def add_social_screenshots(self):
        paths = filedialog.askopenfilenames(
            title="Choose screenshots of the school's posts",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"),
                       ("All files", "*.*")])
        if not paths:
            return
        self.social_screenshots.extend(paths)
        self._note_screenshots(f"{len(paths)} added")

    def clear_social_screenshots(self):
        self.social_screenshots.clear()
        self.social_summary.configure(text="No screenshots queued.")

    def _render_social(self):
        for row in self.social_tree.get_children():
            self.social_tree.delete(row)
        social = getattr(self.review, "social", None) if self.review else None
        if social is None or not social.posts:
            self.social_summary.configure(
                text="Social media was not reviewed for this run. Add the "
                     "school's page id, an export file, or screenshots.")
            return
        for index, post in enumerate(social.posts):
            self.social_tree.insert(
                "", END, iid=str(index), tags=(post["risk"],),
                values=(post["risk"].title(),
                        (post.get("posted_at") or "")[:10],
                        "; ".join(post["flags"]) or "nothing flagged",
                        ", ".join(post["identifiers_found"][:4])))
        counts = social.counts
        self.social_summary.configure(
            text=f"{counts.get('posts', 0)} post(s) reviewed via "
                 f"{social.source} · {counts.get('high_risk', 0)} high risk · "
                 f"{counts.get('names_with_class', 0)} name a child with a "
                 f"class · {counts.get('promoted', 0)} boosted")

    # -------------------------------------------------------- reports tab
    def _tab_reports(self):
        frame = ttk.Frame(self.tabs, padding=18)
        self.tabs.add(frame, text="  Reports  ")
        card = ttk.Frame(frame, style="Card.TFrame", padding=18)
        card.pack(fill=X)
        ttk.Label(card, text="Export", style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 10))
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(anchor=W)
        self.docx_button = ttk.Button(row, text="Word report",
                                      style="Accent.TButton",
                                      command=self.save_docx, state="disabled")
        self.docx_button.pack(side=LEFT)
        self.xlsx_button = ttk.Button(row, text="Excel workbook",
                                      command=self.save_xlsx, state="disabled")
        self.xlsx_button.pack(side=LEFT, padx=8)
        self.html_button = ttk.Button(row, text="HTML dashboard",
                                      command=self.save_html, state="disabled")
        self.html_button.pack(side=LEFT)
        ttk.Label(card, style="CardMuted.TLabel",
                  text="Nothing is sent anywhere. Sharing a report is a "
                       "separate, deliberate step you take yourself.").pack(
            anchor=W, pady=(12, 0))

        ttk.Label(frame, text="Scan history", style="H2.TLabel").pack(
            anchor=W, pady=(18, 6))
        self.history_tree = ttk.Treeview(
            frame, columns=("when", "institution", "score", "band"),
            show="headings", height=9)
        for column, heading, width in (("when", "Written at", 200),
                                       ("institution", "Institution", 330),
                                       ("score", "Score", 90),
                                       ("band", "Band", 130)):
            self.history_tree.heading(column, text=heading)
            self.history_tree.column(column, width=width)
        self.history_tree.pack(fill=BOTH, expand=True)
        ttk.Button(frame, text="Refresh history",
                   command=self.refresh_history).pack(anchor=W, pady=8)
        self.refresh_history()

    def refresh_history(self):
        for row in self.history_tree.get_children():
            self.history_tree.delete(row)
        for record in evidence.history():
            self.history_tree.insert(
                "", END, values=(record["written_at"], record["institution"],
                                 record["score"], record["band"]))

    def load_history(self):
        path = filedialog.askopenfilename(
            title="Open a saved evidence file",
            filetypes=[("Evidence JSON", "*.json")])
        if not path:
            return
        try:
            record = evidence.load(path)
        except Exception as exc:
            messagebox.showerror("Could not open that file", str(exc))
            return
        assessment = (record.get("payload") or {}).get("assessment") or {}
        messagebox.showinfo(
            "Saved scan",
            f"{record.get('institution', '')}\n"
            f"Written {record.get('written_at', '')}\n"
            f"Score {assessment.get('score')} ({assessment.get('band')})\n\n"
            "Re-run the scan to load it into the tabs.")

    # -------------------------------------------------------------- actions
    def start_scan(self):
        name = self.name_var.get().strip()
        url = self.url_var.get().strip()
        if not name or url in ("", "https://"):
            messagebox.showwarning(
                "Missing information",
                "Enter both the institution name and the website address.")
            return
        extras = [u.strip() for u in self.extra_var.get().split(",") if u.strip()]

        authorisation = Authorisation(authorised_by=self.auth_by_var.get())
        problems = authorisation.problems()
        if problems:
            messagebox.showwarning(
                "Authorised by is empty",
                "Enter the name and designation of the person who "
                "authorised this review before running it.")
            return

        self.scan_button.configure(state="disabled")
        self.progress.start(12)
        self._log_lines = 0
        self.log.configure(state="normal")
        self.log.delete("1.0", END)
        self.log.configure(state="disabled")
        self.log_hint.configure(text="starting…")

        def work():
            try:
                review = run_review(
                    name, url, extras, responses=self.responses,
                    authorisation=authorisation,
                    document_paths=list(self.document_paths),
                    social_page_id=_page_id(self.social_page_var.get()),
                    social_export=self.social_export_var.get().strip() or None,
                    social_screenshots=list(self.social_screenshots) or None,
                    system_exports=list(self.system_exports) or None,
                    include_tally=self.tally_var.get(),
                    settings=self.settings, use_ai=self.ai_var.get(),
                    progress=self._say)
                self.messages.put(("done", review))
            except AuthorisationError as exc:
                self.messages.put(("error", str(exc)))
            except Exception as exc:  # surfaced to the user, not swallowed
                self.messages.put(("error", f"{type(exc).__name__}: {exc}"))

        threading.Thread(target=work, daemon=True).start()

    def rescore(self):
        if not self.review:
            messagebox.showinfo("Run a scan first",
                                "Re-scoring uses the website findings too.")
            return
        from ..questionnaire import to_answer_map
        from .. import rules_engine
        findings = rules_engine.assess(
            self.review.scan, to_answer_map(self.responses),
            social=getattr(self.review, "social", None),
            systems=getattr(self.review, "systems", None))
        self.review.findings = findings
        self.review.assessment = scoring.score_findings(
            self.review.scan.institution_name,
            self.review.scan.scanned_at, findings)
        self.review.working_paper_stats = completion_stats(self.responses)
        from .. import perspectives as perspectives_module
        self.review.perspectives = perspectives_module.build_perspectives(findings)
        self._render_review()
        self.status.configure(text="Re-scored with the working paper.")

    def _scan_finished(self, review):
        self.progress.stop()
        self.scan_button.configure(state="normal")
        self.review = review
        self._render_review()
        self._render_documents()
        self._render_social()
        self._render_systems()
        self.refresh_history()
        for button in (self.docx_button, self.xlsx_button, self.html_button):
            button.configure(state="normal")
        self.status.configure(
            text=f"Done. Evidence written to "
                 f"{Path(review.evidence_path).name if review.evidence_path else 'memory'}.")
        self.tabs.select(2)

    def _render_review(self):
        assessment = self.review.assessment
        self.score_label.configure(text=f"{assessment.score:.0f}")
        self.band_label.configure(
            text=f"{assessment.band} · {assessment.coverage_percent:.0f}% of the "
                 f"catalogue assessed")

        for row in self.findings_tree.get_children():
            self.findings_tree.delete(row)
        for finding in self.review.findings:
            self.findings_tree.insert(
                "", END, iid=finding.obligation_id,
                tags=(ROW_TAGS.get(finding.status, "na"),),
                values=(finding.obligation_id, finding.domain, finding.title,
                        f"{finding.provision}",
                        STATUS_WORDS.get(finding.status, finding.status),
                        finding.rationale[:160]))

        self.perspective_text.configure(state="normal")
        self.perspective_text.delete("1.0", END)
        if not self.review.perspectives:
            self.perspective_text.insert(
                END, "No contested findings — nothing to argue about.")
        for pair in self.review.perspectives:
            self.perspective_text.insert(
                END, f"{pair.obligation_id} — {pair.title}\n", "h")
            self.perspective_text.insert(
                END, f"{pair.provision} · residual risk: {pair.residual_risk}\n",
                "sub")
            self.perspective_text.insert(END, "The institution's position\n",
                                         "panel")
            self.perspective_text.insert(END, pair.institution_position + "\n")
            self.perspective_text.insert(
                END, "The parent's or the Board's position\n", "panel")
            self.perspective_text.insert(END, pair.regulator_position + "\n")
            self.perspective_text.insert(END, "What decides it\n", "panel")
            self.perspective_text.insert(END, pair.what_decides_it + "\n\n")
        self.perspective_text.configure(state="disabled")

    def _default_name(self, extension: str) -> str:
        stem = evidence.slugify(self.review.scan.institution_name)
        return f"{stem}_DPDP_Readiness_{date.today():%Y%m%d}{extension}"

    def _export(self, extension: str, description: str, writer):
        if not self.review:
            messagebox.showinfo("No scan yet", "Run a review first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=extension,
            initialdir=str(output_root()),
            initialfile=self._default_name(extension),
            filetypes=[(description, "*" + extension)],
            title="Save the report as…")
        if not path:
            return
        try:
            writer(path)
        except Exception as exc:
            messagebox.showerror("Could not save", f"{type(exc).__name__}: {exc}")
            return
        if messagebox.askyesno("Report saved",
                               f"Saved to:\n{path}\n\nOpen it now?"):
            webbrowser.open(Path(path).as_uri())

    def save_docx(self):
        self._export(".docx", "Word document",
                     lambda p: report_docx.generate(
                         self.review, p,
                         prepared_by=self.reviewer_var.get().strip()))

    def save_xlsx(self):
        def write(path):
            setattr(self.review, "_responses", self.responses)
            report_xlsx.generate(self.review, path)
        self._export(".xlsx", "Excel workbook", write)

    def save_html(self):
        self._export(".html", "HTML dashboard",
                     lambda p: report_html.generate(self.review, p))


def _page_id(value: str) -> str | None:
    """
    Accept what a person actually pastes.

    People paste the whole address bar, often URL-encoded. The platform wants
    the page id or its plain name, so pull that out rather than sending a
    URL and failing with an unhelpful error.
    """
    from urllib.parse import unquote, urlparse

    text = unquote((value or "").strip())
    if not text:
        return None
    if text.startswith(("http://", "https://", "www.", "facebook.com",
                        "instagram.com")):
        if not text.startswith(("http://", "https://")):
            text = "https://" + text
        path = urlparse(text).path.strip("/")
        parts = [p for p in path.split("/") if p and p not in ("p", "pages")]
        text = parts[-1] if parts else ""
    return text.strip() or None


def _make_root():
    """
    Build the main window.

    tkinterdnd2 replaces the root window class, which is what lets Tk accept
    files dragged from Explorer. It is optional: without it everything works
    except drag-and-drop, and the Social tab says so on its drop zone rather
    than leaving the person wondering why nothing happens.
    """
    try:
        from tkinterdnd2 import TkinterDnD
        return TkinterDnD.Tk()
    except Exception:
        return Tk()


def main():
    root = _make_root()
    SurakshaScanApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
