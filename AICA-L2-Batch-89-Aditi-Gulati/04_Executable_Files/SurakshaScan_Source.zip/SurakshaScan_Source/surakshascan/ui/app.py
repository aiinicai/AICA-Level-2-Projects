"""
SurakshaScan desktop application.

Tabbed, themed, and built on the audit working-paper pattern from Day 4:

    Scan          set up and run the review
    Working paper five tabs of internal-practices lines with status and reviewer
    Findings      every obligation, its rating and its evidence
    Two views     the institution's case and the Board's case, side by side
    Documents     admission forms, consent slips and signage, read by vision
    Reports       Word, Excel and HTML output, and the scan history

The long-running scan is done on a worker thread so the window stays alive,
and the UI is only ever touched from the main thread through a queue.
"""

from __future__ import annotations

import queue
import threading
import webbrowser
from datetime import date
from pathlib import Path
from tkinter import (
    BOTH, END, LEFT, RIGHT, W, X, Y, BooleanVar, StringVar, Tk, Text,
    filedialog, messagebox, ttk,
)

from .. import evidence, report_docx, report_html, report_xlsx, scoring
from ..authorisation import Authorisation, AuthorisationError
from ..config import Settings
from ..dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from ..engine import run_review
from ..resources import icon_path, output_root
from ..questionnaire import (
    ANSWERS, CONFIDENCE, QUESTIONS, STATUSES, STATUS_COMPLETED, TABS,
    blank_responses, completion_stats, finalise, validate,
)

INK = "#1F3B57"
TEAL = "#2E7D8F"
BG = "#F2F5F7"
CARD = "#FFFFFF"
MUTED = "#5A6B78"
STATUS_WORDS = {MET: "Met", PARTIAL: "Partly met", GAP: "Gap",
                NOT_ASSESSED: "Not assessed"}
ROW_TAGS = {MET: "met", PARTIAL: "partial", GAP: "gap", NOT_ASSESSED: "na"}


class SurakshaScanApp:
    def __init__(self, root: Tk):
        self.root = root
        self.settings = Settings.load()
        self.responses = blank_responses()
        self.review = None
        self.document_paths: list[str] = []
        self.messages: queue.Queue = queue.Queue()
        self._log_lines = 0

        root.title("SurakshaScan — DPDP Readiness Scanner for Educational "
                   "Institutions")
        root.geometry("1120x760")
        root.minsize(940, 640)
        root.configure(bg=BG)
        self._set_icon()
        self._style()
        self._header()

        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill=BOTH, expand=True, padx=14, pady=(0, 6))
        self._tab_scan()
        self._tab_working_paper()
        self._tab_findings()
        self._tab_perspectives()
        self._tab_documents()
        self._tab_reports()
        self._statusbar()
        self.root.after(120, self._drain)

    # --------------------------------------------------------------- chrome
    def _set_icon(self):
        icon = icon_path()
        if icon is None:
            return
        try:
            self.root.iconbitmap(str(icon))
        except Exception:
            # Tk on macOS and some Linux builds rejects .ico. Not worth
            # failing to open the application over a missing icon.
            pass

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=BG, foreground=INK,
                        font=("Segoe UI", 10))
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9),
                        font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", CARD), ("!selected", "#DFE6EA")],
                  foreground=[("selected", INK), ("!selected", MUTED)])
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD, relief="flat")
        style.configure("TLabel", background=BG, foreground=INK)
        style.configure("Card.TLabel", background=CARD, foreground=INK)
        style.configure("Muted.TLabel", background=BG, foreground=MUTED,
                        font=("Segoe UI", 9))
        style.configure("CardMuted.TLabel", background=CARD, foreground=MUTED,
                        font=("Segoe UI", 9))
        style.configure("H2.TLabel", background=BG, foreground=INK,
                        font=("Segoe UI", 12, "bold"))
        style.configure("Accent.TButton", background=TEAL, foreground="white",
                        font=("Segoe UI", 10, "bold"), padding=(16, 8),
                        borderwidth=0)
        style.map("Accent.TButton",
                  background=[("active", INK), ("disabled", "#B9C6CD")])
        style.configure("TButton", padding=(12, 6))
        style.configure("Treeview", rowheight=26, fieldbackground=CARD,
                        background=CARD)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"),
                        background=INK, foreground="white")

    def _header(self):
        bar = ttk.Frame(self.root)
        bar.pack(fill=X, padx=14, pady=(14, 10))
        left = ttk.Frame(bar)
        left.pack(side=LEFT)
        ttk.Label(left, text="SurakshaScan",
                  font=("Segoe UI", 20, "bold")).pack(anchor=W)
        ttk.Label(left, style="Muted.TLabel",
                  text="DPDP readiness for schools · Act 2023 and Rules 2025 · "
                       "Powered by Aditi").pack(anchor=W)
        right = ttk.Frame(bar)
        right.pack(side=RIGHT)
        self.score_label = ttk.Label(right, text="—",
                                     font=("Segoe UI", 30, "bold"))
        self.score_label.pack(anchor="e")
        self.band_label = ttk.Label(right, style="Muted.TLabel",
                                    text="no scan yet")
        self.band_label.pack(anchor="e")

    def _statusbar(self):
        bar = ttk.Frame(self.root)
        bar.pack(fill=X, padx=14, pady=(0, 10))
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=180)
        self.progress.pack(side=LEFT)
        self.status = ttk.Label(bar, style="Muted.TLabel", text="Ready.")
        self.status.pack(side=LEFT, padx=10)

    def _say(self, message: str):
        self.messages.put(("status", message))

    def _drain(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "status":
                    self.status.configure(text=payload)
                    self._log_lines += 1
                    self.log.configure(state="normal")
                    self.log.insert(END, f"{self._log_lines:>3}  {payload}\n")
                    self.log.see(END)
                    self.log.configure(state="disabled")
                    self.log_hint.configure(
                        text=f"{self._log_lines} step(s) — latest at the "
                             "bottom")
                elif kind == "done":
                    self._scan_finished(payload)
                elif kind == "error":
                    self.progress.stop()
                    self.scan_button.configure(state="normal")
                    self.status.configure(text="Scan failed.")
                    messagebox.showerror("Scan failed", payload)
        except queue.Empty:
            pass
        self.root.after(120, self._drain)

    # ------------------------------------------------------------ scan tab
    def _tab_scan(self):
        """
        Laid out so the Activity log always gets the leftover height.

        The inputs are compact and fixed; the log expands. On a short screen
        the log shrinks last rather than first, because watching the scan run
        is the whole point of this tab while a review is in progress.
        """
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Scan  ")

        top = ttk.Frame(frame)
        top.pack(fill=X)

        card = ttk.Frame(top, style="Card.TFrame", padding=14)
        card.pack(fill=X)
        ttk.Label(card, text="Institution", style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=4, sticky=W, pady=(0, 8))
        self.name_var = StringVar()
        self.url_var = StringVar(value="https://")
        self.extra_var = StringVar()
        self.reviewer_var = StringVar()
        self.ai_var = BooleanVar(value=False)

        # Two fields per row keeps the card half the height it used to be.
        pairs = (
            (("Institution name", self.name_var, 32),
             ("Reviewer name", self.reviewer_var, 26)),
            (("Website URL", self.url_var, 32),
             ("Extra pages (comma separated)", self.extra_var, 26)),
        )
        for row, pair in enumerate(pairs, start=1):
            for half, (label, var, width) in enumerate(pair):
                ttk.Label(card, text=label, style="Card.TLabel").grid(
                    row=row, column=half * 2, sticky=W,
                    padx=(0 if not half else 18, 8), pady=4)
                ttk.Entry(card, textvariable=var, width=width).grid(
                    row=row, column=half * 2 + 1, sticky=W, pady=4)

        ttk.Checkbutton(
            card, variable=self.ai_var,
            text="Also run the AI policy analysis (needs an API key; it never "
                 "changes the score)").grid(
            row=3, column=0, columnspan=4, sticky=W, pady=(10, 0))

        # ---- Who authorised this review.
        auth = ttk.Frame(top, style="Card.TFrame", padding=14)
        auth.pack(fill=X, pady=(10, 0))
        self.auth_by_var = StringVar()
        ttk.Label(auth, text="Authorised by", style="Card.TLabel",
                  font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky=W, padx=(0, 10))
        ttk.Entry(auth, textvariable=self.auth_by_var, width=48).grid(
            row=0, column=1, sticky=W)
        ttk.Label(auth, style="CardMuted.TLabel",
                  text="name and designation, e.g. Sr. Anne, Principal").grid(
            row=0, column=2, sticky=W, padx=(10, 0))

        buttons = ttk.Frame(top)
        buttons.pack(fill=X, pady=10)
        self.scan_button = ttk.Button(buttons, text="Run the review",
                                      style="Accent.TButton",
                                      command=self.start_scan)
        self.scan_button.pack(side=LEFT)
        ttk.Button(buttons, text="Load a previous scan",
                   command=self.load_history).pack(side=LEFT, padx=8)
        ttk.Label(
            buttons, style="Muted.TLabel", justify=LEFT, wraplength=540,
            text="Scan only a site you are authorised to scan. Reads "
                 "robots.txt, rate-limits itself, public pages only, never "
                 "logs in.").pack(side=LEFT, padx=(18, 0))

        # Everything below this point takes the remaining height.
        log_header = ttk.Frame(frame)
        log_header.pack(fill=X, pady=(6, 4))
        ttk.Label(log_header, text="Activity", style="H2.TLabel").pack(side=LEFT)
        self.log_hint = ttk.Label(log_header, style="Muted.TLabel", text="")
        self.log_hint.pack(side=RIGHT)

        log_holder = ttk.Frame(frame)
        log_holder.pack(fill=BOTH, expand=True)
        self.log = Text(log_holder, height=8, wrap="word", relief="flat",
                        bg=CARD, fg=INK, font=("Consolas", 9),
                        padx=12, pady=8)
        log_scroll = ttk.Scrollbar(log_holder, orient="vertical",
                                   command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.pack(side=LEFT, fill=BOTH, expand=True)
        log_scroll.pack(side=RIGHT, fill=Y)
        self.log.tag_configure("step", foreground=INK)
        self.log.configure(state="disabled")

    # --------------------------------------------------- working paper tab
    def _tab_working_paper(self):
        outer = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(outer, text="  Working paper  ")
        ttk.Label(outer, style="Muted.TLabel", justify=LEFT,
                  text="What a website scan cannot see. A line cannot be marked "
                       "Completed without a reviewer name. Where a line is "
                       "Completed with no remark, a neutral remark recording "
                       "what was inspected is written for you.").pack(
            anchor=W, pady=(0, 10))

        inner = ttk.Notebook(outer)
        inner.pack(fill=BOTH, expand=True)
        self.wp_widgets: dict[str, dict] = {}

        for tab in TABS:
            page = ttk.Frame(inner, padding=10)
            inner.add(page, text=tab)
            canvas_frame = ttk.Frame(page)
            canvas_frame.pack(fill=BOTH, expand=True)
            tree = ttk.Treeview(
                canvas_frame,
                columns=("ref", "question", "answer", "status", "reviewer",
                         "confidence"),
                show="headings", height=11)
            for column, heading, width in (
                    ("ref", "Ref", 52), ("question", "Question", 430),
                    ("answer", "Answer", 80), ("status", "Status", 100),
                    ("reviewer", "Reviewer", 120),
                    ("confidence", "Confidence", 120)):
                tree.heading(column, text=heading)
                tree.column(column, width=width,
                            anchor=W if column == "question" else "center")
            scroll = ttk.Scrollbar(canvas_frame, orient="vertical",
                                   command=tree.yview)
            tree.configure(yscrollcommand=scroll.set)
            tree.pack(side=LEFT, fill=BOTH, expand=True)
            scroll.pack(side=RIGHT, fill=Y)

            for question in (q for q in QUESTIONS if q.tab == tab):
                tree.insert("", END, iid=question.id,
                            values=(question.id, question.text, "unknown",
                                    "Pending", "", "not verified"))

            editor = ttk.Frame(page, style="Card.TFrame", padding=12)
            editor.pack(fill=X, pady=(10, 0))
            answer_var = StringVar(value="unknown")
            status_var = StringVar(value="Pending")
            conf_var = StringVar(value="not verified")
            remark_var = StringVar()
            for column, (label, var, values, width) in enumerate((
                    ("Answer", answer_var, ANSWERS, 10),
                    ("Status", status_var, STATUSES, 13),
                    ("Confidence", conf_var, CONFIDENCE, 16))):
                ttk.Label(editor, text=label, style="Card.TLabel").grid(
                    row=0, column=column * 2, sticky=W, padx=(0 if not column else 14, 6))
                ttk.Combobox(editor, textvariable=var, values=list(values),
                             width=width, state="readonly").grid(
                    row=0, column=column * 2 + 1, sticky=W)
            ttk.Label(editor, text="Remark", style="Card.TLabel").grid(
                row=1, column=0, sticky=W, pady=(10, 0))
            ttk.Entry(editor, textvariable=remark_var, width=74).grid(
                row=1, column=1, columnspan=4, sticky=W, pady=(10, 0))
            ttk.Button(editor, text="Save line", style="Accent.TButton",
                       command=lambda t=tab: self.save_line(t)).grid(
                row=1, column=5, padx=(14, 0), pady=(10, 0))

            self.wp_widgets[tab] = {
                "tree": tree, "answer": answer_var, "status": status_var,
                "confidence": conf_var, "remark": remark_var,
            }
            tree.bind("<<TreeviewSelect>>",
                      lambda _event, t=tab: self.load_line(t))

        footer = ttk.Frame(outer)
        footer.pack(fill=X, pady=(10, 0))
        self.wp_summary = ttk.Label(footer, style="Muted.TLabel",
                                    text="0 of 24 lines completed.")
        self.wp_summary.pack(side=LEFT)
        ttk.Button(footer, text="Re-score with the working paper",
                   command=self.rescore).pack(side=RIGHT)

    def load_line(self, tab: str):
        widgets = self.wp_widgets[tab]
        selection = widgets["tree"].selection()
        if not selection:
            return
        response = self.responses[selection[0]]
        widgets["answer"].set(response.answer)
        widgets["status"].set(response.status)
        widgets["confidence"].set(response.confidence)
        widgets["remark"].set(response.remark)

    def save_line(self, tab: str):
        widgets = self.wp_widgets[tab]
        selection = widgets["tree"].selection()
        if not selection:
            messagebox.showinfo("Select a line",
                                "Choose a line in the table above first.")
            return
        question_id = selection[0]
        question = next(q for q in QUESTIONS if q.id == question_id)
        response = self.responses[question_id]
        response.answer = widgets["answer"].get()
        response.status = widgets["status"].get()
        response.confidence = widgets["confidence"].get()
        response.remark = widgets["remark"].get()
        response.reviewer = self.reviewer_var.get().strip()

        errors = validate(response, question)
        if errors:
            messagebox.showwarning(
                "This line is not complete",
                "\n".join("• " + e for e in errors))
            return
        finalise(response, question)
        widgets["tree"].item(question_id, values=(
            question.id, question.text, response.answer, response.status,
            response.reviewer, response.confidence))
        widgets["remark"].set(response.remark)
        stats = completion_stats(self.responses)
        self.wp_summary.configure(
            text=f"{stats['by_status'][STATUS_COMPLETED]} of {stats['total']} "
                 f"lines completed ({stats['percent_complete']:.0f}% of "
                 f"assessable lines).")

    # -------------------------------------------------------- findings tab
    def _tab_findings(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Findings  ")
        holder = ttk.Frame(frame)
        holder.pack(fill=BOTH, expand=True)
        self.findings_tree = ttk.Treeview(
            holder,
            columns=("ref", "domain", "obligation", "provision", "status",
                     "basis"),
            show="headings")
        for column, heading, width in (
                ("ref", "Ref", 50), ("domain", "Domain", 150),
                ("obligation", "Obligation", 330),
                ("provision", "Provision", 170), ("status", "Status", 95),
                ("basis", "Why", 300)):
            self.findings_tree.heading(column, text=heading)
            self.findings_tree.column(
                column, width=width,
                anchor=W if column in ("obligation", "basis", "domain") else "center")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.findings_tree.yview)
        self.findings_tree.configure(yscrollcommand=scroll.set)
        self.findings_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)
        self.findings_tree.tag_configure("met", background="#E8F4EE")
        self.findings_tree.tag_configure("partial", background="#FDF4E0")
        self.findings_tree.tag_configure("gap", background="#FAE6E2")
        self.findings_tree.tag_configure("na", background="#F1F4F5")

        self.finding_detail = Text(frame, height=8, wrap="word", relief="flat",
                                   bg=CARD, fg=INK, padx=12, pady=10,
                                   font=("Segoe UI", 9))
        self.finding_detail.pack(fill=X, pady=(12, 0))
        self.finding_detail.configure(state="disabled")
        self.findings_tree.bind("<<TreeviewSelect>>", self.show_finding)

    def show_finding(self, _event=None):
        selection = self.findings_tree.selection()
        if not selection or not self.review:
            return
        finding = next((f for f in self.review.findings
                        if f.obligation_id == selection[0]), None)
        if finding is None:
            return
        lines = [
            f"{finding.obligation_id} — {finding.title}",
            f"{finding.provision} ({finding.provision_status}) · weight "
            f"{finding.weight} · confidence {finding.confidence} · decided by "
            f"{finding.decided_by}",
            "",
            finding.rationale, "",
        ]
        if finding.evidence:
            lines.append("Evidence:")
            lines += [f"  • {str(e)[:300]}" for e in finding.evidence[:6]]
            lines.append("")
        lines += ["Remediation:", f"  {finding.remediation}",
                  f"  Effort: {finding.effort}"]
        if finding.school_note:
            lines += ["", "Note for schools:", "  " + finding.school_note]
        self.finding_detail.configure(state="normal")
        self.finding_detail.delete("1.0", END)
        self.finding_detail.insert(END, "\n".join(lines))
        self.finding_detail.configure(state="disabled")

    # ---------------------------------------------------- perspectives tab
    def _tab_perspectives(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Two views  ")
        ttk.Label(frame, style="Muted.TLabel", justify=LEFT,
                  text="The same facts, read two ways. The panels differ "
                       "because the perspective differs, not because the facts "
                       "changed.").pack(anchor=W, pady=(0, 10))
        self.perspective_text = Text(frame, wrap="word", relief="flat",
                                     bg=CARD, fg=INK, padx=16, pady=14,
                                     font=("Segoe UI", 10))
        self.perspective_text.pack(fill=BOTH, expand=True)
        self.perspective_text.tag_configure(
            "h", font=("Segoe UI", 11, "bold"), foreground=INK,
            spacing1=12, spacing3=4)
        self.perspective_text.tag_configure(
            "sub", font=("Segoe UI", 9), foreground=MUTED, spacing3=6)
        self.perspective_text.tag_configure(
            "panel", font=("Segoe UI", 9, "bold"), foreground=TEAL,
            spacing1=6)
        self.perspective_text.configure(state="disabled")

    # ------------------------------------------------------ documents tab
    def _tab_documents(self):
        frame = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(frame, text="  Documents  ")
        ttk.Label(frame, style="Muted.TLabel", justify=LEFT,
                  text="Add the admission form, the consent slip, the CCTV "
                       "signage photograph or the transport app screenshot. "
                       "PDFs are read offline with PyMuPDF; images are read by "
                       "the vision model when a key is available.").pack(
            anchor=W, pady=(0, 10))
        buttons = ttk.Frame(frame)
        buttons.pack(fill=X, pady=(0, 10))
        ttk.Button(buttons, text="Add documents…",
                   command=self.add_documents).pack(side=LEFT)
        ttk.Button(buttons, text="Clear",
                   command=self.clear_documents).pack(side=LEFT, padx=8)
        self.documents_list = Text(frame, wrap="word", relief="flat", bg=CARD,
                                   fg=INK, padx=12, pady=10,
                                   font=("Segoe UI", 9))
        self.documents_list.pack(fill=BOTH, expand=True)
        self.documents_list.configure(state="disabled")

    def add_documents(self):
        paths = filedialog.askopenfilenames(
            title="Choose supporting documents",
            filetypes=[("Documents and images",
                        "*.pdf *.png *.jpg *.jpeg *.webp"),
                       ("All files", "*.*")])
        self.document_paths.extend(paths)
        self._render_documents()

    def clear_documents(self):
        self.document_paths.clear()
        self._render_documents()

    def _render_documents(self):
        self.documents_list.configure(state="normal")
        self.documents_list.delete("1.0", END)
        if not self.document_paths:
            self.documents_list.insert(END, "No documents added.")
        for path in self.document_paths:
            self.documents_list.insert(END, f"• {Path(path).name}\n")
        if self.review and self.review.documents:
            self.documents_list.insert(END, "\nReviewed:\n")
            for document in self.review.documents:
                self.documents_list.insert(
                    END, f"\n{document.file_name} ({document.method})\n")
                if document.error:
                    self.documents_list.insert(END, f"   {document.error}\n")
                    continue
                for element in document.elements_absent:
                    self.documents_list.insert(END, f"   missing: {element}\n")
                for note in document.uncertainty:
                    self.documents_list.insert(END, f"   uncertainty: {note}\n")
        self.documents_list.configure(state="disabled")

    # -------------------------------------------------------- reports tab
    def _tab_reports(self):
        frame = ttk.Frame(self.tabs, padding=18)
        self.tabs.add(frame, text="  Reports  ")
        card = ttk.Frame(frame, style="Card.TFrame", padding=18)
        card.pack(fill=X)
        ttk.Label(card, text="Export", style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 10))
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(anchor=W)
        self.docx_button = ttk.Button(row, text="Word report",
                                      style="Accent.TButton",
                                      command=self.save_docx, state="disabled")
        self.docx_button.pack(side=LEFT)
        self.xlsx_button = ttk.Button(row, text="Excel workbook",
                                      command=self.save_xlsx, state="disabled")
        self.xlsx_button.pack(side=LEFT, padx=8)
        self.html_button = ttk.Button(row, text="HTML dashboard",
                                      command=self.save_html, state="disabled")
        self.html_button.pack(side=LEFT)
        ttk.Label(card, style="CardMuted.TLabel",
                  text="Nothing is sent anywhere. Sharing a report is a "
                       "separate, deliberate step you take yourself.").pack(
            anchor=W, pady=(12, 0))

        ttk.Label(frame, text="Scan history", style="H2.TLabel").pack(
            anchor=W, pady=(18, 6))
        self.history_tree = ttk.Treeview(
            frame, columns=("when", "institution", "score", "band"),
            show="headings", height=9)
        for column, heading, width in (("when", "Written at", 200),
                                       ("institution", "Institution", 330),
                                       ("score", "Score", 90),
                                       ("band", "Band", 130)):
            self.history_tree.heading(column, text=heading)
            self.history_tree.column(column, width=width)
        self.history_tree.pack(fill=BOTH, expand=True)
        ttk.Button(frame, text="Refresh history",
                   command=self.refresh_history).pack(anchor=W, pady=8)
        self.refresh_history()

    def refresh_history(self):
        for row in self.history_tree.get_children():
            self.history_tree.delete(row)
        for record in evidence.history():
            self.history_tree.insert(
                "", END, values=(record["written_at"], record["institution"],
                                 record["score"], record["band"]))

    def load_history(self):
        path = filedialog.askopenfilename(
            title="Open a saved evidence file",
            filetypes=[("Evidence JSON", "*.json")])
        if not path:
            return
        try:
            record = evidence.load(path)
        except Exception as exc:
            messagebox.showerror("Could not open that file", str(exc))
            return
        assessment = (record.get("payload") or {}).get("assessment") or {}
        messagebox.showinfo(
            "Saved scan",
            f"{record.get('institution', '')}\n"
            f"Written {record.get('written_at', '')}\n"
            f"Score {assessment.get('score')} ({assessment.get('band')})\n\n"
            "Re-run the scan to load it into the tabs.")

    # -------------------------------------------------------------- actions
    def start_scan(self):
        name = self.name_var.get().strip()
        url = self.url_var.get().strip()
        if not name or url in ("", "https://"):
            messagebox.showwarning(
                "Missing information",
                "Enter both the institution name and the website address.")
            return
        extras = [u.strip() for u in self.extra_var.get().split(",") if u.strip()]

        authorisation = Authorisation(authorised_by=self.auth_by_var.get())
        problems = authorisation.problems()
        if problems:
            messagebox.showwarning(
                "Authorised by is empty",
                "Enter the name and designation of the person who "
                "authorised this review before running it.")
            return

        self.scan_button.configure(state="disabled")
        self.progress.start(12)
        self._log_lines = 0
        self.log.configure(state="normal")
        self.log.delete("1.0", END)
        self.log.configure(state="disabled")
        self.log_hint.configure(text="starting…")

        def work():
            try:
                review = run_review(
                    name, url, extras, responses=self.responses,
                    authorisation=authorisation,
                    document_paths=list(self.document_paths),
                    settings=self.settings, use_ai=self.ai_var.get(),
                    progress=self._say)
                self.messages.put(("done", review))
            except AuthorisationError as exc:
                self.messages.put(("error", str(exc)))
            except Exception as exc:  # surfaced to the user, not swallowed
                self.messages.put(("error", f"{type(exc).__name__}: {exc}"))

        threading.Thread(target=work, daemon=True).start()

    def rescore(self):
        if not self.review:
            messagebox.showinfo("Run a scan first",
                                "Re-scoring uses the website findings too.")
            return
        from ..questionnaire import to_answer_map
        from .. import rules_engine
        findings = rules_engine.assess(
            self.review.scan, to_answer_map(self.responses))
        self.review.findings = findings
        self.review.assessment = scoring.score_findings(
            self.review.scan.institution_name,
            self.review.scan.scanned_at, findings)
        self.review.working_paper_stats = completion_stats(self.responses)
        from .. import perspectives as perspectives_module
        self.review.perspectives = perspectives_module.build_perspectives(findings)
        self._render_review()
        self.status.configure(text="Re-scored with the working paper.")

    def _scan_finished(self, review):
        self.progress.stop()
        self.scan_button.configure(state="normal")
        self.review = review
        self._render_review()
        self._render_documents()
        self.refresh_history()
        for button in (self.docx_button, self.xlsx_button, self.html_button):
            button.configure(state="normal")
        self.status.configure(
            text=f"Done. Evidence written to "
                 f"{Path(review.evidence_path).name if review.evidence_path else 'memory'}.")
        self.tabs.select(2)

    def _render_review(self):
        assessment = self.review.assessment
        self.score_label.configure(text=f"{assessment.score:.0f}")
        self.band_label.configure(
            text=f"{assessment.band} · {assessment.coverage_percent:.0f}% of the "
                 f"catalogue assessed")

        for row in self.findings_tree.get_children():
            self.findings_tree.delete(row)
        for finding in self.review.findings:
            self.findings_tree.insert(
                "", END, iid=finding.obligation_id,
                tags=(ROW_TAGS.get(finding.status, "na"),),
                values=(finding.obligation_id, finding.domain, finding.title,
                        f"{finding.provision}",
                        STATUS_WORDS.get(finding.status, finding.status),
                        finding.rationale[:160]))

        self.perspective_text.configure(state="normal")
        self.perspective_text.delete("1.0", END)
        if not self.review.perspectives:
            self.perspective_text.insert(
                END, "No contested findings — nothing to argue about.")
        for pair in self.review.perspectives:
            self.perspective_text.insert(
                END, f"{pair.obligation_id} — {pair.title}\n", "h")
            self.perspective_text.insert(
                END, f"{pair.provision} · residual risk: {pair.residual_risk}\n",
                "sub")
            self.perspective_text.insert(END, "The institution's position\n",
                                         "panel")
            self.perspective_text.insert(END, pair.institution_position + "\n")
            self.perspective_text.insert(
                END, "The parent's or the Board's position\n", "panel")
            self.perspective_text.insert(END, pair.regulator_position + "\n")
            self.perspective_text.insert(END, "What decides it\n", "panel")
            self.perspective_text.insert(END, pair.what_decides_it + "\n\n")
        self.perspective_text.configure(state="disabled")

    def _default_name(self, extension: str) -> str:
        stem = evidence.slugify(self.review.scan.institution_name)
        return f"{stem}_DPDP_Readiness_{date.today():%Y%m%d}{extension}"

    def _export(self, extension: str, description: str, writer):
        if not self.review:
            messagebox.showinfo("No scan yet", "Run a review first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=extension,
            initialdir=str(output_root()),
            initialfile=self._default_name(extension),
            filetypes=[(description, "*" + extension)],
            title="Save the report as…")
        if not path:
            return
        try:
            writer(path)
        except Exception as exc:
            messagebox.showerror("Could not save", f"{type(exc).__name__}: {exc}")
            return
        if messagebox.askyesno("Report saved",
                               f"Saved to:\n{path}\n\nOpen it now?"):
            webbrowser.open(Path(path).as_uri())

    def save_docx(self):
        self._export(".docx", "Word document",
                     lambda p: report_docx.generate(
                         self.review, p,
                         prepared_by=self.reviewer_var.get().strip()))

    def save_xlsx(self):
        def write(path):
            setattr(self.review, "_responses", self.responses)
            report_xlsx.generate(self.review, path)
        self._export(".xlsx", "Excel workbook", write)

    def save_html(self):
        self._export(".html", "HTML dashboard",
                     lambda p: report_html.generate(self.review, p))


def main():
    root = Tk()
    SurakshaScanApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
