"""
The audit trail.

Running theme from the course: every output row should trace back to its
source record. Here that means every scan is written to a timestamped JSON
file containing the raw evidence, and every report names the evidence file it
was produced from. A finding in a report can therefore be re-opened months
later and checked against what the site actually said on the day.

Nothing secret is written. The API key is never serialised.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path

from .config import EVIDENCE_DIR

SECRET_KEYS = ("api_key", "apikey", "token", "password", "secret",
               "authorization")


def _clean(obj):
    if is_dataclass(obj) and not isinstance(obj, type):
        obj = asdict(obj)
    if isinstance(obj, dict):
        return {k: ("[redacted]" if any(s in k.lower() for s in SECRET_KEYS)
                    else _clean(v)) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


def slugify(text: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", (text or "institution")).strip("_")
    return (slug or "institution")[:60]


def save(institution_name: str, payload: dict,
         directory: Path | None = None) -> Path:
    directory = Path(directory or EVIDENCE_DIR)
    directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = directory / f"{slugify(institution_name)}_{stamp}.json"
    record = {
        "schema": "surakshascan.evidence/1",
        "written_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "institution": institution_name,
        "payload": _clean(payload),
    }
    path.write_text(json.dumps(record, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    return path


def load(path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def history(institution_name: str | None = None,
            directory: Path | None = None) -> list[dict]:
    """List prior scans, newest first - the basis for trend and re-scan."""
    directory = Path(directory or EVIDENCE_DIR)
    if not directory.exists():
        return []
    out = []
    pattern = f"{slugify(institution_name)}_*.json" if institution_name else "*.json"
    for path in sorted(directory.glob(pattern), reverse=True):
        try:
            record = load(path)
        except (json.JSONDecodeError, OSError):
            continue
        assessment = (record.get("payload") or {}).get("assessment") or {}
        out.append({
            "file": str(path),
            "institution": record.get("institution", ""),
            "written_at": record.get("written_at", ""),
            "score": assessment.get("score"),
            "band": assessment.get("band"),
        })
    return out
