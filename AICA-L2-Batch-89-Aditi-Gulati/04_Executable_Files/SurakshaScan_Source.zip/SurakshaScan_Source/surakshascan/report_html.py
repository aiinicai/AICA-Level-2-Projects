"""
A self-contained HTML dashboard, for the reader who will not open Word.

One file, no network, no external stylesheet, charts embedded as data URIs so
it survives being emailed. Responsive down to phone width, because a school
principal reads it on a phone.
"""

from __future__ import annotations

import base64
import html
import tempfile
from datetime import date
from pathlib import Path

from . import charts
from .dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL

STATUS_WORDS = {MET: "Met", PARTIAL: "Partly met", GAP: "Gap",
                NOT_ASSESSED: "Not assessed"}
STATUS_CLASS = {MET: "met", PARTIAL: "partial", GAP: "gap",
                NOT_ASSESSED: "na"}

CSS = """
:root{--ink:#1F3B57;--muted:#5A6B78;--line:#DDE4E9;--bg:#F6F8FA;
--met:#2E7D5B;--partial:#C98A16;--gap:#B3321E;--na:#9AA5AD;--card:#FFFFFF}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
.wrap{max-width:1040px;margin:0 auto;padding:24px 16px 64px}
header{border-bottom:3px solid var(--ink);padding-bottom:16px;margin-bottom:24px}
h1{margin:0 0 4px;font-size:26px}
h2{font-size:19px;margin:32px 0 12px;padding-bottom:6px;
border-bottom:1px solid var(--line)}
h3{font-size:15px;margin:20px 0 6px}
.sub{color:var(--muted);font-size:13px;margin:0}
.grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;
padding:16px}
.big{font-size:38px;font-weight:700;line-height:1.1}
.label{color:var(--muted);font-size:12px;text-transform:uppercase;
letter-spacing:.06em}
img{max-width:100%;height:auto;display:block;margin:12px auto}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:8px}
th{background:var(--ink);color:#fff;text-align:left;padding:8px;font-weight:600}
td{padding:8px;border-bottom:1px solid var(--line);vertical-align:top}
tr:nth-child(even) td{background:#FBFCFD}
.pill{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11.5px;
font-weight:600;white-space:nowrap}
.met{background:#D8EDE2;color:var(--met)}
.partial{background:#FBEFD2;color:#8A5E08}
.gap{background:#F7D9D3;color:var(--gap)}
.na{background:#ECEFF1;color:var(--na)}
.panels{display:grid;gap:12px;grid-template-columns:1fr 1fr;margin-top:8px}
.panel{background:var(--card);border:1px solid var(--line);border-radius:8px;
padding:12px;font-size:13px}
.panel h4{margin:0 0 6px;font-size:12px;text-transform:uppercase;
letter-spacing:.05em;color:var(--muted)}
.decides{background:#EEF4F7;border-left:3px solid var(--ink);padding:10px 12px;
margin-top:8px;font-size:13px;border-radius:0 6px 6px 0}
.note{color:var(--muted);font-size:12.5px;font-style:italic}
footer{margin-top:40px;padding-top:16px;border-top:1px solid var(--line);
color:var(--muted);font-size:12px}
@media(max-width:720px){.panels{grid-template-columns:1fr}.big{font-size:30px}}
"""


def _embed(path: str) -> str:
    data = base64.b64encode(Path(path).read_bytes()).decode("ascii")
    return f"data:image/png;base64,{data}"


def _e(text) -> str:
    return html.escape(str(text if text is not None else ""))


def generate(review, output_path, comparison: dict | None = None) -> str:
    scan, assessment = review.scan, review.assessment
    output_path = Path(output_path)
    tmp = Path(tempfile.mkdtemp(prefix="surakshascan_html_"))

    donut = _embed(charts.donut_of_statuses(
        assessment.counts, assessment.score, tmp / "d.png"))
    bars = _embed(charts.bar_of_domains(assessment.domains, tmp / "b.png"))
    compare_img = ""
    if comparison and comparison.get("rows"):
        compare_img = _embed(charts.bar_of_comparison(comparison, tmp / "c.png"))

    parts: list[str] = [
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>",
        f"<title>DPDP Readiness — {_e(scan.institution_name)}</title>",
        f"<style>{CSS}</style></head><body><div class='wrap'>",
        "<header><h1>DPDP Readiness Report</h1>",
        f"<p class='sub'><strong>{_e(scan.institution_name)}</strong> — "
        f"{_e(scan.base_url)}</p>",
        f"<p class='sub'>Scanned {_e(scan.scanned_at)} · "
        f"Report {date.today():%d %B %Y}</p></header>",

        "<div class='grid'>",
        f"<div class='card'><div class='label'>Readiness score</div>"
        f"<div class='big'>{assessment.score:.0f}</div>"
        f"<div class='sub'>{_e(assessment.band)}</div></div>",
        f"<div class='card'><div class='label'>Gaps</div>"
        f"<div class='big'>{assessment.counts.get(GAP, 0)}</div>"
        f"<div class='sub'>obligations not addressed</div></div>",
        f"<div class='card'><div class='label'>Partly met</div>"
        f"<div class='big'>{assessment.counts.get(PARTIAL, 0)}</div>"
        f"<div class='sub'>need strengthening</div></div>",
        f"<div class='card'><div class='label'>Coverage</div>"
        f"<div class='big'>{assessment.coverage_percent:.0f}%</div>"
        f"<div class='sub'>of the catalogue assessable</div></div>",
        "</div>",

        f"<p class='note'>{_e(assessment.band_note)}</p>",
        f"<img src='{donut}' alt='Status mix'>",
        "<h2>Where the gaps are</h2>",
        f"<img src='{bars}' alt='Readiness by domain'>",
    ]

    if compare_img:
        parts += ["<h2>How this compares</h2>",
                  f"<img src='{compare_img}' alt='Benchmark'>"]

    parts.append("<h2>What to do first</h2><table><tr><th>#</th>"
                 "<th>Obligation</th><th>Action</th><th>Effort</th>"
                 "<th>Score gain</th></tr>")
    for item in assessment.remediation[:12]:
        parts.append(
            f"<tr><td>{item.rank}</td><td><strong>{_e(item.obligation_id)}</strong> "
            f"{_e(item.title)}<br><span class='note'>{_e(item.provision)} · "
            f"{_e(item.provision_status)}</span></td>"
            f"<td>{_e(item.action)}</td><td>{_e(item.effort)}</td>"
            f"<td>+{item.score_gain:.1f}</td></tr>")
    parts.append("</table>")

    parts.append("<h2>Every obligation</h2><table><tr><th>Ref</th>"
                 "<th>Obligation</th><th>Provision</th><th>Status</th>"
                 "<th>Basis</th></tr>")
    for finding in review.findings:
        cls = STATUS_CLASS.get(finding.status, "na")
        parts.append(
            f"<tr><td>{_e(finding.obligation_id)}</td>"
            f"<td>{_e(finding.title)}</td>"
            f"<td>{_e(finding.provision)}<br><span class='note'>"
            f"{_e(finding.provision_status)}</span></td>"
            f"<td><span class='pill {cls}'>"
            f"{_e(STATUS_WORDS.get(finding.status, finding.status))}</span></td>"
            f"<td>{_e(finding.rationale)}</td></tr>")
    parts.append("</table>")

    if review.perspectives:
        parts.append("<h2>Two views of the same facts</h2>"
                     "<p class='note'>Identical facts, two readings. This is "
                     "the argument the institution can expect to have.</p>")
        for pair in review.perspectives:
            parts.append(
                f"<h3>{_e(pair.obligation_id)} — {_e(pair.title)}</h3>"
                f"<p class='note'>{_e(pair.provision)} · residual risk: "
                f"{_e(pair.residual_risk)}</p><div class='panels'>"
                f"<div class='panel'><h4>The institution's position</h4>"
                f"{_e(pair.institution_position)}</div>"
                f"<div class='panel'><h4>The parent's or the Board's position</h4>"
                f"{_e(pair.regulator_position)}</div></div>"
                f"<div class='decides'><strong>What decides it:</strong> "
                f"{_e(pair.what_decides_it)}</div>")

    ai_line = (f"AI layer: used ({_e(review.ai.model)}), "
               f"{sum(1 for f in review.ai.findings if f.accepted)} findings "
               f"accepted, {sum(1 for f in review.ai.findings if not f.accepted)} "
               f"rejected by verification. Ratings above come from the "
               f"deterministic rules engine."
               if (review.ai and review.ai.used)
               else f"AI layer: not used. {_e(review.ai.reason_not_used) if review.ai else ''}")

    parts += [
        "<footer>",
        f"<p><strong>Authorisation:</strong> "
        f"{_e(review.authorisation.summary() if getattr(review, 'authorisation', None) else 'not recorded')}</p>",
        f"<p>{ai_line}</p>",
        f"<p>Pages fetched: {len(scan.pages)} · robots.txt: "
        f"{_e(scan.robots_note)} · Evidence file: "
        f"{_e(Path(review.evidence_path).name if review.evidence_path else 'not written')}</p>",
        "<p>This report records a point-in-time readiness review. It is not a "
        "certificate of compliance with the Digital Personal Data Protection "
        "Act, 2023 or the DPDP Rules, 2025, and it is not legal advice. "
        "Automated checks cover publicly accessible pages only. Absence of a "
        "finding is not evidence of absence. Verify every legal reference "
        "against the notified text before acting on it.</p>",
        "</footer></div></body></html>",
    ]

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("".join(parts), encoding="utf-8")
    return str(output_path)
