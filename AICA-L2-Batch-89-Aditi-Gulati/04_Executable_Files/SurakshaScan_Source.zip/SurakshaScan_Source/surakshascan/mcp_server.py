"""
MCP server - Day 5.

Exposes SurakshaScan to an AI client as tools, so a reviewer can ask for a
readiness check in conversation instead of opening the app.

Permission design, following the Day 5 caution that installing an MCP
extension does not by itself grant safe access:

* Read-only by default. The write tools - saving a report to disk - are
  registered only when SURAKSHASCAN_MCP_ALLOW_WRITE=1 is set.
* The output directory is fixed by SURAKSHASCAN_MCP_OUTPUT_DIR and every path
  is resolved inside it. A path that escapes is refused.
* No tool sends anything anywhere. Emailing a report stays a human act.
* The API key is never exposed through a tool, and never returned in output.
* Scanning is rate-limited and robots-aware exactly as in the desktop app.

Run:  python -m surakshascan.mcp_server
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from . import evidence, report_docx, report_html, report_xlsx
from .authorisation import Authorisation, AuthorisationError
from .config import Settings
from .dpdp_catalogue import CATALOGUE
from .engine import run_review

ALLOW_WRITE = os.environ.get("SURAKSHASCAN_MCP_ALLOW_WRITE") == "1"
OUTPUT_DIR = Path(os.environ.get(
    "SURAKSHASCAN_MCP_OUTPUT_DIR",
    Path.home() / "SurakshaScan_reports")).expanduser().resolve()

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:  # keep the module importable for tests and docs
    FastMCP = None

_last_review = {}


def _safe_output_path(filename: str) -> Path:
    candidate = (OUTPUT_DIR / Path(filename).name).resolve()
    if OUTPUT_DIR not in candidate.parents and candidate != OUTPUT_DIR:
        raise ValueError("the output path must stay inside the configured "
                         "output directory")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return candidate


def register(server) -> None:
    @server.tool()
    def list_obligations() -> str:
        """List the DPDP obligations SurakshaScan checks, with the provision
        each one comes from and when that provision commences."""
        return json.dumps([{
            "id": o.id, "domain": o.domain, "title": o.title,
            "provision": o.provision, "commences": str(o.commences),
            "in_force": o.in_force, "weight": o.weight,
            "evidence_sources": list(o.evidence),
        } for o in CATALOGUE], indent=2)

    @server.tool()
    def scan_institution(name: str, url: str, authorised_by: str,
                         extra_pages: str = "") -> str:
        """Run a DPDP readiness review of an institution's public website.
        authorised_by is the name and designation of the person who
        authorised the review. Read-only: public pages only, obeys
        robots.txt, never logs in."""
        extras = [u.strip() for u in extra_pages.split(",") if u.strip()]
        auth = Authorisation(authorised_by=authorised_by)
        try:
            review = run_review(name, url, extras, settings=Settings.load(),
                                use_ai=False, authorisation=auth)
        except AuthorisationError as exc:
            return json.dumps({"refused": str(exc)})
        _last_review["review"] = review
        assessment = review.assessment
        return json.dumps({
            "institution": name,
            "score": assessment.score,
            "band": assessment.band,
            "band_note": assessment.band_note,
            "coverage_percent": assessment.coverage_percent,
            "counts": assessment.counts,
            "by_domain": [{"domain": d.domain, "percent": d.percent,
                           "gaps": d.gap} for d in assessment.domains],
            "top_actions": [{
                "rank": r.rank, "id": r.obligation_id, "title": r.title,
                "action": r.action, "effort": r.effort,
                "score_gain": r.score_gain, "provision": r.provision,
            } for r in assessment.remediation[:10]],
            "evidence_file": review.evidence_path,
            "caveat": ("Public pages only. Not a compliance certificate. "
                       "Internal practices need the working paper."),
        }, indent=2)

    @server.tool()
    def explain_finding(obligation_id: str) -> str:
        """Explain one obligation from the last scan: the rating, the evidence
        behind it, the remediation, and the two-perspective analysis."""
        review = _last_review.get("review")
        if review is None:
            return json.dumps({"error": "no scan has been run in this session"})
        finding = next((f for f in review.findings
                        if f.obligation_id.upper() == obligation_id.upper()),
                       None)
        if finding is None:
            return json.dumps({"error": f"no obligation '{obligation_id}'"})
        pair = next((p for p in review.perspectives
                     if p.obligation_id == finding.obligation_id), None)
        return json.dumps({
            "finding": finding.to_dict(),
            "two_views": pair.to_dict() if pair else None,
        }, indent=2)

    @server.tool()
    def scan_history(institution: str = "") -> str:
        """List previous scans and their scores, newest first."""
        return json.dumps(evidence.history(institution or None), indent=2)

    if not ALLOW_WRITE:
        return

    @server.tool()
    def save_report(filename: str, format: str = "docx") -> str:
        """Write the last scan's report to the configured output directory.
        Available only when write access has been explicitly enabled."""
        review = _last_review.get("review")
        if review is None:
            return json.dumps({"error": "no scan has been run in this session"})
        try:
            path = _safe_output_path(filename)
        except ValueError as exc:
            return json.dumps({"error": str(exc)})
        writers = {"docx": report_docx.generate,
                   "xlsx": report_xlsx.generate,
                   "html": report_html.generate}
        writer = writers.get(format.lower())
        if writer is None:
            return json.dumps({"error": f"unsupported format '{format}'"})
        return json.dumps({"written": writer(review, path)}, indent=2)


def main() -> None:
    if FastMCP is None:
        raise SystemExit(
            "The mcp package is not installed. Install it with:\n"
            "    pip install \"mcp[cli]\"")
    server = FastMCP("surakshascan")
    register(server)
    server.run()


if __name__ == "__main__":
    main()
