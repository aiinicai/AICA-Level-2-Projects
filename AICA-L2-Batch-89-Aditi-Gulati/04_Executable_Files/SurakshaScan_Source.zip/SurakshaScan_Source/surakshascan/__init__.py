"""SurakshaScan - a DPDP readiness scanner for educational institutions."""

__version__ = "2.0.0"
__all__ = ["__version__"]
