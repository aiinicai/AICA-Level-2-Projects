"""
Authorisation - who allowed this review.

The tool records the name and designation of the person who authorised the
review, refuses to run without one, and prints it on every report so anyone
reading the report can see on whose authority it was done.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime


class AuthorisationError(ValueError):
    """Raised when a review is attempted without a recorded authorisation."""


@dataclass
class Authorisation:
    authorised_by: str = ""          # name and designation
    recorded_at: str = ""

    def __post_init__(self):
        self.authorised_by = (self.authorised_by or "").strip()
        if not self.recorded_at:
            self.recorded_at = datetime.now().isoformat(timespec="seconds")

    def problems(self) -> list[str]:
        if not self.authorised_by:
            return ["enter the name and designation of the person who "
                    "authorised this review"]
        return []

    def require(self) -> None:
        issues = self.problems()
        if issues:
            raise AuthorisationError(
                "This review is not authorised: " + "; ".join(issues) + ".")

    def summary(self) -> str:
        return f"Authorised by {self.authorised_by}."

    def to_dict(self) -> dict:
        return asdict(self)


def fixture() -> Authorisation:
    """The self-test's authorisation."""
    return Authorisation(authorised_by="SurakshaScan self-test")
