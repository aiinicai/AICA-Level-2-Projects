"""
Two-perspective analysis - the Day 2 method applied to each material finding.

The classroom exercise set the same facts in two panels with opposing roles
and observed that the difference in output reflects perspective, not changed
facts. That is exactly what a school needs before it goes to its management
committee: not "you have a gap", but "here is the case the school would make,
here is the case a parent or the Board would make, and here is what actually
decides it".

The facts in both panels are identical and come from the rules engine. Only
the reading changes. Arguments are written per obligation, not per domain,
because the case a school runs for an advertising pixel is not the case it
runs for a photograph in the prospectus, even though both are children's
data. A domain-level fallback exists so a new obligation is never left
without a panel, but it should be treated as a gap to fill rather than a
finished state.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

from .dpdp_catalogue import GAP, PARTIAL, by_id


@dataclass
class PerspectivePair:
    obligation_id: str
    title: str
    provision: str
    agreed_facts: list[str]
    institution_position: str
    regulator_position: str
    what_decides_it: str
    residual_risk: str            # high | medium | low
    argument_source: str = "obligation"   # obligation | domain

    def to_dict(self) -> dict:
        return asdict(self)


# Per-obligation arguments: (institution case, regulator case, what decides it)
ARGUMENTS: dict[str, tuple[str, str, str]] = {

    # ---------------------------------------------------------------- notice
    "A1": (
        "The school publishes its material information through the prospectus, "
        "the admission form and circulars. A parent who enrols has the "
        "information in practice, and the website is not the only notice "
        "channel. Rule 3, which prescribes the notice format, does not "
        "commence until 14 May 2027.",
        "Section 5 is an obligation of the Act, in force since enactment, and "
        "the Rules do not defer it. Notice must accompany the request for "
        "consent. A prospectus handed over once at admission does not reach "
        "the enquirer who fills in a web form and never enrols - yet their "
        "data is collected all the same.",
        "Whether a parent or an enquirer can, today, open one document that "
        "says what is collected, why, how to withdraw and how to complain. If "
        "no such document exists, the argument does not survive contact with "
        "the question.",
    ),
    "A2": (
        "The notice describes the school's data practices in the round. "
        "Itemising every category would produce a document no parent reads, "
        "and the prescribed format is not due until 14 May 2027.",
        "Section 5(1)(i) requires the personal data to be described, itemised. "
        "A school collects categories a parent would not expect - biometric "
        "templates, CCTV footage, transport pickup points, APAAR identifiers - "
        "and a general sentence conceals exactly the ones that matter.",
        "Whether the notice names the unexpected categories. Name, class and "
        "parent phone number are assumed. Biometrics, CCTV, location and "
        "government identifiers are not, and their absence is what makes the "
        "notice inadequate.",
    ),
    "A3": (
        "The purposes are obvious from context: the school collects student "
        "data in order to educate the student. Stating the obvious adds "
        "length without adding protection.",
        "Consent is valid only for the specified purpose, so purpose is the "
        "boundary of what the school may lawfully do. It has to sit against "
        "the data, not float above it. Where no purpose can be written down, "
        "that is a sign the category should not be collected.",
        "Whether a table exists mapping each category to a purpose. The "
        "exercise of writing it is what exposes the fields nobody can justify.",
    ),
    "A4": (
        "Parents who wish to raise anything come to the school office, and "
        "always have. No parent has ever been refused.",
        "Section 6(4) requires withdrawal to be as easy as giving consent, and "
        "section 5(1)(ii) requires the means to be stated in the notice. An "
        "unwritten practice of being approachable is not a stated means, and "
        "leaves no record that withdrawal was ever honoured.",
        "Whether the notice names a channel, and whether a withdrawal, if one "
        "came tomorrow, would leave a trace.",
    ),
    "A5": (
        "Parents may ask for anything in their child's file and the school "
        "provides it. The rights exist in practice whether or not they are "
        "written out.",
        "Sections 11 to 14 create specific rights - access, correction, "
        "erasure and nomination - and Rule 14 requires the school to publish "
        "how to exercise them and within what period. A right nobody knows "
        "they hold is a right that is never exercised.",
        "Whether the four rights are named, one channel is given for all of "
        "them, and a response period is published.",
    ),
    "A6": (
        "The school resolves parent concerns directly. Pointing parents to a "
        "regulator invites escalation of matters better settled in the office.",
        "Section 5(1)(iii) requires the notice to state how to complain to the "
        "Data Protection Board. It is not optional and not contingent on the "
        "school's view of whether escalation is desirable. Omitting it is "
        "routinely the single missing line in a school policy.",
        "One sentence, present or absent. There is no middle position on this "
        "one.",
    ),

    # --------------------------------------------------------------- consent
    "B1": (
        "The admission process is consensual. Parents sign the admission form "
        "knowing the school will process the student's data, and the "
        "processing is necessary to deliver the service they sought.",
        "A signature on an admission form is consent to admission, not "
        "specific and informed consent to each purpose. Section 6(1) requires "
        "a clear affirmative action. A pre-ticked box, a 'by continuing you "
        "agree' banner, and silence are each expressly not that. Bundled "
        "consent is the classic failure.",
        "Whether the school can produce, for a named student, the consent "
        "artefact and show which purposes it covered. If it cannot be "
        "produced, it cannot be relied on.",
    ),
    "B2": (
        "Schools have always collected full particulars at admission. The "
        "information is used for genuine purposes - medical emergencies, "
        "transport, government returns - and parents give it willingly.",
        "The proviso to section 6(1) limits consent to the data necessary for "
        "the specified purpose. Willingness does not cure necessity. A public "
        "enquiry form asking for Aadhaar, caste or blood group from someone "
        "who has not yet applied collects data for no purpose that exists yet.",
        "Take each field on the public form and write the purpose beside it. "
        "The fields where the column stays blank are the answer.",
    ),
    "B3": (
        "The signed admission forms are in the office and can be produced on "
        "request. The school keeps its records carefully.",
        "The question is not whether the form exists but whether it contains a "
        "data protection consent clause, and whether the school can say which "
        "version of that clause a given student's parent signed. Without a "
        "consent register, the school cannot demonstrate compliance under "
        "section 8(1).",
        "Pick a student file at random - the reviewer picks, not the school - "
        "and see whether the consent, its date and its scope can be produced "
        "in five minutes.",
    ),

    # -------------------------------------------------------------- children
    "C1": (
        "Part A of the Fourth Schedule relieves an educational institution of "
        "section 9(1) for academic activities and for the safety of enrolled "
        "students. Teaching a child and keeping them safe is the whole of what "
        "the school does with their data, and the obligation does not commence "
        "until 14 May 2027 in any event.",
        "The exemption is conditional and purpose-bound. It does not reach a "
        "prospective student who has not enrolled, an alumni database, a "
        "promotional photograph, or an EdTech product the school resells. For "
        "anything outside those purposes the school needs verifiable parental "
        "consent, with due diligence under Rule 10 that the consenting adult "
        "is identifiable - not merely whoever filled in the form.",
        "Whether the school can name, for a given consent, how it knew the "
        "person consenting was the parent. 'The form came back signed' is not "
        "verification.",
    ),
    "C2": (
        "Analytics helps the school understand what parents look for on the "
        "site and improve it. The Fourth Schedule expressly permits tracking "
        "and behavioural monitoring by an educational institution.",
        "The Fourth Schedule permits tracking for academic activity and for "
        "the safety of enrolled students. An advertising pixel serves neither: "
        "it exists to build an advertising profile of the visitor for a "
        "commercial third party. Section 9(3) is a prohibition, not a "
        "balancing exercise, and a school website's visitors are children and "
        "their parents.",
        "Look at what each script is for, not what the school uses it for. An "
        "advertising or social pixel cannot be brought inside 'academic' or "
        "'safety' by intention. Removing it takes ten minutes and settles the "
        "point.",
    ),
    "C3": (
        "Everything the school does is either academic or about student "
        "safety. Writing that down is a documentation exercise that changes "
        "nothing on the ground.",
        "The exemption is a defence, and the burden of establishing it falls "
        "on the school. A defence that has never been written down cannot be "
        "run at the point it is needed, and the exercise of writing it almost "
        "always surfaces two or three activities that are neither academic "
        "nor safety-related.",
        "The list itself. Three columns - academic, safety, neither - with "
        "every processing activity in one of them. The 'neither' column is the "
        "school's actual exposure.",
    ),
    "C4": (
        "Publishing achievements is what schools do, parents are proud of it, "
        "and nobody has ever objected. The photographs celebrate the children "
        "rather than exploiting them.",
        "A named, identifiable child on a public web page is processing of a "
        "child's personal data for a promotional purpose. No academic or "
        "safety exemption reaches promotion. Absence of objection is not "
        "consent, and the one parent who does object - often for a reason they "
        "should not have to explain, such as a custody arrangement - needs the "
        "school to have a mechanism ready.",
        "Whether a separate, revocable media consent exists, and whether a "
        "do-not-publish list exists and is actually checked before a "
        "photograph goes up.",
    ),

    "C5": (
        "Parents want their children's achievements celebrated, and they are "
        "the first to share the post themselves. A school that stopped naming "
        "its students would be accused of not caring about them.",
        "A full name, a class and a photograph together identify a specific "
        "child and disclose where that child is every weekday morning. The "
        "parent sharing it afterwards is making their own decision about "
        "their own child; the school publishing it to a public account is "
        "not, and no academic or safety purpose covers a promotional post.",
        "Look at the last twenty posts. Count how many carry a full name and "
        "a class together. The fix costs nothing - a first name alone, or the "
        "class without the name - and nobody feels less celebrated.",
    ),
    "C6": (
        "Boosting a post is ordinary marketing that every institution does, "
        "and the school is promoting itself rather than targeting children.",
        "Paying a platform to push a post featuring students into selected "
        "people's feeds is advertising built on children's data. Section 9(3) "
        "prohibits targeted advertising directed at children, and the school "
        "chose both the content and the audience.",
        "Whether any post featuring students has been boosted. Promote the "
        "admissions dates and the facilities instead - the same marketing "
        "objective without the children in it.",
    ),
    "C7": (
        "The admission form already covers this. Parents sign it, they know "
        "the school publishes photographs, and none has ever objected.",
        "A clause inside the admission form is consent bundled with "
        "admission, which section 6(1) does not permit: a parent cannot "
        "refuse it without appearing to jeopardise the child's place. It is "
        "also not specific, since one tick covers the website, the "
        "prospectus, the press and social media alike. Section 6(4) then "
        "requires withdrawal to be as easy as the giving.",
        "Whether a parent could, today, decline photographs on social media "
        "while still accepting them in the school magazine - and whether the "
        "school would know they had.",
    ),
    "C8": (
        "Teachers are professionals and share photographs out of genuine "
        "pride in their class. Policing their personal accounts would be "
        "heavy-handed and damage trust.",
        "The school is the Data Fiduciary for school activity under section "
        "8(1) whoever's phone the photograph came from. Processing on a "
        "personal account is processing the school cannot see, cannot "
        "withdraw on a parent's request, and cannot account for if asked.",
        "Whether a written rule exists, and whether staff know what they "
        "should do instead - which is usually 'send it to the office "
        "account', not 'never take photographs'.",
    ),

    # ---------------------------------------------------------- security
    "D1": (
        "The website is a brochure site hosted on a standard commercial "
        "package. It holds nothing sensitive and the hosting provider manages "
        "security.",
        "The form on that brochure site collects a child's name, date of "
        "birth and a parent's phone number, and posts them across the network "
        "in the clear. Encryption in transit is the least that section 8(5) "
        "can mean, it costs nothing, and every browser now marks the page as "
        "not secure to the parent filling it in.",
        "Open the page and look at the address bar. This is the cheapest "
        "finding on the list to close and the most conspicuous to leave open.",
    ),
    "D2": (
        "The school runs a commercial ERP and a hosted website and relies on "
        "its vendors' security, as any school of this size must. Rule 6 does "
        "not commence until 14 May 2027.",
        "Section 8(5) requires reasonable security safeguards now, independent "
        "of when Rule 6 prescribes the detail. Section 8(1) makes the Data "
        "Fiduciary responsible even where a processor does the processing, so "
        "buying the system does not transfer the duty. The controls that "
        "actually fail in schools are local: a shared admin password, an "
        "unencrypted Excel export, a WhatsApp group.",
        "Whether access to the student database is by named user accounts, and "
        "whether anyone could say who exported the address list last month.",
    ),
    "D3": (
        "The school has never had a data breach, and dealing with one if it "
        "arose would be a matter of common sense and prompt action.",
        "Rule 7 requires intimation to every affected Data Principal without "
        "delay and a report to the Board. Common sense at eight in the evening "
        "when the ERP vendor calls does not produce a list of affected parents "
        "or a defensible timeline. The procedure exists to be used on the "
        "worst day, not a normal one.",
        "Whether the school could answer, within a day of an incident, who was "
        "affected, what was taken, and who has been told. The controls matter "
        "less than the ability to answer.",
    ),

    # ------------------------------------------------------------- retention
    "E1": (
        "School records must be retained. CBSE requirements, transfer "
        "certificates and the possibility of a former student needing a "
        "document years later all demand it.",
        "Retention required by law is permitted; indefinite retention of "
        "everything is not. The records that matter here are the ones no rule "
        "requires - enquiries from parents who never enrolled, CCTV from three "
        "years ago, biometric templates of students who left. Section 8(7) "
        "requires erasure once the purpose is spent.",
        "Whether a written schedule exists naming a legal basis for each "
        "period, and whether anything has actually been deleted under it in "
        "the past year. A schedule never acted on is a document, not a "
        "control.",
    ),
    "E2": (
        "Cameras are there for the children's safety and parents want them. "
        "The footage is only viewed if there is an incident.",
        "Safety is a good purpose and the Fourth Schedule recognises it. It "
        "does not carry an unlimited retention period or an unlimited "
        "audience. The risk in school CCTV is not the recording, it is who can "
        "export a clip and where that clip goes afterwards.",
        "The overwrite cycle on the recorder, the list of people who can "
        "export footage, and whether exports are logged.",
    ),

    # ---------------------------------------------------- governance
    "F1": (
        "The school office is easy to reach, the head of administration is "
        "known to every parent, and the contact page has a phone number and an "
        "email address. Nothing is hidden.",
        "Section 8(9) requires the published business contact of the person "
        "able to answer questions about the processing. A general office "
        "address identifies no such person, is answered by whoever is free, "
        "and leaves no record that a data question was ever asked. Rule 9 "
        "requires it to be published prominently.",
        "Whether a dedicated address exists, whether it is monitored, and "
        "whether a parent could find it without asking.",
    ),
    "F2": (
        "Parents raise concerns with the class teacher or the principal and "
        "they are dealt with. The school's door is open.",
        "Section 8(10) requires a readily available grievance mechanism, and "
        "Rule 9(2) requires the response period to be published. An open door "
        "produces no dated record, so the school cannot show a grievance was "
        "answered, and a parent cannot show it was not.",
        "Whether a register exists with dates. An empty register that exists "
        "is worth more than an open door that does not.",
    ),
    "F3": (
        "The school knows what systems it runs. The ERP, the biometric machine "
        "and the transport app are hardly secret, and listing them changes "
        "nothing about how they operate.",
        "Section 8(1) makes the school accountable for all processing, "
        "including through processors. Nothing can be governed that has not "
        "been listed, and the systems that surface only when the list is "
        "drawn up are the dangerous ones - the exam portal a teacher signed up "
        "for, the WhatsApp groups holding parent numbers, the old laptop with "
        "the fee database on it.",
        "Sit down and write the list. What you discover in the last twenty "
        "minutes of writing it is the reason the obligation exists.",
    ),
    "F4": (
        "Teachers are professionals who handle children's information "
        "responsibly every day, and the school trusts them to do so.",
        "Most school data incidents are not attacks. They are a class list "
        "forwarded to a parent WhatsApp group, a mark sheet photographed, an "
        "address list emailed to a vendor. Professional good faith does not "
        "substitute for knowing the rule, and section 8(5) makes the safeguard "
        "the school's obligation, not the teacher's instinct.",
        "Whether an attendance sheet exists for a briefing in the last twelve "
        "months, and whether a one-page rule on sharing student data exists at "
        "all.",
    ),

    "S1": (
        "The ERP came configured this way and the school uses the fields it "
        "needs. The vendor built it for schools, so the fields must be "
        "standard requirements.",
        "The vendor's default is not a lawful basis. Consent extends only to "
        "data necessary for the stated purpose, and a field that exists "
        "because it shipped with the product has no purpose behind it. The "
        "columns that accumulate this way - a caste field for a return that "
        "stopped, a free-text remarks box - are exactly the ones that hurt "
        "in a breach.",
        "Export the student master and put the purpose beside every column. "
        "The blank cells in that second column are the finding, and the "
        "exercise takes an afternoon.",
    ),
    "S2": (
        "Former students come back for transfer certificates, bonafide "
        "letters and mark sheets years later, so the school cannot simply "
        "delete them. In any case the ERP has no delete button.",
        "Retention for a documented purpose is lawful; retention because "
        "deletion was never attempted is not. A transfer certificate needs a "
        "name, a date and a result - not a parent's mobile number, bank "
        "details and medical notes held indefinitely. That the vendor "
        "provides no deletion route is a procurement failure the school "
        "answers for under section 8(1), not a defence.",
        "Ask the vendor in writing how a record is erased, fix a period per "
        "record class, and run the first deletion. Until one has actually "
        "been run, the control does not exist.",
    ),
    "S3": (
        "The books of account must be preserved under the Income-tax and "
        "Companies Act rules. The school has no choice about keeping fee "
        "receipts, and the auditor needs the name against the receipt.",
        "Statutory preservation is a lawful basis and nobody disputes it. Two "
        "things still follow. The school must record that a leaver erased "
        "from the ERP still exists in the ledger, so it does not tell a "
        "parent the data is gone when it is not. And it should ask whether "
        "the ledger needs the child's name at all, since a receipt number "
        "reconciling to the ERP gives the same audit trail in a system fewer "
        "people can open.",
        "Whether the retention schedule names both systems and both periods. "
        "This is a documentation fix, not an accounting one.",
    ),
    "S4": (
        "The learning platform is a teaching tool. Teachers set up their own "
        "classes because that is how it is meant to work, and the platform "
        "is free.",
        "Free is a pricing model, not an absence of processing. The platform "
        "holds student work, attendance and assessment and is a processor "
        "engaged by the school, so section 8(2) requires a valid contract "
        "and section 8(1) leaves the school answerable - including for the "
        "classes nobody approved, on accounts nobody can close when the "
        "teacher leaves.",
        "Whether the school can list every platform actually in use, and "
        "whether it could retrieve or delete a student's content from each "
        "one on request.",
    ),

    # --------------------------------------------------------------- vendors
    "G1": (
        "The school buys standard products from established vendors on the "
        "vendors' own terms. A school of this size has no bargaining power to "
        "rewrite a national vendor's contract.",
        "Section 8(2) permits engagement of a processor only under a valid "
        "contract. Limited bargaining power is a commercial fact, not a legal "
        "defence - it is a reason to ask, to choose a different vendor, or to "
        "record the risk the school has knowingly accepted. Most vendors now "
        "have a data-processing addendum ready and will send it if asked.",
        "Whether a signed data-processing clause exists for each vendor "
        "holding student data. This is a document-production question, not an "
        "argument.",
    ),
    "G2": (
        "The scripts on the website are standard tools that every site uses. "
        "The school did not choose them individually; the web designer "
        "installed them.",
        "Every third-party script loading on a school page discloses the "
        "visitor's data to that third party. Sections 5 and 6 require them to "
        "be named in the notice and consented to, and the school - not the web "
        "designer - is the Data Fiduciary answerable for them.",
        "Compare the list of scripts the scan found against the list named in "
        "the policy. The difference is the finding.",
    ),
    "G3": (
        "Where a vendor hosts its servers is the vendor's business, and the "
        "school has no visibility into it.",
        "Section 16 permits transfer outside India except to a restricted "
        "territory, so the position is likely to be lawful - but the school "
        "cannot say so if it does not know. Asking the question in writing "
        "costs one email per vendor and converts an unknown into a documented "
        "position.",
        "Whether the school holds a written answer from each vendor. The "
        "answer itself is rarely the problem; not having asked is.",
    ),

    # ------------------------------------------------- core systems and AI
    "S1": (
        "The ERP was configured by the vendor to cover what schools "
        "generally need, and every field is there because some form or "
        "government return once asked for it.",
        "Consent extends only to data necessary for the specified purpose. A "
        "field added for one return in 2019 and populated ever since is not "
        "covered by that return. Aadhaar and caste in particular need a "
        "statutory reason the school can name, not an inherited default.",
        "Print the column list and write the purpose beside each one. The "
        "columns where the purpose stays blank are the finding, and the "
        "vendor can usually switch them off in an afternoon.",
    ),
    "S2": (
        "The school keeps former students' records because a transfer "
        "certificate or a verification request can arrive years later, and "
        "the ERP has no delete function in any case.",
        "Retention required by law is permitted; retention because the "
        "software has no delete button is not a legal basis. Section 8(7) "
        "requires erasure once the purpose is spent, and the absence of a "
        "feature is a reason to ask the vendor for one, not a defence.",
        "Ask the vendor in writing how deletion is performed, fix a period "
        "per record class, and run it once. A school that has never deleted "
        "anything cannot claim a retention policy exists.",
    ),
    "S3": (
        "The accounts are the accountant's domain, are kept under the "
        "Income-tax Act and the Companies Act, and have nothing to do with "
        "data protection.",
        "Fee ledgers and salary masters carry names, addresses, phone "
        "numbers, PAN and bank particulars of parents and staff. Statutory "
        "retention of books does not displace the security, access and "
        "grievance duties, and adults attract no children's exemption at "
        "all. It is usually the least governed system in the building.",
        "Whether the accounting system appears in the register of "
        "processing, and who can export a party master to Excel.",
    ),
    "S4": (
        "Staff use ordinary productivity tools to work faster, as every "
        "profession now does. The school cannot police every piece of "
        "software a teacher opens.",
        "Where a tool receives children's personal data the school is "
        "disclosing that data to a third party, usually hosted abroad, "
        "usually on consumer terms permitting the provider to use the input. "
        "Section 8(2) requires a contract and section 8(1) leaves the school "
        "answerable. Not knowing it happened is the finding, not the excuse.",
        "Whether a list exists of the AI tools permitted for school work, on "
        "what terms, and whether anyone has read those terms.",
    ),
}

# Domain-level fallback, so a newly added obligation is never left with no
# panel at all. Anything landing here should be given its own entry above.
DOMAIN_FALLBACK: dict[str, tuple[str, str, str]] = {
    "Notice and transparency": (
        "The school communicates with parents through established channels "
        "and they are well informed in practice.",
        "The Act requires notice in a particular form, capable of being read "
        "on its own, and the Rules do not defer section 5.",
        "Whether one readable document exists today.",
    ),
    "Consent": (
        "Parents consent to the school's processing when they enrol their "
        "child.",
        "Consent must be specific, informed and unambiguous, and limited to "
        "what is necessary for the stated purpose.",
        "Whether the consent artefact can be produced for a named student.",
    ),
    "Children's data": (
        "The Fourth Schedule relieves an educational institution of sections "
        "9(1) and 9(3) for academic activity and student safety.",
        "The exemption is conditional and purpose-bound, and the burden of "
        "establishing it is on the school.",
        "Whether each activity sits in 'academic', 'safety' or 'neither'.",
    ),
    "Security and breach": (
        "The school relies on commercial vendors for security and the "
        "procedural Rules are not yet in force.",
        "Section 8(5) applies now, and responsibility is not outsourced with "
        "the system.",
        "Whether the school could answer, within a day, who was affected.",
    ),
    "Retention and erasure": (
        "Education regulations require school records to be retained.",
        "Retention required by law is permitted; retention by default is not.",
        "Whether a written schedule names a basis for each period.",
    ),
    "Governance and grievance": (
        "The school is approachable and parents reach it easily.",
        "The Act requires a published contact and a recorded mechanism.",
        "Whether a published address and a dated register exist.",
    ),
    "Processors and third parties": (
        "The school buys standard products on vendors' standard terms.",
        "Section 8(2) permits a processor only under a valid contract.",
        "Whether a signed clause exists per vendor.",
    ),
    "Core systems and AI": (
        "The systems were set up by vendors and do what schools generally do.",
        "The school is the Data Fiduciary for everything in them, including "
        "what a vendor or an AI tool does on its behalf.",
        "Whether the system appears in the register of processing at all.",
    ),
}


def _risk(finding) -> str:
    ob = by_id(finding.obligation_id)
    if finding.status == GAP and ob.weight >= 6:
        return "high"
    if finding.status == GAP:
        return "medium"
    if finding.status == PARTIAL and ob.weight >= 6:
        return "medium"
    return "low"


def build_perspectives(findings, limit: int = 10) -> list[PerspectivePair]:
    """
    Produce a two-panel analysis for the findings that are actually contested -
    the gaps and partials. A met obligation needs no argument.
    """
    material = [f for f in findings if f.status in (GAP, PARTIAL)]
    material.sort(key=lambda f: ({GAP: 0, PARTIAL: 1}[f.status], -f.weight))

    pairs: list[PerspectivePair] = []
    for finding in material[:limit]:
        argument = ARGUMENTS.get(finding.obligation_id)
        source = "obligation"
        if argument is None:
            argument = DOMAIN_FALLBACK.get(
                finding.domain,
                ("No institutional argument is recorded for this obligation.",
                 "No regulatory argument is recorded for this obligation.",
                 "A document either exists or it does not."))
            source = "domain"
        institution, regulator, decider = argument

        facts = [finding.rationale]
        facts.extend(finding.evidence[:4])
        pairs.append(PerspectivePair(
            obligation_id=finding.obligation_id,
            title=finding.title,
            provision=finding.provision,
            agreed_facts=[f for f in facts if f],
            institution_position=institution,
            regulator_position=regulator,
            what_decides_it=decider,
            residual_risk=_risk(finding),
            argument_source=source,
        ))
    return pairs
