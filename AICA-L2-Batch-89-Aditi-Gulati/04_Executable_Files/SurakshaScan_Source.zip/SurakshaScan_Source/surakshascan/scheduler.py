"""
The recurring re-scan - Day 1's scheduled task, with Day 1's separate-approval
rule built in.

A school's website changes: a new gallery page, a marketing pixel added by an
agency, a policy quietly replaced. A readiness review that happens once is a
document; one that repeats is a control.

What this does NOT do is send anything. It re-scans, compares against the last
evidence file, writes a report when something moved, and leaves a file for a
person to look at and forward. External actions get a distinct approval step.

Two ways to schedule, both documented in docs/SCHEDULING.md:
  * Windows Task Scheduler / cron, calling `surakshascan watch`
  * the AI assistant's own scheduled task, calling the same command
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from . import evidence
from .config import CONFIG_DIR


@dataclass
class WatchOutcome:
    institution: str
    previous_score: float | None
    current_score: float
    delta: float | None
    changed: bool
    reason: str
    report_path: str = ""
    approved_to_send: bool = False   # only a human sets this


PENDING_DIR = CONFIG_DIR / "pending_review"


def queue_for_approval(outcome: WatchOutcome) -> Path:
    """
    Park the result where a person will see it. Nothing leaves the machine
    until someone opens this and decides to send it.
    """
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = PENDING_DIR / f"{evidence.slugify(outcome.institution)}_{stamp}.json"
    path.write_text(json.dumps({
        "institution": outcome.institution,
        "previous_score": outcome.previous_score,
        "current_score": outcome.current_score,
        "delta": outcome.delta,
        "reason": outcome.reason,
        "report_path": outcome.report_path,
        "approved_to_send": False,
        "note": ("This result has NOT been sent to anyone. Review it, then "
                 "forward it yourself if it should go out."),
    }, indent=2), encoding="utf-8")
    return path


def list_pending() -> list[dict]:
    if not PENDING_DIR.exists():
        return []
    out = []
    for path in sorted(PENDING_DIR.glob("*.json"), reverse=True):
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        record["file"] = str(path)
        out.append(record)
    return out
