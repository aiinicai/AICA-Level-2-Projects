"""
Command line interface - what the scheduler, the MCP server and the n8n
workflow all call, so there is one code path and one set of results.

    python -m surakshascan.cli scan  --name "X School" --url https://x.edu.in
    python -m surakshascan.cli scan  --name "X" --url https://x --docx out.docx
    python -m surakshascan.cli watch --name "X" --url https://x --threshold 5
    python -m surakshascan.cli compare --evidence-dir ~/.surakshascan/evidence
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import evidence, report_docx, report_html, report_xlsx, scoring
from .authorisation import Authorisation, AuthorisationError
from .config import Settings
from .engine import run_review


def _run(args) -> object:
    settings = Settings.load()
    if args.timeout:
        settings.request_timeout = args.timeout
    extras = [u.strip() for u in (args.extra or "").split(",") if u.strip()]
    auth = Authorisation(authorised_by=args.authorised_by or "")
    return run_review(
        args.name, args.url, extras, settings=settings, use_ai=args.ai,
        document_paths=args.document or [],
        authorisation=auth,
        progress=(lambda m: print(f"  {m}", file=sys.stderr)) if args.verbose
        else None)


def cmd_scan(args) -> int:
    review = _run(args)
    assessment = review.assessment
    if args.docx:
        print("Word report:", report_docx.generate(review, args.docx))
    if args.xlsx:
        print("Excel workbook:", report_xlsx.generate(review, args.xlsx))
    if args.html:
        print("HTML dashboard:", report_html.generate(review, args.html))
    if args.json:
        Path(args.json).write_text(
            json.dumps(review.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8")
        print("JSON:", args.json)

    print(f"\n{assessment.institution_name}: {assessment.score:.0f}/100 "
          f"({assessment.band})")
    print(f"Coverage {assessment.coverage_percent:.0f}% · "
          f"{assessment.counts.get('GAP', 0)} gaps · "
          f"{assessment.counts.get('PARTIAL', 0)} partly met")
    print(f"Evidence: {review.evidence_path}")
    print("\nTop actions:")
    for item in assessment.remediation[:5]:
        print(f"  {item.rank}. [{item.obligation_id}] {item.title} "
              f"(+{item.score_gain:.1f}, {item.effort} effort)")
    return 0


def cmd_watch(args) -> int:
    """
    Re-scan and report only if something moved. This is what the scheduled
    task runs, so a quiet quarter produces no noise.
    """
    previous = evidence.history(args.name)
    review = _run(args)
    score = review.assessment.score
    if not previous or previous[0].get("score") is None:
        print(json.dumps({"changed": True, "reason": "first scan",
                          "score": score,
                          "evidence": review.evidence_path}))
        return 0
    before = float(previous[0]["score"])
    delta = round(score - before, 1)
    changed = abs(delta) >= args.threshold
    payload = {
        "changed": changed,
        "previous_score": before,
        "score": score,
        "delta": delta,
        "band": review.assessment.band,
        "new_gaps": [f.obligation_id for f in review.findings
                     if f.status == "GAP"],
        "evidence": review.evidence_path,
        "reason": (f"score moved {delta:+.1f} points" if changed
                   else f"score moved {delta:+.1f}, below the "
                        f"{args.threshold} point threshold"),
    }
    if changed and args.docx:
        payload["docx"] = report_docx.generate(review, args.docx)
    print(json.dumps(payload, indent=2))
    return 0


def cmd_compare(args) -> int:
    directory = Path(args.evidence_dir) if args.evidence_dir else None
    records = evidence.history(directory=directory)
    latest: dict[str, dict] = {}
    for record in records:
        latest.setdefault(record["institution"], record)
    rows = [{"institution": k, "score": v["score"], "band": v["band"],
             "written_at": v["written_at"]}
            for k, v in latest.items() if v["score"] is not None]
    rows.sort(key=lambda r: -r["score"])
    if not rows:
        print("No scored evidence files found.")
        return 1
    average = round(sum(r["score"] for r in rows) / len(rows), 1)
    width = max(len(r["institution"]) for r in rows)
    print(f"{'Institution'.ljust(width)}  Score  Band")
    for row in rows:
        print(f"{row['institution'].ljust(width)}  {row['score']:5.1f}  "
              f"{row['band']}")
    print(f"\nPeer average: {average}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="surakshascan",
        description="DPDP readiness scanner for educational institutions.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    def common(sub):
        sub.add_argument("--name", required=True, help="institution name")
        sub.add_argument("--url", required=True, help="website address")
        sub.add_argument("--extra", help="comma-separated extra pages")
        sub.add_argument("--document", action="append",
                         help="a PDF or image to review; repeatable")
        sub.add_argument("--ai", action="store_true",
                         help="also run the AI policy analysis")
        sub.add_argument("--timeout", type=int, help="request timeout, seconds")
        sub.add_argument("--verbose", action="store_true")
        sub.add_argument("--authorised-by",
                         help="name and designation of the person who "
                              "authorised the review (required)")

    scan = subparsers.add_parser("scan", help="run a full review")
    common(scan)
    scan.add_argument("--docx"); scan.add_argument("--xlsx")
    scan.add_argument("--html"); scan.add_argument("--json")
    scan.set_defaults(func=cmd_scan)

    watch = subparsers.add_parser(
        "watch", help="re-scan and report only if the score moved")
    common(watch)
    watch.add_argument("--threshold", type=float, default=5.0,
                       help="points of movement worth reporting")
    watch.add_argument("--docx")
    watch.set_defaults(func=cmd_watch)

    compare = subparsers.add_parser(
        "compare", help="benchmark every institution scanned so far")
    compare.add_argument("--evidence-dir")
    compare.set_defaults(func=cmd_compare)
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except AuthorisationError as exc:
        print(f"\nRefused. {exc}\n", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
