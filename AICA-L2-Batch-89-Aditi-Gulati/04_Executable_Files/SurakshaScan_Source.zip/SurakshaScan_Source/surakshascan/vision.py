"""
Vision review - the Day 2 computer-vision method applied to the documents a
website scan cannot reach.

Most of a school's DPDP exposure is on paper: the admission form, the consent
slip in the diary, the CCTV signage at the gate, the transport app screenshot.
This module takes images and PDFs of those artefacts, extracts what is on
them, and checks them against the same obligation catalogue.

Two modes:

* Offline - PyMuPDF extracts the text layer of a PDF and the deterministic
  matchers run over it. No network, no key, fully reproducible.
* Vision - when a key is present, the image is described by the model under
  the same discipline as the text analyser: extract only what is visible,
  flag uncertainty, never infer a clause that is not there.

Every extraction carries the source file name and the retrieval date, so a
row in the report traces back to the document it came from.
"""

from __future__ import annotations

import base64
import mimetypes
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

from .config import Settings
from .dpdp_catalogue import CATALOGUE, GAP, MET, PARTIAL

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
PDF_SUFFIXES = {".pdf"}

# What a consent artefact has to contain to be worth anything.
CONSENT_ARTEFACT_ELEMENTS = {
    "identifies the parent or guardian signing":
        ("parent", "guardian", "father", "mother"),
    "names the categories of data collected":
        ("data", "information", "particulars", "details"),
    "states the purpose of the processing":
        ("purpose", "in order to", "for the purpose", "used for"),
    "offers a way to withdraw consent":
        ("withdraw", "revoke", "opt out"),
    "separately addresses photographs or media":
        ("photograph", "photo", "image", "media", "video"),
    "is dated": ("date", "dated", "dd/mm", "day of"),
    "carries a signature block":
        ("signature", "signed", "sign here", "sd/-"),
    "names a contact for questions":
        ("contact", "email", "@", "phone", "officer"),
}


@dataclass
class DocumentEvidence:
    file_name: str
    file_type: str
    extracted_at: str
    method: str                       # pymupdf | vision | unavailable
    pages: int = 0
    characters: int = 0
    text: str = ""
    elements_present: list[str] = field(default_factory=list)
    elements_absent: list[str] = field(default_factory=list)
    uncertainty: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict:
        data = asdict(self)
        # The full text goes to the evidence store, not into the report body.
        data["text"] = self.text[:2000]
        return data


VISION_PROMPT = (
    "You are reviewing a scanned document from an Indian school as part of a "
    "data protection readiness review under the DPDP Act, 2023.\n\n"
    "Transcribe only what is actually visible in the image. Then answer:\n"
    "1. What kind of document is this (admission form, consent slip, notice "
    "board, CCTV signage, app screenshot, other)?\n"
    "2. What categories of personal data does it collect or display?\n"
    "3. Does it contain a consent clause? Quote it exactly if so.\n"
    "4. Does it identify who to contact about the data?\n"
    "5. What is illegible or uncertain?\n\n"
    "Do not infer text that is not visible. Where you cannot read something, "
    "say 'illegible' rather than guessing. Reply as JSON with keys: "
    "document_type, data_categories, consent_clause, contact, uncertainty, "
    "full_transcription."
)


def _check_elements(text: str) -> tuple[list[str], list[str]]:
    lowered = re.sub(r"\s+", " ", text).lower()
    present, absent = [], []
    for element, cues in CONSENT_ARTEFACT_ELEMENTS.items():
        (present if any(c in lowered for c in cues) else absent).append(element)
    return present, absent


def extract_pdf(path: Path) -> DocumentEvidence:
    ev = DocumentEvidence(
        file_name=path.name, file_type="pdf",
        extracted_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        method="pymupdf")
    try:
        import fitz  # PyMuPDF
    except ImportError:
        ev.method = "unavailable"
        ev.error = ("PyMuPDF is not installed, so the PDF text layer could not "
                    "be read. Install pymupdf to enable document review.")
        return ev
    try:
        with fitz.open(path) as doc:
            ev.pages = doc.page_count
            chunks = [page.get_text() for page in doc]
        ev.text = "\n".join(chunks)
        ev.characters = len(ev.text)
        if ev.characters < 40:
            ev.uncertainty.append(
                "This PDF has almost no text layer, so it is probably a scan. "
                "Review it as an image, or run OCR, before relying on the "
                "result.")
        ev.elements_present, ev.elements_absent = _check_elements(ev.text)
    except Exception as exc:
        ev.error = f"{type(exc).__name__}: {exc}"
    return ev


def extract_image(path: Path, settings: Settings | None = None) -> DocumentEvidence:
    settings = settings or Settings()
    ev = DocumentEvidence(
        file_name=path.name, file_type=path.suffix.lstrip("."),
        extracted_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        method="vision", pages=1)

    from .ai_analyzer import resolve_api_key, _extract_json
    key = resolve_api_key(settings)
    if not key:
        ev.method = "unavailable"
        ev.error = ("No API key was available, so the image was not read. "
                    "Transcribe it manually and re-run, or set the key.")
        return ev
    try:
        import anthropic
    except ImportError:
        ev.method = "unavailable"
        ev.error = "The anthropic package is not installed."
        return ev

    media_type = mimetypes.guess_type(path.name)[0] or "image/png"
    try:
        encoded = base64.standard_b64encode(path.read_bytes()).decode("ascii")
        client = anthropic.Anthropic(api_key=key)
        response = client.messages.create(
            model=settings.ai_model, max_tokens=2500, temperature=0,
            messages=[{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64",
                                             "media_type": media_type,
                                             "data": encoded}},
                {"type": "text", "text": VISION_PROMPT},
            ]}])
        raw = "".join(b.text for b in response.content
                      if getattr(b, "type", "") == "text")
    except Exception as exc:
        ev.error = f"{type(exc).__name__}: {exc}"
        return ev

    payload = _extract_json(raw) or {}
    ev.text = str(payload.get("full_transcription", "") or raw)
    ev.characters = len(ev.text)
    unc = payload.get("uncertainty")
    if isinstance(unc, list):
        ev.uncertainty.extend(str(u) for u in unc)
    elif unc:
        ev.uncertainty.append(str(unc))
    ev.elements_present, ev.elements_absent = _check_elements(ev.text)
    return ev


def review_documents(paths, settings: Settings | None = None
                     ) -> list[DocumentEvidence]:
    """Review a list of supporting documents and return structured evidence."""
    results: list[DocumentEvidence] = []
    for raw_path in paths:
        path = Path(raw_path)
        if not path.exists():
            results.append(DocumentEvidence(
                file_name=str(raw_path), file_type="unknown",
                extracted_at=datetime.now(timezone.utc).isoformat(
                    timespec="seconds"),
                method="unavailable", error="file not found"))
            continue
        suffix = path.suffix.lower()
        if suffix in PDF_SUFFIXES:
            results.append(extract_pdf(path))
        elif suffix in IMAGE_SUFFIXES:
            results.append(extract_image(path, settings))
        else:
            results.append(DocumentEvidence(
                file_name=path.name, file_type=suffix.lstrip("."),
                extracted_at=datetime.now(timezone.utc).isoformat(
                    timespec="seconds"),
                method="unavailable",
                error=f"unsupported file type '{suffix}'"))
    return results


def summarise(documents: list[DocumentEvidence]) -> dict:
    """A short roll-up the report and the dashboard can both use."""
    reviewed = [d for d in documents if d.method != "unavailable" and not d.error]
    missing_counts: dict[str, int] = {}
    for doc in reviewed:
        for element in doc.elements_absent:
            missing_counts[element] = missing_counts.get(element, 0) + 1
    return {
        "submitted": len(documents),
        "reviewed": len(reviewed),
        "not_reviewed": len(documents) - len(reviewed),
        "most_commonly_missing": sorted(
            missing_counts.items(), key=lambda kv: -kv[1])[:5],
        "uncertainty_flags": [
            {"file": d.file_name, "note": u}
            for d in documents for u in d.uncertainty],
    }
