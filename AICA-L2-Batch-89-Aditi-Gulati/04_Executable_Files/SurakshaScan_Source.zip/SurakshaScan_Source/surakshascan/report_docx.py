"""
The Word report - overview page with charts, then the detail.

Structure follows the audit working-paper convention from Day 4: an overview
the management committee reads, then section-by-section detail the reviewer
defends, then the evidence appendix that lets a third party re-perform it.
"""

from __future__ import annotations

import tempfile
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from . import charts
from .dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from .questionnaire import QUESTIONS, TABS

INK = RGBColor(0x1F, 0x3B, 0x57)
MUTED = RGBColor(0x5A, 0x6B, 0x78)
STATUS_WORDS = {MET: "Met", PARTIAL: "Partly met", GAP: "Gap",
                NOT_ASSESSED: "Not assessed"}
STATUS_COLOUR = {MET: RGBColor(0x2E, 0x7D, 0x5B),
                 PARTIAL: RGBColor(0xC9, 0x8A, 0x16),
                 GAP: RGBColor(0xB3, 0x32, 0x1E),
                 NOT_ASSESSED: RGBColor(0x9A, 0xA5, 0xAD)}

DISCLAIMER = (
    "This report records a point-in-time readiness review. It is not a "
    "certificate of compliance with the Digital Personal Data Protection Act, "
    "2023 or the Digital Personal Data Protection Rules, 2025, and it is not "
    "legal advice. Automated checks cover publicly accessible pages only; they "
    "do not reach logged-in areas, internal systems, or documents that are not "
    "published. Absence of a finding is not evidence of absence. Every legal "
    "reference should be verified against the notified text before the "
    "institution acts on it."
)


def _small(paragraph, text, colour=MUTED, size=8.5, italic=False):
    run = paragraph.add_run(text)
    run.font.size = Pt(size)
    run.font.color.rgb = colour
    run.font.italic = italic
    return run


def _kv_table(doc, rows):
    table = doc.add_table(rows=0, cols=2)
    table.style = "Light List Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    for key, value in rows:
        cells = table.add_row().cells
        cells[0].text = str(key)
        cells[1].text = str(value)
        for para in cells[0].paragraphs:
            for run in para.runs:
                run.font.bold = True
                run.font.size = Pt(9)
        for para in cells[1].paragraphs:
            for run in para.runs:
                run.font.size = Pt(9)
    return table


def generate(review, output_path, prepared_by: str = "",
             chart_dir: str | None = None) -> str:
    scan = review.scan
    assessment = review.assessment
    findings = review.findings
    output_path = Path(output_path)
    tmp = Path(chart_dir or tempfile.mkdtemp(prefix="surakshascan_charts_"))

    doc = Document()
    for section in doc.sections:
        section.left_margin = section.right_margin = Inches(0.9)

    # ------------------------------------------------------------ overview
    title = doc.add_heading("DPDP Readiness Report", level=0)
    for run in title.runs:
        run.font.color.rgb = INK

    name = doc.add_paragraph()
    run = name.add_run(scan.institution_name)
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.color.rgb = INK

    meta = doc.add_paragraph()
    _small(meta, f"{scan.base_url}\n")
    _small(meta, f"Scanned {scan.scanned_at} · Report {date.today():%d %B %Y}")
    if prepared_by:
        _small(meta, f" · Prepared by {prepared_by}")
    if review.evidence_path:
        _small(meta, f"\nEvidence file: {Path(review.evidence_path).name}")

    _kv_table(doc, [
        ("Readiness score", f"{assessment.score:.0f} / 100  ({assessment.band})"),
        ("What that means", assessment.band_note),
        ("Catalogue coverage", f"{assessment.coverage_percent:.0f}% of the "
                               f"weighted obligation set could be assessed"),
        ("Obligations met", assessment.counts.get(MET, 0)),
        ("Partly met", assessment.counts.get(PARTIAL, 0)),
        ("Gaps", assessment.counts.get(GAP, 0)),
        ("Not assessed", assessment.counts.get(NOT_ASSESSED, 0)),
        ("Authorisation",
         review.authorisation.summary()
         if getattr(review, "authorisation", None) else "not recorded"),
        ("AI layer", ("used - " + review.ai.model) if (review.ai and review.ai.used)
         else "not used; all ratings are from the deterministic rules engine"),
    ])

    donut = charts.donut_of_statuses(assessment.counts, assessment.score,
                                     tmp / "donut.png")
    bars = charts.bar_of_domains(assessment.domains, tmp / "domains.png")
    para = doc.add_paragraph()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.add_run().add_picture(donut, width=Inches(3.2))
    doc.add_picture(bars, width=Inches(6.4))

    caution = doc.add_paragraph()
    _small(caution, DISCLAIMER, italic=True)

    # ------------------------------------------------- what to do first
    doc.add_page_break()
    section = iter(range(1, 20))
    doc.add_heading(f"{next(section)}. What to do first", level=1)
    doc.add_paragraph(
        "Ordered by the improvement each action makes to the readiness score, "
        "with the cheapest action first where the impact is equal.")
    table = doc.add_table(rows=1, cols=6)
    table.style = "Light Grid Accent 1"
    for cell, header in zip(table.rows[0].cells,
                            ("#", "Obligation", "Provision", "Status",
                             "Effort", "Score gain")):
        cell.text = header
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.bold = True
                run.font.size = Pt(9)
    for item in assessment.remediation[:15]:
        cells = table.add_row().cells
        values = (str(item.rank), f"{item.obligation_id} {item.title}",
                  f"{item.provision} ({item.provision_status})",
                  STATUS_WORDS.get(item.status, item.status),
                  item.effort.title(), f"+{item.score_gain:.1f}")
        for cell, value in zip(cells, values):
            cell.text = value
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.size = Pt(8.5)

    doc.add_heading("Actions in detail", level=2)
    for item in assessment.remediation[:15]:
        para = doc.add_paragraph(style="List Number")
        run = para.add_run(f"{item.obligation_id} — {item.title}. ")
        run.font.bold = True
        run.font.size = Pt(9.5)
        detail = para.add_run(item.action)
        detail.font.size = Pt(9.5)
        note = doc.add_paragraph()
        _small(note, f"{item.provision} · {item.provision_status} · "
                     f"effort: {item.effort} · domain: {item.domain}")

    if assessment.due_now:
        doc.add_heading("Open items under provisions already in force", level=2)
        for label in assessment.due_now[:20]:
            doc.add_paragraph(label, style="List Bullet")
    if assessment.due_by_may_2027:
        doc.add_heading("Open items under provisions commencing 14 May 2027",
                        level=2)
        for label in assessment.due_by_may_2027[:20]:
            doc.add_paragraph(label, style="List Bullet")

    # --------------------------------------------------- findings by domain
    doc.add_page_break()
    doc.add_heading(f"{next(section)}. Findings against each obligation", level=1)
    current_domain = None
    for finding in findings:
        if finding.domain != current_domain:
            current_domain = finding.domain
            doc.add_heading(current_domain, level=2)
        head = doc.add_paragraph()
        run = head.add_run(f"{finding.obligation_id}  {finding.title}")
        run.font.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = INK
        status_para = doc.add_paragraph()
        status_run = status_para.add_run(
            STATUS_WORDS.get(finding.status, finding.status))
        status_run.font.bold = True
        status_run.font.size = Pt(9)
        status_run.font.color.rgb = STATUS_COLOUR.get(finding.status, MUTED)
        _small(status_para,
               f"   {finding.provision} ({finding.provision_status}) · "
               f"weight {finding.weight} · confidence {finding.confidence} · "
               f"decided by {finding.decided_by}")
        body = doc.add_paragraph(finding.rationale)
        for run in body.runs:
            run.font.size = Pt(9.5)
        for line in finding.evidence[:6]:
            item = doc.add_paragraph(str(line)[:500], style="List Bullet")
            for run in item.runs:
                run.font.size = Pt(8.5)
        if finding.school_note:
            note = doc.add_paragraph()
            _small(note, "Note for schools: " + finding.school_note, italic=True)

    # ------------------------------------------------ two-perspective panel
    if review.perspectives:
        doc.add_page_break()
        doc.add_heading(f"{next(section)}. Two views of the same facts", level=1)
        doc.add_paragraph(
            "The facts in each panel are identical and come from the findings "
            "above. Only the reading changes. This is the argument the "
            "institution can expect to have, set out before it happens.")
        for pair in review.perspectives:
            doc.add_heading(f"{pair.obligation_id} — {pair.title}", level=2)
            _small(doc.add_paragraph(),
                   f"{pair.provision} · residual risk: {pair.residual_risk}")
            doc.add_paragraph("Agreed facts", style="Intense Quote")
            for fact in pair.agreed_facts[:5]:
                doc.add_paragraph(str(fact)[:400], style="List Bullet")
            table = doc.add_table(rows=2, cols=2)
            table.style = "Light Grid Accent 1"
            table.rows[0].cells[0].text = "The institution's position"
            table.rows[0].cells[1].text = "The parent's or the Board's position"
            for cell in table.rows[0].cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.font.bold = True
                        run.font.size = Pt(9)
            table.rows[1].cells[0].text = pair.institution_position
            table.rows[1].cells[1].text = pair.regulator_position
            for cell in table.rows[1].cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.font.size = Pt(9)
            decider = doc.add_paragraph()
            run = decider.add_run("What decides it: ")
            run.font.bold = True
            run.font.size = Pt(9)
            run2 = decider.add_run(pair.what_decides_it)
            run2.font.size = Pt(9)

    # ------------------------------------------------------ working paper
    if review.working_paper_stats:
        doc.add_page_break()
        doc.add_heading(f"{next(section)}. Internal practices working paper", level=1)
        stats = review.working_paper_stats
        doc.add_paragraph(
            f"{stats['by_status']['Completed']} of {stats['total']} lines "
            f"completed ({stats['percent_complete']:.0f}% of assessable lines).")
        wp_chart = charts.bar_of_working_paper(stats, tmp / "workingpaper.png")
        doc.add_picture(wp_chart, width=Inches(6.4))
        for tab in TABS:
            doc.add_heading(tab, level=2)
            table = doc.add_table(rows=1, cols=4)
            table.style = "Light Grid Accent 1"
            for cell, header in zip(table.rows[0].cells,
                                    ("Ref", "Question", "Status", "Evidence to see")):
                cell.text = header
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.font.bold = True
                        run.font.size = Pt(9)
            for question in (q for q in QUESTIONS if q.tab == tab):
                cells = table.add_row().cells
                for cell, value in zip(cells, (question.id, question.text, "",
                                               question.evidence_to_see)):
                    cell.text = value
                    for para in cell.paragraphs:
                        for run in para.runs:
                            run.font.size = Pt(8.5)

    # --------------------------------------------------- documents reviewed
    if review.documents:
        doc.add_page_break()
        doc.add_heading(f"{next(section)}. Documents reviewed", level=1)
        for document in review.documents:
            doc.add_heading(document.file_name, level=2)
            _small(doc.add_paragraph(),
                   f"{document.file_type} · read by {document.method} · "
                   f"{document.extracted_at} · {document.characters} characters")
            if document.error:
                doc.add_paragraph("Not reviewed: " + document.error)
                continue
            if document.elements_present:
                doc.add_paragraph("Present:")
                for element in document.elements_present:
                    doc.add_paragraph(element, style="List Bullet")
            if document.elements_absent:
                doc.add_paragraph("Not found:")
                for element in document.elements_absent:
                    doc.add_paragraph(element, style="List Bullet")
            for note in document.uncertainty:
                para = doc.add_paragraph()
                _small(para, "Uncertainty: " + note, italic=True)

    # ------------------------------------------------------------- AI layer
    doc.add_page_break()
    doc.add_heading(f"{next(section)}. Chatbots and the AI layer", level=1)
    components = getattr(review.scan, "ai_components", []) or []
    if components:
        doc.add_heading("Chat and AI components on the website", level=2)
        for component in components:
            doc.add_paragraph(
                f"{component.get('vendor', 'unknown')} on "
                f"{component.get('found_on', '')}", style="List Bullet")
        doc.add_paragraph(
            "A chat or assistant component receives whatever a visitor types, "
            "which on a school site may be a child or a parent. It should be "
            "named in the notice, with a statement of where the conversation "
            "goes and how long it is kept.")

    if review.ai and review.ai.used:
        accepted = [f for f in review.ai.findings if f.accepted]
        rejected = [f for f in review.ai.findings if not f.accepted]
        doc.add_paragraph(
            f"Model {review.ai.model} read the published policy and returned "
            f"{len(review.ai.findings)} findings. {len(accepted)} were accepted "
            f"and {len(rejected)} were rejected by the verification step, which "
            "discards any finding whose quoted passage does not actually appear "
            "in the policy. The AI layer does not affect the score.")
        for finding in accepted[:20]:
            para = doc.add_paragraph()
            run = para.add_run(f"{finding.obligation_id}: "
                               f"{STATUS_WORDS.get(finding.status, finding.status)}. ")
            run.font.bold = True
            run.font.size = Pt(9)
            body = para.add_run(finding.reasoning)
            body.font.size = Pt(9)
            if finding.quotation:
                quote = doc.add_paragraph(f'"{finding.quotation}"',
                                          style="Intense Quote")
                for run in quote.runs:
                    run.font.size = Pt(8.5)
        if rejected:
            doc.add_heading("Rejected by verification", level=2)
            for finding in rejected:
                para = doc.add_paragraph(style="List Bullet")
                _small(para, f"{finding.obligation_id or '(no id)'}: "
                             f"{finding.rejected_because}", size=8.5)
        if review.ai.disagreements:
            doc.add_heading("Where the AI layer and the rules engine differ",
                            level=2)
            for row in review.ai.disagreements:
                doc.add_paragraph(
                    f"{row['obligation_id']}: rules engine says "
                    f"{STATUS_WORDS.get(row['rules_engine'], row['rules_engine'])}, "
                    f"AI layer says "
                    f"{STATUS_WORDS.get(row['ai_layer'], row['ai_layer'])}. "
                    f"{row['note']}", style="List Bullet")
        if review.ai.missing_information:
            doc.add_heading("What the reviewer still needs to obtain", level=2)
            for item in review.ai.missing_information:
                doc.add_paragraph(str(item), style="List Bullet")
    else:
        reason = (review.ai.reason_not_used if review.ai else
                  "The AI layer was not requested for this run.")
        doc.add_paragraph(reason)
        doc.add_paragraph(
            "Every rating in this report is therefore reproducible: the same "
            "website and the same working paper will always produce the same "
            "score.")

    # ----------------------------------------------------------- appendix
    doc.add_page_break()
    doc.add_heading("Appendix A — Scan evidence", level=1)
    _kv_table(doc, [
        ("Pages fetched", len(scan.pages)),
        ("robots.txt", scan.robots_note),
        ("Policy pages read", len(scan.policy_pages)),
        ("Policy source", scan.policy_source_url or "none found"),
        ("Site served over HTTPS", "Yes" if scan.site_is_https else "No"),
        ("Third-party hosts", len(scan.all_third_party_hosts)),
        ("Trackers detected", len(scan.all_trackers)),
        ("Trackers engaging s.9(3)", len(scan.child_risk_trackers)),
        ("Contact addresses found", ", ".join(scan.contact_emails[:6]) or "none"),
        ("Scanner version", scan.scanner_version),
    ])
    if scan.all_trackers:
        doc.add_heading("Trackers", level=2)
        table = doc.add_table(rows=1, cols=3)
        table.style = "Light Grid Accent 1"
        for cell, header in zip(table.rows[0].cells,
                                ("Host", "Category", "Found on")):
            cell.text = header
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.bold = True
                    run.font.size = Pt(9)
        for tracker in scan.all_trackers:
            cells = table.add_row().cells
            for cell, value in zip(cells, (tracker["host"], tracker["category"],
                                           tracker["found_on"])):
                cell.text = str(value)
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.font.size = Pt(8)
    if scan.errors:
        doc.add_heading("Errors during the scan", level=2)
        for err in scan.errors:
            doc.add_paragraph(err, style="List Bullet")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)
    return str(output_path)
