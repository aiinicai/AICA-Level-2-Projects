"""
Polite crawler that gathers the web-side evidence a DPDP assessment needs.

Differences from v1, all of which the rules engine depends on:

* obeys robots.txt and rate-limits itself, because a compliance tool that
  misbehaves on the way in is not a good look;
* follows the site to find the policy page rather than guessing five URLs,
  and then reads the policy text, which v1 never did;
* records TLS, redirect chain, form action scheme and the full third-party
  host list, so security and tracker findings rest on evidence;
* classifies each form field as sensitive, child-related or ordinary;
* returns a structured, JSON-serialisable result with a timestamp so a
  finding can be re-verified later.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

from .config import Settings, USER_AGENT

# Hosts whose presence implies advertising, social or behavioural tracking.
# Split so the report can say why a host matters rather than just naming it.
TRACKER_SIGNATURES: dict[str, str] = {
    "doubleclick.net": "advertising",
    "googlesyndication": "advertising",
    "googleadservices": "advertising",
    "adservice.google": "advertising",
    "facebook.net": "social / advertising",
    "connect.facebook": "social / advertising",
    "fbevents": "advertising pixel",
    "tiktok": "advertising pixel",
    "snap.licdn": "advertising pixel",
    "ads-twitter": "advertising pixel",
    "hotjar": "session recording",
    "clarity.ms": "session recording",
    "fullstory": "session recording",
    "mouseflow": "session recording",
    "google-analytics": "analytics",
    "googletagmanager": "tag manager",
    "gtag/js": "analytics",
    "matomo": "analytics",
    "hubspot": "marketing automation",
    "mailchimp": "marketing automation",
}

# Advertising and session-recording categories are the ones that engage
# section 9(3) when the audience is children.
CHILD_SENSITIVE_CATEGORIES = {
    "advertising", "advertising pixel", "social / advertising",
    "session recording",
}

# One script can match several signatures - fbevents.js matches
# "facebook.net", "connect.facebook" AND "fbevents". Counting it three times
# would overstate the finding, and an inflated number is the first thing a
# reviewer challenges. One entry per distinct script, rated by the most
# serious category it matches.
CATEGORY_SEVERITY = {
    "advertising pixel": 6,
    "advertising": 5,
    "social / advertising": 4,
    "session recording": 3,
    "marketing automation": 2,
    "tag manager": 1,
    "analytics": 0,
}

# AI features embedded in a school website - a chatbot, an admissions
# assistant, a proctoring widget. These are not trackers: they are a channel
# through which a visitor's typed words, possibly a child's, reach a third
# party. They need naming in the notice on their own account.
AI_SIGNATURES: dict[str, str] = {
    "openai.com": "OpenAI API or widget",
    "api.anthropic.com": "Anthropic API",
    "dialogflow": "Google Dialogflow chatbot",
    "chatbase.co": "Chatbase chatbot",
    "tidio": "Tidio chat",
    "intercom": "Intercom messenger",
    "drift.com": "Drift chat",
    "crisp.chat": "Crisp chat",
    "tawk.to": "Tawk.to chat",
    "livechatinc": "LiveChat",
    "botpress": "Botpress chatbot",
    "landbot": "Landbot",
    "voiceflow": "Voiceflow assistant",
    "wati.io": "WATI WhatsApp automation",
    "gallabox": "Gallabox WhatsApp automation",
    "proctor": "online proctoring component",
}

POLICY_URL_HINTS = (
    "privacy", "privacy-policy", "data-protection", "dataprotection",
    "policy", "gdpr", "dpdp", "terms", "cookie",
)
POLICY_TEXT_HINTS = (
    "privacy policy", "privacy notice", "data protection", "data privacy",
    "dpdp", "cookie policy", "terms of use", "terms and conditions",
)
COMMON_POLICY_PATHS = (
    "/privacy-policy", "/privacy", "/privacy-notice", "/data-protection",
    "/data-protection-policy", "/policies/privacy", "/privacy.html",
    "/terms-and-conditions", "/cookie-policy",
)

# Field names that indicate a child's or a sensitive category of data.
SENSITIVE_FIELD_PATTERNS = {
    "aadhaar": "government identifier",
    "aadhar": "government identifier",
    "uid": "government identifier",
    "apaar": "student identifier",
    "udise": "student identifier",
    "pan": "government identifier",
    "dob": "date of birth",
    "date_of_birth": "date of birth",
    "birth": "date of birth",
    "caste": "special category",
    "religion": "special category",
    "category": "possible caste category",
    "blood": "health",
    "medical": "health",
    "allerg": "health",
    "disab": "health",
    "photo": "image of a person",
    "image": "image of a person",
    "bank": "financial",
    "account": "financial",
    "ifsc": "financial",
    "password": "credential",
}
CHILD_FIELD_PATTERNS = ("student", "child", "pupil", "ward", "admission",
                        "class", "grade", "roll")

CONSENT_WORDING = (
    "we use cookies", "accept cookies", "cookie consent", "by continuing",
    "i agree", "i consent", "consent to the processing", "accept all",
)
IMPLIED_CONSENT_WORDING = (
    "by continuing to use", "by using this site", "by browsing", "deemed to",
    "you are deemed", "continued use of", "implies your consent",
)


@dataclass
class PageEvidence:
    url: str
    final_url: str | None = None
    status_code: int | None = None
    reachable: bool = False
    https: bool = False
    redirect_chain: list[str] = field(default_factory=list)
    title: str = ""
    policy_links: list[str] = field(default_factory=list)
    internal_links: list[str] = field(default_factory=list)
    cookie_banner_wording: list[str] = field(default_factory=list)
    implied_consent_wording: list[str] = field(default_factory=list)
    forms: list[dict] = field(default_factory=list)
    trackers: list[dict] = field(default_factory=list)
    third_party_hosts: list[str] = field(default_factory=list)
    iframes: list[str] = field(default_factory=list)
    mailto_addresses: list[str] = field(default_factory=list)
    ai_components: list[dict] = field(default_factory=list)
    text_length: int = 0
    error: str | None = None


@dataclass
class ScanResult:
    institution_name: str
    base_url: str
    scanned_at: str
    scanner_version: str = "2.0.0"
    robots_allowed: bool = True
    robots_note: str = ""
    pages: list[dict] = field(default_factory=list)
    policy_pages: list[dict] = field(default_factory=list)
    policy_text: str = ""
    policy_source_url: str | None = None
    site_is_https: bool = False
    insecure_form_actions: list[str] = field(default_factory=list)
    all_trackers: list[dict] = field(default_factory=list)
    child_risk_trackers: list[dict] = field(default_factory=list)
    all_third_party_hosts: list[str] = field(default_factory=list)
    ai_components: list[dict] = field(default_factory=list)
    contact_emails: list[str] = field(default_factory=list)
    sensitive_fields_seen: list[dict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


class Scanner:
    def __init__(self, settings: Settings | None = None, session=None,
                 progress=None):
        self.settings = settings or Settings()
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})
        self._robots: RobotFileParser | None = None
        self._last_request = 0.0
        self._progress = progress or (lambda msg: None)

    # ------------------------------------------------------------- plumbing
    def _sleep(self) -> None:
        elapsed = time.monotonic() - self._last_request
        if elapsed < self.settings.crawl_delay:
            time.sleep(self.settings.crawl_delay - elapsed)
        self._last_request = time.monotonic()

    def _load_robots(self, base_url: str) -> tuple[bool, str]:
        if not self.settings.respect_robots:
            return True, "robots.txt checking disabled by the operator"
        parsed = urlparse(base_url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = RobotFileParser()
        try:
            resp = self.session.get(robots_url,
                                    timeout=self.settings.request_timeout)
            if resp.status_code == 200:
                rp.parse(resp.text.splitlines())
                self._robots = rp
                allowed = rp.can_fetch(USER_AGENT, base_url)
                return allowed, ("robots.txt read" if allowed else
                                 "robots.txt disallows this path")
            return True, f"no robots.txt (HTTP {resp.status_code})"
        except requests.RequestException as exc:
            return True, f"robots.txt unreachable ({type(exc).__name__})"

    def _may_fetch(self, url: str) -> bool:
        if self._robots is None:
            return True
        try:
            return self._robots.can_fetch(USER_AGENT, url)
        except Exception:
            return True

    def _get(self, url: str):
        last_exc = None
        for attempt in range(self.settings.max_retries + 1):
            self._sleep()
            try:
                return self.session.get(
                    url, timeout=self.settings.request_timeout,
                    allow_redirects=True)
            except requests.RequestException as exc:
                last_exc = exc
                # Back off between attempts, but never after the last one -
                # a failed host should not cost a second of wall clock.
                if attempt < self.settings.max_retries:
                    time.sleep(0.6 * (attempt + 1))
        raise last_exc  # type: ignore[misc]

    # ----------------------------------------------------------- page level
    def scan_page(self, url: str) -> PageEvidence:
        ev = PageEvidence(url=url)
        if not self._may_fetch(url):
            ev.error = "skipped: disallowed by robots.txt"
            return ev
        try:
            resp = self._get(url)
        except requests.RequestException as exc:
            ev.error = f"{type(exc).__name__}: {exc}"
            return ev

        ev.status_code = resp.status_code
        ev.final_url = resp.url
        ev.https = resp.url.lower().startswith("https://")
        ev.redirect_chain = [r.url for r in resp.history]
        if resp.status_code != 200:
            return ev
        ev.reachable = True

        soup = BeautifulSoup(resp.text, "html.parser")
        ev.title = (soup.title.get_text(strip=True) if soup.title else "")
        page_text = soup.get_text(" ", strip=True)
        lowered = page_text.lower()
        ev.text_length = len(page_text)

        base_host = urlparse(resp.url).netloc.lower()

        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.lower().startswith("mailto:"):
                addr = href[7:].split("?")[0].strip()
                if addr and addr not in ev.mailto_addresses:
                    ev.mailto_addresses.append(addr)
                continue
            absolute = urljoin(resp.url, href)
            label = a.get_text(" ", strip=True).lower()
            target = absolute.lower()
            if (any(h in label for h in POLICY_TEXT_HINTS)
                    or any(h in target for h in POLICY_URL_HINTS)):
                if absolute not in ev.policy_links:
                    ev.policy_links.append(absolute)
            if urlparse(absolute).netloc.lower() == base_host:
                clean = absolute.split("#")[0]
                if clean not in ev.internal_links:
                    ev.internal_links.append(clean)

        ev.cookie_banner_wording = [w for w in CONSENT_WORDING if w in lowered]
        ev.implied_consent_wording = [w for w in IMPLIED_CONSENT_WORDING
                                      if w in lowered]

        for form in soup.find_all("form"):
            action_raw = (form.get("action") or "").strip()
            action = urljoin(resp.url, action_raw) if action_raw else resp.url
            fields = []
            for inp in form.find_all(["input", "textarea", "select"]):
                itype = (inp.get("type") or inp.name or "text").lower()
                if itype in ("submit", "button", "hidden", "reset", "image"):
                    continue
                name = (inp.get("name") or inp.get("id")
                        or inp.get("placeholder") or "(unnamed field)")
                key = str(name).lower()
                sensitivity = next(
                    (label for pat, label in SENSITIVE_FIELD_PATTERNS.items()
                     if pat in key), None)
                child_related = any(p in key for p in CHILD_FIELD_PATTERNS)
                fields.append({
                    "name": str(name), "type": itype,
                    "required": inp.has_attr("required"),
                    "sensitivity": sensitivity,
                    "child_related": child_related,
                })
            has_consent_control = any(
                (i.get("type") or "").lower() == "checkbox"
                and any(k in ((i.get("name") or "") + (i.get("id") or "")).lower()
                        for k in ("consent", "agree", "accept", "privacy", "terms"))
                for i in form.find_all("input"))
            pre_ticked = any(
                (i.get("type") or "").lower() == "checkbox" and i.has_attr("checked")
                for i in form.find_all("input"))
            ev.forms.append({
                "action": action,
                "method": (form.get("method") or "get").lower(),
                "action_is_insecure": action.lower().startswith("http://"),
                "fields": fields,
                "field_count": len(fields),
                "has_consent_checkbox": has_consent_control,
                "has_pre_ticked_checkbox": pre_ticked,
            })

        for tag, attr in (("script", "src"), ("img", "src"),
                          ("link", "href"), ("iframe", "src")):
            for node in soup.find_all(tag):
                src = node.get(attr)
                if not src:
                    continue
                absolute = urljoin(resp.url, src)
                host = urlparse(absolute).netloc.lower()
                if host and host != base_host:
                    if host not in ev.third_party_hosts:
                        ev.third_party_hosts.append(host)
                for sig, label in AI_SIGNATURES.items():
                    if sig in absolute.lower():
                        entry = {"vendor": label, "signature": sig,
                                 "url": absolute, "found_on": resp.url}
                        if entry not in ev.ai_components:
                            ev.ai_components.append(entry)
                matched = [(sig, cat) for sig, cat
                           in TRACKER_SIGNATURES.items()
                           if sig in absolute.lower()]
                if matched:
                    signatures = sorted(sig for sig, _ in matched)
                    best = max(matched,
                               key=lambda pair: CATEGORY_SEVERITY.get(pair[1], 0))
                    entry = {"url": absolute, "host": host,
                             "signature": best[0],
                             "matched_signatures": signatures,
                             "category": best[1], "found_on": resp.url}
                    if not any(t["url"] == absolute
                               and t["found_on"] == resp.url
                               for t in ev.trackers):
                        ev.trackers.append(entry)

        # Inline scripts carry gtag / fbq / dataLayer just as often as src.
        for script in soup.find_all("script"):
            if script.get("src") or not script.string:
                continue
            body = script.string.lower()
            for sig, category in (("fbq(", "advertising pixel"),
                                  ("gtag(", "analytics"),
                                  ("datalayer", "tag manager"),
                                  ("ga(", "analytics"),
                                  ("clarity(", "session recording")):
                if sig in body:
                    entry = {"url": f"(inline script: {sig})",
                             "host": base_host, "signature": sig,
                             "matched_signatures": [sig], "category": category,
                             "found_on": resp.url}
                    if not any(t["url"] == entry["url"]
                               and t["found_on"] == resp.url
                               for t in ev.trackers):
                        ev.trackers.append(entry)

        for frame in soup.find_all("iframe", src=True):
            ev.iframes.append(urljoin(resp.url, frame["src"]))

        for match in re.findall(
                r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", page_text):
            if match not in ev.mailto_addresses:
                ev.mailto_addresses.append(match)

        return ev

    # ------------------------------------------------------ policy handling
    def _extract_policy_text(self, url: str) -> tuple[str, str] | None:
        try:
            resp = self._get(url)
        except requests.RequestException:
            return None
        if resp.status_code != 200:
            return None
        soup = BeautifulSoup(resp.text, "html.parser")
        for junk in soup(["script", "style", "nav", "footer", "header"]):
            junk.decompose()
        text = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n", strip=True))
        # A real policy page is not forty words of navigation.
        if len(text) < 400:
            return None
        return resp.url, text

    def discover_policy_pages(self, base_url: str,
                              candidates: list[str]) -> list[dict]:
        found: list[dict] = []
        seen: set[str] = set()
        # Common paths hang off the site root, not off whatever page the
        # review happened to start from - otherwise a base URL ending in
        # /index.html produces /index.html/privacy-policy, which is nonsense.
        parsed = urlparse(base_url)
        root = f"{parsed.scheme}://{parsed.netloc}"
        ordered = list(dict.fromkeys(
            candidates + [root + p for p in COMMON_POLICY_PATHS]))
        for url in ordered:
            if url in seen or len(found) >= 6:
                continue
            seen.add(url)
            if not self._may_fetch(url):
                continue
            self._progress(f"Reading candidate policy page: {url}")
            got = self._extract_policy_text(url)
            if got:
                final_url, text = got
                if final_url in seen and final_url != url:
                    continue
                seen.add(final_url)
                found.append({"url": final_url, "characters": len(text),
                              "text": text})
        return found

    # ------------------------------------------------------------ top level
    def scan(self, institution_name: str, base_url: str,
             extra_pages: list[str] | None = None) -> ScanResult:
        if not base_url.lower().startswith(("http://", "https://")):
            base_url = "https://" + base_url
        result = ScanResult(
            institution_name=institution_name,
            base_url=base_url,
            scanned_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        allowed, note = self._load_robots(base_url)
        result.robots_allowed, result.robots_note = allowed, note
        if not allowed:
            result.errors.append(
                "robots.txt disallows automated access to this site. "
                "Scan the site only with the institution's written permission.")
            return result

        targets = [base_url] + list(extra_pages or [])
        self._progress(f"Fetching {base_url}")
        home = self.scan_page(base_url)
        result.pages.append(asdict(home))
        if home.error:
            result.errors.append(f"{base_url}: {home.error}")

        # Follow a few likely-relevant internal pages: contact, admission,
        # about - these are where the forms and the officer details live.
        interesting = ("contact", "admission", "enquir", "enroll", "apply",
                       "fee", "about", "registration")
        auto = [u for u in home.internal_links
                if any(k in u.lower() for k in interesting)][:6]
        for url in list(dict.fromkeys(list(extra_pages or []) + auto)):
            if len(result.pages) >= self.settings.max_pages:
                break
            if url == base_url:
                continue
            self._progress(f"Fetching {url}")
            page = self.scan_page(url)
            result.pages.append(asdict(page))
            if page.error:
                result.errors.append(f"{url}: {page.error}")

        candidate_policies: list[str] = []
        for page in result.pages:
            candidate_policies.extend(page.get("policy_links", []))
        result.policy_pages = self.discover_policy_pages(
            base_url, candidate_policies)
        if result.policy_pages:
            best = max(result.policy_pages, key=lambda p: p["characters"])
            result.policy_text = best["text"]
            result.policy_source_url = best["url"]

        # Roll-ups the rules engine reads.
        result.site_is_https = bool(result.pages) and bool(
            result.pages[0].get("https"))
        for page in result.pages:
            for form in page.get("forms", []):
                if form.get("action_is_insecure"):
                    result.insecure_form_actions.append(form["action"])
                for fld in form.get("fields", []):
                    if fld.get("sensitivity"):
                        result.sensitive_fields_seen.append({
                            "page": page.get("final_url") or page["url"],
                            "field": fld["name"],
                            "why": fld["sensitivity"],
                            "child_related": fld["child_related"],
                        })
            for tracker in page.get("trackers", []):
                if tracker not in result.all_trackers:
                    result.all_trackers.append(tracker)
            for host in page.get("third_party_hosts", []):
                if host not in result.all_third_party_hosts:
                    result.all_third_party_hosts.append(host)
            for addr in page.get("mailto_addresses", []):
                if addr not in result.contact_emails:
                    result.contact_emails.append(addr)
            for component in page.get("ai_components", []):
                if component not in result.ai_components:
                    result.ai_components.append(component)

        result.child_risk_trackers = [
            t for t in result.all_trackers
            if t["category"] in CHILD_SENSITIVE_CATEGORIES]
        return result


def scan_institution(institution_name: str, base_url: str,
                     extra_pages: list[str] | None = None,
                     settings: Settings | None = None,
                     progress=None) -> ScanResult:
    """Convenience wrapper mirroring the v1 entry point."""
    return Scanner(settings=settings, progress=progress).scan(
        institution_name, base_url, extra_pages)
