"""
The core systems - the ERP, the fee software, the accounts, the learning
platform.

This is where a school's children's data actually lives. The website is a
brochure and the social feed is a shop window; the student records system
holds the date of birth, the parent's phone number, the medical note, the
transport pickup point and the marks, for every child, going back years.

The school is the Data Fiduciary for all of it. The ERP vendor, the payment
gateway, the SMS gateway and the learning platform are Data Processors.
Section 8(1) keeps the school responsible for compliance even where a
processor does the processing on its behalf, and section 8(2) permits
engaging one only under a valid contract. If the vendor is breached, it is the
school that must intimate the parents and report to the Board.

Design constraint, and the reason this module looks the way it does:

    It reads the SHAPE of the data, never the data.

Given an export it reports which columns exist, what category of personal
data each one holds, and how many rows are filled in. A fill rate is a count,
not a value. No cell contents are ever written to the evidence store, shown
in a report, or sent anywhere. A readiness tool that accumulated a copy of
every school's student database would be a worse problem than the one it was
built to find, and there is a test in the suite that fails if a cell value
reaches the evidence file.
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

# --------------------------------------------------------------------------
# What a column header tells us about the category held.
# (pattern, category, why it matters)
# --------------------------------------------------------------------------

CATEGORY_RULES: tuple[tuple[str, str, str], ...] = (
    (r"aadha?ar|\buid\b|uidai", "Government identifier",
     "Aadhaar should not be held unless a statute requires it. Record the "
     "purpose and mask the number at rest."),
    (r"\bpan\b|pan[_ ]?no|pan[_ ]?number", "Government identifier",
     "A PAN in a student record usually belongs to a parent and needs its own "
     "purpose."),
    (r"passport", "Government identifier",
     "A passport number is rarely needed outside an overseas trip."),
    (r"apaar|\bpen\b", "Student identifier",
     "APAAR/PEN is a national identifier. Confirm the statutory basis and who "
     "it is shared with."),
    (r"udise", "Student identifier",
     "UDISE+ reporting is a lawful purpose, but the field should not travel "
     "beyond it."),
    (r"caste|^category$|category[_ ]?code|social[_ ]?category|\bsc[_ ]?st\b|"
     r"\bobc\b|community", "Possible caste category",
     "Collected for government returns. It should not be visible to teachers "
     "or exportable with the class list."),
    (r"religion", "Special category",
     "Rarely needed for any school purpose once admission is complete."),
    (r"biometric|finger|face[_ ]?id|thumb", "Biometric",
     "A biometric template of a child, held continuously. Confirm the "
     "vendor's deletion terms."),
    (r"password|\bpin\b|\botp\b|secret|token|api[_ ]?key", "Credential",
     "Credentials must never appear in an export at all."),
    (r"blood[_ ]?group|medical|allerg|disab|divyang|health|therapy|"
     r"medication|counsel", "Health",
     "Health data needs a narrow purpose and tight access."),
    (r"bank|account[_ ]?no|account[_ ]?number|ifsc|\bupi\b|\bvpa\b",
     "Financial",
     "Bank particulars usually belong to a parent, not the student."),
    (r"\bdob\b|date[_ ]?of[_ ]?birth|birth[_ ]?date|birthday",
     "Date of birth",
     "Date of birth plus a name is what makes a child's record "
     "re-identifiable."),
    (r"photo|image|picture|avatar", "Photograph",
     "A photograph is personal data and feeds the media-consent question."),
    (r"remark|comment|behaviou?r|discipline|conduct", "Behavioural note",
     "Free-text remarks about a child are the highest-risk field in any "
     "school system and are rarely reviewed."),
    (r"address|street|locality|pin[_ ]?code|pincode|\bcity\b|village|"
     r"district", "Home address",
     "An address plus a child's name discloses where the child lives."),
    (r"transport|route|pickup|drop|bus[_ ]?stop|\bgps\b|latitude|longitude",
     "Location",
     "A pickup point plus a name locates a child at a known time each day."),
    (r"mobile|phone|contact[_ ]?no|whatsapp|telephone", "Contact",
     "Parent phone numbers are the field most often exported and forwarded."),
    (r"e-?mail", "Contact", "Used for circulars; confirm it is not shared on."),
    (r"father|mother|guardian|parent", "Parent identity",
     "Parents are Data Principals in their own right."),
    (r"fee|amount|receipt|invoice|\bdue\b|\bpaid\b|balance|concession|"
     r"scholarship", "Fee and payment",
     "Fee data is commercial administration, which is harder to bring inside "
     "the Fourth Schedule's 'academic activities'."),
    (r"\bmarks\b|obtained[_ ]?marks|max[_ ]?marks|grade|score|result|"
     r"percentage|cgpa|assessment|\bexam\b", "Academic performance",
     "Publishing or sharing this beyond the school needs its own basis."),
    (r"attendance|present|absent", "Attendance", ""),
    (r"^status$|is[_ ]?active|^active$|record[_ ]?status|tc[_ ]?issued|"
     r"date[_ ]?of[_ ]?leaving|leaving[_ ]?date|withdraw", "Record status",
     "Not personal data in itself, but it is what makes a leaver findable "
     "for deletion."),
    (r"admission|enrol", "Enrolment", ""),
    (r"\bname\b|student[_ ]?name|first[_ ]?name|last[_ ]?name|surname",
     "Name", ""),
    (r"class|section|standard|grade[_ ]?level|roll", "Class or roll", ""),
)

# Categories where a breach or a careless export does lasting harm.
HIGH_HARM = {
    "Government identifier", "Student identifier", "Biometric", "Credential",
    "Special category", "Possible caste category", "Health",
}

STATUS_COLUMNS = re.compile(
    r"status|active|left|tc[_ ]?issued|withdraw|alumni|struck|discontinued|"
    r"date[_ ]?of[_ ]?leaving|leaving[_ ]?date|exit", re.IGNORECASE)
LEAVER_VALUES = {
    "left", "inactive", "withdrawn", "alumni", "tc issued", "tc_issued",
    "discontinued", "struck off", "ex-student", "passed out", "closed",
    "transferred", "no", "n", "0", "false",
}
DATE_COLUMNS = re.compile(r"date|_dt$|leaving|admission|last", re.IGNORECASE)


def _normalise(header: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (header or "").strip().lower()).strip("_")


def classify_column(header: str) -> tuple[str | None, str]:
    """
    Match a header against the category rules.

    Both the underscore form and the spaced form are tried, because an
    underscore is a word character: "marks_obtained" does not satisfy
    \\bmarks\\b, but "marks obtained" does. Real exports use both.
    """
    key = _normalise(header)
    if not key:
        return None, ""
    spaced = key.replace("_", " ")
    for pattern, category, why in CATEGORY_RULES:
        if re.search(pattern, key) or re.search(pattern, spaced):
            return category, why
    return None, ""


# --------------------------------------------------------------------------
# Reading an export without keeping it
# --------------------------------------------------------------------------

def _open_export(path: Path):
    suffix = path.suffix.lower()
    if suffix in (".csv", ".txt", ".tsv"):
        delimiter = "\t" if suffix == ".tsv" else ","
        handle = path.open(encoding="utf-8-sig", newline="", errors="replace")
        reader = csv.reader(handle, delimiter=delimiter)
        return next(reader, []), reader, handle
    if suffix in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        workbook = load_workbook(path, read_only=True, data_only=True)
        rows = workbook.active.iter_rows(values_only=True)
        headers = [str(c) if c is not None else "" for c in next(rows, [])]
        return headers, rows, workbook
    raise ValueError(f"unsupported export format '{suffix}' - save the export "
                     "as .csv or .xlsx")


def analyse_export(path, system_name: str = "") -> dict:
    """
    Read one export and return its shape.

    The file is streamed, counted and closed. Fill rates are counted as the
    rows go past; only the totals survive.
    """
    path = Path(path)
    result: dict = {
        "system_name": system_name or path.stem,
        "source_file": path.name,
        "reviewed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "rows": 0, "columns": 0,
        "findings": [], "categories_present": [],
        "unclassified_columns": [],
        "inactive_rows": 0, "oldest_year": None, "status_column": "",
        "notes": [], "errors": [],
    }
    if not path.exists():
        result["errors"].append(f"file not found: {path}")
        return result

    try:
        headers, rows, handle = _open_export(path)
    except Exception as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
        return result

    headers = [str(h) if h is not None else "" for h in headers]
    result["columns"] = len([h for h in headers if h.strip()])

    tracked: list[tuple[int, str, str, str]] = []   # index, column, category, why
    status_index = None
    date_indexes: list[int] = []
    for index, header in enumerate(headers):
        if not header.strip():
            continue
        category, why = classify_column(header)
        if category:
            tracked.append((index, header.strip(), category, why))
            if category not in result["categories_present"]:
                result["categories_present"].append(category)
        else:
            result["unclassified_columns"].append(header.strip())
        if status_index is None and STATUS_COLUMNS.search(header):
            status_index = index
            result["status_column"] = header.strip()
        if DATE_COLUMNS.search(header):
            date_indexes.append(index)

    populated = {index: 0 for index, _, _, _ in tracked}
    row_count = 0
    inactive = 0
    oldest_year = None
    year_pattern = re.compile(r"(?:19|20)\d{2}")
    try:
        for row in rows:
            row_count += 1
            if row_count > 500_000:
                result["notes"].append("Counting stopped at 500,000 rows.")
                break
            for index in populated:
                if index < len(row):
                    value = row[index]
                    if value is not None and str(value).strip() != "":
                        populated[index] += 1
            if status_index is not None and status_index < len(row):
                if str(row[status_index] or "").strip().lower() in LEAVER_VALUES:
                    inactive += 1
            for index in date_indexes:
                if index < len(row):
                    match = year_pattern.search(str(row[index] or ""))
                    if match:
                        year = int(match.group(0))
                        if 1950 < year <= datetime.now().year:
                            oldest_year = (year if oldest_year is None
                                           else min(oldest_year, year))
    except Exception as exc:
        result["errors"].append(
            f"while counting rows: {type(exc).__name__}: {exc}")
    finally:
        try:
            handle.close()
        except Exception:
            pass

    result["rows"] = row_count
    result["inactive_rows"] = inactive
    result["oldest_year"] = oldest_year
    for index, column, category, why in tracked:
        count = populated[index]
        result["findings"].append({
            "column": column, "category": category,
            "populated": count, "total": row_count,
            "fill_rate": round(100.0 * count / row_count, 1) if row_count else 0.0,
            "why": why,
        })

    high_harm = sorted({f["category"] for f in result["findings"]
                        if f["category"] in HIGH_HARM and f["populated"]})
    if high_harm:
        result["notes"].append(
            "High-harm categories are populated here: " + ", ".join(high_harm)
            + ". Each needs a stated purpose or removal.")
    if inactive:
        share = round(100.0 * inactive / row_count, 1) if row_count else 0
        result["notes"].append(
            f"{inactive} of {row_count} records ({share}%) are marked as "
            "leavers and are still held in full.")
    if oldest_year is not None and (datetime.now().year - oldest_year) >= 6:
        result["notes"].append(
            f"Dates go back to {oldest_year}. Confirm a retention rule covers "
            "records that old.")
    if result["unclassified_columns"]:
        result["notes"].append(
            f"{len(result['unclassified_columns'])} column(s) could not be "
            "classified and need review by hand: "
            + ", ".join(result["unclassified_columns"][:8])
            + ". An unclassified column is not a safe column.")
    return result


# --------------------------------------------------------------------------
# The accounting system - deliberately narrow
# --------------------------------------------------------------------------
# Schools typically post fee receipts with the student's name against each
# receipt, so the books hold a thin slice of children's data: a name and a
# payment. That slice is small, but it raises a problem the ERP does not. The
# books of account must be preserved for years under the Income-tax and
# Companies Act record rules, while section 8(7) requires erasure from the
# student system once the purpose is served. A school that "deleted" a leaver
# has therefore usually not deleted them - and should say so rather than tell
# a parent the data is gone.

TALLY_FIELDS: tuple[tuple[str, str, str, str], ...] = (
    ("LEDGERMOBILE", "Mobile number", "Contact",
     "A parent or staff phone number inside the books of account."),
    ("EMAIL", "Email address", "Contact",
     "Reaches further than the accounts team."),
    ("LEDGERPHONE", "Landline", "Contact", ""),
    ("ADDRESS", "Postal address", "Home address",
     "An address against a student name locates the child."),
    ("INCOMETAXNUMBER", "PAN", "Government identifier",
     "Usually a parent's PAN, held for receipts or 80G."),
    ("PARTYGSTIN", "GSTIN", "Government identifier",
     "A business identifier; lower sensitivity but still governed."),
    ("BANKACCHOLDERNAME", "Bank account holder", "Financial", ""),
    ("BANKACCOUNTNUMBER", "Bank account number", "Financial",
     "A bank account number inside the ledger master."),
    ("BANKDETAILS", "Bank account", "Financial",
     "Bank particulars of a parent or a staff member."),
)

PARTY_PARENTS = ("sundry debtor", "sundry creditor", "loan", "salary",
                 "staff", "employee", "fee", "student", "advance")

TALLY_REQUEST = """<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST>
<TYPE>Collection</TYPE><ID>Ledgers</ID></HEADER>
<BODY><DESC><STATICVARIABLES>
<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
</STATICVARIABLES><TDL><TDLMESSAGE>
<COLLECTION NAME="Ledgers" ISMODIFY="No">
<TYPE>Ledger</TYPE>
<FETCH>NAME,PARENT,LEDGERMOBILE,LEDGERPHONE,EMAIL,ADDRESS,
INCOMETAXNUMBER,PARTYGSTIN,BANKACCHOLDERNAME,BANKDETAILS</FETCH>
</COLLECTION></TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>"""


def parse_ledgers(payload: str) -> dict:
    """
    Turn a TallyPrime ledger collection into counts.

    Separated from the fetch so it can be exercised against a saved response
    without TallyPrime running - and so it is obvious, reading it, that only
    counts come out. No ledger name, number or address is returned.
    """
    import xml.etree.ElementTree as ET
    try:
        # Some Tally builds emit control characters that are not valid XML.
        cleaned = re.sub(r"&#[0-9]+;", "", payload)
        cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", cleaned)
        root = ET.fromstring(cleaned)
    except Exception as exc:
        return {"error": f"the XML could not be parsed ({type(exc).__name__})",
                "ledgers": 0, "party_ledgers": 0, "fields": {}}

    ledgers = root.findall(".//LEDGER")
    counts = {tag: 0 for tag, _, _, _ in TALLY_FIELDS}
    party = 0
    for ledger in ledgers:
        parent = (ledger.findtext("PARENT") or "").lower()
        if any(word in parent for word in PARTY_PARENTS):
            party += 1
        for tag, _, _, _ in TALLY_FIELDS:
            value = ledger.findtext(tag)
            if value is not None and str(value).strip():
                counts[tag] += 1
    return {
        "error": "",
        "ledgers": len(ledgers),
        "party_ledgers": party,
        "fields": {
            label: {"populated": counts[tag], "category": category,
                    "why": why}
            for tag, label, category, why in TALLY_FIELDS if counts[tag]
        },
    }


def read_accounting(host: str = "localhost", port: int = 9000,
                    settings=None) -> dict:
    """
    Read ledger MASTERS from a local TallyPrime, over its own XML interface.

    Read-only: this asks for a collection and writes nothing back. Only counts
    leave this function - how many ledgers exist, how many look like party or
    staff accounts, and how many have each personal-data field filled in. No
    ledger name, number or address is retained.
    """
    result: dict = {
        "reachable": False,
        "endpoint": f"http://{host}:{port}",
        "ledgers": 0, "party_ledgers": 0,
        "fields": {}, "note": "", "errors": [],
        "read_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    try:
        import requests
        response = requests.post(
            result["endpoint"], data=TALLY_REQUEST.encode("utf-8"),
            headers={"Content-Type": "text/xml;charset=utf-8"},
            timeout=(settings.request_timeout if settings else 12))
        if response.status_code != 200:
            result["errors"].append(
                f"TallyPrime answered HTTP {response.status_code}. Check that "
                "the company is open and the XML interface is enabled.")
            return result
        payload = response.text
    except Exception as exc:
        result["errors"].append(
            f"Could not reach TallyPrime at {result['endpoint']} "
            f"({type(exc).__name__}). Open the company and enable the XML "
            "interface, or skip this check.")
        return result

    parsed = parse_ledgers(payload)
    if parsed.get("error"):
        result["errors"].append(parsed["error"])
        return result
    result["reachable"] = True
    result["ledgers"] = parsed["ledgers"]
    result["party_ledgers"] = parsed["party_ledgers"]
    result["fields"] = parsed["fields"]
    result["note"] = (
        "Only counts were read - no ledger name, number or address left "
        "TallyPrime. Where fee receipts are posted against a student's name, "
        "the books hold a thin slice of children's data that is preserved "
        "under the Income-tax and Companies Act record rules, and therefore "
        "outlives any deletion from the ERP. Record that in the retention "
        "schedule, and consider whether a receipt number reconciling to the "
        "ERP would serve the audit trail with less personal data.")
    return result


# --------------------------------------------------------------------------
# Assembly
# --------------------------------------------------------------------------

@dataclass
class SystemsReview:
    reviewed_at: str = ""
    systems: list[dict] = field(default_factory=list)
    accounting: dict = field(default_factory=dict)
    counts: dict = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    @property
    def assessed(self) -> bool:
        return bool(self.systems) or bool(self.accounting.get("reachable"))

    def to_dict(self) -> dict:
        return asdict(self)


def build(export_paths=None, tally: bool = False,
          tally_host: str = "localhost", tally_port: int = 9000,
          settings=None) -> SystemsReview:
    review = SystemsReview(
        reviewed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))

    for entry in (export_paths or []):
        if isinstance(entry, (tuple, list)) and len(entry) == 2:
            label, path = entry
        else:
            path, label = entry, ""
        result = analyse_export(path, system_name=label)
        review.systems.append(result)
        review.errors.extend(result["errors"])

    if tally:
        review.accounting = read_accounting(tally_host, tally_port, settings)
        review.errors.extend(review.accounting.get("errors", []))

    reviewed = [s for s in review.systems if not s["errors"]]
    high_harm = sorted({f["category"] for s in reviewed
                        for f in s["findings"]
                        if f["category"] in HIGH_HARM and f["populated"]})
    review.counts = {
        "systems_reviewed": len(reviewed),
        "rows": sum(s["rows"] for s in reviewed),
        "categories": len({c for s in reviewed
                           for c in s["categories_present"]}),
        "high_harm_categories": high_harm,
        "stale_records": sum(s["inactive_rows"] for s in reviewed),
        "tally_ledgers": review.accounting.get("ledgers", 0),
        "tally_party_ledgers": review.accounting.get("party_ledgers", 0),
    }
    return review
