"""
Locate files that ship with the application.

When the app runs from source these sit in the project folder. When it runs
from a PyInstaller build they are unpacked into a temporary directory that
PyInstaller points at with sys._MEIPASS. Everything that reads a bundled file
goes through here so the two cases cannot drift apart.

Files the application WRITES never go to either of those places - a
PyInstaller temp directory disappears when the app closes, and the folder
holding the .exe may be read-only. Written output goes to the user's own
Documents folder or to the config directory.
"""

from __future__ import annotations

import sys
from pathlib import Path


def is_frozen() -> bool:
    """True when running from a PyInstaller build rather than from source."""
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def resource_root() -> Path:
    """Where bundled read-only files live."""
    if is_frozen():
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parents[1]


def resource(*parts: str) -> Path:
    return resource_root().joinpath(*parts)


def output_root() -> Path:
    """
    Where reports go by default.

    From source: the project's own output_reports folder, which keeps a
    capstone submission self-contained.
    From a build: Documents\\SurakshaScan Reports, because the folder holding
    the .exe is often somewhere the user cannot write to.
    """
    if is_frozen():
        documents = Path.home() / "Documents"
        base = documents if documents.exists() else Path.home()
        path = base / "SurakshaScan Reports"
    else:
        path = Path(__file__).resolve().parents[1] / "output_reports"
    path.mkdir(parents=True, exist_ok=True)
    return path


def icon_path() -> Path | None:
    candidate = resource("assets", "surakshascan.ico")
    return candidate if candidate.exists() else None
