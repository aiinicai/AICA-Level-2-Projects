"""
The Excel export - status counts by section plus the full working paper.

Sheets:
  Overview        score, band, coverage, counts
  Findings        one row per obligation with its evidence
  Remediation     the prioritised plan, filterable by effort and domain
  Working paper   the internal-practices lines
  Trackers        the third-party scripts detected
  Evidence log    what was fetched, when, and with what result
"""

from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .dpdp_catalogue import GAP, MET, NOT_ASSESSED, PARTIAL
from .questionnaire import QUESTIONS

HEADER_FILL = PatternFill("solid", fgColor="1F3B57")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=10)
STATUS_FILL = {
    MET: PatternFill("solid", fgColor="D8EDE2"),
    PARTIAL: PatternFill("solid", fgColor="FBEFD2"),
    GAP: PatternFill("solid", fgColor="F7D9D3"),
    NOT_ASSESSED: PatternFill("solid", fgColor="ECEFF1"),
}
STATUS_WORDS = {MET: "Met", PARTIAL: "Partly met", GAP: "Gap",
                NOT_ASSESSED: "Not assessed"}


def _write_sheet(ws, headers, rows, widths=None, status_column=None):
    ws.append(headers)
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    for row in rows:
        ws.append(row)
        if status_column is not None:
            value = row[status_column]
            key = next((k for k, v in STATUS_WORDS.items() if v == value), None)
            if key:
                ws.cell(row=ws.max_row, column=status_column + 1).fill = \
                    STATUS_FILL[key]
    for index, width in enumerate(widths or [], start=1):
        ws.column_dimensions[get_column_letter(index)].width = width
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    if ws.max_row > 1:
        ws.auto_filter.ref = ws.dimensions


def generate(review, output_path) -> str:
    scan, assessment = review.scan, review.assessment
    output_path = Path(output_path)
    wb = Workbook()

    ws = wb.active
    ws.title = "Overview"
    _write_sheet(ws, ["Item", "Value"], [
        ["Institution", scan.institution_name],
        ["Website", scan.base_url],
        ["Scanned at (UTC)", scan.scanned_at],
        ["Readiness score", assessment.score],
        ["Band", assessment.band],
        ["Band note", assessment.band_note],
        ["Catalogue coverage (%)", assessment.coverage_percent],
        ["Weight assessed", assessment.weight_assessed],
        ["Weight total", assessment.weight_total],
        ["Met", assessment.counts.get(MET, 0)],
        ["Partly met", assessment.counts.get(PARTIAL, 0)],
        ["Gap", assessment.counts.get(GAP, 0)],
        ["Not assessed", assessment.counts.get(NOT_ASSESSED, 0)],
        ["Authorisation", review.authorisation.summary()
         if getattr(review, "authorisation", None) else "not recorded"],
        ["AI layer used", "Yes" if (review.ai and review.ai.used) else "No"],
        ["Evidence file", review.evidence_path or "not written"],
    ], widths=[34, 78])

    ws = wb.create_sheet("By domain")
    _write_sheet(ws, ["Domain", "Met", "Partly met", "Gap", "Not assessed",
                      "Weight assessed", "Percent met"],
                 [[d.domain, d.met, d.partial, d.gap, d.not_assessed,
                   d.weight_assessed, d.percent] for d in assessment.domains],
                 widths=[34, 9, 12, 9, 14, 17, 13])

    ws = wb.create_sheet("Findings")
    _write_sheet(
        ws,
        ["Ref", "Domain", "Obligation", "Provision", "Provision status",
         "Status", "Weight", "Confidence", "Decided by", "Rationale",
         "Evidence", "Remediation", "Effort"],
        [[f.obligation_id, f.domain, f.title, f.provision, f.provision_status,
          STATUS_WORDS.get(f.status, f.status), f.weight, f.confidence,
          f.decided_by, f.rationale, "\n".join(str(e) for e in f.evidence[:6]),
          f.remediation, f.effort] for f in review.findings],
        widths=[7, 24, 46, 26, 16, 13, 8, 12, 13, 54, 54, 54, 9],
        status_column=5)

    ws = wb.create_sheet("Remediation")
    _write_sheet(
        ws,
        ["Rank", "Ref", "Obligation", "Domain", "Status", "Action", "Effort",
         "Score gain", "Provision", "Provision status", "Owner", "Target date",
         "Done"],
        [[r.rank, r.obligation_id, r.title, r.domain,
          STATUS_WORDS.get(r.status, r.status), r.action, r.effort,
          r.score_gain, r.provision, r.provision_status, "", "", ""]
         for r in assessment.remediation],
        widths=[7, 7, 44, 24, 13, 60, 9, 11, 26, 16, 16, 13, 8],
        status_column=4)

    ws = wb.create_sheet("Working paper")
    responses = getattr(review, "_responses", {}) or {}
    rows = []
    for question in QUESTIONS:
        response = responses.get(question.id)
        rows.append([
            question.id, question.tab, question.text, question.obligation_id,
            response.answer if response else "unknown",
            response.status if response else "Pending",
            response.reviewer if response else "",
            response.confidence if response else "not verified",
            response.remark if response else "",
            question.evidence_to_see, question.guidance,
        ])
    _write_sheet(ws, ["Ref", "Tab", "Question", "Maps to", "Answer", "Status",
                      "Reviewer", "Confidence", "Remark", "Evidence to see",
                      "Guidance"], rows,
                 widths=[7, 26, 62, 9, 10, 13, 18, 16, 46, 52, 46])

    ws = wb.create_sheet("Trackers")
    _write_sheet(ws, ["Host", "Category", "Signature", "Found on", "URL"],
                 [[t["host"], t["category"], t["signature"], t["found_on"],
                   t["url"]] for t in scan.all_trackers],
                 widths=[32, 22, 20, 52, 62])

    ws = wb.create_sheet("Evidence log")
    rows = []
    for page in scan.pages:
        rows.append([
            page.get("url"), page.get("final_url") or "", page.get("status_code"),
            "Yes" if page.get("https") else "No", len(page.get("forms", [])),
            len(page.get("trackers", [])), len(page.get("third_party_hosts", [])),
            page.get("error") or "",
        ])
    _write_sheet(ws, ["Requested URL", "Final URL", "HTTP status", "HTTPS",
                      "Forms", "Trackers", "Third-party hosts", "Error"], rows,
                 widths=[54, 54, 12, 8, 8, 10, 18, 44])

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    return str(output_path)
