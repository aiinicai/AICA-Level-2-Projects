# IFC Advisory — UAE Client Portal & Advisory Management System

A full-stack B2B and B2C advisory platform for **IFC Advisory**, a UAE consulting firm serving businesses across all seven Emirates (Abu Dhabi, Dubai, Sharjah, Ajman, Umm Al Quwain, Ras Al Khaimah and Fujairah), backed by IFC Global.

Dark-green and gold executive theme, role-based client and staff workflows, Maker–Checker quality control, document checklists, and installable mobile app (PWA).

---

## Key Features

### Client onboarding
- New clients **request access with email only** (no password at signup).
- Admin reviews and approves the request; approval issues a **one-time password**.
- At first sign-in the client must enter the one-time password and **set a new password**.

### Roles
- **Admin** — the first person to register becomes admin. Approves clients, creates team members, resets passwords, assigns roles.
- **Team** — IFC staff with designations; work on projects as Maker or Checker.
- **Client** — sees own projects, progress, tasks, action items and documents.

### Projects & Maker–Checker
- Each project has a service, status, quote, progress, a Maker (prepares) and a Checker (reviews and signs off).
- Standard tasks and data requirements are suggested per service.

### Document checklists
When a project is created, document tabs open automatically:
- **KYC** — passport, Emirates ID, proof of address, UBO declaration
- **Corporate** — trade licence, MOA, power of attorney
- **Financial** — audited statements, bank statements, trial balance
- **Tax** — TRN certificate, Corporate Tax certificate, prior returns
- **Service** — documents specific to the chosen service
- **Reports & other** — reports, quotes and invoices from IFC

IFC team members can add extra document requirements with comments.

### Services
Accounting & Bookkeeping · Audit & Assurance · Corporate Tax & VAT · Transfer Pricing · AML / GoAML · Company Formation · CFO Advisory · Payroll & HR.

### Staff dashboard
Analytics, Approvals, Projects, Tasks, Clients, Team and Sign-in log.

### Mobile app (PWA)
Install from the browser: iPhone (Safari → Share → Add to Home Screen) or Android (Chrome → menu → Install app).

---

## Tech Stack
- TanStack Start v1 (React 19, TanStack Router), Vite 7
- Tailwind CSS v4, shadcn/ui, Lucide icons, Recharts
- Lovable Cloud (database with row-level security, auth, file storage)
- Vitest + React Testing Library

---

## Getting Started

```bash
git clone <your-repository-url>
cd ifc-advisory-portal
bun install        # or: npm install
bun dev            # or: npm run dev
```

Create a `.env` file with:
```env
VITE_SUPABASE_URL=<your backend URL>
VITE_SUPABASE_PUBLISHABLE_KEY=<your publishable key>
VITE_SUPABASE_PROJECT_ID=<your project id>
```

Run tests: `bunx vitest run`

---

## Project Structure

```text
src/
  assets/                 Hero imagery
  components/portal/      Client & staff dashboards, document checklists
  hooks/                  useMe (role + profile)
  lib/admin.functions.ts  Admin server actions (approve, create users, reset passwords)
  lib/catalog.ts          Emirates, services, designations, tasks, document templates
  routes/                 Landing, auth, reset-password, dashboard
  styles.css              Theme (dark green & gold)
public/                   PWA manifest and icons
```

---

## Security
- Roles stored in a separate protected table (not editable by users).
- Row-level security: clients only see their own projects and files.
- Private document storage with signed download links.
- Sign-in events are logged.

---

© IFC Advisory. All rights reserved.
