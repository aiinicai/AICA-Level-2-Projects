# Compressa — PDF & JPEG Compressor

A local desktop app that compresses PDF and JPEG files. No internet connection
required to run it — everything happens on your machine.

## Why you're getting a Python file, not a ready-made .exe

Turning a Python app into a Windows `.exe` has to happen *on Windows* — the
tool that does it (PyInstaller) doesn't cross-build from other operating
systems. I built and tested the app itself in full, but the final exe has to
be compiled on a Windows PC. It's a single command and takes about a minute.

## Option A — No Windows machine needed (recommended)

This folder includes a GitHub Actions workflow (`.github/workflows/build.yml`)
that builds the exe on a real Windows machine in the cloud, for free. You
never need to touch Windows yourself.

1. Create a free GitHub account at github.com if you don't have one.
2. Create a new **private** repository (any name, e.g. `compressa`).
3. Upload all the files in this folder to that repo, keeping the folder
   structure — the `.github/workflows/build.yml` file must end up at that
   exact path in the repo (GitHub's "Add file → Upload files" in the web UI
   preserves folder structure if you drag the whole folder in).
4. Go to the repo's **Actions** tab. You should see a workflow run start
   automatically (or click "Run workflow" if it doesn't).
5. Wait 1-2 minutes for it to finish (green checkmark).
6. Click into the finished run, scroll to **Artifacts**, and download
   `Compressa-exe`. Unzip it — that's your `Compressa.exe`.

That single exe file is fully standalone — copy it to any Windows computer
and double-click to run it. No Python or install step needed on those other
machines.

## Option B — On a Windows PC with Python installed

1. If you don't have Python, install it from python.org (check "Add to PATH"
   during install).
2. Copy this whole folder to that PC.
3. Open Command Prompt in the folder and run:

```
pip install -r requirements.txt
```

4. Build the exe:

```
pyinstaller --onefile --windowed --name Compressa compressor_app.py
```

5. Your `.exe` will appear in the newly created `dist` folder as
   `dist\Compressa.exe`.

## Using the app

- Drag files in via "Browse Files" (PDF, JPG, JPEG supported).
- Move the slider to trade off file size vs. quality.
- Pick an output folder (defaults to Downloads).
- Click "Compress Files" — compressed copies are saved with `_compressed`
  appended to the filename; your originals are never touched.

## How compression works

- **JPEG**: re-encoded at the chosen quality level with optimized encoding.
- **PDF**: every embedded image inside the PDF is individually re-encoded at
  the chosen quality, then the file is rebuilt with stream compression and
  unused-object cleanup. Text and vector content are untouched — only images
  are compressed, so text stays crisp.

Typical results: 50-80% size reduction on image-heavy PDFs and photos,
depending on the quality setting and how much the source was already
compressed.

## Notes

- Nothing is uploaded anywhere — the whole app runs locally.
- If Windows SmartScreen flags the exe on first run (common for unsigned
  small apps), click "More info" → "Run anyway."
