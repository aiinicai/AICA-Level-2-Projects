"""
File Compressor — PDF & JPEG compression, local desktop app.
Run with: python compressor_app.py
Build to .exe with: pyinstaller --onefile --windowed --name FileCompressor --icon=icon.ico compressor_app.py
"""

import os
import sys
import io
import threading
import queue
from pathlib import Path

import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image
import pymupdf as fitz  # PyMuPDF

# ---------- Appearance ----------
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

ACCENT = "#5B8DEF"
ACCENT_HOVER = "#4A7BD9"
SURFACE = "#1E1F26"
SURFACE_2 = "#262832"
SUCCESS = "#4CAF7D"
DANGER = "#E5686D"
TEXT_MUTED = "#9AA0AC"


# ---------- Compression logic ----------

def compress_jpeg(src_path: str, dst_path: str, quality: int) -> tuple[int, int]:
    """Compresses a standalone JPEG/PNG image to standard baseline JPEG."""
    original_size = os.path.getsize(src_path)
    img = Image.open(src_path)

    # Handle transparency by flattening onto a white background
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        background = Image.new("RGB", img.size, (255, 255, 255))
        rgba_img = img.convert("RGBA")
        background.paste(rgba_img, mask=rgba_img.split()[-1])
        img = background
    elif img.mode != "RGB":
        img = img.convert("RGB")

    # Save as standard baseline JPEG (progressive=False prevents Acrobat/viewer decoding errors)
    img.save(dst_path, "JPEG", quality=quality, optimize=True, progressive=False)
    new_size = os.path.getsize(dst_path)
    return original_size, new_size


def compress_pdf(src_path: str, dst_path: str, quality: int, max_dpi: int = None, scrub: bool = False) -> tuple[int, int]:
    """
    Recompresses embedded images inside the PDF at the given quality level
    and updates the PDF dictionary keys properly to prevent the 'Insufficient data' error.
    Allows downsampling image resolution (DPI) and scrubbing extra metadata to drastically reduce file sizes.
    """
    original_size = os.path.getsize(src_path)
    doc = fitz.open(src_path)

    # 1. Scrub extra overhead metadata, thumbnail caches, embedded files, and javascript
    if scrub:
        try:
            import inspect
            sig = inspect.signature(doc.scrub)
            kwargs = {}
            
            # Check for attachments parameters
            if "attached_files" in sig.parameters:
                kwargs["attached_files"] = True
            elif "attachments" in sig.parameters:
                kwargs["attachments"] = True
            elif "attach" in sig.parameters:
                kwargs["attach"] = True
                
            if "clean_pages" in sig.parameters:
                kwargs["clean_pages"] = True
            if "embedded_files" in sig.parameters:
                kwargs["embedded_files"] = True
            if "hidden_text" in sig.parameters:
                kwargs["hidden_text"] = False  # Keep hidden text
            if "javascript" in sig.parameters:
                kwargs["javascript"] = True
            if "metadata" in sig.parameters:
                kwargs["metadata"] = True
            if "thumbnails" in sig.parameters:
                kwargs["thumbnails"] = True
            if "xml_metadata" in sig.parameters:
                kwargs["xml_metadata"] = True
                
            # Check for links parameters
            if "remove_links" in sig.parameters:
                kwargs["remove_links"] = False  # Keep links
            elif "links" in sig.parameters:
                kwargs["links"] = False
                
            doc.scrub(**kwargs)
        except Exception:
            try:
                doc.scrub()
            except Exception:
                pass
        try:
            doc.subset_fonts()
        except Exception:
            pass

    # 2. Re-compress images and downsample DPI
    if hasattr(doc, "rewrite_images"):
        try:
            kwargs = {
                "quality": quality,
                "lossy": True,
                "lossless": True,
                "bitonal": False
            }
            if max_dpi:
                kwargs["dpi_target"] = max_dpi
                # dpi_threshold MUST be strictly greater than dpi_target in PyMuPDF
                kwargs["dpi_threshold"] = max_dpi + 1
            
            doc.rewrite_images(**kwargs)
        except Exception:
            _fallback_compress_images(doc, quality, max_dpi)
    else:
        _fallback_compress_images(doc, quality, max_dpi)

    # Save with aggressive garbage collection and stream deflation.
    # Note: clean=False prevents occasional stream/annotation corruption bugs.
    doc.save(
        dst_path,
        garbage=4,
        deflate=True,
        clean=False,
        linear=False
    )
    doc.close()

    new_size = os.path.getsize(dst_path)
    return original_size, new_size


def _fallback_compress_images(doc: fitz.Document, quality: int, max_dpi: int = None):
    """
    Fallback image compressor that ensures dictionary /Filter is updated to /DCTDecode.
    """
    processed_xrefs = set()

    for page in doc:
        for img in page.get_images(full=True):
            xref = img[0]
            if xref in processed_xrefs:
                continue
            processed_xrefs.add(xref)

            try:
                base_image = doc.extract_image(xref)
                if not base_image:
                    continue

                image_bytes = base_image["image"]
                if len(image_bytes) < 8000:
                    continue

                pil_img = Image.open(io.BytesIO(image_bytes))
                
                # Perform basic resizing if DPI is set and image metadata contains DPI higher than target
                if max_dpi:
                    img_dpi = pil_img.info.get("dpi", (96, 96))
                    current_dpi = max(img_dpi)
                    if current_dpi > max_dpi:
                        scale = max_dpi / current_dpi
                        new_size = (max(1, int(pil_img.width * scale)), max(1, int(pil_img.height * scale)))
                        pil_img = pil_img.resize(new_size, Image.Resampling.LANCZOS)

                if pil_img.mode in ("RGBA", "LA", "P", "CMYK"):
                    pil_img = pil_img.convert("RGB")

                buf = io.BytesIO()
                pil_img.save(buf, "JPEG", quality=quality, optimize=True, progressive=False)
                new_bytes = buf.getvalue()

                if len(new_bytes) < len(image_bytes):
                    # Replace stream AND update PDF dictionary metadata to /DCTDecode
                    doc.update_stream(xref, new_bytes)
                    doc.xref_set_key(xref, "Filter", "/DCTDecode")
                    doc.xref_set_key(xref, "ColorSpace", "/DeviceRGB")
                    doc.xref_set_key(xref, "BitsPerComponent", "8")
                    doc.xref_set_key(xref, "DecodeParms", "null")
                    doc.xref_set_key(xref, "SMask", "null")
                    doc.xref_set_key(xref, "Mask", "null")
            except Exception:
                continue


# ---------- GUI ----------

class FileRow(ctk.CTkFrame):
    def __init__(self, master, filepath, on_remove):
        super().__init__(master, fg_color=SURFACE_2, corner_radius=10, height=56)
        self.filepath = filepath
        self.pack_propagate(False)

        name = Path(filepath).name
        size_kb = os.path.getsize(filepath) / 1024
        size_str = f"{size_kb:.0f} KB" if size_kb < 1024 else f"{size_kb/1024:.1f} MB"

        icon = "📄" if filepath.lower().endswith(".pdf") else "🖼️"

        left = ctk.CTkFrame(self, fg_color="transparent")
        left.pack(side="left", fill="both", expand=True, padx=14, pady=8)

        ctk.CTkLabel(left, text=f"{icon}  {name}", font=("Segoe UI", 13),
                     anchor="w", text_color="#F0F0F2").pack(anchor="w")
        self.status_label = ctk.CTkLabel(left, text=size_str, font=("Segoe UI", 11),
                                          text_color=TEXT_MUTED, anchor="w")
        self.status_label.pack(anchor="w")

        self.progress = ctk.CTkProgressBar(self, width=90, height=6, progress_color=ACCENT)
        self.progress.set(0)
        self.progress.pack(side="right", padx=(0, 14))
        self.progress.pack_forget()

        remove_btn = ctk.CTkButton(self, text="✕", width=28, height=28, fg_color="transparent",
                                    hover_color="#3A3C46", text_color=TEXT_MUTED,
                                    command=lambda: on_remove(self))
        remove_btn.pack(side="right", padx=(0, 6))

    def set_status(self, text, color=TEXT_MUTED):
        self.status_label.configure(text=text, text_color=color)

    def show_progress(self):
        self.progress.pack(side="right", padx=(0, 14))

    def hide_progress(self):
        self.progress.pack_forget()


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Compressa — Compress PDF & JPEG")
        self.geometry("620x720")
        self.minsize(560, 600)
        self.configure(fg_color="#15161B")

        self.files = []
        self.rows = {}
        self.output_dir = str(Path.home() / "Downloads")
        self.result_queue = queue.Queue()

        self._build_header()
        self._build_dropzone()
        self._build_file_list()
        self._build_settings()
        self._build_footer()

        self.after(100, self._poll_queue)

    def _build_header(self):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=28, pady=(24, 10))

        ctk.CTkLabel(header, text="Compressa", font=("Segoe UI Semibold", 24),
                     text_color="#FFFFFF").pack(anchor="w")
        ctk.CTkLabel(header, text="Shrink PDFs and JPEGs without leaving your computer",
                     font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(anchor="w")

    def _build_dropzone(self):
        zone = ctk.CTkFrame(self, fg_color=SURFACE, corner_radius=14, height=100,
                             border_width=1, border_color="#33353F")
        zone.pack(fill="x", padx=28, pady=12)
        zone.pack_propagate(False)

        inner = ctk.CTkFrame(zone, fg_color="transparent")
        inner.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(inner, text="＋  Add PDF or JPEG files", font=("Segoe UI", 14),
                     text_color="#D6D8DE").pack()
        btn = ctk.CTkButton(inner, text="Browse Files", width=140, height=34,
                             fg_color=ACCENT, hover_color=ACCENT_HOVER,
                             font=("Segoe UI", 12), command=self.browse_files)
        btn.pack(pady=(10, 0))

    def _build_file_list(self):
        wrapper = ctk.CTkFrame(self, fg_color="transparent")
        wrapper.pack(fill="both", expand=True, padx=28, pady=(0, 8))

        self.list_frame = ctk.CTkScrollableFrame(wrapper, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True)

        self.empty_label = ctk.CTkLabel(self.list_frame, text="No files added yet",
                                         font=("Segoe UI", 12), text_color=TEXT_MUTED)
        self.empty_label.pack(pady=30)

    def _build_settings(self):
        panel = ctk.CTkFrame(self, fg_color=SURFACE, corner_radius=14)
        panel.pack(fill="x", padx=28, pady=8)

        # Quality slider row
        row1 = ctk.CTkFrame(panel, fg_color="transparent")
        row1.pack(fill="x", padx=18, pady=(16, 4))

        ctk.CTkLabel(row1, text="Compression level", font=("Segoe UI", 12),
                     text_color="#D6D8DE").pack(side="left")
        self.quality_value_label = ctk.CTkLabel(row1, text="Balanced (65)", font=("Segoe UI", 12),
                                                 text_color=ACCENT)
        self.quality_value_label.pack(side="right")

        self.quality_slider = ctk.CTkSlider(panel, from_=10, to=95, number_of_steps=17,
                                             progress_color=ACCENT, button_color=ACCENT,
                                             button_hover_color=ACCENT_HOVER,
                                             command=self._on_quality_change)
        self.quality_slider.set(65)
        self.quality_slider.pack(fill="x", padx=18, pady=(0, 4))

        labels_row = ctk.CTkFrame(panel, fg_color="transparent")
        labels_row.pack(fill="x", padx=18, pady=(0, 8))
        ctk.CTkLabel(labels_row, text="Smaller file (Aggressive)", font=("Segoe UI", 10),
                     text_color=TEXT_MUTED).pack(side="left")
        ctk.CTkLabel(labels_row, text="Higher quality", font=("Segoe UI", 10),
                     text_color=TEXT_MUTED).pack(side="right")

        # DPI downsampling row
        row_dpi = ctk.CTkFrame(panel, fg_color="transparent")
        row_dpi.pack(fill="x", padx=18, pady=(8, 8))

        ctk.CTkLabel(row_dpi, text="Max Image Resolution", font=("Segoe UI", 12),
                     text_color="#D6D8DE").pack(side="left")
        
        self.dpi_var = ctk.StringVar(value="150 DPI (Balanced)")
        self.dpi_menu = ctk.CTkOptionMenu(
            row_dpi,
            values=["Original DPI", "150 DPI (Balanced)", "72 DPI (Web/Smallest)"],
            variable=self.dpi_var,
            width=160,
            height=28,
            fg_color=SURFACE_2,
            button_color=SURFACE_2,
            button_hover_color=ACCENT_HOVER,
            dropdown_fg_color=SURFACE_2,
            dropdown_hover_color=ACCENT,
            font=("Segoe UI", 11),
            dropdown_font=("Segoe UI", 11)
        )
        self.dpi_menu.pack(side="right")

        # Scrubbing extra data checkbox
        self.clean_var = ctk.BooleanVar(value=True)
        self.clean_cb = ctk.CTkCheckBox(
            panel,
            text="Scrub extra data (fonts, metadata, thumbs cache)",
            variable=self.clean_var,
            font=("Segoe UI", 11),
            text_color="#D6D8DE",
            fg_color=ACCENT,
            hover_color=ACCENT_HOVER
        )
        self.clean_cb.pack(fill="x", padx=18, pady=(8, 12))

        # Output folder row
        out_row = ctk.CTkFrame(panel, fg_color="transparent")
        out_row.pack(fill="x", padx=18, pady=(0, 16))
        ctk.CTkLabel(out_row, text="Save to:", font=("Segoe UI", 12),
                     text_color="#D6D8DE").pack(side="left")
        self.output_label = ctk.CTkLabel(out_row, text=self._short_path(self.output_dir),
                                          font=("Segoe UI", 11), text_color=TEXT_MUTED)
        self.output_label.pack(side="left", padx=(8, 0))
        ctk.CTkButton(out_row, text="Change", width=70, height=26, fg_color="transparent",
                       border_width=1, border_color="#3A3C46", hover_color="#2A2C36",
                       font=("Segoe UI", 11), command=self.choose_output_dir).pack(side="right")

    def _build_footer(self):
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=28, pady=(6, 22))

        self.compress_btn = ctk.CTkButton(footer, text="Compress Files", height=44,
                                           fg_color=ACCENT, hover_color=ACCENT_HOVER,
                                           font=("Segoe UI Semibold", 14),
                                           command=self.start_compression)
        self.compress_btn.pack(fill="x")

        self.summary_label = ctk.CTkLabel(footer, text="", font=("Segoe UI", 11),
                                           text_color=TEXT_MUTED)
        self.summary_label.pack(pady=(8, 0))

    def _short_path(self, path, maxlen=38):
        return path if len(path) <= maxlen else "…" + path[-(maxlen - 1):]

    def _on_quality_change(self, val):
        val = int(val)
        if val < 30:
            label = f"Aggressive / Low Size ({val})"
        elif val < 60:
            label = f"Balanced ({val})"
        elif val < 80:
            label = f"High Quality ({val})"
        else:
            label = f"Best quality ({val})"
        self.quality_value_label.configure(text=label)

    def browse_files(self):
        paths = filedialog.askopenfilenames(
            title="Select PDF or JPEG files",
            filetypes=[("PDF and JPEG files", "*.pdf *.jpg *.jpeg"),
                       ("PDF files", "*.pdf"), ("JPEG files", "*.jpg *.jpeg")]
        )
        for p in paths:
            if p not in self.files:
                self.add_file(p)

    def add_file(self, path):
        self.files.append(path)
        if self.empty_label.winfo_ismapped():
            self.empty_label.pack_forget()
        row = FileRow(self.list_frame, path, self.remove_file)
        row.pack(fill="x", pady=4)
        self.rows[path] = row

    def remove_file(self, row: FileRow):
        self.files.remove(row.filepath)
        del self.rows[row.filepath]
        row.destroy()
        if not self.files:
            self.empty_label.pack(pady=30)

    def choose_output_dir(self):
        d = filedialog.askdirectory(title="Choose output folder")
        if d:
            self.output_dir = d
            self.output_label.configure(text=self._short_path(d))

    def start_compression(self):
        if not self.files:
            messagebox.showinfo("No files", "Add at least one PDF or JPEG file first.")
            return

        self.compress_btn.configure(state="disabled", text="Compressing…")
        self.summary_label.configure(text="")
        quality = int(self.quality_slider.get())

        # Determine DPI choice
        dpi_str = self.dpi_var.get()
        if "72" in dpi_str:
            max_dpi = 72
        elif "150" in dpi_str:
            max_dpi = 150
        else:
            max_dpi = None

        scrub = self.clean_var.get()

        for f in self.files:
            self.rows[f].show_progress()
            self.rows[f].set_status("Waiting…")

        thread = threading.Thread(target=self._compress_worker, args=(list(self.files), quality, max_dpi, scrub),
                                   daemon=True)
        thread.start()

    def _compress_worker(self, files, quality, max_dpi, scrub):
        total_before = 0
        total_after = 0
        errors = 0

        for f in files:
            try:
                self.result_queue.put(("status", f, "Compressing…"))
                stem = Path(f).stem
                ext = Path(f).suffix.lower()
                out_name = f"{stem}_compressed{ext}"
                dst = str(Path(self.output_dir) / out_name)

                if ext == ".pdf":
                    before, after = compress_pdf(f, dst, quality, max_dpi, scrub)
                else:
                    before, after = compress_jpeg(f, dst, quality)

                total_before += before
                total_after += after
                pct = max(0, round((1 - after / before) * 100)) if before else 0
                self.result_queue.put(("done", f, f"-{pct}%  ·  saved as {out_name}"))
            except Exception as e:
                errors += 1
                self.result_queue.put(("error", f, f"Failed: {e}"))

        self.result_queue.put(("finished", None, (total_before, total_after, errors)))

    def _poll_queue(self):
        try:
            while True:
                kind, f, payload = self.result_queue.get_nowait()
                if kind == "status":
                    self.rows[f].set_status(payload)
                elif kind == "done":
                    self.rows[f].set_status(payload, SUCCESS)
                    self.rows[f].hide_progress()
                elif kind == "error":
                    self.rows[f].set_status(payload, DANGER)
                    self.rows[f].hide_progress()
                elif kind == "finished":
                    before, after, errors = payload
                    self.compress_btn.configure(state="normal", text="Compress Files")
                    if before:
                        pct = round((1 - after / before) * 100)
                        mb_saved = (before - after) / (1024 * 1024)
                        msg = f"Done — reduced total size by {pct}% ({mb_saved:.1f} MB saved)"
                        if errors:
                            msg += f"  ·  {errors} file(s) failed"
                        self.summary_label.configure(text=msg, text_color=SUCCESS)
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    app = App()
    app.mainloop()
