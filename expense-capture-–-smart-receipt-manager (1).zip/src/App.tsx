import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/Navbar';
import { OfflineIndicator } from './components/OfflineIndicator';
import { AuthView } from './views/AuthView';
import { CaptureView } from './views/CaptureView';
import { ReviewQueueView } from './views/ReviewQueueView';
import { DashboardView } from './views/DashboardView';
import { TransactionsTableView } from './views/TransactionsTableView';
import { SettingsView } from './views/SettingsView';
import { AcceptanceTestsView } from './views/AcceptanceTestsView';
import { BudgetAlerts } from './components/BudgetAlerts';
import { api } from './services/api';
import { getOfflineQueue, removeFromOfflineQueue } from './services/offlineQueue';
import { Receipt, Category, AppSettings, RuleOverride, AuditLogEntry, User } from './types';

function MainApp() {
  const { user, loading } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('capture');

  // Application Data States
  const [receipts, setReceipts] = useState<Receipt[]>([]); // Starts strictly empty
  const [categories, setCategories] = useState<Category[]>([]);
  const [taxonomyVersion, setTaxonomyVersion] = useState(1);
  const [settings, setSettings] = useState<AppSettings>({
    geminiModel: 'gemini-3.8-flash',
    confidenceThreshold: 0.8,
    retentionYears: 5,
    simplifiedInvoiceThresholdMinor: 1000000,
    approvalLimitMinor: 100000,
    oldDocumentDays: 90,
    uaeWeekendMode: 'sat_sun',
    dedicatedEmail: 'invoices-capture@receipts.local',
    taxonomyVersion: 1,
  });
  const [rules, setRules] = useState<RuleOverride[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [redFlagAlertCount, setRedFlagAlertCount] = useState<number>(0);
  const [initialDataLoading, setInitialDataLoading] = useState(true);

  // Load configuration and data on authentication
  useEffect(() => {
    async function loadInitialData() {
      if (!user) return;
      try {
        const [catData, settsData, rcptData, auditData, alertsData] = await Promise.all([
          api.getCategories(),
          api.getSettings(),
          api.getReceipts(),
          api.getAuditLogs(),
          api.getEmailAlerts().catch(() => ({ alerts: [] })),
        ]);

        setCategories(catData.categories);
        setTaxonomyVersion(catData.taxonomyVersion);
        setSettings(settsData.settings);
        setRules(settsData.ruleOverrides);
        setReceipts(rcptData.receipts || []);
        setAuditLogs(auditData.logs || []);
        setRedFlagAlertCount(alertsData.alerts?.length || 0);

        if (user.role === 'Admin') {
          const uRes = await fetch('/api/users', {
            headers: { Authorization: `Bearer ${localStorage.getItem('expense_capture_token')}` },
          });
          if (uRes.ok) {
            const uData = await uRes.json();
            setUsersList(uData.users);
          }
        }
      } catch (err) {
        console.error('Failed to load app data:', err);
      } finally {
        setInitialDataLoading(false);
      }
    }

    if (user) {
      loadInitialData();
    }
  }, [user]);

  // Sync offline queue when back online
  const handleSyncOfflineQueue = async () => {
    const queue = getOfflineQueue();
    if (queue.length === 0) return;

    for (const item of queue) {
      try {
        const res = await api.processReceipt({
          imageBase64: item.imageBase64,
          fileName: item.fileName,
          fileType: item.fileType,
          costCentre: item.costCentre,
        });
        setReceipts((prev) => [res.receipt, ...prev]);
        removeFromOfflineQueue(item.id);
      } catch (err) {
        console.error('Offline item sync error:', err);
      }
    }
  };

  const handleReceiptProcessed = (newReceipt: Receipt) => {
    setReceipts((prev) => [newReceipt, ...prev.filter((r) => r.id !== newReceipt.id)]);
    // Refresh audit logs and email alerts
    api.getAuditLogs().then((res) => setAuditLogs(res.logs));
    api.getEmailAlerts().then((res) => setRedFlagAlertCount(res.alerts?.length || 0)).catch(() => {});
  };

  const handleReceiptUpdated = (updated: Receipt) => {
    setReceipts((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    api.getAuditLogs().then((res) => setAuditLogs(res.logs));
    api.getEmailAlerts().then((res) => setRedFlagAlertCount(res.alerts?.length || 0)).catch(() => {});
  };

  if (loading || (user && initialDataLoading)) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-bold text-slate-600 dark:text-slate-400">Loading Expense Tracker...</p>
        </div>
      </div>
    );
  }

  // Not authenticated: Show Login & Sign-up
  if (!user) {
    return <AuthView />;
  }

  const reviewPendingCount = receipts.filter((r) => r.status === 'in_review').length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        reviewCount={reviewPendingCount}
        redFlagAlertCount={redFlagAlertCount}
        onOpenAlerts={() => setCurrentTab('budget')}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {currentTab === 'capture' && (
          <CaptureView
            hasExistingTransactions={receipts.length > 0}
            onReceiptProcessed={(rcpt) => {
              handleReceiptProcessed(rcpt);
            }}
            onNavigateToReview={() => setCurrentTab('review')}
          />
        )}

        {currentTab === 'review' && (
          <ReviewQueueView
            receipts={receipts}
            categories={categories}
            onReceiptUpdated={handleReceiptUpdated}
            onNavigateToCapture={() => setCurrentTab('capture')}
          />
        )}

        {currentTab === 'dashboard' && (
          <DashboardView
            receipts={receipts}
            categories={categories}
            onNavigateToCapture={() => setCurrentTab('capture')}
            onNavigateToSettings={() => setCurrentTab('settings')}
            onNavigateToBudget={() => setCurrentTab('budget')}
          />
        )}

        {currentTab === 'budget' && (
          <BudgetAlerts
            categories={categories}
            receipts={receipts}
            onCategoriesUpdated={(cats, ver) => {
              setCategories(cats);
              setTaxonomyVersion(ver);
            }}
            onNavigateToCapture={() => setCurrentTab('capture')}
          />
        )}

        {currentTab === 'transactions' && (
          <TransactionsTableView
            receipts={receipts}
            categories={categories}
            auditLogs={auditLogs}
            onReceiptUpdated={handleReceiptUpdated}
            onNavigateToCapture={() => setCurrentTab('capture')}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            categories={categories}
            settings={settings}
            rules={rules}
            users={usersList}
            taxonomyVersion={taxonomyVersion}
            onCategoriesUpdated={(cats, ver) => {
              setCategories(cats);
              setTaxonomyVersion(ver);
            }}
            onSettingsUpdated={setSettings}
            onRulesUpdated={setRules}
            onUsersUpdated={setUsersList}
          />
        )}

        {currentTab === 'tests' && <AcceptanceTestsView />}
      </main>

      <OfflineIndicator onSyncNeeded={handleSyncOfflineQueue} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MainApp />
      </AuthProvider>
    </LanguageProvider>
  );
}
